.class public final Lax0;
.super Lnx0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation runtime Lq02;
    with = Lcx0;
.end annotation


# static fields
.field public static final INSTANCE:Lax0;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lax0;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lax0;->INSTANCE:Lax0;

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/String;
    .registers 1

    const-string p0, "null"

    return-object p0
.end method

.method public final serializer()Ljy0;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljy0;"
        }
    .end annotation

    sget-object p0, Lcx0;->a:Lcx0;

    return-object p0
.end method
