.class public final La30;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ld42;


# instance fields
.field public final synthetic a:I

.field public b:Z

.field public final c:Ljava/lang/Object;

.field public final d:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Laq1;Ljava/util/zip/Deflater;)V
    .registers 4

    const/4 v0, 0x0

    iput v0, p0, La30;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La30;->c:Ljava/lang/Object;

    iput-object p2, p0, La30;->d:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lsg;)V
    .registers 3

    const/4 v0, 0x1

    iput v0, p0, La30;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La30;->d:Ljava/lang/Object;

    new-instance v0, Ljh0;

    iget-object p1, p1, Lsg;->e:Ljava/lang/Object;

    check-cast p1, Lgl;

    invoke-interface {p1}, Ld42;->timeout()Lya2;

    move-result-object p1

    invoke-direct {v0, p1}, Ljh0;-><init>(Lya2;)V

    iput-object v0, p0, La30;->c:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public a(Z)V
    .registers 9

    .prologue
    iget-object v0, p0, La30;->d:Ljava/lang/Object;

    check-cast v0, Ljava/util/zip/Deflater;

    iget-object p0, p0, La30;->c:Ljava/lang/Object;

    check-cast p0, Laq1;

    iget-object v1, p0, Laq1;->b:Lvk;

    :cond_a
    :goto_a
    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Lvk;->S(I)Lkz1;

    move-result-object v2

    iget-object v3, v2, Lkz1;->a:[B

    iget v4, v2, Lkz1;->c:I

    if-eqz p1, :cond_1d

    rsub-int v5, v4, 0x2000

    const/4 v6, 0x2

    invoke-virtual {v0, v3, v4, v5, v6}, Ljava/util/zip/Deflater;->deflate([BIII)I

    move-result v3

    goto :goto_23

    :cond_1d
    rsub-int v5, v4, 0x2000

    invoke-virtual {v0, v3, v4, v5}, Ljava/util/zip/Deflater;->deflate([BII)I

    move-result v3

    :goto_23
    if-lez v3, :cond_34

    iget v4, v2, Lkz1;->c:I

    add-int/2addr v4, v3

    iput v4, v2, Lkz1;->c:I

    iget-wide v4, v1, Lvk;->b:J

    int-to-long v2, v3

    add-long/2addr v4, v2

    iput-wide v4, v1, Lvk;->b:J

    invoke-virtual {p0}, Laq1;->k()Lgl;

    goto :goto_a

    :cond_34
    invoke-virtual {v0}, Ljava/util/zip/Deflater;->needsInput()Z

    move-result v3

    if-eqz v3, :cond_a

    iget p0, v2, Lkz1;->b:I

    iget p1, v2, Lkz1;->c:I

    if-ne p0, p1, :cond_49

    invoke-virtual {v2}, Lkz1;->a()Lkz1;

    move-result-object p0

    iput-object p0, v1, Lvk;->a:Lkz1;

    invoke-static {v2}, Lmz1;->a(Lkz1;)V

    :cond_49
    return-void
.end method

.method public final close()V
    .registers 5

    .prologue
    iget v0, p0, La30;->a:I

    iget-object v1, p0, La30;->c:Ljava/lang/Object;

    const/4 v2, 0x1

    iget-object v3, p0, La30;->d:Ljava/lang/Object;

    packed-switch v0, :pswitch_data_4e

    check-cast v3, Lsg;

    iget-boolean v0, p0, La30;->b:Z

    if-eqz v0, :cond_11

    goto :goto_24

    :cond_11
    iput-boolean v2, p0, La30;->b:Z

    check-cast v1, Ljh0;

    iget-object p0, v1, Ljh0;->e:Lya2;

    sget-object v0, Lya2;->d:Lxa2;

    iput-object v0, v1, Ljh0;->e:Lya2;

    invoke-virtual {p0}, Lya2;->a()Lya2;

    invoke-virtual {p0}, Lya2;->b()Lya2;

    const/4 p0, 0x3

    iput p0, v3, Lsg;->a:I

    :goto_24
    return-void

    :pswitch_25  #0x0
    check-cast v3, Ljava/util/zip/Deflater;

    iget-boolean v0, p0, La30;->b:Z

    if-eqz v0, :cond_2c

    goto :goto_4c

    :cond_2c
    :try_start_2c
    invoke-virtual {v3}, Ljava/util/zip/Deflater;->finish()V

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, La30;->a(Z)V
    :try_end_33
    .catchall {:try_start_2c .. :try_end_33} :catchall_35

    const/4 v0, 0x0

    goto :goto_36

    :catchall_35
    move-exception v0

    :goto_36
    :try_start_36
    invoke-virtual {v3}, Ljava/util/zip/Deflater;->end()V
    :try_end_39
    .catchall {:try_start_36 .. :try_end_39} :catchall_3a

    goto :goto_3e

    :catchall_3a
    move-exception v3

    if-nez v0, :cond_3e

    move-object v0, v3

    :cond_3e
    :goto_3e
    :try_start_3e
    check-cast v1, Laq1;

    invoke-virtual {v1}, Laq1;->close()V
    :try_end_43
    .catchall {:try_start_3e .. :try_end_43} :catchall_44

    goto :goto_48

    :catchall_44
    move-exception v1

    if-nez v0, :cond_48

    move-object v0, v1

    :cond_48
    :goto_48
    iput-boolean v2, p0, La30;->b:Z

    if-nez v0, :cond_4d

    :goto_4c
    return-void

    :cond_4d
    throw v0

    :pswitch_data_4e
    .packed-switch 0x0
        :pswitch_25  #00000000
    .end packed-switch
.end method

.method public final flush()V
    .registers 2

    .prologue
    iget v0, p0, La30;->a:I

    packed-switch v0, :pswitch_data_22

    iget-boolean v0, p0, La30;->b:Z

    if-eqz v0, :cond_a

    goto :goto_15

    :cond_a
    iget-object p0, p0, La30;->d:Ljava/lang/Object;

    check-cast p0, Lsg;

    iget-object p0, p0, Lsg;->e:Ljava/lang/Object;

    check-cast p0, Lgl;

    invoke-interface {p0}, Lgl;->flush()V

    :goto_15
    return-void

    :pswitch_16  #0x0
    const/4 v0, 0x1

    invoke-virtual {p0, v0}, La30;->a(Z)V

    iget-object p0, p0, La30;->c:Ljava/lang/Object;

    check-cast p0, Laq1;

    invoke-virtual {p0}, Laq1;->flush()V

    return-void

    :pswitch_data_22
    .packed-switch 0x0
        :pswitch_16  #00000000
    .end packed-switch
.end method

.method public final r(Lvk;J)V
    .registers 14

    .prologue
    iget v0, p0, La30;->a:I

    iget-object v1, p0, La30;->d:Ljava/lang/Object;

    const-wide/16 v2, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    packed-switch v0, :pswitch_data_7c

    iget-boolean p0, p0, La30;->b:Z

    if-nez p0, :cond_30

    iget-wide v4, p1, Lvk;->b:J

    sget-object p0, Lki2;->a:[B

    cmp-long p0, p2, v2

    if-ltz p0, :cond_2a

    cmp-long p0, v2, v4

    if-gtz p0, :cond_2a

    cmp-long p0, v4, p2

    if-ltz p0, :cond_2a

    check-cast v1, Lsg;

    iget-object p0, v1, Lsg;->e:Ljava/lang/Object;

    check-cast p0, Lgl;

    invoke-interface {p0, p1, p2, p3}, Ld42;->r(Lvk;J)V

    goto :goto_35

    :cond_2a
    new-instance p0, Ljava/lang/ArrayIndexOutOfBoundsException;

    invoke-direct {p0}, Ljava/lang/ArrayIndexOutOfBoundsException;-><init>()V

    throw p0

    :cond_30
    const-string p0, "closed"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    :goto_35
    return-void

    :pswitch_36  #0x0
    iget-wide v4, p1, Lvk;->b:J

    const-wide/16 v6, 0x0

    move-wide v8, p2

    invoke-static/range {v4 .. v9}, Lpy2;->l(JJJ)V

    :goto_3e
    cmp-long v0, p2, v2

    if-lez v0, :cond_7a

    iget-object v0, p1, Lvk;->a:Lkz1;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget v4, v0, Lkz1;->c:I

    iget v5, v0, Lkz1;->b:I

    sub-int/2addr v4, v5

    int-to-long v4, v4

    invoke-static {p2, p3, v4, v5}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v4

    long-to-int v4, v4

    move-object v5, v1

    check-cast v5, Ljava/util/zip/Deflater;

    iget-object v6, v0, Lkz1;->a:[B

    iget v7, v0, Lkz1;->b:I

    invoke-virtual {v5, v6, v7, v4}, Ljava/util/zip/Deflater;->setInput([BII)V

    const/4 v5, 0x0

    invoke-virtual {p0, v5}, La30;->a(Z)V

    iget-wide v5, p1, Lvk;->b:J

    int-to-long v7, v4

    sub-long/2addr v5, v7

    iput-wide v5, p1, Lvk;->b:J

    iget v5, v0, Lkz1;->b:I

    add-int/2addr v5, v4

    iput v5, v0, Lkz1;->b:I

    iget v4, v0, Lkz1;->c:I

    if-ne v5, v4, :cond_78

    invoke-virtual {v0}, Lkz1;->a()Lkz1;

    move-result-object v4

    iput-object v4, p1, Lvk;->a:Lkz1;

    invoke-static {v0}, Lmz1;->a(Lkz1;)V

    :cond_78
    sub-long/2addr p2, v7

    goto :goto_3e

    :cond_7a
    return-void

    nop

    :pswitch_data_7c
    .packed-switch 0x0
        :pswitch_36  #00000000
    .end packed-switch
.end method

.method public final timeout()Lya2;
    .registers 2

    .prologue
    iget v0, p0, La30;->a:I

    iget-object p0, p0, La30;->c:Ljava/lang/Object;

    packed-switch v0, :pswitch_data_14

    check-cast p0, Ljh0;

    return-object p0

    :pswitch_a  #0x0
    check-cast p0, Laq1;

    iget-object p0, p0, Laq1;->a:Ld42;

    invoke-interface {p0}, Ld42;->timeout()Lya2;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_14
    .packed-switch 0x0
        :pswitch_a  #00000000
    .end packed-switch
.end method

.method public toString()Ljava/lang/String;
    .registers 3

    .prologue
    iget v0, p0, La30;->a:I

    packed-switch v0, :pswitch_data_22

    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :pswitch_a  #0x0
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "DeflaterSink("

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object p0, p0, La30;->c:Ljava/lang/Object;

    check-cast p0, Laq1;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 p0, 0x29

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :pswitch_data_22
    .packed-switch 0x0
        :pswitch_a  #00000000
    .end packed-switch
.end method
