.class public final Lb21;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ljava/util/Iterator;
.implements Lgy0;


# instance fields
.field public final a:Ljava/lang/CharSequence;

.field public b:I

.field public c:I

.field public d:I

.field public e:I


# direct methods
.method public constructor <init>(Ljava/lang/CharSequence;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lb21;->a:Ljava/lang/CharSequence;

    return-void
.end method


# virtual methods
.method public final hasNext()Z
    .registers 10

    .prologue
    iget v0, p0, Lb21;->b:I

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_a

    if-ne v0, v2, :cond_9

    return v2

    :cond_9
    return v1

    :cond_a
    iget v0, p0, Lb21;->e:I

    const/4 v3, 0x2

    if-gez v0, :cond_12

    iput v3, p0, Lb21;->b:I

    return v1

    :cond_12
    iget-object v0, p0, Lb21;->a:Ljava/lang/CharSequence;

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v1

    iget v4, p0, Lb21;->c:I

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v5

    :goto_1e
    if-ge v4, v5, :cond_43

    invoke-interface {v0, v4}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v6

    const/16 v7, 0xd

    const/16 v8, 0xa

    if-eq v6, v8, :cond_2f

    if-eq v6, v7, :cond_2f

    add-int/lit8 v4, v4, 0x1

    goto :goto_1e

    :cond_2f
    if-ne v6, v7, :cond_40

    add-int/lit8 v1, v4, 0x1

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v5

    if-ge v1, v5, :cond_40

    invoke-interface {v0, v1}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v0

    if-ne v0, v8, :cond_40

    goto :goto_41

    :cond_40
    move v3, v2

    :goto_41
    move v1, v4

    goto :goto_44

    :cond_43
    const/4 v3, -0x1

    :goto_44
    iput v2, p0, Lb21;->b:I

    iput v3, p0, Lb21;->e:I

    iput v1, p0, Lb21;->d:I

    return v2
.end method

.method public final next()Ljava/lang/Object;
    .registers 4

    .prologue
    invoke-virtual {p0}, Lb21;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_1d

    const/4 v0, 0x0

    iput v0, p0, Lb21;->b:I

    iget v0, p0, Lb21;->d:I

    iget v1, p0, Lb21;->c:I

    iget v2, p0, Lb21;->e:I

    add-int/2addr v2, v0

    iput v2, p0, Lb21;->c:I

    iget-object p0, p0, Lb21;->a:Ljava/lang/CharSequence;

    invoke-interface {p0, v1, v0}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_1d
    invoke-static {}, Lvx2;->s()V

    const/4 p0, 0x0

    return-object p0
.end method

.method public final remove()V
    .registers 2

    new-instance p0, Ljava/lang/UnsupportedOperationException;

    const-string v0, "Operation is not supported for read-only collection"

    invoke-direct {p0, v0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p0
.end method
