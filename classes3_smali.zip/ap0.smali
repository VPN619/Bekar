.class public final Lap0;
.super Lr92;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final synthetic e:I

.field public final synthetic f:Ldp0;

.field public final synthetic g:I

.field public final synthetic h:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;Ldp0;ILjava/lang/Object;I)V
    .registers 6

    iput p5, p0, Lap0;->e:I

    iput-object p2, p0, Lap0;->f:Ldp0;

    iput p3, p0, Lap0;->g:I

    iput-object p4, p0, Lap0;->h:Ljava/lang/Object;

    const/4 p2, 0x1

    invoke-direct {p0, p1, p2}, Lr92;-><init>(Ljava/lang/String;Z)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ldp0;ILjava/util/List;Z)V
    .registers 6

    const/4 p5, 0x0

    iput p5, p0, Lap0;->e:I

    iput-object p2, p0, Lap0;->f:Ldp0;

    iput p3, p0, Lap0;->g:I

    iput-object p4, p0, Lap0;->h:Ljava/lang/Object;

    const/4 p2, 0x1

    invoke-direct {p0, p1, p2}, Lr92;-><init>(Ljava/lang/String;Z)V

    return-void
.end method


# virtual methods
.method public final a()J
    .registers 6

    .prologue
    iget v0, p0, Lap0;->e:I

    const-wide/16 v1, -0x1

    packed-switch v0, :pswitch_data_6c

    iget-object v0, p0, Lap0;->f:Ldp0;

    :try_start_9
    iget v3, p0, Lap0;->g:I

    iget-object p0, p0, Lap0;->h:Ljava/lang/Object;

    check-cast p0, Lfb0;

    iget-object v4, v0, Ldp0;->w:Llp0;

    invoke-virtual {v4, v3, p0}, Llp0;->p(ILfb0;)V
    :try_end_14
    .catch Ljava/io/IOException; {:try_start_9 .. :try_end_14} :catch_15

    goto :goto_1b

    :catch_15
    move-exception p0

    sget-object v3, Lfb0;->c:Lfb0;

    invoke-virtual {v0, v3, v3, p0}, Ldp0;->a(Lfb0;Lfb0;Ljava/io/IOException;)V

    :goto_1b
    return-wide v1

    :pswitch_1c  #0x1
    iget-object v0, p0, Lap0;->f:Ldp0;

    iget-object v0, v0, Ldp0;->k:Lkn0;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_23
    iget-object v0, p0, Lap0;->f:Ldp0;

    iget-object v0, v0, Ldp0;->w:Llp0;

    iget v3, p0, Lap0;->g:I

    sget-object v4, Lfb0;->g:Lfb0;

    invoke-virtual {v0, v3, v4}, Llp0;->p(ILfb0;)V

    iget-object v0, p0, Lap0;->f:Ldp0;

    monitor-enter v0
    :try_end_31
    .catch Ljava/io/IOException; {:try_start_23 .. :try_end_31} :catch_43

    :try_start_31
    iget-object v3, p0, Lap0;->f:Ldp0;

    iget-object v3, v3, Ldp0;->y:Ljava/util/LinkedHashSet;

    iget p0, p0, Lap0;->g:I

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    invoke-interface {v3, p0}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z
    :try_end_3e
    .catchall {:try_start_31 .. :try_end_3e} :catchall_40

    :try_start_3e
    monitor-exit v0

    goto :goto_43

    :catchall_40
    move-exception p0

    monitor-exit v0

    throw p0
    :try_end_43
    .catch Ljava/io/IOException; {:try_start_3e .. :try_end_43} :catch_43

    :catch_43
    :goto_43
    return-wide v1

    :pswitch_44  #0x0
    iget-object v0, p0, Lap0;->f:Ldp0;

    iget-object v0, v0, Ldp0;->k:Lkn0;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_4b
    iget-object v0, p0, Lap0;->f:Ldp0;

    iget-object v0, v0, Ldp0;->w:Llp0;

    iget v3, p0, Lap0;->g:I

    sget-object v4, Lfb0;->g:Lfb0;

    invoke-virtual {v0, v3, v4}, Llp0;->p(ILfb0;)V

    iget-object v0, p0, Lap0;->f:Ldp0;

    monitor-enter v0
    :try_end_59
    .catch Ljava/io/IOException; {:try_start_4b .. :try_end_59} :catch_6b

    :try_start_59
    iget-object v3, p0, Lap0;->f:Ldp0;

    iget-object v3, v3, Ldp0;->y:Ljava/util/LinkedHashSet;

    iget p0, p0, Lap0;->g:I

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    invoke-interface {v3, p0}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z
    :try_end_66
    .catchall {:try_start_59 .. :try_end_66} :catchall_68

    :try_start_66
    monitor-exit v0

    goto :goto_6b

    :catchall_68
    move-exception p0

    monitor-exit v0

    throw p0
    :try_end_6b
    .catch Ljava/io/IOException; {:try_start_66 .. :try_end_6b} :catch_6b

    :catch_6b
    :goto_6b
    return-wide v1

    :pswitch_data_6c
    .packed-switch 0x0
        :pswitch_44  #00000000
        :pswitch_1c  #00000001
    .end packed-switch
.end method
