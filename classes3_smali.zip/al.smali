.class public final synthetic Lal;
.super Lzk0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lrk0;


# static fields
.field public static final h:Lal;


# direct methods
.method static constructor <clinit>()V
    .registers 6

    new-instance v0, Lal;

    const-string v4, "processResultSelectReceive(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;"

    const/4 v5, 0x0

    const/4 v1, 0x3

    const-class v2, Ldl;

    const-string v3, "processResultSelectReceive"

    invoke-direct/range {v0 .. v5}, Lzk0;-><init>(ILjava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    sput-object v0, Lal;->h:Lal;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .prologue
    check-cast p1, Ldl;

    sget-object p0, Ldl;->b:Ljava/util/concurrent/atomic/AtomicLongFieldUpdater;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object p0, Lfl;->l:Lq5;

    if-eq p3, p0, :cond_c

    return-object p3

    :cond_c
    invoke-virtual {p1}, Ldl;->q()Ljava/lang/Throwable;

    move-result-object p0

    throw p0
.end method
