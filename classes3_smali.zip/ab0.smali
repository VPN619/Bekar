.class public final Lab0;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ljy0;


# instance fields
.field public final a:[Ljava/lang/Enum;

.field public final b:Lw82;


# direct methods
.method public constructor <init>(Ljava/lang/String;[Ljava/lang/Enum;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Lab0;->a:[Ljava/lang/Enum;

    new-instance p2, Lwh;

    const/4 v0, 0x2

    invoke-direct {p2, v0, p0, p1}, Lwh;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    new-instance p1, Lw82;

    invoke-direct {p1, p2}, Lw82;-><init>(Lzj0;)V

    iput-object p1, p0, Lab0;->b:Lw82;

    return-void
.end method


# virtual methods
.method public final deserialize(Lj10;)Ljava/lang/Object;
    .registers 5

    .prologue
    invoke-virtual {p0}, Lab0;->getDescriptor()Lm02;

    move-result-object v0

    invoke-interface {p1, v0}, Lj10;->u(Lm02;)I

    move-result p1

    iget-object v0, p0, Lab0;->a:[Ljava/lang/Enum;

    if-ltz p1, :cond_12

    array-length v1, v0

    if-ge p1, v1, :cond_12

    aget-object p0, v0, p1

    return-object p0

    :cond_12
    new-instance v1, Lt02;

    invoke-virtual {p0}, Lab0;->getDescriptor()Lm02;

    move-result-object p0

    invoke-interface {p0}, Lm02;->a()Ljava/lang/String;

    move-result-object p0

    array-length v0, v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, " is not among valid "

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " enum values, values size is "

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v1
.end method

.method public final getDescriptor()Lm02;
    .registers 1

    iget-object p0, p0, Lab0;->b:Lw82;

    invoke-virtual {p0}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lm02;

    return-object p0
.end method

.method public final serialize(Lga0;Ljava/lang/Object;)V
    .registers 6

    .prologue
    check-cast p2, Ljava/lang/Enum;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Lab0;->a:[Ljava/lang/Enum;

    invoke-static {p2, v0}, Laf;->l0(Ljava/lang/Object;[Ljava/lang/Object;)I

    move-result v1

    const/4 v2, -0x1

    if-eq v1, v2, :cond_16

    invoke-virtual {p0}, Lab0;->getDescriptor()Lm02;

    move-result-object p0

    invoke-interface {p1, p0, v1}, Lga0;->u(Lm02;I)V

    return-void

    :cond_16
    new-instance p1, Lt02;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lab0;->getDescriptor()Lm02;

    move-result-object p0

    invoke-interface {p0}, Lm02;->a()Ljava/lang/String;

    move-result-object p0

    invoke-static {v0}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v0, " is not a valid enum "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, ", must be one of "

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "kotlinx.serialization.internal.EnumSerializer<"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Lab0;->getDescriptor()Lm02;

    move-result-object p0

    invoke-interface {p0}, Lm02;->a()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 p0, 0x3e

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
