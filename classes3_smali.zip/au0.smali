.class public final Lau0;
.super Llz;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final p:Ljava/util/concurrent/atomic/AtomicLong;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    new-instance v0, Ljava/util/concurrent/atomic/AtomicLong;

    const-wide/16 v1, 0x0

    invoke-direct {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicLong;-><init>(J)V

    sput-object v0, Lau0;->p:Ljava/util/concurrent/atomic/AtomicLong;

    return-void
.end method


# virtual methods
.method public final addPublicKeyPins(Ljava/lang/String;Ljava/util/Set;ZLjava/util/Date;)Lorg/chromium/net/ICronetEngineBuilder;
    .registers 7

    .prologue
    const-string p3, "The hostname cannot be null."

    invoke-static {p1, p3}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    const-string p3, "The set of SHA256 pins cannot be null."

    invoke-static {p2, p3}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    const-string p3, "The pin expiration date cannot be null."

    invoke-static {p4, p3}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    sget-object p3, Llz;->n:Ljava/util/regex/Pattern;

    invoke-virtual {p3, p1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object p3

    invoke-virtual {p3}, Ljava/util/regex/Matcher;->matches()Z

    move-result p3

    const/4 p4, 0x0

    const-string v0, "Hostname "

    if-nez p3, :cond_86

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result p3

    const/16 v1, 0xff

    if-gt p3, v1, :cond_7c

    const/4 p3, 0x2

    :try_start_27
    invoke-static {p1, p3}, Ljava/net/IDN;->toASCII(Ljava/lang/String;I)Ljava/lang/String;
    :try_end_2a
    .catch Ljava/lang/IllegalArgumentException; {:try_start_27 .. :try_end_2a} :catch_72

    new-instance p1, Ljava/util/HashMap;

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    invoke-interface {p2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_33
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result p3

    if-eqz p3, :cond_55

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p3

    check-cast p3, [B

    if-eqz p3, :cond_4f

    array-length v0, p3

    const/16 v1, 0x20

    if-ne v0, v1, :cond_4f

    const/4 v0, 0x0

    invoke-static {p3, v0}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0, p3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_33

    :cond_4f
    const-string p0, "Public key pin is invalid"

    invoke-static {p0}, Lz6;->s(Ljava/lang/String;)V

    return-object p4

    :cond_55
    new-instance p2, Lp80;

    invoke-virtual {p1}, Ljava/util/HashMap;->values()Ljava/util/Collection;

    move-result-object p3

    invoke-virtual {p1}, Ljava/util/HashMap;->size()I

    move-result p1

    new-array p1, p1, [[B

    invoke-interface {p3, p1}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p1

    check-cast p1, [[B

    const/16 p1, 0x15

    invoke-direct {p2, p1}, Lp80;-><init>(I)V

    iget-object p1, p0, Llz;->d:Ljava/util/ArrayList;

    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-object p0

    :catch_72
    const-string p0, " is illegal. The name of the host does not comply with RFC 1122 and RFC 1123."

    invoke-static {v0, p1, p0}, Lrt2;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->s(Ljava/lang/String;)V

    return-object p4

    :cond_7c
    const-string p0, " is too long. The name of the host does not comply with RFC 1122 and RFC 1123."

    invoke-static {v0, p1, p0}, Lrt2;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->s(Ljava/lang/String;)V

    return-object p4

    :cond_86
    const-string p0, " is illegal. A hostname should not consist of digits and/or dots only."

    invoke-static {v0, p1, p0}, Lrt2;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->s(Ljava/lang/String;)V

    return-object p4
.end method

.method public final addQuicHint(Ljava/lang/String;II)Lorg/chromium/net/ICronetEngineBuilder;
    .registers 4

    .prologue
    const-string p2, "/"

    invoke-virtual {p1, p2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p2

    if-nez p2, :cond_15

    new-instance p1, Lkn0;

    const/16 p2, 0x15

    invoke-direct {p1, p2}, Lkn0;-><init>(I)V

    iget-object p2, p0, Llz;->c:Ljava/util/ArrayList;

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-object p0

    :cond_15
    const-string p0, "Illegal QUIC Hint Host: "

    invoke-virtual {p0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->s(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public final build()Lorg/chromium/net/ExperimentalCronetEngine;
    .registers 2

    .prologue
    iget-object v0, p0, Llz;->f:Ljava/lang/String;

    if-nez v0, :cond_a

    invoke-virtual {p0}, Llz;->getDefaultUserAgent()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Llz;->f:Ljava/lang/String;

    :cond_a
    new-instance v0, Lzt0;

    invoke-direct {v0, p0}, Lzt0;-><init>(Lau0;)V

    return-object v0
.end method

.method public final enableBrotli(Z)Lorg/chromium/net/ICronetEngineBuilder;
    .registers 2

    iput-boolean p1, p0, Llz;->j:Z

    return-object p0
.end method

.method public final enableHttp2(Z)Lorg/chromium/net/ICronetEngineBuilder;
    .registers 2

    iput-boolean p1, p0, Llz;->i:Z

    return-object p0
.end method

.method public final bridge synthetic enableHttpCache(IJ)Lorg/chromium/net/ICronetEngineBuilder;
    .registers 4

    invoke-virtual {p0, p1}, Llz;->a(I)V

    return-object p0
.end method

.method public final enableNetworkQualityEstimator(Z)Lorg/chromium/net/ICronetEngineBuilder;
    .registers 2

    iput-boolean p1, p0, Llz;->m:Z

    return-object p0
.end method

.method public final enablePublicKeyPinningBypassForLocalTrustAnchors(Z)Lorg/chromium/net/ICronetEngineBuilder;
    .registers 2

    iput-boolean p1, p0, Llz;->e:Z

    return-object p0
.end method

.method public final enableQuic(Z)Lorg/chromium/net/ICronetEngineBuilder;
    .registers 2

    iput-boolean p1, p0, Llz;->h:Z

    return-object p0
.end method

.method public final enableSdch(Z)Lorg/chromium/net/ICronetEngineBuilder;
    .registers 2

    return-object p0
.end method

.method public final getLogCronetInitializationRef()J
    .registers 5

    iget-object p0, p0, Llz;->a:Lg73;

    invoke-virtual {p0}, Lg73;->t()J

    move-result-wide v0

    sget-object p0, Lau0;->p:Ljava/util/concurrent/atomic/AtomicLong;

    const-wide/16 v2, 0x0

    invoke-virtual {p0, v2, v3, v0, v1}, Ljava/util/concurrent/atomic/AtomicLong;->compareAndSet(JJ)Z

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicLong;->get()J

    move-result-wide v0

    return-wide v0
.end method

.method public final setExperimentalOptions(Ljava/lang/String;)Lorg/chromium/net/ICronetEngineBuilder;
    .registers 2

    iput-object p1, p0, Llz;->l:Ljava/lang/String;

    return-object p0
.end method

.method public final setLibraryLoader(Lorg/chromium/net/CronetEngine$Builder$LibraryLoader;)Lorg/chromium/net/ICronetEngineBuilder;
    .registers 2

    return-object p0
.end method

.method public final setProxyOptions(Lorg/chromium/net/ProxyOptions;)Lorg/chromium/net/ICronetEngineBuilder;
    .registers 5

    .prologue
    if-eqz p1, :cond_2c

    invoke-static {}, Lns2;->n()I

    move-result v0

    const/16 v1, 0x26

    const/4 v2, 0x0

    if-lt v0, v1, :cond_1c

    invoke-virtual {p1}, Lorg/chromium/net/ProxyOptions;->getProxyList()Ljava/util/List;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result p1

    if-nez p1, :cond_16

    goto :goto_2c

    :cond_16
    const-string p0, "The list of proxies should never be empty, this is checked in the API layer"

    invoke-static {p0}, Lz6;->q(Ljava/lang/Object;)V

    return-object v2

    :cond_1c
    invoke-static {}, Lns2;->n()I

    move-result p0

    const-string p1, "This should have not been created: the Cronet API being used has an ApiLevel of "

    const-string v0, ", but setProxyOptions was added in ApiLevel 38"

    invoke-static {p0, p1, v0}, Lrt2;->g(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->q(Ljava/lang/Object;)V

    return-object v2

    :cond_2c
    :goto_2c
    return-object p0
.end method

.method public final setStoragePath(Ljava/lang/String;)Lorg/chromium/net/ICronetEngineBuilder;
    .registers 3

    .prologue
    new-instance v0, Ljava/io/File;

    invoke-direct {v0, p1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->isDirectory()Z

    move-result v0

    if-eqz v0, :cond_e

    iput-object p1, p0, Llz;->g:Ljava/lang/String;

    return-object p0

    :cond_e
    const-string p0, "Storage path must be set to existing directory"

    invoke-static {p0}, Lz6;->s(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public final setThreadPriority(I)Lorg/chromium/net/ICronetEngineBuilder;
    .registers 2

    return-object p0
.end method

.method public final setUserAgent(Ljava/lang/String;)Lorg/chromium/net/ICronetEngineBuilder;
    .registers 2

    iput-object p1, p0, Llz;->f:Ljava/lang/String;

    return-object p0
.end method
