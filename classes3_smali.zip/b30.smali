.class public interface abstract Lb30;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# virtual methods
.method public abstract p(JLjava/lang/Runnable;Lly;)Lk50;
.end method

.method public abstract y(JLjn;)V
.end method
