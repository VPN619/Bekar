.class public final Lads_mobile_sdk/c21;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Lads_mobile_sdk/qr0;

.field public final b:Ltv2;

.field public final c:Ltv2;

.field public final d:Lads_mobile_sdk/i41;

.field public final e:Lw82;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/qr0;Ltv2;Ltv2;Lads_mobile_sdk/i41;)V
    .registers 5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/c21;->a:Lads_mobile_sdk/qr0;

    iput-object p2, p0, Lads_mobile_sdk/c21;->b:Ltv2;

    iput-object p3, p0, Lads_mobile_sdk/c21;->c:Ltv2;

    iput-object p4, p0, Lads_mobile_sdk/c21;->d:Lads_mobile_sdk/i41;

    new-instance p1, Lxm0;

    const/4 p2, 0x2

    invoke-direct {p1, p2, p0}, Lxm0;-><init>(ILjava/lang/Object;)V

    new-instance p2, Lw82;

    invoke-direct {p2, p1}, Lw82;-><init>(Lzj0;)V

    iput-object p2, p0, Lads_mobile_sdk/c21;->e:Lw82;

    return-void
.end method
