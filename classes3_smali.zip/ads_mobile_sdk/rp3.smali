.class public final Lads_mobile_sdk/rp3;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Landroid/view/ViewGroup$LayoutParams;

.field public final b:I

.field public final c:Landroid/view/ViewGroup;

.field public final d:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/view/ViewGroup$LayoutParams;ILandroid/view/ViewGroup;Landroid/content/Context;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/rp3;->a:Landroid/view/ViewGroup$LayoutParams;

    iput p2, p0, Lads_mobile_sdk/rp3;->b:I

    iput-object p3, p0, Lads_mobile_sdk/rp3;->c:Landroid/view/ViewGroup;

    iput-object p4, p0, Lads_mobile_sdk/rp3;->d:Landroid/content/Context;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    .prologue
    if-ne p0, p1, :cond_3

    goto :goto_33

    :cond_3
    instance-of v0, p1, Lads_mobile_sdk/rp3;

    if-nez v0, :cond_8

    goto :goto_31

    :cond_8
    check-cast p1, Lads_mobile_sdk/rp3;

    iget-object v0, p0, Lads_mobile_sdk/rp3;->a:Landroid/view/ViewGroup$LayoutParams;

    iget-object v1, p1, Lads_mobile_sdk/rp3;->a:Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_15

    goto :goto_31

    :cond_15
    iget v0, p0, Lads_mobile_sdk/rp3;->b:I

    iget v1, p1, Lads_mobile_sdk/rp3;->b:I

    if-eq v0, v1, :cond_1c

    goto :goto_31

    :cond_1c
    iget-object v0, p0, Lads_mobile_sdk/rp3;->c:Landroid/view/ViewGroup;

    iget-object v1, p1, Lads_mobile_sdk/rp3;->c:Landroid/view/ViewGroup;

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_27

    goto :goto_31

    :cond_27
    iget-object p0, p0, Lads_mobile_sdk/rp3;->d:Landroid/content/Context;

    iget-object p1, p1, Lads_mobile_sdk/rp3;->d:Landroid/content/Context;

    invoke-virtual {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_33

    :goto_31
    const/4 p0, 0x0

    return p0

    :cond_33
    :goto_33
    const/4 p0, 0x1

    return p0
.end method

.method public final hashCode()I
    .registers 3

    iget-object v0, p0, Lads_mobile_sdk/rp3;->a:Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, Lads_mobile_sdk/rp3;->b:I

    invoke-static {v1, v0}, Lsz;->c(II)I

    move-result v0

    iget-object v1, p0, Lads_mobile_sdk/rp3;->c:Landroid/view/ViewGroup;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    mul-int/lit8 v1, v1, 0x1f

    iget-object p0, p0, Lads_mobile_sdk/rp3;->d:Landroid/content/Context;

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result p0

    add-int/2addr p0, v1

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "WebViewParentLayoutInfo(layoutParams="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lads_mobile_sdk/rp3;->a:Landroid/view/ViewGroup$LayoutParams;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", index="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lads_mobile_sdk/rp3;->b:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", parent="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lads_mobile_sdk/rp3;->c:Landroid/view/ViewGroup;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", originalContext="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, Lads_mobile_sdk/rp3;->d:Landroid/content/Context;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
