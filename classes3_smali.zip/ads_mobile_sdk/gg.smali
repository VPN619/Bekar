.class public final Lads_mobile_sdk/gg;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lzx2;


# instance fields
.field public final a:Ljava/nio/channels/FileChannel;

.field public final b:J

.field public final c:J


# direct methods
.method public constructor <init>(Ljava/nio/channels/FileChannel;JJ)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/gg;->a:Ljava/nio/channels/FileChannel;

    iput-wide p2, p0, Lads_mobile_sdk/gg;->b:J

    iput-wide p4, p0, Lads_mobile_sdk/gg;->c:J

    return-void
.end method


# virtual methods
.method public final a([Ljava/security/MessageDigest;JI)V
    .registers 13

    .prologue
    iget-wide v0, p0, Lads_mobile_sdk/gg;->b:J

    add-long v4, v0, p2

    sget-object v3, Ljava/nio/channels/FileChannel$MapMode;->READ_ONLY:Ljava/nio/channels/FileChannel$MapMode;

    int-to-long v6, p4

    iget-object v2, p0, Lads_mobile_sdk/gg;->a:Ljava/nio/channels/FileChannel;

    invoke-virtual/range {v2 .. v7}, Ljava/nio/channels/FileChannel;->map(Ljava/nio/channels/FileChannel$MapMode;JJ)Ljava/nio/MappedByteBuffer;

    move-result-object p0

    invoke-virtual {p0}, Ljava/nio/MappedByteBuffer;->load()Ljava/nio/MappedByteBuffer;

    array-length p2, p1

    const/4 p3, 0x0

    move p4, p3

    :goto_13
    if-ge p4, p2, :cond_20

    aget-object v0, p1, p4

    invoke-virtual {p0, p3}, Ljava/nio/MappedByteBuffer;->position(I)Ljava/nio/Buffer;

    invoke-virtual {v0, p0}, Ljava/security/MessageDigest;->update(Ljava/nio/ByteBuffer;)V

    add-int/lit8 p4, p4, 0x1

    goto :goto_13

    :cond_20
    return-void
.end method

.method public final size()J
    .registers 3

    iget-wide v0, p0, Lads_mobile_sdk/gg;->c:J

    return-wide v0
.end method
