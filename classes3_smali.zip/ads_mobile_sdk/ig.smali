.class public final Lads_mobile_sdk/ig;
.super Ljava/security/cert/X509Certificate;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Ljava/security/cert/X509Certificate;

.field public final b:[B


# direct methods
.method public constructor <init>(Ljava/security/cert/X509Certificate;[B)V
    .registers 3

    invoke-direct {p0}, Ljava/security/cert/X509Certificate;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/ig;->a:Ljava/security/cert/X509Certificate;

    iput-object p2, p0, Lads_mobile_sdk/ig;->b:[B

    return-void
.end method


# virtual methods
.method public final checkValidity()V
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/ig;->a:Ljava/security/cert/X509Certificate;

    invoke-virtual {p0}, Ljava/security/cert/X509Certificate;->checkValidity()V

    return-void
.end method

.method public final checkValidity(Ljava/util/Date;)V
    .registers 2

    iget-object p0, p0, Lads_mobile_sdk/ig;->a:Ljava/security/cert/X509Certificate;

    invoke-virtual {p0, p1}, Ljava/security/cert/X509Certificate;->checkValidity(Ljava/util/Date;)V

    return-void
.end method

.method public final getBasicConstraints()I
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/ig;->a:Ljava/security/cert/X509Certificate;

    invoke-virtual {p0}, Ljava/security/cert/X509Certificate;->getBasicConstraints()I

    move-result p0

    return p0
.end method

.method public final getCriticalExtensionOIDs()Ljava/util/Set;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/ig;->a:Ljava/security/cert/X509Certificate;

    invoke-interface {p0}, Ljava/security/cert/X509Extension;->getCriticalExtensionOIDs()Ljava/util/Set;

    move-result-object p0

    return-object p0
.end method

.method public final getEncoded()[B
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/ig;->b:[B

    return-object p0
.end method

.method public final getExtensionValue(Ljava/lang/String;)[B
    .registers 2

    iget-object p0, p0, Lads_mobile_sdk/ig;->a:Ljava/security/cert/X509Certificate;

    invoke-interface {p0, p1}, Ljava/security/cert/X509Extension;->getExtensionValue(Ljava/lang/String;)[B

    move-result-object p0

    return-object p0
.end method

.method public final getIssuerDN()Ljava/security/Principal;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/ig;->a:Ljava/security/cert/X509Certificate;

    invoke-virtual {p0}, Ljava/security/cert/X509Certificate;->getIssuerDN()Ljava/security/Principal;

    move-result-object p0

    return-object p0
.end method

.method public final getIssuerUniqueID()[Z
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/ig;->a:Ljava/security/cert/X509Certificate;

    invoke-virtual {p0}, Ljava/security/cert/X509Certificate;->getIssuerUniqueID()[Z

    move-result-object p0

    return-object p0
.end method

.method public final getKeyUsage()[Z
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/ig;->a:Ljava/security/cert/X509Certificate;

    invoke-virtual {p0}, Ljava/security/cert/X509Certificate;->getKeyUsage()[Z

    move-result-object p0

    return-object p0
.end method

.method public final getNonCriticalExtensionOIDs()Ljava/util/Set;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/ig;->a:Ljava/security/cert/X509Certificate;

    invoke-interface {p0}, Ljava/security/cert/X509Extension;->getNonCriticalExtensionOIDs()Ljava/util/Set;

    move-result-object p0

    return-object p0
.end method

.method public final getNotAfter()Ljava/util/Date;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/ig;->a:Ljava/security/cert/X509Certificate;

    invoke-virtual {p0}, Ljava/security/cert/X509Certificate;->getNotAfter()Ljava/util/Date;

    move-result-object p0

    return-object p0
.end method

.method public final getNotBefore()Ljava/util/Date;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/ig;->a:Ljava/security/cert/X509Certificate;

    invoke-virtual {p0}, Ljava/security/cert/X509Certificate;->getNotBefore()Ljava/util/Date;

    move-result-object p0

    return-object p0
.end method

.method public final getPublicKey()Ljava/security/PublicKey;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/ig;->a:Ljava/security/cert/X509Certificate;

    invoke-virtual {p0}, Ljava/security/cert/Certificate;->getPublicKey()Ljava/security/PublicKey;

    move-result-object p0

    return-object p0
.end method

.method public final getSerialNumber()Ljava/math/BigInteger;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/ig;->a:Ljava/security/cert/X509Certificate;

    invoke-virtual {p0}, Ljava/security/cert/X509Certificate;->getSerialNumber()Ljava/math/BigInteger;

    move-result-object p0

    return-object p0
.end method

.method public final getSigAlgName()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/ig;->a:Ljava/security/cert/X509Certificate;

    invoke-virtual {p0}, Ljava/security/cert/X509Certificate;->getSigAlgName()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public final getSigAlgOID()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/ig;->a:Ljava/security/cert/X509Certificate;

    invoke-virtual {p0}, Ljava/security/cert/X509Certificate;->getSigAlgOID()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public final getSigAlgParams()[B
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/ig;->a:Ljava/security/cert/X509Certificate;

    invoke-virtual {p0}, Ljava/security/cert/X509Certificate;->getSigAlgParams()[B

    move-result-object p0

    return-object p0
.end method

.method public final getSignature()[B
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/ig;->a:Ljava/security/cert/X509Certificate;

    invoke-virtual {p0}, Ljava/security/cert/X509Certificate;->getSignature()[B

    move-result-object p0

    return-object p0
.end method

.method public final getSubjectDN()Ljava/security/Principal;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/ig;->a:Ljava/security/cert/X509Certificate;

    invoke-virtual {p0}, Ljava/security/cert/X509Certificate;->getSubjectDN()Ljava/security/Principal;

    move-result-object p0

    return-object p0
.end method

.method public final getSubjectUniqueID()[Z
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/ig;->a:Ljava/security/cert/X509Certificate;

    invoke-virtual {p0}, Ljava/security/cert/X509Certificate;->getSubjectUniqueID()[Z

    move-result-object p0

    return-object p0
.end method

.method public final getTBSCertificate()[B
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/ig;->a:Ljava/security/cert/X509Certificate;

    invoke-virtual {p0}, Ljava/security/cert/X509Certificate;->getTBSCertificate()[B

    move-result-object p0

    return-object p0
.end method

.method public final getVersion()I
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/ig;->a:Ljava/security/cert/X509Certificate;

    invoke-virtual {p0}, Ljava/security/cert/X509Certificate;->getVersion()I

    move-result p0

    return p0
.end method

.method public final hasUnsupportedCriticalExtension()Z
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/ig;->a:Ljava/security/cert/X509Certificate;

    invoke-interface {p0}, Ljava/security/cert/X509Extension;->hasUnsupportedCriticalExtension()Z

    move-result p0

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/ig;->a:Ljava/security/cert/X509Certificate;

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public final verify(Ljava/security/PublicKey;)V
    .registers 2

    iget-object p0, p0, Lads_mobile_sdk/ig;->a:Ljava/security/cert/X509Certificate;

    invoke-virtual {p0, p1}, Ljava/security/cert/Certificate;->verify(Ljava/security/PublicKey;)V

    return-void
.end method

.method public final verify(Ljava/security/PublicKey;Ljava/lang/String;)V
    .registers 3

    iget-object p0, p0, Lads_mobile_sdk/ig;->a:Ljava/security/cert/X509Certificate;

    invoke-virtual {p0, p1, p2}, Ljava/security/cert/Certificate;->verify(Ljava/security/PublicKey;Ljava/lang/String;)V

    return-void
.end method
