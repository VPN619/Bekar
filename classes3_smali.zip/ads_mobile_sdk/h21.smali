.class public final Lads_mobile_sdk/h21;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Ljava/net/URL;

.field public final b:Ljava/lang/String;

.field public final c:Ljava/util/Map;

.field public final d:[B

.field public final e:Lads_mobile_sdk/in0;

.field public final f:Lx63;


# direct methods
.method public constructor <init>(Ljava/net/URL;Ljava/lang/String;Ljava/util/Map;[BLads_mobile_sdk/in0;Lx63;)V
    .registers 7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/h21;->a:Ljava/net/URL;

    iput-object p2, p0, Lads_mobile_sdk/h21;->b:Ljava/lang/String;

    iput-object p3, p0, Lads_mobile_sdk/h21;->c:Ljava/util/Map;

    iput-object p4, p0, Lads_mobile_sdk/h21;->d:[B

    iput-object p5, p0, Lads_mobile_sdk/h21;->e:Lads_mobile_sdk/in0;

    iput-object p6, p0, Lads_mobile_sdk/h21;->f:Lx63;

    return-void
.end method


# virtual methods
.method public final h()Lkt1;
    .registers 7

    .prologue
    new-instance v0, Lft1;

    invoke-direct {v0}, Lft1;-><init>()V

    iget-object v1, p0, Lads_mobile_sdk/h21;->a:Ljava/net/URL;

    invoke-virtual {v1}, Ljava/net/URL;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v2, Lnp0;

    const/4 v3, 0x0

    invoke-direct {v2, v3}, Lnp0;-><init>(I)V

    const/4 v4, 0x0

    invoke-virtual {v2, v4, v1}, Lnp0;->f(Lop0;Ljava/lang/String;)V

    invoke-virtual {v2}, Lnp0;->b()Lop0;

    move-result-object v1

    iput-object v1, v0, Lft1;->a:Lop0;

    iget-object v1, p0, Lads_mobile_sdk/h21;->d:[B

    if-eqz v1, :cond_29

    sget-object v2, Lpt1;->Companion:Lot1;

    const/4 v5, 0x7

    invoke-static {v2, v1, v4, v3, v5}, Lot1;->d(Lot1;[BLa81;II)Lnt1;

    move-result-object v4

    :cond_29
    iget-object v1, p0, Lads_mobile_sdk/h21;->b:Ljava/lang/String;

    invoke-virtual {v0, v1, v4}, Lft1;->d(Ljava/lang/String;Lpt1;)V

    iget-object p0, p0, Lads_mobile_sdk/h21;->c:Ljava/util/Map;

    invoke-interface {p0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_38
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_54

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v0, v2, v1}, Lft1;->a(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_38

    :cond_54
    invoke-virtual {v0}, Lft1;->b()Lkt1;

    move-result-object p0

    return-object p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "HttpRequest{method="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lads_mobile_sdk/h21;->b:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", url="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lads_mobile_sdk/h21;->a:Ljava/net/URL;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", headers="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, Lads_mobile_sdk/h21;->c:Ljava/util/Map;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, "}"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
