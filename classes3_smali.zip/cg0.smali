.class public final Lcg0;
.super Lwx;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public synthetic t:Ljava/lang/Object;

.field public u:I

.field public v:Lhf0;

.field public final synthetic w:Ltf0;


# direct methods
.method public constructor <init>(Ltf0;Lvx;)V
    .registers 3

    iput-object p1, p0, Lcg0;->w:Ltf0;

    invoke-direct {p0, p2}, Lwx;-><init>(Lvx;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    iput-object p1, p0, Lcg0;->t:Ljava/lang/Object;

    iget p1, p0, Lcg0;->u:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, Lcg0;->u:I

    iget-object p1, p0, Lcg0;->w:Ltf0;

    const/4 v0, 0x0

    invoke-virtual {p1, v0, p0}, Ltf0;->emit(Ljava/lang/Object;Lvx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
