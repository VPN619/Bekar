.class public final Lc9;
.super Lkz;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static c:Z

.field public static d:Z


# instance fields
.field public final a:Landroid/net/http/HttpEngine;

.field public final b:Ljava/util/Map;


# direct methods
.method public constructor <init>(Landroid/net/http/HttpEngine;)V
    .registers 3

    invoke-direct {p0}, Lorg/chromium/net/ExperimentalCronetEngine;-><init>()V

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    invoke-static {v0}, Ljava/util/Collections;->synchronizedMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v0

    iput-object v0, p0, Lc9;->b:Ljava/util/Map;

    iput-object p1, p0, Lc9;->a:Landroid/net/http/HttpEngine;

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;Lorg/chromium/net/UrlRequest$Callback;Ljava/util/concurrent/Executor;ILjava/util/ArrayList;ZZZIZILorg/chromium/net/RequestFinishedInfo$Listener;JLjava/lang/String;Ljava/util/ArrayList;Lorg/chromium/net/UploadDataProvider;Ljava/util/concurrent/Executor;)Lorg/chromium/net/ExperimentalUrlRequest;
    .registers 22

    .prologue
    move-object/from16 v0, p17

    new-instance v1, Lo9;

    invoke-direct {v1, p2}, Lo9;-><init>(Lorg/chromium/net/UrlRequest$Callback;)V

    iget-object p2, p0, Lc9;->a:Landroid/net/http/HttpEngine;

    invoke-virtual {p2, p1, p3, v1}, Landroid/net/http/HttpEngine;->newUrlRequestBuilder(Ljava/lang/String;Ljava/util/concurrent/Executor;Landroid/net/http/UrlRequest$Callback;)Landroid/net/http/UrlRequest$Builder;

    move-result-object p2

    invoke-virtual {p2, p4}, Landroid/net/http/UrlRequest$Builder;->setPriority(I)Landroid/net/http/UrlRequest$Builder;

    if-eqz p6, :cond_15

    invoke-virtual {p2, p6}, Landroid/net/http/UrlRequest$Builder;->setCacheDisabled(Z)Landroid/net/http/UrlRequest$Builder;

    :cond_15
    if-eqz p7, :cond_1a

    invoke-virtual {p2, p7}, Landroid/net/http/UrlRequest$Builder;->setDirectExecutorAllowed(Z)Landroid/net/http/UrlRequest$Builder;

    :cond_1a
    if-eqz p8, :cond_1f

    invoke-virtual {p2, p9}, Landroid/net/http/UrlRequest$Builder;->setTrafficStatsTag(I)Landroid/net/http/UrlRequest$Builder;

    :cond_1f
    if-eqz p10, :cond_24

    invoke-virtual {p2, p11}, Landroid/net/http/UrlRequest$Builder;->setTrafficStatsTag(I)Landroid/net/http/UrlRequest$Builder;

    :cond_24
    const-wide/16 p3, -0x1

    cmp-long p3, p13, p3

    if-nez p3, :cond_2c

    const/4 p3, 0x0

    goto :goto_30

    :cond_2c
    invoke-static/range {p13 .. p14}, Landroid/net/Network;->fromNetworkHandle(J)Landroid/net/Network;

    move-result-object p3

    :goto_30
    invoke-virtual {p2, p3}, Landroid/net/http/UrlRequest$Builder;->bindToNetwork(Landroid/net/Network;)Landroid/net/http/UrlRequest$Builder;

    move-object/from16 p3, p15

    invoke-virtual {p2, p3}, Landroid/net/http/UrlRequest$Builder;->setHttpMethod(Ljava/lang/String;)Landroid/net/http/UrlRequest$Builder;

    invoke-virtual/range {p16 .. p16}, Ljava/util/ArrayList;->size()I

    move-result p3

    const/4 p4, 0x0

    :goto_3d
    if-ge p4, p3, :cond_59

    move-object/from16 p6, p16

    invoke-virtual {p6, p4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p7

    add-int/lit8 p4, p4, 0x1

    check-cast p7, Ljava/util/Map$Entry;

    invoke-interface {p7}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-interface {p7}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p7

    check-cast p7, Ljava/lang/String;

    invoke-virtual {p2, v2, p7}, Landroid/net/http/UrlRequest$Builder;->addHeader(Ljava/lang/String;Ljava/lang/String;)Landroid/net/http/UrlRequest$Builder;

    goto :goto_3d

    :cond_59
    if-eqz v0, :cond_65

    new-instance p3, Lm9;

    invoke-direct {p3, v0}, Lm9;-><init>(Lorg/chromium/net/UploadDataProvider;)V

    move-object/from16 p4, p18

    invoke-virtual {p2, p3, p4}, Landroid/net/http/UrlRequest$Builder;->setUploadDataProvider(Landroid/net/http/UploadDataProvider;Ljava/util/concurrent/Executor;)Landroid/net/http/UrlRequest$Builder;

    :cond_65
    invoke-virtual {p2}, Landroid/net/http/UrlRequest$Builder;->build()Landroid/net/http/UrlRequest;

    move-result-object p7

    new-instance p6, Lq9;

    move-object p8, p0

    move-object p9, p1

    move-object p10, p5

    move-object p11, p12

    invoke-direct/range {p6 .. p11}, Lq9;-><init>(Landroid/net/http/UrlRequest;Lc9;Ljava/lang/String;Ljava/util/Collection;Lorg/chromium/net/RequestFinishedInfo$Listener;)V

    iput-object p6, v1, Lo9;->b:Lq9;

    return-object p6
.end method

.method public final addRequestFinishedListener(Lorg/chromium/net/RequestFinishedInfo$Listener;)V
    .registers 3

    new-instance v0, Lhj2;

    invoke-direct {v0, p1}, Lhj2;-><init>(Lorg/chromium/net/RequestFinishedInfo$Listener;)V

    iget-object p0, p0, Lc9;->b:Ljava/util/Map;

    invoke-interface {p0, p1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public final b(Ljava/lang/String;Lorg/chromium/net/BidirectionalStream$Callback;Ljava/util/concurrent/Executor;Ljava/lang/String;Ljava/util/ArrayList;IZLjava/util/ArrayList;ZIZI)Lorg/chromium/net/ExperimentalBidirectionalStream;
    .registers 16

    .prologue
    new-instance v0, Ls8;

    invoke-direct {v0, p2}, Ls8;-><init>(Lorg/chromium/net/BidirectionalStream$Callback;)V

    iget-object p2, p0, Lc9;->a:Landroid/net/http/HttpEngine;

    invoke-virtual {p2, p1, p3, v0}, Landroid/net/http/HttpEngine;->newBidirectionalStreamBuilder(Ljava/lang/String;Ljava/util/concurrent/Executor;Landroid/net/http/BidirectionalStream$Callback;)Landroid/net/http/BidirectionalStream$Builder;

    move-result-object p2

    invoke-virtual {p2, p4}, Landroid/net/http/BidirectionalStream$Builder;->setHttpMethod(Ljava/lang/String;)Landroid/net/http/BidirectionalStream$Builder;

    invoke-virtual {p5}, Ljava/util/ArrayList;->size()I

    move-result p3

    const/4 p4, 0x0

    :goto_13
    if-ge p4, p3, :cond_2d

    invoke-virtual {p5, p4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    add-int/lit8 p4, p4, 0x1

    check-cast v1, Ljava/util/Map$Entry;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-virtual {p2, v2, v1}, Landroid/net/http/BidirectionalStream$Builder;->addHeader(Ljava/lang/String;Ljava/lang/String;)Landroid/net/http/BidirectionalStream$Builder;

    goto :goto_13

    :cond_2d
    invoke-virtual {p2, p6}, Landroid/net/http/BidirectionalStream$Builder;->setPriority(I)Landroid/net/http/BidirectionalStream$Builder;

    invoke-virtual {p2, p7}, Landroid/net/http/BidirectionalStream$Builder;->setDelayRequestHeadersUntilFirstFlushEnabled(Z)Landroid/net/http/BidirectionalStream$Builder;

    if-eqz p9, :cond_38

    invoke-virtual {p2, p10}, Landroid/net/http/BidirectionalStream$Builder;->setTrafficStatsTag(I)Landroid/net/http/BidirectionalStream$Builder;

    :cond_38
    if-eqz p11, :cond_3d

    invoke-virtual {p2, p12}, Landroid/net/http/BidirectionalStream$Builder;->setTrafficStatsUid(I)Landroid/net/http/BidirectionalStream$Builder;

    :cond_3d
    invoke-virtual {p2}, Landroid/net/http/BidirectionalStream$Builder;->build()Landroid/net/http/BidirectionalStream;

    move-result-object p2

    new-instance p3, Lt8;

    invoke-direct {p3, p2, p0, p1, p8}, Lt8;-><init>(Landroid/net/http/BidirectionalStream;Lc9;Ljava/lang/String;Ljava/util/Collection;)V

    iput-object p3, v0, Ls8;->b:Lt8;

    return-object p3
.end method

.method public final bindToNetwork(J)V
    .registers 5

    .prologue
    iget-object p0, p0, Lc9;->a:Landroid/net/http/HttpEngine;

    const-wide/16 v0, -0x1

    cmp-long v0, p1, v0

    if-nez v0, :cond_a

    const/4 p1, 0x0

    goto :goto_e

    :cond_a
    invoke-static {p1, p2}, Landroid/net/Network;->fromNetworkHandle(J)Landroid/net/Network;

    move-result-object p1

    :goto_e
    invoke-virtual {p0, p1}, Landroid/net/http/HttpEngine;->bindToNetwork(Landroid/net/Network;)V

    return-void
.end method

.method public final synthetic c(Ljava/net/URL;)Ljava/net/URLConnection;
    .registers 2

    iget-object p0, p0, Lc9;->a:Landroid/net/http/HttpEngine;

    invoke-virtual {p0, p1}, Landroid/net/http/HttpEngine;->openConnection(Ljava/net/URL;)Ljava/net/URLConnection;

    move-result-object p0

    return-object p0
.end method

.method public final createURLStreamHandlerFactory()Ljava/net/URLStreamHandlerFactory;
    .registers 1

    iget-object p0, p0, Lc9;->a:Landroid/net/http/HttpEngine;

    invoke-virtual {p0}, Landroid/net/http/HttpEngine;->createUrlStreamHandlerFactory()Ljava/net/URLStreamHandlerFactory;

    move-result-object p0

    return-object p0
.end method

.method public final getGlobalMetricsDeltas()[B
    .registers 2

    .prologue
    sget-boolean p0, Lc9;->d:Z

    if-nez p0, :cond_c

    const-string p0, "HttpEngineWrapper"

    const-string v0, "GlobalMetricsDelta is unsupported when HttpEngineNativeProvider is used. An empty protobuf is returned."

    nop

    const/4 p0, 0x1

    sput-boolean p0, Lc9;->d:Z

    :cond_c
    const/4 p0, 0x0

    new-array p0, p0, [B

    return-object p0
.end method

.method public final getVersionString()Ljava/lang/String;
    .registers 1

    invoke-static {}, Landroid/net/http/HttpEngine;->getVersionString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public final newBidirectionalStreamBuilder(Ljava/lang/String;Lorg/chromium/net/BidirectionalStream$Callback;Ljava/util/concurrent/Executor;)Lorg/chromium/net/BidirectionalStream$Builder;
    .registers 5

    new-instance v0, Ljj;

    invoke-direct {v0, p1, p2, p3, p0}, Ljj;-><init>(Ljava/lang/String;Lorg/chromium/net/BidirectionalStream$Callback;Ljava/util/concurrent/Executor;Lc9;)V

    return-object v0
.end method

.method public final newBidirectionalStreamBuilder(Ljava/lang/String;Lorg/chromium/net/BidirectionalStream$Callback;Ljava/util/concurrent/Executor;)Lorg/chromium/net/ExperimentalBidirectionalStream$Builder;
    .registers 5

    new-instance v0, Ljj;

    invoke-direct {v0, p1, p2, p3, p0}, Ljj;-><init>(Ljava/lang/String;Lorg/chromium/net/BidirectionalStream$Callback;Ljava/util/concurrent/Executor;Lc9;)V

    return-object v0
.end method

.method public final newUrlRequestBuilder(Ljava/lang/String;Lorg/chromium/net/UrlRequest$Callback;Ljava/util/concurrent/Executor;)Lorg/chromium/net/UrlRequest$Builder;
    .registers 5

    new-instance v0, Lwh2;

    invoke-direct {v0, p1, p2, p3, p0}, Lwh2;-><init>(Ljava/lang/String;Lorg/chromium/net/UrlRequest$Callback;Ljava/util/concurrent/Executor;Lkz;)V

    return-object v0
.end method

.method public final openConnection(Ljava/net/URL;)Ljava/net/URLConnection;
    .registers 4

    new-instance v0, Lx3;

    const/4 v1, 0x1

    invoke-direct {v0, v1, p0, p1}, Lx3;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    const-class p0, Ljava/io/IOException;

    invoke-static {v0, p0}, Ls1;->d(Lmz;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/net/URLConnection;

    return-object p0
.end method

.method public final openConnection(Ljava/net/URL;Ljava/net/Proxy;)Ljava/net/URLConnection;
    .registers 5

    .prologue
    invoke-virtual {p2}, Ljava/net/Proxy;->type()Ljava/net/Proxy$Type;

    move-result-object p2

    sget-object v0, Ljava/net/Proxy$Type;->DIRECT:Ljava/net/Proxy$Type;

    const/4 v1, 0x0

    if-ne p2, v0, :cond_2d

    invoke-virtual {p1}, Ljava/net/URL;->getProtocol()Ljava/lang/String;

    move-result-object p2

    const-string v0, "http"

    invoke-virtual {v0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_28

    const-string v0, "https"

    invoke-virtual {v0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1e

    goto :goto_28

    :cond_1e
    const-string p0, "Unexpected protocol:"

    invoke-static {p0, p2}, Lrt2;->h(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lvh0;->n(Ljava/lang/String;)V

    return-object v1

    :cond_28
    :goto_28
    invoke-virtual {p0, p1}, Lc9;->openConnection(Ljava/net/URL;)Ljava/net/URLConnection;

    move-result-object p0

    return-object p0

    :cond_2d
    invoke-static {}, Lvx2;->p()V

    return-object v1
.end method

.method public final removeRequestFinishedListener(Lorg/chromium/net/RequestFinishedInfo$Listener;)V
    .registers 2

    iget-object p0, p0, Lc9;->b:Ljava/util/Map;

    invoke-interface {p0, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public final shutdown()V
    .registers 1

    iget-object p0, p0, Lc9;->a:Landroid/net/http/HttpEngine;

    invoke-virtual {p0}, Landroid/net/http/HttpEngine;->shutdown()V

    return-void
.end method

.method public final startNetLogToFile(Ljava/lang/String;Z)V
    .registers 3

    .prologue
    sget-boolean p0, Lc9;->c:Z

    if-nez p0, :cond_c

    const-string p0, "HttpEngineWrapper"

    const-string p1, "Netlog is unsupported when HttpEngineNativeProvider is used."

    nop

    const/4 p0, 0x1

    sput-boolean p0, Lc9;->c:Z

    :cond_c
    return-void
.end method

.method public final stopNetLog()V
    .registers 1

    return-void
.end method
