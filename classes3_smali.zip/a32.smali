.class public final La32;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ljy0;


# static fields
.field public static final a:La32;

.field public static final b:Lwm1;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    new-instance v0, La32;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, La32;->a:La32;

    new-instance v0, Lwm1;

    const-string v1, "kotlin.Short"

    sget-object v2, Lsm1;->B:Lsm1;

    invoke-direct {v0, v1, v2}, Lwm1;-><init>(Ljava/lang/String;Lsm1;)V

    sput-object v0, La32;->b:Lwm1;

    return-void
.end method


# virtual methods
.method public final deserialize(Lj10;)Ljava/lang/Object;
    .registers 2

    invoke-interface {p1}, Lj10;->B()S

    move-result p0

    invoke-static {p0}, Ljava/lang/Short;->valueOf(S)Ljava/lang/Short;

    move-result-object p0

    return-object p0
.end method

.method public final getDescriptor()Lm02;
    .registers 1

    sget-object p0, La32;->b:Lwm1;

    return-object p0
.end method

.method public final serialize(Lga0;Ljava/lang/Object;)V
    .registers 3

    check-cast p2, Ljava/lang/Number;

    invoke-virtual {p2}, Ljava/lang/Number;->shortValue()S

    move-result p0

    invoke-interface {p1, p0}, Lga0;->i(S)V

    return-void
.end method
