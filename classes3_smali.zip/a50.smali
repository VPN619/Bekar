.class public final La50;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ljava/io/Closeable;


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:J

.field public final c:Ljava/util/ArrayList;

.field public final synthetic d:Lc50;


# direct methods
.method public constructor <init>(Lc50;Ljava/lang/String;JLjava/util/ArrayList;[J)V
    .registers 7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, La50;->d:Lc50;

    iput-object p2, p0, La50;->a:Ljava/lang/String;

    iput-wide p3, p0, La50;->b:J

    iput-object p5, p0, La50;->c:Ljava/util/ArrayList;

    return-void
.end method


# virtual methods
.method public final close()V
    .registers 4

    .prologue
    iget-object p0, p0, La50;->c:Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_7
    if-ge v1, v0, :cond_17

    invoke-virtual {p0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    add-int/lit8 v1, v1, 0x1

    check-cast v2, Lr42;

    check-cast v2, Ljava/io/Closeable;

    invoke-static {v2}, Lki2;->c(Ljava/io/Closeable;)V

    goto :goto_7

    :cond_17
    return-void
.end method
