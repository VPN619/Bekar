.class public final Lad0;
.super Lv0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final b:Lh6;


# direct methods
.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lh6;

    const/4 v1, 0x5

    invoke-direct {v0, v1}, Lh6;-><init>(I)V

    iput-object v0, p0, Lad0;->b:Lh6;

    return-void
.end method


# virtual methods
.method public final k()Ljava/util/Random;
    .registers 1

    iget-object p0, p0, Lad0;->b:Lh6;

    invoke-virtual {p0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p0, Ljava/util/Random;

    return-object p0
.end method
