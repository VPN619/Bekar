.class Lcom/mbridge/msdk/timer/a$a;
.super Landroid/os/Handler;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/mbridge/msdk/timer/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/mbridge/msdk/timer/a;


# direct methods
.method public constructor <init>(Lcom/mbridge/msdk/timer/a;)V
    .registers 2

    iput-object p1, p0, Lcom/mbridge/msdk/timer/a$a;->a:Lcom/mbridge/msdk/timer/a;

    invoke-direct {p0}, Landroid/os/Handler;-><init>()V

    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .registers 6

    .prologue
    iget-object v0, p0, Lcom/mbridge/msdk/timer/a$a;->a:Lcom/mbridge/msdk/timer/a;

    monitor-enter v0

    :try_start_3
    iget p1, p1, Landroid/os/Message;->what:I

    const/4 v1, 0x1

    if-eq p1, v1, :cond_14

    const/4 v1, 0x2

    if-eq p1, v1, :cond_c

    goto :goto_34

    :cond_c
    iget-object p0, p0, Lcom/mbridge/msdk/timer/a$a;->a:Lcom/mbridge/msdk/timer/a;

    invoke-static {p0}, Lcom/mbridge/msdk/timer/a;->c(Lcom/mbridge/msdk/timer/a;)V

    goto :goto_34

    :catchall_12
    move-exception p0

    goto :goto_36

    :cond_14
    iget-object p1, p0, Lcom/mbridge/msdk/timer/a$a;->a:Lcom/mbridge/msdk/timer/a;

    invoke-static {p1}, Lcom/mbridge/msdk/timer/a;->a(Lcom/mbridge/msdk/timer/a;)Z

    move-result p1

    if-eqz p1, :cond_1e

    monitor-exit v0

    return-void

    :cond_1e
    iget-object p1, p0, Lcom/mbridge/msdk/timer/a$a;->a:Lcom/mbridge/msdk/timer/a;

    invoke-static {p1}, Lcom/mbridge/msdk/timer/a;->b(Lcom/mbridge/msdk/timer/a;)J

    move-result-wide v2

    invoke-static {p1, v2, v3}, Lcom/mbridge/msdk/timer/a;->a(Lcom/mbridge/msdk/timer/a;J)V

    invoke-virtual {p0, v1}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object p1

    iget-object v1, p0, Lcom/mbridge/msdk/timer/a$a;->a:Lcom/mbridge/msdk/timer/a;

    invoke-static {v1}, Lcom/mbridge/msdk/timer/a;->b(Lcom/mbridge/msdk/timer/a;)J

    move-result-wide v1

    invoke-virtual {p0, p1, v1, v2}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z

    :goto_34
    monitor-exit v0

    return-void

    :goto_36
    monitor-exit v0
    :try_end_37
    .catchall {:try_start_3 .. :try_end_37} :catchall_12

    throw p0
.end method
