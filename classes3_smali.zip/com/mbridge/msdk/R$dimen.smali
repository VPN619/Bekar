.class public final Lcom/mbridge/msdk/R$dimen;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/mbridge/msdk/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "dimen"
.end annotation


# static fields
.field public static compat_button_inset_horizontal_material:I = 0x7f070058

.field public static compat_button_inset_vertical_material:I = 0x7f070059

.field public static compat_button_padding_horizontal_material:I = 0x7f07005a

.field public static compat_button_padding_vertical_material:I = 0x7f07005b

.field public static compat_control_corner_material:I = 0x7f07005c

.field public static compat_notification_large_icon_max_height:I = 0x7f07005d

.field public static compat_notification_large_icon_max_width:I = 0x7f07005e

.field public static mbridge_video_common_alertview_bg_padding:I = 0x7f070387

.field public static mbridge_video_common_alertview_button_height:I = 0x7f070388

.field public static mbridge_video_common_alertview_button_margintop:I = 0x7f070389

.field public static mbridge_video_common_alertview_button_radius:I = 0x7f07038a

.field public static mbridge_video_common_alertview_button_textsize:I = 0x7f07038b

.field public static mbridge_video_common_alertview_button_width:I = 0x7f07038c

.field public static mbridge_video_common_alertview_content_margintop:I = 0x7f07038d

.field public static mbridge_video_common_alertview_content_size:I = 0x7f07038e

.field public static mbridge_video_common_alertview_contentview_maxwidth:I = 0x7f07038f

.field public static mbridge_video_common_alertview_contentview_minwidth:I = 0x7f070390

.field public static mbridge_video_common_alertview_title_size:I = 0x7f070391

.field public static notification_action_icon_size:I = 0x7f07045a

.field public static notification_action_text_size:I = 0x7f07045b

.field public static notification_big_circle_margin:I = 0x7f07045c

.field public static notification_content_margin_start:I = 0x7f07045d

.field public static notification_large_icon_height:I = 0x7f07045e

.field public static notification_large_icon_width:I = 0x7f07045f

.field public static notification_main_column_padding_top:I = 0x7f070460

.field public static notification_media_narrow_margin:I = 0x7f070461

.field public static notification_right_icon_size:I = 0x7f070462

.field public static notification_right_side_padding_top:I = 0x7f070463

.field public static notification_small_icon_background_padding:I = 0x7f070464

.field public static notification_small_icon_size_as_large:I = 0x7f070465

.field public static notification_subtext_size:I = 0x7f070466

.field public static notification_top_pad:I = 0x7f070467

.field public static notification_top_pad_large_text:I = 0x7f070468


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
