.class public final Lcom/mbridge/msdk/R$id;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/mbridge/msdk/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static accessibility_action_clickable_span:I = 0x7f090011

.field public static accessibility_custom_action_0:I = 0x7f090012

.field public static accessibility_custom_action_1:I = 0x7f090013

.field public static accessibility_custom_action_10:I = 0x7f090014

.field public static accessibility_custom_action_11:I = 0x7f090015

.field public static accessibility_custom_action_12:I = 0x7f090016

.field public static accessibility_custom_action_13:I = 0x7f090017

.field public static accessibility_custom_action_14:I = 0x7f090018

.field public static accessibility_custom_action_15:I = 0x7f090019

.field public static accessibility_custom_action_16:I = 0x7f09001a

.field public static accessibility_custom_action_17:I = 0x7f09001b

.field public static accessibility_custom_action_18:I = 0x7f09001c

.field public static accessibility_custom_action_19:I = 0x7f09001d

.field public static accessibility_custom_action_2:I = 0x7f09001e

.field public static accessibility_custom_action_20:I = 0x7f09001f

.field public static accessibility_custom_action_21:I = 0x7f090020

.field public static accessibility_custom_action_22:I = 0x7f090021

.field public static accessibility_custom_action_23:I = 0x7f090022

.field public static accessibility_custom_action_24:I = 0x7f090023

.field public static accessibility_custom_action_25:I = 0x7f090024

.field public static accessibility_custom_action_26:I = 0x7f090025

.field public static accessibility_custom_action_27:I = 0x7f090026

.field public static accessibility_custom_action_28:I = 0x7f090027

.field public static accessibility_custom_action_29:I = 0x7f090028

.field public static accessibility_custom_action_3:I = 0x7f090029

.field public static accessibility_custom_action_30:I = 0x7f09002a

.field public static accessibility_custom_action_31:I = 0x7f09002b

.field public static accessibility_custom_action_4:I = 0x7f09002c

.field public static accessibility_custom_action_5:I = 0x7f09002d

.field public static accessibility_custom_action_6:I = 0x7f09002e

.field public static accessibility_custom_action_7:I = 0x7f09002f

.field public static accessibility_custom_action_8:I = 0x7f090030

.field public static accessibility_custom_action_9:I = 0x7f090031

.field public static action_container:I = 0x7f09003c

.field public static action_divider:I = 0x7f09003e

.field public static action_image:I = 0x7f09003f

.field public static action_text:I = 0x7f090045

.field public static actions:I = 0x7f090046

.field public static adjust_height:I = 0x7f09004b

.field public static adjust_width:I = 0x7f09004c

.field public static async:I = 0x7f090067

.field public static auto:I = 0x7f090068

.field public static blocking:I = 0x7f09007a

.field public static bottom:I = 0x7f09007f

.field public static chronometer:I = 0x7f0900a5

.field public static dark:I = 0x7f0900d1

.field public static dialog_button:I = 0x7f0900df

.field public static end:I = 0x7f0900fc

.field public static forever:I = 0x7f090116

.field public static icon:I = 0x7f09013c

.field public static icon_group:I = 0x7f09013e

.field public static icon_only:I = 0x7f09013f

.field public static info:I = 0x7f090152

.field public static italic:I = 0x7f090157

.field public static item:I = 0x7f090158

.field public static left:I = 0x7f090160

.field public static light:I = 0x7f090163

.field public static line1:I = 0x7f090164

.field public static line3:I = 0x7f090165

.field public static mbridge_alertview_close_button:I = 0x7f09018e

.field public static mbridge_alertview_contentview:I = 0x7f09018f

.field public static mbridge_alertview_continue_button:I = 0x7f090190

.field public static mbridge_alertview_titleview:I = 0x7f090191

.field public static mbridge_animation_click_view:I = 0x7f090192

.field public static mbridge_bottom_finger_bg:I = 0x7f090193

.field public static mbridge_bottom_icon_iv:I = 0x7f090194

.field public static mbridge_bottom_item_rl:I = 0x7f090195

.field public static mbridge_bottom_iv:I = 0x7f090196

.field public static mbridge_bottom_play_bg:I = 0x7f090197

.field public static mbridge_bottom_ration:I = 0x7f090198

.field public static mbridge_bottom_title_tv:I = 0x7f090199

.field public static mbridge_bt_container:I = 0x7f09019a

.field public static mbridge_bt_container_root:I = 0x7f09019b

.field public static mbridge_center_view:I = 0x7f09019c

.field public static mbridge_choice_frl:I = 0x7f09019d

.field public static mbridge_choice_one_countdown_tv:I = 0x7f09019e

.field public static mbridge_cta_layout:I = 0x7f09019f

.field public static mbridge_ec_layout_center:I = 0x7f0901a0

.field public static mbridge_ec_layout_top:I = 0x7f0901a1

.field public static mbridge_full_animation_content:I = 0x7f0901a2

.field public static mbridge_full_animation_player:I = 0x7f0901a3

.field public static mbridge_full_iv_close:I = 0x7f0901a4

.field public static mbridge_full_pb_loading:I = 0x7f0901a5

.field public static mbridge_full_player_parent:I = 0x7f0901a6

.field public static mbridge_full_rl_close:I = 0x7f0901a7

.field public static mbridge_full_rl_playcontainer:I = 0x7f0901a8

.field public static mbridge_full_tv_display_content:I = 0x7f0901a9

.field public static mbridge_full_tv_display_description:I = 0x7f0901aa

.field public static mbridge_full_tv_display_icon:I = 0x7f0901ab

.field public static mbridge_full_tv_display_title:I = 0x7f0901ac

.field public static mbridge_full_tv_feeds_star:I = 0x7f0901ad

.field public static mbridge_full_tv_install:I = 0x7f0901ae

.field public static mbridge_interstitial_iv_close:I = 0x7f0901af

.field public static mbridge_interstitial_pb:I = 0x7f0901b0

.field public static mbridge_interstitial_wv:I = 0x7f0901b1

.field public static mbridge_iv_adbanner:I = 0x7f0901b2

.field public static mbridge_iv_adbanner_bg:I = 0x7f0901b3

.field public static mbridge_iv_appicon:I = 0x7f0901b4

.field public static mbridge_iv_close:I = 0x7f0901b5

.field public static mbridge_iv_flag:I = 0x7f0901b6

.field public static mbridge_iv_icon:I = 0x7f0901b7

.field public static mbridge_iv_iconbg:I = 0x7f0901b8

.field public static mbridge_iv_link:I = 0x7f0901b9

.field public static mbridge_iv_logo:I = 0x7f0901ba

.field public static mbridge_iv_pause:I = 0x7f0901bb

.field public static mbridge_iv_play:I = 0x7f0901bc

.field public static mbridge_iv_playend_pic:I = 0x7f0901bd

.field public static mbridge_iv_sound:I = 0x7f0901be

.field public static mbridge_iv_sound_animation:I = 0x7f0901bf

.field public static mbridge_iv_vastclose:I = 0x7f0901c0

.field public static mbridge_iv_vastok:I = 0x7f0901c1

.field public static mbridge_layout_bottomLayout:I = 0x7f0901c2

.field public static mbridge_ll_loading:I = 0x7f0901c3

.field public static mbridge_ll_playerview_container:I = 0x7f0901c4

.field public static mbridge_lv_desc_tv:I = 0x7f0901c5

.field public static mbridge_lv_icon_iv:I = 0x7f0901c6

.field public static mbridge_lv_item_rl:I = 0x7f0901c7

.field public static mbridge_lv_iv:I = 0x7f0901c8

.field public static mbridge_lv_iv_bg:I = 0x7f0901c9

.field public static mbridge_lv_iv_burl:I = 0x7f0901ca

.field public static mbridge_lv_iv_cover:I = 0x7f0901cb

.field public static mbridge_lv_sv_starlevel:I = 0x7f0901cc

.field public static mbridge_lv_title_tv:I = 0x7f0901cd

.field public static mbridge_lv_tv_install:I = 0x7f0901ce

.field public static mbridge_more_offer_ll_item:I = 0x7f0901cf

.field public static mbridge_moreoffer_hls:I = 0x7f0901d0

.field public static mbridge_my_big_img:I = 0x7f0901d1

.field public static mbridge_native_ec_controller:I = 0x7f0901d2

.field public static mbridge_native_ec_layer_layout:I = 0x7f0901d3

.field public static mbridge_native_ec_layout:I = 0x7f0901d4

.field public static mbridge_native_ec_rl:I = 0x7f0901d5

.field public static mbridge_native_endcard_feed_btn:I = 0x7f0901d6

.field public static mbridge_native_order_camp_controller:I = 0x7f0901d7

.field public static mbridge_native_order_camp_feed_btn:I = 0x7f0901d8

.field public static mbridge_native_pb:I = 0x7f0901d9

.field public static mbridge_native_rl_root:I = 0x7f0901da

.field public static mbridge_nativex_webview_layout:I = 0x7f0901db

.field public static mbridge_nativex_webview_layout_webview:I = 0x7f0901dc

.field public static mbridge_order_view_h_lv:I = 0x7f0901dd

.field public static mbridge_order_view_iv_close:I = 0x7f0901de

.field public static mbridge_order_view_lv:I = 0x7f0901df

.field public static mbridge_order_viewed_tv:I = 0x7f0901e0

.field public static mbridge_playercommon_ll_loading:I = 0x7f0901e1

.field public static mbridge_playercommon_ll_sur_container:I = 0x7f0901e2

.field public static mbridge_playercommon_rl_root:I = 0x7f0901e3

.field public static mbridge_progress:I = 0x7f0901e4

.field public static mbridge_progressBar:I = 0x7f0901e5

.field public static mbridge_progressBar1:I = 0x7f0901e6

.field public static mbridge_reward_bottom_layout:I = 0x7f0901e7

.field public static mbridge_reward_bottom_widget:I = 0x7f0901e8

.field public static mbridge_reward_choice_one_like_iv:I = 0x7f0901e9

.field public static mbridge_reward_click_tv:I = 0x7f0901ea

.field public static mbridge_reward_cta_layout:I = 0x7f0901eb

.field public static mbridge_reward_desc_tv:I = 0x7f0901ec

.field public static mbridge_reward_end_card_item_iv:I = 0x7f0901ed

.field public static mbridge_reward_end_card_item_title_tv:I = 0x7f0901ee

.field public static mbridge_reward_end_card_like_tv:I = 0x7f0901ef

.field public static mbridge_reward_end_card_more_offer_rl:I = 0x7f0901f0

.field public static mbridge_reward_end_card_offer_title_rl:I = 0x7f0901f1

.field public static mbridge_reward_header_layout:I = 0x7f0901f2

.field public static mbridge_reward_icon_riv:I = 0x7f0901f3

.field public static mbridge_reward_logo_iv:I = 0x7f0901f4

.field public static mbridge_reward_popview:I = 0x7f0901f5

.field public static mbridge_reward_root_container:I = 0x7f0901f6

.field public static mbridge_reward_scale_webview_layout:I = 0x7f0901f7

.field public static mbridge_reward_segment_progressbar:I = 0x7f0901f8

.field public static mbridge_reward_stars_mllv:I = 0x7f0901f9

.field public static mbridge_reward_title_tv:I = 0x7f0901fa

.field public static mbridge_rl_content:I = 0x7f0901fb

.field public static mbridge_rl_mediaview_root:I = 0x7f0901fc

.field public static mbridge_rl_playing_close:I = 0x7f0901fd

.field public static mbridge_sound_switch:I = 0x7f0901fe

.field public static mbridge_splash_feedback:I = 0x7f0901ff

.field public static mbridge_splash_iv_foregroundimage:I = 0x7f090200

.field public static mbridge_splash_iv_icon:I = 0x7f090201

.field public static mbridge_splash_iv_image:I = 0x7f090202

.field public static mbridge_splash_iv_image_bg:I = 0x7f090203

.field public static mbridge_splash_iv_link:I = 0x7f090204

.field public static mbridge_splash_landscape_foreground:I = 0x7f090205

.field public static mbridge_splash_layout_appinfo:I = 0x7f090206

.field public static mbridge_splash_layout_foreground:I = 0x7f090207

.field public static mbridge_splash_topcontroller:I = 0x7f090208

.field public static mbridge_splash_tv_adcircle:I = 0x7f090209

.field public static mbridge_splash_tv_adrect:I = 0x7f09020a

.field public static mbridge_splash_tv_app_desc:I = 0x7f09020b

.field public static mbridge_splash_tv_appinfo:I = 0x7f09020c

.field public static mbridge_splash_tv_click:I = 0x7f09020d

.field public static mbridge_splash_tv_permission:I = 0x7f09020e

.field public static mbridge_splash_tv_privacy:I = 0x7f09020f

.field public static mbridge_splash_tv_skip:I = 0x7f090210

.field public static mbridge_splash_tv_title:I = 0x7f090211

.field public static mbridge_sv_starlevel:I = 0x7f090212

.field public static mbridge_tag_icon:I = 0x7f090213

.field public static mbridge_tag_title:I = 0x7f090214

.field public static mbridge_temp_container:I = 0x7f090215

.field public static mbridge_textView:I = 0x7f090216

.field public static mbridge_text_layout:I = 0x7f090217

.field public static mbridge_textureview:I = 0x7f090218

.field public static mbridge_title_layout:I = 0x7f090219

.field public static mbridge_top_control:I = 0x7f09021a

.field public static mbridge_top_finger_bg:I = 0x7f09021b

.field public static mbridge_top_icon_iv:I = 0x7f09021c

.field public static mbridge_top_item_rl:I = 0x7f09021d

.field public static mbridge_top_iv:I = 0x7f09021e

.field public static mbridge_top_play_bg:I = 0x7f09021f

.field public static mbridge_top_ration:I = 0x7f090220

.field public static mbridge_top_title_tv:I = 0x7f090221

.field public static mbridge_tv_appdesc:I = 0x7f090222

.field public static mbridge_tv_apptitle:I = 0x7f090223

.field public static mbridge_tv_count:I = 0x7f090224

.field public static mbridge_tv_cta:I = 0x7f090225

.field public static mbridge_tv_desc:I = 0x7f090226

.field public static mbridge_tv_flag:I = 0x7f090227

.field public static mbridge_tv_install:I = 0x7f090228

.field public static mbridge_tv_number:I = 0x7f090229

.field public static mbridge_tv_number_layout:I = 0x7f09022a

.field public static mbridge_tv_reward_status:I = 0x7f09022b

.field public static mbridge_tv_title:I = 0x7f09022c

.field public static mbridge_tv_vasttag:I = 0x7f09022d

.field public static mbridge_tv_vasttitle:I = 0x7f09022e

.field public static mbridge_vec_btn:I = 0x7f09022f

.field public static mbridge_vec_iv_close:I = 0x7f090230

.field public static mbridge_vec_iv_icon:I = 0x7f090231

.field public static mbridge_vec_tv_desc:I = 0x7f090232

.field public static mbridge_vec_tv_title:I = 0x7f090233

.field public static mbridge_vfpv:I = 0x7f090234

.field public static mbridge_vfpv_fl:I = 0x7f090235

.field public static mbridge_video_common_alertview_cancel_button:I = 0x7f090236

.field public static mbridge_video_common_alertview_confirm_button:I = 0x7f090237

.field public static mbridge_video_common_alertview_contentview:I = 0x7f090238

.field public static mbridge_video_common_alertview_contentview_scrollview:I = 0x7f090239

.field public static mbridge_video_common_alertview_private_action_button:I = 0x7f09023a

.field public static mbridge_video_common_alertview_titleview:I = 0x7f09023b

.field public static mbridge_video_progress_bar:I = 0x7f09023c

.field public static mbridge_video_templete_container:I = 0x7f09023d

.field public static mbridge_video_templete_progressbar:I = 0x7f09023e

.field public static mbridge_video_templete_videoview:I = 0x7f09023f

.field public static mbridge_video_templete_webview_parent:I = 0x7f090240

.field public static mbridge_videoview_bg:I = 0x7f090241

.field public static mbridge_view_cover:I = 0x7f090242

.field public static mbridge_viewgroup_ctaroot:I = 0x7f090243

.field public static mbridge_windwv_close:I = 0x7f090244

.field public static mbridge_windwv_content_rl:I = 0x7f090245

.field public static none:I = 0x7f09028a

.field public static normal:I = 0x7f09028b

.field public static notification_background:I = 0x7f09028d

.field public static notification_main_column:I = 0x7f09028e

.field public static notification_main_column_container:I = 0x7f09028f

.field public static right:I = 0x7f0902ec

.field public static right_icon:I = 0x7f0902ee

.field public static right_side:I = 0x7f0902ef

.field public static standard:I = 0x7f090356

.field public static start:I = 0x7f090357

.field public static tag_accessibility_actions:I = 0x7f090366

.field public static tag_accessibility_clickable_spans:I = 0x7f090367

.field public static tag_accessibility_heading:I = 0x7f090368

.field public static tag_accessibility_pane_title:I = 0x7f090369

.field public static tag_screen_reader_focusable:I = 0x7f09036e

.field public static tag_transition_group:I = 0x7f090371

.field public static tag_unhandled_key_event_manager:I = 0x7f090372

.field public static tag_unhandled_key_listeners:I = 0x7f090373

.field public static text:I = 0x7f090375

.field public static text2:I = 0x7f090376

.field public static time:I = 0x7f090387

.field public static title:I = 0x7f09038a

.field public static top:I = 0x7f09038f

.field public static wide:I = 0x7f0903c1


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
