.class Lcom/mbridge/msdk/util/timer/b$a;
.super Landroid/os/CountDownTimer;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/mbridge/msdk/util/timer/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field private a:Lcom/mbridge/msdk/util/timer/a;


# direct methods
.method public constructor <init>(JJ)V
    .registers 5

    invoke-direct {p0, p1, p2, p3, p4}, Landroid/os/CountDownTimer;-><init>(JJ)V

    return-void
.end method


# virtual methods
.method public a(Lcom/mbridge/msdk/util/timer/a;)V
    .registers 2

    iput-object p1, p0, Lcom/mbridge/msdk/util/timer/b$a;->a:Lcom/mbridge/msdk/util/timer/a;

    return-void
.end method

.method public onFinish()V
    .registers 1

    .prologue
    iget-object p0, p0, Lcom/mbridge/msdk/util/timer/b$a;->a:Lcom/mbridge/msdk/util/timer/a;

    if-eqz p0, :cond_7

    invoke-interface {p0}, Lcom/mbridge/msdk/util/timer/a;->onFinish()V

    :cond_7
    return-void
.end method

.method public onTick(J)V
    .registers 3

    .prologue
    iget-object p0, p0, Lcom/mbridge/msdk/util/timer/b$a;->a:Lcom/mbridge/msdk/util/timer/a;

    if-eqz p0, :cond_7

    invoke-interface {p0, p1, p2}, Lcom/mbridge/msdk/util/timer/a;->onTick(J)V

    :cond_7
    return-void
.end method
