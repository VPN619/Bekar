.class public final Lcom/mbridge/msdk/R$color;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/mbridge/msdk/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "color"
.end annotation


# static fields
.field public static androidx_core_ripple_material_light:I = 0x7f06001b

.field public static androidx_core_secondary_text_default_material_light:I = 0x7f06001c

.field public static common_google_signin_btn_text_dark:I = 0x7f060048

.field public static common_google_signin_btn_text_dark_default:I = 0x7f060049

.field public static common_google_signin_btn_text_dark_disabled:I = 0x7f06004a

.field public static common_google_signin_btn_text_dark_focused:I = 0x7f06004b

.field public static common_google_signin_btn_text_dark_pressed:I = 0x7f06004c

.field public static common_google_signin_btn_text_light:I = 0x7f06004d

.field public static common_google_signin_btn_text_light_default:I = 0x7f06004e

.field public static common_google_signin_btn_text_light_disabled:I = 0x7f06004f

.field public static common_google_signin_btn_text_light_focused:I = 0x7f060050

.field public static common_google_signin_btn_text_light_pressed:I = 0x7f060051

.field public static common_google_signin_btn_tint:I = 0x7f060052

.field public static mbridge_black:I = 0x7f06039a

.field public static mbridge_black_66:I = 0x7f06039b

.field public static mbridge_black_alpha_50:I = 0x7f06039c

.field public static mbridge_cm_feedback_dialog_chice_bg_pressed:I = 0x7f06039d

.field public static mbridge_cm_feedback_rb_text_color_color_list:I = 0x7f06039e

.field public static mbridge_color_999999:I = 0x7f06039f

.field public static mbridge_color_cc000000:I = 0x7f0603a0

.field public static mbridge_color_cc0000001:I = 0x7f0603a1

.field public static mbridge_common_white:I = 0x7f0603a2

.field public static mbridge_cpb_blue:I = 0x7f0603a3

.field public static mbridge_cpb_blue_dark:I = 0x7f0603a4

.field public static mbridge_cpb_green:I = 0x7f0603a5

.field public static mbridge_cpb_green_dark:I = 0x7f0603a6

.field public static mbridge_cpb_grey:I = 0x7f0603a7

.field public static mbridge_cpb_red:I = 0x7f0603a8

.field public static mbridge_cpb_red_dark:I = 0x7f0603a9

.field public static mbridge_cpb_white:I = 0x7f0603aa

.field public static mbridge_dd_grey:I = 0x7f0603ab

.field public static mbridge_ee_grey:I = 0x7f0603ac

.field public static mbridge_interstitial_black:I = 0x7f0603ad

.field public static mbridge_interstitial_white:I = 0x7f0603ae

.field public static mbridge_more_offer_list_bg:I = 0x7f0603af

.field public static mbridge_nativex_cta_txt_nor:I = 0x7f0603b0

.field public static mbridge_nativex_cta_txt_pre:I = 0x7f0603b1

.field public static mbridge_nativex_land_cta_bg_nor:I = 0x7f0603b2

.field public static mbridge_nativex_por_cta_bg_nor:I = 0x7f0603b3

.field public static mbridge_nativex_por_cta_bg_pre:I = 0x7f0603b4

.field public static mbridge_nativex_sound_bg:I = 0x7f0603b5

.field public static mbridge_purple_200:I = 0x7f0603b6

.field public static mbridge_purple_500:I = 0x7f0603b7

.field public static mbridge_purple_700:I = 0x7f0603b8

.field public static mbridge_reward_black:I = 0x7f0603b9

.field public static mbridge_reward_cta_bg:I = 0x7f0603ba

.field public static mbridge_reward_desc_textcolor:I = 0x7f0603bb

.field public static mbridge_reward_endcard_hor_bg:I = 0x7f0603bc

.field public static mbridge_reward_endcard_land_bg:I = 0x7f0603bd

.field public static mbridge_reward_endcard_line_bg:I = 0x7f0603be

.field public static mbridge_reward_endcard_vast_bg:I = 0x7f0603bf

.field public static mbridge_reward_kiloo_background:I = 0x7f0603c0

.field public static mbridge_reward_layer_text_bg:I = 0x7f0603c1

.field public static mbridge_reward_minicard_bg:I = 0x7f0603c2

.field public static mbridge_reward_six_black_transparent:I = 0x7f0603c3

.field public static mbridge_reward_six_black_transparent1:I = 0x7f0603c4

.field public static mbridge_reward_six_black_transparent2:I = 0x7f0603c5

.field public static mbridge_reward_title_textcolor:I = 0x7f0603c6

.field public static mbridge_reward_white:I = 0x7f0603c7

.field public static mbridge_splash_count_time_skip_text_color:I = 0x7f0603c8

.field public static mbridge_teal_200:I = 0x7f0603c9

.field public static mbridge_teal_700:I = 0x7f0603ca

.field public static mbridge_video_common_alertview_bg:I = 0x7f0603cb

.field public static mbridge_video_common_alertview_cancel_button_bg_default:I = 0x7f0603cc

.field public static mbridge_video_common_alertview_cancel_button_bg_pressed:I = 0x7f0603cd

.field public static mbridge_video_common_alertview_cancel_button_textcolor:I = 0x7f0603ce

.field public static mbridge_video_common_alertview_confirm_button_bg_default:I = 0x7f0603cf

.field public static mbridge_video_common_alertview_confirm_button_bg_pressed:I = 0x7f0603d0

.field public static mbridge_video_common_alertview_confirm_button_textcolor:I = 0x7f0603d1

.field public static mbridge_video_common_alertview_content_textcolor:I = 0x7f0603d2

.field public static mbridge_video_common_alertview_feedback_rb_bg:I = 0x7f0603d3

.field public static mbridge_video_common_alertview_title_textcolor:I = 0x7f0603d4

.field public static mbridge_white:I = 0x7f0603d5

.field public static notification_action_color_filter:I = 0x7f06040d

.field public static notification_icon_bg_color:I = 0x7f06040e

.field public static primary_text_default_material_dark:I = 0x7f060416

.field public static ripple_material_light:I = 0x7f06041f

.field public static secondary_text_default_material_dark:I = 0x7f060420

.field public static secondary_text_default_material_light:I = 0x7f060421


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
