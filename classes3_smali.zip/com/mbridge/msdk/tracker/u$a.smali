.class Lcom/mbridge/msdk/tracker/u$a;
.super Landroid/os/Handler;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/mbridge/msdk/tracker/u;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/mbridge/msdk/tracker/u;


# direct methods
.method public constructor <init>(Lcom/mbridge/msdk/tracker/u;Landroid/os/Looper;)V
    .registers 3

    iput-object p1, p0, Lcom/mbridge/msdk/tracker/u$a;->a:Lcom/mbridge/msdk/tracker/u;

    invoke-direct {p0, p2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .registers 3

    .prologue
    invoke-super {p0, p1}, Landroid/os/Handler;->handleMessage(Landroid/os/Message;)V

    iget p1, p1, Landroid/os/Message;->what:I

    const/4 v0, 0x1

    if-eq p1, v0, :cond_9

    return-void

    :cond_9
    :try_start_9
    iget-object p1, p0, Lcom/mbridge/msdk/tracker/u$a;->a:Lcom/mbridge/msdk/tracker/u;

    invoke-virtual {p1}, Lcom/mbridge/msdk/tracker/u;->b()V

    iget-object p1, p0, Lcom/mbridge/msdk/tracker/u$a;->a:Lcom/mbridge/msdk/tracker/u;

    iget-object p1, p1, Lcom/mbridge/msdk/tracker/u;->f:Landroid/os/Handler;

    invoke-virtual {p1, v0}, Landroid/os/Handler;->removeMessages(I)V

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/u$a;->a:Lcom/mbridge/msdk/tracker/u;

    invoke-static {p0}, Lcom/mbridge/msdk/tracker/u;->a(Lcom/mbridge/msdk/tracker/u;)V
    :try_end_1a
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_1a} :catch_1b

    return-void

    :catch_1b
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    return-void
.end method
