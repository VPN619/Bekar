.class Lcom/mbridge/msdk/tracker/k;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field private static volatile o:Ljava/lang/String;


# instance fields
.field private final a:Ljava/lang/String;

.field private final b:Lcom/mbridge/msdk/tracker/m;

.field private c:Landroid/content/Context;

.field private d:Lcom/mbridge/msdk/tracker/x;

.field private e:Lorg/json/JSONObject;

.field private f:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private g:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private volatile h:Lcom/mbridge/msdk/tracker/c;

.field private volatile i:Lcom/mbridge/msdk/tracker/l;

.field private volatile j:Lcom/mbridge/msdk/tracker/d;

.field private volatile k:Lcom/mbridge/msdk/tracker/j;

.field private volatile l:Lcom/mbridge/msdk/tracker/s;

.field private volatile m:Z

.field private volatile n:Lcom/mbridge/msdk/tracker/o;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-string v0, ""

    sput-object v0, Lcom/mbridge/msdk/tracker/k;->o:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Lcom/mbridge/msdk/tracker/m;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/mbridge/msdk/tracker/k;->m:Z

    iput-object p1, p0, Lcom/mbridge/msdk/tracker/k;->a:Ljava/lang/String;

    iput-object p2, p0, Lcom/mbridge/msdk/tracker/k;->b:Lcom/mbridge/msdk/tracker/m;

    return-void
.end method


# virtual methods
.method public a(Landroid/content/Context;)V
    .registers 2

    iput-object p1, p0, Lcom/mbridge/msdk/tracker/k;->c:Landroid/content/Context;

    return-void
.end method

.method public a(Lcom/mbridge/msdk/tracker/x;)V
    .registers 2

    iput-object p1, p0, Lcom/mbridge/msdk/tracker/k;->d:Lcom/mbridge/msdk/tracker/x;

    return-void
.end method

.method public a(Lorg/json/JSONObject;)V
    .registers 2

    iput-object p1, p0, Lcom/mbridge/msdk/tracker/k;->e:Lorg/json/JSONObject;

    return-void
.end method

.method public a()Z
    .registers 2

    .prologue
    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/k;->c()Lcom/mbridge/msdk/tracker/x;

    move-result-object v0

    invoke-static {v0}, Lcom/mbridge/msdk/tracker/y;->b(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5f

    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/k;->g()Lcom/mbridge/msdk/tracker/d;

    move-result-object v0

    invoke-static {v0}, Lcom/mbridge/msdk/tracker/y;->b(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_59

    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/k;->s()Lcom/mbridge/msdk/tracker/w;

    move-result-object v0

    invoke-static {v0}, Lcom/mbridge/msdk/tracker/y;->b(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_53

    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/k;->o()Lcom/mbridge/msdk/tracker/p;

    move-result-object v0

    invoke-static {v0}, Lcom/mbridge/msdk/tracker/y;->b(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_4d

    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/k;->o()Lcom/mbridge/msdk/tracker/p;

    move-result-object v0

    invoke-virtual {v0}, Lcom/mbridge/msdk/tracker/p;->b()Lcom/mbridge/msdk/tracker/network/toolbox/a;

    move-result-object v0

    invoke-static {v0}, Lcom/mbridge/msdk/tracker/y;->b(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_4d

    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/k;->o()Lcom/mbridge/msdk/tracker/p;

    move-result-object p0

    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/p;->c()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p0

    if-nez p0, :cond_46

    const/4 p0, 0x1

    return p0

    :cond_46
    const-string p0, "report url is null"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    :goto_4b
    const/4 p0, 0x0

    return p0

    :cond_4d
    const-string p0, "networkStackConfig or stack can not be null"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    goto :goto_4b

    :cond_53
    const-string p0, "responseHandler can not be null"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    goto :goto_4b

    :cond_59
    const-string p0, "decorate can not be null"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    goto :goto_4b

    :cond_5f
    const-string p0, "config can not be null"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    goto :goto_4b
.end method

.method public a(Lcom/mbridge/msdk/tracker/e;)Z
    .registers 6

    .prologue
    invoke-static {p1}, Lcom/mbridge/msdk/tracker/y;->b(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_7

    goto :goto_2c

    :cond_7
    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/k;->c()Lcom/mbridge/msdk/tracker/x;

    move-result-object v0

    iget-object v0, v0, Lcom/mbridge/msdk/tracker/x;->j:Lcom/mbridge/msdk/tracker/f;

    invoke-static {v0}, Lcom/mbridge/msdk/tracker/y;->a(Ljava/lang/Object;)Z

    move-result v1

    const-string v2, "TrackManager"

    if-eqz v1, :cond_22

    :try_start_15
    invoke-interface {v0, p1}, Lcom/mbridge/msdk/tracker/f;->a(Lcom/mbridge/msdk/tracker/e;)Z

    move-result p0
    :try_end_19
    .catch Ljava/lang/Exception; {:try_start_15 .. :try_end_19} :catch_1a

    return p0

    :catch_1a
    move-exception v0

    sget-boolean v1, Lcom/mbridge/msdk/tracker/a;->a:Z

    if-eqz v1, :cond_22

    const-string v1, "event filter apply exception"

    nop

    :cond_22
    invoke-virtual {p1}, Lcom/mbridge/msdk/tracker/e;->g()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_2e

    :goto_2c
    const/4 p0, 0x0

    return p0

    :cond_2e
    iget-object v0, p0, Lcom/mbridge/msdk/tracker/k;->g:Ljava/util/List;

    const/4 v1, 0x1

    if-eqz v0, :cond_41

    :try_start_33
    invoke-interface {v0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result p0
    :try_end_37
    .catch Ljava/lang/Exception; {:try_start_33 .. :try_end_37} :catch_39

    xor-int/2addr p0, v1

    return p0

    :catch_39
    move-exception v0

    sget-boolean v3, Lcom/mbridge/msdk/tracker/a;->a:Z

    if-eqz v3, :cond_41

    const-string v3, "disallowTrackEventNames contains exception"

    nop

    :cond_41
    iget-object p0, p0, Lcom/mbridge/msdk/tracker/k;->f:Ljava/util/List;

    if-eqz p0, :cond_52

    :try_start_45
    invoke-interface {p0, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result p0
    :try_end_49
    .catch Ljava/lang/Exception; {:try_start_45 .. :try_end_49} :catch_4a

    return p0

    :catch_4a
    move-exception p0

    sget-boolean p1, Lcom/mbridge/msdk/tracker/a;->a:Z

    if-eqz p1, :cond_52

    const-string p1, "allowTrackEventNames contains exception"

    nop

    :cond_52
    return v1
.end method

.method public b()V
    .registers 3

    .prologue
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/mbridge/msdk/tracker/k;->m:Z

    :try_start_3
    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/k;->q()Lcom/mbridge/msdk/tracker/s;

    move-result-object v0

    invoke-virtual {v0}, Lcom/mbridge/msdk/tracker/s;->j()V

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/mbridge/msdk/tracker/k;->l:Lcom/mbridge/msdk/tracker/s;

    iput-object v0, p0, Lcom/mbridge/msdk/tracker/k;->k:Lcom/mbridge/msdk/tracker/j;
    :try_end_f
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_f} :catch_10

    return-void

    :catch_10
    move-exception p0

    sget-boolean v0, Lcom/mbridge/msdk/tracker/a;->a:Z

    if-eqz v0, :cond_1a

    const-string v0, "TrackManager"

    const-string v1, "report manager shutdown exception"

    nop

    :cond_1a
    return-void
.end method

.method public c()Lcom/mbridge/msdk/tracker/x;
    .registers 2

    .prologue
    iget-object v0, p0, Lcom/mbridge/msdk/tracker/k;->d:Lcom/mbridge/msdk/tracker/x;

    if-nez v0, :cond_f

    new-instance v0, Lcom/mbridge/msdk/tracker/x$b;

    invoke-direct {v0}, Lcom/mbridge/msdk/tracker/x$b;-><init>()V

    invoke-virtual {v0}, Lcom/mbridge/msdk/tracker/x$b;->a()Lcom/mbridge/msdk/tracker/x;

    move-result-object v0

    iput-object v0, p0, Lcom/mbridge/msdk/tracker/k;->d:Lcom/mbridge/msdk/tracker/x;

    :cond_f
    return-object v0
.end method

.method public d()Landroid/content/Context;
    .registers 1

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/k;->c:Landroid/content/Context;

    return-object p0
.end method

.method public e()Lcom/mbridge/msdk/tracker/c;
    .registers 7

    .prologue
    iget-object v0, p0, Lcom/mbridge/msdk/tracker/k;->h:Lcom/mbridge/msdk/tracker/c;

    invoke-static {v0}, Lcom/mbridge/msdk/tracker/y;->b(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_32

    const-class v0, Lcom/mbridge/msdk/tracker/k;

    monitor-enter v0

    :try_start_b
    iget-object v1, p0, Lcom/mbridge/msdk/tracker/k;->h:Lcom/mbridge/msdk/tracker/c;

    invoke-static {v1}, Lcom/mbridge/msdk/tracker/y;->b(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2e

    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/k;->u()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Lcom/mbridge/msdk/tracker/c;

    new-instance v3, Lcom/mbridge/msdk/tracker/b;

    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/k;->d()Landroid/content/Context;

    move-result-object v4

    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/k;->f()Ljava/lang/String;

    move-result-object v5

    invoke-direct {v3, v4, v5, v1}, Lcom/mbridge/msdk/tracker/b;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {v2, v3, v1}, Lcom/mbridge/msdk/tracker/c;-><init>(Lcom/mbridge/msdk/tracker/b;Ljava/lang/String;)V

    iput-object v2, p0, Lcom/mbridge/msdk/tracker/k;->h:Lcom/mbridge/msdk/tracker/c;

    goto :goto_2e

    :catchall_2c
    move-exception p0

    goto :goto_30

    :cond_2e
    :goto_2e
    monitor-exit v0

    goto :goto_32

    :goto_30
    monitor-exit v0
    :try_end_31
    .catchall {:try_start_b .. :try_end_31} :catchall_2c

    throw p0

    :cond_32
    :goto_32
    iget-object p0, p0, Lcom/mbridge/msdk/tracker/k;->h:Lcom/mbridge/msdk/tracker/c;

    return-object p0
.end method

.method public f()Ljava/lang/String;
    .registers 3

    .prologue
    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/k;->w()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_d

    const-string p0, "track_manager_default.db"

    return-object p0

    :cond_d
    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/k;->w()Ljava/lang/String;

    move-result-object p0

    const-string v0, "track_manager_"

    const-string v1, ".db"

    invoke-static {v0, p0, v1}, Lrt2;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public g()Lcom/mbridge/msdk/tracker/d;
    .registers 2

    .prologue
    iget-object v0, p0, Lcom/mbridge/msdk/tracker/k;->j:Lcom/mbridge/msdk/tracker/d;

    invoke-static {v0}, Lcom/mbridge/msdk/tracker/y;->b(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_10

    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/k;->c()Lcom/mbridge/msdk/tracker/x;

    move-result-object v0

    iget-object v0, v0, Lcom/mbridge/msdk/tracker/x;->h:Lcom/mbridge/msdk/tracker/d;

    iput-object v0, p0, Lcom/mbridge/msdk/tracker/k;->j:Lcom/mbridge/msdk/tracker/d;

    :cond_10
    iget-object p0, p0, Lcom/mbridge/msdk/tracker/k;->j:Lcom/mbridge/msdk/tracker/d;

    return-object p0
.end method

.method public h()Lcom/mbridge/msdk/tracker/l;
    .registers 6

    .prologue
    iget-object v0, p0, Lcom/mbridge/msdk/tracker/k;->i:Lcom/mbridge/msdk/tracker/l;

    invoke-static {v0}, Lcom/mbridge/msdk/tracker/y;->b(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2e

    const-class v0, Lcom/mbridge/msdk/tracker/k;

    monitor-enter v0

    :try_start_b
    iget-object v1, p0, Lcom/mbridge/msdk/tracker/k;->i:Lcom/mbridge/msdk/tracker/l;

    invoke-static {v1}, Lcom/mbridge/msdk/tracker/y;->b(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2a

    new-instance v1, Lcom/mbridge/msdk/tracker/q;

    new-instance v2, Lcom/mbridge/msdk/tracker/g;

    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/k;->e()Lcom/mbridge/msdk/tracker/c;

    move-result-object v3

    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/k;->q()Lcom/mbridge/msdk/tracker/s;

    move-result-object v4

    invoke-direct {v2, v3, v4}, Lcom/mbridge/msdk/tracker/g;-><init>(Lcom/mbridge/msdk/tracker/c;Lcom/mbridge/msdk/tracker/s;)V

    invoke-direct {v1, v2}, Lcom/mbridge/msdk/tracker/q;-><init>(Lcom/mbridge/msdk/tracker/g;)V

    iput-object v1, p0, Lcom/mbridge/msdk/tracker/k;->i:Lcom/mbridge/msdk/tracker/l;

    goto :goto_2a

    :catchall_28
    move-exception p0

    goto :goto_2c

    :cond_2a
    :goto_2a
    monitor-exit v0

    goto :goto_2e

    :goto_2c
    monitor-exit v0
    :try_end_2d
    .catchall {:try_start_b .. :try_end_2d} :catchall_28

    throw p0

    :cond_2e
    :goto_2e
    iget-object p0, p0, Lcom/mbridge/msdk/tracker/k;->i:Lcom/mbridge/msdk/tracker/l;

    return-object p0
.end method

.method public i()Lcom/mbridge/msdk/tracker/j;
    .registers 3

    .prologue
    iget-object v0, p0, Lcom/mbridge/msdk/tracker/k;->k:Lcom/mbridge/msdk/tracker/j;

    invoke-static {v0}, Lcom/mbridge/msdk/tracker/y;->b(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_21

    const-class v0, Lcom/mbridge/msdk/tracker/k;

    monitor-enter v0

    :try_start_b
    iget-object v1, p0, Lcom/mbridge/msdk/tracker/k;->k:Lcom/mbridge/msdk/tracker/j;

    invoke-static {v1}, Lcom/mbridge/msdk/tracker/y;->b(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1d

    new-instance v1, Lcom/mbridge/msdk/tracker/j;

    invoke-direct {v1}, Lcom/mbridge/msdk/tracker/j;-><init>()V

    iput-object v1, p0, Lcom/mbridge/msdk/tracker/k;->k:Lcom/mbridge/msdk/tracker/j;

    goto :goto_1d

    :catchall_1b
    move-exception p0

    goto :goto_1f

    :cond_1d
    :goto_1d
    monitor-exit v0

    goto :goto_21

    :goto_1f
    monitor-exit v0
    :try_end_20
    .catchall {:try_start_b .. :try_end_20} :catchall_1b

    throw p0

    :cond_21
    :goto_21
    iget-object p0, p0, Lcom/mbridge/msdk/tracker/k;->k:Lcom/mbridge/msdk/tracker/j;

    return-object p0
.end method

.method public j()I
    .registers 2

    .prologue
    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/k;->c()Lcom/mbridge/msdk/tracker/x;

    move-result-object v0

    iget v0, v0, Lcom/mbridge/msdk/tracker/x;->a:I

    if-gez v0, :cond_b

    const/16 p0, 0x32

    return p0

    :cond_b
    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/k;->c()Lcom/mbridge/msdk/tracker/x;

    move-result-object p0

    iget p0, p0, Lcom/mbridge/msdk/tracker/x;->a:I

    return p0
.end method

.method public k()I
    .registers 2

    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/k;->c()Lcom/mbridge/msdk/tracker/x;

    move-result-object p0

    iget p0, p0, Lcom/mbridge/msdk/tracker/x;->e:I

    const/4 v0, 0x0

    invoke-static {p0, v0}, Ljava/lang/Math;->max(II)I

    move-result p0

    return p0
.end method

.method public l()I
    .registers 2

    .prologue
    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/k;->c()Lcom/mbridge/msdk/tracker/x;

    move-result-object v0

    iget v0, v0, Lcom/mbridge/msdk/tracker/x;->d:I

    if-gtz v0, :cond_a

    const/4 p0, 0x2

    return p0

    :cond_a
    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/k;->c()Lcom/mbridge/msdk/tracker/x;

    move-result-object p0

    iget p0, p0, Lcom/mbridge/msdk/tracker/x;->d:I

    return p0
.end method

.method public m()I
    .registers 2

    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/k;->c()Lcom/mbridge/msdk/tracker/x;

    move-result-object p0

    iget p0, p0, Lcom/mbridge/msdk/tracker/x;->b:I

    const/4 v0, 0x0

    invoke-static {p0, v0}, Ljava/lang/Math;->max(II)I

    move-result p0

    return p0
.end method

.method public n()Lcom/mbridge/msdk/tracker/o;
    .registers 7

    .prologue
    iget-object v0, p0, Lcom/mbridge/msdk/tracker/k;->n:Lcom/mbridge/msdk/tracker/o;

    invoke-static {v0}, Lcom/mbridge/msdk/tracker/y;->b(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_31

    const-class v0, Lcom/mbridge/msdk/tracker/k;

    monitor-enter v0

    :try_start_b
    iget-object v1, p0, Lcom/mbridge/msdk/tracker/k;->n:Lcom/mbridge/msdk/tracker/o;

    invoke-static {v1}, Lcom/mbridge/msdk/tracker/y;->b(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2d

    new-instance v1, Lcom/mbridge/msdk/tracker/o;

    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/k;->l()I

    move-result v2

    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/k;->o()Lcom/mbridge/msdk/tracker/p;

    move-result-object v3

    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/k;->s()Lcom/mbridge/msdk/tracker/w;

    move-result-object v4

    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/k;->r()I

    move-result v5

    invoke-direct {v1, v2, v3, v4, v5}, Lcom/mbridge/msdk/tracker/o;-><init>(ILcom/mbridge/msdk/tracker/p;Lcom/mbridge/msdk/tracker/w;I)V

    iput-object v1, p0, Lcom/mbridge/msdk/tracker/k;->n:Lcom/mbridge/msdk/tracker/o;

    goto :goto_2d

    :catchall_2b
    move-exception p0

    goto :goto_2f

    :cond_2d
    :goto_2d
    monitor-exit v0

    goto :goto_31

    :goto_2f
    monitor-exit v0
    :try_end_30
    .catchall {:try_start_b .. :try_end_30} :catchall_2b

    throw p0

    :cond_31
    :goto_31
    iget-object p0, p0, Lcom/mbridge/msdk/tracker/k;->n:Lcom/mbridge/msdk/tracker/o;

    return-object p0
.end method

.method public o()Lcom/mbridge/msdk/tracker/p;
    .registers 1

    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/k;->c()Lcom/mbridge/msdk/tracker/x;

    move-result-object p0

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/x;->g:Lcom/mbridge/msdk/tracker/p;

    return-object p0
.end method

.method public p()Lorg/json/JSONObject;
    .registers 2

    .prologue
    iget-object v0, p0, Lcom/mbridge/msdk/tracker/k;->e:Lorg/json/JSONObject;

    if-nez v0, :cond_b

    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    iput-object v0, p0, Lcom/mbridge/msdk/tracker/k;->e:Lorg/json/JSONObject;

    :cond_b
    return-object v0
.end method

.method public q()Lcom/mbridge/msdk/tracker/s;
    .registers 3

    .prologue
    iget-object v0, p0, Lcom/mbridge/msdk/tracker/k;->l:Lcom/mbridge/msdk/tracker/s;

    invoke-static {v0}, Lcom/mbridge/msdk/tracker/y;->b(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_21

    const-class v0, Lcom/mbridge/msdk/tracker/k;

    monitor-enter v0

    :try_start_b
    iget-object v1, p0, Lcom/mbridge/msdk/tracker/k;->l:Lcom/mbridge/msdk/tracker/s;

    invoke-static {v1}, Lcom/mbridge/msdk/tracker/y;->b(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1d

    new-instance v1, Lcom/mbridge/msdk/tracker/s;

    invoke-direct {v1, p0}, Lcom/mbridge/msdk/tracker/s;-><init>(Lcom/mbridge/msdk/tracker/k;)V

    iput-object v1, p0, Lcom/mbridge/msdk/tracker/k;->l:Lcom/mbridge/msdk/tracker/s;

    goto :goto_1d

    :catchall_1b
    move-exception p0

    goto :goto_1f

    :cond_1d
    :goto_1d
    monitor-exit v0

    goto :goto_21

    :goto_1f
    monitor-exit v0
    :try_end_20
    .catchall {:try_start_b .. :try_end_20} :catchall_1b

    throw p0

    :cond_21
    :goto_21
    iget-object p0, p0, Lcom/mbridge/msdk/tracker/k;->l:Lcom/mbridge/msdk/tracker/s;

    return-object p0
.end method

.method public r()I
    .registers 1

    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/k;->c()Lcom/mbridge/msdk/tracker/x;

    move-result-object p0

    iget p0, p0, Lcom/mbridge/msdk/tracker/x;->c:I

    return p0
.end method

.method public s()Lcom/mbridge/msdk/tracker/w;
    .registers 1

    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/k;->c()Lcom/mbridge/msdk/tracker/x;

    move-result-object p0

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/x;->i:Lcom/mbridge/msdk/tracker/w;

    return-object p0
.end method

.method public t()Ljava/lang/String;
    .registers 1

    .prologue
    sget-object p0, Lcom/mbridge/msdk/tracker/k;->o:Ljava/lang/String;

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p0

    if-eqz p0, :cond_13

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object p0

    invoke-virtual {p0}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object p0

    sput-object p0, Lcom/mbridge/msdk/tracker/k;->o:Ljava/lang/String;

    return-object p0

    :cond_13
    sget-object p0, Lcom/mbridge/msdk/tracker/k;->o:Ljava/lang/String;

    return-object p0
.end method

.method public u()Ljava/lang/String;
    .registers 1

    const-string p0, "event_table"

    return-object p0
.end method

.method public v()Lcom/mbridge/msdk/tracker/m;
    .registers 1

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/k;->b:Lcom/mbridge/msdk/tracker/m;

    return-object p0
.end method

.method public w()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/k;->a:Ljava/lang/String;

    return-object p0
.end method

.method public x()Z
    .registers 1

    iget-boolean p0, p0, Lcom/mbridge/msdk/tracker/k;->m:Z

    return p0
.end method

.method public y()Ljava/lang/String;
    .registers 5

    .prologue
    iget-object v0, p0, Lcom/mbridge/msdk/tracker/k;->c:Landroid/content/Context;

    invoke-static {v0}, Lcom/mbridge/msdk/tracker/y;->b(Ljava/lang/Object;)Z

    move-result v0

    const-string v1, ""

    if-nez v0, :cond_41

    iget-object v0, p0, Lcom/mbridge/msdk/tracker/k;->d:Lcom/mbridge/msdk/tracker/x;

    invoke-static {v0}, Lcom/mbridge/msdk/tracker/y;->b(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_13

    goto :goto_41

    :cond_13
    :try_start_13
    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/k;->q()Lcom/mbridge/msdk/tracker/s;

    move-result-object v0

    invoke-virtual {v0}, Lcom/mbridge/msdk/tracker/s;->k()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/mbridge/msdk/tracker/k;->m:Z

    sget-object v0, Lcom/mbridge/msdk/tracker/k;->o:Ljava/lang/String;

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_32

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/mbridge/msdk/tracker/k;->o:Ljava/lang/String;

    goto :goto_32

    :catch_30
    move-exception v0

    goto :goto_35

    :cond_32
    :goto_32
    sget-object p0, Lcom/mbridge/msdk/tracker/k;->o:Ljava/lang/String;
    :try_end_34
    .catch Ljava/lang/Exception; {:try_start_13 .. :try_end_34} :catch_30

    return-object p0

    :goto_35
    sget-boolean v2, Lcom/mbridge/msdk/tracker/a;->a:Z

    if-eqz v2, :cond_3e

    const-string v2, "TrackManager"

    const-string v3, "start error"

    nop

    :cond_3e
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/mbridge/msdk/tracker/k;->m:Z

    :cond_41
    :goto_41
    return-object v1
.end method
