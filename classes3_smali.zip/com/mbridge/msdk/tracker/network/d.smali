.class public Lcom/mbridge/msdk/tracker/network/d;
.super Lcom/mbridge/msdk/tracker/network/y;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# direct methods
.method public constructor <init>(Lcom/mbridge/msdk/tracker/network/q;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/mbridge/msdk/tracker/network/y;-><init>(Lcom/mbridge/msdk/tracker/network/q;)V

    return-void
.end method


# virtual methods
.method public d()I
    .registers 1

    const/4 p0, 0x1

    return p0
.end method
