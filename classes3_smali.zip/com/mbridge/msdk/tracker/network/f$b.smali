.class Lcom/mbridge/msdk/tracker/network/f$b;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/mbridge/msdk/tracker/network/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# instance fields
.field private final a:Lcom/mbridge/msdk/tracker/network/t;

.field private final b:Lcom/mbridge/msdk/tracker/network/v;

.field private final c:Ljava/lang/Runnable;


# direct methods
.method public constructor <init>(Lcom/mbridge/msdk/tracker/network/t;Lcom/mbridge/msdk/tracker/network/v;Ljava/lang/Runnable;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/mbridge/msdk/tracker/network/f$b;->a:Lcom/mbridge/msdk/tracker/network/t;

    iput-object p2, p0, Lcom/mbridge/msdk/tracker/network/f$b;->b:Lcom/mbridge/msdk/tracker/network/v;

    iput-object p3, p0, Lcom/mbridge/msdk/tracker/network/f$b;->c:Ljava/lang/Runnable;

    return-void
.end method


# virtual methods
.method public run()V
    .registers 3

    .prologue
    iget-object v0, p0, Lcom/mbridge/msdk/tracker/network/f$b;->a:Lcom/mbridge/msdk/tracker/network/t;

    invoke-virtual {v0}, Lcom/mbridge/msdk/tracker/network/t;->v()Z

    move-result v0

    if-eqz v0, :cond_10

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/network/f$b;->a:Lcom/mbridge/msdk/tracker/network/t;

    const-string v0, "canceled-at-delivery"

    invoke-virtual {p0, v0}, Lcom/mbridge/msdk/tracker/network/t;->c(Ljava/lang/String;)V

    return-void

    :cond_10
    iget-object v0, p0, Lcom/mbridge/msdk/tracker/network/f$b;->b:Lcom/mbridge/msdk/tracker/network/v;

    invoke-virtual {v0}, Lcom/mbridge/msdk/tracker/network/v;->a()Z

    move-result v0

    iget-object v1, p0, Lcom/mbridge/msdk/tracker/network/f$b;->a:Lcom/mbridge/msdk/tracker/network/t;

    if-eqz v0, :cond_22

    iget-object v0, p0, Lcom/mbridge/msdk/tracker/network/f$b;->b:Lcom/mbridge/msdk/tracker/network/v;

    iget-object v0, v0, Lcom/mbridge/msdk/tracker/network/v;->a:Ljava/lang/Object;

    invoke-virtual {v1, v0}, Lcom/mbridge/msdk/tracker/network/t;->a(Ljava/lang/Object;)V

    goto :goto_29

    :cond_22
    iget-object v0, p0, Lcom/mbridge/msdk/tracker/network/f$b;->b:Lcom/mbridge/msdk/tracker/network/v;

    iget-object v0, v0, Lcom/mbridge/msdk/tracker/network/v;->c:Lcom/mbridge/msdk/tracker/network/b0;

    invoke-virtual {v1, v0}, Lcom/mbridge/msdk/tracker/network/t;->b(Lcom/mbridge/msdk/tracker/network/b0;)V

    :goto_29
    iget-object v0, p0, Lcom/mbridge/msdk/tracker/network/f$b;->b:Lcom/mbridge/msdk/tracker/network/v;

    iget-boolean v0, v0, Lcom/mbridge/msdk/tracker/network/v;->d:Z

    iget-object v1, p0, Lcom/mbridge/msdk/tracker/network/f$b;->a:Lcom/mbridge/msdk/tracker/network/t;

    if-eqz v0, :cond_37

    const-string v0, "intermediate-response"

    invoke-virtual {v1, v0}, Lcom/mbridge/msdk/tracker/network/t;->a(Ljava/lang/String;)V

    goto :goto_3c

    :cond_37
    const-string v0, "done"

    invoke-virtual {v1, v0}, Lcom/mbridge/msdk/tracker/network/t;->c(Ljava/lang/String;)V

    :goto_3c
    iget-object p0, p0, Lcom/mbridge/msdk/tracker/network/f$b;->c:Ljava/lang/Runnable;

    if-eqz p0, :cond_43

    invoke-interface {p0}, Ljava/lang/Runnable;->run()V

    :cond_43
    return-void
.end method
