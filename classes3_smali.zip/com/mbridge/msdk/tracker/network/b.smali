.class public interface abstract Lcom/mbridge/msdk/tracker/network/b;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/mbridge/msdk/tracker/network/b$a;
    }
.end annotation


# virtual methods
.method public abstract a(Ljava/lang/String;Lcom/mbridge/msdk/tracker/network/b$a;)V
.end method
