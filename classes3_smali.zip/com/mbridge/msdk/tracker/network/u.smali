.class public Lcom/mbridge/msdk/tracker/network/u;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/mbridge/msdk/tracker/network/u$c;
    }
.end annotation


# instance fields
.field private volatile a:Ljava/util/concurrent/ThreadPoolExecutor;

.field private final b:Ljava/util/concurrent/atomic/AtomicInteger;

.field private final c:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Lcom/mbridge/msdk/tracker/network/t<",
            "*>;>;"
        }
    .end annotation
.end field

.field private final d:Ljava/util/concurrent/PriorityBlockingQueue;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/PriorityBlockingQueue<",
            "Lcom/mbridge/msdk/tracker/network/t<",
            "*>;>;"
        }
    .end annotation
.end field

.field private final e:I

.field private final f:Lcom/mbridge/msdk/tracker/network/b;

.field private final g:Lcom/mbridge/msdk/tracker/network/m;

.field private final h:Lcom/mbridge/msdk/tracker/network/w;

.field private final i:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/mbridge/msdk/tracker/network/u$c;",
            ">;"
        }
    .end annotation
.end field

.field private j:Z


# direct methods
.method public constructor <init>(Lcom/mbridge/msdk/tracker/network/m;Lcom/mbridge/msdk/tracker/network/w;ILcom/mbridge/msdk/tracker/network/b;)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-direct {v0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>()V

    iput-object v0, p0, Lcom/mbridge/msdk/tracker/network/u;->b:Ljava/util/concurrent/atomic/AtomicInteger;

    new-instance v0, Ljava/util/HashSet;

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    iput-object v0, p0, Lcom/mbridge/msdk/tracker/network/u;->c:Ljava/util/Set;

    new-instance v0, Ljava/util/concurrent/PriorityBlockingQueue;

    invoke-direct {v0}, Ljava/util/concurrent/PriorityBlockingQueue;-><init>()V

    iput-object v0, p0, Lcom/mbridge/msdk/tracker/network/u;->d:Ljava/util/concurrent/PriorityBlockingQueue;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/mbridge/msdk/tracker/network/u;->i:Ljava/util/List;

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/mbridge/msdk/tracker/network/u;->j:Z

    iput p3, p0, Lcom/mbridge/msdk/tracker/network/u;->e:I

    iput-object p4, p0, Lcom/mbridge/msdk/tracker/network/u;->f:Lcom/mbridge/msdk/tracker/network/b;

    iput-object p1, p0, Lcom/mbridge/msdk/tracker/network/u;->g:Lcom/mbridge/msdk/tracker/network/m;

    iput-object p2, p0, Lcom/mbridge/msdk/tracker/network/u;->h:Lcom/mbridge/msdk/tracker/network/w;

    return-void
.end method

.method public static synthetic a(Lcom/mbridge/msdk/tracker/network/u;)Ljava/util/concurrent/PriorityBlockingQueue;
    .registers 1

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/network/u;->d:Ljava/util/concurrent/PriorityBlockingQueue;

    return-object p0
.end method

.method private a(I)V
    .registers 3

    .prologue
    iget-object v0, p0, Lcom/mbridge/msdk/tracker/network/u;->a:Ljava/util/concurrent/ThreadPoolExecutor;

    if-eqz v0, :cond_5

    goto :goto_11

    :cond_5
    :try_start_5
    invoke-direct {p0, p1}, Lcom/mbridge/msdk/tracker/network/u;->b(I)V
    :try_end_8
    .catchall {:try_start_5 .. :try_end_8} :catchall_9

    return-void

    :catchall_9
    const/4 p1, 0x5

    :try_start_a
    invoke-direct {p0, p1}, Lcom/mbridge/msdk/tracker/network/u;->b(I)V
    :try_end_d
    .catch Ljava/lang/Exception; {:try_start_a .. :try_end_d} :catch_e

    goto :goto_11

    :catch_e
    const/4 p1, 0x0

    iput-object p1, p0, Lcom/mbridge/msdk/tracker/network/u;->a:Ljava/util/concurrent/ThreadPoolExecutor;

    :goto_11
    return-void
.end method

.method public static synthetic b(Lcom/mbridge/msdk/tracker/network/u;)Lcom/mbridge/msdk/tracker/network/m;
    .registers 1

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/network/u;->g:Lcom/mbridge/msdk/tracker/network/m;

    return-object p0
.end method

.method private b(I)V
    .registers 11

    new-instance v0, Ljava/util/concurrent/ThreadPoolExecutor;

    new-instance v6, Ljava/util/concurrent/LinkedBlockingQueue;

    invoke-direct {v6}, Ljava/util/concurrent/LinkedBlockingQueue;-><init>()V

    new-instance v7, Lcom/mbridge/msdk/tracker/network/u$a;

    invoke-direct {v7, p0}, Lcom/mbridge/msdk/tracker/network/u$a;-><init>(Lcom/mbridge/msdk/tracker/network/u;)V

    new-instance v8, Ljava/util/concurrent/ThreadPoolExecutor$DiscardPolicy;

    invoke-direct {v8}, Ljava/util/concurrent/ThreadPoolExecutor$DiscardPolicy;-><init>()V

    const-wide/16 v3, 0x64

    sget-object v5, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    move v2, p1

    move v1, p1

    invoke-direct/range {v0 .. v8}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;Ljava/util/concurrent/RejectedExecutionHandler;)V

    iput-object v0, p0, Lcom/mbridge/msdk/tracker/network/u;->a:Ljava/util/concurrent/ThreadPoolExecutor;

    return-void
.end method

.method public static synthetic c(Lcom/mbridge/msdk/tracker/network/u;)Lcom/mbridge/msdk/tracker/network/b;
    .registers 1

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/network/u;->f:Lcom/mbridge/msdk/tracker/network/b;

    return-object p0
.end method

.method public static synthetic d(Lcom/mbridge/msdk/tracker/network/u;)Lcom/mbridge/msdk/tracker/network/w;
    .registers 1

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/network/u;->h:Lcom/mbridge/msdk/tracker/network/w;

    return-object p0
.end method


# virtual methods
.method public a()I
    .registers 1

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/network/u;->b:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicInteger;->incrementAndGet()I

    move-result p0

    return p0
.end method

.method public a(Lcom/mbridge/msdk/tracker/network/t;)Lcom/mbridge/msdk/tracker/network/t;
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/mbridge/msdk/tracker/network/t<",
            "TT;>;)",
            "Lcom/mbridge/msdk/tracker/network/t<",
            "TT;>;"
        }
    .end annotation

    .prologue
    invoke-virtual {p1, p0}, Lcom/mbridge/msdk/tracker/network/t;->a(Lcom/mbridge/msdk/tracker/network/u;)Lcom/mbridge/msdk/tracker/network/t;

    iget-object v0, p0, Lcom/mbridge/msdk/tracker/network/u;->c:Ljava/util/Set;

    monitor-enter v0

    :try_start_6
    iget-object v1, p0, Lcom/mbridge/msdk/tracker/network/u;->c:Ljava/util/Set;

    invoke-interface {v1, p1}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    monitor-exit v0
    :try_end_c
    .catchall {:try_start_6 .. :try_end_c} :catchall_3b

    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/network/u;->a()I

    move-result v0

    invoke-virtual {p1, v0}, Lcom/mbridge/msdk/tracker/network/t;->b(I)Lcom/mbridge/msdk/tracker/network/t;

    const-string v0, "add-to-queue"

    invoke-virtual {p1, v0}, Lcom/mbridge/msdk/tracker/network/t;->a(Ljava/lang/String;)V

    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Lcom/mbridge/msdk/tracker/network/u;->a(Lcom/mbridge/msdk/tracker/network/t;I)V

    invoke-virtual {p0, p1}, Lcom/mbridge/msdk/tracker/network/u;->b(Lcom/mbridge/msdk/tracker/network/t;)V

    iget-object v0, p0, Lcom/mbridge/msdk/tracker/network/u;->a:Ljava/util/concurrent/ThreadPoolExecutor;

    if-nez v0, :cond_28

    iget v0, p0, Lcom/mbridge/msdk/tracker/network/u;->e:I

    invoke-direct {p0, v0}, Lcom/mbridge/msdk/tracker/network/u;->a(I)V

    :cond_28
    iget-object v0, p0, Lcom/mbridge/msdk/tracker/network/u;->a:Ljava/util/concurrent/ThreadPoolExecutor;

    invoke-virtual {v0}, Ljava/util/concurrent/ThreadPoolExecutor;->isShutdown()Z

    move-result v0

    if-nez v0, :cond_3a

    iget-object v0, p0, Lcom/mbridge/msdk/tracker/network/u;->a:Ljava/util/concurrent/ThreadPoolExecutor;

    new-instance v1, Lcom/mbridge/msdk/tracker/network/u$b;

    invoke-direct {v1, p0}, Lcom/mbridge/msdk/tracker/network/u$b;-><init>(Lcom/mbridge/msdk/tracker/network/u;)V

    invoke-virtual {v0, v1}, Ljava/util/concurrent/ThreadPoolExecutor;->execute(Ljava/lang/Runnable;)V

    :cond_3a
    return-object p1

    :catchall_3b
    move-exception p0

    :try_start_3c
    monitor-exit v0
    :try_end_3d
    .catchall {:try_start_3c .. :try_end_3d} :catchall_3b

    throw p0
.end method

.method public a(Lcom/mbridge/msdk/tracker/network/t;I)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/mbridge/msdk/tracker/network/t<",
            "*>;I)V"
        }
    .end annotation

    .prologue
    iget-object v0, p0, Lcom/mbridge/msdk/tracker/network/u;->i:Ljava/util/List;

    monitor-enter v0

    :try_start_3
    iget-object p0, p0, Lcom/mbridge/msdk/tracker/network/u;->i:Ljava/util/List;

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_9
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_1b

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/mbridge/msdk/tracker/network/u$c;

    invoke-interface {v1, p1, p2}, Lcom/mbridge/msdk/tracker/network/u$c;->a(Lcom/mbridge/msdk/tracker/network/t;I)V

    goto :goto_9

    :catchall_19
    move-exception p0

    goto :goto_1d

    :cond_1b
    monitor-exit v0

    return-void

    :goto_1d
    monitor-exit v0
    :try_end_1e
    .catchall {:try_start_3 .. :try_end_1e} :catchall_19

    throw p0
.end method

.method public b()V
    .registers 2

    .prologue
    iget-boolean v0, p0, Lcom/mbridge/msdk/tracker/network/u;->j:Z

    if-eqz v0, :cond_9

    iget-object v0, p0, Lcom/mbridge/msdk/tracker/network/u;->a:Ljava/util/concurrent/ThreadPoolExecutor;

    if-eqz v0, :cond_9

    return-void

    :cond_9
    iget v0, p0, Lcom/mbridge/msdk/tracker/network/u;->e:I

    invoke-direct {p0, v0}, Lcom/mbridge/msdk/tracker/network/u;->a(I)V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/mbridge/msdk/tracker/network/u;->j:Z

    return-void
.end method

.method public b(Lcom/mbridge/msdk/tracker/network/t;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/mbridge/msdk/tracker/network/t<",
            "TT;>;)V"
        }
    .end annotation

    invoke-virtual {p0, p1}, Lcom/mbridge/msdk/tracker/network/u;->d(Lcom/mbridge/msdk/tracker/network/t;)V

    return-void
.end method

.method public c(Lcom/mbridge/msdk/tracker/network/t;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/mbridge/msdk/tracker/network/t<",
            "TT;>;)V"
        }
    .end annotation

    .prologue
    iget-object v0, p0, Lcom/mbridge/msdk/tracker/network/u;->c:Ljava/util/Set;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, Lcom/mbridge/msdk/tracker/network/u;->c:Ljava/util/Set;

    invoke-interface {v1, p1}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    monitor-exit v0
    :try_end_9
    .catchall {:try_start_3 .. :try_end_9} :catchall_e

    const/4 v0, 0x5

    invoke-virtual {p0, p1, v0}, Lcom/mbridge/msdk/tracker/network/u;->a(Lcom/mbridge/msdk/tracker/network/t;I)V

    return-void

    :catchall_e
    move-exception p0

    :try_start_f
    monitor-exit v0
    :try_end_10
    .catchall {:try_start_f .. :try_end_10} :catchall_e

    throw p0
.end method

.method public d(Lcom/mbridge/msdk/tracker/network/t;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lcom/mbridge/msdk/tracker/network/t<",
            "TT;>;)V"
        }
    .end annotation

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/network/u;->d:Ljava/util/concurrent/PriorityBlockingQueue;

    invoke-virtual {p0, p1}, Ljava/util/concurrent/PriorityBlockingQueue;->add(Ljava/lang/Object;)Z

    return-void
.end method
