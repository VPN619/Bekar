.class final Lcom/mbridge/msdk/tracker/network/toolbox/k;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/mbridge/msdk/tracker/network/toolbox/k$b;
    }
.end annotation


# direct methods
.method public static a(Lcom/mbridge/msdk/tracker/network/t;JLjava/util/List;)Lcom/mbridge/msdk/tracker/network/q;
    .registers 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/mbridge/msdk/tracker/network/t<",
            "*>;J",
            "Ljava/util/List<",
            "Lcom/mbridge/msdk/tracker/network/g;",
            ">;)",
            "Lcom/mbridge/msdk/tracker/network/q;"
        }
    .end annotation

    .prologue
    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/network/t;->d()Lcom/mbridge/msdk/tracker/network/b$a;

    move-result-object p0

    if-nez p0, :cond_12

    new-instance v0, Lcom/mbridge/msdk/tracker/network/q;

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/16 v1, 0x130

    move-wide v4, p1

    move-object v6, p3

    invoke-direct/range {v0 .. v6}, Lcom/mbridge/msdk/tracker/network/q;-><init>(I[BZJLjava/util/List;)V

    return-object v0

    :cond_12
    move-wide v4, p1

    move-object v6, p3

    invoke-static {v6, p0}, Lcom/mbridge/msdk/tracker/network/toolbox/f;->a(Ljava/util/List;Lcom/mbridge/msdk/tracker/network/b$a;)Ljava/util/List;

    move-result-object v7

    new-instance v1, Lcom/mbridge/msdk/tracker/network/q;

    iget-object v3, p0, Lcom/mbridge/msdk/tracker/network/b$a;->a:[B

    const/16 v2, 0x130

    move-wide v5, v4

    const/4 v4, 0x1

    invoke-direct/range {v1 .. v7}, Lcom/mbridge/msdk/tracker/network/q;-><init>(I[BZJLjava/util/List;)V

    return-object v1
.end method

.method public static a(Lcom/mbridge/msdk/tracker/network/t;Ljava/io/IOException;JLcom/mbridge/msdk/tracker/network/toolbox/g;[B)Lcom/mbridge/msdk/tracker/network/toolbox/k$b;
    .registers 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/mbridge/msdk/tracker/network/t<",
            "*>;",
            "Ljava/io/IOException;",
            "J",
            "Lcom/mbridge/msdk/tracker/network/toolbox/g;",
            "[B)",
            "Lcom/mbridge/msdk/tracker/network/toolbox/k$b;"
        }
    .end annotation

    .prologue
    instance-of v0, p1, Ljava/net/SocketTimeoutException;

    const/4 v1, 0x0

    if-eqz v0, :cond_12

    new-instance p0, Lcom/mbridge/msdk/tracker/network/toolbox/k$b;

    new-instance p1, Lcom/mbridge/msdk/tracker/network/z;

    invoke-direct {p1}, Lcom/mbridge/msdk/tracker/network/z;-><init>()V

    const-string p2, "socket"

    invoke-direct {p0, p2, p1, v1}, Lcom/mbridge/msdk/tracker/network/toolbox/k$b;-><init>(Ljava/lang/String;Lcom/mbridge/msdk/tracker/network/b0;Lcom/mbridge/msdk/tracker/network/toolbox/k$a;)V

    return-object p0

    :cond_12
    instance-of v0, p1, Ljava/net/MalformedURLException;

    if-nez v0, :cond_9a

    if-eqz p4, :cond_81

    invoke-virtual {p4}, Lcom/mbridge/msdk/tracker/network/toolbox/g;->d()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/network/t;->t()Ljava/lang/String;

    move-result-object v0

    filled-new-array {p1, v0}, [Ljava/lang/Object;

    move-result-object p1

    const-string v0, "Unexpected response code %d for %s"

    invoke-static {v0, p1}, Lcom/mbridge/msdk/tracker/network/c0;->c(Ljava/lang/String;[Ljava/lang/Object;)V

    if-eqz p5, :cond_71

    invoke-virtual {p4}, Lcom/mbridge/msdk/tracker/network/toolbox/g;->c()Ljava/util/List;

    move-result-object v8

    new-instance v2, Lcom/mbridge/msdk/tracker/network/q;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    sub-long v6, v4, p2

    const/4 v5, 0x0

    move-object v4, p5

    invoke-direct/range {v2 .. v8}, Lcom/mbridge/msdk/tracker/network/q;-><init>(I[BZJLjava/util/List;)V

    const/16 p1, 0x190

    if-lt v3, p1, :cond_52

    const/16 p1, 0x1f3

    if-le v3, p1, :cond_49

    goto :goto_52

    :cond_49
    new-instance p0, Lcom/mbridge/msdk/tracker/network/d;

    invoke-direct {p0, v2}, Lcom/mbridge/msdk/tracker/network/d;-><init>(Lcom/mbridge/msdk/tracker/network/q;)V

    invoke-virtual {p0, v3}, Lcom/mbridge/msdk/tracker/network/b0;->a(I)V

    throw p0

    :cond_52
    :goto_52
    new-instance p1, Lcom/mbridge/msdk/tracker/network/y;

    invoke-direct {p1, v2}, Lcom/mbridge/msdk/tracker/network/y;-><init>(Lcom/mbridge/msdk/tracker/network/q;)V

    invoke-virtual {p1, v3}, Lcom/mbridge/msdk/tracker/network/b0;->a(I)V

    const/16 p2, 0x1f4

    if-lt v3, p2, :cond_70

    const/16 p2, 0x257

    if-gt v3, p2, :cond_70

    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/network/t;->B()Z

    move-result p0

    if-eqz p0, :cond_70

    new-instance p0, Lcom/mbridge/msdk/tracker/network/toolbox/k$b;

    const-string p2, "server"

    invoke-direct {p0, p2, p1, v1}, Lcom/mbridge/msdk/tracker/network/toolbox/k$b;-><init>(Ljava/lang/String;Lcom/mbridge/msdk/tracker/network/b0;Lcom/mbridge/msdk/tracker/network/toolbox/k$a;)V

    return-object p0

    :cond_70
    throw p1

    :cond_71
    new-instance p0, Lcom/mbridge/msdk/tracker/network/o;

    invoke-direct {p0}, Lcom/mbridge/msdk/tracker/network/o;-><init>()V

    invoke-virtual {p0, v3}, Lcom/mbridge/msdk/tracker/network/b0;->a(I)V

    new-instance p1, Lcom/mbridge/msdk/tracker/network/toolbox/k$b;

    const-string p2, "network"

    invoke-direct {p1, p2, p0, v1}, Lcom/mbridge/msdk/tracker/network/toolbox/k$b;-><init>(Ljava/lang/String;Lcom/mbridge/msdk/tracker/network/b0;Lcom/mbridge/msdk/tracker/network/toolbox/k$a;)V

    return-object p1

    :cond_81
    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/network/t;->A()Z

    move-result p0

    if-eqz p0, :cond_94

    new-instance p0, Lcom/mbridge/msdk/tracker/network/toolbox/k$b;

    new-instance p1, Lcom/mbridge/msdk/tracker/network/r;

    invoke-direct {p1}, Lcom/mbridge/msdk/tracker/network/r;-><init>()V

    const-string p2, "connection"

    invoke-direct {p0, p2, p1, v1}, Lcom/mbridge/msdk/tracker/network/toolbox/k$b;-><init>(Ljava/lang/String;Lcom/mbridge/msdk/tracker/network/b0;Lcom/mbridge/msdk/tracker/network/toolbox/k$a;)V

    return-object p0

    :cond_94
    new-instance p0, Lcom/mbridge/msdk/tracker/network/r;

    invoke-direct {p0, p1}, Lcom/mbridge/msdk/tracker/network/r;-><init>(Ljava/lang/Throwable;)V

    throw p0

    :cond_9a
    new-instance p1, Lcom/mbridge/msdk/tracker/network/a;

    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/network/t;->t()Ljava/lang/String;

    move-result-object p0

    new-instance p2, Ljava/lang/StringBuilder;

    const-string p3, "Bad URL "

    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Lcom/mbridge/msdk/tracker/network/a;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public static a(JLcom/mbridge/msdk/tracker/network/t;[BI)V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(J",
            "Lcom/mbridge/msdk/tracker/network/t<",
            "*>;[BI)V"
        }
    .end annotation

    .prologue
    const-wide/16 v0, 0xbb8

    cmp-long v0, p0, v0

    if-lez v0, :cond_2d

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    if-eqz p3, :cond_12

    array-length p1, p3

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    goto :goto_14

    :cond_12
    const-string p1, "null"

    :goto_14
    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p3

    invoke-virtual {p2}, Lcom/mbridge/msdk/tracker/network/t;->o()Lcom/mbridge/msdk/tracker/network/x;

    move-result-object p4

    invoke-interface {p4}, Lcom/mbridge/msdk/tracker/network/x;->c()I

    move-result p4

    invoke-static {p4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p4

    filled-new-array {p2, p0, p1, p3, p4}, [Ljava/lang/Object;

    move-result-object p0

    const-string p1, "HTTP response for request=<%s> [lifetime=%d], [size=%s], [rc=%d], [retryCount=%s]"

    invoke-static {p1, p0}, Lcom/mbridge/msdk/tracker/network/c0;->b(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_2d
    return-void
.end method

.method private static a(Lcom/mbridge/msdk/tracker/network/p;)V
    .registers 3

    .prologue
    if-eqz p0, :cond_7

    const-wide/16 v0, 0x0

    invoke-virtual {p0, v0, v1}, Lcom/mbridge/msdk/tracker/network/p;->c(J)V

    :cond_7
    return-void
.end method

.method private static a(Lcom/mbridge/msdk/tracker/network/p;I)V
    .registers 6

    .prologue
    if-eqz p0, :cond_b

    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/network/p;->B()J

    move-result-wide v0

    int-to-long v2, p1

    add-long/2addr v0, v2

    invoke-virtual {p0, v0, v1}, Lcom/mbridge/msdk/tracker/network/p;->c(J)V

    :cond_b
    return-void
.end method

.method public static a(Lcom/mbridge/msdk/tracker/network/t;Lcom/mbridge/msdk/tracker/network/toolbox/k$b;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/mbridge/msdk/tracker/network/t<",
            "*>;",
            "Lcom/mbridge/msdk/tracker/network/toolbox/k$b;",
            ")V"
        }
    .end annotation

    .prologue
    if-eqz p0, :cond_1f

    if-eqz p1, :cond_17

    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/network/t;->o()Lcom/mbridge/msdk/tracker/network/x;

    move-result-object p0

    iget-object v0, p1, Lcom/mbridge/msdk/tracker/network/toolbox/k$b;->b:Lcom/mbridge/msdk/tracker/network/b0;

    if-eqz p0, :cond_16

    invoke-interface {p0, v0}, Lcom/mbridge/msdk/tracker/network/x;->a(Lcom/mbridge/msdk/tracker/network/b0;)Z

    move-result p0

    if-eqz p0, :cond_13

    return-void

    :cond_13
    iget-object p0, p1, Lcom/mbridge/msdk/tracker/network/toolbox/k$b;->b:Lcom/mbridge/msdk/tracker/network/b0;

    throw p0

    :cond_16
    throw v0

    :cond_17
    new-instance p0, Lcom/mbridge/msdk/tracker/network/a0;

    const-string p1, "retry info is null when retrying"

    invoke-direct {p0, p1}, Lcom/mbridge/msdk/tracker/network/a0;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1f
    new-instance p0, Lcom/mbridge/msdk/tracker/network/a0;

    const-string p1, "request is null when retrying"

    invoke-direct {p0, p1}, Lcom/mbridge/msdk/tracker/network/a0;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static a(Ljava/io/InputStream;ILcom/mbridge/msdk/tracker/network/toolbox/c;Lcom/mbridge/msdk/tracker/network/p;)[B
    .registers 9

    .prologue
    const-string v0, "Error occurred when closing InputStream"

    new-instance v1, Lcom/mbridge/msdk/tracker/network/toolbox/n;

    invoke-direct {v1, p2, p1}, Lcom/mbridge/msdk/tracker/network/toolbox/n;-><init>(Lcom/mbridge/msdk/tracker/network/toolbox/c;I)V

    invoke-static {p3}, Lcom/mbridge/msdk/tracker/network/toolbox/k;->a(Lcom/mbridge/msdk/tracker/network/p;)V

    const/16 p1, 0x400

    const/4 v2, 0x0

    :try_start_d
    invoke-virtual {p2, p1}, Lcom/mbridge/msdk/tracker/network/toolbox/c;->a(I)[B

    move-result-object p1
    :try_end_11
    .catchall {:try_start_d .. :try_end_11} :catchall_35

    :goto_11
    :try_start_11
    invoke-virtual {p0, p1}, Ljava/io/InputStream;->read([B)I

    move-result v3

    const/4 v4, -0x1

    if-eq v3, v4, :cond_21

    invoke-virtual {v1, p1, v2, v3}, Lcom/mbridge/msdk/tracker/network/toolbox/n;->write([BII)V

    invoke-static {p3, v3}, Lcom/mbridge/msdk/tracker/network/toolbox/k;->a(Lcom/mbridge/msdk/tracker/network/p;I)V

    goto :goto_11

    :catchall_1f
    move-exception p3

    goto :goto_37

    :cond_21
    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p3
    :try_end_25
    .catchall {:try_start_11 .. :try_end_25} :catchall_1f

    :try_start_25
    invoke-virtual {p0}, Ljava/io/InputStream;->close()V
    :try_end_28
    .catch Ljava/io/IOException; {:try_start_25 .. :try_end_28} :catch_29

    goto :goto_2e

    :catch_29
    new-array p0, v2, [Ljava/lang/Object;

    invoke-static {v0, p0}, Lcom/mbridge/msdk/tracker/network/c0;->d(Ljava/lang/String;[Ljava/lang/Object;)V

    :goto_2e
    invoke-virtual {p2, p1}, Lcom/mbridge/msdk/tracker/network/toolbox/c;->a([B)V

    invoke-virtual {v1}, Lcom/mbridge/msdk/tracker/network/toolbox/n;->close()V

    return-object p3

    :catchall_35
    move-exception p3

    const/4 p1, 0x0

    :goto_37
    if-eqz p0, :cond_42

    :try_start_39
    invoke-virtual {p0}, Ljava/io/InputStream;->close()V
    :try_end_3c
    .catch Ljava/io/IOException; {:try_start_39 .. :try_end_3c} :catch_3d

    goto :goto_42

    :catch_3d
    new-array p0, v2, [Ljava/lang/Object;

    invoke-static {v0, p0}, Lcom/mbridge/msdk/tracker/network/c0;->d(Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_42
    :goto_42
    invoke-virtual {p2, p1}, Lcom/mbridge/msdk/tracker/network/toolbox/c;->a([B)V

    invoke-virtual {v1}, Lcom/mbridge/msdk/tracker/network/toolbox/n;->close()V

    throw p3
.end method
