.class public Lcom/mbridge/msdk/tracker/network/toolbox/n;
.super Ljava/io/ByteArrayOutputStream;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field private final a:Lcom/mbridge/msdk/tracker/network/toolbox/c;


# direct methods
.method public constructor <init>(Lcom/mbridge/msdk/tracker/network/toolbox/c;I)V
    .registers 4

    invoke-direct {p0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    iput-object p1, p0, Lcom/mbridge/msdk/tracker/network/toolbox/n;->a:Lcom/mbridge/msdk/tracker/network/toolbox/c;

    const/16 v0, 0x100

    invoke-static {p2, v0}, Ljava/lang/Math;->max(II)I

    move-result p2

    invoke-virtual {p1, p2}, Lcom/mbridge/msdk/tracker/network/toolbox/c;->a(I)[B

    move-result-object p1

    iput-object p1, p0, Ljava/io/ByteArrayOutputStream;->buf:[B

    return-void
.end method

.method private a(I)V
    .registers 5

    .prologue
    iget v0, p0, Ljava/io/ByteArrayOutputStream;->count:I

    add-int/2addr v0, p1

    iget-object p1, p0, Ljava/io/ByteArrayOutputStream;->buf:[B

    array-length p1, p1

    if-gt v0, p1, :cond_9

    return-void

    :cond_9
    iget-object p1, p0, Lcom/mbridge/msdk/tracker/network/toolbox/n;->a:Lcom/mbridge/msdk/tracker/network/toolbox/c;

    mul-int/lit8 v0, v0, 0x2

    invoke-virtual {p1, v0}, Lcom/mbridge/msdk/tracker/network/toolbox/c;->a(I)[B

    move-result-object p1

    iget-object v0, p0, Ljava/io/ByteArrayOutputStream;->buf:[B

    iget v1, p0, Ljava/io/ByteArrayOutputStream;->count:I

    const/4 v2, 0x0

    invoke-static {v0, v2, p1, v2, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-object v0, p0, Lcom/mbridge/msdk/tracker/network/toolbox/n;->a:Lcom/mbridge/msdk/tracker/network/toolbox/c;

    iget-object v1, p0, Ljava/io/ByteArrayOutputStream;->buf:[B

    invoke-virtual {v0, v1}, Lcom/mbridge/msdk/tracker/network/toolbox/c;->a([B)V

    iput-object p1, p0, Ljava/io/ByteArrayOutputStream;->buf:[B

    return-void
.end method


# virtual methods
.method public close()V
    .registers 3

    iget-object v0, p0, Lcom/mbridge/msdk/tracker/network/toolbox/n;->a:Lcom/mbridge/msdk/tracker/network/toolbox/c;

    iget-object v1, p0, Ljava/io/ByteArrayOutputStream;->buf:[B

    invoke-virtual {v0, v1}, Lcom/mbridge/msdk/tracker/network/toolbox/c;->a([B)V

    const/4 v0, 0x0

    iput-object v0, p0, Ljava/io/ByteArrayOutputStream;->buf:[B

    invoke-super {p0}, Ljava/io/ByteArrayOutputStream;->close()V

    return-void
.end method

.method public finalize()V
    .registers 2

    iget-object v0, p0, Lcom/mbridge/msdk/tracker/network/toolbox/n;->a:Lcom/mbridge/msdk/tracker/network/toolbox/c;

    iget-object p0, p0, Ljava/io/ByteArrayOutputStream;->buf:[B

    invoke-virtual {v0, p0}, Lcom/mbridge/msdk/tracker/network/toolbox/c;->a([B)V

    return-void
.end method

.method public declared-synchronized write(I)V
    .registers 3

    .prologue
    monitor-enter p0

    const/4 v0, 0x1

    :try_start_2
    invoke-direct {p0, v0}, Lcom/mbridge/msdk/tracker/network/toolbox/n;->a(I)V

    invoke-super {p0, p1}, Ljava/io/ByteArrayOutputStream;->write(I)V
    :try_end_8
    .catchall {:try_start_2 .. :try_end_8} :catchall_a

    monitor-exit p0

    return-void

    :catchall_a
    move-exception p1

    :try_start_b
    monitor-exit p0
    :try_end_c
    .catchall {:try_start_b .. :try_end_c} :catchall_a

    throw p1
.end method

.method public declared-synchronized write([BII)V
    .registers 4

    .prologue
    monitor-enter p0

    :try_start_1
    invoke-direct {p0, p3}, Lcom/mbridge/msdk/tracker/network/toolbox/n;->a(I)V

    if-eqz p1, :cond_c

    invoke-super {p0, p1, p2, p3}, Ljava/io/ByteArrayOutputStream;->write([BII)V
    :try_end_9
    .catchall {:try_start_1 .. :try_end_9} :catchall_a

    goto :goto_c

    :catchall_a
    move-exception p1

    goto :goto_e

    :cond_c
    :goto_c
    monitor-exit p0

    return-void

    :goto_e
    :try_start_e
    monitor-exit p0
    :try_end_f
    .catchall {:try_start_e .. :try_end_f} :catchall_a

    throw p1
.end method
