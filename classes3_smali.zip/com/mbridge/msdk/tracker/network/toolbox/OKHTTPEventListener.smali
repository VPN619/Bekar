.class public Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;
.super Lcom/mbridge/msdk/thrid/okhttp/o;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lcom/mbridge/msdk/system/NoProGuard;


# static fields
.field private static TAG:Ljava/lang/String;


# instance fields
.field private final monitor:Lcom/mbridge/msdk/tracker/network/p;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-string v0, "OKHTTPEventListener"

    sput-object v0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->TAG:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Lcom/mbridge/msdk/tracker/network/p;)V
    .registers 2

    invoke-direct {p0}, Lcom/mbridge/msdk/thrid/okhttp/o;-><init>()V

    iput-object p1, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    return-void
.end method


# virtual methods
.method public callEnd(Lcom/mbridge/msdk/thrid/okhttp/d;)V
    .registers 2

    .prologue
    iget-object p0, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    if-nez p0, :cond_5

    return-void

    :cond_5
    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Lcom/mbridge/msdk/tracker/network/p;->a(Ljava/io/IOException;)V

    return-void
.end method

.method public callFailed(Lcom/mbridge/msdk/thrid/okhttp/d;Ljava/io/IOException;)V
    .registers 3

    .prologue
    iget-object p0, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    if-nez p0, :cond_5

    return-void

    :cond_5
    invoke-virtual {p0, p2}, Lcom/mbridge/msdk/tracker/network/p;->a(Ljava/io/IOException;)V

    return-void
.end method

.method public callStart(Lcom/mbridge/msdk/thrid/okhttp/d;)V
    .registers 2

    .prologue
    iget-object p0, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    if-nez p0, :cond_5

    return-void

    :cond_5
    invoke-virtual {p0, p1}, Lcom/mbridge/msdk/tracker/network/p;->a(Lcom/mbridge/msdk/thrid/okhttp/d;)V

    return-void
.end method

.method public connectEnd(Lcom/mbridge/msdk/thrid/okhttp/d;Ljava/net/InetSocketAddress;Ljava/net/Proxy;Lcom/mbridge/msdk/thrid/okhttp/w;)V
    .registers 5

    .prologue
    iget-object p1, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    if-nez p1, :cond_5

    return-void

    :cond_5
    const-string p2, "connection_end"

    invoke-virtual {p1, p2}, Lcom/mbridge/msdk/tracker/network/p;->d(Ljava/lang/String;)V

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    const/4 p1, 0x0

    invoke-virtual {p0, p4, p1}, Lcom/mbridge/msdk/tracker/network/p;->a(Lcom/mbridge/msdk/thrid/okhttp/w;Ljava/io/IOException;)V

    return-void
.end method

.method public connectFailed(Lcom/mbridge/msdk/thrid/okhttp/d;Ljava/net/InetSocketAddress;Ljava/net/Proxy;Lcom/mbridge/msdk/thrid/okhttp/w;Ljava/io/IOException;)V
    .registers 6

    .prologue
    iget-object p0, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    if-nez p0, :cond_5

    return-void

    :cond_5
    invoke-virtual {p0, p4, p5}, Lcom/mbridge/msdk/tracker/network/p;->a(Lcom/mbridge/msdk/thrid/okhttp/w;Ljava/io/IOException;)V

    return-void
.end method

.method public connectStart(Lcom/mbridge/msdk/thrid/okhttp/d;Ljava/net/InetSocketAddress;Ljava/net/Proxy;)V
    .registers 5

    .prologue
    iget-object p1, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    if-nez p1, :cond_5

    return-void

    :cond_5
    const-string v0, "connection_start"

    invoke-virtual {p1, v0}, Lcom/mbridge/msdk/tracker/network/p;->d(Ljava/lang/String;)V

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    invoke-virtual {p0, p2, p3}, Lcom/mbridge/msdk/tracker/network/p;->a(Ljava/net/InetSocketAddress;Ljava/net/Proxy;)V

    return-void
.end method

.method public connectionAcquired(Lcom/mbridge/msdk/thrid/okhttp/d;Lcom/mbridge/msdk/thrid/okhttp/h;)V
    .registers 3

    .prologue
    iget-object p0, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    if-nez p0, :cond_5

    return-void

    :cond_5
    invoke-virtual {p0, p2}, Lcom/mbridge/msdk/tracker/network/p;->a(Lcom/mbridge/msdk/thrid/okhttp/h;)V

    return-void
.end method

.method public connectionReleased(Lcom/mbridge/msdk/thrid/okhttp/d;Lcom/mbridge/msdk/thrid/okhttp/h;)V
    .registers 3

    .prologue
    iget-object p0, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    if-nez p0, :cond_5

    return-void

    :cond_5
    invoke-virtual {p0, p2}, Lcom/mbridge/msdk/tracker/network/p;->b(Lcom/mbridge/msdk/thrid/okhttp/h;)V

    return-void
.end method

.method public dnsEnd(Lcom/mbridge/msdk/thrid/okhttp/d;Ljava/lang/String;Ljava/util/List;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/mbridge/msdk/thrid/okhttp/d;",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/net/InetAddress;",
            ">;)V"
        }
    .end annotation

    .prologue
    iget-object p1, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    if-nez p1, :cond_5

    return-void

    :cond_5
    const-string p2, "dns_end"

    invoke-virtual {p1, p2}, Lcom/mbridge/msdk/tracker/network/p;->d(Ljava/lang/String;)V

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    invoke-virtual {p0, p3}, Lcom/mbridge/msdk/tracker/network/p;->a(Ljava/util/List;)V

    return-void
.end method

.method public dnsStart(Lcom/mbridge/msdk/thrid/okhttp/d;Ljava/lang/String;)V
    .registers 3

    .prologue
    iget-object p1, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    if-nez p1, :cond_5

    return-void

    :cond_5
    const-string p2, "dns_start"

    invoke-virtual {p1, p2}, Lcom/mbridge/msdk/tracker/network/p;->d(Ljava/lang/String;)V

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/network/p;->a()V

    return-void
.end method

.method public requestBodyEnd(Lcom/mbridge/msdk/thrid/okhttp/d;J)V
    .registers 5

    .prologue
    iget-object p1, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    if-nez p1, :cond_5

    return-void

    :cond_5
    const-string v0, "request_body_end"

    invoke-virtual {p1, v0}, Lcom/mbridge/msdk/tracker/network/p;->d(Ljava/lang/String;)V

    iget-object p1, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    invoke-virtual {p1, p2, p3}, Lcom/mbridge/msdk/tracker/network/p;->b(J)V

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    const-string p1, "transmission_start"

    invoke-virtual {p0, p1}, Lcom/mbridge/msdk/tracker/network/p;->d(Ljava/lang/String;)V

    return-void
.end method

.method public requestBodyStart(Lcom/mbridge/msdk/thrid/okhttp/d;)V
    .registers 3

    .prologue
    iget-object p1, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    if-nez p1, :cond_5

    return-void

    :cond_5
    const-string v0, "request_body_start"

    invoke-virtual {p1, v0}, Lcom/mbridge/msdk/tracker/network/p;->d(Ljava/lang/String;)V

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/network/p;->R()V

    return-void
.end method

.method public requestHeadersEnd(Lcom/mbridge/msdk/thrid/okhttp/d;Lcom/mbridge/msdk/thrid/okhttp/y;)V
    .registers 4

    .prologue
    iget-object p1, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    if-nez p1, :cond_5

    return-void

    :cond_5
    const-string v0, "request_header_end"

    invoke-virtual {p1, v0}, Lcom/mbridge/msdk/tracker/network/p;->d(Ljava/lang/String;)V

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    invoke-virtual {p0, p2}, Lcom/mbridge/msdk/tracker/network/p;->a(Lcom/mbridge/msdk/thrid/okhttp/y;)V

    return-void
.end method

.method public requestHeadersStart(Lcom/mbridge/msdk/thrid/okhttp/d;)V
    .registers 3

    .prologue
    iget-object p1, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    if-nez p1, :cond_5

    return-void

    :cond_5
    const-string v0, "request_header_start"

    invoke-virtual {p1, v0}, Lcom/mbridge/msdk/tracker/network/p;->d(Ljava/lang/String;)V

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/network/p;->S()V

    return-void
.end method

.method public responseBodyEnd(Lcom/mbridge/msdk/thrid/okhttp/d;J)V
    .registers 5

    .prologue
    iget-object p1, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    if-nez p1, :cond_5

    return-void

    :cond_5
    const-string v0, "response_body_end"

    invoke-virtual {p1, v0}, Lcom/mbridge/msdk/tracker/network/p;->d(Ljava/lang/String;)V

    iget-object p1, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    invoke-virtual {p1, p2, p3}, Lcom/mbridge/msdk/tracker/network/p;->h(J)V

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    invoke-virtual {p0, p2, p3}, Lcom/mbridge/msdk/tracker/network/p;->d(J)V

    return-void
.end method

.method public responseBodyStart(Lcom/mbridge/msdk/thrid/okhttp/d;)V
    .registers 3

    .prologue
    iget-object p1, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    if-nez p1, :cond_5

    return-void

    :cond_5
    const-string v0, "response_body_start"

    invoke-virtual {p1, v0}, Lcom/mbridge/msdk/tracker/network/p;->d(Ljava/lang/String;)V

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/network/p;->U()V

    return-void
.end method

.method public responseHeadersEnd(Lcom/mbridge/msdk/thrid/okhttp/d;Lcom/mbridge/msdk/thrid/okhttp/a0;)V
    .registers 4

    .prologue
    iget-object p1, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    if-nez p1, :cond_5

    return-void

    :cond_5
    const-string v0, "response_header_end"

    invoke-virtual {p1, v0}, Lcom/mbridge/msdk/tracker/network/p;->d(Ljava/lang/String;)V

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    invoke-virtual {p0, p2}, Lcom/mbridge/msdk/tracker/network/p;->a(Lcom/mbridge/msdk/thrid/okhttp/a0;)V

    return-void
.end method

.method public responseHeadersStart(Lcom/mbridge/msdk/thrid/okhttp/d;)V
    .registers 3

    .prologue
    iget-object p1, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    if-nez p1, :cond_5

    return-void

    :cond_5
    const-string v0, "response_header_start"

    invoke-virtual {p1, v0}, Lcom/mbridge/msdk/tracker/network/p;->d(Ljava/lang/String;)V

    iget-object p1, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    invoke-virtual {p1}, Lcom/mbridge/msdk/tracker/network/p;->V()V

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    const-string p1, "transmission_end"

    invoke-virtual {p0, p1}, Lcom/mbridge/msdk/tracker/network/p;->d(Ljava/lang/String;)V

    return-void
.end method

.method public secureConnectEnd(Lcom/mbridge/msdk/thrid/okhttp/d;Lcom/mbridge/msdk/thrid/okhttp/q;)V
    .registers 4

    .prologue
    iget-object p1, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    if-nez p1, :cond_5

    return-void

    :cond_5
    const-string v0, "secure_connect_end"

    invoke-virtual {p1, v0}, Lcom/mbridge/msdk/tracker/network/p;->d(Ljava/lang/String;)V

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    invoke-virtual {p0, p2}, Lcom/mbridge/msdk/tracker/network/p;->a(Lcom/mbridge/msdk/thrid/okhttp/q;)V

    return-void
.end method

.method public secureConnectStart(Lcom/mbridge/msdk/thrid/okhttp/d;)V
    .registers 3

    .prologue
    iget-object p1, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    if-nez p1, :cond_5

    return-void

    :cond_5
    const-string v0, "secure_connect_start"

    invoke-virtual {p1, v0}, Lcom/mbridge/msdk/tracker/network/p;->d(Ljava/lang/String;)V

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/network/toolbox/OKHTTPEventListener;->monitor:Lcom/mbridge/msdk/tracker/network/p;

    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/network/p;->W()V

    return-void
.end method
