.class public final Lcom/mbridge/msdk/tracker/network/toolbox/g;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field private final a:I

.field private final b:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/mbridge/msdk/tracker/network/g;",
            ">;"
        }
    .end annotation
.end field

.field private final c:I

.field private final d:Ljava/io/InputStream;

.field private final e:[B


# direct methods
.method public constructor <init>(ILjava/util/List;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Lcom/mbridge/msdk/tracker/network/g;",
            ">;)V"
        }
    .end annotation

    const/4 v0, -0x1

    const/4 v1, 0x0

    invoke-direct {p0, p1, p2, v0, v1}, Lcom/mbridge/msdk/tracker/network/toolbox/g;-><init>(ILjava/util/List;ILjava/io/InputStream;)V

    return-void
.end method

.method public constructor <init>(ILjava/util/List;ILjava/io/InputStream;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Lcom/mbridge/msdk/tracker/network/g;",
            ">;I",
            "Ljava/io/InputStream;",
            ")V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/mbridge/msdk/tracker/network/toolbox/g;->a:I

    iput-object p2, p0, Lcom/mbridge/msdk/tracker/network/toolbox/g;->b:Ljava/util/List;

    iput p3, p0, Lcom/mbridge/msdk/tracker/network/toolbox/g;->c:I

    iput-object p4, p0, Lcom/mbridge/msdk/tracker/network/toolbox/g;->d:Ljava/io/InputStream;

    const/4 p1, 0x0

    iput-object p1, p0, Lcom/mbridge/msdk/tracker/network/toolbox/g;->e:[B

    return-void
.end method


# virtual methods
.method public final a()Ljava/io/InputStream;
    .registers 2

    .prologue
    iget-object v0, p0, Lcom/mbridge/msdk/tracker/network/toolbox/g;->d:Ljava/io/InputStream;

    if-eqz v0, :cond_5

    return-object v0

    :cond_5
    iget-object v0, p0, Lcom/mbridge/msdk/tracker/network/toolbox/g;->e:[B

    if-eqz v0, :cond_11

    new-instance v0, Ljava/io/ByteArrayInputStream;

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/network/toolbox/g;->e:[B

    invoke-direct {v0, p0}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    return-object v0

    :cond_11
    const/4 p0, 0x0

    return-object p0
.end method

.method public final b()I
    .registers 1

    iget p0, p0, Lcom/mbridge/msdk/tracker/network/toolbox/g;->c:I

    return p0
.end method

.method public final c()Ljava/util/List;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/mbridge/msdk/tracker/network/g;",
            ">;"
        }
    .end annotation

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/network/toolbox/g;->b:Ljava/util/List;

    invoke-static {p0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object p0

    return-object p0
.end method

.method public final d()I
    .registers 1

    iget p0, p0, Lcom/mbridge/msdk/tracker/network/toolbox/g;->a:I

    return p0
.end method
