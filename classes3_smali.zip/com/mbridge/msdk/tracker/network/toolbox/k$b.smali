.class Lcom/mbridge/msdk/tracker/network/toolbox/k$b;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/mbridge/msdk/tracker/network/toolbox/k;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# instance fields
.field final a:Ljava/lang/String;

.field final b:Lcom/mbridge/msdk/tracker/network/b0;


# direct methods
.method private constructor <init>(Ljava/lang/String;Lcom/mbridge/msdk/tracker/network/b0;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/mbridge/msdk/tracker/network/toolbox/k$b;->a:Ljava/lang/String;

    iput-object p2, p0, Lcom/mbridge/msdk/tracker/network/toolbox/k$b;->b:Lcom/mbridge/msdk/tracker/network/b0;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Lcom/mbridge/msdk/tracker/network/b0;Lcom/mbridge/msdk/tracker/network/toolbox/k$a;)V
    .registers 4

    invoke-direct {p0, p1, p2}, Lcom/mbridge/msdk/tracker/network/toolbox/k$b;-><init>(Ljava/lang/String;Lcom/mbridge/msdk/tracker/network/b0;)V

    return-void
.end method
