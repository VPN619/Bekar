.class public Lcom/mbridge/msdk/tracker/network/o;
.super Lcom/mbridge/msdk/tracker/network/b0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lcom/mbridge/msdk/tracker/network/b0;-><init>()V

    return-void
.end method

.method public constructor <init>(Ljava/lang/Throwable;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/mbridge/msdk/tracker/network/b0;-><init>(Ljava/lang/Throwable;)V

    return-void
.end method


# virtual methods
.method public d()I
    .registers 1

    const/4 p0, 0x3

    return p0
.end method
