.class public Lcom/mbridge/msdk/tracker/network/e;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lcom/mbridge/msdk/tracker/network/x;


# instance fields
.field private a:I

.field private b:J

.field private c:I

.field private final d:I


# direct methods
.method public constructor <init>()V
    .registers 3

    const/16 v0, 0x9c4

    const/4 v1, 0x1

    invoke-direct {p0, v0, v1}, Lcom/mbridge/msdk/tracker/network/e;-><init>(II)V

    return-void
.end method

.method public constructor <init>(II)V
    .registers 5

    const-wide/32 v0, 0xea60

    invoke-direct {p0, p1, v0, v1, p2}, Lcom/mbridge/msdk/tracker/network/e;-><init>(IJI)V

    return-void
.end method

.method public constructor <init>(IJI)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p2, p0, Lcom/mbridge/msdk/tracker/network/e;->b:J

    iput p1, p0, Lcom/mbridge/msdk/tracker/network/e;->a:I

    iput p4, p0, Lcom/mbridge/msdk/tracker/network/e;->d:I

    return-void
.end method


# virtual methods
.method public a()J
    .registers 3

    iget-wide v0, p0, Lcom/mbridge/msdk/tracker/network/e;->b:J

    return-wide v0
.end method

.method public a(Lcom/mbridge/msdk/tracker/network/b0;)Z
    .registers 3

    .prologue
    iget p1, p0, Lcom/mbridge/msdk/tracker/network/e;->c:I

    const/4 v0, 0x1

    add-int/2addr p1, v0

    iput p1, p0, Lcom/mbridge/msdk/tracker/network/e;->c:I

    iget p0, p0, Lcom/mbridge/msdk/tracker/network/e;->d:I

    if-gt p1, p0, :cond_b

    return v0

    :cond_b
    const/4 p0, 0x0

    return p0
.end method

.method public b()I
    .registers 1

    iget p0, p0, Lcom/mbridge/msdk/tracker/network/e;->a:I

    return p0
.end method

.method public c()I
    .registers 1

    iget p0, p0, Lcom/mbridge/msdk/tracker/network/e;->c:I

    return p0
.end method
