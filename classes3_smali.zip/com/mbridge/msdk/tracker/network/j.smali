.class public interface abstract Lcom/mbridge/msdk/tracker/network/j;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "<T:",
        "Ljava/lang/Object;",
        ">",
        "Ljava/lang/Object;"
    }
.end annotation


# virtual methods
.method public abstract a(Lcom/mbridge/msdk/tracker/network/h;Lcom/mbridge/msdk/tracker/network/v;Lcom/mbridge/msdk/tracker/network/q;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/mbridge/msdk/tracker/network/h<",
            "TT;>;",
            "Lcom/mbridge/msdk/tracker/network/v<",
            "TT;>;",
            "Lcom/mbridge/msdk/tracker/network/q;",
            ")V"
        }
    .end annotation
.end method

.method public abstract b(Lcom/mbridge/msdk/tracker/network/h;Lcom/mbridge/msdk/tracker/network/v;Lcom/mbridge/msdk/tracker/network/q;)V
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/mbridge/msdk/tracker/network/h<",
            "TT;>;",
            "Lcom/mbridge/msdk/tracker/network/v<",
            "TT;>;",
            "Lcom/mbridge/msdk/tracker/network/q;",
            ")V"
        }
    .end annotation
.end method
