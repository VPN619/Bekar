.class public Lcom/mbridge/msdk/tracker/network/l;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field private static volatile b:Lcom/mbridge/msdk/tracker/network/l;


# instance fields
.field private a:Lcom/mbridge/msdk/tracker/network/u;


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a()Lcom/mbridge/msdk/tracker/network/l;
    .registers 2

    .prologue
    sget-object v0, Lcom/mbridge/msdk/tracker/network/l;->b:Lcom/mbridge/msdk/tracker/network/l;

    if-nez v0, :cond_19

    const-class v0, Lcom/mbridge/msdk/tracker/network/l;

    monitor-enter v0

    :try_start_7
    sget-object v1, Lcom/mbridge/msdk/tracker/network/l;->b:Lcom/mbridge/msdk/tracker/network/l;

    if-nez v1, :cond_15

    new-instance v1, Lcom/mbridge/msdk/tracker/network/l;

    invoke-direct {v1}, Lcom/mbridge/msdk/tracker/network/l;-><init>()V

    sput-object v1, Lcom/mbridge/msdk/tracker/network/l;->b:Lcom/mbridge/msdk/tracker/network/l;

    goto :goto_15

    :catchall_13
    move-exception v1

    goto :goto_17

    :cond_15
    :goto_15
    monitor-exit v0

    goto :goto_19

    :goto_17
    monitor-exit v0
    :try_end_18
    .catchall {:try_start_7 .. :try_end_18} :catchall_13

    throw v1

    :cond_19
    :goto_19
    sget-object v0, Lcom/mbridge/msdk/tracker/network/l;->b:Lcom/mbridge/msdk/tracker/network/l;

    return-object v0
.end method


# virtual methods
.method public b()Lcom/mbridge/msdk/tracker/network/u;
    .registers 5

    .prologue
    iget-object v0, p0, Lcom/mbridge/msdk/tracker/network/l;->a:Lcom/mbridge/msdk/tracker/network/u;

    if-nez v0, :cond_1f

    new-instance v0, Lcom/mbridge/msdk/tracker/network/toolbox/b;

    new-instance v1, Lcom/mbridge/msdk/tracker/network/toolbox/m;

    invoke-direct {v1}, Lcom/mbridge/msdk/tracker/network/toolbox/m;-><init>()V

    invoke-direct {v0, v1}, Lcom/mbridge/msdk/tracker/network/toolbox/b;-><init>(Lcom/mbridge/msdk/tracker/network/toolbox/a;)V

    new-instance v1, Lcom/mbridge/msdk/tracker/network/toolbox/l;

    invoke-direct {v1}, Lcom/mbridge/msdk/tracker/network/toolbox/l;-><init>()V

    const/4 v2, 0x0

    const/16 v3, 0xa

    invoke-static {v0, v2, v3, v1}, Lcom/mbridge/msdk/tracker/network/toolbox/o;->a(Lcom/mbridge/msdk/tracker/network/m;Lcom/mbridge/msdk/tracker/network/w;ILcom/mbridge/msdk/tracker/network/b;)Lcom/mbridge/msdk/tracker/network/u;

    move-result-object v0

    iput-object v0, p0, Lcom/mbridge/msdk/tracker/network/l;->a:Lcom/mbridge/msdk/tracker/network/u;

    invoke-virtual {v0}, Lcom/mbridge/msdk/tracker/network/u;->b()V

    :cond_1f
    iget-object p0, p0, Lcom/mbridge/msdk/tracker/network/l;->a:Lcom/mbridge/msdk/tracker/network/u;

    return-object p0
.end method
