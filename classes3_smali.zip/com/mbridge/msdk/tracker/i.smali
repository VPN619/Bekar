.class public Lcom/mbridge/msdk/tracker/i;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field static i:Ljava/lang/String;

.field static j:Ljava/lang/String;


# instance fields
.field private final a:Lcom/mbridge/msdk/tracker/e;

.field private b:I

.field private c:I

.field private final d:Ljava/lang/String;

.field private e:J

.field private f:Z

.field private g:Z

.field private h:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-string v0, "CREATE TABLE IF NOT EXISTS %s (id INTEGER PRIMARY KEY,uuid TEXT,name TEXT,type INTEGER,time_stamp INTEGER,duration INTEGER,properties TEXT,priority INTEGER,state INTEGER,invalid_time INTEGER,ignore_max_timeout INTEGER,ignore_max_retry_times INTEGER,report_error_message TEXT,report_count INTEGER)"

    sput-object v0, Lcom/mbridge/msdk/tracker/i;->i:Ljava/lang/String;

    const-string v0, "DROP TABLE IF EXISTS %s"

    sput-object v0, Lcom/mbridge/msdk/tracker/i;->j:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Lcom/mbridge/msdk/tracker/e;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/mbridge/msdk/tracker/i;->f:Z

    iput-boolean v0, p0, Lcom/mbridge/msdk/tracker/i;->g:Z

    iput-object p1, p0, Lcom/mbridge/msdk/tracker/i;->a:Lcom/mbridge/msdk/tracker/e;

    invoke-virtual {p1}, Lcom/mbridge/msdk/tracker/e;->n()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/mbridge/msdk/tracker/i;->d:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public a(I)V
    .registers 2

    iput p1, p0, Lcom/mbridge/msdk/tracker/i;->b:I

    return-void
.end method

.method public a(J)V
    .registers 3

    iput-wide p1, p0, Lcom/mbridge/msdk/tracker/i;->e:J

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lcom/mbridge/msdk/tracker/i;->h:Ljava/lang/String;

    return-void
.end method

.method public a(Z)V
    .registers 2

    iput-boolean p1, p0, Lcom/mbridge/msdk/tracker/i;->g:Z

    return-void
.end method

.method public b(I)V
    .registers 2

    iput p1, p0, Lcom/mbridge/msdk/tracker/i;->c:I

    return-void
.end method

.method public b(Z)V
    .registers 2

    iput-boolean p1, p0, Lcom/mbridge/msdk/tracker/i;->f:Z

    return-void
.end method

.method public d()Lcom/mbridge/msdk/tracker/e;
    .registers 1

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/i;->a:Lcom/mbridge/msdk/tracker/e;

    return-object p0
.end method

.method public g()J
    .registers 3

    iget-wide v0, p0, Lcom/mbridge/msdk/tracker/i;->e:J

    return-wide v0
.end method

.method public h()I
    .registers 1

    iget p0, p0, Lcom/mbridge/msdk/tracker/i;->b:I

    return p0
.end method

.method public i()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/i;->h:Ljava/lang/String;

    return-object p0
.end method

.method public j()I
    .registers 1

    iget p0, p0, Lcom/mbridge/msdk/tracker/i;->c:I

    return p0
.end method

.method public k()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/i;->d:Ljava/lang/String;

    return-object p0
.end method

.method public l()Z
    .registers 1

    iget-boolean p0, p0, Lcom/mbridge/msdk/tracker/i;->g:Z

    return p0
.end method

.method public m()Z
    .registers 1

    iget-boolean p0, p0, Lcom/mbridge/msdk/tracker/i;->f:Z

    return p0
.end method
