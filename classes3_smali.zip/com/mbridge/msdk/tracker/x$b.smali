.class public final Lcom/mbridge/msdk/tracker/x$b;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/mbridge/msdk/tracker/x;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "b"
.end annotation


# instance fields
.field private a:I

.field private b:I

.field private c:I

.field private d:Lcom/mbridge/msdk/tracker/p;

.field private e:I

.field private f:I

.field private g:I

.field private h:Lcom/mbridge/msdk/tracker/d;

.field private i:Lcom/mbridge/msdk/tracker/w;

.field private j:Lcom/mbridge/msdk/tracker/f;


# direct methods
.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x32

    iput v0, p0, Lcom/mbridge/msdk/tracker/x$b;->a:I

    const/16 v1, 0x3a98

    iput v1, p0, Lcom/mbridge/msdk/tracker/x$b;->b:I

    const/4 v1, 0x1

    iput v1, p0, Lcom/mbridge/msdk/tracker/x$b;->c:I

    const/4 v1, 0x2

    iput v1, p0, Lcom/mbridge/msdk/tracker/x$b;->e:I

    iput v0, p0, Lcom/mbridge/msdk/tracker/x$b;->f:I

    const v0, 0x240c8400

    iput v0, p0, Lcom/mbridge/msdk/tracker/x$b;->g:I

    return-void
.end method

.method public static synthetic a(Lcom/mbridge/msdk/tracker/x$b;)I
    .registers 1

    iget p0, p0, Lcom/mbridge/msdk/tracker/x$b;->a:I

    return p0
.end method

.method public static synthetic b(Lcom/mbridge/msdk/tracker/x$b;)I
    .registers 1

    iget p0, p0, Lcom/mbridge/msdk/tracker/x$b;->b:I

    return p0
.end method

.method public static synthetic c(Lcom/mbridge/msdk/tracker/x$b;)I
    .registers 1

    iget p0, p0, Lcom/mbridge/msdk/tracker/x$b;->c:I

    return p0
.end method

.method public static synthetic d(Lcom/mbridge/msdk/tracker/x$b;)I
    .registers 1

    iget p0, p0, Lcom/mbridge/msdk/tracker/x$b;->e:I

    return p0
.end method

.method public static synthetic e(Lcom/mbridge/msdk/tracker/x$b;)I
    .registers 1

    iget p0, p0, Lcom/mbridge/msdk/tracker/x$b;->f:I

    return p0
.end method

.method public static synthetic f(Lcom/mbridge/msdk/tracker/x$b;)I
    .registers 1

    iget p0, p0, Lcom/mbridge/msdk/tracker/x$b;->g:I

    return p0
.end method

.method public static synthetic g(Lcom/mbridge/msdk/tracker/x$b;)Lcom/mbridge/msdk/tracker/p;
    .registers 1

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/x$b;->d:Lcom/mbridge/msdk/tracker/p;

    return-object p0
.end method

.method public static synthetic h(Lcom/mbridge/msdk/tracker/x$b;)Lcom/mbridge/msdk/tracker/d;
    .registers 1

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/x$b;->h:Lcom/mbridge/msdk/tracker/d;

    return-object p0
.end method

.method public static synthetic i(Lcom/mbridge/msdk/tracker/x$b;)Lcom/mbridge/msdk/tracker/w;
    .registers 1

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/x$b;->i:Lcom/mbridge/msdk/tracker/w;

    return-object p0
.end method

.method public static synthetic j(Lcom/mbridge/msdk/tracker/x$b;)Lcom/mbridge/msdk/tracker/f;
    .registers 1

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/x$b;->j:Lcom/mbridge/msdk/tracker/f;

    return-object p0
.end method


# virtual methods
.method public a(I)Lcom/mbridge/msdk/tracker/x$b;
    .registers 2

    .prologue
    if-gez p1, :cond_8

    const p1, 0x240c8400

    iput p1, p0, Lcom/mbridge/msdk/tracker/x$b;->g:I

    return-object p0

    :cond_8
    iput p1, p0, Lcom/mbridge/msdk/tracker/x$b;->g:I

    return-object p0
.end method

.method public a(ILcom/mbridge/msdk/tracker/p;)Lcom/mbridge/msdk/tracker/x$b;
    .registers 3

    iput p1, p0, Lcom/mbridge/msdk/tracker/x$b;->c:I

    iput-object p2, p0, Lcom/mbridge/msdk/tracker/x$b;->d:Lcom/mbridge/msdk/tracker/p;

    return-object p0
.end method

.method public a(Lcom/mbridge/msdk/tracker/d;)Lcom/mbridge/msdk/tracker/x$b;
    .registers 2

    iput-object p1, p0, Lcom/mbridge/msdk/tracker/x$b;->h:Lcom/mbridge/msdk/tracker/d;

    return-object p0
.end method

.method public a(Lcom/mbridge/msdk/tracker/f;)Lcom/mbridge/msdk/tracker/x$b;
    .registers 2

    iput-object p1, p0, Lcom/mbridge/msdk/tracker/x$b;->j:Lcom/mbridge/msdk/tracker/f;

    return-object p0
.end method

.method public a(Lcom/mbridge/msdk/tracker/w;)Lcom/mbridge/msdk/tracker/x$b;
    .registers 2

    iput-object p1, p0, Lcom/mbridge/msdk/tracker/x$b;->i:Lcom/mbridge/msdk/tracker/w;

    return-object p0
.end method

.method public a()Lcom/mbridge/msdk/tracker/x;
    .registers 3

    .prologue
    iget-object v0, p0, Lcom/mbridge/msdk/tracker/x$b;->h:Lcom/mbridge/msdk/tracker/d;

    invoke-static {v0}, Lcom/mbridge/msdk/tracker/y;->b(Ljava/lang/Object;)Z

    move-result v0

    const-string v1, "TrackManager"

    if-eqz v0, :cond_11

    sget-boolean v0, Lcom/mbridge/msdk/tracker/a;->a:Z

    if-eqz v0, :cond_11

    const-string v0, "decorate can not be null"

    nop

    :cond_11
    iget-object v0, p0, Lcom/mbridge/msdk/tracker/x$b;->i:Lcom/mbridge/msdk/tracker/w;

    invoke-static {v0}, Lcom/mbridge/msdk/tracker/y;->b(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_20

    sget-boolean v0, Lcom/mbridge/msdk/tracker/a;->a:Z

    if-eqz v0, :cond_20

    const-string v0, "responseHandler can not be null"

    nop

    :cond_20
    iget-object v0, p0, Lcom/mbridge/msdk/tracker/x$b;->d:Lcom/mbridge/msdk/tracker/p;

    invoke-static {v0}, Lcom/mbridge/msdk/tracker/y;->b(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_34

    iget-object v0, p0, Lcom/mbridge/msdk/tracker/x$b;->d:Lcom/mbridge/msdk/tracker/p;

    invoke-virtual {v0}, Lcom/mbridge/msdk/tracker/p;->b()Lcom/mbridge/msdk/tracker/network/toolbox/a;

    move-result-object v0

    invoke-static {v0}, Lcom/mbridge/msdk/tracker/y;->b(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3b

    :cond_34
    sget-boolean v0, Lcom/mbridge/msdk/tracker/a;->a:Z

    if-eqz v0, :cond_3b

    const-string v0, "networkStackConfig or stack can not be null"

    nop

    :cond_3b
    new-instance v0, Lcom/mbridge/msdk/tracker/x;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lcom/mbridge/msdk/tracker/x;-><init>(Lcom/mbridge/msdk/tracker/x$b;Lcom/mbridge/msdk/tracker/x$a;)V

    return-object v0
.end method

.method public b(I)Lcom/mbridge/msdk/tracker/x$b;
    .registers 2

    .prologue
    if-gtz p1, :cond_7

    const/16 p1, 0x32

    iput p1, p0, Lcom/mbridge/msdk/tracker/x$b;->a:I

    return-object p0

    :cond_7
    iput p1, p0, Lcom/mbridge/msdk/tracker/x$b;->a:I

    return-object p0
.end method

.method public c(I)Lcom/mbridge/msdk/tracker/x$b;
    .registers 2

    .prologue
    if-gez p1, :cond_7

    const/16 p1, 0x3a98

    iput p1, p0, Lcom/mbridge/msdk/tracker/x$b;->b:I

    return-object p0

    :cond_7
    iput p1, p0, Lcom/mbridge/msdk/tracker/x$b;->b:I

    return-object p0
.end method

.method public d(I)Lcom/mbridge/msdk/tracker/x$b;
    .registers 2

    .prologue
    if-gez p1, :cond_7

    const/16 p1, 0x32

    iput p1, p0, Lcom/mbridge/msdk/tracker/x$b;->f:I

    return-object p0

    :cond_7
    iput p1, p0, Lcom/mbridge/msdk/tracker/x$b;->f:I

    return-object p0
.end method

.method public e(I)Lcom/mbridge/msdk/tracker/x$b;
    .registers 2

    .prologue
    if-gtz p1, :cond_6

    const/4 p1, 0x2

    iput p1, p0, Lcom/mbridge/msdk/tracker/x$b;->e:I

    return-object p0

    :cond_6
    iput p1, p0, Lcom/mbridge/msdk/tracker/x$b;->e:I

    return-object p0
.end method
