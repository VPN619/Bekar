.class Lcom/mbridge/msdk/tracker/y;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# direct methods
.method public static a(IJJ)J
    .registers 7

    .prologue
    if-lez p0, :cond_32

    const-wide/16 v0, 0x0

    cmp-long p1, p1, v0

    if-nez p1, :cond_9

    goto :goto_32

    :cond_9
    const/16 p1, 0xa

    if-gt p0, p1, :cond_e

    goto :goto_32

    :cond_e
    const/16 p1, 0x14

    if-gt p0, p1, :cond_16

    const-wide/32 p0, 0xea60

    return-wide p0

    :cond_16
    const/16 p1, 0x1e

    if-gt p0, p1, :cond_1e

    const-wide/32 p0, 0x1d4c0

    return-wide p0

    :cond_1e
    const/16 p1, 0x28

    if-gt p0, p1, :cond_26

    const-wide/32 p0, 0x2bf20

    return-wide p0

    :cond_26
    const/16 p1, 0x32

    if-gt p0, p1, :cond_2e

    const-wide/32 p0, 0x3a980

    return-wide p0

    :cond_2e
    const-wide/32 p0, 0x493e0

    return-wide p0

    :cond_32
    :goto_32
    return-wide p3
.end method

.method public static a(Landroid/database/Cursor;)V
    .registers 2

    .prologue
    :try_start_0
    invoke-static {p0}, Lcom/mbridge/msdk/tracker/y;->a(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_f

    invoke-interface {p0}, Landroid/database/Cursor;->isClosed()Z

    move-result v0

    if-nez v0, :cond_f

    invoke-interface {p0}, Landroid/database/Cursor;->close()V
    :try_end_f
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_f} :catch_f

    :catch_f
    :cond_f
    return-void
.end method

.method public static a(Lcom/mbridge/msdk/tracker/e;)Z
    .registers 2

    .prologue
    invoke-static {p0}, Lcom/mbridge/msdk/tracker/y;->a(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_e

    invoke-virtual {p0}, Lcom/mbridge/msdk/tracker/e;->h()I

    move-result p0

    const/4 v0, 0x1

    if-ne p0, v0, :cond_e

    return v0

    :cond_e
    const/4 p0, 0x0

    return p0
.end method

.method public static a(Ljava/lang/Object;)Z
    .registers 1

    .prologue
    if-eqz p0, :cond_4

    const/4 p0, 0x1

    return p0

    :cond_4
    const/4 p0, 0x0

    return p0
.end method

.method public static a(Ljava/util/List;)Z
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/mbridge/msdk/tracker/i;",
            ">;)Z"
        }
    .end annotation

    .prologue
    invoke-static {p0}, Lcom/mbridge/msdk/tracker/y;->b(Ljava/util/List;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_8

    return v1

    :cond_8
    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_c
    :goto_c
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_32

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/mbridge/msdk/tracker/i;

    invoke-static {v0}, Lcom/mbridge/msdk/tracker/y;->b(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_1f

    goto :goto_c

    :cond_1f
    invoke-virtual {v0}, Lcom/mbridge/msdk/tracker/i;->d()Lcom/mbridge/msdk/tracker/e;

    move-result-object v0

    invoke-static {v0}, Lcom/mbridge/msdk/tracker/y;->b(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2a

    goto :goto_c

    :cond_2a
    invoke-virtual {v0}, Lcom/mbridge/msdk/tracker/e;->h()I

    move-result v0

    const/4 v2, 0x1

    if-ne v0, v2, :cond_c

    return v2

    :cond_32
    return v1
.end method

.method public static b(Landroid/database/Cursor;)Ljava/util/List;
    .registers 20
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/database/Cursor;",
            ")",
            "Ljava/util/List<",
            "Lcom/mbridge/msdk/tracker/i;",
            ">;"
        }
    .end annotation

    .prologue
    move-object/from16 v1, p0

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    :try_start_7
    const-string v0, "name"

    invoke-interface {v1, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v3

    const-string v0, "type"

    invoke-interface {v1, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v4

    const-string v0, "time_stamp"

    invoke-interface {v1, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v5

    const-string v0, "properties"

    invoke-interface {v1, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v6

    const-string v0, "priority"

    invoke-interface {v1, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v7

    const-string v0, "uuid"

    invoke-interface {v1, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v8

    const-string v0, "duration"

    invoke-interface {v1, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v9

    const-string v0, "state"

    invoke-interface {v1, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v10

    const-string v0, "report_count"

    invoke-interface {v1, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v11

    const-string v0, "ignore_max_timeout"

    invoke-interface {v1, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v12

    const-string v0, "ignore_max_retry_times"

    invoke-interface {v1, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v13

    const-string v0, "invalid_time"

    invoke-interface {v1, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v14

    const-string v0, "report_error_message"

    invoke-interface {v1, v0}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v15
    :try_end_55
    .catch Ljava/lang/Exception; {:try_start_7 .. :try_end_55} :catch_106

    :goto_55
    invoke-interface {v1}, Landroid/database/Cursor;->moveToNext()Z

    move-result v0

    if-eqz v0, :cond_106

    :try_start_5b
    invoke-interface {v1, v3}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0
    :try_end_5f
    .catch Lorg/json/JSONException; {:try_start_5b .. :try_end_5f} :catch_f6

    move/from16 v16, v3

    :try_start_61
    new-instance v3, Lcom/mbridge/msdk/tracker/e;

    invoke-direct {v3, v0}, Lcom/mbridge/msdk/tracker/e;-><init>(Ljava/lang/String;)V

    invoke-interface {v1, v4}, Landroid/database/Cursor;->getInt(I)I

    move-result v0

    invoke-virtual {v3, v0}, Lcom/mbridge/msdk/tracker/e;->b(I)V
    :try_end_6d
    .catch Lorg/json/JSONException; {:try_start_61 .. :try_end_6d} :catch_f2

    move/from16 v17, v14

    move/from16 v18, v15

    :try_start_71
    invoke-interface {v1, v5}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v14

    invoke-virtual {v3, v14, v15}, Lcom/mbridge/msdk/tracker/e;->c(J)V

    invoke-interface {v1, v6}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0

    new-instance v14, Lorg/json/JSONObject;

    invoke-direct {v14, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v14}, Lcom/mbridge/msdk/tracker/e;->a(Lorg/json/JSONObject;)V

    invoke-interface {v1, v7}, Landroid/database/Cursor;->getInt(I)I

    move-result v0

    invoke-virtual {v3, v0}, Lcom/mbridge/msdk/tracker/e;->a(I)V

    invoke-interface {v1, v8}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Lcom/mbridge/msdk/tracker/e;->a(Ljava/lang/String;)V

    invoke-interface {v1, v9}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v14

    invoke-virtual {v3, v14, v15}, Lcom/mbridge/msdk/tracker/e;->a(J)V

    new-instance v0, Lcom/mbridge/msdk/tracker/i;

    invoke-direct {v0, v3}, Lcom/mbridge/msdk/tracker/i;-><init>(Lcom/mbridge/msdk/tracker/e;)V

    invoke-interface {v1, v10}, Landroid/database/Cursor;->getInt(I)I

    move-result v3

    invoke-virtual {v0, v3}, Lcom/mbridge/msdk/tracker/i;->b(I)V

    invoke-interface {v1, v11}, Landroid/database/Cursor;->getInt(I)I

    move-result v3

    invoke-virtual {v0, v3}, Lcom/mbridge/msdk/tracker/i;->a(I)V

    invoke-interface {v1, v12}, Landroid/database/Cursor;->getInt(I)I

    move-result v3

    const/4 v14, 0x0

    const/4 v15, 0x1

    if-nez v3, :cond_b6

    move v3, v15

    goto :goto_b7

    :cond_b6
    move v3, v14

    :goto_b7
    invoke-virtual {v0, v3}, Lcom/mbridge/msdk/tracker/i;->b(Z)V

    invoke-interface {v1, v13}, Landroid/database/Cursor;->getInt(I)I

    move-result v3

    if-nez v3, :cond_c1

    move v14, v15

    :cond_c1
    invoke-virtual {v0, v14}, Lcom/mbridge/msdk/tracker/i;->a(Z)V
    :try_end_c4
    .catch Lorg/json/JSONException; {:try_start_71 .. :try_end_c4} :catch_ee

    move/from16 v3, v17

    :try_start_c6
    invoke-interface {v1, v3}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v14

    invoke-virtual {v0, v14, v15}, Lcom/mbridge/msdk/tracker/i;->a(J)V
    :try_end_cd
    .catch Lorg/json/JSONException; {:try_start_c6 .. :try_end_cd} :catch_ea

    move/from16 v14, v18

    :try_start_cf
    invoke-interface {v1, v14}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v15

    invoke-static {v15}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v17

    if-eqz v17, :cond_de

    const-string v15, ""

    goto :goto_de

    :catch_dc
    move-exception v0

    goto :goto_fa

    :cond_de
    :goto_de
    invoke-virtual {v0, v15}, Lcom/mbridge/msdk/tracker/i;->a(Ljava/lang/String;)V

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_e4
    .catch Lorg/json/JSONException; {:try_start_cf .. :try_end_e4} :catch_dc

    :goto_e4
    move v15, v14

    move v14, v3

    move/from16 v3, v16

    goto/16 :goto_55

    :catch_ea
    move-exception v0

    :goto_eb
    move/from16 v14, v18

    goto :goto_fa

    :catch_ee
    move-exception v0

    move/from16 v3, v17

    goto :goto_eb

    :catch_f2
    move-exception v0

    :goto_f3
    move v3, v14

    move v14, v15

    goto :goto_fa

    :catch_f6
    move-exception v0

    move/from16 v16, v3

    goto :goto_f3

    :goto_fa
    sget-boolean v15, Lcom/mbridge/msdk/tracker/a;->a:Z

    if-eqz v15, :cond_103

    const-string v15, "TrackManager"

    const-string v1, "create: "

    nop

    :cond_103
    move-object/from16 v1, p0

    goto :goto_e4

    :catch_106
    :cond_106
    return-object v2
.end method

.method public static b(Ljava/lang/Object;)Z
    .registers 1

    .prologue
    if-nez p0, :cond_4

    const/4 p0, 0x1

    return p0

    :cond_4
    const/4 p0, 0x0

    return p0
.end method

.method public static b(Ljava/util/List;)Z
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "*>;)Z"
        }
    .end annotation

    .prologue
    if-eqz p0, :cond_b

    invoke-interface {p0}, Ljava/util/List;->isEmpty()Z

    move-result p0

    if-eqz p0, :cond_9

    goto :goto_b

    :cond_9
    const/4 p0, 0x0

    return p0

    :cond_b
    :goto_b
    const/4 p0, 0x1

    return p0
.end method
