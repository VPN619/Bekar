.class interface abstract Lcom/mbridge/msdk/tracker/r;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# virtual methods
.method public abstract a(Lcom/mbridge/msdk/tracker/t;)V
.end method

.method public abstract a(Lcom/mbridge/msdk/tracker/t;ILjava/lang/String;)V
.end method
