.class Lcom/mbridge/msdk/tracker/o;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/mbridge/msdk/tracker/o$c;,
        Lcom/mbridge/msdk/tracker/o$b;
    }
.end annotation


# instance fields
.field private a:Lcom/mbridge/msdk/tracker/r;

.field private final b:I

.field private final c:Lcom/mbridge/msdk/tracker/p;

.field private final d:Lcom/mbridge/msdk/tracker/w;

.field private final e:I

.field private f:Lcom/mbridge/msdk/tracker/network/u;

.field private final g:Ljava/util/concurrent/Executor;


# direct methods
.method public constructor <init>(ILcom/mbridge/msdk/tracker/p;Lcom/mbridge/msdk/tracker/w;I)V
    .registers 14

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/mbridge/msdk/tracker/o;->b:I

    iput-object p2, p0, Lcom/mbridge/msdk/tracker/o;->c:Lcom/mbridge/msdk/tracker/p;

    iput-object p3, p0, Lcom/mbridge/msdk/tracker/o;->d:Lcom/mbridge/msdk/tracker/w;

    iput p4, p0, Lcom/mbridge/msdk/tracker/o;->e:I

    new-instance v0, Ljava/util/concurrent/ThreadPoolExecutor;

    new-instance v6, Ljava/util/concurrent/LinkedBlockingQueue;

    invoke-direct {v6}, Ljava/util/concurrent/LinkedBlockingQueue;-><init>()V

    new-instance v7, Lcom/mbridge/msdk/tracker/o$a;

    invoke-direct {v7, p0}, Lcom/mbridge/msdk/tracker/o$a;-><init>(Lcom/mbridge/msdk/tracker/o;)V

    new-instance v8, Ljava/util/concurrent/ThreadPoolExecutor$DiscardPolicy;

    invoke-direct {v8}, Ljava/util/concurrent/ThreadPoolExecutor$DiscardPolicy;-><init>()V

    const-wide/16 v3, 0x14

    sget-object v5, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    move v2, p1

    move v1, p1

    invoke-direct/range {v0 .. v8}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;Ljava/util/concurrent/RejectedExecutionHandler;)V

    iput-object v0, p0, Lcom/mbridge/msdk/tracker/o;->g:Ljava/util/concurrent/Executor;

    return-void
.end method

.method private a(Lcom/mbridge/msdk/tracker/t;Ljava/util/Map;Z)Lcom/mbridge/msdk/tracker/v;
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/mbridge/msdk/tracker/t;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;Z)",
            "Lcom/mbridge/msdk/tracker/v<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    .prologue
    iget v0, p0, Lcom/mbridge/msdk/tracker/o;->e:I

    iget-object v1, p0, Lcom/mbridge/msdk/tracker/o;->c:Lcom/mbridge/msdk/tracker/p;

    const/4 v2, 0x1

    if-ne v0, v2, :cond_17

    new-instance v0, Lcom/mbridge/msdk/tracker/v;

    invoke-virtual {v1}, Lcom/mbridge/msdk/tracker/p;->c()Ljava/lang/String;

    move-result-object v1

    iget-object v3, p0, Lcom/mbridge/msdk/tracker/o;->c:Lcom/mbridge/msdk/tracker/p;

    invoke-virtual {v3}, Lcom/mbridge/msdk/tracker/p;->a()I

    move-result v3

    invoke-direct {v0, v1, v2, v3}, Lcom/mbridge/msdk/tracker/v;-><init>(Ljava/lang/String;II)V

    goto :goto_20

    :cond_17
    new-instance v0, Lcom/mbridge/msdk/tracker/v;

    invoke-virtual {v1}, Lcom/mbridge/msdk/tracker/p;->c()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1, v2}, Lcom/mbridge/msdk/tracker/v;-><init>(Ljava/lang/String;I)V

    :goto_20
    invoke-virtual {v0, p2}, Lcom/mbridge/msdk/tracker/v;->a(Ljava/util/Map;)V

    const/4 p2, 0x0

    invoke-virtual {v0, p2}, Lcom/mbridge/msdk/tracker/network/t;->a(Z)Lcom/mbridge/msdk/tracker/network/t;

    invoke-virtual {v0, v2}, Lcom/mbridge/msdk/tracker/network/t;->c(Z)Lcom/mbridge/msdk/tracker/network/t;

    invoke-virtual {v0, v2}, Lcom/mbridge/msdk/tracker/network/t;->b(Z)Lcom/mbridge/msdk/tracker/network/t;

    iget-object p2, p0, Lcom/mbridge/msdk/tracker/o;->d:Lcom/mbridge/msdk/tracker/w;

    invoke-virtual {v0, p2}, Lcom/mbridge/msdk/tracker/v;->a(Lcom/mbridge/msdk/tracker/w;)V

    if-eqz p3, :cond_37

    sget-object p2, Lcom/mbridge/msdk/tracker/network/t$a;->c:Lcom/mbridge/msdk/tracker/network/t$a;

    goto :goto_39

    :cond_37
    sget-object p2, Lcom/mbridge/msdk/tracker/network/t$a;->b:Lcom/mbridge/msdk/tracker/network/t$a;

    :goto_39
    invoke-virtual {v0, p2}, Lcom/mbridge/msdk/tracker/v;->a(Lcom/mbridge/msdk/tracker/network/t$a;)V

    new-instance p2, Lcom/mbridge/msdk/tracker/o$c;

    iget-object p3, p0, Lcom/mbridge/msdk/tracker/o;->a:Lcom/mbridge/msdk/tracker/r;

    invoke-direct {p2, p3, p1}, Lcom/mbridge/msdk/tracker/o$c;-><init>(Lcom/mbridge/msdk/tracker/r;Lcom/mbridge/msdk/tracker/t;)V

    invoke-virtual {v0, p2}, Lcom/mbridge/msdk/tracker/v;->a(Lcom/mbridge/msdk/tracker/network/v$b;)V

    new-instance p2, Lcom/mbridge/msdk/tracker/o$b;

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/o;->a:Lcom/mbridge/msdk/tracker/r;

    invoke-direct {p2, p0, p1}, Lcom/mbridge/msdk/tracker/o$b;-><init>(Lcom/mbridge/msdk/tracker/r;Lcom/mbridge/msdk/tracker/t;)V

    invoke-virtual {v0, p2}, Lcom/mbridge/msdk/tracker/network/t;->a(Lcom/mbridge/msdk/tracker/network/v$a;)V

    return-object v0
.end method

.method private a()V
    .registers 5

    .prologue
    iget-object v0, p0, Lcom/mbridge/msdk/tracker/o;->f:Lcom/mbridge/msdk/tracker/network/u;

    invoke-static {v0}, Lcom/mbridge/msdk/tracker/y;->a(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_9

    return-void

    :cond_9
    new-instance v0, Lcom/mbridge/msdk/tracker/network/toolbox/b;

    iget-object v1, p0, Lcom/mbridge/msdk/tracker/o;->c:Lcom/mbridge/msdk/tracker/p;

    invoke-virtual {v1}, Lcom/mbridge/msdk/tracker/p;->b()Lcom/mbridge/msdk/tracker/network/toolbox/a;

    move-result-object v1

    invoke-direct {v0, v1}, Lcom/mbridge/msdk/tracker/network/toolbox/b;-><init>(Lcom/mbridge/msdk/tracker/network/toolbox/a;)V

    new-instance v1, Lcom/mbridge/msdk/tracker/network/f;

    iget-object v2, p0, Lcom/mbridge/msdk/tracker/o;->g:Ljava/util/concurrent/Executor;

    invoke-direct {v1, v2}, Lcom/mbridge/msdk/tracker/network/f;-><init>(Ljava/util/concurrent/Executor;)V

    iget v2, p0, Lcom/mbridge/msdk/tracker/o;->b:I

    const/4 v3, 0x0

    invoke-static {v0, v1, v2, v3}, Lcom/mbridge/msdk/tracker/network/toolbox/o;->a(Lcom/mbridge/msdk/tracker/network/m;Lcom/mbridge/msdk/tracker/network/w;ILcom/mbridge/msdk/tracker/network/b;)Lcom/mbridge/msdk/tracker/network/u;

    move-result-object v0

    iput-object v0, p0, Lcom/mbridge/msdk/tracker/o;->f:Lcom/mbridge/msdk/tracker/network/u;

    invoke-virtual {v0}, Lcom/mbridge/msdk/tracker/network/u;->b()V

    return-void
.end method


# virtual methods
.method public a(Lcom/mbridge/msdk/tracker/r;)V
    .registers 2

    iput-object p1, p0, Lcom/mbridge/msdk/tracker/o;->a:Lcom/mbridge/msdk/tracker/r;

    return-void
.end method

.method public b(Lcom/mbridge/msdk/tracker/t;Ljava/util/Map;Z)V
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/mbridge/msdk/tracker/t;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;Z)V"
        }
    .end annotation

    .prologue
    invoke-static {p2}, Lcom/mbridge/msdk/tracker/y;->b(Ljava/lang/Object;)Z

    move-result v0

    const-string v1, "send error"

    const-string v2, "TrackManager"

    const/4 v3, 0x0

    if-eqz v0, :cond_1c

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/o;->a:Lcom/mbridge/msdk/tracker/r;

    if-eqz p0, :cond_40

    :try_start_f
    const-string p2, "params is null"

    invoke-interface {p0, p1, v3, p2}, Lcom/mbridge/msdk/tracker/r;->a(Lcom/mbridge/msdk/tracker/t;ILjava/lang/String;)V
    :try_end_14
    .catch Ljava/lang/Exception; {:try_start_f .. :try_end_14} :catch_15

    return-void

    :catch_15
    move-exception p0

    sget-boolean p1, Lcom/mbridge/msdk/tracker/a;->a:Z

    if-eqz p1, :cond_40

    nop

    goto :goto_40

    :cond_1c
    :try_start_1c
    invoke-direct {p0}, Lcom/mbridge/msdk/tracker/o;->a()V

    invoke-direct {p0, p1, p2, p3}, Lcom/mbridge/msdk/tracker/o;->a(Lcom/mbridge/msdk/tracker/t;Ljava/util/Map;Z)Lcom/mbridge/msdk/tracker/v;

    move-result-object p2

    iget-object p3, p0, Lcom/mbridge/msdk/tracker/o;->f:Lcom/mbridge/msdk/tracker/network/u;

    invoke-virtual {p3, p2}, Lcom/mbridge/msdk/tracker/network/u;->a(Lcom/mbridge/msdk/tracker/network/t;)Lcom/mbridge/msdk/tracker/network/t;
    :try_end_28
    .catch Ljava/lang/Exception; {:try_start_1c .. :try_end_28} :catch_29

    return-void

    :catch_29
    move-exception p2

    sget-boolean p3, Lcom/mbridge/msdk/tracker/a;->a:Z

    if-eqz p3, :cond_2f

    nop

    :cond_2f
    iget-object p3, p0, Lcom/mbridge/msdk/tracker/o;->a:Lcom/mbridge/msdk/tracker/r;

    invoke-static {p3}, Lcom/mbridge/msdk/tracker/y;->a(Ljava/lang/Object;)Z

    move-result p3

    if-eqz p3, :cond_40

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/o;->a:Lcom/mbridge/msdk/tracker/r;

    invoke-virtual {p2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p2

    invoke-interface {p0, p1, v3, p2}, Lcom/mbridge/msdk/tracker/r;->a(Lcom/mbridge/msdk/tracker/t;ILjava/lang/String;)V

    :cond_40
    :goto_40
    return-void
.end method
