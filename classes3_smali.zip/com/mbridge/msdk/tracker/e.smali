.class public Lcom/mbridge/msdk/tracker/e;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ljava/io/Serializable;


# instance fields
.field private a:Ljava/lang/String;

.field private b:I

.field private c:I

.field private d:Lorg/json/JSONObject;

.field private e:Ljava/lang/String;

.field private f:J

.field private g:J

.field private h:J

.field private i:Lcom/mbridge/msdk/tracker/h;

.field private j:Z

.field private k:Z


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Lcom/mbridge/msdk/tracker/e;->b:I

    iput v0, p0, Lcom/mbridge/msdk/tracker/e;->c:I

    const-wide/16 v1, 0x0

    iput-wide v1, p0, Lcom/mbridge/msdk/tracker/e;->g:J

    const-wide/32 v1, 0x240c8400

    iput-wide v1, p0, Lcom/mbridge/msdk/tracker/e;->h:J

    iput-boolean v0, p0, Lcom/mbridge/msdk/tracker/e;->j:Z

    iput-boolean v0, p0, Lcom/mbridge/msdk/tracker/e;->k:Z

    iput-object p1, p0, Lcom/mbridge/msdk/tracker/e;->a:Ljava/lang/String;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    iput-wide v0, p0, Lcom/mbridge/msdk/tracker/e;->f:J

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lcom/mbridge/msdk/tracker/e;->e:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public a(I)V
    .registers 2

    iput p1, p0, Lcom/mbridge/msdk/tracker/e;->c:I

    return-void
.end method

.method public a(J)V
    .registers 3

    iput-wide p1, p0, Lcom/mbridge/msdk/tracker/e;->g:J

    return-void
.end method

.method public a(Lcom/mbridge/msdk/tracker/h;)V
    .registers 2

    iput-object p1, p0, Lcom/mbridge/msdk/tracker/e;->i:Lcom/mbridge/msdk/tracker/h;

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lcom/mbridge/msdk/tracker/e;->e:Ljava/lang/String;

    return-void
.end method

.method public a(Lorg/json/JSONObject;)V
    .registers 2

    iput-object p1, p0, Lcom/mbridge/msdk/tracker/e;->d:Lorg/json/JSONObject;

    return-void
.end method

.method public a(Z)V
    .registers 2

    iput-boolean p1, p0, Lcom/mbridge/msdk/tracker/e;->k:Z

    return-void
.end method

.method public b(I)V
    .registers 2

    iput p1, p0, Lcom/mbridge/msdk/tracker/e;->b:I

    return-void
.end method

.method public b(J)V
    .registers 3

    iput-wide p1, p0, Lcom/mbridge/msdk/tracker/e;->h:J

    return-void
.end method

.method public c(J)V
    .registers 3

    iput-wide p1, p0, Lcom/mbridge/msdk/tracker/e;->f:J

    return-void
.end method

.method public d()J
    .registers 3

    iget-wide v0, p0, Lcom/mbridge/msdk/tracker/e;->g:J

    return-wide v0
.end method

.method public g()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/e;->a:Ljava/lang/String;

    return-object p0
.end method

.method public h()I
    .registers 1

    iget p0, p0, Lcom/mbridge/msdk/tracker/e;->c:I

    return p0
.end method

.method public i()Lorg/json/JSONObject;
    .registers 2

    .prologue
    iget-object v0, p0, Lcom/mbridge/msdk/tracker/e;->d:Lorg/json/JSONObject;

    if-nez v0, :cond_b

    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    iput-object v0, p0, Lcom/mbridge/msdk/tracker/e;->d:Lorg/json/JSONObject;

    :cond_b
    return-object v0
.end method

.method public j()Lcom/mbridge/msdk/tracker/h;
    .registers 1

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/e;->i:Lcom/mbridge/msdk/tracker/h;

    return-object p0
.end method

.method public k()J
    .registers 3

    iget-wide v0, p0, Lcom/mbridge/msdk/tracker/e;->h:J

    return-wide v0
.end method

.method public l()J
    .registers 3

    iget-wide v0, p0, Lcom/mbridge/msdk/tracker/e;->f:J

    return-wide v0
.end method

.method public m()I
    .registers 1

    iget p0, p0, Lcom/mbridge/msdk/tracker/e;->b:I

    return p0
.end method

.method public n()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lcom/mbridge/msdk/tracker/e;->e:Ljava/lang/String;

    return-object p0
.end method

.method public o()Z
    .registers 1

    iget-boolean p0, p0, Lcom/mbridge/msdk/tracker/e;->k:Z

    return p0
.end method

.method public p()Z
    .registers 1

    iget-boolean p0, p0, Lcom/mbridge/msdk/tracker/e;->j:Z

    return p0
.end method
