.class public Lcom/mbridge/msdk/foundation/same/net/utils/a;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# direct methods
.method public static a(Lcom/mbridge/msdk/foundation/same/net/exception/a;)Ljava/lang/String;
    .registers 6

    .prologue
    const-string v0, "Network error,please check state code "

    const-string v1, "The server returns an exception state code "

    if-nez p0, :cond_8

    goto/16 :goto_8a

    :cond_8
    :try_start_8
    iget v2, p0, Lcom/mbridge/msdk/foundation/same/net/exception/a;->a:I

    iget-object p0, p0, Lcom/mbridge/msdk/foundation/same/net/exception/a;->c:Lcom/mbridge/msdk/foundation/same/net/toolbox/a;

    if-eqz p0, :cond_11

    iget v3, p0, Lcom/mbridge/msdk/foundation/same/net/toolbox/a;->d:I

    goto :goto_12

    :cond_11
    const/4 v3, 0x0

    :goto_12
    const/4 v4, -0x2

    if-eq v2, v4, :cond_83

    const/16 v4, 0xf

    if-eq v2, v4, :cond_80

    const v4, 0xd6d97

    if-eq v2, v4, :cond_7d

    const v4, 0xd6da9

    if-eq v2, v4, :cond_7a

    packed-switch v2, :pswitch_data_8e

    packed-switch v2, :pswitch_data_a2

    const-string p0, "Network error,unknown"

    return-object p0

    :pswitch_2c  #0xd
    if-eqz p0, :cond_3b

    iget-object p0, p0, Lcom/mbridge/msdk/foundation/same/net/toolbox/a;->a:[B

    if-eqz p0, :cond_38

    new-instance v0, Ljava/lang/String;

    invoke-direct {v0, p0}, Ljava/lang/String;-><init>([B)V

    return-object v0

    :cond_38
    const-string p0, "Socket exception message is NULL"

    return-object p0

    :cond_3b
    const-string p0, "Unknown socket exception"

    return-object p0

    :pswitch_3e  #0xc
    const-string p0, "Network error,ConnectException"

    return-object p0

    :pswitch_41  #0xb
    const-string p0, "Network error，sslp exception"

    return-object p0

    :pswitch_44  #0xa
    const-string p0, "Network error,socket timeout exception"

    return-object p0

    :pswitch_47  #0x8
    const-string p0, "Cast exception, return data can not be casted correctly"

    return-object p0

    :pswitch_4a  #0x7
    if-eqz v3, :cond_59

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_59
    const-string p0, "The server returns an exception "

    return-object p0

    :pswitch_5c  #0x6
    if-eqz v3, :cond_6b

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_6b
    const-string p0, "Network error,please check "

    return-object p0

    :pswitch_6e  #0x5
    const-string p0, "Network error，https is not work,please check your phone time"

    return-object p0

    :pswitch_71  #0x4
    const-string p0, "Network unknown error"

    return-object p0

    :pswitch_74  #0x3
    const-string p0, "Network error,timeout exception"

    return-object p0

    :pswitch_77  #0x2
    const-string p0, "Network error,I/O exception"

    return-object p0

    :cond_7a
    const-string p0, "Network error,UnknownHostException"

    return-object p0

    :cond_7d
    const-string p0, "timeout"

    return-object p0

    :cond_80
    const-string p0, "Network error,I/O exception contents null"

    return-object p0

    :cond_83
    const-string p0, "Network is canceled"
    :try_end_85
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_85} :catch_86

    return-object p0

    :catch_86
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_8a
    :pswitch_8a  #0x1
    const-string p0, "Network error,Load failed"

    return-object p0

    nop

    :pswitch_data_8e
    .packed-switch 0x1
        :pswitch_8a  #00000001
        :pswitch_77  #00000002
        :pswitch_74  #00000003
        :pswitch_71  #00000004
        :pswitch_6e  #00000005
        :pswitch_5c  #00000006
        :pswitch_4a  #00000007
        :pswitch_47  #00000008
    .end packed-switch

    :pswitch_data_a2
    .packed-switch 0xa
        :pswitch_44  #0000000a
        :pswitch_41  #0000000b
        :pswitch_3e  #0000000c
        :pswitch_2c  #0000000d
    .end packed-switch
.end method
