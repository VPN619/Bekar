.class final Lcom/mbridge/msdk/thrid/okio/l$b;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lcom/mbridge/msdk/thrid/okio/s;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/mbridge/msdk/thrid/okio/l;->a(Ljava/io/InputStream;Lcom/mbridge/msdk/thrid/okio/t;)Lcom/mbridge/msdk/thrid/okio/s;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/mbridge/msdk/thrid/okio/t;

.field final synthetic b:Ljava/io/InputStream;


# direct methods
.method public constructor <init>(Lcom/mbridge/msdk/thrid/okio/t;Ljava/io/InputStream;)V
    .registers 3

    iput-object p1, p0, Lcom/mbridge/msdk/thrid/okio/l$b;->a:Lcom/mbridge/msdk/thrid/okio/t;

    iput-object p2, p0, Lcom/mbridge/msdk/thrid/okio/l$b;->b:Ljava/io/InputStream;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public b(Lcom/mbridge/msdk/thrid/okio/c;J)J
    .registers 7

    .prologue
    const-wide/16 v0, 0x0

    cmp-long v2, p2, v0

    if-ltz v2, :cond_47

    if-nez v2, :cond_9

    return-wide v0

    :cond_9
    :try_start_9
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okio/l$b;->a:Lcom/mbridge/msdk/thrid/okio/t;

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okio/t;->e()V

    const/4 v0, 0x1

    invoke-virtual {p1, v0}, Lcom/mbridge/msdk/thrid/okio/c;->b(I)Lcom/mbridge/msdk/thrid/okio/o;

    move-result-object v0

    iget v1, v0, Lcom/mbridge/msdk/thrid/okio/o;->c:I

    rsub-int v1, v1, 0x2000

    int-to-long v1, v1

    invoke-static {p2, p3, v1, v2}, Ljava/lang/Math;->min(JJ)J

    move-result-wide p2

    long-to-int p2, p2

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okio/l$b;->b:Ljava/io/InputStream;

    iget-object p3, v0, Lcom/mbridge/msdk/thrid/okio/o;->a:[B

    iget v1, v0, Lcom/mbridge/msdk/thrid/okio/o;->c:I

    invoke-virtual {p0, p3, v1, p2}, Ljava/io/InputStream;->read([BII)I

    move-result p0

    const/4 p2, -0x1

    if-ne p0, p2, :cond_2d

    const-wide/16 p0, -0x1

    return-wide p0

    :cond_2d
    iget p2, v0, Lcom/mbridge/msdk/thrid/okio/o;->c:I

    add-int/2addr p2, p0

    iput p2, v0, Lcom/mbridge/msdk/thrid/okio/o;->c:I

    iget-wide p2, p1, Lcom/mbridge/msdk/thrid/okio/c;->b:J

    int-to-long v0, p0

    add-long/2addr p2, v0

    iput-wide p2, p1, Lcom/mbridge/msdk/thrid/okio/c;->b:J
    :try_end_38
    .catch Ljava/lang/AssertionError; {:try_start_9 .. :try_end_38} :catch_39

    return-wide v0

    :catch_39
    move-exception p0

    invoke-static {p0}, Lcom/mbridge/msdk/thrid/okio/l;->a(Ljava/lang/AssertionError;)Z

    move-result p1

    if-eqz p1, :cond_46

    new-instance p1, Ljava/io/IOException;

    invoke-direct {p1, p0}, Ljava/io/IOException;-><init>(Ljava/lang/Throwable;)V

    throw p1

    :cond_46
    throw p0

    :cond_47
    const-string p0, "byteCount < 0: "

    invoke-static {p2, p3, p0}, Lmz2;->j(JLjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->s(Ljava/lang/String;)V

    return-wide v0
.end method

.method public b()Lcom/mbridge/msdk/thrid/okio/t;
    .registers 1

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okio/l$b;->a:Lcom/mbridge/msdk/thrid/okio/t;

    return-object p0
.end method

.method public close()V
    .registers 1

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okio/l$b;->b:Ljava/io/InputStream;

    invoke-virtual {p0}, Ljava/io/InputStream;->close()V

    return-void
.end method

.method public toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "source("

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okio/l$b;->b:Ljava/io/InputStream;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
