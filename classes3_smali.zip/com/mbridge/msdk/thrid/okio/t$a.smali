.class final Lcom/mbridge/msdk/thrid/okio/t$a;
.super Lcom/mbridge/msdk/thrid/okio/t;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/mbridge/msdk/thrid/okio/t;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lcom/mbridge/msdk/thrid/okio/t;-><init>()V

    return-void
.end method


# virtual methods
.method public a(J)Lcom/mbridge/msdk/thrid/okio/t;
    .registers 3

    return-object p0
.end method

.method public a(JLjava/util/concurrent/TimeUnit;)Lcom/mbridge/msdk/thrid/okio/t;
    .registers 4

    return-object p0
.end method

.method public e()V
    .registers 1

    return-void
.end method
