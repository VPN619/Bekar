.class public interface abstract Lcom/mbridge/msdk/thrid/okio/d;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lcom/mbridge/msdk/thrid/okio/r;
.implements Ljava/nio/channels/WritableByteChannel;


# virtual methods
.method public abstract a()Lcom/mbridge/msdk/thrid/okio/c;
.end method

.method public abstract a(J)Lcom/mbridge/msdk/thrid/okio/d;
.end method

.method public abstract a(Ljava/lang/String;)Lcom/mbridge/msdk/thrid/okio/d;
.end method

.method public abstract flush()V
.end method

.method public abstract write([B)Lcom/mbridge/msdk/thrid/okio/d;
.end method

.method public abstract write([BII)Lcom/mbridge/msdk/thrid/okio/d;
.end method

.method public abstract writeByte(I)Lcom/mbridge/msdk/thrid/okio/d;
.end method

.method public abstract writeInt(I)Lcom/mbridge/msdk/thrid/okio/d;
.end method

.method public abstract writeShort(I)Lcom/mbridge/msdk/thrid/okio/d;
.end method
