.class final Lcom/mbridge/msdk/thrid/okio/p;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field static a:Lcom/mbridge/msdk/thrid/okio/o;
    .annotation build Landroidx/annotation/Nullable;
    .end annotation
.end field

.field static b:J


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a()Lcom/mbridge/msdk/thrid/okio/o;
    .registers 6

    .prologue
    const-class v0, Lcom/mbridge/msdk/thrid/okio/p;

    monitor-enter v0

    :try_start_3
    sget-object v1, Lcom/mbridge/msdk/thrid/okio/p;->a:Lcom/mbridge/msdk/thrid/okio/o;

    if-eqz v1, :cond_19

    iget-object v2, v1, Lcom/mbridge/msdk/thrid/okio/o;->f:Lcom/mbridge/msdk/thrid/okio/o;

    sput-object v2, Lcom/mbridge/msdk/thrid/okio/p;->a:Lcom/mbridge/msdk/thrid/okio/o;

    const/4 v2, 0x0

    iput-object v2, v1, Lcom/mbridge/msdk/thrid/okio/o;->f:Lcom/mbridge/msdk/thrid/okio/o;

    sget-wide v2, Lcom/mbridge/msdk/thrid/okio/p;->b:J

    const-wide/16 v4, 0x2000

    sub-long/2addr v2, v4

    sput-wide v2, Lcom/mbridge/msdk/thrid/okio/p;->b:J

    monitor-exit v0

    return-object v1

    :catchall_17
    move-exception v1

    goto :goto_20

    :cond_19
    monitor-exit v0
    :try_end_1a
    .catchall {:try_start_3 .. :try_end_1a} :catchall_17

    new-instance v0, Lcom/mbridge/msdk/thrid/okio/o;

    invoke-direct {v0}, Lcom/mbridge/msdk/thrid/okio/o;-><init>()V

    return-object v0

    :goto_20
    :try_start_20
    monitor-exit v0
    :try_end_21
    .catchall {:try_start_20 .. :try_end_21} :catchall_17

    throw v1
.end method

.method public static a(Lcom/mbridge/msdk/thrid/okio/o;)V
    .registers 6

    .prologue
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okio/o;->f:Lcom/mbridge/msdk/thrid/okio/o;

    if-nez v0, :cond_31

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okio/o;->g:Lcom/mbridge/msdk/thrid/okio/o;

    if-nez v0, :cond_31

    iget-boolean v0, p0, Lcom/mbridge/msdk/thrid/okio/o;->d:Z

    if-eqz v0, :cond_d

    return-void

    :cond_d
    const-class v0, Lcom/mbridge/msdk/thrid/okio/p;

    monitor-enter v0

    :try_start_10
    sget-wide v1, Lcom/mbridge/msdk/thrid/okio/p;->b:J

    const-wide/16 v3, 0x2000

    add-long/2addr v1, v3

    const-wide/32 v3, 0x10000

    cmp-long v3, v1, v3

    if-lez v3, :cond_20

    monitor-exit v0

    return-void

    :catchall_1e
    move-exception p0

    goto :goto_2f

    :cond_20
    sput-wide v1, Lcom/mbridge/msdk/thrid/okio/p;->b:J

    sget-object v1, Lcom/mbridge/msdk/thrid/okio/p;->a:Lcom/mbridge/msdk/thrid/okio/o;

    iput-object v1, p0, Lcom/mbridge/msdk/thrid/okio/o;->f:Lcom/mbridge/msdk/thrid/okio/o;

    const/4 v1, 0x0

    iput v1, p0, Lcom/mbridge/msdk/thrid/okio/o;->c:I

    iput v1, p0, Lcom/mbridge/msdk/thrid/okio/o;->b:I

    sput-object p0, Lcom/mbridge/msdk/thrid/okio/p;->a:Lcom/mbridge/msdk/thrid/okio/o;

    monitor-exit v0

    return-void

    :goto_2f
    monitor-exit v0
    :try_end_30
    .catchall {:try_start_10 .. :try_end_30} :catchall_1e

    throw p0

    :cond_31
    invoke-static {}, Lpw1;->h()V

    return-void
.end method
