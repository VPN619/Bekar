.class public interface abstract Lcom/mbridge/msdk/thrid/okio/r;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ljava/io/Closeable;
.implements Ljava/io/Flushable;


# virtual methods
.method public abstract a(Lcom/mbridge/msdk/thrid/okio/c;J)V
.end method

.method public abstract b()Lcom/mbridge/msdk/thrid/okio/t;
.end method

.method public abstract close()V
.end method

.method public abstract flush()V
.end method
