.class public interface abstract Lcom/mbridge/msdk/thrid/okio/s;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ljava/io/Closeable;


# virtual methods
.method public abstract b(Lcom/mbridge/msdk/thrid/okio/c;J)J
.end method

.method public abstract b()Lcom/mbridge/msdk/thrid/okio/t;
.end method

.method public abstract close()V
.end method
