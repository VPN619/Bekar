.class public final Lcom/mbridge/msdk/thrid/okio/k;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lcom/mbridge/msdk/thrid/okio/s;


# instance fields
.field private final a:Lcom/mbridge/msdk/thrid/okio/e;

.field private final b:Ljava/util/zip/Inflater;

.field private c:I

.field private d:Z


# direct methods
.method public constructor <init>(Lcom/mbridge/msdk/thrid/okio/e;Ljava/util/zip/Inflater;)V
    .registers 4

    .prologue
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    if-eqz p1, :cond_13

    if-eqz p2, :cond_d

    iput-object p1, p0, Lcom/mbridge/msdk/thrid/okio/k;->a:Lcom/mbridge/msdk/thrid/okio/e;

    iput-object p2, p0, Lcom/mbridge/msdk/thrid/okio/k;->b:Ljava/util/zip/Inflater;

    return-void

    :cond_d
    const-string p0, "inflater == null"

    invoke-static {p0}, Lz6;->s(Ljava/lang/String;)V

    throw v0

    :cond_13
    const-string p0, "source == null"

    invoke-static {p0}, Lz6;->s(Ljava/lang/String;)V

    throw v0
.end method

.method private h()V
    .registers 3

    .prologue
    iget v0, p0, Lcom/mbridge/msdk/thrid/okio/k;->c:I

    if-nez v0, :cond_5

    return-void

    :cond_5
    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okio/k;->b:Ljava/util/zip/Inflater;

    invoke-virtual {v1}, Ljava/util/zip/Inflater;->getRemaining()I

    move-result v1

    sub-int/2addr v0, v1

    iget v1, p0, Lcom/mbridge/msdk/thrid/okio/k;->c:I

    sub-int/2addr v1, v0

    iput v1, p0, Lcom/mbridge/msdk/thrid/okio/k;->c:I

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okio/k;->a:Lcom/mbridge/msdk/thrid/okio/e;

    int-to-long v0, v0

    invoke-interface {p0, v0, v1}, Lcom/mbridge/msdk/thrid/okio/e;->skip(J)V

    return-void
.end method


# virtual methods
.method public b(Lcom/mbridge/msdk/thrid/okio/c;J)J
    .registers 10

    .prologue
    const-wide/16 v0, 0x0

    cmp-long v2, p2, v0

    if-ltz v2, :cond_76

    iget-boolean v3, p0, Lcom/mbridge/msdk/thrid/okio/k;->d:Z

    if-nez v3, :cond_70

    if-nez v2, :cond_d

    return-wide v0

    :cond_d
    :goto_d
    invoke-virtual {p0}, Lcom/mbridge/msdk/thrid/okio/k;->d()Z

    move-result v0

    const/4 v1, 0x1

    :try_start_12
    invoke-virtual {p1, v1}, Lcom/mbridge/msdk/thrid/okio/c;->b(I)Lcom/mbridge/msdk/thrid/okio/o;

    move-result-object v1

    iget v2, v1, Lcom/mbridge/msdk/thrid/okio/o;->c:I

    rsub-int v2, v2, 0x2000

    int-to-long v2, v2

    invoke-static {p2, p3, v2, v3}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v2

    long-to-int v2, v2

    iget-object v3, p0, Lcom/mbridge/msdk/thrid/okio/k;->b:Ljava/util/zip/Inflater;

    iget-object v4, v1, Lcom/mbridge/msdk/thrid/okio/o;->a:[B

    iget v5, v1, Lcom/mbridge/msdk/thrid/okio/o;->c:I

    invoke-virtual {v3, v4, v5, v2}, Ljava/util/zip/Inflater;->inflate([BII)I

    move-result v2

    if-lez v2, :cond_38

    iget p0, v1, Lcom/mbridge/msdk/thrid/okio/o;->c:I

    add-int/2addr p0, v2

    iput p0, v1, Lcom/mbridge/msdk/thrid/okio/o;->c:I

    iget-wide p2, p1, Lcom/mbridge/msdk/thrid/okio/c;->b:J

    int-to-long v0, v2

    add-long/2addr p2, v0

    iput-wide p2, p1, Lcom/mbridge/msdk/thrid/okio/c;->b:J

    return-wide v0

    :cond_38
    iget-object v2, p0, Lcom/mbridge/msdk/thrid/okio/k;->b:Ljava/util/zip/Inflater;

    invoke-virtual {v2}, Ljava/util/zip/Inflater;->finished()Z

    move-result v2

    if-nez v2, :cond_54

    iget-object v2, p0, Lcom/mbridge/msdk/thrid/okio/k;->b:Ljava/util/zip/Inflater;

    invoke-virtual {v2}, Ljava/util/zip/Inflater;->needsDictionary()Z

    move-result v2

    if-eqz v2, :cond_49

    goto :goto_54

    :cond_49
    if-nez v0, :cond_4c

    goto :goto_d

    :cond_4c
    new-instance p0, Ljava/io/EOFException;

    const-string p1, "source exhausted prematurely"

    invoke-direct {p0, p1}, Ljava/io/EOFException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_54
    :goto_54
    invoke-direct {p0}, Lcom/mbridge/msdk/thrid/okio/k;->h()V

    iget p0, v1, Lcom/mbridge/msdk/thrid/okio/o;->b:I

    iget p2, v1, Lcom/mbridge/msdk/thrid/okio/o;->c:I

    if-ne p0, p2, :cond_66

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okio/o;->b()Lcom/mbridge/msdk/thrid/okio/o;

    move-result-object p0

    iput-object p0, p1, Lcom/mbridge/msdk/thrid/okio/c;->a:Lcom/mbridge/msdk/thrid/okio/o;

    invoke-static {v1}, Lcom/mbridge/msdk/thrid/okio/p;->a(Lcom/mbridge/msdk/thrid/okio/o;)V
    :try_end_66
    .catch Ljava/util/zip/DataFormatException; {:try_start_12 .. :try_end_66} :catch_69

    :cond_66
    const-wide/16 p0, -0x1

    return-wide p0

    :catch_69
    move-exception p0

    new-instance p1, Ljava/io/IOException;

    invoke-direct {p1, p0}, Ljava/io/IOException;-><init>(Ljava/lang/Throwable;)V

    throw p1

    :cond_70
    const-string p0, "closed"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-wide v0

    :cond_76
    const-string p0, "byteCount < 0: "

    invoke-static {p2, p3, p0}, Lmz2;->j(JLjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->s(Ljava/lang/String;)V

    return-wide v0
.end method

.method public b()Lcom/mbridge/msdk/thrid/okio/t;
    .registers 1

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okio/k;->a:Lcom/mbridge/msdk/thrid/okio/e;

    invoke-interface {p0}, Lcom/mbridge/msdk/thrid/okio/s;->b()Lcom/mbridge/msdk/thrid/okio/t;

    move-result-object p0

    return-object p0
.end method

.method public close()V
    .registers 2

    .prologue
    iget-boolean v0, p0, Lcom/mbridge/msdk/thrid/okio/k;->d:Z

    if-eqz v0, :cond_5

    return-void

    :cond_5
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okio/k;->b:Ljava/util/zip/Inflater;

    invoke-virtual {v0}, Ljava/util/zip/Inflater;->end()V

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/mbridge/msdk/thrid/okio/k;->d:Z

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okio/k;->a:Lcom/mbridge/msdk/thrid/okio/e;

    invoke-interface {p0}, Lcom/mbridge/msdk/thrid/okio/s;->close()V

    return-void
.end method

.method public final d()Z
    .registers 5

    .prologue
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okio/k;->b:Ljava/util/zip/Inflater;

    invoke-virtual {v0}, Ljava/util/zip/Inflater;->needsInput()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_a

    return v1

    :cond_a
    invoke-direct {p0}, Lcom/mbridge/msdk/thrid/okio/k;->h()V

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okio/k;->b:Ljava/util/zip/Inflater;

    invoke-virtual {v0}, Ljava/util/zip/Inflater;->getRemaining()I

    move-result v0

    if-nez v0, :cond_36

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okio/k;->a:Lcom/mbridge/msdk/thrid/okio/e;

    invoke-interface {v0}, Lcom/mbridge/msdk/thrid/okio/e;->f()Z

    move-result v0

    if-eqz v0, :cond_1f

    const/4 p0, 0x1

    return p0

    :cond_1f
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okio/k;->a:Lcom/mbridge/msdk/thrid/okio/e;

    invoke-interface {v0}, Lcom/mbridge/msdk/thrid/okio/e;->a()Lcom/mbridge/msdk/thrid/okio/c;

    move-result-object v0

    iget-object v0, v0, Lcom/mbridge/msdk/thrid/okio/c;->a:Lcom/mbridge/msdk/thrid/okio/o;

    iget v2, v0, Lcom/mbridge/msdk/thrid/okio/o;->c:I

    iget v3, v0, Lcom/mbridge/msdk/thrid/okio/o;->b:I

    sub-int/2addr v2, v3

    iput v2, p0, Lcom/mbridge/msdk/thrid/okio/k;->c:I

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okio/k;->b:Ljava/util/zip/Inflater;

    iget-object v0, v0, Lcom/mbridge/msdk/thrid/okio/o;->a:[B

    invoke-virtual {p0, v0, v3, v2}, Ljava/util/zip/Inflater;->setInput([BII)V

    return v1

    :cond_36
    const-string p0, "?"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return v1
.end method
