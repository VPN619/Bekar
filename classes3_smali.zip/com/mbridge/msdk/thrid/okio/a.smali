.class public Lcom/mbridge/msdk/thrid/okio/a;
.super Lcom/mbridge/msdk/thrid/okio/t;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/mbridge/msdk/thrid/okio/a$c;
    }
.end annotation


# static fields
.field private static final h:J

.field private static final i:J

.field static j:Lcom/mbridge/msdk/thrid/okio/a;
    .annotation build Landroidx/annotation/Nullable;
    .end annotation
.end field


# instance fields
.field private e:Z

.field private f:Lcom/mbridge/msdk/thrid/okio/a;
    .annotation build Landroidx/annotation/Nullable;
    .end annotation
.end field

.field private g:J


# direct methods
.method static constructor <clinit>()V
    .registers 2

    const-wide/32 v0, 0xea60

    sput-wide v0, Lcom/mbridge/msdk/thrid/okio/a;->h:J

    const-wide v0, 0xdf8475800L

    sput-wide v0, Lcom/mbridge/msdk/thrid/okio/a;->i:J

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lcom/mbridge/msdk/thrid/okio/t;-><init>()V

    return-void
.end method

.method private static declared-synchronized a(Lcom/mbridge/msdk/thrid/okio/a;JZ)V
    .registers 9

    .prologue
    const-class v0, Lcom/mbridge/msdk/thrid/okio/a;

    monitor-enter v0

    :try_start_3
    sget-object v1, Lcom/mbridge/msdk/thrid/okio/a;->j:Lcom/mbridge/msdk/thrid/okio/a;

    if-nez v1, :cond_19

    new-instance v1, Lcom/mbridge/msdk/thrid/okio/a;

    invoke-direct {v1}, Lcom/mbridge/msdk/thrid/okio/a;-><init>()V

    sput-object v1, Lcom/mbridge/msdk/thrid/okio/a;->j:Lcom/mbridge/msdk/thrid/okio/a;

    new-instance v1, Lcom/mbridge/msdk/thrid/okio/a$c;

    invoke-direct {v1}, Lcom/mbridge/msdk/thrid/okio/a$c;-><init>()V

    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    goto :goto_19

    :catchall_17
    move-exception p0

    goto :goto_6d

    :cond_19
    :goto_19
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v1

    const-wide/16 v3, 0x0

    cmp-long v3, p1, v3

    if-eqz v3, :cond_32

    if-eqz p3, :cond_32

    invoke-virtual {p0}, Lcom/mbridge/msdk/thrid/okio/t;->c()J

    move-result-wide v3

    sub-long/2addr v3, v1

    invoke-static {p1, p2, v3, v4}, Ljava/lang/Math;->min(JJ)J

    move-result-wide p1

    add-long/2addr p1, v1

    iput-wide p1, p0, Lcom/mbridge/msdk/thrid/okio/a;->g:J

    goto :goto_40

    :cond_32
    if-eqz v3, :cond_38

    add-long/2addr p1, v1

    iput-wide p1, p0, Lcom/mbridge/msdk/thrid/okio/a;->g:J

    goto :goto_40

    :cond_38
    if-eqz p3, :cond_67

    invoke-virtual {p0}, Lcom/mbridge/msdk/thrid/okio/t;->c()J

    move-result-wide p1

    iput-wide p1, p0, Lcom/mbridge/msdk/thrid/okio/a;->g:J

    :goto_40
    invoke-direct {p0, v1, v2}, Lcom/mbridge/msdk/thrid/okio/a;->b(J)J

    move-result-wide p1

    sget-object p3, Lcom/mbridge/msdk/thrid/okio/a;->j:Lcom/mbridge/msdk/thrid/okio/a;

    :goto_46
    iget-object v3, p3, Lcom/mbridge/msdk/thrid/okio/a;->f:Lcom/mbridge/msdk/thrid/okio/a;

    if-eqz v3, :cond_56

    invoke-direct {v3, v1, v2}, Lcom/mbridge/msdk/thrid/okio/a;->b(J)J

    move-result-wide v3

    cmp-long v3, p1, v3

    if-gez v3, :cond_53

    goto :goto_56

    :cond_53
    iget-object p3, p3, Lcom/mbridge/msdk/thrid/okio/a;->f:Lcom/mbridge/msdk/thrid/okio/a;

    goto :goto_46

    :cond_56
    :goto_56
    iget-object p1, p3, Lcom/mbridge/msdk/thrid/okio/a;->f:Lcom/mbridge/msdk/thrid/okio/a;

    iput-object p1, p0, Lcom/mbridge/msdk/thrid/okio/a;->f:Lcom/mbridge/msdk/thrid/okio/a;

    iput-object p0, p3, Lcom/mbridge/msdk/thrid/okio/a;->f:Lcom/mbridge/msdk/thrid/okio/a;

    sget-object p0, Lcom/mbridge/msdk/thrid/okio/a;->j:Lcom/mbridge/msdk/thrid/okio/a;

    if-ne p3, p0, :cond_65

    const-class p0, Lcom/mbridge/msdk/thrid/okio/a;

    invoke-virtual {p0}, Ljava/lang/Object;->notify()V
    :try_end_65
    .catchall {:try_start_3 .. :try_end_65} :catchall_17

    :cond_65
    monitor-exit v0

    return-void

    :cond_67
    :try_start_67
    new-instance p0, Ljava/lang/AssertionError;

    invoke-direct {p0}, Ljava/lang/AssertionError;-><init>()V

    throw p0

    :goto_6d
    monitor-exit v0
    :try_end_6e
    .catchall {:try_start_67 .. :try_end_6e} :catchall_17

    throw p0
.end method

.method private static declared-synchronized a(Lcom/mbridge/msdk/thrid/okio/a;)Z
    .registers 4

    .prologue
    const-class v0, Lcom/mbridge/msdk/thrid/okio/a;

    monitor-enter v0

    :try_start_3
    sget-object v1, Lcom/mbridge/msdk/thrid/okio/a;->j:Lcom/mbridge/msdk/thrid/okio/a;

    :goto_5
    if-eqz v1, :cond_19

    iget-object v2, v1, Lcom/mbridge/msdk/thrid/okio/a;->f:Lcom/mbridge/msdk/thrid/okio/a;

    if-ne v2, p0, :cond_17

    iget-object v2, p0, Lcom/mbridge/msdk/thrid/okio/a;->f:Lcom/mbridge/msdk/thrid/okio/a;

    iput-object v2, v1, Lcom/mbridge/msdk/thrid/okio/a;->f:Lcom/mbridge/msdk/thrid/okio/a;

    const/4 v1, 0x0

    iput-object v1, p0, Lcom/mbridge/msdk/thrid/okio/a;->f:Lcom/mbridge/msdk/thrid/okio/a;
    :try_end_12
    .catchall {:try_start_3 .. :try_end_12} :catchall_15

    monitor-exit v0

    const/4 p0, 0x0

    return p0

    :catchall_15
    move-exception p0

    goto :goto_1c

    :cond_17
    move-object v1, v2

    goto :goto_5

    :cond_19
    monitor-exit v0

    const/4 p0, 0x1

    return p0

    :goto_1c
    :try_start_1c
    monitor-exit v0
    :try_end_1d
    .catchall {:try_start_1c .. :try_end_1d} :catchall_15

    throw p0
.end method

.method private b(J)J
    .registers 5

    iget-wide v0, p0, Lcom/mbridge/msdk/thrid/okio/a;->g:J

    sub-long/2addr v0, p1

    return-wide v0
.end method

.method public static g()Lcom/mbridge/msdk/thrid/okio/a;
    .registers 9
    .annotation build Landroidx/annotation/Nullable;
    .end annotation

    .prologue
    sget-object v0, Lcom/mbridge/msdk/thrid/okio/a;->j:Lcom/mbridge/msdk/thrid/okio/a;

    iget-object v0, v0, Lcom/mbridge/msdk/thrid/okio/a;->f:Lcom/mbridge/msdk/thrid/okio/a;

    const-class v1, Lcom/mbridge/msdk/thrid/okio/a;

    const/4 v2, 0x0

    if-nez v0, :cond_27

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v3

    sget-wide v5, Lcom/mbridge/msdk/thrid/okio/a;->h:J

    invoke-virtual {v1, v5, v6}, Ljava/lang/Object;->wait(J)V

    sget-object v0, Lcom/mbridge/msdk/thrid/okio/a;->j:Lcom/mbridge/msdk/thrid/okio/a;

    iget-object v0, v0, Lcom/mbridge/msdk/thrid/okio/a;->f:Lcom/mbridge/msdk/thrid/okio/a;

    if-nez v0, :cond_26

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v0

    sub-long/2addr v0, v3

    sget-wide v3, Lcom/mbridge/msdk/thrid/okio/a;->i:J

    cmp-long v0, v0, v3

    if-ltz v0, :cond_26

    sget-object v0, Lcom/mbridge/msdk/thrid/okio/a;->j:Lcom/mbridge/msdk/thrid/okio/a;

    return-object v0

    :cond_26
    return-object v2

    :cond_27
    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v3

    invoke-direct {v0, v3, v4}, Lcom/mbridge/msdk/thrid/okio/a;->b(J)J

    move-result-wide v3

    const-wide/16 v5, 0x0

    cmp-long v5, v3, v5

    if-lez v5, :cond_41

    const-wide/32 v5, 0xf4240

    div-long v7, v3, v5

    mul-long/2addr v5, v7

    sub-long/2addr v3, v5

    long-to-int v0, v3

    invoke-virtual {v1, v7, v8, v0}, Ljava/lang/Object;->wait(JI)V

    return-object v2

    :cond_41
    sget-object v1, Lcom/mbridge/msdk/thrid/okio/a;->j:Lcom/mbridge/msdk/thrid/okio/a;

    iget-object v3, v0, Lcom/mbridge/msdk/thrid/okio/a;->f:Lcom/mbridge/msdk/thrid/okio/a;

    iput-object v3, v1, Lcom/mbridge/msdk/thrid/okio/a;->f:Lcom/mbridge/msdk/thrid/okio/a;

    iput-object v2, v0, Lcom/mbridge/msdk/thrid/okio/a;->f:Lcom/mbridge/msdk/thrid/okio/a;

    return-object v0
.end method


# virtual methods
.method public final a(Lcom/mbridge/msdk/thrid/okio/r;)Lcom/mbridge/msdk/thrid/okio/r;
    .registers 3

    new-instance v0, Lcom/mbridge/msdk/thrid/okio/a$a;

    invoke-direct {v0, p0, p1}, Lcom/mbridge/msdk/thrid/okio/a$a;-><init>(Lcom/mbridge/msdk/thrid/okio/a;Lcom/mbridge/msdk/thrid/okio/r;)V

    return-object v0
.end method

.method public final a(Lcom/mbridge/msdk/thrid/okio/s;)Lcom/mbridge/msdk/thrid/okio/s;
    .registers 3

    new-instance v0, Lcom/mbridge/msdk/thrid/okio/a$b;

    invoke-direct {v0, p0, p1}, Lcom/mbridge/msdk/thrid/okio/a$b;-><init>(Lcom/mbridge/msdk/thrid/okio/a;Lcom/mbridge/msdk/thrid/okio/s;)V

    return-object v0
.end method

.method public final a(Ljava/io/IOException;)Ljava/io/IOException;
    .registers 3

    .prologue
    invoke-virtual {p0}, Lcom/mbridge/msdk/thrid/okio/a;->i()Z

    move-result v0

    if-nez v0, :cond_7

    return-object p1

    :cond_7
    invoke-virtual {p0, p1}, Lcom/mbridge/msdk/thrid/okio/a;->b(Ljava/io/IOException;)Ljava/io/IOException;

    move-result-object p0

    return-object p0
.end method

.method public final a(Z)V
    .registers 3

    .prologue
    invoke-virtual {p0}, Lcom/mbridge/msdk/thrid/okio/a;->i()Z

    move-result v0

    if-eqz v0, :cond_f

    if-nez p1, :cond_9

    goto :goto_f

    :cond_9
    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Lcom/mbridge/msdk/thrid/okio/a;->b(Ljava/io/IOException;)Ljava/io/IOException;

    move-result-object p0

    throw p0

    :cond_f
    :goto_f
    return-void
.end method

.method public b(Ljava/io/IOException;)Ljava/io/IOException;
    .registers 3
    .param p1  # Ljava/io/IOException;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    .prologue
    new-instance p0, Ljava/io/InterruptedIOException;

    const-string v0, "timeout"

    invoke-direct {p0, v0}, Ljava/io/InterruptedIOException;-><init>(Ljava/lang/String;)V

    if-eqz p1, :cond_c

    invoke-virtual {p0, p1}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    :cond_c
    return-object p0
.end method

.method public final h()V
    .registers 6

    .prologue
    iget-boolean v0, p0, Lcom/mbridge/msdk/thrid/okio/a;->e:Z

    if-nez v0, :cond_1c

    invoke-virtual {p0}, Lcom/mbridge/msdk/thrid/okio/t;->f()J

    move-result-wide v0

    invoke-virtual {p0}, Lcom/mbridge/msdk/thrid/okio/t;->d()Z

    move-result v2

    const-wide/16 v3, 0x0

    cmp-long v3, v0, v3

    if-nez v3, :cond_15

    if-nez v2, :cond_15

    return-void

    :cond_15
    const/4 v3, 0x1

    iput-boolean v3, p0, Lcom/mbridge/msdk/thrid/okio/a;->e:Z

    invoke-static {p0, v0, v1, v2}, Lcom/mbridge/msdk/thrid/okio/a;->a(Lcom/mbridge/msdk/thrid/okio/a;JZ)V

    return-void

    :cond_1c
    const-string p0, "Unbalanced enter/exit"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-void
.end method

.method public final i()Z
    .registers 3

    .prologue
    iget-boolean v0, p0, Lcom/mbridge/msdk/thrid/okio/a;->e:Z

    const/4 v1, 0x0

    if-nez v0, :cond_6

    return v1

    :cond_6
    iput-boolean v1, p0, Lcom/mbridge/msdk/thrid/okio/a;->e:Z

    invoke-static {p0}, Lcom/mbridge/msdk/thrid/okio/a;->a(Lcom/mbridge/msdk/thrid/okio/a;)Z

    move-result p0

    return p0
.end method

.method public j()V
    .registers 1

    return-void
.end method
