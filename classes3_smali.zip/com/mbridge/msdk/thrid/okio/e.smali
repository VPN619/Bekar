.class public interface abstract Lcom/mbridge/msdk/thrid/okio/e;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lcom/mbridge/msdk/thrid/okio/s;
.implements Ljava/nio/channels/ReadableByteChannel;


# virtual methods
.method public abstract a(B)J
.end method

.method public abstract a()Lcom/mbridge/msdk/thrid/okio/c;
.end method

.method public abstract a(Ljava/nio/charset/Charset;)Ljava/lang/String;
.end method

.method public abstract a(JLcom/mbridge/msdk/thrid/okio/f;)Z
.end method

.method public abstract b(J)Lcom/mbridge/msdk/thrid/okio/f;
.end method

.method public abstract c()Ljava/lang/String;
.end method

.method public abstract c(J)[B
.end method

.method public abstract d(J)Ljava/lang/String;
.end method

.method public abstract e()I
.end method

.method public abstract e(J)V
.end method

.method public abstract f()Z
.end method

.method public abstract g()S
.end method

.method public abstract i()J
.end method

.method public abstract j()Ljava/io/InputStream;
.end method

.method public abstract readByte()B
.end method

.method public abstract readFully([B)V
.end method

.method public abstract readInt()I
.end method

.method public abstract readShort()S
.end method

.method public abstract skip(J)V
.end method
