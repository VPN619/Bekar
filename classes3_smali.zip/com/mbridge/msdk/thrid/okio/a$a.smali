.class Lcom/mbridge/msdk/thrid/okio/a$a;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lcom/mbridge/msdk/thrid/okio/r;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/mbridge/msdk/thrid/okio/a;->a(Lcom/mbridge/msdk/thrid/okio/r;)Lcom/mbridge/msdk/thrid/okio/r;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/mbridge/msdk/thrid/okio/r;

.field final synthetic b:Lcom/mbridge/msdk/thrid/okio/a;


# direct methods
.method public constructor <init>(Lcom/mbridge/msdk/thrid/okio/a;Lcom/mbridge/msdk/thrid/okio/r;)V
    .registers 3

    iput-object p1, p0, Lcom/mbridge/msdk/thrid/okio/a$a;->b:Lcom/mbridge/msdk/thrid/okio/a;

    iput-object p2, p0, Lcom/mbridge/msdk/thrid/okio/a$a;->a:Lcom/mbridge/msdk/thrid/okio/r;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lcom/mbridge/msdk/thrid/okio/c;J)V
    .registers 10

    .prologue
    iget-wide v0, p1, Lcom/mbridge/msdk/thrid/okio/c;->b:J

    const-wide/16 v2, 0x0

    move-wide v4, p2

    invoke-static/range {v0 .. v5}, Lcom/mbridge/msdk/thrid/okio/u;->a(JJJ)V

    :goto_8
    const-wide/16 v0, 0x0

    cmp-long v2, p2, v0

    if-lez v2, :cond_4c

    iget-object v2, p1, Lcom/mbridge/msdk/thrid/okio/c;->a:Lcom/mbridge/msdk/thrid/okio/o;

    :goto_10
    const-wide/32 v3, 0x10000

    cmp-long v3, v0, v3

    if-gez v3, :cond_27

    iget v3, v2, Lcom/mbridge/msdk/thrid/okio/o;->c:I

    iget v4, v2, Lcom/mbridge/msdk/thrid/okio/o;->b:I

    sub-int/2addr v3, v4

    int-to-long v3, v3

    add-long/2addr v0, v3

    cmp-long v3, v0, p2

    if-ltz v3, :cond_24

    move-wide v0, p2

    goto :goto_27

    :cond_24
    iget-object v2, v2, Lcom/mbridge/msdk/thrid/okio/o;->f:Lcom/mbridge/msdk/thrid/okio/o;

    goto :goto_10

    :cond_27
    :goto_27
    iget-object v2, p0, Lcom/mbridge/msdk/thrid/okio/a$a;->b:Lcom/mbridge/msdk/thrid/okio/a;

    invoke-virtual {v2}, Lcom/mbridge/msdk/thrid/okio/a;->h()V

    :try_start_2c
    iget-object v2, p0, Lcom/mbridge/msdk/thrid/okio/a$a;->a:Lcom/mbridge/msdk/thrid/okio/r;

    invoke-interface {v2, p1, v0, v1}, Lcom/mbridge/msdk/thrid/okio/r;->a(Lcom/mbridge/msdk/thrid/okio/c;J)V
    :try_end_31
    .catch Ljava/io/IOException; {:try_start_2c .. :try_end_31} :catch_3c
    .catchall {:try_start_2c .. :try_end_31} :catchall_39

    sub-long/2addr p2, v0

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okio/a$a;->b:Lcom/mbridge/msdk/thrid/okio/a;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Lcom/mbridge/msdk/thrid/okio/a;->a(Z)V

    goto :goto_8

    :catchall_39
    move-exception v0

    move-object p1, v0

    goto :goto_45

    :catch_3c
    move-exception v0

    move-object p1, v0

    :try_start_3e
    iget-object p2, p0, Lcom/mbridge/msdk/thrid/okio/a$a;->b:Lcom/mbridge/msdk/thrid/okio/a;

    invoke-virtual {p2, p1}, Lcom/mbridge/msdk/thrid/okio/a;->a(Ljava/io/IOException;)Ljava/io/IOException;

    move-result-object p1

    throw p1
    :try_end_45
    .catchall {:try_start_3e .. :try_end_45} :catchall_39

    :goto_45
    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okio/a$a;->b:Lcom/mbridge/msdk/thrid/okio/a;

    const/4 p2, 0x0

    invoke-virtual {p0, p2}, Lcom/mbridge/msdk/thrid/okio/a;->a(Z)V

    throw p1

    :cond_4c
    return-void
.end method

.method public b()Lcom/mbridge/msdk/thrid/okio/t;
    .registers 1

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okio/a$a;->b:Lcom/mbridge/msdk/thrid/okio/a;

    return-object p0
.end method

.method public close()V
    .registers 3

    .prologue
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okio/a$a;->b:Lcom/mbridge/msdk/thrid/okio/a;

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okio/a;->h()V

    :try_start_5
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okio/a$a;->a:Lcom/mbridge/msdk/thrid/okio/r;

    invoke-interface {v0}, Lcom/mbridge/msdk/thrid/okio/r;->close()V
    :try_end_a
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_a} :catch_13
    .catchall {:try_start_5 .. :try_end_a} :catchall_11

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okio/a$a;->b:Lcom/mbridge/msdk/thrid/okio/a;

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lcom/mbridge/msdk/thrid/okio/a;->a(Z)V

    return-void

    :catchall_11
    move-exception v0

    goto :goto_1b

    :catch_13
    move-exception v0

    :try_start_14
    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okio/a$a;->b:Lcom/mbridge/msdk/thrid/okio/a;

    invoke-virtual {v1, v0}, Lcom/mbridge/msdk/thrid/okio/a;->a(Ljava/io/IOException;)Ljava/io/IOException;

    move-result-object v0

    throw v0
    :try_end_1b
    .catchall {:try_start_14 .. :try_end_1b} :catchall_11

    :goto_1b
    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okio/a$a;->b:Lcom/mbridge/msdk/thrid/okio/a;

    const/4 v1, 0x0

    invoke-virtual {p0, v1}, Lcom/mbridge/msdk/thrid/okio/a;->a(Z)V

    throw v0
.end method

.method public flush()V
    .registers 3

    .prologue
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okio/a$a;->b:Lcom/mbridge/msdk/thrid/okio/a;

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okio/a;->h()V

    :try_start_5
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okio/a$a;->a:Lcom/mbridge/msdk/thrid/okio/r;

    invoke-interface {v0}, Lcom/mbridge/msdk/thrid/okio/r;->flush()V
    :try_end_a
    .catch Ljava/io/IOException; {:try_start_5 .. :try_end_a} :catch_13
    .catchall {:try_start_5 .. :try_end_a} :catchall_11

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okio/a$a;->b:Lcom/mbridge/msdk/thrid/okio/a;

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Lcom/mbridge/msdk/thrid/okio/a;->a(Z)V

    return-void

    :catchall_11
    move-exception v0

    goto :goto_1b

    :catch_13
    move-exception v0

    :try_start_14
    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okio/a$a;->b:Lcom/mbridge/msdk/thrid/okio/a;

    invoke-virtual {v1, v0}, Lcom/mbridge/msdk/thrid/okio/a;->a(Ljava/io/IOException;)Ljava/io/IOException;

    move-result-object v0

    throw v0
    :try_end_1b
    .catchall {:try_start_14 .. :try_end_1b} :catchall_11

    :goto_1b
    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okio/a$a;->b:Lcom/mbridge/msdk/thrid/okio/a;

    const/4 v1, 0x0

    invoke-virtual {p0, v1}, Lcom/mbridge/msdk/thrid/okio/a;->a(Z)V

    throw v0
.end method

.method public toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "AsyncTimeout.sink("

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okio/a$a;->a:Lcom/mbridge/msdk/thrid/okio/r;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
