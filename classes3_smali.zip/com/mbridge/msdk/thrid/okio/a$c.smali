.class final Lcom/mbridge/msdk/thrid/okio/a$c;
.super Ljava/lang/Thread;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/mbridge/msdk/thrid/okio/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 2

    const-string v0, "Okio Watchdog"

    invoke-direct {p0, v0}, Ljava/lang/Thread;-><init>(Ljava/lang/String;)V

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Ljava/lang/Thread;->setDaemon(Z)V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 3

    .prologue
    :catch_0
    :goto_0
    :try_start_0
    const-class p0, Lcom/mbridge/msdk/thrid/okio/a;

    monitor-enter p0
    :try_end_3
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_3} :catch_0

    :try_start_3
    invoke-static {}, Lcom/mbridge/msdk/thrid/okio/a;->g()Lcom/mbridge/msdk/thrid/okio/a;

    move-result-object v0

    if-nez v0, :cond_d

    monitor-exit p0

    goto :goto_0

    :catchall_b
    move-exception v0

    goto :goto_1b

    :cond_d
    sget-object v1, Lcom/mbridge/msdk/thrid/okio/a;->j:Lcom/mbridge/msdk/thrid/okio/a;

    if-ne v0, v1, :cond_16

    const/4 v0, 0x0

    sput-object v0, Lcom/mbridge/msdk/thrid/okio/a;->j:Lcom/mbridge/msdk/thrid/okio/a;

    monitor-exit p0

    return-void

    :cond_16
    monitor-exit p0
    :try_end_17
    .catchall {:try_start_3 .. :try_end_17} :catchall_b

    :try_start_17
    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okio/a;->j()V
    :try_end_1a
    .catch Ljava/lang/InterruptedException; {:try_start_17 .. :try_end_1a} :catch_0

    goto :goto_0

    :goto_1b
    :try_start_1b
    monitor-exit p0
    :try_end_1c
    .catchall {:try_start_1b .. :try_end_1c} :catchall_b

    :try_start_1c
    throw v0
    :try_end_1d
    .catch Ljava/lang/InterruptedException; {:try_start_1c .. :try_end_1d} :catch_0
.end method
