.class Lcom/mbridge/msdk/thrid/okio/c$a;
.super Ljava/io/InputStream;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/mbridge/msdk/thrid/okio/c;->j()Ljava/io/InputStream;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/mbridge/msdk/thrid/okio/c;


# direct methods
.method public constructor <init>(Lcom/mbridge/msdk/thrid/okio/c;)V
    .registers 2

    iput-object p1, p0, Lcom/mbridge/msdk/thrid/okio/c$a;->a:Lcom/mbridge/msdk/thrid/okio/c;

    invoke-direct {p0}, Ljava/io/InputStream;-><init>()V

    return-void
.end method


# virtual methods
.method public available()I
    .registers 5

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okio/c$a;->a:Lcom/mbridge/msdk/thrid/okio/c;

    iget-wide v0, p0, Lcom/mbridge/msdk/thrid/okio/c;->b:J

    const-wide/32 v2, 0x7fffffff

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v0

    long-to-int p0, v0

    return p0
.end method

.method public close()V
    .registers 1

    return-void
.end method

.method public read()I
    .registers 5

    .prologue
    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okio/c$a;->a:Lcom/mbridge/msdk/thrid/okio/c;

    iget-wide v0, p0, Lcom/mbridge/msdk/thrid/okio/c;->b:J

    const-wide/16 v2, 0x0

    cmp-long v0, v0, v2

    if-lez v0, :cond_11

    invoke-virtual {p0}, Lcom/mbridge/msdk/thrid/okio/c;->readByte()B

    move-result p0

    and-int/lit16 p0, p0, 0xff

    return p0

    :cond_11
    const/4 p0, -0x1

    return p0
.end method

.method public read([BII)I
    .registers 4

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okio/c$a;->a:Lcom/mbridge/msdk/thrid/okio/c;

    invoke-virtual {p0, p1, p2, p3}, Lcom/mbridge/msdk/thrid/okio/c;->read([BII)I

    move-result p0

    return p0
.end method

.method public toString()Ljava/lang/String;
    .registers 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okio/c$a;->a:Lcom/mbridge/msdk/thrid/okio/c;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, ".inputStream()"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
