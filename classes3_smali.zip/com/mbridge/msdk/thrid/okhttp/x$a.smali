.class Lcom/mbridge/msdk/thrid/okhttp/x$a;
.super Lcom/mbridge/msdk/thrid/okio/a;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/mbridge/msdk/thrid/okhttp/x;-><init>(Lcom/mbridge/msdk/thrid/okhttp/v;Lcom/mbridge/msdk/thrid/okhttp/y;Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field final synthetic k:Lcom/mbridge/msdk/thrid/okhttp/x;


# direct methods
.method public constructor <init>(Lcom/mbridge/msdk/thrid/okhttp/x;)V
    .registers 2

    iput-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/x$a;->k:Lcom/mbridge/msdk/thrid/okhttp/x;

    invoke-direct {p0}, Lcom/mbridge/msdk/thrid/okio/a;-><init>()V

    return-void
.end method


# virtual methods
.method public j()V
    .registers 1

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/x$a;->k:Lcom/mbridge/msdk/thrid/okhttp/x;

    invoke-virtual {p0}, Lcom/mbridge/msdk/thrid/okhttp/x;->cancel()V

    return-void
.end method
