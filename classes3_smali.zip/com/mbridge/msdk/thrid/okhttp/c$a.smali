.class public final Lcom/mbridge/msdk/thrid/okhttp/c$a;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/mbridge/msdk/thrid/okhttp/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field a:Z

.field b:Z

.field c:I

.field d:I

.field e:I

.field f:Z

.field g:Z

.field h:Z


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    iput v0, p0, Lcom/mbridge/msdk/thrid/okhttp/c$a;->c:I

    iput v0, p0, Lcom/mbridge/msdk/thrid/okhttp/c$a;->d:I

    iput v0, p0, Lcom/mbridge/msdk/thrid/okhttp/c$a;->e:I

    return-void
.end method


# virtual methods
.method public a(ILjava/util/concurrent/TimeUnit;)Lcom/mbridge/msdk/thrid/okhttp/c$a;
    .registers 5

    .prologue
    if-ltz p1, :cond_16

    int-to-long v0, p1

    invoke-virtual {p2, v0, v1}, Ljava/util/concurrent/TimeUnit;->toSeconds(J)J

    move-result-wide p1

    const-wide/32 v0, 0x7fffffff

    cmp-long v0, p1, v0

    if-lez v0, :cond_12

    const p1, 0x7fffffff

    goto :goto_13

    :cond_12
    long-to-int p1, p1

    :goto_13
    iput p1, p0, Lcom/mbridge/msdk/thrid/okhttp/c$a;->d:I

    return-object p0

    :cond_16
    const-string p0, "maxStale < 0: "

    invoke-static {p1, p0}, Lrt2;->f(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->s(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public a()Lcom/mbridge/msdk/thrid/okhttp/c;
    .registers 2

    new-instance v0, Lcom/mbridge/msdk/thrid/okhttp/c;

    invoke-direct {v0, p0}, Lcom/mbridge/msdk/thrid/okhttp/c;-><init>(Lcom/mbridge/msdk/thrid/okhttp/c$a;)V

    return-object v0
.end method

.method public b()Lcom/mbridge/msdk/thrid/okhttp/c$a;
    .registers 2

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/c$a;->a:Z

    return-object p0
.end method

.method public c()Lcom/mbridge/msdk/thrid/okhttp/c$a;
    .registers 2

    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/c$a;->f:Z

    return-object p0
.end method
