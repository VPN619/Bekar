.class public final Lcom/mbridge/msdk/thrid/okhttp/c;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/mbridge/msdk/thrid/okhttp/c$a;
    }
.end annotation


# static fields
.field public static final n:Lcom/mbridge/msdk/thrid/okhttp/c;

.field public static final o:Lcom/mbridge/msdk/thrid/okhttp/c;


# instance fields
.field private final a:Z

.field private final b:Z

.field private final c:I

.field private final d:I

.field private final e:Z

.field private final f:Z

.field private final g:Z

.field private final h:I

.field private final i:I

.field private final j:Z

.field private final k:Z

.field private final l:Z

.field m:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    new-instance v0, Lcom/mbridge/msdk/thrid/okhttp/c$a;

    invoke-direct {v0}, Lcom/mbridge/msdk/thrid/okhttp/c$a;-><init>()V

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/c$a;->b()Lcom/mbridge/msdk/thrid/okhttp/c$a;

    move-result-object v0

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/c$a;->a()Lcom/mbridge/msdk/thrid/okhttp/c;

    move-result-object v0

    sput-object v0, Lcom/mbridge/msdk/thrid/okhttp/c;->n:Lcom/mbridge/msdk/thrid/okhttp/c;

    new-instance v0, Lcom/mbridge/msdk/thrid/okhttp/c$a;

    invoke-direct {v0}, Lcom/mbridge/msdk/thrid/okhttp/c$a;-><init>()V

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/c$a;->c()Lcom/mbridge/msdk/thrid/okhttp/c$a;

    move-result-object v0

    sget-object v1, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const v2, 0x7fffffff

    invoke-virtual {v0, v2, v1}, Lcom/mbridge/msdk/thrid/okhttp/c$a;->a(ILjava/util/concurrent/TimeUnit;)Lcom/mbridge/msdk/thrid/okhttp/c$a;

    move-result-object v0

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/c$a;->a()Lcom/mbridge/msdk/thrid/okhttp/c;

    move-result-object v0

    sput-object v0, Lcom/mbridge/msdk/thrid/okhttp/c;->o:Lcom/mbridge/msdk/thrid/okhttp/c;

    return-void
.end method

.method public constructor <init>(Lcom/mbridge/msdk/thrid/okhttp/c$a;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iget-boolean v0, p1, Lcom/mbridge/msdk/thrid/okhttp/c$a;->a:Z

    iput-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->a:Z

    iget-boolean v0, p1, Lcom/mbridge/msdk/thrid/okhttp/c$a;->b:Z

    iput-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->b:Z

    iget v0, p1, Lcom/mbridge/msdk/thrid/okhttp/c$a;->c:I

    iput v0, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->c:I

    const/4 v0, -0x1

    iput v0, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->d:I

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->e:Z

    iput-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->f:Z

    iput-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->g:Z

    iget v0, p1, Lcom/mbridge/msdk/thrid/okhttp/c$a;->d:I

    iput v0, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->h:I

    iget v0, p1, Lcom/mbridge/msdk/thrid/okhttp/c$a;->e:I

    iput v0, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->i:I

    iget-boolean v0, p1, Lcom/mbridge/msdk/thrid/okhttp/c$a;->f:Z

    iput-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->j:Z

    iget-boolean v0, p1, Lcom/mbridge/msdk/thrid/okhttp/c$a;->g:Z

    iput-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->k:Z

    iget-boolean p1, p1, Lcom/mbridge/msdk/thrid/okhttp/c$a;->h:Z

    iput-boolean p1, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->l:Z

    return-void
.end method

.method private constructor <init>(ZZIIZZZIIZZZLjava/lang/String;)V
    .registers 14

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-boolean p1, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->a:Z

    iput-boolean p2, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->b:Z

    iput p3, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->c:I

    iput p4, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->d:I

    iput-boolean p5, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->e:Z

    iput-boolean p6, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->f:Z

    iput-boolean p7, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->g:Z

    iput p8, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->h:I

    iput p9, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->i:I

    iput-boolean p10, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->j:Z

    iput-boolean p11, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->k:Z

    iput-boolean p12, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->l:Z

    iput-object p13, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->m:Ljava/lang/String;

    return-void
.end method

.method public static a(Lcom/mbridge/msdk/thrid/okhttp/r;)Lcom/mbridge/msdk/thrid/okhttp/c;
    .registers 24

    .prologue
    move-object/from16 v0, p0

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/r;->b()I

    move-result v1

    const/4 v6, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, -0x1

    const/4 v12, -0x1

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v16, -0x1

    const/16 v17, -0x1

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    :goto_1a
    if-ge v6, v1, :cond_146

    invoke-virtual {v0, v6}, Lcom/mbridge/msdk/thrid/okhttp/r;->a(I)Ljava/lang/String;

    move-result-object v2

    const/16 v22, 0x1

    invoke-virtual {v0, v6}, Lcom/mbridge/msdk/thrid/okhttp/r;->b(I)Ljava/lang/String;

    move-result-object v4

    const-string v5, "Cache-Control"

    invoke-virtual {v2, v5}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_33

    if-eqz v8, :cond_31

    goto :goto_3b

    :cond_31
    move-object v8, v4

    goto :goto_3c

    :cond_33
    const-string v5, "Pragma"

    invoke-virtual {v2, v5}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_13f

    :goto_3b
    const/4 v7, 0x0

    :goto_3c
    const/4 v2, 0x0

    :goto_3d
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v5

    if-ge v2, v5, :cond_13f

    const-string v5, "=,;"

    invoke-static {v4, v2, v5}, Lcom/mbridge/msdk/thrid/okhttp/internal/http/e;->a(Ljava/lang/String;ILjava/lang/String;)I

    move-result v5

    invoke-virtual {v4, v2, v5}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v3

    if-eq v5, v3, :cond_9a

    invoke-virtual {v4, v5}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const/16 v0, 0x2c

    if-eq v3, v0, :cond_9a

    invoke-virtual {v4, v5}, Ljava/lang/String;->charAt(I)C

    move-result v0

    const/16 v3, 0x3b

    if-ne v0, v3, :cond_68

    goto :goto_9a

    :cond_68
    add-int/lit8 v5, v5, 0x1

    invoke-static {v4, v5}, Lcom/mbridge/msdk/thrid/okhttp/internal/http/e;->b(Ljava/lang/String;I)I

    move-result v0

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v3

    if-ge v0, v3, :cond_8b

    invoke-virtual {v4, v0}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const/16 v5, 0x22

    if-ne v3, v5, :cond_8b

    add-int/lit8 v0, v0, 0x1

    const-string v3, "\""

    invoke-static {v4, v0, v3}, Lcom/mbridge/msdk/thrid/okhttp/internal/http/e;->a(Ljava/lang/String;ILjava/lang/String;)I

    move-result v3

    invoke-virtual {v4, v0, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    add-int/lit8 v3, v3, 0x1

    goto :goto_9e

    :cond_8b
    const-string v3, ",;"

    invoke-static {v4, v0, v3}, Lcom/mbridge/msdk/thrid/okhttp/internal/http/e;->a(Ljava/lang/String;ILjava/lang/String;)I

    move-result v3

    invoke-virtual {v4, v0, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    goto :goto_9e

    :cond_9a
    :goto_9a
    add-int/lit8 v5, v5, 0x1

    move v3, v5

    const/4 v0, 0x0

    :goto_9e
    const-string v5, "no-cache"

    invoke-virtual {v5, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_ab

    move/from16 v9, v22

    :goto_a8
    const/4 v5, -0x1

    goto/16 :goto_13a

    :cond_ab
    const-string v5, "no-store"

    invoke-virtual {v5, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_b6

    move/from16 v10, v22

    goto :goto_a8

    :cond_b6
    const-string v5, "max-age"

    invoke-virtual {v5, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_c6

    const/4 v5, -0x1

    invoke-static {v0, v5}, Lcom/mbridge/msdk/thrid/okhttp/internal/http/e;->a(Ljava/lang/String;I)I

    move-result v0

    move v11, v0

    goto/16 :goto_13a

    :cond_c6
    const-string v5, "s-maxage"

    invoke-virtual {v5, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_d6

    const/4 v5, -0x1

    invoke-static {v0, v5}, Lcom/mbridge/msdk/thrid/okhttp/internal/http/e;->a(Ljava/lang/String;I)I

    move-result v0

    move v12, v0

    goto/16 :goto_13a

    :cond_d6
    const-string v5, "private"

    invoke-virtual {v5, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_e1

    move/from16 v13, v22

    goto :goto_a8

    :cond_e1
    const-string v5, "public"

    invoke-virtual {v5, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_ec

    move/from16 v14, v22

    goto :goto_a8

    :cond_ec
    const-string v5, "must-revalidate"

    invoke-virtual {v5, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_f7

    move/from16 v15, v22

    goto :goto_a8

    :cond_f7
    const-string v5, "max-stale"

    invoke-virtual {v5, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_109

    const v2, 0x7fffffff

    invoke-static {v0, v2}, Lcom/mbridge/msdk/thrid/okhttp/internal/http/e;->a(Ljava/lang/String;I)I

    move-result v0

    move/from16 v16, v0

    goto :goto_a8

    :cond_109
    const-string v5, "min-fresh"

    invoke-virtual {v5, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_119

    const/4 v5, -0x1

    invoke-static {v0, v5}, Lcom/mbridge/msdk/thrid/okhttp/internal/http/e;->a(Ljava/lang/String;I)I

    move-result v0

    move/from16 v17, v0

    goto :goto_13a

    :cond_119
    const/4 v5, -0x1

    const-string v0, "only-if-cached"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_125

    move/from16 v18, v22

    goto :goto_13a

    :cond_125
    const-string v0, "no-transform"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_130

    move/from16 v19, v22

    goto :goto_13a

    :cond_130
    const-string v0, "immutable"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_13a

    move/from16 v20, v22

    :cond_13a
    :goto_13a
    move-object/from16 v0, p0

    move v2, v3

    goto/16 :goto_3d

    :cond_13f
    const/4 v5, -0x1

    add-int/lit8 v6, v6, 0x1

    move-object/from16 v0, p0

    goto/16 :goto_1a

    :cond_146
    if-nez v7, :cond_14b

    const/16 v21, 0x0

    goto :goto_14d

    :cond_14b
    move-object/from16 v21, v8

    :goto_14d
    new-instance v8, Lcom/mbridge/msdk/thrid/okhttp/c;

    invoke-direct/range {v8 .. v21}, Lcom/mbridge/msdk/thrid/okhttp/c;-><init>(ZZIIZZZIIZZZLjava/lang/String;)V

    return-object v8
.end method

.method private a()Ljava/lang/String;
    .registers 5

    .prologue
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-boolean v1, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->a:Z

    if-eqz v1, :cond_e

    const-string v1, "no-cache, "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_e
    iget-boolean v1, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->b:Z

    if-eqz v1, :cond_17

    const-string v1, "no-store, "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_17
    iget v1, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->c:I

    const-string v2, ", "

    const/4 v3, -0x1

    if-eq v1, v3, :cond_2b

    const-string v1, "max-age="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->c:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_2b
    iget v1, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->d:I

    if-eq v1, v3, :cond_3c

    const-string v1, "s-maxage="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->d:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_3c
    iget-boolean v1, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->e:Z

    if-eqz v1, :cond_45

    const-string v1, "private, "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_45
    iget-boolean v1, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->f:Z

    if-eqz v1, :cond_4e

    const-string v1, "public, "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_4e
    iget-boolean v1, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->g:Z

    if-eqz v1, :cond_57

    const-string v1, "must-revalidate, "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_57
    iget v1, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->h:I

    if-eq v1, v3, :cond_68

    const-string v1, "max-stale="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->h:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_68
    iget v1, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->i:I

    if-eq v1, v3, :cond_79

    const-string v1, "min-fresh="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->i:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_79
    iget-boolean v1, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->j:Z

    if-eqz v1, :cond_82

    const-string v1, "only-if-cached, "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_82
    iget-boolean v1, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->k:Z

    if-eqz v1, :cond_8b

    const-string v1, "no-transform, "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_8b
    iget-boolean p0, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->l:Z

    if-eqz p0, :cond_94

    const-string p0, "immutable, "

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_94
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result p0

    if-nez p0, :cond_9d

    const-string p0, ""

    return-object p0

    :cond_9d
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result p0

    add-int/lit8 p0, p0, -0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result v1

    invoke-virtual {v0, p0, v1}, Ljava/lang/StringBuilder;->delete(II)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public b()Z
    .registers 1

    iget-boolean p0, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->e:Z

    return p0
.end method

.method public c()Z
    .registers 1

    iget-boolean p0, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->f:Z

    return p0
.end method

.method public d()I
    .registers 1

    iget p0, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->c:I

    return p0
.end method

.method public e()I
    .registers 1

    iget p0, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->h:I

    return p0
.end method

.method public f()I
    .registers 1

    iget p0, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->i:I

    return p0
.end method

.method public g()Z
    .registers 1

    iget-boolean p0, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->g:Z

    return p0
.end method

.method public h()Z
    .registers 1

    iget-boolean p0, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->a:Z

    return p0
.end method

.method public i()Z
    .registers 1

    iget-boolean p0, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->b:Z

    return p0
.end method

.method public j()Z
    .registers 1

    iget-boolean p0, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->j:Z

    return p0
.end method

.method public toString()Ljava/lang/String;
    .registers 2

    .prologue
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->m:Ljava/lang/String;

    if-eqz v0, :cond_5

    return-object v0

    :cond_5
    invoke-direct {p0}, Lcom/mbridge/msdk/thrid/okhttp/c;->a()Ljava/lang/String;

    move-result-object v0

    iput-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/c;->m:Ljava/lang/String;

    return-object v0
.end method
