.class public final Lcom/mbridge/msdk/thrid/okhttp/internal/d;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# direct methods
.method public static a()Ljava/lang/String;
    .registers 1

    const-string v0, "okhttp/3.12.13"

    return-object v0
.end method
