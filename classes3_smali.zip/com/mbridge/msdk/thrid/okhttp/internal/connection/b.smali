.class public final Lcom/mbridge/msdk/thrid/okhttp/internal/connection/b;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field private final a:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/mbridge/msdk/thrid/okhttp/j;",
            ">;"
        }
    .end annotation
.end field

.field private b:I

.field private c:Z

.field private d:Z


# direct methods
.method public constructor <init>(Ljava/util/List;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/mbridge/msdk/thrid/okhttp/j;",
            ">;)V"
        }
    .end annotation

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/b;->b:I

    iput-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/b;->a:Ljava/util/List;

    return-void
.end method

.method private b(Ljavax/net/ssl/SSLSocket;)Z
    .registers 4

    .prologue
    iget v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/b;->b:I

    :goto_2
    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/b;->a:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    if-ge v0, v1, :cond_1d

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/b;->a:Ljava/util/List;

    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/mbridge/msdk/thrid/okhttp/j;

    invoke-virtual {v1, p1}, Lcom/mbridge/msdk/thrid/okhttp/j;->a(Ljavax/net/ssl/SSLSocket;)Z

    move-result v1

    if-eqz v1, :cond_1a

    const/4 p0, 0x1

    return p0

    :cond_1a
    add-int/lit8 v0, v0, 0x1

    goto :goto_2

    :cond_1d
    const/4 p0, 0x0

    return p0
.end method


# virtual methods
.method public a(Ljavax/net/ssl/SSLSocket;)Lcom/mbridge/msdk/thrid/okhttp/j;
    .registers 6

    .prologue
    iget v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/b;->b:I

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/b;->a:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    :goto_8
    if-ge v0, v1, :cond_20

    iget-object v2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/b;->a:Ljava/util/List;

    invoke-interface {v2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/mbridge/msdk/thrid/okhttp/j;

    invoke-virtual {v2, p1}, Lcom/mbridge/msdk/thrid/okhttp/j;->a(Ljavax/net/ssl/SSLSocket;)Z

    move-result v3

    if-eqz v3, :cond_1d

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/b;->b:I

    goto :goto_21

    :cond_1d
    add-int/lit8 v0, v0, 0x1

    goto :goto_8

    :cond_20
    const/4 v2, 0x0

    :goto_21
    if-eqz v2, :cond_31

    invoke-direct {p0, p1}, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/b;->b(Ljavax/net/ssl/SSLSocket;)Z

    move-result v0

    iput-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/b;->c:Z

    sget-object v0, Lcom/mbridge/msdk/thrid/okhttp/internal/a;->a:Lcom/mbridge/msdk/thrid/okhttp/internal/a;

    iget-boolean p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/b;->d:Z

    invoke-virtual {v0, v2, p1, p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/a;->a(Lcom/mbridge/msdk/thrid/okhttp/j;Ljavax/net/ssl/SSLSocket;Z)V

    return-object v2

    :cond_31
    new-instance v0, Ljava/net/UnknownServiceException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Unable to find acceptable protocols. isFallback="

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-boolean v2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/b;->d:Z

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v2, ", modes="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/b;->a:Ljava/util/List;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljavax/net/ssl/SSLSocket;->getEnabledProtocols()[Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const-string p1, ", supported protocols="

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/net/UnknownServiceException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public a(Ljava/io/IOException;)Z
    .registers 5

    .prologue
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/b;->d:Z

    iget-boolean p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/b;->c:Z

    const/4 v1, 0x0

    if-nez p0, :cond_9

    return v1

    :cond_9
    instance-of p0, p1, Ljava/net/ProtocolException;

    if-eqz p0, :cond_e

    return v1

    :cond_e
    instance-of p0, p1, Ljava/io/InterruptedIOException;

    if-eqz p0, :cond_13

    return v1

    :cond_13
    instance-of p0, p1, Ljavax/net/ssl/SSLHandshakeException;

    if-eqz p0, :cond_20

    invoke-virtual {p1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v2

    instance-of v2, v2, Ljava/security/cert/CertificateException;

    if-eqz v2, :cond_20

    return v1

    :cond_20
    instance-of v2, p1, Ljavax/net/ssl/SSLPeerUnverifiedException;

    if-eqz v2, :cond_25

    return v1

    :cond_25
    if-nez p0, :cond_31

    instance-of p0, p1, Ljavax/net/ssl/SSLProtocolException;

    if-nez p0, :cond_31

    instance-of p0, p1, Ljavax/net/ssl/SSLException;

    if-eqz p0, :cond_30

    goto :goto_31

    :cond_30
    return v1

    :cond_31
    :goto_31
    return v0
.end method
