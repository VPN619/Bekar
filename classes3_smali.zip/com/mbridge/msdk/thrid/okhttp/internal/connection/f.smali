.class public final Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f$a;
    }
.end annotation


# instance fields
.field private final a:Lcom/mbridge/msdk/thrid/okhttp/a;

.field private final b:Lcom/mbridge/msdk/thrid/okhttp/internal/connection/d;

.field private final c:Lcom/mbridge/msdk/thrid/okhttp/d;

.field private final d:Lcom/mbridge/msdk/thrid/okhttp/o;

.field private e:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/net/Proxy;",
            ">;"
        }
    .end annotation
.end field

.field private f:I

.field private g:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/net/InetSocketAddress;",
            ">;"
        }
    .end annotation
.end field

.field private final h:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/mbridge/msdk/thrid/okhttp/c0;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lcom/mbridge/msdk/thrid/okhttp/a;Lcom/mbridge/msdk/thrid/okhttp/internal/connection/d;Lcom/mbridge/msdk/thrid/okhttp/d;Lcom/mbridge/msdk/thrid/okhttp/o;)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget-object v0, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    iput-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->e:Ljava/util/List;

    iput-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->g:Ljava/util/List;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->h:Ljava/util/List;

    iput-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->a:Lcom/mbridge/msdk/thrid/okhttp/a;

    iput-object p2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->b:Lcom/mbridge/msdk/thrid/okhttp/internal/connection/d;

    iput-object p3, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->c:Lcom/mbridge/msdk/thrid/okhttp/d;

    iput-object p4, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->d:Lcom/mbridge/msdk/thrid/okhttp/o;

    invoke-virtual {p1}, Lcom/mbridge/msdk/thrid/okhttp/a;->k()Lcom/mbridge/msdk/thrid/okhttp/s;

    move-result-object p2

    invoke-virtual {p1}, Lcom/mbridge/msdk/thrid/okhttp/a;->f()Ljava/net/Proxy;

    move-result-object p1

    invoke-direct {p0, p2, p1}, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->a(Lcom/mbridge/msdk/thrid/okhttp/s;Ljava/net/Proxy;)V

    return-void
.end method

.method public static a(Ljava/net/InetSocketAddress;)Ljava/lang/String;
    .registers 2

    .prologue
    invoke-virtual {p0}, Ljava/net/InetSocketAddress;->getAddress()Ljava/net/InetAddress;

    move-result-object v0

    if-nez v0, :cond_b

    invoke-virtual {p0}, Ljava/net/InetSocketAddress;->getHostName()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_b
    invoke-virtual {v0}, Ljava/net/InetAddress;->getHostAddress()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method private a(Lcom/mbridge/msdk/thrid/okhttp/s;Ljava/net/Proxy;)V
    .registers 3

    .prologue
    if-eqz p2, :cond_9

    invoke-static {p2}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->e:Ljava/util/List;

    goto :goto_30

    :cond_9
    iget-object p2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->a:Lcom/mbridge/msdk/thrid/okhttp/a;

    invoke-virtual {p2}, Lcom/mbridge/msdk/thrid/okhttp/a;->h()Ljava/net/ProxySelector;

    move-result-object p2

    invoke-virtual {p1}, Lcom/mbridge/msdk/thrid/okhttp/s;->n()Ljava/net/URI;

    move-result-object p1

    invoke-virtual {p2, p1}, Ljava/net/ProxySelector;->select(Ljava/net/URI;)Ljava/util/List;

    move-result-object p1

    if-eqz p1, :cond_24

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result p2

    if-nez p2, :cond_24

    invoke-static {p1}, Lcom/mbridge/msdk/thrid/okhttp/internal/c;->a(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    goto :goto_2e

    :cond_24
    sget-object p1, Ljava/net/Proxy;->NO_PROXY:Ljava/net/Proxy;

    filled-new-array {p1}, [Ljava/net/Proxy;

    move-result-object p1

    invoke-static {p1}, Lcom/mbridge/msdk/thrid/okhttp/internal/c;->a([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    :goto_2e
    iput-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->e:Ljava/util/List;

    :goto_30
    const/4 p1, 0x0

    iput p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->f:I

    return-void
.end method

.method private a(Ljava/net/Proxy;)V
    .registers 8

    .prologue
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->g:Ljava/util/List;

    invoke-virtual {p1}, Ljava/net/Proxy;->type()Ljava/net/Proxy$Type;

    move-result-object v0

    sget-object v1, Ljava/net/Proxy$Type;->DIRECT:Ljava/net/Proxy$Type;

    if-eq v0, v1, :cond_35

    invoke-virtual {p1}, Ljava/net/Proxy;->type()Ljava/net/Proxy$Type;

    move-result-object v0

    sget-object v1, Ljava/net/Proxy$Type;->SOCKS:Ljava/net/Proxy$Type;

    if-ne v0, v1, :cond_18

    goto :goto_35

    :cond_18
    invoke-virtual {p1}, Ljava/net/Proxy;->address()Ljava/net/SocketAddress;

    move-result-object v0

    instance-of v1, v0, Ljava/net/InetSocketAddress;

    if-eqz v1, :cond_2b

    check-cast v0, Ljava/net/InetSocketAddress;

    invoke-static {v0}, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->a(Ljava/net/InetSocketAddress;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0}, Ljava/net/InetSocketAddress;->getPort()I

    move-result v0

    goto :goto_49

    :cond_2b
    const-string p0, "Proxy.address() is not an InetSocketAddress: "

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p1

    invoke-static {p1, p0}, Lvx2;->i(Ljava/lang/Object;Ljava/lang/String;)V

    return-void

    :cond_35
    :goto_35
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->a:Lcom/mbridge/msdk/thrid/okhttp/a;

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/a;->k()Lcom/mbridge/msdk/thrid/okhttp/s;

    move-result-object v0

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/s;->g()Ljava/lang/String;

    move-result-object v1

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->a:Lcom/mbridge/msdk/thrid/okhttp/a;

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/a;->k()Lcom/mbridge/msdk/thrid/okhttp/s;

    move-result-object v0

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/s;->j()I

    move-result v0

    :goto_49
    const/4 v2, 0x1

    if-lt v0, v2, :cond_bc

    const v2, 0xffff

    if-gt v0, v2, :cond_bc

    invoke-virtual {p1}, Ljava/net/Proxy;->type()Ljava/net/Proxy$Type;

    move-result-object p1

    sget-object v2, Ljava/net/Proxy$Type;->SOCKS:Ljava/net/Proxy$Type;

    if-ne p1, v2, :cond_63

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->g:Ljava/util/List;

    invoke-static {v1, v0}, Ljava/net/InetSocketAddress;->createUnresolved(Ljava/lang/String;I)Ljava/net/InetSocketAddress;

    move-result-object p1

    invoke-interface {p0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    return-void

    :cond_63
    iget-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->d:Lcom/mbridge/msdk/thrid/okhttp/o;

    iget-object v2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->c:Lcom/mbridge/msdk/thrid/okhttp/d;

    invoke-virtual {p1, v2, v1}, Lcom/mbridge/msdk/thrid/okhttp/o;->dnsStart(Lcom/mbridge/msdk/thrid/okhttp/d;Ljava/lang/String;)V

    iget-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->a:Lcom/mbridge/msdk/thrid/okhttp/a;

    invoke-virtual {p1}, Lcom/mbridge/msdk/thrid/okhttp/a;->c()Lcom/mbridge/msdk/thrid/okhttp/n;

    move-result-object p1

    invoke-interface {p1, v1}, Lcom/mbridge/msdk/thrid/okhttp/n;->a(Ljava/lang/String;)Ljava/util/List;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_9c

    iget-object v2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->d:Lcom/mbridge/msdk/thrid/okhttp/o;

    iget-object v3, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->c:Lcom/mbridge/msdk/thrid/okhttp/d;

    invoke-virtual {v2, v3, v1, p1}, Lcom/mbridge/msdk/thrid/okhttp/o;->dnsEnd(Lcom/mbridge/msdk/thrid/okhttp/d;Ljava/lang/String;Ljava/util/List;)V

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v2, 0x0

    :goto_86
    if-ge v2, v1, :cond_9b

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/net/InetAddress;

    iget-object v4, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->g:Ljava/util/List;

    new-instance v5, Ljava/net/InetSocketAddress;

    invoke-direct {v5, v3, v0}, Ljava/net/InetSocketAddress;-><init>(Ljava/net/InetAddress;I)V

    invoke-interface {v4, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    add-int/lit8 v2, v2, 0x1

    goto :goto_86

    :cond_9b
    return-void

    :cond_9c
    new-instance p1, Ljava/net/UnknownHostException;

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->a:Lcom/mbridge/msdk/thrid/okhttp/a;

    invoke-virtual {p0}, Lcom/mbridge/msdk/thrid/okhttp/a;->c()Lcom/mbridge/msdk/thrid/okhttp/n;

    move-result-object p0

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, " returned no addresses for "

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/net/UnknownHostException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_bc
    new-instance p0, Ljava/net/SocketException;

    new-instance p1, Ljava/lang/StringBuilder;

    const-string v2, "No route to "

    invoke-direct {p1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ":"

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v0, "; port is out of range"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/net/SocketException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private b()Z
    .registers 2

    .prologue
    iget v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->f:I

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->e:Ljava/util/List;

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result p0

    if-ge v0, p0, :cond_c

    const/4 p0, 0x1

    return p0

    :cond_c
    const/4 p0, 0x0

    return p0
.end method

.method private d()Ljava/net/Proxy;
    .registers 5

    .prologue
    invoke-direct {p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->b()Z

    move-result v0

    if-eqz v0, :cond_18

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->e:Ljava/util/List;

    iget v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->f:I

    add-int/lit8 v2, v1, 0x1

    iput v2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->f:I

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/net/Proxy;

    invoke-direct {p0, v0}, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->a(Ljava/net/Proxy;)V

    return-object v0

    :cond_18
    new-instance v0, Ljava/net/SocketException;

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->a:Lcom/mbridge/msdk/thrid/okhttp/a;

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okhttp/a;->k()Lcom/mbridge/msdk/thrid/okhttp/s;

    move-result-object v1

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okhttp/s;->g()Ljava/lang/String;

    move-result-object v1

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->e:Ljava/util/List;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "No route to "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "; exhausted proxy configurations: "

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/net/SocketException;-><init>(Ljava/lang/String;)V

    throw v0
.end method


# virtual methods
.method public a(Lcom/mbridge/msdk/thrid/okhttp/c0;Ljava/io/IOException;)V
    .registers 6

    .prologue
    invoke-virtual {p1}, Lcom/mbridge/msdk/thrid/okhttp/c0;->b()Ljava/net/Proxy;

    move-result-object v0

    invoke-virtual {v0}, Ljava/net/Proxy;->type()Ljava/net/Proxy$Type;

    move-result-object v0

    sget-object v1, Ljava/net/Proxy$Type;->DIRECT:Ljava/net/Proxy$Type;

    if-eq v0, v1, :cond_2f

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->a:Lcom/mbridge/msdk/thrid/okhttp/a;

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/a;->h()Ljava/net/ProxySelector;

    move-result-object v0

    if-eqz v0, :cond_2f

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->a:Lcom/mbridge/msdk/thrid/okhttp/a;

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/a;->h()Ljava/net/ProxySelector;

    move-result-object v0

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->a:Lcom/mbridge/msdk/thrid/okhttp/a;

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okhttp/a;->k()Lcom/mbridge/msdk/thrid/okhttp/s;

    move-result-object v1

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okhttp/s;->n()Ljava/net/URI;

    move-result-object v1

    invoke-virtual {p1}, Lcom/mbridge/msdk/thrid/okhttp/c0;->b()Ljava/net/Proxy;

    move-result-object v2

    invoke-virtual {v2}, Ljava/net/Proxy;->address()Ljava/net/SocketAddress;

    move-result-object v2

    invoke-virtual {v0, v1, v2, p2}, Ljava/net/ProxySelector;->connectFailed(Ljava/net/URI;Ljava/net/SocketAddress;Ljava/io/IOException;)V

    :cond_2f
    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->b:Lcom/mbridge/msdk/thrid/okhttp/internal/connection/d;

    invoke-virtual {p0, p1}, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/d;->b(Lcom/mbridge/msdk/thrid/okhttp/c0;)V

    return-void
.end method

.method public a()Z
    .registers 2

    .prologue
    invoke-direct {p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->b()Z

    move-result v0

    if-nez v0, :cond_11

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->h:Ljava/util/List;

    invoke-interface {p0}, Ljava/util/List;->isEmpty()Z

    move-result p0

    if-nez p0, :cond_f

    goto :goto_11

    :cond_f
    const/4 p0, 0x0

    return p0

    :cond_11
    :goto_11
    const/4 p0, 0x1

    return p0
.end method

.method public c()Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f$a;
    .registers 8

    .prologue
    invoke-virtual {p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->a()Z

    move-result v0

    if-eqz v0, :cond_5d

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    :cond_b
    invoke-direct {p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->b()Z

    move-result v1

    if-eqz v1, :cond_47

    invoke-direct {p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->d()Ljava/net/Proxy;

    move-result-object v1

    iget-object v2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->g:Ljava/util/List;

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    const/4 v3, 0x0

    :goto_1c
    if-ge v3, v2, :cond_41

    new-instance v4, Lcom/mbridge/msdk/thrid/okhttp/c0;

    iget-object v5, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->a:Lcom/mbridge/msdk/thrid/okhttp/a;

    iget-object v6, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->g:Ljava/util/List;

    invoke-interface {v6, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/net/InetSocketAddress;

    invoke-direct {v4, v5, v1, v6}, Lcom/mbridge/msdk/thrid/okhttp/c0;-><init>(Lcom/mbridge/msdk/thrid/okhttp/a;Ljava/net/Proxy;Ljava/net/InetSocketAddress;)V

    iget-object v5, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->b:Lcom/mbridge/msdk/thrid/okhttp/internal/connection/d;

    invoke-virtual {v5, v4}, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/d;->c(Lcom/mbridge/msdk/thrid/okhttp/c0;)Z

    move-result v5

    if-eqz v5, :cond_3b

    iget-object v5, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->h:Ljava/util/List;

    invoke-interface {v5, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    goto :goto_3e

    :cond_3b
    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_3e
    add-int/lit8 v3, v3, 0x1

    goto :goto_1c

    :cond_41
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_b

    :cond_47
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_57

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->h:Ljava/util/List;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f;->h:Ljava/util/List;

    invoke-interface {p0}, Ljava/util/List;->clear()V

    :cond_57
    new-instance p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f$a;

    invoke-direct {p0, v0}, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/f$a;-><init>(Ljava/util/List;)V

    return-object p0

    :cond_5d
    invoke-static {}, Lvx2;->s()V

    const/4 p0, 0x0

    return-object p0
.end method
