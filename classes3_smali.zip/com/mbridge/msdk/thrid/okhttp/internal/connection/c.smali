.class public final Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;
.super Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$j;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lcom/mbridge/msdk/thrid/okhttp/h;


# instance fields
.field private final b:Lcom/mbridge/msdk/thrid/okhttp/i;

.field private final c:Lcom/mbridge/msdk/thrid/okhttp/c0;

.field private d:Ljava/net/Socket;

.field private e:Ljava/net/Socket;

.field private f:Lcom/mbridge/msdk/thrid/okhttp/q;

.field private g:Lcom/mbridge/msdk/thrid/okhttp/w;

.field private h:Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g;

.field private i:Lcom/mbridge/msdk/thrid/okio/e;

.field private j:Lcom/mbridge/msdk/thrid/okio/d;

.field public k:Z

.field public l:I

.field public m:I

.field public final n:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/ref/Reference<",
            "Lcom/mbridge/msdk/thrid/okhttp/internal/connection/g;",
            ">;>;"
        }
    .end annotation
.end field

.field public o:J


# direct methods
.method public constructor <init>(Lcom/mbridge/msdk/thrid/okhttp/i;Lcom/mbridge/msdk/thrid/okhttp/c0;)V
    .registers 5

    invoke-direct {p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$j;-><init>()V

    const/4 v0, 0x1

    iput v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->m:I

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->n:Ljava/util/List;

    const-wide v0, 0x7fffffffffffffffL

    iput-wide v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->o:J

    iput-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->b:Lcom/mbridge/msdk/thrid/okhttp/i;

    iput-object p2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    return-void
.end method

.method private a(IILcom/mbridge/msdk/thrid/okhttp/y;Lcom/mbridge/msdk/thrid/okhttp/s;)Lcom/mbridge/msdk/thrid/okhttp/y;
    .registers 13

    .prologue
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "CONNECT "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x1

    invoke-static {p4, v1}, Lcom/mbridge/msdk/thrid/okhttp/internal/c;->a(Lcom/mbridge/msdk/thrid/okhttp/s;Z)Ljava/lang/String;

    move-result-object p4

    invoke-virtual {v0, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p4, " HTTP/1.1"

    invoke-virtual {v0, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p4

    :goto_18
    new-instance v0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->i:Lcom/mbridge/msdk/thrid/okio/e;

    iget-object v2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->j:Lcom/mbridge/msdk/thrid/okio/d;

    const/4 v3, 0x0

    invoke-direct {v0, v3, v3, v1, v2}, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;-><init>(Lcom/mbridge/msdk/thrid/okhttp/v;Lcom/mbridge/msdk/thrid/okhttp/internal/connection/g;Lcom/mbridge/msdk/thrid/okio/e;Lcom/mbridge/msdk/thrid/okio/d;)V

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->i:Lcom/mbridge/msdk/thrid/okio/e;

    invoke-interface {v1}, Lcom/mbridge/msdk/thrid/okio/s;->b()Lcom/mbridge/msdk/thrid/okio/t;

    move-result-object v1

    int-to-long v4, p1

    sget-object v2, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-virtual {v1, v4, v5, v2}, Lcom/mbridge/msdk/thrid/okio/t;->a(JLjava/util/concurrent/TimeUnit;)Lcom/mbridge/msdk/thrid/okio/t;

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->j:Lcom/mbridge/msdk/thrid/okio/d;

    invoke-interface {v1}, Lcom/mbridge/msdk/thrid/okio/r;->b()Lcom/mbridge/msdk/thrid/okio/t;

    move-result-object v1

    int-to-long v4, p2

    invoke-virtual {v1, v4, v5, v2}, Lcom/mbridge/msdk/thrid/okio/t;->a(JLjava/util/concurrent/TimeUnit;)Lcom/mbridge/msdk/thrid/okio/t;

    invoke-virtual {p3}, Lcom/mbridge/msdk/thrid/okhttp/y;->c()Lcom/mbridge/msdk/thrid/okhttp/r;

    move-result-object v1

    invoke-virtual {v0, v1, p4}, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;->a(Lcom/mbridge/msdk/thrid/okhttp/r;Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;->a()V

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;->a(Z)Lcom/mbridge/msdk/thrid/okhttp/a0$a;

    move-result-object v1

    invoke-virtual {v1, p3}, Lcom/mbridge/msdk/thrid/okhttp/a0$a;->a(Lcom/mbridge/msdk/thrid/okhttp/y;)Lcom/mbridge/msdk/thrid/okhttp/a0$a;

    move-result-object p3

    invoke-virtual {p3}, Lcom/mbridge/msdk/thrid/okhttp/a0$a;->a()Lcom/mbridge/msdk/thrid/okhttp/a0;

    move-result-object p3

    invoke-static {p3}, Lcom/mbridge/msdk/thrid/okhttp/internal/http/e;->a(Lcom/mbridge/msdk/thrid/okhttp/a0;)J

    move-result-wide v4

    const-wide/16 v6, -0x1

    cmp-long v1, v4, v6

    if-nez v1, :cond_5b

    const-wide/16 v4, 0x0

    :cond_5b
    invoke-virtual {v0, v4, v5}, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;->b(J)Lcom/mbridge/msdk/thrid/okio/s;

    move-result-object v0

    const v1, 0x7fffffff

    invoke-static {v0, v1, v2}, Lcom/mbridge/msdk/thrid/okhttp/internal/c;->b(Lcom/mbridge/msdk/thrid/okio/s;ILjava/util/concurrent/TimeUnit;)Z

    invoke-interface {v0}, Lcom/mbridge/msdk/thrid/okio/s;->close()V

    invoke-virtual {p3}, Lcom/mbridge/msdk/thrid/okhttp/a0;->k()I

    move-result v0

    const/16 v1, 0xc8

    if-eq v0, v1, :cond_a7

    const/16 v1, 0x197

    if-ne v0, v1, :cond_9d

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/c0;->a()Lcom/mbridge/msdk/thrid/okhttp/a;

    move-result-object v0

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/a;->g()Lcom/mbridge/msdk/thrid/okhttp/b;

    move-result-object v0

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-interface {v0, v1, p3}, Lcom/mbridge/msdk/thrid/okhttp/b;->a(Lcom/mbridge/msdk/thrid/okhttp/c0;Lcom/mbridge/msdk/thrid/okhttp/a0;)Lcom/mbridge/msdk/thrid/okhttp/y;

    move-result-object v0

    if-eqz v0, :cond_97

    const-string v1, "Connection"

    invoke-virtual {p3, v1}, Lcom/mbridge/msdk/thrid/okhttp/a0;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    const-string v1, "close"

    invoke-virtual {v1, p3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result p3

    if-eqz p3, :cond_95

    return-object v0

    :cond_95
    move-object p3, v0

    goto :goto_18

    :cond_97
    const-string p0, "Failed to authenticate with proxy"

    invoke-static {p0}, Lvh0;->k(Ljava/lang/String;)V

    return-object v3

    :cond_9d
    const-string p0, "Unexpected response code for CONNECT: "

    invoke-virtual {p3}, Lcom/mbridge/msdk/thrid/okhttp/a0;->k()I

    move-result p1

    invoke-static {p1, p0}, Lvx2;->f(ILjava/lang/String;)V

    return-object v3

    :cond_a7
    iget-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->i:Lcom/mbridge/msdk/thrid/okio/e;

    invoke-interface {p1}, Lcom/mbridge/msdk/thrid/okio/e;->a()Lcom/mbridge/msdk/thrid/okio/c;

    move-result-object p1

    invoke-virtual {p1}, Lcom/mbridge/msdk/thrid/okio/c;->f()Z

    move-result p1

    if-eqz p1, :cond_c0

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->j:Lcom/mbridge/msdk/thrid/okio/d;

    invoke-interface {p0}, Lcom/mbridge/msdk/thrid/okio/d;->a()Lcom/mbridge/msdk/thrid/okio/c;

    move-result-object p0

    invoke-virtual {p0}, Lcom/mbridge/msdk/thrid/okio/c;->f()Z

    move-result p0

    if-eqz p0, :cond_c0

    return-object v3

    :cond_c0
    const-string p0, "TLS tunnel buffered too many bytes!"

    invoke-static {p0}, Lvh0;->k(Ljava/lang/String;)V

    return-object v3
.end method

.method private a(I)V
    .registers 7

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->e:Ljava/net/Socket;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/net/Socket;->setSoTimeout(I)V

    new-instance v0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$h;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$h;-><init>(Z)V

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->e:Ljava/net/Socket;

    iget-object v2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-virtual {v2}, Lcom/mbridge/msdk/thrid/okhttp/c0;->a()Lcom/mbridge/msdk/thrid/okhttp/a;

    move-result-object v2

    invoke-virtual {v2}, Lcom/mbridge/msdk/thrid/okhttp/a;->k()Lcom/mbridge/msdk/thrid/okhttp/s;

    move-result-object v2

    invoke-virtual {v2}, Lcom/mbridge/msdk/thrid/okhttp/s;->g()Ljava/lang/String;

    move-result-object v2

    iget-object v3, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->i:Lcom/mbridge/msdk/thrid/okio/e;

    iget-object v4, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->j:Lcom/mbridge/msdk/thrid/okio/d;

    invoke-virtual {v0, v1, v2, v3, v4}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$h;->a(Ljava/net/Socket;Ljava/lang/String;Lcom/mbridge/msdk/thrid/okio/e;Lcom/mbridge/msdk/thrid/okio/d;)Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$h;

    move-result-object v0

    invoke-virtual {v0, p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$h;->a(Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$j;)Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$h;

    move-result-object v0

    invoke-virtual {v0, p1}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$h;->a(I)Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$h;

    move-result-object p1

    invoke-virtual {p1}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$h;->a()Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g;

    move-result-object p1

    iput-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->h:Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g;

    invoke-virtual {p1}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g;->m()V

    return-void
.end method

.method private a(IIILcom/mbridge/msdk/thrid/okhttp/d;Lcom/mbridge/msdk/thrid/okhttp/o;)V
    .registers 12

    .prologue
    invoke-direct {p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->e()Lcom/mbridge/msdk/thrid/okhttp/y;

    move-result-object v0

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/y;->g()Lcom/mbridge/msdk/thrid/okhttp/s;

    move-result-object v1

    const/4 v2, 0x0

    :goto_9
    const/16 v3, 0x15

    if-ge v2, v3, :cond_35

    invoke-direct {p0, p1, p2, p4, p5}, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->a(IILcom/mbridge/msdk/thrid/okhttp/d;Lcom/mbridge/msdk/thrid/okhttp/o;)V

    invoke-direct {p0, p2, p3, v0, v1}, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->a(IILcom/mbridge/msdk/thrid/okhttp/y;Lcom/mbridge/msdk/thrid/okhttp/s;)Lcom/mbridge/msdk/thrid/okhttp/y;

    move-result-object v0

    if-nez v0, :cond_17

    goto :goto_35

    :cond_17
    iget-object v3, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->d:Ljava/net/Socket;

    invoke-static {v3}, Lcom/mbridge/msdk/thrid/okhttp/internal/c;->a(Ljava/net/Socket;)V

    const/4 v3, 0x0

    iput-object v3, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->d:Ljava/net/Socket;

    iput-object v3, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->j:Lcom/mbridge/msdk/thrid/okio/d;

    iput-object v3, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->i:Lcom/mbridge/msdk/thrid/okio/e;

    iget-object v4, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-virtual {v4}, Lcom/mbridge/msdk/thrid/okhttp/c0;->d()Ljava/net/InetSocketAddress;

    move-result-object v4

    iget-object v5, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-virtual {v5}, Lcom/mbridge/msdk/thrid/okhttp/c0;->b()Ljava/net/Proxy;

    move-result-object v5

    invoke-virtual {p5, p4, v4, v5, v3}, Lcom/mbridge/msdk/thrid/okhttp/o;->connectEnd(Lcom/mbridge/msdk/thrid/okhttp/d;Ljava/net/InetSocketAddress;Ljava/net/Proxy;Lcom/mbridge/msdk/thrid/okhttp/w;)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_9

    :cond_35
    :goto_35
    return-void
.end method

.method private a(IILcom/mbridge/msdk/thrid/okhttp/d;Lcom/mbridge/msdk/thrid/okhttp/o;)V
    .registers 9

    .prologue
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/c0;->b()Ljava/net/Proxy;

    move-result-object v0

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okhttp/c0;->a()Lcom/mbridge/msdk/thrid/okhttp/a;

    move-result-object v1

    invoke-virtual {v0}, Ljava/net/Proxy;->type()Ljava/net/Proxy$Type;

    move-result-object v2

    sget-object v3, Ljava/net/Proxy$Type;->DIRECT:Ljava/net/Proxy$Type;

    if-eq v2, v3, :cond_23

    invoke-virtual {v0}, Ljava/net/Proxy;->type()Ljava/net/Proxy$Type;

    move-result-object v2

    sget-object v3, Ljava/net/Proxy$Type;->HTTP:Ljava/net/Proxy$Type;

    if-ne v2, v3, :cond_1d

    goto :goto_23

    :cond_1d
    new-instance v1, Ljava/net/Socket;

    invoke-direct {v1, v0}, Ljava/net/Socket;-><init>(Ljava/net/Proxy;)V

    goto :goto_2b

    :cond_23
    :goto_23
    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okhttp/a;->i()Ljavax/net/SocketFactory;

    move-result-object v1

    invoke-virtual {v1}, Ljavax/net/SocketFactory;->createSocket()Ljava/net/Socket;

    move-result-object v1

    :goto_2b
    iput-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->d:Ljava/net/Socket;

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okhttp/c0;->d()Ljava/net/InetSocketAddress;

    move-result-object v1

    invoke-virtual {p4, p3, v1, v0}, Lcom/mbridge/msdk/thrid/okhttp/o;->connectStart(Lcom/mbridge/msdk/thrid/okhttp/d;Ljava/net/InetSocketAddress;Ljava/net/Proxy;)V

    iget-object p3, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->d:Ljava/net/Socket;

    invoke-virtual {p3, p2}, Ljava/net/Socket;->setSoTimeout(I)V

    :try_start_3b
    invoke-static {}, Lcom/mbridge/msdk/thrid/okhttp/internal/platform/g;->d()Lcom/mbridge/msdk/thrid/okhttp/internal/platform/g;

    move-result-object p2

    iget-object p3, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->d:Ljava/net/Socket;

    iget-object p4, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-virtual {p4}, Lcom/mbridge/msdk/thrid/okhttp/c0;->d()Ljava/net/InetSocketAddress;

    move-result-object p4

    invoke-virtual {p2, p3, p4, p1}, Lcom/mbridge/msdk/thrid/okhttp/internal/platform/g;->a(Ljava/net/Socket;Ljava/net/InetSocketAddress;I)V
    :try_end_4a
    .catch Ljava/net/ConnectException; {:try_start_3b .. :try_end_4a} :catch_77

    :try_start_4a
    iget-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->d:Ljava/net/Socket;

    invoke-static {p1}, Lcom/mbridge/msdk/thrid/okio/l;->b(Ljava/net/Socket;)Lcom/mbridge/msdk/thrid/okio/s;

    move-result-object p1

    invoke-static {p1}, Lcom/mbridge/msdk/thrid/okio/l;->a(Lcom/mbridge/msdk/thrid/okio/s;)Lcom/mbridge/msdk/thrid/okio/e;

    move-result-object p1

    iput-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->i:Lcom/mbridge/msdk/thrid/okio/e;

    iget-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->d:Ljava/net/Socket;

    invoke-static {p1}, Lcom/mbridge/msdk/thrid/okio/l;->a(Ljava/net/Socket;)Lcom/mbridge/msdk/thrid/okio/r;

    move-result-object p1

    invoke-static {p1}, Lcom/mbridge/msdk/thrid/okio/l;->a(Lcom/mbridge/msdk/thrid/okio/r;)Lcom/mbridge/msdk/thrid/okio/d;

    move-result-object p1

    iput-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->j:Lcom/mbridge/msdk/thrid/okio/d;
    :try_end_62
    .catch Ljava/lang/NullPointerException; {:try_start_4a .. :try_end_62} :catch_63

    return-void

    :catch_63
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const-string p2, "throw with null exception"

    invoke-virtual {p2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_71

    return-void

    :cond_71
    new-instance p1, Ljava/io/IOException;

    invoke-direct {p1, p0}, Ljava/io/IOException;-><init>(Ljava/lang/Throwable;)V

    throw p1

    :catch_77
    move-exception p1

    new-instance p2, Ljava/net/ConnectException;

    new-instance p3, Ljava/lang/StringBuilder;

    const-string p4, "Failed to connect to "

    invoke-direct {p3, p4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-virtual {p0}, Lcom/mbridge/msdk/thrid/okhttp/c0;->d()Ljava/net/InetSocketAddress;

    move-result-object p0

    invoke-virtual {p3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p2, p0}, Ljava/net/ConnectException;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p1}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    throw p2
.end method

.method private a(Lcom/mbridge/msdk/thrid/okhttp/internal/connection/b;)V
    .registers 9

    .prologue
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/c0;->a()Lcom/mbridge/msdk/thrid/okhttp/a;

    move-result-object v0

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/a;->j()Ljavax/net/ssl/SSLSocketFactory;

    move-result-object v1

    const/4 v2, 0x0

    :try_start_b
    iget-object v3, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->d:Ljava/net/Socket;

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/a;->k()Lcom/mbridge/msdk/thrid/okhttp/s;

    move-result-object v4

    invoke-virtual {v4}, Lcom/mbridge/msdk/thrid/okhttp/s;->g()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/a;->k()Lcom/mbridge/msdk/thrid/okhttp/s;

    move-result-object v5

    invoke-virtual {v5}, Lcom/mbridge/msdk/thrid/okhttp/s;->j()I

    move-result v5

    const/4 v6, 0x1

    invoke-virtual {v1, v3, v4, v5, v6}, Ljavax/net/ssl/SSLSocketFactory;->createSocket(Ljava/net/Socket;Ljava/lang/String;IZ)Ljava/net/Socket;

    move-result-object v1

    check-cast v1, Ljavax/net/ssl/SSLSocket;
    :try_end_24
    .catch Ljava/lang/AssertionError; {:try_start_b .. :try_end_24} :catch_12b
    .catchall {:try_start_b .. :try_end_24} :catchall_129

    :try_start_24
    invoke-virtual {p1, v1}, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/b;->a(Ljavax/net/ssl/SSLSocket;)Lcom/mbridge/msdk/thrid/okhttp/j;

    move-result-object p1

    invoke-virtual {p1}, Lcom/mbridge/msdk/thrid/okhttp/j;->c()Z

    move-result v3

    if-eqz v3, :cond_4a

    invoke-static {}, Lcom/mbridge/msdk/thrid/okhttp/internal/platform/g;->d()Lcom/mbridge/msdk/thrid/okhttp/internal/platform/g;

    move-result-object v3

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/a;->k()Lcom/mbridge/msdk/thrid/okhttp/s;

    move-result-object v4

    invoke-virtual {v4}, Lcom/mbridge/msdk/thrid/okhttp/s;->g()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/a;->e()Ljava/util/List;

    move-result-object v5

    invoke-virtual {v3, v1, v4, v5}, Lcom/mbridge/msdk/thrid/okhttp/internal/platform/g;->a(Ljavax/net/ssl/SSLSocket;Ljava/lang/String;Ljava/util/List;)V

    goto :goto_4a

    :catchall_42
    move-exception p0

    move-object v2, v1

    goto/16 :goto_139

    :catch_46
    move-exception p0

    move-object v2, v1

    goto/16 :goto_12c

    :cond_4a
    :goto_4a
    invoke-virtual {v1}, Ljavax/net/ssl/SSLSocket;->startHandshake()V

    invoke-virtual {v1}, Ljavax/net/ssl/SSLSocket;->getSession()Ljavax/net/ssl/SSLSession;

    move-result-object v3

    invoke-static {v3}, Lcom/mbridge/msdk/thrid/okhttp/q;->a(Ljavax/net/ssl/SSLSession;)Lcom/mbridge/msdk/thrid/okhttp/q;

    move-result-object v4

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/a;->d()Ljavax/net/ssl/HostnameVerifier;

    move-result-object v5

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/a;->k()Lcom/mbridge/msdk/thrid/okhttp/s;

    move-result-object v6

    invoke-virtual {v6}, Lcom/mbridge/msdk/thrid/okhttp/s;->g()Ljava/lang/String;

    move-result-object v6

    invoke-interface {v5, v6, v3}, Ljavax/net/ssl/HostnameVerifier;->verify(Ljava/lang/String;Ljavax/net/ssl/SSLSession;)Z

    move-result v3

    if-nez v3, :cond_db

    invoke-virtual {v4}, Lcom/mbridge/msdk/thrid/okhttp/q;->b()Ljava/util/List;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/List;->isEmpty()Z

    move-result p1
    :try_end_6f
    .catch Ljava/lang/AssertionError; {:try_start_24 .. :try_end_6f} :catch_46
    .catchall {:try_start_24 .. :try_end_6f} :catchall_42

    const-string v2, "Hostname "

    if-nez p1, :cond_bc

    const/4 p1, 0x0

    :try_start_74
    invoke-interface {p0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/security/cert/X509Certificate;

    new-instance p1, Ljavax/net/ssl/SSLPeerUnverifiedException;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/a;->k()Lcom/mbridge/msdk/thrid/okhttp/s;

    move-result-object v0

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/s;->g()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " not verified:\n    certificate: "

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p0}, Lcom/mbridge/msdk/thrid/okhttp/f;->a(Ljava/security/cert/Certificate;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "\n    DN: "

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/security/cert/X509Certificate;->getSubjectDN()Ljava/security/Principal;

    move-result-object v0

    invoke-interface {v0}, Ljava/security/Principal;->getName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "\n    subjectAltNames: "

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/tls/d;->a(Ljava/security/cert/X509Certificate;)Ljava/util/List;

    move-result-object p0

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljavax/net/ssl/SSLPeerUnverifiedException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_bc
    new-instance p0, Ljavax/net/ssl/SSLPeerUnverifiedException;

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/a;->k()Lcom/mbridge/msdk/thrid/okhttp/s;

    move-result-object v0

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/s;->g()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " not verified (no certificates)"

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljavax/net/ssl/SSLPeerUnverifiedException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_db
    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/a;->a()Lcom/mbridge/msdk/thrid/okhttp/f;

    move-result-object v3

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/a;->k()Lcom/mbridge/msdk/thrid/okhttp/s;

    move-result-object v0

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/s;->g()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4}, Lcom/mbridge/msdk/thrid/okhttp/q;->b()Ljava/util/List;

    move-result-object v5

    invoke-virtual {v3, v0, v5}, Lcom/mbridge/msdk/thrid/okhttp/f;->a(Ljava/lang/String;Ljava/util/List;)V

    invoke-virtual {p1}, Lcom/mbridge/msdk/thrid/okhttp/j;->c()Z

    move-result p1

    if-eqz p1, :cond_fc

    invoke-static {}, Lcom/mbridge/msdk/thrid/okhttp/internal/platform/g;->d()Lcom/mbridge/msdk/thrid/okhttp/internal/platform/g;

    move-result-object p1

    invoke-virtual {p1, v1}, Lcom/mbridge/msdk/thrid/okhttp/internal/platform/g;->b(Ljavax/net/ssl/SSLSocket;)Ljava/lang/String;

    move-result-object v2

    :cond_fc
    iput-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->e:Ljava/net/Socket;

    invoke-static {v1}, Lcom/mbridge/msdk/thrid/okio/l;->b(Ljava/net/Socket;)Lcom/mbridge/msdk/thrid/okio/s;

    move-result-object p1

    invoke-static {p1}, Lcom/mbridge/msdk/thrid/okio/l;->a(Lcom/mbridge/msdk/thrid/okio/s;)Lcom/mbridge/msdk/thrid/okio/e;

    move-result-object p1

    iput-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->i:Lcom/mbridge/msdk/thrid/okio/e;

    iget-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->e:Ljava/net/Socket;

    invoke-static {p1}, Lcom/mbridge/msdk/thrid/okio/l;->a(Ljava/net/Socket;)Lcom/mbridge/msdk/thrid/okio/r;

    move-result-object p1

    invoke-static {p1}, Lcom/mbridge/msdk/thrid/okio/l;->a(Lcom/mbridge/msdk/thrid/okio/r;)Lcom/mbridge/msdk/thrid/okio/d;

    move-result-object p1

    iput-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->j:Lcom/mbridge/msdk/thrid/okio/d;

    iput-object v4, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->f:Lcom/mbridge/msdk/thrid/okhttp/q;

    if-eqz v2, :cond_11d

    invoke-static {v2}, Lcom/mbridge/msdk/thrid/okhttp/w;->a(Ljava/lang/String;)Lcom/mbridge/msdk/thrid/okhttp/w;

    move-result-object p1

    goto :goto_11f

    :cond_11d
    sget-object p1, Lcom/mbridge/msdk/thrid/okhttp/w;->c:Lcom/mbridge/msdk/thrid/okhttp/w;

    :goto_11f
    iput-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->g:Lcom/mbridge/msdk/thrid/okhttp/w;
    :try_end_121
    .catch Ljava/lang/AssertionError; {:try_start_74 .. :try_end_121} :catch_46
    .catchall {:try_start_74 .. :try_end_121} :catchall_42

    invoke-static {}, Lcom/mbridge/msdk/thrid/okhttp/internal/platform/g;->d()Lcom/mbridge/msdk/thrid/okhttp/internal/platform/g;

    move-result-object p0

    invoke-virtual {p0, v1}, Lcom/mbridge/msdk/thrid/okhttp/internal/platform/g;->a(Ljavax/net/ssl/SSLSocket;)V

    return-void

    :catchall_129
    move-exception p0

    goto :goto_139

    :catch_12b
    move-exception p0

    :goto_12c
    :try_start_12c
    invoke-static {p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/c;->a(Ljava/lang/AssertionError;)Z

    move-result p1

    if-eqz p1, :cond_138

    new-instance p1, Ljava/io/IOException;

    invoke-direct {p1, p0}, Ljava/io/IOException;-><init>(Ljava/lang/Throwable;)V

    throw p1

    :cond_138
    throw p0
    :try_end_139
    .catchall {:try_start_12c .. :try_end_139} :catchall_129

    :goto_139
    if-eqz v2, :cond_142

    invoke-static {}, Lcom/mbridge/msdk/thrid/okhttp/internal/platform/g;->d()Lcom/mbridge/msdk/thrid/okhttp/internal/platform/g;

    move-result-object p1

    invoke-virtual {p1, v2}, Lcom/mbridge/msdk/thrid/okhttp/internal/platform/g;->a(Ljavax/net/ssl/SSLSocket;)V

    :cond_142
    invoke-static {v2}, Lcom/mbridge/msdk/thrid/okhttp/internal/c;->a(Ljava/net/Socket;)V

    throw p0
.end method

.method private a(Lcom/mbridge/msdk/thrid/okhttp/internal/connection/b;ILcom/mbridge/msdk/thrid/okhttp/d;Lcom/mbridge/msdk/thrid/okhttp/o;)V
    .registers 6

    .prologue
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/c0;->a()Lcom/mbridge/msdk/thrid/okhttp/a;

    move-result-object v0

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/a;->j()Ljavax/net/ssl/SSLSocketFactory;

    move-result-object v0

    if-nez v0, :cond_2f

    iget-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-virtual {p1}, Lcom/mbridge/msdk/thrid/okhttp/c0;->a()Lcom/mbridge/msdk/thrid/okhttp/a;

    move-result-object p1

    invoke-virtual {p1}, Lcom/mbridge/msdk/thrid/okhttp/a;->e()Ljava/util/List;

    move-result-object p1

    sget-object p3, Lcom/mbridge/msdk/thrid/okhttp/w;->f:Lcom/mbridge/msdk/thrid/okhttp/w;

    invoke-interface {p1, p3}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result p1

    iget-object p4, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->d:Ljava/net/Socket;

    if-eqz p1, :cond_28

    iput-object p4, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->e:Ljava/net/Socket;

    iput-object p3, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->g:Lcom/mbridge/msdk/thrid/okhttp/w;

    invoke-direct {p0, p2}, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->a(I)V

    return-void

    :cond_28
    iput-object p4, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->e:Ljava/net/Socket;

    sget-object p1, Lcom/mbridge/msdk/thrid/okhttp/w;->c:Lcom/mbridge/msdk/thrid/okhttp/w;

    iput-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->g:Lcom/mbridge/msdk/thrid/okhttp/w;

    return-void

    :cond_2f
    invoke-virtual {p4, p3}, Lcom/mbridge/msdk/thrid/okhttp/o;->secureConnectStart(Lcom/mbridge/msdk/thrid/okhttp/d;)V

    invoke-direct {p0, p1}, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->a(Lcom/mbridge/msdk/thrid/okhttp/internal/connection/b;)V

    iget-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->f:Lcom/mbridge/msdk/thrid/okhttp/q;

    invoke-virtual {p4, p3, p1}, Lcom/mbridge/msdk/thrid/okhttp/o;->secureConnectEnd(Lcom/mbridge/msdk/thrid/okhttp/d;Lcom/mbridge/msdk/thrid/okhttp/q;)V

    iget-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->g:Lcom/mbridge/msdk/thrid/okhttp/w;

    sget-object p3, Lcom/mbridge/msdk/thrid/okhttp/w;->e:Lcom/mbridge/msdk/thrid/okhttp/w;

    if-ne p1, p3, :cond_43

    invoke-direct {p0, p2}, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->a(I)V

    :cond_43
    return-void
.end method

.method private e()Lcom/mbridge/msdk/thrid/okhttp/y;
    .registers 5

    .prologue
    new-instance v0, Lcom/mbridge/msdk/thrid/okhttp/y$a;

    invoke-direct {v0}, Lcom/mbridge/msdk/thrid/okhttp/y$a;-><init>()V

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okhttp/c0;->a()Lcom/mbridge/msdk/thrid/okhttp/a;

    move-result-object v1

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okhttp/a;->k()Lcom/mbridge/msdk/thrid/okhttp/s;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/mbridge/msdk/thrid/okhttp/y$a;->a(Lcom/mbridge/msdk/thrid/okhttp/s;)Lcom/mbridge/msdk/thrid/okhttp/y$a;

    move-result-object v0

    const-string v1, "CONNECT"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Lcom/mbridge/msdk/thrid/okhttp/y$a;->a(Ljava/lang/String;Lcom/mbridge/msdk/thrid/okhttp/z;)Lcom/mbridge/msdk/thrid/okhttp/y$a;

    move-result-object v0

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okhttp/c0;->a()Lcom/mbridge/msdk/thrid/okhttp/a;

    move-result-object v1

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okhttp/a;->k()Lcom/mbridge/msdk/thrid/okhttp/s;

    move-result-object v1

    const/4 v2, 0x1

    invoke-static {v1, v2}, Lcom/mbridge/msdk/thrid/okhttp/internal/c;->a(Lcom/mbridge/msdk/thrid/okhttp/s;Z)Ljava/lang/String;

    move-result-object v1

    const-string v2, "Host"

    invoke-virtual {v0, v2, v1}, Lcom/mbridge/msdk/thrid/okhttp/y$a;->b(Ljava/lang/String;Ljava/lang/String;)Lcom/mbridge/msdk/thrid/okhttp/y$a;

    move-result-object v0

    const-string v1, "Proxy-Connection"

    const-string v2, "Keep-Alive"

    invoke-virtual {v0, v1, v2}, Lcom/mbridge/msdk/thrid/okhttp/y$a;->b(Ljava/lang/String;Ljava/lang/String;)Lcom/mbridge/msdk/thrid/okhttp/y$a;

    move-result-object v0

    invoke-static {}, Lcom/mbridge/msdk/thrid/okhttp/internal/d;->a()Ljava/lang/String;

    move-result-object v1

    const-string v2, "User-Agent"

    invoke-virtual {v0, v2, v1}, Lcom/mbridge/msdk/thrid/okhttp/y$a;->b(Ljava/lang/String;Ljava/lang/String;)Lcom/mbridge/msdk/thrid/okhttp/y$a;

    move-result-object v0

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/y$a;->a()Lcom/mbridge/msdk/thrid/okhttp/y;

    move-result-object v0

    new-instance v1, Lcom/mbridge/msdk/thrid/okhttp/a0$a;

    invoke-direct {v1}, Lcom/mbridge/msdk/thrid/okhttp/a0$a;-><init>()V

    invoke-virtual {v1, v0}, Lcom/mbridge/msdk/thrid/okhttp/a0$a;->a(Lcom/mbridge/msdk/thrid/okhttp/y;)Lcom/mbridge/msdk/thrid/okhttp/a0$a;

    move-result-object v1

    sget-object v2, Lcom/mbridge/msdk/thrid/okhttp/w;->c:Lcom/mbridge/msdk/thrid/okhttp/w;

    invoke-virtual {v1, v2}, Lcom/mbridge/msdk/thrid/okhttp/a0$a;->a(Lcom/mbridge/msdk/thrid/okhttp/w;)Lcom/mbridge/msdk/thrid/okhttp/a0$a;

    move-result-object v1

    const/16 v2, 0x197

    invoke-virtual {v1, v2}, Lcom/mbridge/msdk/thrid/okhttp/a0$a;->a(I)Lcom/mbridge/msdk/thrid/okhttp/a0$a;

    move-result-object v1

    const-string v2, "Preemptive Authenticate"

    invoke-virtual {v1, v2}, Lcom/mbridge/msdk/thrid/okhttp/a0$a;->a(Ljava/lang/String;)Lcom/mbridge/msdk/thrid/okhttp/a0$a;

    move-result-object v1

    sget-object v2, Lcom/mbridge/msdk/thrid/okhttp/internal/c;->c:Lcom/mbridge/msdk/thrid/okhttp/b0;

    invoke-virtual {v1, v2}, Lcom/mbridge/msdk/thrid/okhttp/a0$a;->a(Lcom/mbridge/msdk/thrid/okhttp/b0;)Lcom/mbridge/msdk/thrid/okhttp/a0$a;

    move-result-object v1

    const-wide/16 v2, -0x1

    invoke-virtual {v1, v2, v3}, Lcom/mbridge/msdk/thrid/okhttp/a0$a;->b(J)Lcom/mbridge/msdk/thrid/okhttp/a0$a;

    move-result-object v1

    invoke-virtual {v1, v2, v3}, Lcom/mbridge/msdk/thrid/okhttp/a0$a;->a(J)Lcom/mbridge/msdk/thrid/okhttp/a0$a;

    move-result-object v1

    const-string v2, "Proxy-Authenticate"

    const-string v3, "OkHttp-Preemptive"

    invoke-virtual {v1, v2, v3}, Lcom/mbridge/msdk/thrid/okhttp/a0$a;->b(Ljava/lang/String;Ljava/lang/String;)Lcom/mbridge/msdk/thrid/okhttp/a0$a;

    move-result-object v1

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okhttp/a0$a;->a()Lcom/mbridge/msdk/thrid/okhttp/a0;

    move-result-object v1

    iget-object v2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-virtual {v2}, Lcom/mbridge/msdk/thrid/okhttp/c0;->a()Lcom/mbridge/msdk/thrid/okhttp/a;

    move-result-object v2

    invoke-virtual {v2}, Lcom/mbridge/msdk/thrid/okhttp/a;->g()Lcom/mbridge/msdk/thrid/okhttp/b;

    move-result-object v2

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-interface {v2, p0, v1}, Lcom/mbridge/msdk/thrid/okhttp/b;->a(Lcom/mbridge/msdk/thrid/okhttp/c0;Lcom/mbridge/msdk/thrid/okhttp/a0;)Lcom/mbridge/msdk/thrid/okhttp/y;

    move-result-object p0

    if-eqz p0, :cond_8f

    return-object p0

    :cond_8f
    return-object v0
.end method


# virtual methods
.method public a(Lcom/mbridge/msdk/thrid/okhttp/v;Lcom/mbridge/msdk/thrid/okhttp/t$a;Lcom/mbridge/msdk/thrid/okhttp/internal/connection/g;)Lcom/mbridge/msdk/thrid/okhttp/internal/http/c;
    .registers 8

    .prologue
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->h:Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g;

    if-eqz v0, :cond_c

    new-instance v0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/f;

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->h:Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g;

    invoke-direct {v0, p1, p2, p3, p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/f;-><init>(Lcom/mbridge/msdk/thrid/okhttp/v;Lcom/mbridge/msdk/thrid/okhttp/t$a;Lcom/mbridge/msdk/thrid/okhttp/internal/connection/g;Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g;)V

    return-object v0

    :cond_c
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->e:Ljava/net/Socket;

    invoke-interface {p2}, Lcom/mbridge/msdk/thrid/okhttp/t$a;->b()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/net/Socket;->setSoTimeout(I)V

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->i:Lcom/mbridge/msdk/thrid/okio/e;

    invoke-interface {v0}, Lcom/mbridge/msdk/thrid/okio/s;->b()Lcom/mbridge/msdk/thrid/okio/t;

    move-result-object v0

    invoke-interface {p2}, Lcom/mbridge/msdk/thrid/okhttp/t$a;->b()I

    move-result v1

    int-to-long v1, v1

    sget-object v3, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-virtual {v0, v1, v2, v3}, Lcom/mbridge/msdk/thrid/okio/t;->a(JLjava/util/concurrent/TimeUnit;)Lcom/mbridge/msdk/thrid/okio/t;

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->j:Lcom/mbridge/msdk/thrid/okio/d;

    invoke-interface {v0}, Lcom/mbridge/msdk/thrid/okio/r;->b()Lcom/mbridge/msdk/thrid/okio/t;

    move-result-object v0

    invoke-interface {p2}, Lcom/mbridge/msdk/thrid/okhttp/t$a;->c()I

    move-result p2

    int-to-long v1, p2

    invoke-virtual {v0, v1, v2, v3}, Lcom/mbridge/msdk/thrid/okio/t;->a(JLjava/util/concurrent/TimeUnit;)Lcom/mbridge/msdk/thrid/okio/t;

    new-instance p2, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->i:Lcom/mbridge/msdk/thrid/okio/e;

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->j:Lcom/mbridge/msdk/thrid/okio/d;

    invoke-direct {p2, p1, p3, v0, p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;-><init>(Lcom/mbridge/msdk/thrid/okhttp/v;Lcom/mbridge/msdk/thrid/okhttp/internal/connection/g;Lcom/mbridge/msdk/thrid/okio/e;Lcom/mbridge/msdk/thrid/okio/d;)V

    return-object p2
.end method

.method public a()Lcom/mbridge/msdk/thrid/okhttp/w;
    .registers 1

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->g:Lcom/mbridge/msdk/thrid/okhttp/w;

    return-object p0
.end method

.method public a(IIIIZLcom/mbridge/msdk/thrid/okhttp/d;Lcom/mbridge/msdk/thrid/okhttp/o;)V
    .registers 20

    .prologue
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->g:Lcom/mbridge/msdk/thrid/okhttp/w;

    if-nez v0, :cond_140

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/c0;->a()Lcom/mbridge/msdk/thrid/okhttp/a;

    move-result-object v0

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/a;->b()Ljava/util/List;

    move-result-object v0

    new-instance v7, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/b;

    invoke-direct {v7, v0}, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/b;-><init>(Ljava/util/List;)V

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okhttp/c0;->a()Lcom/mbridge/msdk/thrid/okhttp/a;

    move-result-object v1

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okhttp/a;->j()Ljavax/net/ssl/SSLSocketFactory;

    move-result-object v1

    if-nez v1, :cond_60

    sget-object v1, Lcom/mbridge/msdk/thrid/okhttp/j;->j:Lcom/mbridge/msdk/thrid/okhttp/j;

    invoke-interface {v0, v1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_53

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/c0;->a()Lcom/mbridge/msdk/thrid/okhttp/a;

    move-result-object v0

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/a;->k()Lcom/mbridge/msdk/thrid/okhttp/s;

    move-result-object v0

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/s;->g()Ljava/lang/String;

    move-result-object v0

    invoke-static {}, Lcom/mbridge/msdk/thrid/okhttp/internal/platform/g;->d()Lcom/mbridge/msdk/thrid/okhttp/internal/platform/g;

    move-result-object v1

    invoke-virtual {v1, v0}, Lcom/mbridge/msdk/thrid/okhttp/internal/platform/g;->b(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_40

    goto :goto_72

    :cond_40
    new-instance p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/e;

    new-instance p1, Ljava/net/UnknownServiceException;

    const-string p2, "CLEARTEXT communication to "

    const-string p3, " not permitted by network security policy"

    invoke-static {p2, v0, p3}, Lrt2;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/net/UnknownServiceException;-><init>(Ljava/lang/String;)V

    invoke-direct {p0, p1}, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/e;-><init>(Ljava/io/IOException;)V

    throw p0

    :cond_53
    new-instance p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/e;

    new-instance p1, Ljava/net/UnknownServiceException;

    const-string p2, "CLEARTEXT communication not enabled for client"

    invoke-direct {p1, p2}, Ljava/net/UnknownServiceException;-><init>(Ljava/lang/String;)V

    invoke-direct {p0, p1}, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/e;-><init>(Ljava/io/IOException;)V

    throw p0

    :cond_60
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/c0;->a()Lcom/mbridge/msdk/thrid/okhttp/a;

    move-result-object v0

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/a;->e()Ljava/util/List;

    move-result-object v0

    sget-object v1, Lcom/mbridge/msdk/thrid/okhttp/w;->f:Lcom/mbridge/msdk/thrid/okhttp/w;

    invoke-interface {v0, v1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_133

    :goto_72
    const/4 v8, 0x0

    move-object v9, v8

    :goto_74
    :try_start_74
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/c0;->c()Z

    move-result v0
    :try_end_7a
    .catch Ljava/io/IOException; {:try_start_74 .. :try_end_7a} :catch_ec

    if-eqz v0, :cond_9d

    move-object v1, p0

    move v2, p1

    move v3, p2

    move v4, p3

    move-object/from16 v5, p6

    move-object/from16 v6, p7

    :try_start_84
    invoke-direct/range {v1 .. v6}, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->a(IIILcom/mbridge/msdk/thrid/okhttp/d;Lcom/mbridge/msdk/thrid/okhttp/o;)V
    :try_end_87
    .catch Ljava/io/IOException; {:try_start_84 .. :try_end_87} :catch_98

    move v10, v3

    move-object v2, v5

    move-object v1, v6

    :try_start_8a
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->d:Ljava/net/Socket;

    if-nez v0, :cond_8f

    goto :goto_ba

    :cond_8f
    :goto_8f
    move/from16 v11, p4

    goto :goto_a6

    :catch_92
    move-exception v0

    :goto_93
    move/from16 v11, p4

    :goto_95
    move-object v6, v0

    goto/16 :goto_f5

    :catch_98
    move-exception v0

    move v10, v3

    move-object v2, v5

    move-object v1, v6

    goto :goto_93

    :cond_9d
    move v10, p2

    move-object/from16 v2, p6

    move-object/from16 v1, p7

    invoke-direct {p0, p1, p2, v2, v1}, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->a(IILcom/mbridge/msdk/thrid/okhttp/d;Lcom/mbridge/msdk/thrid/okhttp/o;)V
    :try_end_a5
    .catch Ljava/io/IOException; {:try_start_8a .. :try_end_a5} :catch_92

    goto :goto_8f

    :goto_a6
    :try_start_a6
    invoke-direct {p0, v7, v11, v2, v1}, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->a(Lcom/mbridge/msdk/thrid/okhttp/internal/connection/b;ILcom/mbridge/msdk/thrid/okhttp/d;Lcom/mbridge/msdk/thrid/okhttp/o;)V

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/c0;->d()Ljava/net/InetSocketAddress;

    move-result-object v0

    iget-object v3, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-virtual {v3}, Lcom/mbridge/msdk/thrid/okhttp/c0;->b()Ljava/net/Proxy;

    move-result-object v3

    iget-object v4, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->g:Lcom/mbridge/msdk/thrid/okhttp/w;

    invoke-virtual {v1, v2, v0, v3, v4}, Lcom/mbridge/msdk/thrid/okhttp/o;->connectEnd(Lcom/mbridge/msdk/thrid/okhttp/d;Ljava/net/InetSocketAddress;Ljava/net/Proxy;Lcom/mbridge/msdk/thrid/okhttp/w;)V
    :try_end_ba
    .catch Ljava/io/IOException; {:try_start_a6 .. :try_end_ba} :catch_ea

    :goto_ba
    iget-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-virtual {p1}, Lcom/mbridge/msdk/thrid/okhttp/c0;->c()Z

    move-result p1

    if-eqz p1, :cond_d4

    iget-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->d:Ljava/net/Socket;

    if-eqz p1, :cond_c7

    goto :goto_d4

    :cond_c7
    new-instance p0, Ljava/net/ProtocolException;

    const-string p1, "Too many tunnel connections attempted: 21"

    invoke-direct {p0, p1}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V

    new-instance p1, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/e;

    invoke-direct {p1, p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/e;-><init>(Ljava/io/IOException;)V

    throw p1

    :cond_d4
    :goto_d4
    iget-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->h:Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g;

    if-eqz p1, :cond_e9

    iget-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->b:Lcom/mbridge/msdk/thrid/okhttp/i;

    monitor-enter p1

    :try_start_db
    iget-object p2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->h:Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g;

    invoke-virtual {p2}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g;->k()I

    move-result p2

    iput p2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->m:I

    monitor-exit p1

    goto :goto_e9

    :catchall_e5
    move-exception v0

    move-object p0, v0

    monitor-exit p1
    :try_end_e8
    .catchall {:try_start_db .. :try_end_e8} :catchall_e5

    throw p0

    :cond_e9
    :goto_e9
    return-void

    :catch_ea
    move-exception v0

    goto :goto_95

    :catch_ec
    move-exception v0

    move v10, p2

    move/from16 v11, p4

    move-object/from16 v2, p6

    move-object/from16 v1, p7

    goto :goto_95

    :goto_f5
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->e:Ljava/net/Socket;

    invoke-static {v0}, Lcom/mbridge/msdk/thrid/okhttp/internal/c;->a(Ljava/net/Socket;)V

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->d:Ljava/net/Socket;

    invoke-static {v0}, Lcom/mbridge/msdk/thrid/okhttp/internal/c;->a(Ljava/net/Socket;)V

    iput-object v8, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->e:Ljava/net/Socket;

    iput-object v8, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->d:Ljava/net/Socket;

    iput-object v8, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->i:Lcom/mbridge/msdk/thrid/okio/e;

    iput-object v8, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->j:Lcom/mbridge/msdk/thrid/okio/d;

    iput-object v8, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->f:Lcom/mbridge/msdk/thrid/okhttp/q;

    iput-object v8, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->g:Lcom/mbridge/msdk/thrid/okhttp/w;

    iput-object v8, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->h:Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g;

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/c0;->d()Ljava/net/InetSocketAddress;

    move-result-object v3

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/c0;->b()Ljava/net/Proxy;

    move-result-object v4

    const/4 v5, 0x0

    invoke-virtual/range {v1 .. v6}, Lcom/mbridge/msdk/thrid/okhttp/o;->connectFailed(Lcom/mbridge/msdk/thrid/okhttp/d;Ljava/net/InetSocketAddress;Ljava/net/Proxy;Lcom/mbridge/msdk/thrid/okhttp/w;Ljava/io/IOException;)V

    if-nez v9, :cond_125

    new-instance v9, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/e;

    invoke-direct {v9, v6}, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/e;-><init>(Ljava/io/IOException;)V

    goto :goto_128

    :cond_125
    invoke-virtual {v9, v6}, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/e;->a(Ljava/io/IOException;)V

    :goto_128
    if-eqz p5, :cond_132

    invoke-virtual {v7, v6}, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/b;->a(Ljava/io/IOException;)Z

    move-result v0

    if-eqz v0, :cond_132

    goto/16 :goto_74

    :cond_132
    throw v9

    :cond_133
    new-instance p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/e;

    new-instance p1, Ljava/net/UnknownServiceException;

    const-string p2, "H2_PRIOR_KNOWLEDGE cannot be used with HTTPS"

    invoke-direct {p1, p2}, Ljava/net/UnknownServiceException;-><init>(Ljava/lang/String;)V

    invoke-direct {p0, p1}, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/e;-><init>(Ljava/io/IOException;)V

    throw p0

    :cond_140
    const-string p0, "already connected"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-void
.end method

.method public a(Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g;)V
    .registers 3

    .prologue
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->b:Lcom/mbridge/msdk/thrid/okhttp/i;

    monitor-enter v0

    :try_start_3
    invoke-virtual {p1}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g;->k()I

    move-result p1

    iput p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->m:I

    monitor-exit v0

    return-void

    :catchall_b
    move-exception p0

    monitor-exit v0
    :try_end_d
    .catchall {:try_start_3 .. :try_end_d} :catchall_b

    throw p0
.end method

.method public a(Lcom/mbridge/msdk/thrid/okhttp/internal/http2/i;)V
    .registers 2

    sget-object p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/b;->f:Lcom/mbridge/msdk/thrid/okhttp/internal/http2/b;

    invoke-virtual {p1, p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/i;->a(Lcom/mbridge/msdk/thrid/okhttp/internal/http2/b;)V

    return-void
.end method

.method public a(Lcom/mbridge/msdk/thrid/okhttp/a;Lcom/mbridge/msdk/thrid/okhttp/c0;)Z
    .registers 7

    .prologue
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->n:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    iget v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->m:I

    const/4 v2, 0x0

    if-ge v0, v1, :cond_a3

    iget-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->k:Z

    if-eqz v0, :cond_11

    goto/16 :goto_a3

    :cond_11
    sget-object v0, Lcom/mbridge/msdk/thrid/okhttp/internal/a;->a:Lcom/mbridge/msdk/thrid/okhttp/internal/a;

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okhttp/c0;->a()Lcom/mbridge/msdk/thrid/okhttp/a;

    move-result-object v1

    invoke-virtual {v0, v1, p1}, Lcom/mbridge/msdk/thrid/okhttp/internal/a;->a(Lcom/mbridge/msdk/thrid/okhttp/a;Lcom/mbridge/msdk/thrid/okhttp/a;)Z

    move-result v0

    if-nez v0, :cond_20

    return v2

    :cond_20
    invoke-virtual {p1}, Lcom/mbridge/msdk/thrid/okhttp/a;->k()Lcom/mbridge/msdk/thrid/okhttp/s;

    move-result-object v0

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/s;->g()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c()Lcom/mbridge/msdk/thrid/okhttp/c0;

    move-result-object v1

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okhttp/c0;->a()Lcom/mbridge/msdk/thrid/okhttp/a;

    move-result-object v1

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okhttp/a;->k()Lcom/mbridge/msdk/thrid/okhttp/s;

    move-result-object v1

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okhttp/s;->g()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_40

    return v1

    :cond_40
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->h:Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g;

    if-nez v0, :cond_45

    return v2

    :cond_45
    if-nez p2, :cond_48

    return v2

    :cond_48
    invoke-virtual {p2}, Lcom/mbridge/msdk/thrid/okhttp/c0;->b()Ljava/net/Proxy;

    move-result-object v0

    invoke-virtual {v0}, Ljava/net/Proxy;->type()Ljava/net/Proxy$Type;

    move-result-object v0

    sget-object v3, Ljava/net/Proxy$Type;->DIRECT:Ljava/net/Proxy$Type;

    if-eq v0, v3, :cond_55

    return v2

    :cond_55
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/c0;->b()Ljava/net/Proxy;

    move-result-object v0

    invoke-virtual {v0}, Ljava/net/Proxy;->type()Ljava/net/Proxy$Type;

    move-result-object v0

    if-eq v0, v3, :cond_62

    return v2

    :cond_62
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/c0;->d()Ljava/net/InetSocketAddress;

    move-result-object v0

    invoke-virtual {p2}, Lcom/mbridge/msdk/thrid/okhttp/c0;->d()Ljava/net/InetSocketAddress;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/net/InetSocketAddress;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_73

    return v2

    :cond_73
    invoke-virtual {p2}, Lcom/mbridge/msdk/thrid/okhttp/c0;->a()Lcom/mbridge/msdk/thrid/okhttp/a;

    move-result-object p2

    invoke-virtual {p2}, Lcom/mbridge/msdk/thrid/okhttp/a;->d()Ljavax/net/ssl/HostnameVerifier;

    move-result-object p2

    sget-object v0, Lcom/mbridge/msdk/thrid/okhttp/internal/tls/d;->a:Lcom/mbridge/msdk/thrid/okhttp/internal/tls/d;

    if-eq p2, v0, :cond_80

    return v2

    :cond_80
    invoke-virtual {p1}, Lcom/mbridge/msdk/thrid/okhttp/a;->k()Lcom/mbridge/msdk/thrid/okhttp/s;

    move-result-object p2

    invoke-virtual {p0, p2}, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->a(Lcom/mbridge/msdk/thrid/okhttp/s;)Z

    move-result p2

    if-nez p2, :cond_8b

    return v2

    :cond_8b
    :try_start_8b
    invoke-virtual {p1}, Lcom/mbridge/msdk/thrid/okhttp/a;->a()Lcom/mbridge/msdk/thrid/okhttp/f;

    move-result-object p2

    invoke-virtual {p1}, Lcom/mbridge/msdk/thrid/okhttp/a;->k()Lcom/mbridge/msdk/thrid/okhttp/s;

    move-result-object p1

    invoke-virtual {p1}, Lcom/mbridge/msdk/thrid/okhttp/s;->g()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->b()Lcom/mbridge/msdk/thrid/okhttp/q;

    move-result-object p0

    invoke-virtual {p0}, Lcom/mbridge/msdk/thrid/okhttp/q;->b()Ljava/util/List;

    move-result-object p0

    invoke-virtual {p2, p1, p0}, Lcom/mbridge/msdk/thrid/okhttp/f;->a(Ljava/lang/String;Ljava/util/List;)V
    :try_end_a2
    .catch Ljavax/net/ssl/SSLPeerUnverifiedException; {:try_start_8b .. :try_end_a2} :catch_a3

    return v1

    :catch_a3
    :cond_a3
    :goto_a3
    return v2
.end method

.method public a(Lcom/mbridge/msdk/thrid/okhttp/s;)Z
    .registers 5

    .prologue
    invoke-virtual {p1}, Lcom/mbridge/msdk/thrid/okhttp/s;->j()I

    move-result v0

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okhttp/c0;->a()Lcom/mbridge/msdk/thrid/okhttp/a;

    move-result-object v1

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okhttp/a;->k()Lcom/mbridge/msdk/thrid/okhttp/s;

    move-result-object v1

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okhttp/s;->j()I

    move-result v1

    const/4 v2, 0x0

    if-eq v0, v1, :cond_16

    return v2

    :cond_16
    invoke-virtual {p1}, Lcom/mbridge/msdk/thrid/okhttp/s;->g()Ljava/lang/String;

    move-result-object v0

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okhttp/c0;->a()Lcom/mbridge/msdk/thrid/okhttp/a;

    move-result-object v1

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okhttp/a;->k()Lcom/mbridge/msdk/thrid/okhttp/s;

    move-result-object v1

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okhttp/s;->g()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v1, 0x1

    if-nez v0, :cond_4d

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->f:Lcom/mbridge/msdk/thrid/okhttp/q;

    if-eqz v0, :cond_4c

    sget-object v0, Lcom/mbridge/msdk/thrid/okhttp/internal/tls/d;->a:Lcom/mbridge/msdk/thrid/okhttp/internal/tls/d;

    invoke-virtual {p1}, Lcom/mbridge/msdk/thrid/okhttp/s;->g()Ljava/lang/String;

    move-result-object p1

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->f:Lcom/mbridge/msdk/thrid/okhttp/q;

    invoke-virtual {p0}, Lcom/mbridge/msdk/thrid/okhttp/q;->b()Ljava/util/List;

    move-result-object p0

    invoke-interface {p0, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/security/cert/X509Certificate;

    invoke-virtual {v0, p1, p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/tls/d;->a(Ljava/lang/String;Ljava/security/cert/X509Certificate;)Z

    move-result p0

    if-eqz p0, :cond_4c

    return v1

    :cond_4c
    return v2

    :cond_4d
    return v1
.end method

.method public a(Z)Z
    .registers 5

    .prologue
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->e:Ljava/net/Socket;

    invoke-virtual {v0}, Ljava/net/Socket;->isClosed()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_50

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->e:Ljava/net/Socket;

    invoke-virtual {v0}, Ljava/net/Socket;->isInputShutdown()Z

    move-result v0

    if-nez v0, :cond_50

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->e:Ljava/net/Socket;

    invoke-virtual {v0}, Ljava/net/Socket;->isOutputShutdown()Z

    move-result v0

    if-eqz v0, :cond_1a

    goto :goto_50

    :cond_1a
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->h:Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g;

    if-eqz v0, :cond_27

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide p0

    invoke-virtual {v0, p0, p1}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g;->f(J)Z

    move-result p0

    return p0

    :cond_27
    const/4 v0, 0x1

    if-eqz p1, :cond_4f

    :try_start_2a
    iget-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->e:Ljava/net/Socket;

    invoke-virtual {p1}, Ljava/net/Socket;->getSoTimeout()I

    move-result p1
    :try_end_30
    .catch Ljava/net/SocketTimeoutException; {:try_start_2a .. :try_end_30} :catch_4f
    .catch Ljava/io/IOException; {:try_start_2a .. :try_end_30} :catch_4e

    :try_start_30
    iget-object v2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->e:Ljava/net/Socket;

    invoke-virtual {v2, v0}, Ljava/net/Socket;->setSoTimeout(I)V

    iget-object v2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->i:Lcom/mbridge/msdk/thrid/okio/e;

    invoke-interface {v2}, Lcom/mbridge/msdk/thrid/okio/e;->f()Z

    move-result v2
    :try_end_3b
    .catchall {:try_start_30 .. :try_end_3b} :catchall_47

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->e:Ljava/net/Socket;

    if-eqz v2, :cond_43

    :try_start_3f
    invoke-virtual {p0, p1}, Ljava/net/Socket;->setSoTimeout(I)V

    return v1

    :cond_43
    invoke-virtual {p0, p1}, Ljava/net/Socket;->setSoTimeout(I)V

    return v0

    :catchall_47
    move-exception v2

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->e:Ljava/net/Socket;

    invoke-virtual {p0, p1}, Ljava/net/Socket;->setSoTimeout(I)V

    throw v2
    :try_end_4e
    .catch Ljava/net/SocketTimeoutException; {:try_start_3f .. :try_end_4e} :catch_4f
    .catch Ljava/io/IOException; {:try_start_3f .. :try_end_4e} :catch_4e

    :catch_4e
    return v1

    :catch_4f
    :cond_4f
    return v0

    :cond_50
    :goto_50
    return v1
.end method

.method public b()Lcom/mbridge/msdk/thrid/okhttp/q;
    .registers 1

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->f:Lcom/mbridge/msdk/thrid/okhttp/q;

    return-object p0
.end method

.method public c()Lcom/mbridge/msdk/thrid/okhttp/c0;
    .registers 1

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    return-object p0
.end method

.method public d()V
    .registers 1

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->d:Ljava/net/Socket;

    invoke-static {p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/c;->a(Ljava/net/Socket;)V

    return-void
.end method

.method public f()Z
    .registers 1

    .prologue
    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->h:Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g;

    if-eqz p0, :cond_6

    const/4 p0, 0x1

    return p0

    :cond_6
    const/4 p0, 0x0

    return p0
.end method

.method public g()Ljava/net/Socket;
    .registers 1

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->e:Ljava/net/Socket;

    return-object p0
.end method

.method public toString()Ljava/lang/String;
    .registers 3

    .prologue
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Connection{"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okhttp/c0;->a()Lcom/mbridge/msdk/thrid/okhttp/a;

    move-result-object v1

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okhttp/a;->k()Lcom/mbridge/msdk/thrid/okhttp/s;

    move-result-object v1

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okhttp/s;->g()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ":"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okhttp/c0;->a()Lcom/mbridge/msdk/thrid/okhttp/a;

    move-result-object v1

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okhttp/a;->k()Lcom/mbridge/msdk/thrid/okhttp/s;

    move-result-object v1

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okhttp/s;->j()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", proxy="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okhttp/c0;->b()Ljava/net/Proxy;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, " hostAddress="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->c:Lcom/mbridge/msdk/thrid/okhttp/c0;

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okhttp/c0;->d()Ljava/net/InetSocketAddress;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, " cipherSuite="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->f:Lcom/mbridge/msdk/thrid/okhttp/q;

    if-eqz v1, :cond_58

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okhttp/q;->a()Lcom/mbridge/msdk/thrid/okhttp/g;

    move-result-object v1

    goto :goto_5a

    :cond_58
    const-string v1, "none"

    :goto_5a
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, " protocol="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/connection/c;->g:Lcom/mbridge/msdk/thrid/okhttp/w;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 p0, 0x7d

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
