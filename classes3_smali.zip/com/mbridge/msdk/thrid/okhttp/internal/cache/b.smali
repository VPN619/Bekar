.class public final Lcom/mbridge/msdk/thrid/okhttp/internal/cache/b;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/mbridge/msdk/thrid/okhttp/internal/cache/b$a;
    }
.end annotation


# instance fields
.field public final a:Lcom/mbridge/msdk/thrid/okhttp/y;

.field public final b:Lcom/mbridge/msdk/thrid/okhttp/a0;


# direct methods
.method public constructor <init>(Lcom/mbridge/msdk/thrid/okhttp/y;Lcom/mbridge/msdk/thrid/okhttp/a0;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/cache/b;->a:Lcom/mbridge/msdk/thrid/okhttp/y;

    iput-object p2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/cache/b;->b:Lcom/mbridge/msdk/thrid/okhttp/a0;

    return-void
.end method

.method public static a(Lcom/mbridge/msdk/thrid/okhttp/a0;Lcom/mbridge/msdk/thrid/okhttp/y;)Z
    .registers 5

    .prologue
    invoke-virtual {p0}, Lcom/mbridge/msdk/thrid/okhttp/a0;->k()I

    move-result v0

    const/16 v1, 0xc8

    const/4 v2, 0x0

    if-eq v0, v1, :cond_5a

    const/16 v1, 0x19a

    if-eq v0, v1, :cond_5a

    const/16 v1, 0x19e

    if-eq v0, v1, :cond_5a

    const/16 v1, 0x1f5

    if-eq v0, v1, :cond_5a

    const/16 v1, 0xcb

    if-eq v0, v1, :cond_5a

    const/16 v1, 0xcc

    if-eq v0, v1, :cond_5a

    const/16 v1, 0x133

    if-eq v0, v1, :cond_31

    const/16 v1, 0x134

    if-eq v0, v1, :cond_5a

    const/16 v1, 0x194

    if-eq v0, v1, :cond_5a

    const/16 v1, 0x195

    if-eq v0, v1, :cond_5a

    packed-switch v0, :pswitch_data_72

    goto :goto_59

    :cond_31
    :pswitch_31  #0x12e
    const-string v0, "Expires"

    invoke-virtual {p0, v0}, Lcom/mbridge/msdk/thrid/okhttp/a0;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_5a

    invoke-virtual {p0}, Lcom/mbridge/msdk/thrid/okhttp/a0;->h()Lcom/mbridge/msdk/thrid/okhttp/c;

    move-result-object v0

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/c;->d()I

    move-result v0

    const/4 v1, -0x1

    if-ne v0, v1, :cond_5a

    invoke-virtual {p0}, Lcom/mbridge/msdk/thrid/okhttp/a0;->h()Lcom/mbridge/msdk/thrid/okhttp/c;

    move-result-object v0

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/c;->c()Z

    move-result v0

    if-nez v0, :cond_5a

    invoke-virtual {p0}, Lcom/mbridge/msdk/thrid/okhttp/a0;->h()Lcom/mbridge/msdk/thrid/okhttp/c;

    move-result-object v0

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/c;->b()Z

    move-result v0

    if-eqz v0, :cond_59

    goto :goto_5a

    :cond_59
    :goto_59
    return v2

    :cond_5a
    :goto_5a
    :pswitch_5a  #0x12c, 0x12d
    invoke-virtual {p0}, Lcom/mbridge/msdk/thrid/okhttp/a0;->h()Lcom/mbridge/msdk/thrid/okhttp/c;

    move-result-object p0

    invoke-virtual {p0}, Lcom/mbridge/msdk/thrid/okhttp/c;->i()Z

    move-result p0

    if-nez p0, :cond_70

    invoke-virtual {p1}, Lcom/mbridge/msdk/thrid/okhttp/y;->b()Lcom/mbridge/msdk/thrid/okhttp/c;

    move-result-object p0

    invoke-virtual {p0}, Lcom/mbridge/msdk/thrid/okhttp/c;->i()Z

    move-result p0

    if-nez p0, :cond_70

    const/4 p0, 0x1

    return p0

    :cond_70
    return v2

    nop

    :pswitch_data_72
    .packed-switch 0x12c
        :pswitch_5a  #0000012c
        :pswitch_5a  #0000012d
        :pswitch_31  #0000012e
    .end packed-switch
.end method
