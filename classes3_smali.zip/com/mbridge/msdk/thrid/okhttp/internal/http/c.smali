.class public interface abstract Lcom/mbridge/msdk/thrid/okhttp/internal/http/c;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# virtual methods
.method public abstract a(Z)Lcom/mbridge/msdk/thrid/okhttp/a0$a;
.end method

.method public abstract a(Lcom/mbridge/msdk/thrid/okhttp/a0;)Lcom/mbridge/msdk/thrid/okhttp/b0;
.end method

.method public abstract a(Lcom/mbridge/msdk/thrid/okhttp/y;J)Lcom/mbridge/msdk/thrid/okio/r;
.end method

.method public abstract a()V
.end method

.method public abstract a(Lcom/mbridge/msdk/thrid/okhttp/y;)V
.end method

.method public abstract b()V
.end method

.method public abstract cancel()V
.end method
