.class final Lcom/mbridge/msdk/thrid/okhttp/internal/http/b$a;
.super Lcom/mbridge/msdk/thrid/okio/g;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/mbridge/msdk/thrid/okhttp/internal/http/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field b:J


# direct methods
.method public constructor <init>(Lcom/mbridge/msdk/thrid/okio/r;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/mbridge/msdk/thrid/okio/g;-><init>(Lcom/mbridge/msdk/thrid/okio/r;)V

    return-void
.end method


# virtual methods
.method public a(Lcom/mbridge/msdk/thrid/okio/c;J)V
    .registers 6

    invoke-super {p0, p1, p2, p3}, Lcom/mbridge/msdk/thrid/okio/g;->a(Lcom/mbridge/msdk/thrid/okio/c;J)V

    iget-wide v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http/b$a;->b:J

    add-long/2addr v0, p2

    iput-wide v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http/b$a;->b:J

    return-void
.end method
