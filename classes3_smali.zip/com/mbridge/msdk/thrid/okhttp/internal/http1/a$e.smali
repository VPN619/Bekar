.class final Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$e;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lcom/mbridge/msdk/thrid/okio/r;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x11
    name = "e"
.end annotation


# instance fields
.field private final a:Lcom/mbridge/msdk/thrid/okio/i;

.field private b:Z

.field private c:J

.field final synthetic d:Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;


# direct methods
.method public constructor <init>(Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;J)V
    .registers 5

    iput-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$e;->d:Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lcom/mbridge/msdk/thrid/okio/i;

    iget-object p1, p1, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;->d:Lcom/mbridge/msdk/thrid/okio/d;

    invoke-interface {p1}, Lcom/mbridge/msdk/thrid/okio/r;->b()Lcom/mbridge/msdk/thrid/okio/t;

    move-result-object p1

    invoke-direct {v0, p1}, Lcom/mbridge/msdk/thrid/okio/i;-><init>(Lcom/mbridge/msdk/thrid/okio/t;)V

    iput-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$e;->a:Lcom/mbridge/msdk/thrid/okio/i;

    iput-wide p2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$e;->c:J

    return-void
.end method


# virtual methods
.method public a(Lcom/mbridge/msdk/thrid/okio/c;J)V
    .registers 11

    .prologue
    iget-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$e;->b:Z

    if-nez v0, :cond_3f

    invoke-virtual {p1}, Lcom/mbridge/msdk/thrid/okio/c;->size()J

    move-result-wide v1

    const-wide/16 v3, 0x0

    move-wide v5, p2

    invoke-static/range {v1 .. v6}, Lcom/mbridge/msdk/thrid/okhttp/internal/c;->a(JJJ)V

    iget-wide p2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$e;->c:J

    cmp-long p2, v5, p2

    if-gtz p2, :cond_21

    iget-object p2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$e;->d:Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;

    iget-object p2, p2, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;->d:Lcom/mbridge/msdk/thrid/okio/d;

    invoke-interface {p2, p1, v5, v6}, Lcom/mbridge/msdk/thrid/okio/r;->a(Lcom/mbridge/msdk/thrid/okio/c;J)V

    iget-wide p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$e;->c:J

    sub-long/2addr p1, v5

    iput-wide p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$e;->c:J

    return-void

    :cond_21
    new-instance p1, Ljava/net/ProtocolException;

    iget-wide p2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$e;->c:J

    new-instance p0, Ljava/lang/StringBuilder;

    const-string v0, "expected "

    invoke-direct {p0, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string p2, " bytes but received "

    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_3f
    const-string p0, "closed"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-void
.end method

.method public b()Lcom/mbridge/msdk/thrid/okio/t;
    .registers 1

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$e;->a:Lcom/mbridge/msdk/thrid/okio/i;

    return-object p0
.end method

.method public close()V
    .registers 5

    .prologue
    iget-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$e;->b:Z

    if-eqz v0, :cond_5

    return-void

    :cond_5
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$e;->b:Z

    iget-wide v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$e;->c:J

    const-wide/16 v2, 0x0

    cmp-long v0, v0, v2

    if-gtz v0, :cond_1d

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$e;->d:Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$e;->a:Lcom/mbridge/msdk/thrid/okio/i;

    invoke-virtual {v0, v1}, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;->a(Lcom/mbridge/msdk/thrid/okio/i;)V

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$e;->d:Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;

    const/4 v0, 0x3

    iput v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;->e:I

    return-void

    :cond_1d
    new-instance p0, Ljava/net/ProtocolException;

    const-string v0, "unexpected end of stream"

    invoke-direct {p0, v0}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public flush()V
    .registers 2

    .prologue
    iget-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$e;->b:Z

    if-eqz v0, :cond_5

    return-void

    :cond_5
    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$e;->d:Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;->d:Lcom/mbridge/msdk/thrid/okio/d;

    invoke-interface {p0}, Lcom/mbridge/msdk/thrid/okio/d;->flush()V

    return-void
.end method
