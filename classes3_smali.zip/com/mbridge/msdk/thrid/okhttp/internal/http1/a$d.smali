.class Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$d;
.super Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$b;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "d"
.end annotation


# instance fields
.field private final e:Lcom/mbridge/msdk/thrid/okhttp/s;

.field private f:J

.field private g:Z

.field final synthetic h:Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;


# direct methods
.method public constructor <init>(Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;Lcom/mbridge/msdk/thrid/okhttp/s;)V
    .registers 5

    iput-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$d;->h:Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;

    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$b;-><init>(Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$a;)V

    const-wide/16 v0, -0x1

    iput-wide v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$d;->f:J

    const/4 p1, 0x1

    iput-boolean p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$d;->g:Z

    iput-object p2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$d;->e:Lcom/mbridge/msdk/thrid/okhttp/s;

    return-void
.end method

.method private d()V
    .registers 7

    .prologue
    const-string v0, "expected chunk size and optional extensions but was \""

    iget-wide v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$d;->f:J

    const-wide/16 v3, -0x1

    cmp-long v1, v1, v3

    if-eqz v1, :cond_11

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$d;->h:Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;

    iget-object v1, v1, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;->c:Lcom/mbridge/msdk/thrid/okio/e;

    invoke-interface {v1}, Lcom/mbridge/msdk/thrid/okio/e;->c()Ljava/lang/String;

    :cond_11
    :try_start_11
    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$d;->h:Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;

    iget-object v1, v1, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;->c:Lcom/mbridge/msdk/thrid/okio/e;

    invoke-interface {v1}, Lcom/mbridge/msdk/thrid/okio/e;->i()J

    move-result-wide v1

    iput-wide v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$d;->f:J

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$d;->h:Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;

    iget-object v1, v1, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;->c:Lcom/mbridge/msdk/thrid/okio/e;

    invoke-interface {v1}, Lcom/mbridge/msdk/thrid/okio/e;->c()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    iget-wide v2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$d;->f:J

    const-wide/16 v4, 0x0

    cmp-long v2, v2, v4

    if-ltz v2, :cond_5f

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_3d

    const-string v2, ";"

    invoke-virtual {v1, v2}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v2
    :try_end_3b
    .catch Ljava/lang/NumberFormatException; {:try_start_11 .. :try_end_3b} :catch_7b

    if-eqz v2, :cond_5f

    :cond_3d
    iget-wide v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$d;->f:J

    cmp-long v0, v0, v4

    if-nez v0, :cond_5e

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$d;->g:Z

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$d;->h:Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;

    iget-object v0, v0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;->a:Lcom/mbridge/msdk/thrid/okhttp/v;

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/v;->i()Lcom/mbridge/msdk/thrid/okhttp/l;

    move-result-object v0

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$d;->e:Lcom/mbridge/msdk/thrid/okhttp/s;

    iget-object v2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$d;->h:Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;

    invoke-virtual {v2}, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a;->f()Lcom/mbridge/msdk/thrid/okhttp/r;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lcom/mbridge/msdk/thrid/okhttp/internal/http/e;->a(Lcom/mbridge/msdk/thrid/okhttp/l;Lcom/mbridge/msdk/thrid/okhttp/s;Lcom/mbridge/msdk/thrid/okhttp/r;)V

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$b;->a(ZLjava/io/IOException;)V

    :cond_5e
    return-void

    :cond_5f
    :try_start_5f
    new-instance v2, Ljava/net/ProtocolException;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-wide v4, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$d;->f:J

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, "\""

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v2, p0}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V

    throw v2
    :try_end_7b
    .catch Ljava/lang/NumberFormatException; {:try_start_5f .. :try_end_7b} :catch_7b

    :catch_7b
    move-exception p0

    new-instance v0, Ljava/net/ProtocolException;

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V

    throw v0
.end method


# virtual methods
.method public b(Lcom/mbridge/msdk/thrid/okio/c;J)J
    .registers 11

    .prologue
    const-wide/16 v0, 0x0

    cmp-long v2, p2, v0

    if-ltz v2, :cond_4b

    iget-boolean v2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$b;->b:Z

    if-nez v2, :cond_43

    iget-boolean v2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$d;->g:Z

    const-wide/16 v3, -0x1

    if-nez v2, :cond_11

    return-wide v3

    :cond_11
    iget-wide v5, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$d;->f:J

    cmp-long v0, v5, v0

    if-eqz v0, :cond_1b

    cmp-long v0, v5, v3

    if-nez v0, :cond_23

    :cond_1b
    invoke-direct {p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$d;->d()V

    iget-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$d;->g:Z

    if-nez v0, :cond_23

    return-wide v3

    :cond_23
    iget-wide v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$d;->f:J

    invoke-static {p2, p3, v0, v1}, Ljava/lang/Math;->min(JJ)J

    move-result-wide p2

    invoke-super {p0, p1, p2, p3}, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$b;->b(Lcom/mbridge/msdk/thrid/okio/c;J)J

    move-result-wide p1

    cmp-long p3, p1, v3

    if-eqz p3, :cond_37

    iget-wide v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$d;->f:J

    sub-long/2addr v0, p1

    iput-wide v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$d;->f:J

    return-wide p1

    :cond_37
    new-instance p1, Ljava/net/ProtocolException;

    const-string p2, "unexpected end of stream"

    invoke-direct {p1, p2}, Ljava/net/ProtocolException;-><init>(Ljava/lang/String;)V

    const/4 p2, 0x0

    invoke-virtual {p0, p2, p1}, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$b;->a(ZLjava/io/IOException;)V

    throw p1

    :cond_43
    const-string p0, "closed"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    :goto_48
    const-wide/16 p0, 0x0

    return-wide p0

    :cond_4b
    const-string p0, "byteCount < 0: "

    invoke-static {p2, p3, p0}, Lmz2;->j(JLjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->s(Ljava/lang/String;)V

    goto :goto_48
.end method

.method public close()V
    .registers 3

    .prologue
    iget-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$b;->b:Z

    if-eqz v0, :cond_5

    return-void

    :cond_5
    iget-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$d;->g:Z

    if-eqz v0, :cond_18

    sget-object v0, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const/16 v1, 0x64

    invoke-static {p0, v1, v0}, Lcom/mbridge/msdk/thrid/okhttp/internal/c;->a(Lcom/mbridge/msdk/thrid/okio/s;ILjava/util/concurrent/TimeUnit;)Z

    move-result v0

    if-nez v0, :cond_18

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$b;->a(ZLjava/io/IOException;)V

    :cond_18
    const/4 v0, 0x1

    iput-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http1/a$b;->b:Z

    return-void
.end method
