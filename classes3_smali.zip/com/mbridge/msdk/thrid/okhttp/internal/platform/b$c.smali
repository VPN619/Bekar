.class final Lcom/mbridge/msdk/thrid/okhttp/internal/platform/b$c;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/mbridge/msdk/thrid/okhttp/internal/platform/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "c"
.end annotation


# instance fields
.field private final a:Ljava/lang/reflect/Method;

.field private final b:Ljava/lang/reflect/Method;

.field private final c:Ljava/lang/reflect/Method;


# direct methods
.method public constructor <init>(Ljava/lang/reflect/Method;Ljava/lang/reflect/Method;Ljava/lang/reflect/Method;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/platform/b$c;->a:Ljava/lang/reflect/Method;

    iput-object p2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/platform/b$c;->b:Ljava/lang/reflect/Method;

    iput-object p3, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/platform/b$c;->c:Ljava/lang/reflect/Method;

    return-void
.end method

.method public static a()Lcom/mbridge/msdk/thrid/okhttp/internal/platform/b$c;
    .registers 5

    .prologue
    const/4 v0, 0x0

    :try_start_1
    const-string v1, "dalvik.system.CloseGuard"

    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1

    const-string v2, "get"

    invoke-virtual {v1, v2, v0}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    const-string v3, "open"

    const-class v4, Ljava/lang/String;

    filled-new-array {v4}, [Ljava/lang/Class;

    move-result-object v4

    invoke-virtual {v1, v3, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v3

    const-string v4, "warnIfOpen"

    invoke-virtual {v1, v4, v0}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0
    :try_end_1f
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1f} :catch_22

    move-object v1, v0

    move-object v0, v2

    goto :goto_24

    :catch_22
    move-object v1, v0

    move-object v3, v1

    :goto_24
    new-instance v2, Lcom/mbridge/msdk/thrid/okhttp/internal/platform/b$c;

    invoke-direct {v2, v0, v3, v1}, Lcom/mbridge/msdk/thrid/okhttp/internal/platform/b$c;-><init>(Ljava/lang/reflect/Method;Ljava/lang/reflect/Method;Ljava/lang/reflect/Method;)V

    return-object v2
.end method


# virtual methods
.method public a(Ljava/lang/String;)Ljava/lang/Object;
    .registers 4

    .prologue
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/platform/b$c;->a:Ljava/lang/reflect/Method;

    const/4 v1, 0x0

    if-eqz v0, :cond_13

    :try_start_5
    invoke-virtual {v0, v1, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/platform/b$c;->b:Ljava/lang/reflect/Method;

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object p1

    invoke-virtual {p0, v0, p1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_12
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_12} :catch_13

    return-object v0

    :catch_13
    :cond_13
    return-object v1
.end method

.method public a(Ljava/lang/Object;)Z
    .registers 3

    .prologue
    if-eqz p1, :cond_a

    :try_start_2
    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/platform/b$c;->c:Ljava/lang/reflect/Method;

    const/4 v0, 0x0

    invoke-virtual {p0, p1, v0}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_8} :catch_a

    const/4 p0, 0x1

    return p0

    :catch_a
    :cond_a
    const/4 p0, 0x0

    return p0
.end method
