.class Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$f;
.super Lcom/mbridge/msdk/thrid/okhttp/internal/b;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g;->a(ILcom/mbridge/msdk/thrid/okio/e;IZ)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field final synthetic b:I

.field final synthetic c:Lcom/mbridge/msdk/thrid/okio/c;

.field final synthetic d:I

.field final synthetic e:Z

.field final synthetic f:Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g;


# direct methods
.method public varargs constructor <init>(Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g;Ljava/lang/String;[Ljava/lang/Object;ILcom/mbridge/msdk/thrid/okio/c;IZ)V
    .registers 8

    iput-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$f;->f:Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g;

    iput p4, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$f;->b:I

    iput-object p5, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$f;->c:Lcom/mbridge/msdk/thrid/okio/c;

    iput p6, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$f;->d:I

    iput-boolean p7, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$f;->e:Z

    invoke-direct {p0, p2, p3}, Lcom/mbridge/msdk/thrid/okhttp/internal/b;-><init>(Ljava/lang/String;[Ljava/lang/Object;)V

    return-void
.end method


# virtual methods
.method public b()V
    .registers 6

    .prologue
    :try_start_0
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$f;->f:Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g;

    iget-object v0, v0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g;->j:Lcom/mbridge/msdk/thrid/okhttp/internal/http2/l;

    iget v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$f;->b:I

    iget-object v2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$f;->c:Lcom/mbridge/msdk/thrid/okio/c;

    iget v3, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$f;->d:I

    iget-boolean v4, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$f;->e:Z

    invoke-interface {v0, v1, v2, v3, v4}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/l;->a(ILcom/mbridge/msdk/thrid/okio/e;IZ)Z

    move-result v0

    if-eqz v0, :cond_1d

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$f;->f:Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g;

    iget-object v1, v1, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g;->w:Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;

    iget v2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$f;->b:I

    sget-object v3, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/b;->g:Lcom/mbridge/msdk/thrid/okhttp/internal/http2/b;

    invoke-virtual {v1, v2, v3}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a(ILcom/mbridge/msdk/thrid/okhttp/internal/http2/b;)V

    :cond_1d
    if-nez v0, :cond_23

    iget-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$f;->e:Z

    if-eqz v0, :cond_38

    :cond_23
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$f;->f:Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g;

    monitor-enter v0
    :try_end_26
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_26} :catch_38

    :try_start_26
    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$f;->f:Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g;

    iget-object v1, v1, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g;->y:Ljava/util/Set;

    iget p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$f;->b:I

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    invoke-interface {v1, p0}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    monitor-exit v0

    return-void

    :catchall_35
    move-exception p0

    monitor-exit v0
    :try_end_37
    .catchall {:try_start_26 .. :try_end_37} :catchall_35

    :try_start_37
    throw p0
    :try_end_38
    .catch Ljava/io/IOException; {:try_start_37 .. :try_end_38} :catch_38

    :catch_38
    :cond_38
    return-void
.end method
