.class public abstract Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$j;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "j"
.end annotation


# static fields
.field public static final a:Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$j;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$j$a;

    invoke-direct {v0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$j$a;-><init>()V

    sput-object v0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$j;->a:Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$j;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g;)V
    .registers 2

    return-void
.end method

.method public abstract a(Lcom/mbridge/msdk/thrid/okhttp/internal/http2/i;)V
.end method
