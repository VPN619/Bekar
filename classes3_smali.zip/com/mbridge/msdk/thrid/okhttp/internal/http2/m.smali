.class public final Lcom/mbridge/msdk/thrid/okhttp/internal/http2/m;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field private a:I

.field private final b:[I


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0xa

    new-array v0, v0, [I

    iput-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/m;->b:[I

    return-void
.end method


# virtual methods
.method public a(I)I
    .registers 2

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/m;->b:[I

    aget p0, p0, p1

    return p0
.end method

.method public a(II)Lcom/mbridge/msdk/thrid/okhttp/internal/http2/m;
    .registers 6

    .prologue
    if-ltz p1, :cond_11

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/m;->b:[I

    array-length v1, v0

    if-lt p1, v1, :cond_8

    goto :goto_11

    :cond_8
    const/4 v1, 0x1

    shl-int/2addr v1, p1

    iget v2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/m;->a:I

    or-int/2addr v1, v2

    iput v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/m;->a:I

    aput p2, v0, p1

    :cond_11
    :goto_11
    return-object p0
.end method

.method public a()V
    .registers 2

    const/4 v0, 0x0

    iput v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/m;->a:I

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/m;->b:[I

    invoke-static {p0, v0}, Ljava/util/Arrays;->fill([II)V

    return-void
.end method

.method public a(Lcom/mbridge/msdk/thrid/okhttp/internal/http2/m;)V
    .registers 4

    .prologue
    const/4 v0, 0x0

    :goto_1
    const/16 v1, 0xa

    if-ge v0, v1, :cond_16

    invoke-virtual {p1, v0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/m;->d(I)Z

    move-result v1

    if-nez v1, :cond_c

    goto :goto_13

    :cond_c
    invoke-virtual {p1, v0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/m;->a(I)I

    move-result v1

    invoke-virtual {p0, v0, v1}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/m;->a(II)Lcom/mbridge/msdk/thrid/okhttp/internal/http2/m;

    :goto_13
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_16
    return-void
.end method

.method public b()I
    .registers 2

    .prologue
    iget v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/m;->a:I

    and-int/lit8 v0, v0, 0x2

    if-eqz v0, :cond_c

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/m;->b:[I

    const/4 v0, 0x1

    aget p0, p0, v0

    return p0

    :cond_c
    const/4 p0, -0x1

    return p0
.end method

.method public b(I)I
    .registers 3

    .prologue
    iget v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/m;->a:I

    and-int/lit8 v0, v0, 0x10

    if-eqz v0, :cond_c

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/m;->b:[I

    const/4 p1, 0x4

    aget p0, p0, p1

    return p0

    :cond_c
    return p1
.end method

.method public c()I
    .registers 2

    .prologue
    iget v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/m;->a:I

    and-int/lit16 v0, v0, 0x80

    if-eqz v0, :cond_c

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/m;->b:[I

    const/4 v0, 0x7

    aget p0, p0, v0

    return p0

    :cond_c
    const p0, 0xffff

    return p0
.end method

.method public c(I)I
    .registers 3

    .prologue
    iget v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/m;->a:I

    and-int/lit8 v0, v0, 0x20

    if-eqz v0, :cond_c

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/m;->b:[I

    const/4 p1, 0x5

    aget p0, p0, p1

    return p0

    :cond_c
    return p1
.end method

.method public d()I
    .registers 1

    iget p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/m;->a:I

    invoke-static {p0}, Ljava/lang/Integer;->bitCount(I)I

    move-result p0

    return p0
.end method

.method public d(I)Z
    .registers 3

    .prologue
    const/4 v0, 0x1

    shl-int p1, v0, p1

    iget p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/m;->a:I

    and-int/2addr p0, p1

    if-eqz p0, :cond_9

    return v0

    :cond_9
    const/4 p0, 0x0

    return p0
.end method
