.class final Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ljava/io/Closeable;


# static fields
.field private static final g:Ljava/util/logging/Logger;


# instance fields
.field private final a:Lcom/mbridge/msdk/thrid/okio/d;

.field private final b:Z

.field private final c:Lcom/mbridge/msdk/thrid/okio/c;

.field private d:I

.field private e:Z

.field final f:Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$b;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/e;

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/util/logging/Logger;->getLogger(Ljava/lang/String;)Ljava/util/logging/Logger;

    move-result-object v0

    sput-object v0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->g:Ljava/util/logging/Logger;

    return-void
.end method

.method public constructor <init>(Lcom/mbridge/msdk/thrid/okio/d;Z)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a:Lcom/mbridge/msdk/thrid/okio/d;

    iput-boolean p2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->b:Z

    new-instance p1, Lcom/mbridge/msdk/thrid/okio/c;

    invoke-direct {p1}, Lcom/mbridge/msdk/thrid/okio/c;-><init>()V

    iput-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->c:Lcom/mbridge/msdk/thrid/okio/c;

    new-instance p2, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$b;

    invoke-direct {p2, p1}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$b;-><init>(Lcom/mbridge/msdk/thrid/okio/c;)V

    iput-object p2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->f:Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$b;

    const/16 p1, 0x4000

    iput p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->d:I

    return-void
.end method

.method private static a(Lcom/mbridge/msdk/thrid/okio/d;I)V
    .registers 3

    ushr-int/lit8 v0, p1, 0x10

    and-int/lit16 v0, v0, 0xff

    invoke-interface {p0, v0}, Lcom/mbridge/msdk/thrid/okio/d;->writeByte(I)Lcom/mbridge/msdk/thrid/okio/d;

    ushr-int/lit8 v0, p1, 0x8

    and-int/lit16 v0, v0, 0xff

    invoke-interface {p0, v0}, Lcom/mbridge/msdk/thrid/okio/d;->writeByte(I)Lcom/mbridge/msdk/thrid/okio/d;

    and-int/lit16 p1, p1, 0xff

    invoke-interface {p0, p1}, Lcom/mbridge/msdk/thrid/okio/d;->writeByte(I)Lcom/mbridge/msdk/thrid/okio/d;

    return-void
.end method

.method private b(IJ)V
    .registers 9

    .prologue
    :goto_0
    const-wide/16 v0, 0x0

    cmp-long v2, p2, v0

    if-lez v2, :cond_24

    iget v2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->d:I

    int-to-long v2, v2

    invoke-static {v2, v3, p2, p3}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v2

    long-to-int v2, v2

    int-to-long v3, v2

    sub-long/2addr p2, v3

    cmp-long v0, p2, v0

    if-nez v0, :cond_16

    const/4 v0, 0x4

    goto :goto_17

    :cond_16
    const/4 v0, 0x0

    :goto_17
    const/16 v1, 0x9

    invoke-virtual {p0, p1, v2, v1, v0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a(IIBB)V

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a:Lcom/mbridge/msdk/thrid/okio/d;

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->c:Lcom/mbridge/msdk/thrid/okio/c;

    invoke-interface {v0, v1, v3, v4}, Lcom/mbridge/msdk/thrid/okio/r;->a(Lcom/mbridge/msdk/thrid/okio/c;J)V

    goto :goto_0

    :cond_24
    return-void
.end method


# virtual methods
.method public a(IBLcom/mbridge/msdk/thrid/okio/c;I)V
    .registers 6

    .prologue
    const/4 v0, 0x0

    invoke-virtual {p0, p1, p4, v0, p2}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a(IIBB)V

    if-lez p4, :cond_c

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a:Lcom/mbridge/msdk/thrid/okio/d;

    int-to-long p1, p4

    invoke-interface {p0, p3, p1, p2}, Lcom/mbridge/msdk/thrid/okio/r;->a(Lcom/mbridge/msdk/thrid/okio/c;J)V

    :cond_c
    return-void
.end method

.method public a(IIBB)V
    .registers 7

    .prologue
    sget-object v0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->g:Ljava/util/logging/Logger;

    sget-object v1, Ljava/util/logging/Level;->FINE:Ljava/util/logging/Level;

    invoke-virtual {v0, v1}, Ljava/util/logging/Logger;->isLoggable(Ljava/util/logging/Level;)Z

    move-result v1

    if-eqz v1, :cond_12

    const/4 v1, 0x0

    invoke-static {v1, p1, p2, p3, p4}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/e;->a(ZIIBB)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/logging/Logger;->fine(Ljava/lang/String;)V

    :cond_12
    iget v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->d:I

    if-gt p2, v0, :cond_47

    const/high16 v0, -0x80000000

    and-int/2addr v0, p1

    if-nez v0, :cond_38

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a:Lcom/mbridge/msdk/thrid/okio/d;

    invoke-static {v0, p2}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a(Lcom/mbridge/msdk/thrid/okio/d;I)V

    iget-object p2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a:Lcom/mbridge/msdk/thrid/okio/d;

    and-int/lit16 p3, p3, 0xff

    invoke-interface {p2, p3}, Lcom/mbridge/msdk/thrid/okio/d;->writeByte(I)Lcom/mbridge/msdk/thrid/okio/d;

    iget-object p2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a:Lcom/mbridge/msdk/thrid/okio/d;

    and-int/lit16 p3, p4, 0xff

    invoke-interface {p2, p3}, Lcom/mbridge/msdk/thrid/okio/d;->writeByte(I)Lcom/mbridge/msdk/thrid/okio/d;

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a:Lcom/mbridge/msdk/thrid/okio/d;

    const p2, 0x7fffffff

    and-int/2addr p1, p2

    invoke-interface {p0, p1}, Lcom/mbridge/msdk/thrid/okio/d;->writeInt(I)Lcom/mbridge/msdk/thrid/okio/d;

    return-void

    :cond_38
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object p0

    const-string p1, "reserved bit set: %s"

    invoke-static {p1, p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/e;->a(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/IllegalArgumentException;

    move-result-object p0

    throw p0

    :cond_47
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    filled-new-array {p0, p1}, [Ljava/lang/Object;

    move-result-object p0

    const-string p1, "FRAME_SIZE_ERROR length > %d: %d"

    invoke-static {p1, p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/e;->a(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/IllegalArgumentException;

    move-result-object p0

    throw p0
.end method

.method public declared-synchronized a(IILjava/util/List;)V
    .registers 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(II",
            "Ljava/util/List<",
            "Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;",
            ">;)V"
        }
    .end annotation

    .prologue
    monitor-enter p0

    :try_start_1
    iget-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->e:Z

    if-nez v0, :cond_42

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->f:Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$b;

    invoke-virtual {v0, p3}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$b;->a(Ljava/util/List;)V

    iget-object p3, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->c:Lcom/mbridge/msdk/thrid/okio/c;

    invoke-virtual {p3}, Lcom/mbridge/msdk/thrid/okio/c;->size()J

    move-result-wide v0

    iget p3, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->d:I

    const/4 v2, 0x4

    sub-int/2addr p3, v2

    int-to-long v3, p3

    invoke-static {v3, v4, v0, v1}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v3

    long-to-int p3, v3

    int-to-long v3, p3

    cmp-long v5, v0, v3

    if-nez v5, :cond_21

    move v6, v2

    goto :goto_22

    :cond_21
    const/4 v6, 0x0

    :goto_22
    add-int/2addr p3, v2

    const/4 v2, 0x5

    invoke-virtual {p0, p1, p3, v2, v6}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a(IIBB)V

    iget-object p3, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a:Lcom/mbridge/msdk/thrid/okio/d;

    const v2, 0x7fffffff

    and-int/2addr p2, v2

    invoke-interface {p3, p2}, Lcom/mbridge/msdk/thrid/okio/d;->writeInt(I)Lcom/mbridge/msdk/thrid/okio/d;

    iget-object p2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a:Lcom/mbridge/msdk/thrid/okio/d;

    iget-object p3, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->c:Lcom/mbridge/msdk/thrid/okio/c;

    invoke-interface {p2, p3, v3, v4}, Lcom/mbridge/msdk/thrid/okio/r;->a(Lcom/mbridge/msdk/thrid/okio/c;J)V

    if-lez v5, :cond_40

    sub-long/2addr v0, v3

    invoke-direct {p0, p1, v0, v1}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->b(IJ)V
    :try_end_3d
    .catchall {:try_start_1 .. :try_end_3d} :catchall_3e

    goto :goto_40

    :catchall_3e
    move-exception p1

    goto :goto_4a

    :cond_40
    :goto_40
    monitor-exit p0

    return-void

    :cond_42
    :try_start_42
    new-instance p1, Ljava/io/IOException;

    const-string p2, "closed"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :goto_4a
    monitor-exit p0
    :try_end_4b
    .catchall {:try_start_42 .. :try_end_4b} :catchall_3e

    throw p1
.end method

.method public declared-synchronized a(IJ)V
    .registers 7

    .prologue
    monitor-enter p0

    :try_start_1
    iget-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->e:Z

    if-nez v0, :cond_37

    const-wide/16 v0, 0x0

    cmp-long v0, p2, v0

    if-eqz v0, :cond_28

    const-wide/32 v0, 0x7fffffff

    cmp-long v0, p2, v0

    if-gtz v0, :cond_28

    const/16 v0, 0x8

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0, p1, v2, v0, v1}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a(IIBB)V

    iget-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a:Lcom/mbridge/msdk/thrid/okio/d;

    long-to-int p2, p2

    invoke-interface {p1, p2}, Lcom/mbridge/msdk/thrid/okio/d;->writeInt(I)Lcom/mbridge/msdk/thrid/okio/d;

    iget-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a:Lcom/mbridge/msdk/thrid/okio/d;

    invoke-interface {p1}, Lcom/mbridge/msdk/thrid/okio/d;->flush()V
    :try_end_24
    .catchall {:try_start_1 .. :try_end_24} :catchall_26

    monitor-exit p0

    return-void

    :catchall_26
    move-exception p1

    goto :goto_3f

    :cond_28
    :try_start_28
    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object p1

    const-string p2, "windowSizeIncrement == 0 || windowSizeIncrement > 0x7fffffffL: %s"

    invoke-static {p2, p1}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/e;->a(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/IllegalArgumentException;

    move-result-object p1

    throw p1

    :cond_37
    new-instance p1, Ljava/io/IOException;

    const-string p2, "closed"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :goto_3f
    monitor-exit p0
    :try_end_40
    .catchall {:try_start_28 .. :try_end_40} :catchall_26

    throw p1
.end method

.method public declared-synchronized a(ILcom/mbridge/msdk/thrid/okhttp/internal/http2/b;)V
    .registers 6

    .prologue
    monitor-enter p0

    :try_start_1
    iget-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->e:Z

    if-nez v0, :cond_26

    iget v0, p2, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/b;->a:I

    const/4 v1, -0x1

    if-eq v0, v1, :cond_20

    const/4 v0, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0, p1, v2, v0, v1}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a(IIBB)V

    iget-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a:Lcom/mbridge/msdk/thrid/okio/d;

    iget p2, p2, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/b;->a:I

    invoke-interface {p1, p2}, Lcom/mbridge/msdk/thrid/okio/d;->writeInt(I)Lcom/mbridge/msdk/thrid/okio/d;

    iget-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a:Lcom/mbridge/msdk/thrid/okio/d;

    invoke-interface {p1}, Lcom/mbridge/msdk/thrid/okio/d;->flush()V
    :try_end_1c
    .catchall {:try_start_1 .. :try_end_1c} :catchall_1e

    monitor-exit p0

    return-void

    :catchall_1e
    move-exception p1

    goto :goto_2e

    :cond_20
    :try_start_20
    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    throw p1

    :cond_26
    new-instance p1, Ljava/io/IOException;

    const-string p2, "closed"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :goto_2e
    monitor-exit p0
    :try_end_2f
    .catchall {:try_start_20 .. :try_end_2f} :catchall_1e

    throw p1
.end method

.method public declared-synchronized a(ILcom/mbridge/msdk/thrid/okhttp/internal/http2/b;[B)V
    .registers 7

    .prologue
    monitor-enter p0

    :try_start_1
    iget-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->e:Z

    if-nez v0, :cond_39

    iget v0, p2, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/b;->a:I

    const/4 v1, -0x1

    const/4 v2, 0x0

    if-eq v0, v1, :cond_30

    array-length v0, p3

    add-int/lit8 v0, v0, 0x8

    const/4 v1, 0x7

    invoke-virtual {p0, v2, v0, v1, v2}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a(IIBB)V

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a:Lcom/mbridge/msdk/thrid/okio/d;

    invoke-interface {v0, p1}, Lcom/mbridge/msdk/thrid/okio/d;->writeInt(I)Lcom/mbridge/msdk/thrid/okio/d;

    iget-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a:Lcom/mbridge/msdk/thrid/okio/d;

    iget p2, p2, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/b;->a:I

    invoke-interface {p1, p2}, Lcom/mbridge/msdk/thrid/okio/d;->writeInt(I)Lcom/mbridge/msdk/thrid/okio/d;

    array-length p1, p3

    if-lez p1, :cond_29

    iget-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a:Lcom/mbridge/msdk/thrid/okio/d;

    invoke-interface {p1, p3}, Lcom/mbridge/msdk/thrid/okio/d;->write([B)Lcom/mbridge/msdk/thrid/okio/d;

    goto :goto_29

    :catchall_27
    move-exception p1

    goto :goto_41

    :cond_29
    :goto_29
    iget-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a:Lcom/mbridge/msdk/thrid/okio/d;

    invoke-interface {p1}, Lcom/mbridge/msdk/thrid/okio/d;->flush()V
    :try_end_2e
    .catchall {:try_start_1 .. :try_end_2e} :catchall_27

    monitor-exit p0

    return-void

    :cond_30
    :try_start_30
    new-array p1, v2, [Ljava/lang/Object;

    const-string p2, "errorCode.httpCode == -1"

    invoke-static {p2, p1}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/e;->a(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/IllegalArgumentException;

    move-result-object p1

    throw p1

    :cond_39
    new-instance p1, Ljava/io/IOException;

    const-string p2, "closed"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :goto_41
    monitor-exit p0
    :try_end_42
    .catchall {:try_start_30 .. :try_end_42} :catchall_27

    throw p1
.end method

.method public declared-synchronized a(Lcom/mbridge/msdk/thrid/okhttp/internal/http2/m;)V
    .registers 4

    .prologue
    monitor-enter p0

    :try_start_1
    iget-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->e:Z

    if-nez v0, :cond_2d

    iget v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->d:I

    invoke-virtual {p1, v0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/m;->c(I)I

    move-result v0

    iput v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->d:I

    invoke-virtual {p1}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/m;->b()I

    move-result v0

    const/4 v1, -0x1

    if-eq v0, v1, :cond_20

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->f:Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$b;

    invoke-virtual {p1}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/m;->b()I

    move-result p1

    invoke-virtual {v0, p1}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$b;->b(I)V

    goto :goto_20

    :catchall_1e
    move-exception p1

    goto :goto_35

    :cond_20
    :goto_20
    const/4 p1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p0, v1, v1, p1, v0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a(IIBB)V

    iget-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a:Lcom/mbridge/msdk/thrid/okio/d;

    invoke-interface {p1}, Lcom/mbridge/msdk/thrid/okio/d;->flush()V
    :try_end_2b
    .catchall {:try_start_1 .. :try_end_2b} :catchall_1e

    monitor-exit p0

    return-void

    :cond_2d
    :try_start_2d
    new-instance p1, Ljava/io/IOException;

    const-string v0, "closed"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :goto_35
    monitor-exit p0
    :try_end_36
    .catchall {:try_start_2d .. :try_end_36} :catchall_1e

    throw p1
.end method

.method public declared-synchronized a(ZII)V
    .registers 7

    .prologue
    monitor-enter p0

    :try_start_1
    iget-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->e:Z

    if-nez v0, :cond_1f

    const/4 v0, 0x6

    const/4 v1, 0x0

    const/16 v2, 0x8

    invoke-virtual {p0, v1, v2, v0, p1}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a(IIBB)V

    iget-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a:Lcom/mbridge/msdk/thrid/okio/d;

    invoke-interface {p1, p2}, Lcom/mbridge/msdk/thrid/okio/d;->writeInt(I)Lcom/mbridge/msdk/thrid/okio/d;

    iget-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a:Lcom/mbridge/msdk/thrid/okio/d;

    invoke-interface {p1, p3}, Lcom/mbridge/msdk/thrid/okio/d;->writeInt(I)Lcom/mbridge/msdk/thrid/okio/d;

    iget-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a:Lcom/mbridge/msdk/thrid/okio/d;

    invoke-interface {p1}, Lcom/mbridge/msdk/thrid/okio/d;->flush()V
    :try_end_1b
    .catchall {:try_start_1 .. :try_end_1b} :catchall_1d

    monitor-exit p0

    return-void

    :catchall_1d
    move-exception p1

    goto :goto_27

    :cond_1f
    :try_start_1f
    new-instance p1, Ljava/io/IOException;

    const-string p2, "closed"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :goto_27
    monitor-exit p0
    :try_end_28
    .catchall {:try_start_1f .. :try_end_28} :catchall_1d

    throw p1
.end method

.method public declared-synchronized a(ZIILjava/util/List;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(ZII",
            "Ljava/util/List<",
            "Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;",
            ">;)V"
        }
    .end annotation

    .prologue
    monitor-enter p0

    :try_start_1
    iget-boolean p3, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->e:Z

    if-nez p3, :cond_c

    invoke-virtual {p0, p1, p2, p4}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a(ZILjava/util/List;)V
    :try_end_8
    .catchall {:try_start_1 .. :try_end_8} :catchall_a

    monitor-exit p0

    return-void

    :catchall_a
    move-exception p1

    goto :goto_14

    :cond_c
    :try_start_c
    new-instance p1, Ljava/io/IOException;

    const-string p2, "closed"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :goto_14
    monitor-exit p0
    :try_end_15
    .catchall {:try_start_c .. :try_end_15} :catchall_a

    throw p1
.end method

.method public declared-synchronized a(ZILcom/mbridge/msdk/thrid/okio/c;I)V
    .registers 6

    .prologue
    monitor-enter p0

    :try_start_1
    iget-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->e:Z

    if-nez v0, :cond_c

    invoke-virtual {p0, p2, p1, p3, p4}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a(IBLcom/mbridge/msdk/thrid/okio/c;I)V
    :try_end_8
    .catchall {:try_start_1 .. :try_end_8} :catchall_a

    monitor-exit p0

    return-void

    :catchall_a
    move-exception p1

    goto :goto_14

    :cond_c
    :try_start_c
    new-instance p1, Ljava/io/IOException;

    const-string p2, "closed"

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :goto_14
    monitor-exit p0
    :try_end_15
    .catchall {:try_start_c .. :try_end_15} :catchall_a

    throw p1
.end method

.method public a(ZILjava/util/List;)V
    .registers 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(ZI",
            "Ljava/util/List<",
            "Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;",
            ">;)V"
        }
    .end annotation

    .prologue
    iget-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->e:Z

    if-nez v0, :cond_36

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->f:Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$b;

    invoke-virtual {v0, p3}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$b;->a(Ljava/util/List;)V

    iget-object p3, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->c:Lcom/mbridge/msdk/thrid/okio/c;

    invoke-virtual {p3}, Lcom/mbridge/msdk/thrid/okio/c;->size()J

    move-result-wide v0

    iget p3, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->d:I

    int-to-long v2, p3

    invoke-static {v2, v3, v0, v1}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v2

    long-to-int p3, v2

    int-to-long v2, p3

    cmp-long v4, v0, v2

    if-nez v4, :cond_1e

    const/4 v5, 0x4

    goto :goto_1f

    :cond_1e
    const/4 v5, 0x0

    :goto_1f
    if-eqz p1, :cond_24

    or-int/lit8 p1, v5, 0x1

    int-to-byte v5, p1

    :cond_24
    const/4 p1, 0x1

    invoke-virtual {p0, p2, p3, p1, v5}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a(IIBB)V

    iget-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a:Lcom/mbridge/msdk/thrid/okio/d;

    iget-object p3, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->c:Lcom/mbridge/msdk/thrid/okio/c;

    invoke-interface {p1, p3, v2, v3}, Lcom/mbridge/msdk/thrid/okio/r;->a(Lcom/mbridge/msdk/thrid/okio/c;J)V

    if-lez v4, :cond_35

    sub-long/2addr v0, v2

    invoke-direct {p0, p2, v0, v1}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->b(IJ)V

    :cond_35
    return-void

    :cond_36
    const-string p0, "closed"

    invoke-static {p0}, Lvh0;->k(Ljava/lang/String;)V

    return-void
.end method

.method public declared-synchronized b(Lcom/mbridge/msdk/thrid/okhttp/internal/http2/m;)V
    .registers 6

    .prologue
    monitor-enter p0

    :try_start_1
    iget-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->e:Z

    if-nez v0, :cond_3f

    invoke-virtual {p1}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/m;->d()I

    move-result v0

    mul-int/lit8 v0, v0, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0, v2, v0, v1, v2}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a(IIBB)V

    :goto_10
    const/16 v0, 0xa

    if-ge v2, v0, :cond_38

    invoke-virtual {p1, v2}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/m;->d(I)Z

    move-result v0

    if-nez v0, :cond_1b

    goto :goto_33

    :cond_1b
    if-ne v2, v1, :cond_1f

    const/4 v0, 0x3

    goto :goto_25

    :cond_1f
    const/4 v0, 0x7

    if-ne v2, v0, :cond_24

    move v0, v1

    goto :goto_25

    :cond_24
    move v0, v2

    :goto_25
    iget-object v3, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a:Lcom/mbridge/msdk/thrid/okio/d;

    invoke-interface {v3, v0}, Lcom/mbridge/msdk/thrid/okio/d;->writeShort(I)Lcom/mbridge/msdk/thrid/okio/d;

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a:Lcom/mbridge/msdk/thrid/okio/d;

    invoke-virtual {p1, v2}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/m;->a(I)I

    move-result v3

    invoke-interface {v0, v3}, Lcom/mbridge/msdk/thrid/okio/d;->writeInt(I)Lcom/mbridge/msdk/thrid/okio/d;

    :goto_33
    add-int/lit8 v2, v2, 0x1

    goto :goto_10

    :catchall_36
    move-exception p1

    goto :goto_47

    :cond_38
    iget-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a:Lcom/mbridge/msdk/thrid/okio/d;

    invoke-interface {p1}, Lcom/mbridge/msdk/thrid/okio/d;->flush()V
    :try_end_3d
    .catchall {:try_start_1 .. :try_end_3d} :catchall_36

    monitor-exit p0

    return-void

    :cond_3f
    :try_start_3f
    new-instance p1, Ljava/io/IOException;

    const-string v0, "closed"

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :goto_47
    monitor-exit p0
    :try_end_48
    .catchall {:try_start_3f .. :try_end_48} :catchall_36

    throw p1
.end method

.method public declared-synchronized close()V
    .registers 2

    .prologue
    monitor-enter p0

    const/4 v0, 0x1

    :try_start_2
    iput-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->e:Z

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a:Lcom/mbridge/msdk/thrid/okio/d;

    invoke-interface {v0}, Lcom/mbridge/msdk/thrid/okio/r;->close()V
    :try_end_9
    .catchall {:try_start_2 .. :try_end_9} :catchall_b

    monitor-exit p0

    return-void

    :catchall_b
    move-exception v0

    :try_start_c
    monitor-exit p0
    :try_end_d
    .catchall {:try_start_c .. :try_end_d} :catchall_b

    throw v0
.end method

.method public declared-synchronized d()V
    .registers 4

    .prologue
    monitor-enter p0

    :try_start_1
    iget-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->e:Z

    if-nez v0, :cond_3d

    iget-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->b:Z
    :try_end_7
    .catchall {:try_start_1 .. :try_end_7} :catchall_29

    if-nez v0, :cond_b

    monitor-exit p0

    return-void

    :cond_b
    :try_start_b
    sget-object v0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->g:Ljava/util/logging/Logger;

    sget-object v1, Ljava/util/logging/Level;->FINE:Ljava/util/logging/Level;

    invoke-virtual {v0, v1}, Ljava/util/logging/Logger;->isLoggable(Ljava/util/logging/Level;)Z

    move-result v1

    if-eqz v1, :cond_2b

    sget-object v1, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/e;->a:Lcom/mbridge/msdk/thrid/okio/f;

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okio/f;->g()Ljava/lang/String;

    move-result-object v1

    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object v1

    const-string v2, ">> CONNECTION %s"

    invoke-static {v2, v1}, Lcom/mbridge/msdk/thrid/okhttp/internal/c;->a(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/logging/Logger;->fine(Ljava/lang/String;)V

    goto :goto_2b

    :catchall_29
    move-exception v0

    goto :goto_45

    :cond_2b
    :goto_2b
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a:Lcom/mbridge/msdk/thrid/okio/d;

    sget-object v1, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/e;->a:Lcom/mbridge/msdk/thrid/okio/f;

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okio/f;->l()[B

    move-result-object v1

    invoke-interface {v0, v1}, Lcom/mbridge/msdk/thrid/okio/d;->write([B)Lcom/mbridge/msdk/thrid/okio/d;

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a:Lcom/mbridge/msdk/thrid/okio/d;

    invoke-interface {v0}, Lcom/mbridge/msdk/thrid/okio/d;->flush()V
    :try_end_3b
    .catchall {:try_start_b .. :try_end_3b} :catchall_29

    monitor-exit p0

    return-void

    :cond_3d
    :try_start_3d
    new-instance v0, Ljava/io/IOException;

    const-string v1, "closed"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :goto_45
    monitor-exit p0
    :try_end_46
    .catchall {:try_start_3d .. :try_end_46} :catchall_29

    throw v0
.end method

.method public declared-synchronized flush()V
    .registers 3

    .prologue
    monitor-enter p0

    :try_start_1
    iget-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->e:Z

    if-nez v0, :cond_e

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->a:Lcom/mbridge/msdk/thrid/okio/d;

    invoke-interface {v0}, Lcom/mbridge/msdk/thrid/okio/d;->flush()V
    :try_end_a
    .catchall {:try_start_1 .. :try_end_a} :catchall_c

    monitor-exit p0

    return-void

    :catchall_c
    move-exception v0

    goto :goto_16

    :cond_e
    :try_start_e
    new-instance v0, Ljava/io/IOException;

    const-string v1, "closed"

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0

    :goto_16
    monitor-exit p0
    :try_end_17
    .catchall {:try_start_e .. :try_end_17} :catchall_c

    throw v0
.end method

.method public h()I
    .registers 1

    iget p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/j;->d:I

    return p0
.end method
