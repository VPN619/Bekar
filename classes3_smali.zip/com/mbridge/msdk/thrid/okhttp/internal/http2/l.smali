.class public interface abstract Lcom/mbridge/msdk/thrid/okhttp/internal/http2/l;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final a:Lcom/mbridge/msdk/thrid/okhttp/internal/http2/l;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/l$a;

    invoke-direct {v0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/l$a;-><init>()V

    sput-object v0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/l;->a:Lcom/mbridge/msdk/thrid/okhttp/internal/http2/l;

    return-void
.end method


# virtual methods
.method public abstract a(ILcom/mbridge/msdk/thrid/okhttp/internal/http2/b;)V
.end method

.method public abstract a(ILcom/mbridge/msdk/thrid/okio/e;IZ)Z
.end method

.method public abstract a(ILjava/util/List;)Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;",
            ">;)Z"
        }
    .end annotation
.end method

.method public abstract a(ILjava/util/List;Z)Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;",
            ">;Z)Z"
        }
    .end annotation
.end method
