.class final Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field private final a:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;",
            ">;"
        }
    .end annotation
.end field

.field private final b:Lcom/mbridge/msdk/thrid/okio/e;

.field private final c:I

.field private d:I

.field e:[Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;

.field f:I

.field g:I

.field h:I


# direct methods
.method public constructor <init>(IILcom/mbridge/msdk/thrid/okio/s;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->a:Ljava/util/List;

    const/16 v0, 0x8

    new-array v0, v0, [Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;

    iput-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->e:[Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;

    const/4 v0, 0x7

    iput v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->f:I

    const/4 v0, 0x0

    iput v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->g:I

    iput v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->h:I

    iput p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->c:I

    iput p2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->d:I

    invoke-static {p3}, Lcom/mbridge/msdk/thrid/okio/l;->a(Lcom/mbridge/msdk/thrid/okio/s;)Lcom/mbridge/msdk/thrid/okio/e;

    move-result-object p1

    iput-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->b:Lcom/mbridge/msdk/thrid/okio/e;

    return-void
.end method

.method public constructor <init>(ILcom/mbridge/msdk/thrid/okio/s;)V
    .registers 3

    invoke-direct {p0, p1, p1, p2}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;-><init>(IILcom/mbridge/msdk/thrid/okio/s;)V

    return-void
.end method

.method private a(I)I
    .registers 2

    iget p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->f:I

    add-int/lit8 p0, p0, 0x1

    add-int/2addr p0, p1

    return p0
.end method

.method private a()V
    .registers 3

    .prologue
    iget v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->d:I

    iget v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->h:I

    if-ge v0, v1, :cond_10

    if-nez v0, :cond_c

    invoke-direct {p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->b()V

    return-void

    :cond_c
    sub-int/2addr v1, v0

    invoke-direct {p0, v1}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->b(I)I

    :cond_10
    return-void
.end method

.method private a(ILcom/mbridge/msdk/thrid/okhttp/internal/http2/c;)V
    .registers 8

    .prologue
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->a:Ljava/util/List;

    invoke-interface {v0, p2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    iget v0, p2, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;->c:I

    const/4 v1, -0x1

    if-eq p1, v1, :cond_15

    iget-object v2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->e:[Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;

    invoke-direct {p0, p1}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->a(I)I

    move-result v3

    aget-object v2, v2, v3

    iget v2, v2, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;->c:I

    sub-int/2addr v0, v2

    :cond_15
    iget v2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->d:I

    if-le v0, v2, :cond_1d

    invoke-direct {p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->b()V

    return-void

    :cond_1d
    iget v3, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->h:I

    add-int/2addr v3, v0

    sub-int/2addr v3, v2

    invoke-direct {p0, v3}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->b(I)I

    move-result v2

    if-ne p1, v1, :cond_54

    iget p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->g:I

    add-int/lit8 p1, p1, 0x1

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->e:[Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;

    array-length v2, v1

    if-le p1, v2, :cond_45

    array-length p1, v1

    mul-int/lit8 p1, p1, 0x2

    new-array p1, p1, [Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;

    array-length v2, v1

    array-length v3, v1

    const/4 v4, 0x0

    invoke-static {v1, v4, p1, v2, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->e:[Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;

    array-length v1, v1

    add-int/lit8 v1, v1, -0x1

    iput v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->f:I

    iput-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->e:[Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;

    move-object v1, p1

    :cond_45
    iget p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->f:I

    add-int/lit8 v2, p1, -0x1

    iput v2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->f:I

    aput-object p2, v1, p1

    iget p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->g:I

    add-int/lit8 p1, p1, 0x1

    iput p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->g:I

    goto :goto_5e

    :cond_54
    invoke-direct {p0, p1}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->a(I)I

    move-result v1

    add-int/2addr v1, v2

    add-int/2addr v1, p1

    iget-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->e:[Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;

    aput-object p2, p1, v1

    :goto_5e
    iget p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->h:I

    add-int/2addr p1, v0

    iput p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->h:I

    return-void
.end method

.method private b(I)I
    .registers 6

    .prologue
    const/4 v0, 0x0

    if-lez p1, :cond_35

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->e:[Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;

    array-length v1, v1

    add-int/lit8 v1, v1, -0x1

    :goto_8
    iget v2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->f:I

    if-lt v1, v2, :cond_25

    if-lez p1, :cond_25

    iget-object v2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->e:[Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;

    aget-object v2, v2, v1

    iget v2, v2, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;->c:I

    sub-int/2addr p1, v2

    iget v3, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->h:I

    sub-int/2addr v3, v2

    iput v3, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->h:I

    iget v2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->g:I

    add-int/lit8 v2, v2, -0x1

    iput v2, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->g:I

    add-int/lit8 v0, v0, 0x1

    add-int/lit8 v1, v1, -0x1

    goto :goto_8

    :cond_25
    iget-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->e:[Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;

    add-int/lit8 v2, v2, 0x1

    add-int v1, v2, v0

    iget v3, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->g:I

    invoke-static {p1, v2, p1, v1, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->f:I

    add-int/2addr p1, v0

    iput p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->f:I

    :cond_35
    return v0
.end method

.method private b()V
    .registers 3

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->e:[Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Ljava/util/Arrays;->fill([Ljava/lang/Object;Ljava/lang/Object;)V

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->e:[Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;

    array-length v0, v0

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->f:I

    const/4 v0, 0x0

    iput v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->g:I

    iput v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->h:I

    return-void
.end method

.method private c(I)Lcom/mbridge/msdk/thrid/okio/f;
    .registers 4

    .prologue
    invoke-direct {p0, p1}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->d(I)Z

    move-result v0

    if-eqz v0, :cond_d

    sget-object p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d;->a:[Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;

    aget-object p0, p0, p1

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;->a:Lcom/mbridge/msdk/thrid/okio/f;

    return-object p0

    :cond_d
    sget-object v0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d;->a:[Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;

    array-length v0, v0

    sub-int v0, p1, v0

    invoke-direct {p0, v0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->a(I)I

    move-result v0

    if-ltz v0, :cond_22

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->e:[Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;

    array-length v1, p0

    if-ge v0, v1, :cond_22

    aget-object p0, p0, v0

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;->a:Lcom/mbridge/msdk/thrid/okio/f;

    return-object p0

    :cond_22
    add-int/lit8 p1, p1, 0x1

    const-string p0, "Header index too large "

    invoke-static {p1, p0}, Lvx2;->f(ILjava/lang/String;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method private d()I
    .registers 1

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->b:Lcom/mbridge/msdk/thrid/okio/e;

    invoke-interface {p0}, Lcom/mbridge/msdk/thrid/okio/e;->readByte()B

    move-result p0

    and-int/lit16 p0, p0, 0xff

    return p0
.end method

.method private d(I)Z
    .registers 3

    .prologue
    if-ltz p1, :cond_a

    sget-object p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d;->a:[Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;

    array-length p0, p0

    const/4 v0, 0x1

    sub-int/2addr p0, v0

    if-gt p1, p0, :cond_a

    return v0

    :cond_a
    const/4 p0, 0x0

    return p0
.end method

.method private e(I)V
    .registers 5

    .prologue
    invoke-direct {p0, p1}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->d(I)Z

    move-result v0

    if-eqz v0, :cond_10

    sget-object v0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d;->a:[Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;

    aget-object p1, v0, p1

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->a:Ljava/util/List;

    invoke-interface {p0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    return-void

    :cond_10
    sget-object v0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d;->a:[Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;

    array-length v0, v0

    sub-int v0, p1, v0

    invoke-direct {p0, v0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->a(I)I

    move-result v0

    if-ltz v0, :cond_28

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->e:[Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;

    array-length v2, v1

    if-ge v0, v2, :cond_28

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->a:Ljava/util/List;

    aget-object p1, v1, v0

    invoke-interface {p0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    return-void

    :cond_28
    add-int/lit8 p1, p1, 0x1

    const-string p0, "Header index too large "

    invoke-static {p1, p0}, Lvx2;->f(ILjava/lang/String;)V

    return-void
.end method

.method private f(I)V
    .registers 4

    invoke-direct {p0, p1}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->c(I)Lcom/mbridge/msdk/thrid/okio/f;

    move-result-object p1

    invoke-virtual {p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->e()Lcom/mbridge/msdk/thrid/okio/f;

    move-result-object v0

    new-instance v1, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;

    invoke-direct {v1, p1, v0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;-><init>(Lcom/mbridge/msdk/thrid/okio/f;Lcom/mbridge/msdk/thrid/okio/f;)V

    const/4 p1, -0x1

    invoke-direct {p0, p1, v1}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->a(ILcom/mbridge/msdk/thrid/okhttp/internal/http2/c;)V

    return-void
.end method

.method private g()V
    .registers 4

    invoke-virtual {p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->e()Lcom/mbridge/msdk/thrid/okio/f;

    move-result-object v0

    invoke-static {v0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d;->a(Lcom/mbridge/msdk/thrid/okio/f;)Lcom/mbridge/msdk/thrid/okio/f;

    move-result-object v0

    invoke-virtual {p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->e()Lcom/mbridge/msdk/thrid/okio/f;

    move-result-object v1

    new-instance v2, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;

    invoke-direct {v2, v0, v1}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;-><init>(Lcom/mbridge/msdk/thrid/okio/f;Lcom/mbridge/msdk/thrid/okio/f;)V

    const/4 v0, -0x1

    invoke-direct {p0, v0, v2}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->a(ILcom/mbridge/msdk/thrid/okhttp/internal/http2/c;)V

    return-void
.end method

.method private g(I)V
    .registers 4

    invoke-direct {p0, p1}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->c(I)Lcom/mbridge/msdk/thrid/okio/f;

    move-result-object p1

    invoke-virtual {p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->e()Lcom/mbridge/msdk/thrid/okio/f;

    move-result-object v0

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->a:Ljava/util/List;

    new-instance v1, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;

    invoke-direct {v1, p1, v0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;-><init>(Lcom/mbridge/msdk/thrid/okio/f;Lcom/mbridge/msdk/thrid/okio/f;)V

    invoke-interface {p0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    return-void
.end method

.method private h()V
    .registers 4

    invoke-virtual {p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->e()Lcom/mbridge/msdk/thrid/okio/f;

    move-result-object v0

    invoke-static {v0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d;->a(Lcom/mbridge/msdk/thrid/okio/f;)Lcom/mbridge/msdk/thrid/okio/f;

    move-result-object v0

    invoke-virtual {p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->e()Lcom/mbridge/msdk/thrid/okio/f;

    move-result-object v1

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->a:Ljava/util/List;

    new-instance v2, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;

    invoke-direct {v2, v0, v1}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;-><init>(Lcom/mbridge/msdk/thrid/okio/f;Lcom/mbridge/msdk/thrid/okio/f;)V

    invoke-interface {p0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    return-void
.end method


# virtual methods
.method public a(II)I
    .registers 5

    .prologue
    and-int/2addr p1, p2

    if-ge p1, p2, :cond_4

    return p1

    :cond_4
    const/4 p1, 0x0

    :goto_5
    invoke-direct {p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->d()I

    move-result v0

    and-int/lit16 v1, v0, 0x80

    if-eqz v1, :cond_14

    and-int/lit8 v0, v0, 0x7f

    shl-int/2addr v0, p1

    add-int/2addr p2, v0

    add-int/lit8 p1, p1, 0x7

    goto :goto_5

    :cond_14
    shl-int p0, v0, p1

    add-int/2addr p2, p0

    return p2
.end method

.method public c()Ljava/util/List;
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/mbridge/msdk/thrid/okhttp/internal/http2/c;",
            ">;"
        }
    .end annotation

    new-instance v0, Ljava/util/ArrayList;

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->a:Ljava/util/List;

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->a:Ljava/util/List;

    invoke-interface {p0}, Ljava/util/List;->clear()V

    return-object v0
.end method

.method public e()Lcom/mbridge/msdk/thrid/okio/f;
    .registers 5

    .prologue
    invoke-direct {p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->d()I

    move-result v0

    and-int/lit16 v1, v0, 0x80

    const/16 v2, 0x80

    if-ne v1, v2, :cond_c

    const/4 v1, 0x1

    goto :goto_d

    :cond_c
    const/4 v1, 0x0

    :goto_d
    const/16 v2, 0x7f

    invoke-virtual {p0, v0, v2}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->a(II)I

    move-result v0

    if-eqz v1, :cond_29

    invoke-static {}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/k;->b()Lcom/mbridge/msdk/thrid/okhttp/internal/http2/k;

    move-result-object v1

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->b:Lcom/mbridge/msdk/thrid/okio/e;

    int-to-long v2, v0

    invoke-interface {p0, v2, v3}, Lcom/mbridge/msdk/thrid/okio/e;->c(J)[B

    move-result-object p0

    invoke-virtual {v1, p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/k;->a([B)[B

    move-result-object p0

    invoke-static {p0}, Lcom/mbridge/msdk/thrid/okio/f;->a([B)Lcom/mbridge/msdk/thrid/okio/f;

    move-result-object p0

    return-object p0

    :cond_29
    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->b:Lcom/mbridge/msdk/thrid/okio/e;

    int-to-long v0, v0

    invoke-interface {p0, v0, v1}, Lcom/mbridge/msdk/thrid/okio/e;->b(J)Lcom/mbridge/msdk/thrid/okio/f;

    move-result-object p0

    return-object p0
.end method

.method public f()V
    .registers 5

    .prologue
    :goto_0
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->b:Lcom/mbridge/msdk/thrid/okio/e;

    invoke-interface {v0}, Lcom/mbridge/msdk/thrid/okio/e;->f()Z

    move-result v0

    if-nez v0, :cond_78

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->b:Lcom/mbridge/msdk/thrid/okio/e;

    invoke-interface {v0}, Lcom/mbridge/msdk/thrid/okio/e;->readByte()B

    move-result v0

    and-int/lit16 v1, v0, 0xff

    const/16 v2, 0x80

    if-eq v1, v2, :cond_73

    and-int/lit16 v3, v0, 0x80

    if-ne v3, v2, :cond_24

    const/16 v0, 0x7f

    invoke-virtual {p0, v1, v0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->a(II)I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    invoke-direct {p0, v0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->e(I)V

    goto :goto_0

    :cond_24
    const/16 v2, 0x40

    if-ne v1, v2, :cond_2c

    invoke-direct {p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->g()V

    goto :goto_0

    :cond_2c
    and-int/lit8 v3, v0, 0x40

    if-ne v3, v2, :cond_3c

    const/16 v0, 0x3f

    invoke-virtual {p0, v1, v0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->a(II)I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    invoke-direct {p0, v0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->f(I)V

    goto :goto_0

    :cond_3c
    and-int/lit8 v0, v0, 0x20

    const/16 v2, 0x20

    if-ne v0, v2, :cond_5c

    const/16 v0, 0x1f

    invoke-virtual {p0, v1, v0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->a(II)I

    move-result v0

    iput v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->d:I

    if-ltz v0, :cond_54

    iget v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->c:I

    if-gt v0, v1, :cond_54

    invoke-direct {p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->a()V

    goto :goto_0

    :cond_54
    const-string v0, "Invalid dynamic table size update "

    iget p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->d:I

    invoke-static {p0, v0}, Lvx2;->f(ILjava/lang/String;)V

    return-void

    :cond_5c
    const/16 v0, 0x10

    if-eq v1, v0, :cond_6f

    if-nez v1, :cond_63

    goto :goto_6f

    :cond_63
    const/16 v0, 0xf

    invoke-virtual {p0, v1, v0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->a(II)I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    invoke-direct {p0, v0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->g(I)V

    goto :goto_0

    :cond_6f
    :goto_6f
    invoke-direct {p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/d$a;->h()V

    goto :goto_0

    :cond_73
    const-string p0, "index == 0"

    invoke-static {p0}, Lvh0;->k(Ljava/lang/String;)V

    :cond_78
    return-void
.end method
