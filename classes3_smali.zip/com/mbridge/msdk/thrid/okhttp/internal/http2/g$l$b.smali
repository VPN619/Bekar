.class Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$l$b;
.super Lcom/mbridge/msdk/thrid/okhttp/internal/b;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$l;->a(ZLcom/mbridge/msdk/thrid/okhttp/internal/http2/m;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field final synthetic b:Z

.field final synthetic c:Lcom/mbridge/msdk/thrid/okhttp/internal/http2/m;

.field final synthetic d:Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$l;


# direct methods
.method public varargs constructor <init>(Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$l;Ljava/lang/String;[Ljava/lang/Object;ZLcom/mbridge/msdk/thrid/okhttp/internal/http2/m;)V
    .registers 6

    iput-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$l$b;->d:Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$l;

    iput-boolean p4, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$l$b;->b:Z

    iput-object p5, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$l$b;->c:Lcom/mbridge/msdk/thrid/okhttp/internal/http2/m;

    invoke-direct {p0, p2, p3}, Lcom/mbridge/msdk/thrid/okhttp/internal/b;-><init>(Ljava/lang/String;[Ljava/lang/Object;)V

    return-void
.end method


# virtual methods
.method public b()V
    .registers 3

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$l$b;->d:Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$l;

    iget-boolean v1, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$l$b;->b:Z

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$l$b;->c:Lcom/mbridge/msdk/thrid/okhttp/internal/http2/m;

    invoke-virtual {v0, v1, p0}, Lcom/mbridge/msdk/thrid/okhttp/internal/http2/g$l;->b(ZLcom/mbridge/msdk/thrid/okhttp/internal/http2/m;)V

    return-void
.end method
