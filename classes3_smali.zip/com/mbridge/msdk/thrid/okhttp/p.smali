.class public final Lcom/mbridge/msdk/thrid/okhttp/p;
.super Lcom/mbridge/msdk/thrid/okhttp/z;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/mbridge/msdk/thrid/okhttp/p$a;
    }
.end annotation


# static fields
.field private static final c:Lcom/mbridge/msdk/thrid/okhttp/u;


# instance fields
.field private final a:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final b:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-string v0, "application/x-www-form-urlencoded"

    invoke-static {v0}, Lcom/mbridge/msdk/thrid/okhttp/u;->a(Ljava/lang/String;)Lcom/mbridge/msdk/thrid/okhttp/u;

    move-result-object v0

    sput-object v0, Lcom/mbridge/msdk/thrid/okhttp/p;->c:Lcom/mbridge/msdk/thrid/okhttp/u;

    return-void
.end method

.method public constructor <init>(Ljava/util/List;Ljava/util/List;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    invoke-direct {p0}, Lcom/mbridge/msdk/thrid/okhttp/z;-><init>()V

    invoke-static {p1}, Lcom/mbridge/msdk/thrid/okhttp/internal/c;->a(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/p;->a:Ljava/util/List;

    invoke-static {p2}, Lcom/mbridge/msdk/thrid/okhttp/internal/c;->a(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/p;->b:Ljava/util/List;

    return-void
.end method

.method private a(Lcom/mbridge/msdk/thrid/okio/d;Z)J
    .registers 6

    .prologue
    if-eqz p2, :cond_8

    new-instance p1, Lcom/mbridge/msdk/thrid/okio/c;

    invoke-direct {p1}, Lcom/mbridge/msdk/thrid/okio/c;-><init>()V

    goto :goto_c

    :cond_8
    invoke-interface {p1}, Lcom/mbridge/msdk/thrid/okio/d;->a()Lcom/mbridge/msdk/thrid/okio/c;

    move-result-object p1

    :goto_c
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/p;->a:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_13
    if-ge v1, v0, :cond_3a

    if-lez v1, :cond_1c

    const/16 v2, 0x26

    invoke-virtual {p1, v2}, Lcom/mbridge/msdk/thrid/okio/c;->c(I)Lcom/mbridge/msdk/thrid/okio/c;

    :cond_1c
    iget-object v2, p0, Lcom/mbridge/msdk/thrid/okhttp/p;->a:Ljava/util/List;

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {p1, v2}, Lcom/mbridge/msdk/thrid/okio/c;->b(Ljava/lang/String;)Lcom/mbridge/msdk/thrid/okio/c;

    const/16 v2, 0x3d

    invoke-virtual {p1, v2}, Lcom/mbridge/msdk/thrid/okio/c;->c(I)Lcom/mbridge/msdk/thrid/okio/c;

    iget-object v2, p0, Lcom/mbridge/msdk/thrid/okhttp/p;->b:Ljava/util/List;

    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {p1, v2}, Lcom/mbridge/msdk/thrid/okio/c;->b(Ljava/lang/String;)Lcom/mbridge/msdk/thrid/okio/c;

    add-int/lit8 v1, v1, 0x1

    goto :goto_13

    :cond_3a
    if-eqz p2, :cond_44

    invoke-virtual {p1}, Lcom/mbridge/msdk/thrid/okio/c;->size()J

    move-result-wide v0

    invoke-virtual {p1}, Lcom/mbridge/msdk/thrid/okio/c;->k()V

    return-wide v0

    :cond_44
    const-wide/16 p0, 0x0

    return-wide p0
.end method


# virtual methods
.method public a()J
    .registers 3

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0, v0, v1}, Lcom/mbridge/msdk/thrid/okhttp/p;->a(Lcom/mbridge/msdk/thrid/okio/d;Z)J

    move-result-wide v0

    return-wide v0
.end method

.method public a(Lcom/mbridge/msdk/thrid/okio/d;)V
    .registers 3

    const/4 v0, 0x0

    invoke-direct {p0, p1, v0}, Lcom/mbridge/msdk/thrid/okhttp/p;->a(Lcom/mbridge/msdk/thrid/okio/d;Z)J

    return-void
.end method

.method public b()Lcom/mbridge/msdk/thrid/okhttp/u;
    .registers 1

    sget-object p0, Lcom/mbridge/msdk/thrid/okhttp/p;->c:Lcom/mbridge/msdk/thrid/okhttp/u;

    return-object p0
.end method
