.class public final Lcom/mbridge/msdk/thrid/okhttp/j;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/mbridge/msdk/thrid/okhttp/j$a;
    }
.end annotation


# static fields
.field private static final e:[Lcom/mbridge/msdk/thrid/okhttp/g;

.field private static final f:[Lcom/mbridge/msdk/thrid/okhttp/g;

.field public static final g:Lcom/mbridge/msdk/thrid/okhttp/j;

.field public static final h:Lcom/mbridge/msdk/thrid/okhttp/j;

.field public static final i:Lcom/mbridge/msdk/thrid/okhttp/j;

.field public static final j:Lcom/mbridge/msdk/thrid/okhttp/j;


# instance fields
.field final a:Z

.field final b:Z

.field final c:[Ljava/lang/String;

.field final d:[Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 20

    sget-object v0, Lcom/mbridge/msdk/thrid/okhttp/g;->n1:Lcom/mbridge/msdk/thrid/okhttp/g;

    sget-object v1, Lcom/mbridge/msdk/thrid/okhttp/g;->o1:Lcom/mbridge/msdk/thrid/okhttp/g;

    sget-object v2, Lcom/mbridge/msdk/thrid/okhttp/g;->p1:Lcom/mbridge/msdk/thrid/okhttp/g;

    sget-object v3, Lcom/mbridge/msdk/thrid/okhttp/g;->q1:Lcom/mbridge/msdk/thrid/okhttp/g;

    sget-object v4, Lcom/mbridge/msdk/thrid/okhttp/g;->r1:Lcom/mbridge/msdk/thrid/okhttp/g;

    sget-object v5, Lcom/mbridge/msdk/thrid/okhttp/g;->Z0:Lcom/mbridge/msdk/thrid/okhttp/g;

    sget-object v6, Lcom/mbridge/msdk/thrid/okhttp/g;->d1:Lcom/mbridge/msdk/thrid/okhttp/g;

    sget-object v7, Lcom/mbridge/msdk/thrid/okhttp/g;->a1:Lcom/mbridge/msdk/thrid/okhttp/g;

    sget-object v8, Lcom/mbridge/msdk/thrid/okhttp/g;->e1:Lcom/mbridge/msdk/thrid/okhttp/g;

    sget-object v9, Lcom/mbridge/msdk/thrid/okhttp/g;->k1:Lcom/mbridge/msdk/thrid/okhttp/g;

    sget-object v10, Lcom/mbridge/msdk/thrid/okhttp/g;->j1:Lcom/mbridge/msdk/thrid/okhttp/g;

    filled-new-array/range {v0 .. v10}, [Lcom/mbridge/msdk/thrid/okhttp/g;

    move-result-object v11

    sput-object v11, Lcom/mbridge/msdk/thrid/okhttp/j;->e:[Lcom/mbridge/msdk/thrid/okhttp/g;

    sget-object v12, Lcom/mbridge/msdk/thrid/okhttp/g;->K0:Lcom/mbridge/msdk/thrid/okhttp/g;

    sget-object v13, Lcom/mbridge/msdk/thrid/okhttp/g;->L0:Lcom/mbridge/msdk/thrid/okhttp/g;

    sget-object v14, Lcom/mbridge/msdk/thrid/okhttp/g;->i0:Lcom/mbridge/msdk/thrid/okhttp/g;

    sget-object v15, Lcom/mbridge/msdk/thrid/okhttp/g;->j0:Lcom/mbridge/msdk/thrid/okhttp/g;

    sget-object v16, Lcom/mbridge/msdk/thrid/okhttp/g;->G:Lcom/mbridge/msdk/thrid/okhttp/g;

    sget-object v17, Lcom/mbridge/msdk/thrid/okhttp/g;->K:Lcom/mbridge/msdk/thrid/okhttp/g;

    sget-object v18, Lcom/mbridge/msdk/thrid/okhttp/g;->k:Lcom/mbridge/msdk/thrid/okhttp/g;

    move-object/from16 v19, v1

    move-object v1, v0

    move-object v0, v11

    move-object v11, v10

    move-object v10, v9

    move-object v9, v8

    move-object v8, v7

    move-object v7, v6

    move-object v6, v5

    move-object v5, v4

    move-object v4, v3

    move-object v3, v2

    move-object/from16 v2, v19

    filled-new-array/range {v1 .. v18}, [Lcom/mbridge/msdk/thrid/okhttp/g;

    move-result-object v1

    sput-object v1, Lcom/mbridge/msdk/thrid/okhttp/j;->f:[Lcom/mbridge/msdk/thrid/okhttp/g;

    new-instance v2, Lcom/mbridge/msdk/thrid/okhttp/j$a;

    const/4 v3, 0x1

    invoke-direct {v2, v3}, Lcom/mbridge/msdk/thrid/okhttp/j$a;-><init>(Z)V

    invoke-virtual {v2, v0}, Lcom/mbridge/msdk/thrid/okhttp/j$a;->a([Lcom/mbridge/msdk/thrid/okhttp/g;)Lcom/mbridge/msdk/thrid/okhttp/j$a;

    move-result-object v0

    sget-object v2, Lcom/mbridge/msdk/thrid/okhttp/d0;->b:Lcom/mbridge/msdk/thrid/okhttp/d0;

    sget-object v4, Lcom/mbridge/msdk/thrid/okhttp/d0;->c:Lcom/mbridge/msdk/thrid/okhttp/d0;

    filled-new-array {v2, v4}, [Lcom/mbridge/msdk/thrid/okhttp/d0;

    move-result-object v5

    invoke-virtual {v0, v5}, Lcom/mbridge/msdk/thrid/okhttp/j$a;->a([Lcom/mbridge/msdk/thrid/okhttp/d0;)Lcom/mbridge/msdk/thrid/okhttp/j$a;

    move-result-object v0

    invoke-virtual {v0, v3}, Lcom/mbridge/msdk/thrid/okhttp/j$a;->a(Z)Lcom/mbridge/msdk/thrid/okhttp/j$a;

    move-result-object v0

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/j$a;->a()Lcom/mbridge/msdk/thrid/okhttp/j;

    move-result-object v0

    sput-object v0, Lcom/mbridge/msdk/thrid/okhttp/j;->g:Lcom/mbridge/msdk/thrid/okhttp/j;

    new-instance v0, Lcom/mbridge/msdk/thrid/okhttp/j$a;

    invoke-direct {v0, v3}, Lcom/mbridge/msdk/thrid/okhttp/j$a;-><init>(Z)V

    invoke-virtual {v0, v1}, Lcom/mbridge/msdk/thrid/okhttp/j$a;->a([Lcom/mbridge/msdk/thrid/okhttp/g;)Lcom/mbridge/msdk/thrid/okhttp/j$a;

    move-result-object v0

    sget-object v5, Lcom/mbridge/msdk/thrid/okhttp/d0;->d:Lcom/mbridge/msdk/thrid/okhttp/d0;

    sget-object v6, Lcom/mbridge/msdk/thrid/okhttp/d0;->e:Lcom/mbridge/msdk/thrid/okhttp/d0;

    filled-new-array {v2, v4, v5, v6}, [Lcom/mbridge/msdk/thrid/okhttp/d0;

    move-result-object v2

    invoke-virtual {v0, v2}, Lcom/mbridge/msdk/thrid/okhttp/j$a;->a([Lcom/mbridge/msdk/thrid/okhttp/d0;)Lcom/mbridge/msdk/thrid/okhttp/j$a;

    move-result-object v0

    invoke-virtual {v0, v3}, Lcom/mbridge/msdk/thrid/okhttp/j$a;->a(Z)Lcom/mbridge/msdk/thrid/okhttp/j$a;

    move-result-object v0

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/j$a;->a()Lcom/mbridge/msdk/thrid/okhttp/j;

    move-result-object v0

    sput-object v0, Lcom/mbridge/msdk/thrid/okhttp/j;->h:Lcom/mbridge/msdk/thrid/okhttp/j;

    new-instance v0, Lcom/mbridge/msdk/thrid/okhttp/j$a;

    invoke-direct {v0, v3}, Lcom/mbridge/msdk/thrid/okhttp/j$a;-><init>(Z)V

    invoke-virtual {v0, v1}, Lcom/mbridge/msdk/thrid/okhttp/j$a;->a([Lcom/mbridge/msdk/thrid/okhttp/g;)Lcom/mbridge/msdk/thrid/okhttp/j$a;

    move-result-object v0

    filled-new-array {v6}, [Lcom/mbridge/msdk/thrid/okhttp/d0;

    move-result-object v1

    invoke-virtual {v0, v1}, Lcom/mbridge/msdk/thrid/okhttp/j$a;->a([Lcom/mbridge/msdk/thrid/okhttp/d0;)Lcom/mbridge/msdk/thrid/okhttp/j$a;

    move-result-object v0

    invoke-virtual {v0, v3}, Lcom/mbridge/msdk/thrid/okhttp/j$a;->a(Z)Lcom/mbridge/msdk/thrid/okhttp/j$a;

    move-result-object v0

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/j$a;->a()Lcom/mbridge/msdk/thrid/okhttp/j;

    move-result-object v0

    sput-object v0, Lcom/mbridge/msdk/thrid/okhttp/j;->i:Lcom/mbridge/msdk/thrid/okhttp/j;

    new-instance v0, Lcom/mbridge/msdk/thrid/okhttp/j$a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/mbridge/msdk/thrid/okhttp/j$a;-><init>(Z)V

    invoke-virtual {v0}, Lcom/mbridge/msdk/thrid/okhttp/j$a;->a()Lcom/mbridge/msdk/thrid/okhttp/j;

    move-result-object v0

    sput-object v0, Lcom/mbridge/msdk/thrid/okhttp/j;->j:Lcom/mbridge/msdk/thrid/okhttp/j;

    return-void
.end method

.method public constructor <init>(Lcom/mbridge/msdk/thrid/okhttp/j$a;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iget-boolean v0, p1, Lcom/mbridge/msdk/thrid/okhttp/j$a;->a:Z

    iput-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/j;->a:Z

    iget-object v0, p1, Lcom/mbridge/msdk/thrid/okhttp/j$a;->b:[Ljava/lang/String;

    iput-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/j;->c:[Ljava/lang/String;

    iget-object v0, p1, Lcom/mbridge/msdk/thrid/okhttp/j$a;->c:[Ljava/lang/String;

    iput-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/j;->d:[Ljava/lang/String;

    iget-boolean p1, p1, Lcom/mbridge/msdk/thrid/okhttp/j$a;->d:Z

    iput-boolean p1, p0, Lcom/mbridge/msdk/thrid/okhttp/j;->b:Z

    return-void
.end method

.method private b(Ljavax/net/ssl/SSLSocket;Z)Lcom/mbridge/msdk/thrid/okhttp/j;
    .registers 7

    .prologue
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/j;->c:[Ljava/lang/String;

    if-eqz v0, :cond_11

    sget-object v0, Lcom/mbridge/msdk/thrid/okhttp/g;->b:Ljava/util/Comparator;

    invoke-virtual {p1}, Ljavax/net/ssl/SSLSocket;->getEnabledCipherSuites()[Ljava/lang/String;

    move-result-object v1

    iget-object v2, p0, Lcom/mbridge/msdk/thrid/okhttp/j;->c:[Ljava/lang/String;

    invoke-static {v0, v1, v2}, Lcom/mbridge/msdk/thrid/okhttp/internal/c;->a(Ljava/util/Comparator;[Ljava/lang/String;[Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    goto :goto_15

    :cond_11
    invoke-virtual {p1}, Ljavax/net/ssl/SSLSocket;->getEnabledCipherSuites()[Ljava/lang/String;

    move-result-object v0

    :goto_15
    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/j;->d:[Ljava/lang/String;

    if-eqz v1, :cond_26

    sget-object v1, Lcom/mbridge/msdk/thrid/okhttp/internal/c;->q:Ljava/util/Comparator;

    invoke-virtual {p1}, Ljavax/net/ssl/SSLSocket;->getEnabledProtocols()[Ljava/lang/String;

    move-result-object v2

    iget-object v3, p0, Lcom/mbridge/msdk/thrid/okhttp/j;->d:[Ljava/lang/String;

    invoke-static {v1, v2, v3}, Lcom/mbridge/msdk/thrid/okhttp/internal/c;->a(Ljava/util/Comparator;[Ljava/lang/String;[Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v1

    goto :goto_2a

    :cond_26
    invoke-virtual {p1}, Ljavax/net/ssl/SSLSocket;->getEnabledProtocols()[Ljava/lang/String;

    move-result-object v1

    :goto_2a
    invoke-virtual {p1}, Ljavax/net/ssl/SSLSocket;->getSupportedCipherSuites()[Ljava/lang/String;

    move-result-object p1

    sget-object v2, Lcom/mbridge/msdk/thrid/okhttp/g;->b:Ljava/util/Comparator;

    const-string v3, "TLS_FALLBACK_SCSV"

    invoke-static {v2, p1, v3}, Lcom/mbridge/msdk/thrid/okhttp/internal/c;->a(Ljava/util/Comparator;[Ljava/lang/String;Ljava/lang/String;)I

    move-result v2

    if-eqz p2, :cond_41

    const/4 p2, -0x1

    if-eq v2, p2, :cond_41

    aget-object p1, p1, v2

    invoke-static {v0, p1}, Lcom/mbridge/msdk/thrid/okhttp/internal/c;->a([Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    :cond_41
    new-instance p1, Lcom/mbridge/msdk/thrid/okhttp/j$a;

    invoke-direct {p1, p0}, Lcom/mbridge/msdk/thrid/okhttp/j$a;-><init>(Lcom/mbridge/msdk/thrid/okhttp/j;)V

    invoke-virtual {p1, v0}, Lcom/mbridge/msdk/thrid/okhttp/j$a;->a([Ljava/lang/String;)Lcom/mbridge/msdk/thrid/okhttp/j$a;

    move-result-object p0

    invoke-virtual {p0, v1}, Lcom/mbridge/msdk/thrid/okhttp/j$a;->b([Ljava/lang/String;)Lcom/mbridge/msdk/thrid/okhttp/j$a;

    move-result-object p0

    invoke-virtual {p0}, Lcom/mbridge/msdk/thrid/okhttp/j$a;->a()Lcom/mbridge/msdk/thrid/okhttp/j;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public a()Ljava/util/List;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/mbridge/msdk/thrid/okhttp/g;",
            ">;"
        }
    .end annotation

    .prologue
    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/j;->c:[Ljava/lang/String;

    if-eqz p0, :cond_9

    invoke-static {p0}, Lcom/mbridge/msdk/thrid/okhttp/g;->a([Ljava/lang/String;)Ljava/util/List;

    move-result-object p0

    return-object p0

    :cond_9
    const/4 p0, 0x0

    return-object p0
.end method

.method public a(Ljavax/net/ssl/SSLSocket;Z)V
    .registers 3

    .prologue
    invoke-direct {p0, p1, p2}, Lcom/mbridge/msdk/thrid/okhttp/j;->b(Ljavax/net/ssl/SSLSocket;Z)Lcom/mbridge/msdk/thrid/okhttp/j;

    move-result-object p0

    iget-object p2, p0, Lcom/mbridge/msdk/thrid/okhttp/j;->d:[Ljava/lang/String;

    if-eqz p2, :cond_b

    invoke-virtual {p1, p2}, Ljavax/net/ssl/SSLSocket;->setEnabledProtocols([Ljava/lang/String;)V

    :cond_b
    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/j;->c:[Ljava/lang/String;

    if-eqz p0, :cond_12

    invoke-virtual {p1, p0}, Ljavax/net/ssl/SSLSocket;->setEnabledCipherSuites([Ljava/lang/String;)V

    :cond_12
    return-void
.end method

.method public a(Ljavax/net/ssl/SSLSocket;)Z
    .registers 6

    .prologue
    iget-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/j;->a:Z

    const/4 v1, 0x0

    if-nez v0, :cond_6

    return v1

    :cond_6
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/j;->d:[Ljava/lang/String;

    if-eqz v0, :cond_17

    sget-object v2, Lcom/mbridge/msdk/thrid/okhttp/internal/c;->q:Ljava/util/Comparator;

    invoke-virtual {p1}, Ljavax/net/ssl/SSLSocket;->getEnabledProtocols()[Ljava/lang/String;

    move-result-object v3

    invoke-static {v2, v0, v3}, Lcom/mbridge/msdk/thrid/okhttp/internal/c;->b(Ljava/util/Comparator;[Ljava/lang/String;[Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_17

    return v1

    :cond_17
    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/j;->c:[Ljava/lang/String;

    if-eqz p0, :cond_28

    sget-object v0, Lcom/mbridge/msdk/thrid/okhttp/g;->b:Ljava/util/Comparator;

    invoke-virtual {p1}, Ljavax/net/ssl/SSLSocket;->getEnabledCipherSuites()[Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p0, p1}, Lcom/mbridge/msdk/thrid/okhttp/internal/c;->b(Ljava/util/Comparator;[Ljava/lang/String;[Ljava/lang/String;)Z

    move-result p0

    if-nez p0, :cond_28

    return v1

    :cond_28
    const/4 p0, 0x1

    return p0
.end method

.method public b()Z
    .registers 1

    iget-boolean p0, p0, Lcom/mbridge/msdk/thrid/okhttp/j;->a:Z

    return p0
.end method

.method public c()Z
    .registers 1

    iget-boolean p0, p0, Lcom/mbridge/msdk/thrid/okhttp/j;->b:Z

    return p0
.end method

.method public d()Ljava/util/List;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/mbridge/msdk/thrid/okhttp/d0;",
            ">;"
        }
    .end annotation

    .prologue
    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/j;->d:[Ljava/lang/String;

    if-eqz p0, :cond_9

    invoke-static {p0}, Lcom/mbridge/msdk/thrid/okhttp/d0;->a([Ljava/lang/String;)Ljava/util/List;

    move-result-object p0

    return-object p0

    :cond_9
    const/4 p0, 0x0

    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 6

    .prologue
    instance-of v0, p1, Lcom/mbridge/msdk/thrid/okhttp/j;

    const/4 v1, 0x0

    if-nez v0, :cond_6

    return v1

    :cond_6
    const/4 v0, 0x1

    if-ne p1, p0, :cond_a

    return v0

    :cond_a
    check-cast p1, Lcom/mbridge/msdk/thrid/okhttp/j;

    iget-boolean v2, p0, Lcom/mbridge/msdk/thrid/okhttp/j;->a:Z

    iget-boolean v3, p1, Lcom/mbridge/msdk/thrid/okhttp/j;->a:Z

    if-eq v2, v3, :cond_13

    return v1

    :cond_13
    if-eqz v2, :cond_32

    iget-object v2, p0, Lcom/mbridge/msdk/thrid/okhttp/j;->c:[Ljava/lang/String;

    iget-object v3, p1, Lcom/mbridge/msdk/thrid/okhttp/j;->c:[Ljava/lang/String;

    invoke-static {v2, v3}, Ljava/util/Arrays;->equals([Ljava/lang/Object;[Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_20

    return v1

    :cond_20
    iget-object v2, p0, Lcom/mbridge/msdk/thrid/okhttp/j;->d:[Ljava/lang/String;

    iget-object v3, p1, Lcom/mbridge/msdk/thrid/okhttp/j;->d:[Ljava/lang/String;

    invoke-static {v2, v3}, Ljava/util/Arrays;->equals([Ljava/lang/Object;[Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_2b

    return v1

    :cond_2b
    iget-boolean p0, p0, Lcom/mbridge/msdk/thrid/okhttp/j;->b:Z

    iget-boolean p1, p1, Lcom/mbridge/msdk/thrid/okhttp/j;->b:Z

    if-eq p0, p1, :cond_32

    return v1

    :cond_32
    return v0
.end method

.method public hashCode()I
    .registers 3

    .prologue
    iget-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/j;->a:Z

    if-eqz v0, :cond_1d

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/j;->c:[Ljava/lang/String;

    invoke-static {v0}, Ljava/util/Arrays;->hashCode([Ljava/lang/Object;)I

    move-result v0

    add-int/lit16 v0, v0, 0x20f

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/j;->d:[Ljava/lang/String;

    invoke-static {v1}, Ljava/util/Arrays;->hashCode([Ljava/lang/Object;)I

    move-result v1

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-boolean p0, p0, Lcom/mbridge/msdk/thrid/okhttp/j;->b:Z

    xor-int/lit8 p0, p0, 0x1

    add-int/2addr v0, p0

    return v0

    :cond_1d
    const/16 p0, 0x11

    return p0
.end method

.method public toString()Ljava/lang/String;
    .registers 6

    .prologue
    iget-boolean v0, p0, Lcom/mbridge/msdk/thrid/okhttp/j;->a:Z

    if-nez v0, :cond_7

    const-string p0, "ConnectionSpec()"

    return-object p0

    :cond_7
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/j;->c:[Ljava/lang/String;

    const-string v1, "[all enabled]"

    if-eqz v0, :cond_16

    invoke-virtual {p0}, Lcom/mbridge/msdk/thrid/okhttp/j;->a()Ljava/util/List;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_17

    :cond_16
    move-object v0, v1

    :goto_17
    iget-object v2, p0, Lcom/mbridge/msdk/thrid/okhttp/j;->d:[Ljava/lang/String;

    if-eqz v2, :cond_23

    invoke-virtual {p0}, Lcom/mbridge/msdk/thrid/okhttp/j;->d()Ljava/util/List;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    :cond_23
    const-string v2, ", tlsVersions="

    const-string v3, ", supportsTlsExtensions="

    const-string v4, "ConnectionSpec(cipherSuites="

    invoke-static {v4, v0, v2, v1, v3}, Ly41;->t(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-boolean p0, p0, Lcom/mbridge/msdk/thrid/okhttp/j;->b:Z

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
