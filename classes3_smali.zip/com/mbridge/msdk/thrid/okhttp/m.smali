.class public final Lcom/mbridge/msdk/thrid/okhttp/m;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field static final synthetic h:Z = true


# instance fields
.field private a:I

.field private b:I

.field private c:Ljava/lang/Runnable;

.field private d:Ljava/util/concurrent/ExecutorService;

.field private final e:Ljava/util/Deque;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Deque<",
            "Lcom/mbridge/msdk/thrid/okhttp/x$b;",
            ">;"
        }
    .end annotation
.end field

.field private final f:Ljava/util/Deque;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Deque<",
            "Lcom/mbridge/msdk/thrid/okhttp/x$b;",
            ">;"
        }
    .end annotation
.end field

.field private final g:Ljava/util/Deque;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Deque<",
            "Lcom/mbridge/msdk/thrid/okhttp/x;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x40

    iput v0, p0, Lcom/mbridge/msdk/thrid/okhttp/m;->a:I

    const/4 v0, 0x5

    iput v0, p0, Lcom/mbridge/msdk/thrid/okhttp/m;->b:I

    new-instance v0, Ljava/util/ArrayDeque;

    invoke-direct {v0}, Ljava/util/ArrayDeque;-><init>()V

    iput-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/m;->e:Ljava/util/Deque;

    new-instance v0, Ljava/util/ArrayDeque;

    invoke-direct {v0}, Ljava/util/ArrayDeque;-><init>()V

    iput-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/m;->f:Ljava/util/Deque;

    new-instance v0, Ljava/util/ArrayDeque;

    invoke-direct {v0}, Ljava/util/ArrayDeque;-><init>()V

    iput-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/m;->g:Ljava/util/Deque;

    return-void
.end method

.method public constructor <init>(Ljava/util/concurrent/ExecutorService;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x40

    iput v0, p0, Lcom/mbridge/msdk/thrid/okhttp/m;->a:I

    const/4 v0, 0x5

    iput v0, p0, Lcom/mbridge/msdk/thrid/okhttp/m;->b:I

    new-instance v0, Ljava/util/ArrayDeque;

    invoke-direct {v0}, Ljava/util/ArrayDeque;-><init>()V

    iput-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/m;->e:Ljava/util/Deque;

    new-instance v0, Ljava/util/ArrayDeque;

    invoke-direct {v0}, Ljava/util/ArrayDeque;-><init>()V

    iput-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/m;->f:Ljava/util/Deque;

    new-instance v0, Ljava/util/ArrayDeque;

    invoke-direct {v0}, Ljava/util/ArrayDeque;-><init>()V

    iput-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/m;->g:Ljava/util/Deque;

    iput-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/m;->d:Ljava/util/concurrent/ExecutorService;

    return-void
.end method

.method private a(Ljava/util/Deque;Ljava/lang/Object;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/util/Deque<",
            "TT;>;TT;)V"
        }
    .end annotation

    .prologue
    monitor-enter p0

    :try_start_1
    invoke-interface {p1, p2}, Ljava/util/Deque;->remove(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_18

    iget-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/m;->c:Ljava/lang/Runnable;

    monitor-exit p0
    :try_end_a
    .catchall {:try_start_1 .. :try_end_a} :catchall_16

    invoke-direct {p0}, Lcom/mbridge/msdk/thrid/okhttp/m;->b()Z

    move-result p0

    if-nez p0, :cond_15

    if-eqz p1, :cond_15

    invoke-interface {p1}, Ljava/lang/Runnable;->run()V

    :cond_15
    return-void

    :catchall_16
    move-exception p1

    goto :goto_20

    :cond_18
    :try_start_18
    new-instance p1, Ljava/lang/AssertionError;

    const-string p2, "Call wasn\'t in-flight!"

    invoke-direct {p1, p2}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    throw p1

    :goto_20
    monitor-exit p0
    :try_end_21
    .catchall {:try_start_18 .. :try_end_21} :catchall_16

    throw p1
.end method

.method private b()Z
    .registers 7

    .prologue
    sget-boolean v0, Lcom/mbridge/msdk/thrid/okhttp/m;->h:Z

    const/4 v1, 0x0

    if-nez v0, :cond_10

    invoke-static {p0}, Ljava/lang/Thread;->holdsLock(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_c

    goto :goto_10

    :cond_c
    invoke-static {}, Lpw1;->l()V

    return v1

    :cond_10
    :goto_10
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    monitor-enter p0

    :try_start_16
    iget-object v2, p0, Lcom/mbridge/msdk/thrid/okhttp/m;->e:Ljava/util/Deque;

    invoke-interface {v2}, Ljava/util/Deque;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_1c
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_4a

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/mbridge/msdk/thrid/okhttp/x$b;

    iget-object v4, p0, Lcom/mbridge/msdk/thrid/okhttp/m;->f:Ljava/util/Deque;

    invoke-interface {v4}, Ljava/util/Deque;->size()I

    move-result v4

    iget v5, p0, Lcom/mbridge/msdk/thrid/okhttp/m;->a:I

    if-lt v4, v5, :cond_33

    goto :goto_4a

    :cond_33
    invoke-direct {p0, v3}, Lcom/mbridge/msdk/thrid/okhttp/m;->c(Lcom/mbridge/msdk/thrid/okhttp/x$b;)I

    move-result v4

    iget v5, p0, Lcom/mbridge/msdk/thrid/okhttp/m;->b:I

    if-lt v4, v5, :cond_3c

    goto :goto_1c

    :cond_3c
    invoke-interface {v2}, Ljava/util/Iterator;->remove()V

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object v4, p0, Lcom/mbridge/msdk/thrid/okhttp/m;->f:Ljava/util/Deque;

    invoke-interface {v4, v3}, Ljava/util/Deque;->add(Ljava/lang/Object;)Z

    goto :goto_1c

    :catchall_48
    move-exception v0

    goto :goto_6b

    :cond_4a
    :goto_4a
    invoke-virtual {p0}, Lcom/mbridge/msdk/thrid/okhttp/m;->c()I

    move-result v2

    if-lez v2, :cond_52

    const/4 v2, 0x1

    goto :goto_53

    :cond_52
    move v2, v1

    :goto_53
    monitor-exit p0
    :try_end_54
    .catchall {:try_start_16 .. :try_end_54} :catchall_48

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v3

    :goto_58
    if-ge v1, v3, :cond_6a

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/mbridge/msdk/thrid/okhttp/x$b;

    invoke-virtual {p0}, Lcom/mbridge/msdk/thrid/okhttp/m;->a()Ljava/util/concurrent/ExecutorService;

    move-result-object v5

    invoke-virtual {v4, v5}, Lcom/mbridge/msdk/thrid/okhttp/x$b;->a(Ljava/util/concurrent/ExecutorService;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_58

    :cond_6a
    return v2

    :goto_6b
    :try_start_6b
    monitor-exit p0
    :try_end_6c
    .catchall {:try_start_6b .. :try_end_6c} :catchall_48

    throw v0
.end method

.method private c(Lcom/mbridge/msdk/thrid/okhttp/x$b;)I
    .registers 5

    .prologue
    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/m;->f:Ljava/util/Deque;

    invoke-interface {p0}, Ljava/util/Deque;->iterator()Ljava/util/Iterator;

    move-result-object p0

    const/4 v0, 0x0

    :cond_7
    :goto_7
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2d

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/mbridge/msdk/thrid/okhttp/x$b;

    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okhttp/x$b;->c()Lcom/mbridge/msdk/thrid/okhttp/x;

    move-result-object v2

    iget-boolean v2, v2, Lcom/mbridge/msdk/thrid/okhttp/x;->f:Z

    if-eqz v2, :cond_1c

    goto :goto_7

    :cond_1c
    invoke-virtual {v1}, Lcom/mbridge/msdk/thrid/okhttp/x$b;->d()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1}, Lcom/mbridge/msdk/thrid/okhttp/x$b;->d()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_7

    add-int/lit8 v0, v0, 0x1

    goto :goto_7

    :cond_2d
    return v0
.end method


# virtual methods
.method public declared-synchronized a()Ljava/util/concurrent/ExecutorService;
    .registers 10

    .prologue
    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/m;->d:Ljava/util/concurrent/ExecutorService;

    if-nez v0, :cond_24

    new-instance v1, Ljava/util/concurrent/ThreadPoolExecutor;

    sget-object v6, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    new-instance v7, Ljava/util/concurrent/SynchronousQueue;

    invoke-direct {v7}, Ljava/util/concurrent/SynchronousQueue;-><init>()V

    const-string v0, "OkHttp Dispatcher"

    const/4 v2, 0x0

    invoke-static {v0, v2}, Lcom/mbridge/msdk/thrid/okhttp/internal/c;->a(Ljava/lang/String;Z)Ljava/util/concurrent/ThreadFactory;

    move-result-object v8

    const v3, 0x7fffffff

    const-wide/16 v4, 0x3c

    const/4 v2, 0x0

    invoke-direct/range {v1 .. v8}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;)V

    iput-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/m;->d:Ljava/util/concurrent/ExecutorService;
    :try_end_20
    .catchall {:try_start_1 .. :try_end_20} :catchall_22

    move-object v0, v1

    goto :goto_24

    :catchall_22
    move-exception v0

    goto :goto_26

    :cond_24
    :goto_24
    monitor-exit p0

    return-object v0

    :goto_26
    :try_start_26
    monitor-exit p0
    :try_end_27
    .catchall {:try_start_26 .. :try_end_27} :catchall_22

    throw v0
.end method

.method public a(I)V
    .registers 3

    .prologue
    const/4 v0, 0x1

    if-lt p1, v0, :cond_e

    monitor-enter p0

    :try_start_4
    iput p1, p0, Lcom/mbridge/msdk/thrid/okhttp/m;->a:I

    monitor-exit p0
    :try_end_7
    .catchall {:try_start_4 .. :try_end_7} :catchall_b

    invoke-direct {p0}, Lcom/mbridge/msdk/thrid/okhttp/m;->b()Z

    return-void

    :catchall_b
    move-exception p1

    :try_start_c
    monitor-exit p0
    :try_end_d
    .catchall {:try_start_c .. :try_end_d} :catchall_b

    throw p1

    :cond_e
    const-string p0, "max < 1: "

    invoke-static {p1, p0}, Lrt2;->f(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->s(Ljava/lang/String;)V

    return-void
.end method

.method public a(Lcom/mbridge/msdk/thrid/okhttp/x$b;)V
    .registers 3

    .prologue
    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/m;->e:Ljava/util/Deque;

    invoke-interface {v0, p1}, Ljava/util/Deque;->add(Ljava/lang/Object;)Z

    monitor-exit p0
    :try_end_7
    .catchall {:try_start_1 .. :try_end_7} :catchall_b

    invoke-direct {p0}, Lcom/mbridge/msdk/thrid/okhttp/m;->b()Z

    return-void

    :catchall_b
    move-exception p1

    :try_start_c
    monitor-exit p0
    :try_end_d
    .catchall {:try_start_c .. :try_end_d} :catchall_b

    throw p1
.end method

.method public declared-synchronized a(Lcom/mbridge/msdk/thrid/okhttp/x;)V
    .registers 3

    .prologue
    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/m;->g:Ljava/util/Deque;

    invoke-interface {v0, p1}, Ljava/util/Deque;->add(Ljava/lang/Object;)Z
    :try_end_6
    .catchall {:try_start_1 .. :try_end_6} :catchall_8

    monitor-exit p0

    return-void

    :catchall_8
    move-exception p1

    :try_start_9
    monitor-exit p0
    :try_end_a
    .catchall {:try_start_9 .. :try_end_a} :catchall_8

    throw p1
.end method

.method public b(I)V
    .registers 3

    .prologue
    const/4 v0, 0x1

    if-lt p1, v0, :cond_e

    monitor-enter p0

    :try_start_4
    iput p1, p0, Lcom/mbridge/msdk/thrid/okhttp/m;->b:I

    monitor-exit p0
    :try_end_7
    .catchall {:try_start_4 .. :try_end_7} :catchall_b

    invoke-direct {p0}, Lcom/mbridge/msdk/thrid/okhttp/m;->b()Z

    return-void

    :catchall_b
    move-exception p1

    :try_start_c
    monitor-exit p0
    :try_end_d
    .catchall {:try_start_c .. :try_end_d} :catchall_b

    throw p1

    :cond_e
    const-string p0, "max < 1: "

    invoke-static {p1, p0}, Lrt2;->f(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->s(Ljava/lang/String;)V

    return-void
.end method

.method public b(Lcom/mbridge/msdk/thrid/okhttp/x$b;)V
    .registers 3

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/m;->f:Ljava/util/Deque;

    invoke-direct {p0, v0, p1}, Lcom/mbridge/msdk/thrid/okhttp/m;->a(Ljava/util/Deque;Ljava/lang/Object;)V

    return-void
.end method

.method public b(Lcom/mbridge/msdk/thrid/okhttp/x;)V
    .registers 3

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/m;->g:Ljava/util/Deque;

    invoke-direct {p0, v0, p1}, Lcom/mbridge/msdk/thrid/okhttp/m;->a(Ljava/util/Deque;Ljava/lang/Object;)V

    return-void
.end method

.method public declared-synchronized c()I
    .registers 3

    .prologue
    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/m;->f:Ljava/util/Deque;

    invoke-interface {v0}, Ljava/util/Deque;->size()I

    move-result v0

    iget-object v1, p0, Lcom/mbridge/msdk/thrid/okhttp/m;->g:Ljava/util/Deque;

    invoke-interface {v1}, Ljava/util/Deque;->size()I

    move-result v1
    :try_end_d
    .catchall {:try_start_1 .. :try_end_d} :catchall_10

    add-int/2addr v0, v1

    monitor-exit p0

    return v0

    :catchall_10
    move-exception v0

    :try_start_11
    monitor-exit p0
    :try_end_12
    .catchall {:try_start_11 .. :try_end_12} :catchall_10

    throw v0
.end method
