.class public final enum Lcom/mbridge/msdk/thrid/okhttp/w;
.super Ljava/lang/Enum;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/mbridge/msdk/thrid/okhttp/w;",
        ">;"
    }
.end annotation


# static fields
.field public static final enum b:Lcom/mbridge/msdk/thrid/okhttp/w;

.field public static final enum c:Lcom/mbridge/msdk/thrid/okhttp/w;

.field public static final enum d:Lcom/mbridge/msdk/thrid/okhttp/w;

.field public static final enum e:Lcom/mbridge/msdk/thrid/okhttp/w;

.field public static final enum f:Lcom/mbridge/msdk/thrid/okhttp/w;

.field public static final enum g:Lcom/mbridge/msdk/thrid/okhttp/w;

.field private static final synthetic h:[Lcom/mbridge/msdk/thrid/okhttp/w;


# instance fields
.field private final a:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 9

    new-instance v0, Lcom/mbridge/msdk/thrid/okhttp/w;

    const/4 v1, 0x0

    const-string v2, "http/1.0"

    const-string v3, "HTTP_1_0"

    invoke-direct {v0, v3, v1, v2}, Lcom/mbridge/msdk/thrid/okhttp/w;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v0, Lcom/mbridge/msdk/thrid/okhttp/w;->b:Lcom/mbridge/msdk/thrid/okhttp/w;

    new-instance v1, Lcom/mbridge/msdk/thrid/okhttp/w;

    const/4 v2, 0x1

    const-string v3, "http/1.1"

    const-string v4, "HTTP_1_1"

    invoke-direct {v1, v4, v2, v3}, Lcom/mbridge/msdk/thrid/okhttp/w;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v1, Lcom/mbridge/msdk/thrid/okhttp/w;->c:Lcom/mbridge/msdk/thrid/okhttp/w;

    new-instance v2, Lcom/mbridge/msdk/thrid/okhttp/w;

    const/4 v3, 0x2

    const-string v4, "spdy/3.1"

    const-string v5, "SPDY_3"

    invoke-direct {v2, v5, v3, v4}, Lcom/mbridge/msdk/thrid/okhttp/w;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v2, Lcom/mbridge/msdk/thrid/okhttp/w;->d:Lcom/mbridge/msdk/thrid/okhttp/w;

    new-instance v3, Lcom/mbridge/msdk/thrid/okhttp/w;

    const/4 v4, 0x3

    const-string v5, "h2"

    const-string v6, "HTTP_2"

    invoke-direct {v3, v6, v4, v5}, Lcom/mbridge/msdk/thrid/okhttp/w;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v3, Lcom/mbridge/msdk/thrid/okhttp/w;->e:Lcom/mbridge/msdk/thrid/okhttp/w;

    new-instance v4, Lcom/mbridge/msdk/thrid/okhttp/w;

    const/4 v5, 0x4

    const-string v6, "h2_prior_knowledge"

    const-string v7, "H2_PRIOR_KNOWLEDGE"

    invoke-direct {v4, v7, v5, v6}, Lcom/mbridge/msdk/thrid/okhttp/w;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v4, Lcom/mbridge/msdk/thrid/okhttp/w;->f:Lcom/mbridge/msdk/thrid/okhttp/w;

    new-instance v5, Lcom/mbridge/msdk/thrid/okhttp/w;

    const/4 v6, 0x5

    const-string v7, "quic"

    const-string v8, "QUIC"

    invoke-direct {v5, v8, v6, v7}, Lcom/mbridge/msdk/thrid/okhttp/w;-><init>(Ljava/lang/String;ILjava/lang/String;)V

    sput-object v5, Lcom/mbridge/msdk/thrid/okhttp/w;->g:Lcom/mbridge/msdk/thrid/okhttp/w;

    filled-new-array/range {v0 .. v5}, [Lcom/mbridge/msdk/thrid/okhttp/w;

    move-result-object v0

    sput-object v0, Lcom/mbridge/msdk/thrid/okhttp/w;->h:[Lcom/mbridge/msdk/thrid/okhttp/w;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;ILjava/lang/String;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput-object p3, p0, Lcom/mbridge/msdk/thrid/okhttp/w;->a:Ljava/lang/String;

    return-void
.end method

.method public static a(Ljava/lang/String;)Lcom/mbridge/msdk/thrid/okhttp/w;
    .registers 3

    .prologue
    sget-object v0, Lcom/mbridge/msdk/thrid/okhttp/w;->b:Lcom/mbridge/msdk/thrid/okhttp/w;

    iget-object v1, v0, Lcom/mbridge/msdk/thrid/okhttp/w;->a:Ljava/lang/String;

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_b

    return-object v0

    :cond_b
    sget-object v0, Lcom/mbridge/msdk/thrid/okhttp/w;->c:Lcom/mbridge/msdk/thrid/okhttp/w;

    iget-object v1, v0, Lcom/mbridge/msdk/thrid/okhttp/w;->a:Ljava/lang/String;

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_16

    return-object v0

    :cond_16
    sget-object v0, Lcom/mbridge/msdk/thrid/okhttp/w;->f:Lcom/mbridge/msdk/thrid/okhttp/w;

    iget-object v1, v0, Lcom/mbridge/msdk/thrid/okhttp/w;->a:Ljava/lang/String;

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_21

    return-object v0

    :cond_21
    sget-object v0, Lcom/mbridge/msdk/thrid/okhttp/w;->e:Lcom/mbridge/msdk/thrid/okhttp/w;

    iget-object v1, v0, Lcom/mbridge/msdk/thrid/okhttp/w;->a:Ljava/lang/String;

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_2c

    return-object v0

    :cond_2c
    sget-object v0, Lcom/mbridge/msdk/thrid/okhttp/w;->d:Lcom/mbridge/msdk/thrid/okhttp/w;

    iget-object v1, v0, Lcom/mbridge/msdk/thrid/okhttp/w;->a:Ljava/lang/String;

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_37

    return-object v0

    :cond_37
    sget-object v0, Lcom/mbridge/msdk/thrid/okhttp/w;->g:Lcom/mbridge/msdk/thrid/okhttp/w;

    iget-object v1, v0, Lcom/mbridge/msdk/thrid/okhttp/w;->a:Ljava/lang/String;

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_42

    return-object v0

    :cond_42
    const-string v0, "Unexpected protocol: "

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lvh0;->k(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/mbridge/msdk/thrid/okhttp/w;
    .registers 2

    const-class v0, Lcom/mbridge/msdk/thrid/okhttp/w;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lcom/mbridge/msdk/thrid/okhttp/w;

    return-object p0
.end method

.method public static values()[Lcom/mbridge/msdk/thrid/okhttp/w;
    .registers 1

    sget-object v0, Lcom/mbridge/msdk/thrid/okhttp/w;->h:[Lcom/mbridge/msdk/thrid/okhttp/w;

    invoke-virtual {v0}, [Lcom/mbridge/msdk/thrid/okhttp/w;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/mbridge/msdk/thrid/okhttp/w;

    return-object v0
.end method


# virtual methods
.method public toString()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/w;->a:Ljava/lang/String;

    return-object p0
.end method
