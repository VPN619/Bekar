.class final Lcom/mbridge/msdk/thrid/okhttp/z$a;
.super Lcom/mbridge/msdk/thrid/okhttp/z;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/mbridge/msdk/thrid/okhttp/z;->a(Lcom/mbridge/msdk/thrid/okhttp/u;[BII)Lcom/mbridge/msdk/thrid/okhttp/z;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/mbridge/msdk/thrid/okhttp/u;

.field final synthetic b:I

.field final synthetic c:[B

.field final synthetic d:I


# direct methods
.method public constructor <init>(Lcom/mbridge/msdk/thrid/okhttp/u;I[BI)V
    .registers 5

    iput-object p1, p0, Lcom/mbridge/msdk/thrid/okhttp/z$a;->a:Lcom/mbridge/msdk/thrid/okhttp/u;

    iput p2, p0, Lcom/mbridge/msdk/thrid/okhttp/z$a;->b:I

    iput-object p3, p0, Lcom/mbridge/msdk/thrid/okhttp/z$a;->c:[B

    iput p4, p0, Lcom/mbridge/msdk/thrid/okhttp/z$a;->d:I

    invoke-direct {p0}, Lcom/mbridge/msdk/thrid/okhttp/z;-><init>()V

    return-void
.end method


# virtual methods
.method public a()J
    .registers 3

    iget p0, p0, Lcom/mbridge/msdk/thrid/okhttp/z$a;->b:I

    int-to-long v0, p0

    return-wide v0
.end method

.method public a(Lcom/mbridge/msdk/thrid/okio/d;)V
    .registers 4

    iget-object v0, p0, Lcom/mbridge/msdk/thrid/okhttp/z$a;->c:[B

    iget v1, p0, Lcom/mbridge/msdk/thrid/okhttp/z$a;->d:I

    iget p0, p0, Lcom/mbridge/msdk/thrid/okhttp/z$a;->b:I

    invoke-interface {p1, v0, v1, p0}, Lcom/mbridge/msdk/thrid/okio/d;->write([BII)Lcom/mbridge/msdk/thrid/okio/d;

    return-void
.end method

.method public b()Lcom/mbridge/msdk/thrid/okhttp/u;
    .registers 1

    iget-object p0, p0, Lcom/mbridge/msdk/thrid/okhttp/z$a;->a:Lcom/mbridge/msdk/thrid/okhttp/u;

    return-object p0
.end method
