.class public interface abstract Lcom/mbridge/msdk/thrid/okhttp/h;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# virtual methods
.method public abstract a()Lcom/mbridge/msdk/thrid/okhttp/w;
.end method

.method public abstract b()Lcom/mbridge/msdk/thrid/okhttp/q;
.end method

.method public abstract c()Lcom/mbridge/msdk/thrid/okhttp/c0;
.end method
