.class public interface abstract Lcom/mbridge/msdk/thrid/okhttp/b;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final a:Lcom/mbridge/msdk/thrid/okhttp/b;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/mbridge/msdk/thrid/okhttp/b$a;

    invoke-direct {v0}, Lcom/mbridge/msdk/thrid/okhttp/b$a;-><init>()V

    sput-object v0, Lcom/mbridge/msdk/thrid/okhttp/b;->a:Lcom/mbridge/msdk/thrid/okhttp/b;

    return-void
.end method


# virtual methods
.method public abstract a(Lcom/mbridge/msdk/thrid/okhttp/c0;Lcom/mbridge/msdk/thrid/okhttp/a0;)Lcom/mbridge/msdk/thrid/okhttp/y;
.end method
