.class public final Lcom/mbridge/msdk/R$style;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/mbridge/msdk/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "style"
.end annotation


# static fields
.field public static AppBaseTheme:I = 0x7f14000b

.field public static MBridgeAppTheme:I = 0x7f140138

.field public static TextAppearance_Compat_Notification:I = 0x7f140255

.field public static TextAppearance_Compat_Notification_Info:I = 0x7f140256

.field public static TextAppearance_Compat_Notification_Line2:I = 0x7f140257

.field public static TextAppearance_Compat_Notification_Time:I = 0x7f140258

.field public static TextAppearance_Compat_Notification_Title:I = 0x7f140259

.field public static Widget_Compat_NotificationActionContainer:I = 0x7f140470

.field public static Widget_Compat_NotificationActionText:I = 0x7f140471

.field public static Widget_Support_CoordinatorLayout:I = 0x7f14061e

.field public static mbridge_common_activity_style:I = 0x7f14061f

.field public static mbridge_reward_theme:I = 0x7f140620

.field public static mbridge_transparent_common_activity_style:I = 0x7f140621

.field public static mbridge_transparent_theme:I = 0x7f140622

.field public static myDialog:I = 0x7f140623


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
