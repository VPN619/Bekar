.class public final Lcom/mbridge/msdk/R$attr;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/mbridge/msdk/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "attr"
.end annotation


# static fields
.field public static alpha:I = 0x7f040036

.field public static buttonSize:I = 0x7f0400a6

.field public static circleCrop:I = 0x7f0400e6

.field public static colorScheme:I = 0x7f040139

.field public static coordinatorLayoutStyle:I = 0x7f04017d

.field public static corner:I = 0x7f04017f

.field public static font:I = 0x7f040268

.field public static fontProviderAuthority:I = 0x7f04026a

.field public static fontProviderCerts:I = 0x7f04026b

.field public static fontProviderFetchStrategy:I = 0x7f04026d

.field public static fontProviderFetchTimeout:I = 0x7f04026e

.field public static fontProviderPackage:I = 0x7f04026f

.field public static fontProviderQuery:I = 0x7f040270

.field public static fontStyle:I = 0x7f040272

.field public static fontVariationSettings:I = 0x7f040273

.field public static fontWeight:I = 0x7f040274

.field public static imageAspectRatio:I = 0x7f0402b7

.field public static imageAspectRatioAdjust:I = 0x7f0402b8

.field public static keylines:I = 0x7f0402f5

.field public static layout_anchor:I = 0x7f040305

.field public static layout_anchorGravity:I = 0x7f040306

.field public static layout_behavior:I = 0x7f040307

.field public static layout_dodgeInsetEdges:I = 0x7f040338

.field public static layout_insetEdge:I = 0x7f040342

.field public static layout_keyline:I = 0x7f040343

.field public static mbridge_click:I = 0x7f0403bf

.field public static mbridge_data:I = 0x7f0403c0

.field public static mbridge_effect:I = 0x7f0403c1

.field public static mbridge_effect_strategy:I = 0x7f0403c2

.field public static mbridge_imageEffect:I = 0x7f0403c3

.field public static mbridge_radius:I = 0x7f0403c4

.field public static mbridge_report:I = 0x7f0403c5

.field public static mbridge_strategy:I = 0x7f0403c6

.field public static mbridge_visible:I = 0x7f0403c7

.field public static scopeUris:I = 0x7f040490

.field public static statusBarBackground:I = 0x7f040503

.field public static ttcIndex:I = 0x7f0405f9


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
