.class public interface abstract Lcom/mbridge/msdk/video/dynview/listener/g;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# virtual methods
.method public abstract a(ILjava/lang/String;)V
.end method

.method public abstract a(Landroid/view/ViewGroup;Lcom/mbridge/msdk/foundation/entity/CampaignUnit;)V
.end method
