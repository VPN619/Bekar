.class public Lcom/mbridge/msdk/video/dynview/energize/a;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field private static volatile b:Lcom/mbridge/msdk/video/dynview/energize/a;


# instance fields
.field public a:Lcom/mbridge/msdk/video/dynview/inter/a;


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static a()Lcom/mbridge/msdk/video/dynview/energize/a;
    .registers 2

    .prologue
    sget-object v0, Lcom/mbridge/msdk/video/dynview/energize/a;->b:Lcom/mbridge/msdk/video/dynview/energize/a;

    if-nez v0, :cond_1b

    const-class v0, Lcom/mbridge/msdk/video/dynview/energize/a;

    monitor-enter v0

    :try_start_7
    sget-object v1, Lcom/mbridge/msdk/video/dynview/energize/a;->b:Lcom/mbridge/msdk/video/dynview/energize/a;

    if-nez v1, :cond_15

    new-instance v1, Lcom/mbridge/msdk/video/dynview/energize/a;

    invoke-direct {v1}, Lcom/mbridge/msdk/video/dynview/energize/a;-><init>()V

    sput-object v1, Lcom/mbridge/msdk/video/dynview/energize/a;->b:Lcom/mbridge/msdk/video/dynview/energize/a;

    goto :goto_15

    :catchall_13
    move-exception v1

    goto :goto_19

    :cond_15
    :goto_15
    sget-object v1, Lcom/mbridge/msdk/video/dynview/energize/a;->b:Lcom/mbridge/msdk/video/dynview/energize/a;

    monitor-exit v0

    return-object v1

    :goto_19
    monitor-exit v0
    :try_end_1a
    .catchall {:try_start_7 .. :try_end_1a} :catchall_13

    throw v1

    :cond_1b
    sget-object v0, Lcom/mbridge/msdk/video/dynview/energize/a;->b:Lcom/mbridge/msdk/video/dynview/energize/a;

    return-object v0
.end method

.method private a(Lcom/mbridge/msdk/video/dynview/c;Landroid/view/View;Lcom/mbridge/msdk/video/dynview/listener/e;)V
    .registers 4

    new-instance p0, Lcom/mbridge/msdk/video/dynview/wrapper/a;

    invoke-direct {p0}, Lcom/mbridge/msdk/video/dynview/wrapper/a;-><init>()V

    invoke-virtual {p0, p1, p2, p3}, Lcom/mbridge/msdk/video/dynview/wrapper/a;->a(Lcom/mbridge/msdk/video/dynview/c;Landroid/view/View;Lcom/mbridge/msdk/video/dynview/listener/e;)V

    return-void
.end method

.method private a(Lcom/mbridge/msdk/video/dynview/c;Landroid/view/View;Ljava/util/Map;Lcom/mbridge/msdk/video/dynview/listener/e;)V
    .registers 6

    new-instance v0, Lcom/mbridge/msdk/video/dynview/wrapper/a;

    invoke-direct {v0}, Lcom/mbridge/msdk/video/dynview/wrapper/a;-><init>()V

    invoke-virtual {v0, p1, p2, p3, p4}, Lcom/mbridge/msdk/video/dynview/wrapper/a;->a(Lcom/mbridge/msdk/video/dynview/c;Landroid/view/View;Ljava/util/Map;Lcom/mbridge/msdk/video/dynview/listener/e;)V

    iget-object p1, v0, Lcom/mbridge/msdk/video/dynview/wrapper/a;->l:Lcom/mbridge/msdk/video/dynview/inter/a;

    iput-object p1, p0, Lcom/mbridge/msdk/video/dynview/energize/a;->a:Lcom/mbridge/msdk/video/dynview/inter/a;

    return-void
.end method

.method private b(Lcom/mbridge/msdk/video/dynview/c;Landroid/view/View;Ljava/util/Map;Lcom/mbridge/msdk/video/dynview/listener/e;)V
    .registers 5

    new-instance p0, Lcom/mbridge/msdk/video/dynview/wrapper/a;

    invoke-direct {p0}, Lcom/mbridge/msdk/video/dynview/wrapper/a;-><init>()V

    invoke-virtual {p0, p1, p2, p3, p4}, Lcom/mbridge/msdk/video/dynview/wrapper/a;->b(Lcom/mbridge/msdk/video/dynview/c;Landroid/view/View;Ljava/util/Map;Lcom/mbridge/msdk/video/dynview/listener/e;)V

    return-void
.end method

.method private c(Lcom/mbridge/msdk/video/dynview/c;Landroid/view/View;Ljava/util/Map;Lcom/mbridge/msdk/video/dynview/listener/e;)V
    .registers 5

    new-instance p0, Lcom/mbridge/msdk/video/dynview/wrapper/a;

    invoke-direct {p0}, Lcom/mbridge/msdk/video/dynview/wrapper/a;-><init>()V

    invoke-virtual {p0, p1, p2, p3, p4}, Lcom/mbridge/msdk/video/dynview/wrapper/a;->c(Lcom/mbridge/msdk/video/dynview/c;Landroid/view/View;Ljava/util/Map;Lcom/mbridge/msdk/video/dynview/listener/e;)V

    return-void
.end method


# virtual methods
.method public a(Landroid/view/View;Lcom/mbridge/msdk/video/dynview/c;Ljava/util/Map;Lcom/mbridge/msdk/video/dynview/listener/e;)V
    .registers 7

    .prologue
    invoke-virtual {p2}, Lcom/mbridge/msdk/video/dynview/c;->g()I

    move-result v0

    const/4 v1, 0x1

    if-eq v0, v1, :cond_25

    const/4 v1, 0x2

    if-eq v0, v1, :cond_21

    const/4 v1, 0x4

    if-eq v0, v1, :cond_1d

    const/4 v1, 0x5

    if-eq v0, v1, :cond_19

    new-instance p0, Ljava/util/ArrayList;

    invoke-direct {p0}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {p4, p1, p0}, Lcom/mbridge/msdk/video/dynview/listener/e;->a(Landroid/view/View;Ljava/util/List;)V

    return-void

    :cond_19
    invoke-direct {p0, p2, p1, p3, p4}, Lcom/mbridge/msdk/video/dynview/energize/a;->c(Lcom/mbridge/msdk/video/dynview/c;Landroid/view/View;Ljava/util/Map;Lcom/mbridge/msdk/video/dynview/listener/e;)V

    return-void

    :cond_1d
    invoke-direct {p0, p2, p1, p4}, Lcom/mbridge/msdk/video/dynview/energize/a;->a(Lcom/mbridge/msdk/video/dynview/c;Landroid/view/View;Lcom/mbridge/msdk/video/dynview/listener/e;)V

    return-void

    :cond_21
    invoke-direct {p0, p2, p1, p3, p4}, Lcom/mbridge/msdk/video/dynview/energize/a;->b(Lcom/mbridge/msdk/video/dynview/c;Landroid/view/View;Ljava/util/Map;Lcom/mbridge/msdk/video/dynview/listener/e;)V

    return-void

    :cond_25
    invoke-direct {p0, p2, p1, p3, p4}, Lcom/mbridge/msdk/video/dynview/energize/a;->a(Lcom/mbridge/msdk/video/dynview/c;Landroid/view/View;Ljava/util/Map;Lcom/mbridge/msdk/video/dynview/listener/e;)V

    return-void
.end method

.method public b()V
    .registers 1

    .prologue
    iget-object p0, p0, Lcom/mbridge/msdk/video/dynview/energize/a;->a:Lcom/mbridge/msdk/video/dynview/inter/a;

    if-eqz p0, :cond_7

    invoke-interface {p0}, Lcom/mbridge/msdk/video/dynview/inter/a;->b()V

    :cond_7
    return-void
.end method

.method public c()V
    .registers 1

    .prologue
    iget-object p0, p0, Lcom/mbridge/msdk/video/dynview/energize/a;->a:Lcom/mbridge/msdk/video/dynview/inter/a;

    if-eqz p0, :cond_7

    invoke-interface {p0}, Lcom/mbridge/msdk/video/dynview/inter/a;->a()V

    :cond_7
    return-void
.end method

.method public d()V
    .registers 1

    .prologue
    iget-object p0, p0, Lcom/mbridge/msdk/video/dynview/energize/a;->a:Lcom/mbridge/msdk/video/dynview/inter/a;

    if-eqz p0, :cond_7

    invoke-interface {p0}, Lcom/mbridge/msdk/video/dynview/inter/a;->c()V

    :cond_7
    return-void
.end method
