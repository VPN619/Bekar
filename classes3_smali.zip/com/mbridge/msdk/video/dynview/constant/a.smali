.class public Lcom/mbridge/msdk/video/dynview/constant/a;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static a:I

.field public static b:I

.field public static c:I

.field public static d:I

.field public static e:I


# direct methods
.method public static a(IIIII)V
    .registers 5

    sput p0, Lcom/mbridge/msdk/video/dynview/constant/a;->e:I

    sput p1, Lcom/mbridge/msdk/video/dynview/constant/a;->a:I

    sput p2, Lcom/mbridge/msdk/video/dynview/constant/a;->b:I

    sput p3, Lcom/mbridge/msdk/video/dynview/constant/a;->c:I

    sput p4, Lcom/mbridge/msdk/video/dynview/constant/a;->d:I

    return-void
.end method
