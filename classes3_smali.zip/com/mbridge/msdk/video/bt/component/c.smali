.class public Lcom/mbridge/msdk/video/bt/component/c;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/mbridge/msdk/video/bt/component/c$b;
    }
.end annotation


# instance fields
.field private a:Ljava/lang/String;

.field b:I

.field c:I


# direct methods
.method private constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v0, "handlerNativeResult"

    iput-object v0, p0, Lcom/mbridge/msdk/video/bt/component/c;->a:Ljava/lang/String;

    const/4 v0, 0x0

    iput v0, p0, Lcom/mbridge/msdk/video/bt/component/c;->b:I

    const/4 v0, 0x1

    iput v0, p0, Lcom/mbridge/msdk/video/bt/component/c;->c:I

    return-void
.end method

.method public synthetic constructor <init>(Lcom/mbridge/msdk/video/bt/component/c$a;)V
    .registers 2

    invoke-direct {p0}, Lcom/mbridge/msdk/video/bt/component/c;-><init>()V

    return-void
.end method

.method public static a()Lcom/mbridge/msdk/video/bt/component/c;
    .registers 1

    invoke-static {}, Lcom/mbridge/msdk/video/bt/component/c$b;->a()Lcom/mbridge/msdk/video/bt/component/c;

    move-result-object v0

    return-object v0
.end method


# virtual methods
.method public a(ILjava/lang/String;Ljava/lang/Object;)V
    .registers 6

    .prologue
    const-string p0, "HandlerH5MessageManager"

    :try_start_2
    new-instance v0, Lorg/json/JSONObject;

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const-string v1, "code"

    invoke-virtual {v0, v1, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const-string p1, "message"

    invoke-virtual {v0, p1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-static {}, Lcom/mbridge/msdk/mbsignalcommon/windvane/f;->a()Lcom/mbridge/msdk/mbsignalcommon/windvane/f;

    move-result-object p1

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/String;->getBytes()[B

    move-result-object p2

    const/4 v0, 0x2

    invoke-static {p2, v0}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p3, p2}, Lcom/mbridge/msdk/mbsignalcommon/windvane/f;->b(Ljava/lang/Object;Ljava/lang/String;)V
    :try_end_25
    .catch Lorg/json/JSONException; {:try_start_2 .. :try_end_25} :catch_28
    .catchall {:try_start_2 .. :try_end_25} :catchall_26

    return-void

    :catchall_26
    move-exception p1

    goto :goto_2a

    :catch_28
    move-exception p1

    goto :goto_32

    :goto_2a
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-static {p0, p1}, Lcom/mbridge/msdk/foundation/tools/q0;->a(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_39

    :goto_32
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    invoke-static {p0, p1}, Lcom/mbridge/msdk/foundation/tools/q0;->a(Ljava/lang/String;Ljava/lang/String;)V

    :goto_39
    return-void
.end method

.method public a(Ljava/lang/Object;Lorg/json/JSONObject;)V
    .registers 9

    .prologue
    const-string v0, "HandlerH5MessageManager"

    if-eqz p2, :cond_7b

    :try_start_4
    invoke-virtual {p2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_f

    goto :goto_7b

    :cond_f
    const-string v1, "uniqueIdentifier"

    invoke-virtual {p2, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "name"

    invoke-virtual {p2, v2}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_73

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_28

    goto :goto_73

    :cond_28
    const-string v3, "parameters"

    invoke-virtual {p2, v3}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v3

    const-string v4, "result"

    invoke-virtual {p2, v4}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p2

    const/4 v4, 0x0

    if-eqz p2, :cond_4c

    invoke-virtual {p2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v5

    if-nez v5, :cond_4c

    const-string v5, "type"

    invoke-virtual {p2, v5, v4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v4

    goto :goto_4c

    :catchall_48
    move-exception p2

    goto :goto_83

    :catch_4a
    move-exception p2

    goto :goto_94

    :cond_4c
    :goto_4c
    iget p2, p0, Lcom/mbridge/msdk/video/bt/component/c;->b:I

    const-string v5, "receivedMessage"

    invoke-virtual {p0, p2, v5, p1}, Lcom/mbridge/msdk/video/bt/component/c;->a(ILjava/lang/String;Ljava/lang/Object;)V

    const-string p2, "reporter"

    invoke-virtual {v1, p2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result p2

    if-eqz p2, :cond_63

    invoke-static {}, Lcom/mbridge/msdk/mbsignalcommon/Report/a;->a()Lcom/mbridge/msdk/mbsignalcommon/Report/a;

    move-result-object p2

    invoke-virtual {p2, p1, v2, v3, v4}, Lcom/mbridge/msdk/mbsignalcommon/Report/a;->a(Ljava/lang/Object;Ljava/lang/String;Lorg/json/JSONArray;I)V

    return-void

    :cond_63
    const-string p2, "MediaPlayer"

    invoke-virtual {v1, p2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result p2

    if-eqz p2, :cond_a4

    invoke-static {}, Lcom/mbridge/msdk/video/bt/component/b;->a()Lcom/mbridge/msdk/video/bt/component/b;

    move-result-object p2

    invoke-virtual {p2, p1, v2, v3, v4}, Lcom/mbridge/msdk/video/bt/component/b;->a(Ljava/lang/Object;Ljava/lang/String;Lorg/json/JSONArray;I)V

    return-void

    :cond_73
    :goto_73
    iget p2, p0, Lcom/mbridge/msdk/video/bt/component/c;->c:I

    const-string v1, "module or method is null"

    invoke-virtual {p0, p2, v1, p1}, Lcom/mbridge/msdk/video/bt/component/c;->a(ILjava/lang/String;Ljava/lang/Object;)V

    return-void

    :cond_7b
    :goto_7b
    iget p2, p0, Lcom/mbridge/msdk/video/bt/component/c;->c:I

    const-string v1, "params is null"

    invoke-virtual {p0, p2, v1, p1}, Lcom/mbridge/msdk/video/bt/component/c;->a(ILjava/lang/String;Ljava/lang/Object;)V
    :try_end_82
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_82} :catch_4a
    .catchall {:try_start_4 .. :try_end_82} :catchall_48

    return-void

    :goto_83
    invoke-virtual {p2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/mbridge/msdk/foundation/tools/q0;->a(Ljava/lang/String;Ljava/lang/String;)V

    iget v0, p0, Lcom/mbridge/msdk/video/bt/component/c;->c:I

    invoke-virtual {p2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p0, v0, p2, p1}, Lcom/mbridge/msdk/video/bt/component/c;->a(ILjava/lang/String;Ljava/lang/Object;)V

    goto :goto_a4

    :goto_94
    invoke-virtual {p2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lcom/mbridge/msdk/foundation/tools/q0;->a(Ljava/lang/String;Ljava/lang/String;)V

    iget v0, p0, Lcom/mbridge/msdk/video/bt/component/c;->c:I

    invoke-virtual {p2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p0, v0, p2, p1}, Lcom/mbridge/msdk/video/bt/component/c;->a(ILjava/lang/String;Ljava/lang/Object;)V

    :cond_a4
    :goto_a4
    return-void
.end method
