.class Lcom/mbridge/msdk/video/bt/component/d$b;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/mbridge/msdk/video/bt/component/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "b"
.end annotation


# static fields
.field private static a:Lcom/mbridge/msdk/video/bt/component/d;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lcom/mbridge/msdk/video/bt/component/d;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/mbridge/msdk/video/bt/component/d;-><init>(Lcom/mbridge/msdk/video/bt/component/d$a;)V

    sput-object v0, Lcom/mbridge/msdk/video/bt/component/d$b;->a:Lcom/mbridge/msdk/video/bt/component/d;

    return-void
.end method

.method public static synthetic a()Lcom/mbridge/msdk/video/bt/component/d;
    .registers 1

    sget-object v0, Lcom/mbridge/msdk/video/bt/component/d$b;->a:Lcom/mbridge/msdk/video/bt/component/d;

    return-object v0
.end method
