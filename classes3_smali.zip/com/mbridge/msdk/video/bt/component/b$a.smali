.class final Lcom/mbridge/msdk/video/bt/component/b$a;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/mbridge/msdk/video/bt/component/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# static fields
.field private static a:Lcom/mbridge/msdk/video/bt/component/b;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/mbridge/msdk/video/bt/component/b;

    invoke-direct {v0}, Lcom/mbridge/msdk/video/bt/component/b;-><init>()V

    sput-object v0, Lcom/mbridge/msdk/video/bt/component/b$a;->a:Lcom/mbridge/msdk/video/bt/component/b;

    return-void
.end method

.method public static synthetic a()Lcom/mbridge/msdk/video/bt/component/b;
    .registers 1

    sget-object v0, Lcom/mbridge/msdk/video/bt/component/b$a;->a:Lcom/mbridge/msdk/video/bt/component/b;

    return-object v0
.end method
