.class public Lcom/mbridge/msdk/video/bt/component/d;
.super Lcom/mbridge/msdk/video/bt/component/a;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/mbridge/msdk/video/bt/component/d$b;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Lcom/mbridge/msdk/video/bt/component/a;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lcom/mbridge/msdk/video/bt/component/d$a;)V
    .registers 2

    invoke-direct {p0}, Lcom/mbridge/msdk/video/bt/component/d;-><init>()V

    return-void
.end method

.method public static c()Lcom/mbridge/msdk/video/bt/component/d;
    .registers 1

    invoke-static {}, Lcom/mbridge/msdk/video/bt/component/d$b;->a()Lcom/mbridge/msdk/video/bt/component/d;

    move-result-object v0

    return-object v0
.end method
