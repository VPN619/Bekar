.class public Lcom/mbridge/msdk/video/bt/module/MBridgeBTNativeECDiff;
.super Lcom/mbridge/msdk/video/bt/module/BTBaseView;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public ctaView:Landroid/view/View;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/mbridge/msdk/video/bt/module/BTBaseView;-><init>(Landroid/content/Context;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/mbridge/msdk/video/bt/module/BTBaseView;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method


# virtual methods
.method public checkChinaProgressBarStatus()Z
    .registers 1

    const/4 p0, 0x0

    return p0
.end method

.method public doChinaJumpClick(Landroid/content/Context;Lcom/mbridge/msdk/video/signal/impl/k;)V
    .registers 3

    return-void
.end method

.method public init(Landroid/content/Context;)V
    .registers 2

    return-void
.end method

.method public onDestory()V
    .registers 1

    return-void
.end method

.method public setChinaCTAData(Lcom/mbridge/msdk/foundation/entity/CampaignEx;)V
    .registers 2

    return-void
.end method
