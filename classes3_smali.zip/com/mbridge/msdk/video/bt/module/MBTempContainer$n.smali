.class final Lcom/mbridge/msdk/video/bt/module/MBTempContainer$n;
.super Lcom/mbridge/msdk/video/module/listener/impl/f;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/mbridge/msdk/video/bt/module/MBTempContainer;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x11
    name = "n"
.end annotation


# instance fields
.field final synthetic a:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;


# direct methods
.method private constructor <init>(Lcom/mbridge/msdk/video/bt/module/MBTempContainer;)V
    .registers 2

    iput-object p1, p0, Lcom/mbridge/msdk/video/bt/module/MBTempContainer$n;->a:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    invoke-direct {p0}, Lcom/mbridge/msdk/video/module/listener/impl/f;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lcom/mbridge/msdk/video/bt/module/MBTempContainer;Lcom/mbridge/msdk/video/bt/module/MBTempContainer$b;)V
    .registers 3

    invoke-direct {p0, p1}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer$n;-><init>(Lcom/mbridge/msdk/video/bt/module/MBTempContainer;)V

    return-void
.end method


# virtual methods
.method public a(ILjava/lang/Object;)V
    .registers 7

    .prologue
    invoke-super {p0, p1, p2}, Lcom/mbridge/msdk/video/module/listener/impl/f;->a(ILjava/lang/Object;)V

    :try_start_3
    instance-of v0, p2, Lorg/json/JSONObject;

    if-eqz v0, :cond_c

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_f

    :cond_c
    move-object v0, p2

    check-cast v0, Ljava/lang/String;

    :goto_f
    iget-object v1, p0, Lcom/mbridge/msdk/video/bt/module/MBTempContainer$n;->a:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    invoke-static {v1}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->C(Lcom/mbridge/msdk/video/bt/module/MBTempContainer;)Z

    move-result v1

    if-eqz v1, :cond_56

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_56

    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string v0, "type"

    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v0

    const-string v2, "complete"

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v1
    :try_end_2e
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_2e} :catch_4f

    const/4 v2, 0x2

    if-eq v0, v2, :cond_42

    iget-object v2, p0, Lcom/mbridge/msdk/video/bt/module/MBTempContainer$n;->a:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    const/4 v3, 0x3

    if-eq v0, v3, :cond_3c

    :try_start_36
    sget v0, Lcom/mbridge/msdk/foundation/same/a;->F:I

    invoke-static {v2, v0}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->b(Lcom/mbridge/msdk/video/bt/module/MBTempContainer;I)I

    goto :goto_49

    :cond_3c
    sget v0, Lcom/mbridge/msdk/foundation/same/a;->E:I

    invoke-static {v2, v0}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->b(Lcom/mbridge/msdk/video/bt/module/MBTempContainer;I)I

    goto :goto_49

    :cond_42
    iget-object v0, p0, Lcom/mbridge/msdk/video/bt/module/MBTempContainer$n;->a:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    sget v2, Lcom/mbridge/msdk/foundation/same/a;->D:I

    invoke-static {v0, v2}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->b(Lcom/mbridge/msdk/video/bt/module/MBTempContainer;I)I

    :goto_49
    iget-object v0, p0, Lcom/mbridge/msdk/video/bt/module/MBTempContainer$n;->a:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    invoke-static {v0, v1}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->c(Lcom/mbridge/msdk/video/bt/module/MBTempContainer;I)I
    :try_end_4e
    .catch Ljava/lang/Exception; {:try_start_36 .. :try_end_4e} :catch_4f

    goto :goto_56

    :catch_4f
    const-string v0, "NotifyListener"

    const-string v1, "PlayableResultListener ERROR"

    invoke-static {v0, v1}, Lcom/mbridge/msdk/foundation/tools/q0;->b(Ljava/lang/String;Ljava/lang/String;)V

    :cond_56
    :goto_56
    const/16 v0, 0x78

    if-eq p1, v0, :cond_13c

    const/16 v0, 0x83

    const-string v1, ""

    if-eq p1, v0, :cond_12b

    const/16 v0, 0x7e

    if-eq p1, v0, :cond_114

    const/16 v0, 0x7f

    const/4 v2, 0x1

    if-eq p1, v0, :cond_df

    packed-switch p1, :pswitch_data_152

    goto/16 :goto_151

    :pswitch_6e  #0x69
    invoke-static {}, Lcom/mbridge/msdk/util/b;->a()Z

    move-result p1

    if-eqz p1, :cond_79

    iget-object p1, p0, Lcom/mbridge/msdk/video/bt/module/MBTempContainer$n;->a:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    invoke-virtual {p1}, Lcom/mbridge/msdk/video/bt/module/MBTempContainerDiff;->setChinaCTACallBack()V

    :cond_79
    iget-object p0, p0, Lcom/mbridge/msdk/video/bt/module/MBTempContainer$n;->a:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    invoke-virtual {p0}, Lcom/mbridge/msdk/video/signal/container/AbstractJSContainer;->getJSCommon()Lcom/mbridge/msdk/video/signal/d;

    move-result-object p0

    if-eqz p2, :cond_85

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    :cond_85
    invoke-interface {p0, v2, v1}, Lcom/mbridge/msdk/video/signal/e;->click(ILjava/lang/String;)V

    goto/16 :goto_151

    :pswitch_8a  #0x68
    iget-object p0, p0, Lcom/mbridge/msdk/video/bt/module/MBTempContainer$n;->a:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    invoke-static {p0}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->k(Lcom/mbridge/msdk/video/bt/module/MBTempContainer;)V

    goto/16 :goto_151

    :pswitch_91  #0x67
    iget-object p1, p0, Lcom/mbridge/msdk/video/bt/module/MBTempContainer$n;->a:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    invoke-static {p1, v2}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->b(Lcom/mbridge/msdk/video/bt/module/MBTempContainer;Z)Z

    iget-object p1, p0, Lcom/mbridge/msdk/video/bt/module/MBTempContainer$n;->a:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    invoke-static {p1}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->a(Lcom/mbridge/msdk/video/bt/module/MBTempContainer;)Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    move-result-object p1

    invoke-virtual {p1}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->isMraid()Z

    move-result p1

    iget-object p0, p0, Lcom/mbridge/msdk/video/bt/module/MBTempContainer$n;->a:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    if-eqz p1, :cond_a9

    invoke-static {p0}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->k(Lcom/mbridge/msdk/video/bt/module/MBTempContainer;)V

    goto/16 :goto_151

    :cond_a9
    invoke-virtual {p0}, Lcom/mbridge/msdk/video/signal/container/AbstractJSContainer;->getJSCommon()Lcom/mbridge/msdk/video/signal/d;

    move-result-object p0

    invoke-interface {p0}, Lcom/mbridge/msdk/video/signal/a;->f()V

    goto/16 :goto_151

    :pswitch_b2  #0x65, 0x66
    iget-object p0, p0, Lcom/mbridge/msdk/video/bt/module/MBTempContainer$n;->a:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    invoke-virtual {p0}, Lcom/mbridge/msdk/video/signal/container/AbstractJSContainer;->getJSCommon()Lcom/mbridge/msdk/video/signal/d;

    move-result-object p0

    invoke-interface {p0}, Lcom/mbridge/msdk/video/signal/a;->f()V

    goto/16 :goto_151

    :pswitch_bd  #0x64
    iget-object p1, p0, Lcom/mbridge/msdk/video/bt/module/MBTempContainer$n;->a:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    invoke-static {p1, v2}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->d(Lcom/mbridge/msdk/video/bt/module/MBTempContainer;Z)Z

    iget-object p1, p0, Lcom/mbridge/msdk/video/bt/module/MBTempContainer$n;->a:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    iget-object p2, p1, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->T:Landroid/os/Handler;

    invoke-static {p1}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->D(Lcom/mbridge/msdk/video/bt/module/MBTempContainer;)Ljava/lang/Runnable;

    move-result-object p1

    const-wide/16 v0, 0xfa

    invoke-virtual {p2, p1, v0, v1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    iget-object p1, p0, Lcom/mbridge/msdk/video/bt/module/MBTempContainer$n;->a:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    invoke-static {p1}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->J(Lcom/mbridge/msdk/video/bt/module/MBTempContainer;)Lcom/mbridge/msdk/video/bt/module/orglistener/h;

    move-result-object p1

    iget-object p0, p0, Lcom/mbridge/msdk/video/bt/module/MBTempContainer$n;->a:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    invoke-static {p0}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->z(Lcom/mbridge/msdk/video/bt/module/MBTempContainer;)Lcom/mbridge/msdk/foundation/same/report/metrics/c;

    move-result-object p0

    invoke-interface {p1, p0}, Lcom/mbridge/msdk/video/bt/module/orglistener/h;->a(Lcom/mbridge/msdk/foundation/same/report/metrics/c;)V

    goto :goto_151

    :cond_df
    iget-object p1, p0, Lcom/mbridge/msdk/video/bt/module/MBTempContainer$n;->a:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    invoke-static {p1, v2}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->b(Lcom/mbridge/msdk/video/bt/module/MBTempContainer;Z)Z

    iget-object p1, p0, Lcom/mbridge/msdk/video/bt/module/MBTempContainer$n;->a:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    invoke-static {p1}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->J(Lcom/mbridge/msdk/video/bt/module/MBTempContainer;)Lcom/mbridge/msdk/video/bt/module/orglistener/h;

    move-result-object p1

    iget-object p2, p0, Lcom/mbridge/msdk/video/bt/module/MBTempContainer$n;->a:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    invoke-static {p2}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->z(Lcom/mbridge/msdk/video/bt/module/MBTempContainer;)Lcom/mbridge/msdk/foundation/same/report/metrics/c;

    move-result-object p2

    invoke-interface {p1, p2}, Lcom/mbridge/msdk/video/bt/module/orglistener/h;->a(Lcom/mbridge/msdk/foundation/same/report/metrics/c;)V

    iget-object p1, p0, Lcom/mbridge/msdk/video/bt/module/MBTempContainer$n;->a:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    invoke-static {p1}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->J(Lcom/mbridge/msdk/video/bt/module/MBTempContainer;)Lcom/mbridge/msdk/video/bt/module/orglistener/h;

    move-result-object p1

    iget-object p2, p0, Lcom/mbridge/msdk/video/bt/module/MBTempContainer$n;->a:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    invoke-static {p2}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->I(Lcom/mbridge/msdk/video/bt/module/MBTempContainer;)Ljava/lang/String;

    move-result-object p2

    iget-object v0, p0, Lcom/mbridge/msdk/video/bt/module/MBTempContainer$n;->a:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    invoke-static {v0}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->K(Lcom/mbridge/msdk/video/bt/module/MBTempContainer;)Ljava/lang/String;

    move-result-object v0

    invoke-interface {p1, p2, v0}, Lcom/mbridge/msdk/video/bt/module/orglistener/h;->a(Ljava/lang/String;Ljava/lang/String;)V

    iget-object p0, p0, Lcom/mbridge/msdk/video/bt/module/MBTempContainer$n;->a:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    invoke-virtual {p0}, Lcom/mbridge/msdk/video/signal/container/AbstractJSContainer;->getJSContainerModule()Lcom/mbridge/msdk/video/signal/f;

    move-result-object p0

    const/16 p1, 0x64

    invoke-interface {p0, p1}, Lcom/mbridge/msdk/video/signal/f;->showEndcard(I)V

    goto :goto_151

    :cond_114
    iget-object p1, p0, Lcom/mbridge/msdk/video/bt/module/MBTempContainer$n;->a:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    invoke-static {p1}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->J(Lcom/mbridge/msdk/video/bt/module/MBTempContainer;)Lcom/mbridge/msdk/video/bt/module/orglistener/h;

    move-result-object p1

    iget-object p2, p0, Lcom/mbridge/msdk/video/bt/module/MBTempContainer$n;->a:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    invoke-static {p2}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->G(Lcom/mbridge/msdk/video/bt/module/MBTempContainer;)Ljava/lang/String;

    move-result-object p2

    iget-object p0, p0, Lcom/mbridge/msdk/video/bt/module/MBTempContainer$n;->a:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    invoke-static {p0}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->H(Lcom/mbridge/msdk/video/bt/module/MBTempContainer;)Ljava/lang/String;

    move-result-object p0

    const/4 v0, 0x0

    invoke-interface {p1, v0, p2, p0}, Lcom/mbridge/msdk/video/bt/module/orglistener/h;->a(ZLjava/lang/String;Ljava/lang/String;)V

    goto :goto_151

    :cond_12b
    iget-object p0, p0, Lcom/mbridge/msdk/video/bt/module/MBTempContainer$n;->a:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    invoke-virtual {p0}, Lcom/mbridge/msdk/video/signal/container/AbstractJSContainer;->getJSCommon()Lcom/mbridge/msdk/video/signal/d;

    move-result-object p0

    if-eqz p2, :cond_137

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    :cond_137
    const/4 p1, 0x4

    invoke-interface {p0, p1, v1}, Lcom/mbridge/msdk/video/signal/e;->click(ILjava/lang/String;)V

    goto :goto_151

    :cond_13c
    iget-object p1, p0, Lcom/mbridge/msdk/video/bt/module/MBTempContainer$n;->a:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    invoke-static {p1}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->J(Lcom/mbridge/msdk/video/bt/module/MBTempContainer;)Lcom/mbridge/msdk/video/bt/module/orglistener/h;

    move-result-object p1

    iget-object p2, p0, Lcom/mbridge/msdk/video/bt/module/MBTempContainer$n;->a:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    invoke-static {p2}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->E(Lcom/mbridge/msdk/video/bt/module/MBTempContainer;)Ljava/lang/String;

    move-result-object p2

    iget-object p0, p0, Lcom/mbridge/msdk/video/bt/module/MBTempContainer$n;->a:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    invoke-static {p0}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->F(Lcom/mbridge/msdk/video/bt/module/MBTempContainer;)Ljava/lang/String;

    move-result-object p0

    invoke-interface {p1, p2, p0}, Lcom/mbridge/msdk/video/bt/module/orglistener/h;->a(Ljava/lang/String;Ljava/lang/String;)V

    :goto_151
    return-void

    :pswitch_data_152
    .packed-switch 0x64
        :pswitch_bd  #00000064
        :pswitch_b2  #00000065
        :pswitch_b2  #00000066
        :pswitch_91  #00000067
        :pswitch_8a  #00000068
        :pswitch_6e  #00000069
    .end packed-switch
.end method
