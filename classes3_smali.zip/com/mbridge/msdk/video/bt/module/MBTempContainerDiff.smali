.class public Lcom/mbridge/msdk/video/bt/module/MBTempContainerDiff;
.super Lcom/mbridge/msdk/video/signal/container/AbstractJSContainer;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public mbridgeVideoView:Lcom/mbridge/msdk/video/module/MBridgeVideoView;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 2

    invoke-direct {p0, p1}, Lcom/mbridge/msdk/video/signal/container/AbstractJSContainer;-><init>(Landroid/content/Context;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .registers 3

    invoke-direct {p0, p1, p2}, Lcom/mbridge/msdk/video/signal/container/AbstractJSContainer;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;)V

    return-void
.end method


# virtual methods
.method public checkChinaSendToServerDiff(Lcom/mbridge/msdk/video/bt/module/orglistener/h;)Z
    .registers 2

    const/4 p0, 0x0

    return p0
.end method

.method public checkChinaShowingAlertViewState()Z
    .registers 1

    const/4 p0, 0x0

    return p0
.end method

.method public setChinaBrowserCallBack(Lcom/mbridge/msdk/video/bt/module/listener/b;Ljava/lang/String;Lcom/mbridge/msdk/video/bt/module/orglistener/h;Lcom/mbridge/msdk/foundation/entity/CampaignEx;)V
    .registers 5

    return-void
.end method

.method public setChinaCTACallBack()V
    .registers 1

    return-void
.end method

.method public setChinaCallBackStatus(Lcom/mbridge/msdk/mbsignalcommon/windvane/WindVaneWebView;)V
    .registers 2

    return-void
.end method

.method public setChinaDestroy()V
    .registers 1

    return-void
.end method

.method public setChinaJsCommonContext()V
    .registers 1

    return-void
.end method
