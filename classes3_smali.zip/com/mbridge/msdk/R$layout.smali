.class public final Lcom/mbridge/msdk/R$layout;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/mbridge/msdk/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "layout"
.end annotation


# static fields
.field public static custom_dialog:I = 0x7f0c0024

.field public static loading_alert:I = 0x7f0c0040

.field public static mainlayout:I = 0x7f0c004c

.field public static mbridge_activity:I = 0x7f0c005b

.field public static mbridge_alertview_layout:I = 0x7f0c005c

.field public static mbridge_bt_container:I = 0x7f0c005d

.field public static mbridge_cm_alertview:I = 0x7f0c005e

.field public static mbridge_cm_feedback_notice_layout:I = 0x7f0c005f

.field public static mbridge_cm_feedbackview:I = 0x7f0c0060

.field public static mbridge_cm_loading_layout:I = 0x7f0c0061

.field public static mbridge_interstitial_activity:I = 0x7f0c0062

.field public static mbridge_more_offer_activity:I = 0x7f0c0063

.field public static mbridge_nativex_fullbasescreen:I = 0x7f0c0064

.field public static mbridge_nativex_fullscreen_top:I = 0x7f0c0065

.field public static mbridge_nativex_mbmediaview:I = 0x7f0c0066

.field public static mbridge_nativex_playerview:I = 0x7f0c0067

.field public static mbridge_order_layout_item:I = 0x7f0c0068

.field public static mbridge_order_layout_list_landscape:I = 0x7f0c0069

.field public static mbridge_order_layout_list_portrait:I = 0x7f0c006a

.field public static mbridge_playercommon_player_view:I = 0x7f0c006b

.field public static mbridge_reward_activity_video_templete:I = 0x7f0c006c

.field public static mbridge_reward_activity_video_templete_transparent:I = 0x7f0c006d

.field public static mbridge_reward_clickable_cta:I = 0x7f0c006e

.field public static mbridge_reward_end_card_layout_landscape:I = 0x7f0c006f

.field public static mbridge_reward_end_card_layout_landscape_1302:I = 0x7f0c0070

.field public static mbridge_reward_end_card_layout_portrait:I = 0x7f0c0071

.field public static mbridge_reward_end_card_layout_portrait_1302:I = 0x7f0c0072

.field public static mbridge_reward_end_card_more_offer_item:I = 0x7f0c0073

.field public static mbridge_reward_endcard_h5:I = 0x7f0c0074

.field public static mbridge_reward_endcard_native_half_landscape:I = 0x7f0c0075

.field public static mbridge_reward_endcard_native_half_portrait:I = 0x7f0c0076

.field public static mbridge_reward_endcard_native_hor:I = 0x7f0c0077

.field public static mbridge_reward_endcard_native_land:I = 0x7f0c0078

.field public static mbridge_reward_endcard_vast:I = 0x7f0c0079

.field public static mbridge_reward_layer_floor:I = 0x7f0c007a

.field public static mbridge_reward_layer_floor_302:I = 0x7f0c007b

.field public static mbridge_reward_layer_floor_5002010:I = 0x7f0c007c

.field public static mbridge_reward_layer_floor_802:I = 0x7f0c007d

.field public static mbridge_reward_layer_floor_902:I = 0x7f0c007e

.field public static mbridge_reward_layer_floor_904:I = 0x7f0c007f

.field public static mbridge_reward_layer_floor_bottom:I = 0x7f0c0080

.field public static mbridge_reward_layer_floor_half_portrait:I = 0x7f0c0081

.field public static mbridge_reward_more_offer_view:I = 0x7f0c0082

.field public static mbridge_reward_videoend_cover:I = 0x7f0c0083

.field public static mbridge_reward_videoview_item:I = 0x7f0c0084

.field public static mbridge_reward_view_tag_item:I = 0x7f0c0085

.field public static mbridge_same_choice_one_layout_landscape:I = 0x7f0c0086

.field public static mbridge_same_choice_one_layout_portrait:I = 0x7f0c0087

.field public static mbridge_splash_landscape:I = 0x7f0c0088

.field public static mbridge_splash_portrait:I = 0x7f0c0089

.field public static notification_action:I = 0x7f0c00aa

.field public static notification_action_tombstone:I = 0x7f0c00ab

.field public static notification_template_custom_big:I = 0x7f0c00ac

.field public static notification_template_icon_group:I = 0x7f0c00ad

.field public static notification_template_part_chronometer:I = 0x7f0c00ae

.field public static notification_template_part_time:I = 0x7f0c00af


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
