.class public final Lcom/mbridge/msdk/R$styleable;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/mbridge/msdk/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "styleable"
.end annotation


# static fields
.field public static ColorStateListItem:[I = null

.field public static ColorStateListItem_alpha:I = 0x3

.field public static ColorStateListItem_android_alpha:I = 0x1

.field public static ColorStateListItem_android_color:I = 0x0

.field public static ColorStateListItem_android_lStar:I = 0x2

.field public static ColorStateListItem_lStar:I = 0x4

.field public static CoordinatorLayout:[I = null

.field public static CoordinatorLayout_Layout:[I = null

.field public static CoordinatorLayout_Layout_android_layout_gravity:I = 0x0

.field public static CoordinatorLayout_Layout_layout_anchor:I = 0x1

.field public static CoordinatorLayout_Layout_layout_anchorGravity:I = 0x2

.field public static CoordinatorLayout_Layout_layout_behavior:I = 0x3

.field public static CoordinatorLayout_Layout_layout_dodgeInsetEdges:I = 0x4

.field public static CoordinatorLayout_Layout_layout_insetEdge:I = 0x5

.field public static CoordinatorLayout_Layout_layout_keyline:I = 0x6

.field public static CoordinatorLayout_keylines:I = 0x0

.field public static CoordinatorLayout_statusBarBackground:I = 0x1

.field public static FontFamily:[I = null

.field public static FontFamilyFont:[I = null

.field public static FontFamilyFont_android_font:I = 0x0

.field public static FontFamilyFont_android_fontStyle:I = 0x2

.field public static FontFamilyFont_android_fontVariationSettings:I = 0x4

.field public static FontFamilyFont_android_fontWeight:I = 0x1

.field public static FontFamilyFont_android_ttcIndex:I = 0x3

.field public static FontFamilyFont_font:I = 0x5

.field public static FontFamilyFont_fontStyle:I = 0x6

.field public static FontFamilyFont_fontVariationSettings:I = 0x7

.field public static FontFamilyFont_fontWeight:I = 0x8

.field public static FontFamilyFont_ttcIndex:I = 0x9

.field public static FontFamily_fontProviderAuthority:I = 0x0

.field public static FontFamily_fontProviderCerts:I = 0x1

.field public static FontFamily_fontProviderFallbackQuery:I = 0x2

.field public static FontFamily_fontProviderFetchStrategy:I = 0x3

.field public static FontFamily_fontProviderFetchTimeout:I = 0x4

.field public static FontFamily_fontProviderPackage:I = 0x5

.field public static FontFamily_fontProviderQuery:I = 0x6

.field public static FontFamily_fontProviderSystemFontFamily:I = 0x7

.field public static GradientColor:[I = null

.field public static GradientColorItem:[I = null

.field public static GradientColorItem_android_color:I = 0x0

.field public static GradientColorItem_android_offset:I = 0x1

.field public static GradientColor_android_centerColor:I = 0x7

.field public static GradientColor_android_centerX:I = 0x3

.field public static GradientColor_android_centerY:I = 0x4

.field public static GradientColor_android_endColor:I = 0x1

.field public static GradientColor_android_endX:I = 0xa

.field public static GradientColor_android_endY:I = 0xb

.field public static GradientColor_android_gradientRadius:I = 0x5

.field public static GradientColor_android_startColor:I = 0x0

.field public static GradientColor_android_startX:I = 0x8

.field public static GradientColor_android_startY:I = 0x9

.field public static GradientColor_android_tileMode:I = 0x6

.field public static GradientColor_android_type:I = 0x2

.field public static LoadingImageView:[I = null

.field public static LoadingImageView_circleCrop:I = 0x0

.field public static LoadingImageView_imageAspectRatio:I = 0x1

.field public static LoadingImageView_imageAspectRatioAdjust:I = 0x2

.field public static RoundRectImageView:[I = null

.field public static RoundRectImageView_corner:I = 0x0

.field public static SignInButton:[I = null

.field public static SignInButton_buttonSize:I = 0x0

.field public static SignInButton_colorScheme:I = 0x1

.field public static SignInButton_scopeUris:I = 0x2


# direct methods
.method public static constructor <clinit>()V
    .registers 5

    .prologue
    const v0, 0x7f040036

    const v1, 0x7f0402f6

    const v2, 0x10101a5

    const v3, 0x101031f

    const v4, 0x1010647

    filled-new-array {v2, v3, v4, v0, v1}, [I

    move-result-object v0

    sput-object v0, Lcom/mbridge/msdk/R$styleable;->ColorStateListItem:[I

    const v0, 0x7f0402f5

    const v1, 0x7f040503

    filled-new-array {v0, v1}, [I

    move-result-object v0

    sput-object v0, Lcom/mbridge/msdk/R$styleable;->CoordinatorLayout:[I

    const/4 v0, 0x7

    new-array v0, v0, [I

    fill-array-data v0, :array_76

    sput-object v0, Lcom/mbridge/msdk/R$styleable;->CoordinatorLayout_Layout:[I

    const/16 v0, 0x8

    new-array v0, v0, [I

    fill-array-data v0, :array_88

    sput-object v0, Lcom/mbridge/msdk/R$styleable;->FontFamily:[I

    const/16 v0, 0xa

    new-array v0, v0, [I

    fill-array-data v0, :array_9c

    sput-object v0, Lcom/mbridge/msdk/R$styleable;->FontFamilyFont:[I

    const/16 v0, 0xc

    new-array v0, v0, [I

    fill-array-data v0, :array_b4

    sput-object v0, Lcom/mbridge/msdk/R$styleable;->GradientColor:[I

    const v0, 0x1010514

    filled-new-array {v2, v0}, [I

    move-result-object v0

    sput-object v0, Lcom/mbridge/msdk/R$styleable;->GradientColorItem:[I

    const v0, 0x7f0402b7

    const v1, 0x7f0402b8

    const v2, 0x7f0400e6

    filled-new-array {v2, v0, v1}, [I

    move-result-object v0

    sput-object v0, Lcom/mbridge/msdk/R$styleable;->LoadingImageView:[I

    const v0, 0x7f04017f

    filled-new-array {v0}, [I

    move-result-object v0

    sput-object v0, Lcom/mbridge/msdk/R$styleable;->RoundRectImageView:[I

    const v0, 0x7f040139

    const v1, 0x7f040490

    const v2, 0x7f0400a6

    filled-new-array {v2, v0, v1}, [I

    move-result-object v0

    sput-object v0, Lcom/mbridge/msdk/R$styleable;->SignInButton:[I

    return-void

    nop

    :array_76
    .array-data 4
        0x10100b3
        0x7f040305
        0x7f040306
        0x7f040307
        0x7f040338
        0x7f040342
        0x7f040343
    .end array-data

    :array_88
    .array-data 4
        0x7f04026a
        0x7f04026b
        0x7f04026c
        0x7f04026d
        0x7f04026e
        0x7f04026f
        0x7f040270
        0x7f040271
    .end array-data

    :array_9c
    .array-data 4
        0x1010532
        0x1010533
        0x101053f
        0x101056f
        0x1010570
        0x7f040268
        0x7f040272
        0x7f040273
        0x7f040274
        0x7f0405f9
    .end array-data

    :array_b4
    .array-data 4
        0x101019d
        0x101019e
        0x10101a1
        0x10101a2
        0x10101a3
        0x10101a4
        0x1010201
        0x101020b
        0x1010510
        0x1010511
        0x1010512
        0x1010513
    .end array-data
.end method

.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
