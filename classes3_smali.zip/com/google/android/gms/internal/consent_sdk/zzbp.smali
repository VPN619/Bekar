.class public final synthetic Lcom/google/android/gms/internal/consent_sdk/zzbp;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lzh2;


# instance fields
.field public final synthetic zza:Lmv;


# direct methods
.method public synthetic constructor <init>(Lmv;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/google/android/gms/internal/consent_sdk/zzbp;->zza:Lmv;

    return-void
.end method


# virtual methods
.method public final onConsentFormLoadFailure(Lch0;)V
    .registers 2

    iget-object p0, p0, Lcom/google/android/gms/internal/consent_sdk/zzbp;->zza:Lmv;

    check-cast p0, Ly3;

    invoke-virtual {p0, p1}, Ly3;->a(Lch0;)V

    return-void
.end method
