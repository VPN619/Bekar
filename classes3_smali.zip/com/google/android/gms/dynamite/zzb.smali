.class public final Lcom/google/android/gms/dynamite/zzb;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static a:Ljava/lang/ClassLoader;

.field public static b:Ljava/lang/Thread;


# direct methods
.method public static declared-synchronized zza()Ljava/lang/ClassLoader;
    .registers 13
    .annotation build Landroidx/annotation/Nullable;
    .end annotation

    .prologue
    const-class v0, Lcom/google/android/gms/dynamite/zzb;

    monitor-enter v0

    :try_start_3
    sget-object v1, Lcom/google/android/gms/dynamite/zzb;->a:Ljava/lang/ClassLoader;

    if-nez v1, :cond_e8

    const-string v1, "Failed to get thread context classloader "

    sget-object v2, Lcom/google/android/gms/dynamite/zzb;->b:Ljava/lang/Thread;

    const/4 v3, 0x0

    if-nez v2, :cond_b6

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    invoke-virtual {v2}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Thread;->getThreadGroup()Ljava/lang/ThreadGroup;

    move-result-object v2

    const-string v4, "Failed to enumerate thread/threadgroup "

    if-nez v2, :cond_21

    move-object v2, v3

    goto/16 :goto_ac

    :cond_21
    const-class v5, Ljava/lang/Void;

    monitor-enter v5
    :try_end_24
    .catchall {:try_start_3 .. :try_end_24} :catchall_b2

    :try_start_24
    invoke-virtual {v2}, Ljava/lang/ThreadGroup;->activeGroupCount()I

    move-result v6

    new-array v7, v6, [Ljava/lang/ThreadGroup;

    invoke-virtual {v2, v7}, Ljava/lang/ThreadGroup;->enumerate([Ljava/lang/ThreadGroup;)I

    const/4 v8, 0x0

    move v9, v8

    :goto_2f
    if-ge v9, v6, :cond_48

    aget-object v10, v7, v9

    const-string v11, "dynamiteLoader"

    invoke-virtual {v10}, Ljava/lang/ThreadGroup;->getName()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_40

    goto :goto_49

    :cond_40
    add-int/lit8 v9, v9, 0x1

    goto :goto_2f

    :catchall_43
    move-exception v1

    goto/16 :goto_b4

    :catch_46
    move-exception v2

    goto :goto_88

    :cond_48
    move-object v10, v3

    :goto_49
    if-nez v10, :cond_52

    new-instance v10, Ljava/lang/ThreadGroup;

    const-string v6, "dynamiteLoader"

    invoke-direct {v10, v2, v6}, Ljava/lang/ThreadGroup;-><init>(Ljava/lang/ThreadGroup;Ljava/lang/String;)V

    :cond_52
    invoke-virtual {v10}, Ljava/lang/ThreadGroup;->activeCount()I

    move-result v2

    new-array v6, v2, [Ljava/lang/Thread;

    invoke-virtual {v10, v6}, Ljava/lang/ThreadGroup;->enumerate([Ljava/lang/Thread;)I

    :goto_5b
    if-ge v8, v2, :cond_6f

    aget-object v7, v6, v8

    const-string v9, "GmsDynamite"

    invoke-virtual {v7}, Ljava/lang/Thread;->getName()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v9, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9
    :try_end_69
    .catch Ljava/lang/SecurityException; {:try_start_24 .. :try_end_69} :catch_46
    .catchall {:try_start_24 .. :try_end_69} :catchall_43

    if-eqz v9, :cond_6c

    goto :goto_70

    :cond_6c
    add-int/lit8 v8, v8, 0x1

    goto :goto_5b

    :cond_6f
    move-object v7, v3

    :goto_70
    if-nez v7, :cond_aa

    :try_start_72
    new-instance v2, Ldf;

    const-string v6, "GmsDynamite"

    invoke-direct {v2, v10, v6}, Ldf;-><init>(Ljava/lang/ThreadGroup;Ljava/lang/String;)V
    :try_end_79
    .catch Ljava/lang/SecurityException; {:try_start_72 .. :try_end_79} :catch_86
    .catchall {:try_start_72 .. :try_end_79} :catchall_43

    :try_start_79
    invoke-virtual {v2, v3}, Ljava/lang/Thread;->setContextClassLoader(Ljava/lang/ClassLoader;)V

    invoke-virtual {v2}, Ljava/lang/Thread;->start()V
    :try_end_7f
    .catch Ljava/lang/SecurityException; {:try_start_79 .. :try_end_7f} :catch_81
    .catchall {:try_start_79 .. :try_end_7f} :catchall_43

    move-object v7, v2

    goto :goto_aa

    :catch_81
    move-exception v6

    move-object v7, v2

    goto :goto_8a

    :goto_84
    move-object v6, v2

    goto :goto_8a

    :catch_86
    move-exception v2

    goto :goto_84

    :goto_88
    move-object v6, v2

    move-object v7, v3

    :goto_8a
    :try_start_8a
    const-string v2, "DynamiteLoaderV2CL"

    invoke-virtual {v6}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/String;->length()I

    move-result v8

    add-int/lit8 v8, v8, 0x27

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9, v8}, Ljava/lang/StringBuilder;-><init>(I)V

    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    nop

    :cond_aa
    :goto_aa
    monitor-exit v5
    :try_end_ab
    .catchall {:try_start_8a .. :try_end_ab} :catchall_43

    move-object v2, v7

    :goto_ac
    :try_start_ac
    sput-object v2, Lcom/google/android/gms/dynamite/zzb;->b:Ljava/lang/Thread;
    :try_end_ae
    .catchall {:try_start_ac .. :try_end_ae} :catchall_b2

    if-nez v2, :cond_b6

    :goto_b0
    move-object v1, v3

    goto :goto_e3

    :catchall_b2
    move-exception v1

    goto :goto_ea

    :goto_b4
    :try_start_b4
    monitor-exit v5
    :try_end_b5
    .catchall {:try_start_b4 .. :try_end_b5} :catchall_43

    :try_start_b5
    throw v1

    :cond_b6
    monitor-enter v2
    :try_end_b7
    .catchall {:try_start_b5 .. :try_end_b7} :catchall_b2

    :try_start_b7
    sget-object v4, Lcom/google/android/gms/dynamite/zzb;->b:Ljava/lang/Thread;

    invoke-virtual {v4}, Ljava/lang/Thread;->getContextClassLoader()Ljava/lang/ClassLoader;

    move-result-object v3
    :try_end_bd
    .catch Ljava/lang/SecurityException; {:try_start_b7 .. :try_end_bd} :catch_c0
    .catchall {:try_start_b7 .. :try_end_bd} :catchall_be

    goto :goto_e1

    :catchall_be
    move-exception v1

    goto :goto_e6

    :catch_c0
    move-exception v4

    :try_start_c1
    const-string v5, "DynamiteLoaderV2CL"

    invoke-virtual {v4}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v6

    add-int/lit8 v6, v6, 0x29

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7, v6}, Ljava/lang/StringBuilder;-><init>(I)V

    invoke-virtual {v7, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    nop

    :goto_e1
    monitor-exit v2
    :try_end_e2
    .catchall {:try_start_c1 .. :try_end_e2} :catchall_be

    goto :goto_b0

    :goto_e3
    :try_start_e3
    sput-object v1, Lcom/google/android/gms/dynamite/zzb;->a:Ljava/lang/ClassLoader;
    :try_end_e5
    .catchall {:try_start_e3 .. :try_end_e5} :catchall_b2

    goto :goto_e8

    :goto_e6
    :try_start_e6
    monitor-exit v2
    :try_end_e7
    .catchall {:try_start_e6 .. :try_end_e7} :catchall_be

    :try_start_e7
    throw v1
    :try_end_e8
    .catchall {:try_start_e7 .. :try_end_e8} :catchall_b2

    :cond_e8
    :goto_e8
    monitor-exit v0

    return-object v1

    :goto_ea
    :try_start_ea
    monitor-exit v0
    :try_end_eb
    .catchall {:try_start_ea .. :try_end_eb} :catchall_b2

    throw v1
.end method
