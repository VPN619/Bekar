.class public final Lcom/google/android/gms/base/R$attr;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/gms/base/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "attr"
.end annotation


# static fields
.field public static buttonSize:I = 0x7f0400a6

.field public static circleCrop:I = 0x7f0400e6

.field public static colorScheme:I = 0x7f040139

.field public static imageAspectRatio:I = 0x7f0402b7

.field public static imageAspectRatioAdjust:I = 0x7f0402b8

.field public static scopeUris:I = 0x7f040490
