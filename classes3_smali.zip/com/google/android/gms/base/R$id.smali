.class public final Lcom/google/android/gms/base/R$id;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/google/android/gms/base/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static adjust_height:I = 0x7f09004b

.field public static adjust_width:I = 0x7f09004c

.field public static auto:I = 0x7f090068

.field public static dark:I = 0x7f0900d1

.field public static icon_only:I = 0x7f09013f

.field public static light:I = 0x7f090163

.field public static none:I = 0x7f09028a

.field public static standard:I = 0x7f090356

.field public static wide:I = 0x7f0903c1
