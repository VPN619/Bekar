.class public final Lbg0;
.super Lwx;


# instance fields
.field public synthetic t:Ljava/lang/Object;

.field public u:I

.field public final synthetic v:Lwf0;

.field public w:Ljava/lang/Object;

.field public x:Lhf0;


# direct methods
.method public constructor <init>(Lwf0;Lvx;)V
    .registers 3

    iput-object p1, p0, Lbg0;->v:Lwf0;

    invoke-direct {p0, p2}, Lwx;-><init>(Lvx;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    iput-object p1, p0, Lbg0;->t:Ljava/lang/Object;

    iget p1, p0, Lbg0;->u:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, Lbg0;->u:I

    iget-object p1, p0, Lbg0;->v:Lwf0;

    const/4 v0, 0x0

    invoke-virtual {p1, v0, p0}, Lwf0;->emit(Ljava/lang/Object;Lvx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
