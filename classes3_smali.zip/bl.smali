.class public final Lbl;
.super Lwx;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public synthetic t:Ljava/lang/Object;

.field public final synthetic u:Ldl;

.field public v:I


# direct methods
.method public constructor <init>(Ldl;Lwx;)V
    .registers 3

    iput-object p1, p0, Lbl;->u:Ldl;

    invoke-direct {p0, p2}, Lwx;-><init>(Lvx;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .prologue
    iput-object p1, p0, Lbl;->t:Ljava/lang/Object;

    iget p1, p0, Lbl;->v:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, Lbl;->v:I

    iget-object p1, p0, Lbl;->u:Ldl;

    invoke-static {p1, p0}, Ldl;->F(Ldl;Lwx;)Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lwy;->a:Lwy;

    if-ne p0, p1, :cond_14

    return-object p0

    :cond_14
    new-instance p1, Lyo;

    invoke-direct {p1, p0}, Lyo;-><init>(Ljava/lang/Object;)V

    return-object p1
.end method
