.class public final La81;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final c:Ljava/util/regex/Pattern;

.field public static final d:Ljava/util/regex/Pattern;


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:[Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-string v0, "([a-zA-Z0-9-!#$%&\'*+.^_`{|}~]+)/([a-zA-Z0-9-!#$%&\'*+.^_`{|}~]+)"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    sput-object v0, La81;->c:Ljava/util/regex/Pattern;

    const-string v0, ";\\s*(?:([a-zA-Z0-9-!#$%&\'*+.^_`{|}~]+)=(?:([a-zA-Z0-9-!#$%&\'*+.^_`{|}~]+)|\"([^\"]*)\"))?"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    sput-object v0, La81;->d:Ljava/util/regex/Pattern;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;[Ljava/lang/String;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La81;->a:Ljava/lang/String;

    iput-object p2, p0, La81;->b:[Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final a(Ljava/nio/charset/Charset;)Ljava/nio/charset/Charset;
    .registers 8

    .prologue
    iget-object p0, p0, La81;->b:[Ljava/lang/String;

    array-length v0, p0

    add-int/lit8 v0, v0, -0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {v2, v0, v1}, Lv13;->s(III)I

    move-result v0

    if-ltz v0, :cond_23

    :goto_d
    add-int/lit8 v1, v2, 0x2

    aget-object v3, p0, v2

    const-string v4, "charset"

    const/4 v5, 0x1

    invoke-static {v3, v4, v5}, Lk72;->f0(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v3

    if-eqz v3, :cond_1e

    add-int/2addr v2, v5

    aget-object p0, p0, v2

    goto :goto_24

    :cond_1e
    if-ne v2, v0, :cond_21

    goto :goto_23

    :cond_21
    move v2, v1

    goto :goto_d

    :cond_23
    :goto_23
    const/4 p0, 0x0

    :goto_24
    if-nez p0, :cond_27

    return-object p1

    :cond_27
    :try_start_27
    invoke-static {p0}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object p0
    :try_end_2b
    .catch Ljava/lang/IllegalArgumentException; {:try_start_27 .. :try_end_2b} :catch_2c

    return-object p0

    :catch_2c
    return-object p1
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 3

    .prologue
    instance-of v0, p1, La81;

    if-eqz v0, :cond_12

    check-cast p1, La81;

    iget-object p1, p1, La81;->a:Ljava/lang/String;

    iget-object p0, p0, La81;->a:Ljava/lang/String;

    invoke-static {p1, p0}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_12

    const/4 p0, 0x1

    return p0

    :cond_12
    const/4 p0, 0x0

    return p0
.end method

.method public final hashCode()I
    .registers 1

    iget-object p0, p0, La81;->a:Ljava/lang/String;

    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result p0

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, La81;->a:Ljava/lang/String;

    return-object p0
.end method
