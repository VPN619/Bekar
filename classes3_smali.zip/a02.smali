.class public final synthetic La02;
.super Lzk0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# static fields
.field public static final h:La02;


# direct methods
.method static constructor <clinit>()V
    .registers 6

    new-instance v0, La02;

    const-string v4, "createSegment(JLkotlinx/coroutines/sync/SemaphoreSegment;)Lkotlinx/coroutines/sync/SemaphoreSegment;"

    const/4 v5, 0x1

    const/4 v1, 0x2

    const-class v2, Ld02;

    const-string v3, "createSegment"

    invoke-direct/range {v0 .. v5}, Lzk0;-><init>(ILjava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    sput-object v0, La02;->h:La02;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    check-cast p1, Ljava/lang/Number;

    invoke-virtual {p1}, Ljava/lang/Number;->longValue()J

    move-result-wide p0

    check-cast p2, Le02;

    sget v0, Ld02;->a:I

    new-instance v0, Le02;

    const/4 v1, 0x0

    invoke-direct {v0, p0, p1, p2, v1}, Le02;-><init>(JLe02;I)V

    return-object v0
.end method
