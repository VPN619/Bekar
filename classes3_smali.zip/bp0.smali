.class public final Lbp0;
.super Lr92;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final synthetic e:Ldp0;

.field public final synthetic f:I


# direct methods
.method public constructor <init>(Ljava/lang/String;Ldp0;ILfb0;)V
    .registers 5

    iput-object p2, p0, Lbp0;->e:Ldp0;

    iput p3, p0, Lbp0;->f:I

    const/4 p2, 0x1

    invoke-direct {p0, p1, p2}, Lr92;-><init>(Ljava/lang/String;Z)V

    return-void
.end method


# virtual methods
.method public final a()J
    .registers 3

    .prologue
    iget-object v0, p0, Lbp0;->e:Ldp0;

    iget-object v0, v0, Ldp0;->k:Lkn0;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Lbp0;->e:Ldp0;

    monitor-enter v0

    :try_start_a
    iget-object v1, p0, Lbp0;->e:Ldp0;

    iget-object v1, v1, Ldp0;->y:Ljava/util/LinkedHashSet;

    iget p0, p0, Lbp0;->f:I

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    invoke-interface {v1, p0}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z
    :try_end_17
    .catchall {:try_start_a .. :try_end_17} :catchall_1b

    monitor-exit v0

    const-wide/16 v0, -0x1

    return-wide v0

    :catchall_1b
    move-exception p0

    monitor-exit v0

    throw p0
.end method
