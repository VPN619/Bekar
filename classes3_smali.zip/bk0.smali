.class public interface abstract Lbk0;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lqk0;


# virtual methods
.method public abstract invoke(Ljava/lang/Object;)Ljava/lang/Object;
.end method
