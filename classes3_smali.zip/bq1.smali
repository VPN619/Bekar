.class public final Lbq1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lhl;


# instance fields
.field public final a:Lr42;

.field public final b:Lvk;

.field public c:Z


# direct methods
.method public constructor <init>(Lr42;)V
    .registers 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lbq1;->a:Lr42;

    new-instance p1, Lvk;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lbq1;->b:Lvk;

    return-void
.end method


# virtual methods
.method public final A()Ljava/lang/String;
    .registers 3

    const-wide v0, 0x7fffffffffffffffL

    invoke-virtual {p0, v0, v1}, Lbq1;->v(J)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public final B(Lpi1;)I
    .registers 8

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-boolean v0, p0, Lbq1;->c:Z

    if-nez v0, :cond_30

    :cond_7
    const/4 v0, 0x1

    iget-object v1, p0, Lbq1;->b:Lvk;

    invoke-static {v1, p1, v0}, Lps2;->b(Lvk;Lpi1;Z)I

    move-result v0

    const/4 v2, -0x2

    const/4 v3, -0x1

    if-eq v0, v2, :cond_21

    if-eq v0, v3, :cond_2f

    iget-object p0, p1, Lpi1;->a:[Lxl;

    aget-object p0, p0, v0

    invoke-virtual {p0}, Lxl;->g()I

    move-result p0

    int-to-long p0, p0

    invoke-virtual {v1, p0, p1}, Lvk;->skip(J)V

    return v0

    :cond_21
    iget-object v0, p0, Lbq1;->a:Lr42;

    const-wide/16 v4, 0x2000

    invoke-interface {v0, v1, v4, v5}, Lr42;->read(Lvk;J)J

    move-result-wide v0

    const-wide/16 v4, -0x1

    cmp-long v0, v0, v4

    if-nez v0, :cond_7

    :cond_2f
    return v3

    :cond_30
    const-string p0, "closed"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    const/4 p0, 0x0

    return p0
.end method

.method public final F(J)V
    .registers 3

    .prologue
    invoke-virtual {p0, p1, p2}, Lbq1;->p(J)Z

    move-result p0

    if-eqz p0, :cond_7

    return-void

    :cond_7
    invoke-static {}, Lz6;->m()V

    return-void
.end method

.method public final J()J
    .registers 7

    .prologue
    const-wide/16 v0, 0x1

    invoke-virtual {p0, v0, v1}, Lbq1;->F(J)V

    const/4 v0, 0x0

    :goto_6
    add-int/lit8 v1, v0, 0x1

    int-to-long v2, v1

    invoke-virtual {p0, v2, v3}, Lbq1;->p(J)Z

    move-result v2

    iget-object v3, p0, Lbq1;->b:Lvk;

    if-eqz v2, :cond_4f

    int-to-long v4, v0

    invoke-virtual {v3, v4, v5}, Lvk;->y(J)B

    move-result v2

    const/16 v4, 0x30

    if-lt v2, v4, :cond_1e

    const/16 v4, 0x39

    if-le v2, v4, :cond_2f

    :cond_1e
    const/16 v4, 0x61

    if-lt v2, v4, :cond_26

    const/16 v4, 0x66

    if-le v2, v4, :cond_2f

    :cond_26
    const/16 v4, 0x41

    if-lt v2, v4, :cond_31

    const/16 v4, 0x46

    if-le v2, v4, :cond_2f

    goto :goto_31

    :cond_2f
    move v0, v1

    goto :goto_6

    :cond_31
    :goto_31
    if-eqz v0, :cond_34

    goto :goto_4f

    :cond_34
    new-instance p0, Ljava/lang/NumberFormatException;

    const/16 v0, 0x10

    invoke-static {v0}, Lw53;->y(I)V

    invoke-static {v0}, Lw53;->y(I)V

    invoke-static {v2, v0}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v1, "Expected leading [0-9a-fA-F] character but was 0x"

    invoke-virtual {v1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Ljava/lang/NumberFormatException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_4f
    :goto_4f
    invoke-virtual {v3}, Lvk;->J()J

    move-result-wide v0

    return-wide v0
.end method

.method public final L()Ljava/io/InputStream;
    .registers 3

    new-instance v0, Luk;

    const/4 v1, 0x1

    invoke-direct {v0, p0, v1}, Luk;-><init>(Lhl;I)V

    return-object v0
.end method

.method public final close()V
    .registers 3

    .prologue
    iget-boolean v0, p0, Lbq1;->c:Z

    if-nez v0, :cond_13

    const/4 v0, 0x1

    iput-boolean v0, p0, Lbq1;->c:Z

    iget-object v0, p0, Lbq1;->a:Lr42;

    invoke-interface {v0}, Ljava/io/Closeable;->close()V

    iget-object p0, p0, Lbq1;->b:Lvk;

    iget-wide v0, p0, Lvk;->b:J

    invoke-virtual {p0, v0, v1}, Lvk;->skip(J)V

    :cond_13
    return-void
.end method

.method public final isOpen()Z
    .registers 1

    iget-boolean p0, p0, Lbq1;->c:Z

    xor-int/lit8 p0, p0, 0x1

    return p0
.end method

.method public final j(J)Lxl;
    .registers 3

    invoke-virtual {p0, p1, p2}, Lbq1;->F(J)V

    iget-object p0, p0, Lbq1;->b:Lvk;

    invoke-virtual {p0, p1, p2}, Lvk;->j(J)Lxl;

    move-result-object p0

    return-object p0
.end method

.method public final k()Z
    .registers 7

    .prologue
    iget-boolean v0, p0, Lbq1;->c:Z

    const/4 v1, 0x0

    if-nez v0, :cond_1e

    iget-object v0, p0, Lbq1;->b:Lvk;

    invoke-virtual {v0}, Lvk;->p()Z

    move-result v2

    if-eqz v2, :cond_1d

    iget-object p0, p0, Lbq1;->a:Lr42;

    const-wide/16 v2, 0x2000

    invoke-interface {p0, v0, v2, v3}, Lr42;->read(Lvk;J)J

    move-result-wide v2

    const-wide/16 v4, -0x1

    cmp-long p0, v2, v4

    if-nez p0, :cond_1d

    const/4 p0, 0x1

    return p0

    :cond_1d
    return v1

    :cond_1e
    const-string p0, "closed"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return v1
.end method

.method public final n(BJJ)J
    .registers 14

    .prologue
    iget-boolean p2, p0, Lbq1;->c:Z

    const-wide/16 v0, 0x0

    if-nez p2, :cond_44

    cmp-long p2, v0, p4

    if-gtz p2, :cond_39

    move-wide v4, v0

    :goto_b
    cmp-long p2, v4, p4

    const-wide/16 v0, -0x1

    if-gez p2, :cond_38

    iget-object v2, p0, Lbq1;->b:Lvk;

    move v3, p1

    move-wide v6, p4

    invoke-virtual/range {v2 .. v7}, Lvk;->C(BJJ)J

    move-result-wide p1

    cmp-long p3, p1, v0

    if-eqz p3, :cond_1e

    return-wide p1

    :cond_1e
    iget-wide p1, v2, Lvk;->b:J

    cmp-long p3, p1, v6

    if-gez p3, :cond_38

    iget-object p3, p0, Lbq1;->a:Lr42;

    const-wide/16 p4, 0x2000

    invoke-interface {p3, v2, p4, p5}, Lr42;->read(Lvk;J)J

    move-result-wide p3

    cmp-long p3, p3, v0

    if-nez p3, :cond_31

    goto :goto_38

    :cond_31
    invoke-static {v4, v5, p1, p2}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v4

    move p1, v3

    move-wide p4, v6

    goto :goto_b

    :cond_38
    :goto_38
    return-wide v0

    :cond_39
    move-wide v6, p4

    const-string p0, "fromIndex=0 toIndex="

    invoke-static {v6, v7, p0}, Lmz2;->j(JLjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->v(Ljava/lang/Object;)V

    return-wide v0

    :cond_44
    const-string p0, "closed"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-wide v0
.end method

.method public final p(J)Z
    .registers 9

    .prologue
    const-wide/16 v0, 0x0

    cmp-long v0, p1, v0

    const/4 v1, 0x0

    if-ltz v0, :cond_2a

    iget-boolean v0, p0, Lbq1;->c:Z

    if-nez v0, :cond_24

    :cond_b
    iget-object v0, p0, Lbq1;->b:Lvk;

    iget-wide v2, v0, Lvk;->b:J

    cmp-long v2, v2, p1

    if-gez v2, :cond_22

    iget-object v2, p0, Lbq1;->a:Lr42;

    const-wide/16 v3, 0x2000

    invoke-interface {v2, v0, v3, v4}, Lr42;->read(Lvk;J)J

    move-result-wide v2

    const-wide/16 v4, -0x1

    cmp-long v0, v2, v4

    if-nez v0, :cond_b

    return v1

    :cond_22
    const/4 p0, 0x1

    return p0

    :cond_24
    const-string p0, "closed"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return v1

    :cond_2a
    const-string p0, "byteCount < 0: "

    invoke-static {p1, p2, p0}, Lmz2;->j(JLjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->v(Ljava/lang/Object;)V

    return v1
.end method

.method public final read(Ljava/nio/ByteBuffer;)I
    .registers 7

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Lbq1;->b:Lvk;

    iget-wide v1, v0, Lvk;->b:J

    const-wide/16 v3, 0x0

    cmp-long v1, v1, v3

    if-nez v1, :cond_1d

    iget-object p0, p0, Lbq1;->a:Lr42;

    const-wide/16 v1, 0x2000

    invoke-interface {p0, v0, v1, v2}, Lr42;->read(Lvk;J)J

    move-result-wide v1

    const-wide/16 v3, -0x1

    cmp-long p0, v1, v3

    if-nez p0, :cond_1d

    const/4 p0, -0x1

    return p0

    :cond_1d
    invoke-virtual {v0, p1}, Lvk;->read(Ljava/nio/ByteBuffer;)I

    move-result p0

    return p0
.end method

.method public final read(Lvk;J)J
    .registers 9

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-wide/16 v0, 0x0

    cmp-long v2, p2, v0

    if-ltz v2, :cond_35

    iget-boolean v2, p0, Lbq1;->c:Z

    if-nez v2, :cond_2f

    iget-object v2, p0, Lbq1;->b:Lvk;

    iget-wide v3, v2, Lvk;->b:J

    cmp-long v0, v3, v0

    if-nez v0, :cond_24

    iget-object p0, p0, Lbq1;->a:Lr42;

    const-wide/16 v0, 0x2000

    invoke-interface {p0, v2, v0, v1}, Lr42;->read(Lvk;J)J

    move-result-wide v0

    const-wide/16 v3, -0x1

    cmp-long p0, v0, v3

    if-nez p0, :cond_24

    return-wide v3

    :cond_24
    iget-wide v0, v2, Lvk;->b:J

    invoke-static {p2, p3, v0, v1}, Ljava/lang/Math;->min(JJ)J

    move-result-wide p2

    invoke-virtual {v2, p1, p2, p3}, Lvk;->read(Lvk;J)J

    move-result-wide p0

    return-wide p0

    :cond_2f
    const-string p0, "closed"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-wide v0

    :cond_35
    const-string p0, "byteCount < 0: "

    invoke-static {p2, p3, p0}, Lmz2;->j(JLjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->v(Ljava/lang/Object;)V

    return-wide v0
.end method

.method public final readByte()B
    .registers 3

    const-wide/16 v0, 0x1

    invoke-virtual {p0, v0, v1}, Lbq1;->F(J)V

    iget-object p0, p0, Lbq1;->b:Lvk;

    invoke-virtual {p0}, Lvk;->readByte()B

    move-result p0

    return p0
.end method

.method public final readInt()I
    .registers 3

    const-wide/16 v0, 0x4

    invoke-virtual {p0, v0, v1}, Lbq1;->F(J)V

    iget-object p0, p0, Lbq1;->b:Lvk;

    invoke-virtual {p0}, Lvk;->readInt()I

    move-result p0

    return p0
.end method

.method public final readShort()S
    .registers 3

    const-wide/16 v0, 0x2

    invoke-virtual {p0, v0, v1}, Lbq1;->F(J)V

    iget-object p0, p0, Lbq1;->b:Lvk;

    invoke-virtual {p0}, Lvk;->readShort()S

    move-result p0

    return p0
.end method

.method public final skip(J)V
    .registers 8

    .prologue
    iget-boolean v0, p0, Lbq1;->c:Z

    if-nez v0, :cond_31

    :goto_4
    const-wide/16 v0, 0x0

    cmp-long v2, p1, v0

    if-lez v2, :cond_30

    iget-object v2, p0, Lbq1;->b:Lvk;

    iget-wide v3, v2, Lvk;->b:J

    cmp-long v0, v3, v0

    if-nez v0, :cond_25

    iget-object v0, p0, Lbq1;->a:Lr42;

    const-wide/16 v3, 0x2000

    invoke-interface {v0, v2, v3, v4}, Lr42;->read(Lvk;J)J

    move-result-wide v0

    const-wide/16 v3, -0x1

    cmp-long v0, v0, v3

    if-eqz v0, :cond_21

    goto :goto_25

    :cond_21
    invoke-static {}, Lz6;->m()V

    return-void

    :cond_25
    :goto_25
    iget-wide v0, v2, Lvk;->b:J

    invoke-static {p1, p2, v0, v1}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v0

    invoke-virtual {v2, v0, v1}, Lvk;->skip(J)V

    sub-long/2addr p1, v0

    goto :goto_4

    :cond_30
    return-void

    :cond_31
    const-string p0, "closed"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-void
.end method

.method public final timeout()Lya2;
    .registers 1

    iget-object p0, p0, Lbq1;->a:Lr42;

    invoke-interface {p0}, Lr42;->timeout()Lya2;

    move-result-object p0

    return-object p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "buffer("

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object p0, p0, Lbq1;->a:Lr42;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 p0, 0x29

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public final u()[B
    .registers 3

    iget-object v0, p0, Lbq1;->a:Lr42;

    iget-object p0, p0, Lbq1;->b:Lvk;

    invoke-virtual {p0, v0}, Lvk;->m(Lr42;)J

    iget-wide v0, p0, Lvk;->b:J

    invoke-virtual {p0, v0, v1}, Lvk;->M(J)[B

    move-result-object p0

    return-object p0
.end method

.method public final v(J)Ljava/lang/String;
    .registers 23

    .prologue
    move-wide/from16 v6, p1

    const-wide/16 v0, 0x0

    cmp-long v0, v6, v0

    const/4 v8, 0x0

    if-ltz v0, :cond_7d

    const-wide v9, 0x7fffffffffffffffL

    cmp-long v0, v6, v9

    const-wide/16 v11, 0x1

    if-nez v0, :cond_16

    move-wide v4, v9

    goto :goto_19

    :cond_16
    add-long v0, v6, v11

    move-wide v4, v0

    :goto_19
    const-wide/16 v2, 0x0

    const/16 v1, 0xa

    move-object/from16 v0, p0

    invoke-virtual/range {v0 .. v5}, Lbq1;->n(BJJ)J

    move-result-wide v2

    const-wide/16 v13, -0x1

    cmp-long v13, v2, v13

    iget-object v14, v0, Lbq1;->b:Lvk;

    if-eqz v13, :cond_30

    invoke-static {v14, v2, v3}, Lps2;->a(Lvk;J)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_30
    cmp-long v2, v4, v9

    if-gez v2, :cond_57

    invoke-virtual {v0, v4, v5}, Lbq1;->p(J)Z

    move-result v2

    if-eqz v2, :cond_57

    sub-long v2, v4, v11

    invoke-virtual {v14, v2, v3}, Lvk;->y(J)B

    move-result v2

    const/16 v3, 0xd

    if-ne v2, v3, :cond_57

    add-long v2, v4, v11

    invoke-virtual {v0, v2, v3}, Lbq1;->p(J)Z

    move-result v0

    if-eqz v0, :cond_57

    invoke-virtual {v14, v4, v5}, Lvk;->y(J)B

    move-result v0

    if-ne v0, v1, :cond_57

    invoke-static {v14, v4, v5}, Lps2;->a(Lvk;J)Ljava/lang/String;

    move-result-object v0

    return-object v0

    :cond_57
    new-instance v15, Lvk;

    invoke-direct {v15}, Ljava/lang/Object;-><init>()V

    iget-wide v0, v14, Lvk;->b:J

    const-wide/16 v2, 0x20

    invoke-static {v2, v3, v0, v1}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v18

    const-wide/16 v16, 0x0

    invoke-virtual/range {v14 .. v19}, Lvk;->n(Lvk;JJ)V

    iget-wide v0, v14, Lvk;->b:J

    invoke-static {v0, v1, v6, v7}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v0

    iget-wide v2, v15, Lvk;->b:J

    invoke-virtual {v15, v2, v3}, Lvk;->j(J)Lxl;

    move-result-object v2

    invoke-virtual {v2}, Lxl;->h()Ljava/lang/String;

    move-result-object v2

    invoke-static {v0, v1, v2}, Lz6;->o(JLjava/lang/Object;)V

    return-object v8

    :cond_7d
    const-string v0, "limit < 0: "

    invoke-static {v6, v7, v0}, Lmz2;->j(JLjava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lz6;->v(Ljava/lang/Object;)V

    return-object v8
.end method

.method public final w(Ljava/nio/charset/Charset;)Ljava/lang/String;
    .registers 4

    iget-object v0, p0, Lbq1;->a:Lr42;

    iget-object p0, p0, Lbq1;->b:Lvk;

    invoke-virtual {p0, v0}, Lvk;->m(Lr42;)J

    iget-wide v0, p0, Lvk;->b:J

    invoke-virtual {p0, v0, v1, p1}, Lvk;->O(JLjava/nio/charset/Charset;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public final x()Lxl;
    .registers 3

    iget-object v0, p0, Lbq1;->a:Lr42;

    iget-object p0, p0, Lbq1;->b:Lvk;

    invoke-virtual {p0, v0}, Lvk;->m(Lr42;)J

    iget-wide v0, p0, Lvk;->b:J

    invoke-virtual {p0, v0, v1}, Lvk;->j(J)Lxl;

    move-result-object p0

    return-object p0
.end method

.method public final z(Lvk;)J
    .registers 12

    .prologue
    const-wide/16 v0, 0x0

    move-wide v2, v0

    :cond_3
    :goto_3
    iget-object v4, p0, Lbq1;->a:Lr42;

    const-wide/16 v5, 0x2000

    iget-object v7, p0, Lbq1;->b:Lvk;

    invoke-interface {v4, v7, v5, v6}, Lr42;->read(Lvk;J)J

    move-result-wide v4

    const-wide/16 v8, -0x1

    cmp-long v4, v4, v8

    if-eqz v4, :cond_20

    invoke-virtual {v7}, Lvk;->k()J

    move-result-wide v4

    cmp-long v6, v4, v0

    if-lez v6, :cond_3

    add-long/2addr v2, v4

    invoke-virtual {p1, v7, v4, v5}, Lvk;->r(Lvk;J)V

    goto :goto_3

    :cond_20
    iget-wide v4, v7, Lvk;->b:J

    cmp-long p0, v4, v0

    if-lez p0, :cond_2a

    add-long/2addr v2, v4

    invoke-virtual {p1, v7, v4, v5}, Lvk;->r(Lvk;J)V

    :cond_2a
    return-wide v2
.end method
