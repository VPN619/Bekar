.class public final Lb50;
.super Lr92;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final synthetic e:I

.field public final synthetic f:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/String;I)V
    .registers 4

    iput p3, p0, Lb50;->e:I

    iput-object p1, p0, Lb50;->f:Ljava/lang/Object;

    const/4 p1, 0x1

    invoke-direct {p0, p2, p1}, Lr92;-><init>(Ljava/lang/String;Z)V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/Object;I)V
    .registers 4

    iput p3, p0, Lb50;->e:I

    iput-object p2, p0, Lb50;->f:Ljava/lang/Object;

    const/4 p2, 0x1

    invoke-direct {p0, p1, p2}, Lr92;-><init>(Ljava/lang/String;Z)V

    return-void
.end method


# virtual methods
.method public final a()J
    .registers 16

    .prologue
    iget v0, p0, Lb50;->e:I

    const/4 v1, 0x1

    const/4 v2, 0x0

    const-wide/16 v3, -0x1

    packed-switch v0, :pswitch_data_e8

    iget-object p0, p0, Lb50;->f:Ljava/lang/Object;

    check-cast p0, Lzj0;

    invoke-interface {p0}, Lzj0;->invoke()Ljava/lang/Object;

    return-wide v3

    :pswitch_11  #0x2
    iget-object p0, p0, Lb50;->f:Ljava/lang/Object;

    check-cast p0, Liq1;

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v5

    iget-object v0, p0, Liq1;->e:Ljava/util/concurrent/ConcurrentLinkedQueue;

    invoke-virtual {v0}, Ljava/util/concurrent/ConcurrentLinkedQueue;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v7, 0x0

    const-wide/high16 v8, -0x8000000000000000L

    move-wide v9, v8

    move-object v8, v7

    move v7, v2

    :goto_25
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_4f

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lhq1;

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    monitor-enter v11

    :try_start_35
    invoke-virtual {p0, v11, v5, v6}, Liq1;->b(Lhq1;J)I

    move-result v12

    if-lez v12, :cond_3e

    add-int/lit8 v7, v7, 0x1

    goto :goto_4a

    :cond_3e
    add-int/lit8 v2, v2, 0x1

    iget-wide v12, v11, Lhq1;->q:J
    :try_end_42
    .catchall {:try_start_35 .. :try_end_42} :catchall_4c

    sub-long v12, v5, v12

    cmp-long v14, v12, v9

    if-lez v14, :cond_4a

    move-object v8, v11

    move-wide v9, v12

    :cond_4a
    :goto_4a
    monitor-exit v11

    goto :goto_25

    :catchall_4c
    move-exception p0

    monitor-exit v11

    throw p0

    :cond_4f
    iget-wide v11, p0, Liq1;->b:J

    cmp-long v0, v9, v11

    if-gez v0, :cond_63

    iget v0, p0, Liq1;->a:I

    if-le v2, v0, :cond_5a

    goto :goto_63

    :cond_5a
    if-lez v2, :cond_5f

    sub-long v3, v11, v9

    goto :goto_99

    :cond_5f
    if-lez v7, :cond_99

    move-wide v3, v11

    goto :goto_99

    :cond_63
    :goto_63
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    monitor-enter v8

    :try_start_67
    iget-object v0, v8, Lhq1;->p:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v0
    :try_end_6d
    .catchall {:try_start_67 .. :try_end_6d} :catchall_9a

    const-wide/16 v3, 0x0

    if-nez v0, :cond_73

    monitor-exit v8

    goto :goto_99

    :cond_73
    :try_start_73
    iget-wide v11, v8, Lhq1;->q:J
    :try_end_75
    .catchall {:try_start_73 .. :try_end_75} :catchall_9a

    add-long/2addr v11, v9

    cmp-long v0, v11, v5

    if-eqz v0, :cond_7c

    monitor-exit v8

    goto :goto_99

    :cond_7c
    :try_start_7c
    iput-boolean v1, v8, Lhq1;->j:Z

    iget-object v0, p0, Liq1;->e:Ljava/util/concurrent/ConcurrentLinkedQueue;

    invoke-virtual {v0, v8}, Ljava/util/concurrent/ConcurrentLinkedQueue;->remove(Ljava/lang/Object;)Z
    :try_end_83
    .catchall {:try_start_7c .. :try_end_83} :catchall_9a

    monitor-exit v8

    iget-object v0, v8, Lhq1;->d:Ljava/net/Socket;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v0}, Lki2;->d(Ljava/net/Socket;)V

    iget-object v0, p0, Liq1;->e:Ljava/util/concurrent/ConcurrentLinkedQueue;

    invoke-virtual {v0}, Ljava/util/concurrent/ConcurrentLinkedQueue;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_99

    iget-object p0, p0, Liq1;->c:Lu92;

    invoke-virtual {p0}, Lu92;->a()V

    :cond_99
    :goto_99
    return-wide v3

    :catchall_9a
    move-exception p0

    monitor-exit v8

    throw p0

    :pswitch_9d  #0x1
    iget-object p0, p0, Lb50;->f:Ljava/lang/Object;

    check-cast p0, Ldp0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_a4
    iget-object v0, p0, Ldp0;->w:Llp0;

    const/4 v1, 0x2

    invoke-virtual {v0, v1, v2, v2}, Llp0;->n(IIZ)V
    :try_end_aa
    .catch Ljava/io/IOException; {:try_start_a4 .. :try_end_aa} :catch_ab

    goto :goto_b1

    :catch_ab
    move-exception v0

    sget-object v1, Lfb0;->c:Lfb0;

    invoke-virtual {p0, v1, v1, v0}, Ldp0;->a(Lfb0;Lfb0;Ljava/io/IOException;)V

    :goto_b1
    return-wide v3

    :pswitch_b2  #0x0
    iget-object p0, p0, Lb50;->f:Ljava/lang/Object;

    check-cast p0, Lc50;

    monitor-enter p0

    :try_start_b7
    iget-boolean v0, p0, Lc50;->l:Z

    if-eqz v0, :cond_e4

    iget-boolean v0, p0, Lc50;->m:Z
    :try_end_bd
    .catchall {:try_start_b7 .. :try_end_bd} :catchall_c4

    if-eqz v0, :cond_c0

    goto :goto_e4

    :cond_c0
    :try_start_c0
    invoke-virtual {p0}, Lc50;->R()V
    :try_end_c3
    .catch Ljava/io/IOException; {:try_start_c0 .. :try_end_c3} :catch_c6
    .catchall {:try_start_c0 .. :try_end_c3} :catchall_c4

    goto :goto_c8

    :catchall_c4
    move-exception v0

    goto :goto_e6

    :catch_c6
    :try_start_c6
    iput-boolean v1, p0, Lc50;->n:Z
    :try_end_c8
    .catchall {:try_start_c6 .. :try_end_c8} :catchall_c4

    :goto_c8
    :try_start_c8
    invoke-virtual {p0}, Lc50;->H()Z

    move-result v0

    if-eqz v0, :cond_e2

    invoke-virtual {p0}, Lc50;->P()V

    iput v2, p0, Lc50;->i:I
    :try_end_d3
    .catch Ljava/io/IOException; {:try_start_c8 .. :try_end_d3} :catch_d4
    .catchall {:try_start_c8 .. :try_end_d3} :catchall_c4

    goto :goto_e2

    :catch_d4
    :try_start_d4
    iput-boolean v1, p0, Lc50;->o:Z

    new-instance v0, Lkj;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    new-instance v1, Laq1;

    invoke-direct {v1, v0}, Laq1;-><init>(Ld42;)V

    iput-object v1, p0, Lc50;->g:Laq1;
    :try_end_e2
    .catchall {:try_start_d4 .. :try_end_e2} :catchall_c4

    :cond_e2
    :goto_e2
    monitor-exit p0

    goto :goto_e5

    :cond_e4
    :goto_e4
    monitor-exit p0

    :goto_e5
    return-wide v3

    :goto_e6
    monitor-exit p0

    throw v0

    :pswitch_data_e8
    .packed-switch 0x0
        :pswitch_b2  #00000000
        :pswitch_9d  #00000001
        :pswitch_11  #00000002
    .end packed-switch
.end method
