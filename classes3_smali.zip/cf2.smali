.class public final Lcf2;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lky0;


# instance fields
.field public final a:Llq;

.field public final b:Ljava/util/List;

.field public final c:I


# direct methods
.method public constructor <init>(Llq;Ljava/util/List;I)V
    .registers 4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcf2;->a:Llq;

    iput-object p2, p0, Lcf2;->b:Ljava/util/List;

    iput p3, p0, Lcf2;->c:I

    return-void
.end method


# virtual methods
.method public final a()Z
    .registers 2

    .prologue
    iget p0, p0, Lcf2;->c:I

    const/4 v0, 0x1

    and-int/2addr p0, v0

    if-eqz p0, :cond_7

    return v0

    :cond_7
    const/4 p0, 0x0

    return p0
.end method

.method public final b()Ljava/util/List;
    .registers 1

    iget-object p0, p0, Lcf2;->b:Ljava/util/List;

    return-object p0
.end method

.method public final c()Llq;
    .registers 1

    iget-object p0, p0, Lcf2;->a:Llq;

    return-object p0
.end method

.method public final d(Z)Ljava/lang/String;
    .registers 12

    .prologue
    iget-object v0, p0, Lcf2;->a:Llq;

    instance-of v1, v0, Llq;

    const/4 v2, 0x0

    if-eqz v1, :cond_9

    move-object v1, v0

    goto :goto_a

    :cond_9
    move-object v1, v2

    :goto_a
    if-eqz v1, :cond_11

    iget-object v2, v1, Llq;->a:Ljava/lang/Class;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :cond_11
    if-nez v2, :cond_19

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    goto/16 :goto_9a

    :cond_19
    iget v1, p0, Lcf2;->c:I

    and-int/lit8 v1, v1, 0x4

    if-eqz v1, :cond_23

    const-string p1, "kotlin.Nothing"

    goto/16 :goto_9a

    :cond_23
    invoke-virtual {v2}, Ljava/lang/Class;->isArray()Z

    move-result v1

    if-eqz v1, :cond_85

    const-class p1, [Z

    invoke-virtual {v2, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_35

    const-string p1, "kotlin.BooleanArray"

    goto/16 :goto_9a

    :cond_35
    const-class p1, [C

    invoke-virtual {v2, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_40

    const-string p1, "kotlin.CharArray"

    goto :goto_9a

    :cond_40
    const-class p1, [B

    invoke-virtual {v2, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_4b

    const-string p1, "kotlin.ByteArray"

    goto :goto_9a

    :cond_4b
    const-class p1, [S

    invoke-virtual {v2, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_56

    const-string p1, "kotlin.ShortArray"

    goto :goto_9a

    :cond_56
    const-class p1, [I

    invoke-virtual {v2, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_61

    const-string p1, "kotlin.IntArray"

    goto :goto_9a

    :cond_61
    const-class p1, [F

    invoke-virtual {v2, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_6c

    const-string p1, "kotlin.FloatArray"

    goto :goto_9a

    :cond_6c
    const-class p1, [J

    invoke-virtual {v2, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_77

    const-string p1, "kotlin.LongArray"

    goto :goto_9a

    :cond_77
    const-class p1, [D

    invoke-virtual {v2, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_82

    const-string p1, "kotlin.DoubleArray"

    goto :goto_9a

    :cond_82
    const-string p1, "kotlin.Array"

    goto :goto_9a

    :cond_85
    if-eqz p1, :cond_96

    invoke-virtual {v2}, Ljava/lang/Class;->isPrimitive()Z

    move-result p1

    if-eqz p1, :cond_96

    invoke-static {v0}, Lqk;->o(Llq;)Ljava/lang/Class;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p1

    goto :goto_9a

    :cond_96
    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p1

    :goto_9a
    iget-object v0, p0, Lcf2;->b:Ljava/util/List;

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v1

    const-string v2, ""

    if-eqz v1, :cond_a6

    move-object v0, v2

    goto :goto_bd

    :cond_a6
    move-object v3, v0

    check-cast v3, Ljava/lang/Iterable;

    new-instance v8, Lb3;

    const/16 v0, 0x18

    invoke-direct {v8, v0, p0}, Lb3;-><init>(ILjava/lang/Object;)V

    const/16 v9, 0x18

    const-string v4, ", "

    const-string v5, "<"

    const-string v6, ">"

    const/4 v7, 0x0

    invoke-static/range {v3 .. v9}, Lbs;->p0(Ljava/lang/Iterable;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILbk0;I)Ljava/lang/String;

    move-result-object v0

    :goto_bd
    invoke-virtual {p0}, Lcf2;->a()Z

    move-result p0

    if-eqz p0, :cond_c5

    const-string v2, "?"

    :cond_c5
    invoke-static {p1, v0, v2}, Lrt2;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    .prologue
    instance-of v0, p1, Lcf2;

    if-eqz v0, :cond_22

    check-cast p1, Lcf2;

    iget-object v0, p1, Lcf2;->a:Llq;

    iget-object v1, p0, Lcf2;->a:Llq;

    invoke-static {v1, v0}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_22

    iget-object v0, p0, Lcf2;->b:Ljava/util/List;

    iget-object v1, p1, Lcf2;->b:Ljava/util/List;

    invoke-static {v0, v1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_22

    iget p0, p0, Lcf2;->c:I

    iget p1, p1, Lcf2;->c:I

    if-ne p0, p1, :cond_22

    const/4 p0, 0x1

    return p0

    :cond_22
    const/4 p0, 0x0

    return p0
.end method

.method public final hashCode()I
    .registers 3

    iget-object v0, p0, Lcf2;->a:Llq;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, Lcf2;->b:Ljava/util/List;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    mul-int/lit8 v1, v1, 0x1f

    iget p0, p0, Lcf2;->c:I

    invoke-static {p0}, Ljava/lang/Integer;->hashCode(I)I

    move-result p0

    add-int/2addr p0, v1

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 2

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lcf2;->d(Z)Ljava/lang/String;

    move-result-object p0

    const-string v0, " (Kotlin reflection is not available)"

    invoke-virtual {p0, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
