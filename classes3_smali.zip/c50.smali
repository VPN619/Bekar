.class public final Lc50;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ljava/io/Closeable;
.implements Ljava/io/Flushable;


# static fields
.field public static final s:Ljs1;

.field public static final t:Ljava/lang/String;

.field public static final u:Ljava/lang/String;

.field public static final v:Ljava/lang/String;

.field public static final w:Ljava/lang/String;


# instance fields
.field public final a:Ljava/io/File;

.field public final b:J

.field public final c:Ljava/io/File;

.field public final d:Ljava/io/File;

.field public final e:Ljava/io/File;

.field public f:J

.field public g:Laq1;

.field public final h:Ljava/util/LinkedHashMap;

.field public i:I

.field public j:Z

.field public k:Z

.field public l:Z

.field public m:Z

.field public n:Z

.field public o:Z

.field public p:J

.field public final q:Lu92;

.field public final r:Lb50;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Ljs1;

    const-string v1, "[a-z0-9_-]{1,120}"

    invoke-direct {v0, v1}, Ljs1;-><init>(Ljava/lang/String;)V

    sput-object v0, Lc50;->s:Ljs1;

    const-string v0, "CLEAN"

    sput-object v0, Lc50;->t:Ljava/lang/String;

    const-string v0, "DIRTY"

    sput-object v0, Lc50;->u:Ljava/lang/String;

    const-string v0, "REMOVE"

    sput-object v0, Lc50;->v:Ljava/lang/String;

    const-string v0, "READ"

    sput-object v0, Lc50;->w:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Ljava/io/File;JLv92;)V
    .registers 9

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lc50;->a:Ljava/io/File;

    iput-wide p2, p0, Lc50;->b:J

    new-instance v0, Ljava/util/LinkedHashMap;

    const/high16 v1, 0x3f400000  # 0.75f

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-direct {v0, v3, v1, v2}, Ljava/util/LinkedHashMap;-><init>(IFZ)V

    iput-object v0, p0, Lc50;->h:Ljava/util/LinkedHashMap;

    invoke-virtual {p4}, Lv92;->d()Lu92;

    move-result-object p4

    iput-object p4, p0, Lc50;->q:Lu92;

    sget-object p4, Lki2;->g:Ljava/lang/String;

    const-string v0, " Cache"

    invoke-static {v0, p4}, Lgt0;->C0(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p4

    new-instance v0, Lb50;

    invoke-direct {v0, p0, p4, v3}, Lb50;-><init>(Ljava/lang/Object;Ljava/lang/String;I)V

    iput-object v0, p0, Lc50;->r:Lb50;

    const-wide/16 v0, 0x0

    cmp-long p2, p2, v0

    if-lez p2, :cond_4f

    new-instance p2, Ljava/io/File;

    const-string p3, "journal"

    invoke-direct {p2, p1, p3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    iput-object p2, p0, Lc50;->c:Ljava/io/File;

    new-instance p2, Ljava/io/File;

    const-string p3, "journal.tmp"

    invoke-direct {p2, p1, p3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    iput-object p2, p0, Lc50;->d:Ljava/io/File;

    new-instance p2, Ljava/io/File;

    const-string p3, "journal.bkp"

    invoke-direct {p2, p1, p3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    iput-object p2, p0, Lc50;->e:Ljava/io/File;

    return-void

    :cond_4f
    const-string p0, "maxSize <= 0"

    invoke-static {p0}, Lz6;->s(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0
.end method

.method public static S(Ljava/lang/String;)V
    .registers 3

    .prologue
    sget-object v0, Lc50;->s:Ljs1;

    invoke-virtual {v0, p0}, Ljs1;->c(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_9

    return-void

    :cond_9
    const-string v0, "keys must match regex [a-z0-9_-]{1,120}: \""

    const/16 v1, 0x22

    invoke-static {v0, p0, v1}, Ly41;->p(Ljava/lang/String;Ljava/lang/String;C)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->v(Ljava/lang/Object;)V

    return-void
.end method


# virtual methods
.method public final declared-synchronized C()V
    .registers 7

    .prologue
    const-string v0, "DiskLruCache "

    monitor-enter p0

    :try_start_3
    sget-object v1, Lki2;->a:[B

    iget-boolean v1, p0, Lc50;->l:Z
    :try_end_7
    .catchall {:try_start_3 .. :try_end_7} :catchall_23

    if-eqz v1, :cond_b

    monitor-exit p0

    return-void

    :cond_b
    :try_start_b
    sget-object v1, Lms1;->c:Lms1;

    iget-object v2, p0, Lc50;->e:Ljava/io/File;

    invoke-virtual {v1, v2}, Lms1;->k(Ljava/io/File;)Z

    move-result v2

    if-eqz v2, :cond_2b

    iget-object v2, p0, Lc50;->c:Ljava/io/File;

    invoke-virtual {v1, v2}, Lms1;->k(Ljava/io/File;)Z

    move-result v2
    :try_end_1b
    .catchall {:try_start_b .. :try_end_1b} :catchall_23

    iget-object v3, p0, Lc50;->e:Ljava/io/File;

    if-eqz v2, :cond_26

    :try_start_1f
    invoke-virtual {v1, v3}, Lms1;->i(Ljava/io/File;)V

    goto :goto_2b

    :catchall_23
    move-exception v0

    goto/16 :goto_b5

    :cond_26
    iget-object v2, p0, Lc50;->c:Ljava/io/File;

    invoke-virtual {v1, v3, v2}, Lms1;->m(Ljava/io/File;Ljava/io/File;)V

    :cond_2b
    :goto_2b
    iget-object v2, p0, Lc50;->e:Ljava/io/File;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_33
    .catchall {:try_start_1f .. :try_end_33} :catchall_23

    :try_start_33
    invoke-static {v2}, Lfh1;->a(Ljava/io/File;)Lef;

    move-result-object v3
    :try_end_37
    .catch Ljava/io/FileNotFoundException; {:try_start_33 .. :try_end_37} :catch_38
    .catchall {:try_start_33 .. :try_end_37} :catchall_23

    goto :goto_43

    :catch_38
    :try_start_38
    invoke-virtual {v2}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v3

    invoke-virtual {v3}, Ljava/io/File;->mkdirs()Z

    invoke-static {v2}, Lfh1;->a(Ljava/io/File;)Lef;

    move-result-object v3
    :try_end_43
    .catchall {:try_start_38 .. :try_end_43} :catchall_23

    :goto_43
    const/4 v4, 0x0

    const/4 v5, 0x1

    :try_start_45
    invoke-virtual {v1, v2}, Lms1;->i(Ljava/io/File;)V
    :try_end_48
    .catch Ljava/io/IOException; {:try_start_45 .. :try_end_48} :catch_54
    .catchall {:try_start_45 .. :try_end_48} :catchall_4d

    :try_start_48
    invoke-virtual {v3}, Lef;->close()V
    :try_end_4b
    .catchall {:try_start_48 .. :try_end_4b} :catchall_23

    move v1, v5

    goto :goto_5b

    :catchall_4d
    move-exception v0

    :try_start_4e
    throw v0
    :try_end_4f
    .catchall {:try_start_4e .. :try_end_4f} :catchall_4f

    :catchall_4f
    move-exception v1

    :try_start_50
    invoke-static {v3, v0}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v1

    :catch_54
    invoke-virtual {v3}, Lef;->close()V

    invoke-virtual {v1, v2}, Lms1;->i(Ljava/io/File;)V

    move v1, v4

    :goto_5b
    iput-boolean v1, p0, Lc50;->k:Z

    iget-object v1, p0, Lc50;->c:Ljava/io/File;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v1
    :try_end_66
    .catchall {:try_start_50 .. :try_end_66} :catchall_23

    if-eqz v1, :cond_ae

    :try_start_68
    invoke-virtual {p0}, Lc50;->N()V

    invoke-virtual {p0}, Lc50;->M()V

    iput-boolean v5, p0, Lc50;->l:Z
    :try_end_70
    .catch Ljava/io/IOException; {:try_start_68 .. :try_end_70} :catch_72
    .catchall {:try_start_68 .. :try_end_70} :catchall_23

    monitor-exit p0

    return-void

    :catch_72
    move-exception v1

    :try_start_73
    sget-object v2, Lbk1;->a:Lbk1;

    sget-object v2, Lbk1;->a:Lbk1;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v0, p0, Lc50;->a:Ljava/io/File;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, " is corrupt: "

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, ", removing"

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v2, 0x5

    invoke-static {v2, v0, v1}, Lbk1;->i(ILjava/lang/String;Ljava/lang/Throwable;)V
    :try_end_9d
    .catchall {:try_start_73 .. :try_end_9d} :catchall_23

    :try_start_9d
    invoke-virtual {p0}, Lc50;->close()V

    sget-object v0, Lms1;->c:Lms1;

    iget-object v1, p0, Lc50;->a:Ljava/io/File;

    invoke-virtual {v0, v1}, Lms1;->j(Ljava/io/File;)V
    :try_end_a7
    .catchall {:try_start_9d .. :try_end_a7} :catchall_aa

    :try_start_a7
    iput-boolean v4, p0, Lc50;->m:Z

    goto :goto_ae

    :catchall_aa
    move-exception v0

    iput-boolean v4, p0, Lc50;->m:Z

    throw v0

    :cond_ae
    :goto_ae
    invoke-virtual {p0}, Lc50;->P()V

    iput-boolean v5, p0, Lc50;->l:Z
    :try_end_b3
    .catchall {:try_start_a7 .. :try_end_b3} :catchall_23

    monitor-exit p0

    return-void

    :goto_b5
    :try_start_b5
    monitor-exit p0
    :try_end_b6
    .catchall {:try_start_b5 .. :try_end_b6} :catchall_23

    throw v0
.end method

.method public final H()Z
    .registers 3

    .prologue
    iget v0, p0, Lc50;->i:I

    const/16 v1, 0x7d0

    if-lt v0, v1, :cond_10

    iget-object p0, p0, Lc50;->h:Ljava/util/LinkedHashMap;

    invoke-virtual {p0}, Ljava/util/AbstractMap;->size()I

    move-result p0

    if-lt v0, p0, :cond_10

    const/4 p0, 0x1

    return p0

    :cond_10
    const/4 p0, 0x0

    return p0
.end method

.method public final I()Laq1;
    .registers 6

    .prologue
    iget-object v0, p0, Lc50;->c:Ljava/io/File;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x1

    :try_start_6
    sget-object v2, Lfh1;->a:Ljava/util/logging/Logger;

    new-instance v2, Ljava/io/FileOutputStream;

    invoke-direct {v2, v0, v1}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;Z)V

    new-instance v3, Lef;

    new-instance v4, Lya2;

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    invoke-direct {v3, v1, v2, v4}, Lef;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V
    :try_end_17
    .catch Ljava/io/FileNotFoundException; {:try_start_6 .. :try_end_17} :catch_18

    goto :goto_30

    :catch_18
    invoke-virtual {v0}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v2

    invoke-virtual {v2}, Ljava/io/File;->mkdirs()Z

    sget-object v2, Lfh1;->a:Ljava/util/logging/Logger;

    new-instance v2, Ljava/io/FileOutputStream;

    invoke-direct {v2, v0, v1}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;Z)V

    new-instance v3, Lef;

    new-instance v0, Lya2;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    invoke-direct {v3, v1, v2, v0}, Lef;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    :goto_30
    new-instance v0, Lfd0;

    new-instance v2, Lo20;

    invoke-direct {v2, v1, p0}, Lo20;-><init>(ILjava/lang/Object;)V

    invoke-direct {v0, v3, v2}, Lfd0;-><init>(Lef;Lbk0;)V

    new-instance p0, Laq1;

    invoke-direct {p0, v0}, Laq1;-><init>(Ld42;)V

    return-object p0
.end method

.method public final M()V
    .registers 12

    .prologue
    sget-object v0, Lms1;->c:Lms1;

    iget-object v1, p0, Lc50;->d:Ljava/io/File;

    invoke-virtual {v0, v1}, Lms1;->i(Ljava/io/File;)V

    iget-object v1, p0, Lc50;->h:Ljava/util/LinkedHashMap;

    invoke-virtual {v1}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_11
    :goto_11
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_58

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v2, Lz40;

    iget-object v3, v2, Lz40;->g:Lx40;

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-nez v3, :cond_35

    :goto_26
    if-ge v5, v4, :cond_11

    add-int/lit8 v3, v5, 0x1

    iget-wide v6, p0, Lc50;->f:J

    iget-object v8, v2, Lz40;->b:[J

    aget-wide v9, v8, v5

    add-long/2addr v6, v9

    iput-wide v6, p0, Lc50;->f:J

    move v5, v3

    goto :goto_26

    :cond_35
    const/4 v3, 0x0

    iput-object v3, v2, Lz40;->g:Lx40;

    :goto_38
    if-ge v5, v4, :cond_54

    add-int/lit8 v3, v5, 0x1

    iget-object v6, v2, Lz40;->c:Ljava/util/ArrayList;

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/io/File;

    invoke-virtual {v0, v6}, Lms1;->i(Ljava/io/File;)V

    iget-object v6, v2, Lz40;->d:Ljava/util/ArrayList;

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/io/File;

    invoke-virtual {v0, v5}, Lms1;->i(Ljava/io/File;)V

    move v5, v3

    goto :goto_38

    :cond_54
    invoke-interface {v1}, Ljava/util/Iterator;->remove()V

    goto :goto_11

    :cond_58
    return-void
.end method

.method public final N()V
    .registers 12

    .prologue
    const-string v0, ", "

    const-string v1, "unexpected journal header: ["

    iget-object v2, p0, Lc50;->c:Ljava/io/File;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v3, Lfh1;->a:Ljava/util/logging/Logger;

    new-instance v3, Lff;

    new-instance v4, Ljava/io/FileInputStream;

    invoke-direct {v4, v2}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V

    sget-object v2, Lya2;->d:Lxa2;

    const/4 v5, 0x1

    invoke-direct {v3, v5, v4, v2}, Lff;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    new-instance v2, Lbq1;

    invoke-direct {v2, v3}, Lbq1;-><init>(Lr42;)V

    const-wide v3, 0x7fffffffffffffffL

    :try_start_22
    invoke-virtual {v2, v3, v4}, Lbq1;->v(J)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v3, v4}, Lbq1;->v(J)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v2, v3, v4}, Lbq1;->v(J)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v2, v3, v4}, Lbq1;->v(J)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v2, v3, v4}, Lbq1;->v(J)Ljava/lang/String;

    move-result-object v9

    const-string v10, "libcore.io.DiskLruCache"

    invoke-virtual {v10, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_8e

    const-string v10, "1"

    invoke-virtual {v10, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_8e

    const v10, 0x31191

    invoke-static {v10}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v10

    invoke-static {v10, v7}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_8e

    const/4 v7, 0x2

    invoke-static {v7}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v7

    invoke-static {v7, v8}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_8e

    invoke-virtual {v9}, Ljava/lang/String;->length()I

    move-result v7
    :try_end_62
    .catchall {:try_start_22 .. :try_end_62} :catchall_6f

    if-gtz v7, :cond_8e

    const/4 v0, 0x0

    :goto_65
    :try_start_65
    invoke-virtual {v2, v3, v4}, Lbq1;->v(J)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, Lc50;->O(Ljava/lang/String;)V
    :try_end_6c
    .catch Ljava/io/EOFException; {:try_start_65 .. :try_end_6c} :catch_71
    .catchall {:try_start_65 .. :try_end_6c} :catchall_6f

    add-int/lit8 v0, v0, 0x1

    goto :goto_65

    :catchall_6f
    move-exception p0

    goto :goto_b7

    :catch_71
    :try_start_71
    iget-object v1, p0, Lc50;->h:Ljava/util/LinkedHashMap;

    invoke-virtual {v1}, Ljava/util/AbstractMap;->size()I

    move-result v1

    sub-int/2addr v0, v1

    iput v0, p0, Lc50;->i:I

    invoke-virtual {v2}, Lbq1;->k()Z

    move-result v0

    if-nez v0, :cond_84

    invoke-virtual {p0}, Lc50;->P()V

    goto :goto_8a

    :cond_84
    invoke-virtual {p0}, Lc50;->I()Laq1;

    move-result-object v0

    iput-object v0, p0, Lc50;->g:Laq1;
    :try_end_8a
    .catchall {:try_start_71 .. :try_end_8a} :catchall_6f

    :goto_8a
    invoke-virtual {v2}, Lbq1;->close()V

    return-void

    :cond_8e
    :try_start_8e
    new-instance p0, Ljava/io/IOException;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x5d

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
    :try_end_b7
    .catchall {:try_start_8e .. :try_end_b7} :catchall_6f

    :goto_b7
    :try_start_b7
    throw p0
    :try_end_b8
    .catchall {:try_start_b7 .. :try_end_b8} :catchall_b8

    :catchall_b8
    move-exception v0

    invoke-static {v2, p0}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0
.end method

.method public final O(Ljava/lang/String;)V
    .registers 12

    .prologue
    const/4 v0, 0x6

    const/16 v1, 0x20

    const/4 v2, 0x0

    invoke-static {p1, v1, v2, v0}, Lc72;->r0(Ljava/lang/CharSequence;CII)I

    move-result v0

    const-string v3, "unexpected journal line: "

    const/4 v4, -0x1

    if-eq v0, v4, :cond_ca

    add-int/lit8 v5, v0, 0x1

    const/4 v6, 0x4

    invoke-static {p1, v1, v5, v6}, Lc72;->r0(Ljava/lang/CharSequence;CII)I

    move-result v6

    iget-object v7, p0, Lc50;->h:Ljava/util/LinkedHashMap;

    if-ne v6, v4, :cond_2e

    invoke-virtual {p1, v5}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v5

    sget-object v8, Lc50;->v:Ljava/lang/String;

    invoke-virtual {v8}, Ljava/lang/String;->length()I

    move-result v9

    if-ne v0, v9, :cond_32

    invoke-static {p1, v8, v2}, Lk72;->k0(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v8

    if-eqz v8, :cond_32

    invoke-virtual {v7, v5}, Ljava/util/AbstractMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_2e
    invoke-virtual {p1, v5, v6}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v5

    :cond_32
    invoke-virtual {v7, v5}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lz40;

    if-nez v8, :cond_42

    new-instance v8, Lz40;

    invoke-direct {v8, p0, v5}, Lz40;-><init>(Lc50;Ljava/lang/String;)V

    invoke-interface {v7, v5, v8}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_42
    if-eq v6, v4, :cond_99

    sget-object v5, Lc50;->t:Ljava/lang/String;

    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v7

    if-ne v0, v7, :cond_99

    invoke-static {p1, v5, v2}, Lk72;->k0(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v5

    if-eqz v5, :cond_99

    const/4 p0, 0x1

    add-int/2addr v6, p0

    invoke-virtual {p1, v6}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p1

    new-array v0, p0, [C

    aput-char v1, v0, v2

    invoke-static {p1, v0}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object p1

    iput-boolean p0, v8, Lz40;->e:Z

    const/4 p0, 0x0

    iput-object p0, v8, Lz40;->g:Lx40;

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    iget-object v0, v8, Lz40;->j:Lc50;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x2

    if-ne p0, v0, :cond_91

    :try_start_71
    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p0

    :goto_75
    if-ge v2, p0, :cond_c1

    add-int/lit8 v0, v2, 0x1

    iget-object v1, v8, Lz40;->b:[J

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-static {v4}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v4

    aput-wide v4, v1, v2
    :try_end_87
    .catch Ljava/lang/NumberFormatException; {:try_start_71 .. :try_end_87} :catch_89

    move v2, v0

    goto :goto_75

    :catch_89
    invoke-static {p1, v3}, Lgt0;->C0(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lvh0;->k(Ljava/lang/String;)V

    return-void

    :cond_91
    invoke-static {p1, v3}, Lgt0;->C0(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lvh0;->k(Ljava/lang/String;)V

    return-void

    :cond_99
    if-ne v6, v4, :cond_b1

    sget-object v1, Lc50;->u:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v5

    if-ne v0, v5, :cond_b1

    invoke-static {p1, v1, v2}, Lk72;->k0(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v1

    if-eqz v1, :cond_b1

    new-instance p1, Lx40;

    invoke-direct {p1, p0, v8}, Lx40;-><init>(Lc50;Lz40;)V

    iput-object p1, v8, Lz40;->g:Lx40;

    return-void

    :cond_b1
    if-ne v6, v4, :cond_c2

    sget-object p0, Lc50;->w:Ljava/lang/String;

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    if-ne v0, v1, :cond_c2

    invoke-static {p1, p0, v2}, Lk72;->k0(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result p0

    if-eqz p0, :cond_c2

    :cond_c1
    return-void

    :cond_c2
    invoke-static {p1, v3}, Lgt0;->C0(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lvh0;->k(Ljava/lang/String;)V

    return-void

    :cond_ca
    invoke-static {p1, v3}, Lgt0;->C0(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lvh0;->k(Ljava/lang/String;)V

    return-void
.end method

.method public final declared-synchronized P()V
    .registers 10

    .prologue
    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Lc50;->g:Laq1;

    if-nez v0, :cond_6

    goto :goto_9

    :cond_6
    invoke-virtual {v0}, Laq1;->close()V

    :goto_9
    iget-object v0, p0, Lc50;->d:Ljava/io/File;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_e
    .catchall {:try_start_1 .. :try_end_e} :catchall_af

    :try_start_e
    invoke-static {v0}, Lfh1;->a(Ljava/io/File;)Lef;

    move-result-object v0
    :try_end_12
    .catch Ljava/io/FileNotFoundException; {:try_start_e .. :try_end_12} :catch_13
    .catchall {:try_start_e .. :try_end_12} :catchall_af

    goto :goto_1e

    :catch_13
    :try_start_13
    invoke-virtual {v0}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object v1

    invoke-virtual {v1}, Ljava/io/File;->mkdirs()Z

    invoke-static {v0}, Lfh1;->a(Ljava/io/File;)Lef;

    move-result-object v0

    :goto_1e
    new-instance v1, Laq1;

    invoke-direct {v1, v0}, Laq1;-><init>(Ld42;)V
    :try_end_23
    .catchall {:try_start_13 .. :try_end_23} :catchall_af

    :try_start_23
    const-string v0, "libcore.io.DiskLruCache"

    invoke-virtual {v1, v0}, Laq1;->q(Ljava/lang/String;)Lgl;

    const/16 v0, 0xa

    invoke-virtual {v1, v0}, Laq1;->writeByte(I)Lgl;

    const-string v2, "1"

    invoke-virtual {v1, v2}, Laq1;->q(Ljava/lang/String;)Lgl;

    invoke-virtual {v1, v0}, Laq1;->writeByte(I)Lgl;

    const-wide/32 v2, 0x31191

    invoke-virtual {v1, v2, v3}, Laq1;->G(J)Lgl;

    invoke-virtual {v1, v0}, Laq1;->writeByte(I)Lgl;

    const-wide/16 v2, 0x2

    invoke-virtual {v1, v2, v3}, Laq1;->G(J)Lgl;

    invoke-virtual {v1, v0}, Laq1;->writeByte(I)Lgl;

    invoke-virtual {v1, v0}, Laq1;->writeByte(I)Lgl;

    iget-object v2, p0, Lc50;->h:Ljava/util/LinkedHashMap;

    invoke-virtual {v2}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_53
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_9a

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lz40;

    iget-object v5, v3, Lz40;->g:Lx40;

    const/16 v6, 0x20

    if-eqz v5, :cond_79

    sget-object v4, Lc50;->u:Ljava/lang/String;

    invoke-virtual {v1, v4}, Laq1;->q(Ljava/lang/String;)Lgl;

    invoke-virtual {v1, v6}, Laq1;->writeByte(I)Lgl;

    iget-object v3, v3, Lz40;->a:Ljava/lang/String;

    invoke-virtual {v1, v3}, Laq1;->q(Ljava/lang/String;)Lgl;

    invoke-virtual {v1, v0}, Laq1;->writeByte(I)Lgl;

    goto :goto_53

    :catchall_77
    move-exception v0

    goto :goto_c9

    :cond_79
    sget-object v5, Lc50;->t:Ljava/lang/String;

    invoke-virtual {v1, v5}, Laq1;->q(Ljava/lang/String;)Lgl;

    invoke-virtual {v1, v6}, Laq1;->writeByte(I)Lgl;

    iget-object v5, v3, Lz40;->a:Ljava/lang/String;

    invoke-virtual {v1, v5}, Laq1;->q(Ljava/lang/String;)Lgl;

    iget-object v3, v3, Lz40;->b:[J

    array-length v5, v3

    :goto_89
    if-ge v4, v5, :cond_96

    aget-wide v7, v3, v4

    add-int/lit8 v4, v4, 0x1

    invoke-virtual {v1, v6}, Laq1;->writeByte(I)Lgl;

    invoke-virtual {v1, v7, v8}, Laq1;->G(J)Lgl;

    goto :goto_89

    :cond_96
    invoke-virtual {v1, v0}, Laq1;->writeByte(I)Lgl;
    :try_end_99
    .catchall {:try_start_23 .. :try_end_99} :catchall_77

    goto :goto_53

    :cond_9a
    :try_start_9a
    invoke-virtual {v1}, Laq1;->close()V

    sget-object v0, Lms1;->c:Lms1;

    iget-object v1, p0, Lc50;->c:Ljava/io/File;

    invoke-virtual {v0, v1}, Lms1;->k(Ljava/io/File;)Z

    move-result v1

    if-eqz v1, :cond_b1

    iget-object v1, p0, Lc50;->c:Ljava/io/File;

    iget-object v2, p0, Lc50;->e:Ljava/io/File;

    invoke-virtual {v0, v1, v2}, Lms1;->m(Ljava/io/File;Ljava/io/File;)V

    goto :goto_b1

    :catchall_af
    move-exception v0

    goto :goto_cf

    :cond_b1
    :goto_b1
    iget-object v1, p0, Lc50;->d:Ljava/io/File;

    iget-object v2, p0, Lc50;->c:Ljava/io/File;

    invoke-virtual {v0, v1, v2}, Lms1;->m(Ljava/io/File;Ljava/io/File;)V

    iget-object v1, p0, Lc50;->e:Ljava/io/File;

    invoke-virtual {v0, v1}, Lms1;->i(Ljava/io/File;)V

    invoke-virtual {p0}, Lc50;->I()Laq1;

    move-result-object v0

    iput-object v0, p0, Lc50;->g:Laq1;

    iput-boolean v4, p0, Lc50;->j:Z

    iput-boolean v4, p0, Lc50;->o:Z
    :try_end_c7
    .catchall {:try_start_9a .. :try_end_c7} :catchall_af

    monitor-exit p0

    return-void

    :goto_c9
    :try_start_c9
    throw v0
    :try_end_ca
    .catchall {:try_start_c9 .. :try_end_ca} :catchall_ca

    :catchall_ca
    move-exception v2

    :try_start_cb
    invoke-static {v1, v0}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v2

    :goto_cf
    monitor-exit p0
    :try_end_d0
    .catchall {:try_start_cb .. :try_end_d0} :catchall_af

    throw v0
.end method

.method public final Q(Lz40;)V
    .registers 13

    .prologue
    iget-object v0, p1, Lz40;->a:Ljava/lang/String;

    iget-boolean v1, p0, Lc50;->k:Z

    const/16 v2, 0xa

    const/16 v3, 0x20

    const/4 v4, 0x1

    if-nez v1, :cond_30

    iget v1, p1, Lz40;->h:I

    if-lez v1, :cond_25

    iget-object v1, p0, Lc50;->g:Laq1;

    if-nez v1, :cond_14

    goto :goto_25

    :cond_14
    sget-object v5, Lc50;->u:Ljava/lang/String;

    invoke-virtual {v1, v5}, Laq1;->q(Ljava/lang/String;)Lgl;

    invoke-virtual {v1, v3}, Laq1;->writeByte(I)Lgl;

    invoke-virtual {v1, v0}, Laq1;->q(Ljava/lang/String;)Lgl;

    invoke-virtual {v1, v2}, Laq1;->writeByte(I)Lgl;

    invoke-virtual {v1}, Laq1;->flush()V

    :cond_25
    :goto_25
    iget v1, p1, Lz40;->h:I

    if-gtz v1, :cond_2d

    iget-object v1, p1, Lz40;->g:Lx40;

    if-eqz v1, :cond_30

    :cond_2d
    iput-boolean v4, p1, Lz40;->f:Z

    return-void

    :cond_30
    iget-object v1, p1, Lz40;->g:Lx40;

    if-nez v1, :cond_35

    goto :goto_38

    :cond_35
    invoke-virtual {v1}, Lx40;->d()V

    :goto_38
    const/4 v1, 0x0

    :goto_39
    const/4 v5, 0x2

    if-ge v1, v5, :cond_6f

    add-int/lit8 v5, v1, 0x1

    iget-object v6, p1, Lz40;->c:Ljava/util/ArrayList;

    invoke-virtual {v6, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/io/File;

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v6}, Ljava/io/File;->delete()Z

    move-result v7

    if-nez v7, :cond_60

    invoke-virtual {v6}, Ljava/io/File;->exists()Z

    move-result v7

    if-nez v7, :cond_56

    goto :goto_60

    :cond_56
    const-string p0, "failed to delete "

    invoke-static {v6, p0}, Lgt0;->C0(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lvh0;->k(Ljava/lang/String;)V

    return-void

    :cond_60
    :goto_60
    iget-wide v6, p0, Lc50;->f:J

    iget-object v8, p1, Lz40;->b:[J

    aget-wide v9, v8, v1

    sub-long/2addr v6, v9

    iput-wide v6, p0, Lc50;->f:J

    const-wide/16 v6, 0x0

    aput-wide v6, v8, v1

    move v1, v5

    goto :goto_39

    :cond_6f
    iget p1, p0, Lc50;->i:I

    add-int/2addr p1, v4

    iput p1, p0, Lc50;->i:I

    iget-object p1, p0, Lc50;->g:Laq1;

    if-nez p1, :cond_79

    goto :goto_87

    :cond_79
    sget-object v1, Lc50;->v:Ljava/lang/String;

    invoke-virtual {p1, v1}, Laq1;->q(Ljava/lang/String;)Lgl;

    invoke-virtual {p1, v3}, Laq1;->writeByte(I)Lgl;

    invoke-virtual {p1, v0}, Laq1;->q(Ljava/lang/String;)Lgl;

    invoke-virtual {p1, v2}, Laq1;->writeByte(I)Lgl;

    :goto_87
    iget-object p1, p0, Lc50;->h:Ljava/util/LinkedHashMap;

    invoke-virtual {p1, v0}, Ljava/util/AbstractMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p0}, Lc50;->H()Z

    move-result p1

    if-eqz p1, :cond_99

    iget-object p1, p0, Lc50;->q:Lu92;

    iget-object p0, p0, Lc50;->r:Lb50;

    invoke-static {p1, p0}, Lu92;->d(Lu92;Lr92;)V

    :cond_99
    return-void
.end method

.method public final R()V
    .registers 5

    .prologue
    :goto_0
    iget-wide v0, p0, Lc50;->f:J

    iget-wide v2, p0, Lc50;->b:J

    cmp-long v0, v0, v2

    if-lez v0, :cond_27

    iget-object v0, p0, Lc50;->h:Ljava/util/LinkedHashMap;

    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_12
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_26

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lz40;

    iget-boolean v2, v1, Lz40;->f:Z

    if-nez v2, :cond_12

    invoke-virtual {p0, v1}, Lc50;->Q(Lz40;)V

    goto :goto_0

    :cond_26
    return-void

    :cond_27
    const/4 v0, 0x0

    iput-boolean v0, p0, Lc50;->n:Z

    return-void
.end method

.method public final declared-synchronized close()V
    .registers 6

    .prologue
    monitor-enter p0

    :try_start_1
    iget-boolean v0, p0, Lc50;->l:Z

    const/4 v1, 0x1

    if-eqz v0, :cond_4a

    iget-boolean v0, p0, Lc50;->m:Z

    if-eqz v0, :cond_b

    goto :goto_4a

    :cond_b
    iget-object v0, p0, Lc50;->h:Ljava/util/LinkedHashMap;

    invoke-virtual {v0}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v2, 0x0

    new-array v3, v2, [Lz40;

    invoke-interface {v0, v3}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_42

    check-cast v0, [Lz40;

    array-length v3, v0

    :cond_20
    :goto_20
    if-ge v2, v3, :cond_30

    aget-object v4, v0, v2

    add-int/lit8 v2, v2, 0x1

    iget-object v4, v4, Lz40;->g:Lx40;

    if-eqz v4, :cond_20

    invoke-virtual {v4}, Lx40;->d()V

    goto :goto_20

    :catchall_2e
    move-exception v0

    goto :goto_4e

    :cond_30
    invoke-virtual {p0}, Lc50;->R()V

    iget-object v0, p0, Lc50;->g:Laq1;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Laq1;->close()V

    const/4 v0, 0x0

    iput-object v0, p0, Lc50;->g:Laq1;

    iput-boolean v1, p0, Lc50;->m:Z
    :try_end_40
    .catchall {:try_start_1 .. :try_end_40} :catchall_2e

    monitor-exit p0

    return-void

    :cond_42
    :try_start_42
    new-instance v0, Ljava/lang/NullPointerException;

    const-string v1, "null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>"

    invoke-direct {v0, v1}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_4a
    :goto_4a
    iput-boolean v1, p0, Lc50;->m:Z
    :try_end_4c
    .catchall {:try_start_42 .. :try_end_4c} :catchall_2e

    monitor-exit p0

    return-void

    :goto_4e
    :try_start_4e
    monitor-exit p0
    :try_end_4f
    .catchall {:try_start_4e .. :try_end_4f} :catchall_2e

    throw v0
.end method

.method public final declared-synchronized flush()V
    .registers 2

    .prologue
    monitor-enter p0

    :try_start_1
    iget-boolean v0, p0, Lc50;->l:Z
    :try_end_3
    .catchall {:try_start_1 .. :try_end_3} :catchall_17

    if-nez v0, :cond_7

    monitor-exit p0

    return-void

    :cond_7
    :try_start_7
    invoke-virtual {p0}, Lc50;->k()V

    invoke-virtual {p0}, Lc50;->R()V

    iget-object v0, p0, Lc50;->g:Laq1;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Laq1;->flush()V
    :try_end_15
    .catchall {:try_start_7 .. :try_end_15} :catchall_17

    monitor-exit p0

    return-void

    :catchall_17
    move-exception v0

    :try_start_18
    monitor-exit p0
    :try_end_19
    .catchall {:try_start_18 .. :try_end_19} :catchall_17

    throw v0
.end method

.method public final declared-synchronized k()V
    .registers 3

    .prologue
    monitor-enter p0

    :try_start_1
    iget-boolean v0, p0, Lc50;->m:Z
    :try_end_3
    .catchall {:try_start_1 .. :try_end_3} :catchall_f

    if-nez v0, :cond_7

    monitor-exit p0

    return-void

    :cond_7
    :try_start_7
    const-string v0, "cache is closed"

    new-instance v1, Ljava/lang/IllegalStateException;

    invoke-direct {v1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1

    :catchall_f
    move-exception v0

    monitor-exit p0
    :try_end_11
    .catchall {:try_start_7 .. :try_end_11} :catchall_f

    throw v0
.end method

.method public final declared-synchronized n(Lx40;Z)V
    .registers 14

    .prologue
    monitor-enter p0

    :try_start_1
    iget-object v0, p1, Lx40;->c:Ljava/lang/Object;

    check-cast v0, Lz40;

    iget-object v1, v0, Lz40;->g:Lx40;

    invoke-static {v1, p1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_12b

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-eqz p2, :cond_53

    iget-boolean v3, v0, Lz40;->e:Z

    if-nez v3, :cond_53

    move v3, v2

    :goto_16
    if-ge v3, v1, :cond_53

    add-int/lit8 v4, v3, 0x1

    iget-object v5, p1, Lx40;->a:Ljava/lang/Object;

    check-cast v5, [Z

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    aget-boolean v5, v5, v3

    if-eqz v5, :cond_40

    iget-object v5, v0, Lz40;->d:Ljava/util/ArrayList;

    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/io/File;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v3}, Ljava/io/File;->exists()Z

    move-result v3

    if-nez v3, :cond_3e

    invoke-virtual {p1}, Lx40;->b()V
    :try_end_39
    .catchall {:try_start_1 .. :try_end_39} :catchall_3b

    monitor-exit p0

    return-void

    :catchall_3b
    move-exception p1

    goto/16 :goto_133

    :cond_3e
    move v3, v4

    goto :goto_16

    :cond_40
    :try_start_40
    invoke-virtual {p1}, Lx40;->b()V

    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "Newly created entry didn\'t create value for index "

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-static {v0, p2}, Lgt0;->C0(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_53
    move p1, v2

    :goto_54
    if-ge p1, v1, :cond_aa

    add-int/lit8 v3, p1, 0x1

    iget-object v4, v0, Lz40;->d:Ljava/util/ArrayList;

    invoke-virtual {v4, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/io/File;

    if-eqz p2, :cond_8c

    iget-boolean v5, v0, Lz40;->f:Z

    if-nez v5, :cond_8c

    sget-object v5, Lms1;->c:Lms1;

    invoke-virtual {v5, v4}, Lms1;->k(Ljava/io/File;)Z

    move-result v6

    if-eqz v6, :cond_a8

    iget-object v6, v0, Lz40;->c:Ljava/util/ArrayList;

    invoke-virtual {v6, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/io/File;

    invoke-virtual {v5, v4, v6}, Lms1;->m(Ljava/io/File;Ljava/io/File;)V

    iget-object v4, v0, Lz40;->b:[J

    aget-wide v7, v4, p1

    invoke-virtual {v6}, Ljava/io/File;->length()J

    move-result-wide v4

    iget-object v6, v0, Lz40;->b:[J

    aput-wide v4, v6, p1

    iget-wide v9, p0, Lc50;->f:J

    sub-long/2addr v9, v7

    add-long/2addr v9, v4

    iput-wide v9, p0, Lc50;->f:J

    goto :goto_a8

    :cond_8c
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v4}, Ljava/io/File;->delete()Z

    move-result p1

    if-nez p1, :cond_a8

    invoke-virtual {v4}, Ljava/io/File;->exists()Z

    move-result p1

    if-nez p1, :cond_9c

    goto :goto_a8

    :cond_9c
    new-instance p1, Ljava/io/IOException;

    const-string p2, "failed to delete "

    invoke-static {v4, p2}, Lgt0;->C0(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-direct {p1, p2}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_a8
    :goto_a8
    move p1, v3

    goto :goto_54

    :cond_aa
    const/4 p1, 0x0

    iput-object p1, v0, Lz40;->g:Lx40;

    iget-boolean p1, v0, Lz40;->f:Z

    if-eqz p1, :cond_b6

    invoke-virtual {p0, v0}, Lc50;->Q(Lz40;)V
    :try_end_b4
    .catchall {:try_start_40 .. :try_end_b4} :catchall_3b

    monitor-exit p0

    return-void

    :cond_b6
    :try_start_b6
    iget p1, p0, Lc50;->i:I

    const/4 v1, 0x1

    add-int/2addr p1, v1

    iput p1, p0, Lc50;->i:I

    iget-object p1, p0, Lc50;->g:Laq1;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-boolean v3, v0, Lz40;->e:Z

    const/16 v4, 0xa

    const/16 v5, 0x20

    if-nez v3, :cond_e4

    if-eqz p2, :cond_cc

    goto :goto_e4

    :cond_cc
    iget-object p2, p0, Lc50;->h:Ljava/util/LinkedHashMap;

    iget-object v1, v0, Lz40;->a:Ljava/lang/String;

    invoke-virtual {p2, v1}, Ljava/util/AbstractMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    sget-object p2, Lc50;->v:Ljava/lang/String;

    invoke-virtual {p1, p2}, Laq1;->q(Ljava/lang/String;)Lgl;

    invoke-virtual {p1, v5}, Laq1;->writeByte(I)Lgl;

    iget-object p2, v0, Lz40;->a:Ljava/lang/String;

    invoke-virtual {p1, p2}, Laq1;->q(Ljava/lang/String;)Lgl;

    invoke-virtual {p1, v4}, Laq1;->writeByte(I)Lgl;

    goto :goto_111

    :cond_e4
    :goto_e4
    iput-boolean v1, v0, Lz40;->e:Z

    sget-object v1, Lc50;->t:Ljava/lang/String;

    invoke-virtual {p1, v1}, Laq1;->q(Ljava/lang/String;)Lgl;

    invoke-virtual {p1, v5}, Laq1;->writeByte(I)Lgl;

    iget-object v1, v0, Lz40;->a:Ljava/lang/String;

    invoke-virtual {p1, v1}, Laq1;->q(Ljava/lang/String;)Lgl;

    iget-object v1, v0, Lz40;->b:[J

    array-length v3, v1

    :goto_f6
    if-ge v2, v3, :cond_103

    aget-wide v6, v1, v2

    add-int/lit8 v2, v2, 0x1

    invoke-virtual {p1, v5}, Laq1;->writeByte(I)Lgl;

    invoke-virtual {p1, v6, v7}, Laq1;->G(J)Lgl;

    goto :goto_f6

    :cond_103
    invoke-virtual {p1, v4}, Laq1;->writeByte(I)Lgl;

    if-eqz p2, :cond_111

    iget-wide v1, p0, Lc50;->p:J

    const-wide/16 v3, 0x1

    add-long/2addr v3, v1

    iput-wide v3, p0, Lc50;->p:J

    iput-wide v1, v0, Lz40;->i:J

    :cond_111
    :goto_111
    invoke-virtual {p1}, Laq1;->flush()V

    iget-wide p1, p0, Lc50;->f:J

    iget-wide v0, p0, Lc50;->b:J

    cmp-long p1, p1, v0

    if-gtz p1, :cond_122

    invoke-virtual {p0}, Lc50;->H()Z

    move-result p1

    if-eqz p1, :cond_129

    :cond_122
    iget-object p1, p0, Lc50;->q:Lu92;

    iget-object p2, p0, Lc50;->r:Lb50;

    invoke-static {p1, p2}, Lu92;->d(Lu92;Lr92;)V
    :try_end_129
    .catchall {:try_start_b6 .. :try_end_129} :catchall_3b

    :cond_129
    monitor-exit p0

    return-void

    :cond_12b
    :try_start_12b
    const-string p1, "Check failed."

    new-instance p2, Ljava/lang/IllegalStateException;

    invoke-direct {p2, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p2

    :goto_133
    monitor-exit p0
    :try_end_134
    .catchall {:try_start_12b .. :try_end_134} :catchall_3b

    throw p1
.end method

.method public final declared-synchronized p(JLjava/lang/String;)Lx40;
    .registers 9

    .prologue
    monitor-enter p0

    :try_start_1
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Lc50;->C()V

    invoke-virtual {p0}, Lc50;->k()V

    invoke-static {p3}, Lc50;->S(Ljava/lang/String;)V

    iget-object v0, p0, Lc50;->h:Ljava/util/LinkedHashMap;

    invoke-virtual {v0, p3}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lz40;

    const-wide/16 v1, -0x1

    cmp-long v1, p1, v1

    const/4 v2, 0x0

    if-eqz v1, :cond_29

    if-eqz v0, :cond_27

    iget-wide v3, v0, Lz40;->i:J
    :try_end_20
    .catchall {:try_start_1 .. :try_end_20} :catchall_25

    cmp-long p1, v3, p1

    if-eqz p1, :cond_29

    goto :goto_27

    :catchall_25
    move-exception p1

    goto :goto_82

    :cond_27
    :goto_27
    monitor-exit p0

    return-object v2

    :cond_29
    if-nez v0, :cond_2d

    move-object p1, v2

    goto :goto_2f

    :cond_2d
    :try_start_2d
    iget-object p1, v0, Lz40;->g:Lx40;
    :try_end_2f
    .catchall {:try_start_2d .. :try_end_2f} :catchall_25

    :goto_2f
    if-eqz p1, :cond_33

    monitor-exit p0

    return-object v2

    :cond_33
    if-eqz v0, :cond_3b

    :try_start_35
    iget p1, v0, Lz40;->h:I
    :try_end_37
    .catchall {:try_start_35 .. :try_end_37} :catchall_25

    if-eqz p1, :cond_3b

    monitor-exit p0

    return-object v2

    :cond_3b
    :try_start_3b
    iget-boolean p1, p0, Lc50;->n:Z

    if-nez p1, :cond_79

    iget-boolean p1, p0, Lc50;->o:Z

    if-eqz p1, :cond_44

    goto :goto_79

    :cond_44
    iget-object p1, p0, Lc50;->g:Laq1;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object p2, Lc50;->u:Ljava/lang/String;

    invoke-virtual {p1, p2}, Laq1;->q(Ljava/lang/String;)Lgl;

    const/16 p2, 0x20

    invoke-virtual {p1, p2}, Laq1;->writeByte(I)Lgl;

    invoke-interface {p1, p3}, Lgl;->q(Ljava/lang/String;)Lgl;

    const/16 p2, 0xa

    invoke-interface {p1, p2}, Lgl;->writeByte(I)Lgl;

    invoke-virtual {p1}, Laq1;->flush()V

    iget-boolean p1, p0, Lc50;->j:Z
    :try_end_60
    .catchall {:try_start_3b .. :try_end_60} :catchall_25

    if-eqz p1, :cond_64

    monitor-exit p0

    return-object v2

    :cond_64
    if-nez v0, :cond_70

    :try_start_66
    new-instance v0, Lz40;

    invoke-direct {v0, p0, p3}, Lz40;-><init>(Lc50;Ljava/lang/String;)V

    iget-object p1, p0, Lc50;->h:Ljava/util/LinkedHashMap;

    invoke-interface {p1, p3, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_70
    new-instance p1, Lx40;

    invoke-direct {p1, p0, v0}, Lx40;-><init>(Lc50;Lz40;)V

    iput-object p1, v0, Lz40;->g:Lx40;
    :try_end_77
    .catchall {:try_start_66 .. :try_end_77} :catchall_25

    monitor-exit p0

    return-object p1

    :cond_79
    :goto_79
    :try_start_79
    iget-object p1, p0, Lc50;->q:Lu92;

    iget-object p2, p0, Lc50;->r:Lb50;

    invoke-static {p1, p2}, Lu92;->d(Lu92;Lr92;)V
    :try_end_80
    .catchall {:try_start_79 .. :try_end_80} :catchall_25

    monitor-exit p0

    return-object v2

    :goto_82
    :try_start_82
    monitor-exit p0
    :try_end_83
    .catchall {:try_start_82 .. :try_end_83} :catchall_25

    throw p1
.end method

.method public final declared-synchronized y(Ljava/lang/String;)La50;
    .registers 5

    .prologue
    monitor-enter p0

    :try_start_1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Lc50;->C()V

    invoke-virtual {p0}, Lc50;->k()V

    invoke-static {p1}, Lc50;->S(Ljava/lang/String;)V

    iget-object v0, p0, Lc50;->h:Ljava/util/LinkedHashMap;

    invoke-virtual {v0, p1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lz40;
    :try_end_15
    .catchall {:try_start_1 .. :try_end_15} :catchall_4d

    const/4 v1, 0x0

    if-nez v0, :cond_1a

    monitor-exit p0

    return-object v1

    :cond_1a
    :try_start_1a
    invoke-virtual {v0}, Lz40;->a()La50;

    move-result-object v0
    :try_end_1e
    .catchall {:try_start_1a .. :try_end_1e} :catchall_4d

    if-nez v0, :cond_22

    monitor-exit p0

    return-object v1

    :cond_22
    :try_start_22
    iget v1, p0, Lc50;->i:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, Lc50;->i:I

    iget-object v1, p0, Lc50;->g:Laq1;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v2, Lc50;->w:Ljava/lang/String;

    invoke-virtual {v1, v2}, Laq1;->q(Ljava/lang/String;)Lgl;

    const/16 v2, 0x20

    invoke-virtual {v1, v2}, Laq1;->writeByte(I)Lgl;

    invoke-interface {v1, p1}, Lgl;->q(Ljava/lang/String;)Lgl;

    const/16 p1, 0xa

    invoke-interface {v1, p1}, Lgl;->writeByte(I)Lgl;

    invoke-virtual {p0}, Lc50;->H()Z

    move-result p1

    if-eqz p1, :cond_4f

    iget-object p1, p0, Lc50;->q:Lu92;

    iget-object v1, p0, Lc50;->r:Lb50;

    invoke-static {p1, v1}, Lu92;->d(Lu92;Lr92;)V
    :try_end_4c
    .catchall {:try_start_22 .. :try_end_4c} :catchall_4d

    goto :goto_4f

    :catchall_4d
    move-exception p1

    goto :goto_51

    :cond_4f
    :goto_4f
    monitor-exit p0

    return-object v0

    :goto_51
    :try_start_51
    monitor-exit p0
    :try_end_52
    .catchall {:try_start_51 .. :try_end_52} :catchall_4d

    throw p1
.end method
