.class public final Lc5;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Lvp1;

.field public final b:Ljavax/net/SocketFactory;

.field public final c:Ljavax/net/ssl/SSLSocketFactory;

.field public final d:Ljavax/net/ssl/HostnameVerifier;

.field public final e:Lxn;

.field public final f:Lp80;

.field public final g:Ljava/net/ProxySelector;

.field public final h:Lop0;

.field public final i:Ljava/util/List;

.field public final j:Ljava/util/List;


# direct methods
.method public constructor <init>(Ljava/lang/String;ILvp1;Ljavax/net/SocketFactory;Ljavax/net/ssl/SSLSocketFactory;Ljavax/net/ssl/HostnameVerifier;Lxn;Lp80;Ljava/util/List;Ljava/util/List;Ljava/net/ProxySelector;)V
    .registers 12

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p3, p0, Lc5;->a:Lvp1;

    iput-object p4, p0, Lc5;->b:Ljavax/net/SocketFactory;

    iput-object p5, p0, Lc5;->c:Ljavax/net/ssl/SSLSocketFactory;

    iput-object p6, p0, Lc5;->d:Ljavax/net/ssl/HostnameVerifier;

    iput-object p7, p0, Lc5;->e:Lxn;

    iput-object p8, p0, Lc5;->f:Lp80;

    iput-object p11, p0, Lc5;->g:Ljava/net/ProxySelector;

    new-instance p3, Lnp0;

    const/4 p4, 0x0

    invoke-direct {p3, p4}, Lnp0;-><init>(I)V

    const-string p6, "http"

    const-string p7, "https"

    if-eqz p5, :cond_34

    move-object p5, p7

    goto :goto_35

    :cond_34
    move-object p5, p6

    :goto_35
    invoke-virtual {p5, p6}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result p8

    const/4 p11, 0x0

    if-eqz p8, :cond_3f

    iput-object p6, p3, Lnp0;->c:Ljava/lang/Object;

    goto :goto_47

    :cond_3f
    invoke-virtual {p5, p7}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result p6

    if-eqz p6, :cond_88

    iput-object p7, p3, Lnp0;->c:Ljava/lang/Object;

    :goto_47
    const/4 p5, 0x7

    invoke-static {p4, p4, p5, p1}, Lp80;->q(IIILjava/lang/String;)Ljava/lang/String;

    move-result-object p4

    invoke-static {p4}, Luz;->N(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p4

    if-eqz p4, :cond_7e

    iput-object p4, p3, Lnp0;->f:Ljava/lang/Object;

    const/4 p1, 0x1

    if-gt p1, p2, :cond_70

    const/high16 p1, 0x10000

    if-ge p2, p1, :cond_70

    iput p2, p3, Lnp0;->b:I

    invoke-virtual {p3}, Lnp0;->b()Lop0;

    move-result-object p1

    iput-object p1, p0, Lc5;->h:Lop0;

    invoke-static {p9}, Lki2;->v(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, Lc5;->i:Ljava/util/List;

    invoke-static {p10}, Lki2;->v(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, Lc5;->j:Ljava/util/List;

    return-void

    :cond_70
    const-string p0, "unexpected port: "

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-static {p1, p0}, Lgt0;->C0(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->v(Ljava/lang/Object;)V

    throw p11

    :cond_7e
    const-string p0, "unexpected host: "

    invoke-static {p1, p0}, Lgt0;->C0(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->s(Ljava/lang/String;)V

    throw p11

    :cond_88
    const-string p0, "unexpected scheme: "

    invoke-static {p5, p0}, Lgt0;->C0(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->s(Ljava/lang/String;)V

    throw p11
.end method


# virtual methods
.method public final a(Lc5;)Z
    .registers 4

    .prologue
    iget-object v0, p0, Lc5;->a:Lvp1;

    iget-object v1, p1, Lc5;->a:Lvp1;

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5c

    iget-object v0, p0, Lc5;->f:Lp80;

    iget-object v1, p1, Lc5;->f:Lp80;

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5c

    iget-object v0, p0, Lc5;->i:Ljava/util/List;

    iget-object v1, p1, Lc5;->i:Ljava/util/List;

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5c

    iget-object v0, p0, Lc5;->j:Ljava/util/List;

    iget-object v1, p1, Lc5;->j:Ljava/util/List;

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5c

    iget-object v0, p0, Lc5;->g:Ljava/net/ProxySelector;

    iget-object v1, p1, Lc5;->g:Ljava/net/ProxySelector;

    invoke-static {v0, v1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5c

    iget-object v0, p0, Lc5;->c:Ljavax/net/ssl/SSLSocketFactory;

    iget-object v1, p1, Lc5;->c:Ljavax/net/ssl/SSLSocketFactory;

    invoke-static {v0, v1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5c

    iget-object v0, p0, Lc5;->d:Ljavax/net/ssl/HostnameVerifier;

    iget-object v1, p1, Lc5;->d:Ljavax/net/ssl/HostnameVerifier;

    invoke-static {v0, v1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5c

    iget-object v0, p0, Lc5;->e:Lxn;

    iget-object v1, p1, Lc5;->e:Lxn;

    invoke-static {v0, v1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5c

    iget-object p0, p0, Lc5;->h:Lop0;

    iget p0, p0, Lop0;->e:I

    iget-object p1, p1, Lc5;->h:Lop0;

    iget p1, p1, Lop0;->e:I

    if-ne p0, p1, :cond_5c

    const/4 p0, 0x1

    return p0

    :cond_5c
    const/4 p0, 0x0

    return p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    .prologue
    instance-of v0, p1, Lc5;

    if-eqz v0, :cond_18

    check-cast p1, Lc5;

    iget-object v0, p1, Lc5;->h:Lop0;

    iget-object v1, p0, Lc5;->h:Lop0;

    invoke-virtual {v1, v0}, Lop0;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_18

    invoke-virtual {p0, p1}, Lc5;->a(Lc5;)Z

    move-result p0

    if-eqz p0, :cond_18

    const/4 p0, 0x1

    return p0

    :cond_18
    const/4 p0, 0x0

    return p0
.end method

.method public final hashCode()I
    .registers 4

    iget-object v0, p0, Lc5;->h:Lop0;

    iget-object v0, v0, Lop0;->h:Ljava/lang/String;

    const/16 v1, 0x20f

    const/16 v2, 0x1f

    invoke-static {v1, v2, v0}, Ly41;->j(IILjava/lang/String;)I

    move-result v0

    iget-object v1, p0, Lc5;->a:Lvp1;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    mul-int/2addr v1, v2

    iget-object v0, p0, Lc5;->f:Lp80;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    add-int/2addr v0, v1

    mul-int/2addr v0, v2

    iget-object v1, p0, Lc5;->i:Ljava/util/List;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    mul-int/2addr v1, v2

    iget-object v0, p0, Lc5;->j:Ljava/util/List;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    add-int/2addr v0, v1

    mul-int/2addr v0, v2

    iget-object v1, p0, Lc5;->g:Ljava/net/ProxySelector;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    mul-int/lit16 v1, v1, 0x3c1

    iget-object v0, p0, Lc5;->c:Ljavax/net/ssl/SSLSocketFactory;

    invoke-static {v0}, Ljava/util/Objects;->hashCode(Ljava/lang/Object;)I

    move-result v0

    add-int/2addr v0, v1

    mul-int/2addr v0, v2

    iget-object v1, p0, Lc5;->d:Ljavax/net/ssl/HostnameVerifier;

    invoke-static {v1}, Ljava/util/Objects;->hashCode(Ljava/lang/Object;)I

    move-result v1

    add-int/2addr v1, v0

    mul-int/2addr v1, v2

    iget-object p0, p0, Lc5;->e:Lxn;

    invoke-static {p0}, Ljava/util/Objects;->hashCode(Ljava/lang/Object;)I

    move-result p0

    add-int/2addr p0, v1

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 4

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Address{"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lc5;->h:Lop0;

    iget-object v2, v1, Lop0;->d:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v2, 0x3a

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    iget v1, v1, Lop0;->e:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, "proxySelector="

    iget-object p0, p0, Lc5;->g:Ljava/net/ProxySelector;

    invoke-static {p0, v1}, Lgt0;->C0(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 p0, 0x7d

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
