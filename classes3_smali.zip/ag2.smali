.class public final Lag2;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ljy0;


# static fields
.field public static final a:Lag2;

.field public static final b:Lmr0;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lag2;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lag2;->a:Lag2;

    const-string v0, "kotlin.ULong"

    sget-object v1, Lv41;->a:Lv41;

    invoke-static {v1, v0}, Lgt0;->G(Ljy0;Ljava/lang/String;)Lmr0;

    move-result-object v0

    sput-object v0, Lag2;->b:Lmr0;

    return-void
.end method


# virtual methods
.method public final deserialize(Lj10;)Ljava/lang/Object;
    .registers 3

    sget-object p0, Lag2;->b:Lmr0;

    invoke-interface {p1, p0}, Lj10;->q(Lm02;)Lj10;

    move-result-object p0

    invoke-interface {p0}, Lj10;->v()J

    move-result-wide p0

    new-instance v0, Lwf2;

    invoke-direct {v0, p0, p1}, Lwf2;-><init>(J)V

    return-object v0
.end method

.method public final getDescriptor()Lm02;
    .registers 1

    sget-object p0, Lag2;->b:Lmr0;

    return-object p0
.end method

.method public final serialize(Lga0;Ljava/lang/Object;)V
    .registers 5

    check-cast p2, Lwf2;

    iget-wide v0, p2, Lwf2;->a:J

    sget-object p0, Lag2;->b:Lmr0;

    invoke-interface {p1, p0}, Lga0;->m(Lm02;)Lga0;

    move-result-object p0

    invoke-interface {p0, v0, v1}, Lga0;->B(J)V

    return-void
.end method
