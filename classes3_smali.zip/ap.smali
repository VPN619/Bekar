.class public final Lap;
.super Lnm1;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public a:[C

.field public b:I


# virtual methods
.method public final a()Ljava/lang/Object;
    .registers 2

    iget-object v0, p0, Lap;->a:[C

    iget p0, p0, Lap;->b:I

    invoke-static {v0, p0}, Ljava/util/Arrays;->copyOf([CI)[C

    move-result-object p0

    return-object p0
.end method

.method public final b(I)V
    .registers 4

    .prologue
    iget-object v0, p0, Lap;->a:[C

    array-length v1, v0

    if-ge v1, p1, :cond_11

    array-length v1, v0

    mul-int/lit8 v1, v1, 0x2

    if-ge p1, v1, :cond_b

    move p1, v1

    :cond_b
    invoke-static {v0, p1}, Ljava/util/Arrays;->copyOf([CI)[C

    move-result-object p1

    iput-object p1, p0, Lap;->a:[C

    :cond_11
    return-void
.end method

.method public final d()I
    .registers 1

    iget p0, p0, Lap;->b:I

    return p0
.end method
