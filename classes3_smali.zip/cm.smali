.class public final Lcm;
.super Lih0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final synthetic b:Ldm;


# direct methods
.method public constructor <init>(Lr42;Ldm;)V
    .registers 3

    iput-object p2, p0, Lcm;->b:Ldm;

    invoke-direct {p0, p1}, Lih0;-><init>(Lr42;)V

    return-void
.end method


# virtual methods
.method public final close()V
    .registers 2

    iget-object v0, p0, Lcm;->b:Ldm;

    iget-object v0, v0, Ldm;->d:La50;

    invoke-virtual {v0}, La50;->close()V

    invoke-super {p0}, Lih0;->close()V

    return-void
.end method
