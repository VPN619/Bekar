.class public abstract Lan0;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final a:Ljava/lang/String;

.field public static final b:Ljava/security/MessageDigest;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .prologue
    const-class v0, Ltz;

    invoke-virtual {v0}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lan0;->a:Ljava/lang/String;

    :try_start_8
    const-string v0, "MD5"

    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v0
    :try_end_e
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_8 .. :try_end_e} :catch_f

    goto :goto_1d

    :catch_f
    move-exception v0

    sget-object v1, Lan0;->a:Ljava/lang/String;

    const/4 v2, 0x3

    invoke-static {v1, v2}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v2

    if-eqz v2, :cond_1c

    const-string v2, "Error while instantiating messageDigest"

    nop

    :cond_1c
    const/4 v0, 0x0

    :goto_1d
    sput-object v0, Lan0;->b:Ljava/security/MessageDigest;

    return-void
.end method
