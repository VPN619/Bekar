.class public final Lb72;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ljy0;


# static fields
.field public static final a:Lb72;

.field public static final b:Lwm1;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    new-instance v0, Lb72;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lb72;->a:Lb72;

    new-instance v0, Lwm1;

    const-string v1, "kotlin.String"

    sget-object v2, Lsm1;->C:Lsm1;

    invoke-direct {v0, v1, v2}, Lwm1;-><init>(Ljava/lang/String;Lsm1;)V

    sput-object v0, Lb72;->b:Lwm1;

    return-void
.end method


# virtual methods
.method public final deserialize(Lj10;)Ljava/lang/Object;
    .registers 2

    invoke-interface {p1}, Lj10;->t()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public final getDescriptor()Lm02;
    .registers 1

    sget-object p0, Lb72;->b:Lwm1;

    return-object p0
.end method

.method public final serialize(Lga0;Ljava/lang/Object;)V
    .registers 3

    check-cast p2, Ljava/lang/String;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {p1, p2}, Lga0;->D(Ljava/lang/String;)V

    return-void
.end method
