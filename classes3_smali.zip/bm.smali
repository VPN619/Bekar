.class public final Lbm;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lmp;


# static fields
.field public static final b:[I


# instance fields
.field public a:I


# direct methods
.method static constructor <clinit>()V
    .registers 5

    .prologue
    const/16 v0, 0x100

    new-array v1, v0, [I

    sput-object v1, Lbm;->b:[I

    const/4 v1, 0x0

    :goto_7
    if-ge v1, v0, :cond_25

    const/16 v2, 0x8

    move v3, v1

    :goto_c
    add-int/lit8 v2, v2, -0x1

    if-ltz v2, :cond_1e

    and-int/lit8 v4, v3, 0x1

    if-eqz v4, :cond_1b

    ushr-int/lit8 v3, v3, 0x1

    const v4, -0x12477ce0

    xor-int/2addr v3, v4

    goto :goto_c

    :cond_1b
    ushr-int/lit8 v3, v3, 0x1

    goto :goto_c

    :cond_1e
    sget-object v2, Lbm;->b:[I

    aput v3, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_7

    :cond_25
    return-void
.end method

.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput v0, p0, Lbm;->a:I

    return-void
.end method


# virtual methods
.method public final a(J)V
    .registers 5

    const-wide v0, 0xffffffffL

    and-long/2addr p1, v0

    long-to-int p1, p1

    iput p1, p0, Lbm;->a:I

    return-void
.end method

.method public final getValue()J
    .registers 5

    iget p0, p0, Lbm;->a:I

    int-to-long v0, p0

    const-wide v2, 0xffffffffL

    and-long/2addr v0, v2

    return-wide v0
.end method

.method public final reset()V
    .registers 2

    const/4 v0, 0x0

    iput v0, p0, Lbm;->a:I

    return-void
.end method

.method public final update([BII)V
    .registers 7

    .prologue
    iget v0, p0, Lbm;->a:I

    not-int v0, v0

    :goto_3
    add-int/lit8 p3, p3, -0x1

    if-ltz p3, :cond_17

    add-int/lit8 v1, p2, 0x1

    aget-byte p2, p1, p2

    xor-int/2addr p2, v0

    and-int/lit16 p2, p2, 0xff

    sget-object v2, Lbm;->b:[I

    aget p2, v2, p2

    ushr-int/lit8 v0, v0, 0x8

    xor-int/2addr v0, p2

    move p2, v1

    goto :goto_3

    :cond_17
    not-int p1, v0

    iput p1, p0, Lbm;->a:I

    return-void
.end method
