.class public final Lbq;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final b:Lp80;

.field public static final c:Laq;

.field public static final d:Ljava/util/LinkedHashMap;

.field public static final e:Lbq;

.field public static final f:Lbq;

.field public static final g:Lbq;

.field public static final h:Lbq;

.field public static final i:Lbq;

.field public static final j:Lbq;

.field public static final k:Lbq;

.field public static final l:Lbq;

.field public static final m:Lbq;

.field public static final n:Lbq;

.field public static final o:Lbq;

.field public static final p:Lbq;

.field public static final q:Lbq;

.field public static final r:Lbq;

.field public static final s:Lbq;

.field public static final t:Lbq;


# instance fields
.field public final a:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lp80;

    const/16 v1, 0x14

    invoke-direct {v0, v1}, Lp80;-><init>(I)V

    sput-object v0, Lbq;->b:Lp80;

    new-instance v0, Laq;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Laq;-><init>(I)V

    sput-object v0, Lbq;->c:Laq;

    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    sput-object v0, Lbq;->d:Ljava/util/LinkedHashMap;

    const-string v0, "SSL_RSA_WITH_NULL_MD5"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "SSL_RSA_WITH_NULL_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "SSL_RSA_EXPORT_WITH_RC4_40_MD5"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "SSL_RSA_WITH_RC4_128_MD5"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "SSL_RSA_WITH_RC4_128_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "SSL_RSA_EXPORT_WITH_DES40_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "SSL_RSA_WITH_DES_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "SSL_RSA_WITH_3DES_EDE_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    move-result-object v0

    sput-object v0, Lbq;->e:Lbq;

    const-string v0, "SSL_DHE_DSS_EXPORT_WITH_DES40_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "SSL_DHE_DSS_WITH_DES_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "SSL_DHE_DSS_WITH_3DES_EDE_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "SSL_DHE_RSA_EXPORT_WITH_DES40_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "SSL_DHE_RSA_WITH_DES_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "SSL_DHE_RSA_WITH_3DES_EDE_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "SSL_DH_anon_EXPORT_WITH_RC4_40_MD5"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "SSL_DH_anon_WITH_RC4_128_MD5"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "SSL_DH_anon_EXPORT_WITH_DES40_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "SSL_DH_anon_WITH_DES_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "SSL_DH_anon_WITH_3DES_EDE_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_KRB5_WITH_DES_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_KRB5_WITH_3DES_EDE_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_KRB5_WITH_RC4_128_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_KRB5_WITH_DES_CBC_MD5"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_KRB5_WITH_3DES_EDE_CBC_MD5"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_KRB5_WITH_RC4_128_MD5"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_KRB5_EXPORT_WITH_DES_CBC_40_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_KRB5_EXPORT_WITH_RC4_40_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_KRB5_EXPORT_WITH_DES_CBC_40_MD5"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_KRB5_EXPORT_WITH_RC4_40_MD5"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_RSA_WITH_AES_128_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    move-result-object v0

    sput-object v0, Lbq;->f:Lbq;

    const-string v0, "TLS_DHE_DSS_WITH_AES_128_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_DHE_RSA_WITH_AES_128_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_DH_anon_WITH_AES_128_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_RSA_WITH_AES_256_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    move-result-object v0

    sput-object v0, Lbq;->g:Lbq;

    const-string v0, "TLS_DHE_DSS_WITH_AES_256_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_DHE_RSA_WITH_AES_256_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_DH_anon_WITH_AES_256_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_RSA_WITH_NULL_SHA256"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_RSA_WITH_AES_128_CBC_SHA256"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_RSA_WITH_AES_256_CBC_SHA256"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_DHE_DSS_WITH_AES_128_CBC_SHA256"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_RSA_WITH_CAMELLIA_128_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_DHE_DSS_WITH_CAMELLIA_128_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_DHE_RSA_WITH_CAMELLIA_128_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_DHE_RSA_WITH_AES_128_CBC_SHA256"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_DHE_DSS_WITH_AES_256_CBC_SHA256"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_DHE_RSA_WITH_AES_256_CBC_SHA256"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_DH_anon_WITH_AES_128_CBC_SHA256"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_DH_anon_WITH_AES_256_CBC_SHA256"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_RSA_WITH_CAMELLIA_256_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_DHE_DSS_WITH_CAMELLIA_256_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_DHE_RSA_WITH_CAMELLIA_256_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_PSK_WITH_RC4_128_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_PSK_WITH_3DES_EDE_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_PSK_WITH_AES_128_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_PSK_WITH_AES_256_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_RSA_WITH_SEED_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_RSA_WITH_AES_128_GCM_SHA256"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    move-result-object v0

    sput-object v0, Lbq;->h:Lbq;

    const-string v0, "TLS_RSA_WITH_AES_256_GCM_SHA384"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    move-result-object v0

    sput-object v0, Lbq;->i:Lbq;

    const-string v0, "TLS_DHE_RSA_WITH_AES_128_GCM_SHA256"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_DHE_RSA_WITH_AES_256_GCM_SHA384"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_DHE_DSS_WITH_AES_128_GCM_SHA256"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_DHE_DSS_WITH_AES_256_GCM_SHA384"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_DH_anon_WITH_AES_128_GCM_SHA256"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_DH_anon_WITH_AES_256_GCM_SHA384"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_EMPTY_RENEGOTIATION_INFO_SCSV"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_FALLBACK_SCSV"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDH_ECDSA_WITH_NULL_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDH_ECDSA_WITH_RC4_128_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDH_ECDSA_WITH_3DES_EDE_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDHE_ECDSA_WITH_NULL_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDHE_ECDSA_WITH_RC4_128_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDHE_ECDSA_WITH_3DES_EDE_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDH_RSA_WITH_NULL_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDH_RSA_WITH_RC4_128_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDH_RSA_WITH_3DES_EDE_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDH_RSA_WITH_AES_128_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDH_RSA_WITH_AES_256_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDHE_RSA_WITH_NULL_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDHE_RSA_WITH_RC4_128_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDHE_RSA_WITH_3DES_EDE_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    move-result-object v0

    sput-object v0, Lbq;->j:Lbq;

    const-string v0, "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    move-result-object v0

    sput-object v0, Lbq;->k:Lbq;

    const-string v0, "TLS_ECDH_anon_WITH_NULL_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDH_anon_WITH_RC4_128_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDH_anon_WITH_3DES_EDE_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDH_anon_WITH_AES_128_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDH_anon_WITH_AES_256_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDH_ECDSA_WITH_AES_128_CBC_SHA256"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDH_ECDSA_WITH_AES_256_CBC_SHA384"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDH_RSA_WITH_AES_128_CBC_SHA256"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDH_RSA_WITH_AES_256_CBC_SHA384"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    move-result-object v0

    sput-object v0, Lbq;->l:Lbq;

    const-string v0, "TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    move-result-object v0

    sput-object v0, Lbq;->m:Lbq;

    const-string v0, "TLS_ECDH_ECDSA_WITH_AES_128_GCM_SHA256"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDH_ECDSA_WITH_AES_256_GCM_SHA384"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    move-result-object v0

    sput-object v0, Lbq;->n:Lbq;

    const-string v0, "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    move-result-object v0

    sput-object v0, Lbq;->o:Lbq;

    const-string v0, "TLS_ECDH_RSA_WITH_AES_128_GCM_SHA256"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDH_RSA_WITH_AES_256_GCM_SHA384"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDHE_PSK_WITH_AES_128_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDHE_PSK_WITH_AES_256_CBC_SHA"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    move-result-object v0

    sput-object v0, Lbq;->p:Lbq;

    const-string v0, "TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    move-result-object v0

    sput-object v0, Lbq;->q:Lbq;

    const-string v0, "TLS_DHE_RSA_WITH_CHACHA20_POLY1305_SHA256"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_ECDHE_PSK_WITH_CHACHA20_POLY1305_SHA256"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_AES_128_GCM_SHA256"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    move-result-object v0

    sput-object v0, Lbq;->r:Lbq;

    const-string v0, "TLS_AES_256_GCM_SHA384"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    move-result-object v0

    sput-object v0, Lbq;->s:Lbq;

    const-string v0, "TLS_CHACHA20_POLY1305_SHA256"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    move-result-object v0

    sput-object v0, Lbq;->t:Lbq;

    const-string v0, "TLS_AES_128_CCM_SHA256"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    const-string v0, "TLS_AES_128_CCM_8_SHA256"

    invoke-static {v0}, Lp80;->o(Ljava/lang/String;)Lbq;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lbq;->a:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lbq;->a:Ljava/lang/String;

    return-object p0
.end method
