.class public final Lbh;
.super Liv0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final synthetic h:J


# instance fields
.field private volatile synthetic _disposer$volatile:Ljava/lang/Object;

.field public final e:Ljn;

.field public f:Lk50;

.field public final synthetic g:Ldh;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    sget-object v0, Lbf;->a:Lsun/misc/Unsafe;

    const-class v1, Lbh;

    const-string v2, "_disposer$volatile"

    invoke-virtual {v1, v2}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v1

    invoke-virtual {v0, v1}, Lsun/misc/Unsafe;->objectFieldOffset(Ljava/lang/reflect/Field;)J

    move-result-wide v0

    sput-wide v0, Lbh;->h:J

    return-void
.end method

.method public constructor <init>(Ldh;Ljn;)V
    .registers 3

    iput-object p1, p0, Lbh;->g:Ldh;

    invoke-direct {p0}, Ly31;-><init>()V

    iput-object p2, p0, Lbh;->e:Ljn;

    return-void
.end method


# virtual methods
.method public final l()Z
    .registers 1

    const/4 p0, 0x0

    return p0
.end method

.method public final m(Ljava/lang/Throwable;)V
    .registers 6

    .prologue
    const/4 v0, 0x0

    iget-object v1, p0, Lbh;->e:Ljn;

    if-eqz p1, :cond_24

    new-instance v2, Let;

    invoke-direct {v2, p1, v0}, Let;-><init>(Ljava/lang/Throwable;Z)V

    const/4 p1, 0x0

    invoke-virtual {v1, v2, p1}, Ljn;->E(Ljava/lang/Object;Lrk0;)Lq5;

    move-result-object p1

    if-eqz p1, :cond_48

    invoke-virtual {v1, p1}, Ljn;->m(Ljava/lang/Object;)V

    sget-object p1, Lbf;->a:Lsun/misc/Unsafe;

    sget-wide v0, Lbh;->h:J

    invoke-virtual {p1, p0, v0, v1}, Lsun/misc/Unsafe;->getObjectVolatile(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lch;

    if-eqz p0, :cond_48

    invoke-virtual {p0}, Lch;->a()V

    return-void

    :cond_24
    sget-object p1, Ldh;->b:Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;

    iget-object p0, p0, Lbh;->g:Ldh;

    invoke-virtual {p1, p0}, Ljava/util/concurrent/atomic/AtomicIntegerFieldUpdater;->decrementAndGet(Ljava/lang/Object;)I

    move-result p1

    if-nez p1, :cond_48

    iget-object p0, p0, Ldh;->a:[Lu20;

    new-instance p1, Ljava/util/ArrayList;

    array-length v2, p0

    invoke-direct {p1, v2}, Ljava/util/ArrayList;-><init>(I)V

    array-length v2, p0

    :goto_37
    if-ge v0, v2, :cond_45

    aget-object v3, p0, v0

    invoke-interface {v3}, Lu20;->k()Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {p1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v0, v0, 0x1

    goto :goto_37

    :cond_45
    invoke-virtual {v1, p1}, Ljn;->resumeWith(Ljava/lang/Object;)V

    :cond_48
    return-void
.end method
