.class public abstract Lbo1;
.super Lsm;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Liy0;


# instance fields
.field public final g:Z


# direct methods
.method public constructor <init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V
    .registers 14

    .prologue
    const/4 v0, 0x1

    and-int/2addr p5, v0

    const/4 v1, 0x0

    if-ne p5, v0, :cond_c

    move v7, v0

    :goto_6
    move-object v2, p0

    move-object v3, p1

    move-object v4, p2

    move-object v5, p3

    move-object v6, p4

    goto :goto_e

    :cond_c
    move v7, v1

    goto :goto_6

    :goto_e
    invoke-direct/range {v2 .. v7}, Lsm;-><init>(Ljava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;Z)V

    iput-boolean v1, v2, Lbo1;->g:Z

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    .prologue
    if-ne p1, p0, :cond_3

    goto :goto_35

    :cond_3
    instance-of v0, p1, Lbo1;

    if-eqz v0, :cond_37

    check-cast p1, Lbo1;

    invoke-virtual {p0}, Lsm;->g()Ljq;

    move-result-object v0

    invoke-virtual {p1}, Lsm;->g()Ljq;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_44

    iget-object v0, p0, Lsm;->d:Ljava/lang/String;

    iget-object v1, p1, Lsm;->d:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_44

    iget-object v0, p0, Lsm;->e:Ljava/lang/String;

    iget-object v1, p1, Lsm;->e:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_44

    iget-object p0, p0, Lsm;->b:Ljava/lang/Object;

    iget-object p1, p1, Lsm;->b:Ljava/lang/Object;

    invoke-static {p0, p1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_44

    :goto_35
    const/4 p0, 0x1

    return p0

    :cond_37
    instance-of v0, p1, Liy0;

    if-eqz v0, :cond_44

    invoke-virtual {p0}, Lbo1;->h()Lfy0;

    move-result-object p0

    invoke-virtual {p1, p0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    return p0

    :cond_44
    const/4 p0, 0x0

    return p0
.end method

.method public final h()Lfy0;
    .registers 2

    .prologue
    iget-boolean v0, p0, Lbo1;->g:Z

    if-eqz v0, :cond_5

    return-object p0

    :cond_5
    iget-object v0, p0, Lsm;->a:Lfy0;

    if-nez v0, :cond_f

    invoke-virtual {p0}, Lsm;->d()Lfy0;

    move-result-object v0

    iput-object v0, p0, Lsm;->a:Lfy0;

    :cond_f
    return-object v0
.end method

.method public final hashCode()I
    .registers 4

    invoke-virtual {p0}, Lsm;->g()Ljq;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const/16 v1, 0x1f

    mul-int/2addr v0, v1

    iget-object v2, p0, Lsm;->d:Ljava/lang/String;

    invoke-static {v0, v1, v2}, Ly41;->j(IILjava/lang/String;)I

    move-result v0

    iget-object p0, p0, Lsm;->e:Ljava/lang/String;

    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result p0

    add-int/2addr p0, v0

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    .prologue
    invoke-virtual {p0}, Lbo1;->h()Lfy0;

    move-result-object v0

    if-eq v0, p0, :cond_b

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_b
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "property "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object p0, p0, Lsm;->d:Ljava/lang/String;

    const-string v1, " (Kotlin reflection is not available)"

    invoke-static {v0, p0, v1}, Ly41;->s(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
