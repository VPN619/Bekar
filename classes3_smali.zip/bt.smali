.class public final Lbt;
.super Lnv0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lat;


# direct methods
.method public constructor <init>()V
    .registers 2

    const/4 v0, 0x1

    invoke-direct {p0, v0}, Lnv0;-><init>(Z)V

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Lnv0;->J(Lfv0;)V

    return-void
.end method
