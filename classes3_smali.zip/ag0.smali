.class public final Lag0;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public synthetic t:I


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 4

    new-instance p0, Lag0;

    const/4 v0, 0x2

    invoke-direct {p0, v0, p1}, Lm82;-><init>(ILvx;)V

    check-cast p2, Ljava/lang/Number;

    invoke-virtual {p2}, Ljava/lang/Number;->intValue()I

    move-result p1

    iput p1, p0, Lag0;->t:I

    return-object p0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Ljava/lang/Number;

    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    move-result p1

    check-cast p2, Lvx;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    invoke-virtual {p0, p2, p1}, Lag0;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lag0;

    sget-object p1, Lrg2;->a:Lrg2;

    invoke-virtual {p0, p1}, Lag0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .prologue
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget p0, p0, Lag0;->t:I

    if-lez p0, :cond_9

    const/4 p0, 0x1

    goto :goto_a

    :cond_9
    const/4 p0, 0x0

    :goto_a
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0
.end method
