.class public abstract Lai;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lvx;
.implements Lxy;
.implements Ljava/io/Serializable;


# instance fields
.field private final completion:Lvx;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lvx;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>(Lvx;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lai;->completion:Lvx;

    return-void
.end method


# virtual methods
.method public create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 3

    new-instance p0, Ljava/lang/UnsupportedOperationException;

    const-string p1, "create(Any?;Continuation) has not been overridden"

    invoke-direct {p0, p1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public getCallerFrame()Lxy;
    .registers 2

    .prologue
    iget-object p0, p0, Lai;->completion:Lvx;

    instance-of v0, p0, Lxy;

    if-eqz v0, :cond_9

    check-cast p0, Lxy;

    return-object p0

    :cond_9
    const/4 p0, 0x0

    return-object p0
.end method

.method public final getCompletion()Lvx;
    .registers 1
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lvx;"
        }
    .end annotation

    iget-object p0, p0, Lai;->completion:Lvx;

    return-object p0
.end method

.method public getStackTraceElement()Ljava/lang/StackTraceElement;
    .registers 9

    .prologue
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const-class v1, Lh10;

    invoke-virtual {v0, v1}, Ljava/lang/Class;->getAnnotation(Ljava/lang/Class;)Ljava/lang/annotation/Annotation;

    move-result-object v0

    check-cast v0, Lh10;

    const/4 v1, 0x0

    if-nez v0, :cond_10

    goto :goto_17

    :cond_10
    invoke-interface {v0}, Lh10;->v()I

    move-result v2

    const/4 v3, 0x1

    if-ge v2, v3, :cond_18

    :goto_17
    return-object v1

    :cond_18
    const/4 v2, -0x1

    :try_start_19
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v4

    const-string v5, "label"

    invoke-virtual {v4, v5}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    invoke-virtual {v4, p0}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    instance-of v5, v4, Ljava/lang/Integer;

    if-eqz v5, :cond_31

    check-cast v4, Ljava/lang/Integer;

    goto :goto_32

    :cond_31
    move-object v4, v1

    :goto_32
    if-eqz v4, :cond_39

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v4
    :try_end_38
    .catch Ljava/lang/Exception; {:try_start_19 .. :try_end_38} :catch_3c

    goto :goto_3a

    :cond_39
    const/4 v4, 0x0

    :goto_3a
    sub-int/2addr v4, v3

    goto :goto_3d

    :catch_3c
    move v4, v2

    :goto_3d
    if-gez v4, :cond_40

    goto :goto_46

    :cond_40
    invoke-interface {v0}, Lh10;->l()[I

    move-result-object v2

    aget v2, v2, v4

    :goto_46
    sget-object v3, Lsz;->h:Ler;

    sget-object v4, Lsz;->i:Ler;

    if-nez v4, :cond_88

    :try_start_4c
    const-class v4, Ljava/lang/Class;

    const-string v5, "getModule"

    invoke-virtual {v4, v5, v1}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v4

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v5

    const-string v6, "java.lang.Module"

    invoke-virtual {v5, v6}, Ljava/lang/ClassLoader;->loadClass(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v5

    const-string v6, "getDescriptor"

    invoke-virtual {v5, v6, v1}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v5

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v6

    const-string v7, "java.lang.module.ModuleDescriptor"

    invoke-virtual {v6, v7}, Ljava/lang/ClassLoader;->loadClass(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v6

    const-string v7, "name"

    invoke-virtual {v6, v7, v1}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v6

    new-instance v7, Ler;

    invoke-direct {v7, v4, v5, v6}, Ler;-><init>(Ljava/lang/reflect/Method;Ljava/lang/reflect/Method;Ljava/lang/reflect/Method;)V

    sput-object v7, Lsz;->i:Ler;
    :try_end_83
    .catch Ljava/lang/Exception; {:try_start_4c .. :try_end_83} :catch_85

    move-object v4, v7

    goto :goto_88

    :catch_85
    sput-object v3, Lsz;->i:Ler;

    move-object v4, v3

    :cond_88
    :goto_88
    if-ne v4, v3, :cond_8b

    goto :goto_b6

    :cond_8b
    iget-object v3, v4, Ler;->a:Ljava/lang/reflect/Method;

    if-eqz v3, :cond_b6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    invoke-virtual {v3, p0, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    if-nez p0, :cond_9a

    goto :goto_b6

    :cond_9a
    iget-object v3, v4, Ler;->b:Ljava/lang/reflect/Method;

    if-eqz v3, :cond_b6

    invoke-virtual {v3, p0, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    if-nez p0, :cond_a5

    goto :goto_b6

    :cond_a5
    iget-object v3, v4, Ler;->c:Ljava/lang/reflect/Method;

    if-eqz v3, :cond_ae

    invoke-virtual {v3, p0, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    goto :goto_af

    :cond_ae
    move-object p0, v1

    :goto_af
    instance-of v3, p0, Ljava/lang/String;

    if-eqz v3, :cond_b6

    move-object v1, p0

    check-cast v1, Ljava/lang/String;

    :cond_b6
    :goto_b6
    if-nez v1, :cond_bd

    invoke-interface {v0}, Lh10;->c()Ljava/lang/String;

    move-result-object p0

    goto :goto_d2

    :cond_bd
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v1, 0x2f

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-interface {v0}, Lh10;->c()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    :goto_d2
    new-instance v1, Ljava/lang/StackTraceElement;

    invoke-interface {v0}, Lh10;->m()Ljava/lang/String;

    move-result-object v3

    invoke-interface {v0}, Lh10;->f()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, p0, v3, v0, v2}, Ljava/lang/StackTraceElement;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V

    return-object v1
.end method

.method public abstract invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
.end method

.method public releaseIntercepted()V
    .registers 1

    return-void
.end method

.method public final resumeWith(Ljava/lang/Object;)V
    .registers 4

    .prologue
    :goto_0
    check-cast p0, Lai;

    iget-object v0, p0, Lai;->completion:Lvx;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_7
    invoke-virtual {p0, p1}, Lai;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    sget-object v1, Lwy;->a:Lwy;
    :try_end_d
    .catchall {:try_start_7 .. :try_end_d} :catchall_10

    if-ne p1, v1, :cond_17

    return-void

    :catchall_10
    move-exception p1

    new-instance v1, Lpu1;

    invoke-direct {v1, p1}, Lpu1;-><init>(Ljava/lang/Throwable;)V

    move-object p1, v1

    :cond_17
    invoke-virtual {p0}, Lai;->releaseIntercepted()V

    instance-of p0, v0, Lai;

    if-eqz p0, :cond_20

    move-object p0, v0

    goto :goto_0

    :cond_20
    invoke-interface {v0, p1}, Lvx;->resumeWith(Ljava/lang/Object;)V

    return-void
.end method

.method public toString()Ljava/lang/String;
    .registers 3

    .prologue
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Continuation at "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Lai;->getStackTraceElement()Ljava/lang/StackTraceElement;

    move-result-object v1

    if-nez v1, :cond_15

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    :cond_15
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
