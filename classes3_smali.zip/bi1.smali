.class public final synthetic Lbi1;
.super Lzk0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lrk0;


# static fields
.field public static final h:Lbi1;


# direct methods
.method static constructor <clinit>()V
    .registers 6

    new-instance v0, Lbi1;

    const-string v4, "register(Lkotlinx/coroutines/selects/SelectInstance;Ljava/lang/Object;)V"

    const/4 v5, 0x0

    const/4 v1, 0x3

    const-class v2, Lci1;

    const-string v3, "register"

    invoke-direct/range {v0 .. v5}, Lzk0;-><init>(ILjava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    sput-object v0, Lbi1;->h:Lbi1;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 8

    .prologue
    check-cast p1, Lci1;

    check-cast p2, Lqz1;

    iget-wide v0, p1, Lci1;->a:J

    const-wide/16 v2, 0x0

    cmp-long p0, v0, v2

    sget-object p3, Lrg2;->a:Lrg2;

    if-gtz p0, :cond_11

    iput-object p3, p2, Lqz1;->e:Ljava/lang/Object;

    return-object p3

    :cond_11
    new-instance p0, Lcl0;

    const/16 v2, 0xb

    invoke-direct {p0, v2, p2, p1}, Lcl0;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p1, p2, Lqz1;->a:Lly;

    invoke-static {p1}, Lsz;->z(Lly;)Lb30;

    move-result-object v2

    invoke-interface {v2, v0, v1, p0, p1}, Lb30;->p(JLjava/lang/Runnable;Lly;)Lk50;

    move-result-object p0

    iput-object p0, p2, Lqz1;->c:Ljava/lang/Object;

    return-object p3
.end method
