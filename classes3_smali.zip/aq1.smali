.class public final Laq1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lgl;


# instance fields
.field public final a:Ld42;

.field public final b:Lvk;

.field public c:Z


# direct methods
.method public constructor <init>(Ld42;)V
    .registers 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Laq1;->a:Ld42;

    new-instance p1, Lvk;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Laq1;->b:Lvk;

    return-void
.end method


# virtual methods
.method public final D(Lxl;)Lgl;
    .registers 3

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-boolean v0, p0, Laq1;->c:Z

    if-nez v0, :cond_10

    iget-object v0, p0, Laq1;->b:Lvk;

    invoke-virtual {v0, p1}, Lvk;->T(Lxl;)V

    invoke-virtual {p0}, Laq1;->k()Lgl;

    return-object p0

    :cond_10
    const-string p0, "closed"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public final G(J)Lgl;
    .registers 4

    .prologue
    iget-boolean v0, p0, Laq1;->c:Z

    if-nez v0, :cond_d

    iget-object v0, p0, Laq1;->b:Lvk;

    invoke-virtual {v0, p1, p2}, Lvk;->V(J)V

    invoke-virtual {p0}, Laq1;->k()Lgl;

    return-object p0

    :cond_d
    const-string p0, "closed"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public final close()V
    .registers 7

    .prologue
    iget-object v0, p0, Laq1;->a:Ld42;

    iget-boolean v1, p0, Laq1;->c:Z

    if-nez v1, :cond_26

    :try_start_6
    iget-object v1, p0, Laq1;->b:Lvk;

    iget-wide v2, v1, Lvk;->b:J

    const-wide/16 v4, 0x0

    cmp-long v4, v2, v4

    if-lez v4, :cond_16

    invoke-interface {v0, v1, v2, v3}, Ld42;->r(Lvk;J)V
    :try_end_13
    .catchall {:try_start_6 .. :try_end_13} :catchall_14

    goto :goto_16

    :catchall_14
    move-exception v1

    goto :goto_17

    :cond_16
    :goto_16
    const/4 v1, 0x0

    :goto_17
    :try_start_17
    invoke-interface {v0}, Ld42;->close()V
    :try_end_1a
    .catchall {:try_start_17 .. :try_end_1a} :catchall_1b

    goto :goto_1f

    :catchall_1b
    move-exception v0

    if-nez v1, :cond_1f

    move-object v1, v0

    :cond_1f
    :goto_1f
    const/4 v0, 0x1

    iput-boolean v0, p0, Laq1;->c:Z

    if-nez v1, :cond_25

    goto :goto_26

    :cond_25
    throw v1

    :cond_26
    :goto_26
    return-void
.end method

.method public final flush()V
    .registers 6

    .prologue
    iget-boolean v0, p0, Laq1;->c:Z

    if-nez v0, :cond_17

    iget-object v0, p0, Laq1;->b:Lvk;

    iget-wide v1, v0, Lvk;->b:J

    const-wide/16 v3, 0x0

    cmp-long v3, v1, v3

    iget-object p0, p0, Laq1;->a:Ld42;

    if-lez v3, :cond_13

    invoke-interface {p0, v0, v1, v2}, Ld42;->r(Lvk;J)V

    :cond_13
    invoke-interface {p0}, Ld42;->flush()V

    return-void

    :cond_17
    const-string p0, "closed"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-void
.end method

.method public final isOpen()Z
    .registers 1

    iget-boolean p0, p0, Laq1;->c:Z

    xor-int/lit8 p0, p0, 0x1

    return p0
.end method

.method public final k()Lgl;
    .registers 6

    .prologue
    iget-boolean v0, p0, Laq1;->c:Z

    if-nez v0, :cond_16

    iget-object v0, p0, Laq1;->b:Lvk;

    invoke-virtual {v0}, Lvk;->k()J

    move-result-wide v1

    const-wide/16 v3, 0x0

    cmp-long v3, v1, v3

    if-lez v3, :cond_15

    iget-object v3, p0, Laq1;->a:Ld42;

    invoke-interface {v3, v0, v1, v2}, Ld42;->r(Lvk;J)V

    :cond_15
    return-object p0

    :cond_16
    const-string p0, "closed"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public final m(Lr42;)J
    .registers 8

    .prologue
    const-wide/16 v0, 0x0

    :goto_2
    const-wide/16 v2, 0x2000

    move-object v4, p1

    check-cast v4, Lff;

    iget-object v5, p0, Laq1;->b:Lvk;

    invoke-virtual {v4, v5, v2, v3}, Lff;->read(Lvk;J)J

    move-result-wide v2

    const-wide/16 v4, -0x1

    cmp-long v4, v2, v4

    if-eqz v4, :cond_18

    add-long/2addr v0, v2

    invoke-virtual {p0}, Laq1;->k()Lgl;

    goto :goto_2

    :cond_18
    return-wide v0
.end method

.method public final q(Ljava/lang/String;)Lgl;
    .registers 3

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-boolean v0, p0, Laq1;->c:Z

    if-nez v0, :cond_10

    iget-object v0, p0, Laq1;->b:Lvk;

    invoke-virtual {v0, p1}, Lvk;->a0(Ljava/lang/String;)V

    invoke-virtual {p0}, Laq1;->k()Lgl;

    return-object p0

    :cond_10
    const-string p0, "closed"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public final r(Lvk;J)V
    .registers 5

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-boolean v0, p0, Laq1;->c:Z

    if-nez v0, :cond_10

    iget-object v0, p0, Laq1;->b:Lvk;

    invoke-virtual {v0, p1, p2, p3}, Lvk;->r(Lvk;J)V

    invoke-virtual {p0}, Laq1;->k()Lgl;

    return-void

    :cond_10
    const-string p0, "closed"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-void
.end method

.method public final s(J)Lgl;
    .registers 4

    .prologue
    iget-boolean v0, p0, Laq1;->c:Z

    if-nez v0, :cond_d

    iget-object v0, p0, Laq1;->b:Lvk;

    invoke-virtual {v0, p1, p2}, Lvk;->W(J)V

    invoke-virtual {p0}, Laq1;->k()Lgl;

    return-object p0

    :cond_d
    const-string p0, "closed"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public final timeout()Lya2;
    .registers 1

    iget-object p0, p0, Laq1;->a:Ld42;

    invoke-interface {p0}, Ld42;->timeout()Lya2;

    move-result-object p0

    return-object p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "buffer("

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object p0, p0, Laq1;->a:Ld42;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 p0, 0x29

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public final write(Ljava/nio/ByteBuffer;)I
    .registers 3

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-boolean v0, p0, Laq1;->c:Z

    if-nez v0, :cond_11

    iget-object v0, p0, Laq1;->b:Lvk;

    invoke-virtual {v0, p1}, Lvk;->write(Ljava/nio/ByteBuffer;)I

    move-result p1

    invoke-virtual {p0}, Laq1;->k()Lgl;

    return p1

    :cond_11
    const-string p0, "closed"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    const/4 p0, 0x0

    return p0
.end method

.method public final write([B)Lgl;
    .registers 5

    .prologue
    iget-boolean v0, p0, Laq1;->c:Z

    if-nez v0, :cond_f

    const/4 v0, 0x0

    array-length v1, p1

    iget-object v2, p0, Laq1;->b:Lvk;

    invoke-virtual {v2, p1, v0, v1}, Lvk;->write([BII)V

    invoke-virtual {p0}, Laq1;->k()Lgl;

    return-object p0

    :cond_f
    const-string p0, "closed"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public final write([BII)Lgl;
    .registers 5

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-boolean v0, p0, Laq1;->c:Z

    if-nez v0, :cond_10

    iget-object v0, p0, Laq1;->b:Lvk;

    invoke-virtual {v0, p1, p2, p3}, Lvk;->write([BII)V

    invoke-virtual {p0}, Laq1;->k()Lgl;

    return-object p0

    :cond_10
    const-string p0, "closed"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public final writeByte(I)Lgl;
    .registers 3

    .prologue
    iget-boolean v0, p0, Laq1;->c:Z

    if-nez v0, :cond_d

    iget-object v0, p0, Laq1;->b:Lvk;

    invoke-virtual {v0, p1}, Lvk;->U(I)V

    invoke-virtual {p0}, Laq1;->k()Lgl;

    return-object p0

    :cond_d
    const-string p0, "closed"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public final writeInt(I)Lgl;
    .registers 3

    .prologue
    iget-boolean v0, p0, Laq1;->c:Z

    if-nez v0, :cond_d

    iget-object v0, p0, Laq1;->b:Lvk;

    invoke-virtual {v0, p1}, Lvk;->X(I)V

    invoke-virtual {p0}, Laq1;->k()Lgl;

    return-object p0

    :cond_d
    const-string p0, "closed"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public final writeShort(I)Lgl;
    .registers 3

    .prologue
    iget-boolean v0, p0, Laq1;->c:Z

    if-nez v0, :cond_d

    iget-object v0, p0, Laq1;->b:Lvk;

    invoke-virtual {v0, p1}, Lvk;->Y(I)V

    invoke-virtual {p0}, Laq1;->k()Lgl;

    return-object p0

    :cond_d
    const-string p0, "closed"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0
.end method
