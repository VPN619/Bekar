.class public final Lcn0;
.super Lp;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Ljy0;

.field public final b:Ljy0;

.field public final synthetic c:I

.field public final d:Lbn0;


# direct methods
.method public constructor <init>(Ljy0;Ljy0;B)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcn0;->a:Ljy0;

    iput-object p2, p0, Lcn0;->b:Ljy0;

    return-void
.end method

.method public constructor <init>(Ljy0;Ljy0;I)V
    .registers 5

    .prologue
    iput p3, p0, Lcn0;->c:I

    const/4 v0, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    packed-switch p3, :pswitch_data_42

    invoke-direct {p0, p1, p2, v0}, Lcn0;-><init>(Ljy0;Ljy0;B)V

    new-instance p3, Lbn0;

    invoke-interface {p1}, Ljy0;->getDescriptor()Lm02;

    move-result-object p1

    invoke-interface {p2}, Ljy0;->getDescriptor()Lm02;

    move-result-object p2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v0, "kotlin.collections.HashMap"

    invoke-direct {p3, v0, p1, p2}, Lbn0;-><init>(Ljava/lang/String;Lm02;Lm02;)V

    iput-object p3, p0, Lcn0;->d:Lbn0;

    return-void

    :pswitch_27  #0x1
    invoke-direct {p0, p1, p2, v0}, Lcn0;-><init>(Ljy0;Ljy0;B)V

    new-instance p3, Lbn0;

    invoke-interface {p1}, Ljy0;->getDescriptor()Lm02;

    move-result-object p1

    invoke-interface {p2}, Ljy0;->getDescriptor()Lm02;

    move-result-object p2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v0, "kotlin.collections.LinkedHashMap"

    invoke-direct {p3, v0, p1, p2}, Lbn0;-><init>(Ljava/lang/String;Lm02;Lm02;)V

    iput-object p3, p0, Lcn0;->d:Lbn0;

    return-void

    :pswitch_data_42
    .packed-switch 0x1
        :pswitch_27  #00000001
    .end packed-switch
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .registers 1

    .prologue
    iget p0, p0, Lcn0;->c:I

    packed-switch p0, :pswitch_data_12

    new-instance p0, Ljava/util/LinkedHashMap;

    invoke-direct {p0}, Ljava/util/LinkedHashMap;-><init>()V

    return-object p0

    :pswitch_b  #0x0
    new-instance p0, Ljava/util/HashMap;

    invoke-direct {p0}, Ljava/util/HashMap;-><init>()V

    return-object p0

    nop

    :pswitch_data_12
    .packed-switch 0x0
        :pswitch_b  #00000000
    .end packed-switch
.end method

.method public final b(Ljava/lang/Object;)I
    .registers 2

    .prologue
    iget p0, p0, Lcn0;->c:I

    packed-switch p0, :pswitch_data_1c

    check-cast p1, Ljava/util/LinkedHashMap;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/util/AbstractMap;->size()I

    move-result p0

    :goto_e
    mul-int/lit8 p0, p0, 0x2

    return p0

    :pswitch_11  #0x0
    check-cast p1, Ljava/util/HashMap;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/util/HashMap;->size()I

    move-result p0

    goto :goto_e

    nop

    :pswitch_data_1c
    .packed-switch 0x0
        :pswitch_11  #00000000
    .end packed-switch
.end method

.method public final c(Ljava/lang/Object;)Ljava/util/Iterator;
    .registers 2

    .prologue
    iget p0, p0, Lcn0;->c:I

    packed-switch p0, :pswitch_data_22

    check-cast p1, Ljava/util/Map;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {p1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    return-object p0

    :pswitch_13  #0x0
    check-cast p1, Ljava/util/Map;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {p1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_22
    .packed-switch 0x0
        :pswitch_13  #00000000
    .end packed-switch
.end method

.method public final d(Ljava/lang/Object;)I
    .registers 2

    .prologue
    iget p0, p0, Lcn0;->c:I

    packed-switch p0, :pswitch_data_1a

    check-cast p1, Ljava/util/Map;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {p1}, Ljava/util/Map;->size()I

    move-result p0

    return p0

    :pswitch_f  #0x0
    check-cast p1, Ljava/util/Map;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {p1}, Ljava/util/Map;->size()I

    move-result p0

    return p0

    nop

    :pswitch_data_1a
    .packed-switch 0x0
        :pswitch_f  #00000000
    .end packed-switch
.end method

.method public final f(Lfu;ILjava/lang/Object;)V
    .registers 8

    .prologue
    check-cast p3, Ljava/util/Map;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {p0}, Ljy0;->getDescriptor()Lm02;

    move-result-object v0

    iget-object v1, p0, Lcn0;->a:Ljy0;

    const/4 v2, 0x0

    invoke-interface {p1, v0, p2, v1, v2}, Lfu;->r(Lm02;ILjy0;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    invoke-interface {p0}, Ljy0;->getDescriptor()Lm02;

    move-result-object v1

    invoke-interface {p1, v1}, Lfu;->j(Lm02;)I

    move-result v1

    add-int/lit8 v3, p2, 0x1

    if-ne v1, v3, :cond_49

    invoke-interface {p3, v0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result p2

    iget-object v3, p0, Lcn0;->b:Ljy0;

    if-eqz p2, :cond_3d

    invoke-interface {v3}, Ljy0;->getDescriptor()Lm02;

    move-result-object p2

    invoke-interface {p2}, Lm02;->e()Lqk;

    move-result-object p2

    instance-of p2, p2, Lsm1;

    if-nez p2, :cond_3d

    invoke-interface {p0}, Ljy0;->getDescriptor()Lm02;

    move-result-object p0

    invoke-static {p3, v0}, Lb61;->P(Ljava/util/Map;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    invoke-interface {p1, p0, v1, v3, p2}, Lfu;->r(Lm02;ILjy0;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    goto :goto_45

    :cond_3d
    invoke-interface {p0}, Ljy0;->getDescriptor()Lm02;

    move-result-object p0

    invoke-interface {p1, p0, v1, v3, v2}, Lfu;->r(Lm02;ILjy0;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    :goto_45
    invoke-interface {p3, v0, p0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_54

    :cond_49
    const-string p0, "Value must follow key in a map, index for key: "

    const-string p1, ", returned index for value: "

    invoke-static {p2, v1, p0, p1}, Ly41;->o(IILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->v(Ljava/lang/Object;)V

    :goto_54
    return-void
.end method

.method public final g(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .prologue
    iget p0, p0, Lcn0;->c:I

    packed-switch p0, :pswitch_data_a

    const/4 p0, 0x0

    throw p0

    :pswitch_7  #0x0
    const/4 p0, 0x0

    throw p0

    nop

    :pswitch_data_a
    .packed-switch 0x0
        :pswitch_7  #00000000
    .end packed-switch
.end method

.method public final getDescriptor()Lm02;
    .registers 2

    iget v0, p0, Lcn0;->c:I

    iget-object p0, p0, Lcn0;->d:Lbn0;

    return-object p0
.end method

.method public final h(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .prologue
    iget p0, p0, Lcn0;->c:I

    packed-switch p0, :pswitch_data_12

    check-cast p1, Ljava/util/LinkedHashMap;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object p1

    :pswitch_b  #0x0
    check-cast p1, Ljava/util/HashMap;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object p1

    nop

    :pswitch_data_12
    .packed-switch 0x0
        :pswitch_b  #00000000
    .end packed-switch
.end method

.method public final serialize(Lga0;Ljava/lang/Object;)V
    .registers 10

    .prologue
    invoke-virtual {p0, p2}, Lp;->d(Ljava/lang/Object;)I

    move-result v0

    invoke-interface {p0}, Ljy0;->getDescriptor()Lm02;

    move-result-object v1

    invoke-interface {p1, v1, v0}, Lga0;->F(Lm02;I)Lgu;

    move-result-object p1

    invoke-virtual {p0, p2}, Lp;->c(Ljava/lang/Object;)Ljava/util/Iterator;

    move-result-object p2

    const/4 v0, 0x0

    :goto_11
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_3c

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    invoke-interface {p0}, Ljy0;->getDescriptor()Lm02;

    move-result-object v4

    add-int/lit8 v5, v0, 0x1

    iget-object v6, p0, Lcn0;->a:Ljy0;

    invoke-interface {p1, v4, v0, v6, v3}, Lgu;->p(Lm02;ILjy0;Ljava/lang/Object;)V

    invoke-interface {p0}, Ljy0;->getDescriptor()Lm02;

    move-result-object v3

    add-int/lit8 v0, v0, 0x2

    iget-object v4, p0, Lcn0;->b:Ljy0;

    invoke-interface {p1, v3, v5, v4, v2}, Lgu;->p(Lm02;ILjy0;Ljava/lang/Object;)V

    goto :goto_11

    :cond_3c
    invoke-interface {p1, v1}, Lgu;->b(Lm02;)V

    return-void
.end method
