.class public final Lbp;
.super Lcp;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final c:Lbp;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lbp;

    invoke-direct {v0}, Lcp;-><init>()V

    sput-object v0, Lbp;->c:Lbp;

    return-void
.end method
