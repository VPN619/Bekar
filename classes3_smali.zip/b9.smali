.class public final Lb9;
.super Lorg/chromium/net/ICronetEngineBuilder;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static b:Z

.field public static c:Z


# instance fields
.field public final a:Landroid/net/http/HttpEngine$Builder;


# direct methods
.method public constructor <init>(Landroid/net/http/HttpEngine$Builder;)V
    .registers 2

    invoke-direct {p0}, Lorg/chromium/net/ICronetEngineBuilder;-><init>()V

    iput-object p1, p0, Lb9;->a:Landroid/net/http/HttpEngine$Builder;

    return-void
.end method

.method public static a(I)I
    .registers 3

    .prologue
    invoke-static {p0}, Lc33;->x(I)I

    move-result v0

    if-eqz v0, :cond_2d

    const/4 v1, 0x1

    if-eq v0, v1, :cond_2c

    const/4 v1, 0x2

    if-ne v0, v1, :cond_d

    return v1

    :cond_d
    const/4 v0, 0x1

    if-eq p0, v0, :cond_1f

    const/4 v0, 0x2

    if-eq p0, v0, :cond_1c

    const/4 v0, 0x3

    if-eq p0, v0, :cond_19

    const-string p0, "null"

    goto :goto_21

    :cond_19
    const-string p0, "FALSE"

    goto :goto_21

    :cond_1c
    const-string p0, "TRUE"

    goto :goto_21

    :cond_1f
    const-string p0, "UNSET"

    :goto_21
    const-string v0, "Invalid OptionalBoolean value: "

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->q(Ljava/lang/Object;)V

    const/4 p0, 0x0

    return p0

    :cond_2c
    return v1

    :cond_2d
    const/4 p0, 0x0

    return p0
.end method


# virtual methods
.method public final addPublicKeyPins(Ljava/lang/String;Ljava/util/Set;ZLjava/util/Date;)Lorg/chromium/net/ICronetEngineBuilder;
    .registers 6

    iget-object v0, p0, Lb9;->a:Landroid/net/http/HttpEngine$Builder;

    invoke-static {p4}, Lj$/util/DateRetargetClass;->toInstant(Ljava/util/Date;)Lj$/time/Instant;

    move-result-object p4

    invoke-static {v0, p1, p2, p3, p4}, Lz6;->i(Landroid/net/http/HttpEngine$Builder;Ljava/lang/String;Ljava/util/Set;ZLj$/time/Instant;)Landroid/net/http/HttpEngine$Builder;

    return-object p0
.end method

.method public final addQuicHint(Ljava/lang/String;II)Lorg/chromium/net/ICronetEngineBuilder;
    .registers 5

    iget-object v0, p0, Lb9;->a:Landroid/net/http/HttpEngine$Builder;

    invoke-virtual {v0, p1, p2, p3}, Landroid/net/http/HttpEngine$Builder;->addQuicHint(Ljava/lang/String;II)Landroid/net/http/HttpEngine$Builder;

    return-object p0
.end method

.method public final build()Lorg/chromium/net/ExperimentalCronetEngine;
    .registers 2

    new-instance v0, Lc9;

    iget-object p0, p0, Lb9;->a:Landroid/net/http/HttpEngine$Builder;

    invoke-virtual {p0}, Landroid/net/http/HttpEngine$Builder;->build()Landroid/net/http/HttpEngine;

    move-result-object p0

    invoke-direct {v0, p0}, Lc9;-><init>(Landroid/net/http/HttpEngine;)V

    return-object v0
.end method

.method public final enableBrotli(Z)Lorg/chromium/net/ICronetEngineBuilder;
    .registers 3

    iget-object v0, p0, Lb9;->a:Landroid/net/http/HttpEngine$Builder;

    invoke-virtual {v0, p1}, Landroid/net/http/HttpEngine$Builder;->setEnableBrotli(Z)Landroid/net/http/HttpEngine$Builder;

    return-object p0
.end method

.method public final enableHttp2(Z)Lorg/chromium/net/ICronetEngineBuilder;
    .registers 3

    iget-object v0, p0, Lb9;->a:Landroid/net/http/HttpEngine$Builder;

    invoke-virtual {v0, p1}, Landroid/net/http/HttpEngine$Builder;->setEnableHttp2(Z)Landroid/net/http/HttpEngine$Builder;

    return-object p0
.end method

.method public final enableHttpCache(IJ)Lorg/chromium/net/ICronetEngineBuilder;
    .registers 5

    iget-object v0, p0, Lb9;->a:Landroid/net/http/HttpEngine$Builder;

    invoke-virtual {v0, p1, p2, p3}, Landroid/net/http/HttpEngine$Builder;->setEnableHttpCache(IJ)Landroid/net/http/HttpEngine$Builder;

    return-object p0
.end method

.method public final enableNetworkQualityEstimator(Z)Lorg/chromium/net/ICronetEngineBuilder;
    .registers 3

    .prologue
    sget-boolean p1, Lb9;->c:Z

    if-nez p1, :cond_c

    const-string p1, "HttpEngBuilderWrap"

    const-string v0, "NetworkQualityEstimator is unsupported when HttpEngineNativeProvider is used"

    nop

    const/4 p1, 0x1

    sput-boolean p1, Lb9;->c:Z

    :cond_c
    return-object p0
.end method

.method public final enablePublicKeyPinningBypassForLocalTrustAnchors(Z)Lorg/chromium/net/ICronetEngineBuilder;
    .registers 3

    iget-object v0, p0, Lb9;->a:Landroid/net/http/HttpEngine$Builder;

    invoke-virtual {v0, p1}, Landroid/net/http/HttpEngine$Builder;->setEnablePublicKeyPinningBypassForLocalTrustAnchors(Z)Landroid/net/http/HttpEngine$Builder;

    return-object p0
.end method

.method public final enableQuic(Z)Lorg/chromium/net/ICronetEngineBuilder;
    .registers 3

    iget-object v0, p0, Lb9;->a:Landroid/net/http/HttpEngine$Builder;

    invoke-virtual {v0, p1}, Landroid/net/http/HttpEngine$Builder;->setEnableQuic(Z)Landroid/net/http/HttpEngine$Builder;

    return-object p0
.end method

.method public final enableSdch(Z)Lorg/chromium/net/ICronetEngineBuilder;
    .registers 2

    return-object p0
.end method

.method public final getDefaultUserAgent()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lb9;->a:Landroid/net/http/HttpEngine$Builder;

    invoke-virtual {p0}, Landroid/net/http/HttpEngine$Builder;->getDefaultUserAgent()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public final setExperimentalOptions(Ljava/lang/String;)Lorg/chromium/net/ICronetEngineBuilder;
    .registers 14

    .prologue
    const/4 v0, -0x1

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    new-instance v2, Ldc0;

    invoke-direct {v2, p1}, Ldc0;-><init>(Ljava/lang/String;)V

    iget-object p1, p0, Lb9;->a:Landroid/net/http/HttpEngine$Builder;

    new-instance v3, Landroid/net/http/ConnectionMigrationOptions$Builder;

    invoke-direct {v3}, Landroid/net/http/ConnectionMigrationOptions$Builder;-><init>()V

    const-string v4, "QUIC"

    const-string v5, "migrate_sessions_on_network_change_v2"

    const/4 v6, 0x0

    const-class v7, Ljava/lang/Boolean;

    invoke-virtual {v2, v4, v5, v6, v7}, Ldc0;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-static {v5}, Ly41;->d(Ljava/lang/Boolean;)I

    move-result v5

    invoke-static {v5}, Lb9;->a(I)I

    move-result v5

    invoke-virtual {v3, v5}, Landroid/net/http/ConnectionMigrationOptions$Builder;->setDefaultNetworkMigration(I)Landroid/net/http/ConnectionMigrationOptions$Builder;

    const-string v5, "allow_port_migration"

    invoke-virtual {v2, v4, v5, v6, v7}, Ldc0;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-static {v5}, Ly41;->d(Ljava/lang/Boolean;)I

    move-result v5

    invoke-static {v5}, Lb9;->a(I)I

    move-result v5

    invoke-virtual {v3, v5}, Landroid/net/http/ConnectionMigrationOptions$Builder;->setPathDegradationMigration(I)Landroid/net/http/ConnectionMigrationOptions$Builder;

    const-string v5, "migrate_sessions_early_v2"

    invoke-virtual {v2, v4, v5, v6, v7}, Ldc0;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-static {v5}, Ly41;->d(Ljava/lang/Boolean;)I

    move-result v5

    invoke-static {v5}, Lb9;->a(I)I

    move-result v8

    invoke-virtual {v3, v8}, Landroid/net/http/ConnectionMigrationOptions$Builder;->setAllowNonDefaultNetworkUsage(I)Landroid/net/http/ConnectionMigrationOptions$Builder;

    const/4 v8, 0x2

    if-ne v5, v8, :cond_59

    invoke-static {v8}, Lb9;->a(I)I

    move-result v5

    invoke-virtual {v3, v5}, Landroid/net/http/ConnectionMigrationOptions$Builder;->setPathDegradationMigration(I)Landroid/net/http/ConnectionMigrationOptions$Builder;

    :cond_59
    invoke-virtual {v3}, Landroid/net/http/ConnectionMigrationOptions$Builder;->build()Landroid/net/http/ConnectionMigrationOptions;

    move-result-object v3

    invoke-virtual {p1, v3}, Landroid/net/http/HttpEngine$Builder;->setConnectionMigrationOptions(Landroid/net/http/ConnectionMigrationOptions;)Landroid/net/http/HttpEngine$Builder;

    iget-object p1, p0, Lb9;->a:Landroid/net/http/HttpEngine$Builder;

    new-instance v3, Landroid/net/http/DnsOptions$StaleDnsOptions$Builder;

    invoke-direct {v3}, Landroid/net/http/DnsOptions$StaleDnsOptions$Builder;-><init>()V

    const-string v5, "delay_ms"

    const-string v8, "StaleDNS"

    const-class v9, Ljava/lang/Integer;

    invoke-virtual {v2, v8, v5, v1, v9}, Ldc0;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    if-eq v5, v0, :cond_81

    int-to-long v10, v5

    invoke-static {v10, v11}, Lj$/time/Duration;->ofMillis(J)Lj$/time/Duration;

    move-result-object v5

    invoke-static {v3, v5}, Lz6;->h(Landroid/net/http/DnsOptions$StaleDnsOptions$Builder;Lj$/time/Duration;)Landroid/net/http/DnsOptions$StaleDnsOptions$Builder;

    :cond_81
    const-string v5, "max_expired_time_ms"

    invoke-virtual {v2, v8, v5, v1, v9}, Ldc0;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    if-eq v5, v0, :cond_97

    int-to-long v10, v5

    invoke-static {v10, v11}, Lj$/time/Duration;->ofMillis(J)Lj$/time/Duration;

    move-result-object v5

    invoke-static {v3, v5}, Lz6;->u(Landroid/net/http/DnsOptions$StaleDnsOptions$Builder;Lj$/time/Duration;)Landroid/net/http/DnsOptions$StaleDnsOptions$Builder;

    :cond_97
    const-string v5, "allow_other_network"

    invoke-virtual {v2, v8, v5, v6, v7}, Ldc0;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-static {v5}, Ly41;->d(Ljava/lang/Boolean;)I

    move-result v5

    invoke-static {v5}, Lb9;->a(I)I

    move-result v5

    invoke-virtual {v3, v5}, Landroid/net/http/DnsOptions$StaleDnsOptions$Builder;->setAllowCrossNetworkUsage(I)Landroid/net/http/DnsOptions$StaleDnsOptions$Builder;

    move-result-object v5

    const-string v10, "use_stale_on_name_not_resolved"

    invoke-virtual {v2, v8, v10, v6, v7}, Ldc0;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/Boolean;

    invoke-static {v10}, Ly41;->d(Ljava/lang/Boolean;)I

    move-result v10

    invoke-static {v10}, Lb9;->a(I)I

    move-result v10

    invoke-virtual {v5, v10}, Landroid/net/http/DnsOptions$StaleDnsOptions$Builder;->setUseStaleOnNameNotResolved(I)Landroid/net/http/DnsOptions$StaleDnsOptions$Builder;

    new-instance v5, Landroid/net/http/DnsOptions$Builder;

    invoke-direct {v5}, Landroid/net/http/DnsOptions$Builder;-><init>()V

    const-string v10, "AsyncDNS"

    const-string v11, "enable"

    invoke-virtual {v2, v10, v11, v6, v7}, Ldc0;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/Boolean;

    invoke-static {v10}, Ly41;->d(Ljava/lang/Boolean;)I

    move-result v10

    invoke-static {v10}, Lb9;->a(I)I

    move-result v10

    invoke-virtual {v5, v10}, Landroid/net/http/DnsOptions$Builder;->setUseHttpStackDnsResolver(I)Landroid/net/http/DnsOptions$Builder;

    move-result-object v10

    invoke-virtual {v2, v8, v11, v6, v7}, Ldc0;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/Boolean;

    invoke-static {v11}, Ly41;->d(Ljava/lang/Boolean;)I

    move-result v11

    invoke-static {v11}, Lb9;->a(I)I

    move-result v11

    invoke-virtual {v10, v11}, Landroid/net/http/DnsOptions$Builder;->setStaleDns(I)Landroid/net/http/DnsOptions$Builder;

    move-result-object v10

    invoke-virtual {v3}, Landroid/net/http/DnsOptions$StaleDnsOptions$Builder;->build()Landroid/net/http/DnsOptions$StaleDnsOptions;

    move-result-object v3

    invoke-virtual {v10, v3}, Landroid/net/http/DnsOptions$Builder;->setStaleDnsOptions(Landroid/net/http/DnsOptions$StaleDnsOptions;)Landroid/net/http/DnsOptions$Builder;

    move-result-object v3

    const-string v10, "race_stale_dns_on_connection"

    invoke-virtual {v2, v4, v10, v6, v7}, Ldc0;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/Boolean;

    invoke-static {v10}, Ly41;->d(Ljava/lang/Boolean;)I

    move-result v10

    invoke-static {v10}, Lb9;->a(I)I

    move-result v10

    invoke-virtual {v3, v10}, Landroid/net/http/DnsOptions$Builder;->setPreestablishConnectionsToStaleDnsResults(I)Landroid/net/http/DnsOptions$Builder;

    move-result-object v3

    const-string v10, "persist_to_disk"

    invoke-virtual {v2, v8, v10, v6, v7}, Ldc0;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/Boolean;

    invoke-static {v7}, Ly41;->d(Ljava/lang/Boolean;)I

    move-result v7

    invoke-static {v7}, Lb9;->a(I)I

    move-result v7

    invoke-virtual {v3, v7}, Landroid/net/http/DnsOptions$Builder;->setPersistHostCache(I)Landroid/net/http/DnsOptions$Builder;

    const-string v3, "persist_delay_ms"

    invoke-virtual {v2, v8, v3, v1, v9}, Ldc0;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    if-eq v3, v0, :cond_130

    int-to-long v7, v3

    invoke-static {v7, v8}, Lj$/time/Duration;->ofMillis(J)Lj$/time/Duration;

    move-result-object v3

    invoke-static {v5, v3}, Lz6;->g(Landroid/net/http/DnsOptions$Builder;Lj$/time/Duration;)Landroid/net/http/DnsOptions$Builder;

    :cond_130
    invoke-virtual {v5}, Landroid/net/http/DnsOptions$Builder;->build()Landroid/net/http/DnsOptions;

    move-result-object v3

    invoke-virtual {p1, v3}, Landroid/net/http/HttpEngine$Builder;->setDnsOptions(Landroid/net/http/DnsOptions;)Landroid/net/http/HttpEngine$Builder;

    iget-object p1, p0, Lb9;->a:Landroid/net/http/HttpEngine$Builder;

    new-instance v3, Landroid/net/http/QuicOptions$Builder;

    invoke-direct {v3}, Landroid/net/http/QuicOptions$Builder;-><init>()V

    const-string v5, "host_whitelist"

    const-class v7, Ljava/lang/String;

    invoke-virtual {v2, v4, v5, v6, v7}, Ldc0;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    if-eqz v8, :cond_162

    invoke-virtual {v2, v4, v5, v6, v7}, Ldc0;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    const-string v8, ","

    invoke-virtual {v5, v8}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v5

    array-length v8, v5

    const/4 v10, 0x0

    :goto_158
    if-ge v10, v8, :cond_162

    aget-object v11, v5, v10

    invoke-virtual {v3, v11}, Landroid/net/http/QuicOptions$Builder;->addAllowedQuicHost(Ljava/lang/String;)Landroid/net/http/QuicOptions$Builder;

    add-int/lit8 v10, v10, 0x1

    goto :goto_158

    :cond_162
    const-string v5, "max_server_configs_stored_in_properties"

    invoke-virtual {v2, v4, v5, v1, v9}, Ldc0;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    if-eq v5, v0, :cond_173

    invoke-virtual {v3, v5}, Landroid/net/http/QuicOptions$Builder;->setInMemoryServerConfigsCacheSize(I)Landroid/net/http/QuicOptions$Builder;

    :cond_173
    const-string v5, "user_agent_id"

    invoke-virtual {v2, v4, v5, v6, v7}, Ldc0;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    if-eqz v5, :cond_180

    invoke-virtual {v3, v5}, Landroid/net/http/QuicOptions$Builder;->setHandshakeUserAgent(Ljava/lang/String;)Landroid/net/http/QuicOptions$Builder;

    :cond_180
    const-string v5, "idle_connection_timeout_seconds"

    invoke-virtual {v2, v4, v5, v1, v9}, Ldc0;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    if-eq v1, v0, :cond_196

    int-to-long v0, v1

    invoke-static {v0, v1}, Lj$/time/Duration;->ofSeconds(J)Lj$/time/Duration;

    move-result-object v0

    invoke-static {v3, v0}, Lz6;->j(Landroid/net/http/QuicOptions$Builder;Lj$/time/Duration;)Landroid/net/http/QuicOptions$Builder;

    :cond_196
    invoke-virtual {v3}, Landroid/net/http/QuicOptions$Builder;->build()Landroid/net/http/QuicOptions;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/net/http/HttpEngine$Builder;->setQuicOptions(Landroid/net/http/QuicOptions;)Landroid/net/http/HttpEngine$Builder;

    return-object p0
.end method

.method public final setLibraryLoader(Lorg/chromium/net/CronetEngine$Builder$LibraryLoader;)Lorg/chromium/net/ICronetEngineBuilder;
    .registers 3

    .prologue
    sget-boolean p1, Lb9;->b:Z

    if-nez p1, :cond_c

    const-string p1, "HttpEngBuilderWrap"

    const-string v0, "Custom library loader is unsupported when HttpEngineNativeProvider is used."

    nop

    const/4 p1, 0x1

    sput-boolean p1, Lb9;->b:Z

    :cond_c
    return-object p0
.end method

.method public final setStoragePath(Ljava/lang/String;)Lorg/chromium/net/ICronetEngineBuilder;
    .registers 3

    iget-object v0, p0, Lb9;->a:Landroid/net/http/HttpEngine$Builder;

    invoke-virtual {v0, p1}, Landroid/net/http/HttpEngine$Builder;->setStoragePath(Ljava/lang/String;)Landroid/net/http/HttpEngine$Builder;

    return-object p0
.end method

.method public final setThreadPriority(I)Lorg/chromium/net/ICronetEngineBuilder;
    .registers 2

    return-object p0
.end method

.method public final setUserAgent(Ljava/lang/String;)Lorg/chromium/net/ICronetEngineBuilder;
    .registers 3

    iget-object v0, p0, Lb9;->a:Landroid/net/http/HttpEngine$Builder;

    invoke-virtual {v0, p1}, Landroid/net/http/HttpEngine$Builder;->setUserAgent(Ljava/lang/String;)Landroid/net/http/HttpEngine$Builder;

    return-object p0
.end method
