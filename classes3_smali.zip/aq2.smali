.class public final Laq2;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lzj0;


# instance fields
.field public final synthetic a:[Lff0;


# direct methods
.method public constructor <init>([Lff0;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Laq2;->a:[Lff0;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 1

    iget-object p0, p0, Laq2;->a:[Lff0;

    array-length p0, p0

    new-array p0, p0, [Lcx;

    return-object p0
.end method
