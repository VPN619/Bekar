.class public final Lbn0;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lm02;


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Lm02;

.field public final c:Lm02;


# direct methods
.method public constructor <init>(Ljava/lang/String;Lm02;Lm02;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lbn0;->a:Ljava/lang/String;

    iput-object p2, p0, Lbn0;->b:Lm02;

    iput-object p3, p0, Lbn0;->c:Lm02;

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lbn0;->a:Ljava/lang/String;

    return-object p0
.end method

.method public final c()Z
    .registers 1

    const/4 p0, 0x0

    return p0
.end method

.method public final d(Ljava/lang/String;)I
    .registers 2

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1}, Lj72;->b0(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object p0

    if-eqz p0, :cond_e

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    return p0

    :cond_e
    const-string p0, " is not a valid map index"

    invoke-virtual {p1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->s(Ljava/lang/String;)V

    const/4 p0, 0x0

    return p0
.end method

.method public final e()Lqk;
    .registers 1

    sget-object p0, Ll72;->w:Ll72;

    return-object p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    .prologue
    if-ne p0, p1, :cond_3

    goto :goto_2c

    :cond_3
    instance-of v0, p1, Lbn0;

    if-nez v0, :cond_8

    goto :goto_2a

    :cond_8
    check-cast p1, Lbn0;

    iget-object v0, p1, Lbn0;->a:Ljava/lang/String;

    iget-object v1, p0, Lbn0;->a:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_15

    goto :goto_2a

    :cond_15
    iget-object v0, p0, Lbn0;->b:Lm02;

    iget-object v1, p1, Lbn0;->b:Lm02;

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_20

    goto :goto_2a

    :cond_20
    iget-object p0, p0, Lbn0;->c:Lm02;

    iget-object p1, p1, Lbn0;->c:Lm02;

    invoke-virtual {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_2c

    :goto_2a
    const/4 p0, 0x0

    return p0

    :cond_2c
    :goto_2c
    const/4 p0, 0x1

    return p0
.end method

.method public final f()I
    .registers 1

    const/4 p0, 0x2

    return p0
.end method

.method public final g(I)Ljava/lang/String;
    .registers 2

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public final getAnnotations()Ljava/util/List;
    .registers 1

    sget-object p0, Lba0;->a:Lba0;

    return-object p0
.end method

.method public final h()Z
    .registers 1

    const/4 p0, 0x0

    return p0
.end method

.method public final hashCode()I
    .registers 3

    iget-object v0, p0, Lbn0;->a:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, Lbn0;->b:Lm02;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    mul-int/lit8 v1, v1, 0x1f

    iget-object p0, p0, Lbn0;->c:Lm02;

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result p0

    add-int/2addr p0, v1

    return p0
.end method

.method public final i(I)Ljava/util/List;
    .registers 4

    .prologue
    if-ltz p1, :cond_5

    sget-object p0, Lba0;->a:Lba0;

    return-object p0

    :cond_5
    const-string v0, "Illegal index "

    const-string v1, ", "

    invoke-static {p1, v0, v1}, Lmz2;->n(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    iget-object p0, p0, Lbn0;->a:Ljava/lang/String;

    const-string v0, " expects only non-negative indices"

    invoke-static {p1, p0, v0}, Ly41;->s(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->v(Ljava/lang/Object;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public final j(I)Lm02;
    .registers 5

    .prologue
    const/4 v0, 0x0

    if-ltz p1, :cond_16

    rem-int/lit8 p1, p1, 0x2

    if-eqz p1, :cond_13

    const/4 v1, 0x1

    if-ne p1, v1, :cond_d

    iget-object p0, p0, Lbn0;->c:Lm02;

    return-object p0

    :cond_d
    const-string p0, "Unreached"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v0

    :cond_13
    iget-object p0, p0, Lbn0;->b:Lm02;

    return-object p0

    :cond_16
    const-string v1, "Illegal index "

    const-string v2, ", "

    invoke-static {p1, v1, v2}, Lmz2;->n(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    iget-object p0, p0, Lbn0;->a:Ljava/lang/String;

    const-string v1, " expects only non-negative indices"

    invoke-static {p1, p0, v1}, Ly41;->s(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->v(Ljava/lang/Object;)V

    return-object v0
.end method

.method public final k(I)Z
    .registers 4

    .prologue
    if-ltz p1, :cond_4

    const/4 p0, 0x0

    return p0

    :cond_4
    const-string v0, "Illegal index "

    const-string v1, ", "

    invoke-static {p1, v0, v1}, Lmz2;->n(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    iget-object p0, p0, Lbn0;->a:Ljava/lang/String;

    const-string v0, " expects only non-negative indices"

    invoke-static {p1, p0, v0}, Ly41;->s(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->v(Ljava/lang/Object;)V

    const/4 p0, 0x0

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    iget-object v1, p0, Lbn0;->a:Ljava/lang/String;

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v1, 0x28

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lbn0;->b:Lm02;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, Lbn0;->c:Lm02;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 p0, 0x29

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
