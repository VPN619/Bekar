.class public abstract Lc72;
.super Lk72;


# direct methods
.method public static final A0(I)V
    .registers 2

    .prologue
    if-ltz p0, :cond_3

    return-void

    :cond_3
    const-string v0, "Limit must be non-negative, but was "

    invoke-static {p0, v0}, Lrt2;->f(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->v(Ljava/lang/Object;)V

    return-void
.end method

.method public static B0(Ljava/lang/String;)Ljava/lang/StringBuilder;
    .registers 2

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, p0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/CharSequence;)V

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->reverse()Ljava/lang/StringBuilder;

    move-result-object p0

    return-object p0
.end method

.method public static final C0(ILjava/lang/CharSequence;Ljava/lang/String;)Ljava/util/List;
    .registers 11

    .prologue
    invoke-static {p0}, Lc72;->A0(I)V

    const/4 v0, 0x0

    invoke-static {p1, p2, v0, v0}, Lc72;->p0(Ljava/lang/CharSequence;Ljava/lang/String;IZ)I

    move-result v1

    const/4 v2, -0x1

    if-eq v1, v2, :cond_52

    const/4 v3, 0x1

    if-ne p0, v3, :cond_f

    goto :goto_52

    :cond_f
    if-lez p0, :cond_13

    move v4, v3

    goto :goto_14

    :cond_13
    move v4, v0

    :goto_14
    new-instance v5, Ljava/util/ArrayList;

    const/16 v6, 0xa

    if-eqz v4, :cond_1e

    if-le p0, v6, :cond_1d

    goto :goto_1e

    :cond_1d
    move v6, p0

    :cond_1e
    :goto_1e
    invoke-direct {v5, v6}, Ljava/util/ArrayList;-><init>(I)V

    move v6, v0

    :cond_22
    invoke-interface {p1, v6, v1}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v6

    add-int/2addr v6, v1

    if-eqz v4, :cond_3c

    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    move-result v1

    add-int/lit8 v7, p0, -0x1

    if-eq v1, v7, :cond_42

    :cond_3c
    invoke-static {p1, p2, v6, v0}, Lc72;->p0(Ljava/lang/CharSequence;Ljava/lang/String;IZ)I

    move-result v1

    if-ne v1, v2, :cond_22

    :cond_42
    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result p0

    invoke-interface {p1, v6, p0}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v5, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    return-object v5

    :cond_52
    :goto_52
    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Luz;->G(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    return-object p0
.end method

.method public static D0(Ljava/lang/CharSequence;[C)Ljava/util/List;
    .registers 6

    .prologue
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    array-length v0, p1

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-ne v0, v2, :cond_13

    aget-char p1, p1, v1

    invoke-static {p1}, Ljava/lang/String;->valueOf(C)Ljava/lang/String;

    move-result-object p1

    invoke-static {v1, p0, p1}, Lc72;->C0(ILjava/lang/CharSequence;Ljava/lang/String;)Ljava/util/List;

    move-result-object p0

    return-object p0

    :cond_13
    invoke-static {v1}, Lc72;->A0(I)V

    new-instance v0, Lo30;

    new-instance v3, Lnx1;

    invoke-direct {v3, v2, p1}, Lnx1;-><init>(ILjava/lang/Object;)V

    invoke-direct {v0, p0, v1, v3}, Lo30;-><init>(Ljava/lang/CharSequence;ILpk0;)V

    new-instance p1, Lzq0;

    invoke-direct {p1, v2, v0}, Lzq0;-><init>(ILjava/lang/Object;)V

    new-instance v0, Ljava/util/ArrayList;

    const/16 v1, 0xa

    invoke-static {p1, v1}, Lds;->Y(Ljava/lang/Iterable;I)I

    move-result v1

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    invoke-virtual {p1}, Lzq0;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_34
    move-object v1, p1

    check-cast v1, Ln30;

    invoke-virtual {v1}, Ln30;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_57

    invoke-virtual {v1}, Ln30;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljs0;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget v3, v1, Lhs0;->a:I

    iget v1, v1, Lhs0;->b:I

    add-int/2addr v1, v2

    invoke-interface {p0, v3, v1}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_34

    :cond_57
    return-object v0
.end method

.method public static E0(Ljava/lang/CharSequence;[Ljava/lang/String;I)Ljava/util/List;
    .registers 7

    .prologue
    and-int/lit8 p2, p2, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    if-eqz p2, :cond_8

    move p2, v1

    goto :goto_9

    :cond_8
    move p2, v0

    :goto_9
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    array-length v2, p1

    const/4 v3, 0x1

    if-ne v2, v3, :cond_1e

    aget-object v1, p1, v1

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    if-nez v2, :cond_19

    goto :goto_1e

    :cond_19
    invoke-static {p2, p0, v1}, Lc72;->C0(ILjava/lang/CharSequence;Ljava/lang/String;)Ljava/util/List;

    move-result-object p0

    return-object p0

    :cond_1e
    :goto_1e
    invoke-static {p2}, Lc72;->A0(I)V

    invoke-static {p1}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lo30;

    new-instance v2, Lnx1;

    invoke-direct {v2, v0, p1}, Lnx1;-><init>(ILjava/lang/Object;)V

    invoke-direct {v1, p0, p2, v2}, Lo30;-><init>(Ljava/lang/CharSequence;ILpk0;)V

    new-instance p1, Lzq0;

    invoke-direct {p1, v3, v1}, Lzq0;-><init>(ILjava/lang/Object;)V

    new-instance p2, Ljava/util/ArrayList;

    const/16 v0, 0xa

    invoke-static {p1, v0}, Lds;->Y(Ljava/lang/Iterable;I)I

    move-result v0

    invoke-direct {p2, v0}, Ljava/util/ArrayList;-><init>(I)V

    invoke-virtual {p1}, Lzq0;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_46
    move-object v0, p1

    check-cast v0, Ln30;

    invoke-virtual {v0}, Ln30;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_69

    invoke-virtual {v0}, Ln30;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljs0;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget v1, v0, Lhs0;->a:I

    iget v0, v0, Lhs0;->b:I

    add-int/2addr v0, v3

    invoke-interface {p0, v1, v0}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_46

    :cond_69
    return-object p2
.end method

.method public static F0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 5

    .prologue
    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-static {p0, p1, v0, v0, v1}, Lc72;->s0(Ljava/lang/CharSequence;Ljava/lang/String;IZI)I

    move-result v0

    const/4 v1, -0x1

    if-ne v0, v1, :cond_a

    return-object p2

    :cond_a
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result p1

    add-int/2addr p1, v0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p2

    invoke-virtual {p0, p1, p2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static G0(ILjava/lang/String;)Ljava/lang/String;
    .registers 3

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-ltz p0, :cond_12

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    if-le p0, v0, :cond_c

    move p0, v0

    :cond_c
    const/4 v0, 0x0

    invoke-virtual {p1, v0, p0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_12
    const-string p1, "Requested character count "

    const-string v0, " is less than zero."

    invoke-static {p0, p1, v0}, Lrt2;->g(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->v(Ljava/lang/Object;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static H0(Ljava/lang/String;)Ljava/lang/Boolean;
    .registers 2

    .prologue
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v0, "true"

    invoke-virtual {p0, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_e

    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    return-object p0

    :cond_e
    const-string v0, "false"

    invoke-virtual {p0, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_19

    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    return-object p0

    :cond_19
    const/4 p0, 0x0

    return-object p0
.end method

.method public static I0(Ljava/lang/String;)Ljava/lang/CharSequence;
    .registers 6

    .prologue
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v1, 0x1

    sub-int/2addr v0, v1

    const/4 v2, 0x0

    move v3, v2

    :goto_b
    if-gt v2, v0, :cond_29

    if-nez v3, :cond_11

    move v4, v2

    goto :goto_12

    :cond_11
    move v4, v0

    :goto_12
    invoke-virtual {p0, v4}, Ljava/lang/String;->charAt(I)C

    move-result v4

    invoke-static {v4}, Lw53;->M(C)Z

    move-result v4

    if-nez v3, :cond_23

    if-nez v4, :cond_20

    move v3, v1

    goto :goto_b

    :cond_20
    add-int/lit8 v2, v2, 0x1

    goto :goto_b

    :cond_23
    if-nez v4, :cond_26

    goto :goto_29

    :cond_26
    add-int/lit8 v0, v0, -0x1

    goto :goto_b

    :cond_29
    :goto_29
    add-int/2addr v0, v1

    invoke-virtual {p0, v2, v0}, Ljava/lang/String;->subSequence(II)Ljava/lang/CharSequence;

    move-result-object p0

    return-object p0
.end method

.method public static l0(Ljava/lang/CharSequence;Ljava/lang/CharSequence;Z)Z
    .registers 11

    .prologue
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    instance-of v0, p1, Ljava/lang/String;

    const/4 v1, 0x0

    if-eqz v0, :cond_15

    check-cast p1, Ljava/lang/String;

    const/4 v0, 0x2

    invoke-static {p0, p1, v1, p2, v0}, Lc72;->s0(Ljava/lang/CharSequence;Ljava/lang/String;IZI)I

    move-result p0

    if-ltz p0, :cond_26

    goto :goto_24

    :cond_15
    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result v5

    const/4 v7, 0x0

    const/4 v4, 0x0

    move-object v2, p0

    move-object v3, p1

    move v6, p2

    invoke-static/range {v2 .. v7}, Lc72;->q0(Ljava/lang/CharSequence;Ljava/lang/CharSequence;IIZZ)I

    move-result p0

    if-ltz p0, :cond_26

    :goto_24
    const/4 p0, 0x1

    return p0

    :cond_26
    return v1
.end method

.method public static m0(Ljava/lang/CharSequence;C)Z
    .registers 4

    .prologue
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-static {p0, p1, v1, v0}, Lc72;->r0(Ljava/lang/CharSequence;CII)I

    move-result p0

    if-ltz p0, :cond_d

    const/4 p0, 0x1

    return p0

    :cond_d
    return v1
.end method

.method public static n0(Ljava/lang/CharSequence;Ljava/lang/String;Z)Z
    .registers 11

    .prologue
    if-nez p2, :cond_e

    instance-of v0, p0, Ljava/lang/String;

    if-eqz v0, :cond_e

    check-cast p0, Ljava/lang/String;

    const/4 p2, 0x0

    invoke-static {p0, p1, p2}, Lk72;->e0(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result p0

    return p0

    :cond_e
    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    sub-int v3, v0, v1

    const/4 v5, 0x0

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v6

    move-object v2, p0

    move-object v4, p1

    move v7, p2

    invoke-static/range {v2 .. v7}, Lc72;->x0(Ljava/lang/CharSequence;ILjava/lang/CharSequence;IIZ)Z

    move-result p0

    return p0
.end method

.method public static o0(Ljava/lang/String;C)Z
    .registers 5

    .prologue
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v1, 0x0

    if-lez v0, :cond_18

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v2, 0x1

    sub-int/2addr v0, v2

    invoke-virtual {p0, v0}, Ljava/lang/String;->charAt(I)C

    move-result p0

    invoke-static {p0, p1, v1}, Lw53;->D(CCZ)Z

    move-result p0

    if-eqz p0, :cond_18

    return v2

    :cond_18
    return v1
.end method

.method public static final p0(Ljava/lang/CharSequence;Ljava/lang/String;IZ)I
    .registers 10

    .prologue
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-nez p3, :cond_14

    instance-of v0, p0, Ljava/lang/String;

    if-nez v0, :cond_d

    goto :goto_14

    :cond_d
    check-cast p0, Ljava/lang/String;

    invoke-virtual {p0, p1, p2}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result p0

    return p0

    :cond_14
    :goto_14
    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result v3

    const/4 v5, 0x0

    move-object v0, p0

    move-object v1, p1

    move v2, p2

    move v4, p3

    invoke-static/range {v0 .. v5}, Lc72;->q0(Ljava/lang/CharSequence;Ljava/lang/CharSequence;IIZZ)I

    move-result p0

    return p0
.end method

.method public static final q0(Ljava/lang/CharSequence;Ljava/lang/CharSequence;IIZZ)I
    .registers 22

    .prologue
    move-object/from16 v2, p0

    move-object/from16 v0, p1

    move/from16 v1, p2

    move/from16 v3, p3

    const/4 v6, -0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-nez p5, :cond_1d

    new-instance v7, Ljs0;

    if-gez v1, :cond_12

    move v1, v5

    :cond_12
    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    move-result v5

    if-le v3, v5, :cond_19

    move v3, v5

    :cond_19
    invoke-direct {v7, v1, v3, v4}, Lhs0;-><init>(III)V

    goto :goto_30

    :cond_1d
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    move-result v7

    sub-int/2addr v7, v4

    if-le v1, v7, :cond_28

    move v1, v7

    :cond_28
    if-gez v3, :cond_2b

    move v3, v5

    :cond_2b
    new-instance v7, Lhs0;

    invoke-direct {v7, v1, v3, v6}, Lhs0;-><init>(III)V

    :goto_30
    instance-of v1, v2, Ljava/lang/String;

    iget v8, v7, Lhs0;->c:I

    iget v9, v7, Lhs0;->b:I

    iget v3, v7, Lhs0;->a:I

    if-eqz v1, :cond_5f

    instance-of v1, v0, Ljava/lang/String;

    if-eqz v1, :cond_5f

    if-lez v8, :cond_42

    if-le v3, v9, :cond_46

    :cond_42
    if-gez v8, :cond_7d

    if-gt v9, v3, :cond_7d

    :cond_46
    move v13, v3

    :goto_47
    move-object v10, v0

    check-cast v10, Ljava/lang/String;

    move-object v12, v2

    check-cast v12, Ljava/lang/String;

    invoke-virtual {v10}, Ljava/lang/String;->length()I

    move-result v14

    const/4 v11, 0x0

    move/from16 v15, p4

    invoke-static/range {v10 .. v15}, Lk72;->g0(Ljava/lang/String;ILjava/lang/String;IIZ)Z

    move-result v1

    if-eqz v1, :cond_5b

    return v13

    :cond_5b
    if-eq v13, v9, :cond_7d

    add-int/2addr v13, v8

    goto :goto_47

    :cond_5f
    if-lez v8, :cond_63

    if-le v3, v9, :cond_67

    :cond_63
    if-gez v8, :cond_7d

    if-gt v9, v3, :cond_7d

    :cond_67
    :goto_67
    const/4 v1, 0x0

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v4

    move/from16 v5, p4

    invoke-static/range {v0 .. v5}, Lc72;->x0(Ljava/lang/CharSequence;ILjava/lang/CharSequence;IIZ)Z

    move-result v1

    if-eqz v1, :cond_75

    return v3

    :cond_75
    if-eq v3, v9, :cond_7d

    add-int/2addr v3, v8

    move-object/from16 v2, p0

    move-object/from16 v0, p1

    goto :goto_67

    :cond_7d
    return v6
.end method

.method public static r0(Ljava/lang/CharSequence;CII)I
    .registers 5

    .prologue
    and-int/lit8 p3, p3, 0x2

    const/4 v0, 0x0

    if-eqz p3, :cond_6

    move p2, v0

    :cond_6
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    instance-of p3, p0, Ljava/lang/String;

    if-nez p3, :cond_17

    const/4 p3, 0x1

    new-array p3, p3, [C

    aput-char p1, p3, v0

    invoke-static {p0, p3, p2, v0}, Lc72;->t0(Ljava/lang/CharSequence;[CIZ)I

    move-result p0

    return p0

    :cond_17
    check-cast p0, Ljava/lang/String;

    invoke-virtual {p0, p1, p2}, Ljava/lang/String;->indexOf(II)I

    move-result p0

    return p0
.end method

.method public static synthetic s0(Ljava/lang/CharSequence;Ljava/lang/String;IZI)I
    .registers 7

    .prologue
    and-int/lit8 v0, p4, 0x2

    const/4 v1, 0x0

    if-eqz v0, :cond_6

    move p2, v1

    :cond_6
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_b

    move p3, v1

    :cond_b
    invoke-static {p0, p1, p2, p3}, Lc72;->p0(Ljava/lang/CharSequence;Ljava/lang/String;IZ)I

    move-result p0

    return p0
.end method

.method public static final t0(Ljava/lang/CharSequence;[CIZ)I
    .registers 10

    .prologue
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x1

    if-nez p3, :cond_18

    array-length v1, p1

    if-ne v1, v0, :cond_18

    instance-of v1, p0, Ljava/lang/String;

    if-eqz v1, :cond_18

    invoke-static {p1}, Laf;->q0([C)C

    move-result p1

    check-cast p0, Ljava/lang/String;

    invoke-virtual {p0, p1, p2}, Ljava/lang/String;->indexOf(II)I

    move-result p0

    return p0

    :cond_18
    const/4 v1, 0x0

    if-gez p2, :cond_1c

    move p2, v1

    :cond_1c
    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result v2

    sub-int/2addr v2, v0

    if-gt p2, v2, :cond_3c

    :goto_23
    invoke-interface {p0, p2}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v0

    array-length v3, p1

    move v4, v1

    :goto_29
    if-ge v4, v3, :cond_37

    aget-char v5, p1, v4

    invoke-static {v5, v0, p3}, Lw53;->D(CCZ)Z

    move-result v5

    if-eqz v5, :cond_34

    return p2

    :cond_34
    add-int/lit8 v4, v4, 0x1

    goto :goto_29

    :cond_37
    if-eq p2, v2, :cond_3c

    add-int/lit8 p2, p2, 0x1

    goto :goto_23

    :cond_3c
    const/4 p0, -0x1

    return p0
.end method

.method public static u0(Ljava/lang/CharSequence;)Z
    .registers 4

    .prologue
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x0

    move v1, v0

    :goto_5
    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result v2

    if-ge v1, v2, :cond_19

    invoke-interface {p0, v1}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v2

    invoke-static {v2}, Lw53;->M(C)Z

    move-result v2

    if-nez v2, :cond_16

    return v0

    :cond_16
    add-int/lit8 v1, v1, 0x1

    goto :goto_5

    :cond_19
    const/4 p0, 0x1

    return p0
.end method

.method public static v0(Ljava/lang/String;IIC)I
    .registers 4

    .prologue
    and-int/lit8 p2, p2, 0x2

    if-eqz p2, :cond_a

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p1

    add-int/lit8 p1, p1, -0x1

    :cond_a
    invoke-virtual {p0, p3, p1}, Ljava/lang/String;->lastIndexOf(II)I

    move-result p0

    return p0
.end method

.method public static w0(Ljava/lang/CharSequence;)Ljava/util/List;
    .registers 3

    .prologue
    new-instance v0, Lb21;

    invoke-direct {v0, p0}, Lb21;-><init>(Ljava/lang/CharSequence;)V

    invoke-virtual {v0}, Lb21;->hasNext()Z

    move-result p0

    if-nez p0, :cond_e

    sget-object p0, Lba0;->a:Lba0;

    return-object p0

    :cond_e
    invoke-virtual {v0}, Lb21;->next()Ljava/lang/Object;

    move-result-object p0

    invoke-virtual {v0}, Lb21;->hasNext()Z

    move-result v1

    if-nez v1, :cond_1d

    invoke-static {p0}, Luz;->G(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    return-object p0

    :cond_1d
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v1, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_25
    invoke-virtual {v0}, Lb21;->hasNext()Z

    move-result p0

    if-eqz p0, :cond_33

    invoke-virtual {v0}, Lb21;->next()Ljava/lang/Object;

    move-result-object p0

    invoke-virtual {v1, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_25

    :cond_33
    return-object v1
.end method

.method public static final x0(Ljava/lang/CharSequence;ILjava/lang/CharSequence;IIZ)Z
    .registers 10

    .prologue
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x0

    if-ltz p3, :cond_35

    if-ltz p1, :cond_35

    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result v1

    sub-int/2addr v1, p4

    if-gt p1, v1, :cond_35

    invoke-interface {p2}, Ljava/lang/CharSequence;->length()I

    move-result v1

    sub-int/2addr v1, p4

    if-le p3, v1, :cond_1a

    goto :goto_35

    :cond_1a
    move v1, v0

    :goto_1b
    if-ge v1, p4, :cond_33

    add-int v2, p1, v1

    invoke-interface {p0, v2}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v2

    add-int v3, p3, v1

    invoke-interface {p2, v3}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v3

    invoke-static {v2, v3, p5}, Lw53;->D(CCZ)Z

    move-result v2

    if-nez v2, :cond_30

    return v0

    :cond_30
    add-int/lit8 v1, v1, 0x1

    goto :goto_1b

    :cond_33
    const/4 p0, 0x1

    return p0

    :cond_35
    :goto_35
    return v0
.end method

.method public static y0(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 3

    .prologue
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x0

    invoke-static {p0, p1, v0}, Lk72;->k0(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_12

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result p1

    invoke-virtual {p0, p1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    :cond_12
    return-object p0
.end method

.method public static z0(Ljava/lang/CharSequence;II)Ljava/lang/CharSequence;
    .registers 7

    .prologue
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-lt p2, p1, :cond_28

    const/4 v0, 0x0

    if-ne p2, p1, :cond_11

    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result p1

    invoke-interface {p0, v0, p1}, Ljava/lang/CharSequence;->subSequence(II)Ljava/lang/CharSequence;

    move-result-object p0

    return-object p0

    :cond_11
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result v2

    sub-int v3, p2, p1

    sub-int/2addr v2, v3

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(I)V

    invoke-virtual {v1, p0, v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result p1

    invoke-virtual {v1, p0, p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    return-object v1

    :cond_28
    const-string p0, ") is less than start index ("

    const-string v0, ")."

    const-string v1, "End index ("

    invoke-static {p2, p1, v1, p0, v0}, Lc33;->j(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lvx2;->n(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0
.end method
