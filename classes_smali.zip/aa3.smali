.class public final Laa3;
.super Lcom/google/android/gms/common/moduleinstall/internal/zaa;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/google/android/gms/tasks/TaskCompletionSource;


# direct methods
.method public synthetic constructor <init>(ILcom/google/android/gms/tasks/TaskCompletionSource;)V
    .registers 3

    iput p1, p0, Laa3;->a:I

    iput-object p2, p0, Laa3;->b:Lcom/google/android/gms/tasks/TaskCompletionSource;

    invoke-direct {p0}, Lcom/google/android/gms/common/moduleinstall/internal/zaa;-><init>()V

    return-void
.end method


# virtual methods
.method public zab(Lcom/google/android/gms/common/api/Status;)V
    .registers 3

    .prologue
    iget v0, p0, Laa3;->a:I

    packed-switch v0, :pswitch_data_10

    invoke-super {p0, p1}, Lcom/google/android/gms/common/moduleinstall/internal/zaa;->zab(Lcom/google/android/gms/common/api/Status;)V

    return-void

    :pswitch_9  #0x1
    const/4 v0, 0x0

    iget-object p0, p0, Laa3;->b:Lcom/google/android/gms/tasks/TaskCompletionSource;

    invoke-static {p1, v0, p0}, Lcom/google/android/gms/common/api/internal/TaskUtil;->trySetResultOrApiException(Lcom/google/android/gms/common/api/Status;Ljava/lang/Object;Lcom/google/android/gms/tasks/TaskCompletionSource;)Z

    return-void

    :pswitch_data_10
    .packed-switch 0x1
        :pswitch_9  #00000001
    .end packed-switch
.end method

.method public zac(Lcom/google/android/gms/common/api/Status;Lcom/google/android/gms/common/moduleinstall/ModuleInstallIntentResponse;)V
    .registers 4

    .prologue
    iget v0, p0, Laa3;->a:I

    packed-switch v0, :pswitch_data_10

    invoke-super {p0, p1, p2}, Lcom/google/android/gms/common/moduleinstall/internal/zaa;->zac(Lcom/google/android/gms/common/api/Status;Lcom/google/android/gms/common/moduleinstall/ModuleInstallIntentResponse;)V

    return-void

    :pswitch_9  #0x3
    iget-object p0, p0, Laa3;->b:Lcom/google/android/gms/tasks/TaskCompletionSource;

    invoke-static {p1, p2, p0}, Lcom/google/android/gms/common/api/internal/TaskUtil;->trySetResultOrApiException(Lcom/google/android/gms/common/api/Status;Ljava/lang/Object;Lcom/google/android/gms/tasks/TaskCompletionSource;)Z

    return-void

    nop

    :pswitch_data_10
    .packed-switch 0x3
        :pswitch_9  #00000003
    .end packed-switch
.end method

.method public zad(Lcom/google/android/gms/common/api/Status;Lcom/google/android/gms/common/moduleinstall/ModuleInstallResponse;)V
    .registers 4

    .prologue
    iget v0, p0, Laa3;->a:I

    packed-switch v0, :pswitch_data_10

    invoke-super {p0, p1, p2}, Lcom/google/android/gms/common/moduleinstall/internal/zaa;->zad(Lcom/google/android/gms/common/api/Status;Lcom/google/android/gms/common/moduleinstall/ModuleInstallResponse;)V

    return-void

    :pswitch_9  #0x2
    iget-object p0, p0, Laa3;->b:Lcom/google/android/gms/tasks/TaskCompletionSource;

    invoke-static {p1, p2, p0}, Lcom/google/android/gms/common/api/internal/TaskUtil;->trySetResultOrApiException(Lcom/google/android/gms/common/api/Status;Ljava/lang/Object;Lcom/google/android/gms/tasks/TaskCompletionSource;)Z

    return-void

    nop

    :pswitch_data_10
    .packed-switch 0x2
        :pswitch_9  #00000002
    .end packed-switch
.end method

.method public zae(Lcom/google/android/gms/common/api/Status;Lcom/google/android/gms/common/moduleinstall/ModuleAvailabilityResponse;)V
    .registers 4

    .prologue
    iget v0, p0, Laa3;->a:I

    packed-switch v0, :pswitch_data_10

    invoke-super {p0, p1, p2}, Lcom/google/android/gms/common/moduleinstall/internal/zaa;->zae(Lcom/google/android/gms/common/api/Status;Lcom/google/android/gms/common/moduleinstall/ModuleAvailabilityResponse;)V

    return-void

    :pswitch_9  #0x0
    iget-object p0, p0, Laa3;->b:Lcom/google/android/gms/tasks/TaskCompletionSource;

    invoke-static {p1, p2, p0}, Lcom/google/android/gms/common/api/internal/TaskUtil;->trySetResultOrApiException(Lcom/google/android/gms/common/api/Status;Ljava/lang/Object;Lcom/google/android/gms/tasks/TaskCompletionSource;)Z

    return-void

    nop

    :pswitch_data_10
    .packed-switch 0x0
        :pswitch_9  #00000000
    .end packed-switch
.end method
