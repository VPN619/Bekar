.class public abstract synthetic La9;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# direct methods
.method public static synthetic a()Landroid/adservices/topics/GetTopicsRequest$Builder;
    .registers 1

    new-instance v0, Landroid/adservices/topics/GetTopicsRequest$Builder;

    invoke-direct {v0}, Landroid/adservices/topics/GetTopicsRequest$Builder;-><init>()V

    return-object v0
.end method

.method public static synthetic b(Landroid/content/Context;)Landroid/net/http/HttpEngine$Builder;
    .registers 2

    new-instance v0, Landroid/net/http/HttpEngine$Builder;

    invoke-direct {v0, p0}, Landroid/net/http/HttpEngine$Builder;-><init>(Landroid/content/Context;)V

    return-object v0
.end method

.method public static synthetic c()V
    .registers 1

    new-instance v0, Landroid/net/http/HttpEngine$Builder;

    return-void
.end method
