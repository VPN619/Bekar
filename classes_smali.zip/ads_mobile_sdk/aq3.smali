.class public final Lads_mobile_sdk/aq3;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lia3;


# instance fields
.field public final a:Lads_mobile_sdk/yq3;

.field public final b:Lads_mobile_sdk/qr0;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/yq3;Lads_mobile_sdk/qr0;)V
    .registers 3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/aq3;->a:Lads_mobile_sdk/yq3;

    iput-object p2, p0, Lads_mobile_sdk/aq3;->b:Lads_mobile_sdk/qr0;

    return-void
.end method


# virtual methods
.method public final b(Lvx;)Ljava/lang/Object;
    .registers 5

    .prologue
    iget-object p1, p0, Lads_mobile_sdk/aq3;->b:Lads_mobile_sdk/qr0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sget-object v1, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    const-string v2, "gads:webview_optimize_profile:enabled"

    invoke-virtual {p1, v2, v0, v1}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_31

    iget-object p0, p0, Lads_mobile_sdk/aq3;->a:Lads_mobile_sdk/yq3;

    iget-object p1, p0, Lads_mobile_sdk/yq3;->e:Lvy;

    new-instance v0, Lto;

    const/16 v1, 0x13

    const/4 v2, 0x0

    invoke-direct {v0, p0, v2, v1}, Lto;-><init>(Ljava/lang/Object;Lvx;I)V

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance p0, La42;

    invoke-direct {p0, v0, v2}, La42;-><init>(Lpk0;Lvx;)V

    const/4 v0, 0x2

    sget-object v1, Ly90;->a:Ly90;

    invoke-static {p1, v1, v2, p0, v0}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    :cond_31
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method
