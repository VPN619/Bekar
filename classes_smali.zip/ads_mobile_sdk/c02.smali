.class public final Lads_mobile_sdk/c02;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lgt2;


# instance fields
.field public final a:Ljava/lang/Object;

.field public final synthetic b:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/a02;)V
    .registers 3

    const/4 v0, 0x0

    iput v0, p0, Lads_mobile_sdk/c02;->b:I

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/c02;->a:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lqx2;)V
    .registers 3

    const/4 v0, 0x1

    iput v0, p0, Lads_mobile_sdk/c02;->b:I

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/c02;->a:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final a(Lvx;)Ljava/lang/Object;
    .registers 5

    .prologue
    iget v0, p0, Lads_mobile_sdk/c02;->b:I

    sget-object v1, Lrg2;->a:Lrg2;

    sget-object v2, Lwy;->a:Lwy;

    iget-object p0, p0, Lads_mobile_sdk/c02;->a:Ljava/lang/Object;

    packed-switch v0, :pswitch_data_26

    check-cast p0, Lqx2;

    check-cast p1, Lm82;

    invoke-interface {p0, p1}, Lqx2;->a(Lm82;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v2, :cond_16

    move-object v1, p0

    :cond_16
    return-object v1

    :pswitch_17  #0x0
    check-cast p0, Lads_mobile_sdk/a02;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p1, Lwx;

    invoke-static {p0, p1}, Lads_mobile_sdk/a02;->b(Lads_mobile_sdk/a02;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v2, :cond_25

    move-object v1, p0

    :cond_25
    return-object v1

    :pswitch_data_26
    .packed-switch 0x0
        :pswitch_17  #00000000
    .end packed-switch
.end method
