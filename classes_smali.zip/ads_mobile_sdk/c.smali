.class public final Lads_mobile_sdk/c;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lw03;


# instance fields
.field public final a:[B


# direct methods
.method public constructor <init>([BI)V
    .registers 8

    .prologue
    packed-switch p2, :pswitch_data_38

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 p2, 0x100

    new-array v0, p2, [B

    iput-object v0, p0, Lads_mobile_sdk/c;->a:[B

    const/4 v0, 0x0

    move v1, v0

    :goto_e
    if-ge v1, p2, :cond_18

    iget-object v2, p0, Lads_mobile_sdk/c;->a:[B

    int-to-byte v3, v1

    aput-byte v3, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_e

    :cond_18
    move v1, v0

    :goto_19
    if-ge v0, p2, :cond_31

    iget-object v2, p0, Lads_mobile_sdk/c;->a:[B

    aget-byte v3, v2, v0

    add-int/2addr v1, v3

    array-length v4, p1

    rem-int v4, v0, v4

    aget-byte v4, p1, v4

    add-int/2addr v1, v4

    and-int/lit16 v1, v1, 0xff

    aget-byte v4, v2, v1

    aput-byte v4, v2, v0

    aput-byte v3, v2, v1

    add-int/lit8 v0, v0, 0x1

    goto :goto_19

    :cond_31
    return-void

    :pswitch_32  #0x1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/c;->a:[B

    return-void

    :pswitch_data_38
    .packed-switch 0x1
        :pswitch_32  #00000001
    .end packed-switch
.end method


# virtual methods
.method public a()Ljava/lang/Object;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/c;->a:[B

    return-object p0
.end method

.method public a(Ljava/io/FileInputStream;)Ljava/lang/Object;
    .registers 3

    .prologue
    :try_start_0
    invoke-static {p1}, Lol;->b(Ljava/io/FileInputStream;)[B

    move-result-object p0
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_4} :catch_5

    return-object p0

    :catch_5
    move-exception p0

    new-instance p1, Lb03;

    const-string v0, "Cannot read bytes."

    invoke-direct {p1, v0, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw p1
.end method

.method public a(Ljava/lang/Object;Ljava/io/FileOutputStream;)V
    .registers 3

    check-cast p1, [B

    invoke-virtual {p2, p1}, Ljava/io/OutputStream;->write([B)V

    return-void
.end method
