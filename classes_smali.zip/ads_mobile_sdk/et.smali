.class public final Lads_mobile_sdk/et;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lnt2;


# instance fields
.field public final a:Ltv2;

.field public final b:Lads_mobile_sdk/ah0;

.field public final c:Ltv2;

.field public final d:Ltv2;

.field public final e:Lads_mobile_sdk/ob1;

.field public final synthetic f:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/ob1;Ltv2;Lads_mobile_sdk/ah0;Ltv2;Ltv2;)V
    .registers 7

    const/4 v0, 0x1

    iput v0, p0, Lads_mobile_sdk/et;->f:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/et;->e:Lads_mobile_sdk/ob1;

    iput-object p2, p0, Lads_mobile_sdk/et;->a:Ltv2;

    iput-object p3, p0, Lads_mobile_sdk/et;->b:Lads_mobile_sdk/ah0;

    iput-object p4, p0, Lads_mobile_sdk/et;->c:Ltv2;

    iput-object p5, p0, Lads_mobile_sdk/et;->d:Ltv2;

    return-void
.end method

.method public synthetic constructor <init>(Ltv2;Lads_mobile_sdk/ah0;Ltv2;Ltv2;Lads_mobile_sdk/ob1;I)V
    .registers 7

    iput p6, p0, Lads_mobile_sdk/et;->f:I

    iput-object p1, p0, Lads_mobile_sdk/et;->a:Ltv2;

    iput-object p2, p0, Lads_mobile_sdk/et;->b:Lads_mobile_sdk/ah0;

    iput-object p3, p0, Lads_mobile_sdk/et;->c:Ltv2;

    iput-object p4, p0, Lads_mobile_sdk/et;->d:Ltv2;

    iput-object p5, p0, Lads_mobile_sdk/et;->e:Lads_mobile_sdk/ob1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 13

    .prologue
    iget v0, p0, Lads_mobile_sdk/et;->f:I

    iget-object v1, p0, Lads_mobile_sdk/et;->e:Lads_mobile_sdk/ob1;

    iget-object v2, p0, Lads_mobile_sdk/et;->d:Ltv2;

    iget-object v3, p0, Lads_mobile_sdk/et;->c:Ltv2;

    iget-object v4, p0, Lads_mobile_sdk/et;->b:Lads_mobile_sdk/ah0;

    iget-object p0, p0, Lads_mobile_sdk/et;->a:Ltv2;

    packed-switch v0, :pswitch_data_96

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v6, p0

    check-cast v6, Lads_mobile_sdk/u92;

    invoke-virtual {v4}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v7, p0

    check-cast v7, Lads_mobile_sdk/ah3;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v8, p0

    check-cast v8, Lads_mobile_sdk/qr0;

    new-instance p0, Llm0;

    invoke-direct {p0}, Llm0;-><init>()V

    new-instance v0, Lcom/google/android/libraries/ads/mobile/sdk/internal/util/AndroidBundleTypeAdapterFactory;

    invoke-direct {v0}, Lcom/google/android/libraries/ads/mobile/sdk/internal/util/AndroidBundleTypeAdapterFactory;-><init>()V

    invoke-virtual {p0, v0}, Llm0;->c(Lcom/google/android/libraries/ads/mobile/sdk/internal/util/AndroidBundleTypeAdapterFactory;)V

    new-instance v9, Lkm0;

    invoke-direct {v9, p0}, Lkm0;-><init>(Llm0;)V

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v10, p0

    check-cast v10, Lads_mobile_sdk/zv1;

    iget-object p0, v1, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v11, p0

    check-cast v11, Landroid/content/Context;

    new-instance v5, Lads_mobile_sdk/x92;

    invoke-direct/range {v5 .. v11}, Lads_mobile_sdk/x92;-><init>(Lads_mobile_sdk/u92;Lads_mobile_sdk/ah3;Lads_mobile_sdk/qr0;Lkm0;Lads_mobile_sdk/zv1;Landroid/content/Context;)V

    return-object v5

    :pswitch_48  #0x1
    iget-object v0, v1, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v6, v0

    check-cast v6, Landroid/content/Context;

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v7, p0

    check-cast v7, Ljava/lang/String;

    invoke-virtual {v4}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v8, p0

    check-cast v8, Lads_mobile_sdk/vz;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v9, p0

    check-cast v9, Lads_mobile_sdk/ax0;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v10, p0

    check-cast v10, Lads_mobile_sdk/qr0;

    new-instance v5, Lads_mobile_sdk/zm1;

    invoke-direct/range {v5 .. v10}, Lads_mobile_sdk/zm1;-><init>(Landroid/content/Context;Ljava/lang/String;Lads_mobile_sdk/vz;Lads_mobile_sdk/ax0;Lads_mobile_sdk/qr0;)V

    return-object v5

    :pswitch_6f  #0x0
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v6, p0

    check-cast v6, Lads_mobile_sdk/k8;

    invoke-virtual {v4}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v7, p0

    check-cast v7, Lads_mobile_sdk/z2;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v8, p0

    check-cast v8, Lads_mobile_sdk/dl;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v9, p0

    check-cast v9, Lads_mobile_sdk/gn0;

    iget-object p0, v1, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v10, p0

    check-cast v10, Lads_mobile_sdk/a2;

    new-instance v5, Lads_mobile_sdk/dt;

    invoke-direct/range {v5 .. v10}, Lads_mobile_sdk/dt;-><init>(Lads_mobile_sdk/k8;Lads_mobile_sdk/z2;Lads_mobile_sdk/dl;Lads_mobile_sdk/gn0;Lads_mobile_sdk/a2;)V

    return-object v5

    :pswitch_data_96
    .packed-switch 0x0
        :pswitch_6f  #00000000
        :pswitch_48  #00000001
    .end packed-switch
.end method
