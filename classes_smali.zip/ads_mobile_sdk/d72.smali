.class public final Lads_mobile_sdk/d72;
.super Lwx;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public a:Lads_mobile_sdk/f72;

.field public b:Ljava/lang/Object;

.field public c:Ljava/lang/Object;

.field public d:Z

.field public synthetic e:Ljava/lang/Object;

.field public final synthetic f:Lads_mobile_sdk/f72;

.field public g:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/f72;Lwx;)V
    .registers 3

    iput-object p1, p0, Lads_mobile_sdk/d72;->f:Lads_mobile_sdk/f72;

    invoke-direct {p0, p2}, Lwx;-><init>(Lvx;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    iput-object p1, p0, Lads_mobile_sdk/d72;->e:Ljava/lang/Object;

    iget p1, p0, Lads_mobile_sdk/d72;->g:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, Lads_mobile_sdk/d72;->g:I

    const/4 p1, 0x0

    const/4 v0, 0x0

    iget-object v1, p0, Lads_mobile_sdk/d72;->f:Lads_mobile_sdk/f72;

    invoke-static {v1, p1, v0, p0}, Lads_mobile_sdk/f72;->a(Lads_mobile_sdk/f72;Lads_mobile_sdk/cy0;ZLwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
