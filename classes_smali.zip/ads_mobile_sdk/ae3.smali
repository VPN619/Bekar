.class public final Lads_mobile_sdk/ae3;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Lvy;

.field public final b:Lads_mobile_sdk/a2;

.field public final c:Lads_mobile_sdk/z2;

.field public final d:Ly43;

.field public final e:Lyx2;

.field public final f:Ljava/util/Optional;

.field public volatile g:Lx52;


# direct methods
.method public constructor <init>(Lvy;Lads_mobile_sdk/a2;Lads_mobile_sdk/z2;Ly43;Lyx2;Ljava/util/Optional;)V
    .registers 7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/ae3;->a:Lvy;

    iput-object p2, p0, Lads_mobile_sdk/ae3;->b:Lads_mobile_sdk/a2;

    iput-object p3, p0, Lads_mobile_sdk/ae3;->c:Lads_mobile_sdk/z2;

    iput-object p4, p0, Lads_mobile_sdk/ae3;->d:Ly43;

    iput-object p5, p0, Lads_mobile_sdk/ae3;->e:Lyx2;

    iput-object p6, p0, Lads_mobile_sdk/ae3;->f:Ljava/util/Optional;

    return-void
.end method
