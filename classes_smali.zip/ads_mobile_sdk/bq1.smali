.class public final Lads_mobile_sdk/bq1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:Lvy;

.field public final c:Lads_mobile_sdk/g0;

.field public final d:Lads_mobile_sdk/kj0;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lvy;Lads_mobile_sdk/g0;Lads_mobile_sdk/kj0;)V
    .registers 5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/bq1;->a:Landroid/content/Context;

    iput-object p2, p0, Lads_mobile_sdk/bq1;->b:Lvy;

    iput-object p3, p0, Lads_mobile_sdk/bq1;->c:Lads_mobile_sdk/g0;

    iput-object p4, p0, Lads_mobile_sdk/bq1;->d:Lads_mobile_sdk/kj0;

    return-void
.end method

.method public static a(Lads_mobile_sdk/cy0;IIIILads_mobile_sdk/nr1;)Ljava/lang/Object;
    .registers 8

    .prologue
    new-instance v0, Lfx0;

    invoke-direct {v0}, Lfx0;-><init>()V

    new-instance v1, Ljava/lang/Integer;

    invoke-direct {v1, p1}, Ljava/lang/Integer;-><init>(I)V

    const-string p1, "x"

    invoke-virtual {v0, v1, p1}, Lfx0;->q(Ljava/lang/Number;Ljava/lang/String;)V

    new-instance p1, Ljava/lang/Integer;

    invoke-direct {p1, p2}, Ljava/lang/Integer;-><init>(I)V

    const-string p2, "y"

    invoke-virtual {v0, p1, p2}, Lfx0;->q(Ljava/lang/Number;Ljava/lang/String;)V

    new-instance p1, Ljava/lang/Integer;

    invoke-direct {p1, p3}, Ljava/lang/Integer;-><init>(I)V

    const-string p2, "width"

    invoke-virtual {v0, p1, p2}, Lfx0;->q(Ljava/lang/Number;Ljava/lang/String;)V

    new-instance p1, Ljava/lang/Integer;

    invoke-direct {p1, p4}, Ljava/lang/Integer;-><init>(I)V

    const-string p2, "height"

    invoke-virtual {v0, p1, p2}, Lfx0;->q(Ljava/lang/Number;Ljava/lang/String;)V

    const-string p1, "onSizeChanged"

    invoke-virtual {p0, v0, p1, p5}, Lads_mobile_sdk/cy0;->a(Lfx0;Ljava/lang/String;Lvx;)Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lwy;->a:Lwy;

    if-ne p0, p1, :cond_38

    return-object p0

    :cond_38
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method

.method public static a(Lads_mobile_sdk/cy0;Ljava/lang/String;Ljava/lang/String;Lm82;)Ljava/lang/Object;
    .registers 6

    .prologue
    new-instance v0, Lfx0;

    invoke-direct {v0}, Lfx0;-><init>()V

    const-string v1, "action"

    invoke-virtual {v0, v1, p2}, Lfx0;->s(Ljava/lang/String;Ljava/lang/String;)V

    const-string p2, "message"

    invoke-virtual {v0, p2, p1}, Lfx0;->s(Ljava/lang/String;Ljava/lang/String;)V

    const-string p1, "onError"

    invoke-virtual {p0, v0, p1, p3}, Lads_mobile_sdk/cy0;->a(Lfx0;Ljava/lang/String;Lvx;)Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lwy;->a:Lwy;

    if-ne p0, p1, :cond_1a

    return-object p0

    :cond_1a
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method


# virtual methods
.method public final a(Lads_mobile_sdk/cy0;)V
    .registers 11

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/bq1;->d:Lads_mobile_sdk/kj0;

    iget-object v1, p0, Lads_mobile_sdk/bq1;->a:Landroid/content/Context;

    invoke-virtual {v0, v1}, Lads_mobile_sdk/kj0;->c(Landroid/content/Context;)Landroid/content/Context;

    move-result-object v2

    invoke-virtual {v0, v1}, Lads_mobile_sdk/kj0;->a(Landroid/content/Context;)Landroid/view/Display;

    move-result-object v0

    const/4 v1, 0x0

    if-nez v0, :cond_15

    const-string p0, "Unable to get Display in MraidAfmaDispatcher"

    invoke-static {p0, v1}, Lads_mobile_sdk/nw;->b(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void

    :cond_15
    invoke-virtual {v0}, Landroid/view/Display;->getRotation()I

    move-result v0

    invoke-static {v2}, Lt12;->h(Landroid/content/Context;)Landroid/util/DisplayMetrics;

    move-result-object v3

    iget v4, v3, Landroid/util/DisplayMetrics;->density:F

    iget v5, v3, Landroid/util/DisplayMetrics;->widthPixels:I

    int-to-float v5, v5

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    invoke-virtual {v6}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget v6, v6, Landroid/util/DisplayMetrics;->density:F

    div-float/2addr v5, v6

    invoke-static {v5}, Lsz;->K(F)I

    move-result v5

    iget v3, v3, Landroid/util/DisplayMetrics;->heightPixels:I

    int-to-float v3, v3

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget v2, v2, Landroid/util/DisplayMetrics;->density:F

    div-float/2addr v3, v2

    invoke-static {v3}, Lsz;->K(F)I

    move-result v2

    iget-object v3, p0, Lads_mobile_sdk/bq1;->c:Lads_mobile_sdk/g0;

    invoke-virtual {v3}, Lads_mobile_sdk/g0;->b()Landroid/app/Activity;

    move-result-object v3

    if-eqz v3, :cond_56

    invoke-static {v3}, Lt12;->k(Landroid/app/Activity;)Ldj1;

    move-result-object v3

    goto :goto_65

    :cond_56
    new-instance v3, Ldj1;

    new-instance v6, Ljava/lang/Integer;

    invoke-direct {v6, v5}, Ljava/lang/Integer;-><init>(I)V

    new-instance v7, Ljava/lang/Integer;

    invoke-direct {v7, v2}, Ljava/lang/Integer;-><init>(I)V

    invoke-direct {v3, v6, v7}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    :goto_65
    iget-object v6, v3, Ldj1;->a:Ljava/lang/Object;

    check-cast v6, Ljava/lang/Number;

    invoke-virtual {v6}, Ljava/lang/Number;->intValue()I

    move-result v6

    iget-object v3, v3, Ldj1;->b:Ljava/lang/Object;

    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    move-result v3

    new-instance v7, Lfx0;

    invoke-direct {v7}, Lfx0;-><init>()V

    new-instance v8, Ljava/lang/Integer;

    invoke-direct {v8, v5}, Ljava/lang/Integer;-><init>(I)V

    const-string v5, "width"

    invoke-virtual {v7, v8, v5}, Lfx0;->q(Ljava/lang/Number;Ljava/lang/String;)V

    new-instance v5, Ljava/lang/Integer;

    invoke-direct {v5, v2}, Ljava/lang/Integer;-><init>(I)V

    const-string v2, "height"

    invoke-virtual {v7, v5, v2}, Lfx0;->q(Ljava/lang/Number;Ljava/lang/String;)V

    new-instance v2, Ljava/lang/Integer;

    invoke-direct {v2, v6}, Ljava/lang/Integer;-><init>(I)V

    const-string v5, "maxSizeWidth"

    invoke-virtual {v7, v2, v5}, Lfx0;->q(Ljava/lang/Number;Ljava/lang/String;)V

    new-instance v2, Ljava/lang/Integer;

    invoke-direct {v2, v3}, Ljava/lang/Integer;-><init>(I)V

    const-string v3, "maxSizeHeight"

    invoke-virtual {v7, v2, v3}, Lfx0;->q(Ljava/lang/Number;Ljava/lang/String;)V

    float-to-double v2, v4

    new-instance v4, Ljava/lang/Double;

    invoke-direct {v4, v2, v3}, Ljava/lang/Double;-><init>(D)V

    const-string v2, "density"

    invoke-virtual {v7, v4, v2}, Lfx0;->q(Ljava/lang/Number;Ljava/lang/String;)V

    new-instance v2, Ljava/lang/Integer;

    invoke-direct {v2, v0}, Ljava/lang/Integer;-><init>(I)V

    const-string v0, "rotation"

    invoke-virtual {v7, v2, v0}, Lfx0;->q(Ljava/lang/Number;Ljava/lang/String;)V

    new-instance v0, Lads_mobile_sdk/aq1;

    const/4 v2, 0x0

    invoke-direct {v0, p1, v7, v1, v2}, Lads_mobile_sdk/aq1;-><init>(Lads_mobile_sdk/cy0;Lfx0;Lvx;I)V

    const/4 p1, 0x3

    iget-object p0, p0, Lads_mobile_sdk/bq1;->b:Lvy;

    invoke-static {p0, v1, v1, v0, p1}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    return-void
.end method
