.class public final Lads_mobile_sdk/dl0;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:J

.field public final d:I


# direct methods
.method public constructor <init>(IJLjava/lang/String;)V
    .registers 6

    sget-object v0, Landroid/os/Build;->MODEL:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p4, p0, Lads_mobile_sdk/dl0;->a:Ljava/lang/String;

    iput-wide p2, p0, Lads_mobile_sdk/dl0;->b:J

    iput p1, p0, Lads_mobile_sdk/dl0;->d:I

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .prologue
    if-ne p0, p1, :cond_3

    goto :goto_2f

    :cond_3
    instance-of v0, p1, Lads_mobile_sdk/dl0;

    if-nez v0, :cond_8

    goto :goto_2d

    :cond_8
    check-cast p1, Lads_mobile_sdk/dl0;

    iget-object v0, p0, Lads_mobile_sdk/dl0;->a:Ljava/lang/String;

    iget-object v1, p1, Lads_mobile_sdk/dl0;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_15

    goto :goto_2d

    :cond_15
    iget-wide v0, p0, Lads_mobile_sdk/dl0;->b:J

    iget-wide v2, p1, Lads_mobile_sdk/dl0;->b:J

    cmp-long v0, v0, v2

    if-eqz v0, :cond_1e

    goto :goto_2d

    :cond_1e
    sget-object v0, Landroid/os/Build;->MODEL:Ljava/lang/String;

    invoke-static {v0, v0}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_27

    goto :goto_2d

    :cond_27
    iget p0, p0, Lads_mobile_sdk/dl0;->d:I

    iget p1, p1, Lads_mobile_sdk/dl0;->d:I

    if-eq p0, p1, :cond_2f

    :goto_2d
    const/4 p0, 0x0

    return p0

    :cond_2f
    :goto_2f
    const/4 p0, 0x1

    return p0
.end method

.method public final hashCode()I
    .registers 5

    iget-object v0, p0, Lads_mobile_sdk/dl0;->a:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/16 v1, 0x1f

    mul-int/2addr v0, v1

    iget-wide v2, p0, Lads_mobile_sdk/dl0;->b:J

    invoke-static {v0, v1, v2, v3}, Ly41;->i(IIJ)I

    move-result v0

    sget-object v1, Landroid/os/Build;->MODEL:Ljava/lang/String;

    invoke-static {v1, v0}, Luz;->e(Ljava/lang/String;I)I

    move-result v0

    iget p0, p0, Lads_mobile_sdk/dl0;->d:I

    invoke-static {p0}, Ljava/lang/Integer;->hashCode(I)I

    move-result p0

    add-int/2addr p0, v0

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 5

    sget-object v0, Landroid/os/Build;->MODEL:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "EnvironmentData(packageName="

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Lads_mobile_sdk/dl0;->a:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ", versionCode="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v2, p0, Lads_mobile_sdk/dl0;->b:J

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v2, ", deviceModel="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ", apiVersion="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget p0, p0, Lads_mobile_sdk/dl0;->d:I

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
