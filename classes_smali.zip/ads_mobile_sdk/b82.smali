.class public final Lads_mobile_sdk/b82;
.super Lpb;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lvz2;


# instance fields
.field public final c:Lvy;

.field public final d:Lfx0;

.field public final e:Lads_mobile_sdk/a2;

.field public final f:Lads_mobile_sdk/s52;

.field public final g:Lads_mobile_sdk/it1;

.field public final h:Lads_mobile_sdk/jz2;

.field public final i:Lnb1;

.field public j:Lx52;

.field public k:Lads_mobile_sdk/cy0;

.field public l:Lads_mobile_sdk/q6;

.field public final m:Z

.field public final n:Ljava/util/List;


# direct methods
.method public constructor <init>(Lly;Lvy;Lfx0;Lads_mobile_sdk/a2;Lads_mobile_sdk/s52;Lads_mobile_sdk/it1;Lads_mobile_sdk/qr0;Lads_mobile_sdk/jz2;)V
    .registers 9

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0, p7, p1}, Lpb;-><init>(Lads_mobile_sdk/qr0;Lly;)V

    iput-object p2, p0, Lads_mobile_sdk/b82;->c:Lvy;

    iput-object p3, p0, Lads_mobile_sdk/b82;->d:Lfx0;

    iput-object p4, p0, Lads_mobile_sdk/b82;->e:Lads_mobile_sdk/a2;

    iput-object p5, p0, Lads_mobile_sdk/b82;->f:Lads_mobile_sdk/s52;

    iput-object p6, p0, Lads_mobile_sdk/b82;->g:Lads_mobile_sdk/it1;

    iput-object p8, p0, Lads_mobile_sdk/b82;->h:Lads_mobile_sdk/jz2;

    new-instance p1, Lnb1;

    invoke-direct {p1}, Lnb1;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/b82;->i:Lnb1;

    iget-object p1, p6, Lads_mobile_sdk/it1;->n:Lads_mobile_sdk/j82;

    const/4 p2, 0x0

    if-eqz p1, :cond_36

    iget p1, p1, Lads_mobile_sdk/j82;->a:I

    goto :goto_37

    :cond_36
    move p1, p2

    :goto_37
    const/4 p3, 0x1

    if-ne p1, p3, :cond_3b

    move p2, p3

    :cond_3b
    iput-boolean p2, p0, Lads_mobile_sdk/b82;->m:Z

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    invoke-static {p1}, Ljava/util/Collections;->synchronizedList(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, Lads_mobile_sdk/b82;->n:Ljava/util/List;

    return-void
.end method

.method public static b(Lads_mobile_sdk/b82;Lwx;)Ljava/lang/Object;
    .registers 13

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/s72;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/s72;

    iget v1, v0, Lads_mobile_sdk/s72;->e:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/s72;->e:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/s72;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/s72;-><init>(Lads_mobile_sdk/b82;Lwx;)V

    :goto_18
    iget-object p1, v0, Lads_mobile_sdk/s72;->c:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/s72;->e:I

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    sget-object v7, Lwy;->a:Lwy;

    if-eqz v1, :cond_5a

    if-eq v1, v5, :cond_50

    if-eq v1, v4, :cond_48

    if-eq v1, v3, :cond_3f

    if-ne v1, v2, :cond_39

    iget-object p0, v0, Lads_mobile_sdk/s72;->b:Llb1;

    iget-object v0, v0, Lads_mobile_sdk/s72;->a:Lads_mobile_sdk/b82;

    :try_start_31
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_34
    .catchall {:try_start_31 .. :try_end_34} :catchall_36

    goto/16 :goto_e3

    :catchall_36
    move-exception p1

    goto/16 :goto_ef

    :cond_39
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v6

    :cond_3f
    iget-object p0, v0, Lads_mobile_sdk/s72;->b:Llb1;

    iget-object v1, v0, Lads_mobile_sdk/s72;->a:Lads_mobile_sdk/b82;

    :try_start_43
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_46
    .catchall {:try_start_43 .. :try_end_46} :catchall_36

    goto/16 :goto_d1

    :cond_48
    iget-object p0, v0, Lads_mobile_sdk/s72;->b:Llb1;

    iget-object v1, v0, Lads_mobile_sdk/s72;->a:Lads_mobile_sdk/b82;

    :try_start_4c
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_4f
    .catchall {:try_start_4c .. :try_end_4f} :catchall_36

    goto :goto_a0

    :cond_50
    iget-object p0, v0, Lads_mobile_sdk/s72;->b:Llb1;

    iget-object v1, v0, Lads_mobile_sdk/s72;->a:Lads_mobile_sdk/b82;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    move-object p1, p0

    move-object p0, v1

    goto :goto_6d

    :cond_5a
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/b82;->i:Lnb1;

    iput-object p0, v0, Lads_mobile_sdk/s72;->a:Lads_mobile_sdk/b82;

    iput-object p1, v0, Lads_mobile_sdk/s72;->b:Llb1;

    iput v5, v0, Lads_mobile_sdk/s72;->e:I

    invoke-virtual {p1, v0}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v7, :cond_6d

    goto/16 :goto_e1

    :cond_6d
    :goto_6d
    :try_start_6d
    iget-object v1, p0, Lads_mobile_sdk/b82;->j:Lx52;

    if-eqz v1, :cond_74

    invoke-virtual {v1, v6}, Lnv0;->a(Ljava/util/concurrent/CancellationException;)V

    :cond_74
    iget-object v1, p0, Lads_mobile_sdk/b82;->g:Lads_mobile_sdk/it1;

    iget-object v1, v1, Lads_mobile_sdk/it1;->o:Lu20;

    if-eqz v1, :cond_7d

    invoke-interface {v1, v6}, Lfv0;->a(Ljava/util/concurrent/CancellationException;)V

    :cond_7d
    iget-object v1, p0, Lads_mobile_sdk/b82;->n:Ljava/util/List;

    invoke-interface {v1}, Ljava/util/List;->clear()V

    iget-object v1, p0, Lads_mobile_sdk/b82;->l:Lads_mobile_sdk/q6;

    if-eqz v1, :cond_cf

    iget-object v5, p0, Lpb;->b:Ljava/lang/Object;

    check-cast v5, Lly;

    new-instance v8, Lb11;

    const/16 v9, 0x1a

    invoke-direct {v8, p0, v1, v6, v9}, Lb11;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lvx;I)V

    iput-object p0, v0, Lads_mobile_sdk/s72;->a:Lads_mobile_sdk/b82;

    iput-object p1, v0, Lads_mobile_sdk/s72;->b:Llb1;

    iput v4, v0, Lads_mobile_sdk/s72;->e:I

    invoke-static {v5, v8, v0}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object v1
    :try_end_9b
    .catchall {:try_start_6d .. :try_end_9b} :catchall_cd

    if-ne v1, v7, :cond_9e

    goto :goto_e1

    :cond_9e
    move-object v1, p0

    move-object p0, p1

    :goto_a0
    :try_start_a0
    iget-object p1, v1, Lpb;->a:Ljava/lang/Object;

    check-cast p1, Lads_mobile_sdk/qr0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v5, "gads:omid:destroy_webview_delay"

    sget-object v8, Lv60;->b:Lp80;

    sget-object v8, Ly60;->e:Ly60;

    invoke-static {v4, v8}, Li10;->G0(ILy60;)J

    move-result-wide v8

    new-instance v4, Lv60;

    invoke-direct {v4, v8, v9}, Lv60;-><init>(J)V

    sget-object v8, Lads_mobile_sdk/fo;->a$18:Lads_mobile_sdk/fo;

    invoke-virtual {p1, v5, v4, v8}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lv60;

    iget-wide v4, p1, Lv60;->a:J

    iput-object v1, v0, Lads_mobile_sdk/s72;->a:Lads_mobile_sdk/b82;

    iput-object p0, v0, Lads_mobile_sdk/s72;->b:Llb1;

    iput v3, v0, Lads_mobile_sdk/s72;->e:I

    invoke-static {v4, v5, v0}, Lsz;->u(JLvx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v7, :cond_d1

    goto :goto_e1

    :catchall_cd
    move-exception p0

    goto :goto_f2

    :cond_cf
    move-object v1, p0

    move-object p0, p1

    :cond_d1
    :goto_d1
    iget-object p1, v1, Lads_mobile_sdk/b82;->k:Lads_mobile_sdk/cy0;

    if-eqz p1, :cond_e2

    iput-object v1, v0, Lads_mobile_sdk/s72;->a:Lads_mobile_sdk/b82;

    iput-object p0, v0, Lads_mobile_sdk/s72;->b:Llb1;

    iput v2, v0, Lads_mobile_sdk/s72;->e:I

    invoke-virtual {p1, v0}, Lads_mobile_sdk/cy0;->a(Lvx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v7, :cond_e2

    :goto_e1
    return-object v7

    :cond_e2
    move-object v0, v1

    :goto_e3
    iput-object v6, v0, Lads_mobile_sdk/b82;->j:Lx52;

    iput-object v6, v0, Lads_mobile_sdk/b82;->l:Lads_mobile_sdk/q6;

    iput-object v6, v0, Lads_mobile_sdk/b82;->k:Lads_mobile_sdk/cy0;

    sget-object p1, Lrg2;->a:Lrg2;
    :try_end_eb
    .catchall {:try_start_a0 .. :try_end_eb} :catchall_36

    invoke-interface {p0, v6}, Llb1;->b(Ljava/lang/Object;)V

    return-object p1

    :goto_ef
    move-object v10, p1

    move-object p1, p0

    move-object p0, v10

    :goto_f2
    invoke-interface {p1, v6}, Llb1;->b(Ljava/lang/Object;)V

    throw p0
.end method

.method public static c(Lads_mobile_sdk/b82;Lwx;)Ljava/lang/Object;
    .registers 6

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/u72;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/u72;

    iget v1, v0, Lads_mobile_sdk/u72;->e:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/u72;->e:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/u72;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/u72;-><init>(Lads_mobile_sdk/b82;Lwx;)V

    :goto_18
    iget-object p1, v0, Lads_mobile_sdk/u72;->c:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/u72;->e:I

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v1, :cond_32

    if-ne v1, v2, :cond_2c

    iget-object p0, v0, Lads_mobile_sdk/u72;->b:Lnb1;

    iget-object v0, v0, Lads_mobile_sdk/u72;->a:Lads_mobile_sdk/b82;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    move-object p1, p0

    move-object p0, v0

    goto :goto_46

    :cond_2c
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v3

    :cond_32
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/b82;->i:Lnb1;

    iput-object p0, v0, Lads_mobile_sdk/u72;->a:Lads_mobile_sdk/b82;

    iput-object p1, v0, Lads_mobile_sdk/u72;->b:Lnb1;

    iput v2, v0, Lads_mobile_sdk/u72;->e:I

    invoke-virtual {p1, v0}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v0

    sget-object v1, Lwy;->a:Lwy;

    if-ne v0, v1, :cond_46

    return-object v1

    :cond_46
    :goto_46
    :try_start_46
    iget-object v0, p0, Lads_mobile_sdk/b82;->l:Lads_mobile_sdk/q6;

    if-nez v0, :cond_53

    iget-object p0, p0, Lads_mobile_sdk/b82;->j:Lx52;

    if-eqz p0, :cond_4f

    goto :goto_53

    :cond_4f
    const/4 v2, 0x0

    goto :goto_53

    :catchall_51
    move-exception p0

    goto :goto_5b

    :cond_53
    :goto_53
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0
    :try_end_57
    .catchall {:try_start_46 .. :try_end_57} :catchall_51

    invoke-virtual {p1, v3}, Lnb1;->b(Ljava/lang/Object;)V

    return-object p0

    :goto_5b
    invoke-virtual {p1, v3}, Lnb1;->b(Ljava/lang/Object;)V

    throw p0
.end method

.method public static d(Lads_mobile_sdk/b82;Lwx;)Ljava/lang/Object;
    .registers 10

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/y72;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/y72;

    iget v1, v0, Lads_mobile_sdk/y72;->d:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/y72;->d:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/y72;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/y72;-><init>(Lads_mobile_sdk/b82;Lwx;)V

    :goto_18
    iget-object p1, v0, Lads_mobile_sdk/y72;->b:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/y72;->d:I

    sget-object v2, Lrg2;->a:Lrg2;

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    sget-object v6, Lwy;->a:Lwy;

    if-eqz v1, :cond_39

    if-eq v1, v5, :cond_33

    if-ne v1, v3, :cond_2d

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    return-object v2

    :cond_2d
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v4

    :cond_33
    iget-object p0, v0, Lads_mobile_sdk/y72;->a:Lads_mobile_sdk/b82;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_77

    :cond_39
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/b82;->f:Lads_mobile_sdk/s52;

    iget-object p1, p1, Lads_mobile_sdk/s52;->f:Lads_mobile_sdk/ah3;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_43
    sget-object v1, Lgt0;->o:Llv;

    iget-boolean v1, v1, Llv;->a:Z

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1
    :try_end_4b
    .catch Ljava/lang/Exception; {:try_start_43 .. :try_end_4b} :catch_4c

    goto :goto_53

    :catch_4c
    move-exception v1

    const-string v7, "IsActive"

    invoke-virtual {p1, v7, v1}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V

    move-object p1, v4

    :goto_53
    if-eqz p1, :cond_9f

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_9f

    iget-object p1, p0, Lads_mobile_sdk/b82;->d:Lfx0;

    const-string v1, "enable_omid"

    if-nez p1, :cond_62

    goto :goto_9f

    :cond_62
    :try_start_62
    invoke-virtual {p1, v1}, Lfx0;->v(Ljava/lang/String;)Lkw0;

    move-result-object p1

    invoke-virtual {p1}, Lkw0;->b()Z

    move-result p1
    :try_end_6a
    .catch Ljava/lang/Exception; {:try_start_62 .. :try_end_6a} :catch_9f

    if-eqz p1, :cond_9f

    iput-object p0, v0, Lads_mobile_sdk/y72;->a:Lads_mobile_sdk/b82;

    iput v5, v0, Lads_mobile_sdk/y72;->d:I

    invoke-static {p0, v0}, Lads_mobile_sdk/b82;->c(Lads_mobile_sdk/b82;Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v6, :cond_77

    goto :goto_9e

    :cond_77
    :goto_77
    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-nez p1, :cond_9f

    iget-object p1, p0, Lads_mobile_sdk/b82;->g:Lads_mobile_sdk/it1;

    iget v1, p1, Lads_mobile_sdk/it1;->b:I

    if-ne v1, v3, :cond_90

    iget-object p1, p1, Lads_mobile_sdk/it1;->n:Lads_mobile_sdk/j82;

    if-eqz p1, :cond_8c

    iget p1, p1, Lads_mobile_sdk/j82;->a:I

    goto :goto_8d

    :cond_8c
    const/4 p1, 0x0

    :goto_8d
    if-ne p1, v3, :cond_90

    goto :goto_9f

    :cond_90
    iput-object v4, v0, Lads_mobile_sdk/y72;->a:Lads_mobile_sdk/b82;

    iput v3, v0, Lads_mobile_sdk/y72;->d:I

    const-string p1, "Google"

    sget-object v1, Lads_mobile_sdk/z31;->e:Lads_mobile_sdk/z31;

    invoke-virtual {p0, p1, v5, v1, v0}, Lads_mobile_sdk/b82;->a(Ljava/lang/String;ZLads_mobile_sdk/z31;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v6, :cond_9f

    :goto_9e
    return-object v6

    :catch_9f
    :cond_9f
    :goto_9f
    return-object v2
.end method


# virtual methods
.method public final a(Lads_mobile_sdk/lp3;)Ljava/lang/Object;
    .registers 2

    invoke-static {p0, p1}, Lads_mobile_sdk/b82;->b(Lads_mobile_sdk/b82;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final a(Landroid/view/View;Lads_mobile_sdk/fs0;Lm82;)Ljava/lang/Object;
    .registers 6

    .prologue
    new-instance v0, Lads_mobile_sdk/k72;

    const/4 v1, 0x0

    invoke-direct {v0, p0, p1, p2, v1}, Lads_mobile_sdk/k72;-><init>(Lads_mobile_sdk/b82;Landroid/view/View;Lads_mobile_sdk/fs0;Lvx;)V

    const-string p1, "addFriendlyObstruction"

    invoke-virtual {p0, p1, v0, p3}, Lads_mobile_sdk/b82;->a(Ljava/lang/String;Lrk0;Lwx;)Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lwy;->a:Lwy;

    if-ne p0, p1, :cond_11

    return-object p0

    :cond_11
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method

.method public final a(Landroid/view/View;Lvx;)Ljava/lang/Object;
    .registers 5

    .prologue
    iget-boolean v0, p0, Lads_mobile_sdk/b82;->m:Z

    if-eqz v0, :cond_5

    goto :goto_18

    :cond_5
    new-instance v0, Lads_mobile_sdk/a82;

    const/4 v1, 0x0

    invoke-direct {v0, p0, p1, v1}, Lads_mobile_sdk/a82;-><init>(Lads_mobile_sdk/b82;Landroid/view/View;Lvx;)V

    const-string p1, "updateRegisteredAdView"

    check-cast p2, Lwx;

    invoke-virtual {p0, p1, v0, p2}, Lads_mobile_sdk/b82;->a(Ljava/lang/String;Lrk0;Lwx;)Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lwy;->a:Lwy;

    if-ne p0, p1, :cond_18

    return-object p0

    :cond_18
    :goto_18
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method

.method public final a(Ljava/lang/String;Lrk0;Lwx;)Ljava/lang/Object;
    .registers 20

    .prologue
    move-object/from16 v0, p0

    move-object/from16 v1, p3

    instance-of v2, v1, Lads_mobile_sdk/q72;

    if-eqz v2, :cond_17

    move-object v2, v1

    check-cast v2, Lads_mobile_sdk/q72;

    iget v3, v2, Lads_mobile_sdk/q72;->g:I

    const/high16 v4, -0x80000000

    and-int v5, v3, v4

    if-eqz v5, :cond_17

    sub-int/2addr v3, v4

    iput v3, v2, Lads_mobile_sdk/q72;->g:I

    goto :goto_1c

    :cond_17
    new-instance v2, Lads_mobile_sdk/q72;

    invoke-direct {v2, v0, v1}, Lads_mobile_sdk/q72;-><init>(Lads_mobile_sdk/b82;Lwx;)V

    :goto_1c
    iget-object v1, v2, Lads_mobile_sdk/q72;->e:Ljava/lang/Object;

    iget v3, v2, Lads_mobile_sdk/q72;->g:I

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x1

    sget-object v8, Lrg2;->a:Lrg2;

    const/4 v13, 0x0

    sget-object v15, Lwy;->a:Lwy;

    if-eqz v3, :cond_87

    if-eq v3, v7, :cond_73

    if-eq v3, v6, :cond_60

    if-eq v3, v5, :cond_4c

    if-ne v3, v4, :cond_45

    iget-object v0, v2, Lads_mobile_sdk/q72;->b:Ljava/lang/Object;

    move-object v3, v0

    check-cast v3, Llb1;

    iget-object v0, v2, Lads_mobile_sdk/q72;->a:Ljava/lang/Object;

    move-object v2, v0

    check-cast v2, Ljava/lang/String;

    :try_start_3d
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_40
    .catchall {:try_start_3d .. :try_end_40} :catchall_42

    goto/16 :goto_f8

    :catchall_42
    move-exception v0

    goto/16 :goto_100

    :cond_45
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {v0}, Lz6;->w(Ljava/lang/String;)V

    const/4 v0, 0x0

    return-object v0

    :cond_4c
    iget-object v0, v2, Lads_mobile_sdk/q72;->d:Lnb1;

    iget-object v3, v2, Lads_mobile_sdk/q72;->c:Lrk0;

    iget-object v5, v2, Lads_mobile_sdk/q72;->b:Ljava/lang/Object;

    check-cast v5, Ljava/lang/String;

    iget-object v6, v2, Lads_mobile_sdk/q72;->a:Ljava/lang/Object;

    check-cast v6, Lads_mobile_sdk/b82;

    :try_start_58
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_5b
    .catch Ljava/util/concurrent/CancellationException; {:try_start_58 .. :try_end_5b} :catch_104

    move-object v1, v5

    :cond_5c
    move-object v10, v3

    move-object v3, v0

    goto/16 :goto_ce

    :cond_60
    iget-object v0, v2, Lads_mobile_sdk/q72;->c:Lrk0;

    iget-object v3, v2, Lads_mobile_sdk/q72;->b:Ljava/lang/Object;

    check-cast v3, Ljava/lang/String;

    iget-object v6, v2, Lads_mobile_sdk/q72;->a:Ljava/lang/Object;

    check-cast v6, Lads_mobile_sdk/b82;

    :try_start_6a
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_6d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_6a .. :try_end_6d} :catch_70

    move-object v1, v3

    move-object v3, v0

    goto :goto_bb

    :catch_70
    move-object v5, v3

    goto/16 :goto_104

    :cond_73
    iget-object v0, v2, Lads_mobile_sdk/q72;->d:Lnb1;

    iget-object v3, v2, Lads_mobile_sdk/q72;->c:Lrk0;

    iget-object v7, v2, Lads_mobile_sdk/q72;->b:Ljava/lang/Object;

    check-cast v7, Ljava/lang/String;

    iget-object v9, v2, Lads_mobile_sdk/q72;->a:Ljava/lang/Object;

    check-cast v9, Lads_mobile_sdk/b82;

    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V

    move-object v1, v9

    move-object v9, v0

    move-object v0, v1

    move-object v1, v7

    goto :goto_a1

    :cond_87
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V

    iput-object v0, v2, Lads_mobile_sdk/q72;->a:Ljava/lang/Object;

    move-object/from16 v1, p1

    iput-object v1, v2, Lads_mobile_sdk/q72;->b:Ljava/lang/Object;

    move-object/from16 v3, p2

    iput-object v3, v2, Lads_mobile_sdk/q72;->c:Lrk0;

    iget-object v9, v0, Lads_mobile_sdk/b82;->i:Lnb1;

    iput-object v9, v2, Lads_mobile_sdk/q72;->d:Lnb1;

    iput v7, v2, Lads_mobile_sdk/q72;->g:I

    invoke-virtual {v9, v2}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v7

    if-ne v7, v15, :cond_a1

    goto :goto_f6

    :cond_a1
    :goto_a1
    :try_start_a1
    iget-object v7, v0, Lads_mobile_sdk/b82;->j:Lx52;
    :try_end_a3
    .catchall {:try_start_a1 .. :try_end_a3} :catchall_117

    invoke-virtual {v9, v13}, Lnb1;->b(Ljava/lang/Object;)V

    if-nez v7, :cond_a9

    return-object v8

    :cond_a9
    :try_start_a9
    iput-object v0, v2, Lads_mobile_sdk/q72;->a:Ljava/lang/Object;

    iput-object v1, v2, Lads_mobile_sdk/q72;->b:Ljava/lang/Object;

    iput-object v3, v2, Lads_mobile_sdk/q72;->c:Lrk0;

    iput-object v13, v2, Lads_mobile_sdk/q72;->d:Lnb1;

    iput v6, v2, Lads_mobile_sdk/q72;->g:I

    invoke-virtual {v7, v2}, Lnv0;->H(Lwx;)Ljava/lang/Object;

    move-result-object v6

    if-ne v6, v15, :cond_ba

    goto :goto_f6

    :cond_ba
    move-object v6, v0

    :goto_bb
    iget-object v0, v6, Lads_mobile_sdk/b82;->i:Lnb1;

    iput-object v6, v2, Lads_mobile_sdk/q72;->a:Ljava/lang/Object;

    iput-object v1, v2, Lads_mobile_sdk/q72;->b:Ljava/lang/Object;

    iput-object v3, v2, Lads_mobile_sdk/q72;->c:Lrk0;

    iput-object v0, v2, Lads_mobile_sdk/q72;->d:Lnb1;

    iput v5, v2, Lads_mobile_sdk/q72;->g:I

    invoke-virtual {v0, v2}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v5
    :try_end_cb
    .catch Ljava/util/concurrent/CancellationException; {:try_start_a9 .. :try_end_cb} :catch_de

    if-ne v5, v15, :cond_5c

    goto :goto_f6

    :goto_ce
    :try_start_ce
    iget-object v11, v6, Lads_mobile_sdk/b82;->k:Lads_mobile_sdk/cy0;
    :try_end_d0
    .catchall {:try_start_ce .. :try_end_d0} :catchall_fe

    if-nez v11, :cond_d6

    :try_start_d2
    invoke-virtual {v3, v13}, Lnb1;->b(Ljava/lang/Object;)V
    :try_end_d5
    .catch Ljava/util/concurrent/CancellationException; {:try_start_d2 .. :try_end_d5} :catch_de

    return-object v8

    :cond_d6
    :try_start_d6
    iget-object v12, v6, Lads_mobile_sdk/b82;->l:Lads_mobile_sdk/q6;
    :try_end_d8
    .catchall {:try_start_d6 .. :try_end_d8} :catchall_fe

    if-nez v12, :cond_e0

    :try_start_da
    invoke-virtual {v3, v13}, Lnb1;->b(Ljava/lang/Object;)V
    :try_end_dd
    .catch Ljava/util/concurrent/CancellationException; {:try_start_da .. :try_end_dd} :catch_de

    return-object v8

    :catch_de
    move-object v5, v1

    goto :goto_104

    :cond_e0
    :try_start_e0
    new-instance v9, Lads_mobile_sdk/al;

    const/4 v14, 0x5

    invoke-direct/range {v9 .. v14}, Lads_mobile_sdk/al;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lvx;I)V

    iput-object v1, v2, Lads_mobile_sdk/q72;->a:Ljava/lang/Object;

    iput-object v3, v2, Lads_mobile_sdk/q72;->b:Ljava/lang/Object;

    iput-object v13, v2, Lads_mobile_sdk/q72;->c:Lrk0;

    iput-object v13, v2, Lads_mobile_sdk/q72;->d:Lnb1;

    iput v4, v2, Lads_mobile_sdk/q72;->g:I

    invoke-virtual {v6, v9, v2}, Lpb;->a(Lbk0;Lwx;)Ljava/lang/Object;

    move-result-object v0
    :try_end_f4
    .catchall {:try_start_e0 .. :try_end_f4} :catchall_fe

    if-ne v0, v15, :cond_f7

    :goto_f6
    return-object v15

    :cond_f7
    move-object v2, v1

    :goto_f8
    :try_start_f8
    invoke-interface {v3, v13}, Llb1;->b(Ljava/lang/Object;)V
    :try_end_fb
    .catch Ljava/util/concurrent/CancellationException; {:try_start_f8 .. :try_end_fb} :catch_fc

    return-object v8

    :catch_fc
    move-object v5, v2

    goto :goto_104

    :catchall_fe
    move-exception v0

    move-object v2, v1

    :goto_100
    :try_start_100
    invoke-interface {v3, v13}, Llb1;->b(Ljava/lang/Object;)V

    throw v0
    :try_end_104
    .catch Ljava/util/concurrent/CancellationException; {:try_start_100 .. :try_end_104} :catch_105

    :catch_104
    :goto_104
    move-object v2, v5

    :catch_105
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Ad session was cancelled in "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v13}, Lads_mobile_sdk/nw;->c(Ljava/lang/String;Ljava/lang/Exception;)V

    return-object v8

    :catchall_117
    move-exception v0

    invoke-virtual {v9, v13}, Lnb1;->b(Ljava/lang/Object;)V

    throw v0
.end method

.method public final a(Ljava/lang/String;ZLads_mobile_sdk/z31;Lwx;)Ljava/lang/Object;
    .registers 23

    .prologue
    move-object/from16 v0, p0

    move-object/from16 v1, p4

    instance-of v2, v1, Lads_mobile_sdk/l72;

    if-eqz v2, :cond_17

    move-object v2, v1

    check-cast v2, Lads_mobile_sdk/l72;

    iget v3, v2, Lads_mobile_sdk/l72;->h:I

    const/high16 v4, -0x80000000

    and-int v5, v3, v4

    if-eqz v5, :cond_17

    sub-int/2addr v3, v4

    iput v3, v2, Lads_mobile_sdk/l72;->h:I

    goto :goto_1c

    :cond_17
    new-instance v2, Lads_mobile_sdk/l72;

    invoke-direct {v2, v0, v1}, Lads_mobile_sdk/l72;-><init>(Lads_mobile_sdk/b82;Lwx;)V

    :goto_1c
    iget-object v1, v2, Lads_mobile_sdk/l72;->f:Ljava/lang/Object;

    iget v3, v2, Lads_mobile_sdk/l72;->h:I

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v3, :cond_3f

    if-ne v3, v4, :cond_39

    iget-boolean v0, v2, Lads_mobile_sdk/l72;->e:Z

    iget-object v3, v2, Lads_mobile_sdk/l72;->d:Lnb1;

    iget-object v6, v2, Lads_mobile_sdk/l72;->c:Lads_mobile_sdk/z31;

    iget-object v7, v2, Lads_mobile_sdk/l72;->b:Ljava/lang/String;

    iget-object v2, v2, Lads_mobile_sdk/l72;->a:Lads_mobile_sdk/b82;

    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V

    move/from16 v16, v0

    move-object v11, v2

    move-object v14, v6

    move-object v12, v7

    goto :goto_65

    :cond_39
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {v0}, Lz6;->w(Ljava/lang/String;)V

    return-object v5

    :cond_3f
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V

    iput-object v0, v2, Lads_mobile_sdk/l72;->a:Lads_mobile_sdk/b82;

    move-object/from16 v1, p1

    iput-object v1, v2, Lads_mobile_sdk/l72;->b:Ljava/lang/String;

    move-object/from16 v3, p3

    iput-object v3, v2, Lads_mobile_sdk/l72;->c:Lads_mobile_sdk/z31;

    iget-object v6, v0, Lads_mobile_sdk/b82;->i:Lnb1;

    iput-object v6, v2, Lads_mobile_sdk/l72;->d:Lnb1;

    move/from16 v7, p2

    iput-boolean v7, v2, Lads_mobile_sdk/l72;->e:Z

    iput v4, v2, Lads_mobile_sdk/l72;->h:I

    invoke-virtual {v6, v2}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v2

    sget-object v8, Lwy;->a:Lwy;

    if-ne v2, v8, :cond_5f

    return-object v8

    :cond_5f
    move-object v11, v0

    move-object v12, v1

    move-object v14, v3

    move-object v3, v6

    move/from16 v16, v7

    :goto_65
    :try_start_65
    iget-object v0, v11, Lads_mobile_sdk/b82;->g:Lads_mobile_sdk/it1;

    iget-object v1, v11, Lads_mobile_sdk/b82;->c:Lvy;

    iget-object v2, v0, Lads_mobile_sdk/it1;->n:Lads_mobile_sdk/j82;
    :try_end_6b
    .catchall {:try_start_65 .. :try_end_6b} :catchall_e6

    sget-object v6, Lrg2;->a:Lrg2;

    if-nez v2, :cond_73

    invoke-virtual {v3, v5}, Lnb1;->b(Ljava/lang/Object;)V

    return-object v6

    :cond_73
    :try_start_73
    new-instance v10, Lvr1;

    invoke-direct {v10}, Ljava/lang/Object;-><init>()V

    new-instance v13, Lvr1;

    invoke-direct {v13}, Ljava/lang/Object;-><init>()V

    new-instance v15, Lvr1;

    invoke-direct {v15}, Ljava/lang/Object;-><init>()V

    iget v2, v2, Lads_mobile_sdk/j82;->a:I

    invoke-static {v2}, Lc33;->x(I)I

    move-result v2
    :try_end_88
    .catchall {:try_start_73 .. :try_end_88} :catchall_e6

    const/4 v7, 0x2

    sget-object v8, Ly90;->a:Ly90;

    if-eqz v2, :cond_e9

    if-eq v2, v4, :cond_a4

    if-ne v2, v7, :cond_9e

    :try_start_91
    const-string v0, "Unknown media type in OmidNativeMonitor"

    invoke-static {v0, v5}, Lads_mobile_sdk/nw;->c(Ljava/lang/String;Ljava/lang/Exception;)V
    :try_end_96
    .catchall {:try_start_91 .. :try_end_96} :catchall_9a

    invoke-virtual {v3, v5}, Lnb1;->b(Ljava/lang/Object;)V

    return-object v6

    :catchall_9a
    move-exception v0

    move-object v4, v5

    goto/16 :goto_133

    :cond_9e
    :try_start_9e
    new-instance v0, Lft;

    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    throw v0
    :try_end_a4
    .catchall {:try_start_9e .. :try_end_a4} :catchall_9a

    :cond_a4
    :try_start_a4
    iget-object v0, v0, Lads_mobile_sdk/it1;->o:Lu20;
    :try_end_a6
    .catchall {:try_start_a4 .. :try_end_a6} :catchall_e6

    if-nez v0, :cond_b1

    :try_start_a8
    const-string v0, "No omid webview in OmidNativeMonitor"

    invoke-static {v0, v5}, Lads_mobile_sdk/nw;->c(Ljava/lang/String;Ljava/lang/Exception;)V
    :try_end_ad
    .catchall {:try_start_a8 .. :try_end_ad} :catchall_9a

    invoke-virtual {v3, v5}, Lnb1;->b(Ljava/lang/Object;)V

    return-object v6

    :cond_b1
    :try_start_b1
    iput-object v0, v10, Lvr1;->a:Ljava/lang/Object;

    sget-object v2, Lads_mobile_sdk/t00;->d:Lads_mobile_sdk/t00;

    iput-object v2, v13, Lvr1;->a:Ljava/lang/Object;

    sget-object v2, Lads_mobile_sdk/z92;->d:Lads_mobile_sdk/z92;

    iput-object v2, v15, Lvr1;->a:Ljava/lang/Object;

    iget-object v2, v11, Lpb;->a:Ljava/lang/Object;

    check-cast v2, Lads_mobile_sdk/qr0;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v4, "gads:native_click_protection:enabled"

    sget-object v9, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sget-object v5, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    invoke-virtual {v2, v4, v9, v5}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Boolean;

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_119

    new-instance v2, Lads_mobile_sdk/zj;

    const/4 v4, 0x0

    invoke-direct {v2, v0, v11, v4, v7}, Lads_mobile_sdk/zj;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lvx;I)V

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, La42;

    invoke-direct {v0, v2, v4}, La42;-><init>(Lpk0;Lvx;)V

    invoke-static {v1, v8, v4, v0, v7}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    goto :goto_119

    :catchall_e6
    move-exception v0

    const/4 v4, 0x0

    goto :goto_133

    :cond_e9
    iget-object v0, v0, Lads_mobile_sdk/it1;->j:Lads_mobile_sdk/cy0;

    if-nez v0, :cond_f9

    const-string v0, "No media webview in OmidNativeMonitor"
    :try_end_ef
    .catchall {:try_start_b1 .. :try_end_ef} :catchall_e6

    const/4 v4, 0x0

    :try_start_f0
    invoke-static {v0, v4}, Lads_mobile_sdk/nw;->c(Ljava/lang/String;Ljava/lang/Exception;)V
    :try_end_f3
    .catchall {:try_start_f0 .. :try_end_f3} :catchall_f7

    invoke-virtual {v3, v4}, Lnb1;->b(Ljava/lang/Object;)V

    return-object v6

    :catchall_f7
    move-exception v0

    goto :goto_133

    :cond_f9
    const/4 v4, 0x0

    :try_start_fa
    invoke-virtual {v0}, Lads_mobile_sdk/cy0;->d()Lads_mobile_sdk/bz0;

    move-result-object v2

    if-nez v2, :cond_109

    const-string v0, "No video controller in OmidNativeMonitor"

    invoke-static {v0, v4}, Lads_mobile_sdk/nw;->c(Ljava/lang/String;Ljava/lang/Exception;)V
    :try_end_105
    .catchall {:try_start_fa .. :try_end_105} :catchall_e6

    invoke-virtual {v3, v4}, Lnb1;->b(Ljava/lang/Object;)V

    return-object v6

    :cond_109
    :try_start_109
    invoke-static {v0}, Lsz;->a(Ljava/lang/Object;)Lbt;

    move-result-object v2

    iput-object v2, v10, Lvr1;->a:Ljava/lang/Object;

    iput-object v0, v11, Lads_mobile_sdk/b82;->k:Lads_mobile_sdk/cy0;

    sget-object v0, Lads_mobile_sdk/t00;->e:Lads_mobile_sdk/t00;

    iput-object v0, v13, Lvr1;->a:Ljava/lang/Object;

    sget-object v0, Lads_mobile_sdk/z92;->c:Lads_mobile_sdk/z92;

    iput-object v0, v15, Lvr1;->a:Ljava/lang/Object;

    :cond_119
    :goto_119
    new-instance v9, Lads_mobile_sdk/o72;

    const/16 v17, 0x0

    invoke-direct/range {v9 .. v17}, Lads_mobile_sdk/o72;-><init>(Lvr1;Lads_mobile_sdk/b82;Ljava/lang/String;Lvr1;Lads_mobile_sdk/z31;Lvr1;ZLvx;)V

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, La42;

    const/4 v4, 0x0

    invoke-direct {v0, v9, v4}, La42;-><init>(Lpk0;Lvx;)V

    invoke-static {v1, v8, v4, v0, v7}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    move-result-object v0

    iput-object v0, v11, Lads_mobile_sdk/b82;->j:Lx52;
    :try_end_12f
    .catchall {:try_start_109 .. :try_end_12f} :catchall_e6

    invoke-virtual {v3, v4}, Lnb1;->b(Ljava/lang/Object;)V

    return-object v6

    :goto_133
    invoke-virtual {v3, v4}, Lnb1;->b(Ljava/lang/Object;)V

    throw v0
.end method

.method public final a(Lvx;)Ljava/lang/Object;
    .registers 2

    .prologue
    check-cast p1, Lwx;

    invoke-static {p0, p1}, Lads_mobile_sdk/b82;->b(Lads_mobile_sdk/b82;Lwx;)Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lwy;->a:Lwy;

    if-ne p0, p1, :cond_b

    return-object p0

    :cond_b
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method

.method public final i(Lvx;)Ljava/lang/Object;
    .registers 2

    check-cast p1, Lwx;

    invoke-static {p0, p1}, Lads_mobile_sdk/b82;->d(Lads_mobile_sdk/b82;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final l(Lads_mobile_sdk/lp3;)Ljava/lang/Object;
    .registers 2

    invoke-static {p0, p1}, Lads_mobile_sdk/b82;->c(Lads_mobile_sdk/b82;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final m(Lads_mobile_sdk/pt0;)Ljava/lang/Object;
    .registers 4

    .prologue
    new-instance v0, Lads_mobile_sdk/v72;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lads_mobile_sdk/v72;-><init>(Lads_mobile_sdk/b82;Lvx;)V

    const-string v1, "measurePreviousView"

    invoke-virtual {p0, v1, v0, p1}, Lads_mobile_sdk/b82;->a(Ljava/lang/String;Lrk0;Lwx;)Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lwy;->a:Lwy;

    if-ne p0, p1, :cond_11

    return-object p0

    :cond_11
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method

.method public final n(Lvx;)Ljava/lang/Object;
    .registers 6

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/b82;->g:Lads_mobile_sdk/it1;

    iget-object v0, v0, Lads_mobile_sdk/it1;->n:Lads_mobile_sdk/j82;

    const/4 v1, 0x0

    if-eqz v0, :cond_a

    iget v0, v0, Lads_mobile_sdk/j82;->a:I

    goto :goto_b

    :cond_a
    move v0, v1

    :goto_b
    const/4 v2, 0x1

    if-ne v0, v2, :cond_22

    new-instance v0, Lads_mobile_sdk/w72;

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-direct {v0, v2, v3, v1}, Lads_mobile_sdk/w72;-><init>(ILvx;I)V

    const-string v1, "onAdClicked"

    check-cast p1, Lwx;

    invoke-virtual {p0, v1, v0, p1}, Lads_mobile_sdk/b82;->a(Ljava/lang/String;Lrk0;Lwx;)Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lwy;->a:Lwy;

    if-ne p0, p1, :cond_22

    return-object p0

    :cond_22
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method

.method public final q(Lvx;)Ljava/lang/Object;
    .registers 6

    .prologue
    new-instance v0, Lads_mobile_sdk/w72;

    const/4 v1, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-direct {v0, v1, v3, v2}, Lads_mobile_sdk/w72;-><init>(ILvx;I)V

    const-string v1, "onAdImpression"

    check-cast p1, Lwx;

    invoke-virtual {p0, v1, v0, p1}, Lads_mobile_sdk/b82;->a(Ljava/lang/String;Lrk0;Lwx;)Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lwy;->a:Lwy;

    if-ne p0, p1, :cond_15

    return-object p0

    :cond_15
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method
