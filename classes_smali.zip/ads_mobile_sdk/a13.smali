.class public final Lads_mobile_sdk/a13;
.super Lads_mobile_sdk/oa3;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final d:Ljava/lang/String;

.field public final e:Lads_mobile_sdk/qr0;

.field public final f:Landroid/content/Context;

.field public final g:Lads_mobile_sdk/ax0;

.field public final h:Ljava/lang/String;

.field public final i:Lads_mobile_sdk/i41;


# direct methods
.method public constructor <init>(Ljava/lang/String;Lads_mobile_sdk/qr0;Landroid/content/Context;Lads_mobile_sdk/ax0;Ljava/lang/String;Lads_mobile_sdk/i41;)V
    .registers 9

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lads_mobile_sdk/fw0;->t:Lads_mobile_sdk/fw0;

    const/4 v1, 0x2

    invoke-direct {p0, v0, v1}, Lads_mobile_sdk/k61;-><init>(Lads_mobile_sdk/fw0;I)V

    iput-object p1, p0, Lads_mobile_sdk/a13;->d:Ljava/lang/String;

    iput-object p2, p0, Lads_mobile_sdk/a13;->e:Lads_mobile_sdk/qr0;

    iput-object p3, p0, Lads_mobile_sdk/a13;->f:Landroid/content/Context;

    iput-object p4, p0, Lads_mobile_sdk/a13;->g:Lads_mobile_sdk/ax0;

    iput-object p5, p0, Lads_mobile_sdk/a13;->h:Ljava/lang/String;

    iput-object p6, p0, Lads_mobile_sdk/a13;->i:Lads_mobile_sdk/i41;

    return-void
.end method


# virtual methods
.method public final a()Lads_mobile_sdk/lw0;
    .registers 1

    sget-object p0, Lads_mobile_sdk/lw0;->N:Lads_mobile_sdk/lw0;

    return-object p0
.end method

.method public final d(Lvx;)Ljava/lang/Object;
    .registers 10

    .prologue
    iget-object p1, p0, Lads_mobile_sdk/a13;->f:Landroid/content/Context;

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object p1

    const/4 v0, 0x0

    if-eqz p1, :cond_d

    iget p1, p1, Landroid/content/pm/ApplicationInfo;->targetSdkVersion:I

    move v2, p1

    goto :goto_e

    :cond_d
    move v2, v0

    :goto_e
    new-instance p1, Lads_mobile_sdk/hv0;

    new-instance v1, Lads_mobile_sdk/z03;

    iget-object v3, p0, Lads_mobile_sdk/a13;->e:Lads_mobile_sdk/qr0;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v4, Lads_mobile_sdk/fo;->a$23:Lads_mobile_sdk/fo;

    const-string v5, "gads:sdk_core_constants:caps"

    const-string v6, ""

    invoke-virtual {v3, v5, v6, v4}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v3

    move-object v4, v3

    check-cast v4, Ljava/lang/String;

    iget-object v3, p0, Lads_mobile_sdk/a13;->g:Lads_mobile_sdk/ax0;

    invoke-virtual {v3}, Lads_mobile_sdk/ax0;->c()Z

    move-result v6

    invoke-static {}, Landroid/os/Process;->myUid()I

    move-result v3

    if-eqz v3, :cond_43

    const/16 v5, 0x3e8

    if-eq v3, v5, :cond_43

    const/16 v5, 0x3e9

    if-eq v3, v5, :cond_43

    const/16 v5, 0x3ea

    if-eq v3, v5, :cond_43

    const/16 v5, 0x403

    if-ne v3, v5, :cond_41

    goto :goto_43

    :cond_41
    :goto_41
    move v7, v0

    goto :goto_45

    :cond_43
    :goto_43
    const/4 v0, 0x1

    goto :goto_41

    :goto_45
    iget-object v0, p0, Lads_mobile_sdk/a13;->i:Lads_mobile_sdk/i41;

    invoke-virtual {v0}, Lads_mobile_sdk/i41;->a()Lfm0;

    iget-object v3, p0, Lads_mobile_sdk/a13;->d:Ljava/lang/String;

    iget-object v5, p0, Lads_mobile_sdk/a13;->h:Ljava/lang/String;

    invoke-direct/range {v1 .. v7}, Lads_mobile_sdk/z03;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZ)V

    invoke-direct {p1, v1}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    return-object p1
.end method
