.class public final Lads_mobile_sdk/eh3;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Lads_mobile_sdk/rg3;

.field public final b:Lads_mobile_sdk/e7;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/rg3;Lads_mobile_sdk/e7;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/eh3;->a:Lads_mobile_sdk/rg3;

    iput-object p2, p0, Lads_mobile_sdk/eh3;->b:Lads_mobile_sdk/e7;

    return-void
.end method
