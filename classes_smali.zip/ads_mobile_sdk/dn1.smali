.class public final Lads_mobile_sdk/dn1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Lads_mobile_sdk/os;

.field public final c:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Ln73;Lads_mobile_sdk/cs3;Ljava/lang/Object;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lads_mobile_sdk/os;

    invoke-direct {v0, p1, p2, p3}, Lads_mobile_sdk/os;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    iput-object v0, p0, Lads_mobile_sdk/dn1;->a:Lads_mobile_sdk/os;

    iput-object p3, p0, Lads_mobile_sdk/dn1;->c:Ljava/lang/Object;

    return-void
.end method
