.class public final Lads_mobile_sdk/fp0;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public a:Ljava/lang/Object;

.field public b:Ljava/lang/Object;

.field public c:I

.field public final synthetic d:Ljava/lang/Object;

.field public final synthetic e:Ljava/lang/Object;

.field public final synthetic f:Ljava/lang/Object;

.field public final synthetic h:Ljava/lang/String;

.field public final synthetic i:Ljava/lang/Object;

.field public final synthetic j:Z

.field public final synthetic t:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/b82;Lads_mobile_sdk/cy0;Ljava/lang/String;Lvr1;Lads_mobile_sdk/z31;Lvr1;ZLvx;)V
    .registers 10

    const/4 v0, 0x1

    iput v0, p0, Lads_mobile_sdk/fp0;->t:I

    iput-object p1, p0, Lads_mobile_sdk/fp0;->b:Ljava/lang/Object;

    iput-object p2, p0, Lads_mobile_sdk/fp0;->d:Ljava/lang/Object;

    iput-object p3, p0, Lads_mobile_sdk/fp0;->h:Ljava/lang/String;

    iput-object p4, p0, Lads_mobile_sdk/fp0;->e:Ljava/lang/Object;

    iput-object p5, p0, Lads_mobile_sdk/fp0;->f:Ljava/lang/Object;

    iput-object p6, p0, Lads_mobile_sdk/fp0;->i:Ljava/lang/Object;

    iput-boolean p7, p0, Lads_mobile_sdk/fp0;->j:Z

    const/4 p1, 0x2

    invoke-direct {p0, p1, p8}, Lm82;-><init>(ILvx;)V

    return-void
.end method

.method public constructor <init>(Lads_mobile_sdk/qp0;Lads_mobile_sdk/vv1;Lfx0;Ljava/lang/String;Landroid/view/View;ZLvx;)V
    .registers 9

    const/4 v0, 0x0

    iput v0, p0, Lads_mobile_sdk/fp0;->t:I

    iput-object p1, p0, Lads_mobile_sdk/fp0;->d:Ljava/lang/Object;

    iput-object p2, p0, Lads_mobile_sdk/fp0;->e:Ljava/lang/Object;

    iput-object p3, p0, Lads_mobile_sdk/fp0;->f:Ljava/lang/Object;

    iput-object p4, p0, Lads_mobile_sdk/fp0;->h:Ljava/lang/String;

    iput-object p5, p0, Lads_mobile_sdk/fp0;->i:Ljava/lang/Object;

    iput-boolean p6, p0, Lads_mobile_sdk/fp0;->j:Z

    const/4 p1, 0x2

    invoke-direct {p0, p1, p7}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 16

    .prologue
    iget p2, p0, Lads_mobile_sdk/fp0;->t:I

    iget-object v0, p0, Lads_mobile_sdk/fp0;->i:Ljava/lang/Object;

    iget-object v1, p0, Lads_mobile_sdk/fp0;->f:Ljava/lang/Object;

    iget-object v2, p0, Lads_mobile_sdk/fp0;->e:Ljava/lang/Object;

    iget-object v3, p0, Lads_mobile_sdk/fp0;->d:Ljava/lang/Object;

    packed-switch p2, :pswitch_data_40

    new-instance v4, Lads_mobile_sdk/fp0;

    iget-object p2, p0, Lads_mobile_sdk/fp0;->b:Ljava/lang/Object;

    move-object v5, p2

    check-cast v5, Lads_mobile_sdk/b82;

    move-object v6, v3

    check-cast v6, Lads_mobile_sdk/cy0;

    move-object v8, v2

    check-cast v8, Lvr1;

    move-object v9, v1

    check-cast v9, Lads_mobile_sdk/z31;

    move-object v10, v0

    check-cast v10, Lvr1;

    iget-boolean v11, p0, Lads_mobile_sdk/fp0;->j:Z

    iget-object v7, p0, Lads_mobile_sdk/fp0;->h:Ljava/lang/String;

    move-object v12, p1

    invoke-direct/range {v4 .. v12}, Lads_mobile_sdk/fp0;-><init>(Lads_mobile_sdk/b82;Lads_mobile_sdk/cy0;Ljava/lang/String;Lvr1;Lads_mobile_sdk/z31;Lvr1;ZLvx;)V

    return-object v4

    :pswitch_29  #0x0
    move-object v12, p1

    new-instance v5, Lads_mobile_sdk/fp0;

    move-object v6, v3

    check-cast v6, Lads_mobile_sdk/qp0;

    move-object v7, v2

    check-cast v7, Lads_mobile_sdk/vv1;

    move-object v8, v1

    check-cast v8, Lfx0;

    move-object v10, v0

    check-cast v10, Landroid/view/View;

    iget-boolean v11, p0, Lads_mobile_sdk/fp0;->j:Z

    iget-object v9, p0, Lads_mobile_sdk/fp0;->h:Ljava/lang/String;

    invoke-direct/range {v5 .. v12}, Lads_mobile_sdk/fp0;-><init>(Lads_mobile_sdk/qp0;Lads_mobile_sdk/vv1;Lfx0;Ljava/lang/String;Landroid/view/View;ZLvx;)V

    return-object v5

    :pswitch_data_40
    .packed-switch 0x0
        :pswitch_29  #00000000
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .prologue
    iget v0, p0, Lads_mobile_sdk/fp0;->t:I

    sget-object v1, Lrg2;->a:Lrg2;

    packed-switch v0, :pswitch_data_26

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    invoke-virtual {p0, p2, p1}, Lads_mobile_sdk/fp0;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/fp0;

    invoke-virtual {p0, v1}, Lads_mobile_sdk/fp0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_16  #0x0
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    invoke-virtual {p0, p2, p1}, Lads_mobile_sdk/fp0;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/fp0;

    invoke-virtual {p0, v1}, Lads_mobile_sdk/fp0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_26
    .packed-switch 0x0
        :pswitch_16  #00000000
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 18

    .prologue
    move-object/from16 v8, p0

    iget v0, v8, Lads_mobile_sdk/fp0;->t:I

    const/4 v9, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x0

    packed-switch v0, :pswitch_data_3c0

    iget-object v0, v8, Lads_mobile_sdk/fp0;->d:Ljava/lang/Object;

    move-object v1, v0

    check-cast v1, Lads_mobile_sdk/cy0;

    iget-object v0, v8, Lads_mobile_sdk/fp0;->b:Ljava/lang/Object;

    move-object v12, v0

    check-cast v12, Lads_mobile_sdk/b82;

    iget-object v0, v12, Lads_mobile_sdk/b82;->f:Lads_mobile_sdk/s52;

    sget-object v13, Lwy;->a:Lwy;

    iget v2, v8, Lads_mobile_sdk/fp0;->c:I

    if-eqz v2, :cond_37

    if-eq v2, v10, :cond_31

    if-ne v2, v9, :cond_2a

    iget-object v0, v8, Lads_mobile_sdk/fp0;->a:Ljava/lang/Object;

    move-object v11, v0

    check-cast v11, Lads_mobile_sdk/q6;

    invoke-static/range {p1 .. p1}, Lt12;->W(Ljava/lang/Object;)V

    goto/16 :goto_a0

    :cond_2a
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {v0}, Lz6;->w(Ljava/lang/String;)V

    goto/16 :goto_a0

    :cond_31
    invoke-static/range {p1 .. p1}, Lt12;->W(Ljava/lang/Object;)V

    move-object/from16 v2, p1

    goto :goto_66

    :cond_37
    invoke-static/range {p1 .. p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object v2, v8, Lads_mobile_sdk/fp0;->h:Ljava/lang/String;

    iget-object v3, v12, Lads_mobile_sdk/b82;->e:Lads_mobile_sdk/a2;

    iget-object v3, v3, Lads_mobile_sdk/a2;->x:Ljava/lang/String;

    iget-object v4, v8, Lads_mobile_sdk/fp0;->e:Ljava/lang/Object;

    check-cast v4, Lvr1;

    iget-object v4, v4, Lvr1;->a:Ljava/lang/Object;

    if-eqz v4, :cond_a7

    check-cast v4, Lads_mobile_sdk/t00;

    iget-object v5, v8, Lads_mobile_sdk/fp0;->f:Ljava/lang/Object;

    check-cast v5, Lads_mobile_sdk/z31;

    sget-object v6, Lads_mobile_sdk/z92;->c:Lads_mobile_sdk/z92;

    iget-object v7, v8, Lads_mobile_sdk/fp0;->i:Ljava/lang/Object;

    check-cast v7, Lvr1;

    iget-object v7, v7, Lvr1;->a:Ljava/lang/Object;

    if-eqz v7, :cond_a1

    check-cast v7, Lads_mobile_sdk/z92;

    iput v10, v8, Lads_mobile_sdk/fp0;->c:I

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static/range {v0 .. v8}, Lads_mobile_sdk/s52;->a(Lads_mobile_sdk/s52;Lads_mobile_sdk/cy0;Ljava/lang/String;Ljava/lang/String;Lads_mobile_sdk/t00;Lads_mobile_sdk/z31;Lads_mobile_sdk/z92;Lads_mobile_sdk/z92;Lwx;)Ljava/lang/Object;

    move-result-object v2

    if-ne v2, v13, :cond_66

    goto :goto_9d

    :cond_66
    :goto_66
    check-cast v2, Lads_mobile_sdk/q6;

    if-eqz v2, :cond_a0

    iget-boolean v3, v8, Lads_mobile_sdk/fp0;->j:Z

    iget-boolean v4, v12, Lads_mobile_sdk/b82;->m:Z

    if-eqz v4, :cond_73

    invoke-virtual {v0, v2, v1}, Lads_mobile_sdk/s52;->a(Lads_mobile_sdk/q6;Landroid/view/View;)Lrg2;

    :cond_73
    if-eqz v3, :cond_9f

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v3, v0, Lads_mobile_sdk/s52;->f:Lads_mobile_sdk/ah3;

    new-instance v0, Lads_mobile_sdk/h52;

    invoke-direct {v0, v2, v10}, Lads_mobile_sdk/h52;-><init>(Lads_mobile_sdk/q6;I)V

    const-string v4, "StartOmidSession"

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_84
    invoke-virtual {v0}, Lads_mobile_sdk/h52;->invoke()Ljava/lang/Object;
    :try_end_87
    .catch Ljava/lang/Exception; {:try_start_84 .. :try_end_87} :catch_88

    goto :goto_8c

    :catch_88
    move-exception v0

    invoke-virtual {v3, v4, v0}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_8c
    new-instance v0, Lfx0;

    invoke-direct {v0}, Lfx0;-><init>()V

    iput-object v2, v8, Lads_mobile_sdk/fp0;->a:Ljava/lang/Object;

    iput v9, v8, Lads_mobile_sdk/fp0;->c:I

    const-string v3, "onSdkLoaded"

    invoke-virtual {v1, v0, v3, v8}, Lads_mobile_sdk/cy0;->a(Lfx0;Ljava/lang/String;Lvx;)Ljava/lang/Object;

    move-result-object v0

    if-ne v0, v13, :cond_9f

    :goto_9d
    move-object v11, v13

    goto :goto_a0

    :cond_9f
    move-object v11, v2

    :cond_a0
    :goto_a0
    return-object v11

    :cond_a1
    const-string v0, "videoEventsOwner"

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_a7
    const-string v0, "creativeType"

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :pswitch_ad  #0x0
    sget-object v0, Lrg2;->a:Lrg2;

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sget-object v2, Lwy;->a:Lwy;

    iget v3, v8, Lads_mobile_sdk/fp0;->c:I

    const/4 v4, 0x0

    if-eqz v3, :cond_e9

    if-eq v3, v10, :cond_d6

    if-ne v3, v9, :cond_cf

    iget-object v1, v8, Lads_mobile_sdk/fp0;->b:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/rg3;

    iget-object v2, v8, Lads_mobile_sdk/fp0;->a:Ljava/lang/Object;

    check-cast v2, Lads_mobile_sdk/rg3;

    :try_start_c4
    invoke-static/range {p1 .. p1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_c7
    .catchall {:try_start_c4 .. :try_end_c7} :catchall_cc

    move-object v5, v1

    move-object/from16 v1, p1

    goto/16 :goto_338

    :catchall_cc
    move-exception v0

    goto/16 :goto_34d

    :cond_cf
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {v0}, Lz6;->w(Ljava/lang/String;)V

    goto/16 :goto_34c

    :cond_d6
    iget-object v1, v8, Lads_mobile_sdk/fp0;->b:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/rg3;

    iget-object v2, v8, Lads_mobile_sdk/fp0;->a:Ljava/lang/Object;

    check-cast v2, Lads_mobile_sdk/rg3;

    :try_start_de
    invoke-static/range {p1 .. p1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_e1
    .catchall {:try_start_de .. :try_end_e1} :catchall_e6

    move-object v5, v1

    move-object/from16 v1, p1

    goto/16 :goto_2c9

    :catchall_e6
    move-exception v0

    goto/16 :goto_2de

    :cond_e9
    invoke-static/range {p1 .. p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object v3, v8, Lads_mobile_sdk/fp0;->d:Ljava/lang/Object;

    check-cast v3, Lads_mobile_sdk/qp0;

    iget-object v3, v3, Lads_mobile_sdk/qp0;->z:Lads_mobile_sdk/qr0;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v5, "gads:native_click_protection:enabled"

    sget-object v6, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    invoke-virtual {v3, v5, v1, v6}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Boolean;

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-eqz v3, :cond_110

    iget-object v3, v8, Lads_mobile_sdk/fp0;->d:Ljava/lang/Object;

    check-cast v3, Lads_mobile_sdk/qp0;

    iget-object v3, v3, Lads_mobile_sdk/qp0;->A:Lads_mobile_sdk/jz2;

    iget-object v3, v3, Lads_mobile_sdk/jz2;->g:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v3, v10}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    :cond_110
    new-instance v3, Lfx0;

    invoke-direct {v3}, Lfx0;-><init>()V

    iget-object v5, v8, Lads_mobile_sdk/fp0;->d:Ljava/lang/Object;

    check-cast v5, Lads_mobile_sdk/qp0;

    iget-object v6, v8, Lads_mobile_sdk/fp0;->e:Ljava/lang/Object;

    check-cast v6, Lads_mobile_sdk/vv1;

    iget-object v7, v8, Lads_mobile_sdk/fp0;->f:Ljava/lang/Object;

    check-cast v7, Lfx0;

    const-string v12, "ad"

    iget-object v13, v5, Lads_mobile_sdk/qp0;->g:Lfx0;

    invoke-virtual {v3, v12, v13}, Lfx0;->o(Ljava/lang/String;Lkw0;)V

    if-eqz v6, :cond_146

    iget-object v12, v6, Lads_mobile_sdk/vv1;->a:Lfx0;

    const-string v13, "asset_view_signal"

    invoke-virtual {v3, v13, v12}, Lfx0;->o(Ljava/lang/String;Lkw0;)V

    iget-object v12, v6, Lads_mobile_sdk/vv1;->b:Lfx0;

    const-string v13, "ad_view_signal"

    invoke-virtual {v3, v13, v12}, Lfx0;->o(Ljava/lang/String;Lkw0;)V

    iget-object v12, v6, Lads_mobile_sdk/vv1;->c:Lfx0;

    const-string v13, "scroll_view_signal"

    invoke-virtual {v3, v13, v12}, Lfx0;->o(Ljava/lang/String;Lkw0;)V

    iget-object v6, v6, Lads_mobile_sdk/vv1;->d:Lfx0;

    const-string v12, "lock_screen_signal"

    invoke-virtual {v3, v12, v6}, Lfx0;->o(Ljava/lang/String;Lkw0;)V

    :cond_146
    if-eqz v7, :cond_14d

    const-string v6, "click_signal"

    invoke-virtual {v3, v6, v7}, Lfx0;->o(Ljava/lang/String;Lkw0;)V

    :cond_14d
    const-string v6, "has_custom_click_handler"

    iget-object v5, v5, Lads_mobile_sdk/qp0;->t:Lads_mobile_sdk/ph0;

    monitor-enter v5

    monitor-exit v5

    invoke-virtual {v3, v6, v1}, Lfx0;->r(Ljava/lang/String;Ljava/lang/Boolean;)V

    new-instance v5, Lfx0;

    invoke-direct {v5}, Lfx0;-><init>()V

    iget-object v6, v8, Lads_mobile_sdk/fp0;->h:Ljava/lang/String;

    iget-object v7, v8, Lads_mobile_sdk/fp0;->d:Ljava/lang/Object;

    check-cast v7, Lads_mobile_sdk/qp0;

    iget-object v12, v8, Lads_mobile_sdk/fp0;->i:Ljava/lang/Object;

    check-cast v12, Landroid/view/View;

    iget-boolean v13, v8, Lads_mobile_sdk/fp0;->j:Z

    const-string v14, "asset_id"

    invoke-virtual {v5, v14, v6}, Lfx0;->s(Ljava/lang/String;Ljava/lang/String;)V

    const-string v6, "template"

    iget-object v14, v7, Lads_mobile_sdk/qp0;->k:Lads_mobile_sdk/it1;

    iget v14, v14, Lads_mobile_sdk/it1;->a:I

    new-instance v15, Ljava/lang/Integer;

    invoke-direct {v15, v14}, Ljava/lang/Integer;-><init>(I)V

    invoke-virtual {v5, v15, v6}, Lfx0;->q(Ljava/lang/Number;Ljava/lang/String;)V

    const-string v6, "view_aware_api_used"

    invoke-virtual {v5, v6, v1}, Lfx0;->r(Ljava/lang/String;Ljava/lang/Boolean;)V

    const-string v6, "custom_mute_requested"

    iget-object v14, v7, Lads_mobile_sdk/qp0;->m:Lxb1;

    invoke-interface {v14}, Lxb1;->i()Z

    move-result v14

    invoke-static {v14}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v14

    invoke-virtual {v5, v6, v14}, Lfx0;->r(Ljava/lang/String;Ljava/lang/Boolean;)V

    invoke-virtual {v7}, Lads_mobile_sdk/qp0;->k()Z

    move-result v6

    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v6

    const-string v14, "custom_mute_enabled"

    invoke-virtual {v5, v14, v6}, Lfx0;->r(Ljava/lang/String;Ljava/lang/Boolean;)V

    const-string v6, "has_custom_click_handler"

    iget-object v14, v7, Lads_mobile_sdk/qp0;->t:Lads_mobile_sdk/ph0;

    monitor-enter v14

    monitor-exit v14

    invoke-virtual {v5, v6, v1}, Lfx0;->r(Ljava/lang/String;Ljava/lang/Boolean;)V

    iget-object v1, v7, Lads_mobile_sdk/qp0;->g:Lfx0;

    new-instance v6, Lfx0;

    invoke-direct {v6}, Lfx0;-><init>()V

    const-string v14, "tracking_urls_and_actions"

    if-nez v1, :cond_1b0

    goto :goto_1b4

    :cond_1b0
    :try_start_1b0
    invoke-virtual {v1, v14}, Lfx0;->x(Ljava/lang/String;)Lfx0;

    move-result-object v6
    :try_end_1b4
    .catch Ljava/lang/Exception; {:try_start_1b0 .. :try_end_1b4} :catch_1b4

    :catch_1b4
    :goto_1b4
    const-string v1, "click_string"

    const-string v14, ""

    invoke-static {v6, v1, v14}, Lads_mobile_sdk/bw2;->a(Lfx0;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iget-object v6, v7, Lads_mobile_sdk/qp0;->n:Lads_mobile_sdk/ux2;

    sget-object v14, Lads_mobile_sdk/fw0;->f0:Lads_mobile_sdk/fw0;

    iget-object v15, v7, Lads_mobile_sdk/qp0;->o:Lads_mobile_sdk/kh3;

    sget-object v9, Lba0;->a:Lba0;

    invoke-static {}, Lads_mobile_sdk/hh3;->b()Lads_mobile_sdk/gh3;

    move-result-object v11

    iget-object v11, v11, Lads_mobile_sdk/gh3;->a:Lads_mobile_sdk/rg3;

    if-nez v11, :cond_212

    invoke-static {v6, v14, v9, v15}, Lads_mobile_sdk/ux2;->a(Lads_mobile_sdk/ux2;Lads_mobile_sdk/fw0;Ljava/util/List;Lads_mobile_sdk/kh3;)Lads_mobile_sdk/wk2;

    move-result-object v6

    :try_start_1d0
    iget-object v11, v7, Lads_mobile_sdk/qp0;->j:Lads_mobile_sdk/k8;

    invoke-virtual {v11, v12, v1}, Lads_mobile_sdk/k8;->a(Landroid/view/View;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1
    :try_end_1d6
    .catchall {:try_start_1d0 .. :try_end_1d6} :catchall_1da

    invoke-virtual {v6}, Lads_mobile_sdk/rg3;->close()V

    goto :goto_21f

    :catchall_1da
    move-exception v0

    :try_start_1db
    invoke-virtual {v6, v0}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v1, v0, Lox2;

    if-nez v1, :cond_20b

    invoke-virtual {v6, v0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of v1, v0, Lza2;

    if-nez v1, :cond_203

    instance-of v1, v0, Ljava/util/concurrent/CancellationException;

    if-nez v1, :cond_1fb

    instance-of v1, v0, Lads_mobile_sdk/mv0;

    if-eqz v1, :cond_1f5

    throw v0

    :catchall_1f2
    move-exception v0

    move-object v1, v0

    goto :goto_20c

    :cond_1f5
    new-instance v1, Lads_mobile_sdk/tu0;

    invoke-direct {v1, v0}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw v1

    :cond_1fb
    new-instance v1, Lads_mobile_sdk/ou0;

    check-cast v0, Ljava/util/concurrent/CancellationException;

    invoke-direct {v1, v0}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw v1

    :cond_203
    new-instance v1, Lads_mobile_sdk/uw0;

    check-cast v0, Lza2;

    invoke-direct {v1, v0}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw v1

    :cond_20b
    throw v0
    :try_end_20c
    .catchall {:try_start_1db .. :try_end_20c} :catchall_1f2

    :goto_20c
    :try_start_20c
    throw v1
    :try_end_20d
    .catchall {:try_start_20c .. :try_end_20d} :catchall_20d

    :catchall_20d
    move-exception v0

    invoke-static {v6, v1}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0

    :cond_212
    invoke-static {v14, v9, v10}, Lads_mobile_sdk/hh3;->a(Lads_mobile_sdk/fw0;Ljava/util/List;Z)Lads_mobile_sdk/rg3;

    move-result-object v6

    :try_start_216
    iget-object v11, v7, Lads_mobile_sdk/qp0;->j:Lads_mobile_sdk/k8;

    invoke-virtual {v11, v12, v1}, Lads_mobile_sdk/k8;->a(Landroid/view/View;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1
    :try_end_21c
    .catchall {:try_start_216 .. :try_end_21c} :catchall_388

    invoke-virtual {v6}, Lads_mobile_sdk/rg3;->close()V

    :goto_21f
    const-string v6, "click_signals"

    invoke-virtual {v5, v6, v1}, Lfx0;->s(Ljava/lang/String;Ljava/lang/String;)V

    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const-string v6, "open_chrome_custom_tab"

    invoke-virtual {v5, v6, v1}, Lfx0;->r(Ljava/lang/String;Ljava/lang/Boolean;)V

    sget v6, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v11, 0x1e

    if-lt v6, v11, :cond_23b

    const-string v6, "try_fallback_for_deep_link"

    invoke-virtual {v5, v6, v1}, Lfx0;->r(Ljava/lang/String;Ljava/lang/Boolean;)V

    const-string v6, "in_app_link_handling_for_android_11_enabled"

    invoke-virtual {v5, v6, v1}, Lfx0;->r(Ljava/lang/String;Ljava/lang/Boolean;)V

    :cond_23b
    iget-object v6, v7, Lads_mobile_sdk/qp0;->I:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v6}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v6

    if-eqz v6, :cond_25b

    iget-object v6, v7, Lads_mobile_sdk/qp0;->g:Lfx0;

    const-string v7, "allow_custom_click_gesture"

    if-nez v6, :cond_24a

    goto :goto_253

    :cond_24a
    :try_start_24a
    invoke-virtual {v6, v7}, Lfx0;->v(Ljava/lang/String;)Lkw0;

    move-result-object v6

    invoke-virtual {v6}, Lkw0;->b()Z

    move-result v6
    :try_end_252
    .catch Ljava/lang/Exception; {:try_start_24a .. :try_end_252} :catch_253

    goto :goto_254

    :catch_253
    :goto_253
    move v6, v4

    :goto_254
    if-eqz v6, :cond_25b

    const-string v6, "custom_click_gesture_eligible"

    invoke-virtual {v5, v6, v1}, Lfx0;->r(Ljava/lang/String;Ljava/lang/Boolean;)V

    :cond_25b
    if-eqz v13, :cond_262

    const-string v6, "is_custom_click_gesture"

    invoke-virtual {v5, v6, v1}, Lfx0;->r(Ljava/lang/String;Ljava/lang/Boolean;)V

    :cond_262
    const-string v1, "click"

    invoke-virtual {v3, v1, v5}, Lfx0;->o(Ljava/lang/String;Lkw0;)V

    new-instance v1, Lfx0;

    invoke-direct {v1}, Lfx0;-><init>()V

    iget-object v5, v8, Lads_mobile_sdk/fp0;->d:Ljava/lang/Object;

    check-cast v5, Lads_mobile_sdk/qp0;

    iget-object v6, v5, Lads_mobile_sdk/qp0;->p:Lx43;

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v6

    const-string v11, "time_from_last_touch_down"

    iget-wide v12, v5, Lads_mobile_sdk/qp0;->G:J

    sub-long v12, v6, v12

    new-instance v14, Ljava/lang/Long;

    invoke-direct {v14, v12, v13}, Ljava/lang/Long;-><init>(J)V

    invoke-virtual {v1, v14, v11}, Lfx0;->q(Ljava/lang/Number;Ljava/lang/String;)V

    const-string v11, "time_from_last_touch"

    iget-wide v12, v5, Lads_mobile_sdk/qp0;->H:J

    sub-long/2addr v6, v12

    new-instance v5, Ljava/lang/Long;

    invoke-direct {v5, v6, v7}, Ljava/lang/Long;-><init>(J)V

    invoke-virtual {v1, v5, v11}, Lfx0;->q(Ljava/lang/Number;Ljava/lang/String;)V

    const-string v5, "touch_signal"

    invoke-virtual {v3, v5, v1}, Lfx0;->o(Ljava/lang/String;Lkw0;)V

    iget-object v1, v8, Lads_mobile_sdk/fp0;->d:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/qp0;

    iget-object v5, v1, Lads_mobile_sdk/qp0;->n:Lads_mobile_sdk/ux2;

    sget-object v6, Lads_mobile_sdk/fw0;->g0:Lads_mobile_sdk/fw0;

    iget-object v7, v1, Lads_mobile_sdk/qp0;->o:Lads_mobile_sdk/kh3;

    invoke-static {}, Lads_mobile_sdk/hh3;->b()Lads_mobile_sdk/gh3;

    move-result-object v11

    iget-object v11, v11, Lads_mobile_sdk/gh3;->a:Lads_mobile_sdk/rg3;

    if-nez v11, :cond_319

    invoke-static {v5, v6, v9, v7}, Lads_mobile_sdk/ux2;->a(Lads_mobile_sdk/ux2;Lads_mobile_sdk/fw0;Ljava/util/List;Lads_mobile_sdk/kh3;)Lads_mobile_sdk/wk2;

    move-result-object v5

    :try_start_2af
    iget-object v1, v1, Lads_mobile_sdk/qp0;->q:Lqx2;

    const-string v6, "google.afma.nativeAds.handleClick"

    iput-object v5, v8, Lads_mobile_sdk/fp0;->a:Ljava/lang/Object;

    iput-object v5, v8, Lads_mobile_sdk/fp0;->b:Ljava/lang/Object;

    iput v10, v8, Lads_mobile_sdk/fp0;->c:I

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v3}, Lkw0;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-interface {v1, v6, v3, v8}, Liz2;->a(Ljava/lang/String;Ljava/lang/String;Lwx;)Ljava/lang/Object;

    move-result-object v1
    :try_end_2c4
    .catchall {:try_start_2af .. :try_end_2c4} :catchall_2e0

    if-ne v1, v2, :cond_2c8

    goto/16 :goto_335

    :cond_2c8
    move-object v2, v5

    :goto_2c9
    :try_start_2c9
    check-cast v1, Lb13;

    instance-of v3, v1, Lads_mobile_sdk/av0;

    if-eqz v3, :cond_2d4

    check-cast v1, Lads_mobile_sdk/av0;

    invoke-static {v1, v4}, Lads_mobile_sdk/xh3;->a(Lads_mobile_sdk/av0;Z)V
    :try_end_2d4
    .catchall {:try_start_2c9 .. :try_end_2d4} :catchall_2d6

    :cond_2d4
    const/4 v1, 0x0

    goto :goto_2d9

    :catchall_2d6
    move-exception v0

    move-object v1, v5

    goto :goto_2de

    :goto_2d9
    invoke-static {v5, v1}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    goto/16 :goto_34b

    :goto_2de
    move-object v5, v2

    goto :goto_2e2

    :catchall_2e0
    move-exception v0

    move-object v1, v5

    :goto_2e2
    :try_start_2e2
    invoke-virtual {v5, v0}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v2, v0, Lox2;

    if-nez v2, :cond_312

    invoke-virtual {v5, v0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of v2, v0, Lza2;

    if-nez v2, :cond_30a

    instance-of v2, v0, Ljava/util/concurrent/CancellationException;

    if-nez v2, :cond_302

    instance-of v2, v0, Lads_mobile_sdk/mv0;

    if-eqz v2, :cond_2fc

    throw v0

    :catchall_2f9
    move-exception v0

    move-object v2, v0

    goto :goto_313

    :cond_2fc
    new-instance v2, Lads_mobile_sdk/tu0;

    invoke-direct {v2, v0}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw v2

    :cond_302
    new-instance v2, Lads_mobile_sdk/ou0;

    check-cast v0, Ljava/util/concurrent/CancellationException;

    invoke-direct {v2, v0}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw v2

    :cond_30a
    new-instance v2, Lads_mobile_sdk/uw0;

    check-cast v0, Lza2;

    invoke-direct {v2, v0}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw v2

    :cond_312
    throw v0
    :try_end_313
    .catchall {:try_start_2e2 .. :try_end_313} :catchall_2f9

    :goto_313
    :try_start_313
    throw v2
    :try_end_314
    .catchall {:try_start_313 .. :try_end_314} :catchall_314

    :catchall_314
    move-exception v0

    invoke-static {v1, v2}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0

    :cond_319
    invoke-static {v6, v9, v10}, Lads_mobile_sdk/hh3;->a(Lads_mobile_sdk/fw0;Ljava/util/List;Z)Lads_mobile_sdk/rg3;

    move-result-object v5

    :try_start_31d
    iget-object v1, v1, Lads_mobile_sdk/qp0;->q:Lqx2;

    const-string v6, "google.afma.nativeAds.handleClick"

    iput-object v5, v8, Lads_mobile_sdk/fp0;->a:Ljava/lang/Object;

    iput-object v5, v8, Lads_mobile_sdk/fp0;->b:Ljava/lang/Object;

    const/4 v7, 0x2

    iput v7, v8, Lads_mobile_sdk/fp0;->c:I

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v3}, Lkw0;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-interface {v1, v6, v3, v8}, Liz2;->a(Ljava/lang/String;Ljava/lang/String;Lwx;)Ljava/lang/Object;

    move-result-object v1
    :try_end_333
    .catchall {:try_start_31d .. :try_end_333} :catchall_34f

    if-ne v1, v2, :cond_337

    :goto_335
    move-object v11, v2

    goto :goto_34c

    :cond_337
    move-object v2, v5

    :goto_338
    :try_start_338
    check-cast v1, Lb13;

    instance-of v3, v1, Lads_mobile_sdk/av0;

    if-eqz v3, :cond_343

    check-cast v1, Lads_mobile_sdk/av0;

    invoke-static {v1, v4}, Lads_mobile_sdk/xh3;->a(Lads_mobile_sdk/av0;Z)V
    :try_end_343
    .catchall {:try_start_338 .. :try_end_343} :catchall_345

    :cond_343
    const/4 v1, 0x0

    goto :goto_348

    :catchall_345
    move-exception v0

    move-object v1, v5

    goto :goto_34d

    :goto_348
    invoke-static {v5, v1}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    :goto_34b
    move-object v11, v0

    :goto_34c
    return-object v11

    :goto_34d
    move-object v5, v2

    goto :goto_351

    :catchall_34f
    move-exception v0

    move-object v1, v5

    :goto_351
    :try_start_351
    invoke-virtual {v5, v0}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v2, v0, Lox2;

    if-nez v2, :cond_381

    invoke-virtual {v5, v0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of v2, v0, Lza2;

    if-nez v2, :cond_379

    instance-of v2, v0, Ljava/util/concurrent/CancellationException;

    if-nez v2, :cond_371

    instance-of v2, v0, Lads_mobile_sdk/mv0;

    if-eqz v2, :cond_36b

    throw v0

    :catchall_368
    move-exception v0

    move-object v2, v0

    goto :goto_382

    :cond_36b
    new-instance v2, Lads_mobile_sdk/tu0;

    invoke-direct {v2, v0}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw v2

    :cond_371
    new-instance v2, Lads_mobile_sdk/ou0;

    check-cast v0, Ljava/util/concurrent/CancellationException;

    invoke-direct {v2, v0}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw v2

    :cond_379
    new-instance v2, Lads_mobile_sdk/uw0;

    check-cast v0, Lza2;

    invoke-direct {v2, v0}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw v2

    :cond_381
    throw v0
    :try_end_382
    .catchall {:try_start_351 .. :try_end_382} :catchall_368

    :goto_382
    :try_start_382
    throw v2
    :try_end_383
    .catchall {:try_start_382 .. :try_end_383} :catchall_383

    :catchall_383
    move-exception v0

    invoke-static {v1, v2}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0

    :catchall_388
    move-exception v0

    :try_start_389
    invoke-virtual {v6, v0}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v1, v0, Lox2;

    if-nez v1, :cond_3b9

    invoke-virtual {v6, v0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of v1, v0, Lza2;

    if-nez v1, :cond_3b1

    instance-of v1, v0, Ljava/util/concurrent/CancellationException;

    if-nez v1, :cond_3a9

    instance-of v1, v0, Lads_mobile_sdk/mv0;

    if-eqz v1, :cond_3a3

    throw v0

    :catchall_3a0
    move-exception v0

    move-object v1, v0

    goto :goto_3ba

    :cond_3a3
    new-instance v1, Lads_mobile_sdk/tu0;

    invoke-direct {v1, v0}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw v1

    :cond_3a9
    new-instance v1, Lads_mobile_sdk/ou0;

    check-cast v0, Ljava/util/concurrent/CancellationException;

    invoke-direct {v1, v0}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw v1

    :cond_3b1
    new-instance v1, Lads_mobile_sdk/uw0;

    check-cast v0, Lza2;

    invoke-direct {v1, v0}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw v1

    :cond_3b9
    throw v0
    :try_end_3ba
    .catchall {:try_start_389 .. :try_end_3ba} :catchall_3a0

    :goto_3ba
    :try_start_3ba
    throw v1
    :try_end_3bb
    .catchall {:try_start_3ba .. :try_end_3bb} :catchall_3bb

    :catchall_3bb
    move-exception v0

    invoke-static {v6, v1}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0

    :pswitch_data_3c0
    .packed-switch 0x0
        :pswitch_ad  #00000000
    .end packed-switch
.end method
