.class public final Lads_mobile_sdk/ep3;
.super Lads_mobile_sdk/k61;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final c:Lads_mobile_sdk/ko3;

.field public final d:Lads_mobile_sdk/qw;

.field public final e:Lads_mobile_sdk/qr0;

.field public final f:Lvy;

.field public final g:Lvy;

.field public final h:Lads_mobile_sdk/ux2;

.field public final i:Lads_mobile_sdk/ah0;

.field public final j:Ljx2;

.field public final k:Lhv0;

.field public final l:Lw82;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/ko3;Lads_mobile_sdk/qw;Lads_mobile_sdk/qr0;Lvy;Lvy;Lads_mobile_sdk/ux2;Lads_mobile_sdk/ah0;Ljx2;)V
    .registers 11

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0, v0, v1}, Lads_mobile_sdk/k61;-><init>(Lads_mobile_sdk/fw0;I)V

    iput-object p1, p0, Lads_mobile_sdk/ep3;->c:Lads_mobile_sdk/ko3;

    iput-object p2, p0, Lads_mobile_sdk/ep3;->d:Lads_mobile_sdk/qw;

    iput-object p3, p0, Lads_mobile_sdk/ep3;->e:Lads_mobile_sdk/qr0;

    iput-object p4, p0, Lads_mobile_sdk/ep3;->f:Lvy;

    iput-object p5, p0, Lads_mobile_sdk/ep3;->g:Lvy;

    iput-object p6, p0, Lads_mobile_sdk/ep3;->h:Lads_mobile_sdk/ux2;

    iput-object p7, p0, Lads_mobile_sdk/ep3;->i:Lads_mobile_sdk/ah0;

    iput-object p8, p0, Lads_mobile_sdk/ep3;->j:Ljx2;

    invoke-static {}, Lw53;->b()Lhv0;

    move-result-object p1

    iput-object p1, p0, Lads_mobile_sdk/ep3;->k:Lhv0;

    new-instance p1, Lxm0;

    const/4 p2, 0x3

    invoke-direct {p1, p2, p0}, Lxm0;-><init>(ILjava/lang/Object;)V

    new-instance p2, Lw82;

    invoke-direct {p2, p1}, Lw82;-><init>(Lzj0;)V

    iput-object p2, p0, Lads_mobile_sdk/ep3;->l:Lw82;

    return-void
.end method

.method public static final a(Lads_mobile_sdk/ep3;Lwx;)Ljava/lang/Object;
    .registers 13

    .prologue
    sget-object v0, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    iget-object v1, p0, Lads_mobile_sdk/ep3;->e:Lads_mobile_sdk/qr0;

    instance-of v2, p1, Lads_mobile_sdk/bp3;

    if-eqz v2, :cond_17

    move-object v2, p1

    check-cast v2, Lads_mobile_sdk/bp3;

    iget v3, v2, Lads_mobile_sdk/bp3;->d:I

    const/high16 v4, -0x80000000

    and-int v5, v3, v4

    if-eqz v5, :cond_17

    sub-int/2addr v3, v4

    iput v3, v2, Lads_mobile_sdk/bp3;->d:I

    goto :goto_1c

    :cond_17
    new-instance v2, Lads_mobile_sdk/bp3;

    invoke-direct {v2, p0, p1}, Lads_mobile_sdk/bp3;-><init>(Lads_mobile_sdk/ep3;Lwx;)V

    :goto_1c
    iget-object p1, v2, Lads_mobile_sdk/bp3;->b:Ljava/lang/Object;

    iget v3, v2, Lads_mobile_sdk/bp3;->d:I

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    sget-object v8, Lwy;->a:Lwy;

    if-eqz v3, :cond_3d

    if-eq v3, v6, :cond_37

    if-ne v3, v7, :cond_31

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto/16 :goto_196

    :cond_31
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v5

    :cond_37
    iget-object p0, v2, Lads_mobile_sdk/bp3;->a:Lads_mobile_sdk/ep3;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_96

    :cond_3d
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iput-object p0, v2, Lads_mobile_sdk/bp3;->a:Lads_mobile_sdk/ep3;

    iput v6, v2, Lads_mobile_sdk/bp3;->d:I

    new-instance p1, Ljn;

    invoke-static {v2}, Lpy2;->A(Lvx;)Lvx;

    move-result-object v3

    invoke-direct {p1, v6, v3}, Ljn;-><init>(ILvx;)V

    invoke-virtual {p1}, Ljn;->t()V

    :try_start_50
    iget-object v3, p0, Lads_mobile_sdk/ep3;->c:Lads_mobile_sdk/ko3;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v6, "gads:webview_initialization_executor:enabled"

    sget-object v9, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {v1, v6, v9, v0}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/Boolean;

    invoke-virtual {v6}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v6
    :try_end_63
    .catch Ljava/lang/Exception; {:try_start_50 .. :try_end_63} :catch_6a

    iget-object v9, p0, Lads_mobile_sdk/ep3;->d:Lads_mobile_sdk/qw;

    if-eqz v6, :cond_6c

    :try_start_67
    iget-object v6, v9, Lads_mobile_sdk/qw;->i:Loa1;

    goto :goto_6e

    :catch_6a
    move-exception v1

    goto :goto_85

    :cond_6c
    iget-object v6, v9, Lads_mobile_sdk/qw;->d:Loa1;

    :goto_6e
    const-string v9, "gads:run_ui_thread_webview_startup_tasks"

    sget-object v10, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {v1, v9, v10, v0}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    new-instance v9, Lads_mobile_sdk/cp3;

    invoke-direct {v9, p1}, Lads_mobile_sdk/cp3;-><init>(Ljn;)V

    invoke-virtual {v3, v6, v1, v9}, Lads_mobile_sdk/ko3;->a(Loa1;ZLads_mobile_sdk/cp3;)V
    :try_end_84
    .catch Ljava/lang/Exception; {:try_start_67 .. :try_end_84} :catch_6a

    goto :goto_8e

    :goto_85
    new-instance v3, Lads_mobile_sdk/bv0;

    const/4 v6, 0x6

    invoke-direct {v3, v4, v5, v1, v6}, Lads_mobile_sdk/bv0;-><init>(ILjava/lang/String;Ljava/lang/Throwable;I)V

    invoke-virtual {p1, v3}, Ljn;->resumeWith(Ljava/lang/Object;)V

    :goto_8e
    invoke-virtual {p1}, Ljn;->r()Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v8, :cond_96

    goto/16 :goto_198

    :cond_96
    :goto_96
    check-cast p1, Lb13;

    instance-of v1, p1, Lads_mobile_sdk/hv0;

    if-eqz v1, :cond_176

    check-cast p1, Lads_mobile_sdk/hv0;

    iget-object p1, p1, Lads_mobile_sdk/hv0;->b:Ljava/lang/Object;

    check-cast p1, Lu53;

    invoke-static {}, Lads_mobile_sdk/hh3;->a()Lads_mobile_sdk/rg3;

    move-result-object v1

    invoke-virtual {v1}, Lads_mobile_sdk/rg3;->e()Lads_mobile_sdk/ub2;

    move-result-object v1

    invoke-static {}, Lads_mobile_sdk/no3;->o()Lj13;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {p1}, Lu53;->getTotalTimeInUiThreadMillis()Ljava/lang/Long;

    move-result-object v4

    if-eqz v4, :cond_c5

    invoke-virtual {v4}, Ljava/lang/Number;->longValue()J

    move-result-wide v9

    invoke-virtual {v3}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v4, v3, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v4, Lads_mobile_sdk/no3;

    invoke-static {v4, v9, v10}, Lads_mobile_sdk/no3;->h(Lads_mobile_sdk/no3;J)V

    :cond_c5
    invoke-interface {p1}, Lu53;->getMaxTimePerTaskInUiThreadMillis()Ljava/lang/Long;

    move-result-object v4

    if-eqz v4, :cond_d9

    invoke-virtual {v4}, Ljava/lang/Number;->longValue()J

    move-result-wide v9

    invoke-virtual {v3}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v4, v3, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v4, Lads_mobile_sdk/no3;

    invoke-static {v4, v9, v10}, Lads_mobile_sdk/no3;->f(Lads_mobile_sdk/no3;J)V

    :cond_d9
    invoke-interface {p1}, Lu53;->b()Ljava/util/List;

    move-result-object v4

    if-eqz v4, :cond_10e

    iget-object v6, v3, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v6, Lads_mobile_sdk/no3;

    invoke-static {v6}, Lads_mobile_sdk/no3;->d(Lads_mobile_sdk/no3;)Lw63;

    move-result-object v6

    invoke-static {v6}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v3}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v6, v3, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v6, Lads_mobile_sdk/no3;

    invoke-static {v6}, Lads_mobile_sdk/no3;->d(Lads_mobile_sdk/no3;)Lw63;

    move-result-object v9

    move-object v10, v9

    check-cast v10, Lads_mobile_sdk/j;

    iget-boolean v10, v10, Lads_mobile_sdk/j;->a:Z

    if-nez v10, :cond_107

    invoke-static {v9}, Li10;->I(Lw63;)Lw63;

    move-result-object v9

    invoke-static {v6, v9}, Lads_mobile_sdk/no3;->i(Lads_mobile_sdk/no3;Lw63;)V

    :cond_107
    invoke-static {v6}, Lads_mobile_sdk/no3;->d(Lads_mobile_sdk/no3;)Lw63;

    move-result-object v6

    invoke-static {v4, v6}, Lads_mobile_sdk/iu0;->a(Ljava/lang/Iterable;Lw63;)V

    :cond_10e
    invoke-interface {p1}, Lu53;->a()Ljava/util/List;

    move-result-object p1

    if-eqz p1, :cond_143

    iget-object v4, v3, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v4, Lads_mobile_sdk/no3;

    invoke-static {v4}, Lads_mobile_sdk/no3;->c(Lads_mobile_sdk/no3;)Lw63;

    move-result-object v4

    invoke-static {v4}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v3}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v4, v3, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v4, Lads_mobile_sdk/no3;

    invoke-static {v4}, Lads_mobile_sdk/no3;->c(Lads_mobile_sdk/no3;)Lw63;

    move-result-object v6

    move-object v9, v6

    check-cast v9, Lads_mobile_sdk/j;

    iget-boolean v9, v9, Lads_mobile_sdk/j;->a:Z

    if-nez v9, :cond_13c

    invoke-static {v6}, Li10;->I(Lw63;)Lw63;

    move-result-object v6

    invoke-static {v4, v6}, Lads_mobile_sdk/no3;->g(Lads_mobile_sdk/no3;Lw63;)V

    :cond_13c
    invoke-static {v4}, Lads_mobile_sdk/no3;->c(Lads_mobile_sdk/no3;)Lw63;

    move-result-object v4

    invoke-static {p1, v4}, Lads_mobile_sdk/iu0;->a(Ljava/lang/Iterable;Lw63;)V

    :cond_143
    invoke-virtual {v3}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object p1

    check-cast p1, Lads_mobile_sdk/no3;

    iput-object p1, v1, Lads_mobile_sdk/ub2;->G:Lads_mobile_sdk/no3;

    iget-object p1, p0, Lads_mobile_sdk/ep3;->e:Lads_mobile_sdk/qr0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v1, "init_profile_after_webview_startup:enabled"

    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {p1, v1, v3, v0}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_196

    iget-object p0, p0, Lads_mobile_sdk/ep3;->i:Lads_mobile_sdk/ah0;

    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/yq3;

    iput-object v5, v2, Lads_mobile_sdk/bp3;->a:Lads_mobile_sdk/ep3;

    iput v7, v2, Lads_mobile_sdk/bp3;->d:I

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p0, v2}, Lads_mobile_sdk/yq3;->d(Lads_mobile_sdk/yq3;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v8, :cond_196

    goto :goto_198

    :cond_176
    instance-of p0, p1, Lads_mobile_sdk/av0;

    if-eqz p0, :cond_196

    check-cast p1, Lads_mobile_sdk/av0;

    invoke-virtual {p1}, Lads_mobile_sdk/av0;->b()Ljava/lang/Throwable;

    move-result-object p0

    if-nez p0, :cond_189

    new-instance p0, Ljava/lang/Exception;

    const-string p1, "WebView Startup Failed"

    invoke-direct {p0, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    :cond_189
    invoke-static {}, Lads_mobile_sdk/hh3;->a()Lads_mobile_sdk/rg3;

    move-result-object p1

    invoke-virtual {p1}, Lads_mobile_sdk/rg3;->e()Lads_mobile_sdk/ub2;

    move-result-object v0

    iput-boolean v4, v0, Lads_mobile_sdk/ub2;->m:Z

    invoke-virtual {p1, p0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    :cond_196
    :goto_196
    sget-object v8, Lrg2;->a:Lrg2;

    :goto_198
    return-object v8
.end method


# virtual methods
.method public final a(Lwx;)Ljava/lang/Object;
    .registers 4

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/ep3;->l:Lw82;

    invoke-virtual {v0}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    sget-object v1, Lwy;->a:Lwy;

    if-eqz v0, :cond_19

    iget-object p0, p0, Lads_mobile_sdk/ep3;->k:Lhv0;

    invoke-virtual {p0, p1}, Lnv0;->H(Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v1, :cond_22

    return-object p0

    :cond_19
    iget-object p0, p0, Lads_mobile_sdk/ep3;->j:Ljx2;

    invoke-interface {p0, p1}, Ljx2;->b(Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v1, :cond_22

    return-object p0

    :cond_22
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method

.method public final h(Lvx;)Ljava/lang/Object;
    .registers 5

    .prologue
    iget-object p1, p0, Lads_mobile_sdk/ep3;->l:Lw82;

    invoke-virtual {p1}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_41

    iget-object p1, p0, Lads_mobile_sdk/ep3;->e:Lads_mobile_sdk/qr0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sget-object v1, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    const-string v2, "gads:webview_initialization_executor:enabled"

    invoke-virtual {p1, v2, v0, v1}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_28

    iget-object p1, p0, Lads_mobile_sdk/ep3;->g:Lvy;

    goto :goto_2a

    :cond_28
    iget-object p1, p0, Lads_mobile_sdk/ep3;->f:Lvy;

    :goto_2a
    new-instance v0, Lto;

    const/16 v1, 0x8

    const/4 v2, 0x0

    invoke-direct {v0, p0, v2, v1}, Lto;-><init>(Ljava/lang/Object;Lvx;I)V

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance p0, La42;

    invoke-direct {p0, v0, v2}, La42;-><init>(Lpk0;Lvx;)V

    const/4 v0, 0x2

    sget-object v1, Ly90;->a:Ly90;

    invoke-static {p1, v1, v2, p0, v0}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    goto :goto_46

    :cond_41
    iget-object p0, p0, Lads_mobile_sdk/ep3;->k:Lhv0;

    invoke-virtual {p0}, Lhv0;->a0()V

    :goto_46
    new-instance p0, Lads_mobile_sdk/hv0;

    sget-object p1, Lrg2;->a:Lrg2;

    invoke-direct {p0, p1}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    return-object p0
.end method
