.class public final Lads_mobile_sdk/bc;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lnt2;


# instance fields
.field public final a:Ltv2;

.field public final b:Ltv2;

.field public final synthetic c:I


# direct methods
.method public synthetic constructor <init>(Ltv2;Ltv2;I)V
    .registers 4

    iput p3, p0, Lads_mobile_sdk/bc;->c:I

    iput-object p1, p0, Lads_mobile_sdk/bc;->a:Ltv2;

    iput-object p2, p0, Lads_mobile_sdk/bc;->b:Ltv2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 14

    .prologue
    iget v0, p0, Lads_mobile_sdk/bc;->c:I

    const/4 v1, 0x0

    iget-object v2, p0, Lads_mobile_sdk/bc;->b:Ltv2;

    iget-object p0, p0, Lads_mobile_sdk/bc;->a:Ltv2;

    packed-switch v0, :pswitch_data_396

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v4, p0

    check-cast v4, Lads_mobile_sdk/nn0;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/qr0;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v3, Lads_mobile_sdk/w32;

    sget-object v0, Lads_mobile_sdk/lw0;->z:Lads_mobile_sdk/lw0;

    invoke-static {p0, v0}, Lt12;->c(Lads_mobile_sdk/qr0;Lads_mobile_sdk/lw0;)J

    move-result-wide v7

    const/4 v9, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-direct/range {v3 .. v9}, Lads_mobile_sdk/w32;-><init>(Lo23;IIJLrh1;)V

    return-object v3

    :pswitch_2c  #0x1c
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v4, p0

    check-cast v4, Lads_mobile_sdk/rl0;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/qr0;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v3, Lads_mobile_sdk/w32;

    sget-object v0, Lads_mobile_sdk/lw0;->y:Lads_mobile_sdk/lw0;

    invoke-static {p0, v0}, Lt12;->c(Lads_mobile_sdk/qr0;Lads_mobile_sdk/lw0;)J

    move-result-wide v7

    const/4 v9, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-direct/range {v3 .. v9}, Lads_mobile_sdk/w32;-><init>(Lo23;IIJLrh1;)V

    return-object v3

    :pswitch_4e  #0x1b
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/qr0;

    new-instance v0, Lads_mobile_sdk/n12;

    invoke-direct {v0, p0, v2}, Lads_mobile_sdk/n12;-><init>(Lads_mobile_sdk/qr0;Ltv2;)V

    return-object v0

    :pswitch_5a  #0x1a
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/bj3;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/qr0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v2, Lads_mobile_sdk/tr;

    sget-object v3, Lads_mobile_sdk/lw0;->T:Lads_mobile_sdk/lw0;

    invoke-static {v0, v3}, Lt12;->c(Lads_mobile_sdk/qr0;Lads_mobile_sdk/lw0;)J

    move-result-wide v3

    invoke-direct {v2, p0, v3, v4, v1}, Lads_mobile_sdk/tr;-><init>(Lads_mobile_sdk/sr;JLzj0;)V

    return-object v2

    :pswitch_78  #0x19
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/util/concurrent/Executor;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lx43;

    new-instance v1, Lads_mobile_sdk/ml1;

    invoke-direct {v1, p0, v0}, Lads_mobile_sdk/ml1;-><init>(Ljava/util/concurrent/Executor;Lx43;)V

    return-object v1

    :pswitch_8a  #0x18
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/qr0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sget-object v3, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    const-string v4, "gads:native_ad_inspector_gesture:enabled"

    invoke-virtual {p0, v4, v0, v3}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    if-eqz p0, :cond_ac

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v1, p0

    check-cast v1, Lads_mobile_sdk/hg0;

    :cond_ac
    return-object v1

    :pswitch_ad  #0x17
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v4, p0

    check-cast v4, Lads_mobile_sdk/lg0;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/qr0;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v3, Lads_mobile_sdk/w32;

    sget-object v0, Lads_mobile_sdk/lw0;->v:Lads_mobile_sdk/lw0;

    invoke-static {p0, v0}, Lt12;->c(Lads_mobile_sdk/qr0;Lads_mobile_sdk/lw0;)J

    move-result-wide v7

    const/4 v9, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-direct/range {v3 .. v9}, Lads_mobile_sdk/w32;-><init>(Lo23;IIJLrh1;)V

    return-object v3

    :pswitch_cf  #0x16
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v4, p0

    check-cast v4, Lads_mobile_sdk/e80;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/qr0;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v3, Lads_mobile_sdk/w32;

    sget-object v0, Lads_mobile_sdk/lw0;->u:Lads_mobile_sdk/lw0;

    invoke-static {p0, v0}, Lt12;->c(Lads_mobile_sdk/qr0;Lads_mobile_sdk/lw0;)J

    move-result-wide v7

    const/4 v9, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-direct/range {v3 .. v9}, Lads_mobile_sdk/w32;-><init>(Lo23;IIJLrh1;)V

    return-object v3

    :pswitch_f1  #0x15
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lly;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/zt1;

    new-instance v1, Lads_mobile_sdk/k33;

    invoke-direct {v1, p0, v0}, Lads_mobile_sdk/k33;-><init>(Lly;Lads_mobile_sdk/zt1;)V

    return-object v1

    :pswitch_103  #0x14
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lx43;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/qr0;

    new-instance v1, Lads_mobile_sdk/jk;

    invoke-direct {v1, v0, p0}, Lads_mobile_sdk/jk;-><init>(Lads_mobile_sdk/qr0;Lx43;)V

    return-object v1

    :pswitch_115  #0x13
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/mp;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/qr0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v2, Lads_mobile_sdk/tr;

    sget-object v3, Lads_mobile_sdk/lw0;->r:Lads_mobile_sdk/lw0;

    invoke-static {v0, v3}, Lt12;->c(Lads_mobile_sdk/qr0;Lads_mobile_sdk/lw0;)J

    move-result-wide v3

    invoke-direct {v2, p0, v3, v4, v1}, Lads_mobile_sdk/tr;-><init>(Lads_mobile_sdk/sr;JLzj0;)V

    return-object v2

    :pswitch_133  #0x12
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/gl;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/qr0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v2, Lads_mobile_sdk/tr;

    sget-object v3, Lads_mobile_sdk/lw0;->p:Lads_mobile_sdk/lw0;

    invoke-static {v0, v3}, Lt12;->c(Lads_mobile_sdk/qr0;Lads_mobile_sdk/lw0;)J

    move-result-wide v3

    invoke-direct {v2, p0, v3, v4, v1}, Lads_mobile_sdk/tr;-><init>(Lads_mobile_sdk/sr;JLzj0;)V

    return-object v2

    :pswitch_151  #0x11
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/e3;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/qr0;

    new-instance v1, Lads_mobile_sdk/h3;

    invoke-direct {v1, p0, v0}, Lads_mobile_sdk/h3;-><init>(Lads_mobile_sdk/e3;Lads_mobile_sdk/qr0;)V

    return-object v1

    :pswitch_163  #0x10
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v4, p0

    check-cast v4, Lads_mobile_sdk/oi;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/qr0;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v3, Lads_mobile_sdk/w32;

    sget-object v0, Lads_mobile_sdk/lw0;->o:Lads_mobile_sdk/lw0;

    invoke-static {p0, v0}, Lt12;->c(Lads_mobile_sdk/qr0;Lads_mobile_sdk/lw0;)J

    move-result-wide v7

    const/4 v9, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-direct/range {v3 .. v9}, Lads_mobile_sdk/w32;-><init>(Lo23;IIJLrh1;)V

    return-object v3

    :pswitch_185  #0xf
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/util/Optional;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Optional;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lads_mobile_sdk/kh3;

    new-instance v2, Lads_mobile_sdk/eq2;

    invoke-direct {v2}, Lads_mobile_sdk/eq2;-><init>()V

    invoke-static {p0, v2}, Lw53;->H(Ljava/util/Optional;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/eq2;

    new-instance v2, Lads_mobile_sdk/ih1;

    invoke-direct {v2}, Lads_mobile_sdk/ih1;-><init>()V

    invoke-static {v0, v2}, Lw53;->H(Ljava/util/Optional;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/ih1;

    new-instance v2, Lads_mobile_sdk/dt2;

    invoke-direct {v2}, Lads_mobile_sdk/dt2;-><init>()V

    new-instance v3, Lads_mobile_sdk/s8;

    invoke-direct {v3}, Lads_mobile_sdk/s8;-><init>()V

    invoke-direct {v1, p0, v0, v2, v3}, Lads_mobile_sdk/kh3;-><init>(Lads_mobile_sdk/eq2;Lads_mobile_sdk/ih1;Lads_mobile_sdk/dt2;Lads_mobile_sdk/s8;)V

    return-object v1

    :pswitch_1bd  #0xe
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v4, p0

    check-cast v4, Lads_mobile_sdk/lg3;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v7, p0

    check-cast v7, Lads_mobile_sdk/qr0;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v3, Lads_mobile_sdk/w32;

    sget-object p0, Lads_mobile_sdk/lw0;->R:Lads_mobile_sdk/lw0;

    invoke-static {v7, p0}, Lt12;->c(Lads_mobile_sdk/qr0;Lads_mobile_sdk/lw0;)J

    move-result-wide v0

    new-instance v5, Lrh1;

    const/4 v11, 0x0

    const/4 v12, 0x4

    const/4 v6, 0x0

    const-class v8, Lads_mobile_sdk/qr0;

    const-string v9, "topicsSignalEnabled"

    const-string v10, "topicsSignalEnabled()Z"

    invoke-direct/range {v5 .. v12}, Lrh1;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;II)V

    const/4 p0, 0x2

    const/4 v6, 0x2

    move-wide v7, v0

    move-object v9, v5

    move v5, p0

    invoke-direct/range {v3 .. v9}, Lads_mobile_sdk/w32;-><init>(Lo23;IIJLrh1;)V

    return-object v3

    :pswitch_1f0  #0xd
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v4, p0

    check-cast v4, Lads_mobile_sdk/bi;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/qr0;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v3, Lads_mobile_sdk/w32;

    sget-object v0, Lads_mobile_sdk/lw0;->m:Lads_mobile_sdk/lw0;

    invoke-static {p0, v0}, Lt12;->c(Lads_mobile_sdk/qr0;Lads_mobile_sdk/lw0;)J

    move-result-wide v7

    const/4 v9, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-direct/range {v3 .. v9}, Lads_mobile_sdk/w32;-><init>(Lo23;IIJLrh1;)V

    return-object v3

    :pswitch_212  #0xc
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/yc2;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/ae2;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lads_mobile_sdk/m41;

    const/4 v2, 0x4

    invoke-direct {v1, v2, p0, v0}, Lads_mobile_sdk/m41;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    return-object v1

    :pswitch_22b  #0xb
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v4, p0

    check-cast v4, Lads_mobile_sdk/la3;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/qr0;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v3, Lads_mobile_sdk/w32;

    sget-object v0, Lads_mobile_sdk/lw0;->P:Lads_mobile_sdk/lw0;

    invoke-static {p0, v0}, Lt12;->c(Lads_mobile_sdk/qr0;Lads_mobile_sdk/lw0;)J

    move-result-wide v7

    const/4 v9, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-direct/range {v3 .. v9}, Lads_mobile_sdk/w32;-><init>(Lo23;IIJLrh1;)V

    return-object v3

    :pswitch_24d  #0xa
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v4, p0

    check-cast v4, Lads_mobile_sdk/oe;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/qr0;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v3, Lads_mobile_sdk/w32;

    sget-object v0, Lads_mobile_sdk/lw0;->l:Lads_mobile_sdk/lw0;

    invoke-static {p0, v0}, Lt12;->c(Lads_mobile_sdk/qr0;Lads_mobile_sdk/lw0;)J

    move-result-wide v7

    const/4 v9, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-direct/range {v3 .. v9}, Lads_mobile_sdk/w32;-><init>(Lo23;IIJLrh1;)V

    return-object v3

    :pswitch_26f  #0x9
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/ws;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lq63;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lads_mobile_sdk/m41;

    const/4 v2, 0x3

    invoke-direct {v1, v2, v0, p0}, Lads_mobile_sdk/m41;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    return-object v1

    :pswitch_288  #0x8
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v4, p0

    check-cast v4, Lads_mobile_sdk/r23;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/qr0;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v3, Lads_mobile_sdk/w32;

    sget-object v0, Lads_mobile_sdk/lw0;->t:Lads_mobile_sdk/lw0;

    invoke-static {p0, v0}, Lt12;->c(Lads_mobile_sdk/qr0;Lads_mobile_sdk/lw0;)J

    move-result-wide v7

    const/4 v9, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-direct/range {v3 .. v9}, Lads_mobile_sdk/w32;-><init>(Lo23;IIJLrh1;)V

    return-object v3

    :pswitch_2aa  #0x7
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v4, p0

    check-cast v4, Lads_mobile_sdk/ac;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/qr0;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v3, Lads_mobile_sdk/w32;

    sget-object v0, Lads_mobile_sdk/lw0;->c:Lads_mobile_sdk/lw0;

    invoke-static {p0, v0}, Lt12;->c(Lads_mobile_sdk/qr0;Lads_mobile_sdk/lw0;)J

    move-result-wide v7

    const/4 v9, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-direct/range {v3 .. v9}, Lads_mobile_sdk/w32;-><init>(Lo23;IIJLrh1;)V

    return-object v3

    :pswitch_2cc  #0x6
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v4, p0

    check-cast v4, Lads_mobile_sdk/y13;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/qr0;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v3, Lads_mobile_sdk/w32;

    sget-object v0, Lads_mobile_sdk/lw0;->O:Lads_mobile_sdk/lw0;

    invoke-static {p0, v0}, Lt12;->c(Lads_mobile_sdk/qr0;Lads_mobile_sdk/lw0;)J

    move-result-wide v7

    const/4 v9, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-direct/range {v3 .. v9}, Lads_mobile_sdk/w32;-><init>(Lo23;IIJLrh1;)V

    return-object v3

    :pswitch_2ee  #0x5
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/cy0;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lvy;

    new-instance v1, Lads_mobile_sdk/dm;

    invoke-direct {v1, v0, p0}, Lads_mobile_sdk/dm;-><init>(Lvy;Lads_mobile_sdk/cy0;)V

    return-object v1

    :pswitch_300  #0x4
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v4, p0

    check-cast v4, Lads_mobile_sdk/a13;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/qr0;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v3, Lads_mobile_sdk/w32;

    sget-object v0, Lads_mobile_sdk/lw0;->N:Lads_mobile_sdk/lw0;

    invoke-static {p0, v0}, Lt12;->c(Lads_mobile_sdk/qr0;Lads_mobile_sdk/lw0;)J

    move-result-wide v7

    const/4 v9, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-direct/range {v3 .. v9}, Lads_mobile_sdk/w32;-><init>(Lo23;IIJLrh1;)V

    return-object v3

    :pswitch_322  #0x3
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lvy;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lq63;

    new-instance v1, Lads_mobile_sdk/am3;

    invoke-direct {v1, p0, v0}, Lads_mobile_sdk/am3;-><init>(Lvy;Lq63;)V

    return-object v1

    :pswitch_334  #0x2
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v4, p0

    check-cast v4, Lads_mobile_sdk/gu2;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/qr0;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v3, Lads_mobile_sdk/w32;

    sget-object v0, Lads_mobile_sdk/lw0;->L:Lads_mobile_sdk/lw0;

    invoke-static {p0, v0}, Lt12;->c(Lads_mobile_sdk/qr0;Lads_mobile_sdk/lw0;)J

    move-result-wide v7

    const/4 v9, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-direct/range {v3 .. v9}, Lads_mobile_sdk/w32;-><init>(Lo23;IIJLrh1;)V

    return-object v3

    :pswitch_356  #0x1
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/j6;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v3, v0

    check-cast v3, Lads_mobile_sdk/qr0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lads_mobile_sdk/tr;

    sget-object v1, Lads_mobile_sdk/lw0;->h:Lads_mobile_sdk/lw0;

    invoke-static {v3, v1}, Lt12;->c(Lads_mobile_sdk/qr0;Lads_mobile_sdk/lw0;)J

    move-result-wide v9

    new-instance v1, Lrh1;

    const/4 v7, 0x0

    const/4 v8, 0x3

    const/4 v2, 0x0

    const-class v4, Lads_mobile_sdk/qr0;

    const-string v5, "attributionReportingEnabled"

    const-string v6, "attributionReportingEnabled()Z"

    invoke-direct/range {v1 .. v8}, Lrh1;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;II)V

    invoke-direct {v0, p0, v9, v10, v1}, Lads_mobile_sdk/tr;-><init>(Lads_mobile_sdk/sr;JLzj0;)V

    return-object v0

    :pswitch_383  #0x0
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/qr0;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/sb;

    new-instance v1, Lads_mobile_sdk/ac;

    invoke-direct {v1, p0, v0}, Lads_mobile_sdk/ac;-><init>(Lads_mobile_sdk/qr0;Lads_mobile_sdk/sb;)V

    return-object v1

    nop

    :pswitch_data_396
    .packed-switch 0x0
        :pswitch_383  #00000000
        :pswitch_356  #00000001
        :pswitch_334  #00000002
        :pswitch_322  #00000003
        :pswitch_300  #00000004
        :pswitch_2ee  #00000005
        :pswitch_2cc  #00000006
        :pswitch_2aa  #00000007
        :pswitch_288  #00000008
        :pswitch_26f  #00000009
        :pswitch_24d  #0000000a
        :pswitch_22b  #0000000b
        :pswitch_212  #0000000c
        :pswitch_1f0  #0000000d
        :pswitch_1bd  #0000000e
        :pswitch_185  #0000000f
        :pswitch_163  #00000010
        :pswitch_151  #00000011
        :pswitch_133  #00000012
        :pswitch_115  #00000013
        :pswitch_103  #00000014
        :pswitch_f1  #00000015
        :pswitch_cf  #00000016
        :pswitch_ad  #00000017
        :pswitch_8a  #00000018
        :pswitch_78  #00000019
        :pswitch_5a  #0000001a
        :pswitch_4e  #0000001b
        :pswitch_2c  #0000001c
    .end packed-switch
.end method
