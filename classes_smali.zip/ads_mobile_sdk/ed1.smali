.class public final Lads_mobile_sdk/ed1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lnt2;


# instance fields
.field public final a:Ltv2;

.field public final b:Ltv2;

.field public final c:Ltv2;

.field public final d:Ltv2;

.field public final e:Ltv2;

.field public final f:Ltv2;

.field public final synthetic g:I


# direct methods
.method public synthetic constructor <init>(Ltv2;Ltv2;Ltv2;Ltv2;Ltv2;Ltv2;I)V
    .registers 8

    iput p7, p0, Lads_mobile_sdk/ed1;->g:I

    iput-object p1, p0, Lads_mobile_sdk/ed1;->a:Ltv2;

    iput-object p2, p0, Lads_mobile_sdk/ed1;->b:Ltv2;

    iput-object p3, p0, Lads_mobile_sdk/ed1;->c:Ltv2;

    iput-object p4, p0, Lads_mobile_sdk/ed1;->d:Ltv2;

    iput-object p5, p0, Lads_mobile_sdk/ed1;->e:Ltv2;

    iput-object p6, p0, Lads_mobile_sdk/ed1;->f:Ltv2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 14

    .prologue
    iget v0, p0, Lads_mobile_sdk/ed1;->g:I

    iget-object v1, p0, Lads_mobile_sdk/ed1;->f:Ltv2;

    iget-object v2, p0, Lads_mobile_sdk/ed1;->e:Ltv2;

    iget-object v3, p0, Lads_mobile_sdk/ed1;->d:Ltv2;

    iget-object v4, p0, Lads_mobile_sdk/ed1;->c:Ltv2;

    iget-object v5, p0, Lads_mobile_sdk/ed1;->b:Ltv2;

    iget-object p0, p0, Lads_mobile_sdk/ed1;->a:Ltv2;

    packed-switch v0, :pswitch_data_9c

    invoke-static {p0}, Lads_mobile_sdk/nj0;->a(Ltv2;)Lv03;

    move-result-object v7

    invoke-static {v5}, Lads_mobile_sdk/nj0;->a(Ltv2;)Lv03;

    move-result-object v8

    invoke-static {v4}, Lads_mobile_sdk/nj0;->a(Ltv2;)Lv03;

    move-result-object v9

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v10, p0

    check-cast v10, Lads_mobile_sdk/l7;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v11, p0

    check-cast v11, Ljava/util/concurrent/ExecutorService;

    invoke-interface {v1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v12, p0

    check-cast v12, Lads_mobile_sdk/th3;

    new-instance v6, Lads_mobile_sdk/r83;

    invoke-direct/range {v6 .. v12}, Lads_mobile_sdk/r83;-><init>(Lv03;Lv03;Lv03;Lads_mobile_sdk/l7;Ljava/util/concurrent/ExecutorService;Lads_mobile_sdk/th3;)V

    return-object v6

    :pswitch_38  #0x1
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v7, p0

    check-cast v7, Lz43;

    invoke-interface {v5}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v8, p0

    check-cast v8, Ly23;

    invoke-interface {v4}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v9, p0

    check-cast v9, Lcw2;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v10, p0

    check-cast v10, Lp23;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v11, p0

    check-cast v11, Ll53;

    invoke-interface {v1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v12, p0

    check-cast v12, Ld03;

    new-instance v6, Lads_mobile_sdk/qr0;

    invoke-direct/range {v6 .. v12}, Lads_mobile_sdk/qr0;-><init>(Lz43;Ly23;Lcw2;Lp23;Ll53;Ld03;)V

    return-object v6

    :pswitch_68  #0x0
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v7, p0

    check-cast v7, Ljava/lang/String;

    invoke-interface {v5}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result v8

    invoke-interface {v4}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v9, p0

    check-cast v9, Lads_mobile_sdk/kh3;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v10, p0

    check-cast v10, Lx63;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v11, p0

    check-cast v11, Lads_mobile_sdk/o32;

    invoke-interface {v1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v12, p0

    check-cast v12, Lads_mobile_sdk/qr0;

    new-instance v6, Lads_mobile_sdk/dd1;

    invoke-direct/range {v6 .. v12}, Lads_mobile_sdk/dd1;-><init>(Ljava/lang/String;ILads_mobile_sdk/kh3;Lx63;Lads_mobile_sdk/o32;Lads_mobile_sdk/qr0;)V

    return-object v6

    nop

    :pswitch_data_9c
    .packed-switch 0x0
        :pswitch_68  #00000000
        :pswitch_38  #00000001
    .end packed-switch
.end method
