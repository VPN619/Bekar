.class public final Lads_mobile_sdk/am;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lnt2;


# instance fields
.field public final a:Ltv2;

.field public final b:Lads_mobile_sdk/ob1;

.field public final synthetic c:I


# direct methods
.method public synthetic constructor <init>(Lads_mobile_sdk/ob1;Ltv2;I)V
    .registers 4

    iput p3, p0, Lads_mobile_sdk/am;->c:I

    iput-object p1, p0, Lads_mobile_sdk/am;->b:Lads_mobile_sdk/ob1;

    iput-object p2, p0, Lads_mobile_sdk/am;->a:Ltv2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Ltv2;Lads_mobile_sdk/ob1;I)V
    .registers 4

    iput p3, p0, Lads_mobile_sdk/am;->c:I

    iput-object p1, p0, Lads_mobile_sdk/am;->a:Ltv2;

    iput-object p2, p0, Lads_mobile_sdk/am;->b:Lads_mobile_sdk/ob1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 24

    .prologue
    move-object/from16 v0, p0

    iget v1, v0, Lads_mobile_sdk/am;->c:I

    const/4 v2, 0x3

    const/4 v4, 0x2

    const/4 v6, 0x4

    const/16 v7, 0x8

    const/4 v8, 0x0

    iget-object v9, v0, Lads_mobile_sdk/am;->b:Lads_mobile_sdk/ob1;

    iget-object v0, v0, Lads_mobile_sdk/am;->a:Ltv2;

    packed-switch v1, :pswitch_data_50a

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ly43;

    iget-object v1, v9, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/a2;

    new-instance v2, Lads_mobile_sdk/yv2;

    invoke-direct {v2, v0, v1}, Lads_mobile_sdk/yv2;-><init>(Ly43;Lads_mobile_sdk/a2;)V

    return-object v2

    :pswitch_21  #0x1b
    iget-object v1, v9, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/a2;

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/d13;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lads_mobile_sdk/ez1;

    invoke-direct {v1, v0, v7}, Lads_mobile_sdk/ez1;-><init>(Lbw2;I)V

    return-object v1

    :pswitch_37  #0x1a
    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/zt1;

    iget-object v1, v9, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v1, Lqx2;

    new-instance v2, Lads_mobile_sdk/tl1;

    invoke-direct {v2, v0, v1}, Lads_mobile_sdk/tl1;-><init>(Lads_mobile_sdk/zt1;Lqx2;)V

    return-object v2

    :pswitch_47  #0x19
    iget-object v1, v9, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/a2;

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/es;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v2, Lads_mobile_sdk/sg2;

    invoke-direct {v2, v1, v0, v8}, Lads_mobile_sdk/sg2;-><init>(Lads_mobile_sdk/a2;Lbw2;I)V

    return-object v2

    :pswitch_5d  #0x18
    iget-object v1, v9, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v1, Landroid/content/Context;

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/qr0;

    new-instance v2, Lads_mobile_sdk/s01;

    invoke-direct {v2, v1, v0}, Lads_mobile_sdk/s01;-><init>(Landroid/content/Context;Lads_mobile_sdk/qr0;)V

    return-object v2

    :pswitch_6d  #0x17
    iget-object v1, v9, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v1, Landroid/content/Context;

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/i41;

    new-instance v2, Lads_mobile_sdk/ng;

    invoke-direct {v2, v1, v0}, Lads_mobile_sdk/ng;-><init>(Landroid/content/Context;Lads_mobile_sdk/i41;)V

    return-object v2

    :pswitch_7d  #0x16
    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/zt1;

    iget-object v1, v9, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/it1;

    new-instance v2, Lads_mobile_sdk/q12;

    invoke-direct {v2, v0, v1}, Lads_mobile_sdk/q12;-><init>(Lads_mobile_sdk/zt1;Lads_mobile_sdk/it1;)V

    return-object v2

    :pswitch_8d  #0x15
    iget-object v1, v9, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v1, Landroid/content/Context;

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/mi0;

    new-instance v2, Lads_mobile_sdk/e7;

    invoke-direct {v2, v1, v0}, Lads_mobile_sdk/e7;-><init>(Landroid/content/Context;Lads_mobile_sdk/mi0;)V

    return-object v2

    :pswitch_9d  #0x14
    iget-object v1, v9, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/it1;

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lvy;

    new-instance v2, Lads_mobile_sdk/pf3;

    invoke-direct {v2, v1, v0}, Lads_mobile_sdk/pf3;-><init>(Lads_mobile_sdk/it1;Lvy;)V

    return-object v2

    :pswitch_ad  #0x13
    iget-object v1, v9, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/a2;

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/d13;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lads_mobile_sdk/ez1;

    invoke-direct {v1, v0, v6}, Lads_mobile_sdk/ez1;-><init>(Lbw2;I)V

    return-object v1

    :pswitch_c3  #0x12
    iget-object v1, v9, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v1, Landroid/content/Context;

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v6, v0

    check-cast v6, Lads_mobile_sdk/z6;

    new-instance v7, Lads_mobile_sdk/nk;

    invoke-direct {v7, v1, v6}, Lads_mobile_sdk/nk;-><init>(Landroid/content/Context;Lads_mobile_sdk/z6;)V

    new-instance v0, Ljava/io/File;

    new-instance v9, Ljava/io/File;

    invoke-virtual {v1}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v1

    iget-object v1, v1, Landroid/content/pm/ApplicationInfo;->dataDir:Ljava/lang/String;

    invoke-direct {v9, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const-string v1, "lib"

    invoke-direct {v0, v9, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v1

    sget-object v9, Lads_mobile_sdk/mk;->d:Lads_mobile_sdk/mk;

    sget-object v10, Lads_mobile_sdk/mk;->c:Lads_mobile_sdk/mk;

    sget-object v11, Lads_mobile_sdk/mk;->f:Lads_mobile_sdk/mk;

    sget-object v12, Lads_mobile_sdk/mk;->e:Lads_mobile_sdk/mk;

    sget-object v13, Lads_mobile_sdk/mk;->g:Lads_mobile_sdk/mk;

    sget-object v14, Lads_mobile_sdk/mk;->h:Lads_mobile_sdk/mk;

    sget-object v15, Lads_mobile_sdk/mk;->b:Lads_mobile_sdk/mk;

    move/from16 v16, v8

    const/4 v8, 0x0

    if-nez v1, :cond_11d

    if-eqz v6, :cond_11a

    iget-object v0, v6, Lads_mobile_sdk/z6;->a:Lads_mobile_sdk/qm1;

    const-wide/16 v19, -0x1

    const/16 v21, 0x0

    const/16 v18, 0x1399

    const-string v22, "No lib/"

    move-object/from16 v17, v0

    invoke-virtual/range {v17 .. v22}, Lads_mobile_sdk/qm1;->a(IJLjava/lang/Throwable;Ljava/lang/String;)V

    new-instance v0, Lcom/google/android/gms/tasks/TaskCompletionSource;

    invoke-direct {v0}, Lcom/google/android/gms/tasks/TaskCompletionSource;-><init>()V

    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Lcom/google/android/gms/tasks/TaskCompletionSource;->setResult(Ljava/lang/Object;)V

    invoke-virtual {v0}, Lcom/google/android/gms/tasks/TaskCompletionSource;->getTask()Lcom/google/android/gms/tasks/Task;

    :cond_11a
    :goto_11a
    move-object v0, v14

    goto/16 :goto_1c5

    :cond_11d
    new-instance v1, Ltj1;

    const/16 v17, 0x1

    sget-object v5, Lads_mobile_sdk/nk;->c:Ljava/util/regex/Pattern;

    invoke-direct {v1, v5}, Ltj1;-><init>(Ljava/util/regex/Pattern;)V

    invoke-virtual {v0, v1}, Ljava/io/File;->listFiles(Ljava/io/FilenameFilter;)[Ljava/io/File;

    move-result-object v0

    if-eqz v0, :cond_1a5

    array-length v1, v0

    if-nez v1, :cond_131

    goto/16 :goto_1a5

    :cond_131
    :try_start_131
    new-instance v1, Ljava/io/FileInputStream;

    aget-object v0, v0, v16

    invoke-direct {v1, v0}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V
    :try_end_138
    .catch Ljava/io/IOException; {:try_start_131 .. :try_end_138} :catch_18d

    const/16 v0, 0x14

    :try_start_13a
    new-array v5, v0, [B

    const/16 v18, 0x5

    invoke-virtual {v1, v5}, Ljava/io/FileInputStream;->read([B)I

    move-result v3

    if-ne v3, v0, :cond_18f

    new-array v0, v4, [B

    aput-byte v16, v0, v16

    aput-byte v16, v0, v17

    aget-byte v3, v5, v18

    if-ne v3, v4, :cond_156

    invoke-virtual {v7, v8, v5}, Lads_mobile_sdk/nk;->a(Ljava/lang/String;[B)V

    :goto_151
    move-object v0, v15

    goto :goto_189

    :catchall_153
    move-exception v0

    move-object v2, v0

    goto :goto_193

    :cond_156
    const/16 v3, 0x13

    aget-byte v3, v5, v3

    aput-byte v3, v0, v16

    const/16 v3, 0x12

    aget-byte v3, v5, v3

    aput-byte v3, v0, v17

    invoke-static {v0}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v0

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->getShort()S

    move-result v0

    if-eq v0, v2, :cond_188

    const/16 v2, 0x28

    if-eq v0, v2, :cond_186

    const/16 v2, 0x3e

    if-eq v0, v2, :cond_184

    const/16 v2, 0xb7

    if-eq v0, v2, :cond_182

    const/16 v2, 0xf3

    if-eq v0, v2, :cond_180

    invoke-virtual {v7, v8, v5}, Lads_mobile_sdk/nk;->a(Ljava/lang/String;[B)V
    :try_end_17f
    .catchall {:try_start_13a .. :try_end_17f} :catchall_153

    goto :goto_151

    :cond_180
    move-object v0, v13

    goto :goto_189

    :cond_182
    move-object v0, v12

    goto :goto_189

    :cond_184
    move-object v0, v11

    goto :goto_189

    :cond_186
    move-object v0, v10

    goto :goto_189

    :cond_188
    move-object v0, v9

    :goto_189
    :try_start_189
    invoke-virtual {v1}, Ljava/io/FileInputStream;->close()V

    goto :goto_1c5

    :catch_18d
    move-exception v0

    goto :goto_19c

    :cond_18f
    invoke-virtual {v1}, Ljava/io/FileInputStream;->close()V
    :try_end_192
    .catch Ljava/io/IOException; {:try_start_189 .. :try_end_192} :catch_18d

    goto :goto_1a3

    :goto_193
    :try_start_193
    invoke-virtual {v1}, Ljava/io/FileInputStream;->close()V
    :try_end_196
    .catchall {:try_start_193 .. :try_end_196} :catchall_197

    goto :goto_19b

    :catchall_197
    move-exception v0

    :try_start_198
    invoke-virtual {v2, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_19b
    throw v2
    :try_end_19c
    .catch Ljava/io/IOException; {:try_start_198 .. :try_end_19c} :catch_18d

    :goto_19c
    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v7, v0, v8}, Lads_mobile_sdk/nk;->a(Ljava/lang/String;[B)V

    :goto_1a3
    move-object v0, v15

    goto :goto_1c5

    :cond_1a5
    :goto_1a5
    if-eqz v6, :cond_11a

    iget-object v0, v6, Lads_mobile_sdk/z6;->a:Lads_mobile_sdk/qm1;

    const-wide/16 v19, -0x1

    const/16 v21, 0x0

    const/16 v18, 0x1399

    const-string v22, "No .so"

    move-object/from16 v17, v0

    invoke-virtual/range {v17 .. v22}, Lads_mobile_sdk/qm1;->a(IJLjava/lang/Throwable;Ljava/lang/String;)V

    new-instance v0, Lcom/google/android/gms/tasks/TaskCompletionSource;

    invoke-direct {v0}, Lcom/google/android/gms/tasks/TaskCompletionSource;-><init>()V

    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Lcom/google/android/gms/tasks/TaskCompletionSource;->setResult(Ljava/lang/Object;)V

    invoke-virtual {v0}, Lcom/google/android/gms/tasks/TaskCompletionSource;->getTask()Lcom/google/android/gms/tasks/Task;

    goto/16 :goto_11a

    :goto_1c5
    if-ne v0, v14, :cond_26a

    new-instance v0, Ljava/util/HashSet;

    const-string v1, "i686"

    const-string v2, "armv71"

    filled-new-array {v1, v2}, [Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v3

    invoke-direct {v0, v3}, Ljava/util/HashSet;-><init>(Ljava/util/Collection;)V

    const-string v3, "os.arch"

    invoke-static {v3}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_1eb

    invoke-virtual {v0, v3}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1eb

    goto :goto_21b

    :cond_1eb
    const-wide/16 v3, 0x0

    const/16 v5, 0x7e8

    :try_start_1ef
    const-class v0, Landroid/os/Build;

    const-string v14, "SUPPORTED_ABIS"

    invoke-virtual {v0, v14}, Ljava/lang/Class;->getField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v0

    invoke-virtual {v0, v8}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Ljava/lang/String;

    if-eqz v0, :cond_214

    array-length v14, v0

    if-lez v14, :cond_214

    aget-object v3, v0, v16
    :try_end_204
    .catch Ljava/lang/NoSuchFieldException; {:try_start_1ef .. :try_end_204} :catch_207
    .catch Ljava/lang/IllegalAccessException; {:try_start_1ef .. :try_end_204} :catch_205

    goto :goto_21b

    :catch_205
    move-exception v0

    goto :goto_209

    :catch_207
    move-exception v0

    goto :goto_20f

    :goto_209
    if-eqz v6, :cond_214

    invoke-virtual {v6, v5, v3, v4, v0}, Lads_mobile_sdk/z6;->a(IJLjava/lang/Exception;)V

    goto :goto_214

    :goto_20f
    if-eqz v6, :cond_214

    invoke-virtual {v6, v5, v3, v4, v0}, Lads_mobile_sdk/z6;->a(IJLjava/lang/Exception;)V

    :cond_214
    :goto_214
    sget-object v3, Landroid/os/Build;->CPU_ABI:Ljava/lang/String;

    if-eqz v3, :cond_219

    goto :goto_21b

    :cond_219
    sget-object v3, Landroid/os/Build;->CPU_ABI2:Ljava/lang/String;

    :goto_21b
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_228

    const-string v0, "Empty dev arch"

    invoke-virtual {v7, v0, v8}, Lads_mobile_sdk/nk;->a(Ljava/lang/String;[B)V

    :goto_226
    move-object v9, v15

    goto :goto_26b

    :cond_228
    invoke-virtual {v3, v1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_26b

    const-string v0, "x86"

    invoke-virtual {v3, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_237

    goto :goto_26b

    :cond_237
    const-string v0, "x86_64"

    invoke-virtual {v3, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_241

    move-object v9, v11

    goto :goto_26b

    :cond_241
    const-string v0, "arm64-v8a"

    invoke-virtual {v3, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_24b

    move-object v9, v12

    goto :goto_26b

    :cond_24b
    const-string v0, "armeabi-v7a"

    invoke-virtual {v3, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_268

    invoke-virtual {v3, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_25a

    goto :goto_268

    :cond_25a
    const-string v0, "riscv64"

    invoke-virtual {v3, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_264

    move-object v9, v13

    goto :goto_26b

    :cond_264
    invoke-virtual {v7, v3, v8}, Lads_mobile_sdk/nk;->a(Ljava/lang/String;[B)V

    goto :goto_226

    :cond_268
    :goto_268
    move-object v9, v10

    goto :goto_26b

    :cond_26a
    move-object v9, v0

    :cond_26b
    :goto_26b
    if-eqz v6, :cond_288

    invoke-virtual {v9}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v5

    iget-object v0, v6, Lads_mobile_sdk/z6;->a:Lads_mobile_sdk/qm1;

    const-wide/16 v2, -0x1

    const/4 v4, 0x0

    const/16 v1, 0x139a

    invoke-virtual/range {v0 .. v5}, Lads_mobile_sdk/qm1;->a(IJLjava/lang/Throwable;Ljava/lang/String;)V

    new-instance v0, Lcom/google/android/gms/tasks/TaskCompletionSource;

    invoke-direct {v0}, Lcom/google/android/gms/tasks/TaskCompletionSource;-><init>()V

    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {v0, v1}, Lcom/google/android/gms/tasks/TaskCompletionSource;->setResult(Ljava/lang/Object;)V

    invoke-virtual {v0}, Lcom/google/android/gms/tasks/TaskCompletionSource;->getTask()Lcom/google/android/gms/tasks/Task;

    :cond_288
    return-object v9

    :pswitch_289  #0x11
    iget-object v1, v9, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/cy0;

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lvz2;

    new-instance v2, Lads_mobile_sdk/mp3;

    invoke-direct {v2, v1, v0}, Lads_mobile_sdk/mp3;-><init>(Lads_mobile_sdk/cy0;Lvz2;)V

    return-object v2

    :pswitch_299  #0x10
    iget-object v1, v9, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v1, Landroid/content/Context;

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/qr0;

    new-instance v2, Lads_mobile_sdk/mi0;

    invoke-direct {v2, v1, v0}, Lads_mobile_sdk/mi0;-><init>(Landroid/content/Context;Lads_mobile_sdk/qr0;)V

    return-object v2

    :pswitch_2a9  #0xf
    iget-object v1, v9, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v1, Landroid/content/Context;

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/qw;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v2, Lads_mobile_sdk/oa1;->a:Lads_mobile_sdk/oa1;

    iget-object v0, v0, Lads_mobile_sdk/qw;->d:Loa1;

    new-instance v3, Lzb0;

    invoke-direct {v3, v0}, Lzb0;-><init>(Ljava/util/concurrent/Executor;)V

    invoke-static {}, Lq23;->e()Lr72;

    move-result-object v0

    invoke-static {v3, v0}, Lns2;->x(Ljy;Lly;)Lly;

    move-result-object v0

    new-instance v3, Lads_mobile_sdk/rh3;

    invoke-direct {v3}, Lads_mobile_sdk/rh3;-><init>()V

    invoke-interface {v0, v3}, Lly;->plus(Lly;)Lly;

    move-result-object v0

    invoke-static {v0}, Lw53;->a(Lly;)Lsx;

    move-result-object v0

    new-instance v3, Lads_mobile_sdk/bj;

    const/4 v4, 0x7

    invoke-direct {v3, v1, v4}, Lads_mobile_sdk/bj;-><init>(Landroid/content/Context;I)V

    invoke-static {v2, v0, v3}, Lp80;->m(Lw02;Lvy;Lzj0;)Lc42;

    move-result-object v0

    return-object v0

    :pswitch_2e2  #0xe
    const/16 v18, 0x5

    iget-object v1, v9, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v1, Landroid/content/Context;

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/qw;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v2, Lads_mobile_sdk/mv1;->a:Lads_mobile_sdk/mv1;

    iget-object v0, v0, Lads_mobile_sdk/qw;->d:Loa1;

    new-instance v3, Lzb0;

    invoke-direct {v3, v0}, Lzb0;-><init>(Ljava/util/concurrent/Executor;)V

    invoke-static {}, Lq23;->e()Lr72;

    move-result-object v0

    invoke-static {v3, v0}, Lns2;->x(Ljy;Lly;)Lly;

    move-result-object v0

    new-instance v3, Lads_mobile_sdk/rh3;

    invoke-direct {v3}, Lads_mobile_sdk/rh3;-><init>()V

    invoke-interface {v0, v3}, Lly;->plus(Lly;)Lly;

    move-result-object v0

    invoke-static {v0}, Lw53;->a(Lly;)Lsx;

    move-result-object v0

    new-instance v3, Lads_mobile_sdk/bj;

    move/from16 v4, v18

    invoke-direct {v3, v1, v4}, Lads_mobile_sdk/bj;-><init>(Landroid/content/Context;I)V

    invoke-static {v2, v0, v3}, Lp80;->m(Lw02;Lvy;Lzj0;)Lc42;

    move-result-object v0

    return-object v0

    :pswitch_31e  #0xd
    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/Context;

    iget-object v1, v9, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v1, Ljava/util/concurrent/ExecutorService;

    new-instance v2, Lads_mobile_sdk/km3;

    invoke-direct {v2, v0, v1}, Lads_mobile_sdk/km3;-><init>(Landroid/content/Context;Ljava/util/concurrent/ExecutorService;)V

    return-object v2

    :pswitch_32e  #0xc
    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/g9;

    iget-object v1, v9, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v1, Lli;

    new-instance v2, Lads_mobile_sdk/j9;

    invoke-direct {v2, v0, v1}, Lads_mobile_sdk/j9;-><init>(Lads_mobile_sdk/g9;Lli;)V

    return-object v2

    :pswitch_33e  #0xb
    iget-object v1, v9, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v1, Landroid/content/Context;

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/g0;

    new-instance v2, Lads_mobile_sdk/in3;

    invoke-direct {v2, v1, v0}, Lads_mobile_sdk/in3;-><init>(Landroid/content/Context;Lads_mobile_sdk/g0;)V

    return-object v2

    :pswitch_34e  #0xa
    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/bn0;

    iget-object v1, v9, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/a2;

    new-instance v2, Lads_mobile_sdk/im1;

    invoke-direct {v2, v0, v1}, Lads_mobile_sdk/im1;-><init>(Lads_mobile_sdk/bn0;Lads_mobile_sdk/a2;)V

    return-object v2

    :pswitch_35e  #0x9
    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/qr0;

    iget-object v1, v9, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v1, Landroid/content/Context;

    new-instance v2, Lads_mobile_sdk/ha2;

    invoke-direct {v2, v1, v0}, Lads_mobile_sdk/ha2;-><init>(Landroid/content/Context;Lads_mobile_sdk/qr0;)V

    return-object v2

    :pswitch_36e  #0x8
    iget-object v1, v9, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v1, Landroid/content/Context;

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/qw;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v2, Lads_mobile_sdk/if;->a:Lads_mobile_sdk/if;

    iget-object v0, v0, Lads_mobile_sdk/qw;->d:Loa1;

    new-instance v3, Lzb0;

    invoke-direct {v3, v0}, Lzb0;-><init>(Ljava/util/concurrent/Executor;)V

    invoke-static {}, Lq23;->e()Lr72;

    move-result-object v0

    invoke-static {v3, v0}, Lns2;->x(Ljy;Lly;)Lly;

    move-result-object v0

    new-instance v3, Lads_mobile_sdk/rh3;

    invoke-direct {v3}, Lads_mobile_sdk/rh3;-><init>()V

    invoke-interface {v0, v3}, Lly;->plus(Lly;)Lly;

    move-result-object v0

    invoke-static {v0}, Lw53;->a(Lly;)Lsx;

    move-result-object v0

    new-instance v3, Lads_mobile_sdk/bj;

    invoke-direct {v3, v1, v6}, Lads_mobile_sdk/bj;-><init>(Landroid/content/Context;I)V

    invoke-static {v2, v0, v3}, Lp80;->m(Lw02;Lvy;Lzj0;)Lc42;

    move-result-object v0

    return-object v0

    :pswitch_3a6  #0x7
    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/Context;

    iget-object v1, v9, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v1, Ljava/util/concurrent/ExecutorService;

    new-instance v2, Lads_mobile_sdk/e32;

    invoke-direct {v2, v0, v1}, Lads_mobile_sdk/e32;-><init>(Landroid/content/Context;Ljava/util/concurrent/ExecutorService;)V

    return-object v2

    :pswitch_3b6  #0x6
    iget-object v1, v9, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v1, Landroid/content/Context;

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/qw;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v2, Lads_mobile_sdk/j03;->a:Lads_mobile_sdk/j03;

    iget-object v0, v0, Lads_mobile_sdk/qw;->d:Loa1;

    new-instance v3, Lzb0;

    invoke-direct {v3, v0}, Lzb0;-><init>(Ljava/util/concurrent/Executor;)V

    invoke-static {}, Lq23;->e()Lr72;

    move-result-object v0

    invoke-static {v3, v0}, Lns2;->x(Ljy;Lly;)Lly;

    move-result-object v0

    new-instance v3, Lads_mobile_sdk/rh3;

    invoke-direct {v3}, Lads_mobile_sdk/rh3;-><init>()V

    invoke-interface {v0, v3}, Lly;->plus(Lly;)Lly;

    move-result-object v0

    invoke-static {v0}, Lw53;->a(Lly;)Lsx;

    move-result-object v0

    new-instance v3, Lads_mobile_sdk/bj;

    invoke-direct {v3, v1, v4}, Lads_mobile_sdk/bj;-><init>(Landroid/content/Context;I)V

    invoke-static {v2, v0, v3}, Lp80;->m(Lw02;Lvy;Lzj0;)Lc42;

    move-result-object v0

    return-object v0

    :pswitch_3ee  #0x5
    iget-object v1, v9, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v1, Landroid/content/Context;

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/qw;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v3, Lads_mobile_sdk/f33;->a:Lads_mobile_sdk/f33;

    iget-object v0, v0, Lads_mobile_sdk/qw;->d:Loa1;

    new-instance v4, Lzb0;

    invoke-direct {v4, v0}, Lzb0;-><init>(Ljava/util/concurrent/Executor;)V

    invoke-static {}, Lq23;->e()Lr72;

    move-result-object v0

    invoke-static {v4, v0}, Lns2;->x(Ljy;Lly;)Lly;

    move-result-object v0

    invoke-static {v0}, Lw53;->a(Lly;)Lsx;

    move-result-object v0

    new-instance v4, Lads_mobile_sdk/bj;

    invoke-direct {v4, v1, v2}, Lads_mobile_sdk/bj;-><init>(Landroid/content/Context;I)V

    invoke-static {v3, v0, v4}, Lp80;->m(Lw02;Lvy;Lzj0;)Lc42;

    move-result-object v0

    return-object v0

    :pswitch_41d  #0x4
    const/16 v17, 0x1

    iget-object v1, v9, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v1, Landroid/content/Context;

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/qw;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v2, Lads_mobile_sdk/kq0;->a:Lads_mobile_sdk/kq0;

    iget-object v0, v0, Lads_mobile_sdk/qw;->d:Loa1;

    new-instance v3, Lzb0;

    invoke-direct {v3, v0}, Lzb0;-><init>(Ljava/util/concurrent/Executor;)V

    invoke-static {}, Lq23;->e()Lr72;

    move-result-object v0

    invoke-static {v3, v0}, Lns2;->x(Ljy;Lly;)Lly;

    move-result-object v0

    new-instance v3, Lads_mobile_sdk/rh3;

    invoke-direct {v3}, Lads_mobile_sdk/rh3;-><init>()V

    invoke-interface {v0, v3}, Lly;->plus(Lly;)Lly;

    move-result-object v0

    invoke-static {v0}, Lw53;->a(Lly;)Lsx;

    move-result-object v0

    new-instance v3, Lads_mobile_sdk/bj;

    move/from16 v4, v17

    invoke-direct {v3, v1, v4}, Lads_mobile_sdk/bj;-><init>(Landroid/content/Context;I)V

    invoke-static {v2, v0, v3}, Lp80;->m(Lw02;Lvy;Lzj0;)Lc42;

    move-result-object v0

    return-object v0

    :pswitch_459  #0x3
    move/from16 v16, v8

    iget-object v1, v9, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v1, Landroid/content/Context;

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/qw;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v2, Lads_mobile_sdk/hj;->a:Lads_mobile_sdk/hj;

    iget-object v0, v0, Lads_mobile_sdk/qw;->d:Loa1;

    new-instance v3, Lzb0;

    invoke-direct {v3, v0}, Lzb0;-><init>(Ljava/util/concurrent/Executor;)V

    invoke-static {}, Lq23;->e()Lr72;

    move-result-object v0

    invoke-static {v3, v0}, Lns2;->x(Ljy;Lly;)Lly;

    move-result-object v0

    new-instance v3, Lads_mobile_sdk/rh3;

    invoke-direct {v3}, Lads_mobile_sdk/rh3;-><init>()V

    invoke-interface {v0, v3}, Lly;->plus(Lly;)Lly;

    move-result-object v0

    invoke-static {v0}, Lw53;->a(Lly;)Lsx;

    move-result-object v0

    new-instance v3, Lads_mobile_sdk/bj;

    move/from16 v4, v16

    invoke-direct {v3, v1, v4}, Lads_mobile_sdk/bj;-><init>(Landroid/content/Context;I)V

    invoke-static {v2, v0, v3}, Lp80;->m(Lw02;Lvy;Lzj0;)Lc42;

    move-result-object v0

    return-object v0

    :pswitch_495  #0x2
    iget-object v1, v9, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v1, Landroid/content/Context;

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/qw;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v2, Lads_mobile_sdk/u70;->a:Lads_mobile_sdk/u70;

    iget-object v0, v0, Lads_mobile_sdk/qw;->d:Loa1;

    new-instance v3, Lzb0;

    invoke-direct {v3, v0}, Lzb0;-><init>(Ljava/util/concurrent/Executor;)V

    invoke-static {}, Lq23;->e()Lr72;

    move-result-object v0

    invoke-static {v3, v0}, Lns2;->x(Ljy;Lly;)Lly;

    move-result-object v0

    new-instance v3, Lads_mobile_sdk/rh3;

    invoke-direct {v3}, Lads_mobile_sdk/rh3;-><init>()V

    invoke-interface {v0, v3}, Lly;->plus(Lly;)Lly;

    move-result-object v0

    invoke-static {v0}, Lw53;->a(Lly;)Lsx;

    move-result-object v0

    new-instance v3, Lads_mobile_sdk/bj;

    invoke-direct {v3, v1, v7}, Lads_mobile_sdk/bj;-><init>(Landroid/content/Context;I)V

    invoke-static {v2, v0, v3}, Lp80;->m(Lw02;Lvy;Lzj0;)Lc42;

    move-result-object v0

    return-object v0

    :pswitch_4cd  #0x1
    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/concurrent/ExecutorService;

    iget-object v1, v9, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/l7;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Mozilla/5.0 (Linux; Android "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    sget-object v3, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "; "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v3, Landroid/os/Build;->MODEL:Ljava/lang/String;

    const-string v4, ")"

    invoke-static {v2, v3, v4}, Ly41;->s(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    new-instance v3, Lads_mobile_sdk/s11;

    invoke-virtual {v1}, Lads_mobile_sdk/l7;->E()J

    move-result-wide v4

    invoke-direct {v3, v0, v2, v4, v5}, Lads_mobile_sdk/s11;-><init>(Ljava/util/concurrent/ExecutorService;Ljava/lang/String;J)V

    return-object v3

    :pswitch_4fa  #0x0
    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lvy;

    iget-object v1, v9, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v1, Lc73;

    new-instance v2, Lads_mobile_sdk/zl;

    invoke-direct {v2, v0, v1}, Lads_mobile_sdk/zl;-><init>(Lvy;Lc73;)V

    return-object v2

    :pswitch_data_50a
    .packed-switch 0x0
        :pswitch_4fa  #00000000
        :pswitch_4cd  #00000001
        :pswitch_495  #00000002
        :pswitch_459  #00000003
        :pswitch_41d  #00000004
        :pswitch_3ee  #00000005
        :pswitch_3b6  #00000006
        :pswitch_3a6  #00000007
        :pswitch_36e  #00000008
        :pswitch_35e  #00000009
        :pswitch_34e  #0000000a
        :pswitch_33e  #0000000b
        :pswitch_32e  #0000000c
        :pswitch_31e  #0000000d
        :pswitch_2e2  #0000000e
        :pswitch_2a9  #0000000f
        :pswitch_299  #00000010
        :pswitch_289  #00000011
        :pswitch_c3  #00000012
        :pswitch_ad  #00000013
        :pswitch_9d  #00000014
        :pswitch_8d  #00000015
        :pswitch_7d  #00000016
        :pswitch_6d  #00000017
        :pswitch_5d  #00000018
        :pswitch_47  #00000019
        :pswitch_37  #0000001a
        :pswitch_21  #0000001b
    .end packed-switch
.end method
