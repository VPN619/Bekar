.class public final Lads_mobile_sdk/cv2;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lbw2;


# instance fields
.field public final a:Lads_mobile_sdk/ha2;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/ha2;)V
    .registers 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/cv2;->a:Lads_mobile_sdk/ha2;

    return-void
.end method


# virtual methods
.method public final a(Lads_mobile_sdk/cy0;Ljava/util/Map;Lvx;)Ljava/lang/Object;
    .registers 4

    iget-object p0, p0, Lads_mobile_sdk/cv2;->a:Lads_mobile_sdk/ha2;

    invoke-virtual {p0}, Lads_mobile_sdk/ha2;->a()V

    invoke-virtual {p0}, Lads_mobile_sdk/ha2;->b()V

    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method

.method public final b()I
    .registers 1

    const/16 p0, 0x1b

    return p0
.end method
