.class public final Lads_mobile_sdk/ei3;
.super Lwx;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public a:Lads_mobile_sdk/li3;

.field public b:Ljava/lang/String;

.field public c:Ljava/util/Collection;

.field public d:Ljava/util/Iterator;

.field public e:Ljava/util/Collection;

.field public synthetic f:Ljava/lang/Object;

.field public final synthetic g:Lads_mobile_sdk/li3;

.field public h:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/li3;Lwx;)V
    .registers 3

    iput-object p1, p0, Lads_mobile_sdk/ei3;->g:Lads_mobile_sdk/li3;

    invoke-direct {p0, p2}, Lwx;-><init>(Lvx;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    iput-object p1, p0, Lads_mobile_sdk/ei3;->f:Ljava/lang/Object;

    iget p1, p0, Lads_mobile_sdk/ei3;->h:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, Lads_mobile_sdk/ei3;->h:I

    iget-object p1, p0, Lads_mobile_sdk/ei3;->g:Lads_mobile_sdk/li3;

    invoke-virtual {p1, p0}, Lads_mobile_sdk/li3;->n(Lvx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
