.class public final Lads_mobile_sdk/a81;
.super Lwx;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public a:Ljava/lang/Object;

.field public b:Ljava/lang/Object;

.field public c:Lads_mobile_sdk/rg3;

.field public d:Ljava/io/Closeable;

.field public e:Lads_mobile_sdk/g21;

.field public f:Lq63;

.field public g:Z

.field public synthetic h:Ljava/lang/Object;

.field public final synthetic i:Lads_mobile_sdk/d91;

.field public j:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/d91;Lwx;)V
    .registers 3

    iput-object p1, p0, Lads_mobile_sdk/a81;->i:Lads_mobile_sdk/d91;

    invoke-direct {p0, p2}, Lwx;-><init>(Lvx;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    iput-object p1, p0, Lads_mobile_sdk/a81;->h:Ljava/lang/Object;

    iget p1, p0, Lads_mobile_sdk/a81;->j:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, Lads_mobile_sdk/a81;->j:I

    iget-object p1, p0, Lads_mobile_sdk/a81;->i:Lads_mobile_sdk/d91;

    const/4 v0, 0x0

    invoke-static {p1, v0, v0, p0}, Lads_mobile_sdk/d91;->a(Lads_mobile_sdk/d91;Ljava/lang/String;Lfx0;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
