.class public final enum Lads_mobile_sdk/av;
.super Ljava/lang/Enum;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final b:Lns1;

.field public static final enum c:Lads_mobile_sdk/av;

.field public static final enum d:Lads_mobile_sdk/av;

.field public static final enum e:Lads_mobile_sdk/av;

.field public static final enum f:Lads_mobile_sdk/av;

.field public static final enum g:Lads_mobile_sdk/av;

.field public static final enum h:Lads_mobile_sdk/av;

.field public static final enum i:Lads_mobile_sdk/av;

.field public static final synthetic j:[Lads_mobile_sdk/av;


# instance fields
.field public final a:Lps1;


# direct methods
.method static constructor <clinit>()V
    .registers 12

    new-instance v0, Lads_mobile_sdk/av;

    const/16 v1, 0xa

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/16 v2, 0x9

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-static {v1, v2}, Ljq0;->s(Ljava/lang/Integer;Ljava/lang/Integer;)Lps1;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v4, "TOP_LEFT"

    const/4 v5, 0x0

    invoke-direct {v0, v4, v5, v3}, Lads_mobile_sdk/av;-><init>(Ljava/lang/String;ILps1;)V

    sput-object v0, Lads_mobile_sdk/av;->c:Lads_mobile_sdk/av;

    move-object v3, v1

    new-instance v1, Lads_mobile_sdk/av;

    const/16 v7, 0xe

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v3, v4}, Ljq0;->s(Ljava/lang/Integer;Ljava/lang/Integer;)Lps1;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v6, "TOP_CENTER"

    const/4 v8, 0x1

    invoke-direct {v1, v6, v8, v5}, Lads_mobile_sdk/av;-><init>(Ljava/lang/String;ILps1;)V

    sput-object v1, Lads_mobile_sdk/av;->d:Lads_mobile_sdk/av;

    move-object v5, v2

    new-instance v2, Lads_mobile_sdk/av;

    const/16 v6, 0xb

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v3, v6}, Ljq0;->s(Ljava/lang/Integer;Ljava/lang/Integer;)Lps1;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v9, "TOP_RIGHT"

    const/4 v10, 0x2

    invoke-direct {v2, v9, v10, v3}, Lads_mobile_sdk/av;-><init>(Ljava/lang/String;ILps1;)V

    sput-object v2, Lads_mobile_sdk/av;->e:Lads_mobile_sdk/av;

    new-instance v3, Lads_mobile_sdk/av;

    const/16 v9, 0xd

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    filled-new-array {v9}, [Ljava/lang/Object;

    move-result-object v9

    invoke-static {v8, v9}, Lvr0;->j(I[Ljava/lang/Object;)V

    invoke-static {v8, v9}, Ljq0;->o(I[Ljava/lang/Object;)Lps1;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v9, "CENTER"

    const/4 v10, 0x3

    invoke-direct {v3, v9, v10, v8}, Lads_mobile_sdk/av;-><init>(Ljava/lang/String;ILps1;)V

    sput-object v3, Lads_mobile_sdk/av;->f:Lads_mobile_sdk/av;

    move-object v8, v4

    new-instance v4, Lads_mobile_sdk/av;

    const/16 v9, 0xc

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-static {v9, v5}, Ljq0;->s(Ljava/lang/Integer;Ljava/lang/Integer;)Lps1;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v10, "BOTTOM_LEFT"

    const/4 v11, 0x4

    invoke-direct {v4, v10, v11, v5}, Lads_mobile_sdk/av;-><init>(Ljava/lang/String;ILps1;)V

    sput-object v4, Lads_mobile_sdk/av;->g:Lads_mobile_sdk/av;

    new-instance v5, Lads_mobile_sdk/av;

    invoke-static {v9, v8}, Ljq0;->s(Ljava/lang/Integer;Ljava/lang/Integer;)Lps1;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v10, "BOTTOM_CENTER"

    const/4 v11, 0x5

    invoke-direct {v5, v10, v11, v8}, Lads_mobile_sdk/av;-><init>(Ljava/lang/String;ILps1;)V

    sput-object v5, Lads_mobile_sdk/av;->h:Lads_mobile_sdk/av;

    move-object v8, v6

    new-instance v6, Lads_mobile_sdk/av;

    invoke-static {v9, v8}, Ljq0;->s(Ljava/lang/Integer;Ljava/lang/Integer;)Lps1;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v9, "BOTTOM_RIGHT"

    const/4 v10, 0x6

    invoke-direct {v6, v9, v10, v8}, Lads_mobile_sdk/av;-><init>(Ljava/lang/String;ILps1;)V

    sput-object v6, Lads_mobile_sdk/av;->i:Lads_mobile_sdk/av;

    filled-new-array/range {v0 .. v6}, [Lads_mobile_sdk/av;

    move-result-object v0

    sput-object v0, Lads_mobile_sdk/av;->j:[Lads_mobile_sdk/av;

    new-instance v0, Lns1;

    invoke-direct {v0, v7}, Lns1;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/av;->b:Lns1;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;ILps1;)V
    .registers 4

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput-object p3, p0, Lads_mobile_sdk/av;->a:Lps1;

    return-void
.end method

.method public static values()[Lads_mobile_sdk/av;
    .registers 1

    sget-object v0, Lads_mobile_sdk/av;->j:[Lads_mobile_sdk/av;

    invoke-virtual {v0}, [Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lads_mobile_sdk/av;

    return-object v0
.end method
