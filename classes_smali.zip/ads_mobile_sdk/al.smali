.class public final Lads_mobile_sdk/al;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lbk0;


# instance fields
.field public a:Ljava/lang/Object;

.field public b:I

.field public final synthetic c:Ljava/lang/Object;

.field public final synthetic d:Ljava/lang/Object;

.field public final synthetic t:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/dl;Landroid/net/Uri;Lvx;)V
    .registers 5

    const/4 v0, 0x0

    iput v0, p0, Lads_mobile_sdk/al;->t:I

    iput-object p1, p0, Lads_mobile_sdk/al;->c:Ljava/lang/Object;

    iput-object p2, p0, Lads_mobile_sdk/al;->d:Ljava/lang/Object;

    const/4 p1, 0x1

    invoke-direct {p0, p1, p3}, Lm82;-><init>(ILvx;)V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lvx;I)V
    .registers 6

    iput p5, p0, Lads_mobile_sdk/al;->t:I

    iput-object p1, p0, Lads_mobile_sdk/al;->a:Ljava/lang/Object;

    iput-object p2, p0, Lads_mobile_sdk/al;->c:Ljava/lang/Object;

    iput-object p3, p0, Lads_mobile_sdk/al;->d:Ljava/lang/Object;

    const/4 p1, 0x1

    invoke-direct {p0, p1, p4}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 12

    .prologue
    iget v0, p0, Lads_mobile_sdk/al;->t:I

    sget-object v1, Lrg2;->a:Lrg2;

    iget-object v2, p0, Lads_mobile_sdk/al;->d:Ljava/lang/Object;

    iget-object v3, p0, Lads_mobile_sdk/al;->c:Ljava/lang/Object;

    packed-switch v0, :pswitch_data_9e

    move-object v8, p1

    check-cast v8, Lvx;

    new-instance v4, Lads_mobile_sdk/al;

    iget-object p0, p0, Lads_mobile_sdk/al;->a:Ljava/lang/Object;

    move-object v5, p0

    check-cast v5, Lrk0;

    move-object v6, v3

    check-cast v6, Lads_mobile_sdk/cy0;

    move-object v7, v2

    check-cast v7, Lads_mobile_sdk/q6;

    const/4 v9, 0x5

    invoke-direct/range {v4 .. v9}, Lads_mobile_sdk/al;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lvx;I)V

    invoke-virtual {v4, v1}, Lads_mobile_sdk/al;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_24  #0x4
    move-object v6, p1

    check-cast v6, Lvx;

    move-object v0, v2

    new-instance v2, Lads_mobile_sdk/al;

    iget-object p0, p0, Lads_mobile_sdk/al;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/td0;

    move-object v4, v3

    check-cast v4, Lads_mobile_sdk/ji;

    move-object v5, v0

    check-cast v5, Lx4;

    const/4 v7, 0x4

    move-object v3, p0

    invoke-direct/range {v2 .. v7}, Lads_mobile_sdk/al;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lvx;I)V

    invoke-virtual {v2, v1}, Lads_mobile_sdk/al;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_3e  #0x3
    move-object v0, v2

    move-object v6, p1

    check-cast v6, Lvx;

    new-instance v2, Lads_mobile_sdk/al;

    iget-object p0, p0, Lads_mobile_sdk/al;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/r62;

    move-object v4, v3

    check-cast v4, Landroid/view/View;

    move-object v5, v0

    check-cast v5, Lads_mobile_sdk/fs0;

    const/4 v7, 0x3

    move-object v3, p0

    invoke-direct/range {v2 .. v7}, Lads_mobile_sdk/al;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lvx;I)V

    invoke-virtual {v2, v1}, Lads_mobile_sdk/al;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_58  #0x2
    move-object v0, v2

    move-object v6, p1

    check-cast v6, Lvx;

    new-instance v2, Lads_mobile_sdk/al;

    iget-object p0, p0, Lads_mobile_sdk/al;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/sb;

    move-object v4, v3

    check-cast v4, Ljava/lang/String;

    move-object v5, v0

    check-cast v5, Lads_mobile_sdk/oa;

    const/4 v7, 0x2

    move-object v3, p0

    invoke-direct/range {v2 .. v7}, Lads_mobile_sdk/al;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lvx;I)V

    invoke-virtual {v2, v1}, Lads_mobile_sdk/al;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_72  #0x1
    move-object v0, v2

    move-object v6, p1

    check-cast v6, Lvx;

    new-instance v2, Lads_mobile_sdk/al;

    iget-object p0, p0, Lads_mobile_sdk/al;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/sy0;

    move-object v4, v3

    check-cast v4, Lads_mobile_sdk/f72;

    move-object v5, v0

    check-cast v5, Lads_mobile_sdk/gj1;

    const/4 v7, 0x1

    move-object v3, p0

    invoke-direct/range {v2 .. v7}, Lads_mobile_sdk/al;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lvx;I)V

    invoke-virtual {v2, v1}, Lads_mobile_sdk/al;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_8c  #0x0
    move-object v0, v2

    check-cast p1, Lvx;

    new-instance p0, Lads_mobile_sdk/al;

    check-cast v3, Lads_mobile_sdk/dl;

    move-object v2, v0

    check-cast v2, Landroid/net/Uri;

    invoke-direct {p0, v3, v2, p1}, Lads_mobile_sdk/al;-><init>(Lads_mobile_sdk/dl;Landroid/net/Uri;Lvx;)V

    invoke-virtual {p0, v1}, Lads_mobile_sdk/al;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_data_9e
    .packed-switch 0x0
        :pswitch_8c  #00000000
        :pswitch_72  #00000001
        :pswitch_58  #00000002
        :pswitch_3e  #00000003
        :pswitch_24  #00000004
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 16

    .prologue
    iget v0, p0, Lads_mobile_sdk/al;->t:I

    const/4 v1, 0x0

    const-string v2, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v3, 0x1

    const/4 v4, 0x0

    packed-switch v0, :pswitch_data_2da

    sget-object v0, Lwy;->a:Lwy;

    iget v1, p0, Lads_mobile_sdk/al;->b:I

    if-eqz v1, :cond_1a

    if-ne v1, v3, :cond_16

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_33

    :cond_16
    invoke-static {v2}, Lz6;->w(Ljava/lang/String;)V

    goto :goto_35

    :cond_1a
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/al;->a:Ljava/lang/Object;

    check-cast p1, Lrk0;

    iget-object v1, p0, Lads_mobile_sdk/al;->c:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/cy0;

    iget-object v2, p0, Lads_mobile_sdk/al;->d:Ljava/lang/Object;

    check-cast v2, Lads_mobile_sdk/q6;

    iput v3, p0, Lads_mobile_sdk/al;->b:I

    invoke-interface {p1, v1, v2, p0}, Lrk0;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v0, :cond_33

    move-object v4, v0

    goto :goto_35

    :cond_33
    :goto_33
    sget-object v4, Lrg2;->a:Lrg2;

    :goto_35
    return-object v4

    :pswitch_36  #0x4
    sget-object v0, Lrg2;->a:Lrg2;

    iget-object v1, p0, Lads_mobile_sdk/al;->a:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/td0;

    sget-object v5, Lwy;->a:Lwy;

    iget v6, p0, Lads_mobile_sdk/al;->b:I

    if-eqz v6, :cond_4d

    if-ne v6, v3, :cond_49

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    :cond_47
    move-object v4, v0

    goto :goto_78

    :cond_49
    invoke-static {v2}, Lz6;->w(Ljava/lang/String;)V

    goto :goto_78

    :cond_4d
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, v1, Lads_mobile_sdk/td0;->k:Ltv2;

    invoke-interface {p1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lads_mobile_sdk/uo2;

    new-instance v2, Lads_mobile_sdk/vd1;

    iget-object v6, p0, Lads_mobile_sdk/al;->c:Ljava/lang/Object;

    check-cast v6, Lads_mobile_sdk/ji;

    new-instance v7, Lb11;

    const/16 v8, 0x15

    invoke-direct {v7, v1, v4, v8}, Lb11;-><init>(Ljava/lang/Object;Lvx;I)V

    invoke-direct {v2, v6, v7}, Lads_mobile_sdk/vd1;-><init>(Lads_mobile_sdk/ji;Lb11;)V

    iget-object v1, p0, Lads_mobile_sdk/al;->d:Ljava/lang/Object;

    check-cast v1, Lx4;

    iput v3, p0, Lads_mobile_sdk/al;->b:I

    iput-object v1, p1, Lads_mobile_sdk/uo2;->A:Lx4;

    iput-object v2, p1, Lads_mobile_sdk/uo2;->x:Lads_mobile_sdk/vd1;

    invoke-virtual {p1, v2}, Lads_mobile_sdk/on2;->a(Lhi1;)V

    if-ne v0, v5, :cond_47

    move-object v4, v5

    :goto_78
    return-object v4

    :pswitch_79  #0x3
    sget-object v0, Lwy;->a:Lwy;

    iget v1, p0, Lads_mobile_sdk/al;->b:I

    if-eqz v1, :cond_8a

    if-ne v1, v3, :cond_85

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_a7

    :cond_85
    invoke-static {v2}, Lz6;->w(Ljava/lang/String;)V

    move-object p1, v4

    goto :goto_a7

    :cond_8a
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/al;->a:Ljava/lang/Object;

    check-cast p1, Lads_mobile_sdk/r62;

    iget-object p1, p1, Lads_mobile_sdk/r62;->g:Lads_mobile_sdk/f72;

    iget-object v1, p0, Lads_mobile_sdk/al;->c:Ljava/lang/Object;

    check-cast v1, Landroid/view/View;

    iget-object v2, p0, Lads_mobile_sdk/al;->d:Ljava/lang/Object;

    check-cast v2, Lads_mobile_sdk/fs0;

    iput v3, p0, Lads_mobile_sdk/al;->b:I

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1, v1, v2, p0}, Lads_mobile_sdk/f72;->a(Lads_mobile_sdk/f72;Landroid/view/View;Lads_mobile_sdk/fs0;Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_a7

    move-object p1, v0

    :cond_a7
    :goto_a7
    return-object p1

    :pswitch_a8  #0x2
    sget-object v0, Lwy;->a:Lwy;

    iget v1, p0, Lads_mobile_sdk/al;->b:I

    if-eqz v1, :cond_b9

    if-ne v1, v3, :cond_b4

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_d1

    :cond_b4
    invoke-static {v2}, Lz6;->w(Ljava/lang/String;)V

    move-object p1, v4

    goto :goto_d1

    :cond_b9
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/al;->a:Ljava/lang/Object;

    check-cast p1, Lads_mobile_sdk/sb;

    iget-object v1, p0, Lads_mobile_sdk/al;->c:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    iget-object v2, p0, Lads_mobile_sdk/al;->d:Ljava/lang/Object;

    check-cast v2, Lads_mobile_sdk/oa;

    iput v3, p0, Lads_mobile_sdk/al;->b:I

    invoke-static {p1, v1, v2, p0}, Lads_mobile_sdk/sb;->a(Lads_mobile_sdk/sb;Ljava/lang/String;Lads_mobile_sdk/oa;Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_d1

    move-object p1, v0

    :cond_d1
    :goto_d1
    return-object p1

    :pswitch_d2  #0x1
    iget-object v0, p0, Lads_mobile_sdk/al;->a:Ljava/lang/Object;

    check-cast v0, Lads_mobile_sdk/sy0;

    sget-object v5, Lwy;->a:Lwy;

    iget v6, p0, Lads_mobile_sdk/al;->b:I

    if-eqz v6, :cond_e8

    if-ne v6, v3, :cond_e3

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto/16 :goto_159

    :cond_e3
    invoke-static {v2}, Lz6;->w(Ljava/lang/String;)V

    goto/16 :goto_15b

    :cond_e8
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p1, v0, Lads_mobile_sdk/sy0;->a:Lads_mobile_sdk/cy0;

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v4

    move v6, v1

    :goto_fa
    if-ge v6, v4, :cond_10f

    invoke-virtual {v0, v6}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v7

    invoke-static {v7, p1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_10c

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v2, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_10c
    add-int/lit8 v6, v6, 0x1

    goto :goto_fa

    :cond_10f
    iget-object v0, p0, Lads_mobile_sdk/al;->c:Ljava/lang/Object;

    check-cast v0, Lads_mobile_sdk/f72;

    iget-object v4, p0, Lads_mobile_sdk/al;->d:Ljava/lang/Object;

    check-cast v4, Lads_mobile_sdk/gj1;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v6

    :goto_11b
    if-ge v1, v6, :cond_148

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    add-int/lit8 v1, v1, 0x1

    check-cast v7, Landroid/view/View;

    iget-object v8, v0, Lads_mobile_sdk/f72;->c:Lads_mobile_sdk/s52;

    sget-object v9, Lads_mobile_sdk/fs0;->c:Lads_mobile_sdk/fs0;

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v8, v8, Lads_mobile_sdk/s52;->f:Lads_mobile_sdk/ah3;

    new-instance v10, Lgq1;

    const/4 v11, 0x2

    invoke-direct {v10, v4, v7, v9, v11}, Lgq1;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_13d
    invoke-virtual {v10}, Lgq1;->invoke()Ljava/lang/Object;
    :try_end_140
    .catch Ljava/lang/Exception; {:try_start_13d .. :try_end_140} :catch_141

    goto :goto_11b

    :catch_141
    move-exception v7

    const-string v9, "AddFriendlyObstructionToJavaScriptSessionService"

    invoke-virtual {v8, v9, v7}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V

    goto :goto_11b

    :cond_148
    new-instance v0, Lfx0;

    invoke-direct {v0}, Lfx0;-><init>()V

    iput v3, p0, Lads_mobile_sdk/al;->b:I

    const-string v1, "onSdkLoaded"

    invoke-virtual {p1, v0, v1, p0}, Lads_mobile_sdk/cy0;->a(Lfx0;Ljava/lang/String;Lvx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_159

    move-object v4, v5

    goto :goto_15b

    :cond_159
    :goto_159
    sget-object v4, Lrg2;->a:Lrg2;

    :goto_15b
    return-object v4

    :pswitch_15c  #0x0
    sget-object v0, Lads_mobile_sdk/fo;->a$23:Lads_mobile_sdk/fo;

    sget-object v5, Lwy;->a:Lwy;

    iget v6, p0, Lads_mobile_sdk/al;->b:I

    const-string v7, "12"

    const-string v8, "nis"

    const-string v9, "gads:nis_param_for_ara"

    if-eqz v6, :cond_17a

    if-ne v6, v3, :cond_175

    iget-object v1, p0, Lads_mobile_sdk/al;->a:Ljava/lang/Object;

    check-cast v1, Landroid/net/Uri$Builder;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto/16 :goto_24d

    :cond_175
    invoke-static {v2}, Lz6;->w(Ljava/lang/String;)V

    goto/16 :goto_2d8

    :cond_17a
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/al;->d:Ljava/lang/Object;

    check-cast p1, Landroid/net/Uri;

    const-string v2, "ase"

    invoke-virtual {p1, v2}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const-string v2, "3"

    invoke-static {p1, v2, v1}, Lk72;->f0(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result p1

    iget-object v2, p0, Lads_mobile_sdk/al;->d:Ljava/lang/Object;

    move-object v4, v2

    check-cast v4, Landroid/net/Uri;

    if-nez p1, :cond_196

    goto/16 :goto_2d8

    :cond_196
    invoke-virtual {v4}, Landroid/net/Uri;->buildUpon()Landroid/net/Uri$Builder;

    move-result-object p1

    iget-object v2, p0, Lads_mobile_sdk/al;->c:Ljava/lang/Object;

    check-cast v2, Lads_mobile_sdk/dl;

    iget-object v2, v2, Lads_mobile_sdk/dl;->d:Ln63;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v2, Ljava/util/Random;

    invoke-direct {v2}, Ljava/util/Random;-><init>()V

    const v4, 0x7fffffff

    invoke-virtual {v2, v4}, Ljava/util/Random;->nextInt(I)I

    move-result v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v2

    iget-object v4, p0, Lads_mobile_sdk/al;->c:Ljava/lang/Object;

    check-cast v4, Lads_mobile_sdk/dl;

    iget-object v4, v4, Lads_mobile_sdk/dl;->e:Lads_mobile_sdk/qr0;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v6, "gads:debug_key_param_for_ara"

    const-string v10, "uk"

    invoke-virtual {v4, v6, v10, v0}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-virtual {p1, v4, v2}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    iget-object v2, p0, Lads_mobile_sdk/al;->c:Ljava/lang/Object;

    check-cast v2, Lads_mobile_sdk/dl;

    iget-object v2, v2, Lads_mobile_sdk/dl;->b:Lads_mobile_sdk/gp3;

    iget-object v2, v2, Lads_mobile_sdk/gp3;->a:Landroid/view/MotionEvent;

    iget-object v4, p0, Lads_mobile_sdk/al;->c:Ljava/lang/Object;

    check-cast v4, Lads_mobile_sdk/dl;

    if-nez v2, :cond_1ee

    iget-object p0, v4, Lads_mobile_sdk/dl;->e:Lads_mobile_sdk/qr0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0, v9, v8, v0}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    const-string v0, "11"

    invoke-virtual {p1, p0, v0}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object p0

    invoke-virtual {p0}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object v4

    goto/16 :goto_2d8

    :cond_1ee
    iget-object v6, p0, Lads_mobile_sdk/al;->d:Ljava/lang/Object;

    check-cast v6, Landroid/net/Uri;

    invoke-virtual {p1}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object v10

    invoke-virtual {v10}, Landroid/net/Uri;->buildUpon()Landroid/net/Uri$Builder;

    move-result-object v10

    const-string v11, "asr"

    const-string v12, "1"

    invoke-virtual {v10, v11, v12}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    iget-object v11, v4, Lads_mobile_sdk/dl;->e:Lads_mobile_sdk/qr0;

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v11, v9, v8, v0}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    invoke-virtual {v10, v11, v7}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    const-string v11, "asrd"

    invoke-virtual {v6, v11}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-static {v6, v12, v1}, Lk72;->f0(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v1

    if-eqz v1, :cond_22d

    iget-object v1, v4, Lads_mobile_sdk/dl;->e:Lads_mobile_sdk/qr0;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v4, "gads:source_registration_domain_for_ara"

    const-string v6, "www.googleadservices.com"

    invoke-virtual {v1, v4, v6, v0}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v10, v1}, Landroid/net/Uri$Builder;->authority(Ljava/lang/String;)Landroid/net/Uri$Builder;

    :cond_22d
    invoke-virtual {v10}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v4, p0, Lads_mobile_sdk/al;->c:Ljava/lang/Object;

    check-cast v4, Lads_mobile_sdk/dl;

    iget-object v4, v4, Lads_mobile_sdk/dl;->c:Lads_mobile_sdk/vz;

    iput-object p1, p0, Lads_mobile_sdk/al;->a:Ljava/lang/Object;

    iput v3, p0, Lads_mobile_sdk/al;->b:I

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v4, v1, v2, p0}, Lads_mobile_sdk/vz;->a(Lads_mobile_sdk/vz;Landroid/net/Uri;Landroid/view/InputEvent;Lwx;)Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v5, :cond_24a

    move-object v4, v5

    goto/16 :goto_2d8

    :cond_24a
    move-object v13, v1

    move-object v1, p1

    move-object p1, v13

    :goto_24d
    check-cast p1, Lb13;

    if-nez p1, :cond_258

    iget-object p0, p0, Lads_mobile_sdk/al;->d:Ljava/lang/Object;

    move-object v4, p0

    check-cast v4, Landroid/net/Uri;

    goto/16 :goto_2d8

    :cond_258
    instance-of v2, p1, Lads_mobile_sdk/hv0;

    iget-object v3, p0, Lads_mobile_sdk/al;->c:Ljava/lang/Object;

    check-cast v3, Lads_mobile_sdk/dl;

    if-eqz v2, :cond_277

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, v3, Lads_mobile_sdk/dl;->e:Lads_mobile_sdk/qr0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0, v9, v8, v0}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    invoke-virtual {v1, p0, v7}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object p0

    invoke-virtual {p0}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object v4

    goto :goto_2d8

    :cond_277
    instance-of v2, p1, Lads_mobile_sdk/bv0;

    const-string v4, "9"

    if-eqz v2, :cond_2c2

    iget-object v2, v3, Lads_mobile_sdk/dl;->f:Lads_mobile_sdk/ah3;

    check-cast p1, Lads_mobile_sdk/bv0;

    iget-object v3, p1, Lads_mobile_sdk/bv0;->c:Ljava/lang/Throwable;

    const-string v5, "AttributionReportingManager.handleRegisterSource"

    invoke-virtual {v2, v5, v3}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V

    iget-object p1, p1, Lads_mobile_sdk/bv0;->c:Ljava/lang/Throwable;

    instance-of p1, p1, Ljava/lang/IllegalStateException;

    iget-object p0, p0, Lads_mobile_sdk/al;->c:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/dl;

    if-eqz p1, :cond_2ab

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p0, Lads_mobile_sdk/dl;->e:Lads_mobile_sdk/qr0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0, v9, v8, v0}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    const-string p1, "10"

    invoke-virtual {v1, p0, p1}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object p0

    invoke-virtual {p0}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object v4

    goto :goto_2d8

    :cond_2ab
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p0, Lads_mobile_sdk/dl;->e:Lads_mobile_sdk/qr0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0, v9, v8, v0}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    invoke-virtual {v1, p0, v4}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object p0

    invoke-virtual {p0}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object v4

    goto :goto_2d8

    :cond_2c2
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, v3, Lads_mobile_sdk/dl;->e:Lads_mobile_sdk/qr0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0, v9, v8, v0}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    invoke-virtual {v1, p0, v4}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object p0

    invoke-virtual {p0}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object v4

    :goto_2d8
    return-object v4

    nop

    :pswitch_data_2da
    .packed-switch 0x0
        :pswitch_15c  #00000000
        :pswitch_d2  #00000001
        :pswitch_a8  #00000002
        :pswitch_79  #00000003
        :pswitch_36  #00000004
    .end packed-switch
.end method
