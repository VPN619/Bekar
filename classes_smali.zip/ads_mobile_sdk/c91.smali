.class public final Lads_mobile_sdk/c91;
.super Lwx;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public a:Lads_mobile_sdk/d91;

.field public synthetic b:Ljava/lang/Object;

.field public final synthetic c:Lads_mobile_sdk/d91;

.field public d:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/d91;Lwx;)V
    .registers 3

    iput-object p1, p0, Lads_mobile_sdk/c91;->c:Lads_mobile_sdk/d91;

    invoke-direct {p0, p2}, Lwx;-><init>(Lvx;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 13

    iput-object p1, p0, Lads_mobile_sdk/c91;->b:Ljava/lang/Object;

    iget p1, p0, Lads_mobile_sdk/c91;->d:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, Lads_mobile_sdk/c91;->d:I

    const/4 v9, 0x0

    const/4 v3, 0x0

    iget-object v0, p0, Lads_mobile_sdk/c91;->c:Lads_mobile_sdk/d91;

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    move-object v10, p0

    invoke-static/range {v0 .. v10}, Lads_mobile_sdk/d91;->a(Lads_mobile_sdk/d91;Ljava/lang/Boolean;Ljava/lang/Boolean;ILjava/lang/String;Ljava/lang/Long;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
