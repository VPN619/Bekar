.class public final Lads_mobile_sdk/dj0;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:Lads_mobile_sdk/ia3;

.field public final c:Ljava/lang/String;

.field public final d:J

.field public final e:J


# direct methods
.method public constructor <init>(Landroid/content/Context;Lads_mobile_sdk/l7;Lads_mobile_sdk/ia3;)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/dj0;->a:Landroid/content/Context;

    invoke-virtual {p2}, Lads_mobile_sdk/l7;->D()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lads_mobile_sdk/dj0;->c:Ljava/lang/String;

    invoke-virtual {p2}, Lads_mobile_sdk/l7;->B()J

    move-result-wide v0

    iput-wide v0, p0, Lads_mobile_sdk/dj0;->d:J

    invoke-virtual {p2}, Lads_mobile_sdk/l7;->F()J

    move-result-wide p1

    iput-wide p1, p0, Lads_mobile_sdk/dj0;->e:J

    iput-object p3, p0, Lads_mobile_sdk/dj0;->b:Lads_mobile_sdk/ia3;

    return-void
.end method


# virtual methods
.method public final a(Ljava/util/HashMap;)V
    .registers 13

    .prologue
    sget-object v0, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    iget-object v1, p0, Lads_mobile_sdk/dj0;->c:Ljava/lang/String;

    const-string v2, "v"

    invoke-virtual {p1, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v1, Ljava/lang/Throwable;

    invoke-direct {v1}, Ljava/lang/Throwable;-><init>()V

    const-string v2, "t"

    invoke-virtual {p1, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "E"

    const-wide/16 v2, -0x1

    const/4 v4, 0x0

    :try_start_18
    const-string v5, "gs"

    invoke-virtual {p1, v5}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ld31;

    if-eqz v5, :cond_9f

    sget v6, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v7, 0x1f

    if-lt v6, v7, :cond_2e

    invoke-interface {v5}, Ljava/util/concurrent/Future;->isDone()Z

    move-result v6

    if-eqz v6, :cond_9f

    :cond_2e
    iget-wide v6, p0, Lads_mobile_sdk/dj0;->d:J

    invoke-interface {v5, v6, v7, v0}, Ljava/util/concurrent/Future;->get(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lads_mobile_sdk/pd;

    if-eqz v5, :cond_9f

    invoke-virtual {v5}, Lads_mobile_sdk/pd;->v()Z

    move-result v6

    if-eqz v6, :cond_81

    invoke-virtual {v5}, Lads_mobile_sdk/pd;->r()Lads_mobile_sdk/he;

    move-result-object v6

    invoke-virtual {v6}, Lads_mobile_sdk/he;->r()Z

    move-result v7

    if-eqz v7, :cond_5c

    invoke-virtual {v6}, Lads_mobile_sdk/he;->o()Lads_mobile_sdk/hr;

    move-result-object v7

    sget-object v8, Ljava/nio/charset/StandardCharsets;->ISO_8859_1:Ljava/nio/charset/Charset;

    invoke-virtual {v7}, Lads_mobile_sdk/hr;->size()I

    move-result v8

    if-nez v8, :cond_57

    const-string v7, ""

    goto :goto_5d

    :cond_57
    invoke-virtual {v7}, Lads_mobile_sdk/hr;->a()Ljava/lang/String;

    move-result-object v7
    :try_end_5b
    .catch Ljava/lang/ClassCastException; {:try_start_18 .. :try_end_5b} :catch_9f
    .catch Ljava/lang/InterruptedException; {:try_start_18 .. :try_end_5b} :catch_9f
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_18 .. :try_end_5b} :catch_9f
    .catch Ljava/util/concurrent/TimeoutException; {:try_start_18 .. :try_end_5b} :catch_9f

    goto :goto_5d

    :cond_5c
    move-object v7, v4

    :goto_5d
    :try_start_5d
    invoke-virtual {v6}, Lads_mobile_sdk/he;->t()Z

    move-result v8

    if-eqz v8, :cond_6c

    invoke-virtual {v6}, Lads_mobile_sdk/he;->q()J

    move-result-wide v8

    invoke-static {v8, v9}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v8
    :try_end_6b
    .catch Ljava/lang/ClassCastException; {:try_start_5d .. :try_end_6b} :catch_7e
    .catch Ljava/lang/InterruptedException; {:try_start_5d .. :try_end_6b} :catch_7e
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_5d .. :try_end_6b} :catch_7e
    .catch Ljava/util/concurrent/TimeoutException; {:try_start_5d .. :try_end_6b} :catch_7e

    goto :goto_6d

    :cond_6c
    move-object v8, v4

    :goto_6d
    :try_start_6d
    invoke-virtual {v6}, Lads_mobile_sdk/he;->s()Z

    move-result v9

    if-eqz v9, :cond_77

    invoke-virtual {v6}, Lads_mobile_sdk/he;->p()Ljava/lang/String;

    move-result-object v4
    :try_end_77
    .catch Ljava/lang/ClassCastException; {:try_start_6d .. :try_end_77} :catch_7a
    .catch Ljava/lang/InterruptedException; {:try_start_6d .. :try_end_77} :catch_7a
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_6d .. :try_end_77} :catch_7a
    .catch Ljava/util/concurrent/TimeoutException; {:try_start_6d .. :try_end_77} :catch_7a

    :cond_77
    move-object v6, v4

    move-object v4, v7

    goto :goto_83

    :catch_7a
    move-object v6, v4

    :goto_7b
    move-object v4, v7

    :catch_7c
    move-object v7, v1

    goto :goto_a2

    :catch_7e
    move-object v6, v4

    move-object v8, v6

    goto :goto_7b

    :cond_81
    move-object v6, v4

    move-object v8, v6

    :goto_83
    :try_start_83
    invoke-virtual {v5}, Lads_mobile_sdk/pd;->p()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/String;->length()I

    move-result v7

    const/4 v9, 0x1

    if-le v7, v9, :cond_93

    invoke-virtual {v5}, Lads_mobile_sdk/pd;->p()Ljava/lang/String;

    move-result-object v7
    :try_end_92
    .catch Ljava/lang/ClassCastException; {:try_start_83 .. :try_end_92} :catch_7c
    .catch Ljava/lang/InterruptedException; {:try_start_83 .. :try_end_92} :catch_7c
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_83 .. :try_end_92} :catch_7c
    .catch Ljava/util/concurrent/TimeoutException; {:try_start_83 .. :try_end_92} :catch_7c

    goto :goto_94

    :cond_93
    move-object v7, v1

    :goto_94
    :try_start_94
    invoke-virtual {v5}, Lads_mobile_sdk/pd;->t()Z

    move-result v9

    if-eqz v9, :cond_a2

    invoke-virtual {v5}, Lads_mobile_sdk/pd;->o()J

    move-result-wide v2
    :try_end_9e
    .catch Ljava/lang/ClassCastException; {:try_start_94 .. :try_end_9e} :catch_a2
    .catch Ljava/lang/InterruptedException; {:try_start_94 .. :try_end_9e} :catch_a2
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_94 .. :try_end_9e} :catch_a2
    .catch Ljava/util/concurrent/TimeoutException; {:try_start_94 .. :try_end_9e} :catch_a2

    goto :goto_a2

    :catch_9f
    :cond_9f
    move-object v7, v1

    move-object v6, v4

    move-object v8, v6

    :catch_a2
    :cond_a2
    :goto_a2
    invoke-virtual {v7, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_c1

    :try_start_a8
    const-string v1, "ai"

    invoke-virtual {p1, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ld31;

    if-eqz v1, :cond_c1

    iget-wide v9, p0, Lads_mobile_sdk/dj0;->e:J

    invoke-interface {v1, v9, v10, v0}, Ljava/util/concurrent/Future;->get(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    invoke-static {p0}, Lck1;->a(Ljava/lang/String;)Z

    move-result v0
    :try_end_be
    .catch Ljava/lang/InterruptedException; {:try_start_a8 .. :try_end_be} :catch_c1
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_a8 .. :try_end_be} :catch_c1
    .catch Ljava/lang/ClassCastException; {:try_start_a8 .. :try_end_be} :catch_c1
    .catch Ljava/util/concurrent/TimeoutException; {:try_start_a8 .. :try_end_be} :catch_c1

    if-nez v0, :cond_c1

    move-object v7, p0

    :catch_c1
    :cond_c1
    const-string p0, "int"

    invoke-virtual {p1, p0, v7}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    if-eqz v4, :cond_cd

    const-string p0, "att"

    invoke-virtual {p1, p0, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_cd
    if-eqz v8, :cond_d4

    const-string p0, "attts"

    invoke-virtual {p1, p0, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_d4
    if-eqz v6, :cond_db

    const-string p0, "attkid"

    invoke-virtual {p1, p0, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_db
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    const-string v0, "gv"

    invoke-virtual {p1, v0, p0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method
