.class public final Lads_mobile_sdk/fa;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lnt2;


# instance fields
.field public final a:Lads_mobile_sdk/ob1;

.field public final b:Ltv2;

.field public final c:Ltv2;

.field public final d:Ltv2;

.field public final e:Ltv2;

.field public final f:Ltv2;

.field public final g:Ltv2;

.field public final h:Ltv2;

.field public final i:Ltv2;

.field public final j:Ltv2;

.field public final synthetic k:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/ob1;Ltv2;Ltv2;Ltv2;Lads_mobile_sdk/n90;Ltv2;Ltv2;Lads_mobile_sdk/ob1;Ltv2;Lads_mobile_sdk/ob1;)V
    .registers 12

    const/4 v0, 0x2

    iput v0, p0, Lads_mobile_sdk/fa;->k:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/fa;->a:Lads_mobile_sdk/ob1;

    iput-object p2, p0, Lads_mobile_sdk/fa;->b:Ltv2;

    iput-object p3, p0, Lads_mobile_sdk/fa;->c:Ltv2;

    iput-object p4, p0, Lads_mobile_sdk/fa;->d:Ltv2;

    iput-object p5, p0, Lads_mobile_sdk/fa;->j:Ltv2;

    iput-object p6, p0, Lads_mobile_sdk/fa;->f:Ltv2;

    iput-object p7, p0, Lads_mobile_sdk/fa;->g:Ltv2;

    iput-object p8, p0, Lads_mobile_sdk/fa;->e:Ltv2;

    iput-object p9, p0, Lads_mobile_sdk/fa;->i:Ltv2;

    iput-object p10, p0, Lads_mobile_sdk/fa;->h:Ltv2;

    return-void
.end method

.method public constructor <init>(Lads_mobile_sdk/ob1;Ltv2;Ltv2;Ltv2;Lads_mobile_sdk/ob1;Ltv2;Ltv2;Lads_mobile_sdk/ob1;Ltv2;Lads_mobile_sdk/ob1;)V
    .registers 12

    const/4 v0, 0x0

    iput v0, p0, Lads_mobile_sdk/fa;->k:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/fa;->a:Lads_mobile_sdk/ob1;

    iput-object p2, p0, Lads_mobile_sdk/fa;->b:Ltv2;

    iput-object p3, p0, Lads_mobile_sdk/fa;->c:Ltv2;

    iput-object p4, p0, Lads_mobile_sdk/fa;->d:Ltv2;

    iput-object p5, p0, Lads_mobile_sdk/fa;->e:Ltv2;

    iput-object p6, p0, Lads_mobile_sdk/fa;->f:Ltv2;

    iput-object p7, p0, Lads_mobile_sdk/fa;->g:Ltv2;

    iput-object p8, p0, Lads_mobile_sdk/fa;->h:Ltv2;

    iput-object p9, p0, Lads_mobile_sdk/fa;->i:Ltv2;

    iput-object p10, p0, Lads_mobile_sdk/fa;->j:Ltv2;

    return-void
.end method

.method public constructor <init>(Lads_mobile_sdk/ob1;Ltv2;Ltv2;Ltv2;Ltv2;Ltv2;Ltv2;Ltv2;Ltv2;Ltv2;)V
    .registers 12

    const/4 v0, 0x1

    iput v0, p0, Lads_mobile_sdk/fa;->k:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/fa;->a:Lads_mobile_sdk/ob1;

    iput-object p2, p0, Lads_mobile_sdk/fa;->b:Ltv2;

    iput-object p3, p0, Lads_mobile_sdk/fa;->c:Ltv2;

    iput-object p4, p0, Lads_mobile_sdk/fa;->d:Ltv2;

    iput-object p5, p0, Lads_mobile_sdk/fa;->f:Ltv2;

    iput-object p6, p0, Lads_mobile_sdk/fa;->g:Ltv2;

    iput-object p7, p0, Lads_mobile_sdk/fa;->i:Ltv2;

    iput-object p8, p0, Lads_mobile_sdk/fa;->e:Ltv2;

    iput-object p9, p0, Lads_mobile_sdk/fa;->h:Ltv2;

    iput-object p10, p0, Lads_mobile_sdk/fa;->j:Ltv2;

    return-void
.end method

.method public constructor <init>(Ltv2;Ltv2;Ltv2;Lads_mobile_sdk/ob1;Lads_mobile_sdk/ob1;Lads_mobile_sdk/ob1;Lads_mobile_sdk/b23;Lads_mobile_sdk/b23;Lads_mobile_sdk/b23;Ltv2;)V
    .registers 12

    const/4 v0, 0x3

    iput v0, p0, Lads_mobile_sdk/fa;->k:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/fa;->b:Ltv2;

    iput-object p2, p0, Lads_mobile_sdk/fa;->c:Ltv2;

    iput-object p3, p0, Lads_mobile_sdk/fa;->d:Ltv2;

    iput-object p4, p0, Lads_mobile_sdk/fa;->a:Lads_mobile_sdk/ob1;

    iput-object p5, p0, Lads_mobile_sdk/fa;->e:Ltv2;

    iput-object p6, p0, Lads_mobile_sdk/fa;->h:Ltv2;

    iput-object p7, p0, Lads_mobile_sdk/fa;->j:Ltv2;

    iput-object p8, p0, Lads_mobile_sdk/fa;->g:Ltv2;

    iput-object p9, p0, Lads_mobile_sdk/fa;->i:Ltv2;

    iput-object p10, p0, Lads_mobile_sdk/fa;->f:Ltv2;

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 23

    .prologue
    move-object/from16 v0, p0

    iget v1, v0, Lads_mobile_sdk/fa;->k:I

    iget-object v2, v0, Lads_mobile_sdk/fa;->f:Ltv2;

    iget-object v3, v0, Lads_mobile_sdk/fa;->i:Ltv2;

    iget-object v4, v0, Lads_mobile_sdk/fa;->g:Ltv2;

    iget-object v5, v0, Lads_mobile_sdk/fa;->j:Ltv2;

    iget-object v6, v0, Lads_mobile_sdk/fa;->h:Ltv2;

    iget-object v7, v0, Lads_mobile_sdk/fa;->e:Ltv2;

    iget-object v8, v0, Lads_mobile_sdk/fa;->a:Lads_mobile_sdk/ob1;

    iget-object v9, v0, Lads_mobile_sdk/fa;->d:Ltv2;

    iget-object v10, v0, Lads_mobile_sdk/fa;->c:Ltv2;

    iget-object v0, v0, Lads_mobile_sdk/fa;->b:Ltv2;

    packed-switch v1, :pswitch_data_198

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v12, v0

    check-cast v12, Loa1;

    invoke-interface {v10}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v13, v0

    check-cast v13, Lads_mobile_sdk/a;

    invoke-interface {v9}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v14, v0

    check-cast v14, Lads_mobile_sdk/rp1;

    iget-object v0, v8, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v15, v0

    check-cast v15, Lads_mobile_sdk/ga3;

    check-cast v7, Lads_mobile_sdk/ob1;

    iget-object v0, v7, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object/from16 v16, v0

    check-cast v16, Ljava/lang/String;

    check-cast v6, Lads_mobile_sdk/ob1;

    iget-object v0, v6, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object/from16 v17, v0

    check-cast v17, Lwy2;

    move-object/from16 v18, v5

    check-cast v18, Lads_mobile_sdk/b23;

    move-object/from16 v19, v4

    check-cast v19, Lads_mobile_sdk/b23;

    move-object/from16 v20, v3

    check-cast v20, Lads_mobile_sdk/b23;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v21, v0

    check-cast v21, Lads_mobile_sdk/th3;

    new-instance v11, Lads_mobile_sdk/j63;

    invoke-direct/range {v11 .. v21}, Lads_mobile_sdk/j63;-><init>(Loa1;Lads_mobile_sdk/a;Lads_mobile_sdk/rp1;Lads_mobile_sdk/ga3;Ljava/lang/String;Lwy2;Lads_mobile_sdk/b23;Lads_mobile_sdk/b23;Lads_mobile_sdk/b23;Lads_mobile_sdk/th3;)V

    return-object v11

    :pswitch_5f  #0x2
    iget-object v1, v8, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v12, v1

    check-cast v12, Landroid/content/Context;

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v13, v0

    check-cast v13, Lvy;

    invoke-interface {v10}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v14, v0

    check-cast v14, Lads_mobile_sdk/fr3;

    invoke-interface {v9}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v15, v0

    check-cast v15, Lads_mobile_sdk/kj0;

    check-cast v5, Lads_mobile_sdk/n90;

    invoke-virtual {v5}, Lads_mobile_sdk/n90;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Optional;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v1

    move-object/from16 v16, v1

    check-cast v16, Lx43;

    invoke-interface {v4}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v1

    move-object/from16 v17, v1

    check-cast v17, Lads_mobile_sdk/qr0;

    check-cast v7, Lads_mobile_sdk/ob1;

    iget-object v1, v7, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object/from16 v18, v1

    check-cast v18, Lads_mobile_sdk/av2;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v1

    move-object/from16 v19, v1

    check-cast v19, Lads_mobile_sdk/g0;

    check-cast v6, Lads_mobile_sdk/ob1;

    iget-object v1, v6, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object/from16 v20, v1

    check-cast v20, Lads_mobile_sdk/a2;

    new-instance v11, Loz2;

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {v16 .. v16}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {v17 .. v17}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {v18 .. v18}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {v19 .. v19}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {v20 .. v20}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct/range {v11 .. v20}, Lads_mobile_sdk/jp;-><init>(Landroid/content/Context;Lvy;Le23;Lads_mobile_sdk/kj0;Lx43;Lads_mobile_sdk/qr0;Lads_mobile_sdk/av2;Lads_mobile_sdk/g0;Lads_mobile_sdk/a2;)V

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/util/Optional;->orElse(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/cy0;

    iput-object v0, v11, Lads_mobile_sdk/jp;->i:Landroid/view/View;

    if-eqz v0, :cond_da

    invoke-virtual {v11, v0}, Lads_mobile_sdk/jp;->a(Landroid/view/View;)V

    :cond_da
    return-object v11

    :pswitch_db  #0x1
    iget-object v1, v8, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v12, v1

    check-cast v12, Landroid/content/Context;

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v13, v0

    check-cast v13, Lads_mobile_sdk/qr0;

    invoke-interface {v10}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v14, v0

    check-cast v14, Lx43;

    invoke-interface {v9}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v15, v0

    check-cast v15, Lads_mobile_sdk/mh3;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v16, v0

    check-cast v16, Lads_mobile_sdk/kl0;

    invoke-interface {v4}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v17, v0

    check-cast v17, Lads_mobile_sdk/i41;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v18, v0

    check-cast v18, Ljava/lang/String;

    invoke-interface {v7}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v19, v0

    check-cast v19, Ljava/lang/String;

    invoke-static {v6}, Lads_mobile_sdk/nj0;->a(Ltv2;)Lv03;

    move-result-object v20

    invoke-interface {v5}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v21, v0

    check-cast v21, Lads_mobile_sdk/mi0;

    new-instance v11, Lads_mobile_sdk/ah3;

    invoke-direct/range {v11 .. v21}, Lads_mobile_sdk/ah3;-><init>(Landroid/content/Context;Lads_mobile_sdk/qr0;Lx43;Lads_mobile_sdk/mh3;Lads_mobile_sdk/kl0;Lads_mobile_sdk/i41;Ljava/lang/String;Ljava/lang/String;Lv03;Lads_mobile_sdk/mi0;)V

    return-object v11

    :pswitch_127  #0x0
    iget-object v1, v8, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v12, v1

    check-cast v12, Landroid/content/Context;

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v13, v0

    check-cast v13, Lvy;

    invoke-interface {v10}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v14, v0

    check-cast v14, Lads_mobile_sdk/z9;

    invoke-interface {v9}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v15, v0

    check-cast v15, Lads_mobile_sdk/kj0;

    check-cast v7, Lads_mobile_sdk/ob1;

    iget-object v0, v7, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v0, Landroid/view/View;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v1

    move-object/from16 v16, v1

    check-cast v16, Lx43;

    invoke-interface {v4}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v1

    move-object/from16 v17, v1

    check-cast v17, Lads_mobile_sdk/qr0;

    check-cast v6, Lads_mobile_sdk/ob1;

    iget-object v1, v6, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object/from16 v18, v1

    check-cast v18, Lads_mobile_sdk/av2;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v1

    move-object/from16 v19, v1

    check-cast v19, Lads_mobile_sdk/g0;

    check-cast v5, Lads_mobile_sdk/ob1;

    iget-object v1, v5, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object/from16 v20, v1

    check-cast v20, Lads_mobile_sdk/a2;

    new-instance v11, Ldx2;

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {v16 .. v16}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {v17 .. v17}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {v18 .. v18}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {v19 .. v19}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {v20 .. v20}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct/range {v11 .. v20}, Lads_mobile_sdk/jp;-><init>(Landroid/content/Context;Lvy;Le23;Lads_mobile_sdk/kj0;Lx43;Lads_mobile_sdk/qr0;Lads_mobile_sdk/av2;Lads_mobile_sdk/g0;Lads_mobile_sdk/a2;)V

    iput-object v0, v11, Lads_mobile_sdk/jp;->i:Landroid/view/View;

    invoke-virtual {v11, v0}, Lads_mobile_sdk/jp;->a(Landroid/view/View;)V

    return-object v11

    :pswitch_data_198
    .packed-switch 0x0
        :pswitch_127  #00000000
        :pswitch_db  #00000001
        :pswitch_5f  #00000002
    .end packed-switch
.end method
