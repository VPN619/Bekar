.class public final Lads_mobile_sdk/e32;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lku2;
.implements Le13;


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:Ljava/util/concurrent/ExecutorService;

.field public c:Landroid/net/NetworkCapabilities;

.field public d:Landroid/net/Network;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/util/concurrent/ExecutorService;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Lads_mobile_sdk/e32;->c:Landroid/net/NetworkCapabilities;

    iput-object v0, p0, Lads_mobile_sdk/e32;->d:Landroid/net/Network;

    iput-object p1, p0, Lads_mobile_sdk/e32;->a:Landroid/content/Context;

    iput-object p2, p0, Lads_mobile_sdk/e32;->b:Ljava/util/concurrent/ExecutorService;

    return-void
.end method


# virtual methods
.method public final a()Ld31;
    .registers 4

    new-instance v0, Lx82;

    const/16 v1, 0xb

    invoke-direct {v0, v1, p0}, Lx82;-><init>(ILjava/lang/Object;)V

    new-instance v1, Lpd2;

    const/4 v2, 0x0

    invoke-static {v0, v2}, Ljava/util/concurrent/Executors;->callable(Ljava/lang/Runnable;Ljava/lang/Object;)Ljava/util/concurrent/Callable;

    move-result-object v0

    invoke-direct {v1, v0}, Lpd2;-><init>(Ljava/util/concurrent/Callable;)V

    iget-object p0, p0, Lads_mobile_sdk/e32;->b:Ljava/util/concurrent/ExecutorService;

    invoke-interface {p0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-object v1
.end method

.method public final a(Ljava/util/HashMap;)V
    .registers 4

    .prologue
    const-string v0, "ntc"

    monitor-enter p0

    :try_start_3
    iget-object v1, p0, Lads_mobile_sdk/e32;->c:Landroid/net/NetworkCapabilities;

    monitor-exit p0
    :try_end_6
    .catchall {:try_start_3 .. :try_end_6} :catchall_44

    invoke-virtual {p1, v0, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    monitor-enter p0

    :try_start_a
    iget-object v0, p0, Lads_mobile_sdk/e32;->c:Landroid/net/NetworkCapabilities;

    if-eqz v0, :cond_35

    const/4 v1, 0x4

    invoke-virtual {v0, v1}, Landroid/net/NetworkCapabilities;->hasTransport(I)Z

    move-result v0

    if-eqz v0, :cond_1b

    monitor-exit p0

    const-wide/16 v0, 0x2

    goto :goto_38

    :catchall_19
    move-exception p1

    goto :goto_42

    :cond_1b
    iget-object v0, p0, Lads_mobile_sdk/e32;->c:Landroid/net/NetworkCapabilities;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/net/NetworkCapabilities;->hasTransport(I)Z

    move-result v0

    if-eqz v0, :cond_28

    monitor-exit p0

    const-wide/16 v0, 0x1

    goto :goto_38

    :cond_28
    iget-object v0, p0, Lads_mobile_sdk/e32;->c:Landroid/net/NetworkCapabilities;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/net/NetworkCapabilities;->hasTransport(I)Z

    move-result v0

    if-eqz v0, :cond_35

    monitor-exit p0

    const-wide/16 v0, 0x0

    goto :goto_38

    :cond_35
    monitor-exit p0
    :try_end_36
    .catchall {:try_start_a .. :try_end_36} :catchall_19

    const-wide/16 v0, -0x1

    :goto_38
    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    const-string v0, "nt"

    invoke-virtual {p1, v0, p0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :goto_42
    :try_start_42
    monitor-exit p0
    :try_end_43
    .catchall {:try_start_42 .. :try_end_43} :catchall_19

    throw p1

    :catchall_44
    move-exception p1

    :try_start_45
    monitor-exit p0
    :try_end_46
    .catchall {:try_start_45 .. :try_end_46} :catchall_44

    throw p1
.end method

.method public final a(Ljava/util/HashMap;Landroid/content/Context;Landroid/view/View;)V
    .registers 4

    return-void
.end method

.method public final b(Ljava/util/HashMap;)V
    .registers 2

    return-void
.end method
