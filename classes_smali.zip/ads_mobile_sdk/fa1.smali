.class public final Lads_mobile_sdk/fa1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lbw2;


# instance fields
.field public final a:Lads_mobile_sdk/ah3;

.field public final b:Lads_mobile_sdk/cu2;

.field public final c:Lads_mobile_sdk/yi;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/ah3;Lads_mobile_sdk/cu2;Lads_mobile_sdk/yi;)V
    .registers 4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/fa1;->a:Lads_mobile_sdk/ah3;

    iput-object p2, p0, Lads_mobile_sdk/fa1;->b:Lads_mobile_sdk/cu2;

    iput-object p3, p0, Lads_mobile_sdk/fa1;->c:Lads_mobile_sdk/yi;

    return-void
.end method


# virtual methods
.method public final a(Lads_mobile_sdk/cy0;Ljava/util/Map;Lvx;)Ljava/lang/Object;
    .registers 13

    .prologue
    const-string p1, "applicationMuted"

    invoke-interface {p2, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    iget-object p3, p0, Lads_mobile_sdk/fa1;->c:Lads_mobile_sdk/yi;

    if-eqz p1, :cond_14

    const-string v0, "1"

    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    iput-boolean p1, p3, Lads_mobile_sdk/yi;->d:Z

    :cond_14
    const-string p1, "applicationVolume"

    invoke-interface {p2, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    const-string v0, "."

    iget-object v1, p0, Lads_mobile_sdk/fa1;->a:Lads_mobile_sdk/ah3;

    if-eqz p1, :cond_3e

    :try_start_22
    invoke-static {p1}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v2

    iput v2, p3, Lads_mobile_sdk/yi;->c:F
    :try_end_28
    .catch Ljava/lang/NumberFormatException; {:try_start_22 .. :try_end_28} :catch_29

    goto :goto_3e

    :catch_29
    move-exception p3

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Failed to parse application volume: "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1, p3}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_3e
    :goto_3e
    iget-object p0, p0, Lads_mobile_sdk/fa1;->b:Lads_mobile_sdk/cu2;

    invoke-virtual {p0}, Lads_mobile_sdk/cu2;->a()Lut1;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string p3, "B3EEABB8EE11C2BE770B684D95219ECB"

    filled-new-array {p3}, [Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/util/ArrayList;

    new-instance v4, Lie;

    const/4 v5, 0x1

    invoke-direct {v4, v2, v5}, Lie;-><init>([Ljava/lang/Object;Z)V

    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    iget-object v2, p1, Lut1;->a:Lqt1;

    iget-object v4, p1, Lut1;->c:Lrt1;

    iget-object p1, p1, Lut1;->b:Ljava/util/ArrayList;

    invoke-virtual {v3}, Ljava/util/ArrayList;->clear()V

    invoke-virtual {v3, p1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {v3, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    sget-object p1, Lqt1;->d:Lza0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance p3, Lk0;

    const/4 v5, 0x0

    invoke-direct {p3, v5, p1}, Lk0;-><init>(ILjava/lang/Object;)V

    :cond_72
    invoke-virtual {p3}, Lk0;->hasNext()Z

    move-result p1

    const/4 v6, 0x0

    if-eqz p1, :cond_8f

    invoke-virtual {p3}, Lk0;->next()Ljava/lang/Object;

    move-result-object p1

    move-object v7, p1

    check-cast v7, Lqt1;

    iget-object v7, v7, Lqt1;->a:Ljava/lang/String;

    const-string v8, "maxAdContentRating"

    invoke-interface {p2, v8}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_72

    goto :goto_90

    :cond_8f
    move-object p1, v6

    :goto_90
    check-cast p1, Lqt1;

    if-eqz p1, :cond_95

    move-object v2, p1

    :cond_95
    const-string p1, "publisherPrivacyPersonalizationState"

    invoke-interface {p2, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    if-eqz p1, :cond_dc

    :try_start_9f
    invoke-static {p1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p2

    sget-object p3, Lrt1;->d:Lza0;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v7, Lk0;

    invoke-direct {v7, v5, p3}, Lk0;-><init>(ILjava/lang/Object;)V

    :cond_ad
    invoke-virtual {v7}, Lk0;->hasNext()Z

    move-result p3

    if-eqz p3, :cond_c2

    invoke-virtual {v7}, Lk0;->next()Ljava/lang/Object;

    move-result-object p3

    move-object v8, p3

    check-cast v8, Lrt1;

    iget v8, v8, Lrt1;->a:I

    if-ne v8, p2, :cond_ad

    move-object v6, p3

    goto :goto_c2

    :catch_c0
    move-exception p2

    goto :goto_c8

    :cond_c2
    :goto_c2
    check-cast v6, Lrt1;
    :try_end_c4
    .catch Ljava/lang/NumberFormatException; {:try_start_9f .. :try_end_c4} :catch_c0

    if-eqz v6, :cond_dc

    move-object v4, v6

    goto :goto_dc

    :goto_c8
    new-instance p3, Ljava/lang/StringBuilder;

    const-string v6, "Failed to parse publisher privacy personalization state: "

    invoke-direct {p3, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v1, p1, p2}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_dc
    :goto_dc
    new-instance p1, Lut1;

    invoke-direct {p1, v2, v3, v4}, Lut1;-><init>(Lqt1;Ljava/util/ArrayList;Lrt1;)V

    iget-object p2, p0, Lads_mobile_sdk/cu2;->a:Lads_mobile_sdk/ji;

    sget-object p3, Lads_mobile_sdk/cu2;->b:[Liy0;

    aget-object p3, p3, v5

    invoke-virtual {p2, p0, p3, p1}, Lads_mobile_sdk/ji;->setValue(Ljava/lang/Object;Liy0;Ljava/lang/Object;)V

    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method

.method public final b()I
    .registers 1

    const/16 p0, 0x28

    return p0
.end method
