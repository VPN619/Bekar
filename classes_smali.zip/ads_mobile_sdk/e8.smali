.class public final Lads_mobile_sdk/e8;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lb23;


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:F

.field public final c:I

.field public final d:I

.field public final e:I

.field public final f:I

.field public final g:Landroid/graphics/Insets;

.field public final h:Ljava/lang/String;

.field public final i:Ljava/lang/Boolean;

.field public final j:Ljava/lang/String;

.field public final k:Ljava/lang/String;

.field public final l:Ljava/util/ArrayList;

.field public final m:Lads_mobile_sdk/ay2;

.field public final n:Z


# direct methods
.method public constructor <init>(Ljava/lang/String;FIIIILandroid/graphics/Insets;Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;Lads_mobile_sdk/ay2;Z)V
    .registers 15

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/e8;->a:Ljava/lang/String;

    iput p2, p0, Lads_mobile_sdk/e8;->b:F

    iput p3, p0, Lads_mobile_sdk/e8;->c:I

    iput p4, p0, Lads_mobile_sdk/e8;->d:I

    iput p5, p0, Lads_mobile_sdk/e8;->e:I

    iput p6, p0, Lads_mobile_sdk/e8;->f:I

    iput-object p7, p0, Lads_mobile_sdk/e8;->g:Landroid/graphics/Insets;

    iput-object p8, p0, Lads_mobile_sdk/e8;->h:Ljava/lang/String;

    iput-object p9, p0, Lads_mobile_sdk/e8;->i:Ljava/lang/Boolean;

    iput-object p10, p0, Lads_mobile_sdk/e8;->j:Ljava/lang/String;

    iput-object p11, p0, Lads_mobile_sdk/e8;->k:Ljava/lang/String;

    iput-object p12, p0, Lads_mobile_sdk/e8;->l:Ljava/util/ArrayList;

    iput-object p13, p0, Lads_mobile_sdk/e8;->m:Lads_mobile_sdk/ay2;

    iput-boolean p14, p0, Lads_mobile_sdk/e8;->n:Z

    return-void
.end method


# virtual methods
.method public final a(Lg32;)V
    .registers 4

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Lads_mobile_sdk/e8;->a:Ljava/lang/String;

    iput-object v0, p1, Lg32;->f:Ljava/lang/String;

    iget v0, p0, Lads_mobile_sdk/e8;->b:F

    iput v0, p1, Lg32;->i:F

    iget v0, p0, Lads_mobile_sdk/e8;->d:I

    iput v0, p1, Lg32;->k:I

    iget v0, p0, Lads_mobile_sdk/e8;->c:I

    iput v0, p1, Lg32;->j:I

    iget v0, p0, Lads_mobile_sdk/e8;->f:I

    iput v0, p1, Lg32;->m:I

    iget v0, p0, Lads_mobile_sdk/e8;->e:I

    iput v0, p1, Lg32;->l:I

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1e

    if-lt v0, v1, :cond_53

    iget-object v0, p0, Lads_mobile_sdk/e8;->g:Landroid/graphics/Insets;

    if-eqz v0, :cond_53

    invoke-static {v0}, Ldm2;->f(Landroid/graphics/Insets;)I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    iput-object v0, p1, Lg32;->t:Ljava/lang/Integer;

    iget-object v0, p0, Lads_mobile_sdk/e8;->g:Landroid/graphics/Insets;

    invoke-static {v0}, Ldm2;->p(Landroid/graphics/Insets;)I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    iput-object v0, p1, Lg32;->u:Ljava/lang/Integer;

    iget-object v0, p0, Lads_mobile_sdk/e8;->g:Landroid/graphics/Insets;

    invoke-static {v0}, Ldm2;->s(Landroid/graphics/Insets;)I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    iput-object v0, p1, Lg32;->v:Ljava/lang/Integer;

    iget-object v0, p0, Lads_mobile_sdk/e8;->g:Landroid/graphics/Insets;

    invoke-static {v0}, Ldm2;->t(Landroid/graphics/Insets;)I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    iput-object v0, p1, Lg32;->w:Ljava/lang/Integer;

    :cond_53
    iget-object v0, p0, Lads_mobile_sdk/e8;->h:Ljava/lang/String;

    iput-object v0, p1, Lg32;->d:Ljava/lang/String;

    iget-object v0, p0, Lads_mobile_sdk/e8;->i:Ljava/lang/Boolean;

    iput-object v0, p1, Lg32;->e:Ljava/lang/Boolean;

    iget-object v0, p0, Lads_mobile_sdk/e8;->j:Ljava/lang/String;

    iput-object v0, p1, Lg32;->g:Ljava/lang/String;

    iget-object v0, p0, Lads_mobile_sdk/e8;->k:Ljava/lang/String;

    iput-object v0, p1, Lg32;->h:Ljava/lang/String;

    iget-object v0, p1, Lg32;->b:Ljava/util/ArrayList;

    iget-object v1, p0, Lads_mobile_sdk/e8;->l:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    iget-object v0, p0, Lads_mobile_sdk/e8;->m:Lads_mobile_sdk/ay2;

    if-eqz v0, :cond_8e

    iget v1, v0, Lads_mobile_sdk/ay2;->a:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    iput-object v1, p1, Lg32;->x:Ljava/lang/Integer;

    iget v1, v0, Lads_mobile_sdk/ay2;->b:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    iput-object v1, p1, Lg32;->y:Ljava/lang/Integer;

    iget v1, v0, Lads_mobile_sdk/ay2;->d:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    iput-object v1, p1, Lg32;->z:Ljava/lang/Integer;

    iget v0, v0, Lads_mobile_sdk/ay2;->c:I

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    iput-object v0, p1, Lg32;->A:Ljava/lang/Integer;

    :cond_8e
    iget-boolean p0, p0, Lads_mobile_sdk/e8;->n:Z

    iput-boolean p0, p1, Lg32;->c:Z

    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    .prologue
    if-ne p0, p1, :cond_4

    goto/16 :goto_97

    :cond_4
    instance-of v0, p1, Lads_mobile_sdk/e8;

    if-nez v0, :cond_a

    goto/16 :goto_95

    :cond_a
    check-cast p1, Lads_mobile_sdk/e8;

    iget-object v0, p0, Lads_mobile_sdk/e8;->a:Ljava/lang/String;

    iget-object v1, p1, Lads_mobile_sdk/e8;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_18

    goto/16 :goto_95

    :cond_18
    iget v0, p0, Lads_mobile_sdk/e8;->b:F

    iget v1, p1, Lads_mobile_sdk/e8;->b:F

    invoke-static {v0, v1}, Ljava/lang/Float;->compare(FF)I

    move-result v0

    if-eqz v0, :cond_24

    goto/16 :goto_95

    :cond_24
    iget v0, p0, Lads_mobile_sdk/e8;->c:I

    iget v1, p1, Lads_mobile_sdk/e8;->c:I

    if-eq v0, v1, :cond_2c

    goto/16 :goto_95

    :cond_2c
    iget v0, p0, Lads_mobile_sdk/e8;->d:I

    iget v1, p1, Lads_mobile_sdk/e8;->d:I

    if-eq v0, v1, :cond_34

    goto/16 :goto_95

    :cond_34
    iget v0, p0, Lads_mobile_sdk/e8;->e:I

    iget v1, p1, Lads_mobile_sdk/e8;->e:I

    if-eq v0, v1, :cond_3b

    goto :goto_95

    :cond_3b
    iget v0, p0, Lads_mobile_sdk/e8;->f:I

    iget v1, p1, Lads_mobile_sdk/e8;->f:I

    if-eq v0, v1, :cond_42

    goto :goto_95

    :cond_42
    iget-object v0, p0, Lads_mobile_sdk/e8;->g:Landroid/graphics/Insets;

    iget-object v1, p1, Lads_mobile_sdk/e8;->g:Landroid/graphics/Insets;

    invoke-static {v0, v1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_4d

    goto :goto_95

    :cond_4d
    iget-object v0, p0, Lads_mobile_sdk/e8;->h:Ljava/lang/String;

    iget-object v1, p1, Lads_mobile_sdk/e8;->h:Ljava/lang/String;

    invoke-static {v0, v1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_58

    goto :goto_95

    :cond_58
    iget-object v0, p0, Lads_mobile_sdk/e8;->i:Ljava/lang/Boolean;

    iget-object v1, p1, Lads_mobile_sdk/e8;->i:Ljava/lang/Boolean;

    invoke-static {v0, v1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_63

    goto :goto_95

    :cond_63
    iget-object v0, p0, Lads_mobile_sdk/e8;->j:Ljava/lang/String;

    iget-object v1, p1, Lads_mobile_sdk/e8;->j:Ljava/lang/String;

    invoke-static {v0, v1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_6e

    goto :goto_95

    :cond_6e
    iget-object v0, p0, Lads_mobile_sdk/e8;->k:Ljava/lang/String;

    iget-object v1, p1, Lads_mobile_sdk/e8;->k:Ljava/lang/String;

    invoke-static {v0, v1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_79

    goto :goto_95

    :cond_79
    iget-object v0, p0, Lads_mobile_sdk/e8;->l:Ljava/util/ArrayList;

    iget-object v1, p1, Lads_mobile_sdk/e8;->l:Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_84

    goto :goto_95

    :cond_84
    iget-object v0, p0, Lads_mobile_sdk/e8;->m:Lads_mobile_sdk/ay2;

    iget-object v1, p1, Lads_mobile_sdk/e8;->m:Lads_mobile_sdk/ay2;

    invoke-static {v0, v1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_8f

    goto :goto_95

    :cond_8f
    iget-boolean p0, p0, Lads_mobile_sdk/e8;->n:Z

    iget-boolean p1, p1, Lads_mobile_sdk/e8;->n:Z

    if-eq p0, p1, :cond_97

    :goto_95
    const/4 p0, 0x0

    return p0

    :cond_97
    :goto_97
    const/4 p0, 0x1

    return p0
.end method

.method public final hashCode()I
    .registers 5

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/e8;->a:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/16 v1, 0x1f

    mul-int/2addr v0, v1

    iget v2, p0, Lads_mobile_sdk/e8;->b:F

    invoke-static {v2}, Ljava/lang/Float;->hashCode(F)I

    move-result v2

    add-int/2addr v2, v0

    mul-int/2addr v2, v1

    iget v0, p0, Lads_mobile_sdk/e8;->c:I

    invoke-static {v0, v2}, Lsz;->c(II)I

    move-result v0

    iget v2, p0, Lads_mobile_sdk/e8;->d:I

    invoke-static {v2, v0}, Lsz;->c(II)I

    move-result v0

    iget v2, p0, Lads_mobile_sdk/e8;->e:I

    invoke-static {v2, v0}, Lsz;->c(II)I

    move-result v0

    iget v2, p0, Lads_mobile_sdk/e8;->f:I

    invoke-static {v2, v0}, Lsz;->c(II)I

    move-result v0

    iget-object v2, p0, Lads_mobile_sdk/e8;->g:Landroid/graphics/Insets;

    const/4 v3, 0x0

    if-nez v2, :cond_30

    move v2, v3

    goto :goto_34

    :cond_30
    invoke-virtual {v2}, Landroid/graphics/Insets;->hashCode()I

    move-result v2

    :goto_34
    add-int/2addr v0, v2

    mul-int/2addr v0, v1

    iget-object v2, p0, Lads_mobile_sdk/e8;->h:Ljava/lang/String;

    if-nez v2, :cond_3c

    move v2, v3

    goto :goto_40

    :cond_3c
    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v2

    :goto_40
    add-int/2addr v0, v2

    mul-int/2addr v0, v1

    iget-object v2, p0, Lads_mobile_sdk/e8;->i:Ljava/lang/Boolean;

    if-nez v2, :cond_48

    move v2, v3

    goto :goto_4c

    :cond_48
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_4c
    add-int/2addr v0, v2

    mul-int/2addr v0, v1

    iget-object v2, p0, Lads_mobile_sdk/e8;->j:Ljava/lang/String;

    if-nez v2, :cond_54

    move v2, v3

    goto :goto_58

    :cond_54
    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v2

    :goto_58
    add-int/2addr v0, v2

    mul-int/2addr v0, v1

    iget-object v2, p0, Lads_mobile_sdk/e8;->k:Ljava/lang/String;

    if-nez v2, :cond_60

    move v2, v3

    goto :goto_64

    :cond_60
    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v2

    :goto_64
    add-int/2addr v0, v2

    mul-int/2addr v0, v1

    iget-object v2, p0, Lads_mobile_sdk/e8;->l:Ljava/util/ArrayList;

    invoke-static {v2, v0, v1}, Ly41;->k(Ljava/util/ArrayList;II)I

    move-result v0

    iget-object v2, p0, Lads_mobile_sdk/e8;->m:Lads_mobile_sdk/ay2;

    if-nez v2, :cond_71

    goto :goto_75

    :cond_71
    invoke-virtual {v2}, Lads_mobile_sdk/ay2;->hashCode()I

    move-result v3

    :goto_75
    add-int/2addr v0, v3

    mul-int/2addr v0, v1

    iget-boolean p0, p0, Lads_mobile_sdk/e8;->n:Z

    if-eqz p0, :cond_7c

    const/4 p0, 0x1

    :cond_7c
    add-int/2addr v0, p0

    mul-int/lit16 v0, v0, 0x3c1

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 4

    iget-object v0, p0, Lads_mobile_sdk/e8;->g:Landroid/graphics/Insets;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "AdSizeSignal(formatString="

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Lads_mobile_sdk/e8;->a:Ljava/lang/String;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, ", screenDensity="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, Lads_mobile_sdk/e8;->b:F

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string v2, ", screenWidth="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, Lads_mobile_sdk/e8;->c:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, ", screenHeight="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, Lads_mobile_sdk/e8;->d:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, ", screenWidthDip="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, Lads_mobile_sdk/e8;->e:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, ", screenHeightDip="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, Lads_mobile_sdk/e8;->f:I

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, ", safeAreaMarginsDip="

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, ", responsiveAutoFormat="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Lads_mobile_sdk/e8;->h:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ", isInlineAdaptive="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Lads_mobile_sdk/e8;->i:Ljava/lang/Boolean;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, ", fluidType="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Lads_mobile_sdk/e8;->j:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ", multipleAdSizeString="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Lads_mobile_sdk/e8;->k:Ljava/lang/String;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ", supportedAdSizes="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Lads_mobile_sdk/e8;->l:Ljava/util/ArrayList;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, ", roundedCornerRadii="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v0, p0, Lads_mobile_sdk/e8;->m:Lads_mobile_sdk/ay2;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, ", isGreaterThanMaxAllowedBannerSize="

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean p0, p0, Lads_mobile_sdk/e8;->n:Z

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string p0, ", maxSlotWidth=null, maxSlotHeight=null)"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
