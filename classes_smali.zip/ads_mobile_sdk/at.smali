.class public final Lads_mobile_sdk/at;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lo23;


# instance fields
.field public final a:Lads_mobile_sdk/av2;

.field public final b:Lads_mobile_sdk/dk;

.field public final c:Lli;

.field public final d:Lads_mobile_sdk/lx;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/av2;Lads_mobile_sdk/dk;Lli;Lads_mobile_sdk/lx;)V
    .registers 5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/at;->a:Lads_mobile_sdk/av2;

    iput-object p2, p0, Lads_mobile_sdk/at;->b:Lads_mobile_sdk/dk;

    iput-object p3, p0, Lads_mobile_sdk/at;->c:Lli;

    iput-object p4, p0, Lads_mobile_sdk/at;->d:Lads_mobile_sdk/lx;

    return-void
.end method


# virtual methods
.method public final a()Lads_mobile_sdk/lw0;
    .registers 1

    sget-object p0, Lads_mobile_sdk/lw0;->s:Lads_mobile_sdk/lw0;

    return-object p0
.end method

.method public final d(Lvx;)Ljava/lang/Object;
    .registers 19

    .prologue
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    instance-of v2, v1, Lads_mobile_sdk/zs;

    if-eqz v2, :cond_17

    move-object v2, v1

    check-cast v2, Lads_mobile_sdk/zs;

    iget v3, v2, Lads_mobile_sdk/zs;->g:I

    const/high16 v4, -0x80000000

    and-int v5, v3, v4

    if-eqz v5, :cond_17

    sub-int/2addr v3, v4

    iput v3, v2, Lads_mobile_sdk/zs;->g:I

    goto :goto_1e

    :cond_17
    new-instance v2, Lads_mobile_sdk/zs;

    check-cast v1, Lwx;

    invoke-direct {v2, v0, v1}, Lads_mobile_sdk/zs;-><init>(Lads_mobile_sdk/at;Lwx;)V

    :goto_1e
    iget-object v1, v2, Lads_mobile_sdk/zs;->e:Ljava/lang/Object;

    iget v3, v2, Lads_mobile_sdk/zs;->g:I

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x0

    sget-object v9, Lwy;->a:Lwy;

    if-eqz v3, :cond_6f

    if-eq v3, v7, :cond_67

    if-eq v3, v6, :cond_5c

    if-eq v3, v5, :cond_4b

    if-ne v3, v4, :cond_45

    iget-object v0, v2, Lads_mobile_sdk/zs;->c:Ljava/lang/Object;

    check-cast v0, Lfx0;

    iget-object v3, v2, Lads_mobile_sdk/zs;->b:Ljava/lang/String;

    iget-object v2, v2, Lads_mobile_sdk/zs;->a:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V

    move-object v11, v2

    :goto_41
    move-object v13, v0

    move-object v12, v3

    goto/16 :goto_e6

    :cond_45
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {v0}, Lz6;->w(Ljava/lang/String;)V

    return-object v8

    :cond_4b
    iget-object v0, v2, Lads_mobile_sdk/zs;->d:Lads_mobile_sdk/bw2;

    iget-object v3, v2, Lads_mobile_sdk/zs;->c:Ljava/lang/Object;

    check-cast v3, Ljava/lang/String;

    iget-object v5, v2, Lads_mobile_sdk/zs;->b:Ljava/lang/String;

    iget-object v6, v2, Lads_mobile_sdk/zs;->a:Ljava/lang/Object;

    check-cast v6, Lads_mobile_sdk/at;

    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V

    goto/16 :goto_be

    :cond_5c
    iget-object v0, v2, Lads_mobile_sdk/zs;->b:Ljava/lang/String;

    iget-object v3, v2, Lads_mobile_sdk/zs;->a:Ljava/lang/Object;

    check-cast v3, Lads_mobile_sdk/at;

    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V

    move-object v6, v3

    goto :goto_9d

    :cond_67
    iget-object v0, v2, Lads_mobile_sdk/zs;->a:Ljava/lang/Object;

    check-cast v0, Lads_mobile_sdk/at;

    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_89

    :cond_6f
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object v1, v0, Lads_mobile_sdk/at;->c:Lli;

    invoke-virtual {v1}, Lli;->m()Ljava/lang/String;

    move-result-object v1

    iget-object v3, v0, Lads_mobile_sdk/at;->a:Lads_mobile_sdk/av2;

    iget-object v3, v3, Lads_mobile_sdk/av2;->a:Ljava/lang/String;

    iput-object v0, v2, Lads_mobile_sdk/zs;->a:Ljava/lang/Object;

    iput v7, v2, Lads_mobile_sdk/zs;->g:I

    iget-object v7, v0, Lads_mobile_sdk/at;->b:Lads_mobile_sdk/dk;

    invoke-virtual {v7, v1, v3, v2}, Lads_mobile_sdk/dk;->b(Ljava/lang/String;Ljava/lang/String;Lwx;)Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v9, :cond_89

    goto :goto_e2

    :cond_89
    :goto_89
    check-cast v1, Ljava/lang/String;

    iget-object v3, v0, Lads_mobile_sdk/at;->b:Lads_mobile_sdk/dk;

    iput-object v0, v2, Lads_mobile_sdk/zs;->a:Ljava/lang/Object;

    iput-object v1, v2, Lads_mobile_sdk/zs;->b:Ljava/lang/String;

    iput v6, v2, Lads_mobile_sdk/zs;->g:I

    invoke-virtual {v3, v2}, Lads_mobile_sdk/dk;->a(Lwx;)Ljava/lang/Object;

    move-result-object v3

    if-ne v3, v9, :cond_9a

    goto :goto_e2

    :cond_9a
    move-object v6, v0

    move-object v0, v1

    move-object v1, v3

    :goto_9d
    check-cast v1, Ljava/lang/String;

    sget-object v3, Lads_mobile_sdk/bw2;->a:Lads_mobile_sdk/bw2;

    iget-object v7, v6, Lads_mobile_sdk/at;->b:Lads_mobile_sdk/dk;

    iput-object v6, v2, Lads_mobile_sdk/zs;->a:Ljava/lang/Object;

    iput-object v0, v2, Lads_mobile_sdk/zs;->b:Ljava/lang/String;

    iput-object v1, v2, Lads_mobile_sdk/zs;->c:Ljava/lang/Object;

    iput-object v3, v2, Lads_mobile_sdk/zs;->d:Lads_mobile_sdk/bw2;

    iput v5, v2, Lads_mobile_sdk/zs;->g:I

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v7, v2}, Lads_mobile_sdk/dk;->b(Lads_mobile_sdk/dk;Lwx;)Ljava/lang/Object;

    move-result-object v5

    if-ne v5, v9, :cond_b7

    goto :goto_e2

    :cond_b7
    move-object/from16 v16, v5

    move-object v5, v0

    move-object v0, v3

    move-object v3, v1

    move-object/from16 v1, v16

    :goto_be
    check-cast v1, Lfx0;

    const-string v7, "common_settings"

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-nez v1, :cond_c9

    :catch_c7
    move-object v0, v8

    goto :goto_cd

    :cond_c9
    :try_start_c9
    invoke-virtual {v1, v7}, Lfx0;->x(Ljava/lang/String;)Lfx0;

    move-result-object v0
    :try_end_cd
    .catch Ljava/lang/Exception; {:try_start_c9 .. :try_end_cd} :catch_c7

    :goto_cd
    iget-object v1, v6, Lads_mobile_sdk/at;->d:Lads_mobile_sdk/lx;

    iput-object v5, v2, Lads_mobile_sdk/zs;->a:Ljava/lang/Object;

    iput-object v3, v2, Lads_mobile_sdk/zs;->b:Ljava/lang/String;

    iput-object v0, v2, Lads_mobile_sdk/zs;->c:Ljava/lang/Object;

    iput-object v8, v2, Lads_mobile_sdk/zs;->d:Lads_mobile_sdk/bw2;

    iput v4, v2, Lads_mobile_sdk/zs;->g:I

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v1, v2}, Lads_mobile_sdk/lx;->b(Lads_mobile_sdk/lx;Lwx;)Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v9, :cond_e3

    :goto_e2
    return-object v9

    :cond_e3
    move-object v11, v5

    goto/16 :goto_41

    :goto_e6
    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->longValue()J

    move-result-wide v14

    new-instance v10, Lads_mobile_sdk/ys;

    invoke-direct/range {v10 .. v15}, Lads_mobile_sdk/ys;-><init>(Ljava/lang/String;Ljava/lang/String;Lfx0;J)V

    new-instance v0, Lads_mobile_sdk/hv0;

    invoke-direct {v0, v10}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    return-object v0
.end method
