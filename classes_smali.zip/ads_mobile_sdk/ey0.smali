.class public final Lads_mobile_sdk/ey0;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public a:I

.field public final synthetic b:Lads_mobile_sdk/ry0;

.field public final synthetic c:Landroid/net/Uri;

.field public final synthetic t:I


# direct methods
.method public synthetic constructor <init>(Lads_mobile_sdk/ry0;Landroid/net/Uri;Lvx;I)V
    .registers 5

    iput p4, p0, Lads_mobile_sdk/ey0;->t:I

    iput-object p1, p0, Lads_mobile_sdk/ey0;->b:Lads_mobile_sdk/ry0;

    iput-object p2, p0, Lads_mobile_sdk/ey0;->c:Landroid/net/Uri;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 5

    .prologue
    iget p2, p0, Lads_mobile_sdk/ey0;->t:I

    iget-object v0, p0, Lads_mobile_sdk/ey0;->c:Landroid/net/Uri;

    iget-object p0, p0, Lads_mobile_sdk/ey0;->b:Lads_mobile_sdk/ry0;

    packed-switch p2, :pswitch_data_1e

    new-instance p2, Lads_mobile_sdk/ey0;

    const/4 v1, 0x2

    invoke-direct {p2, p0, v0, p1, v1}, Lads_mobile_sdk/ey0;-><init>(Lads_mobile_sdk/ry0;Landroid/net/Uri;Lvx;I)V

    return-object p2

    :pswitch_10  #0x1
    new-instance p2, Lads_mobile_sdk/ey0;

    const/4 v1, 0x1

    invoke-direct {p2, p0, v0, p1, v1}, Lads_mobile_sdk/ey0;-><init>(Lads_mobile_sdk/ry0;Landroid/net/Uri;Lvx;I)V

    return-object p2

    :pswitch_17  #0x0
    new-instance p2, Lads_mobile_sdk/ey0;

    const/4 v1, 0x0

    invoke-direct {p2, p0, v0, p1, v1}, Lads_mobile_sdk/ey0;-><init>(Lads_mobile_sdk/ry0;Landroid/net/Uri;Lvx;I)V

    return-object p2

    :pswitch_data_1e
    .packed-switch 0x0
        :pswitch_17  #00000000
        :pswitch_10  #00000001
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .prologue
    iget v0, p0, Lads_mobile_sdk/ey0;->t:I

    sget-object v1, Lrg2;->a:Lrg2;

    iget-object v2, p0, Lads_mobile_sdk/ey0;->c:Landroid/net/Uri;

    iget-object p0, p0, Lads_mobile_sdk/ey0;->b:Lads_mobile_sdk/ry0;

    packed-switch v0, :pswitch_data_38

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/ey0;

    const/4 v0, 0x2

    invoke-direct {p1, p0, v2, p2, v0}, Lads_mobile_sdk/ey0;-><init>(Lads_mobile_sdk/ry0;Landroid/net/Uri;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/ey0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_1a  #0x1
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/ey0;

    const/4 v0, 0x1

    invoke-direct {p1, p0, v2, p2, v0}, Lads_mobile_sdk/ey0;-><init>(Lads_mobile_sdk/ry0;Landroid/net/Uri;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/ey0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_29  #0x0
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/ey0;

    const/4 v0, 0x0

    invoke-direct {p1, p0, v2, p2, v0}, Lads_mobile_sdk/ey0;-><init>(Lads_mobile_sdk/ry0;Landroid/net/Uri;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/ey0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_data_38
    .packed-switch 0x0
        :pswitch_29  #00000000
        :pswitch_1a  #00000001
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 8

    .prologue
    iget v0, p0, Lads_mobile_sdk/ey0;->t:I

    const/4 v1, 0x0

    const-string v2, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v3, 0x1

    packed-switch v0, :pswitch_data_b0

    sget-object v0, Lwy;->a:Lwy;

    iget v4, p0, Lads_mobile_sdk/ey0;->a:I

    if-eqz v4, :cond_19

    if-ne v4, v3, :cond_15

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_2e

    :cond_15
    invoke-static {v2}, Lz6;->w(Ljava/lang/String;)V

    goto :goto_30

    :cond_19
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/ey0;->b:Lads_mobile_sdk/ry0;

    iget-object v1, p1, Lads_mobile_sdk/ry0;->a:Lg33;

    iget-object p1, p1, Lads_mobile_sdk/ry0;->b:Lads_mobile_sdk/cy0;

    iget-object v2, p0, Lads_mobile_sdk/ey0;->c:Landroid/net/Uri;

    iput v3, p0, Lads_mobile_sdk/ey0;->a:I

    invoke-interface {v1, p1, v2, p0}, Lg33;->a(Lads_mobile_sdk/cy0;Landroid/net/Uri;Lads_mobile_sdk/ey0;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v0, :cond_2e

    move-object v1, v0

    goto :goto_30

    :cond_2e
    :goto_2e
    sget-object v1, Lrg2;->a:Lrg2;

    :goto_30
    return-object v1

    :pswitch_31  #0x1
    sget-object v0, Lwy;->a:Lwy;

    iget v4, p0, Lads_mobile_sdk/ey0;->a:I

    const/4 v5, 0x2

    if-eqz v4, :cond_48

    if-eq v4, v3, :cond_44

    if-ne v4, v5, :cond_40

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_7e

    :cond_40
    invoke-static {v2}, Lz6;->w(Ljava/lang/String;)V

    goto :goto_80

    :cond_44
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_63

    :cond_48
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/ey0;->b:Lads_mobile_sdk/ry0;

    iget-object p1, p1, Lads_mobile_sdk/ry0;->u:Lads_mobile_sdk/jz2;

    if-eqz p1, :cond_63

    iget-object v1, p0, Lads_mobile_sdk/ey0;->c:Landroid/net/Uri;

    invoke-virtual {v1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput v3, p0, Lads_mobile_sdk/ey0;->a:I

    invoke-static {p1, v1, p0}, Lads_mobile_sdk/jz2;->a(Lads_mobile_sdk/jz2;Ljava/lang/String;Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_63

    goto :goto_7c

    :cond_63
    :goto_63
    iget-object p1, p0, Lads_mobile_sdk/ey0;->b:Lads_mobile_sdk/ry0;

    iget-object v1, p1, Lads_mobile_sdk/ry0;->p:Lads_mobile_sdk/ji;

    sget-object v2, Lads_mobile_sdk/ry0;->w:[Liy0;

    const/4 v3, 0x4

    aget-object v2, v2, v3

    invoke-virtual {v1, p1, v2}, Lads_mobile_sdk/ji;->getValue(Ljava/lang/Object;Liy0;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lgt2;

    if-eqz p1, :cond_7e

    iput v5, p0, Lads_mobile_sdk/ey0;->a:I

    invoke-interface {p1, p0}, Lgt2;->n(Lvx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v0, :cond_7e

    :goto_7c
    move-object v1, v0

    goto :goto_80

    :cond_7e
    :goto_7e
    sget-object v1, Lrg2;->a:Lrg2;

    :goto_80
    return-object v1

    :pswitch_81  #0x0
    sget-object v0, Lwy;->a:Lwy;

    iget v4, p0, Lads_mobile_sdk/ey0;->a:I

    if-eqz v4, :cond_91

    if-ne v4, v3, :cond_8d

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_ad

    :cond_8d
    invoke-static {v2}, Lz6;->w(Ljava/lang/String;)V

    goto :goto_af

    :cond_91
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/ey0;->b:Lads_mobile_sdk/ry0;

    iget-object p1, p1, Lads_mobile_sdk/ry0;->u:Lads_mobile_sdk/jz2;

    if-eqz p1, :cond_ad

    iget-object v1, p0, Lads_mobile_sdk/ey0;->c:Landroid/net/Uri;

    invoke-virtual {v1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput v3, p0, Lads_mobile_sdk/ey0;->a:I

    invoke-virtual {p1, v1, p0}, Lads_mobile_sdk/jz2;->b(Ljava/lang/String;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v0, :cond_ad

    move-object v1, v0

    goto :goto_af

    :cond_ad
    :goto_ad
    sget-object v1, Lrg2;->a:Lrg2;

    :goto_af
    return-object v1

    :pswitch_data_b0
    .packed-switch 0x0
        :pswitch_81  #00000000
        :pswitch_31  #00000001
    .end packed-switch
.end method
