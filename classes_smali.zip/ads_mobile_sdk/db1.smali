.class public final Lads_mobile_sdk/db1;
.super Lads_mobile_sdk/ku0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field private static final DEFAULT_INSTANCE:Lads_mobile_sdk/db1;

.field public static final c:I = 0x1

.field public static final d:I = 0x2

.field public static final e:I = 0x3

.field public static final f:I = 0x4

.field public static final g:I = 0x5

.field public static final h:I = 0x6

.field public static final i:I = 0x7

.field public static final j:I = 0x8


# instance fields
.field private googlePlayInstant_:Z

.field private installBeginTimestampSeconds_:J

.field private installBeginTimestampServerSeconds_:J

.field private installReferrerErrorCode_:I

.field private installReferrer_:Ljava/lang/String;

.field private installVersion_:Ljava/lang/String;

.field private referrerClickTimestampSeconds_:J

.field private referrerClickTimestampServerSeconds_:J


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lads_mobile_sdk/db1;

    invoke-direct {v0}, Lads_mobile_sdk/db1;-><init>()V

    sput-object v0, Lads_mobile_sdk/db1;->DEFAULT_INSTANCE:Lads_mobile_sdk/db1;

    const-class v1, Lads_mobile_sdk/db1;

    invoke-static {v1, v0}, Lads_mobile_sdk/ku0;->a(Ljava/lang/Class;Lads_mobile_sdk/ku0;)V

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Lads_mobile_sdk/ku0;-><init>()V

    const-string v0, ""

    iput-object v0, p0, Lads_mobile_sdk/db1;->installReferrer_:Ljava/lang/String;

    iput-object v0, p0, Lads_mobile_sdk/db1;->installVersion_:Ljava/lang/String;

    return-void
.end method

.method public static bridge synthetic c(Lads_mobile_sdk/db1;Z)V
    .registers 2

    iput-boolean p1, p0, Lads_mobile_sdk/db1;->googlePlayInstant_:Z

    return-void
.end method

.method public static bridge synthetic d(Lads_mobile_sdk/db1;J)V
    .registers 3

    iput-wide p1, p0, Lads_mobile_sdk/db1;->installBeginTimestampSeconds_:J

    return-void
.end method

.method public static bridge synthetic f(Lads_mobile_sdk/db1;J)V
    .registers 3

    iput-wide p1, p0, Lads_mobile_sdk/db1;->installBeginTimestampServerSeconds_:J

    return-void
.end method

.method public static bridge synthetic g(Lads_mobile_sdk/db1;I)V
    .registers 2

    iput p1, p0, Lads_mobile_sdk/db1;->installReferrerErrorCode_:I

    return-void
.end method

.method public static bridge synthetic h(Lads_mobile_sdk/db1;J)V
    .registers 3

    iput-wide p1, p0, Lads_mobile_sdk/db1;->referrerClickTimestampSeconds_:J

    return-void
.end method

.method public static bridge synthetic i(Lads_mobile_sdk/db1;J)V
    .registers 3

    iput-wide p1, p0, Lads_mobile_sdk/db1;->referrerClickTimestampServerSeconds_:J

    return-void
.end method

.method public static o()Lhu2;
    .registers 1

    sget-object v0, Lads_mobile_sdk/db1;->DEFAULT_INSTANCE:Lads_mobile_sdk/db1;

    invoke-virtual {v0}, Lads_mobile_sdk/ku0;->e()Lads_mobile_sdk/iu0;

    move-result-object v0

    check-cast v0, Lhu2;

    return-object v0
.end method


# virtual methods
.method public final a(ILads_mobile_sdk/ku0;)Ljava/lang/Object;
    .registers 11

    .prologue
    invoke-static {p1}, Lvr0;->a(I)I

    move-result p0

    if-eqz p0, :cond_4d

    const/4 p1, 0x2

    if-eq p0, p1, :cond_2f

    const/4 p1, 0x3

    if-eq p0, p1, :cond_29

    const/4 p1, 0x4

    if-eq p0, p1, :cond_21

    const/4 p1, 0x5

    if-eq p0, p1, :cond_1e

    const/4 p1, 0x6

    if-ne p0, p1, :cond_1c

    const-class p0, Lads_mobile_sdk/db1;

    invoke-static {p0}, Lads_mobile_sdk/ku0;->b(Ljava/lang/Class;)Lads_mobile_sdk/ju0;

    move-result-object p0

    return-object p0

    :cond_1c
    const/4 p0, 0x0

    throw p0

    :cond_1e
    sget-object p0, Lads_mobile_sdk/db1;->DEFAULT_INSTANCE:Lads_mobile_sdk/db1;

    return-object p0

    :cond_21
    new-instance p0, Lhu2;

    sget-object p1, Lads_mobile_sdk/db1;->DEFAULT_INSTANCE:Lads_mobile_sdk/db1;

    invoke-direct {p0, p1}, Lads_mobile_sdk/iu0;-><init>(Lads_mobile_sdk/ku0;)V

    return-object p0

    :cond_29
    new-instance p0, Lads_mobile_sdk/db1;

    invoke-direct {p0}, Lads_mobile_sdk/db1;-><init>()V

    return-object p0

    :cond_2f
    const-string v6, "installVersion_"

    const-string v7, "installReferrerErrorCode_"

    const-string v0, "installReferrer_"

    const-string v1, "referrerClickTimestampSeconds_"

    const-string v2, "installBeginTimestampSeconds_"

    const-string v3, "googlePlayInstant_"

    const-string v4, "referrerClickTimestampServerSeconds_"

    const-string v5, "installBeginTimestampServerSeconds_"

    filled-new-array/range {v0 .. v7}, [Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lads_mobile_sdk/db1;->DEFAULT_INSTANCE:Lads_mobile_sdk/db1;

    new-instance p2, Lads_mobile_sdk/zq2;

    const-string v0, "\u0004\b\u0000\u0000\u0001\b\b\u0000\u0000\u0000\u0001Ȉ\u0002\u0002\u0003\u0002\u0004\u0007\u0005\u0002\u0006\u0002\u0007Ȉ\b\f"

    invoke-direct {p2, p1, v0, p0}, Lads_mobile_sdk/zq2;-><init>(Lads_mobile_sdk/ku0;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object p2

    :cond_4d
    const/4 p0, 0x1

    invoke-static {p0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p0

    return-object p0
.end method

.method public final b(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lads_mobile_sdk/db1;->installReferrer_:Ljava/lang/String;

    return-void
.end method

.method public final c(Ljava/lang/String;)V
    .registers 2

    iput-object p1, p0, Lads_mobile_sdk/db1;->installVersion_:Ljava/lang/String;

    return-void
.end method
