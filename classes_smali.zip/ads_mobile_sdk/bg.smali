.class public final Lads_mobile_sdk/bg;
.super Lads_mobile_sdk/k61;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lot2;


# instance fields
.field public final c:Lvy;

.field public final d:Lvy;

.field public final e:Lads_mobile_sdk/qr0;

.field public final f:Lx43;

.field public final g:Lq63;

.field public final h:Lads_mobile_sdk/we;

.field public final i:Lads_mobile_sdk/ef;

.field public final j:Lads_mobile_sdk/ux2;

.field public k:J

.field public l:J

.field public m:J

.field public final n:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public o:Lx52;

.field public p:Lx52;

.field public q:Lads_mobile_sdk/jf;

.field public final r:Lr63;

.field public s:Lads_mobile_sdk/tv0;

.field public t:Ljava/lang/String;

.field public final u:Lnb1;

.field public v:J

.field public final w:Ldl;

.field public final x:Lnb1;

.field public y:Z

.field public z:J


# direct methods
.method public constructor <init>(Lvy;Lvy;Lads_mobile_sdk/qr0;Lx43;Lq63;Lads_mobile_sdk/we;Lads_mobile_sdk/ef;Lads_mobile_sdk/ux2;)V
    .registers 11

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0, v0, v1}, Lads_mobile_sdk/k61;-><init>(Lads_mobile_sdk/fw0;I)V

    iput-object p1, p0, Lads_mobile_sdk/bg;->c:Lvy;

    iput-object p2, p0, Lads_mobile_sdk/bg;->d:Lvy;

    iput-object p3, p0, Lads_mobile_sdk/bg;->e:Lads_mobile_sdk/qr0;

    iput-object p4, p0, Lads_mobile_sdk/bg;->f:Lx43;

    iput-object p5, p0, Lads_mobile_sdk/bg;->g:Lq63;

    iput-object p6, p0, Lads_mobile_sdk/bg;->h:Lads_mobile_sdk/we;

    iput-object p7, p0, Lads_mobile_sdk/bg;->i:Lads_mobile_sdk/ef;

    iput-object p8, p0, Lads_mobile_sdk/bg;->j:Lads_mobile_sdk/ux2;

    sget-object p1, Lv60;->b:Lp80;

    const-wide/16 p1, 0x0

    iput-wide p1, p0, Lads_mobile_sdk/bg;->k:J

    iput-wide p1, p0, Lads_mobile_sdk/bg;->l:J

    iput-wide p1, p0, Lads_mobile_sdk/bg;->m:J

    new-instance p3, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 p4, 0x0

    invoke-direct {p3, p4}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object p3, p0, Lads_mobile_sdk/bg;->n:Ljava/util/concurrent/atomic/AtomicBoolean;

    sget-object p3, Lads_mobile_sdk/jf;->a:Lads_mobile_sdk/jf;

    iput-object p3, p0, Lads_mobile_sdk/bg;->q:Lads_mobile_sdk/jf;

    invoke-static {}, Lads_mobile_sdk/zv0;->o()Lr63;

    move-result-object p3

    iput-object p3, p0, Lads_mobile_sdk/bg;->r:Lr63;

    new-instance p3, Lnb1;

    invoke-direct {p3}, Lnb1;-><init>()V

    iput-object p3, p0, Lads_mobile_sdk/bg;->u:Lnb1;

    iput-wide p1, p0, Lads_mobile_sdk/bg;->v:J

    const/4 p3, 0x7

    invoke-static {p4, p3, v0}, Lq23;->d(IILwk;)Ldl;

    move-result-object p3

    iput-object p3, p0, Lads_mobile_sdk/bg;->w:Ldl;

    new-instance p3, Lnb1;

    invoke-direct {p3}, Lnb1;-><init>()V

    iput-object p3, p0, Lads_mobile_sdk/bg;->x:Lnb1;

    iput-boolean v1, p0, Lads_mobile_sdk/bg;->y:Z

    iput-wide p1, p0, Lads_mobile_sdk/bg;->z:J

    return-void
.end method

.method public static a(Lads_mobile_sdk/bg;JLwx;)Ljava/lang/Object;
    .registers 8

    .prologue
    instance-of v0, p3, Lads_mobile_sdk/mf;

    if-eqz v0, :cond_13

    move-object v0, p3

    check-cast v0, Lads_mobile_sdk/mf;

    iget v1, v0, Lads_mobile_sdk/mf;->f:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/mf;->f:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/mf;

    invoke-direct {v0, p0, p3}, Lads_mobile_sdk/mf;-><init>(Lads_mobile_sdk/bg;Lwx;)V

    :goto_18
    iget-object p3, v0, Lads_mobile_sdk/mf;->d:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/mf;->f:I

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v1, :cond_34

    if-ne v1, v2, :cond_2e

    iget-wide p1, v0, Lads_mobile_sdk/mf;->c:J

    iget-object p0, v0, Lads_mobile_sdk/mf;->b:Lnb1;

    iget-object v0, v0, Lads_mobile_sdk/mf;->a:Lads_mobile_sdk/bg;

    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V

    move-object p3, p0

    move-object p0, v0

    goto :goto_4a

    :cond_2e
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v3

    :cond_34
    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p3, p0, Lads_mobile_sdk/bg;->x:Lnb1;

    iput-object p0, v0, Lads_mobile_sdk/mf;->a:Lads_mobile_sdk/bg;

    iput-object p3, v0, Lads_mobile_sdk/mf;->b:Lnb1;

    iput-wide p1, v0, Lads_mobile_sdk/mf;->c:J

    iput v2, v0, Lads_mobile_sdk/mf;->f:I

    invoke-virtual {p3, v0}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v0

    sget-object v1, Lwy;->a:Lwy;

    if-ne v0, v1, :cond_4a

    return-object v1

    :cond_4a
    :goto_4a
    :try_start_4a
    iget-wide v0, p0, Lads_mobile_sdk/bg;->z:J

    invoke-static {p1, p2, v0, v1}, Lv60;->c(JJ)I

    move-result v0
    :try_end_50
    .catchall {:try_start_4a .. :try_end_50} :catchall_6b

    sget-object v1, Lrg2;->a:Lrg2;

    if-lez v0, :cond_7d

    :try_start_54
    iget-boolean v0, p0, Lads_mobile_sdk/bg;->y:Z

    if-nez v0, :cond_59

    goto :goto_7d

    :cond_59
    const/4 v0, 0x0

    iput-boolean v0, p0, Lads_mobile_sdk/bg;->y:Z

    iput-wide p1, p0, Lads_mobile_sdk/bg;->z:J

    iget-object p1, p0, Lads_mobile_sdk/bg;->n:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {p1, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    iget-object p1, p0, Lads_mobile_sdk/bg;->o:Lx52;

    if-eqz p1, :cond_6d

    invoke-virtual {p1, v3}, Lnv0;->a(Ljava/util/concurrent/CancellationException;)V

    goto :goto_6d

    :catchall_6b
    move-exception p0

    goto :goto_81

    :cond_6d
    :goto_6d
    iget-object p0, p0, Lads_mobile_sdk/bg;->p:Lx52;

    if-eqz p0, :cond_74

    invoke-virtual {p0, v3}, Lnv0;->a(Ljava/util/concurrent/CancellationException;)V

    :cond_74
    const-string p0, "ANR watchdog stopped"

    invoke-static {p0, v3}, Lads_mobile_sdk/nw;->b(Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_79
    .catchall {:try_start_54 .. :try_end_79} :catchall_6b

    invoke-virtual {p3, v3}, Lnb1;->b(Ljava/lang/Object;)V

    return-object v1

    :cond_7d
    :goto_7d
    invoke-virtual {p3, v3}, Lnb1;->b(Ljava/lang/Object;)V

    return-object v1

    :goto_81
    invoke-virtual {p3, v3}, Lnb1;->b(Ljava/lang/Object;)V

    throw p0
.end method

.method public static final a(Lads_mobile_sdk/bg;Lwx;)Ljava/lang/Object;
    .registers 8

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/of;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/of;

    iget v1, v0, Lads_mobile_sdk/of;->d:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/of;->d:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/of;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/of;-><init>(Lads_mobile_sdk/bg;Lwx;)V

    :goto_18
    iget-object p1, v0, Lads_mobile_sdk/of;->b:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/of;->d:I

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_24

    if-ne v1, v3, :cond_28

    iget-object p0, v0, Lads_mobile_sdk/of;->a:Lads_mobile_sdk/bg;

    :cond_24
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_2e

    :cond_28
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v2

    :cond_2e
    :goto_2e
    iget-object p1, p0, Lads_mobile_sdk/bg;->n:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result p1

    if-eqz p1, :cond_52

    iget-object p1, p0, Lads_mobile_sdk/bg;->d:Lvy;

    new-instance v1, Lto;

    const/16 v4, 0x17

    invoke-direct {v1, p0, v2, v4}, Lto;-><init>(Ljava/lang/Object;Lvx;I)V

    const/4 v4, 0x3

    invoke-static {p1, v2, v2, v1, v4}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    iget-wide v4, p0, Lads_mobile_sdk/bg;->m:J

    iput-object p0, v0, Lads_mobile_sdk/of;->a:Lads_mobile_sdk/bg;

    iput v3, v0, Lads_mobile_sdk/of;->d:I

    invoke-static {v4, v5, v0}, Lsz;->u(JLvx;)Ljava/lang/Object;

    move-result-object p1

    sget-object v1, Lwy;->a:Lwy;

    if-ne p1, v1, :cond_2e

    return-object v1

    :cond_52
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method

.method public static b(Lads_mobile_sdk/bg;JLwx;)Ljava/lang/Object;
    .registers 14

    .prologue
    instance-of v0, p3, Lads_mobile_sdk/nf;

    if-eqz v0, :cond_13

    move-object v0, p3

    check-cast v0, Lads_mobile_sdk/nf;

    iget v1, v0, Lads_mobile_sdk/nf;->f:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/nf;->f:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/nf;

    invoke-direct {v0, p0, p3}, Lads_mobile_sdk/nf;-><init>(Lads_mobile_sdk/bg;Lwx;)V

    :goto_18
    iget-object p3, v0, Lads_mobile_sdk/nf;->d:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/nf;->f:I

    sget-object v2, Lrg2;->a:Lrg2;

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    sget-object v6, Lwy;->a:Lwy;

    if-eqz v1, :cond_47

    if-eq v1, v4, :cond_39

    if-ne v1, v3, :cond_33

    iget-object p0, v0, Lads_mobile_sdk/nf;->a:Ljava/lang/Object;

    check-cast p0, Llb1;

    :try_start_2d
    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_30
    .catchall {:try_start_2d .. :try_end_30} :catchall_31

    goto :goto_7c

    :catchall_31
    move-exception p1

    goto :goto_82

    :cond_33
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v5

    :cond_39
    iget-wide p1, v0, Lads_mobile_sdk/nf;->c:J

    iget-object p0, v0, Lads_mobile_sdk/nf;->b:Lnb1;

    iget-object v1, v0, Lads_mobile_sdk/nf;->a:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/bg;

    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V

    move-object p3, p0

    move-object p0, v1

    goto :goto_5b

    :cond_47
    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p3, p0, Lads_mobile_sdk/bg;->x:Lnb1;

    iput-object p0, v0, Lads_mobile_sdk/nf;->a:Ljava/lang/Object;

    iput-object p3, v0, Lads_mobile_sdk/nf;->b:Lnb1;

    iput-wide p1, v0, Lads_mobile_sdk/nf;->c:J

    iput v4, v0, Lads_mobile_sdk/nf;->f:I

    invoke-virtual {p3, v0}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v6, :cond_5b

    goto :goto_78

    :cond_5b
    :goto_5b
    :try_start_5b
    iget-wide v7, p0, Lads_mobile_sdk/bg;->z:J

    invoke-static {p1, p2, v7, v8}, Lv60;->c(JJ)I

    move-result v1

    if-lez v1, :cond_87

    iget-boolean v1, p0, Lads_mobile_sdk/bg;->y:Z

    if-eqz v1, :cond_68

    goto :goto_87

    :cond_68
    iput-boolean v4, p0, Lads_mobile_sdk/bg;->y:Z

    iput-wide p1, p0, Lads_mobile_sdk/bg;->z:J

    iput-object p3, v0, Lads_mobile_sdk/nf;->a:Ljava/lang/Object;

    iput-object v5, v0, Lads_mobile_sdk/nf;->b:Lnb1;

    iput v3, v0, Lads_mobile_sdk/nf;->f:I

    invoke-static {p0, v0}, Lads_mobile_sdk/bg;->d(Lads_mobile_sdk/bg;Lwx;)Ljava/lang/Object;

    move-result-object p0
    :try_end_76
    .catchall {:try_start_5b .. :try_end_76} :catchall_84

    if-ne p0, v6, :cond_79

    :goto_78
    return-object v6

    :cond_79
    move-object v9, p3

    move-object p3, p0

    move-object p0, v9

    :goto_7c
    :try_start_7c
    check-cast p3, Lb13;
    :try_end_7e
    .catchall {:try_start_7c .. :try_end_7e} :catchall_31

    invoke-interface {p0, v5}, Llb1;->b(Ljava/lang/Object;)V

    return-object v2

    :goto_82
    move-object p3, p0

    goto :goto_8b

    :catchall_84
    move-exception p0

    move-object p1, p0

    goto :goto_8b

    :cond_87
    :goto_87
    invoke-virtual {p3, v5}, Lnb1;->b(Ljava/lang/Object;)V

    return-object v2

    :goto_8b
    invoke-interface {p3, v5}, Llb1;->b(Ljava/lang/Object;)V

    throw p1
.end method

.method public static final b(Lads_mobile_sdk/bg;Lwx;)Ljava/lang/Object;
    .registers 8

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/xf;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/xf;

    iget v1, v0, Lads_mobile_sdk/xf;->f:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/xf;->f:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/xf;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/xf;-><init>(Lads_mobile_sdk/bg;Lwx;)V

    :goto_18
    iget-object p1, v0, Lads_mobile_sdk/xf;->d:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/xf;->f:I

    const/4 v2, 0x2

    const/4 v3, 0x1

    sget-object v4, Lwy;->a:Lwy;

    if-eqz v1, :cond_3d

    if-eq v1, v3, :cond_37

    if-ne v1, v2, :cond_30

    iget-object p0, v0, Lads_mobile_sdk/xf;->c:Ljava/util/Iterator;

    iget-object v1, v0, Lads_mobile_sdk/xf;->b:Ljava/util/Map;

    iget-object v3, v0, Lads_mobile_sdk/xf;->a:Lads_mobile_sdk/bg;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_5c

    :cond_30
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0

    :cond_37
    iget-object p0, v0, Lads_mobile_sdk/xf;->a:Lads_mobile_sdk/bg;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_4d

    :cond_3d
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/bg;->i:Lads_mobile_sdk/ef;

    iput-object p0, v0, Lads_mobile_sdk/xf;->a:Lads_mobile_sdk/bg;

    iput v3, v0, Lads_mobile_sdk/xf;->f:I

    invoke-virtual {p1, v0}, Lads_mobile_sdk/ef;->a(Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v4, :cond_4d

    goto :goto_82

    :cond_4d
    :goto_4d
    move-object v1, p1

    check-cast v1, Ljava/util/Map;

    if-eqz v1, :cond_83

    invoke-interface {v1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    move-object v3, p0

    move-object p0, p1

    :cond_5c
    :goto_5c
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_83

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/Map$Entry;

    invoke-interface {p1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    invoke-interface {p1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lads_mobile_sdk/tv0;

    iput-object v3, v0, Lads_mobile_sdk/xf;->a:Lads_mobile_sdk/bg;

    iput-object v1, v0, Lads_mobile_sdk/xf;->b:Ljava/util/Map;

    iput-object p0, v0, Lads_mobile_sdk/xf;->c:Ljava/util/Iterator;

    iput v2, v0, Lads_mobile_sdk/xf;->f:I

    invoke-virtual {v3, v5, p1, v0}, Lads_mobile_sdk/bg;->a(Ljava/lang/String;Lads_mobile_sdk/tv0;Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v4, :cond_5c

    :goto_82
    return-object v4

    :cond_83
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method

.method public static final c(Lads_mobile_sdk/bg;Lwx;)Ljava/lang/Object;
    .registers 21

    .prologue
    move-object/from16 v0, p1

    instance-of v1, v0, Lads_mobile_sdk/yf;

    if-eqz v1, :cond_17

    move-object v1, v0

    check-cast v1, Lads_mobile_sdk/yf;

    iget v2, v1, Lads_mobile_sdk/yf;->d:I

    const/high16 v3, -0x80000000

    and-int v4, v2, v3

    if-eqz v4, :cond_17

    sub-int/2addr v2, v3

    iput v2, v1, Lads_mobile_sdk/yf;->d:I

    move-object/from16 v2, p0

    goto :goto_1e

    :cond_17
    new-instance v1, Lads_mobile_sdk/yf;

    move-object/from16 v2, p0

    invoke-direct {v1, v2, v0}, Lads_mobile_sdk/yf;-><init>(Lads_mobile_sdk/bg;Lwx;)V

    :goto_1e
    iget-object v0, v1, Lads_mobile_sdk/yf;->b:Ljava/lang/Object;

    iget v3, v1, Lads_mobile_sdk/yf;->d:I

    const/4 v4, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x1

    sget-object v8, Lwy;->a:Lwy;

    if-eqz v3, :cond_32

    if-eq v3, v7, :cond_43

    if-eq v3, v6, :cond_3c

    if-ne v3, v5, :cond_36

    iget-object v2, v1, Lads_mobile_sdk/yf;->a:Lads_mobile_sdk/bg;

    :cond_32
    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_49

    :cond_36
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {v0}, Lz6;->w(Ljava/lang/String;)V

    return-object v4

    :cond_3c
    iget-object v2, v1, Lads_mobile_sdk/yf;->a:Lads_mobile_sdk/bg;

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    goto/16 :goto_b8

    :cond_43
    iget-object v2, v1, Lads_mobile_sdk/yf;->a:Lads_mobile_sdk/bg;

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_5c

    :cond_49
    :goto_49
    iget-object v0, v2, Lads_mobile_sdk/bg;->n:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    if-eqz v0, :cond_c3

    iput-object v2, v1, Lads_mobile_sdk/yf;->a:Lads_mobile_sdk/bg;

    iput v7, v1, Lads_mobile_sdk/yf;->d:I

    invoke-virtual {v2, v1}, Lads_mobile_sdk/bg;->r(Lwx;)Ljava/lang/Object;

    move-result-object v0

    if-ne v0, v8, :cond_5c

    goto :goto_c2

    :cond_5c
    :goto_5c
    check-cast v0, Lv60;

    iget-wide v9, v0, Lv60;->a:J

    new-instance v12, Lqz1;

    invoke-virtual {v1}, Lwx;->getContext()Lly;

    move-result-object v0

    invoke-direct {v12, v0}, Lqz1;-><init>(Lly;)V

    new-instance v0, Lu23;

    invoke-direct {v0, v7, v4, v7}, Lu23;-><init>(ILvx;I)V

    invoke-static {v9, v10}, Lsz;->T(J)J

    move-result-wide v9

    invoke-static {v12, v9, v10, v0}, Lpy2;->F(Lqz1;JLbk0;)V

    iget-object v0, v2, Lads_mobile_sdk/bg;->w:Ldl;

    invoke-virtual {v0}, Ldl;->p()Lfm0;

    move-result-object v0

    new-instance v3, Lit2;

    const/4 v9, 0x0

    invoke-direct {v3, v6, v4, v9}, Lit2;-><init>(ILvx;I)V

    new-instance v11, Loz1;

    iget-object v10, v0, Lfm0;->b:Ljava/lang/Object;

    move-object v13, v10

    check-cast v13, Ldl;

    sget-object v14, Lzk;->h:Lzk;

    sget-object v15, Lal;->h:Lal;

    iget-object v0, v0, Lfm0;->c:Ljava/lang/Object;

    move-object/from16 v18, v0

    check-cast v18, Lrk0;

    const/16 v16, 0x0

    move-object/from16 v17, v3

    invoke-direct/range {v11 .. v18}, Loz1;-><init>(Lqz1;Ljava/lang/Object;Lrk0;Lrk0;Ljava/lang/Object;Lm82;Lrk0;)V

    invoke-virtual {v12, v11, v9}, Lqz1;->f(Loz1;Z)V

    iput-object v2, v1, Lads_mobile_sdk/yf;->a:Lads_mobile_sdk/bg;

    iput v6, v1, Lads_mobile_sdk/yf;->d:I

    sget-object v0, Lbf;->a:Lsun/misc/Unsafe;

    sget-wide v9, Lqz1;->f:J

    invoke-virtual {v0, v12, v9, v10}, Lsun/misc/Unsafe;->getObjectVolatile(Ljava/lang/Object;J)Ljava/lang/Object;

    move-result-object v0

    instance-of v0, v0, Loz1;

    if-eqz v0, :cond_b1

    invoke-virtual {v12, v1}, Lqz1;->c(Lwx;)Ljava/lang/Object;

    move-result-object v0

    goto :goto_b5

    :cond_b1
    invoke-virtual {v12, v1}, Lqz1;->d(Lwx;)Ljava/lang/Object;

    move-result-object v0

    :goto_b5
    if-ne v0, v8, :cond_b8

    goto :goto_c2

    :cond_b8
    :goto_b8
    iput-object v2, v1, Lads_mobile_sdk/yf;->a:Lads_mobile_sdk/bg;

    iput v5, v1, Lads_mobile_sdk/yf;->d:I

    invoke-virtual {v2, v1}, Lads_mobile_sdk/bg;->s(Lwx;)Ljava/lang/Object;

    move-result-object v0

    if-ne v0, v8, :cond_49

    :goto_c2
    return-object v8

    :cond_c3
    sget-object v0, Lrg2;->a:Lrg2;

    return-object v0
.end method

.method public static d(Lads_mobile_sdk/bg;Lwx;)Ljava/lang/Object;
    .registers 18

    .prologue
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    instance-of v2, v1, Lads_mobile_sdk/sf;

    if-eqz v2, :cond_17

    move-object v2, v1

    check-cast v2, Lads_mobile_sdk/sf;

    iget v3, v2, Lads_mobile_sdk/sf;->e:I

    const/high16 v4, -0x80000000

    and-int v5, v3, v4

    if-eqz v5, :cond_17

    sub-int/2addr v3, v4

    iput v3, v2, Lads_mobile_sdk/sf;->e:I

    goto :goto_1c

    :cond_17
    new-instance v2, Lads_mobile_sdk/sf;

    invoke-direct {v2, v0, v1}, Lads_mobile_sdk/sf;-><init>(Lads_mobile_sdk/bg;Lwx;)V

    :goto_1c
    iget-object v1, v2, Lads_mobile_sdk/sf;->c:Ljava/lang/Object;

    iget v3, v2, Lads_mobile_sdk/sf;->e:I

    sget-object v4, Ly60;->d:Ly60;

    sget-object v5, Lrg2;->a:Lrg2;

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-eqz v3, :cond_3b

    if-ne v3, v6, :cond_35

    iget-object v0, v2, Lads_mobile_sdk/sf;->b:Lnb1;

    iget-object v2, v2, Lads_mobile_sdk/sf;->a:Lads_mobile_sdk/bg;

    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V

    move-object v1, v0

    move-object v0, v2

    goto/16 :goto_11d

    :cond_35
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {v0}, Lz6;->w(Ljava/lang/String;)V

    return-object v7

    :cond_3b
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object v1, v0, Lads_mobile_sdk/bg;->e:Lads_mobile_sdk/qr0;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sget-object v8, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    const-string v9, "gads:system_health:anr_watchdog:enabled"

    invoke-virtual {v1, v9, v3, v8}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Boolean;

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-nez v3, :cond_5d

    new-instance v0, Lads_mobile_sdk/ev0;

    const-string v1, "ANR watchdog is disabled"

    invoke-direct {v0, v1, v6}, Lads_mobile_sdk/ev0;-><init>(Ljava/lang/String;I)V

    return-object v0

    :cond_5d
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v3, Lv60;->b:Lp80;

    const/16 v3, 0x3e8

    invoke-static {v3, v4}, Li10;->G0(ILy60;)J

    move-result-wide v8

    new-instance v10, Lv60;

    invoke-direct {v10, v8, v9}, Lv60;-><init>(J)V

    sget-object v8, Lads_mobile_sdk/fo;->a$18:Lads_mobile_sdk/fo;

    const-string v9, "gads:system_health:early_anr_threshold_millis"

    invoke-virtual {v1, v9, v10, v8}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Lv60;

    iget-wide v10, v10, Lv60;->a:J

    const-wide/16 v12, 0x0

    invoke-static {v10, v11, v12, v13}, Lv60;->c(JJ)I

    move-result v10

    if-lez v10, :cond_166

    const/16 v10, 0x1194

    invoke-static {v10, v4}, Li10;->G0(ILy60;)J

    move-result-wide v14

    new-instance v11, Lv60;

    invoke-direct {v11, v14, v15}, Lv60;-><init>(J)V

    const-string v14, "gads:system_health:full_anr_threshold_millis"

    invoke-virtual {v1, v14, v11, v8}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lv60;

    iget-wide v10, v11, Lv60;->a:J

    invoke-static {v10, v11, v12, v13}, Lv60;->c(JJ)I

    move-result v10

    if-lez v10, :cond_166

    const/16 v10, 0x1f4

    invoke-static {v10, v4}, Li10;->G0(ILy60;)J

    move-result-wide v6

    new-instance v11, Lv60;

    invoke-direct {v11, v6, v7}, Lv60;-><init>(J)V

    const-string v6, "gads:system_health:anr_polling_millis"

    invoke-virtual {v1, v6, v11, v8}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lv60;

    iget-wide v10, v7, Lv60;->a:J

    invoke-static {v10, v11, v12, v13}, Lv60;->c(JJ)I

    move-result v7

    if-gtz v7, :cond_b9

    goto/16 :goto_166

    :cond_b9
    iget-object v7, v0, Lads_mobile_sdk/bg;->n:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v11, 0x1

    invoke-virtual {v7, v11}, Ljava/util/concurrent/atomic/AtomicBoolean;->getAndSet(Z)Z

    move-result v7

    if-eqz v7, :cond_ce

    const-string v0, "ANR watchdog is already running"

    const/4 v15, 0x0

    invoke-static {v0, v15}, Lads_mobile_sdk/nw;->b(Ljava/lang/String;Ljava/lang/Throwable;)V

    new-instance v0, Lads_mobile_sdk/hv0;

    invoke-direct {v0, v5}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    return-object v0

    :cond_ce
    invoke-static {v3, v4}, Li10;->G0(ILy60;)J

    move-result-wide v12

    new-instance v3, Lv60;

    invoke-direct {v3, v12, v13}, Lv60;-><init>(J)V

    invoke-virtual {v1, v9, v3, v8}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lv60;

    iget-wide v9, v3, Lv60;->a:J

    iput-wide v9, v0, Lads_mobile_sdk/bg;->k:J

    const/16 v3, 0x1194

    invoke-static {v3, v4}, Li10;->G0(ILy60;)J

    move-result-wide v9

    new-instance v3, Lv60;

    invoke-direct {v3, v9, v10}, Lv60;-><init>(J)V

    invoke-virtual {v1, v14, v3, v8}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lv60;

    iget-wide v9, v3, Lv60;->a:J

    iput-wide v9, v0, Lads_mobile_sdk/bg;->l:J

    const/16 v3, 0x1f4

    invoke-static {v3, v4}, Li10;->G0(ILy60;)J

    move-result-wide v9

    new-instance v3, Lv60;

    invoke-direct {v3, v9, v10}, Lv60;-><init>(J)V

    invoke-virtual {v1, v6, v3, v8}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lv60;

    iget-wide v6, v1, Lv60;->a:J

    iput-wide v6, v0, Lads_mobile_sdk/bg;->m:J

    iget-object v1, v0, Lads_mobile_sdk/bg;->u:Lnb1;

    iput-object v0, v2, Lads_mobile_sdk/sf;->a:Lads_mobile_sdk/bg;

    iput-object v1, v2, Lads_mobile_sdk/sf;->b:Lnb1;

    const/4 v11, 0x1

    iput v11, v2, Lads_mobile_sdk/sf;->e:I

    invoke-virtual {v1, v2}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v2

    sget-object v3, Lwy;->a:Lwy;

    if-ne v2, v3, :cond_11d

    return-object v3

    :cond_11d
    :goto_11d
    :try_start_11d
    sget-object v2, Lv60;->b:Lp80;

    iget-object v2, v0, Lads_mobile_sdk/bg;->f:Lx43;

    iget-object v3, v0, Lads_mobile_sdk/bg;->c:Lvy;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v6

    invoke-static {v6, v7, v4}, Li10;->H0(JLy60;)J

    move-result-wide v6

    iput-wide v6, v0, Lads_mobile_sdk/bg;->v:J
    :try_end_130
    .catchall {:try_start_11d .. :try_end_130} :catchall_160

    const/4 v15, 0x0

    invoke-virtual {v1, v15}, Lnb1;->b(Ljava/lang/Object;)V

    new-instance v1, Lads_mobile_sdk/tf;

    const/4 v2, 0x0

    invoke-direct {v1, v0, v15, v2}, Lads_mobile_sdk/tf;-><init>(Lads_mobile_sdk/bg;Lvx;I)V

    invoke-static {v3, v1}, Lads_mobile_sdk/xh3;->a(Lvy;Lpk0;)Lx52;

    new-instance v1, Lads_mobile_sdk/tf;

    const/4 v11, 0x1

    invoke-direct {v1, v0, v15, v11}, Lads_mobile_sdk/tf;-><init>(Lads_mobile_sdk/bg;Lvx;I)V

    invoke-static {v3, v1}, Lads_mobile_sdk/xh3;->a(Lvy;Lpk0;)Lx52;

    move-result-object v1

    iput-object v1, v0, Lads_mobile_sdk/bg;->o:Lx52;

    new-instance v1, Lads_mobile_sdk/tf;

    const/4 v2, 0x2

    invoke-direct {v1, v0, v15, v2}, Lads_mobile_sdk/tf;-><init>(Lads_mobile_sdk/bg;Lvx;I)V

    invoke-static {v3, v1}, Lads_mobile_sdk/xh3;->a(Lvy;Lpk0;)Lx52;

    move-result-object v1

    iput-object v1, v0, Lads_mobile_sdk/bg;->p:Lx52;

    const-string v0, "ANR watchdog started"

    invoke-static {v0}, Llk;->d(Ljava/lang/String;)V

    new-instance v0, Lads_mobile_sdk/hv0;

    invoke-direct {v0, v5}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    return-object v0

    :catchall_160
    move-exception v0

    const/4 v15, 0x0

    invoke-virtual {v1, v15}, Lnb1;->b(Ljava/lang/Object;)V

    throw v0

    :cond_166
    :goto_166
    new-instance v0, Lads_mobile_sdk/ev0;

    const-string v1, "Invalid ANR watchdog flags"

    const/4 v11, 0x1

    invoke-direct {v0, v1, v11}, Lads_mobile_sdk/ev0;-><init>(Ljava/lang/String;I)V

    return-object v0
.end method


# virtual methods
.method public final a(Ljava/lang/String;Lads_mobile_sdk/tv0;Lwx;)Ljava/lang/Object;
    .registers 11

    .prologue
    instance-of v0, p3, Lads_mobile_sdk/rf;

    if-eqz v0, :cond_13

    move-object v0, p3

    check-cast v0, Lads_mobile_sdk/rf;

    iget v1, v0, Lads_mobile_sdk/rf;->e:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/rf;->e:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/rf;

    invoke-direct {v0, p0, p3}, Lads_mobile_sdk/rf;-><init>(Lads_mobile_sdk/bg;Lwx;)V

    :goto_18
    iget-object p3, v0, Lads_mobile_sdk/rf;->c:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/rf;->e:I

    sget-object v2, Lrg2;->a:Lrg2;

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    sget-object v6, Lwy;->a:Lwy;

    if-eqz v1, :cond_3e

    if-eq v1, v5, :cond_36

    if-ne v1, v4, :cond_30

    iget-object p0, v0, Lads_mobile_sdk/rf;->a:Lads_mobile_sdk/bg;

    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V

    goto/16 :goto_a7

    :cond_30
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v3

    :cond_36
    iget-object p1, v0, Lads_mobile_sdk/rf;->b:Ljava/lang/String;

    iget-object p0, v0, Lads_mobile_sdk/rf;->a:Lads_mobile_sdk/bg;

    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_7e

    :cond_3e
    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Lads_mobile_sdk/yv0;->o()Le73;

    move-result-object p3

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v1, p3, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v1, Lads_mobile_sdk/yv0;

    invoke-virtual {v1, p2}, Lads_mobile_sdk/yv0;->a(Lads_mobile_sdk/tv0;)V

    invoke-virtual {p3}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object p2

    check-cast p2, Lads_mobile_sdk/yv0;

    iget-object p3, p0, Lads_mobile_sdk/bg;->r:Lr63;

    invoke-virtual {p3}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v1, p3, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v1, Lads_mobile_sdk/zv0;

    invoke-virtual {v1, p2}, Lads_mobile_sdk/zv0;->a(Lads_mobile_sdk/yv0;)V

    invoke-virtual {p3}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object p2

    check-cast p2, Lads_mobile_sdk/zv0;

    invoke-virtual {p2}, Lads_mobile_sdk/g;->a()[B

    move-result-object p2

    iput-object p0, v0, Lads_mobile_sdk/rf;->a:Lads_mobile_sdk/bg;

    iput-object p1, v0, Lads_mobile_sdk/rf;->b:Ljava/lang/String;

    iput v5, v0, Lads_mobile_sdk/rf;->e:I

    invoke-virtual {p0, p2, v0}, Lads_mobile_sdk/bg;->a([BLwx;)Ljava/lang/Object;

    move-result-object p3

    if-ne p3, v6, :cond_7e

    goto :goto_a6

    :cond_7e
    :goto_7e
    check-cast p3, Ljava/lang/Boolean;

    invoke-virtual {p3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    if-eqz p2, :cond_a7

    iget-object p2, p0, Lads_mobile_sdk/bg;->i:Lads_mobile_sdk/ef;

    iput-object p0, v0, Lads_mobile_sdk/rf;->a:Lads_mobile_sdk/bg;

    iput-object v3, v0, Lads_mobile_sdk/rf;->b:Ljava/lang/String;

    iput v4, v0, Lads_mobile_sdk/rf;->e:I

    iget-object p2, p2, Lads_mobile_sdk/ef;->a:Lv03;

    invoke-interface {p2}, Lv03;->get()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lc42;

    new-instance p3, Lads_mobile_sdk/cf;

    const/4 v1, 0x0

    invoke-direct {p3, p1, v3, v1}, Lads_mobile_sdk/cf;-><init>(Ljava/lang/String;Lvx;I)V

    invoke-virtual {p2, p3, v0}, Lc42;->i(Lpk0;Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v6, :cond_a3

    goto :goto_a4

    :cond_a3
    move-object p1, v2

    :goto_a4
    if-ne p1, v6, :cond_a7

    :goto_a6
    return-object v6

    :cond_a7
    :goto_a7
    iget-object p0, p0, Lads_mobile_sdk/bg;->r:Lr63;

    invoke-virtual {p0}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object p0, p0, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast p0, Lads_mobile_sdk/zv0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object p1, Lads_mobile_sdk/am2;->e:Lads_mobile_sdk/am2;

    invoke-static {p0, p1}, Lads_mobile_sdk/zv0;->c(Lads_mobile_sdk/zv0;Lw63;)V

    return-object v2
.end method

.method public final a([BLwx;)Ljava/lang/Object;
    .registers 10

    .prologue
    instance-of v0, p2, Lads_mobile_sdk/wf;

    if-eqz v0, :cond_13

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/wf;

    iget v1, v0, Lads_mobile_sdk/wf;->c:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/wf;->c:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/wf;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/wf;-><init>(Lads_mobile_sdk/bg;Lwx;)V

    :goto_18
    iget-object p2, v0, Lads_mobile_sdk/wf;->a:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/wf;->c:I

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_2e

    if-ne v1, v3, :cond_28

    :try_start_22
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_25
    .catch Ljava/lang/Exception; {:try_start_22 .. :try_end_25} :catch_26

    goto :goto_5f

    :catch_26
    move-exception p0

    goto :goto_68

    :cond_28
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v2

    :cond_2e
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    :try_start_31
    new-instance p2, Lads_mobile_sdk/g21;

    invoke-direct {p2}, Lads_mobile_sdk/g21;-><init>()V

    iget-object v1, p0, Lads_mobile_sdk/bg;->e:Lads_mobile_sdk/qr0;

    const-string v4, "gads:remote_capture_service_url"

    const-string v5, "https://pagead2.googlesyndication.com/pagead/ping?e=2&f=1"

    sget-object v6, Lads_mobile_sdk/fo;->a$23:Lads_mobile_sdk/fo;

    invoke-virtual {v1, v4, v5, v6}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-virtual {p2, v1}, Lads_mobile_sdk/g21;->b(Ljava/lang/String;)V

    const-string v1, "application/x-protobuf"

    invoke-virtual {p2, v1, p1}, Lads_mobile_sdk/g21;->b(Ljava/lang/String;[B)V

    invoke-virtual {p2}, Lads_mobile_sdk/g21;->a()Lads_mobile_sdk/h21;

    move-result-object p1

    iget-object p0, p0, Lads_mobile_sdk/bg;->g:Lq63;

    iput v3, v0, Lads_mobile_sdk/wf;->c:I

    const/16 p2, 0x1e

    invoke-static {p0, p1, v2, v0, p2}, Lq63;->b(Lq63;Lads_mobile_sdk/h21;Lv60;Lwx;I)Ljava/lang/Object;

    move-result-object p2
    :try_end_5a
    .catch Ljava/lang/Exception; {:try_start_31 .. :try_end_5a} :catch_26

    sget-object p0, Lwy;->a:Lwy;

    if-ne p2, p0, :cond_5f

    return-object p0

    :cond_5f
    :goto_5f
    :try_start_5f
    check-cast p2, Lb13;

    instance-of p0, p2, Lads_mobile_sdk/hv0;

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0
    :try_end_67
    .catch Ljava/lang/Exception; {:try_start_5f .. :try_end_67} :catch_26

    return-object p0

    :goto_68
    new-instance p1, Ljava/lang/StringBuilder;

    const-string p2, "Failed to ping RCS payload: "

    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0, v2}, Lads_mobile_sdk/nw;->b(Ljava/lang/String;Ljava/lang/Throwable;)V

    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    return-object p0
.end method

.method public final b(JLm82;)Ljava/lang/Object;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lads_mobile_sdk/bg;->b(Lads_mobile_sdk/bg;JLwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final d(JLm82;)Ljava/lang/Object;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lads_mobile_sdk/bg;->a(Lads_mobile_sdk/bg;JLwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final h(Lvx;)Ljava/lang/Object;
    .registers 2

    check-cast p1, Lwx;

    invoke-static {p0, p1}, Lads_mobile_sdk/bg;->d(Lads_mobile_sdk/bg;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final k(Lvx;)Ljava/lang/Object;
    .registers 7

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/kf;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/kf;

    iget v1, v0, Lads_mobile_sdk/kf;->e:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/kf;->e:I

    goto :goto_1a

    :cond_13
    new-instance v0, Lads_mobile_sdk/kf;

    check-cast p1, Lwx;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/kf;-><init>(Lads_mobile_sdk/bg;Lwx;)V

    :goto_1a
    iget-object p1, v0, Lads_mobile_sdk/kf;->c:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/kf;->e:I

    const/4 v2, 0x1

    if-eqz v1, :cond_36

    if-ne v1, v2, :cond_2f

    iget-object p0, v0, Lads_mobile_sdk/kf;->b:Lads_mobile_sdk/bg;

    iget-object v0, v0, Lads_mobile_sdk/kf;->a:Lads_mobile_sdk/bg;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    move-object v4, p1

    move-object p1, p0

    move-object p0, v0

    move-object v0, v4

    goto :goto_4c

    :cond_2f
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0

    :cond_36
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iput-object p0, v0, Lads_mobile_sdk/kf;->a:Lads_mobile_sdk/bg;

    iput-object p0, v0, Lads_mobile_sdk/kf;->b:Lads_mobile_sdk/bg;

    iput v2, v0, Lads_mobile_sdk/kf;->e:I

    iget-object p1, p0, Lads_mobile_sdk/bg;->h:Lads_mobile_sdk/we;

    invoke-virtual {p1, v0}, Lads_mobile_sdk/we;->a(Lwx;)Ljava/lang/Object;

    move-result-object p1

    sget-object v0, Lwy;->a:Lwy;

    if-ne p1, v0, :cond_4a

    return-object v0

    :cond_4a
    move-object v0, p1

    move-object p1, p0

    :goto_4c
    check-cast v0, Lads_mobile_sdk/tv0;

    iput-object v0, p1, Lads_mobile_sdk/bg;->s:Lads_mobile_sdk/tv0;

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lads_mobile_sdk/bg;->t:Ljava/lang/String;

    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method

.method public final r(Lwx;)Ljava/lang/Object;
    .registers 8

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/lf;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/lf;

    iget v1, v0, Lads_mobile_sdk/lf;->f:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/lf;->f:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/lf;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/lf;-><init>(Lads_mobile_sdk/bg;Lwx;)V

    :goto_18
    iget-object p1, v0, Lads_mobile_sdk/lf;->d:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/lf;->f:I

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v1, :cond_34

    if-ne v1, v2, :cond_2e

    iget-wide v4, v0, Lads_mobile_sdk/lf;->c:J

    iget-object p0, v0, Lads_mobile_sdk/lf;->b:Lnb1;

    iget-object v0, v0, Lads_mobile_sdk/lf;->a:Lads_mobile_sdk/bg;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    move-object p1, p0

    move-object p0, v0

    goto :goto_5b

    :cond_2e
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v3

    :cond_34
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    sget-object p1, Lv60;->b:Lp80;

    iget-object p1, p0, Lads_mobile_sdk/bg;->f:Lx43;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    sget-object p1, Ly60;->d:Ly60;

    invoke-static {v4, v5, p1}, Li10;->H0(JLy60;)J

    move-result-wide v4

    iput-object p0, v0, Lads_mobile_sdk/lf;->a:Lads_mobile_sdk/bg;

    iget-object p1, p0, Lads_mobile_sdk/bg;->u:Lnb1;

    iput-object p1, v0, Lads_mobile_sdk/lf;->b:Lnb1;

    iput-wide v4, v0, Lads_mobile_sdk/lf;->c:J

    iput v2, v0, Lads_mobile_sdk/lf;->f:I

    invoke-virtual {p1, v0}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v0

    sget-object v1, Lwy;->a:Lwy;

    if-ne v0, v1, :cond_5b

    return-object v1

    :cond_5b
    :goto_5b
    :try_start_5b
    iget-wide v0, p0, Lads_mobile_sdk/bg;->v:J
    :try_end_5d
    .catchall {:try_start_5b .. :try_end_5d} :catchall_99

    invoke-virtual {p1, v3}, Lnb1;->b(Ljava/lang/Object;)V

    invoke-static {v4, v5, v0, v1}, Lv60;->h(JJ)J

    move-result-wide v0

    iget-object p1, p0, Lads_mobile_sdk/bg;->q:Lads_mobile_sdk/jf;

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    if-eqz p1, :cond_7f

    if-eq p1, v2, :cond_78

    const/4 v0, 0x2

    if-ne p1, v0, :cond_74

    iget-wide p0, p0, Lads_mobile_sdk/bg;->m:J

    goto :goto_85

    :cond_74
    invoke-static {}, Ldm2;->q()V

    return-object v3

    :cond_78
    iget-wide p0, p0, Lads_mobile_sdk/bg;->l:J

    invoke-static {p0, p1, v0, v1}, Lv60;->h(JJ)J

    move-result-wide p0

    goto :goto_85

    :cond_7f
    iget-wide p0, p0, Lads_mobile_sdk/bg;->k:J

    invoke-static {p0, p1, v0, v1}, Lv60;->h(JJ)J

    move-result-wide p0

    :goto_85
    new-instance v0, Lv60;

    const-wide/16 v1, 0x0

    invoke-direct {v0, v1, v2}, Lv60;-><init>(J)V

    new-instance v1, Lv60;

    invoke-direct {v1, p0, p1}, Lv60;-><init>(J)V

    invoke-virtual {v0, v1}, Lv60;->compareTo(Ljava/lang/Object;)I

    move-result p0

    if-ltz p0, :cond_98

    return-object v0

    :cond_98
    return-object v1

    :catchall_99
    move-exception p0

    invoke-virtual {p1, v3}, Lnb1;->b(Ljava/lang/Object;)V

    throw p0
.end method

.method public final s(Lwx;)Ljava/lang/Object;
    .registers 18

    .prologue
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    sget-object v2, Lads_mobile_sdk/jf;->c:Lads_mobile_sdk/jf;

    sget-object v3, Lads_mobile_sdk/jf;->b:Lads_mobile_sdk/jf;

    sget-object v4, Lrg2;->a:Lrg2;

    instance-of v5, v1, Lads_mobile_sdk/qf;

    if-eqz v5, :cond_1d

    move-object v5, v1

    check-cast v5, Lads_mobile_sdk/qf;

    iget v6, v5, Lads_mobile_sdk/qf;->g:I

    const/high16 v7, -0x80000000

    and-int v8, v6, v7

    if-eqz v8, :cond_1d

    sub-int/2addr v6, v7

    iput v6, v5, Lads_mobile_sdk/qf;->g:I

    goto :goto_22

    :cond_1d
    new-instance v5, Lads_mobile_sdk/qf;

    invoke-direct {v5, v0, v1}, Lads_mobile_sdk/qf;-><init>(Lads_mobile_sdk/bg;Lwx;)V

    :goto_22
    iget-object v1, v5, Lads_mobile_sdk/qf;->e:Ljava/lang/Object;

    sget-object v6, Lwy;->a:Lwy;

    iget v7, v5, Lads_mobile_sdk/qf;->g:I

    const/4 v8, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x4

    const/4 v13, 0x0

    if-eqz v7, :cond_8d

    if-eq v7, v11, :cond_79

    if-eq v7, v10, :cond_75

    if-eq v7, v9, :cond_64

    if-eq v7, v12, :cond_52

    if-ne v7, v8, :cond_4c

    iget-object v0, v5, Lads_mobile_sdk/qf;->b:Ljava/lang/Object;

    move-object v2, v0

    check-cast v2, Ljava/io/Closeable;

    iget-object v0, v5, Lads_mobile_sdk/qf;->a:Ljava/lang/Object;

    move-object v3, v0

    check-cast v3, Lads_mobile_sdk/rg3;

    :try_start_44
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_47
    .catchall {:try_start_44 .. :try_end_47} :catchall_49

    goto/16 :goto_1c8

    :catchall_49
    move-exception v0

    goto/16 :goto_1cf

    :cond_4c
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {v0}, Lz6;->w(Ljava/lang/String;)V

    return-object v13

    :cond_52
    iget-object v0, v5, Lads_mobile_sdk/qf;->b:Ljava/lang/Object;

    move-object v2, v0

    check-cast v2, Ljava/io/Closeable;

    iget-object v0, v5, Lads_mobile_sdk/qf;->a:Ljava/lang/Object;

    move-object v3, v0

    check-cast v3, Lads_mobile_sdk/rg3;

    :try_start_5c
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_5f
    .catchall {:try_start_5c .. :try_end_5f} :catchall_61

    goto/16 :goto_174

    :catchall_61
    move-exception v0

    goto/16 :goto_17b

    :cond_64
    iget-object v0, v5, Lads_mobile_sdk/qf;->c:Ljava/lang/Object;

    check-cast v0, Lads_mobile_sdk/tv0;

    iget-object v2, v5, Lads_mobile_sdk/qf;->b:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    iget-object v3, v5, Lads_mobile_sdk/qf;->a:Ljava/lang/Object;

    check-cast v3, Lads_mobile_sdk/bg;

    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V

    goto/16 :goto_138

    :cond_75
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V

    return-object v4

    :cond_79
    iget-wide v14, v5, Lads_mobile_sdk/qf;->d:J

    iget-object v0, v5, Lads_mobile_sdk/qf;->c:Ljava/lang/Object;

    check-cast v0, Llb1;

    iget-object v7, v5, Lads_mobile_sdk/qf;->b:Ljava/lang/Object;

    check-cast v7, Lads_mobile_sdk/jf;

    iget-object v8, v5, Lads_mobile_sdk/qf;->a:Ljava/lang/Object;

    check-cast v8, Lads_mobile_sdk/bg;

    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V

    move-object v1, v0

    move-object v0, v8

    goto :goto_b7

    :cond_8d
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object v7, v0, Lads_mobile_sdk/bg;->q:Lads_mobile_sdk/jf;

    sget-object v1, Lv60;->b:Lp80;

    iget-object v1, v0, Lads_mobile_sdk/bg;->f:Lx43;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v14

    sget-object v1, Ly60;->d:Ly60;

    invoke-static {v14, v15, v1}, Li10;->H0(JLy60;)J

    move-result-wide v14

    iget-object v1, v0, Lads_mobile_sdk/bg;->u:Lnb1;

    iput-object v0, v5, Lads_mobile_sdk/qf;->a:Ljava/lang/Object;

    iput-object v7, v5, Lads_mobile_sdk/qf;->b:Ljava/lang/Object;

    iput-object v1, v5, Lads_mobile_sdk/qf;->c:Ljava/lang/Object;

    iput-wide v14, v5, Lads_mobile_sdk/qf;->d:J

    iput v11, v5, Lads_mobile_sdk/qf;->g:I

    invoke-virtual {v1, v5}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v8

    if-ne v8, v6, :cond_b7

    goto/16 :goto_1c6

    :cond_b7
    :goto_b7
    :try_start_b7
    iget-wide v11, v0, Lads_mobile_sdk/bg;->v:J
    :try_end_b9
    .catchall {:try_start_b7 .. :try_end_b9} :catchall_21c

    invoke-interface {v1, v13}, Llb1;->b(Ljava/lang/Object;)V

    invoke-static {v14, v15, v11, v12}, Lv60;->h(JJ)J

    move-result-wide v11

    sget-object v1, Lads_mobile_sdk/jf;->a:Lads_mobile_sdk/jf;

    if-ne v7, v1, :cond_e3

    iget-wide v14, v0, Lads_mobile_sdk/bg;->k:J

    invoke-static {v11, v12, v14, v15}, Lv60;->c(JJ)I

    move-result v14

    if-lez v14, :cond_e3

    const-string v1, "Early ANR detected"

    invoke-static {v1}, Llk;->d(Ljava/lang/String;)V

    iput-object v3, v0, Lads_mobile_sdk/bg;->q:Lads_mobile_sdk/jf;

    iput-object v13, v5, Lads_mobile_sdk/qf;->a:Ljava/lang/Object;

    iput-object v13, v5, Lads_mobile_sdk/qf;->b:Ljava/lang/Object;

    iput-object v13, v5, Lads_mobile_sdk/qf;->c:Ljava/lang/Object;

    iput v10, v5, Lads_mobile_sdk/qf;->g:I

    invoke-virtual {v0, v5}, Lads_mobile_sdk/bg;->k(Lvx;)Ljava/lang/Object;

    move-result-object v0

    if-ne v0, v6, :cond_21b

    goto/16 :goto_1c6

    :cond_e3
    if-ne v7, v3, :cond_f9

    iget-wide v14, v0, Lads_mobile_sdk/bg;->k:J

    invoke-static {v11, v12, v14, v15}, Lv60;->c(JJ)I

    move-result v10

    if-gtz v10, :cond_f9

    const-string v2, "Recover ANR"

    invoke-static {v2}, Llk;->d(Ljava/lang/String;)V

    iput-object v1, v0, Lads_mobile_sdk/bg;->q:Lads_mobile_sdk/jf;

    iput-object v13, v0, Lads_mobile_sdk/bg;->s:Lads_mobile_sdk/tv0;

    iput-object v13, v0, Lads_mobile_sdk/bg;->t:Ljava/lang/String;

    return-object v4

    :cond_f9
    if-ne v7, v3, :cond_206

    iget-wide v14, v0, Lads_mobile_sdk/bg;->l:J

    invoke-static {v11, v12, v14, v15}, Lv60;->c(JJ)I

    move-result v3

    if-lez v3, :cond_206

    const-string v1, "Full ANR detected"

    invoke-static {v1}, Llk;->d(Ljava/lang/String;)V

    iput-object v2, v0, Lads_mobile_sdk/bg;->q:Lads_mobile_sdk/jf;

    iget-object v2, v0, Lads_mobile_sdk/bg;->t:Ljava/lang/String;

    iget-object v1, v0, Lads_mobile_sdk/bg;->s:Lads_mobile_sdk/tv0;

    if-eqz v2, :cond_21b

    if-eqz v1, :cond_21b

    iget-object v3, v0, Lads_mobile_sdk/bg;->i:Lads_mobile_sdk/ef;

    iput-object v0, v5, Lads_mobile_sdk/qf;->a:Ljava/lang/Object;

    iput-object v2, v5, Lads_mobile_sdk/qf;->b:Ljava/lang/Object;

    iput-object v1, v5, Lads_mobile_sdk/qf;->c:Ljava/lang/Object;

    iput v9, v5, Lads_mobile_sdk/qf;->g:I

    iget-object v3, v3, Lads_mobile_sdk/ef;->a:Lv03;

    invoke-interface {v3}, Lv03;->get()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lc42;

    new-instance v7, Lhn1;

    const/4 v8, 0x1

    invoke-direct {v7, v2, v1, v13, v8}, Lhn1;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lvx;I)V

    invoke-virtual {v3, v7, v5}, Lc42;->i(Lpk0;Lwx;)Ljava/lang/Object;

    move-result-object v3

    if-ne v3, v6, :cond_131

    goto :goto_132

    :cond_131
    move-object v3, v4

    :goto_132
    if-ne v3, v6, :cond_136

    goto/16 :goto_1c6

    :cond_136
    move-object v3, v0

    move-object v0, v1

    :goto_138
    iget-object v1, v3, Lads_mobile_sdk/bg;->j:Lads_mobile_sdk/ux2;

    sget-object v7, Lads_mobile_sdk/fw0;->z1:Lads_mobile_sdk/fw0;

    sget-object v9, Lba0;->a:Lba0;

    new-instance v10, Lads_mobile_sdk/kh3;

    new-instance v11, Lads_mobile_sdk/eq2;

    invoke-direct {v11}, Lads_mobile_sdk/eq2;-><init>()V

    new-instance v12, Lads_mobile_sdk/ih1;

    invoke-direct {v12}, Lads_mobile_sdk/ih1;-><init>()V

    new-instance v14, Lads_mobile_sdk/dt2;

    invoke-direct {v14}, Lads_mobile_sdk/dt2;-><init>()V

    new-instance v15, Lads_mobile_sdk/s8;

    invoke-direct {v15}, Lads_mobile_sdk/s8;-><init>()V

    invoke-direct {v10, v11, v12, v14, v15}, Lads_mobile_sdk/kh3;-><init>(Lads_mobile_sdk/eq2;Lads_mobile_sdk/ih1;Lads_mobile_sdk/dt2;Lads_mobile_sdk/s8;)V

    invoke-static {}, Lads_mobile_sdk/hh3;->b()Lads_mobile_sdk/gh3;

    move-result-object v11

    iget-object v11, v11, Lads_mobile_sdk/gh3;->a:Lads_mobile_sdk/rg3;

    if-nez v11, :cond_1b2

    invoke-static {v1, v7, v9, v10}, Lads_mobile_sdk/ux2;->a(Lads_mobile_sdk/ux2;Lads_mobile_sdk/fw0;Ljava/util/List;Lads_mobile_sdk/kh3;)Lads_mobile_sdk/wk2;

    move-result-object v1

    :try_start_163
    iput-object v1, v5, Lads_mobile_sdk/qf;->a:Ljava/lang/Object;

    iput-object v1, v5, Lads_mobile_sdk/qf;->b:Ljava/lang/Object;

    iput-object v13, v5, Lads_mobile_sdk/qf;->c:Ljava/lang/Object;

    const/4 v7, 0x4

    iput v7, v5, Lads_mobile_sdk/qf;->g:I

    invoke-virtual {v3, v2, v0, v5}, Lads_mobile_sdk/bg;->a(Ljava/lang/String;Lads_mobile_sdk/tv0;Lwx;)Ljava/lang/Object;

    move-result-object v0
    :try_end_170
    .catchall {:try_start_163 .. :try_end_170} :catchall_178

    if-ne v0, v6, :cond_173

    goto :goto_1c6

    :cond_173
    move-object v2, v1

    :goto_174
    invoke-static {v2, v13}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object v4

    :catchall_178
    move-exception v0

    move-object v2, v1

    move-object v3, v2

    :goto_17b
    :try_start_17b
    invoke-virtual {v3, v0}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v1, v0, Lox2;

    if-nez v1, :cond_1ab

    invoke-virtual {v3, v0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of v1, v0, Lza2;

    if-nez v1, :cond_1a3

    instance-of v1, v0, Ljava/util/concurrent/CancellationException;

    if-nez v1, :cond_19b

    instance-of v1, v0, Lads_mobile_sdk/mv0;

    if-eqz v1, :cond_195

    throw v0

    :catchall_192
    move-exception v0

    move-object v1, v0

    goto :goto_1ac

    :cond_195
    new-instance v1, Lads_mobile_sdk/tu0;

    invoke-direct {v1, v0}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw v1

    :cond_19b
    new-instance v1, Lads_mobile_sdk/ou0;

    check-cast v0, Ljava/util/concurrent/CancellationException;

    invoke-direct {v1, v0}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw v1

    :cond_1a3
    new-instance v1, Lads_mobile_sdk/uw0;

    check-cast v0, Lza2;

    invoke-direct {v1, v0}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw v1

    :cond_1ab
    throw v0
    :try_end_1ac
    .catchall {:try_start_17b .. :try_end_1ac} :catchall_192

    :goto_1ac
    :try_start_1ac
    throw v1
    :try_end_1ad
    .catchall {:try_start_1ac .. :try_end_1ad} :catchall_1ad

    :catchall_1ad
    move-exception v0

    invoke-static {v2, v1}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0

    :cond_1b2
    const/4 v8, 0x1

    invoke-static {v7, v9, v8}, Lads_mobile_sdk/hh3;->a(Lads_mobile_sdk/fw0;Ljava/util/List;Z)Lads_mobile_sdk/rg3;

    move-result-object v1

    :try_start_1b7
    iput-object v1, v5, Lads_mobile_sdk/qf;->a:Ljava/lang/Object;

    iput-object v1, v5, Lads_mobile_sdk/qf;->b:Ljava/lang/Object;

    iput-object v13, v5, Lads_mobile_sdk/qf;->c:Ljava/lang/Object;

    const/4 v7, 0x5

    iput v7, v5, Lads_mobile_sdk/qf;->g:I

    invoke-virtual {v3, v2, v0, v5}, Lads_mobile_sdk/bg;->a(Ljava/lang/String;Lads_mobile_sdk/tv0;Lwx;)Ljava/lang/Object;

    move-result-object v0
    :try_end_1c4
    .catchall {:try_start_1b7 .. :try_end_1c4} :catchall_1cc

    if-ne v0, v6, :cond_1c7

    :goto_1c6
    return-object v6

    :cond_1c7
    move-object v2, v1

    :goto_1c8
    invoke-static {v2, v13}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object v4

    :catchall_1cc
    move-exception v0

    move-object v2, v1

    move-object v3, v2

    :goto_1cf
    :try_start_1cf
    invoke-virtual {v3, v0}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v1, v0, Lox2;

    if-nez v1, :cond_1ff

    invoke-virtual {v3, v0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of v1, v0, Lza2;

    if-nez v1, :cond_1f7

    instance-of v1, v0, Ljava/util/concurrent/CancellationException;

    if-nez v1, :cond_1ef

    instance-of v1, v0, Lads_mobile_sdk/mv0;

    if-eqz v1, :cond_1e9

    throw v0

    :catchall_1e6
    move-exception v0

    move-object v1, v0

    goto :goto_200

    :cond_1e9
    new-instance v1, Lads_mobile_sdk/tu0;

    invoke-direct {v1, v0}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw v1

    :cond_1ef
    new-instance v1, Lads_mobile_sdk/ou0;

    check-cast v0, Ljava/util/concurrent/CancellationException;

    invoke-direct {v1, v0}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw v1

    :cond_1f7
    new-instance v1, Lads_mobile_sdk/uw0;

    check-cast v0, Lza2;

    invoke-direct {v1, v0}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw v1

    :cond_1ff
    throw v0
    :try_end_200
    .catchall {:try_start_1cf .. :try_end_200} :catchall_1e6

    :goto_200
    :try_start_200
    throw v1
    :try_end_201
    .catchall {:try_start_200 .. :try_end_201} :catchall_201

    :catchall_201
    move-exception v0

    invoke-static {v2, v1}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0

    :cond_206
    if-ne v7, v2, :cond_21b

    iget-wide v2, v0, Lads_mobile_sdk/bg;->l:J

    invoke-static {v11, v12, v2, v3}, Lv60;->c(JJ)I

    move-result v2

    if-gtz v2, :cond_21b

    const-string v2, "Cooldown ANR"

    invoke-static {v2}, Llk;->d(Ljava/lang/String;)V

    iput-object v1, v0, Lads_mobile_sdk/bg;->q:Lads_mobile_sdk/jf;

    iput-object v13, v0, Lads_mobile_sdk/bg;->s:Lads_mobile_sdk/tv0;

    iput-object v13, v0, Lads_mobile_sdk/bg;->t:Ljava/lang/String;

    :cond_21b
    return-object v4

    :catchall_21c
    move-exception v0

    invoke-interface {v1, v13}, Llb1;->b(Ljava/lang/Object;)V

    throw v0
.end method
