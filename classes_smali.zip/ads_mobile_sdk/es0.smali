.class public final Lads_mobile_sdk/es0;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Lws2;

.field public final b:Ljava/lang/String;

.field public final c:Lads_mobile_sdk/fs0;


# direct methods
.method public constructor <init>(Landroid/view/View;Lads_mobile_sdk/fs0;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lws2;

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, p0, Lads_mobile_sdk/es0;->a:Lws2;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lads_mobile_sdk/es0;->b:Ljava/lang/String;

    iput-object p2, p0, Lads_mobile_sdk/es0;->c:Lads_mobile_sdk/fs0;

    return-void
.end method
