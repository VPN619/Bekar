.class public final Lads_mobile_sdk/f52;
.super Lwx;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public a:Lads_mobile_sdk/s52;

.field public b:Lads_mobile_sdk/cy0;

.field public c:Ljava/lang/String;

.field public d:Ljava/lang/String;

.field public e:Lads_mobile_sdk/t00;

.field public f:Lads_mobile_sdk/z31;

.field public g:Lads_mobile_sdk/z92;

.field public h:Lads_mobile_sdk/z92;

.field public synthetic i:Ljava/lang/Object;

.field public final synthetic j:Lads_mobile_sdk/s52;

.field public k:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/s52;Lwx;)V
    .registers 3

    iput-object p1, p0, Lads_mobile_sdk/f52;->j:Lads_mobile_sdk/s52;

    invoke-direct {p0, p2}, Lwx;-><init>(Lvx;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 11

    iput-object p1, p0, Lads_mobile_sdk/f52;->i:Ljava/lang/Object;

    iget p1, p0, Lads_mobile_sdk/f52;->k:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, Lads_mobile_sdk/f52;->k:I

    const/4 v6, 0x0

    const/4 v7, 0x0

    iget-object v0, p0, Lads_mobile_sdk/f52;->j:Lads_mobile_sdk/s52;

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    move-object v8, p0

    invoke-static/range {v0 .. v8}, Lads_mobile_sdk/s52;->a(Lads_mobile_sdk/s52;Lads_mobile_sdk/cy0;Ljava/lang/String;Ljava/lang/String;Lads_mobile_sdk/t00;Lads_mobile_sdk/z31;Lads_mobile_sdk/z92;Lads_mobile_sdk/z92;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
