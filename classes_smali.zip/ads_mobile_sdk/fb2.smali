.class public final Lads_mobile_sdk/fb2;
.super Lads_mobile_sdk/ku0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field private static final DEFAULT_INSTANCE:Lads_mobile_sdk/fb2;

.field public static final c:I = 0x9

.field public static final d:I = 0x1

.field public static final e:I = 0xb

.field public static final f:I = 0xc

.field public static final g:I = 0x2

.field public static final h:I = 0x3

.field public static final i:I = 0x4

.field private static final includeDefaultEntry_2_:Lads_mobile_sdk/dn1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lads_mobile_sdk/dn1;"
        }
    .end annotation
.end field

.field public static final j:I = 0xd

.field public static final k:I = 0x5

.field public static final l:I = 0x6

.field public static final m:I = 0x7

.field public static final n:I = 0x8

.field public static final o:I = 0xa

.field public static final p:I = 0xe


# instance fields
.field private allowCompression_:Z

.field private allowCookies_:Z

.field private allowedKeys_:Lw63;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lw63;"
        }
    .end annotation
.end field

.field private andRules_:Lw63;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lw63;"
        }
    .end annotation
.end field

.field private baseUrl_:Ljava/lang/String;

.field private bitField0_:I

.field private blobUrlKeys_:Lw63;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lw63;"
        }
    .end annotation
.end field

.field private consoleLogs_:Lw63;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lw63;"
        }
    .end annotation
.end field

.field private elseRules_:Lw63;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lw63;"
        }
    .end annotation
.end field

.field private errorCode_:I

.field private errorString_:Ljava/lang/String;

.field private includeSignals_:Lw63;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lw63;"
        }
    .end annotation
.end field

.field private include_:Lads_mobile_sdk/gn1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lads_mobile_sdk/gn1;"
        }
    .end annotation
.end field

.field private pattern_:Lads_mobile_sdk/vm1;

.field private ruleLabel_:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    sget-object v0, Lads_mobile_sdk/cs3;->d:Ln73;

    new-instance v1, Lads_mobile_sdk/dn1;

    const-string v2, ""

    invoke-direct {v1, v0, v0, v2}, Lads_mobile_sdk/dn1;-><init>(Ln73;Lads_mobile_sdk/cs3;Ljava/lang/Object;)V

    sput-object v1, Lads_mobile_sdk/fb2;->includeDefaultEntry_2_:Lads_mobile_sdk/dn1;

    new-instance v0, Lads_mobile_sdk/fb2;

    invoke-direct {v0}, Lads_mobile_sdk/fb2;-><init>()V

    sput-object v0, Lads_mobile_sdk/fb2;->DEFAULT_INSTANCE:Lads_mobile_sdk/fb2;

    const-class v1, Lads_mobile_sdk/fb2;

    invoke-static {v1, v0}, Lads_mobile_sdk/ku0;->a(Ljava/lang/Class;Lads_mobile_sdk/ku0;)V

    return-void
.end method

.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Lads_mobile_sdk/ku0;-><init>()V

    sget-object v0, Lads_mobile_sdk/gn1;->b:Lads_mobile_sdk/gn1;

    iput-object v0, p0, Lads_mobile_sdk/fb2;->include_:Lads_mobile_sdk/gn1;

    const-string v0, ""

    iput-object v0, p0, Lads_mobile_sdk/fb2;->ruleLabel_:Ljava/lang/String;

    sget-object v1, Lads_mobile_sdk/am2;->e:Lads_mobile_sdk/am2;

    iput-object v1, p0, Lads_mobile_sdk/fb2;->andRules_:Lw63;

    iput-object v1, p0, Lads_mobile_sdk/fb2;->elseRules_:Lw63;

    iput-object v1, p0, Lads_mobile_sdk/fb2;->includeSignals_:Lw63;

    iput-object v1, p0, Lads_mobile_sdk/fb2;->blobUrlKeys_:Lw63;

    iput-object v1, p0, Lads_mobile_sdk/fb2;->allowedKeys_:Lw63;

    iput-object v1, p0, Lads_mobile_sdk/fb2;->consoleLogs_:Lw63;

    iput-object v0, p0, Lads_mobile_sdk/fb2;->errorString_:Ljava/lang/String;

    iput-object v0, p0, Lads_mobile_sdk/fb2;->baseUrl_:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final A()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/fb2;->ruleLabel_:Ljava/lang/String;

    return-object p0
.end method

.method public final B()Z
    .registers 1

    .prologue
    iget p0, p0, Lads_mobile_sdk/fb2;->bitField0_:I

    and-int/lit8 p0, p0, 0x20

    if-eqz p0, :cond_8

    const/4 p0, 0x1

    return p0

    :cond_8
    const/4 p0, 0x0

    return p0
.end method

.method public final C()Z
    .registers 1

    .prologue
    iget p0, p0, Lads_mobile_sdk/fb2;->bitField0_:I

    and-int/lit8 p0, p0, 0x10

    if-eqz p0, :cond_8

    const/4 p0, 0x1

    return p0

    :cond_8
    const/4 p0, 0x0

    return p0
.end method

.method public final D()Z
    .registers 1

    .prologue
    iget p0, p0, Lads_mobile_sdk/fb2;->bitField0_:I

    and-int/lit8 p0, p0, 0x8

    if-eqz p0, :cond_8

    const/4 p0, 0x1

    return p0

    :cond_8
    const/4 p0, 0x0

    return p0
.end method

.method public final E()Z
    .registers 1

    .prologue
    iget p0, p0, Lads_mobile_sdk/fb2;->bitField0_:I

    and-int/lit8 p0, p0, 0x4

    if-eqz p0, :cond_8

    const/4 p0, 0x1

    return p0

    :cond_8
    const/4 p0, 0x0

    return p0
.end method

.method public final F()Z
    .registers 1

    .prologue
    iget p0, p0, Lads_mobile_sdk/fb2;->bitField0_:I

    and-int/lit8 p0, p0, 0x2

    if-eqz p0, :cond_8

    const/4 p0, 0x1

    return p0

    :cond_8
    const/4 p0, 0x0

    return p0
.end method

.method public final a(ILads_mobile_sdk/ku0;)Ljava/lang/Object;
    .registers 23

    .prologue
    invoke-static/range {p1 .. p1}, Lvr0;->a(I)I

    move-result v0

    if-eqz v0, :cond_63

    const/4 v1, 0x2

    if-eq v0, v1, :cond_2f

    const/4 v1, 0x3

    if-eq v0, v1, :cond_29

    const/4 v1, 0x4

    if-eq v0, v1, :cond_21

    const/4 v1, 0x5

    if-eq v0, v1, :cond_1e

    const/4 v1, 0x6

    if-ne v0, v1, :cond_1c

    const-class v0, Lads_mobile_sdk/fb2;

    invoke-static {v0}, Lads_mobile_sdk/ku0;->b(Ljava/lang/Class;)Lads_mobile_sdk/ju0;

    move-result-object v0

    return-object v0

    :cond_1c
    const/4 v0, 0x0

    throw v0

    :cond_1e
    sget-object v0, Lads_mobile_sdk/fb2;->DEFAULT_INSTANCE:Lads_mobile_sdk/fb2;

    return-object v0

    :cond_21
    new-instance v0, Lbt2;

    sget-object v1, Lads_mobile_sdk/fb2;->DEFAULT_INSTANCE:Lads_mobile_sdk/fb2;

    invoke-direct {v0, v1}, Lads_mobile_sdk/iu0;-><init>(Lads_mobile_sdk/ku0;)V

    return-object v0

    :cond_29
    new-instance v0, Lads_mobile_sdk/fb2;

    invoke-direct {v0}, Lads_mobile_sdk/fb2;-><init>()V

    return-object v0

    :cond_2f
    sget-object v4, Lads_mobile_sdk/fb2;->includeDefaultEntry_2_:Lads_mobile_sdk/dn1;

    const-string v18, "allowedKeys_"

    const-string v19, "allowCompression_"

    const-string v1, "bitField0_"

    const-string v2, "pattern_"

    const-string v3, "include_"

    const-string v5, "includeSignals_"

    const-class v6, Lads_mobile_sdk/h41;

    const-string v7, "blobUrlKeys_"

    const-string v8, "consoleLogs_"

    const-string v9, "errorString_"

    const-string v10, "errorCode_"

    const-string v11, "baseUrl_"

    const-string v12, "ruleLabel_"

    const-string v13, "allowCookies_"

    const-string v14, "andRules_"

    const-class v15, Lads_mobile_sdk/fb2;

    const-string v16, "elseRules_"

    move-object/from16 v17, v15

    filled-new-array/range {v1 .. v19}, [Ljava/lang/Object;

    move-result-object v0

    sget-object v1, Lads_mobile_sdk/fb2;->DEFAULT_INSTANCE:Lads_mobile_sdk/fb2;

    new-instance v2, Lads_mobile_sdk/zq2;

    const-string v3, "\u0004\u000e\u0000\u0001\u0001\u000e\u000e\u0001\u0006\u0000\u0001ဉ\u0001\u00022\u0003\u001b\u0004Ț\u0005Ț\u0006ለ\u0002\u0007င\u0003\bለ\u0004\tለ\u0000\nဇ\u0005\u000b\u001b\f\u001b\rȚ\u000eဇ\u0006"

    invoke-direct {v2, v1, v3, v0}, Lads_mobile_sdk/zq2;-><init>(Lads_mobile_sdk/ku0;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object v2

    :cond_63
    const/4 v0, 0x1

    invoke-static {v0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v0

    return-object v0
.end method

.method public final o()Z
    .registers 1

    iget-boolean p0, p0, Lads_mobile_sdk/fb2;->allowCookies_:Z

    return p0
.end method

.method public final p()Lw63;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/fb2;->allowedKeys_:Lw63;

    return-object p0
.end method

.method public final q()Lw63;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/fb2;->andRules_:Lw63;

    return-object p0
.end method

.method public final r()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/fb2;->baseUrl_:Ljava/lang/String;

    return-object p0
.end method

.method public final s()Lw63;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/fb2;->blobUrlKeys_:Lw63;

    return-object p0
.end method

.method public final t()Lw63;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/fb2;->consoleLogs_:Lw63;

    return-object p0
.end method

.method public final u()Lw63;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/fb2;->elseRules_:Lw63;

    return-object p0
.end method

.method public final v()I
    .registers 1

    iget p0, p0, Lads_mobile_sdk/fb2;->errorCode_:I

    return p0
.end method

.method public final w()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/fb2;->errorString_:Ljava/lang/String;

    return-object p0
.end method

.method public final x()Ljava/util/Map;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/fb2;->include_:Lads_mobile_sdk/gn1;

    invoke-static {p0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object p0

    return-object p0
.end method

.method public final y()Lw63;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/fb2;->includeSignals_:Lw63;

    return-object p0
.end method

.method public final z()Lads_mobile_sdk/vm1;
    .registers 1

    .prologue
    iget-object p0, p0, Lads_mobile_sdk/fb2;->pattern_:Lads_mobile_sdk/vm1;

    if-nez p0, :cond_8

    invoke-static {}, Lads_mobile_sdk/vm1;->p()Lads_mobile_sdk/vm1;

    move-result-object p0

    :cond_8
    return-object p0
.end method
