.class public final Lads_mobile_sdk/e30;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lbk0;


# instance fields
.field public a:I

.field public final synthetic b:Z

.field public final synthetic c:Lads_mobile_sdk/p30;

.field public final synthetic d:Ljava/lang/Long;

.field public final synthetic e:Ljava/util/concurrent/atomic/AtomicReference;

.field public final synthetic f:Lhv0;


# direct methods
.method public constructor <init>(ZLads_mobile_sdk/p30;Ljava/lang/Long;Ljava/util/concurrent/atomic/AtomicReference;Lhv0;Lvx;)V
    .registers 7

    iput-boolean p1, p0, Lads_mobile_sdk/e30;->b:Z

    iput-object p2, p0, Lads_mobile_sdk/e30;->c:Lads_mobile_sdk/p30;

    iput-object p3, p0, Lads_mobile_sdk/e30;->d:Ljava/lang/Long;

    iput-object p4, p0, Lads_mobile_sdk/e30;->e:Ljava/util/concurrent/atomic/AtomicReference;

    iput-object p5, p0, Lads_mobile_sdk/e30;->f:Lhv0;

    const/4 p1, 0x1

    invoke-direct {p0, p1, p6}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 9

    move-object v6, p1

    check-cast v6, Lvx;

    new-instance v0, Lads_mobile_sdk/e30;

    iget-object v4, p0, Lads_mobile_sdk/e30;->e:Ljava/util/concurrent/atomic/AtomicReference;

    iget-object v5, p0, Lads_mobile_sdk/e30;->f:Lhv0;

    iget-boolean v1, p0, Lads_mobile_sdk/e30;->b:Z

    iget-object v2, p0, Lads_mobile_sdk/e30;->c:Lads_mobile_sdk/p30;

    iget-object v3, p0, Lads_mobile_sdk/e30;->d:Ljava/lang/Long;

    invoke-direct/range {v0 .. v6}, Lads_mobile_sdk/e30;-><init>(ZLads_mobile_sdk/p30;Ljava/lang/Long;Ljava/util/concurrent/atomic/AtomicReference;Lhv0;Lvx;)V

    sget-object p0, Lrg2;->a:Lrg2;

    invoke-virtual {v0, p0}, Lads_mobile_sdk/e30;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 12

    .prologue
    const-string v0, "Cronet was unable to be initialized and the SDK will not be able to make network requests: "

    sget-object v1, Lwy;->a:Lwy;

    iget v2, p0, Lads_mobile_sdk/e30;->a:I

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v2, :cond_21

    if-eq v2, v4, :cond_1c

    if-ne v2, v3, :cond_16

    :try_start_f
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_12
    .catchall {:try_start_f .. :try_end_12} :catchall_13

    goto :goto_78

    :catchall_13
    move-exception p1

    goto/16 :goto_99

    :cond_16
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v5

    :cond_1c
    :try_start_1c
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_1f
    .catchall {:try_start_1c .. :try_end_1f} :catchall_60

    goto/16 :goto_ac

    :cond_21
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    :try_start_24
    iget-boolean p1, p0, Lads_mobile_sdk/e30;->b:Z

    if-nez p1, :cond_58

    iget-object p1, p0, Lads_mobile_sdk/e30;->c:Lads_mobile_sdk/p30;

    iget-object p1, p1, Lads_mobile_sdk/p30;->b:Lads_mobile_sdk/qr0;

    if-eqz p1, :cond_42

    const-string v2, "gads:cronet_init_timeout:seconds"

    sget-wide v6, Lads_mobile_sdk/qr0;->A:J

    new-instance v8, Lv60;

    invoke-direct {v8, v6, v7}, Lv60;-><init>(J)V

    sget-object v6, Lads_mobile_sdk/fo;->a$21:Lads_mobile_sdk/fo;

    invoke-virtual {p1, v2, v8, v6}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lv60;

    iget-wide v6, p1, Lv60;->a:J

    goto :goto_44

    :cond_42
    sget-wide v6, Lads_mobile_sdk/qr0;->A:J

    :goto_44
    new-instance p1, Lb10;

    iget-object v2, p0, Lads_mobile_sdk/e30;->c:Lads_mobile_sdk/p30;

    iget-object v8, p0, Lads_mobile_sdk/e30;->e:Ljava/util/concurrent/atomic/AtomicReference;

    iget-object v9, p0, Lads_mobile_sdk/e30;->d:Ljava/lang/Long;

    invoke-direct {p1, v2, v8, v9, v5}, Lb10;-><init>(Lads_mobile_sdk/p30;Ljava/util/concurrent/atomic/AtomicReference;Ljava/lang/Long;Lvx;)V

    iput v4, p0, Lads_mobile_sdk/e30;->a:I

    invoke-static {v6, v7, p1, p0}, Lla1;->W(JLpk0;Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v1, :cond_ac

    goto :goto_77

    :cond_58
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v2, "Cronet fallback provider forced to use."

    invoke-direct {p1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_60
    .catchall {:try_start_24 .. :try_end_60} :catchall_60

    :catchall_60
    :try_start_60
    iget-object p1, p0, Lads_mobile_sdk/e30;->c:Lads_mobile_sdk/p30;

    new-instance v2, Lorg/chromium/net/impl/JavaCronetProvider;

    iget-object v4, p1, Lads_mobile_sdk/p30;->d:Landroid/content/Context;

    invoke-direct {v2, v4}, Lorg/chromium/net/impl/JavaCronetProvider;-><init>(Landroid/content/Context;)V

    invoke-virtual {v2}, Lorg/chromium/net/impl/JavaCronetProvider;->createBuilder()Lorg/chromium/net/CronetEngine$Builder;

    move-result-object v2

    iget-object v4, p0, Lads_mobile_sdk/e30;->d:Ljava/lang/Long;

    iput v3, p0, Lads_mobile_sdk/e30;->a:I

    invoke-static {p1, v2, v4, p0}, Lads_mobile_sdk/p30;->a(Lads_mobile_sdk/p30;Lorg/chromium/net/CronetEngine$Builder;Ljava/lang/Long;Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v1, :cond_78

    :goto_77
    return-object v1

    :cond_78
    :goto_78
    check-cast p1, Lorg/chromium/net/CronetEngine$Builder;

    iget-object v1, p0, Lads_mobile_sdk/e30;->e:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {p1}, Lorg/chromium/net/CronetEngine$Builder;->build()Lorg/chromium/net/CronetEngine;

    move-result-object p1

    invoke-virtual {v1, p1}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    invoke-static {}, Lads_mobile_sdk/hh3;->b()Lads_mobile_sdk/gh3;

    move-result-object p1

    iget-object p1, p1, Lads_mobile_sdk/gh3;->a:Lads_mobile_sdk/rg3;

    if-eqz p1, :cond_90

    invoke-virtual {p1}, Lads_mobile_sdk/rg3;->e()Lads_mobile_sdk/ub2;

    move-result-object p1

    goto :goto_91

    :cond_90
    move-object p1, v5

    :goto_91
    if-nez p1, :cond_94

    goto :goto_ac

    :cond_94
    const-string v1, "Fallback-Cronet-Provider"

    iput-object v1, p1, Lads_mobile_sdk/ub2;->z:Ljava/lang/String;
    :try_end_98
    .catchall {:try_start_60 .. :try_end_98} :catchall_13

    goto :goto_ac

    :goto_99
    :try_start_99
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1, v5}, Lads_mobile_sdk/nw;->c(Ljava/lang/String;Ljava/lang/Exception;)V
    :try_end_ac
    .catchall {:try_start_99 .. :try_end_ac} :catchall_b4

    :cond_ac
    :goto_ac
    iget-object p0, p0, Lads_mobile_sdk/e30;->f:Lhv0;

    invoke-virtual {p0}, Lhv0;->a0()V

    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0

    :catchall_b4
    move-exception p1

    iget-object p0, p0, Lads_mobile_sdk/e30;->f:Lhv0;

    invoke-virtual {p0}, Lhv0;->a0()V

    throw p1
.end method
