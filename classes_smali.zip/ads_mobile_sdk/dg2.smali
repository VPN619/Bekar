.class public final Lads_mobile_sdk/dg2;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public synthetic a:Ljava/lang/Object;

.field public final synthetic b:Lads_mobile_sdk/jz2;

.field public final synthetic t:I


# direct methods
.method public synthetic constructor <init>(Lads_mobile_sdk/jz2;Lvx;I)V
    .registers 4

    iput p3, p0, Lads_mobile_sdk/dg2;->t:I

    iput-object p1, p0, Lads_mobile_sdk/dg2;->b:Lads_mobile_sdk/jz2;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 5

    .prologue
    iget v0, p0, Lads_mobile_sdk/dg2;->t:I

    iget-object p0, p0, Lads_mobile_sdk/dg2;->b:Lads_mobile_sdk/jz2;

    packed-switch v0, :pswitch_data_1a

    new-instance v0, Lads_mobile_sdk/dg2;

    const/4 v1, 0x1

    invoke-direct {v0, p0, p1, v1}, Lads_mobile_sdk/dg2;-><init>(Lads_mobile_sdk/jz2;Lvx;I)V

    iput-object p2, v0, Lads_mobile_sdk/dg2;->a:Ljava/lang/Object;

    return-object v0

    :pswitch_10  #0x0
    new-instance v0, Lads_mobile_sdk/dg2;

    const/4 v1, 0x0

    invoke-direct {v0, p0, p1, v1}, Lads_mobile_sdk/dg2;-><init>(Lads_mobile_sdk/jz2;Lvx;I)V

    iput-object p2, v0, Lads_mobile_sdk/dg2;->a:Ljava/lang/Object;

    return-object v0

    nop

    :pswitch_data_1a
    .packed-switch 0x0
        :pswitch_10  #00000000
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .prologue
    iget v0, p0, Lads_mobile_sdk/dg2;->t:I

    sget-object v1, Lrg2;->a:Lrg2;

    iget-object p0, p0, Lads_mobile_sdk/dg2;->b:Lads_mobile_sdk/jz2;

    packed-switch v0, :pswitch_data_2a

    check-cast p1, Lads_mobile_sdk/cy0;

    check-cast p2, Lvx;

    new-instance v0, Lads_mobile_sdk/dg2;

    const/4 v2, 0x1

    invoke-direct {v0, p0, p2, v2}, Lads_mobile_sdk/dg2;-><init>(Lads_mobile_sdk/jz2;Lvx;I)V

    iput-object p1, v0, Lads_mobile_sdk/dg2;->a:Ljava/lang/Object;

    invoke-virtual {v0, v1}, Lads_mobile_sdk/dg2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object v1

    :pswitch_19  #0x0
    check-cast p1, Lads_mobile_sdk/cy0;

    check-cast p2, Lvx;

    new-instance v0, Lads_mobile_sdk/dg2;

    const/4 v2, 0x0

    invoke-direct {v0, p0, p2, v2}, Lads_mobile_sdk/dg2;-><init>(Lads_mobile_sdk/jz2;Lvx;I)V

    iput-object p1, v0, Lads_mobile_sdk/dg2;->a:Ljava/lang/Object;

    invoke-virtual {v0, v1}, Lads_mobile_sdk/dg2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object v1

    nop

    :pswitch_data_2a
    .packed-switch 0x0
        :pswitch_19  #00000000
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .prologue
    iget v0, p0, Lads_mobile_sdk/dg2;->t:I

    packed-switch v0, :pswitch_data_40

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/dg2;->a:Ljava/lang/Object;

    check-cast p1, Lads_mobile_sdk/cy0;

    invoke-virtual {p1}, Lads_mobile_sdk/cy0;->b()Lads_mobile_sdk/ry0;

    move-result-object v0

    iget-object v1, p0, Lads_mobile_sdk/dg2;->b:Lads_mobile_sdk/jz2;

    iput-object v1, v0, Lads_mobile_sdk/ry0;->u:Lads_mobile_sdk/jz2;

    iget-object v0, p0, Lads_mobile_sdk/dg2;->b:Lads_mobile_sdk/jz2;

    new-instance v1, Lvd;

    const/16 v2, 0x17

    invoke-direct {v1, v2, v0}, Lvd;-><init>(ILjava/lang/Object;)V

    invoke-virtual {p1, v1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    iget-object p0, p0, Lads_mobile_sdk/dg2;->b:Lads_mobile_sdk/jz2;

    new-instance v0, Lr60;

    const/4 v1, 0x1

    invoke-direct {v0, v1, p0}, Lr60;-><init>(ILjava/lang/Object;)V

    invoke-virtual {p1, v0}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0

    :pswitch_2e  #0x0
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/dg2;->a:Ljava/lang/Object;

    check-cast p1, Lads_mobile_sdk/cy0;

    invoke-virtual {p1}, Lads_mobile_sdk/cy0;->b()Lads_mobile_sdk/ry0;

    move-result-object p1

    iget-object p0, p0, Lads_mobile_sdk/dg2;->b:Lads_mobile_sdk/jz2;

    iput-object p0, p1, Lads_mobile_sdk/ry0;->u:Lads_mobile_sdk/jz2;

    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0

    :pswitch_data_40
    .packed-switch 0x0
        :pswitch_2e  #00000000
    .end packed-switch
.end method
