.class public final Lads_mobile_sdk/be3;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lnt2;


# instance fields
.field public final a:Lads_mobile_sdk/ah0;

.field public final b:Lads_mobile_sdk/ob1;

.field public final c:Lads_mobile_sdk/ah0;

.field public final d:Ltv2;

.field public final e:Ltv2;

.field public final f:Ltv2;

.field public final synthetic g:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/ah0;Lads_mobile_sdk/ob1;Lads_mobile_sdk/ah0;Ltv2;Ltv2;Ltv2;)V
    .registers 8

    const/4 v0, 0x0

    iput v0, p0, Lads_mobile_sdk/be3;->g:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/be3;->a:Lads_mobile_sdk/ah0;

    iput-object p2, p0, Lads_mobile_sdk/be3;->b:Lads_mobile_sdk/ob1;

    iput-object p3, p0, Lads_mobile_sdk/be3;->c:Lads_mobile_sdk/ah0;

    iput-object p4, p0, Lads_mobile_sdk/be3;->d:Ltv2;

    iput-object p5, p0, Lads_mobile_sdk/be3;->e:Ltv2;

    iput-object p6, p0, Lads_mobile_sdk/be3;->f:Ltv2;

    return-void
.end method

.method public constructor <init>(Lads_mobile_sdk/ob1;Ltv2;Lads_mobile_sdk/ah0;Lads_mobile_sdk/ah0;Ltv2;Ltv2;)V
    .registers 8

    const/4 v0, 0x1

    iput v0, p0, Lads_mobile_sdk/be3;->g:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/be3;->b:Lads_mobile_sdk/ob1;

    iput-object p2, p0, Lads_mobile_sdk/be3;->d:Ltv2;

    iput-object p3, p0, Lads_mobile_sdk/be3;->a:Lads_mobile_sdk/ah0;

    iput-object p4, p0, Lads_mobile_sdk/be3;->c:Lads_mobile_sdk/ah0;

    iput-object p5, p0, Lads_mobile_sdk/be3;->e:Ltv2;

    iput-object p6, p0, Lads_mobile_sdk/be3;->f:Ltv2;

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 14

    .prologue
    iget v0, p0, Lads_mobile_sdk/be3;->g:I

    iget-object v1, p0, Lads_mobile_sdk/be3;->f:Ltv2;

    iget-object v2, p0, Lads_mobile_sdk/be3;->e:Ltv2;

    iget-object v3, p0, Lads_mobile_sdk/be3;->c:Lads_mobile_sdk/ah0;

    iget-object v4, p0, Lads_mobile_sdk/be3;->a:Lads_mobile_sdk/ah0;

    iget-object v5, p0, Lads_mobile_sdk/be3;->d:Ltv2;

    iget-object p0, p0, Lads_mobile_sdk/be3;->b:Lads_mobile_sdk/ob1;

    packed-switch v0, :pswitch_data_6e

    iget-object p0, p0, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v7, p0

    check-cast v7, Landroid/content/Context;

    invoke-interface {v5}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v8, p0

    check-cast v8, Lly;

    invoke-virtual {v4}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v9, p0

    check-cast v9, Lvy;

    invoke-virtual {v3}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v10, p0

    check-cast v10, Lads_mobile_sdk/ah3;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v11, p0

    check-cast v11, Lads_mobile_sdk/ux2;

    invoke-interface {v1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v12, p0

    check-cast v12, Ljava/lang/String;

    new-instance v6, Lads_mobile_sdk/s52;

    invoke-direct/range {v6 .. v12}, Lads_mobile_sdk/s52;-><init>(Landroid/content/Context;Lly;Lvy;Lads_mobile_sdk/ah3;Lads_mobile_sdk/ux2;Ljava/lang/String;)V

    return-object v6

    :pswitch_3f  #0x0
    invoke-virtual {v4}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v7, v0

    check-cast v7, Lvy;

    iget-object p0, p0, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v8, p0

    check-cast v8, Lads_mobile_sdk/a2;

    invoke-virtual {v3}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v9, p0

    check-cast v9, Lads_mobile_sdk/z2;

    invoke-interface {v5}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v10, p0

    check-cast v10, Ly43;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v11, p0

    check-cast v11, Lyx2;

    invoke-interface {v1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v12, p0

    check-cast v12, Ljava/util/Optional;

    new-instance v6, Lads_mobile_sdk/ae3;

    invoke-direct/range {v6 .. v12}, Lads_mobile_sdk/ae3;-><init>(Lvy;Lads_mobile_sdk/a2;Lads_mobile_sdk/z2;Ly43;Lyx2;Ljava/util/Optional;)V

    return-object v6

    nop

    :pswitch_data_6e
    .packed-switch 0x0
        :pswitch_3f  #00000000
    .end packed-switch
.end method
