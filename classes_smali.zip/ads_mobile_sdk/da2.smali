.class public abstract Lads_mobile_sdk/da2;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Ljava/lang/String;

.field public final c:Ljava/lang/String;

.field public final e:Ljava/lang/String;

.field public final f:Lads_mobile_sdk/ji;

.field public final g:Lads_mobile_sdk/hz0;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    new-instance v0, Ljava/util/UUID;

    const-wide/16 v1, 0x0

    invoke-direct {v0, v1, v2, v1, v2}, Ljava/util/UUID;-><init>(JJ)V

    invoke-virtual {v0}, Ljava/util/UUID;->toString()Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 6

    .prologue
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget-object v0, Lads_mobile_sdk/ji;->c:Lads_mobile_sdk/ji;

    if-nez v0, :cond_e

    new-instance v0, Lads_mobile_sdk/ji;

    invoke-direct {v0, p1}, Lads_mobile_sdk/ji;-><init>(Landroid/content/Context;)V

    sput-object v0, Lads_mobile_sdk/ji;->c:Lads_mobile_sdk/ji;

    :cond_e
    iput-object v0, p0, Lads_mobile_sdk/da2;->f:Lads_mobile_sdk/ji;

    invoke-static {p1}, Lads_mobile_sdk/hz0;->a(Landroid/content/Context;)Lads_mobile_sdk/hz0;

    move-result-object p1

    iput-object p1, p0, Lads_mobile_sdk/da2;->g:Lads_mobile_sdk/hz0;

    iput-object p2, p0, Lads_mobile_sdk/da2;->a:Ljava/lang/String;

    const-string p1, "_3p"

    invoke-virtual {p2, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    iput-object p3, p0, Lads_mobile_sdk/da2;->c:Ljava/lang/String;

    invoke-virtual {p3, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    iput-object p4, p0, Lads_mobile_sdk/da2;->e:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final a(J)Lads_mobile_sdk/fz0;
    .registers 14

    .prologue
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const-wide/16 v2, 0x0

    cmp-long v2, v0, v2

    const/4 v3, 0x0

    if-ltz v2, :cond_5f

    iget-object v2, p0, Lads_mobile_sdk/da2;->f:Lads_mobile_sdk/ji;

    iget-object v4, v2, Lads_mobile_sdk/ji;->b:Ljava/lang/Object;

    check-cast v4, Landroid/content/SharedPreferences;

    iget-object v5, v2, Lads_mobile_sdk/ji;->b:Ljava/lang/Object;

    check-cast v5, Landroid/content/SharedPreferences;

    iget-object v6, p0, Lads_mobile_sdk/da2;->c:Ljava/lang/String;

    const-wide/16 v7, -0x1

    invoke-interface {v4, v6, v7, v8}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v9

    cmp-long v4, v9, v7

    if-nez v4, :cond_22

    goto :goto_40

    :cond_22
    cmp-long v4, v0, v9

    if-gez v4, :cond_2e

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    invoke-virtual {v2, p1, v6}, Lads_mobile_sdk/ji;->a(Ljava/lang/Object;Ljava/lang/String;)V

    goto :goto_40

    :cond_2e
    add-long/2addr v9, p1

    cmp-long p1, v0, v9

    if-ltz p1, :cond_40

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lads_mobile_sdk/da2;->a(Ljava/lang/String;)Lads_mobile_sdk/fz0;

    move-result-object p0

    return-object p0

    :cond_40
    :goto_40
    iget-object p1, p0, Lads_mobile_sdk/da2;->a:Ljava/lang/String;

    invoke-interface {v5, p1, v3}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    if-nez p1, :cond_55

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object p1

    invoke-virtual {p1}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Lads_mobile_sdk/da2;->a(Ljava/lang/String;)Lads_mobile_sdk/fz0;

    move-result-object p0

    return-object p0

    :cond_55
    new-instance p0, Lads_mobile_sdk/fz0;

    invoke-interface {v5, v6, v7, v8}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v0

    invoke-direct {p0, v0, v1, p1}, Lads_mobile_sdk/fz0;-><init>(JLjava/lang/String;)V

    return-object p0

    :cond_5f
    iget-object p0, p0, Lads_mobile_sdk/da2;->e:Ljava/lang/String;

    const-string p1, ": Invalid negative current timestamp. Updating PAID failed"

    invoke-virtual {p0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v3
.end method

.method public final a(Ljava/lang/String;)Lads_mobile_sdk/fz0;
    .registers 7

    .prologue
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const-wide/16 v2, 0x0

    cmp-long v2, v0, v2

    if-ltz v2, :cond_20

    iget-object v2, p0, Lads_mobile_sdk/da2;->c:Ljava/lang/String;

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    iget-object v4, p0, Lads_mobile_sdk/da2;->f:Lads_mobile_sdk/ji;

    invoke-virtual {v4, v3, v2}, Lads_mobile_sdk/ji;->a(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object p0, p0, Lads_mobile_sdk/da2;->a:Ljava/lang/String;

    invoke-virtual {v4, p1, p0}, Lads_mobile_sdk/ji;->a(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance p0, Lads_mobile_sdk/fz0;

    invoke-direct {p0, v0, v1, p1}, Lads_mobile_sdk/fz0;-><init>(JLjava/lang/String;)V

    return-object p0

    :cond_20
    iget-object p0, p0, Lads_mobile_sdk/da2;->e:Ljava/lang/String;

    const-string p1, ": Invalid negative current timestamp. Updating PAID failed"

    invoke-virtual {p0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0
.end method
