.class public final Lads_mobile_sdk/a1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lbw2;


# instance fields
.field public final a:Lvu2;


# direct methods
.method public constructor <init>(Lvu2;)V
    .registers 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/a1;->a:Lvu2;

    return-void
.end method


# virtual methods
.method public final a(Lads_mobile_sdk/cy0;Ljava/util/Map;Lvx;)Ljava/lang/Object;
    .registers 4

    .prologue
    const-string p1, "disabled"

    invoke-interface {p2, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    const/4 p2, 0x1

    if-eqz p1, :cond_13

    invoke-static {p1}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result p1

    if-ne p1, p2, :cond_13

    move p1, p2

    goto :goto_14

    :cond_13
    const/4 p1, 0x0

    :goto_14
    xor-int/2addr p1, p2

    iget-object p0, p0, Lads_mobile_sdk/a1;->a:Lvu2;

    iget-object p0, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    check-cast p0, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {p0, p1}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method

.method public final b()I
    .registers 1

    const/16 p0, 0x12

    return p0
.end method
