.class public final Lads_mobile_sdk/dv0;
.super Lads_mobile_sdk/av0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final c:Lc81;


# direct methods
.method public constructor <init>(Lc81;)V
    .registers 3

    const/16 v0, 0xd

    invoke-direct {p0, v0}, Lads_mobile_sdk/av0;-><init>(I)V

    iput-object p1, p0, Lads_mobile_sdk/dv0;->c:Lc81;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 3

    .prologue
    if-ne p0, p1, :cond_3

    goto :goto_16

    :cond_3
    instance-of v0, p1, Lads_mobile_sdk/dv0;

    if-nez v0, :cond_8

    goto :goto_14

    :cond_8
    check-cast p1, Lads_mobile_sdk/dv0;

    iget-object p0, p0, Lads_mobile_sdk/dv0;->c:Lc81;

    iget-object p1, p1, Lads_mobile_sdk/dv0;->c:Lc81;

    invoke-virtual {p0, p1}, Lc81;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_16

    :goto_14
    const/4 p0, 0x0

    return p0

    :cond_16
    :goto_16
    const/4 p0, 0x1

    return p0
.end method

.method public final hashCode()I
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/dv0;->c:Lc81;

    invoke-virtual {p0}, Lc81;->hashCode()I

    move-result p0

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "InternalMediationAdError(mediationAdError="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object p0, p0, Lads_mobile_sdk/dv0;->c:Lc81;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
