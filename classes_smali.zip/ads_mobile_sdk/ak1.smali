.class public final Lads_mobile_sdk/ak1;
.super Lwx;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public a:Ljava/lang/Object;

.field public synthetic b:Ljava/lang/Object;

.field public final synthetic c:Lads_mobile_sdk/bk1;

.field public d:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/bk1;Lwx;)V
    .registers 3

    iput-object p1, p0, Lads_mobile_sdk/ak1;->c:Lads_mobile_sdk/bk1;

    invoke-direct {p0, p2}, Lwx;-><init>(Lvx;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    iput-object p1, p0, Lads_mobile_sdk/ak1;->b:Ljava/lang/Object;

    iget p1, p0, Lads_mobile_sdk/ak1;->d:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, Lads_mobile_sdk/ak1;->d:I

    iget-object p1, p0, Lads_mobile_sdk/ak1;->c:Lads_mobile_sdk/bk1;

    const/4 v0, 0x0

    invoke-static {p1, v0, p0}, Lads_mobile_sdk/bk1;->b(Lads_mobile_sdk/bk1;Ljava/lang/String;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
