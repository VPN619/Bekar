.class public final Lads_mobile_sdk/dy2;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Ljava/lang/String;
    .annotation runtime Lv02;
        value = "name"
    .end annotation
.end field

.field public final b:Ljava/lang/String;
    .annotation runtime Lv02;
        value = "adapter_version"
    .end annotation
.end field

.field public final c:Ljava/lang/String;
    .annotation runtime Lv02;
        value = "sdk_version"
    .end annotation
.end field

.field public d:Ljava/lang/String;
    .annotation runtime Lv02;
        value = "signals"
    .end annotation
.end field

.field public e:Ljava/lang/String;
    .annotation runtime Lv02;
        value = "signal_error"
    .end annotation
.end field

.field public f:Ljava/lang/Integer;
    .annotation runtime Lv02;
        value = "signal_error_code"
    .end annotation
.end field

.field public g:Ljava/lang/Long;
    .annotation runtime Lv02;
        value = "latency"
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 8

    const/4 v5, 0x0

    const/16 v6, 0x7f

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    move-object v0, p0

    invoke-direct/range {v0 .. v6}, Lads_mobile_sdk/dy2;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;I)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;I)V
    .registers 9

    .prologue
    and-int/lit8 v0, p6, 0x1

    const/4 v1, 0x0

    if-eqz v0, :cond_6

    move-object p1, v1

    :cond_6
    and-int/lit8 v0, p6, 0x2

    if-eqz v0, :cond_b

    move-object p2, v1

    :cond_b
    and-int/lit8 v0, p6, 0x4

    if-eqz v0, :cond_10

    move-object p3, v1

    :cond_10
    and-int/lit8 v0, p6, 0x10

    if-eqz v0, :cond_15

    move-object p4, v1

    :cond_15
    and-int/lit8 p6, p6, 0x20

    if-eqz p6, :cond_1a

    move-object p5, v1

    :cond_1a
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/dy2;->a:Ljava/lang/String;

    iput-object p2, p0, Lads_mobile_sdk/dy2;->b:Ljava/lang/String;

    iput-object p3, p0, Lads_mobile_sdk/dy2;->c:Ljava/lang/String;

    iput-object v1, p0, Lads_mobile_sdk/dy2;->d:Ljava/lang/String;

    iput-object p4, p0, Lads_mobile_sdk/dy2;->e:Ljava/lang/String;

    iput-object p5, p0, Lads_mobile_sdk/dy2;->f:Ljava/lang/Integer;

    iput-object v1, p0, Lads_mobile_sdk/dy2;->g:Ljava/lang/Long;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .prologue
    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lads_mobile_sdk/dy2;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, Lads_mobile_sdk/dy2;

    iget-object v1, p0, Lads_mobile_sdk/dy2;->a:Ljava/lang/String;

    iget-object v3, p1, Lads_mobile_sdk/dy2;->a:Ljava/lang/String;

    invoke-static {v1, v3}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_17

    return v2

    :cond_17
    iget-object v1, p0, Lads_mobile_sdk/dy2;->b:Ljava/lang/String;

    iget-object v3, p1, Lads_mobile_sdk/dy2;->b:Ljava/lang/String;

    invoke-static {v1, v3}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_22

    return v2

    :cond_22
    iget-object v1, p0, Lads_mobile_sdk/dy2;->c:Ljava/lang/String;

    iget-object v3, p1, Lads_mobile_sdk/dy2;->c:Ljava/lang/String;

    invoke-static {v1, v3}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2d

    return v2

    :cond_2d
    iget-object v1, p0, Lads_mobile_sdk/dy2;->d:Ljava/lang/String;

    iget-object v3, p1, Lads_mobile_sdk/dy2;->d:Ljava/lang/String;

    invoke-static {v1, v3}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_38

    return v2

    :cond_38
    iget-object v1, p0, Lads_mobile_sdk/dy2;->e:Ljava/lang/String;

    iget-object v3, p1, Lads_mobile_sdk/dy2;->e:Ljava/lang/String;

    invoke-static {v1, v3}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_43

    return v2

    :cond_43
    iget-object v1, p0, Lads_mobile_sdk/dy2;->f:Ljava/lang/Integer;

    iget-object v3, p1, Lads_mobile_sdk/dy2;->f:Ljava/lang/Integer;

    invoke-static {v1, v3}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4e

    return v2

    :cond_4e
    iget-object p0, p0, Lads_mobile_sdk/dy2;->g:Ljava/lang/Long;

    iget-object p1, p1, Lads_mobile_sdk/dy2;->g:Ljava/lang/Long;

    invoke-static {p0, p1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_59

    return v2

    :cond_59
    return v0
.end method

.method public final hashCode()I
    .registers 4

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/dy2;->a:Ljava/lang/String;

    const/4 v1, 0x0

    if-nez v0, :cond_7

    move v0, v1

    goto :goto_b

    :cond_7
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    :goto_b
    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lads_mobile_sdk/dy2;->b:Ljava/lang/String;

    if-nez v2, :cond_13

    move v2, v1

    goto :goto_17

    :cond_13
    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v2

    :goto_17
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lads_mobile_sdk/dy2;->c:Ljava/lang/String;

    if-nez v2, :cond_20

    move v2, v1

    goto :goto_24

    :cond_20
    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v2

    :goto_24
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lads_mobile_sdk/dy2;->d:Ljava/lang/String;

    if-nez v2, :cond_2d

    move v2, v1

    goto :goto_31

    :cond_2d
    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v2

    :goto_31
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lads_mobile_sdk/dy2;->e:Ljava/lang/String;

    if-nez v2, :cond_3a

    move v2, v1

    goto :goto_3e

    :cond_3a
    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v2

    :goto_3e
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object v2, p0, Lads_mobile_sdk/dy2;->f:Ljava/lang/Integer;

    if-nez v2, :cond_47

    move v2, v1

    goto :goto_4b

    :cond_47
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_4b
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object p0, p0, Lads_mobile_sdk/dy2;->g:Ljava/lang/Long;

    if-nez p0, :cond_53

    goto :goto_57

    :cond_53
    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result v1

    :goto_57
    add-int/2addr v0, v1

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 10

    iget-object v0, p0, Lads_mobile_sdk/dy2;->a:Ljava/lang/String;

    iget-object v1, p0, Lads_mobile_sdk/dy2;->b:Ljava/lang/String;

    iget-object v2, p0, Lads_mobile_sdk/dy2;->c:Ljava/lang/String;

    iget-object v3, p0, Lads_mobile_sdk/dy2;->d:Ljava/lang/String;

    iget-object v4, p0, Lads_mobile_sdk/dy2;->e:Ljava/lang/String;

    iget-object v5, p0, Lads_mobile_sdk/dy2;->f:Ljava/lang/Integer;

    iget-object p0, p0, Lads_mobile_sdk/dy2;->g:Ljava/lang/Long;

    const-string v6, ", adapterVersion="

    const-string v7, ", sdkVersion="

    const-string v8, "RtbAdapterData(adapterClassName="

    invoke-static {v8, v0, v6, v1, v7}, Ly41;->t(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", signals="

    const-string v6, ", signalErrorMessage="

    invoke-static {v0, v2, v1, v3, v6}, Ly41;->x(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", signalErrorCode="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", latency="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
