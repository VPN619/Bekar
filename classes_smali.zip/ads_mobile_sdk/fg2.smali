.class public final Lads_mobile_sdk/fg2;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpv2;


# instance fields
.field public final synthetic a:Lads_mobile_sdk/jz2;

.field public final synthetic b:I


# direct methods
.method public synthetic constructor <init>(Lads_mobile_sdk/jz2;I)V
    .registers 3

    iput p2, p0, Lads_mobile_sdk/fg2;->b:I

    iput-object p1, p0, Lads_mobile_sdk/fg2;->a:Lads_mobile_sdk/jz2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Lc03;Lwx;)Ljava/lang/Object;
    .registers 13

    .prologue
    iget v0, p0, Lads_mobile_sdk/fg2;->b:I

    sget-object v1, Lrg2;->a:Lrg2;

    iget-object v2, p0, Lads_mobile_sdk/fg2;->a:Lads_mobile_sdk/jz2;

    const-string v3, "call to \'resume\' before \'invoke\' with coroutine"

    sget-object v4, Lwy;->a:Lwy;

    const/high16 v5, -0x80000000

    const/4 v6, 0x1

    const/4 v7, 0x0

    packed-switch v0, :pswitch_data_84

    instance-of v0, p2, Lads_mobile_sdk/g10;

    if-eqz v0, :cond_22

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/g10;

    iget v8, v0, Lads_mobile_sdk/g10;->c:I

    and-int v9, v8, v5

    if-eqz v9, :cond_22

    sub-int/2addr v8, v5

    iput v8, v0, Lads_mobile_sdk/g10;->c:I

    goto :goto_27

    :cond_22
    new-instance v0, Lads_mobile_sdk/g10;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/g10;-><init>(Lads_mobile_sdk/fg2;Lwx;)V

    :goto_27
    iget-object p0, v0, Lads_mobile_sdk/g10;->a:Ljava/lang/Object;

    iget p2, v0, Lads_mobile_sdk/g10;->c:I

    if-eqz p2, :cond_38

    if-ne p2, v6, :cond_33

    invoke-static {p0}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_49

    :cond_33
    invoke-static {v3}, Lz6;->w(Ljava/lang/String;)V

    move-object v1, v7

    goto :goto_49

    :cond_38
    invoke-static {p0}, Lt12;->W(Ljava/lang/Object;)V

    new-instance p0, Lads_mobile_sdk/dg2;

    invoke-direct {p0, v2, v7, v6}, Lads_mobile_sdk/dg2;-><init>(Lads_mobile_sdk/jz2;Lvx;I)V

    iput v6, v0, Lads_mobile_sdk/g10;->c:I

    invoke-interface {p1, p0, v0}, Lc03;->a(Lpk0;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v4, :cond_49

    move-object v1, v4

    :cond_49
    :goto_49
    return-object v1

    :pswitch_4a  #0x0
    instance-of v0, p2, Lads_mobile_sdk/eg2;

    if-eqz v0, :cond_5b

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/eg2;

    iget v8, v0, Lads_mobile_sdk/eg2;->c:I

    and-int v9, v8, v5

    if-eqz v9, :cond_5b

    sub-int/2addr v8, v5

    iput v8, v0, Lads_mobile_sdk/eg2;->c:I

    goto :goto_60

    :cond_5b
    new-instance v0, Lads_mobile_sdk/eg2;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/eg2;-><init>(Lads_mobile_sdk/fg2;Lwx;)V

    :goto_60
    iget-object p0, v0, Lads_mobile_sdk/eg2;->a:Ljava/lang/Object;

    iget p2, v0, Lads_mobile_sdk/eg2;->c:I

    if-eqz p2, :cond_71

    if-ne p2, v6, :cond_6c

    invoke-static {p0}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_83

    :cond_6c
    invoke-static {v3}, Lz6;->w(Ljava/lang/String;)V

    move-object v1, v7

    goto :goto_83

    :cond_71
    invoke-static {p0}, Lt12;->W(Ljava/lang/Object;)V

    new-instance p0, Lads_mobile_sdk/dg2;

    const/4 p2, 0x0

    invoke-direct {p0, v2, v7, p2}, Lads_mobile_sdk/dg2;-><init>(Lads_mobile_sdk/jz2;Lvx;I)V

    iput v6, v0, Lads_mobile_sdk/eg2;->c:I

    invoke-interface {p1, p0, v0}, Lc03;->a(Lpk0;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v4, :cond_83

    move-object v1, v4

    :cond_83
    :goto_83
    return-object v1

    :pswitch_data_84
    .packed-switch 0x0
        :pswitch_4a  #00000000
    .end packed-switch
.end method

.method public final bridge synthetic a(Ljava/lang/Object;Lads_mobile_sdk/rk1;)Ljava/lang/Object;
    .registers 4

    .prologue
    iget v0, p0, Lads_mobile_sdk/fg2;->b:I

    packed-switch v0, :pswitch_data_14

    check-cast p1, Lc03;

    invoke-virtual {p0, p1, p2}, Lads_mobile_sdk/fg2;->a(Lc03;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_c  #0x0
    check-cast p1, Lc03;

    invoke-virtual {p0, p1, p2}, Lads_mobile_sdk/fg2;->a(Lc03;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_14
    .packed-switch 0x0
        :pswitch_c  #00000000
    .end packed-switch
.end method
