.class public final Lads_mobile_sdk/cl2;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lmt2;


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:Lv03;

.field public final c:Lz53;

.field public final d:Lads_mobile_sdk/th3;

.field public final e:Ljava/util/concurrent/ExecutorService;

.field public final f:Lads_mobile_sdk/pl2;

.field public final g:Lads_mobile_sdk/z6;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lv03;Lz53;Lads_mobile_sdk/th3;Ljava/util/concurrent/ExecutorService;Lads_mobile_sdk/pl2;Lads_mobile_sdk/z6;)V
    .registers 8

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/cl2;->a:Landroid/content/Context;

    iput-object p2, p0, Lads_mobile_sdk/cl2;->b:Lv03;

    iput-object p3, p0, Lads_mobile_sdk/cl2;->c:Lz53;

    iput-object p4, p0, Lads_mobile_sdk/cl2;->d:Lads_mobile_sdk/th3;

    iput-object p5, p0, Lads_mobile_sdk/cl2;->e:Ljava/util/concurrent/ExecutorService;

    iput-object p6, p0, Lads_mobile_sdk/cl2;->f:Lads_mobile_sdk/pl2;

    iput-object p7, p0, Lads_mobile_sdk/cl2;->g:Lads_mobile_sdk/z6;

    return-void
.end method


# virtual methods
.method public final a()Ll;
    .registers 8

    sget-object v0, Lads_mobile_sdk/fl0;->m2:Lads_mobile_sdk/fl0;

    iget-object v1, p0, Lads_mobile_sdk/cl2;->b:Lv03;

    invoke-static {v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v2, Lyp0;

    const/4 v3, 0x7

    invoke-direct {v2, v3, v1}, Lyp0;-><init>(ILjava/lang/Object;)V

    iget-object v1, p0, Lads_mobile_sdk/cl2;->e:Ljava/util/concurrent/ExecutorService;

    invoke-static {v1, v2}, Lpy2;->N(Ljava/util/concurrent/Executor;Ljava/util/concurrent/Callable;)Lpd2;

    move-result-object v2

    invoke-static {v2}, Lfg0;->r(Ld31;)Lfg0;

    move-result-object v2

    new-instance v3, Lqv2;

    const/4 v4, 0x0

    invoke-direct {v3, p0, v4}, Lqv2;-><init>(Lads_mobile_sdk/cl2;I)V

    sget-object v5, Lv40;->a:Lv40;

    invoke-static {v2, v3, v5}, Lk1;->t(Ld31;Llk0;Ljava/util/concurrent/Executor;)Lj1;

    move-result-object v2

    new-instance v3, Lrv2;

    invoke-direct {v3, v4, p0}, Lrv2;-><init>(ILjava/lang/Object;)V

    invoke-static {v2, v3, v5}, Lk1;->s(Lfg0;Lcf;Ljava/util/concurrent/Executor;)Li1;

    move-result-object v2

    new-instance v3, Lqv2;

    const/4 v6, 0x1

    invoke-direct {v3, p0, v6}, Lqv2;-><init>(Lads_mobile_sdk/cl2;I)V

    invoke-static {v2, v3, v1}, Lk1;->t(Ld31;Llk0;Ljava/util/concurrent/Executor;)Lj1;

    move-result-object v1

    new-instance v2, Lsv2;

    invoke-direct {v2, v4}, Lsv2;-><init>(I)V

    const-class v3, Llu2;

    invoke-virtual {v1, v3, v2, v5}, Lfg0;->q(Ljava/lang/Class;Llk0;Ljava/util/concurrent/Executor;)Ll;

    move-result-object v1

    iget-object p0, p0, Lads_mobile_sdk/cl2;->d:Lads_mobile_sdk/th3;

    invoke-virtual {p0, v0, v1}, Lads_mobile_sdk/th3;->a(Lads_mobile_sdk/fl0;Leg0;)V

    return-object v1
.end method
