.class public final Lads_mobile_sdk/cn3;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lbw2;


# instance fields
.field public final a:Lly;


# direct methods
.method public constructor <init>(Lly;)V
    .registers 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/cn3;->a:Lly;

    return-void
.end method


# virtual methods
.method public final a(Lads_mobile_sdk/cy0;Ljava/util/Map;Lvx;)Ljava/lang/Object;
    .registers 11

    .prologue
    const-string v0, "action"

    invoke-interface {p2, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const/4 v1, 0x6

    sget-object v2, Lrg2;->a:Lrg2;

    const/4 v3, 0x0

    if-eqz v0, :cond_9f

    invoke-static {v0}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_16

    goto/16 :goto_9f

    :cond_16
    new-instance v4, Ljava/lang/StringBuilder;

    const-string v5, "Handling \""

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, "\" video GMSG"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4, v3}, Lads_mobile_sdk/nw;->b(Ljava/lang/String;Ljava/lang/Throwable;)V

    invoke-virtual {p1}, Lads_mobile_sdk/cy0;->d()Lads_mobile_sdk/bz0;

    move-result-object p1

    if-nez p1, :cond_33

    goto :goto_9e

    :cond_33
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v4

    const v5, 0x1bde4

    sget-object v6, Lwy;->a:Lwy;

    iget-object p0, p0, Lads_mobile_sdk/cn3;->a:Lly;

    if-eq v4, v5, :cond_77

    const v5, 0x35e57f

    if-eq v4, v5, :cond_61

    const v5, 0x690e7dd6

    if-eq v4, v5, :cond_4b

    goto :goto_7f

    :cond_4b
    const-string v4, "timeupdate"

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_54

    goto :goto_7f

    :cond_54
    new-instance v0, Lads_mobile_sdk/bn3;

    const/4 v1, 0x1

    invoke-direct {v0, p2, p1, v3, v1}, Lads_mobile_sdk/bn3;-><init>(Ljava/util/Map;Lads_mobile_sdk/bz0;Lvx;I)V

    invoke-static {p0, v0, p3}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v6, :cond_9e

    return-object p0

    :cond_61
    const-string v4, "skip"

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_6a

    goto :goto_7f

    :cond_6a
    new-instance p2, Lc4;

    const/4 v0, 0x3

    invoke-direct {p2, p1, v3, v0}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    invoke-static {p0, p2, p3}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v6, :cond_9e

    return-object p0

    :cond_77
    const-string v4, "src"

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_91

    :goto_7f
    new-instance p0, Ljava/lang/StringBuilder;

    const-string p1, "Unhandled video GMSG: "

    invoke-direct {p0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v1, p0, v3}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    return-object v2

    :cond_91
    new-instance v0, Lads_mobile_sdk/bn3;

    const/4 v1, 0x0

    invoke-direct {v0, p2, p1, v3, v1}, Lads_mobile_sdk/bn3;-><init>(Ljava/util/Map;Lads_mobile_sdk/bz0;Lvx;I)V

    invoke-static {p0, v0, p3}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v6, :cond_9e

    return-object p0

    :cond_9e
    :goto_9e
    return-object v2

    :cond_9f
    :goto_9f
    new-instance p0, Ljava/lang/StringBuilder;

    const-string p1, "Action is missing from a video GMSG: "

    invoke-direct {p0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v1, p0, v3}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    return-object v2
.end method

.method public final b()I
    .registers 1

    const/16 p0, 0xb

    return p0
.end method

.method public final c()Z
    .registers 1

    const/4 p0, 0x1

    return p0
.end method
