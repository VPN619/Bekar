.class public final Lads_mobile_sdk/ez1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lbw2;


# instance fields
.field public final a:Lbw2;

.field public final synthetic b:I


# direct methods
.method public synthetic constructor <init>(Lbw2;I)V
    .registers 3

    iput p2, p0, Lads_mobile_sdk/ez1;->b:I

    iput-object p1, p0, Lads_mobile_sdk/ez1;->a:Lbw2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Lbw2;
    .registers 2

    .prologue
    iget v0, p0, Lads_mobile_sdk/ez1;->b:I

    iget-object p0, p0, Lads_mobile_sdk/ez1;->a:Lbw2;

    packed-switch v0, :pswitch_data_2c

    check-cast p0, Lads_mobile_sdk/d13;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object p0

    :pswitch_d  #0x7
    invoke-interface {p0}, Lbw2;->a()Lbw2;

    move-result-object p0

    return-object p0

    :pswitch_12  #0x6
    invoke-interface {p0}, Lbw2;->a()Lbw2;

    move-result-object p0

    return-object p0

    :pswitch_17  #0x5
    invoke-interface {p0}, Lbw2;->a()Lbw2;

    move-result-object p0

    return-object p0

    :pswitch_1c  #0x4
    invoke-interface {p0}, Lbw2;->a()Lbw2;

    move-result-object p0

    :pswitch_20  #0x3
    return-object p0

    :pswitch_21  #0x2
    invoke-interface {p0}, Lbw2;->a()Lbw2;

    move-result-object p0

    :pswitch_25  #0x1
    return-object p0

    :pswitch_26  #0x0
    invoke-interface {p0}, Lbw2;->a()Lbw2;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_2c
    .packed-switch 0x0
        :pswitch_26  #00000000
        :pswitch_25  #00000001
        :pswitch_21  #00000002
        :pswitch_20  #00000003
        :pswitch_1c  #00000004
        :pswitch_17  #00000005
        :pswitch_12  #00000006
        :pswitch_d  #00000007
    .end packed-switch
.end method

.method public final a(Lads_mobile_sdk/cy0;Ljava/util/Map;Lvx;)Ljava/lang/Object;
    .registers 5

    .prologue
    iget v0, p0, Lads_mobile_sdk/ez1;->b:I

    iget-object p0, p0, Lads_mobile_sdk/ez1;->a:Lbw2;

    packed-switch v0, :pswitch_data_36

    check-cast p0, Lads_mobile_sdk/d13;

    invoke-virtual {p0, p1, p2, p3}, Lads_mobile_sdk/d13;->a(Lads_mobile_sdk/cy0;Ljava/util/Map;Lvx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_e  #0x7
    invoke-interface {p0, p1, p2, p3}, Lbw2;->a(Lads_mobile_sdk/cy0;Ljava/util/Map;Lvx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_13  #0x6
    invoke-interface {p0, p1, p2, p3}, Lbw2;->a(Lads_mobile_sdk/cy0;Ljava/util/Map;Lvx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_18  #0x5
    invoke-interface {p0, p1, p2, p3}, Lbw2;->a(Lads_mobile_sdk/cy0;Ljava/util/Map;Lvx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_1d  #0x4
    invoke-interface {p0, p1, p2, p3}, Lbw2;->a(Lads_mobile_sdk/cy0;Ljava/util/Map;Lvx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_22  #0x3
    invoke-interface {p0, p1, p2, p3}, Lbw2;->a(Lads_mobile_sdk/cy0;Ljava/util/Map;Lvx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_27  #0x2
    invoke-interface {p0, p1, p2, p3}, Lbw2;->a(Lads_mobile_sdk/cy0;Ljava/util/Map;Lvx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_2c  #0x1
    invoke-interface {p0, p1, p2, p3}, Lbw2;->a(Lads_mobile_sdk/cy0;Ljava/util/Map;Lvx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_31  #0x0
    invoke-interface {p0, p1, p2, p3}, Lbw2;->a(Lads_mobile_sdk/cy0;Ljava/util/Map;Lvx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_data_36
    .packed-switch 0x0
        :pswitch_31  #00000000
        :pswitch_2c  #00000001
        :pswitch_27  #00000002
        :pswitch_22  #00000003
        :pswitch_1d  #00000004
        :pswitch_18  #00000005
        :pswitch_13  #00000006
        :pswitch_e  #00000007
    .end packed-switch
.end method

.method public final a(Ljava/lang/String;)V
    .registers 3

    .prologue
    iget v0, p0, Lads_mobile_sdk/ez1;->b:I

    iget-object p0, p0, Lads_mobile_sdk/ez1;->a:Lbw2;

    packed-switch v0, :pswitch_data_48

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p0, Lads_mobile_sdk/d13;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void

    :pswitch_10  #0x7
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {p0, p1}, Lbw2;->a(Ljava/lang/String;)V

    return-void

    :pswitch_17  #0x6
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {p0, p1}, Lbw2;->a(Ljava/lang/String;)V

    return-void

    :pswitch_1e  #0x5
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {p0, p1}, Lbw2;->a(Ljava/lang/String;)V

    return-void

    :pswitch_25  #0x4
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {p0, p1}, Lbw2;->a(Ljava/lang/String;)V

    return-void

    :pswitch_2c  #0x3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {p0, p1}, Lbw2;->a(Ljava/lang/String;)V

    return-void

    :pswitch_33  #0x2
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {p0, p1}, Lbw2;->a(Ljava/lang/String;)V

    return-void

    :pswitch_3a  #0x1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {p0, p1}, Lbw2;->a(Ljava/lang/String;)V

    return-void

    :pswitch_41  #0x0
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {p0, p1}, Lbw2;->a(Ljava/lang/String;)V

    return-void

    :pswitch_data_48
    .packed-switch 0x0
        :pswitch_41  #00000000
        :pswitch_3a  #00000001
        :pswitch_33  #00000002
        :pswitch_2c  #00000003
        :pswitch_25  #00000004
        :pswitch_1e  #00000005
        :pswitch_17  #00000006
        :pswitch_10  #00000007
    .end packed-switch
.end method

.method public final b()I
    .registers 2

    .prologue
    iget v0, p0, Lads_mobile_sdk/ez1;->b:I

    iget-object p0, p0, Lads_mobile_sdk/ez1;->a:Lbw2;

    packed-switch v0, :pswitch_data_38

    check-cast p0, Lads_mobile_sdk/d13;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 p0, 0x30

    return p0

    :pswitch_f  #0x7
    invoke-interface {p0}, Lbw2;->b()I

    move-result p0

    return p0

    :pswitch_14  #0x6
    invoke-interface {p0}, Lbw2;->b()I

    move-result p0

    return p0

    :pswitch_19  #0x5
    invoke-interface {p0}, Lbw2;->b()I

    move-result p0

    return p0

    :pswitch_1e  #0x4
    invoke-interface {p0}, Lbw2;->b()I

    move-result p0

    return p0

    :pswitch_23  #0x3
    invoke-interface {p0}, Lbw2;->b()I

    move-result p0

    return p0

    :pswitch_28  #0x2
    invoke-interface {p0}, Lbw2;->b()I

    move-result p0

    return p0

    :pswitch_2d  #0x1
    invoke-interface {p0}, Lbw2;->b()I

    move-result p0

    return p0

    :pswitch_32  #0x0
    invoke-interface {p0}, Lbw2;->b()I

    move-result p0

    return p0

    nop

    :pswitch_data_38
    .packed-switch 0x0
        :pswitch_32  #00000000
        :pswitch_2d  #00000001
        :pswitch_28  #00000002
        :pswitch_23  #00000003
        :pswitch_1e  #00000004
        :pswitch_19  #00000005
        :pswitch_14  #00000006
        :pswitch_f  #00000007
    .end packed-switch
.end method

.method public final c()Z
    .registers 2

    .prologue
    iget v0, p0, Lads_mobile_sdk/ez1;->b:I

    iget-object p0, p0, Lads_mobile_sdk/ez1;->a:Lbw2;

    packed-switch v0, :pswitch_data_36

    check-cast p0, Lads_mobile_sdk/d13;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 p0, 0x0

    return p0

    :pswitch_e  #0x7
    invoke-interface {p0}, Lbw2;->c()Z

    move-result p0

    return p0

    :pswitch_13  #0x6
    invoke-interface {p0}, Lbw2;->c()Z

    move-result p0

    return p0

    :pswitch_18  #0x5
    invoke-interface {p0}, Lbw2;->c()Z

    move-result p0

    return p0

    :pswitch_1d  #0x4
    invoke-interface {p0}, Lbw2;->c()Z

    move-result p0

    return p0

    :pswitch_22  #0x3
    invoke-interface {p0}, Lbw2;->c()Z

    move-result p0

    return p0

    :pswitch_27  #0x2
    invoke-interface {p0}, Lbw2;->c()Z

    move-result p0

    return p0

    :pswitch_2c  #0x1
    invoke-interface {p0}, Lbw2;->c()Z

    move-result p0

    return p0

    :pswitch_31  #0x0
    invoke-interface {p0}, Lbw2;->c()Z

    move-result p0

    return p0

    :pswitch_data_36
    .packed-switch 0x0
        :pswitch_31  #00000000
        :pswitch_2c  #00000001
        :pswitch_27  #00000002
        :pswitch_22  #00000003
        :pswitch_1d  #00000004
        :pswitch_18  #00000005
        :pswitch_13  #00000006
        :pswitch_e  #00000007
    .end packed-switch
.end method

.method public final d()Ljava/lang/String;
    .registers 2

    .prologue
    iget v0, p0, Lads_mobile_sdk/ez1;->b:I

    iget-object p0, p0, Lads_mobile_sdk/ez1;->a:Lbw2;

    packed-switch v0, :pswitch_data_36

    check-cast p0, Lads_mobile_sdk/d13;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 p0, 0x0

    return-object p0

    :pswitch_e  #0x7
    invoke-interface {p0}, Lbw2;->d()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :pswitch_13  #0x6
    invoke-interface {p0}, Lbw2;->d()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :pswitch_18  #0x5
    invoke-interface {p0}, Lbw2;->d()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :pswitch_1d  #0x4
    invoke-interface {p0}, Lbw2;->d()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :pswitch_22  #0x3
    invoke-interface {p0}, Lbw2;->d()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :pswitch_27  #0x2
    invoke-interface {p0}, Lbw2;->d()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :pswitch_2c  #0x1
    invoke-interface {p0}, Lbw2;->d()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :pswitch_31  #0x0
    invoke-interface {p0}, Lbw2;->d()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :pswitch_data_36
    .packed-switch 0x0
        :pswitch_31  #00000000
        :pswitch_2c  #00000001
        :pswitch_27  #00000002
        :pswitch_22  #00000003
        :pswitch_1d  #00000004
        :pswitch_18  #00000005
        :pswitch_13  #00000006
        :pswitch_e  #00000007
    .end packed-switch
.end method
