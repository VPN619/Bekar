.class public final Lads_mobile_sdk/cj1;
.super Lads_mobile_sdk/h83;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static volatile f:Ljava/lang/Long;

.field public static final g:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lads_mobile_sdk/cj1;->g:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/reflect/Method;Lwy2;)V
    .registers 6

    .prologue
    sget-object p0, Lads_mobile_sdk/cj1;->f:Ljava/lang/Long;

    if-nez p0, :cond_20

    sget-object p0, Lads_mobile_sdk/cj1;->g:Ljava/lang/Object;

    monitor-enter p0

    :try_start_7
    sget-object v0, Lads_mobile_sdk/cj1;->f:Ljava/lang/Long;

    if-nez v0, :cond_1c

    const-string v0, ""

    const/4 v1, 0x0

    invoke-virtual {p1, v0, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Long;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sput-object p1, Lads_mobile_sdk/cj1;->f:Ljava/lang/Long;

    goto :goto_1c

    :catchall_1a
    move-exception p1

    goto :goto_1e

    :cond_1c
    :goto_1c
    monitor-exit p0

    goto :goto_20

    :goto_1e
    monitor-exit p0
    :try_end_1f
    .catchall {:try_start_7 .. :try_end_1f} :catchall_1a

    throw p1

    :cond_20
    :goto_20
    monitor-enter p2

    :try_start_21
    sget-object p0, Lads_mobile_sdk/cj1;->f:Ljava/lang/Long;

    if-eqz p0, :cond_42

    sget-object p0, Lads_mobile_sdk/cj1;->f:Ljava/lang/Long;

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide p0

    invoke-virtual {p2}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v0, p2, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v0, Lads_mobile_sdk/pd;

    invoke-static {v0}, Lads_mobile_sdk/pd;->c(Lads_mobile_sdk/pd;)I

    move-result v1

    const/high16 v2, 0x100000

    or-int/2addr v1, v2

    invoke-static {v0, v1}, Lads_mobile_sdk/pd;->r(Lads_mobile_sdk/pd;I)V

    invoke-static {v0, p0, p1}, Lads_mobile_sdk/pd;->G(Lads_mobile_sdk/pd;J)V

    goto :goto_42

    :catchall_40
    move-exception p0

    goto :goto_44

    :cond_42
    :goto_42
    monitor-exit p2

    return-void

    :goto_44
    monitor-exit p2
    :try_end_45
    .catchall {:try_start_21 .. :try_end_45} :catchall_40

    throw p0
.end method
