.class public final Lads_mobile_sdk/ab;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final b:Ljava/util/LinkedHashMap;


# direct methods
.method public constructor <init>(Lur1;Ljava/util/LinkedHashMap;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iget-wide v0, p1, Lur1;->a:J

    invoke-static {v0, v1}, Lv60;->e(J)J

    iput-object p2, p0, Lads_mobile_sdk/ab;->b:Ljava/util/LinkedHashMap;

    return-void
.end method
