.class public final Lads_mobile_sdk/a72;
.super Lwx;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public a:Ljava/lang/Object;

.field public b:Lads_mobile_sdk/sy0;

.field public c:Lnb1;

.field public synthetic d:Ljava/lang/Object;

.field public final synthetic e:Lads_mobile_sdk/f72;

.field public f:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/f72;Lwx;)V
    .registers 3

    iput-object p1, p0, Lads_mobile_sdk/a72;->e:Lads_mobile_sdk/f72;

    invoke-direct {p0, p2}, Lwx;-><init>(Lvx;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    iput-object p1, p0, Lads_mobile_sdk/a72;->d:Ljava/lang/Object;

    iget p1, p0, Lads_mobile_sdk/a72;->f:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, Lads_mobile_sdk/a72;->f:I

    iget-object p1, p0, Lads_mobile_sdk/a72;->e:Lads_mobile_sdk/f72;

    const/4 v0, 0x0

    invoke-static {p1, v0, p0}, Lads_mobile_sdk/f72;->a(Lads_mobile_sdk/f72;Lads_mobile_sdk/sy0;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
