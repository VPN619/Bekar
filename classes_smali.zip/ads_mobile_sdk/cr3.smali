.class public final Lads_mobile_sdk/cr3;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:I

.field public final b:I

.field public final c:I

.field public final d:Z


# direct methods
.method public synthetic constructor <init>(IIII)V
    .registers 7

    .prologue
    and-int/lit8 v0, p4, 0x2

    const/4 v1, 0x0

    if-eqz v0, :cond_6

    move p2, v1

    :cond_6
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_b

    move p3, v1

    :cond_b
    invoke-direct {p0, p1, p2, p3, v1}, Lads_mobile_sdk/cr3;-><init>(IIIZ)V

    return-void
.end method

.method public constructor <init>(IIIZ)V
    .registers 5

    .prologue
    if-eqz p1, :cond_e

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lads_mobile_sdk/cr3;->a:I

    iput p2, p0, Lads_mobile_sdk/cr3;->b:I

    iput p3, p0, Lads_mobile_sdk/cr3;->c:I

    iput-boolean p4, p0, Lads_mobile_sdk/cr3;->d:Z

    return-void

    :cond_e
    const/4 p0, 0x0

    throw p0
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    .prologue
    if-ne p0, p1, :cond_3

    goto :goto_27

    :cond_3
    instance-of v0, p1, Lads_mobile_sdk/cr3;

    if-nez v0, :cond_8

    goto :goto_25

    :cond_8
    check-cast p1, Lads_mobile_sdk/cr3;

    iget v0, p0, Lads_mobile_sdk/cr3;->a:I

    iget v1, p1, Lads_mobile_sdk/cr3;->a:I

    if-eq v0, v1, :cond_11

    goto :goto_25

    :cond_11
    iget v0, p0, Lads_mobile_sdk/cr3;->b:I

    iget v1, p1, Lads_mobile_sdk/cr3;->b:I

    if-eq v0, v1, :cond_18

    goto :goto_25

    :cond_18
    iget v0, p0, Lads_mobile_sdk/cr3;->c:I

    iget v1, p1, Lads_mobile_sdk/cr3;->c:I

    if-eq v0, v1, :cond_1f

    goto :goto_25

    :cond_1f
    iget-boolean p0, p0, Lads_mobile_sdk/cr3;->d:Z

    iget-boolean p1, p1, Lads_mobile_sdk/cr3;->d:Z

    if-eq p0, p1, :cond_27

    :goto_25
    const/4 p0, 0x0

    return p0

    :cond_27
    :goto_27
    const/4 p0, 0x1

    return p0
.end method

.method public final hashCode()I
    .registers 3

    .prologue
    iget v0, p0, Lads_mobile_sdk/cr3;->a:I

    invoke-static {v0}, Lc33;->x(I)I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, Lads_mobile_sdk/cr3;->b:I

    invoke-static {v1, v0}, Lsz;->c(II)I

    move-result v0

    iget v1, p0, Lads_mobile_sdk/cr3;->c:I

    invoke-static {v1, v0}, Lsz;->c(II)I

    move-result v0

    iget-boolean p0, p0, Lads_mobile_sdk/cr3;->d:Z

    if-eqz p0, :cond_19

    const/4 p0, 0x1

    :cond_19
    add-int/2addr v0, p0

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 4

    .prologue
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "WebViewSize(type="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x1

    iget v2, p0, Lads_mobile_sdk/cr3;->a:I

    if-eq v2, v1, :cond_27

    const/4 v1, 0x2

    if-eq v2, v1, :cond_24

    const/4 v1, 0x3

    if-eq v2, v1, :cond_21

    const/4 v1, 0x4

    if-eq v2, v1, :cond_1e

    const/4 v1, 0x5

    if-eq v2, v1, :cond_1b

    const-string v1, "null"

    goto :goto_29

    :cond_1b
    const-string v1, "VIDEO_RECT"

    goto :goto_29

    :cond_1e
    const-string v1, "FULLSCREEN"

    goto :goto_29

    :cond_21
    const-string v1, "FLUID_RECTANGLE"

    goto :goto_29

    :cond_24
    const-string v1, "FIXED_RECTANGLE"

    goto :goto_29

    :cond_27
    const-string v1, "DEFAULT"

    :goto_29
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", widthInPixels="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lads_mobile_sdk/cr3;->b:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", heightInPixels="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lads_mobile_sdk/cr3;->c:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", isFluidHeight="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean p0, p0, Lads_mobile_sdk/cr3;->d:Z

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
