.class public final Lads_mobile_sdk/ar2;
.super Lads_mobile_sdk/h83;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final f:Landroid/content/Context;

.field public final g:Ljava/util/Map;

.field public final synthetic k:I


# direct methods
.method public constructor <init>(Lwy2;Lads_mobile_sdk/rp1;Ljava/util/Map;Landroid/content/Context;Lads_mobile_sdk/th3;I)V
    .registers 13

    .prologue
    iput p6, p0, Lads_mobile_sdk/ar2;->k:I

    packed-switch p6, :pswitch_data_30

    sget-object v2, Lads_mobile_sdk/fl0;->y:Lads_mobile_sdk/fl0;

    invoke-virtual {p5, v2}, Lads_mobile_sdk/th3;->a(Lads_mobile_sdk/fl0;)Lads_mobile_sdk/qg3;

    move-result-object v5

    const-string v1, "LXAGrDyq8uBR9lvZJYWAysh5P0qouDBaMfI0xZ70q2YxRm2wvGpCcvFr+c6FaGMk"

    const-string v2, "eGJT9CdMpeNLCsYGnC6x8Hz6Uym+8x0ExZW22Gs8DPI="

    move-object v0, p0

    move-object v3, p1

    move-object v4, p2

    invoke-direct/range {v0 .. v5}, Lads_mobile_sdk/h83;-><init>(Ljava/lang/String;Ljava/lang/String;Lwy2;Lads_mobile_sdk/rp1;Lads_mobile_sdk/qg3;)V

    iput-object p4, p0, Lads_mobile_sdk/ar2;->f:Landroid/content/Context;

    iput-object p3, p0, Lads_mobile_sdk/ar2;->g:Ljava/util/Map;

    return-void

    :pswitch_1a  #0x1
    sget-object v2, Lads_mobile_sdk/fl0;->E:Lads_mobile_sdk/fl0;

    invoke-virtual {p5, v2}, Lads_mobile_sdk/th3;->a(Lads_mobile_sdk/fl0;)Lads_mobile_sdk/qg3;

    move-result-object v5

    const-string v1, "mle2s8YAwMmQf4ngMkrNv0n99qiagpWzxikCcE7aaWHYwRVzM54GnfvPzkiigYyj"

    const-string v2, "Ug8CS9ZjKQEF0QVbPl+efqPj9yBSAQ7bn50twdNicyo="

    move-object v0, p0

    move-object v3, p1

    move-object v4, p2

    invoke-direct/range {v0 .. v5}, Lads_mobile_sdk/h83;-><init>(Ljava/lang/String;Ljava/lang/String;Lwy2;Lads_mobile_sdk/rp1;Lads_mobile_sdk/qg3;)V

    iput-object p3, p0, Lads_mobile_sdk/ar2;->g:Ljava/util/Map;

    iput-object p4, p0, Lads_mobile_sdk/ar2;->f:Landroid/content/Context;

    return-void

    nop

    :pswitch_data_30
    .packed-switch 0x1
        :pswitch_1a  #00000001
    .end packed-switch
.end method


# virtual methods
.method public final a(Ljava/lang/reflect/Method;Lwy2;)V
    .registers 8

    .prologue
    iget v0, p0, Lads_mobile_sdk/ar2;->k:I

    const/4 v1, 0x1

    const/4 v2, 0x0

    packed-switch v0, :pswitch_data_10a

    iget-object v0, p0, Lads_mobile_sdk/ar2;->g:Ljava/util/Map;

    const-string v3, "evt"

    invoke-interface {v0, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/InputEvent;

    iget-object p0, p0, Lads_mobile_sdk/ar2;->f:Landroid/content/Context;

    filled-new-array {v0, p0}, [Ljava/lang/Object;

    move-result-object p0

    const-string v0, ""

    invoke-virtual {p1, v0, p0}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p0, [Ljava/lang/Object;

    invoke-static {}, Lads_mobile_sdk/vc;->o()Lm53;

    move-result-object p1

    aget-object v0, p0, v2

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    invoke-virtual {p1}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v0, p1, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v0, Lads_mobile_sdk/vc;

    invoke-static {v0}, Lads_mobile_sdk/vc;->c(Lads_mobile_sdk/vc;)I

    move-result v4

    or-int/2addr v4, v1

    invoke-static {v0, v4}, Lads_mobile_sdk/vc;->d(Lads_mobile_sdk/vc;I)V

    invoke-static {v0, v2, v3}, Lads_mobile_sdk/vc;->g(Lads_mobile_sdk/vc;J)V

    aget-object v0, p0, v1

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Long;->intValue()I

    move-result v0

    invoke-static {v0}, Lrt2;->_a$1(I)I

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_a8

    invoke-virtual {p1}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v2, p1, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v2, Lads_mobile_sdk/vc;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v0}, Lrt2;->a(I)I

    move-result v0

    invoke-static {v2, v0}, Lads_mobile_sdk/vc;->f(Lads_mobile_sdk/vc;I)V

    invoke-static {v2}, Lads_mobile_sdk/vc;->c(Lads_mobile_sdk/vc;)I

    move-result v0

    const/4 v3, 0x2

    or-int/2addr v0, v3

    invoke-static {v2, v0}, Lads_mobile_sdk/vc;->d(Lads_mobile_sdk/vc;I)V

    aget-object p0, p0, v3

    check-cast p0, Ljava/lang/Long;

    invoke-virtual {p0}, Ljava/lang/Long;->intValue()I

    move-result p0

    invoke-static {p0}, Lrt2;->_a$1(I)I

    move-result p0

    if-eqz p0, :cond_a7

    invoke-virtual {p1}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v0, p1, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v0, Lads_mobile_sdk/vc;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p0}, Lrt2;->a(I)I

    move-result p0

    invoke-static {v0, p0}, Lads_mobile_sdk/vc;->h(Lads_mobile_sdk/vc;I)V

    invoke-static {v0}, Lads_mobile_sdk/vc;->c(Lads_mobile_sdk/vc;)I

    move-result p0

    or-int/lit8 p0, p0, 0x4

    invoke-static {v0, p0}, Lads_mobile_sdk/vc;->d(Lads_mobile_sdk/vc;I)V

    monitor-enter p2

    :try_start_92
    invoke-virtual {p1}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/vc;

    invoke-virtual {p2}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object p1, p2, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast p1, Lads_mobile_sdk/pd;

    invoke-virtual {p1, p0}, Lads_mobile_sdk/pd;->a(Lads_mobile_sdk/vc;)V

    monitor-exit p2

    return-void

    :catchall_a4
    move-exception p0

    monitor-exit p2
    :try_end_a6
    .catchall {:try_start_92 .. :try_end_a6} :catchall_a4

    throw p0

    :cond_a7
    throw v1

    :cond_a8
    throw v1

    :pswitch_a9  #0x0
    const-wide/16 v3, -0x1

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    :try_start_af
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v4, 0x1e

    if-lt v3, v4, :cond_c8

    const-string v3, ""

    new-array v1, v1, [Ljava/lang/Object;

    iget-object p0, p0, Lads_mobile_sdk/ar2;->f:Landroid/content/Context;

    aput-object p0, v1, v2

    invoke-virtual {p1, v3, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Long;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :goto_c6
    move-object v0, p0

    goto :goto_eb

    :cond_c8
    iget-object p0, p0, Lads_mobile_sdk/ar2;->g:Ljava/util/Map;

    const-string p1, "gs"

    invoke-interface {p0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ld31;

    if-eqz p0, :cond_eb

    invoke-interface {p0}, Ljava/util/concurrent/Future;->isDone()Z

    move-result p1

    if-eqz p1, :cond_eb

    invoke-interface {p0}, Ljava/util/concurrent/Future;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/pd;

    if-eqz p0, :cond_eb

    invoke-virtual {p0}, Lads_mobile_sdk/pd;->s()J

    move-result-wide p0

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0
    :try_end_ea
    .catch Ljava/lang/InterruptedException; {:try_start_af .. :try_end_ea} :catch_eb
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_af .. :try_end_ea} :catch_eb

    goto :goto_c6

    :catch_eb
    :cond_eb
    :goto_eb
    monitor-enter p2

    :try_start_ec
    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide p0

    invoke-virtual {p2}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v0, p2, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v0, Lads_mobile_sdk/pd;

    invoke-static {v0}, Lads_mobile_sdk/pd;->d(Lads_mobile_sdk/pd;)I

    move-result v1

    const/high16 v2, 0x1000000

    or-int/2addr v1, v2

    invoke-static {v0, v1}, Lads_mobile_sdk/pd;->s(Lads_mobile_sdk/pd;I)V

    invoke-static {v0, p0, p1}, Lads_mobile_sdk/pd;->O(Lads_mobile_sdk/pd;J)V

    monitor-exit p2

    return-void

    :catchall_106
    move-exception p0

    monitor-exit p2
    :try_end_108
    .catchall {:try_start_ec .. :try_end_108} :catchall_106

    throw p0

    nop

    :pswitch_data_10a
    .packed-switch 0x0
        :pswitch_a9  #00000000
    .end packed-switch
.end method
