.class public final Lads_mobile_sdk/aa2;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lb23;


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Ljava/lang/String;

.field public final c:Ljava/lang/Integer;

.field public final d:Ljava/lang/String;

.field public final e:Ljava/lang/String;

.field public final f:Ljava/lang/String;

.field public final g:Ljava/lang/String;

.field public final h:Ljava/lang/String;

.field public final i:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 10

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/aa2;->a:Ljava/lang/String;

    iput-object p2, p0, Lads_mobile_sdk/aa2;->b:Ljava/lang/String;

    iput-object p3, p0, Lads_mobile_sdk/aa2;->c:Ljava/lang/Integer;

    iput-object p4, p0, Lads_mobile_sdk/aa2;->d:Ljava/lang/String;

    iput-object p5, p0, Lads_mobile_sdk/aa2;->e:Ljava/lang/String;

    iput-object p6, p0, Lads_mobile_sdk/aa2;->f:Ljava/lang/String;

    iput-object p7, p0, Lads_mobile_sdk/aa2;->g:Ljava/lang/String;

    iput-object p8, p0, Lads_mobile_sdk/aa2;->h:Ljava/lang/String;

    iput-object p9, p0, Lads_mobile_sdk/aa2;->i:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final a(Lg32;)V
    .registers 3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Lads_mobile_sdk/aa2;->a:Ljava/lang/String;

    iput-object v0, p1, Lg32;->x0:Ljava/lang/String;

    iget-object v0, p0, Lads_mobile_sdk/aa2;->b:Ljava/lang/String;

    iput-object v0, p1, Lg32;->A0:Ljava/lang/String;

    iget-object v0, p0, Lads_mobile_sdk/aa2;->c:Ljava/lang/Integer;

    iput-object v0, p1, Lg32;->y0:Ljava/lang/Integer;

    iget-object v0, p0, Lads_mobile_sdk/aa2;->d:Ljava/lang/String;

    iput-object v0, p1, Lg32;->B0:Ljava/lang/String;

    iget-object v0, p0, Lads_mobile_sdk/aa2;->e:Ljava/lang/String;

    iput-object v0, p1, Lg32;->K1:Ljava/lang/String;

    iget-object v0, p0, Lads_mobile_sdk/aa2;->f:Ljava/lang/String;

    iput-object v0, p1, Lg32;->L1:Ljava/lang/String;

    iget-object v0, p0, Lads_mobile_sdk/aa2;->g:Ljava/lang/String;

    iput-object v0, p1, Lg32;->z0:Ljava/lang/String;

    iget-object v0, p0, Lads_mobile_sdk/aa2;->h:Ljava/lang/String;

    iput-object v0, p1, Lg32;->J0:Ljava/lang/String;

    iget-object p0, p0, Lads_mobile_sdk/aa2;->i:Ljava/lang/String;

    iput-object p0, p1, Lg32;->K0:Ljava/lang/String;

    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    .prologue
    if-ne p0, p1, :cond_4

    goto/16 :goto_70

    :cond_4
    instance-of v0, p1, Lads_mobile_sdk/aa2;

    if-nez v0, :cond_a

    goto/16 :goto_6e

    :cond_a
    check-cast p1, Lads_mobile_sdk/aa2;

    iget-object v0, p0, Lads_mobile_sdk/aa2;->a:Ljava/lang/String;

    iget-object v1, p1, Lads_mobile_sdk/aa2;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_17

    goto :goto_6e

    :cond_17
    iget-object v0, p0, Lads_mobile_sdk/aa2;->b:Ljava/lang/String;

    iget-object v1, p1, Lads_mobile_sdk/aa2;->b:Ljava/lang/String;

    invoke-static {v0, v1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_22

    goto :goto_6e

    :cond_22
    iget-object v0, p0, Lads_mobile_sdk/aa2;->c:Ljava/lang/Integer;

    iget-object v1, p1, Lads_mobile_sdk/aa2;->c:Ljava/lang/Integer;

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2d

    goto :goto_6e

    :cond_2d
    iget-object v0, p0, Lads_mobile_sdk/aa2;->d:Ljava/lang/String;

    iget-object v1, p1, Lads_mobile_sdk/aa2;->d:Ljava/lang/String;

    invoke-static {v0, v1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_38

    goto :goto_6e

    :cond_38
    iget-object v0, p0, Lads_mobile_sdk/aa2;->e:Ljava/lang/String;

    iget-object v1, p1, Lads_mobile_sdk/aa2;->e:Ljava/lang/String;

    invoke-static {v0, v1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_43

    goto :goto_6e

    :cond_43
    iget-object v0, p0, Lads_mobile_sdk/aa2;->f:Ljava/lang/String;

    iget-object v1, p1, Lads_mobile_sdk/aa2;->f:Ljava/lang/String;

    invoke-static {v0, v1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_4e

    goto :goto_6e

    :cond_4e
    iget-object v0, p0, Lads_mobile_sdk/aa2;->g:Ljava/lang/String;

    iget-object v1, p1, Lads_mobile_sdk/aa2;->g:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_59

    goto :goto_6e

    :cond_59
    iget-object v0, p0, Lads_mobile_sdk/aa2;->h:Ljava/lang/String;

    iget-object v1, p1, Lads_mobile_sdk/aa2;->h:Ljava/lang/String;

    invoke-static {v0, v1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_64

    goto :goto_6e

    :cond_64
    iget-object p0, p0, Lads_mobile_sdk/aa2;->i:Ljava/lang/String;

    iget-object p1, p1, Lads_mobile_sdk/aa2;->i:Ljava/lang/String;

    invoke-static {p0, p1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_70

    :goto_6e
    const/4 p0, 0x0

    return p0

    :cond_70
    :goto_70
    const/4 p0, 0x1

    return p0
.end method

.method public final hashCode()I
    .registers 5

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/aa2;->a:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/16 v1, 0x1f

    mul-int/2addr v0, v1

    const/4 v2, 0x0

    iget-object v3, p0, Lads_mobile_sdk/aa2;->b:Ljava/lang/String;

    if-nez v3, :cond_10

    move v3, v2

    goto :goto_14

    :cond_10
    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    move-result v3

    :goto_14
    add-int/2addr v0, v3

    mul-int/2addr v0, v1

    iget-object v3, p0, Lads_mobile_sdk/aa2;->c:Ljava/lang/Integer;

    invoke-virtual {v3}, Ljava/lang/Object;->hashCode()I

    move-result v3

    add-int/2addr v3, v0

    mul-int/2addr v3, v1

    iget-object v0, p0, Lads_mobile_sdk/aa2;->d:Ljava/lang/String;

    if-nez v0, :cond_24

    move v0, v2

    goto :goto_28

    :cond_24
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    :goto_28
    add-int/2addr v3, v0

    mul-int/2addr v3, v1

    iget-object v0, p0, Lads_mobile_sdk/aa2;->e:Ljava/lang/String;

    if-nez v0, :cond_30

    move v0, v2

    goto :goto_34

    :cond_30
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    :goto_34
    add-int/2addr v3, v0

    mul-int/2addr v3, v1

    iget-object v0, p0, Lads_mobile_sdk/aa2;->f:Ljava/lang/String;

    if-nez v0, :cond_3c

    move v0, v2

    goto :goto_40

    :cond_3c
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    :goto_40
    add-int/2addr v3, v0

    mul-int/2addr v3, v1

    iget-object v0, p0, Lads_mobile_sdk/aa2;->g:Ljava/lang/String;

    invoke-static {v3, v1, v0}, Ly41;->j(IILjava/lang/String;)I

    move-result v0

    iget-object v3, p0, Lads_mobile_sdk/aa2;->h:Ljava/lang/String;

    if-nez v3, :cond_4e

    move v3, v2

    goto :goto_52

    :cond_4e
    invoke-virtual {v3}, Ljava/lang/String;->hashCode()I

    move-result v3

    :goto_52
    add-int/2addr v0, v3

    mul-int/2addr v0, v1

    iget-object p0, p0, Lads_mobile_sdk/aa2;->i:Ljava/lang/String;

    if-nez p0, :cond_59

    goto :goto_5d

    :cond_59
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result v2

    :goto_5d
    add-int/2addr v0, v2

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 6

    const-string v0, ", versionName="

    const-string v1, ", versionCode="

    const-string v2, "PackageInfoSignal(packageName="

    iget-object v3, p0, Lads_mobile_sdk/aa2;->a:Ljava/lang/String;

    iget-object v4, p0, Lads_mobile_sdk/aa2;->b:Ljava/lang/String;

    invoke-static {v2, v3, v0, v4, v1}, Ly41;->t(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, p0, Lads_mobile_sdk/aa2;->c:Ljava/lang/Integer;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", displayLabel="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lads_mobile_sdk/aa2;->d:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", installerPackage="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", initiatorPackage="

    const-string v2, ", appName="

    iget-object v3, p0, Lads_mobile_sdk/aa2;->e:Ljava/lang/String;

    iget-object v4, p0, Lads_mobile_sdk/aa2;->f:Ljava/lang/String;

    invoke-static {v0, v3, v1, v4, v2}, Ly41;->x(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v1, ", appWebPropertyCode="

    const-string v2, ", applicationCode="

    iget-object v3, p0, Lads_mobile_sdk/aa2;->g:Ljava/lang/String;

    iget-object v4, p0, Lads_mobile_sdk/aa2;->h:Ljava/lang/String;

    invoke-static {v0, v3, v1, v4, v2}, Ly41;->x(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string v1, ")"

    iget-object p0, p0, Lads_mobile_sdk/aa2;->i:Ljava/lang/String;

    invoke-static {v0, p0, v1}, Ly41;->s(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
