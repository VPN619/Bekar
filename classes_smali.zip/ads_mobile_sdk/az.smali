.class public final Lads_mobile_sdk/az;
.super Lwx;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public a:Lads_mobile_sdk/av0;

.field public synthetic b:Ljava/lang/Object;

.field public final synthetic c:Lads_mobile_sdk/vz;

.field public d:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/vz;Lwx;)V
    .registers 3

    iput-object p1, p0, Lads_mobile_sdk/az;->c:Lads_mobile_sdk/vz;

    invoke-direct {p0, p2}, Lwx;-><init>(Lvx;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    iput-object p1, p0, Lads_mobile_sdk/az;->b:Ljava/lang/Object;

    iget p1, p0, Lads_mobile_sdk/az;->d:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, Lads_mobile_sdk/az;->d:I

    iget-object p1, p0, Lads_mobile_sdk/az;->c:Lads_mobile_sdk/vz;

    const/4 v0, 0x0

    invoke-virtual {p1, v0, p0}, Lads_mobile_sdk/vz;->a(Lads_mobile_sdk/av0;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
