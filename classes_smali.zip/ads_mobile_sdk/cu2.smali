.class public final Lads_mobile_sdk/cu2;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final synthetic b:[Liy0;


# instance fields
.field public final a:Lads_mobile_sdk/ji;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    const-string v0, "requestConfiguration"

    const-string v1, "getRequestConfiguration()Lcom/google/android/libraries/ads/mobile/sdk/common/RequestConfiguration;"

    const-class v2, Lads_mobile_sdk/cu2;

    invoke-static {v0, v1, v2}, Lv13;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Class;)Lhb1;

    move-result-object v0

    const/4 v1, 0x1

    new-array v1, v1, [Liy0;

    const/4 v2, 0x0

    aput-object v0, v1, v2

    sput-object v1, Lads_mobile_sdk/cu2;->b:[Liy0;

    return-void
.end method

.method public constructor <init>()V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lads_mobile_sdk/ji;

    const-string v1, "B3EEABB8EE11C2BE770B684D95219ECB"

    filled-new-array {v1}, [Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/util/ArrayList;

    new-instance v3, Lie;

    const/4 v4, 0x1

    invoke-direct {v3, v1, v4}, Lie;-><init>([Ljava/lang/Object;Z)V

    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    new-instance v1, Lut1;

    sget-object v3, Lqt1;->b:Lqt1;

    sget-object v4, Lrt1;->b:Lrt1;

    invoke-direct {v1, v3, v2, v4}, Lut1;-><init>(Lqt1;Ljava/util/ArrayList;Lrt1;)V

    const/4 v2, 0x0

    invoke-direct {v0, v2, v1}, Lads_mobile_sdk/ji;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    iput-object v0, p0, Lads_mobile_sdk/cu2;->a:Lads_mobile_sdk/ji;

    return-void
.end method


# virtual methods
.method public final a()Lut1;
    .registers 3

    sget-object v0, Lads_mobile_sdk/cu2;->b:[Liy0;

    const/4 v1, 0x0

    aget-object v0, v0, v1

    iget-object v1, p0, Lads_mobile_sdk/cu2;->a:Lads_mobile_sdk/ji;

    invoke-virtual {v1, p0, v0}, Lads_mobile_sdk/ji;->getValue(Ljava/lang/Object;Liy0;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lut1;

    return-object p0
.end method
