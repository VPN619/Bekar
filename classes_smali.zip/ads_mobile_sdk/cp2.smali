.class public final Lads_mobile_sdk/cp2;
.super Ljava/util/concurrent/CancellationException;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lox2;


# instance fields
.field public final a:Ljava/util/concurrent/CancellationException;


# direct methods
.method public constructor <init>(Ljava/util/concurrent/CancellationException;)V
    .registers 3

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Ljava/util/concurrent/CancellationException;-><init>(Ljava/lang/String;)V

    iput-object p1, p0, Lads_mobile_sdk/cp2;->a:Ljava/util/concurrent/CancellationException;

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Throwable;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/cp2;->a:Ljava/util/concurrent/CancellationException;

    return-object p0
.end method
