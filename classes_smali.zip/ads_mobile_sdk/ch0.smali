.class public final Lads_mobile_sdk/ch0;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public final synthetic a:Lads_mobile_sdk/ph0;

.field public final synthetic t:I


# direct methods
.method public synthetic constructor <init>(Lads_mobile_sdk/ph0;Lvx;I)V
    .registers 4

    iput p3, p0, Lads_mobile_sdk/ch0;->t:I

    iput-object p1, p0, Lads_mobile_sdk/ch0;->a:Lads_mobile_sdk/ph0;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 4

    .prologue
    iget p2, p0, Lads_mobile_sdk/ch0;->t:I

    iget-object p0, p0, Lads_mobile_sdk/ch0;->a:Lads_mobile_sdk/ph0;

    packed-switch p2, :pswitch_data_38

    new-instance p2, Lads_mobile_sdk/ch0;

    const/4 v0, 0x6

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/ch0;-><init>(Lads_mobile_sdk/ph0;Lvx;I)V

    return-object p2

    :pswitch_e  #0x5
    new-instance p2, Lads_mobile_sdk/ch0;

    const/4 v0, 0x5

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/ch0;-><init>(Lads_mobile_sdk/ph0;Lvx;I)V

    return-object p2

    :pswitch_15  #0x4
    new-instance p2, Lads_mobile_sdk/ch0;

    const/4 v0, 0x4

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/ch0;-><init>(Lads_mobile_sdk/ph0;Lvx;I)V

    return-object p2

    :pswitch_1c  #0x3
    new-instance p2, Lads_mobile_sdk/ch0;

    const/4 v0, 0x3

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/ch0;-><init>(Lads_mobile_sdk/ph0;Lvx;I)V

    return-object p2

    :pswitch_23  #0x2
    new-instance p2, Lads_mobile_sdk/ch0;

    const/4 v0, 0x2

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/ch0;-><init>(Lads_mobile_sdk/ph0;Lvx;I)V

    return-object p2

    :pswitch_2a  #0x1
    new-instance p2, Lads_mobile_sdk/ch0;

    const/4 v0, 0x1

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/ch0;-><init>(Lads_mobile_sdk/ph0;Lvx;I)V

    return-object p2

    :pswitch_31  #0x0
    new-instance p2, Lads_mobile_sdk/ch0;

    const/4 v0, 0x0

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/ch0;-><init>(Lads_mobile_sdk/ph0;Lvx;I)V

    return-object p2

    :pswitch_data_38
    .packed-switch 0x0
        :pswitch_31  #00000000
        :pswitch_2a  #00000001
        :pswitch_23  #00000002
        :pswitch_1c  #00000003
        :pswitch_15  #00000004
        :pswitch_e  #00000005
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .prologue
    iget v0, p0, Lads_mobile_sdk/ch0;->t:I

    sget-object v1, Lrg2;->a:Lrg2;

    iget-object p0, p0, Lads_mobile_sdk/ch0;->a:Lads_mobile_sdk/ph0;

    packed-switch v0, :pswitch_data_6c

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/ch0;

    const/4 v0, 0x6

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/ch0;-><init>(Lads_mobile_sdk/ph0;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/ch0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object v1

    :pswitch_17  #0x5
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/ch0;

    const/4 v0, 0x5

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/ch0;-><init>(Lads_mobile_sdk/ph0;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/ch0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object v1

    :pswitch_25  #0x4
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/ch0;

    const/4 v0, 0x4

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/ch0;-><init>(Lads_mobile_sdk/ph0;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/ch0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object v1

    :pswitch_33  #0x3
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/ch0;

    const/4 v0, 0x3

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/ch0;-><init>(Lads_mobile_sdk/ph0;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/ch0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object v1

    :pswitch_41  #0x2
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/ch0;

    const/4 v0, 0x2

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/ch0;-><init>(Lads_mobile_sdk/ph0;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/ch0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object v1

    :pswitch_4f  #0x1
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/ch0;

    const/4 v0, 0x1

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/ch0;-><init>(Lads_mobile_sdk/ph0;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/ch0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object v1

    :pswitch_5d  #0x0
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/ch0;

    const/4 v0, 0x0

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/ch0;-><init>(Lads_mobile_sdk/ph0;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/ch0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object v1

    nop

    :pswitch_data_6c
    .packed-switch 0x0
        :pswitch_5d  #00000000
        :pswitch_4f  #00000001
        :pswitch_41  #00000002
        :pswitch_33  #00000003
        :pswitch_25  #00000004
        :pswitch_17  #00000005
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .prologue
    iget v0, p0, Lads_mobile_sdk/ch0;->t:I

    packed-switch v0, :pswitch_data_9e

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p0, p0, Lads_mobile_sdk/ch0;->a:Lads_mobile_sdk/ph0;

    monitor-enter p0

    monitor-exit p0

    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0

    :pswitch_f  #0x5
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p0, p0, Lads_mobile_sdk/ch0;->a:Lads_mobile_sdk/ph0;

    invoke-virtual {p0}, Lads_mobile_sdk/ph0;->a()Lh4;

    move-result-object p0

    if-eqz p0, :cond_1d

    invoke-interface {p0}, Lh4;->onAdShowedFullScreenContent()V

    :cond_1d
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0

    :pswitch_20  #0x4
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    sget-object p1, Lads_mobile_sdk/ax0;->f:Lzn1;

    iget-object p1, p0, Lads_mobile_sdk/ch0;->a:Lads_mobile_sdk/ph0;

    sget-object v0, Lxf1;->b:Lxf1;

    invoke-virtual {p0}, Lwx;->getContext()Lly;

    move-result-object p0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v0, p0}, Lns2;->x(Ljy;Lly;)Lly;

    move-result-object p0

    sget-object v0, Lads_mobile_sdk/rh3;->b:Lyx1;

    invoke-interface {p0, v0}, Lly;->minusKey(Lky;)Lly;

    move-result-object p0

    sget-object v0, Ln8;->c:Ln8;

    invoke-interface {p0, v0}, Lly;->minusKey(Lky;)Lly;

    move-result-object p0

    sget-object v0, Lms1;->e:Lms1;

    invoke-interface {p0, v0}, Lly;->minusKey(Lky;)Lly;

    move-result-object p0

    invoke-static {p0}, Lw53;->a(Lly;)Lsx;

    move-result-object p0

    new-instance v0, Lads_mobile_sdk/ch0;

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {v0, p1, v1, v2}, Lads_mobile_sdk/ch0;-><init>(Lads_mobile_sdk/ph0;Lvx;I)V

    invoke-static {p0, v1, v1, v0, v2}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0

    :pswitch_57  #0x3
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p0, p0, Lads_mobile_sdk/ch0;->a:Lads_mobile_sdk/ph0;

    monitor-enter p0

    :try_start_5d
    iget-object p1, p0, Lads_mobile_sdk/ph0;->f:Lyu1;
    :try_end_5f
    .catchall {:try_start_5d .. :try_end_5f} :catchall_68

    monitor-exit p0

    if-eqz p1, :cond_65

    invoke-interface {p1}, Lyu1;->onAdMetadataChanged()V

    :cond_65
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0

    :catchall_68
    move-exception p1

    monitor-exit p0

    throw p1

    :pswitch_6b  #0x2
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p0, p0, Lads_mobile_sdk/ch0;->a:Lads_mobile_sdk/ph0;

    invoke-virtual {p0}, Lads_mobile_sdk/ph0;->a()Lh4;

    move-result-object p0

    if-eqz p0, :cond_79

    invoke-interface {p0}, Lh4;->onAdImpression()V

    :cond_79
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0

    :pswitch_7c  #0x1
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p0, p0, Lads_mobile_sdk/ch0;->a:Lads_mobile_sdk/ph0;

    invoke-virtual {p0}, Lads_mobile_sdk/ph0;->a()Lh4;

    move-result-object p0

    if-eqz p0, :cond_8a

    invoke-interface {p0}, Lh4;->onAdDismissedFullScreenContent()V

    :cond_8a
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0

    :pswitch_8d  #0x0
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p0, p0, Lads_mobile_sdk/ch0;->a:Lads_mobile_sdk/ph0;

    invoke-virtual {p0}, Lads_mobile_sdk/ph0;->a()Lh4;

    move-result-object p0

    if-eqz p0, :cond_9b

    invoke-interface {p0}, Lh4;->onAdClicked()V

    :cond_9b
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0

    :pswitch_data_9e
    .packed-switch 0x0
        :pswitch_8d  #00000000
        :pswitch_7c  #00000001
        :pswitch_6b  #00000002
        :pswitch_57  #00000003
        :pswitch_20  #00000004
        :pswitch_f  #00000005
    .end packed-switch
.end method
