.class public final Lads_mobile_sdk/fv0;
.super Lads_mobile_sdk/av0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final c:Ljava/lang/String;

.field public final d:Z


# direct methods
.method public constructor <init>(Ljava/lang/String;I)V
    .registers 3

    .prologue
    and-int/lit8 p2, p2, 0x1

    if-eqz p2, :cond_6

    const-string p1, "No fill."

    :cond_6
    const/4 p2, 0x0

    invoke-direct {p0, p1, p2}, Lads_mobile_sdk/fv0;-><init>(Ljava/lang/String;Z)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Z)V
    .registers 4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x3

    invoke-direct {p0, v0}, Lads_mobile_sdk/av0;-><init>(I)V

    iput-object p1, p0, Lads_mobile_sdk/fv0;->c:Ljava/lang/String;

    iput-boolean p2, p0, Lads_mobile_sdk/fv0;->d:Z

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    .prologue
    if-ne p0, p1, :cond_3

    goto :goto_1d

    :cond_3
    instance-of v0, p1, Lads_mobile_sdk/fv0;

    if-nez v0, :cond_8

    goto :goto_1b

    :cond_8
    check-cast p1, Lads_mobile_sdk/fv0;

    iget-object v0, p0, Lads_mobile_sdk/fv0;->c:Ljava/lang/String;

    iget-object v1, p1, Lads_mobile_sdk/fv0;->c:Ljava/lang/String;

    invoke-static {v0, v1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_15

    goto :goto_1b

    :cond_15
    iget-boolean p0, p0, Lads_mobile_sdk/fv0;->d:Z

    iget-boolean p1, p1, Lads_mobile_sdk/fv0;->d:Z

    if-eq p0, p1, :cond_1d

    :goto_1b
    const/4 p0, 0x0

    return p0

    :cond_1d
    :goto_1d
    const/4 p0, 0x1

    return p0
.end method

.method public final hashCode()I
    .registers 2

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/fv0;->c:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget-boolean p0, p0, Lads_mobile_sdk/fv0;->d:Z

    if-eqz p0, :cond_d

    const/4 p0, 0x1

    :cond_d
    add-int/2addr v0, p0

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "NoFillError(message="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lads_mobile_sdk/fv0;->c:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", isThrottled="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean p0, p0, Lads_mobile_sdk/fv0;->d:Z

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
