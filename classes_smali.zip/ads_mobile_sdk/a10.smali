.class public final Lads_mobile_sdk/a10;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpv2;


# instance fields
.field public final synthetic a:Ljava/lang/Object;

.field public final synthetic b:I


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    iput p1, p0, Lads_mobile_sdk/a10;->b:I

    iput-object p2, p0, Lads_mobile_sdk/a10;->a:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lc03;Lwx;)Ljava/lang/Object;
    .registers 13

    .prologue
    iget v0, p0, Lads_mobile_sdk/a10;->b:I

    sget-object v1, Lrg2;->a:Lrg2;

    iget-object v2, p0, Lads_mobile_sdk/a10;->a:Ljava/lang/Object;

    const-string v3, "call to \'resume\' before \'invoke\' with coroutine"

    sget-object v4, Lwy;->a:Lwy;

    const/high16 v5, -0x80000000

    const/4 v6, 0x1

    const/4 v7, 0x0

    packed-switch v0, :pswitch_data_104

    :pswitch_11  #0x1, 0x3
    instance-of v0, p2, Lads_mobile_sdk/n10;

    if-eqz v0, :cond_22

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/n10;

    iget v8, v0, Lads_mobile_sdk/n10;->c:I

    and-int v9, v8, v5

    if-eqz v9, :cond_22

    sub-int/2addr v8, v5

    iput v8, v0, Lads_mobile_sdk/n10;->c:I

    goto :goto_27

    :cond_22
    new-instance v0, Lads_mobile_sdk/n10;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/n10;-><init>(Lads_mobile_sdk/a10;Lwx;)V

    :goto_27
    iget-object p0, v0, Lads_mobile_sdk/n10;->a:Ljava/lang/Object;

    iget p2, v0, Lads_mobile_sdk/n10;->c:I

    if-eqz p2, :cond_38

    if-ne p2, v6, :cond_33

    invoke-static {p0}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_4d

    :cond_33
    invoke-static {v3}, Lz6;->w(Ljava/lang/String;)V

    move-object v1, v7

    goto :goto_4d

    :cond_38
    invoke-static {p0}, Lt12;->W(Ljava/lang/Object;)V

    new-instance p0, Lb11;

    check-cast v2, Lads_mobile_sdk/wr3;

    const/16 p2, 0x13

    invoke-direct {p0, v2, v7, p2}, Lb11;-><init>(Ljava/lang/Object;Lvx;I)V

    iput v6, v0, Lads_mobile_sdk/n10;->c:I

    invoke-interface {p1, p0, v0}, Lc03;->a(Lpk0;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v4, :cond_4d

    move-object v1, v4

    :cond_4d
    :goto_4d
    return-object v1

    :pswitch_4e  #0x4
    instance-of v0, p2, Lads_mobile_sdk/j10;

    if-eqz v0, :cond_5f

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/j10;

    iget v8, v0, Lads_mobile_sdk/j10;->c:I

    and-int v9, v8, v5

    if-eqz v9, :cond_5f

    sub-int/2addr v8, v5

    iput v8, v0, Lads_mobile_sdk/j10;->c:I

    goto :goto_64

    :cond_5f
    new-instance v0, Lads_mobile_sdk/j10;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/j10;-><init>(Lads_mobile_sdk/a10;Lwx;)V

    :goto_64
    iget-object p0, v0, Lads_mobile_sdk/j10;->a:Ljava/lang/Object;

    iget p2, v0, Lads_mobile_sdk/j10;->c:I

    if-eqz p2, :cond_75

    if-ne p2, v6, :cond_70

    invoke-static {p0}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_8a

    :cond_70
    invoke-static {v3}, Lz6;->w(Ljava/lang/String;)V

    move-object v1, v7

    goto :goto_8a

    :cond_75
    invoke-static {p0}, Lt12;->W(Ljava/lang/Object;)V

    new-instance p0, Lb11;

    check-cast v2, Lads_mobile_sdk/gp3;

    const/16 p2, 0xf

    invoke-direct {p0, v2, v7, p2}, Lb11;-><init>(Ljava/lang/Object;Lvx;I)V

    iput v6, v0, Lads_mobile_sdk/j10;->c:I

    invoke-interface {p1, p0, v0}, Lc03;->a(Lpk0;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v4, :cond_8a

    move-object v1, v4

    :cond_8a
    :goto_8a
    return-object v1

    :pswitch_8b  #0x2
    instance-of v0, p2, Lads_mobile_sdk/d10;

    if-eqz v0, :cond_9c

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/d10;

    iget v8, v0, Lads_mobile_sdk/d10;->c:I

    and-int v9, v8, v5

    if-eqz v9, :cond_9c

    sub-int/2addr v8, v5

    iput v8, v0, Lads_mobile_sdk/d10;->c:I

    goto :goto_a1

    :cond_9c
    new-instance v0, Lads_mobile_sdk/d10;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/d10;-><init>(Lads_mobile_sdk/a10;Lwx;)V

    :goto_a1
    iget-object p0, v0, Lads_mobile_sdk/d10;->a:Ljava/lang/Object;

    iget p2, v0, Lads_mobile_sdk/d10;->c:I

    if-eqz p2, :cond_b2

    if-ne p2, v6, :cond_ad

    invoke-static {p0}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_c7

    :cond_ad
    invoke-static {v3}, Lz6;->w(Ljava/lang/String;)V

    move-object v1, v7

    goto :goto_c7

    :cond_b2
    invoke-static {p0}, Lt12;->W(Ljava/lang/Object;)V

    new-instance p0, Lb11;

    check-cast v2, Lads_mobile_sdk/hr1;

    const/16 p2, 0x8

    invoke-direct {p0, v2, v7, p2}, Lb11;-><init>(Ljava/lang/Object;Lvx;I)V

    iput v6, v0, Lads_mobile_sdk/d10;->c:I

    invoke-interface {p1, p0, v0}, Lc03;->a(Lpk0;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v4, :cond_c7

    move-object v1, v4

    :cond_c7
    :goto_c7
    return-object v1

    :pswitch_c8  #0x0
    instance-of v0, p2, Lads_mobile_sdk/z00;

    if-eqz v0, :cond_d9

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/z00;

    iget v8, v0, Lads_mobile_sdk/z00;->c:I

    and-int v9, v8, v5

    if-eqz v9, :cond_d9

    sub-int/2addr v8, v5

    iput v8, v0, Lads_mobile_sdk/z00;->c:I

    goto :goto_de

    :cond_d9
    new-instance v0, Lads_mobile_sdk/z00;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/z00;-><init>(Lads_mobile_sdk/a10;Lwx;)V

    :goto_de
    iget-object p0, v0, Lads_mobile_sdk/z00;->a:Ljava/lang/Object;

    iget p2, v0, Lads_mobile_sdk/z00;->c:I

    if-eqz p2, :cond_ef

    if-ne p2, v6, :cond_ea

    invoke-static {p0}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_102

    :cond_ea
    invoke-static {v3}, Lz6;->w(Ljava/lang/String;)V

    move-object v1, v7

    goto :goto_102

    :cond_ef
    invoke-static {p0}, Lt12;->W(Ljava/lang/Object;)V

    new-instance p0, Lads_mobile_sdk/v2;

    check-cast v2, Lads_mobile_sdk/z2;

    invoke-direct {p0, v2, v7, v6}, Lads_mobile_sdk/v2;-><init>(Lads_mobile_sdk/z2;Lvx;I)V

    iput v6, v0, Lads_mobile_sdk/z00;->c:I

    invoke-interface {p1, p0, v0}, Lc03;->a(Lpk0;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v4, :cond_102

    move-object v1, v4

    :cond_102
    :goto_102
    return-object v1

    nop

    :pswitch_data_104
    .packed-switch 0x0
        :pswitch_c8  #00000000
        :pswitch_11  #00000001
        :pswitch_8b  #00000002
        :pswitch_11  #00000003
        :pswitch_4e  #00000004
    .end packed-switch
.end method

.method public final a(Ljava/lang/Object;Lads_mobile_sdk/rk1;)Ljava/lang/Object;
    .registers 8

    .prologue
    iget v0, p0, Lads_mobile_sdk/a10;->b:I

    sget-object v1, Lrg2;->a:Lrg2;

    sget-object v2, Lwy;->a:Lwy;

    const/4 v3, 0x0

    iget-object v4, p0, Lads_mobile_sdk/a10;->a:Ljava/lang/Object;

    packed-switch v0, :pswitch_data_4e

    check-cast p1, Lc03;

    invoke-virtual {p0, p1, p2}, Lads_mobile_sdk/a10;->a(Lc03;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_13  #0x4
    check-cast p1, Lc03;

    invoke-virtual {p0, p1, p2}, Lads_mobile_sdk/a10;->a(Lc03;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_1a  #0x3
    check-cast p1, Lc03;

    new-instance p0, Lb11;

    check-cast v4, Lads_mobile_sdk/xv;

    const/16 v0, 0xa

    invoke-direct {p0, v4, v3, v0}, Lb11;-><init>(Ljava/lang/Object;Lvx;I)V

    invoke-interface {p1, p0, p2}, Lc03;->a(Lpk0;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v2, :cond_2c

    move-object v1, p0

    :cond_2c
    return-object v1

    :pswitch_2d  #0x2
    check-cast p1, Lc03;

    invoke-virtual {p0, p1, p2}, Lads_mobile_sdk/a10;->a(Lc03;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_34  #0x1
    check-cast p1, Lc03;

    new-instance p0, Lb11;

    check-cast v4, Lc73;

    const/16 v0, 0x1c

    invoke-direct {p0, v4, v3, v0}, Lb11;-><init>(Ljava/lang/Object;Lvx;I)V

    invoke-interface {p1, p0, p2}, Lc03;->a(Lpk0;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v2, :cond_46

    move-object v1, p0

    :cond_46
    return-object v1

    :pswitch_47  #0x0
    check-cast p1, Lc03;

    invoke-virtual {p0, p1, p2}, Lads_mobile_sdk/a10;->a(Lc03;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_data_4e
    .packed-switch 0x0
        :pswitch_47  #00000000
        :pswitch_34  #00000001
        :pswitch_2d  #00000002
        :pswitch_1a  #00000003
        :pswitch_13  #00000004
    .end packed-switch
.end method
