.class public final Lads_mobile_sdk/ef2;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lnt2;


# instance fields
.field public final a:Ltv2;

.field public final b:Ltv2;

.field public final c:Ltv2;

.field public final d:Ltv2;

.field public final e:Ltv2;

.field public final f:Ltv2;

.field public final g:Ltv2;

.field public final h:Ltv2;

.field public final i:Ltv2;

.field public final synthetic j:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/ob1;Lads_mobile_sdk/ob1;Ltv2;Ltv2;Ltv2;Ltv2;Lads_mobile_sdk/ah0;Lads_mobile_sdk/ah0;Ltv2;)V
    .registers 11

    const/4 v0, 0x0

    iput v0, p0, Lads_mobile_sdk/ef2;->j:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/ef2;->a:Ltv2;

    iput-object p2, p0, Lads_mobile_sdk/ef2;->b:Ltv2;

    iput-object p3, p0, Lads_mobile_sdk/ef2;->c:Ltv2;

    iput-object p4, p0, Lads_mobile_sdk/ef2;->d:Ltv2;

    iput-object p5, p0, Lads_mobile_sdk/ef2;->e:Ltv2;

    iput-object p6, p0, Lads_mobile_sdk/ef2;->f:Ltv2;

    iput-object p7, p0, Lads_mobile_sdk/ef2;->g:Ltv2;

    iput-object p8, p0, Lads_mobile_sdk/ef2;->h:Ltv2;

    iput-object p9, p0, Lads_mobile_sdk/ef2;->i:Ltv2;

    return-void
.end method

.method public constructor <init>(Lads_mobile_sdk/ob1;Ltv2;Ltv2;Lads_mobile_sdk/ah0;Lads_mobile_sdk/ab0;Lads_mobile_sdk/ab0;Lads_mobile_sdk/ab0;Lads_mobile_sdk/ab0;Lads_mobile_sdk/ab0;)V
    .registers 11

    const/4 v0, 0x3

    iput v0, p0, Lads_mobile_sdk/ef2;->j:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/ef2;->a:Ltv2;

    iput-object p2, p0, Lads_mobile_sdk/ef2;->c:Ltv2;

    iput-object p3, p0, Lads_mobile_sdk/ef2;->d:Ltv2;

    iput-object p4, p0, Lads_mobile_sdk/ef2;->g:Ltv2;

    iput-object p5, p0, Lads_mobile_sdk/ef2;->b:Ltv2;

    iput-object p6, p0, Lads_mobile_sdk/ef2;->e:Ltv2;

    iput-object p7, p0, Lads_mobile_sdk/ef2;->f:Ltv2;

    iput-object p8, p0, Lads_mobile_sdk/ef2;->i:Ltv2;

    iput-object p9, p0, Lads_mobile_sdk/ef2;->h:Ltv2;

    return-void
.end method

.method public constructor <init>(Lads_mobile_sdk/ob1;Ltv2;Ltv2;Ltv2;Ltv2;Lads_mobile_sdk/ob1;Ltv2;Lads_mobile_sdk/ah0;Ltv2;)V
    .registers 11

    const/4 v0, 0x1

    iput v0, p0, Lads_mobile_sdk/ef2;->j:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/ef2;->a:Ltv2;

    iput-object p2, p0, Lads_mobile_sdk/ef2;->c:Ltv2;

    iput-object p3, p0, Lads_mobile_sdk/ef2;->d:Ltv2;

    iput-object p4, p0, Lads_mobile_sdk/ef2;->e:Ltv2;

    iput-object p5, p0, Lads_mobile_sdk/ef2;->f:Ltv2;

    iput-object p6, p0, Lads_mobile_sdk/ef2;->b:Ltv2;

    iput-object p7, p0, Lads_mobile_sdk/ef2;->i:Ltv2;

    iput-object p8, p0, Lads_mobile_sdk/ef2;->g:Ltv2;

    iput-object p9, p0, Lads_mobile_sdk/ef2;->h:Ltv2;

    return-void
.end method

.method public constructor <init>(Ltv2;Ltv2;Ltv2;Lads_mobile_sdk/ah0;Ltv2;Ltv2;Ltv2;Ltv2;Lads_mobile_sdk/ah0;)V
    .registers 11

    const/4 v0, 0x4

    iput v0, p0, Lads_mobile_sdk/ef2;->j:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/ef2;->c:Ltv2;

    iput-object p2, p0, Lads_mobile_sdk/ef2;->d:Ltv2;

    iput-object p3, p0, Lads_mobile_sdk/ef2;->e:Ltv2;

    iput-object p4, p0, Lads_mobile_sdk/ef2;->g:Ltv2;

    iput-object p5, p0, Lads_mobile_sdk/ef2;->f:Ltv2;

    iput-object p6, p0, Lads_mobile_sdk/ef2;->i:Ltv2;

    iput-object p7, p0, Lads_mobile_sdk/ef2;->a:Ltv2;

    iput-object p8, p0, Lads_mobile_sdk/ef2;->b:Ltv2;

    iput-object p9, p0, Lads_mobile_sdk/ef2;->h:Ltv2;

    return-void
.end method

.method public constructor <init>(Ltv2;Ltv2;Ltv2;Ltv2;Lads_mobile_sdk/el;Ltv2;Ltv2;Ltv2;Ltv2;)V
    .registers 11

    const/4 v0, 0x2

    iput v0, p0, Lads_mobile_sdk/ef2;->j:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/ef2;->c:Ltv2;

    iput-object p2, p0, Lads_mobile_sdk/ef2;->d:Ltv2;

    iput-object p3, p0, Lads_mobile_sdk/ef2;->e:Ltv2;

    iput-object p4, p0, Lads_mobile_sdk/ef2;->f:Ltv2;

    iput-object p5, p0, Lads_mobile_sdk/ef2;->a:Ltv2;

    iput-object p6, p0, Lads_mobile_sdk/ef2;->i:Ltv2;

    iput-object p7, p0, Lads_mobile_sdk/ef2;->b:Ltv2;

    iput-object p8, p0, Lads_mobile_sdk/ef2;->g:Ltv2;

    iput-object p9, p0, Lads_mobile_sdk/ef2;->h:Ltv2;

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 22

    .prologue
    move-object/from16 v0, p0

    iget v1, v0, Lads_mobile_sdk/ef2;->j:I

    iget-object v2, v0, Lads_mobile_sdk/ef2;->h:Ltv2;

    iget-object v3, v0, Lads_mobile_sdk/ef2;->b:Ltv2;

    iget-object v4, v0, Lads_mobile_sdk/ef2;->a:Ltv2;

    iget-object v5, v0, Lads_mobile_sdk/ef2;->i:Ltv2;

    iget-object v6, v0, Lads_mobile_sdk/ef2;->f:Ltv2;

    iget-object v7, v0, Lads_mobile_sdk/ef2;->g:Ltv2;

    iget-object v8, v0, Lads_mobile_sdk/ef2;->e:Ltv2;

    iget-object v9, v0, Lads_mobile_sdk/ef2;->d:Ltv2;

    iget-object v0, v0, Lads_mobile_sdk/ef2;->c:Ltv2;

    packed-switch v1, :pswitch_data_198

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v11, v0

    check-cast v11, Lads_mobile_sdk/qr0;

    invoke-interface {v9}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v12, v0

    check-cast v12, Lads_mobile_sdk/j42;

    invoke-interface {v8}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v13, v0

    check-cast v13, Lx43;

    check-cast v7, Lads_mobile_sdk/ah0;

    invoke-virtual {v7}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v14, v0

    check-cast v14, Lvy;

    invoke-interface {v6}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v15, v0

    check-cast v15, Lq63;

    invoke-interface {v5}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v16, v0

    check-cast v16, Lads_mobile_sdk/am3;

    invoke-interface {v4}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v17, v0

    check-cast v17, Lads_mobile_sdk/ws;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v18, v0

    check-cast v18, Lads_mobile_sdk/ux2;

    check-cast v2, Lads_mobile_sdk/ah0;

    invoke-virtual {v2}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v19, v0

    check-cast v19, Lads_mobile_sdk/ah3;

    new-instance v10, Lads_mobile_sdk/tv2;

    invoke-direct/range {v10 .. v19}, Lads_mobile_sdk/tv2;-><init>(Lads_mobile_sdk/qr0;Lads_mobile_sdk/j42;Lx43;Lvy;Lq63;Lads_mobile_sdk/am3;Lads_mobile_sdk/ws;Lads_mobile_sdk/ux2;Lads_mobile_sdk/ah3;)V

    return-object v10

    :pswitch_66  #0x3
    check-cast v4, Lads_mobile_sdk/ob1;

    iget-object v1, v4, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v11, v1

    check-cast v11, Landroid/content/Context;

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v12, v0

    check-cast v12, Lads_mobile_sdk/ax0;

    invoke-interface {v9}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v13, v0

    check-cast v13, Lads_mobile_sdk/g0;

    check-cast v7, Lads_mobile_sdk/ah0;

    invoke-virtual {v7}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v14, v0

    check-cast v14, Lads_mobile_sdk/d91;

    move-object v15, v3

    check-cast v15, Lads_mobile_sdk/ab0;

    move-object/from16 v16, v8

    check-cast v16, Lads_mobile_sdk/ab0;

    move-object/from16 v17, v6

    check-cast v17, Lads_mobile_sdk/ab0;

    move-object/from16 v18, v5

    check-cast v18, Lads_mobile_sdk/ab0;

    move-object/from16 v19, v2

    check-cast v19, Lads_mobile_sdk/ab0;

    new-instance v10, Lads_mobile_sdk/u92;

    invoke-direct/range {v10 .. v19}, Lads_mobile_sdk/u92;-><init>(Landroid/content/Context;Lads_mobile_sdk/ax0;Lads_mobile_sdk/g0;Lads_mobile_sdk/d91;Lads_mobile_sdk/ab0;Lads_mobile_sdk/ab0;Lads_mobile_sdk/ab0;Lads_mobile_sdk/ab0;Lads_mobile_sdk/ab0;)V

    return-object v10

    :pswitch_9d  #0x2
    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v11, v0

    check-cast v11, Ljava/lang/String;

    invoke-interface {v9}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v12

    invoke-interface {v8}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v13, v0

    check-cast v13, Lads_mobile_sdk/i8;

    invoke-interface {v6}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v14, v0

    check-cast v14, Lx13;

    check-cast v4, Lads_mobile_sdk/el;

    invoke-virtual {v4}, Lads_mobile_sdk/el;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v15, v0

    check-cast v15, Lads_mobile_sdk/xa2;

    invoke-interface {v5}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v16, v0

    check-cast v16, Lads_mobile_sdk/kh3;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v17, v0

    check-cast v17, Lx63;

    invoke-interface {v7}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v18, v0

    check-cast v18, Lads_mobile_sdk/qr0;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v19, v0

    check-cast v19, Lvy2;

    new-instance v10, Lads_mobile_sdk/qc1;

    invoke-direct/range {v10 .. v19}, Lads_mobile_sdk/qc1;-><init>(Ljava/lang/String;ILads_mobile_sdk/i8;Lx13;Lads_mobile_sdk/xa2;Lads_mobile_sdk/kh3;Lx63;Lads_mobile_sdk/qr0;Lvy2;)V

    return-object v10

    :pswitch_eb  #0x1
    check-cast v4, Lads_mobile_sdk/ob1;

    iget-object v1, v4, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v11, v1

    check-cast v11, Lli;

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v12, v0

    check-cast v12, Lx63;

    invoke-interface {v9}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v13, v0

    check-cast v13, Lads_mobile_sdk/l;

    invoke-interface {v8}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v14, v0

    check-cast v14, Lads_mobile_sdk/ae2;

    invoke-interface {v6}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v15, v0

    check-cast v15, Lads_mobile_sdk/v5;

    check-cast v3, Lads_mobile_sdk/ob1;

    iget-object v0, v3, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object/from16 v16, v0

    check-cast v16, Lads_mobile_sdk/av2;

    invoke-interface {v5}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v17, v0

    check-cast v17, Lads_mobile_sdk/o32;

    new-instance v0, Llm0;

    invoke-direct {v0}, Llm0;-><init>()V

    new-instance v1, Lcom/google/android/libraries/ads/mobile/sdk/internal/util/AndroidBundleTypeAdapterFactory;

    invoke-direct {v1}, Lcom/google/android/libraries/ads/mobile/sdk/internal/util/AndroidBundleTypeAdapterFactory;-><init>()V

    invoke-virtual {v0, v1}, Llm0;->c(Lcom/google/android/libraries/ads/mobile/sdk/internal/util/AndroidBundleTypeAdapterFactory;)V

    new-instance v1, Lkm0;

    invoke-direct {v1, v0}, Lkm0;-><init>(Llm0;)V

    check-cast v7, Lads_mobile_sdk/ah0;

    invoke-virtual {v7}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v19, v0

    check-cast v19, Lads_mobile_sdk/ah3;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v20, v0

    check-cast v20, Ljava/util/Optional;

    new-instance v10, Lads_mobile_sdk/ie2;

    move-object/from16 v18, v1

    invoke-direct/range {v10 .. v20}, Lads_mobile_sdk/ie2;-><init>(Lli;Lx63;Lads_mobile_sdk/l;Lads_mobile_sdk/ae2;Lads_mobile_sdk/v5;Lads_mobile_sdk/av2;Lads_mobile_sdk/o32;Lkm0;Lads_mobile_sdk/ah3;Ljava/util/Optional;)V

    return-object v10

    :pswitch_14a  #0x0
    check-cast v4, Lads_mobile_sdk/ob1;

    iget-object v1, v4, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v11, v1

    check-cast v11, Landroid/content/Context;

    check-cast v3, Lads_mobile_sdk/ob1;

    iget-object v1, v3, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v12, v1

    check-cast v12, Lads_mobile_sdk/a2;

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v13, v0

    check-cast v13, Lads_mobile_sdk/if2;

    invoke-interface {v9}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v14, v0

    check-cast v14, Lads_mobile_sdk/qr0;

    invoke-interface {v8}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v15, v0

    check-cast v15, Lads_mobile_sdk/ux2;

    invoke-interface {v6}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v16, v0

    check-cast v16, Lads_mobile_sdk/s01;

    check-cast v7, Lads_mobile_sdk/ah0;

    invoke-virtual {v7}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v17, v0

    check-cast v17, Lads_mobile_sdk/ah3;

    check-cast v2, Lads_mobile_sdk/ah0;

    invoke-virtual {v2}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v18, v0

    check-cast v18, Lvy;

    invoke-interface {v5}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v19, v0

    check-cast v19, Lads_mobile_sdk/g0;

    new-instance v10, Lads_mobile_sdk/df2;

    invoke-direct/range {v10 .. v19}, Lads_mobile_sdk/df2;-><init>(Landroid/content/Context;Lads_mobile_sdk/a2;Lads_mobile_sdk/if2;Lads_mobile_sdk/qr0;Lads_mobile_sdk/ux2;Lads_mobile_sdk/s01;Lads_mobile_sdk/ah3;Lvy;Lads_mobile_sdk/g0;)V

    return-object v10

    nop

    :pswitch_data_198
    .packed-switch 0x0
        :pswitch_14a  #00000000
        :pswitch_eb  #00000001
        :pswitch_9d  #00000002
        :pswitch_66  #00000003
    .end packed-switch
.end method
