.class public final Lads_mobile_sdk/bf2;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public a:Ljava/lang/Object;

.field public b:Ljava/lang/Object;

.field public c:I

.field public final synthetic d:Ljava/lang/Object;

.field public final synthetic f:Z

.field public final synthetic t:I


# direct methods
.method public synthetic constructor <init>(Lads_mobile_sdk/df2;ZLvx;I)V
    .registers 5

    iput p4, p0, Lads_mobile_sdk/bf2;->t:I

    iput-object p1, p0, Lads_mobile_sdk/bf2;->d:Ljava/lang/Object;

    iput-boolean p2, p0, Lads_mobile_sdk/bf2;->f:Z

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lm82;-><init>(ILvx;)V

    return-void
.end method

.method public constructor <init>(ZLvr1;Lads_mobile_sdk/ae2;Lads_mobile_sdk/fe2;Lvx;)V
    .registers 7

    const/4 v0, 0x2

    iput v0, p0, Lads_mobile_sdk/bf2;->t:I

    iput-boolean p1, p0, Lads_mobile_sdk/bf2;->f:Z

    iput-object p2, p0, Lads_mobile_sdk/bf2;->a:Ljava/lang/Object;

    iput-object p3, p0, Lads_mobile_sdk/bf2;->b:Ljava/lang/Object;

    iput-object p4, p0, Lads_mobile_sdk/bf2;->d:Ljava/lang/Object;

    invoke-direct {p0, v0, p5}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 11

    .prologue
    iget p2, p0, Lads_mobile_sdk/bf2;->t:I

    iget-boolean v0, p0, Lads_mobile_sdk/bf2;->f:Z

    iget-object v1, p0, Lads_mobile_sdk/bf2;->d:Ljava/lang/Object;

    packed-switch p2, :pswitch_data_34

    new-instance v2, Lads_mobile_sdk/bf2;

    iget-object p2, p0, Lads_mobile_sdk/bf2;->a:Ljava/lang/Object;

    move-object v4, p2

    check-cast v4, Lvr1;

    iget-object p2, p0, Lads_mobile_sdk/bf2;->b:Ljava/lang/Object;

    move-object v5, p2

    check-cast v5, Lads_mobile_sdk/ae2;

    move-object v6, v1

    check-cast v6, Lads_mobile_sdk/fe2;

    iget-boolean v3, p0, Lads_mobile_sdk/bf2;->f:Z

    move-object v7, p1

    invoke-direct/range {v2 .. v7}, Lads_mobile_sdk/bf2;-><init>(ZLvr1;Lads_mobile_sdk/ae2;Lads_mobile_sdk/fe2;Lvx;)V

    return-object v2

    :pswitch_1f  #0x1
    move-object v7, p1

    new-instance p0, Lads_mobile_sdk/bf2;

    check-cast v1, Lads_mobile_sdk/df2;

    const/4 p1, 0x1

    invoke-direct {p0, v1, v0, v7, p1}, Lads_mobile_sdk/bf2;-><init>(Lads_mobile_sdk/df2;ZLvx;I)V

    return-object p0

    :pswitch_29  #0x0
    move-object v7, p1

    new-instance p0, Lads_mobile_sdk/bf2;

    check-cast v1, Lads_mobile_sdk/df2;

    const/4 p1, 0x0

    invoke-direct {p0, v1, v0, v7, p1}, Lads_mobile_sdk/bf2;-><init>(Lads_mobile_sdk/df2;ZLvx;I)V

    return-object p0

    nop

    :pswitch_data_34
    .packed-switch 0x0
        :pswitch_29  #00000000
        :pswitch_1f  #00000001
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .prologue
    iget v0, p0, Lads_mobile_sdk/bf2;->t:I

    sget-object v1, Lrg2;->a:Lrg2;

    packed-switch v0, :pswitch_data_3a

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    invoke-virtual {p0, p2, p1}, Lads_mobile_sdk/bf2;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/bf2;

    invoke-virtual {p0, v1}, Lads_mobile_sdk/bf2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_16  #0x1
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/bf2;

    iget-object v0, p0, Lads_mobile_sdk/bf2;->d:Ljava/lang/Object;

    check-cast v0, Lads_mobile_sdk/df2;

    iget-boolean p0, p0, Lads_mobile_sdk/bf2;->f:Z

    const/4 v2, 0x1

    invoke-direct {p1, v0, p0, p2, v2}, Lads_mobile_sdk/bf2;-><init>(Lads_mobile_sdk/df2;ZLvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/bf2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_2b  #0x0
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    invoke-virtual {p0, p2, p1}, Lads_mobile_sdk/bf2;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/bf2;

    invoke-virtual {p0, v1}, Lads_mobile_sdk/bf2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_data_3a
    .packed-switch 0x0
        :pswitch_2b  #00000000
        :pswitch_16  #00000001
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 16

    .prologue
    iget v0, p0, Lads_mobile_sdk/bf2;->t:I

    const/4 v1, 0x2

    const-string v2, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v3, 0x1

    const/4 v4, 0x0

    packed-switch v0, :pswitch_data_240

    sget-object v0, Lwy;->a:Lwy;

    iget v1, p0, Lads_mobile_sdk/bf2;->c:I

    if-eqz v1, :cond_1a

    if-ne v1, v3, :cond_16

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_3b

    :cond_16
    invoke-static {v2}, Lz6;->w(Ljava/lang/String;)V

    goto :goto_3f

    :cond_1a
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-boolean p1, p0, Lads_mobile_sdk/bf2;->f:Z

    if-nez p1, :cond_29

    iget-object p1, p0, Lads_mobile_sdk/bf2;->a:Ljava/lang/Object;

    check-cast p1, Lvr1;

    iget-object p1, p1, Lvr1;->a:Ljava/lang/Object;

    if-nez p1, :cond_3d

    :cond_29
    iget-object p1, p0, Lads_mobile_sdk/bf2;->b:Ljava/lang/Object;

    check-cast p1, Lads_mobile_sdk/ae2;

    iget-object v1, p0, Lads_mobile_sdk/bf2;->d:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/fe2;

    iput v3, p0, Lads_mobile_sdk/bf2;->c:I

    invoke-static {p1, v1, p0}, Lads_mobile_sdk/ae2;->b(Lads_mobile_sdk/ae2;Lads_mobile_sdk/fe2;Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_3b

    move-object v4, v0

    goto :goto_3f

    :cond_3b
    :goto_3b
    check-cast p1, Lb13;

    :cond_3d
    sget-object v4, Lrg2;->a:Lrg2;

    :goto_3f
    return-object v4

    :pswitch_40  #0x1
    sget-object v0, Lrg2;->a:Lrg2;

    sget-object v5, Lwy;->a:Lwy;

    iget v6, p0, Lads_mobile_sdk/bf2;->c:I

    if-eqz v6, :cond_6f

    if-eq v6, v3, :cond_61

    if-ne v6, v1, :cond_5c

    iget-object v1, p0, Lads_mobile_sdk/bf2;->b:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/rg3;

    iget-object p0, p0, Lads_mobile_sdk/bf2;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/rg3;

    :try_start_54
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_57
    .catchall {:try_start_54 .. :try_end_57} :catchall_59

    goto/16 :goto_101

    :catchall_59
    move-exception p1

    goto/16 :goto_10a

    :cond_5c
    invoke-static {v2}, Lz6;->w(Ljava/lang/String;)V

    goto/16 :goto_105

    :cond_61
    iget-object v1, p0, Lads_mobile_sdk/bf2;->b:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/rg3;

    iget-object p0, p0, Lads_mobile_sdk/bf2;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/rg3;

    :try_start_69
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_6c
    .catchall {:try_start_69 .. :try_end_6c} :catchall_6d

    goto :goto_b0

    :catchall_6d
    move-exception p1

    goto :goto_b8

    :cond_6f
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/bf2;->d:Ljava/lang/Object;

    check-cast p1, Lads_mobile_sdk/df2;

    iget-object v2, p1, Lads_mobile_sdk/df2;->d:Lads_mobile_sdk/ux2;

    sget-object v6, Lads_mobile_sdk/fw0;->S1:Lads_mobile_sdk/fw0;

    iget-boolean v7, p0, Lads_mobile_sdk/bf2;->f:Z

    sget-object v8, Lba0;->a:Lba0;

    new-instance v9, Lads_mobile_sdk/kh3;

    new-instance v10, Lads_mobile_sdk/eq2;

    invoke-direct {v10}, Lads_mobile_sdk/eq2;-><init>()V

    new-instance v11, Lads_mobile_sdk/ih1;

    invoke-direct {v11}, Lads_mobile_sdk/ih1;-><init>()V

    new-instance v12, Lads_mobile_sdk/dt2;

    invoke-direct {v12}, Lads_mobile_sdk/dt2;-><init>()V

    new-instance v13, Lads_mobile_sdk/s8;

    invoke-direct {v13}, Lads_mobile_sdk/s8;-><init>()V

    invoke-direct {v9, v10, v11, v12, v13}, Lads_mobile_sdk/kh3;-><init>(Lads_mobile_sdk/eq2;Lads_mobile_sdk/ih1;Lads_mobile_sdk/dt2;Lads_mobile_sdk/s8;)V

    invoke-static {}, Lads_mobile_sdk/hh3;->b()Lads_mobile_sdk/gh3;

    move-result-object v10

    iget-object v10, v10, Lads_mobile_sdk/gh3;->a:Lads_mobile_sdk/rg3;

    if-nez v10, :cond_ee

    invoke-static {v2, v6, v8, v9}, Lads_mobile_sdk/ux2;->a(Lads_mobile_sdk/ux2;Lads_mobile_sdk/fw0;Ljava/util/List;Lads_mobile_sdk/kh3;)Lads_mobile_sdk/wk2;

    move-result-object v1

    :try_start_a3
    iput-object v1, p0, Lads_mobile_sdk/bf2;->a:Ljava/lang/Object;

    iput-object v1, p0, Lads_mobile_sdk/bf2;->b:Ljava/lang/Object;

    iput v3, p0, Lads_mobile_sdk/bf2;->c:I

    invoke-static {p1, v7, p0}, Lads_mobile_sdk/df2;->a(Lads_mobile_sdk/df2;ZLwx;)Ljava/lang/Object;

    move-result-object p0
    :try_end_ad
    .catchall {:try_start_a3 .. :try_end_ad} :catchall_b5

    if-ne p0, v5, :cond_b0

    goto :goto_fe

    :cond_b0
    :goto_b0
    invoke-static {v1, v4}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    :goto_b3
    move-object v4, v0

    goto :goto_105

    :catchall_b5
    move-exception p0

    move-object p1, p0

    move-object p0, v1

    :goto_b8
    :try_start_b8
    invoke-virtual {p0, p1}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v0, p1, Lox2;

    if-nez v0, :cond_e7

    invoke-virtual {p0, p1}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of p0, p1, Lza2;

    if-nez p0, :cond_df

    instance-of p0, p1, Ljava/util/concurrent/CancellationException;

    if-nez p0, :cond_d7

    instance-of p0, p1, Lads_mobile_sdk/mv0;

    if-eqz p0, :cond_d1

    throw p1

    :catchall_cf
    move-exception p0

    goto :goto_e8

    :cond_d1
    new-instance p0, Lads_mobile_sdk/tu0;

    invoke-direct {p0, p1}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw p0

    :cond_d7
    new-instance p0, Lads_mobile_sdk/ou0;

    check-cast p1, Ljava/util/concurrent/CancellationException;

    invoke-direct {p0, p1}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw p0

    :cond_df
    new-instance p0, Lads_mobile_sdk/uw0;

    check-cast p1, Lza2;

    invoke-direct {p0, p1}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw p0

    :cond_e7
    throw p1
    :try_end_e8
    .catchall {:try_start_b8 .. :try_end_e8} :catchall_cf

    :goto_e8
    :try_start_e8
    throw p0
    :try_end_e9
    .catchall {:try_start_e8 .. :try_end_e9} :catchall_e9

    :catchall_e9
    move-exception p1

    invoke-static {v1, p0}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw p1

    :cond_ee
    invoke-static {v6, v8, v3}, Lads_mobile_sdk/hh3;->a(Lads_mobile_sdk/fw0;Ljava/util/List;Z)Lads_mobile_sdk/rg3;

    move-result-object v2

    :try_start_f2
    iput-object v2, p0, Lads_mobile_sdk/bf2;->a:Ljava/lang/Object;

    iput-object v2, p0, Lads_mobile_sdk/bf2;->b:Ljava/lang/Object;

    iput v1, p0, Lads_mobile_sdk/bf2;->c:I

    invoke-static {p1, v7, p0}, Lads_mobile_sdk/df2;->a(Lads_mobile_sdk/df2;ZLwx;)Ljava/lang/Object;

    move-result-object p0
    :try_end_fc
    .catchall {:try_start_f2 .. :try_end_fc} :catchall_106

    if-ne p0, v5, :cond_100

    :goto_fe
    move-object v4, v5

    goto :goto_105

    :cond_100
    move-object v1, v2

    :goto_101
    invoke-static {v1, v4}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    goto :goto_b3

    :goto_105
    return-object v4

    :catchall_106
    move-exception p0

    move-object p1, p0

    move-object p0, v2

    move-object v1, p0

    :goto_10a
    :try_start_10a
    invoke-virtual {p0, p1}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v0, p1, Lox2;

    if-nez v0, :cond_139

    invoke-virtual {p0, p1}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of p0, p1, Lza2;

    if-nez p0, :cond_131

    instance-of p0, p1, Ljava/util/concurrent/CancellationException;

    if-nez p0, :cond_129

    instance-of p0, p1, Lads_mobile_sdk/mv0;

    if-eqz p0, :cond_123

    throw p1

    :catchall_121
    move-exception p0

    goto :goto_13a

    :cond_123
    new-instance p0, Lads_mobile_sdk/tu0;

    invoke-direct {p0, p1}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw p0

    :cond_129
    new-instance p0, Lads_mobile_sdk/ou0;

    check-cast p1, Ljava/util/concurrent/CancellationException;

    invoke-direct {p0, p1}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw p0

    :cond_131
    new-instance p0, Lads_mobile_sdk/uw0;

    check-cast p1, Lza2;

    invoke-direct {p0, p1}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw p0

    :cond_139
    throw p1
    :try_end_13a
    .catchall {:try_start_10a .. :try_end_13a} :catchall_121

    :goto_13a
    :try_start_13a
    throw p0
    :try_end_13b
    .catchall {:try_start_13a .. :try_end_13b} :catchall_13b

    :catchall_13b
    move-exception p1

    invoke-static {v1, p0}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw p1

    :pswitch_140  #0x0
    sget-object v0, Lrg2;->a:Lrg2;

    sget-object v5, Lwy;->a:Lwy;

    iget v6, p0, Lads_mobile_sdk/bf2;->c:I

    if-eqz v6, :cond_16f

    if-eq v6, v3, :cond_161

    if-ne v6, v1, :cond_15c

    iget-object v1, p0, Lads_mobile_sdk/bf2;->b:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/rg3;

    iget-object p0, p0, Lads_mobile_sdk/bf2;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/rg3;

    :try_start_154
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_157
    .catchall {:try_start_154 .. :try_end_157} :catchall_159

    goto/16 :goto_201

    :catchall_159
    move-exception p1

    goto/16 :goto_20a

    :cond_15c
    invoke-static {v2}, Lz6;->w(Ljava/lang/String;)V

    goto/16 :goto_205

    :cond_161
    iget-object v1, p0, Lads_mobile_sdk/bf2;->b:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/rg3;

    iget-object p0, p0, Lads_mobile_sdk/bf2;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/rg3;

    :try_start_169
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_16c
    .catchall {:try_start_169 .. :try_end_16c} :catchall_16d

    goto :goto_1b0

    :catchall_16d
    move-exception p1

    goto :goto_1b8

    :cond_16f
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/bf2;->d:Ljava/lang/Object;

    check-cast p1, Lads_mobile_sdk/df2;

    iget-object v2, p1, Lads_mobile_sdk/df2;->d:Lads_mobile_sdk/ux2;

    sget-object v6, Lads_mobile_sdk/fw0;->S1:Lads_mobile_sdk/fw0;

    iget-boolean v7, p0, Lads_mobile_sdk/bf2;->f:Z

    sget-object v8, Lba0;->a:Lba0;

    new-instance v9, Lads_mobile_sdk/kh3;

    new-instance v10, Lads_mobile_sdk/eq2;

    invoke-direct {v10}, Lads_mobile_sdk/eq2;-><init>()V

    new-instance v11, Lads_mobile_sdk/ih1;

    invoke-direct {v11}, Lads_mobile_sdk/ih1;-><init>()V

    new-instance v12, Lads_mobile_sdk/dt2;

    invoke-direct {v12}, Lads_mobile_sdk/dt2;-><init>()V

    new-instance v13, Lads_mobile_sdk/s8;

    invoke-direct {v13}, Lads_mobile_sdk/s8;-><init>()V

    invoke-direct {v9, v10, v11, v12, v13}, Lads_mobile_sdk/kh3;-><init>(Lads_mobile_sdk/eq2;Lads_mobile_sdk/ih1;Lads_mobile_sdk/dt2;Lads_mobile_sdk/s8;)V

    invoke-static {}, Lads_mobile_sdk/hh3;->b()Lads_mobile_sdk/gh3;

    move-result-object v10

    iget-object v10, v10, Lads_mobile_sdk/gh3;->a:Lads_mobile_sdk/rg3;

    if-nez v10, :cond_1ee

    invoke-static {v2, v6, v8, v9}, Lads_mobile_sdk/ux2;->a(Lads_mobile_sdk/ux2;Lads_mobile_sdk/fw0;Ljava/util/List;Lads_mobile_sdk/kh3;)Lads_mobile_sdk/wk2;

    move-result-object v1

    :try_start_1a3
    iput-object v1, p0, Lads_mobile_sdk/bf2;->a:Ljava/lang/Object;

    iput-object v1, p0, Lads_mobile_sdk/bf2;->b:Ljava/lang/Object;

    iput v3, p0, Lads_mobile_sdk/bf2;->c:I

    invoke-static {p1, v7, p0}, Lads_mobile_sdk/df2;->a(Lads_mobile_sdk/df2;ZLwx;)Ljava/lang/Object;

    move-result-object p0
    :try_end_1ad
    .catchall {:try_start_1a3 .. :try_end_1ad} :catchall_1b5

    if-ne p0, v5, :cond_1b0

    goto :goto_1fe

    :cond_1b0
    :goto_1b0
    invoke-static {v1, v4}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    :goto_1b3
    move-object v4, v0

    goto :goto_205

    :catchall_1b5
    move-exception p0

    move-object p1, p0

    move-object p0, v1

    :goto_1b8
    :try_start_1b8
    invoke-virtual {p0, p1}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v0, p1, Lox2;

    if-nez v0, :cond_1e7

    invoke-virtual {p0, p1}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of p0, p1, Lza2;

    if-nez p0, :cond_1df

    instance-of p0, p1, Ljava/util/concurrent/CancellationException;

    if-nez p0, :cond_1d7

    instance-of p0, p1, Lads_mobile_sdk/mv0;

    if-eqz p0, :cond_1d1

    throw p1

    :catchall_1cf
    move-exception p0

    goto :goto_1e8

    :cond_1d1
    new-instance p0, Lads_mobile_sdk/tu0;

    invoke-direct {p0, p1}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw p0

    :cond_1d7
    new-instance p0, Lads_mobile_sdk/ou0;

    check-cast p1, Ljava/util/concurrent/CancellationException;

    invoke-direct {p0, p1}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw p0

    :cond_1df
    new-instance p0, Lads_mobile_sdk/uw0;

    check-cast p1, Lza2;

    invoke-direct {p0, p1}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw p0

    :cond_1e7
    throw p1
    :try_end_1e8
    .catchall {:try_start_1b8 .. :try_end_1e8} :catchall_1cf

    :goto_1e8
    :try_start_1e8
    throw p0
    :try_end_1e9
    .catchall {:try_start_1e8 .. :try_end_1e9} :catchall_1e9

    :catchall_1e9
    move-exception p1

    invoke-static {v1, p0}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw p1

    :cond_1ee
    invoke-static {v6, v8, v3}, Lads_mobile_sdk/hh3;->a(Lads_mobile_sdk/fw0;Ljava/util/List;Z)Lads_mobile_sdk/rg3;

    move-result-object v2

    :try_start_1f2
    iput-object v2, p0, Lads_mobile_sdk/bf2;->a:Ljava/lang/Object;

    iput-object v2, p0, Lads_mobile_sdk/bf2;->b:Ljava/lang/Object;

    iput v1, p0, Lads_mobile_sdk/bf2;->c:I

    invoke-static {p1, v7, p0}, Lads_mobile_sdk/df2;->a(Lads_mobile_sdk/df2;ZLwx;)Ljava/lang/Object;

    move-result-object p0
    :try_end_1fc
    .catchall {:try_start_1f2 .. :try_end_1fc} :catchall_206

    if-ne p0, v5, :cond_200

    :goto_1fe
    move-object v4, v5

    goto :goto_205

    :cond_200
    move-object v1, v2

    :goto_201
    invoke-static {v1, v4}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    goto :goto_1b3

    :goto_205
    return-object v4

    :catchall_206
    move-exception p0

    move-object p1, p0

    move-object p0, v2

    move-object v1, p0

    :goto_20a
    :try_start_20a
    invoke-virtual {p0, p1}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v0, p1, Lox2;

    if-nez v0, :cond_239

    invoke-virtual {p0, p1}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of p0, p1, Lza2;

    if-nez p0, :cond_231

    instance-of p0, p1, Ljava/util/concurrent/CancellationException;

    if-nez p0, :cond_229

    instance-of p0, p1, Lads_mobile_sdk/mv0;

    if-eqz p0, :cond_223

    throw p1

    :catchall_221
    move-exception p0

    goto :goto_23a

    :cond_223
    new-instance p0, Lads_mobile_sdk/tu0;

    invoke-direct {p0, p1}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw p0

    :cond_229
    new-instance p0, Lads_mobile_sdk/ou0;

    check-cast p1, Ljava/util/concurrent/CancellationException;

    invoke-direct {p0, p1}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw p0

    :cond_231
    new-instance p0, Lads_mobile_sdk/uw0;

    check-cast p1, Lza2;

    invoke-direct {p0, p1}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw p0

    :cond_239
    throw p1
    :try_end_23a
    .catchall {:try_start_20a .. :try_end_23a} :catchall_221

    :goto_23a
    :try_start_23a
    throw p0
    :try_end_23b
    .catchall {:try_start_23a .. :try_end_23b} :catchall_23b

    :catchall_23b
    move-exception p1

    invoke-static {v1, p0}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw p1

    :pswitch_data_240
    .packed-switch 0x0
        :pswitch_140  #00000000
        :pswitch_40  #00000001
    .end packed-switch
.end method
