.class public abstract Lads_mobile_sdk/eo;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ld03;


# instance fields
.field public final b:Landroid/content/Context;

.field public final c:Lads_mobile_sdk/xq0;

.field public final d:Lads_mobile_sdk/a80;

.field public final e:Lads_mobile_sdk/o03;

.field public final f:Lads_mobile_sdk/aj;

.field public final g:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public final h:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public final i:Lnb1;

.field public j:Lfx0;

.field public final k:Ljava/util/concurrent/atomic/AtomicReference;

.field public final l:Ljava/util/concurrent/atomic/AtomicReference;

.field public final m:Ljava/util/concurrent/atomic/AtomicReference;

.field public final n:Ljava/util/concurrent/atomic/AtomicReference;

.field public final o:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public p:Z

.field public q:Z

.field public r:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;Lads_mobile_sdk/xq0;Lads_mobile_sdk/a80;Lads_mobile_sdk/o03;Lads_mobile_sdk/aj;)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/eo;->b:Landroid/content/Context;

    iput-object p2, p0, Lads_mobile_sdk/eo;->c:Lads_mobile_sdk/xq0;

    iput-object p3, p0, Lads_mobile_sdk/eo;->d:Lads_mobile_sdk/a80;

    iput-object p4, p0, Lads_mobile_sdk/eo;->e:Lads_mobile_sdk/o03;

    iput-object p5, p0, Lads_mobile_sdk/eo;->f:Lads_mobile_sdk/aj;

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 p2, 0x0

    invoke-direct {p1, p2}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object p1, p0, Lads_mobile_sdk/eo;->g:Ljava/util/concurrent/atomic/AtomicBoolean;

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {p1, p2}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object p1, p0, Lads_mobile_sdk/eo;->h:Ljava/util/concurrent/atomic/AtomicBoolean;

    new-instance p1, Lnb1;

    invoke-direct {p1}, Lnb1;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/eo;->i:Lnb1;

    invoke-static {}, Lads_mobile_sdk/yz;->w()Lf73;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object p1

    check-cast p1, Lads_mobile_sdk/yz;

    new-instance p3, Ljava/util/concurrent/atomic/AtomicReference;

    invoke-direct {p3, p1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    iput-object p3, p0, Lads_mobile_sdk/eo;->k:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-static {}, Lads_mobile_sdk/hb2;->r()Lmy2;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object p1

    check-cast p1, Lads_mobile_sdk/hb2;

    new-instance p3, Ljava/util/concurrent/atomic/AtomicReference;

    invoke-direct {p3, p1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    iput-object p3, p0, Lads_mobile_sdk/eo;->l:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-static {}, Lads_mobile_sdk/mg2;->r()Lu03;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object p1

    check-cast p1, Lads_mobile_sdk/mg2;

    new-instance p3, Ljava/util/concurrent/atomic/AtomicReference;

    invoke-direct {p3, p1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    iput-object p3, p0, Lads_mobile_sdk/eo;->m:Ljava/util/concurrent/atomic/AtomicReference;

    new-instance p1, Ljava/util/concurrent/atomic/AtomicReference;

    sget-object p3, Lca0;->a:Lca0;

    invoke-direct {p1, p3}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    iput-object p1, p0, Lads_mobile_sdk/eo;->n:Ljava/util/concurrent/atomic/AtomicReference;

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {p1, p2}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object p1, p0, Lads_mobile_sdk/eo;->o:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-void
.end method

.method public static final a(Lads_mobile_sdk/eo;Lwx;)Ljava/lang/Object;
    .registers 11

    .prologue
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    instance-of v0, p1, Lads_mobile_sdk/sn;

    if-eqz v0, :cond_16

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/sn;

    iget v1, v0, Lads_mobile_sdk/sn;->d:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_16

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/sn;->d:I

    goto :goto_1b

    :cond_16
    new-instance v0, Lads_mobile_sdk/sn;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/sn;-><init>(Lads_mobile_sdk/eo;Lwx;)V

    :goto_1b
    iget-object p1, v0, Lads_mobile_sdk/sn;->b:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/sn;->d:I

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    sget-object v6, Lrg2;->a:Lrg2;

    const/4 v7, 0x1

    sget-object v8, Lwy;->a:Lwy;

    if-eqz v1, :cond_51

    if-eq v1, v7, :cond_4b

    if-eq v1, v5, :cond_45

    if-eq v1, v4, :cond_3f

    if-ne v1, v3, :cond_39

    iget-object p0, v0, Lads_mobile_sdk/sn;->a:Lads_mobile_sdk/eo;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto/16 :goto_b1

    :cond_39
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v2

    :cond_3f
    iget-object p0, v0, Lads_mobile_sdk/sn;->a:Lads_mobile_sdk/eo;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_86

    :cond_45
    iget-object p0, v0, Lads_mobile_sdk/sn;->a:Lads_mobile_sdk/eo;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_77

    :cond_4b
    iget-object p0, v0, Lads_mobile_sdk/sn;->a:Lads_mobile_sdk/eo;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_6a

    :cond_51
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iput-boolean v7, p0, Lads_mobile_sdk/eo;->q:Z

    new-instance p1, Lfx0;

    invoke-direct {p1}, Lfx0;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/eo;->j:Lfx0;

    iget-object p1, p0, Lads_mobile_sdk/eo;->c:Lads_mobile_sdk/xq0;

    iput-object p0, v0, Lads_mobile_sdk/sn;->a:Lads_mobile_sdk/eo;

    iput v7, v0, Lads_mobile_sdk/sn;->d:I

    invoke-virtual {p1, v0}, Lads_mobile_sdk/xq0;->b(Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v8, :cond_6a

    goto :goto_b0

    :cond_6a
    :goto_6a
    iget-object p1, p0, Lads_mobile_sdk/eo;->d:Lads_mobile_sdk/a80;

    iput-object p0, v0, Lads_mobile_sdk/sn;->a:Lads_mobile_sdk/eo;

    iput v5, v0, Lads_mobile_sdk/sn;->d:I

    invoke-virtual {p1, v0}, Lads_mobile_sdk/a80;->a(Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v8, :cond_77

    goto :goto_b0

    :cond_77
    :goto_77
    iget-object p1, p0, Lads_mobile_sdk/eo;->e:Lads_mobile_sdk/o03;

    iput-object p0, v0, Lads_mobile_sdk/sn;->a:Lads_mobile_sdk/eo;

    iput v4, v0, Lads_mobile_sdk/sn;->d:I

    const-string v1, ""

    invoke-static {p1, v1, v0}, Lads_mobile_sdk/o03;->a(Lads_mobile_sdk/o03;Ljava/lang/String;Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v8, :cond_86

    goto :goto_b0

    :cond_86
    :goto_86
    iget-object p1, p0, Lads_mobile_sdk/eo;->f:Lads_mobile_sdk/aj;

    iput-object p0, v0, Lads_mobile_sdk/sn;->a:Lads_mobile_sdk/eo;

    iput v3, v0, Lads_mobile_sdk/sn;->d:I

    invoke-static {}, Lads_mobile_sdk/xi;->x()Lads_mobile_sdk/xi;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p1, p1, Lads_mobile_sdk/aj;->a:Lv03;

    invoke-interface {p1}, Lv03;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lc42;

    new-instance v3, Lc4;

    const/16 v4, 0x17

    invoke-direct {v3, v1, v2, v4}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    invoke-virtual {p1, v3, v0}, Lc42;->i(Lpk0;Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v8, :cond_a9

    goto :goto_aa

    :cond_a9
    move-object p1, v6

    :goto_aa
    if-ne p1, v8, :cond_ad

    goto :goto_ae

    :cond_ad
    move-object p1, v6

    :goto_ae
    if-ne p1, v8, :cond_b1

    :goto_b0
    return-object v8

    :cond_b1
    :goto_b1
    iget-object p0, p0, Lads_mobile_sdk/eo;->o:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    const-string p0, "Flags were reset because too many sessions have passed without updating flags"

    const/4 p1, 0x6

    invoke-static {p1, p0, v2}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    return-object v6
.end method

.method public static final a(Lads_mobile_sdk/eo;Landroid/app/ActivityManager;Lfx0;)Z
    .registers 19

    .prologue
    move-object/from16 v0, p2

    invoke-virtual/range {p0 .. p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-object/from16 v1, p0

    iget-object v1, v1, Lads_mobile_sdk/eo;->b:Landroid/content/Context;

    const-wide/high16 v2, 0x4000000000000000L  # 2.0

    invoke-static {v2, v3}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v2

    const-string v3, "gads:previous_exit_reason_reset_threshold"

    :try_start_11
    invoke-virtual {v0, v3}, Lfx0;->v(Ljava/lang/String;)Lkw0;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v3}, Lkw0;->c()D

    move-result-wide v3

    invoke-static {v3, v4}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v2
    :try_end_20
    .catch Ljava/lang/Exception; {:try_start_11 .. :try_end_20} :catch_20

    :catch_20
    invoke-virtual {v2}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v2

    const-wide/high16 v4, 0x4024000000000000L  # 10.0

    invoke-static {v2, v3, v4, v5}, Ljava/lang/Math;->min(DD)D

    move-result-wide v2

    const-wide/high16 v4, 0x3ff0000000000000L  # 1.0

    invoke-static {v4, v5, v2, v3}, Ljava/lang/Math;->max(DD)D

    move-result-wide v2

    double-to-int v6, v2

    mul-int/lit8 v6, v6, 0x2

    const/16 v7, 0xa

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    const-string v8, "gads:previous_exit_reasons_to_scan"

    :try_start_3b
    invoke-virtual {v0, v8}, Lfx0;->v(Ljava/lang/String;)Lkw0;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v8}, Lkw0;->e()I

    move-result v8

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7
    :try_end_4a
    .catch Ljava/lang/Exception; {:try_start_3b .. :try_end_4a} :catch_4a

    :catch_4a
    invoke-virtual {v7}, Ljava/lang/Number;->intValue()I

    move-result v7

    invoke-static {v6, v7}, Ljava/lang/Math;->max(II)I

    move-result v6

    const/16 v7, 0x14

    invoke-static {v6, v7}, Ljava/lang/Math;->min(II)I

    move-result v6

    const/4 v7, 0x1

    invoke-static {v7, v6}, Ljava/lang/Math;->max(II)I

    move-result v6

    const-string v8, "gads:previous_exit_reason_values"

    sget-object v9, Ld03;->a:Lads_mobile_sdk/ir0;

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v9, Lads_mobile_sdk/ir0;->b:Lfx0;

    :try_start_66
    invoke-virtual {v0, v8}, Lfx0;->v(Ljava/lang/String;)Lkw0;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v10, Lkm0;

    invoke-direct {v10}, Lkm0;-><init>()V

    invoke-virtual {v8}, Lkw0;->m()Ljava/lang/String;

    move-result-object v8

    const-class v11, Lfx0;

    invoke-virtual {v10, v11, v8}, Lkm0;->a(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lfx0;
    :try_end_7e
    .catch Ljava/lang/Exception; {:try_start_66 .. :try_end_7e} :catch_7f

    move-object v9, v8

    :catch_7f
    const-wide/high16 v10, 0x3fd0000000000000L  # 0.25

    invoke-static {v10, v11}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v8

    const-string v10, "gads:unspecified_exit_reason_value"

    :try_start_87
    invoke-virtual {v0, v10}, Lfx0;->v(Ljava/lang/String;)Lkw0;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Lkw0;->c()D

    move-result-wide v10

    invoke-static {v10, v11}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v8
    :try_end_96
    .catch Ljava/lang/Exception; {:try_start_87 .. :try_end_96} :catch_96

    :catch_96
    invoke-virtual {v8}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v10

    invoke-static {v4, v5, v10, v11}, Ljava/lang/Math;->min(DD)D

    move-result-wide v4

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x0

    move-object/from16 v10, p1

    invoke-virtual {v10, v0, v8, v6}, Landroid/app/ActivityManager;->getHistoricalProcessExitReasons(Ljava/lang/String;II)Ljava/util/List;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const-wide/16 v10, 0x0

    move-wide v12, v10

    :cond_b3
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    if-eqz v6, :cond_f2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    invoke-static {v6}, Ldm2;->g(Ljava/lang/Object;)Landroid/app/ApplicationExitInfo;

    move-result-object v6

    invoke-virtual {v6}, Landroid/app/ApplicationExitInfo;->getProcessName()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v15

    invoke-static {v14, v15}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v14

    if-eqz v14, :cond_b3

    invoke-virtual {v6}, Landroid/app/ApplicationExitInfo;->getReason()I

    move-result v6

    invoke-static {v6}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-nez v9, :cond_dd

    goto :goto_e6

    :cond_dd
    :try_start_dd
    invoke-virtual {v9, v6}, Lfx0;->v(Ljava/lang/String;)Lkw0;

    move-result-object v6

    invoke-virtual {v6}, Lkw0;->c()D

    move-result-wide v14
    :try_end_e5
    .catch Ljava/lang/Exception; {:try_start_dd .. :try_end_e5} :catch_e6

    goto :goto_e7

    :catch_e6
    :goto_e6
    move-wide v14, v4

    :goto_e7
    add-double/2addr v12, v14

    cmpg-double v6, v14, v10

    if-gez v6, :cond_ed

    goto :goto_f2

    :cond_ed
    cmpl-double v6, v12, v2

    if-ltz v6, :cond_b3

    goto :goto_f3

    :cond_f2
    :goto_f2
    move v7, v8

    :goto_f3
    return v7
.end method


# virtual methods
.method public final a(Lads_mobile_sdk/t70;Lwx;)Ljava/lang/Object;
    .registers 12

    .prologue
    const-string v0, "flagJson"

    instance-of v1, p2, Lads_mobile_sdk/xn;

    if-eqz v1, :cond_15

    move-object v1, p2

    check-cast v1, Lads_mobile_sdk/xn;

    iget v2, v1, Lads_mobile_sdk/xn;->f:I

    const/high16 v3, -0x80000000

    and-int v4, v2, v3

    if-eqz v4, :cond_15

    sub-int/2addr v2, v3

    iput v2, v1, Lads_mobile_sdk/xn;->f:I

    goto :goto_1a

    :cond_15
    new-instance v1, Lads_mobile_sdk/xn;

    invoke-direct {v1, p0, p2}, Lads_mobile_sdk/xn;-><init>(Lads_mobile_sdk/eo;Lwx;)V

    :goto_1a
    iget-object p2, v1, Lads_mobile_sdk/xn;->d:Ljava/lang/Object;

    iget v2, v1, Lads_mobile_sdk/xn;->f:I

    sget-object v3, Lrg2;->a:Lrg2;

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    sget-object v7, Lwy;->a:Lwy;

    if-eqz v2, :cond_4c

    if-eq v2, v5, :cond_3e

    if-ne v2, v4, :cond_38

    iget-object p0, v1, Lads_mobile_sdk/xn;->b:Ljava/lang/Object;

    check-cast p0, Llb1;

    iget-object p1, v1, Lads_mobile_sdk/xn;->a:Lads_mobile_sdk/eo;

    :try_start_31
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_34
    .catchall {:try_start_31 .. :try_end_34} :catchall_35

    goto :goto_86

    :catchall_35
    move-exception p1

    goto/16 :goto_1b7

    :cond_38
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v6

    :cond_3e
    iget-object p0, v1, Lads_mobile_sdk/xn;->c:Lnb1;

    iget-object p1, v1, Lads_mobile_sdk/xn;->b:Ljava/lang/Object;

    check-cast p1, Lads_mobile_sdk/t70;

    iget-object v2, v1, Lads_mobile_sdk/xn;->a:Lads_mobile_sdk/eo;

    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    move-object p2, p0

    move-object p0, v2

    goto :goto_60

    :cond_4c
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    iput-object p0, v1, Lads_mobile_sdk/xn;->a:Lads_mobile_sdk/eo;

    iput-object p1, v1, Lads_mobile_sdk/xn;->b:Ljava/lang/Object;

    iget-object p2, p0, Lads_mobile_sdk/eo;->i:Lnb1;

    iput-object p2, v1, Lads_mobile_sdk/xn;->c:Lnb1;

    iput v5, v1, Lads_mobile_sdk/xn;->f:I

    invoke-virtual {p2, v1}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v2

    if-ne v2, v7, :cond_60

    goto :goto_81

    :cond_60
    :goto_60
    if-nez p1, :cond_6f

    :try_start_62
    iget-object v2, p0, Lads_mobile_sdk/eo;->o:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v2

    if-nez v2, :cond_1b0

    goto :goto_6f

    :catchall_6b
    move-exception p1

    :goto_6c
    move-object p0, p2

    goto/16 :goto_1b7

    :cond_6f
    :goto_6f
    if-nez p1, :cond_8c

    iget-object p1, p0, Lads_mobile_sdk/eo;->d:Lads_mobile_sdk/a80;

    iput-object p0, v1, Lads_mobile_sdk/xn;->a:Lads_mobile_sdk/eo;

    iput-object p2, v1, Lads_mobile_sdk/xn;->b:Ljava/lang/Object;

    iput-object v6, v1, Lads_mobile_sdk/xn;->c:Lnb1;

    iput v4, v1, Lads_mobile_sdk/xn;->f:I

    invoke-static {p1, v1}, Lads_mobile_sdk/a80;->a(Lads_mobile_sdk/a80;Lwx;)Ljava/lang/Object;

    move-result-object p1
    :try_end_7f
    .catchall {:try_start_62 .. :try_end_7f} :catchall_6b

    if-ne p1, v7, :cond_82

    :goto_81
    return-object v7

    :cond_82
    move-object v8, p1

    move-object p1, p0

    move-object p0, p2

    move-object p2, v8

    :goto_86
    :try_start_86
    check-cast p2, Lads_mobile_sdk/t70;
    :try_end_88
    .catchall {:try_start_86 .. :try_end_88} :catchall_35

    move-object v8, p2

    move-object p2, p0

    move-object p0, p1

    move-object p1, v8

    :cond_8c
    :try_start_8c
    invoke-virtual {p1}, Lads_mobile_sdk/t70;->q()Lads_mobile_sdk/hb2;

    move-result-object v1

    invoke-virtual {v1}, Lads_mobile_sdk/hb2;->p()I

    move-result v1

    if-lez v1, :cond_d1

    invoke-virtual {p1}, Lads_mobile_sdk/t70;->r()Lads_mobile_sdk/mg2;

    move-result-object v1

    invoke-virtual {v1}, Lads_mobile_sdk/mg2;->p()I

    move-result v1

    if-lez v1, :cond_d1

    invoke-virtual {p1}, Lads_mobile_sdk/t70;->o()Ljava/util/Map;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {v1}, Ljava/util/Map;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_d1

    iget-object v0, p0, Lads_mobile_sdk/eo;->l:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {p1}, Lads_mobile_sdk/t70;->q()Lads_mobile_sdk/hb2;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    iget-object v0, p0, Lads_mobile_sdk/eo;->m:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {p1}, Lads_mobile_sdk/t70;->r()Lads_mobile_sdk/mg2;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    iget-object v0, p0, Lads_mobile_sdk/eo;->n:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {p1}, Lads_mobile_sdk/t70;->o()Ljava/util/Map;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    iget-object p0, p0, Lads_mobile_sdk/eo;->o:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {p0, v5}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V
    :try_end_cd
    .catchall {:try_start_8c .. :try_end_cd} :catchall_6b

    invoke-interface {p2, v6}, Llb1;->b(Ljava/lang/Object;)V

    return-object v3

    :cond_d1
    :try_start_d1
    const-string p1, "test_pattern_matching_flag"
    :try_end_d3
    .catchall {:try_start_d1 .. :try_end_d3} :catchall_6b

    :try_start_d3
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_d6
    .catchall {:try_start_d3 .. :try_end_d6} :catchall_1b4

    :try_start_d6
    iget-object v1, p0, Lads_mobile_sdk/eo;->j:Lfx0;

    if-eqz v1, :cond_e6

    invoke-virtual {v1, p1}, Lfx0;->v(Ljava/lang/String;)Lkw0;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Lkw0;->m()Ljava/lang/String;

    move-result-object p1

    goto :goto_eb

    :cond_e6
    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6
    :try_end_ea
    .catch Ljava/lang/Exception; {:try_start_d6 .. :try_end_ea} :catch_ea
    .catchall {:try_start_d6 .. :try_end_ea} :catchall_1b4

    :catch_ea
    move-object p1, v6

    :goto_eb
    const-string v1, ""

    if-nez p1, :cond_f0

    move-object p1, v1

    :cond_f0
    :try_start_f0
    const-string v2, "test_preprocessing_flag"
    :try_end_f2
    .catchall {:try_start_f0 .. :try_end_f2} :catchall_6b

    :try_start_f2
    iget-object v4, p0, Lads_mobile_sdk/eo;->j:Lfx0;

    if-eqz v4, :cond_102

    invoke-virtual {v4, v2}, Lfx0;->v(Ljava/lang/String;)Lkw0;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v2}, Lkw0;->m()Ljava/lang/String;

    move-result-object v2

    goto :goto_10c

    :cond_102
    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6
    :try_end_106
    .catch Ljava/lang/Exception; {:try_start_f2 .. :try_end_106} :catch_10b
    .catchall {:try_start_f2 .. :try_end_106} :catchall_109

    :goto_106
    move-object p1, p0

    goto/16 :goto_6c

    :catchall_109
    move-exception p0

    goto :goto_106

    :catch_10b
    move-object v2, v6

    :goto_10c
    if-nez v2, :cond_10f

    move-object v2, v1

    :cond_10f
    :try_start_10f
    const-string v4, "test_concatenated_signals_flag"
    :try_end_111
    .catchall {:try_start_10f .. :try_end_111} :catchall_6b

    :try_start_111
    iget-object v7, p0, Lads_mobile_sdk/eo;->j:Lfx0;

    if-eqz v7, :cond_121

    invoke-virtual {v7, v4}, Lfx0;->v(Ljava/lang/String;)Lkw0;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Lkw0;->m()Ljava/lang/String;

    move-result-object v0

    goto :goto_128

    :cond_121
    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6
    :try_end_125
    .catch Ljava/lang/Exception; {:try_start_111 .. :try_end_125} :catch_127
    .catchall {:try_start_111 .. :try_end_125} :catchall_125

    :catchall_125
    move-exception p0

    goto :goto_106

    :catch_127
    move-object v0, v6

    :goto_128
    if-nez v0, :cond_12b

    goto :goto_12c

    :cond_12b
    move-object v1, v0

    :goto_12c
    :try_start_12c
    invoke-static {p1}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_1b0

    invoke-static {v2}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_1b0

    invoke-static {v1}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_1b0

    iget-object v0, p0, Lads_mobile_sdk/eo;->l:Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v4, 0x0

    invoke-static {p1, v4}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object p1

    invoke-static {p1}, Lads_mobile_sdk/hb2;->a([B)Lads_mobile_sdk/hb2;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/eo;->m:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-static {v2, v4}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v0

    invoke-static {v0}, Lads_mobile_sdk/mg2;->a([B)Lads_mobile_sdk/mg2;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/eo;->n:Ljava/util/concurrent/atomic/AtomicReference;

    new-instance v0, Lkm0;

    invoke-direct {v0}, Lkm0;-><init>()V

    const-class v2, Lfx0;

    invoke-virtual {v0, v2, v1}, Lkm0;->a(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lfx0;

    iget-object v0, v0, Lfx0;->a:Lf21;

    new-instance v1, Ljava/util/LinkedHashMap;

    iget v2, v0, Lf21;->d:I

    invoke-static {v2}, Lb61;->Q(I)I

    move-result v2

    invoke-direct {v1, v2}, Ljava/util/LinkedHashMap;-><init>(I)V

    invoke-virtual {v0}, Lf21;->entrySet()Ljava/util/Set;

    move-result-object v0
    :try_end_179
    .catchall {:try_start_12c .. :try_end_179} :catchall_6b

    :try_start_179
    check-cast v0, Ld21;

    invoke-virtual {v0}, Ld21;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_17f
    move-object v2, v0

    check-cast v2, Lc21;

    invoke-virtual {v2}, Lc21;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1a8

    move-object v2, v0

    check-cast v2, Lc21;

    invoke-virtual {v2}, Lc21;->b()Le21;

    move-result-object v2
    :try_end_18f
    .catchall {:try_start_179 .. :try_end_18f} :catchall_1a5

    :try_start_18f
    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v4

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lkw0;

    invoke-virtual {v2}, Lkw0;->i()Lox0;

    move-result-object v2

    invoke-virtual {v2}, Lox0;->m()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v1, v4, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_17f

    :catchall_1a5
    move-exception p0

    goto/16 :goto_106

    :cond_1a8
    invoke-virtual {p1, v1}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    iget-object p0, p0, Lads_mobile_sdk/eo;->o:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {p0, v5}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V
    :try_end_1b0
    .catchall {:try_start_18f .. :try_end_1b0} :catchall_6b

    :cond_1b0
    invoke-interface {p2, v6}, Llb1;->b(Ljava/lang/Object;)V

    return-object v3

    :catchall_1b4
    move-exception p0

    goto/16 :goto_106

    :goto_1b7
    invoke-interface {p0, v6}, Llb1;->b(Ljava/lang/Object;)V

    throw p1
.end method

.method public final a(Ljava/lang/String;Lbk0;)Ljava/lang/Object;
    .registers 7

    .prologue
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Lads_mobile_sdk/eo;->g:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    const/4 v1, 0x0

    if-nez v0, :cond_20

    const-string v0, "Flags have not been initialized!"

    invoke-static {v0, v1}, Lads_mobile_sdk/nw;->b(Ljava/lang/String;Ljava/lang/Throwable;)V

    new-instance v2, Ljava/lang/IllegalStateException;

    invoke-direct {v2, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2}, Ljava/lang/Throwable;->printStackTrace()V

    sget-object v3, Lads_mobile_sdk/nw;->a:Lads_mobile_sdk/ah3;

    if-eqz v3, :cond_20

    invoke-virtual {v3, v0, v2}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_20
    :try_start_20
    iget-object p0, p0, Lads_mobile_sdk/eo;->j:Lfx0;

    if-eqz p0, :cond_30

    invoke-virtual {p0, p1}, Lfx0;->v(Ljava/lang/String;)Lkw0;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {p2, p0}, Lbk0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :cond_30
    const-string p0, "flagJson"

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v1
    :try_end_36
    .catch Ljava/lang/Exception; {:try_start_20 .. :try_end_36} :catch_36

    :catch_36
    return-object v1
.end method

.method public final a()V
    .registers 9

    .prologue
    const-string v0, "flagJson"

    const-string v1, "GoogleMobileAds"

    const/4 v2, 0x0

    iget-object v3, p0, Lads_mobile_sdk/eo;->b:Landroid/content/Context;

    invoke-virtual {v3, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v1

    const-string v2, "gads:initialize_webview_before_dagger"

    const/4 v3, 0x0

    :try_start_e
    iget-object v4, p0, Lads_mobile_sdk/eo;->j:Lfx0;

    if-eqz v4, :cond_22

    invoke-virtual {v4, v2}, Lfx0;->v(Ljava/lang/String;)Lkw0;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v2}, Lkw0;->b()Z

    move-result v2

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    goto :goto_27

    :cond_22
    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3
    :try_end_26
    .catch Ljava/lang/Exception; {:try_start_e .. :try_end_26} :catch_26

    :catch_26
    move-object v2, v3

    :goto_27
    sget-object v4, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-static {v2, v4}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    const-string v4, "early_webview_init_profiles"

    const-string v5, "early_webview_init_count"

    if-eqz v2, :cond_8e

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string v6, "gads:initialize_webview_before_dagger:count"

    :try_start_3c
    iget-object v7, p0, Lads_mobile_sdk/eo;->j:Lfx0;

    if-eqz v7, :cond_50

    invoke-virtual {v7, v6}, Lfx0;->v(Ljava/lang/String;)Lkw0;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v6}, Lkw0;->e()I

    move-result v6

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    goto :goto_55

    :cond_50
    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3
    :try_end_54
    .catch Ljava/lang/Exception; {:try_start_3c .. :try_end_54} :catch_54

    :catch_54
    move-object v6, v3

    :goto_55
    if-eqz v6, :cond_5c

    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    move-result v6

    goto :goto_5d

    :cond_5c
    const/4 v6, 0x5

    :goto_5d
    invoke-interface {v2, v5, v6}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    const-string v2, "gads:initialize_webview_before_dagger:profiles"

    :try_start_65
    iget-object p0, p0, Lads_mobile_sdk/eo;->j:Lfx0;

    if-eqz p0, :cond_75

    invoke-virtual {p0, v2}, Lfx0;->v(Ljava/lang/String;)Lkw0;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Lkw0;->m()Ljava/lang/String;

    move-result-object v3

    goto :goto_79

    :cond_75
    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3
    :try_end_79
    .catch Ljava/lang/Exception; {:try_start_65 .. :try_end_79} :catch_79

    :catch_79
    :goto_79
    if-nez v3, :cond_7d

    const-string v3, ""

    :cond_7d
    invoke-static {v3}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result p0

    if-nez p0, :cond_8d

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0, v4, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_8d
    return-void

    :cond_8e
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    invoke-interface {p0, v5}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    invoke-interface {p0, v4}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method
