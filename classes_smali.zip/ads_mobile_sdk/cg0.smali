.class public final Lads_mobile_sdk/cg0;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final q:Landroid/net/Uri;


# instance fields
.field public final a:Lly;

.field public final b:Lvy;

.field public final c:Lads_mobile_sdk/ux2;

.field public final d:Lads_mobile_sdk/ah3;

.field public final e:Lads_mobile_sdk/g0;

.field public final f:Lads_mobile_sdk/qr0;

.field public final g:Lads_mobile_sdk/ax0;

.field public final h:Lads_mobile_sdk/ek;

.field public final i:Lq63;

.field public final j:Lads_mobile_sdk/d91;

.field public final k:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public l:Ljava/lang/String;

.field public m:Ljava/lang/String;

.field public n:Lfx0;

.field public o:Lads_mobile_sdk/kh3;

.field public p:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-string v0, "https://support.google.com/dfp_premium/answer/7160685#push"

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    sput-object v0, Lads_mobile_sdk/cg0;->q:Landroid/net/Uri;

    return-void
.end method

.method public constructor <init>(Lly;Lvy;Lads_mobile_sdk/ux2;Lads_mobile_sdk/ah3;Lads_mobile_sdk/g0;Lads_mobile_sdk/qr0;Lads_mobile_sdk/ax0;Lads_mobile_sdk/ek;Lq63;Lads_mobile_sdk/d91;Ljava/lang/String;)V
    .registers 12

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/cg0;->a:Lly;

    iput-object p2, p0, Lads_mobile_sdk/cg0;->b:Lvy;

    iput-object p3, p0, Lads_mobile_sdk/cg0;->c:Lads_mobile_sdk/ux2;

    iput-object p4, p0, Lads_mobile_sdk/cg0;->d:Lads_mobile_sdk/ah3;

    iput-object p5, p0, Lads_mobile_sdk/cg0;->e:Lads_mobile_sdk/g0;

    iput-object p6, p0, Lads_mobile_sdk/cg0;->f:Lads_mobile_sdk/qr0;

    iput-object p7, p0, Lads_mobile_sdk/cg0;->g:Lads_mobile_sdk/ax0;

    iput-object p8, p0, Lads_mobile_sdk/cg0;->h:Lads_mobile_sdk/ek;

    iput-object p9, p0, Lads_mobile_sdk/cg0;->i:Lq63;

    iput-object p10, p0, Lads_mobile_sdk/cg0;->j:Lads_mobile_sdk/d91;

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 p2, 0x0

    invoke-direct {p1, p2}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object p1, p0, Lads_mobile_sdk/cg0;->k:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-static {}, Lsz;->d()Lads_mobile_sdk/kh3;

    move-result-object p1

    iput-object p1, p0, Lads_mobile_sdk/cg0;->o:Lads_mobile_sdk/kh3;

    return-void
.end method

.method public static synthetic a(Lads_mobile_sdk/cg0;Ljava/lang/String;Landroid/app/Activity;ZLwx;I)Ljava/lang/Object;
    .registers 9

    .prologue
    and-int/lit8 v0, p5, 0x1

    const/4 v1, 0x0

    if-eqz v0, :cond_7

    move v0, v1

    goto :goto_8

    :cond_7
    const/4 v0, 0x1

    :goto_8
    and-int/lit8 v2, p5, 0x2

    if-eqz v2, :cond_e

    const-string p1, "In-app preview failed to load because of a system error. Please try again later."

    :cond_e
    and-int/lit8 v2, p5, 0x4

    if-eqz v2, :cond_13

    const/4 p2, 0x0

    :cond_13
    and-int/lit8 p5, p5, 0x8

    if-eqz p5, :cond_1d

    move-object p5, p4

    move p4, v1

    :goto_19
    move-object p3, p2

    move-object p2, p1

    move p1, v0

    goto :goto_20

    :cond_1d
    move-object p5, p4

    move p4, p3

    goto :goto_19

    :goto_20
    invoke-virtual/range {p0 .. p5}, Lads_mobile_sdk/cg0;->a(ZLjava/lang/String;Landroid/app/Activity;ZLwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public static a(Lads_mobile_sdk/cg0;Ljava/lang/String;Ljava/lang/String;Lfx0;Lads_mobile_sdk/kh3;Lwx;)Ljava/lang/Object;
    .registers 22

    .prologue
    move-object/from16 v1, p0

    move-object/from16 v0, p4

    move-object/from16 v2, p5

    sget-object v3, Lrg2;->a:Lrg2;

    instance-of v4, v2, Lads_mobile_sdk/hf0;

    if-eqz v4, :cond_1b

    move-object v4, v2

    check-cast v4, Lads_mobile_sdk/hf0;

    iget v5, v4, Lads_mobile_sdk/hf0;->f:I

    const/high16 v6, -0x80000000

    and-int v7, v5, v6

    if-eqz v7, :cond_1b

    sub-int/2addr v5, v6

    iput v5, v4, Lads_mobile_sdk/hf0;->f:I

    goto :goto_20

    :cond_1b
    new-instance v4, Lads_mobile_sdk/hf0;

    invoke-direct {v4, v1, v2}, Lads_mobile_sdk/hf0;-><init>(Lads_mobile_sdk/cg0;Lwx;)V

    :goto_20
    iget-object v2, v4, Lads_mobile_sdk/hf0;->d:Ljava/lang/Object;

    sget-object v5, Lwy;->a:Lwy;

    iget v6, v4, Lads_mobile_sdk/hf0;->f:I

    const-string v7, "Failed to show debug menu dialog"

    const/4 v8, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x0

    if-eqz v6, :cond_57

    if-eq v6, v9, :cond_48

    if-ne v6, v8, :cond_42

    iget-object v1, v4, Lads_mobile_sdk/hf0;->c:Lads_mobile_sdk/rg3;

    iget-object v5, v4, Lads_mobile_sdk/hf0;->b:Lads_mobile_sdk/rg3;

    iget-object v4, v4, Lads_mobile_sdk/hf0;->a:Lads_mobile_sdk/cg0;

    :try_start_38
    invoke-static {v2}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_3b
    .catchall {:try_start_38 .. :try_end_3b} :catchall_3d

    goto/16 :goto_166

    :catchall_3d
    move-exception v0

    move-object v2, v1

    move-object v1, v4

    goto/16 :goto_14e

    :cond_42
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {v0}, Lz6;->w(Ljava/lang/String;)V

    return-object v11

    :cond_48
    iget-object v1, v4, Lads_mobile_sdk/hf0;->c:Lads_mobile_sdk/rg3;

    iget-object v5, v4, Lads_mobile_sdk/hf0;->b:Lads_mobile_sdk/rg3;

    iget-object v4, v4, Lads_mobile_sdk/hf0;->a:Lads_mobile_sdk/cg0;

    :try_start_4e
    invoke-static {v2}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_51
    .catchall {:try_start_4e .. :try_end_51} :catchall_53

    goto/16 :goto_d5

    :catchall_53
    move-exception v0

    move-object v2, v1

    move-object v1, v4

    goto :goto_bd

    :cond_57
    invoke-static {v2}, Lt12;->W(Ljava/lang/Object;)V

    iget-object v2, v1, Lads_mobile_sdk/cg0;->k:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v2, v9}, Ljava/util/concurrent/atomic/AtomicBoolean;->getAndSet(Z)Z

    move-result v2

    if-eqz v2, :cond_64

    goto/16 :goto_169

    :cond_64
    move-object/from16 v2, p1

    iput-object v2, v1, Lads_mobile_sdk/cg0;->l:Ljava/lang/String;

    move-object/from16 v2, p2

    iput-object v2, v1, Lads_mobile_sdk/cg0;->m:Ljava/lang/String;

    move-object/from16 v2, p3

    iput-object v2, v1, Lads_mobile_sdk/cg0;->n:Lfx0;

    iput-object v0, v1, Lads_mobile_sdk/cg0;->o:Lads_mobile_sdk/kh3;

    iget-object v2, v1, Lads_mobile_sdk/cg0;->c:Lads_mobile_sdk/ux2;

    sget-object v6, Lads_mobile_sdk/fw0;->Q0:Lads_mobile_sdk/fw0;

    sget-object v12, Lba0;->a:Lba0;

    invoke-static {}, Lads_mobile_sdk/hh3;->b()Lads_mobile_sdk/gh3;

    move-result-object v13

    iget-object v13, v13, Lads_mobile_sdk/gh3;->a:Lads_mobile_sdk/rg3;

    const/4 v14, 0x6

    const-string v15, "No Activity context available for displaying the debug menu."

    const-string v8, "Can not display debug menu without an Activity context."

    if-nez v13, :cond_116

    invoke-static {v2, v6, v12, v0}, Lads_mobile_sdk/ux2;->a(Lads_mobile_sdk/ux2;Lads_mobile_sdk/fw0;Ljava/util/List;Lads_mobile_sdk/kh3;)Lads_mobile_sdk/wk2;

    move-result-object v2

    :try_start_89
    iget-object v0, v1, Lads_mobile_sdk/cg0;->e:Lads_mobile_sdk/g0;

    invoke-virtual {v0}, Lads_mobile_sdk/g0;->b()Landroid/app/Activity;

    move-result-object v0

    if-nez v0, :cond_a2

    invoke-static {v8, v11}, Lads_mobile_sdk/nw;->c(Ljava/lang/String;Ljava/lang/Exception;)V

    invoke-static {v14, v15, v11}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    iget-object v0, v1, Lads_mobile_sdk/cg0;->k:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0, v10}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V
    :try_end_9c
    .catchall {:try_start_89 .. :try_end_9c} :catchall_a0

    invoke-virtual {v2}, Lads_mobile_sdk/rg3;->close()V

    return-object v3

    :catchall_a0
    move-exception v0

    goto :goto_de

    :cond_a2
    :try_start_a2
    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object v6, v1, Lads_mobile_sdk/cg0;->p:Ljava/lang/String;
    :try_end_ab
    .catchall {:try_start_a2 .. :try_end_ab} :catchall_a0

    :try_start_ab
    iput-object v1, v4, Lads_mobile_sdk/hf0;->a:Lads_mobile_sdk/cg0;

    iput-object v2, v4, Lads_mobile_sdk/hf0;->b:Lads_mobile_sdk/rg3;

    iput-object v2, v4, Lads_mobile_sdk/hf0;->c:Lads_mobile_sdk/rg3;

    iput v9, v4, Lads_mobile_sdk/hf0;->f:I

    invoke-virtual {v1, v0, v4}, Lads_mobile_sdk/cg0;->a(Landroid/app/Activity;Lwx;)Ljava/lang/Object;

    move-result-object v0
    :try_end_b7
    .catchall {:try_start_ab .. :try_end_b7} :catchall_bb

    if-ne v0, v5, :cond_d4

    goto/16 :goto_14b

    :catchall_bb
    move-exception v0

    move-object v5, v2

    :goto_bd
    :try_start_bd
    iget-object v4, v1, Lads_mobile_sdk/cg0;->k:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v4, v10}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    invoke-static {}, Lads_mobile_sdk/hh3;->a()Lads_mobile_sdk/rg3;

    move-result-object v4

    invoke-virtual {v4}, Lads_mobile_sdk/rg3;->e()Lads_mobile_sdk/ub2;

    move-result-object v6

    iput-boolean v10, v6, Lads_mobile_sdk/ub2;->m:Z

    invoke-virtual {v4, v0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    iget-object v1, v1, Lads_mobile_sdk/cg0;->d:Lads_mobile_sdk/ah3;

    invoke-virtual {v1, v7, v0}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_d4
    .catchall {:try_start_bd .. :try_end_d4} :catchall_da

    :cond_d4
    move-object v1, v2

    :goto_d5
    invoke-static {v1, v11}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    goto/16 :goto_169

    :catchall_da
    move-exception v0

    move-object v1, v2

    move-object v2, v5

    goto :goto_df

    :goto_de
    move-object v1, v2

    :goto_df
    :try_start_df
    invoke-virtual {v2, v0}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v3, v0, Lox2;

    if-nez v3, :cond_10f

    invoke-virtual {v2, v0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of v2, v0, Lza2;

    if-nez v2, :cond_107

    instance-of v2, v0, Ljava/util/concurrent/CancellationException;

    if-nez v2, :cond_ff

    instance-of v2, v0, Lads_mobile_sdk/mv0;

    if-eqz v2, :cond_f9

    throw v0

    :catchall_f6
    move-exception v0

    move-object v2, v0

    goto :goto_110

    :cond_f9
    new-instance v2, Lads_mobile_sdk/tu0;

    invoke-direct {v2, v0}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw v2

    :cond_ff
    new-instance v2, Lads_mobile_sdk/ou0;

    check-cast v0, Ljava/util/concurrent/CancellationException;

    invoke-direct {v2, v0}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw v2

    :cond_107
    new-instance v2, Lads_mobile_sdk/uw0;

    check-cast v0, Lza2;

    invoke-direct {v2, v0}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw v2

    :cond_10f
    throw v0
    :try_end_110
    .catchall {:try_start_df .. :try_end_110} :catchall_f6

    :goto_110
    :try_start_110
    throw v2
    :try_end_111
    .catchall {:try_start_110 .. :try_end_111} :catchall_111

    :catchall_111
    move-exception v0

    invoke-static {v1, v2}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0

    :cond_116
    invoke-static {v6, v12, v9}, Lads_mobile_sdk/hh3;->a(Lads_mobile_sdk/fw0;Ljava/util/List;Z)Lads_mobile_sdk/rg3;

    move-result-object v2

    :try_start_11a
    iget-object v0, v1, Lads_mobile_sdk/cg0;->e:Lads_mobile_sdk/g0;

    invoke-virtual {v0}, Lads_mobile_sdk/g0;->b()Landroid/app/Activity;

    move-result-object v0

    if-nez v0, :cond_133

    invoke-static {v8, v11}, Lads_mobile_sdk/nw;->c(Ljava/lang/String;Ljava/lang/Exception;)V

    invoke-static {v14, v15, v11}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    iget-object v0, v1, Lads_mobile_sdk/cg0;->k:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0, v10}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V
    :try_end_12d
    .catchall {:try_start_11a .. :try_end_12d} :catchall_131

    invoke-virtual {v2}, Lads_mobile_sdk/rg3;->close()V

    return-object v3

    :catchall_131
    move-exception v0

    goto :goto_16e

    :cond_133
    :try_start_133
    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object v6, v1, Lads_mobile_sdk/cg0;->p:Ljava/lang/String;
    :try_end_13c
    .catchall {:try_start_133 .. :try_end_13c} :catchall_131

    :try_start_13c
    iput-object v1, v4, Lads_mobile_sdk/hf0;->a:Lads_mobile_sdk/cg0;

    iput-object v2, v4, Lads_mobile_sdk/hf0;->b:Lads_mobile_sdk/rg3;

    iput-object v2, v4, Lads_mobile_sdk/hf0;->c:Lads_mobile_sdk/rg3;

    const/4 v6, 0x2

    iput v6, v4, Lads_mobile_sdk/hf0;->f:I

    invoke-virtual {v1, v0, v4}, Lads_mobile_sdk/cg0;->a(Landroid/app/Activity;Lwx;)Ljava/lang/Object;

    move-result-object v0
    :try_end_149
    .catchall {:try_start_13c .. :try_end_149} :catchall_14c

    if-ne v0, v5, :cond_165

    :goto_14b
    return-object v5

    :catchall_14c
    move-exception v0

    move-object v5, v2

    :goto_14e
    :try_start_14e
    iget-object v4, v1, Lads_mobile_sdk/cg0;->k:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v4, v10}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    invoke-static {}, Lads_mobile_sdk/hh3;->a()Lads_mobile_sdk/rg3;

    move-result-object v4

    invoke-virtual {v4}, Lads_mobile_sdk/rg3;->e()Lads_mobile_sdk/ub2;

    move-result-object v6

    iput-boolean v10, v6, Lads_mobile_sdk/ub2;->m:Z

    invoke-virtual {v4, v0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    iget-object v1, v1, Lads_mobile_sdk/cg0;->d:Lads_mobile_sdk/ah3;

    invoke-virtual {v1, v7, v0}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_165
    .catchall {:try_start_14e .. :try_end_165} :catchall_16a

    :cond_165
    move-object v1, v2

    :goto_166
    invoke-static {v1, v11}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    :goto_169
    return-object v3

    :catchall_16a
    move-exception v0

    move-object v1, v2

    move-object v2, v5

    goto :goto_16f

    :goto_16e
    move-object v1, v2

    :goto_16f
    :try_start_16f
    invoke-virtual {v2, v0}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v3, v0, Lox2;

    if-nez v3, :cond_19f

    invoke-virtual {v2, v0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of v2, v0, Lza2;

    if-nez v2, :cond_197

    instance-of v2, v0, Ljava/util/concurrent/CancellationException;

    if-nez v2, :cond_18f

    instance-of v2, v0, Lads_mobile_sdk/mv0;

    if-eqz v2, :cond_189

    throw v0

    :catchall_186
    move-exception v0

    move-object v2, v0

    goto :goto_1a0

    :cond_189
    new-instance v2, Lads_mobile_sdk/tu0;

    invoke-direct {v2, v0}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw v2

    :cond_18f
    new-instance v2, Lads_mobile_sdk/ou0;

    check-cast v0, Ljava/util/concurrent/CancellationException;

    invoke-direct {v2, v0}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw v2

    :cond_197
    new-instance v2, Lads_mobile_sdk/uw0;

    check-cast v0, Lza2;

    invoke-direct {v2, v0}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw v2

    :cond_19f
    throw v0
    :try_end_1a0
    .catchall {:try_start_16f .. :try_end_1a0} :catchall_186

    :goto_1a0
    :try_start_1a0
    throw v2
    :try_end_1a1
    .catchall {:try_start_1a0 .. :try_end_1a1} :catchall_1a1

    :catchall_1a1
    move-exception v0

    invoke-static {v1, v2}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0
.end method

.method public static final a(Lads_mobile_sdk/cg0;Lwx;)Ljava/lang/Object;
    .registers 18

    .prologue
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    sget-object v2, Lads_mobile_sdk/fo;->a$23:Lads_mobile_sdk/fo;

    sget-object v3, Lrg2;->a:Lrg2;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    instance-of v4, v1, Lads_mobile_sdk/ag0;

    if-eqz v4, :cond_1f

    move-object v4, v1

    check-cast v4, Lads_mobile_sdk/ag0;

    iget v5, v4, Lads_mobile_sdk/ag0;->i:I

    const/high16 v6, -0x80000000

    and-int v7, v5, v6

    if-eqz v7, :cond_1f

    sub-int/2addr v5, v6

    iput v5, v4, Lads_mobile_sdk/ag0;->i:I

    :goto_1d
    move-object v9, v4

    goto :goto_25

    :cond_1f
    new-instance v4, Lads_mobile_sdk/ag0;

    invoke-direct {v4, v0, v1}, Lads_mobile_sdk/ag0;-><init>(Lads_mobile_sdk/cg0;Lwx;)V

    goto :goto_1d

    :goto_25
    iget-object v1, v9, Lads_mobile_sdk/ag0;->g:Ljava/lang/Object;

    sget-object v4, Lwy;->a:Lwy;

    iget v5, v9, Lads_mobile_sdk/ag0;->i:I

    const-string v7, "https://www.google.com/dfp/sendDebugData"

    const-string v8, "gads:drx_debug:send_debug_data_url"

    const/4 v10, 0x0

    const/4 v11, 0x0

    packed-switch v5, :pswitch_data_37e

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {v0}, Lz6;->w(Ljava/lang/String;)V

    return-object v11

    :pswitch_3a  #0xa
    iget-object v2, v9, Lads_mobile_sdk/ag0;->b:Ljava/io/Closeable;

    iget-object v0, v9, Lads_mobile_sdk/ag0;->a:Ljava/lang/Object;

    move-object v4, v0

    check-cast v4, Lads_mobile_sdk/rg3;

    :try_start_41
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_44
    .catchall {:try_start_41 .. :try_end_44} :catchall_46

    goto/16 :goto_33f

    :catchall_46
    move-exception v0

    goto/16 :goto_346

    :pswitch_49  #0x9
    iget-object v2, v9, Lads_mobile_sdk/ag0;->b:Ljava/io/Closeable;

    iget-object v0, v9, Lads_mobile_sdk/ag0;->a:Ljava/lang/Object;

    move-object v4, v0

    check-cast v4, Lads_mobile_sdk/rg3;

    :try_start_50
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_53
    .catchall {:try_start_50 .. :try_end_53} :catchall_46

    goto/16 :goto_324

    :pswitch_55  #0x8
    iget-object v0, v9, Lads_mobile_sdk/ag0;->d:Landroid/app/Activity;

    iget-object v2, v9, Lads_mobile_sdk/ag0;->c:Ljava/io/Closeable;

    iget-object v5, v9, Lads_mobile_sdk/ag0;->b:Ljava/io/Closeable;

    check-cast v5, Lads_mobile_sdk/rg3;

    iget-object v6, v9, Lads_mobile_sdk/ag0;->a:Ljava/lang/Object;

    check-cast v6, Lads_mobile_sdk/cg0;

    :try_start_61
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_64
    .catchall {:try_start_61 .. :try_end_64} :catchall_69

    move-object v7, v0

    move-object v12, v5

    :goto_66
    move-object v5, v6

    goto/16 :goto_306

    :catchall_69
    move-exception v0

    move-object v4, v5

    goto/16 :goto_346

    :pswitch_6d  #0x7
    iget-object v0, v9, Lads_mobile_sdk/ag0;->e:Lq63;

    iget-object v2, v9, Lads_mobile_sdk/ag0;->d:Landroid/app/Activity;

    iget-object v5, v9, Lads_mobile_sdk/ag0;->c:Ljava/io/Closeable;

    iget-object v7, v9, Lads_mobile_sdk/ag0;->b:Ljava/io/Closeable;

    check-cast v7, Lads_mobile_sdk/rg3;

    iget-object v8, v9, Lads_mobile_sdk/ag0;->a:Ljava/lang/Object;

    check-cast v8, Lads_mobile_sdk/cg0;

    :try_start_7b
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_7e
    .catchall {:try_start_7b .. :try_end_7e} :catchall_81

    move-object v6, v8

    goto/16 :goto_2d9

    :catchall_81
    move-exception v0

    goto/16 :goto_300

    :pswitch_84  #0x6
    iget-boolean v0, v9, Lads_mobile_sdk/ag0;->f:Z

    iget-object v5, v9, Lads_mobile_sdk/ag0;->d:Landroid/app/Activity;

    iget-object v10, v9, Lads_mobile_sdk/ag0;->c:Ljava/io/Closeable;

    iget-object v12, v9, Lads_mobile_sdk/ag0;->b:Ljava/io/Closeable;

    check-cast v12, Lads_mobile_sdk/rg3;

    iget-object v13, v9, Lads_mobile_sdk/ag0;->a:Ljava/lang/Object;

    check-cast v13, Lads_mobile_sdk/cg0;

    :try_start_92
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_95
    .catchall {:try_start_92 .. :try_end_95} :catchall_99

    move v6, v0

    move-object v0, v13

    goto/16 :goto_28b

    :catchall_99
    move-exception v0

    move-object v2, v10

    :goto_9b
    move-object v4, v12

    goto/16 :goto_346

    :pswitch_9e  #0x5
    iget-object v2, v9, Lads_mobile_sdk/ag0;->b:Ljava/io/Closeable;

    iget-object v0, v9, Lads_mobile_sdk/ag0;->a:Ljava/lang/Object;

    move-object v4, v0

    check-cast v4, Lads_mobile_sdk/rg3;

    :try_start_a5
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_a8
    .catchall {:try_start_a5 .. :try_end_a8} :catchall_aa

    goto/16 :goto_20c

    :catchall_aa
    move-exception v0

    goto/16 :goto_213

    :pswitch_ad  #0x4
    iget-object v2, v9, Lads_mobile_sdk/ag0;->b:Ljava/io/Closeable;

    iget-object v0, v9, Lads_mobile_sdk/ag0;->a:Ljava/lang/Object;

    move-object v4, v0

    check-cast v4, Lads_mobile_sdk/rg3;

    :try_start_b4
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_b7
    .catchall {:try_start_b4 .. :try_end_b7} :catchall_aa

    goto/16 :goto_1f1

    :pswitch_b9  #0x3
    iget-object v0, v9, Lads_mobile_sdk/ag0;->d:Landroid/app/Activity;

    iget-object v2, v9, Lads_mobile_sdk/ag0;->c:Ljava/io/Closeable;

    iget-object v5, v9, Lads_mobile_sdk/ag0;->b:Ljava/io/Closeable;

    check-cast v5, Lads_mobile_sdk/rg3;

    iget-object v6, v9, Lads_mobile_sdk/ag0;->a:Ljava/lang/Object;

    check-cast v6, Lads_mobile_sdk/cg0;

    :try_start_c5
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_c8
    .catchall {:try_start_c5 .. :try_end_c8} :catchall_cd

    move-object v7, v0

    move-object v12, v5

    :goto_ca
    move-object v5, v6

    goto/16 :goto_1d3

    :catchall_cd
    move-exception v0

    move-object v4, v5

    goto/16 :goto_213

    :pswitch_d1  #0x2
    iget-object v0, v9, Lads_mobile_sdk/ag0;->e:Lq63;

    iget-object v2, v9, Lads_mobile_sdk/ag0;->d:Landroid/app/Activity;

    iget-object v5, v9, Lads_mobile_sdk/ag0;->c:Ljava/io/Closeable;

    iget-object v7, v9, Lads_mobile_sdk/ag0;->b:Ljava/io/Closeable;

    check-cast v7, Lads_mobile_sdk/rg3;

    iget-object v8, v9, Lads_mobile_sdk/ag0;->a:Ljava/lang/Object;

    check-cast v8, Lads_mobile_sdk/cg0;

    :try_start_df
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_e2
    .catchall {:try_start_df .. :try_end_e2} :catchall_e5

    move-object v6, v8

    goto/16 :goto_1a6

    :catchall_e5
    move-exception v0

    goto/16 :goto_1cd

    :pswitch_e8  #0x1
    iget-boolean v0, v9, Lads_mobile_sdk/ag0;->f:Z

    iget-object v5, v9, Lads_mobile_sdk/ag0;->d:Landroid/app/Activity;

    iget-object v10, v9, Lads_mobile_sdk/ag0;->c:Ljava/io/Closeable;

    iget-object v12, v9, Lads_mobile_sdk/ag0;->b:Ljava/io/Closeable;

    check-cast v12, Lads_mobile_sdk/rg3;

    iget-object v13, v9, Lads_mobile_sdk/ag0;->a:Ljava/lang/Object;

    check-cast v13, Lads_mobile_sdk/cg0;

    :try_start_f6
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_f9
    .catchall {:try_start_f6 .. :try_end_f9} :catchall_fc

    move v6, v0

    move-object v0, v13

    goto :goto_158

    :catchall_fc
    move-exception v0

    move-object v2, v10

    :goto_fe
    move-object v4, v12

    goto/16 :goto_213

    :pswitch_101  #0x0
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object v1, v0, Lads_mobile_sdk/cg0;->c:Lads_mobile_sdk/ux2;

    sget-object v5, Lads_mobile_sdk/fw0;->T0:Lads_mobile_sdk/fw0;

    iget-object v12, v0, Lads_mobile_sdk/cg0;->o:Lads_mobile_sdk/kh3;

    sget-object v13, Lba0;->a:Lba0;

    invoke-static {}, Lads_mobile_sdk/hh3;->b()Lads_mobile_sdk/gh3;

    move-result-object v14

    iget-object v14, v14, Lads_mobile_sdk/gh3;->a:Lads_mobile_sdk/rg3;

    const-string v6, "No Activity context available for starting debug signals."

    const/4 v15, 0x6

    if-nez v14, :cond_24a

    invoke-static {v1, v5, v13, v12}, Lads_mobile_sdk/ux2;->a(Lads_mobile_sdk/ux2;Lads_mobile_sdk/fw0;Ljava/util/List;Lads_mobile_sdk/kh3;)Lads_mobile_sdk/wk2;

    move-result-object v1

    :try_start_11b
    iget-object v5, v0, Lads_mobile_sdk/cg0;->e:Lads_mobile_sdk/g0;

    invoke-virtual {v5}, Lads_mobile_sdk/g0;->b()Landroid/app/Activity;

    move-result-object v5

    if-nez v5, :cond_12f

    invoke-static {v15, v6, v11}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    iget-object v0, v0, Lads_mobile_sdk/cg0;->k:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0, v10}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V
    :try_end_12b
    .catchall {:try_start_11b .. :try_end_12b} :catchall_210

    invoke-virtual {v1}, Lads_mobile_sdk/rg3;->close()V

    return-object v3

    :cond_12f
    :try_start_12f
    iget-object v6, v0, Lads_mobile_sdk/cg0;->h:Lads_mobile_sdk/ek;

    iget-object v6, v6, Lads_mobile_sdk/ek;->h:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v6}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v6

    iget-object v10, v0, Lads_mobile_sdk/cg0;->j:Lads_mobile_sdk/d91;

    iget-object v12, v0, Lads_mobile_sdk/cg0;->l:Ljava/lang/String;

    iget-object v13, v0, Lads_mobile_sdk/cg0;->n:Lfx0;

    iput-object v0, v9, Lads_mobile_sdk/ag0;->a:Ljava/lang/Object;

    iput-object v1, v9, Lads_mobile_sdk/ag0;->b:Ljava/io/Closeable;

    iput-object v1, v9, Lads_mobile_sdk/ag0;->c:Ljava/io/Closeable;

    iput-object v5, v9, Lads_mobile_sdk/ag0;->d:Landroid/app/Activity;

    iput-boolean v6, v9, Lads_mobile_sdk/ag0;->f:Z

    const/4 v14, 0x1

    iput v14, v9, Lads_mobile_sdk/ag0;->i:I

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v10, v12, v13, v9}, Lads_mobile_sdk/d91;->a(Lads_mobile_sdk/d91;Ljava/lang/String;Lfx0;Lwx;)Ljava/lang/Object;

    move-result-object v10
    :try_end_151
    .catchall {:try_start_12f .. :try_end_151} :catchall_210

    if-ne v10, v4, :cond_155

    goto/16 :goto_33d

    :cond_155
    move-object v12, v1

    move-object v1, v10

    move-object v10, v12

    :goto_158
    :try_start_158
    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    iget-object v13, v0, Lads_mobile_sdk/cg0;->h:Lads_mobile_sdk/ek;

    iget-object v13, v13, Lads_mobile_sdk/ek;->h:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v13, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    iget-object v1, v0, Lads_mobile_sdk/cg0;->h:Lads_mobile_sdk/ek;

    iget-object v1, v1, Lads_mobile_sdk/ek;->h:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v1

    if-eqz v1, :cond_1f8

    if-nez v6, :cond_1d0

    iget-object v1, v0, Lads_mobile_sdk/cg0;->n:Lfx0;

    if-eqz v1, :cond_1d0

    iget-object v1, v0, Lads_mobile_sdk/cg0;->i:Lq63;

    iget-object v6, v0, Lads_mobile_sdk/cg0;->f:Lads_mobile_sdk/qr0;

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v6, v8, v7, v2}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    iput-object v0, v9, Lads_mobile_sdk/ag0;->a:Ljava/lang/Object;

    iput-object v12, v9, Lads_mobile_sdk/ag0;->b:Ljava/io/Closeable;

    iput-object v10, v9, Lads_mobile_sdk/ag0;->c:Ljava/io/Closeable;

    iput-object v5, v9, Lads_mobile_sdk/ag0;->d:Landroid/app/Activity;

    iput-object v1, v9, Lads_mobile_sdk/ag0;->e:Lq63;

    const/4 v6, 0x2

    iput v6, v9, Lads_mobile_sdk/ag0;->i:I

    iget-object v6, v0, Lads_mobile_sdk/cg0;->l:Ljava/lang/String;

    iget-object v7, v0, Lads_mobile_sdk/cg0;->n:Lfx0;

    iget-object v8, v0, Lads_mobile_sdk/cg0;->j:Lads_mobile_sdk/d91;

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v8, v2, v6, v7, v9}, Lads_mobile_sdk/d91;->a(Lads_mobile_sdk/d91;Ljava/lang/String;Ljava/lang/String;Lfx0;Lwx;)Ljava/lang/Comparable;

    move-result-object v2
    :try_end_19c
    .catchall {:try_start_158 .. :try_end_19c} :catchall_fc

    if-ne v2, v4, :cond_1a0

    goto/16 :goto_33d

    :cond_1a0
    move-object v6, v0

    move-object v0, v1

    move-object v1, v2

    move-object v2, v5

    move-object v5, v10

    move-object v7, v12

    :goto_1a6
    :try_start_1a6
    check-cast v1, Landroid/net/Uri;

    invoke-virtual {v1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v1

    new-instance v8, Ljava/net/URL;

    invoke-direct {v8, v1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    iput-object v6, v9, Lads_mobile_sdk/ag0;->a:Ljava/lang/Object;

    iput-object v7, v9, Lads_mobile_sdk/ag0;->b:Ljava/io/Closeable;

    iput-object v5, v9, Lads_mobile_sdk/ag0;->c:Ljava/io/Closeable;

    iput-object v2, v9, Lads_mobile_sdk/ag0;->d:Landroid/app/Activity;

    iput-object v11, v9, Lads_mobile_sdk/ag0;->e:Lq63;

    const/4 v1, 0x3

    iput v1, v9, Lads_mobile_sdk/ag0;->i:I

    const/16 v1, 0x1e

    invoke-static {v0, v8, v11, v9, v1}, Lq63;->a(Lq63;Ljava/net/URL;Ljava/util/Map;Lwx;I)Ljava/lang/Object;

    move-result-object v0
    :try_end_1c4
    .catchall {:try_start_1a6 .. :try_end_1c4} :catchall_e5

    if-ne v0, v4, :cond_1c8

    goto/16 :goto_33d

    :cond_1c8
    move-object v12, v7

    move-object v7, v2

    move-object v2, v5

    goto/16 :goto_ca

    :goto_1cd
    move-object v2, v5

    move-object v4, v7

    goto :goto_213

    :cond_1d0
    move-object v7, v5

    move-object v2, v10

    move-object v5, v0

    :goto_1d3
    :try_start_1d3
    const-string v6, "The device is successfully linked for troubleshooting."

    iput-object v12, v9, Lads_mobile_sdk/ag0;->a:Ljava/lang/Object;

    iput-object v2, v9, Lads_mobile_sdk/ag0;->b:Ljava/io/Closeable;

    iput-object v11, v9, Lads_mobile_sdk/ag0;->c:Ljava/io/Closeable;

    iput-object v11, v9, Lads_mobile_sdk/ag0;->d:Landroid/app/Activity;

    const/4 v0, 0x4

    iput v0, v9, Lads_mobile_sdk/ag0;->i:I

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v10, 0x1

    const/4 v8, 0x0

    invoke-static/range {v5 .. v10}, Lads_mobile_sdk/cg0;->a(Lads_mobile_sdk/cg0;Ljava/lang/String;Landroid/app/Activity;ZLwx;I)Ljava/lang/Object;

    move-result-object v0
    :try_end_1e9
    .catchall {:try_start_1d3 .. :try_end_1e9} :catchall_1f5

    if-ne v0, v4, :cond_1ec

    goto :goto_1ed

    :cond_1ec
    move-object v0, v3

    :goto_1ed
    if-ne v0, v4, :cond_1f1

    goto/16 :goto_33d

    :cond_1f1
    :goto_1f1
    invoke-static {v2, v11}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object v3

    :catchall_1f5
    move-exception v0

    goto/16 :goto_fe

    :cond_1f8
    :try_start_1f8
    iput-object v12, v9, Lads_mobile_sdk/ag0;->a:Ljava/lang/Object;

    iput-object v10, v9, Lads_mobile_sdk/ag0;->b:Ljava/io/Closeable;

    iput-object v11, v9, Lads_mobile_sdk/ag0;->c:Ljava/io/Closeable;

    iput-object v11, v9, Lads_mobile_sdk/ag0;->d:Landroid/app/Activity;

    const/4 v1, 0x5

    iput v1, v9, Lads_mobile_sdk/ag0;->i:I

    invoke-virtual {v0, v9}, Lads_mobile_sdk/cg0;->c(Lwx;)Ljava/lang/Object;

    move-result-object v0
    :try_end_207
    .catchall {:try_start_1f8 .. :try_end_207} :catchall_fc

    if-ne v0, v4, :cond_20b

    goto/16 :goto_33d

    :cond_20b
    move-object v2, v10

    :goto_20c
    invoke-static {v2, v11}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object v3

    :catchall_210
    move-exception v0

    move-object v2, v1

    move-object v4, v2

    :goto_213
    :try_start_213
    invoke-virtual {v4, v0}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v1, v0, Lox2;

    if-nez v1, :cond_243

    invoke-virtual {v4, v0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of v1, v0, Lza2;

    if-nez v1, :cond_23b

    instance-of v1, v0, Ljava/util/concurrent/CancellationException;

    if-nez v1, :cond_233

    instance-of v1, v0, Lads_mobile_sdk/mv0;

    if-eqz v1, :cond_22d

    throw v0

    :catchall_22a
    move-exception v0

    move-object v1, v0

    goto :goto_244

    :cond_22d
    new-instance v1, Lads_mobile_sdk/tu0;

    invoke-direct {v1, v0}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw v1

    :cond_233
    new-instance v1, Lads_mobile_sdk/ou0;

    check-cast v0, Ljava/util/concurrent/CancellationException;

    invoke-direct {v1, v0}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw v1

    :cond_23b
    new-instance v1, Lads_mobile_sdk/uw0;

    check-cast v0, Lza2;

    invoke-direct {v1, v0}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw v1

    :cond_243
    throw v0
    :try_end_244
    .catchall {:try_start_213 .. :try_end_244} :catchall_22a

    :goto_244
    :try_start_244
    throw v1
    :try_end_245
    .catchall {:try_start_244 .. :try_end_245} :catchall_245

    :catchall_245
    move-exception v0

    invoke-static {v2, v1}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0

    :cond_24a
    const/4 v14, 0x1

    invoke-static {v5, v13, v14}, Lads_mobile_sdk/hh3;->a(Lads_mobile_sdk/fw0;Ljava/util/List;Z)Lads_mobile_sdk/rg3;

    move-result-object v1

    :try_start_24f
    iget-object v5, v0, Lads_mobile_sdk/cg0;->e:Lads_mobile_sdk/g0;

    invoke-virtual {v5}, Lads_mobile_sdk/g0;->b()Landroid/app/Activity;

    move-result-object v5

    if-nez v5, :cond_263

    invoke-static {v15, v6, v11}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    iget-object v0, v0, Lads_mobile_sdk/cg0;->k:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0, v10}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V
    :try_end_25f
    .catchall {:try_start_24f .. :try_end_25f} :catchall_343

    invoke-virtual {v1}, Lads_mobile_sdk/rg3;->close()V

    return-object v3

    :cond_263
    :try_start_263
    iget-object v6, v0, Lads_mobile_sdk/cg0;->h:Lads_mobile_sdk/ek;

    iget-object v6, v6, Lads_mobile_sdk/ek;->h:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v6}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v6

    iget-object v10, v0, Lads_mobile_sdk/cg0;->j:Lads_mobile_sdk/d91;

    iget-object v12, v0, Lads_mobile_sdk/cg0;->l:Ljava/lang/String;

    iget-object v13, v0, Lads_mobile_sdk/cg0;->n:Lfx0;

    iput-object v0, v9, Lads_mobile_sdk/ag0;->a:Ljava/lang/Object;

    iput-object v1, v9, Lads_mobile_sdk/ag0;->b:Ljava/io/Closeable;

    iput-object v1, v9, Lads_mobile_sdk/ag0;->c:Ljava/io/Closeable;

    iput-object v5, v9, Lads_mobile_sdk/ag0;->d:Landroid/app/Activity;

    iput-boolean v6, v9, Lads_mobile_sdk/ag0;->f:Z

    iput v15, v9, Lads_mobile_sdk/ag0;->i:I

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v10, v12, v13, v9}, Lads_mobile_sdk/d91;->a(Lads_mobile_sdk/d91;Ljava/lang/String;Lfx0;Lwx;)Ljava/lang/Object;

    move-result-object v10
    :try_end_284
    .catchall {:try_start_263 .. :try_end_284} :catchall_343

    if-ne v10, v4, :cond_288

    goto/16 :goto_33d

    :cond_288
    move-object v12, v1

    move-object v1, v10

    move-object v10, v12

    :goto_28b
    :try_start_28b
    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    iget-object v13, v0, Lads_mobile_sdk/cg0;->h:Lads_mobile_sdk/ek;

    iget-object v13, v13, Lads_mobile_sdk/ek;->h:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v13, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    iget-object v1, v0, Lads_mobile_sdk/cg0;->h:Lads_mobile_sdk/ek;

    iget-object v1, v1, Lads_mobile_sdk/ek;->h:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v1

    if-eqz v1, :cond_32b

    if-nez v6, :cond_303

    iget-object v1, v0, Lads_mobile_sdk/cg0;->n:Lfx0;

    if-eqz v1, :cond_303

    iget-object v1, v0, Lads_mobile_sdk/cg0;->i:Lq63;

    iget-object v6, v0, Lads_mobile_sdk/cg0;->f:Lads_mobile_sdk/qr0;

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v6, v8, v7, v2}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    iput-object v0, v9, Lads_mobile_sdk/ag0;->a:Ljava/lang/Object;

    iput-object v12, v9, Lads_mobile_sdk/ag0;->b:Ljava/io/Closeable;

    iput-object v10, v9, Lads_mobile_sdk/ag0;->c:Ljava/io/Closeable;

    iput-object v5, v9, Lads_mobile_sdk/ag0;->d:Landroid/app/Activity;

    iput-object v1, v9, Lads_mobile_sdk/ag0;->e:Lq63;

    const/4 v6, 0x7

    iput v6, v9, Lads_mobile_sdk/ag0;->i:I

    iget-object v6, v0, Lads_mobile_sdk/cg0;->l:Ljava/lang/String;

    iget-object v7, v0, Lads_mobile_sdk/cg0;->n:Lfx0;

    iget-object v8, v0, Lads_mobile_sdk/cg0;->j:Lads_mobile_sdk/d91;

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v8, v2, v6, v7, v9}, Lads_mobile_sdk/d91;->a(Lads_mobile_sdk/d91;Ljava/lang/String;Ljava/lang/String;Lfx0;Lwx;)Ljava/lang/Comparable;

    move-result-object v2
    :try_end_2cf
    .catchall {:try_start_28b .. :try_end_2cf} :catchall_99

    if-ne v2, v4, :cond_2d3

    goto/16 :goto_33d

    :cond_2d3
    move-object v6, v0

    move-object v0, v1

    move-object v1, v2

    move-object v2, v5

    move-object v5, v10

    move-object v7, v12

    :goto_2d9
    :try_start_2d9
    check-cast v1, Landroid/net/Uri;

    invoke-virtual {v1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v1

    new-instance v8, Ljava/net/URL;

    invoke-direct {v8, v1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    iput-object v6, v9, Lads_mobile_sdk/ag0;->a:Ljava/lang/Object;

    iput-object v7, v9, Lads_mobile_sdk/ag0;->b:Ljava/io/Closeable;

    iput-object v5, v9, Lads_mobile_sdk/ag0;->c:Ljava/io/Closeable;

    iput-object v2, v9, Lads_mobile_sdk/ag0;->d:Landroid/app/Activity;

    iput-object v11, v9, Lads_mobile_sdk/ag0;->e:Lq63;

    const/16 v1, 0x8

    iput v1, v9, Lads_mobile_sdk/ag0;->i:I

    const/16 v1, 0x1e

    invoke-static {v0, v8, v11, v9, v1}, Lq63;->a(Lq63;Ljava/net/URL;Ljava/util/Map;Lwx;I)Ljava/lang/Object;

    move-result-object v0
    :try_end_2f8
    .catchall {:try_start_2d9 .. :try_end_2f8} :catchall_81

    if-ne v0, v4, :cond_2fb

    goto :goto_33d

    :cond_2fb
    move-object v12, v7

    move-object v7, v2

    move-object v2, v5

    goto/16 :goto_66

    :goto_300
    move-object v2, v5

    move-object v4, v7

    goto :goto_346

    :cond_303
    move-object v7, v5

    move-object v2, v10

    move-object v5, v0

    :goto_306
    :try_start_306
    const-string v6, "The device is successfully linked for troubleshooting."

    iput-object v12, v9, Lads_mobile_sdk/ag0;->a:Ljava/lang/Object;

    iput-object v2, v9, Lads_mobile_sdk/ag0;->b:Ljava/io/Closeable;

    iput-object v11, v9, Lads_mobile_sdk/ag0;->c:Ljava/io/Closeable;

    iput-object v11, v9, Lads_mobile_sdk/ag0;->d:Landroid/app/Activity;

    const/16 v0, 0x9

    iput v0, v9, Lads_mobile_sdk/ag0;->i:I

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v10, 0x1

    const/4 v8, 0x0

    invoke-static/range {v5 .. v10}, Lads_mobile_sdk/cg0;->a(Lads_mobile_sdk/cg0;Ljava/lang/String;Landroid/app/Activity;ZLwx;I)Ljava/lang/Object;

    move-result-object v0
    :try_end_31d
    .catchall {:try_start_306 .. :try_end_31d} :catchall_328

    if-ne v0, v4, :cond_320

    goto :goto_321

    :cond_320
    move-object v0, v3

    :goto_321
    if-ne v0, v4, :cond_324

    goto :goto_33d

    :cond_324
    :goto_324
    invoke-static {v2, v11}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object v3

    :catchall_328
    move-exception v0

    goto/16 :goto_9b

    :cond_32b
    :try_start_32b
    iput-object v12, v9, Lads_mobile_sdk/ag0;->a:Ljava/lang/Object;

    iput-object v10, v9, Lads_mobile_sdk/ag0;->b:Ljava/io/Closeable;

    iput-object v11, v9, Lads_mobile_sdk/ag0;->c:Ljava/io/Closeable;

    iput-object v11, v9, Lads_mobile_sdk/ag0;->d:Landroid/app/Activity;

    const/16 v1, 0xa

    iput v1, v9, Lads_mobile_sdk/ag0;->i:I

    invoke-virtual {v0, v9}, Lads_mobile_sdk/cg0;->c(Lwx;)Ljava/lang/Object;

    move-result-object v0
    :try_end_33b
    .catchall {:try_start_32b .. :try_end_33b} :catchall_99

    if-ne v0, v4, :cond_33e

    :goto_33d
    return-object v4

    :cond_33e
    move-object v2, v10

    :goto_33f
    invoke-static {v2, v11}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object v3

    :catchall_343
    move-exception v0

    move-object v2, v1

    move-object v4, v2

    :goto_346
    :try_start_346
    invoke-virtual {v4, v0}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v1, v0, Lox2;

    if-nez v1, :cond_376

    invoke-virtual {v4, v0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of v1, v0, Lza2;

    if-nez v1, :cond_36e

    instance-of v1, v0, Ljava/util/concurrent/CancellationException;

    if-nez v1, :cond_366

    instance-of v1, v0, Lads_mobile_sdk/mv0;

    if-eqz v1, :cond_360

    throw v0

    :catchall_35d
    move-exception v0

    move-object v1, v0

    goto :goto_377

    :cond_360
    new-instance v1, Lads_mobile_sdk/tu0;

    invoke-direct {v1, v0}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw v1

    :cond_366
    new-instance v1, Lads_mobile_sdk/ou0;

    check-cast v0, Ljava/util/concurrent/CancellationException;

    invoke-direct {v1, v0}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw v1

    :cond_36e
    new-instance v1, Lads_mobile_sdk/uw0;

    check-cast v0, Lza2;

    invoke-direct {v1, v0}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw v1

    :cond_376
    throw v0
    :try_end_377
    .catchall {:try_start_346 .. :try_end_377} :catchall_35d

    :goto_377
    :try_start_377
    throw v1
    :try_end_378
    .catchall {:try_start_377 .. :try_end_378} :catchall_378

    :catchall_378
    move-exception v0

    invoke-static {v2, v1}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0

    nop

    :pswitch_data_37e
    .packed-switch 0x0
        :pswitch_101  #00000000
        :pswitch_e8  #00000001
        :pswitch_d1  #00000002
        :pswitch_b9  #00000003
        :pswitch_ad  #00000004
        :pswitch_9e  #00000005
        :pswitch_84  #00000006
        :pswitch_6d  #00000007
        :pswitch_55  #00000008
        :pswitch_49  #00000009
        :pswitch_3a  #0000000a
    .end packed-switch
.end method

.method public static final a(Lads_mobile_sdk/cg0;Ljava/lang/String;)V
    .registers 5

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Lads_mobile_sdk/cg0;->g:Lads_mobile_sdk/ax0;

    new-instance v1, Landroid/content/Intent;

    const-string v2, "android.intent.action.SEND"

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v2, "text/plain"

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v1

    const-string v2, "android.intent.extra.TEXT"

    invoke-virtual {v1, v2, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const-string v1, "Share via"

    invoke-static {p1, v1}, Landroid/content/Intent;->createChooser(Landroid/content/Intent;Ljava/lang/CharSequence;)Landroid/content/Intent;

    move-result-object p1

    invoke-virtual {v0, p1}, Lads_mobile_sdk/ax0;->a(Landroid/content/Intent;)Z

    iget-object p0, p0, Lads_mobile_sdk/cg0;->k:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    return-void
.end method

.method public static final a(Lads_mobile_sdk/cg0;Ljava/util/concurrent/atomic/AtomicInteger;III)V
    .registers 13

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Lads_mobile_sdk/cg0;->b:Lvy;

    new-instance v1, Lads_mobile_sdk/qf0;

    const/4 v7, 0x0

    move-object v5, p0

    move-object v2, p1

    move v3, p2

    move v4, p3

    move v6, p4

    invoke-direct/range {v1 .. v7}, Lads_mobile_sdk/qf0;-><init>(Ljava/util/concurrent/atomic/AtomicInteger;IILads_mobile_sdk/cg0;ILvx;)V

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance p0, La42;

    const/4 p1, 0x0

    invoke-direct {p0, v1, p1}, La42;-><init>(Lpk0;Lvx;)V

    const/4 p2, 0x2

    sget-object p3, Ly90;->a:Ly90;

    invoke-static {v0, p3, p1, p0, p2}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    return-void
.end method

.method public static final b(Lads_mobile_sdk/cg0;Lwx;)Ljava/lang/Object;
    .registers 14

    .prologue
    sget-object v0, Lrg2;->a:Lrg2;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    instance-of v1, p1, Lads_mobile_sdk/bg0;

    if-eqz v1, :cond_19

    move-object v1, p1

    check-cast v1, Lads_mobile_sdk/bg0;

    iget v2, v1, Lads_mobile_sdk/bg0;->g:I

    const/high16 v3, -0x80000000

    and-int v4, v2, v3

    if-eqz v4, :cond_19

    sub-int/2addr v2, v3

    iput v2, v1, Lads_mobile_sdk/bg0;->g:I

    :goto_17
    move-object v6, v1

    goto :goto_1f

    :cond_19
    new-instance v1, Lads_mobile_sdk/bg0;

    invoke-direct {v1, p0, p1}, Lads_mobile_sdk/bg0;-><init>(Lads_mobile_sdk/cg0;Lwx;)V

    goto :goto_17

    :goto_1f
    iget-object p1, v6, Lads_mobile_sdk/bg0;->e:Ljava/lang/Object;

    sget-object v1, Lwy;->a:Lwy;

    iget v2, v6, Lads_mobile_sdk/bg0;->g:I

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 v8, 0x0

    packed-switch v2, :pswitch_data_202

    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v8

    :pswitch_31  #0x5, 0x6
    iget-object p0, v6, Lads_mobile_sdk/bg0;->b:Lads_mobile_sdk/rg3;

    iget-object v1, v6, Lads_mobile_sdk/bg0;->a:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/rg3;

    :try_start_37
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_3a
    .catchall {:try_start_37 .. :try_end_3a} :catchall_3c

    goto/16 :goto_1c4

    :catchall_3c
    move-exception v0

    move-object p1, v0

    goto/16 :goto_1cb

    :pswitch_40  #0x4
    iget-object p0, v6, Lads_mobile_sdk/bg0;->d:Landroid/app/Activity;

    iget-object v2, v6, Lads_mobile_sdk/bg0;->c:Lads_mobile_sdk/rg3;

    iget-object v4, v6, Lads_mobile_sdk/bg0;->b:Lads_mobile_sdk/rg3;

    iget-object v5, v6, Lads_mobile_sdk/bg0;->a:Ljava/lang/Object;

    check-cast v5, Lads_mobile_sdk/cg0;

    :try_start_4a
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_4d
    .catchall {:try_start_4a .. :try_end_4d} :catchall_53

    move-object v9, v4

    move-object v4, p0

    move-object p0, v2

    move-object v2, v5

    goto/16 :goto_181

    :catchall_53
    move-exception v0

    move-object p1, v0

    move-object p0, v2

    move-object v1, v4

    goto/16 :goto_1cb

    :pswitch_59  #0x2, 0x3
    iget-object p0, v6, Lads_mobile_sdk/bg0;->b:Lads_mobile_sdk/rg3;

    iget-object v1, v6, Lads_mobile_sdk/bg0;->a:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/rg3;

    :try_start_5f
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_62
    .catchall {:try_start_5f .. :try_end_62} :catchall_64

    goto/16 :goto_110

    :catchall_64
    move-exception v0

    move-object p1, v0

    goto/16 :goto_117

    :pswitch_68  #0x1
    iget-object p0, v6, Lads_mobile_sdk/bg0;->d:Landroid/app/Activity;

    iget-object v2, v6, Lads_mobile_sdk/bg0;->c:Lads_mobile_sdk/rg3;

    iget-object v3, v6, Lads_mobile_sdk/bg0;->b:Lads_mobile_sdk/rg3;

    iget-object v4, v6, Lads_mobile_sdk/bg0;->a:Ljava/lang/Object;

    check-cast v4, Lads_mobile_sdk/cg0;

    :try_start_72
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_75
    .catchall {:try_start_72 .. :try_end_75} :catchall_7b

    move-object v9, v4

    move-object v4, p0

    move-object p0, v2

    move-object v2, v9

    move-object v9, v3

    goto :goto_ca

    :catchall_7b
    move-exception v0

    move-object p1, v0

    move-object p0, v2

    move-object v1, v3

    goto/16 :goto_117

    :pswitch_81  #0x0
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/cg0;->c:Lads_mobile_sdk/ux2;

    sget-object v2, Lads_mobile_sdk/fw0;->R0:Lads_mobile_sdk/fw0;

    iget-object v5, p0, Lads_mobile_sdk/cg0;->o:Lads_mobile_sdk/kh3;

    sget-object v7, Lba0;->a:Lba0;

    invoke-static {}, Lads_mobile_sdk/hh3;->b()Lads_mobile_sdk/gh3;

    move-result-object v9

    iget-object v9, v9, Lads_mobile_sdk/gh3;->a:Lads_mobile_sdk/rg3;

    const/4 v10, 0x1

    const-string v11, "No Activity context available for starting in app preview."

    if-nez v9, :cond_14e

    invoke-static {p1, v2, v7, v5}, Lads_mobile_sdk/ux2;->a(Lads_mobile_sdk/ux2;Lads_mobile_sdk/fw0;Ljava/util/List;Lads_mobile_sdk/kh3;)Lads_mobile_sdk/wk2;

    move-result-object p1

    :try_start_9b
    iget-object v2, p0, Lads_mobile_sdk/cg0;->e:Lads_mobile_sdk/g0;

    invoke-virtual {v2}, Lads_mobile_sdk/g0;->b()Landroid/app/Activity;

    move-result-object v2

    if-nez v2, :cond_b3

    invoke-static {v3, v11, v8}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    iget-object p0, p0, Lads_mobile_sdk/cg0;->k:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {p0, v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V
    :try_end_ab
    .catchall {:try_start_9b .. :try_end_ab} :catchall_af

    invoke-virtual {p1}, Lads_mobile_sdk/rg3;->close()V

    return-object v0

    :catchall_af
    move-exception v0

    move-object p0, v0

    goto/16 :goto_114

    :cond_b3
    :try_start_b3
    iput-object p0, v6, Lads_mobile_sdk/bg0;->a:Ljava/lang/Object;

    iput-object p1, v6, Lads_mobile_sdk/bg0;->b:Lads_mobile_sdk/rg3;

    iput-object p1, v6, Lads_mobile_sdk/bg0;->c:Lads_mobile_sdk/rg3;

    iput-object v2, v6, Lads_mobile_sdk/bg0;->d:Landroid/app/Activity;

    iput v10, v6, Lads_mobile_sdk/bg0;->g:I

    invoke-virtual {p0, v6}, Lads_mobile_sdk/cg0;->a(Lwx;)Ljava/lang/Object;

    move-result-object v3
    :try_end_c1
    .catchall {:try_start_b3 .. :try_end_c1} :catchall_af

    if-ne v3, v1, :cond_c5

    goto/16 :goto_1c1

    :cond_c5
    move-object v9, p1

    move-object v4, v2

    move-object v2, p0

    move-object p0, v9

    move-object p1, v3

    :goto_ca
    :try_start_ca
    check-cast p1, Lb13;

    instance-of v3, p1, Lads_mobile_sdk/av0;

    if-eqz v3, :cond_f1

    iput-object v9, v6, Lads_mobile_sdk/bg0;->a:Ljava/lang/Object;

    iput-object p0, v6, Lads_mobile_sdk/bg0;->b:Lads_mobile_sdk/rg3;

    iput-object v8, v6, Lads_mobile_sdk/bg0;->c:Lads_mobile_sdk/rg3;

    iput-object v8, v6, Lads_mobile_sdk/bg0;->d:Landroid/app/Activity;

    const/4 p1, 0x2

    iput p1, v6, Lads_mobile_sdk/bg0;->g:I

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v5, 0x0

    const/16 v7, 0xa

    const/4 v3, 0x0

    invoke-static/range {v2 .. v7}, Lads_mobile_sdk/cg0;->a(Lads_mobile_sdk/cg0;Ljava/lang/String;Landroid/app/Activity;ZLwx;I)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v1, :cond_e9

    goto :goto_ea

    :cond_e9
    move-object p1, v0

    :goto_ea
    if-ne p1, v1, :cond_110

    goto/16 :goto_1c1

    :catchall_ee
    move-exception v0

    move-object p1, v0

    goto :goto_10e

    :cond_f1
    instance-of v3, p1, Lads_mobile_sdk/hv0;

    if-eqz v3, :cond_110

    check-cast p1, Lads_mobile_sdk/hv0;

    iget-object p1, p1, Lads_mobile_sdk/hv0;->b:Ljava/lang/Object;

    check-cast p1, Ljava/lang/String;

    iput-object v9, v6, Lads_mobile_sdk/bg0;->a:Ljava/lang/Object;

    iput-object p0, v6, Lads_mobile_sdk/bg0;->b:Lads_mobile_sdk/rg3;

    iput-object v8, v6, Lads_mobile_sdk/bg0;->c:Lads_mobile_sdk/rg3;

    iput-object v8, v6, Lads_mobile_sdk/bg0;->d:Landroid/app/Activity;

    const/4 v3, 0x3

    iput v3, v6, Lads_mobile_sdk/bg0;->g:I

    invoke-virtual {v2, v4, p1, v6}, Lads_mobile_sdk/cg0;->a(Landroid/app/Activity;Ljava/lang/String;Lads_mobile_sdk/bg0;)Ljava/lang/Object;

    move-result-object p1
    :try_end_10a
    .catchall {:try_start_ca .. :try_end_10a} :catchall_ee

    if-ne p1, v1, :cond_110

    goto/16 :goto_1c1

    :goto_10e
    move-object v1, v9

    goto :goto_117

    :cond_110
    :goto_110
    invoke-static {p0, v8}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object v0

    :goto_114
    move-object v1, p1

    move-object p1, p0

    move-object p0, v1

    :goto_117
    :try_start_117
    invoke-virtual {v1, p1}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v0, p1, Lox2;

    if-nez v0, :cond_147

    invoke-virtual {v1, p1}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of v0, p1, Lza2;

    if-nez v0, :cond_13f

    instance-of v0, p1, Ljava/util/concurrent/CancellationException;

    if-nez v0, :cond_137

    instance-of v0, p1, Lads_mobile_sdk/mv0;

    if-eqz v0, :cond_131

    throw p1

    :catchall_12e
    move-exception v0

    move-object p1, v0

    goto :goto_148

    :cond_131
    new-instance v0, Lads_mobile_sdk/tu0;

    invoke-direct {v0, p1}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw v0

    :cond_137
    new-instance v0, Lads_mobile_sdk/ou0;

    check-cast p1, Ljava/util/concurrent/CancellationException;

    invoke-direct {v0, p1}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw v0

    :cond_13f
    new-instance v0, Lads_mobile_sdk/uw0;

    check-cast p1, Lza2;

    invoke-direct {v0, p1}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw v0

    :cond_147
    throw p1
    :try_end_148
    .catchall {:try_start_117 .. :try_end_148} :catchall_12e

    :goto_148
    :try_start_148
    throw p1
    :try_end_149
    .catchall {:try_start_148 .. :try_end_149} :catchall_149

    :catchall_149
    move-exception v0

    invoke-static {p0, p1}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0

    :cond_14e
    invoke-static {v2, v7, v10}, Lads_mobile_sdk/hh3;->a(Lads_mobile_sdk/fw0;Ljava/util/List;Z)Lads_mobile_sdk/rg3;

    move-result-object p1

    :try_start_152
    iget-object v2, p0, Lads_mobile_sdk/cg0;->e:Lads_mobile_sdk/g0;

    invoke-virtual {v2}, Lads_mobile_sdk/g0;->b()Landroid/app/Activity;

    move-result-object v2

    if-nez v2, :cond_16a

    invoke-static {v3, v11, v8}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    iget-object p0, p0, Lads_mobile_sdk/cg0;->k:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {p0, v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V
    :try_end_162
    .catchall {:try_start_152 .. :try_end_162} :catchall_166

    invoke-virtual {p1}, Lads_mobile_sdk/rg3;->close()V

    return-object v0

    :catchall_166
    move-exception v0

    move-object p0, v0

    goto/16 :goto_1c8

    :cond_16a
    :try_start_16a
    iput-object p0, v6, Lads_mobile_sdk/bg0;->a:Ljava/lang/Object;

    iput-object p1, v6, Lads_mobile_sdk/bg0;->b:Lads_mobile_sdk/rg3;

    iput-object p1, v6, Lads_mobile_sdk/bg0;->c:Lads_mobile_sdk/rg3;

    iput-object v2, v6, Lads_mobile_sdk/bg0;->d:Landroid/app/Activity;

    const/4 v4, 0x4

    iput v4, v6, Lads_mobile_sdk/bg0;->g:I

    invoke-virtual {p0, v6}, Lads_mobile_sdk/cg0;->a(Lwx;)Ljava/lang/Object;

    move-result-object v4
    :try_end_179
    .catchall {:try_start_16a .. :try_end_179} :catchall_166

    if-ne v4, v1, :cond_17c

    goto :goto_1c1

    :cond_17c
    move-object v9, p1

    move-object p1, v4

    move-object v4, v2

    move-object v2, p0

    move-object p0, v9

    :goto_181
    :try_start_181
    check-cast p1, Lb13;

    instance-of v5, p1, Lads_mobile_sdk/av0;

    if-eqz v5, :cond_1a7

    iput-object v9, v6, Lads_mobile_sdk/bg0;->a:Ljava/lang/Object;

    iput-object p0, v6, Lads_mobile_sdk/bg0;->b:Lads_mobile_sdk/rg3;

    iput-object v8, v6, Lads_mobile_sdk/bg0;->c:Lads_mobile_sdk/rg3;

    iput-object v8, v6, Lads_mobile_sdk/bg0;->d:Landroid/app/Activity;

    const/4 p1, 0x5

    iput p1, v6, Lads_mobile_sdk/bg0;->g:I

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v5, 0x0

    const/16 v7, 0xa

    const/4 v3, 0x0

    invoke-static/range {v2 .. v7}, Lads_mobile_sdk/cg0;->a(Lads_mobile_sdk/cg0;Ljava/lang/String;Landroid/app/Activity;ZLwx;I)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v1, :cond_1a0

    goto :goto_1a1

    :cond_1a0
    move-object p1, v0

    :goto_1a1
    if-ne p1, v1, :cond_1c4

    goto :goto_1c1

    :catchall_1a4
    move-exception v0

    move-object p1, v0

    goto :goto_1c2

    :cond_1a7
    instance-of v5, p1, Lads_mobile_sdk/hv0;

    if-eqz v5, :cond_1c4

    check-cast p1, Lads_mobile_sdk/hv0;

    iget-object p1, p1, Lads_mobile_sdk/hv0;->b:Ljava/lang/Object;

    check-cast p1, Ljava/lang/String;

    iput-object v9, v6, Lads_mobile_sdk/bg0;->a:Ljava/lang/Object;

    iput-object p0, v6, Lads_mobile_sdk/bg0;->b:Lads_mobile_sdk/rg3;

    iput-object v8, v6, Lads_mobile_sdk/bg0;->c:Lads_mobile_sdk/rg3;

    iput-object v8, v6, Lads_mobile_sdk/bg0;->d:Landroid/app/Activity;

    iput v3, v6, Lads_mobile_sdk/bg0;->g:I

    invoke-virtual {v2, v4, p1, v6}, Lads_mobile_sdk/cg0;->a(Landroid/app/Activity;Ljava/lang/String;Lads_mobile_sdk/bg0;)Ljava/lang/Object;

    move-result-object p1
    :try_end_1bf
    .catchall {:try_start_181 .. :try_end_1bf} :catchall_1a4

    if-ne p1, v1, :cond_1c4

    :goto_1c1
    return-object v1

    :goto_1c2
    move-object v1, v9

    goto :goto_1cb

    :cond_1c4
    :goto_1c4
    invoke-static {p0, v8}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object v0

    :goto_1c8
    move-object v1, p1

    move-object p1, p0

    move-object p0, v1

    :goto_1cb
    :try_start_1cb
    invoke-virtual {v1, p1}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v0, p1, Lox2;

    if-nez v0, :cond_1fb

    invoke-virtual {v1, p1}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of v0, p1, Lza2;

    if-nez v0, :cond_1f3

    instance-of v0, p1, Ljava/util/concurrent/CancellationException;

    if-nez v0, :cond_1eb

    instance-of v0, p1, Lads_mobile_sdk/mv0;

    if-eqz v0, :cond_1e5

    throw p1

    :catchall_1e2
    move-exception v0

    move-object p1, v0

    goto :goto_1fc

    :cond_1e5
    new-instance v0, Lads_mobile_sdk/tu0;

    invoke-direct {v0, p1}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw v0

    :cond_1eb
    new-instance v0, Lads_mobile_sdk/ou0;

    check-cast p1, Ljava/util/concurrent/CancellationException;

    invoke-direct {v0, p1}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw v0

    :cond_1f3
    new-instance v0, Lads_mobile_sdk/uw0;

    check-cast p1, Lza2;

    invoke-direct {v0, p1}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw v0

    :cond_1fb
    throw p1
    :try_end_1fc
    .catchall {:try_start_1cb .. :try_end_1fc} :catchall_1e2

    :goto_1fc
    :try_start_1fc
    throw p1
    :try_end_1fd
    .catchall {:try_start_1fc .. :try_end_1fd} :catchall_1fd

    :catchall_1fd
    move-exception v0

    invoke-static {p0, p1}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0

    :pswitch_data_202
    .packed-switch 0x0
        :pswitch_81  #00000000
        :pswitch_68  #00000001
        :pswitch_59  #00000002
        :pswitch_59  #00000003
        :pswitch_40  #00000004
        :pswitch_31  #00000005
        :pswitch_31  #00000006
    .end packed-switch
.end method


# virtual methods
.method public final a(Landroid/app/Activity;Ljava/lang/String;Lads_mobile_sdk/bg0;)Ljava/lang/Object;
    .registers 13

    .prologue
    invoke-virtual {p2}, Ljava/lang/String;->hashCode()I

    move-result v0

    sget-object v1, Lwy;->a:Lwy;

    sget-object v2, Lrg2;->a:Lrg2;

    packed-switch v0, :pswitch_data_80

    :cond_b
    move-object v3, p0

    move-object v5, p1

    move-object v7, p3

    goto :goto_47

    :pswitch_f  #0x32
    const-string v0, "2"

    invoke-virtual {p2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_b

    const/4 v6, 0x1

    const/4 v8, 0x1

    const-string v4, "There was no creative pushed from DFP to the device."

    move-object v3, p0

    move-object v5, p1

    move-object v7, p3

    invoke-static/range {v3 .. v8}, Lads_mobile_sdk/cg0;->a(Lads_mobile_sdk/cg0;Ljava/lang/String;Landroid/app/Activity;ZLwx;I)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v1, :cond_25

    goto :goto_26

    :cond_25
    move-object p0, v2

    :goto_26
    if-ne p0, v1, :cond_7f

    return-object p0

    :pswitch_29  #0x31
    move-object v3, p0

    move-object v5, p1

    move-object v7, p3

    const-string p0, "1"

    invoke-virtual {p2, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_35

    goto :goto_47

    :cond_35
    invoke-virtual {v3, v7}, Lads_mobile_sdk/cg0;->c(Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v1, :cond_7f

    return-object p0

    :pswitch_3c  #0x30
    move-object v3, p0

    move-object v5, p1

    move-object v7, p3

    const-string p0, "0"

    invoke-virtual {p2, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_70

    :goto_47
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result p0

    const/16 p1, 0x32

    invoke-static {p1, p0}, Ljava/lang/Math;->min(II)I

    move-result p0

    const/4 p1, 0x0

    invoke-virtual {p2, p1, p0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    const-string p1, "Invalid creative preview status: "

    invoke-virtual {p1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 p1, 0x0

    const/4 p2, 0x6

    invoke-static {p2, p0, p1}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    const/4 v6, 0x0

    const/16 v8, 0xa

    const/4 v4, 0x0

    invoke-static/range {v3 .. v8}, Lads_mobile_sdk/cg0;->a(Lads_mobile_sdk/cg0;Ljava/lang/String;Landroid/app/Activity;ZLwx;I)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v1, :cond_6c

    goto :goto_6d

    :cond_6c
    move-object p0, v2

    :goto_6d
    if-ne p0, v1, :cond_7f

    return-object p0

    :cond_70
    const/4 v6, 0x0

    const/4 v8, 0x1

    const-string v4, "The device is successfully linked for creative preview."

    invoke-static/range {v3 .. v8}, Lads_mobile_sdk/cg0;->a(Lads_mobile_sdk/cg0;Ljava/lang/String;Landroid/app/Activity;ZLwx;I)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v1, :cond_7b

    goto :goto_7c

    :cond_7b
    move-object p0, v2

    :goto_7c
    if-ne p0, v1, :cond_7f

    return-object p0

    :cond_7f
    return-object v2

    :pswitch_data_80
    .packed-switch 0x30
        :pswitch_3c  #00000030
        :pswitch_29  #00000031
        :pswitch_f  #00000032
    .end packed-switch
.end method

.method public final a(Landroid/app/Activity;Lwx;)Ljava/lang/Object;
    .registers 26

    .prologue
    move-object/from16 v0, p0

    move-object/from16 v1, p2

    instance-of v2, v1, Lads_mobile_sdk/rf0;

    if-eqz v2, :cond_17

    move-object v2, v1

    check-cast v2, Lads_mobile_sdk/rf0;

    iget v3, v2, Lads_mobile_sdk/rf0;->k:I

    const/high16 v4, -0x80000000

    and-int v5, v3, v4

    if-eqz v5, :cond_17

    sub-int/2addr v3, v4

    iput v3, v2, Lads_mobile_sdk/rf0;->k:I

    goto :goto_1c

    :cond_17
    new-instance v2, Lads_mobile_sdk/rf0;

    invoke-direct {v2, v0, v1}, Lads_mobile_sdk/rf0;-><init>(Lads_mobile_sdk/cg0;Lwx;)V

    :goto_1c
    iget-object v1, v2, Lads_mobile_sdk/rf0;->i:Ljava/lang/Object;

    iget v3, v2, Lads_mobile_sdk/rf0;->k:I

    sget-object v4, Lrg2;->a:Lrg2;

    const/4 v5, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x1

    sget-object v9, Lwy;->a:Lwy;

    if-eqz v3, :cond_53

    if-eq v3, v8, :cond_38

    if-ne v3, v6, :cond_32

    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V

    return-object v4

    :cond_32
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {v0}, Lz6;->w(Ljava/lang/String;)V

    return-object v7

    :cond_38
    iget v0, v2, Lads_mobile_sdk/rf0;->h:I

    iget v3, v2, Lads_mobile_sdk/rf0;->g:I

    iget v10, v2, Lads_mobile_sdk/rf0;->f:I

    iget-object v11, v2, Lads_mobile_sdk/rf0;->e:Ltr1;

    iget-object v12, v2, Lads_mobile_sdk/rf0;->d:Ltr1;

    iget-object v13, v2, Lads_mobile_sdk/rf0;->c:Ljava/util/ArrayList;

    iget-object v14, v2, Lads_mobile_sdk/rf0;->b:Landroid/app/Activity;

    iget-object v15, v2, Lads_mobile_sdk/rf0;->a:Lads_mobile_sdk/cg0;

    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V

    move/from16 v22, v0

    move/from16 v21, v3

    :goto_4f
    move/from16 v17, v10

    goto/16 :goto_ef

    :cond_53
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V

    if-nez p1, :cond_5f

    iget-object v1, v0, Lads_mobile_sdk/cg0;->e:Lads_mobile_sdk/g0;

    invoke-virtual {v1}, Lads_mobile_sdk/g0;->b()Landroid/app/Activity;

    move-result-object v1

    goto :goto_61

    :cond_5f
    move-object/from16 v1, p1

    :goto_61
    if-nez v1, :cond_6f

    const-string v1, "No Activity context available for displaying the debug menu."

    const/4 v2, 0x6

    invoke-static {v2, v1, v7}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    iget-object v0, v0, Lads_mobile_sdk/cg0;->k:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0, v5}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    return-object v4

    :cond_6f
    new-instance v13, Ljava/util/ArrayList;

    invoke-direct {v13}, Ljava/util/ArrayList;-><init>()V

    const-string v3, "Ad information"

    invoke-virtual {v13, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v13}, Ljava/util/ArrayList;->size()I

    move-result v3

    add-int/lit8 v10, v3, -0x1

    iget-object v3, v0, Lads_mobile_sdk/cg0;->h:Lads_mobile_sdk/ek;

    iget-object v11, v3, Lads_mobile_sdk/ek;->g:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v11}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v11, Ljava/lang/CharSequence;

    invoke-static {v11}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v11

    if-eqz v11, :cond_95

    const-string v11, "Creative preview"

    goto :goto_97

    :cond_95
    const-string v11, "Creative preview (enabled)"

    :goto_97
    invoke-virtual {v13, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v13}, Ljava/util/ArrayList;->size()I

    move-result v11

    sub-int/2addr v11, v8

    iget-object v3, v3, Lads_mobile_sdk/ek;->h:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v3

    if-eqz v3, :cond_aa

    const-string v3, "Troubleshooting (enabled)"

    goto :goto_ac

    :cond_aa
    const-string v3, "Troubleshooting"

    :goto_ac
    invoke-virtual {v13, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v13}, Ljava/util/ArrayList;->size()I

    move-result v3

    sub-int/2addr v3, v8

    new-instance v12, Ltr1;

    invoke-direct {v12}, Ljava/lang/Object;-><init>()V

    const/4 v14, -0x1

    iput v14, v12, Ltr1;->a:I

    new-instance v15, Ltr1;

    invoke-direct {v15}, Ljava/lang/Object;-><init>()V

    iput v14, v15, Ltr1;->a:I

    iput-object v0, v2, Lads_mobile_sdk/rf0;->a:Lads_mobile_sdk/cg0;

    iput-object v1, v2, Lads_mobile_sdk/rf0;->b:Landroid/app/Activity;

    iput-object v13, v2, Lads_mobile_sdk/rf0;->c:Ljava/util/ArrayList;

    iput-object v12, v2, Lads_mobile_sdk/rf0;->d:Ltr1;

    iput-object v15, v2, Lads_mobile_sdk/rf0;->e:Ltr1;

    iput v10, v2, Lads_mobile_sdk/rf0;->f:I

    iput v11, v2, Lads_mobile_sdk/rf0;->g:I

    iput v3, v2, Lads_mobile_sdk/rf0;->h:I

    iput v8, v2, Lads_mobile_sdk/rf0;->k:I

    iget-object v14, v0, Lads_mobile_sdk/cg0;->j:Lads_mobile_sdk/d91;

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v14, v2}, Lads_mobile_sdk/d91;->c(Lads_mobile_sdk/d91;Lwx;)Ljava/lang/Object;

    move-result-object v14

    if-ne v14, v9, :cond_e2

    goto/16 :goto_163

    :cond_e2
    move-object/from16 v17, v14

    move-object v14, v1

    move-object/from16 v1, v17

    move/from16 v22, v3

    move/from16 v21, v11

    move-object v11, v15

    move-object v15, v0

    goto/16 :goto_4f

    :goto_ef
    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-nez v0, :cond_10f

    const-string v0, "Open ad inspector"

    invoke-interface {v13, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-interface {v13}, Ljava/util/List;->size()I

    move-result v0

    sub-int/2addr v0, v8

    iput v0, v12, Ltr1;->a:I

    const-string v0, "Ad inspector settings"

    invoke-interface {v13, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-interface {v13}, Ljava/util/List;->size()I

    move-result v0

    sub-int/2addr v0, v8

    iput v0, v11, Ltr1;->a:I

    :cond_10f
    new-instance v0, Landroid/app/AlertDialog$Builder;

    const v1, 0x1030226

    invoke-direct {v0, v14, v1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;I)V

    const-string v1, "Select a debug mode"

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v1, Lhv2;

    invoke-direct {v1, v15, v5}, Lhv2;-><init>(Lads_mobile_sdk/cg0;I)V

    const-string v3, "Close"

    invoke-virtual {v0, v3, v1}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v1, Ljv2;

    invoke-direct {v1, v8, v15}, Ljv2;-><init>(ILjava/lang/Object;)V

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    new-array v1, v5, [Ljava/lang/String;

    invoke-interface {v13, v1}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [Ljava/lang/CharSequence;

    new-instance v16, Lkv2;

    move-object/from16 v19, v11

    move-object/from16 v20, v12

    move-object/from16 v18, v15

    invoke-direct/range {v16 .. v22}, Lkv2;-><init>(ILads_mobile_sdk/cg0;Ltr1;Ltr1;II)V

    move-object/from16 v3, v16

    invoke-virtual {v0, v1, v3}, Landroid/app/AlertDialog$Builder;->setItems([Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    iget-object v1, v15, Lads_mobile_sdk/cg0;->a:Lly;

    new-instance v3, Lads_mobile_sdk/lf0;

    invoke-direct {v3, v0, v7, v6}, Lads_mobile_sdk/lf0;-><init>(Landroid/app/AlertDialog$Builder;Lvx;I)V

    iput-object v7, v2, Lads_mobile_sdk/rf0;->a:Lads_mobile_sdk/cg0;

    iput-object v7, v2, Lads_mobile_sdk/rf0;->b:Landroid/app/Activity;

    iput-object v7, v2, Lads_mobile_sdk/rf0;->c:Ljava/util/ArrayList;

    iput-object v7, v2, Lads_mobile_sdk/rf0;->d:Ltr1;

    iput-object v7, v2, Lads_mobile_sdk/rf0;->e:Ltr1;

    iput v6, v2, Lads_mobile_sdk/rf0;->k:I

    invoke-static {v1, v3, v2}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object v0

    if-ne v0, v9, :cond_164

    :goto_163
    return-object v9

    :cond_164
    return-object v4
.end method

.method public final a(Lwx;)Ljava/lang/Object;
    .registers 18

    .prologue
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    instance-of v2, v1, Lads_mobile_sdk/ff0;

    if-eqz v2, :cond_17

    move-object v2, v1

    check-cast v2, Lads_mobile_sdk/ff0;

    iget v3, v2, Lads_mobile_sdk/ff0;->i:I

    const/high16 v4, -0x80000000

    and-int v5, v3, v4

    if-eqz v5, :cond_17

    sub-int/2addr v3, v4

    iput v3, v2, Lads_mobile_sdk/ff0;->i:I

    goto :goto_1c

    :cond_17
    new-instance v2, Lads_mobile_sdk/ff0;

    invoke-direct {v2, v0, v1}, Lads_mobile_sdk/ff0;-><init>(Lads_mobile_sdk/cg0;Lwx;)V

    :goto_1c
    iget-object v1, v2, Lads_mobile_sdk/ff0;->g:Ljava/lang/Object;

    iget v3, v2, Lads_mobile_sdk/ff0;->i:I

    const/4 v5, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x2

    const-string v8, ""

    const/4 v9, 0x1

    const/4 v10, 0x0

    sget-object v11, Lwy;->a:Lwy;

    if-eqz v3, :cond_95

    if-eq v3, v9, :cond_7c

    if-eq v3, v7, :cond_65

    if-eq v3, v6, :cond_4b

    if-ne v3, v5, :cond_45

    iget-object v0, v2, Lads_mobile_sdk/ff0;->c:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    iget-object v3, v2, Lads_mobile_sdk/ff0;->b:Ljava/io/Closeable;

    iget-object v2, v2, Lads_mobile_sdk/ff0;->a:Ljava/lang/Object;

    check-cast v2, Lads_mobile_sdk/rg3;

    :try_start_3d
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_40
    .catchall {:try_start_3d .. :try_end_40} :catchall_42

    goto/16 :goto_1af

    :catchall_42
    move-exception v0

    goto/16 :goto_1c9

    :cond_45
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {v0}, Lz6;->w(Ljava/lang/String;)V

    return-object v10

    :cond_4b
    iget v0, v2, Lads_mobile_sdk/ff0;->f:I

    iget-object v3, v2, Lads_mobile_sdk/ff0;->d:Ljava/lang/Object;

    check-cast v3, Ljava/lang/String;

    iget-object v6, v2, Lads_mobile_sdk/ff0;->c:Ljava/lang/Object;

    check-cast v6, Ljava/io/Closeable;

    iget-object v7, v2, Lads_mobile_sdk/ff0;->b:Ljava/io/Closeable;

    check-cast v7, Lads_mobile_sdk/rg3;

    iget-object v9, v2, Lads_mobile_sdk/ff0;->a:Ljava/lang/Object;

    check-cast v9, Lads_mobile_sdk/cg0;

    :try_start_5d
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_60
    .catchall {:try_start_5d .. :try_end_60} :catchall_62

    goto/16 :goto_18d

    :catchall_62
    move-exception v0

    goto/16 :goto_1bc

    :cond_65
    iget-object v0, v2, Lads_mobile_sdk/ff0;->c:Ljava/lang/Object;

    move-object v3, v0

    check-cast v3, Ljava/io/Closeable;

    iget-object v0, v2, Lads_mobile_sdk/ff0;->b:Ljava/io/Closeable;

    move-object v7, v0

    check-cast v7, Lads_mobile_sdk/rg3;

    iget-object v0, v2, Lads_mobile_sdk/ff0;->a:Ljava/lang/Object;

    check-cast v0, Lads_mobile_sdk/cg0;

    :try_start_73
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_76
    .catchall {:try_start_73 .. :try_end_76} :catchall_79

    move-object v9, v0

    goto/16 :goto_11f

    :catchall_79
    move-exception v0

    goto/16 :goto_1d8

    :cond_7c
    iget-object v0, v2, Lads_mobile_sdk/ff0;->e:Lq63;

    iget-object v3, v2, Lads_mobile_sdk/ff0;->d:Ljava/lang/Object;

    check-cast v3, Lads_mobile_sdk/g21;

    iget-object v12, v2, Lads_mobile_sdk/ff0;->c:Ljava/lang/Object;

    check-cast v12, Ljava/io/Closeable;

    iget-object v13, v2, Lads_mobile_sdk/ff0;->b:Ljava/io/Closeable;

    check-cast v13, Lads_mobile_sdk/rg3;

    iget-object v14, v2, Lads_mobile_sdk/ff0;->a:Ljava/lang/Object;

    check-cast v14, Lads_mobile_sdk/cg0;

    :try_start_8e
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_91
    .catchall {:try_start_8e .. :try_end_91} :catchall_92

    goto :goto_d9

    :catchall_92
    move-exception v0

    goto/16 :goto_1dd

    :cond_95
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V

    sget-object v1, Lads_mobile_sdk/hh3;->a:Ljava/util/WeakHashMap;

    sget-object v1, Lba0;->a:Lba0;

    sget-object v3, Lads_mobile_sdk/fw0;->S0:Lads_mobile_sdk/fw0;

    invoke-static {v3, v1, v9}, Lads_mobile_sdk/hh3;->a(Lads_mobile_sdk/fw0;Ljava/util/List;Z)Lads_mobile_sdk/rg3;

    move-result-object v12

    :try_start_a2
    iget-object v1, v0, Lads_mobile_sdk/cg0;->i:Lq63;

    new-instance v3, Lads_mobile_sdk/g21;

    invoke-direct {v3}, Lads_mobile_sdk/g21;-><init>()V

    iget-object v13, v0, Lads_mobile_sdk/cg0;->f:Lads_mobile_sdk/qr0;

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v14, "gads:drx_debug:in_app_preview_status_url"

    const-string v15, "https://www.google.com/dfp/inAppPreview"

    sget-object v4, Lads_mobile_sdk/fo;->a$23:Lads_mobile_sdk/fo;

    invoke-virtual {v13, v14, v15, v4}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    iput-object v0, v2, Lads_mobile_sdk/ff0;->a:Ljava/lang/Object;

    iput-object v12, v2, Lads_mobile_sdk/ff0;->b:Ljava/io/Closeable;

    iput-object v12, v2, Lads_mobile_sdk/ff0;->c:Ljava/lang/Object;

    iput-object v3, v2, Lads_mobile_sdk/ff0;->d:Ljava/lang/Object;

    iput-object v1, v2, Lads_mobile_sdk/ff0;->e:Lq63;

    iput v9, v2, Lads_mobile_sdk/ff0;->i:I

    iget-object v13, v0, Lads_mobile_sdk/cg0;->l:Ljava/lang/String;

    iget-object v14, v0, Lads_mobile_sdk/cg0;->j:Lads_mobile_sdk/d91;

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v14, v4, v13, v10, v2}, Lads_mobile_sdk/d91;->a(Lads_mobile_sdk/d91;Ljava/lang/String;Ljava/lang/String;Lfx0;Lwx;)Ljava/lang/Comparable;

    move-result-object v4
    :try_end_d1
    .catchall {:try_start_a2 .. :try_end_d1} :catchall_1db

    if-ne v4, v11, :cond_d5

    goto/16 :goto_1ab

    :cond_d5
    move-object v14, v0

    move-object v0, v1

    move-object v1, v4

    move-object v13, v12

    :goto_d9
    :try_start_d9
    check-cast v1, Landroid/net/Uri;

    invoke-virtual {v1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v3, v1}, Lads_mobile_sdk/g21;->b(Ljava/lang/String;)V

    invoke-virtual {v3}, Lads_mobile_sdk/g21;->a()Lads_mobile_sdk/h21;

    move-result-object v1

    iget-object v3, v14, Lads_mobile_sdk/cg0;->f:Lads_mobile_sdk/qr0;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v4, "gads:drx_debug:timeout_ms"

    sget-object v15, Lv60;->b:Lp80;

    sget-object v15, Ly60;->e:Ly60;

    const/4 v9, 0x5

    invoke-static {v9, v15}, Li10;->G0(ILy60;)J

    move-result-wide v5

    new-instance v9, Lv60;

    invoke-direct {v9, v5, v6}, Lv60;-><init>(J)V

    sget-object v5, Lads_mobile_sdk/fo;->a$18:Lads_mobile_sdk/fo;

    invoke-virtual {v3, v4, v9, v5}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lv60;

    iput-object v14, v2, Lads_mobile_sdk/ff0;->a:Ljava/lang/Object;

    iput-object v13, v2, Lads_mobile_sdk/ff0;->b:Ljava/io/Closeable;

    iput-object v12, v2, Lads_mobile_sdk/ff0;->c:Ljava/lang/Object;

    iput-object v10, v2, Lads_mobile_sdk/ff0;->d:Ljava/lang/Object;

    iput-object v10, v2, Lads_mobile_sdk/ff0;->e:Lq63;

    iput v7, v2, Lads_mobile_sdk/ff0;->i:I

    const/16 v4, 0x1c

    invoke-static {v0, v1, v3, v2, v4}, Lq63;->b(Lq63;Lads_mobile_sdk/h21;Lv60;Lwx;I)Ljava/lang/Object;

    move-result-object v1
    :try_end_118
    .catchall {:try_start_d9 .. :try_end_118} :catchall_92

    if-ne v1, v11, :cond_11c

    goto/16 :goto_1ab

    :cond_11c
    move-object v3, v12

    move-object v7, v13

    move-object v9, v14

    :goto_11f
    :try_start_11f
    check-cast v1, Lb13;

    instance-of v0, v1, Lads_mobile_sdk/av0;

    if-eqz v0, :cond_12a

    check-cast v1, Lads_mobile_sdk/av0;

    :goto_127
    const/4 v5, 0x0

    goto/16 :goto_1d1

    :cond_12a
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v1, Lads_mobile_sdk/hv0;

    iget-object v0, v1, Lads_mobile_sdk/hv0;->b:Ljava/lang/Object;

    check-cast v0, Lads_mobile_sdk/j21;
    :try_end_133
    .catchall {:try_start_11f .. :try_end_133} :catchall_79

    :try_start_133
    iget-object v0, v0, Lads_mobile_sdk/j21;->d:Lads_mobile_sdk/gv2;

    if-eqz v0, :cond_1bf

    invoke-static {v0}, Lads_mobile_sdk/gv2;->a(Lads_mobile_sdk/gv2;)Ljava/lang/String;

    move-result-object v0

    new-instance v1, Lkm0;

    invoke-direct {v1}, Lkm0;-><init>()V

    const-class v4, Lfx0;

    invoke-virtual {v1, v4, v0}, Lkm0;->a(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lfx0;

    const-string v1, "gct"

    invoke-static {v0, v1, v8}, Lads_mobile_sdk/bw2;->a(Lfx0;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iget-object v4, v9, Lads_mobile_sdk/cg0;->h:Lads_mobile_sdk/ek;

    iget-object v4, v4, Lads_mobile_sdk/ek;->g:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v4, v1}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    const-string v1, "status"

    invoke-static {v0, v1, v8}, Lads_mobile_sdk/bw2;->a(Lfx0;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "0"

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_170

    const-string v1, "2"

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_16c

    goto :goto_170

    :cond_16c
    const/4 v1, 0x0

    goto :goto_171

    :catchall_16e
    move-exception v0

    goto :goto_1bd

    :cond_170
    :goto_170
    const/4 v1, 0x1

    :goto_171
    iget-object v4, v9, Lads_mobile_sdk/cg0;->j:Lads_mobile_sdk/d91;

    iput-object v9, v2, Lads_mobile_sdk/ff0;->a:Ljava/lang/Object;

    iput-object v7, v2, Lads_mobile_sdk/ff0;->b:Ljava/io/Closeable;

    iput-object v3, v2, Lads_mobile_sdk/ff0;->c:Ljava/lang/Object;

    iput-object v0, v2, Lads_mobile_sdk/ff0;->d:Ljava/lang/Object;

    iput v1, v2, Lads_mobile_sdk/ff0;->f:I

    const/4 v5, 0x3

    iput v5, v2, Lads_mobile_sdk/ff0;->i:I

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v4, v1, v2}, Lads_mobile_sdk/d91;->a(Lads_mobile_sdk/d91;ZLwx;)Ljava/lang/Object;

    move-result-object v4
    :try_end_187
    .catchall {:try_start_133 .. :try_end_187} :catchall_16e

    if-ne v4, v11, :cond_18a

    goto :goto_1ab

    :cond_18a
    move-object v6, v3

    move-object v3, v0

    move v0, v1

    :goto_18d
    :try_start_18d
    iget-object v1, v9, Lads_mobile_sdk/cg0;->j:Lads_mobile_sdk/d91;

    if-eqz v0, :cond_197

    iget-object v0, v9, Lads_mobile_sdk/cg0;->l:Ljava/lang/String;

    if-nez v0, :cond_196

    goto :goto_197

    :cond_196
    move-object v8, v0

    :cond_197
    :goto_197
    iput-object v7, v2, Lads_mobile_sdk/ff0;->a:Ljava/lang/Object;

    iput-object v6, v2, Lads_mobile_sdk/ff0;->b:Ljava/io/Closeable;

    iput-object v3, v2, Lads_mobile_sdk/ff0;->c:Ljava/lang/Object;

    iput-object v10, v2, Lads_mobile_sdk/ff0;->d:Ljava/lang/Object;

    const/4 v0, 0x4

    iput v0, v2, Lads_mobile_sdk/ff0;->i:I

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v1, v8, v2}, Lads_mobile_sdk/d91;->a(Lads_mobile_sdk/d91;Ljava/lang/String;Lwx;)Ljava/lang/Object;

    move-result-object v0
    :try_end_1a9
    .catchall {:try_start_18d .. :try_end_1a9} :catchall_62

    if-ne v0, v11, :cond_1ac

    :goto_1ab
    return-object v11

    :cond_1ac
    move-object v0, v3

    move-object v3, v6

    move-object v2, v7

    :goto_1af
    :try_start_1af
    new-instance v1, Lads_mobile_sdk/hv0;

    invoke-direct {v1, v0}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V
    :try_end_1b4
    .catchall {:try_start_1af .. :try_end_1b4} :catchall_1b8

    invoke-static {v3, v10}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object v1

    :catchall_1b8
    move-exception v0

    move-object v13, v2

    move-object v12, v3

    goto :goto_1dd

    :goto_1bc
    move-object v3, v6

    :goto_1bd
    move-object v2, v7

    goto :goto_1c9

    :cond_1bf
    :try_start_1bf
    new-instance v1, Lads_mobile_sdk/ev0;

    const-string v0, "Null response body when fetching creative preview token"

    const/4 v2, 0x1

    invoke-direct {v1, v0, v2}, Lads_mobile_sdk/ev0;-><init>(Ljava/lang/String;I)V
    :try_end_1c7
    .catchall {:try_start_1bf .. :try_end_1c7} :catchall_16e

    goto/16 :goto_127

    :goto_1c9
    :try_start_1c9
    new-instance v1, Lads_mobile_sdk/bv0;

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-direct {v1, v5, v10, v0, v4}, Lads_mobile_sdk/bv0;-><init>(ILjava/lang/String;Ljava/lang/Throwable;I)V
    :try_end_1d0
    .catchall {:try_start_1c9 .. :try_end_1d0} :catchall_1b8

    move-object v7, v2

    :goto_1d1
    :try_start_1d1
    invoke-static {v1, v5}, Lads_mobile_sdk/xh3;->a(Lads_mobile_sdk/av0;Z)V
    :try_end_1d4
    .catchall {:try_start_1d1 .. :try_end_1d4} :catchall_79

    invoke-static {v3, v10}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object v1

    :goto_1d8
    move-object v12, v3

    move-object v13, v7

    goto :goto_1dd

    :catchall_1db
    move-exception v0

    move-object v13, v12

    :goto_1dd
    :try_start_1dd
    invoke-virtual {v13, v0}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v1, v0, Lox2;

    if-nez v1, :cond_20d

    invoke-virtual {v13, v0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of v1, v0, Lza2;

    if-nez v1, :cond_205

    instance-of v1, v0, Ljava/util/concurrent/CancellationException;

    if-nez v1, :cond_1fd

    instance-of v1, v0, Lads_mobile_sdk/mv0;

    if-eqz v1, :cond_1f7

    throw v0

    :catchall_1f4
    move-exception v0

    move-object v1, v0

    goto :goto_20e

    :cond_1f7
    new-instance v1, Lads_mobile_sdk/tu0;

    invoke-direct {v1, v0}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw v1

    :cond_1fd
    new-instance v1, Lads_mobile_sdk/ou0;

    check-cast v0, Ljava/util/concurrent/CancellationException;

    invoke-direct {v1, v0}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw v1

    :cond_205
    new-instance v1, Lads_mobile_sdk/uw0;

    check-cast v0, Lza2;

    invoke-direct {v1, v0}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw v1

    :cond_20d
    throw v0
    :try_end_20e
    .catchall {:try_start_1dd .. :try_end_20e} :catchall_1f4

    :goto_20e
    :try_start_20e
    throw v1
    :try_end_20f
    .catchall {:try_start_20e .. :try_end_20f} :catchall_20f

    :catchall_20f
    move-exception v0

    invoke-static {v12, v1}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0
.end method

.method public final a(ZLjava/lang/String;Landroid/app/Activity;ZLwx;)Ljava/lang/Object;
    .registers 12

    .prologue
    instance-of v0, p5, Lads_mobile_sdk/yf0;

    if-eqz v0, :cond_13

    move-object v0, p5

    check-cast v0, Lads_mobile_sdk/yf0;

    iget v1, v0, Lads_mobile_sdk/yf0;->d:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/yf0;->d:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/yf0;

    invoke-direct {v0, p0, p5}, Lads_mobile_sdk/yf0;-><init>(Lads_mobile_sdk/cg0;Lwx;)V

    :goto_18
    iget-object p5, v0, Lads_mobile_sdk/yf0;->b:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/yf0;->d:I

    sget-object v2, Lrg2;->a:Lrg2;

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-eqz v1, :cond_33

    if-ne v1, v3, :cond_2d

    iget-object p0, v0, Lads_mobile_sdk/yf0;->a:Lads_mobile_sdk/cg0;

    :try_start_27
    invoke-static {p5}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_2a
    .catchall {:try_start_27 .. :try_end_2a} :catchall_2b

    return-object v2

    :catchall_2b
    move-exception p1

    goto :goto_94

    :cond_2d
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v5

    :cond_33
    invoke-static {p5}, Lt12;->W(Ljava/lang/Object;)V

    if-nez p3, :cond_3e

    :try_start_38
    iget-object p3, p0, Lads_mobile_sdk/cg0;->e:Lads_mobile_sdk/g0;

    invoke-virtual {p3}, Lads_mobile_sdk/g0;->b()Landroid/app/Activity;

    move-result-object p3

    :cond_3e
    if-nez p3, :cond_4c

    const-string p1, "No Activity context available for showing status dialog."

    const/4 p2, 0x6

    invoke-static {p2, p1, v5}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    iget-object p1, p0, Lads_mobile_sdk/cg0;->k:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {p1, v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    return-object v2

    :cond_4c
    new-instance p5, Landroid/app/AlertDialog$Builder;

    const v1, 0x1030226

    invoke-direct {p5, p3, v1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;I)V

    if-eqz p1, :cond_59

    const-string p1, "Error"

    goto :goto_5b

    :cond_59
    const-string p1, "Info"

    :goto_5b
    invoke-virtual {p5, p1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    invoke-virtual {p5, p2}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    new-instance p1, Ljv2;

    invoke-direct {p1, v4, p0}, Ljv2;-><init>(ILjava/lang/Object;)V

    invoke-virtual {p5, p1}, Landroid/app/AlertDialog$Builder;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)Landroid/app/AlertDialog$Builder;
    :try_end_69
    .catchall {:try_start_38 .. :try_end_69} :catchall_2b

    const-string p1, "Dismiss"

    if-eqz p4, :cond_7b

    :try_start_6d
    invoke-virtual {p5, p1, v5}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    const-string p1, "Learn More"

    new-instance p2, Lhv2;

    invoke-direct {p2, p0, v3}, Lhv2;-><init>(Lads_mobile_sdk/cg0;I)V

    invoke-virtual {p5, p1, p2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    goto :goto_7e

    :cond_7b
    invoke-virtual {p5, p1, v5}, Landroid/app/AlertDialog$Builder;->setNeutralButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    :goto_7e
    iget-object p1, p0, Lads_mobile_sdk/cg0;->a:Lly;

    new-instance p2, Lads_mobile_sdk/lf0;

    const/4 p3, 0x3

    invoke-direct {p2, p5, v5, p3}, Lads_mobile_sdk/lf0;-><init>(Landroid/app/AlertDialog$Builder;Lvx;I)V

    iput-object p0, v0, Lads_mobile_sdk/yf0;->a:Lads_mobile_sdk/cg0;

    iput v3, v0, Lads_mobile_sdk/yf0;->d:I

    invoke-static {p1, p2, v0}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object p0
    :try_end_8e
    .catchall {:try_start_6d .. :try_end_8e} :catchall_2b

    sget-object p1, Lwy;->a:Lwy;

    if-ne p0, p1, :cond_93

    return-object p1

    :cond_93
    return-object v2

    :goto_94
    invoke-static {}, Lads_mobile_sdk/hh3;->a()Lads_mobile_sdk/rg3;

    move-result-object p2

    invoke-virtual {p2}, Lads_mobile_sdk/rg3;->e()Lads_mobile_sdk/ub2;

    move-result-object p3

    iput-boolean v4, p3, Lads_mobile_sdk/ub2;->m:Z

    invoke-virtual {p2, p1}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    iget-object p2, p0, Lads_mobile_sdk/cg0;->k:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {p2, v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    iget-object p0, p0, Lads_mobile_sdk/cg0;->d:Lads_mobile_sdk/ah3;

    const-string p2, "Failed to show status dialog"

    invoke-virtual {p0, p2, p1}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-object v2
.end method

.method public final a(Ljava/lang/String;)Ljava/lang/String;
    .registers 9

    .prologue
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    if-nez v0, :cond_7

    goto :goto_52

    :cond_7
    const-string v0, "\\+"

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v1, "%20"

    invoke-virtual {v0, p1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object p1

    invoke-virtual {p1, v1}, Ljava/util/regex/Matcher;->replaceAll(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Landroid/net/Uri$Builder;

    invoke-direct {v0}, Landroid/net/Uri$Builder;-><init>()V

    invoke-virtual {v0, p1}, Landroid/net/Uri$Builder;->encodedQuery(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object p1

    invoke-virtual {p1}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p0, Lads_mobile_sdk/cg0;->g:Lads_mobile_sdk/ax0;

    invoke-virtual {p0, p1}, Lads_mobile_sdk/ax0;->d(Landroid/net/Uri;)Ljava/util/Map;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    sget-object v5, Lads_mobile_sdk/fo;->a$5:Lads_mobile_sdk/fo;

    const/4 v4, 0x0

    const/16 v6, 0x1e

    const-string v1, "\n\n"

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static/range {v0 .. v6}, Lbs;->p0(Ljava/lang/Iterable;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILbk0;I)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lc72;->I0(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result p1

    if-eqz p1, :cond_54

    :goto_52
    const-string p0, "No debug information"

    :cond_54
    return-object p0
.end method

.method public final c(Lwx;)Ljava/lang/Object;
    .registers 8

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/jf0;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/jf0;

    iget v1, v0, Lads_mobile_sdk/jf0;->f:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/jf0;->f:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/jf0;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/jf0;-><init>(Lads_mobile_sdk/cg0;Lwx;)V

    :goto_18
    iget-object p1, v0, Lads_mobile_sdk/jf0;->d:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/jf0;->f:I

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v1, :cond_32

    if-ne v1, v2, :cond_2c

    iget-object p0, v0, Lads_mobile_sdk/jf0;->c:Lads_mobile_sdk/cg0;

    iget-object v1, v0, Lads_mobile_sdk/jf0;->b:Lads_mobile_sdk/ax0;

    iget-object v0, v0, Lads_mobile_sdk/jf0;->a:Lads_mobile_sdk/cg0;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_61

    :cond_2c
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v3

    :cond_32
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/cg0;->f:Lads_mobile_sdk/qr0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Lads_mobile_sdk/fo;->a$23:Lads_mobile_sdk/fo;

    const-string v4, "gads:drx_debug:debug_device_linking_url"

    const-string v5, "https://www.google.com/dfp/linkDevice"

    invoke-virtual {p1, v4, v5, v1}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    iput-object p0, v0, Lads_mobile_sdk/jf0;->a:Lads_mobile_sdk/cg0;

    iget-object v1, p0, Lads_mobile_sdk/cg0;->g:Lads_mobile_sdk/ax0;

    iput-object v1, v0, Lads_mobile_sdk/jf0;->b:Lads_mobile_sdk/ax0;

    iput-object p0, v0, Lads_mobile_sdk/jf0;->c:Lads_mobile_sdk/cg0;

    iput v2, v0, Lads_mobile_sdk/jf0;->f:I

    iget-object v2, p0, Lads_mobile_sdk/cg0;->l:Ljava/lang/String;

    iget-object v4, p0, Lads_mobile_sdk/cg0;->j:Lads_mobile_sdk/d91;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v4, p1, v2, v3, v0}, Lads_mobile_sdk/d91;->a(Lads_mobile_sdk/d91;Ljava/lang/String;Ljava/lang/String;Lfx0;Lwx;)Ljava/lang/Comparable;

    move-result-object p1

    sget-object v0, Lwy;->a:Lwy;

    if-ne p1, v0, :cond_60

    return-object v0

    :cond_60
    move-object v0, p0

    :goto_61
    check-cast p1, Landroid/net/Uri;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v2, Landroid/content/Intent;

    const-string v4, "android.intent.action.VIEW"

    invoke-direct {v2, v4, p1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    new-instance p1, Landroid/os/Bundle;

    invoke-direct {p1}, Landroid/os/Bundle;-><init>()V

    const-string v4, "android.support.customtabs.extra.SESSION"

    invoke-virtual {p1, v4, v3}, Landroid/os/Bundle;->putBinder(Ljava/lang/String;Landroid/os/IBinder;)V

    iget-object p0, p0, Lads_mobile_sdk/cg0;->p:Ljava/lang/String;

    if-eqz p0, :cond_8f

    const-string v3, "com.android.browser.application_id"

    invoke-virtual {p1, v3, p0}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v2, p1}, Landroid/content/Intent;->putExtras(Landroid/os/Bundle;)Landroid/content/Intent;

    invoke-virtual {v1, v2}, Lads_mobile_sdk/ax0;->a(Landroid/content/Intent;)Z

    iget-object p0, v0, Lads_mobile_sdk/cg0;->k:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0

    :cond_8f
    const-string p0, "packageName"

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3
.end method

.method public final d(Lwx;)Ljava/lang/Object;
    .registers 19

    .prologue
    move-object/from16 v1, p0

    move-object/from16 v0, p1

    sget-object v2, Lrg2;->a:Lrg2;

    instance-of v3, v0, Lads_mobile_sdk/kf0;

    if-eqz v3, :cond_19

    move-object v3, v0

    check-cast v3, Lads_mobile_sdk/kf0;

    iget v4, v3, Lads_mobile_sdk/kf0;->f:I

    const/high16 v5, -0x80000000

    and-int v6, v4, v5

    if-eqz v6, :cond_19

    sub-int/2addr v4, v5

    iput v4, v3, Lads_mobile_sdk/kf0;->f:I

    goto :goto_1e

    :cond_19
    new-instance v3, Lads_mobile_sdk/kf0;

    invoke-direct {v3, v1, v0}, Lads_mobile_sdk/kf0;-><init>(Lads_mobile_sdk/cg0;Lwx;)V

    :goto_1e
    iget-object v0, v3, Lads_mobile_sdk/kf0;->d:Ljava/lang/Object;

    sget-object v4, Lwy;->a:Lwy;

    iget v5, v3, Lads_mobile_sdk/kf0;->f:I

    const-string v6, "Failed to show ad info dialog"

    const/4 v7, 0x2

    const/4 v8, 0x1

    const/4 v10, 0x0

    if-eqz v5, :cond_55

    if-eq v5, v8, :cond_45

    if-ne v5, v7, :cond_3f

    iget-object v1, v3, Lads_mobile_sdk/kf0;->c:Lads_mobile_sdk/rg3;

    iget-object v4, v3, Lads_mobile_sdk/kf0;->b:Lads_mobile_sdk/rg3;

    iget-object v3, v3, Lads_mobile_sdk/kf0;->a:Lads_mobile_sdk/cg0;

    :try_start_35
    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_38
    .catchall {:try_start_35 .. :try_end_38} :catchall_3a

    goto/16 :goto_1bf

    :catchall_3a
    move-exception v0

    move-object v5, v1

    move-object v1, v3

    goto/16 :goto_1a6

    :cond_3f
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {v0}, Lz6;->w(Ljava/lang/String;)V

    return-object v10

    :cond_45
    iget-object v1, v3, Lads_mobile_sdk/kf0;->c:Lads_mobile_sdk/rg3;

    iget-object v4, v3, Lads_mobile_sdk/kf0;->b:Lads_mobile_sdk/rg3;

    iget-object v3, v3, Lads_mobile_sdk/kf0;->a:Lads_mobile_sdk/cg0;

    :try_start_4b
    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_4e
    .catchall {:try_start_4b .. :try_end_4e} :catchall_50

    goto/16 :goto_fa

    :catchall_50
    move-exception v0

    move-object v5, v1

    move-object v1, v3

    goto/16 :goto_e1

    :cond_55
    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    iget-object v0, v1, Lads_mobile_sdk/cg0;->c:Lads_mobile_sdk/ux2;

    sget-object v5, Lads_mobile_sdk/fw0;->V0:Lads_mobile_sdk/fw0;

    iget-object v11, v1, Lads_mobile_sdk/cg0;->o:Lads_mobile_sdk/kh3;

    sget-object v12, Lba0;->a:Lba0;

    invoke-static {}, Lads_mobile_sdk/hh3;->b()Lads_mobile_sdk/gh3;

    move-result-object v13

    iget-object v13, v13, Lads_mobile_sdk/gh3;->a:Lads_mobile_sdk/rg3;

    const-string v14, "Share"

    const-string v15, "Close"

    const-string v8, "Ad Information"

    const-string v16, ""

    const/4 v7, 0x6

    const-string v9, "No Activity context available for displaying the ad info dialog."

    if-nez v13, :cond_139

    invoke-static {v0, v5, v12, v11}, Lads_mobile_sdk/ux2;->a(Lads_mobile_sdk/ux2;Lads_mobile_sdk/fw0;Ljava/util/List;Lads_mobile_sdk/kh3;)Lads_mobile_sdk/wk2;

    move-result-object v5

    :try_start_77
    iget-object v0, v1, Lads_mobile_sdk/cg0;->e:Lads_mobile_sdk/g0;

    invoke-virtual {v0}, Lads_mobile_sdk/g0;->b()Landroid/app/Activity;

    move-result-object v0

    if-nez v0, :cond_90

    invoke-static {v7, v9, v10}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    iget-object v0, v1, Lads_mobile_sdk/cg0;->k:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V
    :try_end_88
    .catchall {:try_start_77 .. :try_end_88} :catchall_8c

    invoke-virtual {v5}, Lads_mobile_sdk/rg3;->close()V

    return-object v2

    :catchall_8c
    move-exception v0

    move-object v1, v5

    goto/16 :goto_102

    :cond_90
    :try_start_90
    iget-object v7, v1, Lads_mobile_sdk/cg0;->m:Ljava/lang/String;

    if-nez v7, :cond_96

    move-object/from16 v7, v16

    :cond_96
    invoke-virtual {v1, v7}, Lads_mobile_sdk/cg0;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7
    :try_end_9a
    .catchall {:try_start_90 .. :try_end_9a} :catchall_8c

    :try_start_9a
    new-instance v9, Landroid/app/AlertDialog$Builder;

    const v11, 0x1030226

    invoke-direct {v9, v0, v11}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;I)V

    invoke-virtual {v9, v7}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    invoke-virtual {v0, v8}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v8, Ljv2;

    const/4 v9, 0x2

    invoke-direct {v8, v9, v1}, Ljv2;-><init>(ILjava/lang/Object;)V

    invoke-virtual {v0, v8}, Landroid/app/AlertDialog$Builder;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v8, Lhv2;

    invoke-direct {v8, v1, v9}, Lhv2;-><init>(Lads_mobile_sdk/cg0;I)V

    invoke-virtual {v0, v15, v8}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v8, Lmv2;

    const/4 v9, 0x0

    invoke-direct {v8, v9, v1, v7}, Lmv2;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v0, v14, v8}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    iget-object v7, v1, Lads_mobile_sdk/cg0;->a:Lly;

    new-instance v8, Lads_mobile_sdk/lf0;

    invoke-direct {v8, v0, v10, v9}, Lads_mobile_sdk/lf0;-><init>(Landroid/app/AlertDialog$Builder;Lvx;I)V

    iput-object v1, v3, Lads_mobile_sdk/kf0;->a:Lads_mobile_sdk/cg0;

    iput-object v5, v3, Lads_mobile_sdk/kf0;->b:Lads_mobile_sdk/rg3;

    iput-object v5, v3, Lads_mobile_sdk/kf0;->c:Lads_mobile_sdk/rg3;

    const/4 v0, 0x1

    iput v0, v3, Lads_mobile_sdk/kf0;->f:I

    invoke-static {v7, v8, v3}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object v0
    :try_end_db
    .catchall {:try_start_9a .. :try_end_db} :catchall_df

    if-ne v0, v4, :cond_f9

    goto/16 :goto_1a3

    :catchall_df
    move-exception v0

    move-object v4, v5

    :goto_e1
    :try_start_e1
    invoke-static {}, Lads_mobile_sdk/hh3;->a()Lads_mobile_sdk/rg3;

    move-result-object v3

    invoke-virtual {v3}, Lads_mobile_sdk/rg3;->e()Lads_mobile_sdk/ub2;

    move-result-object v7

    const/4 v9, 0x0

    iput-boolean v9, v7, Lads_mobile_sdk/ub2;->m:Z

    invoke-virtual {v3, v0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    iget-object v3, v1, Lads_mobile_sdk/cg0;->k:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v3, v9}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    iget-object v1, v1, Lads_mobile_sdk/cg0;->d:Lads_mobile_sdk/ah3;

    invoke-virtual {v1, v6, v0}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_f9
    .catchall {:try_start_e1 .. :try_end_f9} :catchall_ff

    :cond_f9
    move-object v1, v5

    :goto_fa
    invoke-static {v1, v10}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    goto/16 :goto_1c2

    :catchall_ff
    move-exception v0

    move-object v1, v5

    move-object v5, v4

    :goto_102
    :try_start_102
    invoke-virtual {v5, v0}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v2, v0, Lox2;

    if-nez v2, :cond_132

    invoke-virtual {v5, v0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of v2, v0, Lza2;

    if-nez v2, :cond_12a

    instance-of v2, v0, Ljava/util/concurrent/CancellationException;

    if-nez v2, :cond_122

    instance-of v2, v0, Lads_mobile_sdk/mv0;

    if-eqz v2, :cond_11c

    throw v0

    :catchall_119
    move-exception v0

    move-object v2, v0

    goto :goto_133

    :cond_11c
    new-instance v2, Lads_mobile_sdk/tu0;

    invoke-direct {v2, v0}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw v2

    :cond_122
    new-instance v2, Lads_mobile_sdk/ou0;

    check-cast v0, Ljava/util/concurrent/CancellationException;

    invoke-direct {v2, v0}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw v2

    :cond_12a
    new-instance v2, Lads_mobile_sdk/uw0;

    check-cast v0, Lza2;

    invoke-direct {v2, v0}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw v2

    :cond_132
    throw v0
    :try_end_133
    .catchall {:try_start_102 .. :try_end_133} :catchall_119

    :goto_133
    :try_start_133
    throw v2
    :try_end_134
    .catchall {:try_start_133 .. :try_end_134} :catchall_134

    :catchall_134
    move-exception v0

    invoke-static {v1, v2}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0

    :cond_139
    const/4 v0, 0x1

    invoke-static {v5, v12, v0}, Lads_mobile_sdk/hh3;->a(Lads_mobile_sdk/fw0;Ljava/util/List;Z)Lads_mobile_sdk/rg3;

    move-result-object v5

    :try_start_13e
    iget-object v0, v1, Lads_mobile_sdk/cg0;->e:Lads_mobile_sdk/g0;

    invoke-virtual {v0}, Lads_mobile_sdk/g0;->b()Landroid/app/Activity;

    move-result-object v0

    if-nez v0, :cond_156

    invoke-static {v7, v9, v10}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    iget-object v0, v1, Lads_mobile_sdk/cg0;->k:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v9, 0x0

    invoke-virtual {v0, v9}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V
    :try_end_14f
    .catchall {:try_start_13e .. :try_end_14f} :catchall_153

    invoke-virtual {v5}, Lads_mobile_sdk/rg3;->close()V

    return-object v2

    :catchall_153
    move-exception v0

    move-object v1, v5

    goto :goto_1c6

    :cond_156
    :try_start_156
    iget-object v7, v1, Lads_mobile_sdk/cg0;->m:Ljava/lang/String;

    if-nez v7, :cond_15c

    move-object/from16 v7, v16

    :cond_15c
    invoke-virtual {v1, v7}, Lads_mobile_sdk/cg0;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7
    :try_end_160
    .catchall {:try_start_156 .. :try_end_160} :catchall_153

    :try_start_160
    new-instance v9, Landroid/app/AlertDialog$Builder;

    const v11, 0x1030226

    invoke-direct {v9, v0, v11}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;I)V

    invoke-virtual {v9, v7}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    invoke-virtual {v0, v8}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v8, Ljv2;

    const/4 v9, 0x2

    invoke-direct {v8, v9, v1}, Ljv2;-><init>(ILjava/lang/Object;)V

    invoke-virtual {v0, v8}, Landroid/app/AlertDialog$Builder;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v8, Lhv2;

    invoke-direct {v8, v1, v9}, Lhv2;-><init>(Lads_mobile_sdk/cg0;I)V

    invoke-virtual {v0, v15, v8}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v8, Lmv2;

    const/4 v9, 0x0

    invoke-direct {v8, v9, v1, v7}, Lmv2;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    invoke-virtual {v0, v14, v8}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    iget-object v7, v1, Lads_mobile_sdk/cg0;->a:Lly;

    new-instance v8, Lads_mobile_sdk/lf0;

    invoke-direct {v8, v0, v10, v9}, Lads_mobile_sdk/lf0;-><init>(Landroid/app/AlertDialog$Builder;Lvx;I)V

    iput-object v1, v3, Lads_mobile_sdk/kf0;->a:Lads_mobile_sdk/cg0;

    iput-object v5, v3, Lads_mobile_sdk/kf0;->b:Lads_mobile_sdk/rg3;

    iput-object v5, v3, Lads_mobile_sdk/kf0;->c:Lads_mobile_sdk/rg3;

    const/4 v9, 0x2

    iput v9, v3, Lads_mobile_sdk/kf0;->f:I

    invoke-static {v7, v8, v3}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object v0
    :try_end_1a1
    .catchall {:try_start_160 .. :try_end_1a1} :catchall_1a4

    if-ne v0, v4, :cond_1be

    :goto_1a3
    return-object v4

    :catchall_1a4
    move-exception v0

    move-object v4, v5

    :goto_1a6
    :try_start_1a6
    invoke-static {}, Lads_mobile_sdk/hh3;->a()Lads_mobile_sdk/rg3;

    move-result-object v3

    invoke-virtual {v3}, Lads_mobile_sdk/rg3;->e()Lads_mobile_sdk/ub2;

    move-result-object v7

    const/4 v9, 0x0

    iput-boolean v9, v7, Lads_mobile_sdk/ub2;->m:Z

    invoke-virtual {v3, v0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    iget-object v3, v1, Lads_mobile_sdk/cg0;->k:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v3, v9}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    iget-object v1, v1, Lads_mobile_sdk/cg0;->d:Lads_mobile_sdk/ah3;

    invoke-virtual {v1, v6, v0}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_1be
    .catchall {:try_start_1a6 .. :try_end_1be} :catchall_1c3

    :cond_1be
    move-object v1, v5

    :goto_1bf
    invoke-static {v1, v10}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    :goto_1c2
    return-object v2

    :catchall_1c3
    move-exception v0

    move-object v1, v5

    move-object v5, v4

    :goto_1c6
    :try_start_1c6
    invoke-virtual {v5, v0}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v2, v0, Lox2;

    if-nez v2, :cond_1f6

    invoke-virtual {v5, v0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of v2, v0, Lza2;

    if-nez v2, :cond_1ee

    instance-of v2, v0, Ljava/util/concurrent/CancellationException;

    if-nez v2, :cond_1e6

    instance-of v2, v0, Lads_mobile_sdk/mv0;

    if-eqz v2, :cond_1e0

    throw v0

    :catchall_1dd
    move-exception v0

    move-object v2, v0

    goto :goto_1f7

    :cond_1e0
    new-instance v2, Lads_mobile_sdk/tu0;

    invoke-direct {v2, v0}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw v2

    :cond_1e6
    new-instance v2, Lads_mobile_sdk/ou0;

    check-cast v0, Ljava/util/concurrent/CancellationException;

    invoke-direct {v2, v0}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw v2

    :cond_1ee
    new-instance v2, Lads_mobile_sdk/uw0;

    check-cast v0, Lza2;

    invoke-direct {v2, v0}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw v2

    :cond_1f6
    throw v0
    :try_end_1f7
    .catchall {:try_start_1c6 .. :try_end_1f7} :catchall_1dd

    :goto_1f7
    :try_start_1f7
    throw v2
    :try_end_1f8
    .catchall {:try_start_1f7 .. :try_end_1f8} :catchall_1f8

    :catchall_1f8
    move-exception v0

    invoke-static {v1, v2}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0
.end method

.method public final e(Lwx;)Ljava/lang/Object;
    .registers 26

    .prologue
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    sget-object v2, Lrg2;->a:Lrg2;

    instance-of v3, v1, Lads_mobile_sdk/mf0;

    if-eqz v3, :cond_19

    move-object v3, v1

    check-cast v3, Lads_mobile_sdk/mf0;

    iget v4, v3, Lads_mobile_sdk/mf0;->k:I

    const/high16 v5, -0x80000000

    and-int v6, v4, v5

    if-eqz v6, :cond_19

    sub-int/2addr v4, v5

    iput v4, v3, Lads_mobile_sdk/mf0;->k:I

    goto :goto_1e

    :cond_19
    new-instance v3, Lads_mobile_sdk/mf0;

    invoke-direct {v3, v0, v1}, Lads_mobile_sdk/mf0;-><init>(Lads_mobile_sdk/cg0;Lwx;)V

    :goto_1e
    iget-object v1, v3, Lads_mobile_sdk/mf0;->i:Ljava/lang/Object;

    sget-object v4, Lwy;->a:Lwy;

    iget v5, v3, Lads_mobile_sdk/mf0;->k:I

    const-string v8, "Failed to show inspector settings dialog"

    const-string v9, "Save"

    const-string v10, "Dismiss"

    const-string v11, "Setup gesture"

    const-string v13, "Flick"

    const-string v14, "Shake"

    const-string v15, "None"

    const/4 v12, 0x0

    packed-switch v5, :pswitch_data_4c0

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {v0}, Lz6;->w(Ljava/lang/String;)V

    return-object v12

    :pswitch_3c  #0xa
    iget-object v4, v3, Lads_mobile_sdk/mf0;->c:Ljava/io/Closeable;

    iget-object v0, v3, Lads_mobile_sdk/mf0;->b:Ljava/io/Closeable;

    move-object v5, v0

    check-cast v5, Lads_mobile_sdk/rg3;

    iget-object v0, v3, Lads_mobile_sdk/mf0;->a:Ljava/lang/Object;

    move-object v3, v0

    check-cast v3, Lads_mobile_sdk/cg0;

    :try_start_48
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_4b
    .catchall {:try_start_48 .. :try_end_4b} :catchall_4f

    move-object/from16 v17, v2

    goto/16 :goto_458

    :catchall_4f
    move-exception v0

    move-object/from16 v17, v2

    goto/16 :goto_462

    :pswitch_54  #0x9
    iget v0, v3, Lads_mobile_sdk/mf0;->h:I

    iget v5, v3, Lads_mobile_sdk/mf0;->g:I

    iget v13, v3, Lads_mobile_sdk/mf0;->f:I

    iget-object v14, v3, Lads_mobile_sdk/mf0;->e:Ljava/util/ArrayList;

    iget-object v15, v3, Lads_mobile_sdk/mf0;->d:Landroid/app/Activity;

    iget-object v6, v3, Lads_mobile_sdk/mf0;->c:Ljava/io/Closeable;

    iget-object v7, v3, Lads_mobile_sdk/mf0;->b:Ljava/io/Closeable;

    check-cast v7, Lads_mobile_sdk/rg3;

    iget-object v12, v3, Lads_mobile_sdk/mf0;->a:Ljava/lang/Object;

    check-cast v12, Lads_mobile_sdk/cg0;

    :try_start_68
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_6b
    .catchall {:try_start_68 .. :try_end_6b} :catchall_74

    move/from16 v22, v0

    move-object/from16 v17, v2

    :goto_6f
    move/from16 v23, v5

    move-object v5, v7

    goto/16 :goto_3da

    :catchall_74
    move-exception v0

    goto/16 :goto_485

    :pswitch_77  #0x8
    iget-object v6, v3, Lads_mobile_sdk/mf0;->b:Ljava/io/Closeable;

    iget-object v0, v3, Lads_mobile_sdk/mf0;->a:Ljava/lang/Object;

    move-object v7, v0

    check-cast v7, Lads_mobile_sdk/rg3;

    :try_start_7e
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_81
    .catchall {:try_start_7e .. :try_end_81} :catchall_74

    move-object/from16 v17, v2

    const/4 v1, 0x0

    goto/16 :goto_383

    :pswitch_86  #0x7
    iget-object v0, v3, Lads_mobile_sdk/mf0;->d:Landroid/app/Activity;

    iget-object v6, v3, Lads_mobile_sdk/mf0;->c:Ljava/io/Closeable;

    iget-object v5, v3, Lads_mobile_sdk/mf0;->b:Ljava/io/Closeable;

    move-object v7, v5

    check-cast v7, Lads_mobile_sdk/rg3;

    iget-object v5, v3, Lads_mobile_sdk/mf0;->a:Ljava/lang/Object;

    check-cast v5, Lads_mobile_sdk/cg0;

    :try_start_93
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_96
    .catchall {:try_start_93 .. :try_end_96} :catchall_74

    move-object/from16 v17, v2

    goto/16 :goto_366

    :pswitch_9a  #0x6
    iget-object v0, v3, Lads_mobile_sdk/mf0;->d:Landroid/app/Activity;

    iget-object v6, v3, Lads_mobile_sdk/mf0;->c:Ljava/io/Closeable;

    iget-object v5, v3, Lads_mobile_sdk/mf0;->b:Ljava/io/Closeable;

    move-object v7, v5

    check-cast v7, Lads_mobile_sdk/rg3;

    iget-object v5, v3, Lads_mobile_sdk/mf0;->a:Ljava/lang/Object;

    check-cast v5, Lads_mobile_sdk/cg0;

    :try_start_a7
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_aa
    .catchall {:try_start_a7 .. :try_end_aa} :catchall_74

    move-object/from16 v17, v2

    move-object v2, v1

    move-object v1, v0

    move-object v0, v5

    goto/16 :goto_33b

    :pswitch_b1  #0x5
    iget-object v4, v3, Lads_mobile_sdk/mf0;->c:Ljava/io/Closeable;

    iget-object v0, v3, Lads_mobile_sdk/mf0;->b:Ljava/io/Closeable;

    move-object v5, v0

    check-cast v5, Lads_mobile_sdk/rg3;

    iget-object v0, v3, Lads_mobile_sdk/mf0;->a:Ljava/lang/Object;

    move-object v3, v0

    check-cast v3, Lads_mobile_sdk/cg0;

    :try_start_bd
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_c0
    .catchall {:try_start_bd .. :try_end_c0} :catchall_c4

    move-object/from16 v17, v2

    goto/16 :goto_29a

    :catchall_c4
    move-exception v0

    move-object/from16 v17, v2

    goto/16 :goto_2a4

    :pswitch_c9  #0x4
    iget v0, v3, Lads_mobile_sdk/mf0;->h:I

    iget v5, v3, Lads_mobile_sdk/mf0;->g:I

    iget v6, v3, Lads_mobile_sdk/mf0;->f:I

    iget-object v7, v3, Lads_mobile_sdk/mf0;->e:Ljava/util/ArrayList;

    iget-object v12, v3, Lads_mobile_sdk/mf0;->d:Landroid/app/Activity;

    iget-object v13, v3, Lads_mobile_sdk/mf0;->c:Ljava/io/Closeable;

    iget-object v14, v3, Lads_mobile_sdk/mf0;->b:Ljava/io/Closeable;

    check-cast v14, Lads_mobile_sdk/rg3;

    iget-object v15, v3, Lads_mobile_sdk/mf0;->a:Ljava/lang/Object;

    check-cast v15, Lads_mobile_sdk/cg0;

    :try_start_dd
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_e0
    .catchall {:try_start_dd .. :try_end_e0} :catchall_ea

    move/from16 v22, v0

    move-object/from16 v17, v2

    move/from16 v23, v5

    move-object v2, v13

    move-object v5, v14

    goto/16 :goto_21c

    :catchall_ea
    move-exception v0

    goto/16 :goto_2c9

    :pswitch_ed  #0x3
    iget-object v13, v3, Lads_mobile_sdk/mf0;->b:Ljava/io/Closeable;

    iget-object v0, v3, Lads_mobile_sdk/mf0;->a:Ljava/lang/Object;

    move-object v14, v0

    check-cast v14, Lads_mobile_sdk/rg3;

    :try_start_f4
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_f7
    .catchall {:try_start_f4 .. :try_end_f7} :catchall_ea

    move-object/from16 v17, v2

    const/4 v1, 0x0

    goto/16 :goto_1c2

    :pswitch_fc  #0x2
    iget-object v0, v3, Lads_mobile_sdk/mf0;->d:Landroid/app/Activity;

    iget-object v5, v3, Lads_mobile_sdk/mf0;->c:Ljava/io/Closeable;

    iget-object v6, v3, Lads_mobile_sdk/mf0;->b:Ljava/io/Closeable;

    check-cast v6, Lads_mobile_sdk/rg3;

    iget-object v7, v3, Lads_mobile_sdk/mf0;->a:Ljava/lang/Object;

    check-cast v7, Lads_mobile_sdk/cg0;

    :try_start_108
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_10b
    .catchall {:try_start_108 .. :try_end_10b} :catchall_110

    move-object/from16 v17, v2

    move-object v2, v5

    goto/16 :goto_1a5

    :catchall_110
    move-exception v0

    move-object v13, v5

    :goto_112
    move-object v14, v6

    goto/16 :goto_2c9

    :pswitch_115  #0x1
    iget-object v0, v3, Lads_mobile_sdk/mf0;->d:Landroid/app/Activity;

    iget-object v5, v3, Lads_mobile_sdk/mf0;->c:Ljava/io/Closeable;

    iget-object v6, v3, Lads_mobile_sdk/mf0;->b:Ljava/io/Closeable;

    check-cast v6, Lads_mobile_sdk/rg3;

    iget-object v7, v3, Lads_mobile_sdk/mf0;->a:Ljava/lang/Object;

    check-cast v7, Lads_mobile_sdk/cg0;

    :try_start_121
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_124
    .catchall {:try_start_121 .. :try_end_124} :catchall_110

    move-object/from16 v17, v2

    move-object v2, v5

    move-object v5, v0

    move-object v0, v7

    goto :goto_17c

    :pswitch_12a  #0x0
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object v1, v0, Lads_mobile_sdk/cg0;->c:Lads_mobile_sdk/ux2;

    sget-object v5, Lads_mobile_sdk/fw0;->W0:Lads_mobile_sdk/fw0;

    iget-object v6, v0, Lads_mobile_sdk/cg0;->o:Lads_mobile_sdk/kh3;

    sget-object v7, Lba0;->a:Lba0;

    invoke-static {}, Lads_mobile_sdk/hh3;->b()Lads_mobile_sdk/gh3;

    move-result-object v12

    iget-object v12, v12, Lads_mobile_sdk/gh3;->a:Lads_mobile_sdk/rg3;

    move-object/from16 v17, v2

    const-string v2, "No Activity context available for opening ad inspector settings."

    move-object/from16 v18, v12

    const/4 v12, 0x6

    if-nez v18, :cond_304

    invoke-static {v1, v5, v7, v6}, Lads_mobile_sdk/ux2;->a(Lads_mobile_sdk/ux2;Lads_mobile_sdk/fw0;Ljava/util/List;Lads_mobile_sdk/kh3;)Lads_mobile_sdk/wk2;

    move-result-object v1

    :try_start_148
    iget-object v5, v0, Lads_mobile_sdk/cg0;->e:Lads_mobile_sdk/g0;

    invoke-virtual {v5}, Lads_mobile_sdk/g0;->b()Landroid/app/Activity;

    move-result-object v5

    if-nez v5, :cond_161

    const/4 v6, 0x0

    invoke-static {v12, v2, v6}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    iget-object v0, v0, Lads_mobile_sdk/cg0;->k:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x0

    invoke-virtual {v0, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V
    :try_end_15a
    .catchall {:try_start_148 .. :try_end_15a} :catchall_15e

    invoke-virtual {v1}, Lads_mobile_sdk/rg3;->close()V

    return-object v17

    :catchall_15e
    move-exception v0

    goto/16 :goto_2cc

    :cond_161
    :try_start_161
    iget-object v2, v0, Lads_mobile_sdk/cg0;->j:Lads_mobile_sdk/d91;

    iput-object v0, v3, Lads_mobile_sdk/mf0;->a:Ljava/lang/Object;

    iput-object v1, v3, Lads_mobile_sdk/mf0;->b:Ljava/io/Closeable;

    iput-object v1, v3, Lads_mobile_sdk/mf0;->c:Ljava/io/Closeable;

    iput-object v5, v3, Lads_mobile_sdk/mf0;->d:Landroid/app/Activity;

    const/4 v6, 0x1

    iput v6, v3, Lads_mobile_sdk/mf0;->k:I

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v2, v3}, Lads_mobile_sdk/d91;->a(Lads_mobile_sdk/d91;Lwx;)Ljava/lang/Object;

    move-result-object v2
    :try_end_175
    .catchall {:try_start_161 .. :try_end_175} :catchall_15e

    if-ne v2, v4, :cond_179

    goto/16 :goto_456

    :cond_179
    move-object v6, v1

    move-object v1, v2

    move-object v2, v6

    :goto_17c
    :try_start_17c
    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-nez v1, :cond_1cc

    iget-object v1, v0, Lads_mobile_sdk/cg0;->j:Lads_mobile_sdk/d91;

    iget-object v7, v0, Lads_mobile_sdk/cg0;->l:Ljava/lang/String;

    iget-object v12, v0, Lads_mobile_sdk/cg0;->n:Lfx0;

    iput-object v0, v3, Lads_mobile_sdk/mf0;->a:Ljava/lang/Object;

    iput-object v6, v3, Lads_mobile_sdk/mf0;->b:Ljava/io/Closeable;

    iput-object v2, v3, Lads_mobile_sdk/mf0;->c:Ljava/io/Closeable;

    iput-object v5, v3, Lads_mobile_sdk/mf0;->d:Landroid/app/Activity;

    move-object/from16 v18, v0

    const/4 v0, 0x2

    iput v0, v3, Lads_mobile_sdk/mf0;->k:I

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v1, v7, v12, v3}, Lads_mobile_sdk/d91;->a(Lads_mobile_sdk/d91;Ljava/lang/String;Lfx0;Lwx;)Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v4, :cond_1a2

    goto/16 :goto_456

    :cond_1a2
    move-object v0, v5

    move-object/from16 v7, v18

    :goto_1a5
    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-nez v1, :cond_1ca

    iput-object v6, v3, Lads_mobile_sdk/mf0;->a:Ljava/lang/Object;

    iput-object v2, v3, Lads_mobile_sdk/mf0;->b:Ljava/io/Closeable;

    const/4 v1, 0x0

    iput-object v1, v3, Lads_mobile_sdk/mf0;->c:Ljava/io/Closeable;

    iput-object v1, v3, Lads_mobile_sdk/mf0;->d:Landroid/app/Activity;

    const/4 v0, 0x3

    iput v0, v3, Lads_mobile_sdk/mf0;->k:I

    invoke-virtual {v7, v3}, Lads_mobile_sdk/cg0;->c(Lwx;)Ljava/lang/Object;

    move-result-object v0
    :try_end_1bd
    .catchall {:try_start_17c .. :try_end_1bd} :catchall_1c6

    if-ne v0, v4, :cond_1c1

    goto/16 :goto_456

    :cond_1c1
    move-object v13, v2

    :goto_1c2
    invoke-static {v13, v1}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object v17

    :catchall_1c6
    move-exception v0

    move-object v13, v2

    goto/16 :goto_112

    :cond_1ca
    move-object v12, v0

    goto :goto_1d1

    :cond_1cc
    move-object/from16 v18, v0

    move-object v12, v5

    move-object/from16 v7, v18

    :goto_1d1
    :try_start_1d1
    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v0, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/16 v16, 0x1

    add-int/lit8 v1, v1, -0x1

    invoke-virtual {v0, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v5

    add-int/lit8 v5, v5, -0x1

    invoke-virtual {v0, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v13

    add-int/lit8 v13, v13, -0x1

    iget-object v14, v7, Lads_mobile_sdk/cg0;->j:Lads_mobile_sdk/d91;

    iput-object v7, v3, Lads_mobile_sdk/mf0;->a:Ljava/lang/Object;

    iput-object v6, v3, Lads_mobile_sdk/mf0;->b:Ljava/io/Closeable;

    iput-object v2, v3, Lads_mobile_sdk/mf0;->c:Ljava/io/Closeable;

    iput-object v12, v3, Lads_mobile_sdk/mf0;->d:Landroid/app/Activity;

    iput-object v0, v3, Lads_mobile_sdk/mf0;->e:Ljava/util/ArrayList;

    iput v1, v3, Lads_mobile_sdk/mf0;->f:I

    iput v5, v3, Lads_mobile_sdk/mf0;->g:I

    iput v13, v3, Lads_mobile_sdk/mf0;->h:I

    const/4 v15, 0x4

    iput v15, v3, Lads_mobile_sdk/mf0;->k:I

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v14, v3}, Lads_mobile_sdk/d91;->b(Lads_mobile_sdk/d91;Lwx;)Ljava/lang/Object;

    move-result-object v14
    :try_end_20f
    .catchall {:try_start_1d1 .. :try_end_20f} :catchall_1c6

    if-ne v14, v4, :cond_213

    goto/16 :goto_456

    :cond_213
    move/from16 v23, v5

    move-object v5, v6

    move-object v15, v7

    move/from16 v22, v13

    move-object v7, v0

    move v6, v1

    move-object v1, v14

    :goto_21c
    :try_start_21c
    check-cast v1, Lads_mobile_sdk/ia1;

    invoke-virtual {v1}, Lads_mobile_sdk/ia1;->r$2()I

    move-result v0

    sget-object v1, Lgx2;->a:[I

    invoke-static {v0}, Lc33;->x(I)I

    move-result v0

    aget v0, v1, v0

    const/4 v1, 0x1

    if-eq v0, v1, :cond_234

    const/4 v1, 0x2

    if-eq v0, v1, :cond_231

    goto :goto_236

    :cond_231
    move/from16 v6, v23

    goto :goto_236

    :cond_234
    move/from16 v6, v22

    :goto_236
    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-direct {v0, v6}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V
    :try_end_23b
    .catchall {:try_start_21c .. :try_end_23b} :catchall_2c6

    :try_start_23b
    new-instance v1, Landroid/app/AlertDialog$Builder;

    const v13, 0x1030226

    invoke-direct {v1, v12, v13}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;I)V

    invoke-virtual {v1, v11}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    const/4 v11, 0x0

    new-array v12, v11, [Ljava/lang/String;

    invoke-interface {v7, v12}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v7

    check-cast v7, [Ljava/lang/CharSequence;

    new-instance v11, Ld51;

    const/4 v12, 0x4

    invoke-direct {v11, v12, v0}, Ld51;-><init>(ILjava/lang/Object;)V

    invoke-virtual {v1, v7, v6, v11}, Landroid/app/AlertDialog$Builder;->setSingleChoiceItems([Ljava/lang/CharSequence;ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    new-instance v7, Lnv2;

    invoke-direct {v7, v15}, Lnv2;-><init>(Lads_mobile_sdk/cg0;)V

    invoke-virtual {v1, v7}, Landroid/app/AlertDialog$Builder;->setOnCancelListener(Landroid/content/DialogInterface$OnCancelListener;)Landroid/app/AlertDialog$Builder;

    new-instance v7, Lhv2;

    const/4 v11, 0x3

    invoke-direct {v7, v15, v11}, Lhv2;-><init>(Lads_mobile_sdk/cg0;I)V

    invoke-virtual {v1, v10, v7}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    new-instance v18, Liv2;
    :try_end_26b
    .catchall {:try_start_23b .. :try_end_26b} :catchall_29c

    move-object/from16 v20, v0

    move/from16 v21, v6

    move-object/from16 v19, v15

    :try_start_271
    invoke-direct/range {v18 .. v23}, Liv2;-><init>(Lads_mobile_sdk/cg0;Ljava/util/concurrent/atomic/AtomicInteger;III)V
    :try_end_274
    .catchall {:try_start_271 .. :try_end_274} :catchall_2a0

    move-object/from16 v0, v18

    move-object/from16 v15, v19

    :try_start_278
    invoke-virtual {v1, v9, v0}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    iget-object v0, v15, Lads_mobile_sdk/cg0;->a:Lly;

    new-instance v6, Lads_mobile_sdk/lf0;

    const/4 v7, 0x1

    const/4 v9, 0x0

    invoke-direct {v6, v1, v9, v7}, Lads_mobile_sdk/lf0;-><init>(Landroid/app/AlertDialog$Builder;Lvx;I)V

    iput-object v15, v3, Lads_mobile_sdk/mf0;->a:Ljava/lang/Object;

    iput-object v5, v3, Lads_mobile_sdk/mf0;->b:Ljava/io/Closeable;

    iput-object v2, v3, Lads_mobile_sdk/mf0;->c:Ljava/io/Closeable;

    iput-object v9, v3, Lads_mobile_sdk/mf0;->d:Landroid/app/Activity;

    iput-object v9, v3, Lads_mobile_sdk/mf0;->e:Ljava/util/ArrayList;

    const/4 v1, 0x5

    iput v1, v3, Lads_mobile_sdk/mf0;->k:I

    invoke-static {v0, v6, v3}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object v0
    :try_end_295
    .catchall {:try_start_278 .. :try_end_295} :catchall_29c

    if-ne v0, v4, :cond_299

    goto/16 :goto_456

    :cond_299
    move-object v4, v2

    :goto_29a
    const/4 v1, 0x0

    goto :goto_2bd

    :catchall_29c
    move-exception v0

    :goto_29d
    move-object v4, v2

    move-object v3, v15

    goto :goto_2a4

    :catchall_2a0
    move-exception v0

    move-object/from16 v15, v19

    goto :goto_29d

    :goto_2a4
    :try_start_2a4
    invoke-static {}, Lads_mobile_sdk/hh3;->a()Lads_mobile_sdk/rg3;

    move-result-object v1

    invoke-virtual {v1}, Lads_mobile_sdk/rg3;->e()Lads_mobile_sdk/ub2;

    move-result-object v2

    const/4 v11, 0x0

    iput-boolean v11, v2, Lads_mobile_sdk/ub2;->m:Z

    invoke-virtual {v1, v0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    iget-object v1, v3, Lads_mobile_sdk/cg0;->k:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v1, v11}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    iget-object v1, v3, Lads_mobile_sdk/cg0;->d:Lads_mobile_sdk/ah3;

    invoke-virtual {v1, v8, v0}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_2bc
    .catchall {:try_start_2a4 .. :try_end_2bc} :catchall_2c2

    goto :goto_29a

    :goto_2bd
    invoke-static {v4, v1}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    goto/16 :goto_47e

    :catchall_2c2
    move-exception v0

    move-object v13, v4

    move-object v14, v5

    goto :goto_2c9

    :catchall_2c6
    move-exception v0

    move-object v1, v5

    goto :goto_2cd

    :goto_2c9
    move-object v2, v13

    move-object v1, v14

    goto :goto_2cd

    :goto_2cc
    move-object v2, v1

    :goto_2cd
    :try_start_2cd
    invoke-virtual {v1, v0}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v3, v0, Lox2;

    if-nez v3, :cond_2fd

    invoke-virtual {v1, v0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of v1, v0, Lza2;

    if-nez v1, :cond_2f5

    instance-of v1, v0, Ljava/util/concurrent/CancellationException;

    if-nez v1, :cond_2ed

    instance-of v1, v0, Lads_mobile_sdk/mv0;

    if-eqz v1, :cond_2e7

    throw v0

    :catchall_2e4
    move-exception v0

    move-object v1, v0

    goto :goto_2fe

    :cond_2e7
    new-instance v1, Lads_mobile_sdk/tu0;

    invoke-direct {v1, v0}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw v1

    :cond_2ed
    new-instance v1, Lads_mobile_sdk/ou0;

    check-cast v0, Ljava/util/concurrent/CancellationException;

    invoke-direct {v1, v0}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw v1

    :cond_2f5
    new-instance v1, Lads_mobile_sdk/uw0;

    check-cast v0, Lza2;

    invoke-direct {v1, v0}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw v1

    :cond_2fd
    throw v0
    :try_end_2fe
    .catchall {:try_start_2cd .. :try_end_2fe} :catchall_2e4

    :goto_2fe
    :try_start_2fe
    throw v1
    :try_end_2ff
    .catchall {:try_start_2fe .. :try_end_2ff} :catchall_2ff

    :catchall_2ff
    move-exception v0

    invoke-static {v2, v1}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0

    :cond_304
    const/4 v1, 0x1

    invoke-static {v5, v7, v1}, Lads_mobile_sdk/hh3;->a(Lads_mobile_sdk/fw0;Ljava/util/List;Z)Lads_mobile_sdk/rg3;

    move-result-object v5

    :try_start_309
    iget-object v1, v0, Lads_mobile_sdk/cg0;->e:Lads_mobile_sdk/g0;

    invoke-virtual {v1}, Lads_mobile_sdk/g0;->b()Landroid/app/Activity;

    move-result-object v1

    if-nez v1, :cond_322

    const/4 v6, 0x0

    invoke-static {v12, v2, v6}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    iget-object v0, v0, Lads_mobile_sdk/cg0;->k:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v11, 0x0

    invoke-virtual {v0, v11}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V
    :try_end_31b
    .catchall {:try_start_309 .. :try_end_31b} :catchall_31f

    invoke-virtual {v5}, Lads_mobile_sdk/rg3;->close()V

    return-object v17

    :catchall_31f
    move-exception v0

    goto/16 :goto_487

    :cond_322
    :try_start_322
    iget-object v2, v0, Lads_mobile_sdk/cg0;->j:Lads_mobile_sdk/d91;

    iput-object v0, v3, Lads_mobile_sdk/mf0;->a:Ljava/lang/Object;

    iput-object v5, v3, Lads_mobile_sdk/mf0;->b:Ljava/io/Closeable;

    iput-object v5, v3, Lads_mobile_sdk/mf0;->c:Ljava/io/Closeable;

    iput-object v1, v3, Lads_mobile_sdk/mf0;->d:Landroid/app/Activity;

    iput v12, v3, Lads_mobile_sdk/mf0;->k:I

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v2, v3}, Lads_mobile_sdk/d91;->a(Lads_mobile_sdk/d91;Lwx;)Ljava/lang/Object;

    move-result-object v2
    :try_end_335
    .catchall {:try_start_322 .. :try_end_335} :catchall_31f

    if-ne v2, v4, :cond_339

    goto/16 :goto_456

    :cond_339
    move-object v6, v5

    move-object v7, v6

    :goto_33b
    :try_start_33b
    check-cast v2, Ljava/lang/Boolean;

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-nez v2, :cond_389

    iget-object v2, v0, Lads_mobile_sdk/cg0;->j:Lads_mobile_sdk/d91;

    iget-object v5, v0, Lads_mobile_sdk/cg0;->l:Ljava/lang/String;

    iget-object v12, v0, Lads_mobile_sdk/cg0;->n:Lfx0;

    iput-object v0, v3, Lads_mobile_sdk/mf0;->a:Ljava/lang/Object;

    iput-object v7, v3, Lads_mobile_sdk/mf0;->b:Ljava/io/Closeable;

    iput-object v6, v3, Lads_mobile_sdk/mf0;->c:Ljava/io/Closeable;

    iput-object v1, v3, Lads_mobile_sdk/mf0;->d:Landroid/app/Activity;

    move-object/from16 v18, v0

    const/4 v0, 0x7

    iput v0, v3, Lads_mobile_sdk/mf0;->k:I

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v2, v5, v12, v3}, Lads_mobile_sdk/d91;->a(Lads_mobile_sdk/d91;Ljava/lang/String;Lfx0;Lwx;)Ljava/lang/Object;

    move-result-object v0

    if-ne v0, v4, :cond_361

    goto/16 :goto_456

    :cond_361
    move-object v5, v1

    move-object v1, v0

    move-object v0, v5

    move-object/from16 v5, v18

    :goto_366
    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-nez v1, :cond_387

    iput-object v7, v3, Lads_mobile_sdk/mf0;->a:Ljava/lang/Object;

    iput-object v6, v3, Lads_mobile_sdk/mf0;->b:Ljava/io/Closeable;

    const/4 v1, 0x0

    iput-object v1, v3, Lads_mobile_sdk/mf0;->c:Ljava/io/Closeable;

    iput-object v1, v3, Lads_mobile_sdk/mf0;->d:Landroid/app/Activity;

    const/16 v0, 0x8

    iput v0, v3, Lads_mobile_sdk/mf0;->k:I

    invoke-virtual {v5, v3}, Lads_mobile_sdk/cg0;->c(Lwx;)Ljava/lang/Object;

    move-result-object v0
    :try_end_37f
    .catchall {:try_start_33b .. :try_end_37f} :catchall_74

    if-ne v0, v4, :cond_383

    goto/16 :goto_456

    :cond_383
    :goto_383
    invoke-static {v6, v1}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object v17

    :cond_387
    move-object v12, v5

    goto :goto_38e

    :cond_389
    move-object/from16 v18, v0

    move-object v0, v1

    move-object/from16 v12, v18

    :goto_38e
    :try_start_38e
    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    invoke-virtual {v1, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/16 v16, 0x1

    add-int/lit8 v2, v2, -0x1

    invoke-virtual {v1, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v5

    add-int/lit8 v5, v5, -0x1

    invoke-virtual {v1, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v13

    add-int/lit8 v13, v13, -0x1

    iget-object v14, v12, Lads_mobile_sdk/cg0;->j:Lads_mobile_sdk/d91;

    iput-object v12, v3, Lads_mobile_sdk/mf0;->a:Ljava/lang/Object;

    iput-object v7, v3, Lads_mobile_sdk/mf0;->b:Ljava/io/Closeable;

    iput-object v6, v3, Lads_mobile_sdk/mf0;->c:Ljava/io/Closeable;

    iput-object v0, v3, Lads_mobile_sdk/mf0;->d:Landroid/app/Activity;

    iput-object v1, v3, Lads_mobile_sdk/mf0;->e:Ljava/util/ArrayList;

    iput v2, v3, Lads_mobile_sdk/mf0;->f:I

    iput v5, v3, Lads_mobile_sdk/mf0;->g:I

    iput v13, v3, Lads_mobile_sdk/mf0;->h:I

    const/16 v15, 0x9

    iput v15, v3, Lads_mobile_sdk/mf0;->k:I

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v14, v3}, Lads_mobile_sdk/d91;->b(Lads_mobile_sdk/d91;Lwx;)Ljava/lang/Object;

    move-result-object v14
    :try_end_3cd
    .catchall {:try_start_38e .. :try_end_3cd} :catchall_74

    if-ne v14, v4, :cond_3d1

    goto/16 :goto_456

    :cond_3d1
    move-object v15, v14

    move-object v14, v1

    move-object v1, v15

    move-object v15, v0

    move/from16 v22, v13

    move v13, v2

    goto/16 :goto_6f

    :goto_3da
    :try_start_3da
    check-cast v1, Lads_mobile_sdk/ia1;

    invoke-virtual {v1}, Lads_mobile_sdk/ia1;->r$2()I

    move-result v0

    sget-object v1, Lgx2;->a:[I

    invoke-static {v0}, Lc33;->x(I)I

    move-result v0

    aget v0, v1, v0

    const/4 v1, 0x1

    if-eq v0, v1, :cond_3f2

    const/4 v1, 0x2

    if-eq v0, v1, :cond_3ef

    goto :goto_3f4

    :cond_3ef
    move/from16 v13, v23

    goto :goto_3f4

    :cond_3f2
    move/from16 v13, v22

    :goto_3f4
    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-direct {v0, v13}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V
    :try_end_3f9
    .catchall {:try_start_3da .. :try_end_3f9} :catchall_483

    :try_start_3f9
    new-instance v1, Landroid/app/AlertDialog$Builder;

    const v2, 0x1030226

    invoke-direct {v1, v15, v2}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;I)V

    invoke-virtual {v1, v11}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    const/4 v11, 0x0

    new-array v2, v11, [Ljava/lang/String;

    invoke-interface {v14, v2}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v2

    check-cast v2, [Ljava/lang/CharSequence;

    new-instance v7, Ld51;

    const/4 v15, 0x4

    invoke-direct {v7, v15, v0}, Ld51;-><init>(ILjava/lang/Object;)V

    invoke-virtual {v1, v2, v13, v7}, Landroid/app/AlertDialog$Builder;->setSingleChoiceItems([Ljava/lang/CharSequence;ILandroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    new-instance v2, Lnv2;

    invoke-direct {v2, v12}, Lnv2;-><init>(Lads_mobile_sdk/cg0;)V

    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setOnCancelListener(Landroid/content/DialogInterface$OnCancelListener;)Landroid/app/AlertDialog$Builder;

    new-instance v2, Lhv2;

    const/4 v11, 0x3

    invoke-direct {v2, v12, v11}, Lhv2;-><init>(Lads_mobile_sdk/cg0;I)V

    invoke-virtual {v1, v10, v2}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    new-instance v18, Liv2;
    :try_end_429
    .catchall {:try_start_3f9 .. :try_end_429} :catchall_45a

    move-object/from16 v20, v0

    move-object/from16 v19, v12

    move/from16 v21, v13

    :try_start_42f
    invoke-direct/range {v18 .. v23}, Liv2;-><init>(Lads_mobile_sdk/cg0;Ljava/util/concurrent/atomic/AtomicInteger;III)V
    :try_end_432
    .catchall {:try_start_42f .. :try_end_432} :catchall_45e

    move-object/from16 v0, v18

    move-object/from16 v12, v19

    :try_start_436
    invoke-virtual {v1, v9, v0}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    iget-object v0, v12, Lads_mobile_sdk/cg0;->a:Lly;

    new-instance v2, Lads_mobile_sdk/lf0;

    const/4 v7, 0x1

    const/4 v9, 0x0

    invoke-direct {v2, v1, v9, v7}, Lads_mobile_sdk/lf0;-><init>(Landroid/app/AlertDialog$Builder;Lvx;I)V

    iput-object v12, v3, Lads_mobile_sdk/mf0;->a:Ljava/lang/Object;

    iput-object v5, v3, Lads_mobile_sdk/mf0;->b:Ljava/io/Closeable;

    iput-object v6, v3, Lads_mobile_sdk/mf0;->c:Ljava/io/Closeable;

    iput-object v9, v3, Lads_mobile_sdk/mf0;->d:Landroid/app/Activity;

    iput-object v9, v3, Lads_mobile_sdk/mf0;->e:Ljava/util/ArrayList;

    const/16 v1, 0xa

    iput v1, v3, Lads_mobile_sdk/mf0;->k:I

    invoke-static {v0, v2, v3}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object v0
    :try_end_454
    .catchall {:try_start_436 .. :try_end_454} :catchall_45a

    if-ne v0, v4, :cond_457

    :goto_456
    return-object v4

    :cond_457
    move-object v4, v6

    :goto_458
    const/4 v1, 0x0

    goto :goto_47b

    :catchall_45a
    move-exception v0

    :goto_45b
    move-object v4, v6

    move-object v3, v12

    goto :goto_462

    :catchall_45e
    move-exception v0

    move-object/from16 v12, v19

    goto :goto_45b

    :goto_462
    :try_start_462
    invoke-static {}, Lads_mobile_sdk/hh3;->a()Lads_mobile_sdk/rg3;

    move-result-object v1

    invoke-virtual {v1}, Lads_mobile_sdk/rg3;->e()Lads_mobile_sdk/ub2;

    move-result-object v2

    const/4 v11, 0x0

    iput-boolean v11, v2, Lads_mobile_sdk/ub2;->m:Z

    invoke-virtual {v1, v0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    iget-object v1, v3, Lads_mobile_sdk/cg0;->k:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v1, v11}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    iget-object v1, v3, Lads_mobile_sdk/cg0;->d:Lads_mobile_sdk/ah3;

    invoke-virtual {v1, v8, v0}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_47a
    .catchall {:try_start_462 .. :try_end_47a} :catchall_47f

    goto :goto_458

    :goto_47b
    invoke-static {v4, v1}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    :goto_47e
    return-object v17

    :catchall_47f
    move-exception v0

    move-object v6, v4

    move-object v7, v5

    goto :goto_485

    :catchall_483
    move-exception v0

    goto :goto_488

    :goto_485
    move-object v5, v7

    goto :goto_488

    :goto_487
    move-object v6, v5

    :goto_488
    :try_start_488
    invoke-virtual {v5, v0}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v1, v0, Lox2;

    if-nez v1, :cond_4b8

    invoke-virtual {v5, v0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of v1, v0, Lza2;

    if-nez v1, :cond_4b0

    instance-of v1, v0, Ljava/util/concurrent/CancellationException;

    if-nez v1, :cond_4a8

    instance-of v1, v0, Lads_mobile_sdk/mv0;

    if-eqz v1, :cond_4a2

    throw v0

    :catchall_49f
    move-exception v0

    move-object v1, v0

    goto :goto_4b9

    :cond_4a2
    new-instance v1, Lads_mobile_sdk/tu0;

    invoke-direct {v1, v0}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw v1

    :cond_4a8
    new-instance v1, Lads_mobile_sdk/ou0;

    check-cast v0, Ljava/util/concurrent/CancellationException;

    invoke-direct {v1, v0}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw v1

    :cond_4b0
    new-instance v1, Lads_mobile_sdk/uw0;

    check-cast v0, Lza2;

    invoke-direct {v1, v0}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw v1

    :cond_4b8
    throw v0
    :try_end_4b9
    .catchall {:try_start_488 .. :try_end_4b9} :catchall_49f

    :goto_4b9
    :try_start_4b9
    throw v1
    :try_end_4ba
    .catchall {:try_start_4b9 .. :try_end_4ba} :catchall_4ba

    :catchall_4ba
    move-exception v0

    invoke-static {v6, v1}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0

    nop

    :pswitch_data_4c0
    .packed-switch 0x0
        :pswitch_12a  #00000000
        :pswitch_115  #00000001
        :pswitch_fc  #00000002
        :pswitch_ed  #00000003
        :pswitch_c9  #00000004
        :pswitch_b1  #00000005
        :pswitch_9a  #00000006
        :pswitch_86  #00000007
        :pswitch_77  #00000008
        :pswitch_54  #00000009
        :pswitch_3c  #0000000a
    .end packed-switch
.end method
