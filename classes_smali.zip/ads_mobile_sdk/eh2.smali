.class public final Lads_mobile_sdk/eh2;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public a:Lnb1;

.field public b:Lads_mobile_sdk/fh2;

.field public c:J

.field public d:I

.field public synthetic e:Ljava/lang/Object;

.field public final synthetic f:Lads_mobile_sdk/fh2;

.field public final synthetic g:J


# direct methods
.method public constructor <init>(JLads_mobile_sdk/fh2;Lvx;)V
    .registers 5

    iput-object p3, p0, Lads_mobile_sdk/eh2;->f:Lads_mobile_sdk/fh2;

    iput-wide p1, p0, Lads_mobile_sdk/eh2;->g:J

    const/4 p1, 0x2

    invoke-direct {p0, p1, p4}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 7

    new-instance v0, Lads_mobile_sdk/eh2;

    iget-object v1, p0, Lads_mobile_sdk/eh2;->f:Lads_mobile_sdk/fh2;

    iget-wide v2, p0, Lads_mobile_sdk/eh2;->g:J

    invoke-direct {v0, v2, v3, v1, p1}, Lads_mobile_sdk/eh2;-><init>(JLads_mobile_sdk/fh2;Lvx;)V

    iput-object p2, v0, Lads_mobile_sdk/eh2;->e:Ljava/lang/Object;

    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    invoke-virtual {p0, p2, p1}, Lads_mobile_sdk/eh2;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/eh2;

    sget-object p1, Lrg2;->a:Lrg2;

    invoke-virtual {p0, p1}, Lads_mobile_sdk/eh2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 11

    .prologue
    iget v0, p0, Lads_mobile_sdk/eh2;->d:I

    sget-object v1, Lrg2;->a:Lrg2;

    iget-object v2, p0, Lads_mobile_sdk/eh2;->f:Lads_mobile_sdk/fh2;

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    sget-object v6, Lwy;->a:Lwy;

    if-eqz v0, :cond_2e

    if-eq v0, v4, :cond_25

    if-ne v0, v3, :cond_1f

    iget-wide v6, p0, Lads_mobile_sdk/eh2;->c:J

    iget-object v2, p0, Lads_mobile_sdk/eh2;->b:Lads_mobile_sdk/fh2;

    iget-object v0, p0, Lads_mobile_sdk/eh2;->a:Lnb1;

    iget-object p0, p0, Lads_mobile_sdk/eh2;->e:Ljava/lang/Object;

    check-cast p0, Lvy;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_5d

    :cond_1f
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v5

    :cond_25
    iget-object v0, p0, Lads_mobile_sdk/eh2;->e:Ljava/lang/Object;

    check-cast v0, Lvy;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    move-object p1, v0

    goto :goto_46

    :cond_2e
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/eh2;->e:Ljava/lang/Object;

    check-cast p1, Lvy;

    iget-object v0, v2, Lads_mobile_sdk/fh2;->a:Lads_mobile_sdk/xj2;

    iput-object p1, p0, Lads_mobile_sdk/eh2;->e:Ljava/lang/Object;

    iput v4, p0, Lads_mobile_sdk/eh2;->d:I

    invoke-virtual {v0, p0}, Lads_mobile_sdk/xj2;->r(Lwx;)Ljava/lang/Object;

    move-result-object v0

    if-ne v0, v6, :cond_42

    goto :goto_43

    :cond_42
    move-object v0, v1

    :goto_43
    if-ne v0, v6, :cond_46

    goto :goto_5a

    :cond_46
    :goto_46
    iget-object v0, v2, Lads_mobile_sdk/fh2;->f:Lnb1;

    iput-object p1, p0, Lads_mobile_sdk/eh2;->e:Ljava/lang/Object;

    iput-object v0, p0, Lads_mobile_sdk/eh2;->a:Lnb1;

    iput-object v2, p0, Lads_mobile_sdk/eh2;->b:Lads_mobile_sdk/fh2;

    iget-wide v7, p0, Lads_mobile_sdk/eh2;->g:J

    iput-wide v7, p0, Lads_mobile_sdk/eh2;->c:J

    iput v3, p0, Lads_mobile_sdk/eh2;->d:I

    invoke-virtual {v0, p0}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v6, :cond_5b

    :goto_5a
    return-object v6

    :cond_5b
    move-object p0, p1

    move-wide v6, v7

    :goto_5d
    :try_start_5d
    iget-object p1, v2, Lads_mobile_sdk/fh2;->e:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result p1

    if-nez p1, :cond_84

    iget-object p1, v2, Lads_mobile_sdk/fh2;->g:Lx52;

    if-eqz p1, :cond_6f

    invoke-virtual {p1, v5}, Lnv0;->a(Ljava/util/concurrent/CancellationException;)V

    goto :goto_6f

    :catchall_6d
    move-exception p0

    goto :goto_88

    :cond_6f
    :goto_6f
    new-instance p1, Lads_mobile_sdk/dh2;

    invoke-direct {p1, v6, v7, v2, v5}, Lads_mobile_sdk/dh2;-><init>(JLads_mobile_sdk/fh2;Lvx;)V

    sget-object v4, Ly90;->a:Ly90;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v6, La42;

    invoke-direct {v6, p1, v5}, La42;-><init>(Lpk0;Lvx;)V

    invoke-static {p0, v4, v5, v6, v3}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    move-result-object p0

    iput-object p0, v2, Lads_mobile_sdk/fh2;->g:Lx52;
    :try_end_84
    .catchall {:try_start_5d .. :try_end_84} :catchall_6d

    :cond_84
    invoke-virtual {v0, v5}, Lnb1;->b(Ljava/lang/Object;)V

    return-object v1

    :goto_88
    invoke-virtual {v0, v5}, Lnb1;->b(Ljava/lang/Object;)V

    throw p0
.end method
