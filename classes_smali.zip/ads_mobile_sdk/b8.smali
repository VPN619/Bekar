.class public final Lads_mobile_sdk/b8;
.super Lads_mobile_sdk/ku0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field private static final DEFAULT_INSTANCE:Lads_mobile_sdk/b8;

.field public static final c:I = 0x1

.field public static final d:I = 0x2


# instance fields
.field private bitField0_:I

.field private clientPingMetadata_:Lads_mobile_sdk/o7;

.field private payloads_:Lw63;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lw63;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lads_mobile_sdk/b8;

    invoke-direct {v0}, Lads_mobile_sdk/b8;-><init>()V

    sput-object v0, Lads_mobile_sdk/b8;->DEFAULT_INSTANCE:Lads_mobile_sdk/b8;

    const-class v1, Lads_mobile_sdk/b8;

    invoke-static {v1, v0}, Lads_mobile_sdk/ku0;->a(Ljava/lang/Class;Lads_mobile_sdk/ku0;)V

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Lads_mobile_sdk/ku0;-><init>()V

    sget-object v0, Lads_mobile_sdk/am2;->e:Lads_mobile_sdk/am2;

    iput-object v0, p0, Lads_mobile_sdk/b8;->payloads_:Lw63;

    return-void
.end method

.method public static o()Ldt2;
    .registers 1

    sget-object v0, Lads_mobile_sdk/b8;->DEFAULT_INSTANCE:Lads_mobile_sdk/b8;

    invoke-virtual {v0}, Lads_mobile_sdk/ku0;->e()Lads_mobile_sdk/iu0;

    move-result-object v0

    check-cast v0, Ldt2;

    return-object v0
.end method


# virtual methods
.method public final a(ILads_mobile_sdk/ku0;)Ljava/lang/Object;
    .registers 4

    .prologue
    invoke-static {p1}, Lvr0;->a(I)I

    move-result p0

    if-eqz p0, :cond_45

    const/4 p1, 0x2

    if-eq p0, p1, :cond_2f

    const/4 p1, 0x3

    if-eq p0, p1, :cond_29

    const/4 p1, 0x4

    if-eq p0, p1, :cond_21

    const/4 p1, 0x5

    if-eq p0, p1, :cond_1e

    const/4 p1, 0x6

    if-ne p0, p1, :cond_1c

    const-class p0, Lads_mobile_sdk/b8;

    invoke-static {p0}, Lads_mobile_sdk/ku0;->b(Ljava/lang/Class;)Lads_mobile_sdk/ju0;

    move-result-object p0

    return-object p0

    :cond_1c
    const/4 p0, 0x0

    throw p0

    :cond_1e
    sget-object p0, Lads_mobile_sdk/b8;->DEFAULT_INSTANCE:Lads_mobile_sdk/b8;

    return-object p0

    :cond_21
    new-instance p0, Ldt2;

    sget-object p1, Lads_mobile_sdk/b8;->DEFAULT_INSTANCE:Lads_mobile_sdk/b8;

    invoke-direct {p0, p1}, Lads_mobile_sdk/iu0;-><init>(Lads_mobile_sdk/ku0;)V

    return-object p0

    :cond_29
    new-instance p0, Lads_mobile_sdk/b8;

    invoke-direct {p0}, Lads_mobile_sdk/b8;-><init>()V

    return-object p0

    :cond_2f
    const-class p0, Lads_mobile_sdk/z7;

    const-string p1, "clientPingMetadata_"

    const-string p2, "bitField0_"

    const-string v0, "payloads_"

    filled-new-array {p2, v0, p0, p1}, [Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lads_mobile_sdk/b8;->DEFAULT_INSTANCE:Lads_mobile_sdk/b8;

    new-instance p2, Lads_mobile_sdk/zq2;

    const-string v0, "\u0004\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0001\u0000\u0001\u001b\u0002ဉ\u0000"

    invoke-direct {p2, p1, v0, p0}, Lads_mobile_sdk/zq2;-><init>(Lads_mobile_sdk/ku0;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object p2

    :cond_45
    const/4 p0, 0x1

    invoke-static {p0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p0

    return-object p0
.end method

.method public final a(Lads_mobile_sdk/o7;)V
    .registers 2

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iput-object p1, p0, Lads_mobile_sdk/b8;->clientPingMetadata_:Lads_mobile_sdk/o7;

    iget p1, p0, Lads_mobile_sdk/b8;->bitField0_:I

    or-int/lit8 p1, p1, 0x1

    iput p1, p0, Lads_mobile_sdk/b8;->bitField0_:I

    return-void
.end method

.method public final a(Lads_mobile_sdk/z7;)V
    .registers 4

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/b8;->payloads_:Lw63;

    move-object v1, v0

    check-cast v1, Lads_mobile_sdk/j;

    iget-boolean v1, v1, Lads_mobile_sdk/j;->a:Z

    if-nez v1, :cond_f

    invoke-static {v0}, Li10;->I(Lw63;)Lw63;

    move-result-object v0

    iput-object v0, p0, Lads_mobile_sdk/b8;->payloads_:Lw63;

    :cond_f
    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    return-void
.end method
