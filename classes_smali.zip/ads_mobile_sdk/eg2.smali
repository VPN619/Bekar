.class public final Lads_mobile_sdk/eg2;
.super Lwx;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public synthetic a:Ljava/lang/Object;

.field public final synthetic b:Lads_mobile_sdk/fg2;

.field public c:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/fg2;Lwx;)V
    .registers 3

    iput-object p1, p0, Lads_mobile_sdk/eg2;->b:Lads_mobile_sdk/fg2;

    invoke-direct {p0, p2}, Lwx;-><init>(Lvx;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    iput-object p1, p0, Lads_mobile_sdk/eg2;->a:Ljava/lang/Object;

    iget p1, p0, Lads_mobile_sdk/eg2;->c:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, Lads_mobile_sdk/eg2;->c:I

    iget-object p1, p0, Lads_mobile_sdk/eg2;->b:Lads_mobile_sdk/fg2;

    const/4 v0, 0x0

    invoke-virtual {p1, v0, p0}, Lads_mobile_sdk/fg2;->a(Lc03;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
