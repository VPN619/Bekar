.class public final Lads_mobile_sdk/a42;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:I

.field public final b:I

.field public final c:Z


# direct methods
.method public constructor <init>(IIZ)V
    .registers 5

    .prologue
    const/4 v0, 0x0

    if-eqz p1, :cond_10

    if-eqz p2, :cond_f

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lads_mobile_sdk/a42;->a:I

    iput p2, p0, Lads_mobile_sdk/a42;->b:I

    iput-boolean p3, p0, Lads_mobile_sdk/a42;->c:Z

    return-void

    :cond_f
    throw v0

    :cond_10
    throw v0
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    .prologue
    if-ne p0, p1, :cond_3

    goto :goto_20

    :cond_3
    instance-of v0, p1, Lads_mobile_sdk/a42;

    if-nez v0, :cond_8

    goto :goto_1e

    :cond_8
    check-cast p1, Lads_mobile_sdk/a42;

    iget v0, p0, Lads_mobile_sdk/a42;->a:I

    iget v1, p1, Lads_mobile_sdk/a42;->a:I

    if-eq v0, v1, :cond_11

    goto :goto_1e

    :cond_11
    iget v0, p0, Lads_mobile_sdk/a42;->b:I

    iget v1, p1, Lads_mobile_sdk/a42;->b:I

    if-eq v0, v1, :cond_18

    goto :goto_1e

    :cond_18
    iget-boolean p0, p0, Lads_mobile_sdk/a42;->c:Z

    iget-boolean p1, p1, Lads_mobile_sdk/a42;->c:Z

    if-eq p0, p1, :cond_20

    :goto_1e
    const/4 p0, 0x0

    return p0

    :cond_20
    :goto_20
    const/4 p0, 0x1

    return p0
.end method

.method public final hashCode()I
    .registers 3

    .prologue
    iget v0, p0, Lads_mobile_sdk/a42;->a:I

    invoke-static {v0}, Lc33;->x(I)I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, Lads_mobile_sdk/a42;->b:I

    invoke-static {v1}, Lc33;->x(I)I

    move-result v1

    add-int/2addr v1, v0

    mul-int/lit8 v1, v1, 0x1f

    iget-boolean p0, p0, Lads_mobile_sdk/a42;->c:Z

    if-eqz p0, :cond_16

    const/4 p0, 0x1

    :cond_16
    add-int/2addr v1, p0

    return v1
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "OfflineAdConfig(impressionPrerequisite="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v1, p0, Lads_mobile_sdk/a42;->a:I

    invoke-static {v1}, Lmz2;->p(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", clickPrerequisite="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lads_mobile_sdk/a42;->b:I

    invoke-static {v1}, Lmz2;->p(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", notificationFlowEnabled="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean p0, p0, Lads_mobile_sdk/a42;->c:Z

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
