.class public final Lads_mobile_sdk/cg;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lnt2;


# instance fields
.field public final a:Lads_mobile_sdk/ah0;

.field public final b:Ltv2;

.field public final c:Ltv2;

.field public final d:Ltv2;

.field public final e:Ltv2;

.field public final f:Ltv2;

.field public final g:Ltv2;

.field public final h:Ltv2;

.field public final synthetic i:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/ah0;Ltv2;Ltv2;Ltv2;Ltv2;Ltv2;Ltv2;Ltv2;)V
    .registers 10

    const/4 v0, 0x0

    iput v0, p0, Lads_mobile_sdk/cg;->i:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/cg;->a:Lads_mobile_sdk/ah0;

    iput-object p2, p0, Lads_mobile_sdk/cg;->b:Ltv2;

    iput-object p3, p0, Lads_mobile_sdk/cg;->c:Ltv2;

    iput-object p4, p0, Lads_mobile_sdk/cg;->d:Ltv2;

    iput-object p5, p0, Lads_mobile_sdk/cg;->e:Ltv2;

    iput-object p6, p0, Lads_mobile_sdk/cg;->f:Ltv2;

    iput-object p7, p0, Lads_mobile_sdk/cg;->g:Ltv2;

    iput-object p8, p0, Lads_mobile_sdk/cg;->h:Ltv2;

    return-void
.end method

.method public constructor <init>(Ltv2;Ltv2;Ltv2;Lads_mobile_sdk/ah0;Ltv2;Ltv2;Ltv2;Ltv2;)V
    .registers 10

    const/4 v0, 0x1

    iput v0, p0, Lads_mobile_sdk/cg;->i:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/cg;->b:Ltv2;

    iput-object p2, p0, Lads_mobile_sdk/cg;->c:Ltv2;

    iput-object p3, p0, Lads_mobile_sdk/cg;->d:Ltv2;

    iput-object p4, p0, Lads_mobile_sdk/cg;->a:Lads_mobile_sdk/ah0;

    iput-object p5, p0, Lads_mobile_sdk/cg;->e:Ltv2;

    iput-object p6, p0, Lads_mobile_sdk/cg;->f:Ltv2;

    iput-object p7, p0, Lads_mobile_sdk/cg;->g:Ltv2;

    iput-object p8, p0, Lads_mobile_sdk/cg;->h:Ltv2;

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 19

    .prologue
    move-object/from16 v0, p0

    iget v1, v0, Lads_mobile_sdk/cg;->i:I

    iget-object v2, v0, Lads_mobile_sdk/cg;->h:Ltv2;

    iget-object v3, v0, Lads_mobile_sdk/cg;->g:Ltv2;

    iget-object v4, v0, Lads_mobile_sdk/cg;->f:Ltv2;

    iget-object v5, v0, Lads_mobile_sdk/cg;->e:Ltv2;

    iget-object v6, v0, Lads_mobile_sdk/cg;->a:Lads_mobile_sdk/ah0;

    iget-object v7, v0, Lads_mobile_sdk/cg;->d:Ltv2;

    iget-object v8, v0, Lads_mobile_sdk/cg;->c:Ltv2;

    iget-object v0, v0, Lads_mobile_sdk/cg;->b:Ltv2;

    packed-switch v1, :pswitch_data_98

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v10, v0

    check-cast v10, Lads_mobile_sdk/ki0;

    invoke-interface {v8}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v11, v0

    check-cast v11, Lads_mobile_sdk/bq1;

    invoke-interface {v7}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v12, v0

    check-cast v12, Lvy;

    invoke-virtual {v6}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v13, v0

    check-cast v13, Lvy;

    invoke-interface {v5}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v14, v0

    check-cast v14, Lq63;

    invoke-interface {v4}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v15, v0

    check-cast v15, Lads_mobile_sdk/g0;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v16, v0

    check-cast v16, Lads_mobile_sdk/ux2;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v17, v0

    check-cast v17, Lads_mobile_sdk/kh3;

    new-instance v9, Lads_mobile_sdk/cs1;

    invoke-direct/range {v9 .. v17}, Lads_mobile_sdk/cs1;-><init>(Lads_mobile_sdk/ki0;Lads_mobile_sdk/bq1;Lvy;Lvy;Lq63;Lads_mobile_sdk/g0;Lads_mobile_sdk/ux2;Lads_mobile_sdk/kh3;)V

    return-object v9

    :pswitch_57  #0x0
    invoke-virtual {v6}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object v1

    move-object v10, v1

    check-cast v10, Lvy;

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v11, v0

    check-cast v11, Lvy;

    invoke-interface {v8}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v12, v0

    check-cast v12, Lads_mobile_sdk/qr0;

    invoke-interface {v7}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v13, v0

    check-cast v13, Lx43;

    invoke-interface {v5}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v14, v0

    check-cast v14, Lq63;

    invoke-interface {v4}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v15, v0

    check-cast v15, Lads_mobile_sdk/we;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v16, v0

    check-cast v16, Lads_mobile_sdk/ef;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v17, v0

    check-cast v17, Lads_mobile_sdk/ux2;

    new-instance v9, Lads_mobile_sdk/bg;

    invoke-direct/range {v9 .. v17}, Lads_mobile_sdk/bg;-><init>(Lvy;Lvy;Lads_mobile_sdk/qr0;Lx43;Lq63;Lads_mobile_sdk/we;Lads_mobile_sdk/ef;Lads_mobile_sdk/ux2;)V

    return-object v9

    nop

    :pswitch_data_98
    .packed-switch 0x0
        :pswitch_57  #00000000
    .end packed-switch
.end method
