.class public final Lads_mobile_sdk/d52;
.super Lzz0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lzj0;


# instance fields
.field public final synthetic a:Lads_mobile_sdk/s52;

.field public final synthetic b:Lads_mobile_sdk/cy0;

.field public final synthetic c:Ljava/lang/String;

.field public final synthetic d:Lads_mobile_sdk/t00;

.field public final synthetic e:Lads_mobile_sdk/z31;

.field public final synthetic f:Lads_mobile_sdk/z92;

.field public final synthetic g:Lads_mobile_sdk/z92;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/s52;Lads_mobile_sdk/cy0;Ljava/lang/String;Lads_mobile_sdk/t00;Lads_mobile_sdk/z31;Lads_mobile_sdk/z92;Lads_mobile_sdk/z92;)V
    .registers 8

    iput-object p1, p0, Lads_mobile_sdk/d52;->a:Lads_mobile_sdk/s52;

    iput-object p2, p0, Lads_mobile_sdk/d52;->b:Lads_mobile_sdk/cy0;

    iput-object p3, p0, Lads_mobile_sdk/d52;->c:Ljava/lang/String;

    iput-object p4, p0, Lads_mobile_sdk/d52;->d:Lads_mobile_sdk/t00;

    iput-object p5, p0, Lads_mobile_sdk/d52;->e:Lads_mobile_sdk/z31;

    iput-object p6, p0, Lads_mobile_sdk/d52;->f:Lads_mobile_sdk/z92;

    iput-object p7, p0, Lads_mobile_sdk/d52;->g:Lads_mobile_sdk/z92;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lzz0;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 6

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/d52;->a:Lads_mobile_sdk/s52;

    iget-object v0, v0, Lads_mobile_sdk/s52;->j:Lads_mobile_sdk/ji;

    iget-object v1, p0, Lads_mobile_sdk/d52;->c:Ljava/lang/String;

    const-string v2, ""

    iget-object v3, p0, Lads_mobile_sdk/d52;->b:Lads_mobile_sdk/cy0;

    invoke-static {v0, v3, v1, v2}, Lads_mobile_sdk/o6;->a(Lads_mobile_sdk/ji;Landroid/webkit/WebView;Ljava/lang/String;Ljava/lang/String;)Lads_mobile_sdk/o6;

    move-result-object v0

    iget-object v1, p0, Lads_mobile_sdk/d52;->g:Lads_mobile_sdk/z92;

    const/4 v2, 0x1

    iget-object v3, p0, Lads_mobile_sdk/d52;->d:Lads_mobile_sdk/t00;

    iget-object v4, p0, Lads_mobile_sdk/d52;->e:Lads_mobile_sdk/z31;

    iget-object p0, p0, Lads_mobile_sdk/d52;->f:Lads_mobile_sdk/z92;

    invoke-static {v3, v4, p0, v1, v2}, Lgm;->a(Lads_mobile_sdk/t00;Lads_mobile_sdk/z31;Lads_mobile_sdk/z92;Lads_mobile_sdk/z92;Z)Lgm;

    move-result-object p0

    sget-object v1, Lgt0;->o:Llv;

    iget-boolean v1, v1, Llv;->a:Z

    if-eqz v1, :cond_2f

    new-instance v1, Lads_mobile_sdk/q6;

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v1, p0, v0, v2}, Lads_mobile_sdk/q6;-><init>(Lgm;Lads_mobile_sdk/o6;Ljava/lang/String;)V

    return-object v1

    :cond_2f
    const-string p0, "Method called before OM SDK activation"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0
.end method
