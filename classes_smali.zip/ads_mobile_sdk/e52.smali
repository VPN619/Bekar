.class public final Lads_mobile_sdk/e52;
.super Lzz0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lzj0;


# instance fields
.field public final synthetic a:Lads_mobile_sdk/s52;

.field public final synthetic b:Landroid/webkit/WebView;

.field public final synthetic c:Z


# direct methods
.method public constructor <init>(Lads_mobile_sdk/s52;Landroid/webkit/WebView;Z)V
    .registers 4

    iput-object p1, p0, Lads_mobile_sdk/e52;->a:Lads_mobile_sdk/s52;

    iput-object p2, p0, Lads_mobile_sdk/e52;->b:Landroid/webkit/WebView;

    iput-boolean p3, p0, Lads_mobile_sdk/e52;->c:Z

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lzz0;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 4

    iget-object v0, p0, Lads_mobile_sdk/e52;->a:Lads_mobile_sdk/s52;

    iget-object v0, v0, Lads_mobile_sdk/s52;->j:Lads_mobile_sdk/ji;

    new-instance v1, Lads_mobile_sdk/gj1;

    iget-object v2, p0, Lads_mobile_sdk/e52;->b:Landroid/webkit/WebView;

    iget-boolean p0, p0, Lads_mobile_sdk/e52;->c:Z

    invoke-direct {v1, v0, v2, p0}, Lads_mobile_sdk/gj1;-><init>(Lads_mobile_sdk/ji;Landroid/webkit/WebView;Z)V

    return-object v1
.end method
