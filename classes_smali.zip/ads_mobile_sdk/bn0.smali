.class public final Lads_mobile_sdk/bn0;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:Lads_mobile_sdk/ah3;

.field public final c:Lads_mobile_sdk/ux2;

.field public final d:Lads_mobile_sdk/qr0;

.field public final e:Lw82;

.field public final f:Lnb1;

.field public g:Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lads_mobile_sdk/ah3;Lads_mobile_sdk/ux2;Lads_mobile_sdk/qr0;)V
    .registers 5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/bn0;->a:Landroid/content/Context;

    iput-object p2, p0, Lads_mobile_sdk/bn0;->b:Lads_mobile_sdk/ah3;

    iput-object p3, p0, Lads_mobile_sdk/bn0;->c:Lads_mobile_sdk/ux2;

    iput-object p4, p0, Lads_mobile_sdk/bn0;->d:Lads_mobile_sdk/qr0;

    new-instance p1, Lxm0;

    const/16 p2, 0xb

    invoke-direct {p1, p2, p0}, Lxm0;-><init>(ILjava/lang/Object;)V

    new-instance p2, Lw82;

    invoke-direct {p2, p1}, Lw82;-><init>(Lzj0;)V

    iput-object p2, p0, Lads_mobile_sdk/bn0;->e:Lw82;

    new-instance p1, Lnb1;

    invoke-direct {p1}, Lnb1;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/bn0;->f:Lnb1;

    return-void
.end method

.method public static a(Lads_mobile_sdk/bn0;Lwx;)Ljava/lang/Object;
    .registers 6

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/an0;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/an0;

    iget v1, v0, Lads_mobile_sdk/an0;->e:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/an0;->e:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/an0;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/an0;-><init>(Lads_mobile_sdk/bn0;Lwx;)V

    :goto_18
    iget-object p1, v0, Lads_mobile_sdk/an0;->c:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/an0;->e:I

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v1, :cond_32

    if-ne v1, v2, :cond_2c

    iget-object p0, v0, Lads_mobile_sdk/an0;->b:Lnb1;

    iget-object v0, v0, Lads_mobile_sdk/an0;->a:Lads_mobile_sdk/bn0;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    move-object p1, p0

    move-object p0, v0

    goto :goto_46

    :cond_2c
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v3

    :cond_32
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/bn0;->f:Lnb1;

    iput-object p0, v0, Lads_mobile_sdk/an0;->a:Lads_mobile_sdk/bn0;

    iput-object p1, v0, Lads_mobile_sdk/an0;->b:Lnb1;

    iput v2, v0, Lads_mobile_sdk/an0;->e:I

    invoke-virtual {p1, v0}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v0

    sget-object v1, Lwy;->a:Lwy;

    if-ne v0, v1, :cond_46

    return-object v1

    :cond_46
    :goto_46
    :try_start_46
    iget-object v0, p0, Lads_mobile_sdk/bn0;->g:Ljava/lang/String;

    if-eqz v0, :cond_4b

    goto :goto_5d

    :cond_4b
    const-string v0, "getGmpAppId"

    invoke-virtual {p0, v0}, Lads_mobile_sdk/bn0;->a(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_5a

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    goto :goto_5b

    :catchall_58
    move-exception p0

    goto :goto_61

    :cond_5a
    move-object v0, v3

    :goto_5b
    iput-object v0, p0, Lads_mobile_sdk/bn0;->g:Ljava/lang/String;
    :try_end_5d
    .catchall {:try_start_46 .. :try_end_5d} :catchall_58

    :goto_5d
    invoke-virtual {p1, v3}, Lnb1;->b(Ljava/lang/Object;)V

    return-object v0

    :goto_61
    invoke-virtual {p1, v3}, Lnb1;->b(Ljava/lang/Object;)V

    throw p0
.end method

.method public static a(Lads_mobile_sdk/bn0;ILandroid/os/Bundle;Ljava/lang/String;)V
    .registers 21

    .prologue
    move-object/from16 v1, p0

    move-object/from16 v0, p2

    iget-object v2, v1, Lads_mobile_sdk/bn0;->c:Lads_mobile_sdk/ux2;

    sget-object v3, Lads_mobile_sdk/fw0;->E0:Lads_mobile_sdk/fw0;

    sget-object v4, Lba0;->a:Lba0;

    invoke-static {}, Lsz;->d()Lads_mobile_sdk/kh3;

    move-result-object v5

    invoke-static {}, Lads_mobile_sdk/hh3;->b()Lads_mobile_sdk/gh3;

    move-result-object v6

    iget-object v6, v6, Lads_mobile_sdk/gh3;->a:Lads_mobile_sdk/rg3;

    const-string v7, "FirebaseAnalyticsAdapter.invokeMethod logEvent for "

    const-string v9, "Exception while calling Firebase Analytics SDK logEvent method"

    const-string v10, "am"

    const-string v11, "_r"

    const-string v12, "_ac"

    const-string v13, "_aeid"

    const-class v14, Landroid/os/Bundle;

    const-class v15, Ljava/lang/String;

    const-string v8, "logEvent"

    move-object/from16 v16, v6

    const/4 v6, 0x1

    if-nez v16, :cond_d0

    invoke-static {v2, v3, v4, v5}, Lads_mobile_sdk/ux2;->a(Lads_mobile_sdk/ux2;Lads_mobile_sdk/fw0;Ljava/util/List;Lads_mobile_sdk/kh3;)Lads_mobile_sdk/wk2;

    move-result-object v2

    :try_start_2f
    iget-object v3, v1, Lads_mobile_sdk/bn0;->e:Lw82;

    invoke-virtual {v3}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v3

    if-eqz v3, :cond_94

    iget-object v3, v1, Lads_mobile_sdk/bn0;->d:Lads_mobile_sdk/qr0;

    invoke-virtual {v3}, Lads_mobile_sdk/qr0;->N()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v3

    filled-new-array {v15, v15, v14}, [Ljava/lang/Class;

    move-result-object v4

    invoke-virtual {v3, v8, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v3

    invoke-static/range {p1 .. p1}, Lmz2;->a(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v0

    if-nez v0, :cond_5e

    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    goto :goto_5e

    :catchall_59
    move-exception v0

    goto :goto_99

    :catch_5b
    move-exception v0

    const/4 v3, 0x4

    goto :goto_84

    :cond_5e
    :goto_5e
    invoke-static/range {p3 .. p3}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v4

    invoke-virtual {v0, v13, v4, v5}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    invoke-static/range {p1 .. p1}, Lmz2;->a(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v12}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_72

    invoke-virtual {v0, v11, v6}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    :cond_72
    iget-object v4, v1, Lads_mobile_sdk/bn0;->e:Lw82;

    invoke-virtual {v4}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v4

    invoke-static/range {p1 .. p1}, Lmz2;->a(I)Ljava/lang/String;

    move-result-object v5

    filled-new-array {v10, v5, v0}, [Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v3, v4, v0}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_83
    .catch Ljava/lang/Exception; {:try_start_2f .. :try_end_83} :catch_5b
    .catchall {:try_start_2f .. :try_end_83} :catchall_59

    goto :goto_94

    :goto_84
    :try_start_84
    invoke-static {v3, v9, v0}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    iget-object v1, v1, Lads_mobile_sdk/bn0;->b:Lads_mobile_sdk/ah3;

    invoke-static/range {p1 .. p1}, Lmz2;->o(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v7, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3, v0}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_94
    .catchall {:try_start_84 .. :try_end_94} :catchall_59

    :cond_94
    :goto_94
    invoke-virtual {v2}, Lads_mobile_sdk/rg3;->close()V

    goto/16 :goto_13c

    :goto_99
    :try_start_99
    invoke-virtual {v2, v0}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v1, v0, Lox2;

    if-nez v1, :cond_c9

    invoke-virtual {v2, v0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of v1, v0, Lza2;

    if-nez v1, :cond_c1

    instance-of v1, v0, Ljava/util/concurrent/CancellationException;

    if-nez v1, :cond_b9

    instance-of v1, v0, Lads_mobile_sdk/mv0;

    if-eqz v1, :cond_b3

    throw v0

    :catchall_b0
    move-exception v0

    move-object v1, v0

    goto :goto_ca

    :cond_b3
    new-instance v1, Lads_mobile_sdk/tu0;

    invoke-direct {v1, v0}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw v1

    :cond_b9
    new-instance v1, Lads_mobile_sdk/ou0;

    check-cast v0, Ljava/util/concurrent/CancellationException;

    invoke-direct {v1, v0}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw v1

    :cond_c1
    new-instance v1, Lads_mobile_sdk/uw0;

    check-cast v0, Lza2;

    invoke-direct {v1, v0}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw v1

    :cond_c9
    throw v0
    :try_end_ca
    .catchall {:try_start_99 .. :try_end_ca} :catchall_b0

    :goto_ca
    :try_start_ca
    throw v1
    :try_end_cb
    .catchall {:try_start_ca .. :try_end_cb} :catchall_cb

    :catchall_cb
    move-exception v0

    invoke-static {v2, v1}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0

    :cond_d0
    invoke-static {v3, v4, v6}, Lads_mobile_sdk/hh3;->a(Lads_mobile_sdk/fw0;Ljava/util/List;Z)Lads_mobile_sdk/rg3;

    move-result-object v2

    :try_start_d4
    iget-object v3, v1, Lads_mobile_sdk/bn0;->e:Lw82;

    invoke-virtual {v3}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v3

    if-eqz v3, :cond_139

    iget-object v3, v1, Lads_mobile_sdk/bn0;->d:Lads_mobile_sdk/qr0;

    invoke-virtual {v3}, Lads_mobile_sdk/qr0;->N()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v3

    filled-new-array {v15, v15, v14}, [Ljava/lang/Class;

    move-result-object v4

    invoke-virtual {v3, v8, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v3

    invoke-static/range {p1 .. p1}, Lmz2;->a(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v0

    if-nez v0, :cond_103

    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    goto :goto_103

    :catchall_fe
    move-exception v0

    goto :goto_13d

    :catch_100
    move-exception v0

    const/4 v3, 0x4

    goto :goto_129

    :cond_103
    :goto_103
    invoke-static/range {p3 .. p3}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v4

    invoke-virtual {v0, v13, v4, v5}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    invoke-static/range {p1 .. p1}, Lmz2;->a(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4, v12}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_117

    invoke-virtual {v0, v11, v6}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    :cond_117
    iget-object v4, v1, Lads_mobile_sdk/bn0;->e:Lw82;

    invoke-virtual {v4}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v4

    invoke-static/range {p1 .. p1}, Lmz2;->a(I)Ljava/lang/String;

    move-result-object v5

    filled-new-array {v10, v5, v0}, [Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v3, v4, v0}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_128
    .catch Ljava/lang/Exception; {:try_start_d4 .. :try_end_128} :catch_100
    .catchall {:try_start_d4 .. :try_end_128} :catchall_fe

    goto :goto_139

    :goto_129
    :try_start_129
    invoke-static {v3, v9, v0}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    iget-object v1, v1, Lads_mobile_sdk/bn0;->b:Lads_mobile_sdk/ah3;

    invoke-static/range {p1 .. p1}, Lmz2;->o(I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v7, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3, v0}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_139
    .catchall {:try_start_129 .. :try_end_139} :catchall_fe

    :cond_139
    :goto_139
    invoke-virtual {v2}, Lads_mobile_sdk/rg3;->close()V

    :goto_13c
    return-void

    :goto_13d
    :try_start_13d
    invoke-virtual {v2, v0}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v1, v0, Lox2;

    if-nez v1, :cond_16d

    invoke-virtual {v2, v0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of v1, v0, Lza2;

    if-nez v1, :cond_165

    instance-of v1, v0, Ljava/util/concurrent/CancellationException;

    if-nez v1, :cond_15d

    instance-of v1, v0, Lads_mobile_sdk/mv0;

    if-eqz v1, :cond_157

    throw v0

    :catchall_154
    move-exception v0

    move-object v1, v0

    goto :goto_16e

    :cond_157
    new-instance v1, Lads_mobile_sdk/tu0;

    invoke-direct {v1, v0}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw v1

    :cond_15d
    new-instance v1, Lads_mobile_sdk/ou0;

    check-cast v0, Ljava/util/concurrent/CancellationException;

    invoke-direct {v1, v0}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw v1

    :cond_165
    new-instance v1, Lads_mobile_sdk/uw0;

    check-cast v0, Lza2;

    invoke-direct {v1, v0}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw v1

    :cond_16d
    throw v0
    :try_end_16e
    .catchall {:try_start_13d .. :try_end_16e} :catchall_154

    :goto_16e
    :try_start_16e
    throw v1
    :try_end_16f
    .catchall {:try_start_16e .. :try_end_16f} :catchall_16f

    :catchall_16f
    move-exception v0

    invoke-static {v2, v1}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0
.end method


# virtual methods
.method public final a(Ljava/lang/String;)Ljava/lang/Object;
    .registers 6

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/bn0;->e:Lw82;

    const/4 v1, 0x0

    :try_start_3
    invoke-virtual {v0}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v2

    if-eqz v2, :cond_22

    iget-object v2, p0, Lads_mobile_sdk/bn0;->d:Lads_mobile_sdk/qr0;

    invoke-virtual {v2}, Lads_mobile_sdk/qr0;->N()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2, p1, v1}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    invoke-virtual {v0}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v2, v0, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0
    :try_end_1f
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_1f} :catch_20

    return-object p0

    :catch_20
    move-exception v0

    goto :goto_23

    :cond_22
    return-object v1

    :goto_23
    const-string v2, "Exception while calling Firebase Analytics SDK method"

    const/4 v3, 0x4

    invoke-static {v3, v2, v0}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    const-string v2, "FirebaseAnalyticsAdapter.invokeMethod "

    invoke-virtual {v2, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iget-object p0, p0, Lads_mobile_sdk/bn0;->b:Lads_mobile_sdk/ah3;

    invoke-virtual {p0, p1, v0}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-object v1
.end method
