.class public final Lads_mobile_sdk/ey2;
.super Lzz0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lbk0;


# instance fields
.field public final synthetic a:Lads_mobile_sdk/ly2;

.field public final synthetic i:I


# direct methods
.method public synthetic constructor <init>(Lads_mobile_sdk/ly2;I)V
    .registers 3

    iput p2, p0, Lads_mobile_sdk/ey2;->i:I

    iput-object p1, p0, Lads_mobile_sdk/ey2;->a:Lads_mobile_sdk/ly2;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lzz0;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .prologue
    iget v0, p0, Lads_mobile_sdk/ey2;->i:I

    sget-object v1, Lrg2;->a:Lrg2;

    iget-object p0, p0, Lads_mobile_sdk/ey2;->a:Lads_mobile_sdk/ly2;

    packed-switch v0, :pswitch_data_4c

    check-cast p1, Lcom/google/android/gms/ads/mediation/MediationRewardedAd;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Lads_mobile_sdk/ly2;->f:Lcom/google/android/gms/ads/mediation/MediationRewardedAd;

    return-object v1

    :pswitch_11  #0x5
    check-cast p1, Lcom/google/android/gms/ads/mediation/MediationRewardedAd;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Lads_mobile_sdk/ly2;->f:Lcom/google/android/gms/ads/mediation/MediationRewardedAd;

    return-object v1

    :pswitch_19  #0x4
    check-cast p1, Lcom/google/android/gms/ads/mediation/UnifiedNativeAdMapper;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lads_mobile_sdk/vk3;

    invoke-direct {v0, p1}, Lads_mobile_sdk/vk3;-><init>(Lcom/google/android/gms/ads/mediation/UnifiedNativeAdMapper;)V

    iput-object v0, p0, Lads_mobile_sdk/ly2;->d:Ley2;

    return-object v1

    :pswitch_26  #0x3
    check-cast p1, Lcom/google/android/gms/ads/mediation/NativeAdMapper;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lads_mobile_sdk/ju1;

    invoke-direct {v0, p1}, Lads_mobile_sdk/ju1;-><init>(Lcom/google/android/gms/ads/mediation/NativeAdMapper;)V

    iput-object v0, p0, Lads_mobile_sdk/ly2;->d:Ley2;

    return-object v1

    :pswitch_33  #0x2
    check-cast p1, Lcom/google/android/gms/ads/mediation/MediationInterstitialAd;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Lads_mobile_sdk/ly2;->e:Lcom/google/android/gms/ads/mediation/MediationInterstitialAd;

    return-object v1

    :pswitch_3b  #0x1
    check-cast p1, Landroid/view/View;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Lads_mobile_sdk/ly2;->c:Landroid/view/View;

    return-object v1

    :pswitch_43  #0x0
    check-cast p1, Lcom/google/android/gms/ads/mediation/MediationAppOpenAd;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Lads_mobile_sdk/ly2;->g:Lcom/google/android/gms/ads/mediation/MediationAppOpenAd;

    return-object v1

    nop

    :pswitch_data_4c
    .packed-switch 0x0
        :pswitch_43  #00000000
        :pswitch_3b  #00000001
        :pswitch_33  #00000002
        :pswitch_26  #00000003
        :pswitch_19  #00000004
        :pswitch_11  #00000005
    .end packed-switch
.end method
