.class public final Lads_mobile_sdk/bo1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lcom/google/android/gms/ads/mediation/MediationAdRequest;


# instance fields
.field public final a:Ljava/util/HashSet;

.field public final b:Z

.field public final c:I

.field public final d:I

.field public final e:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/util/HashSet;ZIILjava/lang/String;)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/bo1;->a:Ljava/util/HashSet;

    iput-boolean p2, p0, Lads_mobile_sdk/bo1;->b:Z

    iput p3, p0, Lads_mobile_sdk/bo1;->c:I

    iput p4, p0, Lads_mobile_sdk/bo1;->d:I

    iput-object p5, p0, Lads_mobile_sdk/bo1;->e:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final getBirthday()Ljava/util/Date;
    .registers 1

    const/4 p0, 0x0

    return-object p0
.end method

.method public final getGender()I
    .registers 1

    const/4 p0, 0x0

    return p0
.end method

.method public final getKeywords()Ljava/util/Set;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/bo1;->a:Ljava/util/HashSet;

    return-object p0
.end method

.method public final getLocation()Landroid/location/Location;
    .registers 1

    const/4 p0, 0x0

    return-object p0
.end method

.method public final getMaxAdContentRating()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/bo1;->e:Ljava/lang/String;

    return-object p0
.end method

.method public final isDesignedForFamilies()Z
    .registers 1

    const/4 p0, 0x0

    return p0
.end method

.method public final isTesting()Z
    .registers 1

    iget-boolean p0, p0, Lads_mobile_sdk/bo1;->b:Z

    return p0
.end method

.method public final taggedForChildDirectedTreatment()I
    .registers 1

    iget p0, p0, Lads_mobile_sdk/bo1;->c:I

    return p0
.end method

.method public final taggedForUnderAgeTreatment()I
    .registers 1

    iget p0, p0, Lads_mobile_sdk/bo1;->d:I

    return p0
.end method
