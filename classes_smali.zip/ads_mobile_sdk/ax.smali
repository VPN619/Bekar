.class public final Lads_mobile_sdk/ax;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lbk0;


# instance fields
.field public a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;

.field public final synthetic t:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/vs2;Lvx;Lbk0;)V
    .registers 5

    const/4 v0, 0x2

    iput v0, p0, Lads_mobile_sdk/ax;->t:I

    iput-object p3, p0, Lads_mobile_sdk/ax;->b:Ljava/lang/Object;

    iput-object p1, p0, Lads_mobile_sdk/ax;->c:Ljava/lang/Object;

    const/4 p1, 0x1

    invoke-direct {p0, p1, p2}, Lm82;-><init>(ILvx;)V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Lvx;I)V
    .registers 5

    iput p4, p0, Lads_mobile_sdk/ax;->t:I

    iput-object p1, p0, Lads_mobile_sdk/ax;->b:Ljava/lang/Object;

    iput-object p2, p0, Lads_mobile_sdk/ax;->c:Ljava/lang/Object;

    const/4 p1, 0x1

    invoke-direct {p0, p1, p3}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .prologue
    iget v0, p0, Lads_mobile_sdk/ax;->t:I

    sget-object v1, Lrg2;->a:Lrg2;

    iget-object v2, p0, Lads_mobile_sdk/ax;->c:Ljava/lang/Object;

    iget-object p0, p0, Lads_mobile_sdk/ax;->b:Ljava/lang/Object;

    packed-switch v0, :pswitch_data_4e

    check-cast p1, Lvx;

    new-instance v0, Lads_mobile_sdk/ax;

    check-cast p0, Lads_mobile_sdk/lx;

    check-cast v2, Lfx0;

    const/4 v3, 0x3

    invoke-direct {v0, p0, v2, p1, v3}, Lads_mobile_sdk/ax;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lvx;I)V

    invoke-virtual {v0, v1}, Lads_mobile_sdk/ax;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_1c  #0x2
    check-cast p1, Lvx;

    new-instance v0, Lads_mobile_sdk/ax;

    check-cast p0, Lbk0;

    check-cast v2, Lads_mobile_sdk/vs2;

    invoke-direct {v0, v2, p1, p0}, Lads_mobile_sdk/ax;-><init>(Lads_mobile_sdk/vs2;Lvx;Lbk0;)V

    invoke-virtual {v0, v1}, Lads_mobile_sdk/ax;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_2c  #0x1
    check-cast p1, Lvx;

    new-instance v0, Lads_mobile_sdk/ax;

    check-cast p0, Lads_mobile_sdk/sb;

    check-cast v2, Ljava/util/Set;

    const/4 v3, 0x1

    invoke-direct {v0, p0, v2, p1, v3}, Lads_mobile_sdk/ax;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lvx;I)V

    invoke-virtual {v0, v1}, Lads_mobile_sdk/ax;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_3d  #0x0
    check-cast p1, Lvx;

    new-instance v0, Lads_mobile_sdk/ax;

    check-cast p0, Lads_mobile_sdk/lx;

    check-cast v2, Lku;

    const/4 v3, 0x0

    invoke-direct {v0, p0, v2, p1, v3}, Lads_mobile_sdk/ax;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lvx;I)V

    invoke-virtual {v0, v1}, Lads_mobile_sdk/ax;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_data_4e
    .packed-switch 0x0
        :pswitch_3d  #00000000
        :pswitch_2c  #00000001
        :pswitch_1c  #00000002
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 12

    .prologue
    iget v0, p0, Lads_mobile_sdk/ax;->t:I

    sget-object v1, Lrg2;->a:Lrg2;

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v4, p0, Lads_mobile_sdk/ax;->c:Ljava/lang/Object;

    iget-object v5, p0, Lads_mobile_sdk/ax;->b:Ljava/lang/Object;

    const-string v6, "call to \'resume\' before \'invoke\' with coroutine"

    sget-object v7, Lwy;->a:Lwy;

    const/4 v8, 0x1

    const/4 v9, 0x0

    packed-switch v0, :pswitch_data_108

    iget v0, p0, Lads_mobile_sdk/ax;->a:I

    if-eqz v0, :cond_22

    if-ne v0, v8, :cond_1d

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_3d

    :cond_1d
    invoke-static {v6}, Lz6;->w(Ljava/lang/String;)V

    :goto_20
    move-object v7, v9

    goto :goto_59

    :cond_22
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    check-cast v5, Lads_mobile_sdk/lx;

    iget-object p1, v5, Lads_mobile_sdk/lx;->h:Lads_mobile_sdk/bk1;

    check-cast v4, Lfx0;

    iput v8, p0, Lads_mobile_sdk/ax;->a:I

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v0, "google.afma.config.fetchAppSettings"

    invoke-virtual {v4}, Lkw0;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p1, v0, v1, p0}, Lads_mobile_sdk/al0;->a(Ljava/lang/String;Ljava/lang/String;Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v7, :cond_3d

    goto :goto_59

    :cond_3d
    :goto_3d
    check-cast p1, Lb13;

    instance-of p0, p1, Lads_mobile_sdk/hv0;

    if-eqz p0, :cond_4b

    check-cast p1, Lads_mobile_sdk/hv0;

    iget-object p0, p1, Lads_mobile_sdk/hv0;->b:Ljava/lang/Object;

    move-object v7, p0

    check-cast v7, Lfx0;

    goto :goto_59

    :cond_4b
    instance-of p0, p1, Lads_mobile_sdk/av0;

    if-eqz p0, :cond_55

    check-cast p1, Lads_mobile_sdk/av0;

    invoke-static {p1, v3}, Lads_mobile_sdk/xh3;->a(Lads_mobile_sdk/av0;Z)V

    goto :goto_20

    :cond_55
    invoke-static {}, Ldm2;->q()V

    goto :goto_20

    :goto_59
    return-object v7

    :pswitch_5a  #0x2
    check-cast v4, Lads_mobile_sdk/vs2;

    iget v0, p0, Lads_mobile_sdk/ax;->a:I

    if-eqz v0, :cond_71

    if-eq v0, v8, :cond_6d

    if-ne v0, v2, :cond_68

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_94

    :cond_68
    invoke-static {v6}, Lz6;->w(Ljava/lang/String;)V

    move-object v1, v9

    goto :goto_94

    :cond_6d
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_7f

    :cond_71
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    check-cast v5, Lbk0;

    iput v8, p0, Lads_mobile_sdk/ax;->a:I

    invoke-interface {v5, p0}, Lbk0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v7, :cond_7f

    goto :goto_93

    :cond_7f
    :goto_7f
    check-cast p1, Lv60;

    iget-wide v5, p1, Lv60;->a:J

    invoke-virtual {v4}, Lads_mobile_sdk/vs2;->b()J

    move-result-wide v8

    invoke-static {v5, v6, v8, v9}, Lv60;->h(JJ)J

    move-result-wide v5

    iput v2, p0, Lads_mobile_sdk/ax;->a:I

    invoke-static {v5, v6, v4, p0}, Lads_mobile_sdk/vs2;->a(JLads_mobile_sdk/vs2;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v7, :cond_94

    :goto_93
    move-object v1, v7

    :cond_94
    :goto_94
    return-object v1

    :pswitch_95  #0x1
    iget v0, p0, Lads_mobile_sdk/ax;->a:I

    if-eqz v0, :cond_a4

    if-ne v0, v8, :cond_9f

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_cb

    :cond_9f
    invoke-static {v6}, Lz6;->w(Ljava/lang/String;)V

    move-object v1, v9

    goto :goto_cb

    :cond_a4
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    check-cast v5, Lads_mobile_sdk/sb;

    iget-object p1, v5, Lads_mobile_sdk/sb;->a:Lvy;

    new-instance v0, Lyh;

    check-cast v4, Ljava/util/Set;

    const/16 v3, 0x10

    invoke-direct {v0, v5, v4, v9, v3}, Lyh;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lvx;I)V

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v3, La42;

    invoke-direct {v3, v0, v9}, La42;-><init>(Lpk0;Lvx;)V

    sget-object v0, Ly90;->a:Ly90;

    invoke-static {p1, v0, v9, v3, v2}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    move-result-object p1

    iput v8, p0, Lads_mobile_sdk/ax;->a:I

    invoke-virtual {p1, p0}, Lnv0;->H(Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v7, :cond_cb

    move-object v1, v7

    :cond_cb
    :goto_cb
    return-object v1

    :pswitch_cc  #0x0
    iget v0, p0, Lads_mobile_sdk/ax;->a:I

    if-eqz v0, :cond_db

    if-ne v0, v8, :cond_d6

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_eb

    :cond_d6
    invoke-static {v6}, Lz6;->w(Ljava/lang/String;)V

    :goto_d9
    move-object v7, v9

    goto :goto_107

    :cond_db
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    check-cast v5, Lads_mobile_sdk/lx;

    check-cast v4, Lku;

    iput v8, p0, Lads_mobile_sdk/ax;->a:I

    invoke-static {v5, v4, p0}, Lads_mobile_sdk/lx;->a(Lads_mobile_sdk/lx;Lku;Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v7, :cond_eb

    goto :goto_107

    :cond_eb
    :goto_eb
    check-cast p1, Lb13;

    instance-of p0, p1, Lads_mobile_sdk/hv0;

    if-eqz p0, :cond_f9

    check-cast p1, Lads_mobile_sdk/hv0;

    iget-object p0, p1, Lads_mobile_sdk/hv0;->b:Ljava/lang/Object;

    move-object v7, p0

    check-cast v7, Lfx0;

    goto :goto_107

    :cond_f9
    instance-of p0, p1, Lads_mobile_sdk/av0;

    if-eqz p0, :cond_103

    check-cast p1, Lads_mobile_sdk/av0;

    invoke-static {p1, v3}, Lads_mobile_sdk/xh3;->a(Lads_mobile_sdk/av0;Z)V

    goto :goto_d9

    :cond_103
    invoke-static {}, Ldm2;->q()V

    goto :goto_d9

    :goto_107
    return-object v7

    :pswitch_data_108
    .packed-switch 0x0
        :pswitch_cc  #00000000
        :pswitch_95  #00000001
        :pswitch_5a  #00000002
    .end packed-switch
.end method
