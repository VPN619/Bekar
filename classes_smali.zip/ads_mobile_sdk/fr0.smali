.class public final Lads_mobile_sdk/fr0;
.super Lwx;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public a:Ljava/lang/Object;

.field public b:Ljava/lang/Object;

.field public c:Ljava/lang/Object;

.field public d:Ljava/lang/Object;

.field public e:Ljava/lang/Object;

.field public f:Lads_mobile_sdk/t70;

.field public g:Lads_mobile_sdk/yz;

.field public synthetic h:Ljava/lang/Object;

.field public final synthetic i:Lads_mobile_sdk/gr0;

.field public j:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/gr0;Lwx;)V
    .registers 3

    iput-object p1, p0, Lads_mobile_sdk/fr0;->i:Lads_mobile_sdk/gr0;

    invoke-direct {p0, p2}, Lwx;-><init>(Lvx;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    iput-object p1, p0, Lads_mobile_sdk/fr0;->h:Ljava/lang/Object;

    iget p1, p0, Lads_mobile_sdk/fr0;->j:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, Lads_mobile_sdk/fr0;->j:I

    iget-object p1, p0, Lads_mobile_sdk/fr0;->i:Lads_mobile_sdk/gr0;

    const/4 v0, 0x0

    invoke-static {p1, v0, v0, p0}, Lads_mobile_sdk/gr0;->a(Lads_mobile_sdk/gr0;Lads_mobile_sdk/ue1;Lfx0;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
