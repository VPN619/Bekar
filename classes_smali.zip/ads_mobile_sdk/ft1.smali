.class public final Lads_mobile_sdk/ft1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Lnb1;

.field public b:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Ljava/lang/Object;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lnb1;

    invoke-direct {v0}, Lnb1;-><init>()V

    iput-object v0, p0, Lads_mobile_sdk/ft1;->a:Lnb1;

    iput-object p1, p0, Lads_mobile_sdk/ft1;->b:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final a(Lads_mobile_sdk/fo;Lads_mobile_sdk/ts;Lwx;)Ljava/lang/Object;
    .registers 10

    .prologue
    instance-of v0, p3, Lads_mobile_sdk/dt1;

    if-eqz v0, :cond_13

    move-object v0, p3

    check-cast v0, Lads_mobile_sdk/dt1;

    iget v1, v0, Lads_mobile_sdk/dt1;->g:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/dt1;->g:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/dt1;

    invoke-direct {v0, p0, p3}, Lads_mobile_sdk/dt1;-><init>(Lads_mobile_sdk/ft1;Lwx;)V

    :goto_18
    iget-object p3, v0, Lads_mobile_sdk/dt1;->e:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/dt1;->g:I

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    sget-object v5, Lwy;->a:Lwy;

    if-eqz v1, :cond_51

    if-eq v1, v3, :cond_3e

    if-ne v1, v2, :cond_38

    iget-object p0, v0, Lads_mobile_sdk/dt1;->c:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/ft1;

    iget-object p1, v0, Lads_mobile_sdk/dt1;->b:Ljava/lang/Object;

    check-cast p1, Llb1;

    iget-object p2, v0, Lads_mobile_sdk/dt1;->a:Lads_mobile_sdk/ft1;

    :try_start_31
    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_34
    .catchall {:try_start_31 .. :try_end_34} :catchall_35

    goto :goto_8f

    :catchall_35
    move-exception p0

    goto/16 :goto_9b

    :cond_38
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v4

    :cond_3e
    iget-object p0, v0, Lads_mobile_sdk/dt1;->d:Lnb1;

    iget-object p1, v0, Lads_mobile_sdk/dt1;->c:Ljava/lang/Object;

    move-object p2, p1

    check-cast p2, Lbk0;

    iget-object p1, v0, Lads_mobile_sdk/dt1;->b:Ljava/lang/Object;

    check-cast p1, Lbk0;

    iget-object v1, v0, Lads_mobile_sdk/dt1;->a:Lads_mobile_sdk/ft1;

    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V

    move-object p3, p0

    move-object p0, v1

    goto :goto_67

    :cond_51
    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V

    iput-object p0, v0, Lads_mobile_sdk/dt1;->a:Lads_mobile_sdk/ft1;

    iput-object p1, v0, Lads_mobile_sdk/dt1;->b:Ljava/lang/Object;

    iput-object p2, v0, Lads_mobile_sdk/dt1;->c:Ljava/lang/Object;

    iget-object p3, p0, Lads_mobile_sdk/ft1;->a:Lnb1;

    iput-object p3, v0, Lads_mobile_sdk/dt1;->d:Lnb1;

    iput v3, v0, Lads_mobile_sdk/dt1;->g:I

    invoke-virtual {p3, v0}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v5, :cond_67

    goto :goto_8a

    :cond_67
    :goto_67
    :try_start_67
    iget-object v1, p0, Lads_mobile_sdk/ft1;->b:Ljava/lang/Object;

    if-eqz v1, :cond_7a

    invoke-interface {p1, v1}, Lbk0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_78

    goto :goto_7a

    :cond_78
    move-object p1, p3

    goto :goto_92

    :cond_7a
    :goto_7a
    iput-object p0, v0, Lads_mobile_sdk/dt1;->a:Lads_mobile_sdk/ft1;

    iput-object p3, v0, Lads_mobile_sdk/dt1;->b:Ljava/lang/Object;

    iput-object p0, v0, Lads_mobile_sdk/dt1;->c:Ljava/lang/Object;

    iput-object v4, v0, Lads_mobile_sdk/dt1;->d:Lnb1;

    iput v2, v0, Lads_mobile_sdk/dt1;->g:I

    invoke-interface {p2, v0}, Lbk0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1
    :try_end_88
    .catchall {:try_start_67 .. :try_end_88} :catchall_9d

    if-ne p1, v5, :cond_8b

    :goto_8a
    return-object v5

    :cond_8b
    move-object p2, p3

    move-object p3, p1

    move-object p1, p2

    move-object p2, p0

    :goto_8f
    :try_start_8f
    iput-object p3, p0, Lads_mobile_sdk/ft1;->b:Ljava/lang/Object;

    move-object p0, p2

    :goto_92
    iget-object p0, p0, Lads_mobile_sdk/ft1;->b:Ljava/lang/Object;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_97
    .catchall {:try_start_8f .. :try_end_97} :catchall_35

    invoke-interface {p1, v4}, Llb1;->b(Ljava/lang/Object;)V

    return-object p0

    :goto_9b
    move-object p3, p1

    goto :goto_9e

    :catchall_9d
    move-exception p0

    :goto_9e
    invoke-interface {p3, v4}, Llb1;->b(Ljava/lang/Object;)V

    throw p0
.end method

.method public final a(Ljava/lang/Object;Lwx;)Ljava/lang/Object;
    .registers 7

    .prologue
    instance-of v0, p2, Lads_mobile_sdk/et1;

    if-eqz v0, :cond_13

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/et1;

    iget v1, v0, Lads_mobile_sdk/et1;->f:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/et1;->f:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/et1;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/et1;-><init>(Lads_mobile_sdk/ft1;Lwx;)V

    :goto_18
    iget-object p2, v0, Lads_mobile_sdk/et1;->d:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/et1;->f:I

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v1, :cond_34

    if-ne v1, v2, :cond_2e

    iget-object p0, v0, Lads_mobile_sdk/et1;->c:Lnb1;

    iget-object p1, v0, Lads_mobile_sdk/et1;->b:Ljava/lang/Object;

    iget-object v0, v0, Lads_mobile_sdk/et1;->a:Lads_mobile_sdk/ft1;

    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    move-object p2, p0

    move-object p0, v0

    goto :goto_4a

    :cond_2e
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v3

    :cond_34
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    iput-object p0, v0, Lads_mobile_sdk/et1;->a:Lads_mobile_sdk/ft1;

    iput-object p1, v0, Lads_mobile_sdk/et1;->b:Ljava/lang/Object;

    iget-object p2, p0, Lads_mobile_sdk/ft1;->a:Lnb1;

    iput-object p2, v0, Lads_mobile_sdk/et1;->c:Lnb1;

    iput v2, v0, Lads_mobile_sdk/et1;->f:I

    invoke-virtual {p2, v0}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v0

    sget-object v1, Lwy;->a:Lwy;

    if-ne v0, v1, :cond_4a

    return-object v1

    :cond_4a
    :goto_4a
    :try_start_4a
    iput-object p1, p0, Lads_mobile_sdk/ft1;->b:Ljava/lang/Object;

    sget-object p0, Lrg2;->a:Lrg2;
    :try_end_4e
    .catchall {:try_start_4a .. :try_end_4e} :catchall_52

    invoke-virtual {p2, v3}, Lnb1;->b(Ljava/lang/Object;)V

    return-object p0

    :catchall_52
    move-exception p0

    invoke-virtual {p2, v3}, Lnb1;->b(Ljava/lang/Object;)V

    throw p0
.end method

.method public final a(Lwx;)Ljava/lang/Object;
    .registers 6

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/ct1;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/ct1;

    iget v1, v0, Lads_mobile_sdk/ct1;->e:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/ct1;->e:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/ct1;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/ct1;-><init>(Lads_mobile_sdk/ft1;Lwx;)V

    :goto_18
    iget-object p1, v0, Lads_mobile_sdk/ct1;->c:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/ct1;->e:I

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v1, :cond_32

    if-ne v1, v2, :cond_2c

    iget-object p0, v0, Lads_mobile_sdk/ct1;->b:Lnb1;

    iget-object v0, v0, Lads_mobile_sdk/ct1;->a:Lads_mobile_sdk/ft1;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    move-object p1, p0

    move-object p0, v0

    goto :goto_46

    :cond_2c
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v3

    :cond_32
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iput-object p0, v0, Lads_mobile_sdk/ct1;->a:Lads_mobile_sdk/ft1;

    iget-object p1, p0, Lads_mobile_sdk/ft1;->a:Lnb1;

    iput-object p1, v0, Lads_mobile_sdk/ct1;->b:Lnb1;

    iput v2, v0, Lads_mobile_sdk/ct1;->e:I

    invoke-virtual {p1, v0}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v0

    sget-object v1, Lwy;->a:Lwy;

    if-ne v0, v1, :cond_46

    return-object v1

    :cond_46
    :goto_46
    :try_start_46
    iget-object p0, p0, Lads_mobile_sdk/ft1;->b:Ljava/lang/Object;
    :try_end_48
    .catchall {:try_start_46 .. :try_end_48} :catchall_4c

    invoke-virtual {p1, v3}, Lnb1;->b(Ljava/lang/Object;)V

    return-object p0

    :catchall_4c
    move-exception p0

    invoke-virtual {p1, v3}, Lnb1;->b(Ljava/lang/Object;)V

    throw p0
.end method
