.class public final Lads_mobile_sdk/fi0;
.super Lzz0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lzj0;


# static fields
.field public static final a:Lads_mobile_sdk/fi0;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lads_mobile_sdk/fi0;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lzz0;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/fi0;->a:Lads_mobile_sdk/fi0;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 1

    sget-object p0, Lads_mobile_sdk/ax0;->f:Lzn1;

    invoke-static {}, Lq23;->i()Z

    move-result p0

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0
.end method
