.class public final Lads_mobile_sdk/bi;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lo23;


# instance fields
.field public final a:Lads_mobile_sdk/g0;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/g0;)V
    .registers 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/bi;->a:Lads_mobile_sdk/g0;

    return-void
.end method


# virtual methods
.method public final a()Lads_mobile_sdk/lw0;
    .registers 1

    sget-object p0, Lads_mobile_sdk/lw0;->m:Lads_mobile_sdk/lw0;

    return-object p0
.end method

.method public final d(Lvx;)Ljava/lang/Object;
    .registers 4

    .prologue
    new-instance p1, Lads_mobile_sdk/hv0;

    new-instance v0, Lads_mobile_sdk/ai;

    iget-object p0, p0, Lads_mobile_sdk/bi;->a:Lads_mobile_sdk/g0;

    monitor-enter p0

    :try_start_7
    iget-boolean v1, p0, Lads_mobile_sdk/g0;->n:Z
    :try_end_9
    .catchall {:try_start_7 .. :try_end_9} :catchall_11

    monitor-exit p0

    invoke-direct {v0, v1}, Lads_mobile_sdk/ai;-><init>(Z)V

    invoke-direct {p1, v0}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    return-object p1

    :catchall_11
    move-exception p1

    monitor-exit p0

    throw p1
.end method
