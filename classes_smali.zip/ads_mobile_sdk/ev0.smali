.class public final Lads_mobile_sdk/ev0;
.super Lads_mobile_sdk/av0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final c:Ljava/lang/String;

.field public final d:I


# direct methods
.method public constructor <init>(Ljava/lang/String;I)V
    .registers 3

    .prologue
    if-eqz p2, :cond_a

    invoke-direct {p0, p2}, Lads_mobile_sdk/av0;-><init>(I)V

    iput-object p1, p0, Lads_mobile_sdk/ev0;->c:Ljava/lang/String;

    iput p2, p0, Lads_mobile_sdk/ev0;->d:I

    return-void

    :cond_a
    const/4 p0, 0x0

    throw p0
.end method


# virtual methods
.method public final a()I
    .registers 1

    iget p0, p0, Lads_mobile_sdk/ev0;->d:I

    return p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    .prologue
    if-ne p0, p1, :cond_3

    goto :goto_1d

    :cond_3
    instance-of v0, p1, Lads_mobile_sdk/ev0;

    if-nez v0, :cond_8

    goto :goto_1b

    :cond_8
    check-cast p1, Lads_mobile_sdk/ev0;

    iget-object v0, p0, Lads_mobile_sdk/ev0;->c:Ljava/lang/String;

    iget-object v1, p1, Lads_mobile_sdk/ev0;->c:Ljava/lang/String;

    invoke-static {v0, v1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_15

    goto :goto_1b

    :cond_15
    iget p0, p0, Lads_mobile_sdk/ev0;->d:I

    iget p1, p1, Lads_mobile_sdk/ev0;->d:I

    if-eq p0, p1, :cond_1d

    :goto_1b
    const/4 p0, 0x0

    return p0

    :cond_1d
    :goto_1d
    const/4 p0, 0x1

    return p0
.end method

.method public final hashCode()I
    .registers 2

    iget-object v0, p0, Lads_mobile_sdk/ev0;->c:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget p0, p0, Lads_mobile_sdk/ev0;->d:I

    invoke-static {p0}, Lc33;->x(I)I

    move-result p0

    add-int/2addr p0, v0

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 4

    const-string v0, "MessageError(message="

    const-string v1, ", internalErrorCode="

    iget-object v2, p0, Lads_mobile_sdk/ev0;->c:Ljava/lang/String;

    invoke-static {v0, v2, v1}, Lrt2;->o(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget p0, p0, Lads_mobile_sdk/ev0;->d:I

    invoke-static {p0}, Ly41;->C(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
