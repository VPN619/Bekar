.class public final Lads_mobile_sdk/fr3;
.super Lpb;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lcz2;
.implements Le23;


# instance fields
.field public final c:Lnb1;

.field public d:Lads_mobile_sdk/nn3;


# direct methods
.method public constructor <init>(Lvy;Ljava/util/Map;)V
    .registers 3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0, p1, p2}, Lpb;-><init>(Lvy;Ljava/util/Map;)V

    new-instance p1, Lnb1;

    invoke-direct {p1}, Lnb1;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/fr3;->c:Lnb1;

    return-void
.end method

.method public static a(Lads_mobile_sdk/fr3;Lads_mobile_sdk/nn3;Lwx;)Ljava/lang/Object;
    .registers 11

    .prologue
    instance-of v0, p2, Lads_mobile_sdk/dr3;

    if-eqz v0, :cond_13

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/dr3;

    iget v1, v0, Lads_mobile_sdk/dr3;->f:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/dr3;->f:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/dr3;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/dr3;-><init>(Lads_mobile_sdk/fr3;Lwx;)V

    :goto_18
    iget-object p2, v0, Lads_mobile_sdk/dr3;->d:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/dr3;->f:I

    const/4 v2, 0x1

    if-eqz v1, :cond_35

    if-ne v1, v2, :cond_2e

    iget-object p0, v0, Lads_mobile_sdk/dr3;->c:Lnb1;

    iget-object p1, v0, Lads_mobile_sdk/dr3;->b:Lads_mobile_sdk/nn3;

    iget-object v0, v0, Lads_mobile_sdk/dr3;->a:Lads_mobile_sdk/fr3;

    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    move-object p2, p0

    move-object p0, v0

    :cond_2c
    move-object v4, p1

    goto :goto_4b

    :cond_2e
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0

    :cond_35
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p2, p0, Lads_mobile_sdk/fr3;->c:Lnb1;

    iput-object p0, v0, Lads_mobile_sdk/dr3;->a:Lads_mobile_sdk/fr3;

    iput-object p1, v0, Lads_mobile_sdk/dr3;->b:Lads_mobile_sdk/nn3;

    iput-object p2, v0, Lads_mobile_sdk/dr3;->c:Lnb1;

    iput v2, v0, Lads_mobile_sdk/dr3;->f:I

    invoke-virtual {p2, v0}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v0

    sget-object v1, Lwy;->a:Lwy;

    if-ne v0, v1, :cond_2c

    return-object v1

    :goto_4b
    const/4 v3, 0x0

    :try_start_4c
    iget-object p1, p0, Lads_mobile_sdk/fr3;->d:Lads_mobile_sdk/nn3;
    :try_end_4e
    .catchall {:try_start_4c .. :try_end_4e} :catchall_5c

    sget-object v6, Lrg2;->a:Lrg2;

    if-eqz p1, :cond_5f

    :try_start_52
    invoke-static {v4, p1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1
    :try_end_56
    .catchall {:try_start_52 .. :try_end_56} :catchall_5c

    if-eqz p1, :cond_5f

    invoke-virtual {p2, v3}, Lnb1;->b(Ljava/lang/Object;)V

    return-object v6

    :catchall_5c
    move-exception v0

    move-object p0, v0

    goto :goto_a1

    :cond_5f
    :try_start_5f
    iput-object v4, p0, Lads_mobile_sdk/fr3;->d:Lads_mobile_sdk/nn3;

    iget-object p1, p0, Lpb;->b:Ljava/lang/Object;

    check-cast p1, Ljava/util/Map;

    invoke-interface {p1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_6d
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_9d

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    iget-object v0, p0, Lpb;->a:Ljava/lang/Object;

    move-object v7, v0

    check-cast v7, Lvy;

    new-instance v0, Lads_mobile_sdk/y9;

    const/4 v5, 0x1

    invoke-direct/range {v0 .. v5}, Lads_mobile_sdk/y9;-><init>(Ljava/lang/String;Ljava/lang/Object;Lvx;Lads_mobile_sdk/nn3;I)V

    sget-object v1, Ly90;->a:Ly90;

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v2, La42;

    invoke-direct {v2, v0, v3}, La42;-><init>(Lpk0;Lvx;)V

    const/4 v0, 0x2

    invoke-static {v7, v1, v3, v2, v0}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;
    :try_end_9c
    .catchall {:try_start_5f .. :try_end_9c} :catchall_5c

    goto :goto_6d

    :cond_9d
    invoke-virtual {p2, v3}, Lnb1;->b(Ljava/lang/Object;)V

    return-object v6

    :goto_a1
    invoke-virtual {p2, v3}, Lnb1;->b(Ljava/lang/Object;)V

    throw p0
.end method


# virtual methods
.method public final b(Lads_mobile_sdk/nn3;Lvx;)Ljava/lang/Object;
    .registers 3

    check-cast p2, Lwx;

    invoke-static {p0, p1, p2}, Lads_mobile_sdk/fr3;->a(Lads_mobile_sdk/fr3;Lads_mobile_sdk/nn3;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final c(Lads_mobile_sdk/nn3;Lm82;)Ljava/lang/Object;
    .registers 3

    .prologue
    invoke-static {p0, p1, p2}, Lads_mobile_sdk/fr3;->a(Lads_mobile_sdk/fr3;Lads_mobile_sdk/nn3;Lwx;)Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lwy;->a:Lwy;

    if-ne p0, p1, :cond_9

    return-object p0

    :cond_9
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method
