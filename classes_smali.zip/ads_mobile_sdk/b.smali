.class public final Lads_mobile_sdk/b;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lnt2;


# instance fields
.field public final a:Ltv2;

.field public final synthetic b:I


# direct methods
.method public synthetic constructor <init>(Ltv2;I)V
    .registers 3

    iput p2, p0, Lads_mobile_sdk/b;->b:I

    iput-object p1, p0, Lads_mobile_sdk/b;->a:Ltv2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 7

    .prologue
    iget v0, p0, Lads_mobile_sdk/b;->b:I

    const/4 v1, 0x0

    const/4 v2, 0x1

    const v3, 0x7fffffff

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object p0, p0, Lads_mobile_sdk/b;->a:Ltv2;

    packed-switch v0, :pswitch_data_17a

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/li3;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object p0

    :pswitch_18  #0x1c
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ln63;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance p0, Ljava/util/Random;

    invoke-direct {p0}, Ljava/util/Random;-><init>()V

    invoke-virtual {p0, v3}, Ljava/util/Random;->nextInt(I)I

    move-result p0

    invoke-static {p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lhi1;->o(Ljava/lang/Object;)V

    return-object p0

    :pswitch_32  #0x1b
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lpu2;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lads_mobile_sdk/ez1;

    invoke-direct {v0, p0, v4}, Lads_mobile_sdk/ez1;-><init>(Lbw2;I)V

    return-object v0

    :pswitch_41  #0x1a
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/lx;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object p0

    :pswitch_4b  #0x19
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/g0;

    new-instance v0, Lads_mobile_sdk/bi;

    invoke-direct {v0, p0}, Lads_mobile_sdk/bi;-><init>(Lads_mobile_sdk/g0;)V

    return-object v0

    :pswitch_57  #0x18
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/n12;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object p0

    :pswitch_61  #0x17
    invoke-static {p0, p0, v2}, Lmd3;->a(Ltv2;Ltv2;Z)Lads_mobile_sdk/l61;

    move-result-object p0

    return-object p0

    :pswitch_66  #0x16
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/sq1;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lads_mobile_sdk/ez1;

    invoke-direct {v0, p0, v5}, Lads_mobile_sdk/ez1;-><init>(Lbw2;I)V

    return-object v0

    :pswitch_75  #0x15
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/j12;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object p0

    :pswitch_7f  #0x14
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/ph0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object p0

    :pswitch_89  #0x13
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/dt;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lads_mobile_sdk/ez1;

    invoke-direct {v0, p0, v4}, Lads_mobile_sdk/ez1;-><init>(Lbw2;I)V

    return-object v0

    :pswitch_98  #0x12
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ln63;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance p0, Ljava/util/Random;

    invoke-direct {p0}, Ljava/util/Random;-><init>()V

    invoke-virtual {p0, v3}, Ljava/util/Random;->nextInt(I)I

    move-result p0

    invoke-static {p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lhi1;->o(Ljava/lang/Object;)V

    return-object p0

    :pswitch_b2  #0x11
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/dr2;

    new-instance v0, Lads_mobile_sdk/ab2;

    invoke-direct {v0, p0}, Lads_mobile_sdk/ab2;-><init>(Lads_mobile_sdk/dr2;)V

    return-object v0

    :pswitch_be  #0x10
    invoke-static {p0}, Lads_mobile_sdk/nj0;->a(Ltv2;)Lv03;

    move-result-object p0

    new-instance v0, Lads_mobile_sdk/a80;

    invoke-direct {v0, p0}, Lads_mobile_sdk/a80;-><init>(Lv03;)V

    return-object v0

    :pswitch_c8  #0xf
    new-instance v0, Lb63;

    invoke-direct {v0, p0, v1}, Lads_mobile_sdk/l61;-><init>(Ltv2;Z)V

    return-object v0

    :pswitch_ce  #0xe
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/ek;

    new-instance v0, Lads_mobile_sdk/a41;

    invoke-direct {v0, p0}, Lads_mobile_sdk/a41;-><init>(Lads_mobile_sdk/ek;)V

    return-object v0

    :pswitch_da  #0xd
    invoke-static {p0}, Lads_mobile_sdk/nj0;->a(Ltv2;)Lv03;

    move-result-object p0

    new-instance v0, Lads_mobile_sdk/a33;

    invoke-direct {v0, p0}, Lads_mobile_sdk/a33;-><init>(Lv03;)V

    return-object v0

    :pswitch_e4  #0xc
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcy2;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lads_mobile_sdk/ez1;

    invoke-direct {v0, p0, v5}, Lads_mobile_sdk/ez1;-><init>(Lbw2;I)V

    return-object v0

    :pswitch_f3  #0xb
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lvu2;

    new-instance v0, Lads_mobile_sdk/a1;

    invoke-direct {v0, p0}, Lads_mobile_sdk/a1;-><init>(Lvu2;)V

    return-object v0

    :pswitch_ff  #0xa
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/oz1;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object p0

    :pswitch_109  #0x9
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/xr2;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lads_mobile_sdk/ez1;

    invoke-direct {v0, p0, v5}, Lads_mobile_sdk/ez1;-><init>(Lbw2;I)V

    return-object v0

    :pswitch_118  #0x8
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/lg;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lads_mobile_sdk/ez1;

    invoke-direct {v0, p0, v4}, Lads_mobile_sdk/ez1;-><init>(Lbw2;I)V

    return-object v0

    :pswitch_127  #0x7
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/w12;

    new-instance v0, Lads_mobile_sdk/zh3;

    invoke-direct {v0, p0}, Lads_mobile_sdk/zh3;-><init>(Lads_mobile_sdk/w12;)V

    return-object v0

    :pswitch_133  #0x6
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/og0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object p0

    :pswitch_13d  #0x5
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lx43;

    new-instance v0, Lads_mobile_sdk/zf3;

    invoke-direct {v0, p0}, Lads_mobile_sdk/zf3;-><init>(Lx43;)V

    return-object v0

    :pswitch_149  #0x4
    invoke-static {p0, p0, v2}, Lmd3;->a(Ltv2;Ltv2;Z)Lads_mobile_sdk/l61;

    move-result-object p0

    return-object p0

    :pswitch_14e  #0x3
    new-instance v0, Lb63;

    invoke-direct {v0, p0, v1}, Lads_mobile_sdk/l61;-><init>(Ltv2;Z)V

    return-object v0

    :pswitch_154  #0x2
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/in3;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lads_mobile_sdk/ez1;

    invoke-direct {v0, p0, v5}, Lads_mobile_sdk/ez1;-><init>(Lbw2;I)V

    return-object v0

    :pswitch_163  #0x1
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/su1;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object p0

    :pswitch_16d  #0x0
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/th3;

    new-instance v0, Lads_mobile_sdk/a;

    invoke-direct {v0, p0}, Lads_mobile_sdk/a;-><init>(Lads_mobile_sdk/th3;)V

    return-object v0

    nop

    :pswitch_data_17a
    .packed-switch 0x0
        :pswitch_16d  #00000000
        :pswitch_163  #00000001
        :pswitch_154  #00000002
        :pswitch_14e  #00000003
        :pswitch_149  #00000004
        :pswitch_13d  #00000005
        :pswitch_133  #00000006
        :pswitch_127  #00000007
        :pswitch_118  #00000008
        :pswitch_109  #00000009
        :pswitch_ff  #0000000a
        :pswitch_f3  #0000000b
        :pswitch_e4  #0000000c
        :pswitch_da  #0000000d
        :pswitch_ce  #0000000e
        :pswitch_c8  #0000000f
        :pswitch_be  #00000010
        :pswitch_b2  #00000011
        :pswitch_98  #00000012
        :pswitch_89  #00000013
        :pswitch_7f  #00000014
        :pswitch_75  #00000015
        :pswitch_66  #00000016
        :pswitch_61  #00000017
        :pswitch_57  #00000018
        :pswitch_4b  #00000019
        :pswitch_41  #0000001a
        :pswitch_32  #0000001b
        :pswitch_18  #0000001c
    .end packed-switch
.end method
