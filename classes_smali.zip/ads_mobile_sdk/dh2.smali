.class public final Lads_mobile_sdk/dh2;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public a:Lnb1;

.field public b:Lads_mobile_sdk/fh2;

.field public c:I

.field public synthetic d:Ljava/lang/Object;

.field public final synthetic e:J

.field public final synthetic f:Lads_mobile_sdk/fh2;


# direct methods
.method public constructor <init>(JLads_mobile_sdk/fh2;Lvx;)V
    .registers 5

    iput-wide p1, p0, Lads_mobile_sdk/dh2;->e:J

    iput-object p3, p0, Lads_mobile_sdk/dh2;->f:Lads_mobile_sdk/fh2;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p4}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 6

    new-instance v0, Lads_mobile_sdk/dh2;

    iget-wide v1, p0, Lads_mobile_sdk/dh2;->e:J

    iget-object p0, p0, Lads_mobile_sdk/dh2;->f:Lads_mobile_sdk/fh2;

    invoke-direct {v0, v1, v2, p0, p1}, Lads_mobile_sdk/dh2;-><init>(JLads_mobile_sdk/fh2;Lvx;)V

    iput-object p2, v0, Lads_mobile_sdk/dh2;->d:Ljava/lang/Object;

    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    invoke-virtual {p0, p2, p1}, Lads_mobile_sdk/dh2;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/dh2;

    sget-object p1, Lrg2;->a:Lrg2;

    invoke-virtual {p0, p1}, Lads_mobile_sdk/dh2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 12

    .prologue
    iget v0, p0, Lads_mobile_sdk/dh2;->c:I

    sget-object v1, Lrg2;->a:Lrg2;

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v4, p0, Lads_mobile_sdk/dh2;->f:Lads_mobile_sdk/fh2;

    const/4 v5, 0x1

    const/4 v6, 0x0

    sget-object v7, Lwy;->a:Lwy;

    if-eqz v0, :cond_36

    if-eq v0, v5, :cond_2e

    if-eq v0, v3, :cond_26

    if-ne v0, v2, :cond_20

    iget-object v4, p0, Lads_mobile_sdk/dh2;->b:Lads_mobile_sdk/fh2;

    iget-object v0, p0, Lads_mobile_sdk/dh2;->a:Lnb1;

    iget-object p0, p0, Lads_mobile_sdk/dh2;->d:Ljava/lang/Object;

    check-cast p0, Lvy;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_7a

    :cond_20
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v6

    :cond_26
    iget-object v0, p0, Lads_mobile_sdk/dh2;->d:Ljava/lang/Object;

    check-cast v0, Lvy;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_67

    :cond_2e
    iget-object v0, p0, Lads_mobile_sdk/dh2;->d:Ljava/lang/Object;

    check-cast v0, Lvy;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_4b

    :cond_36
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/dh2;->d:Ljava/lang/Object;

    move-object v0, p1

    check-cast v0, Lvy;

    iput-object v0, p0, Lads_mobile_sdk/dh2;->d:Ljava/lang/Object;

    iput v5, p0, Lads_mobile_sdk/dh2;->c:I

    iget-wide v8, p0, Lads_mobile_sdk/dh2;->e:J

    invoke-static {v8, v9, p0}, Lsz;->u(JLvx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v7, :cond_4b

    goto :goto_77

    :cond_4b
    :goto_4b
    iget-object p1, v4, Lads_mobile_sdk/fh2;->e:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v8, 0x0

    invoke-virtual {p1, v8, v5}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result p1

    if-eqz p1, :cond_67

    iget-object p1, v4, Lads_mobile_sdk/fh2;->a:Lads_mobile_sdk/xj2;

    iput-object v0, p0, Lads_mobile_sdk/dh2;->d:Ljava/lang/Object;

    iput v3, p0, Lads_mobile_sdk/dh2;->c:I

    sget-object v3, Lads_mobile_sdk/fw0;->s1:Lads_mobile_sdk/fw0;

    invoke-virtual {p1, v3, p0}, Lads_mobile_sdk/xj2;->a(Lads_mobile_sdk/fw0;Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v7, :cond_63

    goto :goto_64

    :cond_63
    move-object p1, v1

    :goto_64
    if-ne p1, v7, :cond_67

    goto :goto_77

    :cond_67
    :goto_67
    iget-object p1, v4, Lads_mobile_sdk/fh2;->f:Lnb1;

    iput-object v0, p0, Lads_mobile_sdk/dh2;->d:Ljava/lang/Object;

    iput-object p1, p0, Lads_mobile_sdk/dh2;->a:Lnb1;

    iput-object v4, p0, Lads_mobile_sdk/dh2;->b:Lads_mobile_sdk/fh2;

    iput v2, p0, Lads_mobile_sdk/dh2;->c:I

    invoke-virtual {p1, p0}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v7, :cond_78

    :goto_77
    return-object v7

    :cond_78
    move-object p0, v0

    move-object v0, p1

    :goto_7a
    :try_start_7a
    iget-object p1, v4, Lads_mobile_sdk/fh2;->g:Lx52;

    invoke-interface {p0}, Lvy;->h()Lly;

    move-result-object p0

    sget-object v2, Lms1;->e:Lms1;

    invoke-interface {p0, v2}, Lly;->get(Lky;)Ljy;

    move-result-object p0

    invoke-static {p1, p0}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_91

    iput-object v6, v4, Lads_mobile_sdk/fh2;->g:Lx52;
    :try_end_8e
    .catchall {:try_start_7a .. :try_end_8e} :catchall_8f

    goto :goto_91

    :catchall_8f
    move-exception p0

    goto :goto_95

    :cond_91
    :goto_91
    invoke-virtual {v0, v6}, Lnb1;->b(Ljava/lang/Object;)V

    return-object v1

    :goto_95
    invoke-virtual {v0, v6}, Lnb1;->b(Ljava/lang/Object;)V

    throw p0
.end method
