.class public final Lads_mobile_sdk/f81;
.super Lwx;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public a:Lads_mobile_sdk/d91;

.field public b:Lfx0;

.field public c:Ljava/lang/Object;

.field public d:Ljava/lang/Object;

.field public e:Ljava/lang/Object;

.field public f:Ljava/lang/Object;

.field public g:Ljava/lang/Object;

.field public h:Ljava/lang/Object;

.field public i:Ljava/lang/Object;

.field public j:Ljava/lang/String;

.field public k:Lfx0;

.field public l:Lkm0;

.field public m:Z

.field public n:Z

.field public synthetic o:Ljava/lang/Object;

.field public final synthetic p:Lads_mobile_sdk/d91;

.field public q:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/d91;Lwx;)V
    .registers 3

    iput-object p1, p0, Lads_mobile_sdk/f81;->p:Lads_mobile_sdk/d91;

    invoke-direct {p0, p2}, Lwx;-><init>(Lvx;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    iput-object p1, p0, Lads_mobile_sdk/f81;->o:Ljava/lang/Object;

    iget p1, p0, Lads_mobile_sdk/f81;->q:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, Lads_mobile_sdk/f81;->q:I

    iget-object p1, p0, Lads_mobile_sdk/f81;->p:Lads_mobile_sdk/d91;

    invoke-virtual {p1, p0}, Lads_mobile_sdk/d91;->t(Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
