.class public final Lads_mobile_sdk/e22;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public a:I

.field public final synthetic b:Lads_mobile_sdk/p22;

.field public final synthetic c:J

.field public final synthetic d:Landroid/net/Network;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/p22;JLandroid/net/Network;Lvx;)V
    .registers 6

    iput-object p1, p0, Lads_mobile_sdk/e22;->b:Lads_mobile_sdk/p22;

    iput-wide p2, p0, Lads_mobile_sdk/e22;->c:J

    iput-object p4, p0, Lads_mobile_sdk/e22;->d:Landroid/net/Network;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p5}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 9

    new-instance v0, Lads_mobile_sdk/e22;

    iget-wide v2, p0, Lads_mobile_sdk/e22;->c:J

    iget-object v4, p0, Lads_mobile_sdk/e22;->d:Landroid/net/Network;

    iget-object v1, p0, Lads_mobile_sdk/e22;->b:Lads_mobile_sdk/p22;

    move-object v5, p1

    invoke-direct/range {v0 .. v5}, Lads_mobile_sdk/e22;-><init>(Lads_mobile_sdk/p22;JLandroid/net/Network;Lvx;)V

    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    invoke-virtual {p0, p2, p1}, Lads_mobile_sdk/e22;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/e22;

    sget-object p1, Lrg2;->a:Lrg2;

    invoke-virtual {p0, p1}, Lads_mobile_sdk/e22;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 9

    .prologue
    iget v0, p0, Lads_mobile_sdk/e22;->a:I

    const/4 v1, 0x1

    if-eqz v0, :cond_12

    if-ne v0, v1, :cond_b

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_29

    :cond_b
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0

    :cond_12
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iput v1, p0, Lads_mobile_sdk/e22;->a:I

    const/4 v5, 0x0

    iget-object v0, p0, Lads_mobile_sdk/e22;->b:Lads_mobile_sdk/p22;

    iget-wide v1, p0, Lads_mobile_sdk/e22;->c:J

    iget-object v3, p0, Lads_mobile_sdk/e22;->d:Landroid/net/Network;

    const/4 v4, 0x0

    move-object v6, p0

    invoke-virtual/range {v0 .. v6}, Lads_mobile_sdk/p22;->a(JLandroid/net/Network;Landroid/net/NetworkCapabilities;ZLwx;)Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lwy;->a:Lwy;

    if-ne p0, p1, :cond_29

    return-object p1

    :cond_29
    :goto_29
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method
