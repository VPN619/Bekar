.class public final Lads_mobile_sdk/d61;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lnt2;


# instance fields
.field public final a:Ltv2;

.field public final b:Lads_mobile_sdk/b23;

.field public final synthetic c:I


# direct methods
.method public synthetic constructor <init>(Ltv2;Lads_mobile_sdk/b23;I)V
    .registers 4

    iput p3, p0, Lads_mobile_sdk/d61;->c:I

    iput-object p1, p0, Lads_mobile_sdk/d61;->a:Ltv2;

    iput-object p2, p0, Lads_mobile_sdk/d61;->b:Lads_mobile_sdk/b23;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 4

    .prologue
    iget v0, p0, Lads_mobile_sdk/d61;->c:I

    iget-object v1, p0, Lads_mobile_sdk/d61;->b:Lads_mobile_sdk/b23;

    iget-object p0, p0, Lads_mobile_sdk/d61;->a:Ltv2;

    packed-switch v0, :pswitch_data_34

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/da3;

    invoke-virtual {v1}, Lads_mobile_sdk/b23;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Set;

    new-instance v1, Lads_mobile_sdk/ia3;

    invoke-direct {v1, p0, v0}, Lads_mobile_sdk/ia3;-><init>(Lads_mobile_sdk/da3;Ljava/util/Set;)V

    return-object v1

    :pswitch_1b  #0x0
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/g0;

    invoke-virtual {v1}, Lads_mobile_sdk/b23;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Set;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lads_mobile_sdk/m41;

    const/4 v2, 0x1

    invoke-direct {v1, v2, p0, v0}, Lads_mobile_sdk/m41;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    return-object v1

    :pswitch_data_34
    .packed-switch 0x0
        :pswitch_1b  #00000000
    .end packed-switch
.end method
