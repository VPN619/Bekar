.class public final Lads_mobile_sdk/fi1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ldv2;


# instance fields
.field public final a:Lli;

.field public final b:Lads_mobile_sdk/cu2;

.field public final c:Landroid/content/Context;

.field public final d:Lads_mobile_sdk/g0;

.field public final e:Lads_mobile_sdk/rh0;

.field public final f:Ltv2;


# direct methods
.method public constructor <init>(Lli;Lads_mobile_sdk/cu2;Landroid/content/Context;Lads_mobile_sdk/g0;Lads_mobile_sdk/rh0;Lads_mobile_sdk/ab0;)V
    .registers 7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/fi1;->a:Lli;

    iput-object p2, p0, Lads_mobile_sdk/fi1;->b:Lads_mobile_sdk/cu2;

    iput-object p3, p0, Lads_mobile_sdk/fi1;->c:Landroid/content/Context;

    iput-object p4, p0, Lads_mobile_sdk/fi1;->d:Lads_mobile_sdk/g0;

    iput-object p5, p0, Lads_mobile_sdk/fi1;->e:Lads_mobile_sdk/rh0;

    iput-object p6, p0, Lads_mobile_sdk/fi1;->f:Ltv2;

    return-void
.end method


# virtual methods
.method public final a(Lads_mobile_sdk/n13;Lads_mobile_sdk/a2;Lk53;)Lm23;
    .registers 4

    check-cast p3, Lads_mobile_sdk/z42;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p0, Lads_mobile_sdk/fi1;->f:Ltv2;

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/we0;

    new-instance p1, Lay2;

    invoke-direct {p1, p3}, Lay2;-><init>(Lads_mobile_sdk/z42;)V

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Lads_mobile_sdk/we0;->p:Lxy2;

    return-object p0
.end method

.method public final a(Lads_mobile_sdk/n13;Lads_mobile_sdk/a2;Lk53;Lads_mobile_sdk/os;)V
    .registers 14

    .prologue
    check-cast p3, Lads_mobile_sdk/z42;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p1, p0, Lads_mobile_sdk/fi1;->d:Lads_mobile_sdk/g0;

    invoke-virtual {p1}, Lads_mobile_sdk/g0;->b()Landroid/app/Activity;

    move-result-object p1

    if-eqz p1, :cond_15

    :goto_13
    move-object v1, p1

    goto :goto_18

    :cond_15
    iget-object p1, p0, Lads_mobile_sdk/fi1;->c:Landroid/content/Context;

    goto :goto_13

    :goto_18
    iget-object p1, p0, Lads_mobile_sdk/fi1;->b:Lads_mobile_sdk/cu2;

    invoke-virtual {p1}, Lads_mobile_sdk/cu2;->a()Lut1;

    move-result-object p1

    iget-object p2, p2, Lads_mobile_sdk/a2;->c:Lfx0;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Lads_mobile_sdk/fi1;->a:Lli;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p0, Lads_mobile_sdk/fi1;->e:Lads_mobile_sdk/rh0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v2, p3, Lads_mobile_sdk/z42;->a:Lcom/google/android/gms/ads/mediation/MediationAdapter;

    instance-of v3, v2, Lcom/google/android/gms/ads/mediation/MediationInterstitialAdapter;

    if-nez v3, :cond_7d

    new-instance p0, Lcom/google/android/gms/ads/AdError;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object p1

    const-class p2, Lcom/google/android/gms/ads/mediation/MediationInterstitialAdapter;

    invoke-virtual {p2}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object p3

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p2}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object p2

    const-string v1, " to "

    const-string v2, ". Does "

    const-string v3, "Failed to cast "

    invoke-static {v3, p1, v1, p3, v2}, Ly41;->t(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p1

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p3, " implement "

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p2, "?"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 p2, 0x0

    const-string p3, "com.google.android.libraries.ads.mobile.sdk"

    invoke-direct {p0, p2, p1, p3}, Lcom/google/android/gms/ads/AdError;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p4, p0}, Lads_mobile_sdk/os;->a(Lcom/google/android/gms/ads/AdError;)V

    return-void

    :cond_7d
    new-instance v3, Lads_mobile_sdk/bo1;

    iget-object v4, v0, Lli;->e:Ljava/util/HashSet;

    invoke-virtual {p1, v1}, Lut1;->a(Landroid/content/Context;)Z

    move-result v5

    const/4 v7, -0x1

    invoke-static {p2, p1}, Lmu2;->d(Lfx0;Lut1;)Ljava/lang/String;

    move-result-object v8

    const/4 v6, -0x1

    invoke-direct/range {v3 .. v8}, Lads_mobile_sdk/bo1;-><init>(Ljava/util/HashSet;ZIILjava/lang/String;)V

    move-object p1, v0

    move-object v0, v2

    check-cast v0, Lcom/google/android/gms/ads/mediation/MediationInterstitialAdapter;

    move-object v4, v2

    new-instance v2, Lads_mobile_sdk/v42;

    invoke-direct {v2, p0, p4, p3}, Lads_mobile_sdk/v42;-><init>(Lads_mobile_sdk/rh0;Lads_mobile_sdk/os;Lads_mobile_sdk/z42;)V

    invoke-static {p2}, Lmu2;->b(Lfx0;)Landroid/os/Bundle;

    move-result-object p0

    invoke-static {p1, v4}, Lmu2;->a(Lli;Lcom/google/android/gms/ads/mediation/MediationExtrasReceiver;)Landroid/os/Bundle;

    move-result-object v5

    move-object v4, v3

    move-object v3, p0

    invoke-interface/range {v0 .. v5}, Lcom/google/android/gms/ads/mediation/MediationInterstitialAdapter;->requestInterstitialAd(Landroid/content/Context;Lcom/google/android/gms/ads/mediation/MediationInterstitialListener;Landroid/os/Bundle;Lcom/google/android/gms/ads/mediation/MediationAdRequest;Landroid/os/Bundle;)V

    return-void
.end method
