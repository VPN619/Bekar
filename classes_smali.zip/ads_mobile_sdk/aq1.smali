.class public final Lads_mobile_sdk/aq1;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public a:I

.field public final synthetic b:Lads_mobile_sdk/cy0;

.field public final synthetic c:Lfx0;

.field public final synthetic t:I


# direct methods
.method public synthetic constructor <init>(Lads_mobile_sdk/cy0;Lfx0;Lvx;I)V
    .registers 5

    iput p4, p0, Lads_mobile_sdk/aq1;->t:I

    iput-object p1, p0, Lads_mobile_sdk/aq1;->b:Lads_mobile_sdk/cy0;

    iput-object p2, p0, Lads_mobile_sdk/aq1;->c:Lfx0;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 5

    .prologue
    iget p2, p0, Lads_mobile_sdk/aq1;->t:I

    iget-object v0, p0, Lads_mobile_sdk/aq1;->c:Lfx0;

    iget-object p0, p0, Lads_mobile_sdk/aq1;->b:Lads_mobile_sdk/cy0;

    packed-switch p2, :pswitch_data_26

    new-instance p2, Lads_mobile_sdk/aq1;

    const/4 v1, 0x3

    invoke-direct {p2, p0, v0, p1, v1}, Lads_mobile_sdk/aq1;-><init>(Lads_mobile_sdk/cy0;Lfx0;Lvx;I)V

    return-object p2

    :pswitch_10  #0x2
    new-instance p2, Lads_mobile_sdk/aq1;

    const/4 v1, 0x2

    invoke-direct {p2, p0, v0, p1, v1}, Lads_mobile_sdk/aq1;-><init>(Lads_mobile_sdk/cy0;Lfx0;Lvx;I)V

    return-object p2

    :pswitch_17  #0x1
    new-instance p2, Lads_mobile_sdk/aq1;

    const/4 v1, 0x1

    invoke-direct {p2, p0, v0, p1, v1}, Lads_mobile_sdk/aq1;-><init>(Lads_mobile_sdk/cy0;Lfx0;Lvx;I)V

    return-object p2

    :pswitch_1e  #0x0
    new-instance p2, Lads_mobile_sdk/aq1;

    const/4 v1, 0x0

    invoke-direct {p2, p0, v0, p1, v1}, Lads_mobile_sdk/aq1;-><init>(Lads_mobile_sdk/cy0;Lfx0;Lvx;I)V

    return-object p2

    nop

    :pswitch_data_26
    .packed-switch 0x0
        :pswitch_1e  #00000000
        :pswitch_17  #00000001
        :pswitch_10  #00000002
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .prologue
    iget v0, p0, Lads_mobile_sdk/aq1;->t:I

    sget-object v1, Lrg2;->a:Lrg2;

    iget-object v2, p0, Lads_mobile_sdk/aq1;->c:Lfx0;

    iget-object p0, p0, Lads_mobile_sdk/aq1;->b:Lads_mobile_sdk/cy0;

    packed-switch v0, :pswitch_data_48

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/aq1;

    const/4 v0, 0x3

    invoke-direct {p1, p0, v2, p2, v0}, Lads_mobile_sdk/aq1;-><init>(Lads_mobile_sdk/cy0;Lfx0;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/aq1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_1a  #0x2
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/aq1;

    const/4 v0, 0x2

    invoke-direct {p1, p0, v2, p2, v0}, Lads_mobile_sdk/aq1;-><init>(Lads_mobile_sdk/cy0;Lfx0;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/aq1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_29  #0x1
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/aq1;

    const/4 v0, 0x1

    invoke-direct {p1, p0, v2, p2, v0}, Lads_mobile_sdk/aq1;-><init>(Lads_mobile_sdk/cy0;Lfx0;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/aq1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_38  #0x0
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/aq1;

    const/4 v0, 0x0

    invoke-direct {p1, p0, v2, p2, v0}, Lads_mobile_sdk/aq1;-><init>(Lads_mobile_sdk/cy0;Lfx0;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/aq1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_48
    .packed-switch 0x0
        :pswitch_38  #00000000
        :pswitch_29  #00000001
        :pswitch_1a  #00000002
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 10

    .prologue
    iget v0, p0, Lads_mobile_sdk/aq1;->t:I

    sget-object v1, Lrg2;->a:Lrg2;

    iget-object v2, p0, Lads_mobile_sdk/aq1;->c:Lfx0;

    iget-object v3, p0, Lads_mobile_sdk/aq1;->b:Lads_mobile_sdk/cy0;

    const/4 v4, 0x0

    const-string v5, "call to \'resume\' before \'invoke\' with coroutine"

    sget-object v6, Lwy;->a:Lwy;

    const/4 v7, 0x1

    packed-switch v0, :pswitch_data_8a

    iget v0, p0, Lads_mobile_sdk/aq1;->a:I

    if-eqz v0, :cond_20

    if-ne v0, v7, :cond_1b

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_2e

    :cond_1b
    invoke-static {v5}, Lz6;->w(Ljava/lang/String;)V

    move-object v1, v4

    goto :goto_2e

    :cond_20
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iput v7, p0, Lads_mobile_sdk/aq1;->a:I

    const-string p1, "onshow"

    invoke-virtual {v3, v2, p1, p0}, Lads_mobile_sdk/cy0;->a(Lfx0;Ljava/lang/String;Lvx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v6, :cond_2e

    move-object v1, v6

    :cond_2e
    :goto_2e
    return-object v1

    :pswitch_2f  #0x2
    iget v0, p0, Lads_mobile_sdk/aq1;->a:I

    if-eqz v0, :cond_3e

    if-ne v0, v7, :cond_39

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_4c

    :cond_39
    invoke-static {v5}, Lz6;->w(Ljava/lang/String;)V

    move-object v1, v4

    goto :goto_4c

    :cond_3e
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iput v7, p0, Lads_mobile_sdk/aq1;->a:I

    const-string p1, "google.afma.nativeAds.renderVideo"

    invoke-virtual {v3, v2, p1, p0}, Lads_mobile_sdk/cy0;->b(Lfx0;Ljava/lang/String;Lvx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v6, :cond_4c

    move-object v1, v6

    :cond_4c
    :goto_4c
    return-object v1

    :pswitch_4d  #0x1
    iget v0, p0, Lads_mobile_sdk/aq1;->a:I

    if-eqz v0, :cond_5c

    if-ne v0, v7, :cond_57

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_6a

    :cond_57
    invoke-static {v5}, Lz6;->w(Ljava/lang/String;)V

    move-object v1, v4

    goto :goto_6a

    :cond_5c
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iput v7, p0, Lads_mobile_sdk/aq1;->a:I

    const-string p1, "onAdVisibilityChanged"

    invoke-virtual {v3, v2, p1, p0}, Lads_mobile_sdk/cy0;->a(Lfx0;Ljava/lang/String;Lvx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v6, :cond_6a

    move-object v1, v6

    :cond_6a
    :goto_6a
    return-object v1

    :pswitch_6b  #0x0
    iget v0, p0, Lads_mobile_sdk/aq1;->a:I

    if-eqz v0, :cond_7a

    if-ne v0, v7, :cond_75

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_88

    :cond_75
    invoke-static {v5}, Lz6;->w(Ljava/lang/String;)V

    move-object v1, v4

    goto :goto_88

    :cond_7a
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iput v7, p0, Lads_mobile_sdk/aq1;->a:I

    const-string p1, "onScreenInfoChanged"

    invoke-virtual {v3, v2, p1, p0}, Lads_mobile_sdk/cy0;->a(Lfx0;Ljava/lang/String;Lvx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v6, :cond_88

    move-object v1, v6

    :cond_88
    :goto_88
    return-object v1

    nop

    :pswitch_data_8a
    .packed-switch 0x0
        :pswitch_6b  #00000000
        :pswitch_4d  #00000001
        :pswitch_2f  #00000002
    .end packed-switch
.end method
