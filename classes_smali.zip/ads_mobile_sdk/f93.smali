.class public final Lads_mobile_sdk/f93;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lbw2;


# instance fields
.field public final a:Lads_mobile_sdk/d91;

.field public final b:Lads_mobile_sdk/qr0;

.field public final c:Lads_mobile_sdk/ah3;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/d91;Lads_mobile_sdk/qr0;Lads_mobile_sdk/ah3;)V
    .registers 4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/f93;->a:Lads_mobile_sdk/d91;

    iput-object p2, p0, Lads_mobile_sdk/f93;->b:Lads_mobile_sdk/qr0;

    iput-object p3, p0, Lads_mobile_sdk/f93;->c:Lads_mobile_sdk/ah3;

    return-void
.end method


# virtual methods
.method public final a(Lads_mobile_sdk/cy0;Ljava/util/Map;Lvx;)Ljava/lang/Object;
    .registers 21

    .prologue
    move-object/from16 v1, p0

    move-object/from16 v2, p2

    move-object/from16 v0, p3

    instance-of v3, v0, Lads_mobile_sdk/e93;

    if-eqz v3, :cond_1a

    move-object v3, v0

    check-cast v3, Lads_mobile_sdk/e93;

    iget v4, v3, Lads_mobile_sdk/e93;->e:I

    const/high16 v5, -0x80000000

    and-int v6, v4, v5

    if-eqz v6, :cond_1a

    sub-int/2addr v4, v5

    iput v4, v3, Lads_mobile_sdk/e93;->e:I

    :goto_18
    move-object v14, v3

    goto :goto_20

    :cond_1a
    new-instance v3, Lads_mobile_sdk/e93;

    invoke-direct {v3, v1, v0}, Lads_mobile_sdk/e93;-><init>(Lads_mobile_sdk/f93;Lvx;)V

    goto :goto_18

    :goto_20
    iget-object v0, v14, Lads_mobile_sdk/e93;->c:Ljava/lang/Object;

    iget v3, v14, Lads_mobile_sdk/e93;->e:I

    const/4 v4, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    sget-object v16, Lrg2;->a:Lrg2;

    if-eqz v3, :cond_41

    if-ne v3, v5, :cond_3b

    iget-object v1, v14, Lads_mobile_sdk/e93;->b:Ljava/util/Map;

    iget-object v2, v14, Lads_mobile_sdk/e93;->a:Lads_mobile_sdk/f93;

    :try_start_31
    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_34
    .catch Ljava/lang/NumberFormatException; {:try_start_31 .. :try_end_34} :catch_35

    return-object v16

    :catch_35
    move-exception v0

    move-object v3, v2

    move-object v2, v1

    move-object v1, v3

    :goto_39
    move-object v3, v6

    goto :goto_9c

    :cond_3b
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {v0}, Lz6;->w(Ljava/lang/String;)V

    return-object v6

    :cond_41
    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    iget-object v0, v1, Lads_mobile_sdk/f93;->b:Lads_mobile_sdk/qr0;

    invoke-virtual {v0}, Lads_mobile_sdk/qr0;->X()Z

    move-result v0

    if-nez v0, :cond_4d

    goto :goto_9a

    :cond_4d
    const-string v0, "extras"

    invoke-interface {v2, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    move-object v8, v0

    check-cast v8, Ljava/lang/String;

    if-eqz v8, :cond_5e

    invoke-virtual {v8}, Ljava/lang/String;->length()I

    move-result v0

    if-nez v0, :cond_61

    :cond_5e
    move v1, v4

    move-object v3, v6

    goto :goto_bb

    :cond_61
    move v3, v4

    :try_start_62
    iget-object v4, v1, Lads_mobile_sdk/f93;->a:Lads_mobile_sdk/d91;

    const-string v0, "expires"

    invoke-interface {v2, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    if-eqz v0, :cond_75

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v9

    goto :goto_7a

    :catch_73
    move-exception v0

    goto :goto_39

    :cond_75
    const-wide v9, 0x7fffffffffffffffL

    :goto_7a
    new-instance v0, Ljava/lang/Long;

    invoke-direct {v0, v9, v10}, Ljava/lang/Long;-><init>(J)V

    iput-object v1, v14, Lads_mobile_sdk/e93;->a:Lads_mobile_sdk/f93;

    iput-object v2, v14, Lads_mobile_sdk/e93;->b:Ljava/util/Map;

    iput v5, v14, Lads_mobile_sdk/e93;->e:I
    :try_end_85
    .catch Ljava/lang/NumberFormatException; {:try_start_62 .. :try_end_85} :catch_73

    const/4 v7, 0x0

    const/4 v5, 0x0

    move-object v9, v6

    const/4 v6, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/16 v15, 0x1e7

    move-object v3, v9

    move-object v9, v0

    :try_start_91
    invoke-static/range {v4 .. v15}, Lads_mobile_sdk/d91;->a(Lads_mobile_sdk/d91;Ljava/lang/Boolean;Ljava/lang/Boolean;ILjava/lang/String;Ljava/lang/Long;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Boolean;Lwx;I)Ljava/lang/Object;

    move-result-object v0
    :try_end_95
    .catch Ljava/lang/NumberFormatException; {:try_start_91 .. :try_end_95} :catch_9b

    sget-object v1, Lwy;->a:Lwy;

    if-ne v0, v1, :cond_9a

    return-object v1

    :cond_9a
    :goto_9a
    return-object v16

    :catch_9b
    move-exception v0

    :goto_9c
    const-string v4, "Invalid expiration in SingleAdSourceTesting GMSG."

    invoke-static {v4, v3}, Lads_mobile_sdk/nw;->c(Ljava/lang/String;Ljava/lang/Exception;)V

    iget-object v1, v1, Lads_mobile_sdk/f93;->c:Lads_mobile_sdk/ah3;

    const-string v4, "SingleAdSourceTestingGmsgHandler.onGmsg"

    invoke-virtual {v1, v4, v0}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Invalid expiration in SingleAdSource GMSG: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x6

    invoke-static {v1, v0, v3}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    return-object v16

    :goto_bb
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v4, "Network Extras is missing from SingleAdSource GMSG: "

    invoke-direct {v0, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0, v3}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    const-string v0, "Missing network extras in SingleAdSourceTesting request."

    invoke-static {v0, v3}, Lads_mobile_sdk/nw;->c(Ljava/lang/String;Ljava/lang/Exception;)V

    return-object v16
.end method

.method public final b()I
    .registers 1

    const/16 p0, 0x29

    return p0
.end method
