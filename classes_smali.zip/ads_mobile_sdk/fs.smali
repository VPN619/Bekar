.class public final Lads_mobile_sdk/fs;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lnt2;


# instance fields
.field public final a:Lads_mobile_sdk/ob1;

.field public final b:Lads_mobile_sdk/ah0;

.field public final synthetic c:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/ah0;Lads_mobile_sdk/ob1;)V
    .registers 4

    const/4 v0, 0x5

    iput v0, p0, Lads_mobile_sdk/fs;->c:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/fs;->b:Lads_mobile_sdk/ah0;

    iput-object p2, p0, Lads_mobile_sdk/fs;->a:Lads_mobile_sdk/ob1;

    return-void
.end method

.method public synthetic constructor <init>(Lads_mobile_sdk/ob1;Lads_mobile_sdk/ah0;I)V
    .registers 4

    iput p3, p0, Lads_mobile_sdk/fs;->c:I

    iput-object p1, p0, Lads_mobile_sdk/fs;->a:Lads_mobile_sdk/ob1;

    iput-object p2, p0, Lads_mobile_sdk/fs;->b:Lads_mobile_sdk/ah0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 5

    .prologue
    iget v0, p0, Lads_mobile_sdk/fs;->c:I

    iget-object v1, p0, Lads_mobile_sdk/fs;->b:Lads_mobile_sdk/ah0;

    iget-object p0, p0, Lads_mobile_sdk/fs;->a:Lads_mobile_sdk/ob1;

    packed-switch v0, :pswitch_data_98

    iget-object p0, p0, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast p0, Landroid/content/Context;

    invoke-virtual {v1}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lvy;

    new-instance v1, Lads_mobile_sdk/xk;

    invoke-direct {v1, p0, v0}, Lads_mobile_sdk/xk;-><init>(Landroid/content/Context;Lvy;)V

    return-object v1

    :pswitch_19  #0x5
    invoke-virtual {v1}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/z2;

    iget-object p0, p0, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/a2;

    new-instance v1, Lads_mobile_sdk/zl;

    invoke-direct {v1, v0, p0}, Lads_mobile_sdk/zl;-><init>(Lads_mobile_sdk/z2;Lads_mobile_sdk/a2;)V

    return-object v1

    :pswitch_29  #0x4
    iget-object p0, p0, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/a2;

    invoke-virtual {v1}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/k01;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance p0, Lads_mobile_sdk/ez1;

    const/4 v1, 0x4

    invoke-direct {p0, v0, v1}, Lads_mobile_sdk/ez1;-><init>(Lbw2;I)V

    return-object p0

    :pswitch_40  #0x3
    iget-object p0, p0, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast p0, Landroid/content/Context;

    invoke-virtual {v1}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lvy;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Lads_mobile_sdk/o1;->a:Lads_mobile_sdk/o1;

    new-instance v2, Lads_mobile_sdk/bj;

    const/4 v3, 0x6

    invoke-direct {v2, p0, v3}, Lads_mobile_sdk/bj;-><init>(Landroid/content/Context;I)V

    invoke-static {v1, v0, v2}, Lp80;->m(Lw02;Lvy;Lzj0;)Lc42;

    move-result-object p0

    return-object p0

    :pswitch_5d  #0x2
    iget-object p0, p0, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast p0, Landroid/content/Context;

    invoke-virtual {v1}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/ah3;

    new-instance v1, Lads_mobile_sdk/ki0;

    invoke-direct {v1, p0, v0}, Lads_mobile_sdk/ki0;-><init>(Landroid/content/Context;Lads_mobile_sdk/ah3;)V

    return-object v1

    :pswitch_6d  #0x1
    iget-object p0, p0, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast p0, Landroid/content/Context;

    invoke-virtual {v1}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/ah3;

    new-instance v1, Lads_mobile_sdk/yi;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    const/high16 p0, 0x3f800000  # 1.0f

    iput p0, v1, Lads_mobile_sdk/yi;->c:F

    return-object v1

    :pswitch_87  #0x0
    iget-object p0, p0, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast p0, Landroid/content/Context;

    invoke-virtual {v1}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/ah3;

    new-instance v1, Lads_mobile_sdk/es;

    invoke-direct {v1, p0, v0}, Lads_mobile_sdk/es;-><init>(Landroid/content/Context;Lads_mobile_sdk/ah3;)V

    return-object v1

    nop

    :pswitch_data_98
    .packed-switch 0x0
        :pswitch_87  #00000000
        :pswitch_6d  #00000001
        :pswitch_5d  #00000002
        :pswitch_40  #00000003
        :pswitch_29  #00000004
        :pswitch_19  #00000005
    .end packed-switch
.end method
