.class public final Lads_mobile_sdk/a80;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Lv03;

.field public final b:Lnb1;

.field public c:Lads_mobile_sdk/t70;


# direct methods
.method public constructor <init>(Lv03;)V
    .registers 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/a80;->a:Lv03;

    new-instance p1, Lnb1;

    invoke-direct {p1}, Lnb1;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/a80;->b:Lnb1;

    return-void
.end method

.method public static a(Lads_mobile_sdk/a80;Lads_mobile_sdk/t70;Lwx;)Ljava/lang/Object;
    .registers 10

    .prologue
    instance-of v0, p2, Lads_mobile_sdk/y70;

    if-eqz v0, :cond_13

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/y70;

    iget v1, v0, Lads_mobile_sdk/y70;->f:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/y70;->f:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/y70;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/y70;-><init>(Lads_mobile_sdk/a80;Lwx;)V

    :goto_18
    iget-object p2, v0, Lads_mobile_sdk/y70;->d:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/y70;->f:I

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    sget-object v5, Lwy;->a:Lwy;

    if-eqz v1, :cond_3d

    if-eq v1, v3, :cond_37

    if-ne v1, v2, :cond_31

    iget-object p0, v0, Lads_mobile_sdk/y70;->c:Lnb1;

    iget-object p1, v0, Lads_mobile_sdk/y70;->b:Lads_mobile_sdk/t70;

    iget-object v0, v0, Lads_mobile_sdk/y70;->a:Lads_mobile_sdk/a80;

    :try_start_2d
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_30
    .catch Ljava/lang/Exception; {:try_start_2d .. :try_end_30} :catch_7b

    goto :goto_70

    :cond_31
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v4

    :cond_37
    iget-object p0, v0, Lads_mobile_sdk/y70;->a:Lads_mobile_sdk/a80;

    :try_start_39
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_3c
    .catch Ljava/lang/Exception; {:try_start_39 .. :try_end_3c} :catch_7b

    goto :goto_5a

    :cond_3d
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    :try_start_40
    iget-object p2, p0, Lads_mobile_sdk/a80;->a:Lv03;

    invoke-interface {p2}, Lv03;->get()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lc42;

    new-instance v1, Lc4;

    const/16 v6, 0x15

    invoke-direct {v1, p1, v4, v6}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    iput-object p0, v0, Lads_mobile_sdk/y70;->a:Lads_mobile_sdk/a80;

    iput v3, v0, Lads_mobile_sdk/y70;->f:I

    invoke-virtual {p2, v1, v0}, Lc42;->i(Lpk0;Lwx;)Ljava/lang/Object;

    move-result-object p2

    if-ne p2, v5, :cond_5a

    goto :goto_6d

    :cond_5a
    :goto_5a
    move-object p1, p2

    check-cast p1, Lads_mobile_sdk/t70;

    iget-object p2, p0, Lads_mobile_sdk/a80;->b:Lnb1;

    iput-object p0, v0, Lads_mobile_sdk/y70;->a:Lads_mobile_sdk/a80;

    iput-object p1, v0, Lads_mobile_sdk/y70;->b:Lads_mobile_sdk/t70;

    iput-object p2, v0, Lads_mobile_sdk/y70;->c:Lnb1;

    iput v2, v0, Lads_mobile_sdk/y70;->f:I

    invoke-virtual {p2, v0}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v0
    :try_end_6b
    .catch Ljava/lang/Exception; {:try_start_40 .. :try_end_6b} :catch_7b

    if-ne v0, v5, :cond_6e

    :goto_6d
    return-object v5

    :cond_6e
    move-object v0, p0

    move-object p0, p2

    :goto_70
    :try_start_70
    iput-object p1, v0, Lads_mobile_sdk/a80;->c:Lads_mobile_sdk/t70;
    :try_end_72
    .catchall {:try_start_70 .. :try_end_72} :catchall_76

    :try_start_72
    invoke-virtual {p0, v4}, Lnb1;->b(Ljava/lang/Object;)V

    goto :goto_8a

    :catchall_76
    move-exception p1

    invoke-virtual {p0, v4}, Lnb1;->b(Ljava/lang/Object;)V

    throw p1
    :try_end_7b
    .catch Ljava/lang/Exception; {:try_start_72 .. :try_end_7b} :catch_7b

    :catch_7b
    move-exception p0

    invoke-static {}, Lads_mobile_sdk/hh3;->a()Lads_mobile_sdk/rg3;

    move-result-object p1

    invoke-virtual {p1}, Lads_mobile_sdk/rg3;->e()Lads_mobile_sdk/ub2;

    move-result-object p2

    const/4 v0, 0x0

    iput-boolean v0, p2, Lads_mobile_sdk/ub2;->m:Z

    invoke-virtual {p1, p0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    :goto_8a
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method

.method public static a(Lads_mobile_sdk/a80;Lwx;)Ljava/lang/Object;
    .registers 9

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/v70;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/v70;

    iget v1, v0, Lads_mobile_sdk/v70;->f:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/v70;->f:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/v70;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/v70;-><init>(Lads_mobile_sdk/a80;Lwx;)V

    :goto_18
    iget-object p1, v0, Lads_mobile_sdk/v70;->d:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/v70;->f:I

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    sget-object v6, Lwy;->a:Lwy;

    if-eqz v1, :cond_4e

    if-eq v1, v4, :cond_42

    if-eq v1, v3, :cond_3c

    if-ne v1, v2, :cond_36

    iget-object p0, v0, Lads_mobile_sdk/v70;->c:Lnb1;

    iget-object v1, v0, Lads_mobile_sdk/v70;->b:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/t70;

    iget-object v0, v0, Lads_mobile_sdk/v70;->a:Lads_mobile_sdk/a80;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_9b

    :cond_36
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v5

    :cond_3c
    iget-object p0, v0, Lads_mobile_sdk/v70;->a:Lads_mobile_sdk/a80;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_7f

    :cond_42
    iget-object p0, v0, Lads_mobile_sdk/v70;->b:Ljava/lang/Object;

    check-cast p0, Llb1;

    iget-object v1, v0, Lads_mobile_sdk/v70;->a:Lads_mobile_sdk/a80;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    move-object p1, p0

    move-object p0, v1

    goto :goto_60

    :cond_4e
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/a80;->b:Lnb1;

    iput-object p0, v0, Lads_mobile_sdk/v70;->a:Lads_mobile_sdk/a80;

    iput-object p1, v0, Lads_mobile_sdk/v70;->b:Ljava/lang/Object;

    iput v4, v0, Lads_mobile_sdk/v70;->f:I

    invoke-virtual {p1, v0}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v6, :cond_60

    goto :goto_98

    :cond_60
    :goto_60
    :try_start_60
    iget-object v1, p0, Lads_mobile_sdk/a80;->c:Lads_mobile_sdk/t70;
    :try_end_62
    .catchall {:try_start_60 .. :try_end_62} :catchall_a9

    invoke-interface {p1, v5}, Llb1;->b(Ljava/lang/Object;)V

    if-eqz v1, :cond_68

    return-object v1

    :cond_68
    iget-object p1, p0, Lads_mobile_sdk/a80;->a:Lv03;

    invoke-interface {p1}, Lv03;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lc42;

    iget-object p1, p1, Lc42;->c:Lsw;

    iput-object p0, v0, Lads_mobile_sdk/v70;->a:Lads_mobile_sdk/a80;

    iput-object v5, v0, Lads_mobile_sdk/v70;->b:Ljava/lang/Object;

    iput v3, v0, Lads_mobile_sdk/v70;->f:I

    invoke-static {p1, v0}, Lla1;->u(Lff0;Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v6, :cond_7f

    goto :goto_98

    :cond_7f
    :goto_7f
    check-cast p1, Lads_mobile_sdk/t70;

    if-nez p1, :cond_87

    invoke-static {}, Lads_mobile_sdk/t70;->p()Lads_mobile_sdk/t70;

    move-result-object p1

    :cond_87
    move-object v1, p1

    iget-object p1, p0, Lads_mobile_sdk/a80;->b:Lnb1;

    iput-object p0, v0, Lads_mobile_sdk/v70;->a:Lads_mobile_sdk/a80;

    iput-object v1, v0, Lads_mobile_sdk/v70;->b:Ljava/lang/Object;

    iput-object p1, v0, Lads_mobile_sdk/v70;->c:Lnb1;

    iput v2, v0, Lads_mobile_sdk/v70;->f:I

    invoke-virtual {p1, v0}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v0

    if-ne v0, v6, :cond_99

    :goto_98
    return-object v6

    :cond_99
    move-object v0, p0

    move-object p0, p1

    :goto_9b
    :try_start_9b
    iput-object v1, v0, Lads_mobile_sdk/a80;->c:Lads_mobile_sdk/t70;
    :try_end_9d
    .catchall {:try_start_9b .. :try_end_9d} :catchall_a4

    invoke-virtual {p0, v5}, Lnb1;->b(Ljava/lang/Object;)V

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object v1

    :catchall_a4
    move-exception p1

    invoke-virtual {p0, v5}, Lnb1;->b(Ljava/lang/Object;)V

    throw p1

    :catchall_a9
    move-exception p0

    invoke-interface {p1, v5}, Llb1;->b(Ljava/lang/Object;)V

    throw p0
.end method


# virtual methods
.method public final a(Lwx;)Ljava/lang/Object;
    .registers 9

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/w70;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/w70;

    iget v1, v0, Lads_mobile_sdk/w70;->f:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/w70;->f:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/w70;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/w70;-><init>(Lads_mobile_sdk/a80;Lwx;)V

    :goto_18
    iget-object p1, v0, Lads_mobile_sdk/w70;->d:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/w70;->f:I

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    sget-object v5, Lwy;->a:Lwy;

    if-eqz v1, :cond_3d

    if-eq v1, v2, :cond_37

    if-ne v1, v3, :cond_31

    iget-object p0, v0, Lads_mobile_sdk/w70;->c:Lnb1;

    iget-object v1, v0, Lads_mobile_sdk/w70;->b:Lads_mobile_sdk/t70;

    iget-object v0, v0, Lads_mobile_sdk/w70;->a:Lads_mobile_sdk/a80;

    :try_start_2d
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_30
    .catch Ljava/lang/Exception; {:try_start_2d .. :try_end_30} :catch_7a

    goto :goto_6f

    :cond_31
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v4

    :cond_37
    iget-object p0, v0, Lads_mobile_sdk/w70;->a:Lads_mobile_sdk/a80;

    :try_start_39
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_3c
    .catch Ljava/lang/Exception; {:try_start_39 .. :try_end_3c} :catch_7a

    goto :goto_59

    :cond_3d
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    :try_start_40
    iget-object p1, p0, Lads_mobile_sdk/a80;->a:Lv03;

    invoke-interface {p1}, Lv03;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lc42;

    new-instance v1, Lit2;

    const/4 v6, 0x3

    invoke-direct {v1, v3, v4, v6}, Lit2;-><init>(ILvx;I)V

    iput-object p0, v0, Lads_mobile_sdk/w70;->a:Lads_mobile_sdk/a80;

    iput v2, v0, Lads_mobile_sdk/w70;->f:I

    invoke-virtual {p1, v1, v0}, Lc42;->i(Lpk0;Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v5, :cond_59

    goto :goto_6c

    :cond_59
    :goto_59
    move-object v1, p1

    check-cast v1, Lads_mobile_sdk/t70;

    iget-object p1, p0, Lads_mobile_sdk/a80;->b:Lnb1;

    iput-object p0, v0, Lads_mobile_sdk/w70;->a:Lads_mobile_sdk/a80;

    iput-object v1, v0, Lads_mobile_sdk/w70;->b:Lads_mobile_sdk/t70;

    iput-object p1, v0, Lads_mobile_sdk/w70;->c:Lnb1;

    iput v3, v0, Lads_mobile_sdk/w70;->f:I

    invoke-virtual {p1, v0}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v0
    :try_end_6a
    .catch Ljava/lang/Exception; {:try_start_40 .. :try_end_6a} :catch_7a

    if-ne v0, v5, :cond_6d

    :goto_6c
    return-object v5

    :cond_6d
    move-object v0, p0

    move-object p0, p1

    :goto_6f
    :try_start_6f
    iput-object v1, v0, Lads_mobile_sdk/a80;->c:Lads_mobile_sdk/t70;
    :try_end_71
    .catchall {:try_start_6f .. :try_end_71} :catchall_75

    :try_start_71
    invoke-virtual {p0, v4}, Lnb1;->b(Ljava/lang/Object;)V

    goto :goto_89

    :catchall_75
    move-exception p1

    invoke-virtual {p0, v4}, Lnb1;->b(Ljava/lang/Object;)V

    throw p1
    :try_end_7a
    .catch Ljava/lang/Exception; {:try_start_71 .. :try_end_7a} :catch_7a

    :catch_7a
    move-exception p0

    invoke-static {}, Lads_mobile_sdk/hh3;->a()Lads_mobile_sdk/rg3;

    move-result-object p1

    invoke-virtual {p1}, Lads_mobile_sdk/rg3;->e()Lads_mobile_sdk/ub2;

    move-result-object v0

    const/4 v1, 0x0

    iput-boolean v1, v0, Lads_mobile_sdk/ub2;->m:Z

    invoke-virtual {p1, p0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    :goto_89
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method
