.class public final Lads_mobile_sdk/am2;
.super Lads_mobile_sdk/j;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ljava/util/RandomAccess;


# static fields
.field public static final d:[Ljava/lang/Object;

.field public static final e:Lads_mobile_sdk/am2;


# instance fields
.field public b:[Ljava/lang/Object;

.field public c:I


# direct methods
.method static constructor <clinit>()V
    .registers 3

    const/4 v0, 0x0

    new-array v1, v0, [Ljava/lang/Object;

    sput-object v1, Lads_mobile_sdk/am2;->d:[Ljava/lang/Object;

    new-instance v2, Lads_mobile_sdk/am2;

    invoke-direct {v2, v1, v0, v0}, Lads_mobile_sdk/am2;-><init>([Ljava/lang/Object;IZ)V

    sput-object v2, Lads_mobile_sdk/am2;->e:Lads_mobile_sdk/am2;

    return-void
.end method

.method public constructor <init>([Ljava/lang/Object;IZ)V
    .registers 4

    invoke-direct {p0, p3}, Lads_mobile_sdk/j;-><init>(Z)V

    iput-object p1, p0, Lads_mobile_sdk/am2;->b:[Ljava/lang/Object;

    iput p2, p0, Lads_mobile_sdk/am2;->c:I

    return-void
.end method


# virtual methods
.method public final a(I)Lw63;
    .registers 4

    .prologue
    iget v0, p0, Lads_mobile_sdk/am2;->c:I

    if-lt p1, v0, :cond_18

    if-nez p1, :cond_9

    sget-object p1, Lads_mobile_sdk/am2;->d:[Ljava/lang/Object;

    goto :goto_f

    :cond_9
    iget-object v0, p0, Lads_mobile_sdk/am2;->b:[Ljava/lang/Object;

    invoke-static {v0, p1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p1

    :goto_f
    new-instance v0, Lads_mobile_sdk/am2;

    iget p0, p0, Lads_mobile_sdk/am2;->c:I

    const/4 v1, 0x1

    invoke-direct {v0, p1, p0, v1}, Lads_mobile_sdk/am2;-><init>([Ljava/lang/Object;IZ)V

    return-object v0

    :cond_18
    invoke-static {}, Lpw1;->h()V

    const/4 p0, 0x0

    return-object p0
.end method

.method public final add(ILjava/lang/Object;)V
    .registers 7

    .prologue
    invoke-virtual {p0}, Lads_mobile_sdk/j;->a()V

    if-ltz p1, :cond_3f

    iget v0, p0, Lads_mobile_sdk/am2;->c:I

    if-gt p1, v0, :cond_3f

    iget-object v1, p0, Lads_mobile_sdk/am2;->b:[Ljava/lang/Object;

    array-length v2, v1

    if-ge v0, v2, :cond_15

    add-int/lit8 v2, p1, 0x1

    sub-int/2addr v0, p1

    invoke-static {v1, p1, v1, v2, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    goto :goto_2e

    :cond_15
    array-length v0, v1

    invoke-static {v0}, Lns2;->a(I)I

    move-result v0

    new-array v0, v0, [Ljava/lang/Object;

    iget-object v1, p0, Lads_mobile_sdk/am2;->b:[Ljava/lang/Object;

    const/4 v2, 0x0

    invoke-static {v1, v2, v0, v2, p1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iget-object v1, p0, Lads_mobile_sdk/am2;->b:[Ljava/lang/Object;

    add-int/lit8 v2, p1, 0x1

    iget v3, p0, Lads_mobile_sdk/am2;->c:I

    sub-int/2addr v3, p1

    invoke-static {v1, p1, v0, v2, v3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    iput-object v0, p0, Lads_mobile_sdk/am2;->b:[Ljava/lang/Object;

    :goto_2e
    iget-object v0, p0, Lads_mobile_sdk/am2;->b:[Ljava/lang/Object;

    aput-object p2, v0, p1

    iget p1, p0, Lads_mobile_sdk/am2;->c:I

    add-int/lit8 p1, p1, 0x1

    iput p1, p0, Lads_mobile_sdk/am2;->c:I

    iget p1, p0, Ljava/util/AbstractList;->modCount:I

    add-int/lit8 p1, p1, 0x1

    iput p1, p0, Ljava/util/AbstractList;->modCount:I

    return-void

    :cond_3f
    invoke-virtual {p0, p1}, Lads_mobile_sdk/am2;->c(I)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lvx2;->n(Ljava/lang/String;)V

    return-void
.end method

.method public final add(Ljava/lang/Object;)Z
    .registers 5

    .prologue
    invoke-virtual {p0}, Lads_mobile_sdk/j;->a()V

    iget v0, p0, Lads_mobile_sdk/am2;->c:I

    iget-object v1, p0, Lads_mobile_sdk/am2;->b:[Ljava/lang/Object;

    array-length v2, v1

    if-ne v0, v2, :cond_17

    array-length v0, v1

    invoke-static {v0}, Lns2;->a(I)I

    move-result v0

    iget-object v1, p0, Lads_mobile_sdk/am2;->b:[Ljava/lang/Object;

    invoke-static {v1, v0}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v1

    iput-object v1, p0, Lads_mobile_sdk/am2;->b:[Ljava/lang/Object;

    :cond_17
    iget v0, p0, Lads_mobile_sdk/am2;->c:I

    add-int/lit8 v2, v0, 0x1

    iput v2, p0, Lads_mobile_sdk/am2;->c:I

    aput-object p1, v1, v0

    iget p1, p0, Ljava/util/AbstractList;->modCount:I

    const/4 v0, 0x1

    add-int/2addr p1, v0

    iput p1, p0, Ljava/util/AbstractList;->modCount:I

    return v0
.end method

.method public final c(I)Ljava/lang/String;
    .registers 4

    iget p0, p0, Lads_mobile_sdk/am2;->c:I

    const-string v0, "Index:"

    const-string v1, ", Size:"

    invoke-static {p1, p0, v0, v1}, Ly41;->o(IILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 7

    .prologue
    if-ne p1, p0, :cond_3

    goto :goto_4e

    :cond_3
    instance-of v0, p1, Ljava/util/List;

    const/4 v1, 0x0

    if-nez v0, :cond_9

    goto :goto_4a

    :cond_9
    instance-of v0, p1, Ljava/util/RandomAccess;

    if-nez v0, :cond_12

    invoke-super {p0, p1}, Lads_mobile_sdk/j;->equals(Ljava/lang/Object;)Z

    move-result p0

    return p0

    :cond_12
    move-object v0, p1

    check-cast v0, Ljava/util/List;

    iget v2, p0, Lads_mobile_sdk/am2;->c:I

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v3

    if-eq v2, v3, :cond_1e

    goto :goto_4a

    :cond_1e
    instance-of v3, p1, Lads_mobile_sdk/am2;

    if-eqz v3, :cond_39

    check-cast p1, Lads_mobile_sdk/am2;

    move v0, v1

    :goto_25
    if-ge v0, v2, :cond_4e

    iget-object v3, p0, Lads_mobile_sdk/am2;->b:[Ljava/lang/Object;

    aget-object v3, v3, v0

    iget-object v4, p1, Lads_mobile_sdk/am2;->b:[Ljava/lang/Object;

    aget-object v4, v4, v0

    invoke-virtual {v3, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_36

    goto :goto_4a

    :cond_36
    add-int/lit8 v0, v0, 0x1

    goto :goto_25

    :cond_39
    move p1, v1

    :goto_3a
    if-ge p1, v2, :cond_4e

    iget-object v3, p0, Lads_mobile_sdk/am2;->b:[Ljava/lang/Object;

    aget-object v3, v3, p1

    invoke-interface {v0, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4b

    :goto_4a
    return v1

    :cond_4b
    add-int/lit8 p1, p1, 0x1

    goto :goto_3a

    :cond_4e
    :goto_4e
    const/4 p0, 0x1

    return p0
.end method

.method public final get(I)Ljava/lang/Object;
    .registers 3

    .prologue
    if-ltz p1, :cond_b

    iget v0, p0, Lads_mobile_sdk/am2;->c:I

    if-ge p1, v0, :cond_b

    iget-object p0, p0, Lads_mobile_sdk/am2;->b:[Ljava/lang/Object;

    aget-object p0, p0, p1

    return-object p0

    :cond_b
    invoke-virtual {p0, p1}, Lads_mobile_sdk/am2;->c(I)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lvx2;->n(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public final hashCode()I
    .registers 5

    .prologue
    iget v0, p0, Lads_mobile_sdk/am2;->c:I

    const/4 v1, 0x1

    const/4 v2, 0x0

    :goto_4
    if-ge v2, v0, :cond_14

    mul-int/lit8 v1, v1, 0x1f

    iget-object v3, p0, Lads_mobile_sdk/am2;->b:[Ljava/lang/Object;

    aget-object v3, v3, v2

    invoke-virtual {v3}, Ljava/lang/Object;->hashCode()I

    move-result v3

    add-int/2addr v1, v3

    add-int/lit8 v2, v2, 0x1

    goto :goto_4

    :cond_14
    return v1
.end method

.method public final remove(I)Ljava/lang/Object;
    .registers 6

    .prologue
    invoke-virtual {p0}, Lads_mobile_sdk/j;->a()V

    if-ltz p1, :cond_26

    iget v0, p0, Lads_mobile_sdk/am2;->c:I

    if-ge p1, v0, :cond_26

    iget-object v1, p0, Lads_mobile_sdk/am2;->b:[Ljava/lang/Object;

    aget-object v2, v1, p1

    add-int/lit8 v3, v0, -0x1

    if-ge p1, v3, :cond_19

    add-int/lit8 v3, p1, 0x1

    sub-int/2addr v0, p1

    add-int/lit8 v0, v0, -0x1

    invoke-static {v1, v3, v1, p1, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    :cond_19
    iget p1, p0, Lads_mobile_sdk/am2;->c:I

    add-int/lit8 p1, p1, -0x1

    iput p1, p0, Lads_mobile_sdk/am2;->c:I

    iget p1, p0, Ljava/util/AbstractList;->modCount:I

    add-int/lit8 p1, p1, 0x1

    iput p1, p0, Ljava/util/AbstractList;->modCount:I

    return-object v2

    :cond_26
    invoke-virtual {p0, p1}, Lads_mobile_sdk/am2;->c(I)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lvx2;->n(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public final set(ILjava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .prologue
    invoke-virtual {p0}, Lads_mobile_sdk/j;->a()V

    if-ltz p1, :cond_16

    iget v0, p0, Lads_mobile_sdk/am2;->c:I

    if-ge p1, v0, :cond_16

    iget-object v0, p0, Lads_mobile_sdk/am2;->b:[Ljava/lang/Object;

    aget-object v1, v0, p1

    aput-object p2, v0, p1

    iget p1, p0, Ljava/util/AbstractList;->modCount:I

    add-int/lit8 p1, p1, 0x1

    iput p1, p0, Ljava/util/AbstractList;->modCount:I

    return-object v1

    :cond_16
    invoke-virtual {p0, p1}, Lads_mobile_sdk/am2;->c(I)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lvx2;->n(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public final size()I
    .registers 1

    iget p0, p0, Lads_mobile_sdk/am2;->c:I

    return p0
.end method
