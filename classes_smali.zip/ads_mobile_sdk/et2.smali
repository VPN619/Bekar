.class public final Lads_mobile_sdk/et2;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Lads_mobile_sdk/a2;

.field public b:I

.field public final c:J

.field public final d:Ljava/lang/Integer;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/a2;IJLjava/lang/Integer;)V
    .registers 6

    .prologue
    if-eqz p2, :cond_e

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/et2;->a:Lads_mobile_sdk/a2;

    iput p2, p0, Lads_mobile_sdk/et2;->b:I

    iput-wide p3, p0, Lads_mobile_sdk/et2;->c:J

    iput-object p5, p0, Lads_mobile_sdk/et2;->d:Ljava/lang/Integer;

    return-void

    :cond_e
    const/4 p0, 0x0

    throw p0
.end method


# virtual methods
.method public final toString()Ljava/lang/String;
    .registers 5

    iget v0, p0, Lads_mobile_sdk/et2;->b:I

    iget-wide v1, p0, Lads_mobile_sdk/et2;->c:J

    iget-object v3, p0, Lads_mobile_sdk/et2;->d:Ljava/lang/Integer;

    iget-object p0, p0, Lads_mobile_sdk/et2;->a:Lads_mobile_sdk/a2;

    invoke-static {p0, v0, v1, v2, v3}, Llk;->c(Lads_mobile_sdk/a2;IJLjava/lang/Integer;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
