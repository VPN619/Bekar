.class public final Lads_mobile_sdk/bk;
.super Lwx;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public a:Lads_mobile_sdk/ek;

.field public b:Ljava/lang/String;

.field public c:Ljava/lang/String;

.field public d:Lnb1;

.field public synthetic e:Ljava/lang/Object;

.field public final synthetic f:Lads_mobile_sdk/ek;

.field public g:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/ek;Lvx;)V
    .registers 3

    iput-object p1, p0, Lads_mobile_sdk/bk;->f:Lads_mobile_sdk/ek;

    invoke-direct {p0, p2}, Lwx;-><init>(Lvx;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    iput-object p1, p0, Lads_mobile_sdk/bk;->e:Ljava/lang/Object;

    iget p1, p0, Lads_mobile_sdk/bk;->g:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, Lads_mobile_sdk/bk;->g:I

    iget-object p1, p0, Lads_mobile_sdk/bk;->f:Lads_mobile_sdk/ek;

    const/4 v0, 0x0

    invoke-static {p1, v0, v0, p0}, Lads_mobile_sdk/ek;->a(Lads_mobile_sdk/ek;Ljava/lang/String;Ljava/lang/String;Lvx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
