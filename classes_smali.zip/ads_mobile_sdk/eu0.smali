.class public final Lads_mobile_sdk/eu0;
.super Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lads_mobile_sdk/eu0;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field public final a:I

.field public b:Lads_mobile_sdk/pd;

.field public c:[B


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Ls2;

    const/16 v1, 0x1d

    invoke-direct {v0, v1}, Ls2;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/eu0;->CREATOR:Landroid/os/Parcelable$Creator;

    return-void
.end method

.method public constructor <init>(I[B)V
    .registers 3

    invoke-direct {p0}, Lcom/google/android/gms/common/internal/safeparcel/AbstractSafeParcelable;-><init>()V

    iput p1, p0, Lads_mobile_sdk/eu0;->a:I

    const/4 p1, 0x0

    iput-object p1, p0, Lads_mobile_sdk/eu0;->b:Lads_mobile_sdk/pd;

    iput-object p2, p0, Lads_mobile_sdk/eu0;->c:[B

    invoke-virtual {p0}, Lads_mobile_sdk/eu0;->a()V

    return-void
.end method


# virtual methods
.method public final a()V
    .registers 3

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/eu0;->b:Lads_mobile_sdk/pd;

    if-nez v0, :cond_9

    iget-object v1, p0, Lads_mobile_sdk/eu0;->c:[B

    if-eqz v1, :cond_9

    goto :goto_f

    :cond_9
    if-eqz v0, :cond_10

    iget-object v1, p0, Lads_mobile_sdk/eu0;->c:[B

    if-nez v1, :cond_10

    :goto_f
    return-void

    :cond_10
    if-eqz v0, :cond_1d

    iget-object v1, p0, Lads_mobile_sdk/eu0;->c:[B

    if-nez v1, :cond_17

    goto :goto_1d

    :cond_17
    const-string p0, "Invalid internal representation - full"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-void

    :cond_1d
    :goto_1d
    if-nez v0, :cond_29

    iget-object p0, p0, Lads_mobile_sdk/eu0;->c:[B

    if-nez p0, :cond_29

    const-string p0, "Invalid internal representation - empty"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-void

    :cond_29
    const-string p0, "Impossible"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-void
.end method

.method public final writeToParcel(Landroid/os/Parcel;I)V
    .registers 5

    .prologue
    invoke-static {p1}, Lcom/google/android/gms/common/internal/safeparcel/SafeParcelWriter;->beginObjectHeader(Landroid/os/Parcel;)I

    move-result p2

    iget v0, p0, Lads_mobile_sdk/eu0;->a:I

    const/4 v1, 0x1

    invoke-static {p1, v1, v0}, Lcom/google/android/gms/common/internal/safeparcel/SafeParcelWriter;->writeInt(Landroid/os/Parcel;II)V

    iget-object v0, p0, Lads_mobile_sdk/eu0;->c:[B

    if-eqz v0, :cond_f

    goto :goto_15

    :cond_f
    iget-object p0, p0, Lads_mobile_sdk/eu0;->b:Lads_mobile_sdk/pd;

    invoke-virtual {p0}, Lads_mobile_sdk/g;->a()[B

    move-result-object v0

    :goto_15
    const/4 p0, 0x0

    const/4 v1, 0x2

    invoke-static {p1, v1, v0, p0}, Lcom/google/android/gms/common/internal/safeparcel/SafeParcelWriter;->writeByteArray(Landroid/os/Parcel;I[BZ)V

    invoke-static {p1, p2}, Lcom/google/android/gms/common/internal/safeparcel/SafeParcelWriter;->finishObjectHeader(Landroid/os/Parcel;I)V

    return-void
.end method
