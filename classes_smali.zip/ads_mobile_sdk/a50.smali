.class public final Lads_mobile_sdk/a50;
.super Lads_mobile_sdk/ku0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field private static final DEFAULT_INSTANCE:Lads_mobile_sdk/a50;

.field public static final c:I = 0x1

.field public static final d:I = 0x2


# instance fields
.field private bitField0_:I

.field private memoizedIsInitialized:B

.field private name_:Lads_mobile_sdk/hr;

.field private value_:Lads_mobile_sdk/hr;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lads_mobile_sdk/a50;

    invoke-direct {v0}, Lads_mobile_sdk/a50;-><init>()V

    sput-object v0, Lads_mobile_sdk/a50;->DEFAULT_INSTANCE:Lads_mobile_sdk/a50;

    const-class v1, Lads_mobile_sdk/a50;

    invoke-static {v1, v0}, Lads_mobile_sdk/ku0;->a(Ljava/lang/Class;Lads_mobile_sdk/ku0;)V

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Lads_mobile_sdk/ku0;-><init>()V

    const/4 v0, 0x2

    iput-byte v0, p0, Lads_mobile_sdk/a50;->memoizedIsInitialized:B

    sget-object v0, Lads_mobile_sdk/hr;->b:Lads_mobile_sdk/fr;

    iput-object v0, p0, Lads_mobile_sdk/a50;->name_:Lads_mobile_sdk/hr;

    iput-object v0, p0, Lads_mobile_sdk/a50;->value_:Lads_mobile_sdk/hr;

    return-void
.end method

.method public static o()Lv73;
    .registers 1

    sget-object v0, Lads_mobile_sdk/a50;->DEFAULT_INSTANCE:Lads_mobile_sdk/a50;

    invoke-virtual {v0}, Lads_mobile_sdk/ku0;->e()Lads_mobile_sdk/iu0;

    move-result-object v0

    check-cast v0, Lv73;

    return-object v0
.end method


# virtual methods
.method public final a(ILads_mobile_sdk/ku0;)Ljava/lang/Object;
    .registers 4

    .prologue
    invoke-static {p1}, Lvr0;->a(I)I

    move-result p1

    const/4 v0, 0x0

    packed-switch p1, :pswitch_data_46

    throw v0

    :pswitch_9  #0x6
    const-class p0, Lads_mobile_sdk/a50;

    invoke-static {p0}, Lads_mobile_sdk/ku0;->b(Ljava/lang/Class;)Lads_mobile_sdk/ju0;

    move-result-object p0

    return-object p0

    :pswitch_10  #0x5
    sget-object p0, Lads_mobile_sdk/a50;->DEFAULT_INSTANCE:Lads_mobile_sdk/a50;

    return-object p0

    :pswitch_13  #0x4
    new-instance p0, Lv73;

    sget-object p1, Lads_mobile_sdk/a50;->DEFAULT_INSTANCE:Lads_mobile_sdk/a50;

    invoke-direct {p0, p1}, Lads_mobile_sdk/iu0;-><init>(Lads_mobile_sdk/ku0;)V

    return-object p0

    :pswitch_1b  #0x3
    new-instance p0, Lads_mobile_sdk/a50;

    invoke-direct {p0}, Lads_mobile_sdk/a50;-><init>()V

    return-object p0

    :pswitch_21  #0x2
    const-string p0, "name_"

    const-string p1, "value_"

    const-string p2, "bitField0_"

    filled-new-array {p2, p0, p1}, [Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lads_mobile_sdk/a50;->DEFAULT_INSTANCE:Lads_mobile_sdk/a50;

    new-instance p2, Lads_mobile_sdk/zq2;

    const-string v0, "\u0001\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0001\u0001ᔊ\u0000\u0002ည\u0001"

    invoke-direct {p2, p1, v0, p0}, Lads_mobile_sdk/zq2;-><init>(Lads_mobile_sdk/ku0;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object p2

    :pswitch_35  #0x1
    if-nez p2, :cond_39

    const/4 p1, 0x0

    goto :goto_3a

    :cond_39
    const/4 p1, 0x1

    :goto_3a
    int-to-byte p1, p1

    iput-byte p1, p0, Lads_mobile_sdk/a50;->memoizedIsInitialized:B

    return-object v0

    :pswitch_3e  #0x0
    iget-byte p0, p0, Lads_mobile_sdk/a50;->memoizedIsInitialized:B

    invoke-static {p0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_46
    .packed-switch 0x0
        :pswitch_3e  #00000000
        :pswitch_35  #00000001
        :pswitch_21  #00000002
        :pswitch_1b  #00000003
        :pswitch_13  #00000004
        :pswitch_10  #00000005
        :pswitch_9  #00000006
    .end packed-switch
.end method

.method public final a(Lads_mobile_sdk/fr;)V
    .registers 3

    iget v0, p0, Lads_mobile_sdk/a50;->bitField0_:I

    or-int/lit8 v0, v0, 0x1

    iput v0, p0, Lads_mobile_sdk/a50;->bitField0_:I

    iput-object p1, p0, Lads_mobile_sdk/a50;->name_:Lads_mobile_sdk/hr;

    return-void
.end method

.method public final b(Lads_mobile_sdk/fr;)V
    .registers 3

    iget v0, p0, Lads_mobile_sdk/a50;->bitField0_:I

    or-int/lit8 v0, v0, 0x2

    iput v0, p0, Lads_mobile_sdk/a50;->bitField0_:I

    iput-object p1, p0, Lads_mobile_sdk/a50;->value_:Lads_mobile_sdk/hr;

    return-void
.end method
