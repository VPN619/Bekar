.class public final Lads_mobile_sdk/bn2;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lrk0;


# instance fields
.field public a:I

.field public synthetic b:Lhf0;

.field public synthetic c:Ljava/lang/Throwable;

.field public final synthetic d:Lads_mobile_sdk/on2;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/on2;Lvx;)V
    .registers 3

    iput-object p1, p0, Lads_mobile_sdk/bn2;->d:Lads_mobile_sdk/on2;

    const/4 p1, 0x3

    invoke-direct {p0, p1, p2}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    check-cast p1, Lhf0;

    check-cast p2, Ljava/lang/Throwable;

    check-cast p3, Lvx;

    new-instance v0, Lads_mobile_sdk/bn2;

    iget-object p0, p0, Lads_mobile_sdk/bn2;->d:Lads_mobile_sdk/on2;

    invoke-direct {v0, p0, p3}, Lads_mobile_sdk/bn2;-><init>(Lads_mobile_sdk/on2;Lvx;)V

    iput-object p1, v0, Lads_mobile_sdk/bn2;->b:Lhf0;

    iput-object p2, v0, Lads_mobile_sdk/bn2;->c:Ljava/lang/Throwable;

    sget-object p0, Lrg2;->a:Lrg2;

    invoke-virtual {v0, p0}, Lads_mobile_sdk/bn2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 10

    .prologue
    iget v0, p0, Lads_mobile_sdk/bn2;->a:I

    iget-object v1, p0, Lads_mobile_sdk/bn2;->d:Lads_mobile_sdk/on2;

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    sget-object v5, Lwy;->a:Lwy;

    if-eqz v0, :cond_21

    if-eq v0, v3, :cond_19

    if-ne v0, v2, :cond_13

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_66

    :cond_13
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v4

    :cond_19
    iget-object v0, p0, Lads_mobile_sdk/bn2;->c:Ljava/lang/Throwable;

    iget-object v3, p0, Lads_mobile_sdk/bn2;->b:Lhf0;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_3b

    :cond_21
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/bn2;->b:Lhf0;

    iget-object v0, p0, Lads_mobile_sdk/bn2;->c:Ljava/lang/Throwable;

    const-string v6, "Ad failed to load"

    invoke-static {v6, v0}, Lads_mobile_sdk/nw;->b(Ljava/lang/String;Ljava/lang/Throwable;)V

    iput-object p1, p0, Lads_mobile_sdk/bn2;->b:Lhf0;

    iput-object v0, p0, Lads_mobile_sdk/bn2;->c:Ljava/lang/Throwable;

    iput v3, p0, Lads_mobile_sdk/bn2;->a:I

    invoke-virtual {v1, p0}, Lads_mobile_sdk/on2;->c(Lwx;)Ljava/lang/Object;

    move-result-object v3

    if-ne v3, v5, :cond_3a

    goto :goto_65

    :cond_3a
    move-object v3, p1

    :goto_3b
    new-instance p1, Lads_mobile_sdk/bv0;

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-direct {p1, v7, v4, v0, v6}, Lads_mobile_sdk/bv0;-><init>(ILjava/lang/String;Ljava/lang/Throwable;I)V

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lq31;

    iget v1, p1, Lads_mobile_sdk/bv0;->d:I

    invoke-static {v1}, Ly41;->_a(I)Lp31;

    move-result-object v1

    invoke-static {p1}, Lq23;->h(Lads_mobile_sdk/av0;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, v1, p1, v4}, Lq31;-><init>(Lp31;Ljava/lang/String;Llu1;)V

    new-instance p1, Lads_mobile_sdk/pn2;

    invoke-direct {p1, v0}, Lads_mobile_sdk/pn2;-><init>(Lq31;)V

    iput-object v4, p0, Lads_mobile_sdk/bn2;->b:Lhf0;

    iput-object v4, p0, Lads_mobile_sdk/bn2;->c:Ljava/lang/Throwable;

    iput v2, p0, Lads_mobile_sdk/bn2;->a:I

    invoke-interface {v3, p1, p0}, Lhf0;->emit(Ljava/lang/Object;Lvx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_66

    :goto_65
    return-object v5

    :cond_66
    :goto_66
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method
