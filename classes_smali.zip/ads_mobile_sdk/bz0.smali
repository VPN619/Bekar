.class public final Lads_mobile_sdk/bz0;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Loj2;


# instance fields
.field public final a:Lvy;

.field public final b:Lads_mobile_sdk/cy0;

.field public final e:Lbt;

.field public final f:Ljava/lang/Object;

.field public h:F

.field public i:I

.field public k:Z

.field public m:Z


# direct methods
.method public constructor <init>(Lvy;Lads_mobile_sdk/cy0;)V
    .registers 3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/bz0;->a:Lvy;

    iput-object p2, p0, Lads_mobile_sdk/bz0;->b:Lads_mobile_sdk/cy0;

    new-instance p1, Lbt;

    invoke-direct {p1}, Lbt;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/bz0;->e:Lbt;

    new-instance p1, Ljava/lang/Object;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/bz0;->f:Ljava/lang/Object;

    const/4 p1, 0x1

    iput p1, p0, Lads_mobile_sdk/bz0;->i:I

    iput-boolean p1, p0, Lads_mobile_sdk/bz0;->m:Z

    return-void
.end method


# virtual methods
.method public final a(Lpj2;Lwx;)Ljava/lang/Object;
    .registers 7

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/bz0;->f:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    sget-object v1, Lrg2;->a:Lrg2;
    :try_end_5
    .catchall {:try_start_3 .. :try_end_5} :catchall_4e

    monitor-exit v0

    new-instance v0, Lfx0;

    invoke-direct {v0}, Lfx0;-><init>()V

    const-string v2, "muteStart"

    iget-boolean v3, p1, Lpj2;->a:Z

    if-eqz v3, :cond_14

    const-string v3, "1"

    goto :goto_16

    :cond_14
    const-string v3, "0"

    :goto_16
    invoke-virtual {v0, v2, v3}, Lfx0;->s(Ljava/lang/String;Ljava/lang/String;)V

    const-string v2, "customControlsRequested"

    iget-boolean v3, p1, Lpj2;->b:Z

    if-eqz v3, :cond_22

    const-string v3, "1"

    goto :goto_24

    :cond_22
    const-string v3, "0"

    :goto_24
    invoke-virtual {v0, v2, v3}, Lfx0;->s(Ljava/lang/String;Ljava/lang/String;)V

    const-string v2, "clickToExpandRequested"

    iget-boolean p1, p1, Lpj2;->c:Z

    if-eqz p1, :cond_30

    const-string p1, "1"

    goto :goto_32

    :cond_30
    const-string p1, "0"

    :goto_32
    invoke-virtual {v0, v2, p1}, Lfx0;->s(Ljava/lang/String;Ljava/lang/String;)V

    const-string p1, "initialState"

    const-string v2, "action"

    invoke-virtual {v0, v2, p1}, Lfx0;->s(Ljava/lang/String;Ljava/lang/String;)V

    iget-object p0, p0, Lads_mobile_sdk/bz0;->b:Lads_mobile_sdk/cy0;

    const-string p1, "pubVideoCmd"

    invoke-virtual {p0, v0, p1, p2}, Lads_mobile_sdk/cy0;->a(Lfx0;Ljava/lang/String;Lvx;)Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lwy;->a:Lwy;

    if-ne p0, p1, :cond_49

    goto :goto_4a

    :cond_49
    move-object p0, v1

    :goto_4a
    if-ne p0, p1, :cond_4d

    return-object p0

    :cond_4d
    return-object v1

    :catchall_4e
    move-exception p0

    monitor-exit v0

    throw p0
.end method

.method public final a(FIZ)V
    .registers 14

    .prologue
    const/4 v0, 0x0

    if-eqz p2, :cond_4a

    iget-object v1, p0, Lads_mobile_sdk/bz0;->f:Ljava/lang/Object;

    monitor-enter v1

    :try_start_6
    iget-object v2, p0, Lads_mobile_sdk/bz0;->f:Ljava/lang/Object;

    monitor-enter v2
    :try_end_9
    .catchall {:try_start_6 .. :try_end_9} :catchall_2c

    :try_start_9
    iget-boolean v7, p0, Lads_mobile_sdk/bz0;->m:Z
    :try_end_b
    .catchall {:try_start_9 .. :try_end_b} :catchall_44

    :try_start_b
    monitor-exit v2

    iget-object v2, p0, Lads_mobile_sdk/bz0;->f:Ljava/lang/Object;

    monitor-enter v2
    :try_end_f
    .catchall {:try_start_b .. :try_end_f} :catchall_2c

    :try_start_f
    iput-boolean p3, p0, Lads_mobile_sdk/bz0;->m:Z
    :try_end_11
    .catchall {:try_start_f .. :try_end_11} :catchall_40

    :try_start_11
    monitor-exit v2

    iget v5, p0, Lads_mobile_sdk/bz0;->i:I

    iput p2, p0, Lads_mobile_sdk/bz0;->i:I

    iget v2, p0, Lads_mobile_sdk/bz0;->h:F

    iput p1, p0, Lads_mobile_sdk/bz0;->h:F

    sub-float/2addr p1, v2

    invoke-static {p1}, Ljava/lang/Math;->abs(F)F

    move-result p1

    const v2, 0x38d1b717  # 1.0E-4f

    cmpl-float p1, p1, v2

    if-lez p1, :cond_2f

    iget-object p1, p0, Lads_mobile_sdk/bz0;->b:Lads_mobile_sdk/cy0;

    invoke-virtual {p1}, Landroid/view/View;->invalidate()V

    goto :goto_2f

    :catchall_2c
    move-exception v0

    move-object p0, v0

    goto :goto_48

    :cond_2f
    :goto_2f
    iget-object p1, p0, Lads_mobile_sdk/bz0;->a:Lvy;

    new-instance v3, Lads_mobile_sdk/wy0;

    const/4 v9, 0x0

    move-object v4, p0

    move v6, p2

    move v8, p3

    invoke-direct/range {v3 .. v9}, Lads_mobile_sdk/wy0;-><init>(Lads_mobile_sdk/bz0;IIZZLvx;)V

    const/4 p0, 0x3

    invoke-static {p1, v0, v0, v3, p0}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;
    :try_end_3e
    .catchall {:try_start_11 .. :try_end_3e} :catchall_2c

    monitor-exit v1

    return-void

    :catchall_40
    move-exception v0

    move-object p0, v0

    :try_start_42
    monitor-exit v2

    throw p0

    :catchall_44
    move-exception v0

    move-object p0, v0

    monitor-exit v2

    throw p0
    :try_end_48
    .catchall {:try_start_42 .. :try_end_48} :catchall_2c

    :goto_48
    monitor-exit v1

    throw p0

    :cond_4a
    throw v0
.end method

.method public final getVideoLifecycleCallbacks()V
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/bz0;->f:Ljava/lang/Object;

    monitor-enter p0

    monitor-exit p0

    return-void
.end method
