.class public final Lads_mobile_sdk/e41;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lo23;


# instance fields
.field public final a:Lads_mobile_sdk/ek;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/ek;)V
    .registers 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/e41;->a:Lads_mobile_sdk/ek;

    return-void
.end method


# virtual methods
.method public final a()Lads_mobile_sdk/lw0;
    .registers 1

    sget-object p0, Lads_mobile_sdk/lw0;->B:Lads_mobile_sdk/lw0;

    return-object p0
.end method

.method public final d(Lvx;)Ljava/lang/Object;
    .registers 6

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/d41;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/d41;

    iget v1, v0, Lads_mobile_sdk/d41;->c:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/d41;->c:I

    goto :goto_1a

    :cond_13
    new-instance v0, Lads_mobile_sdk/d41;

    check-cast p1, Lwx;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/d41;-><init>(Lads_mobile_sdk/e41;Lwx;)V

    :goto_1a
    iget-object p1, v0, Lads_mobile_sdk/d41;->a:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/d41;->c:I

    const/4 v2, 0x1

    if-eqz v1, :cond_2e

    if-ne v1, v2, :cond_27

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_41

    :cond_27
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0

    :cond_2e
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iput v2, v0, Lads_mobile_sdk/d41;->c:I

    iget-object p0, p0, Lads_mobile_sdk/e41;->a:Lads_mobile_sdk/ek;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p0, v0}, Lads_mobile_sdk/ek;->a(Lads_mobile_sdk/ek;Lwx;)Ljava/lang/Object;

    move-result-object p1

    sget-object p0, Lwy;->a:Lwy;

    if-ne p1, p0, :cond_41

    return-object p0

    :cond_41
    :goto_41
    check-cast p1, Ljava/util/Map;

    new-instance p0, Lads_mobile_sdk/c41;

    invoke-direct {p0, p1}, Lads_mobile_sdk/c41;-><init>(Ljava/util/Map;)V

    new-instance p1, Lads_mobile_sdk/hv0;

    invoke-direct {p1, p0}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    return-object p1
.end method
