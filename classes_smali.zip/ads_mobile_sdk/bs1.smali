.class public final Lads_mobile_sdk/bs1;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public a:Ljava/lang/String;

.field public b:Lads_mobile_sdk/cs1;

.field public c:Lads_mobile_sdk/cy0;

.field public d:Ljava/lang/String;

.field public e:Ljava/lang/String;

.field public f:Landroid/content/Context;

.field public g:Lads_mobile_sdk/rg3;

.field public h:Lads_mobile_sdk/rg3;

.field public i:I

.field public final synthetic j:Lads_mobile_sdk/cs1;

.field public final synthetic k:Ljava/lang/String;

.field public final synthetic l:Lads_mobile_sdk/cy0;

.field public final synthetic m:Ljava/lang/String;

.field public final synthetic n:Ljava/lang/String;

.field public final synthetic o:Landroid/content/Context;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/cs1;Ljava/lang/String;Lads_mobile_sdk/cy0;Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;Lvx;)V
    .registers 8

    iput-object p1, p0, Lads_mobile_sdk/bs1;->j:Lads_mobile_sdk/cs1;

    iput-object p2, p0, Lads_mobile_sdk/bs1;->k:Ljava/lang/String;

    iput-object p3, p0, Lads_mobile_sdk/bs1;->l:Lads_mobile_sdk/cy0;

    iput-object p4, p0, Lads_mobile_sdk/bs1;->m:Ljava/lang/String;

    iput-object p5, p0, Lads_mobile_sdk/bs1;->n:Ljava/lang/String;

    iput-object p6, p0, Lads_mobile_sdk/bs1;->o:Landroid/content/Context;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p7}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 11

    new-instance v0, Lads_mobile_sdk/bs1;

    iget-object v5, p0, Lads_mobile_sdk/bs1;->n:Ljava/lang/String;

    iget-object v6, p0, Lads_mobile_sdk/bs1;->o:Landroid/content/Context;

    iget-object v1, p0, Lads_mobile_sdk/bs1;->j:Lads_mobile_sdk/cs1;

    iget-object v2, p0, Lads_mobile_sdk/bs1;->k:Ljava/lang/String;

    iget-object v3, p0, Lads_mobile_sdk/bs1;->l:Lads_mobile_sdk/cy0;

    iget-object v4, p0, Lads_mobile_sdk/bs1;->m:Ljava/lang/String;

    move-object v7, p1

    invoke-direct/range {v0 .. v7}, Lads_mobile_sdk/bs1;-><init>(Lads_mobile_sdk/cs1;Ljava/lang/String;Lads_mobile_sdk/cy0;Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;Lvx;)V

    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    invoke-virtual {p0, p2, p1}, Lads_mobile_sdk/bs1;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/bs1;

    sget-object p1, Lrg2;->a:Lrg2;

    invoke-virtual {p0, p1}, Lads_mobile_sdk/bs1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 25

    .prologue
    move-object/from16 v0, p0

    sget-object v1, Lrg2;->a:Lrg2;

    sget-object v2, Lwy;->a:Lwy;

    iget v3, v0, Lads_mobile_sdk/bs1;->i:I

    const-string v4, ", no responseBody"

    const/4 v5, 0x2

    const/4 v6, 0x1

    const-string v7, "Could not store picture: "

    const-string v8, "Unable to download image: "

    const/4 v9, 0x0

    if-eqz v3, :cond_66

    if-eq v3, v6, :cond_42

    if-ne v3, v5, :cond_3c

    iget-object v2, v0, Lads_mobile_sdk/bs1;->h:Lads_mobile_sdk/rg3;

    iget-object v3, v0, Lads_mobile_sdk/bs1;->g:Lads_mobile_sdk/rg3;

    iget-object v5, v0, Lads_mobile_sdk/bs1;->f:Landroid/content/Context;

    iget-object v10, v0, Lads_mobile_sdk/bs1;->e:Ljava/lang/String;

    iget-object v11, v0, Lads_mobile_sdk/bs1;->d:Ljava/lang/String;

    iget-object v12, v0, Lads_mobile_sdk/bs1;->c:Lads_mobile_sdk/cy0;

    iget-object v13, v0, Lads_mobile_sdk/bs1;->b:Lads_mobile_sdk/cs1;

    iget-object v0, v0, Lads_mobile_sdk/bs1;->a:Ljava/lang/String;

    :try_start_27
    invoke-static/range {p1 .. p1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_2a
    .catch Ljava/lang/Exception; {:try_start_27 .. :try_end_2a} :catch_37
    .catchall {:try_start_27 .. :try_end_2a} :catchall_1d8

    move-object v14, v0

    move-object/from16 v16, v1

    move-object/from16 v21, v5

    move-object/from16 v20, v10

    move-object/from16 v19, v11

    move-object/from16 v0, p1

    goto/16 :goto_1bf

    :catch_37
    move-exception v0

    move-object/from16 v16, v1

    goto/16 :goto_22d

    :cond_3c
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {v0}, Lz6;->w(Ljava/lang/String;)V

    return-object v9

    :cond_42
    iget-object v2, v0, Lads_mobile_sdk/bs1;->h:Lads_mobile_sdk/rg3;

    iget-object v3, v0, Lads_mobile_sdk/bs1;->g:Lads_mobile_sdk/rg3;

    iget-object v5, v0, Lads_mobile_sdk/bs1;->f:Landroid/content/Context;

    iget-object v10, v0, Lads_mobile_sdk/bs1;->e:Ljava/lang/String;

    iget-object v11, v0, Lads_mobile_sdk/bs1;->d:Ljava/lang/String;

    iget-object v12, v0, Lads_mobile_sdk/bs1;->c:Lads_mobile_sdk/cy0;

    iget-object v13, v0, Lads_mobile_sdk/bs1;->b:Lads_mobile_sdk/cs1;

    iget-object v0, v0, Lads_mobile_sdk/bs1;->a:Ljava/lang/String;

    :try_start_52
    invoke-static/range {p1 .. p1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_55
    .catch Ljava/lang/Exception; {:try_start_52 .. :try_end_55} :catch_61
    .catchall {:try_start_52 .. :try_end_55} :catchall_db

    move-object v14, v0

    move-object/from16 v16, v1

    move-object/from16 v21, v5

    move-object/from16 v20, v10

    move-object/from16 v19, v11

    move-object/from16 v0, p1

    goto :goto_c2

    :catch_61
    move-exception v0

    move-object/from16 v16, v1

    goto/16 :goto_130

    :cond_66
    invoke-static/range {p1 .. p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object v13, v0, Lads_mobile_sdk/bs1;->j:Lads_mobile_sdk/cs1;

    iget-object v3, v13, Lads_mobile_sdk/cs1;->g:Lads_mobile_sdk/ux2;

    sget-object v10, Lads_mobile_sdk/fw0;->X0:Lads_mobile_sdk/fw0;

    sget-object v11, Lba0;->a:Lba0;

    iget-object v12, v13, Lads_mobile_sdk/cs1;->h:Lads_mobile_sdk/kh3;

    iget-object v14, v0, Lads_mobile_sdk/bs1;->k:Ljava/lang/String;

    iget-object v15, v0, Lads_mobile_sdk/bs1;->l:Lads_mobile_sdk/cy0;

    iget-object v5, v0, Lads_mobile_sdk/bs1;->m:Ljava/lang/String;

    iget-object v9, v0, Lads_mobile_sdk/bs1;->n:Ljava/lang/String;

    iget-object v6, v0, Lads_mobile_sdk/bs1;->o:Landroid/content/Context;

    move-object/from16 v16, v1

    invoke-static {}, Lads_mobile_sdk/hh3;->b()Lads_mobile_sdk/gh3;

    move-result-object v1

    iget-object v1, v1, Lads_mobile_sdk/gh3;->a:Lads_mobile_sdk/rg3;

    move-object/from16 p1, v1

    const/16 v1, 0x1e

    if-nez p1, :cond_188

    invoke-static {v3, v10, v11, v12}, Lads_mobile_sdk/ux2;->a(Lads_mobile_sdk/ux2;Lads_mobile_sdk/fw0;Ljava/util/List;Lads_mobile_sdk/kh3;)Lads_mobile_sdk/wk2;

    move-result-object v3

    :try_start_8f
    new-instance v10, Ljava/net/URL;

    invoke-static {v14}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v11

    invoke-virtual {v11}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-direct {v10, v11}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    iget-object v11, v13, Lads_mobile_sdk/cs1;->e:Lq63;

    iput-object v14, v0, Lads_mobile_sdk/bs1;->a:Ljava/lang/String;

    iput-object v13, v0, Lads_mobile_sdk/bs1;->b:Lads_mobile_sdk/cs1;

    iput-object v15, v0, Lads_mobile_sdk/bs1;->c:Lads_mobile_sdk/cy0;

    iput-object v5, v0, Lads_mobile_sdk/bs1;->d:Ljava/lang/String;

    iput-object v9, v0, Lads_mobile_sdk/bs1;->e:Ljava/lang/String;

    iput-object v6, v0, Lads_mobile_sdk/bs1;->f:Landroid/content/Context;

    iput-object v3, v0, Lads_mobile_sdk/bs1;->g:Lads_mobile_sdk/rg3;

    iput-object v3, v0, Lads_mobile_sdk/bs1;->h:Lads_mobile_sdk/rg3;

    const/4 v12, 0x1

    iput v12, v0, Lads_mobile_sdk/bs1;->i:I

    const/4 v12, 0x0

    invoke-static {v11, v10, v12, v0, v1}, Lq63;->a(Lq63;Ljava/net/URL;Ljava/util/Map;Lwx;I)Ljava/lang/Object;

    move-result-object v0
    :try_end_b6
    .catch Ljava/lang/Exception; {:try_start_8f .. :try_end_b6} :catch_134
    .catchall {:try_start_8f .. :try_end_b6} :catchall_132

    if-ne v0, v2, :cond_ba

    goto/16 :goto_1b6

    :cond_ba
    move-object v2, v3

    move-object/from16 v19, v5

    move-object/from16 v21, v6

    move-object/from16 v20, v9

    move-object v12, v15

    :goto_c2
    :try_start_c2
    check-cast v0, Lb13;

    instance-of v1, v0, Lads_mobile_sdk/av0;
    :try_end_c6
    .catch Ljava/lang/Exception; {:try_start_c2 .. :try_end_c6} :catch_128
    .catchall {:try_start_c2 .. :try_end_c6} :catchall_db

    if-eqz v1, :cond_e0

    :try_start_c8
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v1, Lads_mobile_sdk/cs1;->i:Ljs1;

    const/4 v1, 0x1

    invoke-virtual {v13, v0, v12, v1}, Lads_mobile_sdk/cs1;->a(Ljava/lang/String;Lads_mobile_sdk/cy0;Z)V
    :try_end_da
    .catch Ljava/lang/Exception; {:try_start_c8 .. :try_end_da} :catch_de
    .catchall {:try_start_c8 .. :try_end_da} :catchall_db

    goto :goto_12e

    :catchall_db
    move-exception v0

    goto/16 :goto_151

    :catch_de
    move-exception v0

    goto :goto_130

    :cond_e0
    :try_start_e0
    instance-of v1, v0, Lads_mobile_sdk/hv0;

    if-eqz v1, :cond_12e

    check-cast v0, Lads_mobile_sdk/hv0;

    iget-object v0, v0, Lads_mobile_sdk/hv0;->b:Ljava/lang/Object;

    check-cast v0, Lads_mobile_sdk/j21;

    iget-object v0, v0, Lads_mobile_sdk/j21;->d:Lads_mobile_sdk/gv2;
    :try_end_ec
    .catch Ljava/lang/Exception; {:try_start_e0 .. :try_end_ec} :catch_128
    .catchall {:try_start_e0 .. :try_end_ec} :catchall_db

    if-eqz v0, :cond_f8

    :try_start_ee
    new-instance v1, Ljava/io/ByteArrayInputStream;

    iget-object v0, v0, Lads_mobile_sdk/gv2;->a:[B

    invoke-direct {v1, v0}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    move-object/from16 v18, v1

    goto :goto_fa

    :cond_f8
    const/16 v18, 0x0

    :goto_fa
    if-nez v18, :cond_112

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v1, Lads_mobile_sdk/cs1;->i:Ljs1;

    const/4 v1, 0x1

    invoke-virtual {v13, v0, v12, v1}, Lads_mobile_sdk/cs1;->a(Ljava/lang/String;Lads_mobile_sdk/cy0;Z)V
    :try_end_111
    .catch Ljava/lang/Exception; {:try_start_ee .. :try_end_111} :catch_de
    .catchall {:try_start_ee .. :try_end_111} :catchall_db

    goto :goto_12e

    :cond_112
    :try_start_112
    sget-object v0, Lads_mobile_sdk/cs1;->i:Ljs1;
    :try_end_114
    .catch Ljava/lang/Exception; {:try_start_112 .. :try_end_114} :catch_11e
    .catchall {:try_start_112 .. :try_end_114} :catchall_db

    move-object/from16 v22, v12

    move-object/from16 v17, v13

    :try_start_118
    invoke-virtual/range {v17 .. v22}, Lads_mobile_sdk/cs1;->a(Ljava/io/ByteArrayInputStream;Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;Lads_mobile_sdk/cy0;)V
    :try_end_11b
    .catch Ljava/lang/Exception; {:try_start_118 .. :try_end_11b} :catch_11c
    .catchall {:try_start_118 .. :try_end_11b} :catchall_db

    goto :goto_12e

    :catch_11c
    move-exception v0

    goto :goto_123

    :catch_11e
    move-exception v0

    move-object/from16 v22, v12

    move-object/from16 v17, v13

    :goto_123
    move-object/from16 v13, v17

    move-object/from16 v12, v22

    goto :goto_130

    :catch_128
    move-exception v0

    move-object/from16 v22, v12

    move-object/from16 v17, v13

    goto :goto_130

    :cond_12e
    :goto_12e
    const/4 v12, 0x0

    goto :goto_14c

    :goto_130
    move-object v15, v12

    goto :goto_139

    :catchall_132
    move-exception v0

    goto :goto_136

    :catch_134
    move-exception v0

    goto :goto_138

    :goto_136
    move-object v2, v3

    goto :goto_151

    :goto_138
    move-object v2, v3

    :goto_139
    :try_start_139
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v1, Lads_mobile_sdk/cs1;->i:Ljs1;

    const/4 v1, 0x1

    invoke-virtual {v13, v0, v15, v1}, Lads_mobile_sdk/cs1;->a(Ljava/lang/String;Lads_mobile_sdk/cy0;Z)V
    :try_end_14b
    .catchall {:try_start_139 .. :try_end_14b} :catchall_db

    goto :goto_12e

    :goto_14c
    invoke-static {v2, v12}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    goto/16 :goto_24c

    :goto_151
    :try_start_151
    invoke-virtual {v3, v0}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v1, v0, Lox2;

    if-nez v1, :cond_181

    invoke-virtual {v3, v0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of v1, v0, Lza2;

    if-nez v1, :cond_179

    instance-of v1, v0, Ljava/util/concurrent/CancellationException;

    if-nez v1, :cond_171

    instance-of v1, v0, Lads_mobile_sdk/mv0;

    if-eqz v1, :cond_16b

    throw v0

    :catchall_168
    move-exception v0

    move-object v1, v0

    goto :goto_182

    :cond_16b
    new-instance v1, Lads_mobile_sdk/tu0;

    invoke-direct {v1, v0}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw v1

    :cond_171
    new-instance v1, Lads_mobile_sdk/ou0;

    check-cast v0, Ljava/util/concurrent/CancellationException;

    invoke-direct {v1, v0}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw v1

    :cond_179
    new-instance v1, Lads_mobile_sdk/uw0;

    check-cast v0, Lza2;

    invoke-direct {v1, v0}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw v1

    :cond_181
    throw v0
    :try_end_182
    .catchall {:try_start_151 .. :try_end_182} :catchall_168

    :goto_182
    :try_start_182
    throw v1
    :try_end_183
    .catchall {:try_start_182 .. :try_end_183} :catchall_183

    :catchall_183
    move-exception v0

    invoke-static {v2, v1}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0

    :cond_188
    const/4 v12, 0x1

    invoke-static {v10, v11, v12}, Lads_mobile_sdk/hh3;->a(Lads_mobile_sdk/fw0;Ljava/util/List;Z)Lads_mobile_sdk/rg3;

    move-result-object v3

    :try_start_18d
    new-instance v10, Ljava/net/URL;

    invoke-static {v14}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v11

    invoke-virtual {v11}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-direct {v10, v11}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    iget-object v11, v13, Lads_mobile_sdk/cs1;->e:Lq63;

    iput-object v14, v0, Lads_mobile_sdk/bs1;->a:Ljava/lang/String;

    iput-object v13, v0, Lads_mobile_sdk/bs1;->b:Lads_mobile_sdk/cs1;

    iput-object v15, v0, Lads_mobile_sdk/bs1;->c:Lads_mobile_sdk/cy0;

    iput-object v5, v0, Lads_mobile_sdk/bs1;->d:Ljava/lang/String;

    iput-object v9, v0, Lads_mobile_sdk/bs1;->e:Ljava/lang/String;

    iput-object v6, v0, Lads_mobile_sdk/bs1;->f:Landroid/content/Context;

    iput-object v3, v0, Lads_mobile_sdk/bs1;->g:Lads_mobile_sdk/rg3;

    iput-object v3, v0, Lads_mobile_sdk/bs1;->h:Lads_mobile_sdk/rg3;

    const/4 v12, 0x2

    iput v12, v0, Lads_mobile_sdk/bs1;->i:I

    const/4 v12, 0x0

    invoke-static {v11, v10, v12, v0, v1}, Lq63;->a(Lq63;Ljava/net/URL;Ljava/util/Map;Lwx;I)Ljava/lang/Object;

    move-result-object v0
    :try_end_1b4
    .catch Ljava/lang/Exception; {:try_start_18d .. :try_end_1b4} :catch_231
    .catchall {:try_start_18d .. :try_end_1b4} :catchall_22f

    if-ne v0, v2, :cond_1b7

    :goto_1b6
    return-object v2

    :cond_1b7
    move-object v2, v3

    move-object/from16 v19, v5

    move-object/from16 v21, v6

    move-object/from16 v20, v9

    move-object v12, v15

    :goto_1bf
    :try_start_1bf
    check-cast v0, Lb13;

    instance-of v1, v0, Lads_mobile_sdk/av0;
    :try_end_1c3
    .catch Ljava/lang/Exception; {:try_start_1bf .. :try_end_1c3} :catch_225
    .catchall {:try_start_1bf .. :try_end_1c3} :catchall_1d8

    if-eqz v1, :cond_1dd

    :try_start_1c5
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v1, Lads_mobile_sdk/cs1;->i:Ljs1;

    const/4 v1, 0x1

    invoke-virtual {v13, v0, v12, v1}, Lads_mobile_sdk/cs1;->a(Ljava/lang/String;Lads_mobile_sdk/cy0;Z)V
    :try_end_1d7
    .catch Ljava/lang/Exception; {:try_start_1c5 .. :try_end_1d7} :catch_1db
    .catchall {:try_start_1c5 .. :try_end_1d7} :catchall_1d8

    goto :goto_22b

    :catchall_1d8
    move-exception v0

    goto/16 :goto_24d

    :catch_1db
    move-exception v0

    goto :goto_22d

    :cond_1dd
    :try_start_1dd
    instance-of v1, v0, Lads_mobile_sdk/hv0;

    if-eqz v1, :cond_22b

    check-cast v0, Lads_mobile_sdk/hv0;

    iget-object v0, v0, Lads_mobile_sdk/hv0;->b:Ljava/lang/Object;

    check-cast v0, Lads_mobile_sdk/j21;

    iget-object v0, v0, Lads_mobile_sdk/j21;->d:Lads_mobile_sdk/gv2;
    :try_end_1e9
    .catch Ljava/lang/Exception; {:try_start_1dd .. :try_end_1e9} :catch_225
    .catchall {:try_start_1dd .. :try_end_1e9} :catchall_1d8

    if-eqz v0, :cond_1f5

    :try_start_1eb
    new-instance v1, Ljava/io/ByteArrayInputStream;

    iget-object v0, v0, Lads_mobile_sdk/gv2;->a:[B

    invoke-direct {v1, v0}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    move-object/from16 v18, v1

    goto :goto_1f7

    :cond_1f5
    const/16 v18, 0x0

    :goto_1f7
    if-nez v18, :cond_20f

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v1, Lads_mobile_sdk/cs1;->i:Ljs1;

    const/4 v1, 0x1

    invoke-virtual {v13, v0, v12, v1}, Lads_mobile_sdk/cs1;->a(Ljava/lang/String;Lads_mobile_sdk/cy0;Z)V
    :try_end_20e
    .catch Ljava/lang/Exception; {:try_start_1eb .. :try_end_20e} :catch_1db
    .catchall {:try_start_1eb .. :try_end_20e} :catchall_1d8

    goto :goto_22b

    :cond_20f
    :try_start_20f
    sget-object v0, Lads_mobile_sdk/cs1;->i:Ljs1;
    :try_end_211
    .catch Ljava/lang/Exception; {:try_start_20f .. :try_end_211} :catch_21b
    .catchall {:try_start_20f .. :try_end_211} :catchall_1d8

    move-object/from16 v22, v12

    move-object/from16 v17, v13

    :try_start_215
    invoke-virtual/range {v17 .. v22}, Lads_mobile_sdk/cs1;->a(Ljava/io/ByteArrayInputStream;Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;Lads_mobile_sdk/cy0;)V
    :try_end_218
    .catch Ljava/lang/Exception; {:try_start_215 .. :try_end_218} :catch_219
    .catchall {:try_start_215 .. :try_end_218} :catchall_1d8

    goto :goto_22b

    :catch_219
    move-exception v0

    goto :goto_220

    :catch_21b
    move-exception v0

    move-object/from16 v22, v12

    move-object/from16 v17, v13

    :goto_220
    move-object/from16 v13, v17

    move-object/from16 v12, v22

    goto :goto_22d

    :catch_225
    move-exception v0

    move-object/from16 v22, v12

    move-object/from16 v17, v13

    goto :goto_22d

    :cond_22b
    :goto_22b
    const/4 v12, 0x0

    goto :goto_249

    :goto_22d
    move-object v15, v12

    goto :goto_236

    :catchall_22f
    move-exception v0

    goto :goto_233

    :catch_231
    move-exception v0

    goto :goto_235

    :goto_233
    move-object v2, v3

    goto :goto_24d

    :goto_235
    move-object v2, v3

    :goto_236
    :try_start_236
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    sget-object v1, Lads_mobile_sdk/cs1;->i:Ljs1;

    const/4 v1, 0x1

    invoke-virtual {v13, v0, v15, v1}, Lads_mobile_sdk/cs1;->a(Ljava/lang/String;Lads_mobile_sdk/cy0;Z)V
    :try_end_248
    .catchall {:try_start_236 .. :try_end_248} :catchall_1d8

    goto :goto_22b

    :goto_249
    invoke-static {v2, v12}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    :goto_24c
    return-object v16

    :goto_24d
    :try_start_24d
    invoke-virtual {v3, v0}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v1, v0, Lox2;

    if-nez v1, :cond_27d

    invoke-virtual {v3, v0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of v1, v0, Lza2;

    if-nez v1, :cond_275

    instance-of v1, v0, Ljava/util/concurrent/CancellationException;

    if-nez v1, :cond_26d

    instance-of v1, v0, Lads_mobile_sdk/mv0;

    if-eqz v1, :cond_267

    throw v0

    :catchall_264
    move-exception v0

    move-object v1, v0

    goto :goto_27e

    :cond_267
    new-instance v1, Lads_mobile_sdk/tu0;

    invoke-direct {v1, v0}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw v1

    :cond_26d
    new-instance v1, Lads_mobile_sdk/ou0;

    check-cast v0, Ljava/util/concurrent/CancellationException;

    invoke-direct {v1, v0}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw v1

    :cond_275
    new-instance v1, Lads_mobile_sdk/uw0;

    check-cast v0, Lza2;

    invoke-direct {v1, v0}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw v1

    :cond_27d
    throw v0
    :try_end_27e
    .catchall {:try_start_24d .. :try_end_27e} :catchall_264

    :goto_27e
    :try_start_27e
    throw v1
    :try_end_27f
    .catchall {:try_start_27e .. :try_end_27f} :catchall_27f

    :catchall_27f
    move-exception v0

    invoke-static {v2, v1}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0
.end method
