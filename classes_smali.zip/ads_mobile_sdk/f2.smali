.class public abstract Lads_mobile_sdk/f2;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lyt2;


# instance fields
.field public final a:Lads_mobile_sdk/kh3;

.field public final b:Lli;

.field public final c:Lads_mobile_sdk/av2;

.field public final d:J

.field public final e:I

.field public final f:Lads_mobile_sdk/a2;

.field public final g:Lads_mobile_sdk/xv;

.field public final h:Lads_mobile_sdk/n13;

.field public final i:Ljava/lang/String;

.field public final j:Lads_mobile_sdk/ve2;

.field public final k:Lads_mobile_sdk/v31;


# direct methods
.method public synthetic constructor <init>(Lads_mobile_sdk/kh3;Lli;Lads_mobile_sdk/av2;JILads_mobile_sdk/a2;Lads_mobile_sdk/xv;Lads_mobile_sdk/n13;Ljava/lang/String;Lads_mobile_sdk/ve2;)V
    .registers 25

    new-instance v12, Lads_mobile_sdk/v31;

    invoke-direct {v12}, Lads_mobile_sdk/v31;-><init>()V

    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object/from16 v3, p3

    move-wide/from16 v4, p4

    move/from16 v6, p6

    move-object/from16 v7, p7

    move-object/from16 v8, p8

    move-object/from16 v9, p9

    move-object/from16 v10, p10

    move-object/from16 v11, p11

    invoke-direct/range {v0 .. v12}, Lads_mobile_sdk/f2;-><init>(Lads_mobile_sdk/kh3;Lli;Lads_mobile_sdk/av2;JILads_mobile_sdk/a2;Lads_mobile_sdk/xv;Lads_mobile_sdk/n13;Ljava/lang/String;Lads_mobile_sdk/ve2;Lads_mobile_sdk/v31;)V

    return-void
.end method

.method public constructor <init>(Lads_mobile_sdk/kh3;Lli;Lads_mobile_sdk/av2;JILads_mobile_sdk/a2;Lads_mobile_sdk/xv;Lads_mobile_sdk/n13;Ljava/lang/String;Lads_mobile_sdk/ve2;Lads_mobile_sdk/v31;)V
    .registers 13

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/f2;->a:Lads_mobile_sdk/kh3;

    iput-object p2, p0, Lads_mobile_sdk/f2;->b:Lli;

    iput-object p3, p0, Lads_mobile_sdk/f2;->c:Lads_mobile_sdk/av2;

    iput-wide p4, p0, Lads_mobile_sdk/f2;->d:J

    iput p6, p0, Lads_mobile_sdk/f2;->e:I

    iput-object p7, p0, Lads_mobile_sdk/f2;->f:Lads_mobile_sdk/a2;

    iput-object p8, p0, Lads_mobile_sdk/f2;->g:Lads_mobile_sdk/xv;

    iput-object p9, p0, Lads_mobile_sdk/f2;->h:Lads_mobile_sdk/n13;

    iput-object p10, p0, Lads_mobile_sdk/f2;->i:Ljava/lang/String;

    iput-object p11, p0, Lads_mobile_sdk/f2;->j:Lads_mobile_sdk/ve2;

    iput-object p12, p0, Lads_mobile_sdk/f2;->k:Lads_mobile_sdk/v31;

    return-void
.end method

.method public static a(Lads_mobile_sdk/f2;Ljava/lang/String;ILwx;)Ljava/lang/Object;
    .registers 13

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/f2;->a:Lads_mobile_sdk/kh3;

    const-string v1, "Timed out while waiting "

    instance-of v2, p3, Lads_mobile_sdk/d2;

    if-eqz v2, :cond_17

    move-object v2, p3

    check-cast v2, Lads_mobile_sdk/d2;

    iget v3, v2, Lads_mobile_sdk/d2;->f:I

    const/high16 v4, -0x80000000

    and-int v5, v3, v4

    if-eqz v5, :cond_17

    sub-int/2addr v3, v4

    iput v3, v2, Lads_mobile_sdk/d2;->f:I

    goto :goto_1c

    :cond_17
    new-instance v2, Lads_mobile_sdk/d2;

    invoke-direct {v2, p0, p3}, Lads_mobile_sdk/d2;-><init>(Lads_mobile_sdk/f2;Lwx;)V

    :goto_1c
    iget-object p3, v2, Lads_mobile_sdk/d2;->d:Ljava/lang/Object;

    iget v3, v2, Lads_mobile_sdk/d2;->f:I

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eqz v3, :cond_45

    if-ne v3, v5, :cond_3f

    iget-object p0, v2, Lads_mobile_sdk/d2;->c:Lads_mobile_sdk/rg3;

    iget-object p1, v2, Lads_mobile_sdk/d2;->b:Lads_mobile_sdk/rg3;

    iget-object p2, v2, Lads_mobile_sdk/d2;->a:Lads_mobile_sdk/f2;

    :try_start_2d
    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_30
    .catch Lza2; {:try_start_2d .. :try_end_30} :catch_38
    .catchall {:try_start_2d .. :try_end_30} :catchall_35

    move-object v8, p3

    move-object p3, p0

    move-object p0, p2

    move-object p2, v8

    goto :goto_90

    :catchall_35
    move-exception p2

    goto/16 :goto_d2

    :catch_38
    move-exception p3

    move-object v8, p3

    move-object p3, p0

    move-object p0, p2

    move-object p2, v8

    goto/16 :goto_a4

    :cond_3f
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v6

    :cond_45
    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V

    sget-object p3, Lads_mobile_sdk/hh3;->a:Ljava/util/WeakHashMap;

    sget-object p3, Lba0;->a:Lba0;

    sget-object v3, Lads_mobile_sdk/fw0;->K:Lads_mobile_sdk/fw0;

    invoke-static {v3, p3, v5}, Lads_mobile_sdk/hh3;->a(Lads_mobile_sdk/fw0;Ljava/util/List;Z)Lads_mobile_sdk/rg3;

    move-result-object p3

    :try_start_52
    invoke-static {}, Lads_mobile_sdk/hh3;->a()Lads_mobile_sdk/rg3;

    move-result-object v3

    iget-object v7, p0, Lads_mobile_sdk/f2;->f:Lads_mobile_sdk/a2;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object v0, v3, Lads_mobile_sdk/rg3;->a:Lads_mobile_sdk/kh3;

    iget-object v0, v0, Lads_mobile_sdk/kh3;->c:Lads_mobile_sdk/dt2;

    iget-object v3, p0, Lads_mobile_sdk/f2;->i:Ljava/lang/String;

    iput-object v3, v0, Lads_mobile_sdk/dt2;->a:Ljava/lang/String;

    iput-object p1, v0, Lads_mobile_sdk/dt2;->c:Ljava/lang/String;

    iput p2, v0, Lads_mobile_sdk/dt2;->b:I

    iget-object p1, v7, Lads_mobile_sdk/a2;->f:Ljava/lang/String;

    iput-object p1, v0, Lads_mobile_sdk/dt2;->d:Ljava/lang/String;

    iget-object p1, v7, Lads_mobile_sdk/a2;->t0:Lads_mobile_sdk/a42;

    if-eqz p1, :cond_71

    move p1, v5

    goto :goto_72

    :cond_71
    move p1, v4

    :goto_72
    iput-boolean p1, v0, Lads_mobile_sdk/dt2;->g:Z
    :try_end_74
    .catchall {:try_start_52 .. :try_end_74} :catchall_98

    :try_start_74
    iget-wide p1, v7, Lads_mobile_sdk/a2;->d0:J

    new-instance v0, Lqd;

    const/16 v3, 0xf

    invoke-direct {v0, p0, v6, v3}, Lqd;-><init>(Ljava/lang/Object;Lvx;I)V
    :try_end_7d
    .catch Lza2; {:try_start_74 .. :try_end_7d} :catch_9d
    .catchall {:try_start_74 .. :try_end_7d} :catchall_98

    :try_start_7d
    iput-object p0, v2, Lads_mobile_sdk/d2;->a:Lads_mobile_sdk/f2;

    iput-object p3, v2, Lads_mobile_sdk/d2;->b:Lads_mobile_sdk/rg3;

    iput-object p3, v2, Lads_mobile_sdk/d2;->c:Lads_mobile_sdk/rg3;
    :try_end_83
    .catch Lza2; {:try_start_7d .. :try_end_83} :catch_9d
    .catchall {:try_start_7d .. :try_end_83} :catchall_9a

    :try_start_83
    iput v5, v2, Lads_mobile_sdk/d2;->f:I

    invoke-static {p1, p2, v0, v2}, Lla1;->W(JLpk0;Lwx;)Ljava/lang/Object;

    move-result-object p1
    :try_end_89
    .catch Lza2; {:try_start_83 .. :try_end_89} :catch_9d
    .catchall {:try_start_83 .. :try_end_89} :catchall_98

    sget-object p2, Lwy;->a:Lwy;

    if-ne p1, p2, :cond_8e

    return-object p2

    :cond_8e
    move-object p2, p1

    move-object p1, p3

    :goto_90
    :try_start_90
    check-cast p2, Lb13;
    :try_end_92
    .catch Lza2; {:try_start_90 .. :try_end_92} :catch_96
    .catchall {:try_start_90 .. :try_end_92} :catchall_93

    goto :goto_c3

    :catchall_93
    move-exception p0

    move-object p2, p0

    goto :goto_d1

    :catch_96
    move-exception p2

    goto :goto_a4

    :catchall_98
    move-exception p0

    goto :goto_9b

    :catchall_9a
    move-exception p0

    :goto_9b
    move-object p2, p0

    goto :goto_9f

    :catch_9d
    move-exception p1

    goto :goto_a2

    :goto_9f
    move-object p0, p3

    move-object p1, p0

    goto :goto_d2

    :goto_a2
    move-object p2, p1

    move-object p1, p3

    :goto_a4
    :try_start_a4
    new-instance v0, Lads_mobile_sdk/iv0;

    iget-object p0, p0, Lads_mobile_sdk/f2;->f:Lads_mobile_sdk/a2;

    iget-wide v2, p0, Lads_mobile_sdk/a2;->d0:J

    invoke-static {v2, v3}, Lv60;->m(J)Ljava/lang/String;

    move-result-object p0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, " for rendering."

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/iv0;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    move-object p2, v0

    :goto_c3
    instance-of p0, p2, Lads_mobile_sdk/av0;

    if-eqz p0, :cond_cd

    move-object p0, p2

    check-cast p0, Lads_mobile_sdk/av0;

    invoke-static {p0, v4}, Lads_mobile_sdk/xh3;->a(Lads_mobile_sdk/av0;Z)V
    :try_end_cd
    .catchall {:try_start_a4 .. :try_end_cd} :catchall_93

    :cond_cd
    invoke-static {p3, v6}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object p2

    :goto_d1
    move-object p0, p3

    :goto_d2
    :try_start_d2
    invoke-virtual {p1, p2}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of p3, p2, Lox2;

    if-nez p3, :cond_101

    invoke-virtual {p1, p2}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of p1, p2, Lza2;

    if-nez p1, :cond_f9

    instance-of p1, p2, Ljava/util/concurrent/CancellationException;

    if-nez p1, :cond_f1

    instance-of p1, p2, Lads_mobile_sdk/mv0;

    if-eqz p1, :cond_eb

    throw p2

    :catchall_e9
    move-exception p1

    goto :goto_102

    :cond_eb
    new-instance p1, Lads_mobile_sdk/tu0;

    invoke-direct {p1, p2}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw p1

    :cond_f1
    new-instance p1, Lads_mobile_sdk/ou0;

    check-cast p2, Ljava/util/concurrent/CancellationException;

    invoke-direct {p1, p2}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw p1

    :cond_f9
    new-instance p1, Lads_mobile_sdk/uw0;

    check-cast p2, Lza2;

    invoke-direct {p1, p2}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw p1

    :cond_101
    throw p2
    :try_end_102
    .catchall {:try_start_d2 .. :try_end_102} :catchall_e9

    :goto_102
    :try_start_102
    throw p1
    :try_end_103
    .catchall {:try_start_102 .. :try_end_103} :catchall_103

    :catchall_103
    move-exception p2

    invoke-static {p0, p1}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw p2
.end method


# virtual methods
.method public final a(Ljava/lang/String;ILwx;)Ljava/lang/Object;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lads_mobile_sdk/f2;->a(Lads_mobile_sdk/f2;Ljava/lang/String;ILwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final a(Lwx;)Ljava/lang/Object;
    .registers 8

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/c2;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/c2;

    iget v1, v0, Lads_mobile_sdk/c2;->e:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/c2;->e:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/c2;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/c2;-><init>(Lads_mobile_sdk/f2;Lwx;)V

    :goto_18
    iget-object p1, v0, Lads_mobile_sdk/c2;->c:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/c2;->e:I

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v1, :cond_3d

    if-eq v1, v3, :cond_33

    if-ne v1, v2, :cond_2d

    :try_start_25
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_28
    .catch Ljava/lang/Exception; {:try_start_25 .. :try_end_28} :catch_2a

    goto/16 :goto_cb

    :catch_2a
    move-exception p0

    goto/16 :goto_e5

    :cond_2d
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v4

    :cond_33
    iget-object p0, v0, Lads_mobile_sdk/c2;->b:Lads_mobile_sdk/rg3;

    iget-object v0, v0, Lads_mobile_sdk/c2;->a:Lads_mobile_sdk/rg3;

    :try_start_37
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_3a
    .catchall {:try_start_37 .. :try_end_3a} :catchall_3b

    goto :goto_79

    :catchall_3b
    move-exception p1

    goto :goto_83

    :cond_3d
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/f2;->f:Lads_mobile_sdk/a2;

    iget-object p1, p1, Lads_mobile_sdk/a2;->I:Lads_mobile_sdk/s61;

    if-nez p1, :cond_4e

    new-instance p0, Lads_mobile_sdk/ev0;

    const-string p1, "First party ad configuration has no inline ad field."

    invoke-direct {p0, p1, v3}, Lads_mobile_sdk/ev0;-><init>(Ljava/lang/String;I)V

    return-object p0

    :cond_4e
    iget-object v1, p1, Lads_mobile_sdk/s61;->b:Lu20;

    if-eqz v1, :cond_ed

    iget-object p0, p0, Lads_mobile_sdk/f2;->a:Lads_mobile_sdk/kh3;

    iget-object p0, p0, Lads_mobile_sdk/kh3;->c:Lads_mobile_sdk/dt2;

    iput-boolean v3, p0, Lads_mobile_sdk/dt2;->h:Z

    :try_start_58
    invoke-interface {v1}, Lfv0;->isActive()Z

    move-result p0
    :try_end_5c
    .catch Ljava/lang/Exception; {:try_start_58 .. :try_end_5c} :catch_2a

    sget-object p1, Lwy;->a:Lwy;

    if-eqz p0, :cond_c1

    :try_start_60
    sget-object p0, Lads_mobile_sdk/fw0;->L:Lads_mobile_sdk/fw0;

    sget-object v2, Lads_mobile_sdk/hh3;->a:Ljava/util/WeakHashMap;

    sget-object v2, Lba0;->a:Lba0;

    invoke-static {p0, v2, v3}, Lads_mobile_sdk/hh3;->a(Lads_mobile_sdk/fw0;Ljava/util/List;Z)Lads_mobile_sdk/rg3;

    move-result-object p0
    :try_end_6a
    .catch Ljava/lang/Exception; {:try_start_60 .. :try_end_6a} :catch_2a

    :try_start_6a
    iput-object p0, v0, Lads_mobile_sdk/c2;->a:Lads_mobile_sdk/rg3;

    iput-object p0, v0, Lads_mobile_sdk/c2;->b:Lads_mobile_sdk/rg3;

    iput v3, v0, Lads_mobile_sdk/c2;->e:I

    invoke-interface {v1, v0}, Lu20;->b(Lwx;)Ljava/lang/Object;

    move-result-object v0
    :try_end_74
    .catchall {:try_start_6a .. :try_end_74} :catchall_88

    if-ne v0, p1, :cond_77

    goto :goto_c9

    :cond_77
    move-object p1, v0

    move-object v0, p0

    :goto_79
    :try_start_79
    check-cast p1, Lads_mobile_sdk/gv2;

    invoke-static {p1}, Lads_mobile_sdk/gv2;->a(Lads_mobile_sdk/gv2;)Ljava/lang/String;

    move-result-object p1
    :try_end_7f
    .catchall {:try_start_79 .. :try_end_7f} :catchall_3b

    :try_start_7f
    invoke-static {p0, v4}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    :try_end_82
    .catch Ljava/lang/Exception; {:try_start_7f .. :try_end_82} :catch_2a

    goto :goto_d1

    :goto_83
    move-object v5, p1

    move-object p1, p0

    move-object p0, v0

    move-object v0, v5

    goto :goto_8b

    :catchall_88
    move-exception p1

    move-object v0, p1

    move-object p1, p0

    :goto_8b
    :try_start_8b
    invoke-virtual {p0, v0}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v1, v0, Lox2;

    if-nez v1, :cond_ba

    invoke-virtual {p0, v0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of p0, v0, Lza2;

    if-nez p0, :cond_b2

    instance-of p0, v0, Ljava/util/concurrent/CancellationException;

    if-nez p0, :cond_aa

    instance-of p0, v0, Lads_mobile_sdk/mv0;

    if-eqz p0, :cond_a4

    throw v0

    :catchall_a2
    move-exception p0

    goto :goto_bb

    :cond_a4
    new-instance p0, Lads_mobile_sdk/tu0;

    invoke-direct {p0, v0}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw p0

    :cond_aa
    new-instance p0, Lads_mobile_sdk/ou0;

    check-cast v0, Ljava/util/concurrent/CancellationException;

    invoke-direct {p0, v0}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw p0

    :cond_b2
    new-instance p0, Lads_mobile_sdk/uw0;

    check-cast v0, Lza2;

    invoke-direct {p0, v0}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw p0

    :cond_ba
    throw v0
    :try_end_bb
    .catchall {:try_start_8b .. :try_end_bb} :catchall_a2

    :goto_bb
    :try_start_bb
    throw p0
    :try_end_bc
    .catchall {:try_start_bb .. :try_end_bc} :catchall_bc

    :catchall_bc
    move-exception v0

    :try_start_bd
    invoke-static {p1, p0}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0

    :cond_c1
    iput v2, v0, Lads_mobile_sdk/c2;->e:I

    invoke-interface {v1, v0}, Lu20;->b(Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, p1, :cond_ca

    :goto_c9
    return-object p1

    :cond_ca
    move-object p1, p0

    :goto_cb
    check-cast p1, Lads_mobile_sdk/gv2;

    invoke-static {p1}, Lads_mobile_sdk/gv2;->a(Lads_mobile_sdk/gv2;)Ljava/lang/String;

    move-result-object p1

    :goto_d1
    invoke-static {p1}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result p0

    if-eqz p0, :cond_df

    new-instance p0, Lads_mobile_sdk/ev0;

    const-string p1, "First party ad configuration has an empty body."

    invoke-direct {p0, p1, v3}, Lads_mobile_sdk/ev0;-><init>(Ljava/lang/String;I)V

    return-object p0

    :cond_df
    new-instance p0, Lads_mobile_sdk/hv0;

    invoke-direct {p0, p1}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V
    :try_end_e4
    .catch Ljava/lang/Exception; {:try_start_bd .. :try_end_e4} :catch_2a

    return-object p0

    :goto_e5
    new-instance p1, Lads_mobile_sdk/bv0;

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p1, v0, v4, p0, v1}, Lads_mobile_sdk/bv0;-><init>(ILjava/lang/String;Ljava/lang/Throwable;I)V

    return-object p1

    :cond_ed
    iget-object p0, p1, Lads_mobile_sdk/s61;->a:Ljava/lang/String;

    if-nez p0, :cond_f9

    new-instance p0, Lads_mobile_sdk/ev0;

    const-string p1, "First party ad configuration has no body."

    invoke-direct {p0, p1, v3}, Lads_mobile_sdk/ev0;-><init>(Ljava/lang/String;I)V

    return-object p0

    :cond_f9
    new-instance p1, Lads_mobile_sdk/hv0;

    invoke-direct {p1, p0}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    return-object p1
.end method

.method public abstract a(ZLvx;)Ljava/lang/Object;
.end method

.method public final a(Lm23;Z)Lm23;
    .registers 5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Lads_mobile_sdk/f2;->f:Lads_mobile_sdk/a2;

    invoke-interface {p1, v0}, Lm23;->a(Lads_mobile_sdk/a2;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lm23;

    iget-object v0, p0, Lads_mobile_sdk/f2;->g:Lads_mobile_sdk/xv;

    invoke-interface {p1, v0}, Lm23;->a(Lads_mobile_sdk/xv;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lm23;

    iget-object v0, p0, Lads_mobile_sdk/f2;->h:Lads_mobile_sdk/n13;

    invoke-interface {p1, v0}, Lm23;->a(Lads_mobile_sdk/n13;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lm23;

    iget-object v0, p0, Lads_mobile_sdk/f2;->a:Lads_mobile_sdk/kh3;

    iget-object v1, v0, Lads_mobile_sdk/kh3;->a:Lads_mobile_sdk/eq2;

    invoke-interface {p1, v1}, Lm23;->a(Lads_mobile_sdk/eq2;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lm23;

    iget-object v1, v0, Lads_mobile_sdk/kh3;->b:Lads_mobile_sdk/ih1;

    invoke-interface {p1, v1}, Lm23;->a(Lads_mobile_sdk/ih1;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lm23;

    iget-object v1, v0, Lads_mobile_sdk/kh3;->c:Lads_mobile_sdk/dt2;

    invoke-interface {p1, v1}, Lm23;->a(Lads_mobile_sdk/dt2;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lm23;

    iget-object v0, v0, Lads_mobile_sdk/kh3;->d:Lads_mobile_sdk/s8;

    invoke-interface {p1, v0}, Lm23;->a(Lads_mobile_sdk/s8;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lm23;

    iget-object v0, p0, Lads_mobile_sdk/f2;->c:Lads_mobile_sdk/av2;

    invoke-interface {p1, v0}, Lm23;->a(Lads_mobile_sdk/av2;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lm23;

    iget-object v0, p0, Lads_mobile_sdk/f2;->b:Lli;

    invoke-interface {p1, v0}, Lm23;->a(Lli;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lm23;

    iget-wide v0, p0, Lads_mobile_sdk/f2;->d:J

    invoke-interface {p1, v0, v1}, Lm23;->a(J)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lm23;

    invoke-interface {p1, p2}, Lm23;->a(Z)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lm23;

    iget p2, p0, Lads_mobile_sdk/f2;->e:I

    invoke-interface {p1, p2}, Lm23;->a(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lm23;

    iget-object p2, p0, Lads_mobile_sdk/f2;->j:Lads_mobile_sdk/ve2;

    invoke-interface {p1, p2}, Lm23;->a(Lads_mobile_sdk/ve2;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lm23;

    iget-object p0, p0, Lads_mobile_sdk/f2;->k:Lads_mobile_sdk/v31;

    invoke-interface {p1, p0}, Lm23;->a(Lads_mobile_sdk/v31;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lm23;

    return-object p0
.end method
