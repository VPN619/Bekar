.class public final Lads_mobile_sdk/da;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lnt2;


# instance fields
.field public final a:Lads_mobile_sdk/ah0;

.field public final synthetic b:I


# direct methods
.method public synthetic constructor <init>(Lads_mobile_sdk/ah0;I)V
    .registers 3

    iput p2, p0, Lads_mobile_sdk/da;->b:I

    iput-object p1, p0, Lads_mobile_sdk/da;->a:Lads_mobile_sdk/ah0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 4

    .prologue
    iget v0, p0, Lads_mobile_sdk/da;->b:I

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object p0, p0, Lads_mobile_sdk/da;->a:Lads_mobile_sdk/ah0;

    packed-switch v0, :pswitch_data_172

    invoke-static {p0, p0, v2}, Lmd3;->a(Ltv2;Ltv2;Z)Lads_mobile_sdk/l61;

    move-result-object p0

    return-object p0

    :pswitch_e  #0x1c
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/vz;

    new-instance v0, Lads_mobile_sdk/y13;

    invoke-direct {v0, p0}, Lads_mobile_sdk/y13;-><init>(Lads_mobile_sdk/vz;)V

    return-object v0

    :pswitch_1a  #0x1b
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/z2;

    new-instance v0, Lads_mobile_sdk/xx1;

    invoke-direct {v0, p0}, Lads_mobile_sdk/xx1;-><init>(Lads_mobile_sdk/z2;)V

    return-object v0

    :pswitch_26  #0x1a
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/ah3;

    new-instance v0, Lads_mobile_sdk/uu0;

    invoke-direct {v0, p0}, Lads_mobile_sdk/uu0;-><init>(Lads_mobile_sdk/ah3;)V

    return-object v0

    :pswitch_32  #0x19
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/d91;

    new-instance v0, Lads_mobile_sdk/da1;

    const/4 v1, 0x2

    invoke-direct {v0, p0, v1}, Lads_mobile_sdk/da1;-><init>(Lads_mobile_sdk/d91;I)V

    return-object v0

    :pswitch_3f  #0x18
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/d91;

    new-instance v0, Lads_mobile_sdk/ta1;

    invoke-direct {v0, p0}, Lads_mobile_sdk/ta1;-><init>(Lads_mobile_sdk/d91;)V

    return-object v0

    :pswitch_4b  #0x17
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/d91;

    new-instance v0, Lads_mobile_sdk/da1;

    invoke-direct {v0, p0, v1}, Lads_mobile_sdk/da1;-><init>(Lads_mobile_sdk/d91;I)V

    return-object v0

    :pswitch_57  #0x16
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/vz;

    new-instance v0, Lads_mobile_sdk/sb2;

    invoke-direct {v0, p0}, Lads_mobile_sdk/sb2;-><init>(Lads_mobile_sdk/vz;)V

    return-object v0

    :pswitch_63  #0x15
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/d91;

    new-instance v0, Lads_mobile_sdk/e7;

    invoke-direct {v0, p0}, Lads_mobile_sdk/e7;-><init>(Lads_mobile_sdk/d91;)V

    return-object v0

    :pswitch_6f  #0x14
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/vz;

    new-instance v0, Lads_mobile_sdk/r23;

    invoke-direct {v0, p0}, Lads_mobile_sdk/r23;-><init>(Lads_mobile_sdk/vz;)V

    return-object v0

    :pswitch_7b  #0x13
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/z2;

    new-instance v0, Lads_mobile_sdk/ox1;

    invoke-direct {v0, p0}, Lads_mobile_sdk/ox1;-><init>(Lads_mobile_sdk/z2;)V

    return-object v0

    :pswitch_87  #0x12
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/vz;

    new-instance v0, Lads_mobile_sdk/oi;

    invoke-direct {v0, p0}, Lads_mobile_sdk/oi;-><init>(Lads_mobile_sdk/vz;)V

    return-object v0

    :pswitch_93  #0x11
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/vz;

    new-instance v0, Lads_mobile_sdk/oe;

    invoke-direct {v0, p0}, Lads_mobile_sdk/oe;-><init>(Lads_mobile_sdk/vz;)V

    return-object v0

    :pswitch_9f  #0x10
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/vz;

    new-instance v0, Lads_mobile_sdk/nb2;

    invoke-direct {v0, p0}, Lads_mobile_sdk/nb2;-><init>(Lads_mobile_sdk/vz;)V

    return-object v0

    :pswitch_ab  #0xf
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/k01;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object p0

    :pswitch_b5  #0xe
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/z2;

    new-instance v0, Lads_mobile_sdk/lg;

    invoke-direct {v0, p0}, Lads_mobile_sdk/lg;-><init>(Lads_mobile_sdk/z2;)V

    return-object v0

    :pswitch_c1  #0xd
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/vz;

    new-instance v0, Lads_mobile_sdk/l3;

    invoke-direct {v0, p0}, Lads_mobile_sdk/l3;-><init>(Lads_mobile_sdk/vz;)V

    return-object v0

    :pswitch_cd  #0xc
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/z2;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lads_mobile_sdk/a10;

    invoke-direct {v0, v2, p0}, Lads_mobile_sdk/a10;-><init>(ILjava/lang/Object;)V

    return-object v0

    :pswitch_dc  #0xb
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/z2;

    new-instance v0, Lads_mobile_sdk/j80;

    invoke-direct {v0, p0}, Lads_mobile_sdk/j80;-><init>(Lads_mobile_sdk/z2;)V

    return-object v0

    :pswitch_e8  #0xa
    invoke-static {p0, p0, v1}, Lmd3;->a(Ltv2;Ltv2;Z)Lads_mobile_sdk/l61;

    move-result-object p0

    return-object p0

    :pswitch_ed  #0x9
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/f92;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lads_mobile_sdk/ez1;

    const/4 v1, 0x7

    invoke-direct {v0, p0, v1}, Lads_mobile_sdk/ez1;-><init>(Lbw2;I)V

    return-object v0

    :pswitch_fd  #0x8
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/vz;

    new-instance v0, Lads_mobile_sdk/e23;

    invoke-direct {v0, p0}, Lads_mobile_sdk/e23;-><init>(Lads_mobile_sdk/vz;)V

    return-object v0

    :pswitch_109  #0x7
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lly;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Lq23;->e()Lr72;

    move-result-object v0

    invoke-interface {p0, v0}, Lly;->plus(Lly;)Lly;

    move-result-object p0

    invoke-static {p0}, Lw53;->a(Lly;)Lsx;

    move-result-object p0

    return-object p0

    :pswitch_11f  #0x6
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/vz;

    new-instance v0, Lads_mobile_sdk/e80;

    invoke-direct {v0, p0}, Lads_mobile_sdk/e80;-><init>(Lads_mobile_sdk/vz;)V

    return-object v0

    :pswitch_12b  #0x5
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/d91;

    new-instance v0, Lads_mobile_sdk/da1;

    invoke-direct {v0, p0, v2}, Lads_mobile_sdk/da1;-><init>(Lads_mobile_sdk/d91;I)V

    return-object v0

    :pswitch_137  #0x4
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/f92;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lads_mobile_sdk/ez1;

    const/4 v1, 0x6

    invoke-direct {v0, p0, v1}, Lads_mobile_sdk/ez1;-><init>(Lbw2;I)V

    return-object v0

    :pswitch_147  #0x3
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lly;

    new-instance v0, Lads_mobile_sdk/cn3;

    invoke-direct {v0, p0}, Lads_mobile_sdk/cn3;-><init>(Lly;)V

    return-object v0

    :pswitch_153  #0x2
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/z2;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object p0

    :pswitch_15d  #0x1
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lb63;

    invoke-direct {v0, p0, v2}, Lads_mobile_sdk/l61;-><init>(Ltv2;Z)V

    return-object v0

    :pswitch_166  #0x0
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/z2;

    new-instance v0, Lads_mobile_sdk/ca;

    invoke-direct {v0, p0}, Lads_mobile_sdk/ca;-><init>(Lads_mobile_sdk/z2;)V

    return-object v0

    :pswitch_data_172
    .packed-switch 0x0
        :pswitch_166  #00000000
        :pswitch_15d  #00000001
        :pswitch_153  #00000002
        :pswitch_147  #00000003
        :pswitch_137  #00000004
        :pswitch_12b  #00000005
        :pswitch_11f  #00000006
        :pswitch_109  #00000007
        :pswitch_fd  #00000008
        :pswitch_ed  #00000009
        :pswitch_e8  #0000000a
        :pswitch_dc  #0000000b
        :pswitch_cd  #0000000c
        :pswitch_c1  #0000000d
        :pswitch_b5  #0000000e
        :pswitch_ab  #0000000f
        :pswitch_9f  #00000010
        :pswitch_93  #00000011
        :pswitch_87  #00000012
        :pswitch_7b  #00000013
        :pswitch_6f  #00000014
        :pswitch_63  #00000015
        :pswitch_57  #00000016
        :pswitch_4b  #00000017
        :pswitch_3f  #00000018
        :pswitch_32  #00000019
        :pswitch_26  #0000001a
        :pswitch_1a  #0000001b
        :pswitch_e  #0000001c
    .end packed-switch
.end method
