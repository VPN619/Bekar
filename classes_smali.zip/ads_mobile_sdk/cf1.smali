.class public final Lads_mobile_sdk/cf1;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public a:I

.field public final synthetic b:Lads_mobile_sdk/rf1;

.field public final synthetic c:Lb4;

.field public final synthetic t:I


# direct methods
.method public synthetic constructor <init>(Lads_mobile_sdk/rf1;Lb4;Lvx;I)V
    .registers 5

    iput p4, p0, Lads_mobile_sdk/cf1;->t:I

    iput-object p1, p0, Lads_mobile_sdk/cf1;->b:Lads_mobile_sdk/rf1;

    iput-object p2, p0, Lads_mobile_sdk/cf1;->c:Lb4;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 5

    .prologue
    iget p2, p0, Lads_mobile_sdk/cf1;->t:I

    iget-object v0, p0, Lads_mobile_sdk/cf1;->c:Lb4;

    iget-object p0, p0, Lads_mobile_sdk/cf1;->b:Lads_mobile_sdk/rf1;

    packed-switch p2, :pswitch_data_18

    new-instance p2, Lads_mobile_sdk/cf1;

    const/4 v1, 0x1

    invoke-direct {p2, p0, v0, p1, v1}, Lads_mobile_sdk/cf1;-><init>(Lads_mobile_sdk/rf1;Lb4;Lvx;I)V

    return-object p2

    :pswitch_10  #0x0
    new-instance p2, Lads_mobile_sdk/cf1;

    const/4 v1, 0x0

    invoke-direct {p2, p0, v0, p1, v1}, Lads_mobile_sdk/cf1;-><init>(Lads_mobile_sdk/rf1;Lb4;Lvx;I)V

    return-object p2

    nop

    :pswitch_data_18
    .packed-switch 0x0
        :pswitch_10  #00000000
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .prologue
    iget v0, p0, Lads_mobile_sdk/cf1;->t:I

    sget-object v1, Lrg2;->a:Lrg2;

    iget-object v2, p0, Lads_mobile_sdk/cf1;->c:Lb4;

    iget-object p0, p0, Lads_mobile_sdk/cf1;->b:Lads_mobile_sdk/rf1;

    packed-switch v0, :pswitch_data_2a

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/cf1;

    const/4 v0, 0x1

    invoke-direct {p1, p0, v2, p2, v0}, Lads_mobile_sdk/cf1;-><init>(Lads_mobile_sdk/rf1;Lb4;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/cf1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_1a  #0x0
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/cf1;

    const/4 v0, 0x0

    invoke-direct {p1, p0, v2, p2, v0}, Lads_mobile_sdk/cf1;-><init>(Lads_mobile_sdk/rf1;Lb4;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/cf1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_2a
    .packed-switch 0x0
        :pswitch_1a  #00000000
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 11

    .prologue
    iget v0, p0, Lads_mobile_sdk/cf1;->t:I

    sget-object v1, Lrg2;->a:Lrg2;

    iget-object v2, p0, Lads_mobile_sdk/cf1;->c:Lb4;

    iget-object v3, p0, Lads_mobile_sdk/cf1;->b:Lads_mobile_sdk/rf1;

    const/4 v4, 0x0

    const-string v5, "call to \'resume\' before \'invoke\' with coroutine"

    sget-object v6, Lwy;->a:Lwy;

    const/4 v7, 0x1

    packed-switch v0, :pswitch_data_66

    iget v0, p0, Lads_mobile_sdk/cf1;->a:I

    if-eqz v0, :cond_20

    if-ne v0, v7, :cond_1b

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_2c

    :cond_1b
    invoke-static {v5}, Lz6;->w(Ljava/lang/String;)V

    move-object v1, v4

    goto :goto_2c

    :cond_20
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iput v7, p0, Lads_mobile_sdk/cf1;->a:I

    invoke-virtual {v3, v2, p0}, Lads_mobile_sdk/rf1;->a(Lb4;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v6, :cond_2c

    move-object v1, v6

    :cond_2c
    :goto_2c
    return-object v1

    :pswitch_2d  #0x0
    iget v0, p0, Lads_mobile_sdk/cf1;->a:I

    const/4 v8, 0x2

    if-eqz v0, :cond_43

    if-eq v0, v7, :cond_3f

    if-ne v0, v8, :cond_3a

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_64

    :cond_3a
    invoke-static {v5}, Lz6;->w(Ljava/lang/String;)V

    move-object v1, v4

    goto :goto_64

    :cond_3f
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_51

    :cond_43
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, v3, Lads_mobile_sdk/rf1;->A:Lhv0;

    iput v7, p0, Lads_mobile_sdk/cf1;->a:I

    invoke-virtual {p1, p0}, Lnv0;->H(Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v6, :cond_51

    goto :goto_63

    :cond_51
    :goto_51
    iget-object p1, v3, Lads_mobile_sdk/rf1;->i:Lads_mobile_sdk/sb;

    iget-object v0, v3, Lads_mobile_sdk/rf1;->s:Lads_mobile_sdk/i41;

    invoke-virtual {v0}, Lads_mobile_sdk/i41;->a()Lfm0;

    iput v8, p0, Lads_mobile_sdk/cf1;->a:I

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1, v2, p0}, Lads_mobile_sdk/sb;->a(Lads_mobile_sdk/sb;Lb4;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v6, :cond_64

    :goto_63
    move-object v1, v6

    :cond_64
    :goto_64
    return-object v1

    nop

    :pswitch_data_66
    .packed-switch 0x0
        :pswitch_2d  #00000000
    .end packed-switch
.end method
