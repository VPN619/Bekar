.class public final Lads_mobile_sdk/bh0;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public final synthetic a:Lads_mobile_sdk/ph0;

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:Ljava/lang/String;

.field public final synthetic t:I


# direct methods
.method public synthetic constructor <init>(Lvx;Lads_mobile_sdk/ph0;Ljava/lang/String;Ljava/lang/String;I)V
    .registers 6

    iput p5, p0, Lads_mobile_sdk/bh0;->t:I

    iput-object p2, p0, Lads_mobile_sdk/bh0;->a:Lads_mobile_sdk/ph0;

    iput-object p3, p0, Lads_mobile_sdk/bh0;->b:Ljava/lang/String;

    iput-object p4, p0, Lads_mobile_sdk/bh0;->c:Ljava/lang/String;

    const/4 p2, 0x2

    invoke-direct {p0, p2, p1}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 10

    .prologue
    iget p2, p0, Lads_mobile_sdk/bh0;->t:I

    packed-switch p2, :pswitch_data_24

    new-instance v0, Lads_mobile_sdk/bh0;

    iget-object v4, p0, Lads_mobile_sdk/bh0;->c:Ljava/lang/String;

    const/4 v5, 0x1

    iget-object v2, p0, Lads_mobile_sdk/bh0;->a:Lads_mobile_sdk/ph0;

    iget-object v3, p0, Lads_mobile_sdk/bh0;->b:Ljava/lang/String;

    move-object v1, p1

    invoke-direct/range {v0 .. v5}, Lads_mobile_sdk/bh0;-><init>(Lvx;Lads_mobile_sdk/ph0;Ljava/lang/String;Ljava/lang/String;I)V

    return-object v0

    :pswitch_13  #0x0
    move-object v1, p1

    new-instance p1, Lads_mobile_sdk/bh0;

    iget-object v5, p0, Lads_mobile_sdk/bh0;->c:Ljava/lang/String;

    const/4 v6, 0x0

    iget-object v3, p0, Lads_mobile_sdk/bh0;->a:Lads_mobile_sdk/ph0;

    iget-object v4, p0, Lads_mobile_sdk/bh0;->b:Ljava/lang/String;

    move-object v2, v1

    move-object v1, p1

    invoke-direct/range {v1 .. v6}, Lads_mobile_sdk/bh0;-><init>(Lvx;Lads_mobile_sdk/ph0;Ljava/lang/String;Ljava/lang/String;I)V

    return-object v1

    nop

    :pswitch_data_24
    .packed-switch 0x0
        :pswitch_13  #00000000
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .prologue
    iget v0, p0, Lads_mobile_sdk/bh0;->t:I

    sget-object v1, Lrg2;->a:Lrg2;

    packed-switch v0, :pswitch_data_24

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    invoke-virtual {p0, p2, p1}, Lads_mobile_sdk/bh0;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/bh0;

    invoke-virtual {p0, v1}, Lads_mobile_sdk/bh0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object v1

    :pswitch_15  #0x0
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    invoke-virtual {p0, p2, p1}, Lads_mobile_sdk/bh0;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/bh0;

    invoke-virtual {p0, v1}, Lads_mobile_sdk/bh0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object v1

    nop

    :pswitch_data_24
    .packed-switch 0x0
        :pswitch_15  #00000000
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .prologue
    iget v0, p0, Lads_mobile_sdk/bh0;->t:I

    packed-switch v0, :pswitch_data_36

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/bh0;->a:Lads_mobile_sdk/ph0;

    monitor-enter p1

    :try_start_b
    iget-object v0, p1, Lads_mobile_sdk/ph0;->e:Lhh1;
    :try_end_d
    .catchall {:try_start_b .. :try_end_d} :catchall_1a

    monitor-exit p1

    if-eqz v0, :cond_17

    iget-object p1, p0, Lads_mobile_sdk/bh0;->b:Ljava/lang/String;

    iget-object p0, p0, Lads_mobile_sdk/bh0;->c:Ljava/lang/String;

    invoke-interface {v0, p1, p0}, Lhh1;->onAppEvent(Ljava/lang/String;Ljava/lang/String;)V

    :cond_17
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0

    :catchall_1a
    move-exception p0

    monitor-exit p1

    throw p0

    :pswitch_1d  #0x0
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/bh0;->a:Lads_mobile_sdk/ph0;

    monitor-enter p1

    :try_start_23
    iget-object v0, p1, Lads_mobile_sdk/ph0;->e:Lhh1;
    :try_end_25
    .catchall {:try_start_23 .. :try_end_25} :catchall_32

    monitor-exit p1

    if-eqz v0, :cond_2f

    iget-object p1, p0, Lads_mobile_sdk/bh0;->b:Ljava/lang/String;

    iget-object p0, p0, Lads_mobile_sdk/bh0;->c:Ljava/lang/String;

    invoke-interface {v0, p1, p0}, Lhh1;->onAppEvent(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2f
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0

    :catchall_32
    move-exception p0

    monitor-exit p1

    throw p0

    nop

    :pswitch_data_36
    .packed-switch 0x0
        :pswitch_1d  #00000000
    .end packed-switch
.end method
