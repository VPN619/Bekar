.class public final Lads_mobile_sdk/bm;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ldv2;


# instance fields
.field public final a:Lli;

.field public final b:Lqh;

.field public final c:Lads_mobile_sdk/cu2;

.field public final d:Landroid/content/Context;

.field public final e:Lads_mobile_sdk/g0;

.field public final f:Lads_mobile_sdk/rh0;

.field public final g:Ltv2;

.field public final h:Lc73;


# direct methods
.method public constructor <init>(Lli;Lqh;Lads_mobile_sdk/cu2;Landroid/content/Context;Lads_mobile_sdk/g0;Lads_mobile_sdk/rh0;Lads_mobile_sdk/ab0;Lc73;)V
    .registers 9

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/bm;->a:Lli;

    iput-object p2, p0, Lads_mobile_sdk/bm;->b:Lqh;

    iput-object p3, p0, Lads_mobile_sdk/bm;->c:Lads_mobile_sdk/cu2;

    iput-object p4, p0, Lads_mobile_sdk/bm;->d:Landroid/content/Context;

    iput-object p5, p0, Lads_mobile_sdk/bm;->e:Lads_mobile_sdk/g0;

    iput-object p6, p0, Lads_mobile_sdk/bm;->f:Lads_mobile_sdk/rh0;

    iput-object p7, p0, Lads_mobile_sdk/bm;->g:Ltv2;

    iput-object p8, p0, Lads_mobile_sdk/bm;->h:Lc73;

    return-void
.end method


# virtual methods
.method public final a(Lads_mobile_sdk/n13;Lads_mobile_sdk/a2;Lk53;)Lm23;
    .registers 4

    .prologue
    check-cast p3, Lads_mobile_sdk/ko1;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p1, p0, Lads_mobile_sdk/bm;->g:Ltv2;

    invoke-interface {p1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lads_mobile_sdk/ue0;

    iget-object p2, p3, Lads_mobile_sdk/ko1;->b:Landroid/view/View;

    if-eqz p2, :cond_21

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p2, p1, Lads_mobile_sdk/ue0;->q:Landroid/view/View;

    iget-object p0, p0, Lads_mobile_sdk/bm;->h:Lc73;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p0, p1, Lads_mobile_sdk/ue0;->p:Lc73;

    return-object p1

    :cond_21
    const-string p0, "view"

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0
.end method

.method public final a(Lads_mobile_sdk/n13;Lads_mobile_sdk/a2;Lk53;Lads_mobile_sdk/os;)V
    .registers 28

    .prologue
    move-object/from16 v0, p0

    move-object/from16 v1, p4

    move-object/from16 v2, p3

    check-cast v2, Lads_mobile_sdk/ko1;

    invoke-virtual/range {p1 .. p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p2 .. p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v3, v2, Lads_mobile_sdk/q61;->a:Lcom/google/android/gms/ads/mediation/Adapter;

    iget-object v4, v0, Lads_mobile_sdk/bm;->b:Lqh;

    invoke-interface {v4}, Lqh;->k()Ls4;

    move-result-object v4

    if-nez v4, :cond_29

    new-instance v0, Lcom/google/android/gms/ads/AdError;

    const-string v2, "No AdSize available for banner mediation. This may happen when a server-to-server ad response triggers mediation but no AdSize was provided in the signal request."

    const-string v3, "com.google.android.libraries.ads.mobile.sdk"

    const/4 v4, 0x0

    invoke-direct {v0, v4, v2, v3}, Lcom/google/android/gms/ads/AdError;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Lads_mobile_sdk/os;->a(Lcom/google/android/gms/ads/AdError;)V

    return-void

    :cond_29
    iget-object v5, v0, Lads_mobile_sdk/bm;->e:Lads_mobile_sdk/g0;

    invoke-virtual {v5}, Lads_mobile_sdk/g0;->b()Landroid/app/Activity;

    move-result-object v5

    if-eqz v5, :cond_33

    :goto_31
    move-object v7, v5

    goto :goto_36

    :cond_33
    iget-object v5, v0, Lads_mobile_sdk/bm;->d:Landroid/content/Context;

    goto :goto_31

    :goto_36
    iget-object v5, v0, Lads_mobile_sdk/bm;->c:Lads_mobile_sdk/cu2;

    invoke-virtual {v5}, Lads_mobile_sdk/cu2;->a()Lut1;

    move-result-object v5

    move-object/from16 v6, p2

    iget-object v6, v6, Lads_mobile_sdk/a2;->c:Lfx0;

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v8, v0, Lads_mobile_sdk/bm;->a:Lli;

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, v0, Lads_mobile_sdk/bm;->f:Lads_mobile_sdk/rh0;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v9, Lcom/google/android/gms/ads/mediation/MediationBannerAdConfiguration;

    move-object v10, v9

    invoke-static {v6}, Lmu2;->b(Lfx0;)Landroid/os/Bundle;

    move-result-object v9

    invoke-static {v8, v3}, Lmu2;->a(Lli;Lcom/google/android/gms/ads/mediation/MediationExtrasReceiver;)Landroid/os/Bundle;

    move-result-object v8

    invoke-virtual {v5, v7}, Lut1;->a(Landroid/content/Context;)Z

    move-result v11

    invoke-static {v6, v5}, Lmu2;->d(Lfx0;Lut1;)Ljava/lang/String;

    move-result-object v15

    iget v5, v4, Ls4;->a:I

    iget v6, v4, Ls4;->b:I

    iget-object v12, v4, Ls4;->f:Ljava/lang/String;

    iget-boolean v13, v4, Ls4;->c:Z

    iget-boolean v4, v4, Ls4;->d:Z

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v16, Lcom/google/android/gms/ads/AdSize;

    move/from16 v22, v6

    move/from16 v21, v4

    move/from16 v17, v5

    move/from16 v18, v6

    move-object/from16 v19, v12

    move/from16 v20, v13

    invoke-direct/range {v16 .. v22}, Lcom/google/android/gms/ads/AdSize;-><init>(IILjava/lang/String;ZZI)V

    const-string v17, ""

    move-object v6, v10

    move-object v10, v8

    const-string v8, ""

    const/4 v12, 0x0

    const/4 v13, -0x1

    const/4 v14, -0x1

    invoke-direct/range {v6 .. v17}, Lcom/google/android/gms/ads/mediation/MediationBannerAdConfiguration;-><init>(Landroid/content/Context;Ljava/lang/String;Landroid/os/Bundle;Landroid/os/Bundle;ZLandroid/location/Location;IILjava/lang/String;Lcom/google/android/gms/ads/AdSize;Ljava/lang/String;)V

    new-instance v4, Lads_mobile_sdk/do1;

    const/4 v5, 0x1

    invoke-direct {v4, v2, v5}, Lads_mobile_sdk/do1;-><init>(Lads_mobile_sdk/ko1;I)V

    new-instance v2, Lads_mobile_sdk/ap1;

    const/4 v5, 0x2

    invoke-direct {v2, v0, v1, v4, v5}, Lads_mobile_sdk/ap1;-><init>(Lads_mobile_sdk/rh0;Lads_mobile_sdk/os;Lbk0;I)V

    invoke-virtual {v3, v6, v2}, Lcom/google/android/gms/ads/mediation/Adapter;->loadBannerAd(Lcom/google/android/gms/ads/mediation/MediationBannerAdConfiguration;Lcom/google/android/gms/ads/mediation/MediationAdLoadCallback;)V

    return-void
.end method

.method public final a(Lz23;)V
    .registers 2

    check-cast p1, Lads_mobile_sdk/ve0;

    iget-object p0, p1, Lads_mobile_sdk/ve0;->P:Ltv2;

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ldx2;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void
.end method
