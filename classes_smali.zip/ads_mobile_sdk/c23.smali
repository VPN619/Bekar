.class public final Lads_mobile_sdk/c23;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lbw2;


# instance fields
.field public final a:Lads_mobile_sdk/ha2;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/ha2;)V
    .registers 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/c23;->a:Lads_mobile_sdk/ha2;

    return-void
.end method


# virtual methods
.method public final a(Lads_mobile_sdk/cy0;Ljava/util/Map;Lvx;)Ljava/lang/Object;
    .registers 4

    .prologue
    const-string p1, "enabled"

    invoke-interface {p2, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    const-string p2, "true"

    const/4 p3, 0x1

    invoke-static {p1, p2, p3}, Lk72;->f0(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result p2

    if-nez p2, :cond_1c

    const-string p2, "false"

    invoke-static {p1, p2, p3}, Lk72;->f0(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result p2

    if-nez p2, :cond_1c

    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0

    :cond_1c
    iget-object p0, p0, Lads_mobile_sdk/c23;->a:Lads_mobile_sdk/ha2;

    invoke-static {p1}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result p1

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_25
    iget-object p0, p0, Lads_mobile_sdk/ha2;->e:Lw82;

    invoke-virtual {p0}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p0, Lads_mobile_sdk/hz0;

    const-class p2, Lads_mobile_sdk/hz0;

    monitor-enter p2
    :try_end_33
    .catch Ljava/lang/Exception; {:try_start_25 .. :try_end_33} :catch_43

    :try_start_33
    iget-object p0, p0, Lads_mobile_sdk/hz0;->a:Lads_mobile_sdk/ji;

    const-string p3, "paidv2_user_option"

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    invoke-virtual {p0, p1, p3}, Lads_mobile_sdk/ji;->a(Ljava/lang/Object;Ljava/lang/String;)V

    monitor-exit p2

    goto :goto_4a

    :catchall_40
    move-exception p0

    monitor-exit p2
    :try_end_42
    .catchall {:try_start_33 .. :try_end_42} :catchall_40

    :try_start_42
    throw p0
    :try_end_43
    .catch Ljava/lang/Exception; {:try_start_42 .. :try_end_43} :catch_43

    :catch_43
    move-exception p0

    const-string p1, "Exception while setting GpidV2 UserOption"

    const/4 p2, 0x4

    invoke-static {p2, p1, p0}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    :goto_4a
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method

.method public final b()I
    .registers 1

    const/16 p0, 0x1c

    return p0
.end method
