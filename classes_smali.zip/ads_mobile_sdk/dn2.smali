.class public final Lads_mobile_sdk/dn2;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public final synthetic a:Lhi1;

.field public final synthetic t:I


# direct methods
.method public synthetic constructor <init>(Lhi1;Lvx;I)V
    .registers 4

    iput p3, p0, Lads_mobile_sdk/dn2;->t:I

    iput-object p1, p0, Lads_mobile_sdk/dn2;->a:Lhi1;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 4

    .prologue
    iget p2, p0, Lads_mobile_sdk/dn2;->t:I

    iget-object p0, p0, Lads_mobile_sdk/dn2;->a:Lhi1;

    packed-switch p2, :pswitch_data_1c

    new-instance p2, Lads_mobile_sdk/dn2;

    const/4 v0, 0x2

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/dn2;-><init>(Lhi1;Lvx;I)V

    return-object p2

    :pswitch_e  #0x1
    new-instance p2, Lads_mobile_sdk/dn2;

    const/4 v0, 0x1

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/dn2;-><init>(Lhi1;Lvx;I)V

    return-object p2

    :pswitch_15  #0x0
    new-instance p2, Lads_mobile_sdk/dn2;

    const/4 v0, 0x0

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/dn2;-><init>(Lhi1;Lvx;I)V

    return-object p2

    :pswitch_data_1c
    .packed-switch 0x0
        :pswitch_15  #00000000
        :pswitch_e  #00000001
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .prologue
    iget v0, p0, Lads_mobile_sdk/dn2;->t:I

    sget-object v1, Lrg2;->a:Lrg2;

    iget-object p0, p0, Lads_mobile_sdk/dn2;->a:Lhi1;

    packed-switch v0, :pswitch_data_34

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/dn2;

    const/4 v0, 0x2

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/dn2;-><init>(Lhi1;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/dn2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object v1

    :pswitch_17  #0x1
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/dn2;

    const/4 v0, 0x1

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/dn2;-><init>(Lhi1;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/dn2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object v1

    :pswitch_25  #0x0
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/dn2;

    const/4 v0, 0x0

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/dn2;-><init>(Lhi1;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/dn2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object v1

    nop

    :pswitch_data_34
    .packed-switch 0x0
        :pswitch_25  #00000000
        :pswitch_17  #00000001
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .prologue
    iget v0, p0, Lads_mobile_sdk/dn2;->t:I

    iget-object v1, p0, Lads_mobile_sdk/dn2;->a:Lhi1;

    sget-object v2, Lrg2;->a:Lrg2;

    packed-switch v0, :pswitch_data_48

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    return-object v2

    :pswitch_d  #0x1
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    sget-object p1, Lads_mobile_sdk/ax0;->f:Lzn1;

    sget-object p1, Lxf1;->b:Lxf1;

    invoke-virtual {p0}, Lwx;->getContext()Lly;

    move-result-object p0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1, p0}, Lns2;->x(Ljy;Lly;)Lly;

    move-result-object p0

    sget-object p1, Lads_mobile_sdk/rh3;->b:Lyx1;

    invoke-interface {p0, p1}, Lly;->minusKey(Lky;)Lly;

    move-result-object p0

    sget-object p1, Ln8;->c:Ln8;

    invoke-interface {p0, p1}, Lly;->minusKey(Lky;)Lly;

    move-result-object p0

    sget-object p1, Lms1;->e:Lms1;

    invoke-interface {p0, p1}, Lly;->minusKey(Lky;)Lly;

    move-result-object p0

    invoke-static {p0}, Lw53;->a(Lly;)Lsx;

    move-result-object p0

    new-instance p1, Lads_mobile_sdk/dn2;

    const/4 v0, 0x0

    const/4 v3, 0x0

    invoke-direct {p1, v1, v3, v0}, Lads_mobile_sdk/dn2;-><init>(Lhi1;Lvx;I)V

    const/4 v0, 0x3

    invoke-static {p0, v3, v3, p1, v0}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    return-object v2

    :pswitch_41  #0x0
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object v2

    :pswitch_data_48
    .packed-switch 0x0
        :pswitch_41  #00000000
        :pswitch_d  #00000001
    .end packed-switch
.end method
