.class public final Lads_mobile_sdk/c42;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:J

.field public final b:Ljava/lang/String;

.field public final c:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;J)V
    .registers 5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p3, p0, Lads_mobile_sdk/c42;->a:J

    iput-object p1, p0, Lads_mobile_sdk/c42;->b:Ljava/lang/String;

    iput-object p2, p0, Lads_mobile_sdk/c42;->c:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .prologue
    if-ne p0, p1, :cond_3

    goto :goto_2a

    :cond_3
    instance-of v0, p1, Lads_mobile_sdk/c42;

    if-nez v0, :cond_8

    goto :goto_28

    :cond_8
    check-cast p1, Lads_mobile_sdk/c42;

    iget-wide v0, p0, Lads_mobile_sdk/c42;->a:J

    iget-wide v2, p1, Lads_mobile_sdk/c42;->a:J

    cmp-long v0, v0, v2

    if-eqz v0, :cond_13

    goto :goto_28

    :cond_13
    iget-object v0, p0, Lads_mobile_sdk/c42;->b:Ljava/lang/String;

    iget-object v1, p1, Lads_mobile_sdk/c42;->b:Ljava/lang/String;

    invoke-static {v0, v1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1e

    goto :goto_28

    :cond_1e
    iget-object p0, p0, Lads_mobile_sdk/c42;->c:Ljava/lang/String;

    iget-object p1, p1, Lads_mobile_sdk/c42;->c:Ljava/lang/String;

    invoke-virtual {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_2a

    :goto_28
    const/4 p0, 0x0

    return p0

    :cond_2a
    :goto_2a
    const/4 p0, 0x1

    return p0
.end method

.method public final hashCode()I
    .registers 4

    iget-wide v0, p0, Lads_mobile_sdk/c42;->a:J

    invoke-static {v0, v1}, Ljava/lang/Long;->hashCode(J)I

    move-result v0

    const/16 v1, 0x1f

    mul-int/2addr v0, v1

    iget-object v2, p0, Lads_mobile_sdk/c42;->b:Ljava/lang/String;

    invoke-static {v2, v0}, Luz;->e(Ljava/lang/String;I)I

    move-result v0

    iget-object p0, p0, Lads_mobile_sdk/c42;->c:Ljava/lang/String;

    invoke-static {v0, v1, p0}, Ly41;->j(IILjava/lang/String;)I

    move-result p0

    const/4 v0, 0x2

    invoke-static {v0}, Lc33;->x(I)I

    move-result v0

    add-int/2addr v0, p0

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 5

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "OfflineBufferedPingRecord(timestamp="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-wide v1, p0, Lads_mobile_sdk/c42;->a:J

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v1, ", gwsQueryId="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lads_mobile_sdk/c42;->b:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", eventState="

    const-string v2, "READY_TO_PING"

    const-string v3, ", url="

    iget-object p0, p0, Lads_mobile_sdk/c42;->c:Ljava/lang/String;

    invoke-static {v0, v3, p0, v1, v2}, Ly41;->x(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const-string p0, ")"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
