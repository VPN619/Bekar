.class public final Lads_mobile_sdk/eq2;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public a:Ljava/lang/String;

.field public b:Ljava/lang/String;

.field public c:Lads_mobile_sdk/av2;

.field public f:Z

.field public g:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 3

    sget-object v0, Lads_mobile_sdk/av2;->d:Lads_mobile_sdk/av2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v1, ""

    iput-object v1, p0, Lads_mobile_sdk/eq2;->a:Ljava/lang/String;

    iput-object v1, p0, Lads_mobile_sdk/eq2;->b:Ljava/lang/String;

    iput-object v0, p0, Lads_mobile_sdk/eq2;->c:Lads_mobile_sdk/av2;

    const/4 v0, 0x0

    iput-boolean v0, p0, Lads_mobile_sdk/eq2;->f:Z

    iput-object v1, p0, Lads_mobile_sdk/eq2;->g:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    .prologue
    if-ne p0, p1, :cond_3

    goto :goto_3a

    :cond_3
    instance-of v0, p1, Lads_mobile_sdk/eq2;

    if-nez v0, :cond_8

    goto :goto_38

    :cond_8
    check-cast p1, Lads_mobile_sdk/eq2;

    iget-object v0, p0, Lads_mobile_sdk/eq2;->a:Ljava/lang/String;

    iget-object v1, p1, Lads_mobile_sdk/eq2;->a:Ljava/lang/String;

    invoke-static {v0, v1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_15

    goto :goto_38

    :cond_15
    iget-object v0, p0, Lads_mobile_sdk/eq2;->b:Ljava/lang/String;

    iget-object v1, p1, Lads_mobile_sdk/eq2;->b:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_20

    goto :goto_38

    :cond_20
    iget-object v0, p0, Lads_mobile_sdk/eq2;->c:Lads_mobile_sdk/av2;

    iget-object v1, p1, Lads_mobile_sdk/eq2;->c:Lads_mobile_sdk/av2;

    if-eq v0, v1, :cond_27

    goto :goto_38

    :cond_27
    iget-boolean v0, p0, Lads_mobile_sdk/eq2;->f:Z

    iget-boolean v1, p1, Lads_mobile_sdk/eq2;->f:Z

    if-eq v0, v1, :cond_2e

    goto :goto_38

    :cond_2e
    iget-object p0, p0, Lads_mobile_sdk/eq2;->g:Ljava/lang/String;

    iget-object p1, p1, Lads_mobile_sdk/eq2;->g:Ljava/lang/String;

    invoke-virtual {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_3a

    :goto_38
    const/4 p0, 0x0

    return p0

    :cond_3a
    :goto_3a
    const/4 p0, 0x1

    return p0
.end method

.method public final hashCode()I
    .registers 4

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/eq2;->a:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/16 v1, 0x1f

    mul-int/2addr v0, v1

    iget-object v2, p0, Lads_mobile_sdk/eq2;->b:Ljava/lang/String;

    invoke-static {v0, v1, v2}, Ly41;->j(IILjava/lang/String;)I

    move-result v0

    iget-object v2, p0, Lads_mobile_sdk/eq2;->c:Lads_mobile_sdk/av2;

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    add-int/2addr v2, v0

    mul-int/lit16 v2, v2, 0x745f

    iget-boolean v0, p0, Lads_mobile_sdk/eq2;->f:Z

    if-eqz v0, :cond_1d

    const/4 v0, 0x1

    :cond_1d
    add-int/2addr v2, v0

    mul-int/2addr v2, v1

    iget-object p0, p0, Lads_mobile_sdk/eq2;->g:Ljava/lang/String;

    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result p0

    add-int/2addr p0, v2

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 8

    iget-object v0, p0, Lads_mobile_sdk/eq2;->a:Ljava/lang/String;

    iget-object v1, p0, Lads_mobile_sdk/eq2;->b:Ljava/lang/String;

    iget-object v2, p0, Lads_mobile_sdk/eq2;->c:Lads_mobile_sdk/av2;

    iget-boolean v3, p0, Lads_mobile_sdk/eq2;->f:Z

    iget-object p0, p0, Lads_mobile_sdk/eq2;->g:Ljava/lang/String;

    const-string v4, ", adUnitId="

    const-string v5, ", publisherRequestType="

    const-string v6, "PublisherRequestTraceMeta(publisherRequestId="

    invoke-static {v6, v0, v4, v1, v5}, Ly41;->t(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", signalGenerationRequestId=, preloadId=, skipUninitializedAdapters="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, ", requestAgent="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ")"

    invoke-static {v0, p0, v1}, Ly41;->s(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
