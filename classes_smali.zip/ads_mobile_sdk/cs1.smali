.class public final Lads_mobile_sdk/cs1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final i:Ljs1;


# instance fields
.field public final a:Lads_mobile_sdk/ki0;

.field public final b:Lads_mobile_sdk/bq1;

.field public final c:Lvy;

.field public final d:Lvy;

.field public final e:Lq63;

.field public final f:Lads_mobile_sdk/g0;

.field public final g:Lads_mobile_sdk/ux2;

.field public final h:Lads_mobile_sdk/kh3;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Ljs1;

    const-string v1, "[^/\\\\\\s]+(\\.(?i)(jpg|png|gif|bmp|webp))$"

    invoke-direct {v0, v1}, Ljs1;-><init>(Ljava/lang/String;)V

    sput-object v0, Lads_mobile_sdk/cs1;->i:Ljs1;

    return-void
.end method

.method public constructor <init>(Lads_mobile_sdk/ki0;Lads_mobile_sdk/bq1;Lvy;Lvy;Lq63;Lads_mobile_sdk/g0;Lads_mobile_sdk/ux2;Lads_mobile_sdk/kh3;)V
    .registers 9

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/cs1;->a:Lads_mobile_sdk/ki0;

    iput-object p2, p0, Lads_mobile_sdk/cs1;->b:Lads_mobile_sdk/bq1;

    iput-object p3, p0, Lads_mobile_sdk/cs1;->c:Lvy;

    iput-object p4, p0, Lads_mobile_sdk/cs1;->d:Lvy;

    iput-object p5, p0, Lads_mobile_sdk/cs1;->e:Lq63;

    iput-object p6, p0, Lads_mobile_sdk/cs1;->f:Lads_mobile_sdk/g0;

    iput-object p7, p0, Lads_mobile_sdk/cs1;->g:Lads_mobile_sdk/ux2;

    iput-object p8, p0, Lads_mobile_sdk/cs1;->h:Lads_mobile_sdk/kh3;

    return-void
.end method


# virtual methods
.method public final a(Ljava/io/ByteArrayInputStream;Ljava/lang/String;Ljava/lang/String;Landroid/content/Context;Lads_mobile_sdk/cy0;)V
    .registers 23

    .prologue
    move-object/from16 v0, p4

    new-instance v1, Landroid/content/ContentValues;

    invoke-direct {v1}, Landroid/content/ContentValues;-><init>()V

    const-string v2, "_display_name"

    move-object/from16 v3, p2

    invoke-virtual {v1, v2, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "image/"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    move-object/from16 v3, p3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, "mime_type"

    invoke-virtual {v1, v3, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const-string v3, "is_pending"

    const/4 v4, 0x1

    const/16 v5, 0x1e

    if-lt v2, v5, :cond_33

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-virtual {v1, v3, v6}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    :cond_33
    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v6

    sget-object v7, Landroid/provider/MediaStore$Images$Media;->EXTERNAL_CONTENT_URI:Landroid/net/Uri;

    invoke-virtual {v6, v7, v1}, Landroid/content/ContentResolver;->insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;

    move-result-object v7

    if-nez v7, :cond_49

    const-string v0, "Unable to store picture"

    move-object/from16 v1, p0

    move-object/from16 v2, p5

    invoke-virtual {v1, v0, v2, v4}, Lads_mobile_sdk/cs1;->a(Ljava/lang/String;Lads_mobile_sdk/cy0;Z)V

    return-void

    :cond_49
    sget-object v8, Lads_mobile_sdk/mz2;->d:Lads_mobile_sdk/mz2;

    sget-object v9, Lads_mobile_sdk/nz2;->a:[Ljava/lang/String;

    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v9

    if-ge v2, v5, :cond_5c

    invoke-virtual {v7}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v10

    goto :goto_5d

    :cond_5c
    move-object v10, v7

    :goto_5d
    invoke-virtual {v10}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    move-result-object v11

    const-string v12, "android.resource"

    invoke-virtual {v12, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    const/4 v13, -0x1

    const/4 v14, 0x0

    const-string v15, "w"

    if-eqz v12, :cond_74

    invoke-virtual {v9, v10, v15}, Landroid/content/ContentResolver;->openAssetFileDescriptor(Landroid/net/Uri;Ljava/lang/String;)Landroid/content/res/AssetFileDescriptor;

    move-result-object v0

    :goto_71
    move-object v4, v0

    goto/16 :goto_191

    :cond_74
    const-string v12, "content"

    invoke-virtual {v12, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    const-string v5, "Content resolver returned null value."

    if-eqz v12, :cond_17c

    invoke-virtual {v10}, Landroid/net/Uri;->getAuthority()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v12

    invoke-virtual {v12, v11, v14}, Landroid/content/pm/PackageManager;->resolveContentProvider(Ljava/lang/String;I)Landroid/content/pm/ProviderInfo;

    move-result-object v12

    move/from16 p3, v4

    const/16 v4, 0x40

    if-nez v12, :cond_ae

    invoke-virtual {v11, v4}, Ljava/lang/String;->lastIndexOf(I)I

    move-result v14

    if-le v14, v13, :cond_a6

    add-int/lit8 v14, v14, 0x1

    invoke-virtual {v11, v14}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v12

    const/4 v14, 0x0

    invoke-virtual {v12, v11, v14}, Landroid/content/pm/PackageManager;->resolveContentProvider(Ljava/lang/String;I)Landroid/content/pm/ProviderInfo;

    move-result-object v12

    goto :goto_a7

    :cond_a6
    const/4 v14, 0x0

    :goto_a7
    if-nez v12, :cond_ae

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    goto/16 :goto_16e

    :cond_ae
    iget-object v8, v8, Lads_mobile_sdk/mz2;->b:Ljq0;

    invoke-virtual {v8, v14}, Ljq0;->r(I)Lhq0;

    move-result-object v8

    :goto_b4
    invoke-virtual {v8}, Lg0;->hasNext()Z

    move-result v14

    const/16 v16, 0x3

    const/4 v13, 0x2

    if-eqz v14, :cond_f1

    invoke-virtual {v8}, Lg0;->next()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Lc13;

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v10}, Landroid/net/Uri;->getAuthority()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v14, v4}, Ljava/lang/String;->lastIndexOf(I)I

    move-result v14

    const/4 v4, -0x1

    if-le v14, v4, :cond_db

    const-string v4, "android.permission.INTERACT_ACROSS_USERS"

    invoke-static {v0, v4}, Lnp3;->v(Landroid/content/Context;Ljava/lang/String;)I

    move-result v4

    if-nez v4, :cond_db

    move/from16 v16, v13

    :cond_db
    invoke-static/range {v16 .. v16}, Lvr0;->a(I)I

    move-result v4

    move/from16 v14, p3

    if-eqz v4, :cond_ee

    if-eq v4, v14, :cond_eb

    move/from16 p3, v14

    const/16 v4, 0x40

    const/4 v13, -0x1

    goto :goto_b4

    :cond_eb
    move/from16 v16, v13

    goto :goto_f3

    :cond_ee
    move/from16 v16, v14

    goto :goto_f3

    :cond_f1
    move/from16 v14, p3

    :goto_f3
    invoke-static/range {v16 .. v16}, Lvr0;->a(I)I

    move-result v4

    if-eqz v4, :cond_16e

    if-eq v4, v14, :cond_166

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    iget-object v8, v12, Landroid/content/pm/ProviderInfo;->packageName:Ljava/lang/String;

    invoke-virtual {v4, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_166

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v4

    invoke-static {}, Landroid/os/Process;->myUid()I

    move-result v8

    invoke-virtual {v0, v10, v4, v8, v13}, Landroid/content/Context;->checkUriPermission(Landroid/net/Uri;III)I

    move-result v0

    if-nez v0, :cond_116

    goto :goto_16e

    :cond_116
    iget-boolean v0, v12, Landroid/content/pm/ProviderInfo;->exported:Z

    if-eqz v0, :cond_16e

    sget-object v0, Lads_mobile_sdk/nz2;->b:[Ljava/lang/String;

    array-length v4, v0

    const/4 v14, 0x0

    :goto_11e
    if-ge v14, v4, :cond_12c

    aget-object v8, v0, v14

    invoke-virtual {v8, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_129

    goto :goto_16e

    :cond_129
    add-int/lit8 v14, v14, 0x1

    goto :goto_11e

    :cond_12c
    sget-object v0, Lads_mobile_sdk/nz2;->c:[Ljava/lang/String;

    array-length v4, v0

    const/4 v14, 0x0

    :goto_130
    if-ge v14, v4, :cond_13e

    aget-object v8, v0, v14

    invoke-virtual {v8, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_13b

    goto :goto_16e

    :cond_13b
    add-int/lit8 v14, v14, 0x1

    goto :goto_130

    :cond_13e
    sget-object v0, Lads_mobile_sdk/nz2;->a:[Ljava/lang/String;

    const/4 v14, 0x0

    :goto_141
    const/4 v4, 0x7

    if-ge v14, v4, :cond_16e

    aget-object v4, v0, v14

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v8

    const/4 v11, 0x1

    sub-int/2addr v8, v11

    invoke-virtual {v4, v8}, Ljava/lang/String;->charAt(I)C

    move-result v8

    iget-object v13, v12, Landroid/content/pm/ProviderInfo;->packageName:Ljava/lang/String;

    const/16 v11, 0x2e

    if-ne v8, v11, :cond_15d

    invoke-virtual {v13, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v4

    if-nez v4, :cond_166

    goto :goto_163

    :cond_15d
    invoke-virtual {v13, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_166

    :goto_163
    add-int/lit8 v14, v14, 0x1

    goto :goto_141

    :cond_166
    new-instance v0, Ljava/io/FileNotFoundException;

    const-string v1, "Can\'t open content uri."

    invoke-direct {v0, v1}, Ljava/io/FileNotFoundException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_16e
    :goto_16e
    invoke-virtual {v9, v10, v15}, Landroid/content/ContentResolver;->openAssetFileDescriptor(Landroid/net/Uri;Ljava/lang/String;)Landroid/content/res/AssetFileDescriptor;

    move-result-object v0

    if-eqz v0, :cond_176

    goto/16 :goto_71

    :cond_176
    new-instance v0, Ljava/io/FileNotFoundException;

    invoke-direct {v0, v5}, Ljava/io/FileNotFoundException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_17c
    const-string v4, "file"

    invoke-virtual {v4, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_202

    invoke-virtual {v9, v10, v15}, Landroid/content/ContentResolver;->openAssetFileDescriptor(Landroid/net/Uri;Ljava/lang/String;)Landroid/content/res/AssetFileDescriptor;

    move-result-object v4

    if-eqz v4, :cond_1fc

    :try_start_18a
    invoke-virtual {v4}, Landroid/content/res/AssetFileDescriptor;->getParcelFileDescriptor()Landroid/os/ParcelFileDescriptor;

    move-result-object v5

    invoke-static {v0, v5, v10, v8}, Lads_mobile_sdk/nz2;->a(Landroid/content/Context;Landroid/os/ParcelFileDescriptor;Landroid/net/Uri;Lads_mobile_sdk/mz2;)V
    :try_end_191
    .catch Ljava/io/FileNotFoundException; {:try_start_18a .. :try_end_191} :catch_1dd
    .catch Ljava/io/IOException; {:try_start_18a .. :try_end_191} :catch_1db

    :goto_191
    const/4 v0, 0x0

    if-eqz v4, :cond_1ae

    :try_start_194
    invoke-virtual {v4}, Landroid/content/res/AssetFileDescriptor;->createOutputStream()Ljava/io/FileOutputStream;

    move-result-object v4
    :try_end_198
    .catch Ljava/io/IOException; {:try_start_194 .. :try_end_198} :catch_19a

    move-object v5, v4

    goto :goto_1af

    :catch_19a
    move-exception v0

    new-instance v1, Ljava/io/FileNotFoundException;

    const-string v2, "Unable to create stream"

    invoke-direct {v1, v2}, Ljava/io/FileNotFoundException;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    :try_start_1a5
    invoke-virtual {v4}, Landroid/content/res/AssetFileDescriptor;->close()V
    :try_end_1a8
    .catch Ljava/io/IOException; {:try_start_1a5 .. :try_end_1a8} :catch_1a9

    goto :goto_1ad

    :catch_1a9
    move-exception v0

    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_1ad
    throw v1

    :cond_1ae
    move-object v5, v0

    :goto_1af
    sget v4, Lol;->a:I

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v4, 0x2000

    new-array v8, v4, [B

    move-object/from16 v9, p1

    :goto_1ba
    invoke-virtual {v9, v8}, Ljava/io/InputStream;->read([B)I

    move-result v4

    const/4 v10, -0x1

    if-ne v4, v10, :cond_1d4

    const/16 v11, 0x1e

    if-lt v2, v11, :cond_1d3

    invoke-virtual {v1}, Landroid/content/ContentValues;->clear()V

    const/4 v14, 0x0

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v1, v3, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    invoke-virtual {v6, v7, v1, v0, v0}, Landroid/content/ContentResolver;->update(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I

    :cond_1d3
    return-void

    :cond_1d4
    const/16 v11, 0x1e

    const/4 v14, 0x0

    invoke-virtual {v5, v8, v14, v4}, Ljava/io/OutputStream;->write([BII)V

    goto :goto_1ba

    :catch_1db
    move-exception v0

    goto :goto_1e0

    :catch_1dd
    move-exception v0

    move-object v1, v0

    goto :goto_1f3

    :goto_1e0
    new-instance v1, Ljava/io/FileNotFoundException;

    const-string v2, "Validation failed."

    invoke-direct {v1, v2}, Ljava/io/FileNotFoundException;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    :try_start_1ea
    invoke-virtual {v4}, Landroid/content/res/AssetFileDescriptor;->close()V
    :try_end_1ed
    .catch Ljava/io/IOException; {:try_start_1ea .. :try_end_1ed} :catch_1ee

    goto :goto_1f2

    :catch_1ee
    move-exception v0

    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_1f2
    throw v1

    :goto_1f3
    :try_start_1f3
    invoke-virtual {v4}, Landroid/content/res/AssetFileDescriptor;->close()V
    :try_end_1f6
    .catch Ljava/io/IOException; {:try_start_1f3 .. :try_end_1f6} :catch_1f7

    goto :goto_1fb

    :catch_1f7
    move-exception v0

    invoke-virtual {v1, v0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_1fb
    throw v1

    :cond_1fc
    new-instance v0, Ljava/io/FileNotFoundException;

    invoke-direct {v0, v5}, Ljava/io/FileNotFoundException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_202
    new-instance v0, Ljava/io/FileNotFoundException;

    const-string v1, "Unsupported scheme"

    invoke-direct {v0, v1}, Ljava/io/FileNotFoundException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public final a(Ljava/lang/String;Lads_mobile_sdk/cy0;Z)V
    .registers 11

    .prologue
    const-string v0, "Store picture error: "

    invoke-virtual {v0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x0

    invoke-static {v0, v5}, Lads_mobile_sdk/nw;->c(Ljava/lang/String;Ljava/lang/Exception;)V

    if-eqz p3, :cond_10

    const/4 p3, 0x6

    invoke-static {p3, p1, v5}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    :cond_10
    new-instance v1, Lads_mobile_sdk/r9;

    const/16 v6, 0xc

    move-object v2, p0

    move-object v4, p1

    move-object v3, p2

    invoke-direct/range {v1 .. v6}, Lads_mobile_sdk/r9;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lvx;I)V

    const/4 p0, 0x3

    iget-object p1, v2, Lads_mobile_sdk/cs1;->c:Lvy;

    invoke-static {p1, v5, v5, v1, p0}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    return-void
.end method
