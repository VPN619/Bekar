.class public final Lads_mobile_sdk/ax0;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final f:Lzn1;

.field public static final g:Ljava/util/concurrent/atomic/AtomicReference;

.field public static final h:Ljs1;

.field public static final i:Ljs1;


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:Lads_mobile_sdk/g0;

.field public final c:Lads_mobile_sdk/qr0;

.field public final d:Lads_mobile_sdk/l0;

.field public final e:Ljava/lang/Class;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    new-instance v0, Lzn1;

    const/16 v1, 0xd

    invoke-direct {v0, v1}, Lzn1;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/ax0;->f:Lzn1;

    const-string v0, "/pcs/click"

    const-string v1, "/dbm/clk"

    const-string v2, "/aclk"

    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcs;->U([Ljava/lang/Object;)Ljava/util/List;

    new-instance v0, Ljava/util/concurrent/atomic/AtomicReference;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    sput-object v0, Lads_mobile_sdk/ax0;->g:Ljava/util/concurrent/atomic/AtomicReference;

    new-instance v0, Ljs1;

    const-string v1, "^(ca-app-pub-[0-9]{16})~([0-9]{10})$"

    invoke-direct {v0, v1}, Ljs1;-><init>(Ljava/lang/String;)V

    sput-object v0, Lads_mobile_sdk/ax0;->h:Ljs1;

    new-instance v0, Ljs1;

    const-string v1, "^(ca-app-pub-[a-zA-Z0-9\\-]+)/([a-zA-Z0-9_\\-]+)(/.*)?$"

    invoke-direct {v0, v1}, Ljs1;-><init>(Ljava/lang/String;)V

    sput-object v0, Lads_mobile_sdk/ax0;->i:Ljs1;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lads_mobile_sdk/g0;Lads_mobile_sdk/qr0;Lads_mobile_sdk/l0;Ljava/lang/Class;)V
    .registers 6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/ax0;->a:Landroid/content/Context;

    iput-object p2, p0, Lads_mobile_sdk/ax0;->b:Lads_mobile_sdk/g0;

    iput-object p3, p0, Lads_mobile_sdk/ax0;->c:Lads_mobile_sdk/qr0;

    iput-object p4, p0, Lads_mobile_sdk/ax0;->d:Lads_mobile_sdk/l0;

    iput-object p5, p0, Lads_mobile_sdk/ax0;->e:Ljava/lang/Class;

    return-void
.end method

.method public static a(Landroid/content/Context;)Lads_mobile_sdk/zw0;
    .registers 4

    .prologue
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lads_mobile_sdk/zw0;

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/Locale;->getLanguage()Ljava/lang/String;

    move-result-object v1

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v2

    invoke-virtual {v2}, Ljava/util/Locale;->getCountry()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v1, v2}, Lads_mobile_sdk/zw0;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x21

    if-lt v1, v2, :cond_2d

    const-class v1, Landroid/app/LocaleManager;

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/app/LocaleManager;

    if-eqz p0, :cond_3e

    invoke-virtual {p0}, Landroid/app/LocaleManager;->getSystemLocales()Landroid/os/LocaleList;

    move-result-object p0

    goto :goto_3f

    :cond_2d
    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    if-eqz p0, :cond_3e

    invoke-virtual {p0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object p0

    if-eqz p0, :cond_3e

    invoke-virtual {p0}, Landroid/content/res/Configuration;->getLocales()Landroid/os/LocaleList;

    move-result-object p0

    goto :goto_3f

    :cond_3e
    const/4 p0, 0x0

    :goto_3f
    if-eqz p0, :cond_59

    invoke-virtual {p0}, Landroid/os/LocaleList;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_59

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/os/LocaleList;->get(I)Ljava/util/Locale;

    move-result-object p0

    new-instance v0, Lads_mobile_sdk/zw0;

    invoke-virtual {p0}, Ljava/util/Locale;->getLanguage()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0}, Ljava/util/Locale;->getCountry()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, v1, p0}, Lads_mobile_sdk/zw0;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    :cond_59
    return-object v0
.end method


# virtual methods
.method public final a()J
    .registers 4

    .prologue
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x21

    iget-object p0, p0, Lads_mobile_sdk/ax0;->a:Landroid/content/Context;

    if-lt v0, v1, :cond_26

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    if-eqz v0, :cond_23

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const-wide/16 v1, 0x80

    invoke-static {v1, v2}, Landroid/content/pm/PackageManager$PackageInfoFlags;->of(J)Landroid/content/pm/PackageManager$PackageInfoFlags;

    move-result-object v1

    invoke-virtual {v0, p0, v1}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;Landroid/content/pm/PackageManager$PackageInfoFlags;)Landroid/content/pm/PackageInfo;

    move-result-object p0

    if-eqz p0, :cond_23

    invoke-virtual {p0}, Landroid/content/pm/PackageInfo;->getLongVersionCode()J

    move-result-wide v0

    return-wide v0

    :cond_23
    const-wide/16 v0, 0x0

    return-wide v0

    :cond_26
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    if-eqz v0, :cond_3b

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/16 v1, 0x80

    invoke-virtual {v0, p0, v1}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p0

    if-eqz p0, :cond_3b

    iget p0, p0, Landroid/content/pm/PackageInfo;->versionCode:I

    goto :goto_3c

    :cond_3b
    const/4 p0, 0x0

    :goto_3c
    int-to-long v0, p0

    return-wide v0
.end method

.method public final a(Landroid/content/Context;Lez2;)Landroid/content/Intent;
    .registers 11

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Landroid/content/Intent;

    iget-object v1, p0, Lads_mobile_sdk/ax0;->e:Ljava/lang/Class;

    invoke-direct {v0, p1, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    new-instance v1, Landroid/os/Bundle;

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    iget-object p0, p0, Lads_mobile_sdk/ax0;->d:Lads_mobile_sdk/l0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v2, p0, Lads_mobile_sdk/l0;->c:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v2

    iget-object v3, p0, Lads_mobile_sdk/l0;->a:Lvy;

    new-instance v4, Lads_mobile_sdk/gp;

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-direct {v4, p0, v2, v6, v5}, Lads_mobile_sdk/gp;-><init>(Ljava/lang/Object;ILvx;I)V

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v5, La42;

    invoke-direct {v5, v4, v6}, La42;-><init>(Lpk0;Lvx;)V

    const/4 v4, 0x2

    sget-object v7, Ly90;->a:Ly90;

    invoke-static {v3, v7, v6, v5, v4}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    move-result-object v3

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    iget-object p0, p0, Lads_mobile_sdk/l0;->d:Ljava/util/concurrent/ConcurrentHashMap;

    new-instance v5, Lads_mobile_sdk/j0;

    invoke-direct {v5, p2, v3}, Lads_mobile_sdk/j0;-><init>(Lez2;Lx52;)V

    invoke-virtual {p0, v4, v5}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string p0, "ad_activity_delegate"

    invoke-virtual {v1, p0, v2}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const-string p0, "ad_activity_delegate_bundle"

    invoke-virtual {v0, p0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Bundle;)Landroid/content/Intent;

    instance-of p0, p1, Landroid/app/Activity;

    if-nez p0, :cond_56

    const/high16 p0, 0x10000000

    invoke-virtual {v0, p0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    :cond_56
    return-object v0
.end method

.method public final a(Landroid/content/Intent;)Z
    .registers 4

    .prologue
    const/4 v0, 0x0

    if-nez p1, :cond_4

    return v0

    :cond_4
    iget-object v1, p0, Lads_mobile_sdk/ax0;->b:Lads_mobile_sdk/g0;

    invoke-virtual {v1}, Lads_mobile_sdk/g0;->b()Landroid/app/Activity;

    move-result-object v1

    if-eqz v1, :cond_d

    goto :goto_f

    :cond_d
    iget-object v1, p0, Lads_mobile_sdk/ax0;->a:Landroid/content/Context;

    :goto_f
    instance-of p0, v1, Landroid/app/Activity;

    if-nez p0, :cond_18

    const/high16 p0, 0x10000000

    invoke-virtual {p1, p0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    :cond_18
    :try_start_18
    invoke-virtual {v1, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_1b
    .catch Landroid/content/ActivityNotFoundException; {:try_start_18 .. :try_end_1b} :catch_1d

    const/4 p0, 0x1

    return p0

    :catch_1d
    move-exception p0

    new-instance p1, Ljava/lang/StringBuilder;

    const-string v1, "Exception starting Activity: "

    invoke-direct {p1, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 p1, 0x0

    const/4 v1, 0x6

    invoke-static {v1, p0, p1}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    return v0
.end method

.method public final a(Landroid/net/Uri;)Z
    .registers 5

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0, p1}, Lads_mobile_sdk/ax0;->b(Landroid/net/Uri;)Z

    move-result v0

    if-eqz v0, :cond_56

    invoke-virtual {p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object p1

    iget-object p0, p0, Lads_mobile_sdk/ax0;->c:Lads_mobile_sdk/qr0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v0, "^[^?]*(/aclk|/pcs/click|/dbm/clk).*"

    invoke-static {v0}, Luz;->G(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sget-object v1, Lads_mobile_sdk/fo;->a$15:Lads_mobile_sdk/fo;

    const-string v2, "gads:click_url_pattern_match"

    invoke-virtual {p0, v2, v0, v1}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/util/List;

    instance-of v0, p0, Ljava/util/Collection;

    if-eqz v0, :cond_2d

    invoke-interface {p0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_2d

    goto :goto_56

    :cond_2d
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_31
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_56

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0, p1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/regex/Matcher;->find()Z

    move-result v0

    if-eqz v0, :cond_31

    const/4 p0, 0x1

    return p0

    :cond_56
    :goto_56
    const/4 p0, 0x0

    return p0
.end method

.method public final b(Landroid/net/Uri;)Z
    .registers 6

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Landroid/net/Uri;->getHost()Ljava/lang/String;

    move-result-object p1

    const/4 v0, 0x0

    if-eqz p1, :cond_4a

    iget-object p0, p0, Lads_mobile_sdk/ax0;->c:Lads_mobile_sdk/qr0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v1, ".googleadservices.com"

    const-string v2, ".googlesyndication.com"

    const-string v3, ".doubleclick.net"

    filled-new-array {v3, v1, v2}, [Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcs;->U([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    sget-object v2, Lads_mobile_sdk/fo;->a$15:Lads_mobile_sdk/fo;

    const-string v3, "gads:google_ad_domain_suffixes"

    invoke-virtual {p0, v3, v1, v2}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/util/List;

    instance-of v1, p0, Ljava/util/Collection;

    if-eqz v1, :cond_32

    invoke-interface {p0}, Ljava/util/Collection;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_32

    goto :goto_4a

    :cond_32
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_36
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_4a

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {p1, v1, v0}, Lk72;->e0(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v1

    if-eqz v1, :cond_36

    const/4 p0, 0x1

    return p0

    :cond_4a
    :goto_4a
    return v0
.end method

.method public final c()Z
    .registers 3

    .prologue
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1a

    iget-object p0, p0, Lads_mobile_sdk/ax0;->a:Landroid/content/Context;

    if-lt v0, v1, :cond_13

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    if-eqz p0, :cond_1e

    invoke-virtual {p0}, Landroid/content/pm/PackageManager;->isInstantApp()Z

    move-result p0

    return p0

    :cond_13
    :try_start_13
    invoke-virtual {p0}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object p0

    const-string v0, "com.google.android.instantapps.supervisor.InstantAppsRuntime"

    invoke-virtual {p0, v0}, Ljava/lang/ClassLoader;->loadClass(Ljava/lang/String;)Ljava/lang/Class;
    :try_end_1c
    .catch Ljava/lang/ClassNotFoundException; {:try_start_13 .. :try_end_1c} :catch_1e

    const/4 p0, 0x1

    return p0

    :catch_1e
    :cond_1e
    const/4 p0, 0x0

    return p0
.end method

.method public final c(Landroid/net/Uri;)Z
    .registers 5

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0, p1}, Lads_mobile_sdk/ax0;->b(Landroid/net/Uri;)Z

    move-result v0

    if-eqz v0, :cond_56

    invoke-virtual {p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object p1

    iget-object p0, p0, Lads_mobile_sdk/ax0;->c:Lads_mobile_sdk/qr0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v0, "^[^?]*(/adview|/pcs/view).*"

    invoke-static {v0}, Luz;->G(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    sget-object v1, Lads_mobile_sdk/fo;->a$15:Lads_mobile_sdk/fo;

    const-string v2, "gads:impression_url_pattern_match"

    invoke-virtual {p0, v2, v0, v1}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/util/List;

    instance-of v0, p0, Ljava/util/Collection;

    if-eqz v0, :cond_2d

    invoke-interface {p0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_2d

    goto :goto_56

    :cond_2d
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_31
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_56

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0, p1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/regex/Matcher;->find()Z

    move-result v0

    if-eqz v0, :cond_31

    const/4 p0, 0x1

    return p0

    :cond_56
    :goto_56
    const/4 p0, 0x0

    return p0
.end method

.method public final d(Landroid/net/Uri;)Ljava/util/Map;
    .registers 9

    .prologue
    iget-object p0, p0, Lads_mobile_sdk/ax0;->c:Lads_mobile_sdk/qr0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    sget-object v1, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    const-string v2, "gads:uri_query_to_map:enabled"

    invoke-virtual {p0, v2, v0, v1}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v0, 0x0

    if-eqz p0, :cond_6d

    new-instance p0, Ljava/util/LinkedHashMap;

    invoke-direct {p0}, Ljava/util/LinkedHashMap;-><init>()V

    invoke-virtual {p1}, Landroid/net/Uri;->isOpaque()Z

    move-result v1

    if-eqz v1, :cond_24

    goto :goto_6c

    :cond_24
    invoke-virtual {p1}, Landroid/net/Uri;->getEncodedQuery()Ljava/lang/String;

    move-result-object p1

    if-nez p1, :cond_2b

    goto :goto_6c

    :cond_2b
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    :goto_2f
    const/16 v2, 0x26

    const/4 v3, 0x4

    invoke-static {p1, v2, v0, v3}, Lc72;->r0(Ljava/lang/CharSequence;CII)I

    move-result v2

    const/4 v4, -0x1

    if-eq v2, v4, :cond_3b

    move v5, v2

    goto :goto_3c

    :cond_3b
    move v5, v1

    :goto_3c
    const/16 v6, 0x3d

    invoke-static {p1, v6, v0, v3}, Lc72;->r0(Ljava/lang/CharSequence;CII)I

    move-result v3

    if-gt v3, v5, :cond_46

    if-ne v3, v4, :cond_47

    :cond_46
    move v3, v5

    :cond_47
    invoke-virtual {p1, v0, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/net/Uri;->decode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-ne v3, v5, :cond_54

    const-string v3, ""

    goto :goto_5e

    :cond_54
    add-int/lit8 v3, v3, 0x1

    invoke-virtual {p1, v3, v5}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/net/Uri;->decode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    :goto_5e
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {p0, v0, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    if-eq v2, v4, :cond_6c

    add-int/lit8 v0, v2, 0x1

    goto :goto_2f

    :cond_6c
    :goto_6c
    return-object p0

    :cond_6d
    invoke-virtual {p1}, Landroid/net/Uri;->isOpaque()Z

    move-result p0

    if-eqz p0, :cond_76

    sget-object p0, Lca0;->a:Lca0;

    return-object p0

    :cond_76
    invoke-virtual {p1}, Landroid/net/Uri;->getQueryParameterNames()Ljava/util/Set;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lis;

    invoke-direct {v1, v0, p0}, Lis;-><init>(ILjava/lang/Object;)V

    sget-object p0, Lads_mobile_sdk/fo;->a$28:Lads_mobile_sdk/fo;

    new-instance v0, Lxd0;

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2, p0}, Lxd0;-><init>(Li02;ZLbk0;)V

    new-instance p0, Ljava/util/LinkedHashMap;

    invoke-direct {p0}, Ljava/util/LinkedHashMap;-><init>()V

    new-instance v1, Lrd0;

    invoke-direct {v1, v0}, Lrd0;-><init>(Lxd0;)V

    :goto_94
    invoke-virtual {v1}, Lrd0;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_a9

    invoke-virtual {v1}, Lrd0;->next()Ljava/lang/Object;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Ljava/lang/String;

    invoke-virtual {p1, v2}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-interface {p0, v0, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_94

    :cond_a9
    return-object p0
.end method
