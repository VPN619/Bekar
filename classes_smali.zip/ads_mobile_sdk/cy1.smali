.class public final Lads_mobile_sdk/cy1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Li43;


# instance fields
.field public final a:Ltv2;

.field public final b:Lads_mobile_sdk/k71;

.field public final c:Ln63;

.field public final d:Lads_mobile_sdk/qr0;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/ab0;Lads_mobile_sdk/k71;Ln63;Lads_mobile_sdk/qr0;)V
    .registers 5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/cy1;->a:Ltv2;

    iput-object p2, p0, Lads_mobile_sdk/cy1;->b:Lads_mobile_sdk/k71;

    iput-object p3, p0, Lads_mobile_sdk/cy1;->c:Ln63;

    iput-object p4, p0, Lads_mobile_sdk/cy1;->d:Lads_mobile_sdk/qr0;

    return-void
.end method


# virtual methods
.method public final a(Lm4;I)Lb13;
    .registers 15

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    instance-of v0, p1, Lxb1;

    if-eqz v0, :cond_b

    move-object v0, p1

    check-cast v0, Lxb1;

    goto :goto_c

    :cond_b
    const/4 v0, 0x0

    :goto_c
    const/4 v1, 0x1

    if-nez v0, :cond_27

    new-instance p0, Lads_mobile_sdk/ev0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p1

    invoke-static {p1}, Lxr1;->a(Ljava/lang/Class;)Llq;

    move-result-object p1

    invoke-virtual {p1}, Llq;->c()Ljava/lang/String;

    move-result-object p1

    const-string p2, "Expected NativeRequest but received "

    invoke-static {p2, p1}, Lrt2;->h(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1, v1}, Lads_mobile_sdk/ev0;-><init>(Ljava/lang/String;I)V

    return-object p0

    :cond_27
    iget-object v2, p0, Lads_mobile_sdk/cy1;->c:Ln63;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v2, Ljava/util/Random;

    invoke-direct {v2}, Ljava/util/Random;-><init>()V

    const v3, 0x7fffffff

    invoke-virtual {v2, v3}, Ljava/util/Random;->nextInt(I)I

    move-result v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v7

    new-instance v2, Lads_mobile_sdk/hv0;

    iget-object v3, p0, Lads_mobile_sdk/cy1;->a:Ltv2;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-object v11, v3

    check-cast v11, Le33;

    sget-object v5, Lads_mobile_sdk/av2;->i:Lads_mobile_sdk/av2;

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v3, p0, Lads_mobile_sdk/cy1;->b:Lads_mobile_sdk/k71;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p0, Lads_mobile_sdk/cy1;->d:Lads_mobile_sdk/qr0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1}, Ljava/util/Optional;->of(Ljava/lang/Object;)Ljava/util/Optional;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-object v4, v3

    new-instance v3, Lads_mobile_sdk/j71;

    move-object v8, v4

    iget-object v4, v8, Lads_mobile_sdk/k71;->a:Lads_mobile_sdk/d91;

    iget-object v9, v8, Lads_mobile_sdk/k71;->b:Lx43;

    iget-object v10, v8, Lads_mobile_sdk/k71;->c:Lkm0;

    const/4 v8, 0x0

    invoke-direct/range {v3 .. v10}, Lads_mobile_sdk/j71;-><init>(Lads_mobile_sdk/d91;Lads_mobile_sdk/av2;Ljava/util/Optional;Ljava/lang/String;ZLx43;Lkm0;)V

    invoke-interface {v11, p1}, Le33;->a(Lm4;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Le33;

    invoke-interface {p1, v5}, Le33;->a(Lads_mobile_sdk/av2;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Le33;

    new-instance v4, Lads_mobile_sdk/eq2;

    invoke-direct {v4}, Lads_mobile_sdk/eq2;-><init>()V

    invoke-interface {p1, v4}, Le33;->a(Lads_mobile_sdk/eq2;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Le33;

    new-instance v4, Lads_mobile_sdk/ih1;

    invoke-direct {v4}, Lads_mobile_sdk/ih1;-><init>()V

    invoke-interface {p1, v4}, Le33;->a(Lads_mobile_sdk/ih1;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Le33;

    invoke-interface {p1, v3}, Le33;->a(Lads_mobile_sdk/j71;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Le33;

    const/4 v3, 0x0

    invoke-interface {p1, v3}, Le33;->a(Z)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Le33;

    new-instance v3, Lads_mobile_sdk/dr2;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    invoke-interface {p1, v3}, Le33;->a(Lads_mobile_sdk/dr2;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Le33;

    invoke-interface {p1}, Le33;->b()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Le33;

    invoke-interface {p1, v1}, Le33;->c(Z)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Le33;

    new-instance v1, Lads_mobile_sdk/i8;

    invoke-direct {v1, p0}, Lads_mobile_sdk/i8;-><init>(Lads_mobile_sdk/qr0;)V

    invoke-interface {p1, v1}, Le33;->a(Lads_mobile_sdk/i8;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Le33;

    check-cast p0, Lads_mobile_sdk/rc0;

    iput-object v0, p0, Lads_mobile_sdk/rc0;->m:Lxb1;

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    iput-object p1, p0, Lads_mobile_sdk/rc0;->l:Ljava/lang/Integer;

    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    iput-object p1, p0, Lads_mobile_sdk/rc0;->n:Ljava/lang/Boolean;

    new-instance p1, Lqu2;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/rc0;->o:Lia3;

    invoke-virtual {p0}, Lads_mobile_sdk/rc0;->a()Lads_mobile_sdk/sc0;

    move-result-object p0

    invoke-direct {v2, p0}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    return-object v2
.end method
