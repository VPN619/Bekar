.class public final Lads_mobile_sdk/e6;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lnt2;


# instance fields
.field public final a:Lads_mobile_sdk/ob1;

.field public final synthetic b:I


# direct methods
.method public synthetic constructor <init>(Lads_mobile_sdk/ob1;I)V
    .registers 3

    iput p2, p0, Lads_mobile_sdk/e6;->b:I

    iput-object p1, p0, Lads_mobile_sdk/e6;->a:Lads_mobile_sdk/ob1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 4

    .prologue
    iget v0, p0, Lads_mobile_sdk/e6;->b:I

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object p0, p0, Lads_mobile_sdk/e6;->a:Lads_mobile_sdk/ob1;

    packed-switch v0, :pswitch_data_11e

    iget-object p0, p0, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast p0, Landroid/content/Context;

    new-instance v0, Lads_mobile_sdk/ya1;

    invoke-direct {v0, p0}, Lads_mobile_sdk/ya1;-><init>(Landroid/content/Context;)V

    return-object v0

    :pswitch_13  #0x13
    iget-object p0, p0, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast p0, Lc73;

    new-instance v0, Lads_mobile_sdk/xr2;

    invoke-direct {v0, p0}, Lads_mobile_sdk/xr2;-><init>(Lc73;)V

    return-object v0

    :pswitch_1d  #0x12
    iget-object p0, p0, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast p0, Ljava/util/concurrent/ExecutorService;

    new-instance v0, Lads_mobile_sdk/nm0;

    invoke-direct {v0, p0}, Lads_mobile_sdk/nm0;-><init>(Ljava/util/concurrent/ExecutorService;)V

    return-object v0

    :pswitch_27  #0x11
    iget-object p0, p0, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast p0, Landroid/content/Context;

    new-instance v0, Lads_mobile_sdk/vr;

    invoke-direct {v0, p0}, Lads_mobile_sdk/vr;-><init>(Landroid/content/Context;)V

    return-object v0

    :pswitch_31  #0x10
    iget-object p0, p0, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast p0, Lli;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    instance-of v0, p0, Lxb1;

    const/4 v1, 0x0

    if-eqz v0, :cond_40

    check-cast p0, Lxb1;

    goto :goto_41

    :cond_40
    move-object p0, v1

    :goto_41
    if-eqz p0, :cond_47

    invoke-interface {p0}, Lqh;->k()Ls4;

    move-result-object v1

    :cond_47
    if-eqz v1, :cond_50

    sget-object p0, Lads_mobile_sdk/av2;->f:Lads_mobile_sdk/av2;

    invoke-static {p0}, Lt12;->U(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object p0

    goto :goto_52

    :cond_50
    sget-object p0, Lea0;->a:Lea0;

    :goto_52
    check-cast p0, Ljava/util/Set;

    return-object p0

    :pswitch_55  #0xf
    iget-object p0, p0, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/a2;

    new-instance v0, Loy2;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lads_mobile_sdk/sg2;

    invoke-direct {v1, p0, v0, v2}, Lads_mobile_sdk/sg2;-><init>(Lads_mobile_sdk/a2;Lbw2;I)V

    return-object v1

    :pswitch_67  #0xe
    iget-object p0, p0, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/av2;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object p0

    :pswitch_6f  #0xd
    iget-object p0, p0, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/xv;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lads_mobile_sdk/a10;

    const/4 v1, 0x3

    invoke-direct {v0, v1, p0}, Lads_mobile_sdk/a10;-><init>(ILjava/lang/Object;)V

    return-object v0

    :pswitch_7d  #0xc
    iget-object p0, p0, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/j71;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object p0

    :pswitch_85  #0xb
    iget-object p0, p0, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    new-instance v0, Lads_mobile_sdk/mm;

    invoke-direct {v0, p0}, Lads_mobile_sdk/mm;-><init>(Z)V

    return-object v0

    :pswitch_93  #0xa
    iget-object p0, p0, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/j71;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object p0

    :pswitch_9b  #0x9
    iget-object p0, p0, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast p0, Lqx2;

    new-instance v0, Lads_mobile_sdk/c02;

    invoke-direct {v0, p0}, Lads_mobile_sdk/c02;-><init>(Lqx2;)V

    return-object v0

    :pswitch_a5  #0x8
    iget-object p0, p0, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast p0, Landroid/content/Context;

    new-instance v0, Lads_mobile_sdk/pb1;

    const/4 v1, 0x2

    invoke-direct {v0, p0, v1}, Lads_mobile_sdk/pb1;-><init>(Landroid/content/Context;I)V

    return-object v0

    :pswitch_b0  #0x7
    iget-object p0, p0, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast p0, Landroid/content/Context;

    new-instance v0, Lads_mobile_sdk/pb1;

    invoke-direct {v0, p0, v1}, Lads_mobile_sdk/pb1;-><init>(Landroid/content/Context;I)V

    return-object v0

    :pswitch_ba  #0x6
    iget-object p0, p0, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast p0, Landroid/content/Context;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    if-eqz v0, :cond_d5

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/16 v1, 0x80

    invoke-virtual {v0, p0, v1}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p0

    if-eqz p0, :cond_d5

    iget v2, p0, Landroid/content/pm/PackageInfo;->versionCode:I

    :cond_d5
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    return-object p0

    :pswitch_da  #0x5
    iget-object p0, p0, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast p0, Landroid/content/Context;

    new-instance v0, Lads_mobile_sdk/gg3;

    invoke-direct {v0, p0}, Lads_mobile_sdk/gg3;-><init>(Landroid/content/Context;)V

    return-object v0

    :pswitch_e4  #0x4
    iget-object p0, p0, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast p0, Landroid/content/Context;

    new-instance v0, Lads_mobile_sdk/ei;

    invoke-direct {v0, p0}, Lads_mobile_sdk/ei;-><init>(Landroid/content/Context;)V

    return-object v0

    :pswitch_ee  #0x3
    iget-object p0, p0, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast p0, Landroid/content/Context;

    const-string v0, "yqzdkcache"

    invoke-virtual {p0, v0, v2}, Landroid/content/Context;->getDir(Ljava/lang/String;I)Ljava/io/File;

    move-result-object p0

    invoke-static {p0}, Lhi1;->o(Ljava/lang/Object;)V

    return-object p0

    :pswitch_fc  #0x2
    iget-object p0, p0, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast p0, Lc73;

    new-instance v0, Lads_mobile_sdk/dm;

    invoke-direct {v0, p0}, Lads_mobile_sdk/dm;-><init>(Lc73;)V

    return-object v0

    :pswitch_106  #0x1
    iget-object p0, p0, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast p0, Lc73;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lads_mobile_sdk/a10;

    invoke-direct {v0, v1, p0}, Lads_mobile_sdk/a10;-><init>(ILjava/lang/Object;)V

    return-object v0

    :pswitch_113  #0x0
    iget-object p0, p0, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast p0, Landroid/content/Context;

    new-instance v0, Lads_mobile_sdk/d6;

    invoke-direct {v0, p0}, Lads_mobile_sdk/d6;-><init>(Landroid/content/Context;)V

    return-object v0

    nop

    :pswitch_data_11e
    .packed-switch 0x0
        :pswitch_113  #00000000
        :pswitch_106  #00000001
        :pswitch_fc  #00000002
        :pswitch_ee  #00000003
        :pswitch_e4  #00000004
        :pswitch_da  #00000005
        :pswitch_ba  #00000006
        :pswitch_b0  #00000007
        :pswitch_a5  #00000008
        :pswitch_9b  #00000009
        :pswitch_93  #0000000a
        :pswitch_85  #0000000b
        :pswitch_7d  #0000000c
        :pswitch_6f  #0000000d
        :pswitch_67  #0000000e
        :pswitch_55  #0000000f
        :pswitch_31  #00000010
        :pswitch_27  #00000011
        :pswitch_1d  #00000012
        :pswitch_13  #00000013
    .end packed-switch
.end method
