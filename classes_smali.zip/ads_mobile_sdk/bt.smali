.class public final Lads_mobile_sdk/bt;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lnt2;


# instance fields
.field public final a:Ltv2;

.field public final b:Ltv2;

.field public final c:Ltv2;

.field public final d:Ltv2;

.field public final synthetic e:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/ab0;Lads_mobile_sdk/dw;Ltv2;Ltv2;)V
    .registers 6

    const/4 v0, 0x1

    iput v0, p0, Lads_mobile_sdk/bt;->e:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/bt;->a:Ltv2;

    iput-object p2, p0, Lads_mobile_sdk/bt;->c:Ltv2;

    iput-object p3, p0, Lads_mobile_sdk/bt;->b:Ltv2;

    iput-object p4, p0, Lads_mobile_sdk/bt;->d:Ltv2;

    return-void
.end method

.method public constructor <init>(Lads_mobile_sdk/b23;Lads_mobile_sdk/b23;Lads_mobile_sdk/ob1;Ltv2;)V
    .registers 6

    const/4 v0, 0x3

    iput v0, p0, Lads_mobile_sdk/bt;->e:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/bt;->a:Ltv2;

    iput-object p2, p0, Lads_mobile_sdk/bt;->d:Ltv2;

    iput-object p3, p0, Lads_mobile_sdk/bt;->c:Ltv2;

    iput-object p4, p0, Lads_mobile_sdk/bt;->b:Ltv2;

    return-void
.end method

.method public synthetic constructor <init>(Lnt2;Ltv2;Lnt2;Ltv2;I)V
    .registers 6

    iput p5, p0, Lads_mobile_sdk/bt;->e:I

    iput-object p1, p0, Lads_mobile_sdk/bt;->a:Ltv2;

    iput-object p2, p0, Lads_mobile_sdk/bt;->b:Ltv2;

    iput-object p3, p0, Lads_mobile_sdk/bt;->c:Ltv2;

    iput-object p4, p0, Lads_mobile_sdk/bt;->d:Ltv2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Ltv2;Lnt2;Lnt2;Ltv2;)V
    .registers 6

    const/4 v0, 0x6

    iput v0, p0, Lads_mobile_sdk/bt;->e:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/bt;->b:Ltv2;

    iput-object p2, p0, Lads_mobile_sdk/bt;->a:Ltv2;

    iput-object p3, p0, Lads_mobile_sdk/bt;->c:Ltv2;

    iput-object p4, p0, Lads_mobile_sdk/bt;->d:Ltv2;

    return-void
.end method

.method public synthetic constructor <init>(Ltv2;Ltv2;Ltv2;Ltv2;I)V
    .registers 6

    iput p5, p0, Lads_mobile_sdk/bt;->e:I

    iput-object p1, p0, Lads_mobile_sdk/bt;->a:Ltv2;

    iput-object p2, p0, Lads_mobile_sdk/bt;->b:Ltv2;

    iput-object p3, p0, Lads_mobile_sdk/bt;->d:Ltv2;

    iput-object p4, p0, Lads_mobile_sdk/bt;->c:Ltv2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Ltv2;Ltv2;Ltv2;Ltv2;IZ)V
    .registers 7

    iput p5, p0, Lads_mobile_sdk/bt;->e:I

    iput-object p1, p0, Lads_mobile_sdk/bt;->b:Ltv2;

    iput-object p2, p0, Lads_mobile_sdk/bt;->d:Ltv2;

    iput-object p3, p0, Lads_mobile_sdk/bt;->a:Ltv2;

    iput-object p4, p0, Lads_mobile_sdk/bt;->c:Ltv2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 10

    .prologue
    iget v0, p0, Lads_mobile_sdk/bt;->e:I

    iget-object v1, p0, Lads_mobile_sdk/bt;->d:Ltv2;

    iget-object v2, p0, Lads_mobile_sdk/bt;->c:Ltv2;

    iget-object v3, p0, Lads_mobile_sdk/bt;->b:Ltv2;

    iget-object p0, p0, Lads_mobile_sdk/bt;->a:Ltv2;

    packed-switch v0, :pswitch_data_180

    check-cast p0, Lads_mobile_sdk/ah0;

    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lvy;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/ux2;

    check-cast v2, Lads_mobile_sdk/ah0;

    invoke-virtual {v2}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lads_mobile_sdk/ah3;

    invoke-interface {v1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lads_mobile_sdk/qr0;

    new-instance v3, Lads_mobile_sdk/u30;

    invoke-direct {v3, p0, v0, v2, v1}, Lads_mobile_sdk/u30;-><init>(Lvy;Lads_mobile_sdk/ux2;Lads_mobile_sdk/ah3;Lads_mobile_sdk/qr0;)V

    return-object v3

    :pswitch_2f  #0x7
    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Optional;

    invoke-interface {v1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Optional;

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/util/Optional;

    check-cast v2, Lads_mobile_sdk/n90;

    invoke-virtual {v2}, Lads_mobile_sdk/n90;->get()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Optional;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v3, Lads_mobile_sdk/kh3;

    new-instance v4, Lads_mobile_sdk/eq2;

    invoke-direct {v4}, Lads_mobile_sdk/eq2;-><init>()V

    invoke-static {v0, v4}, Lw53;->H(Ljava/util/Optional;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/eq2;

    new-instance v4, Lads_mobile_sdk/ih1;

    invoke-direct {v4}, Lads_mobile_sdk/ih1;-><init>()V

    invoke-static {v1, v4}, Lw53;->H(Ljava/util/Optional;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lads_mobile_sdk/ih1;

    new-instance v4, Lads_mobile_sdk/dt2;

    invoke-direct {v4}, Lads_mobile_sdk/dt2;-><init>()V

    invoke-static {p0, v4}, Lw53;->H(Ljava/util/Optional;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/dt2;

    new-instance v4, Lads_mobile_sdk/s8;

    invoke-direct {v4}, Lads_mobile_sdk/s8;-><init>()V

    invoke-static {v2, v4}, Lw53;->H(Ljava/util/Optional;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lads_mobile_sdk/s8;

    invoke-direct {v3, v0, v1, p0, v2}, Lads_mobile_sdk/kh3;-><init>(Lads_mobile_sdk/eq2;Lads_mobile_sdk/ih1;Lads_mobile_sdk/dt2;Lads_mobile_sdk/s8;)V

    return-object v3

    :pswitch_87  #0x6
    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v4, v0

    check-cast v4, Landroid/content/Context;

    check-cast p0, Lnt2;

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result v5

    check-cast v2, Lnt2;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Long;

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v6

    invoke-interface {v1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v8, p0

    check-cast v8, Ljx2;

    new-instance v3, Lads_mobile_sdk/t42;

    invoke-direct/range {v3 .. v8}, Lads_mobile_sdk/t42;-><init>(Landroid/content/Context;IJLjx2;)V

    return-object v3

    :pswitch_b3  #0x5
    check-cast p0, Lads_mobile_sdk/la0;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/k71;

    invoke-interface {v1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ln63;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lads_mobile_sdk/qr0;

    new-instance v3, Lads_mobile_sdk/ih;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 p0, 0x1

    invoke-direct {v3, p0}, Lads_mobile_sdk/ih;-><init>(I)V

    return-object v3

    :pswitch_da  #0x4
    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v4, v0

    check-cast v4, Lads_mobile_sdk/g9;

    invoke-interface {v1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v5, v0

    check-cast v5, Lads_mobile_sdk/jk;

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v6, p0

    check-cast v6, Ljava/lang/String;

    check-cast v2, Lads_mobile_sdk/ej;

    invoke-virtual {v2}, Lads_mobile_sdk/ej;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Long;

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v7

    new-instance v3, Lads_mobile_sdk/pa3;

    invoke-direct/range {v3 .. v8}, Lads_mobile_sdk/pa3;-><init>(Lads_mobile_sdk/g9;Lads_mobile_sdk/jk;Ljava/lang/String;J)V

    return-object v3

    :pswitch_101  #0x3
    check-cast p0, Lads_mobile_sdk/b23;

    invoke-static {p0}, Lads_mobile_sdk/nj0;->a(Ltv2;)Lv03;

    move-result-object p0

    check-cast v1, Lads_mobile_sdk/b23;

    invoke-static {v1}, Lads_mobile_sdk/nj0;->a(Ltv2;)Lv03;

    move-result-object v0

    check-cast v2, Lads_mobile_sdk/ob1;

    iget-object v1, v2, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v1, Ljava/util/concurrent/ExecutorService;

    invoke-static {v3}, Lads_mobile_sdk/nj0;->a(Ltv2;)Lv03;

    move-result-object v2

    new-instance v3, Lads_mobile_sdk/n61;

    invoke-direct {v3, p0, v0, v1, v2}, Lads_mobile_sdk/n61;-><init>(Lv03;Lv03;Ljava/util/concurrent/ExecutorService;Lv03;)V

    return-object v3

    :pswitch_11d  #0x2
    check-cast p0, Lads_mobile_sdk/ab0;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/k71;

    invoke-interface {v1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ln63;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lads_mobile_sdk/qr0;

    new-instance v3, Lads_mobile_sdk/ih;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 p0, 0x0

    invoke-direct {v3, p0}, Lads_mobile_sdk/ih;-><init>(I)V

    return-object v3

    :pswitch_144  #0x1
    check-cast p0, Lads_mobile_sdk/ab0;

    check-cast v2, Lads_mobile_sdk/dw;

    invoke-virtual {v2}, Lads_mobile_sdk/dw;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/k71;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ln63;

    invoke-interface {v1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lads_mobile_sdk/qr0;

    new-instance v3, Lads_mobile_sdk/cy1;

    invoke-direct {v3, p0, v0, v2, v1}, Lads_mobile_sdk/cy1;-><init>(Lads_mobile_sdk/ab0;Lads_mobile_sdk/k71;Ln63;Lads_mobile_sdk/qr0;)V

    return-object v3

    :pswitch_160  #0x0
    check-cast p0, Lnt2;

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/av2;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/dk;

    check-cast v2, Lads_mobile_sdk/ob1;

    iget-object v2, v2, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v2, Lli;

    invoke-interface {v1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lads_mobile_sdk/lx;

    new-instance v3, Lads_mobile_sdk/at;

    invoke-direct {v3, p0, v0, v2, v1}, Lads_mobile_sdk/at;-><init>(Lads_mobile_sdk/av2;Lads_mobile_sdk/dk;Lli;Lads_mobile_sdk/lx;)V

    return-object v3

    :pswitch_data_180
    .packed-switch 0x0
        :pswitch_160  #00000000
        :pswitch_144  #00000001
        :pswitch_11d  #00000002
        :pswitch_101  #00000003
        :pswitch_da  #00000004
        :pswitch_b3  #00000005
        :pswitch_87  #00000006
        :pswitch_2f  #00000007
    .end packed-switch
.end method
