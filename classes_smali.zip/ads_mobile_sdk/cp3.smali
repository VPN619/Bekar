.class public final Lads_mobile_sdk/cp3;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ltm;


# instance fields
.field public final synthetic a:Ljn;


# direct methods
.method public synthetic constructor <init>(Ljn;)V
    .registers 2

    iput-object p1, p0, Lads_mobile_sdk/cp3;->a:Ljn;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onFailure(Lqm;Ljava/io/IOException;)V
    .registers 7

    new-instance v0, Lads_mobile_sdk/bv0;

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-direct {v0, v3, v1, p2, v2}, Lads_mobile_sdk/bv0;-><init>(ILjava/lang/String;Ljava/lang/Throwable;I)V

    new-instance p2, Lads_mobile_sdk/x11;

    const/4 v1, 0x0

    invoke-direct {p2, p1, v1}, Lads_mobile_sdk/x11;-><init>(Lqm;I)V

    iget-object p0, p0, Lads_mobile_sdk/cp3;->a:Ljn;

    invoke-virtual {p0, v0, p2}, Ljn;->j(Ljava/lang/Object;Lrk0;)V

    return-void
.end method

.method public onResponse(Lqm;Lhu1;)V
    .registers 5

    new-instance v0, Lads_mobile_sdk/hv0;

    invoke-direct {v0, p2}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    new-instance p2, Lads_mobile_sdk/x11;

    const/4 v1, 0x1

    invoke-direct {p2, p1, v1}, Lads_mobile_sdk/x11;-><init>(Lqm;I)V

    iget-object p0, p0, Lads_mobile_sdk/cp3;->a:Ljn;

    invoke-virtual {p0, v0, p2}, Ljn;->j(Ljava/lang/Object;Lrk0;)V

    return-void
.end method
