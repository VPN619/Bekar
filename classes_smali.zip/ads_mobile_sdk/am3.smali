.class public final Lads_mobile_sdk/am3;
.super Lads_mobile_sdk/k61;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final c:Lvy;

.field public final d:Lq63;

.field public final e:Ldl;


# direct methods
.method public constructor <init>(Lvy;Lq63;)V
    .registers 5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0, v1, v0}, Lads_mobile_sdk/k61;-><init>(Lads_mobile_sdk/fw0;I)V

    iput-object p1, p0, Lads_mobile_sdk/am3;->c:Lvy;

    iput-object p2, p0, Lads_mobile_sdk/am3;->d:Lq63;

    const p1, 0x7fffffff

    const/4 p2, 0x6

    invoke-static {p1, p2, v1}, Lq23;->d(IILwk;)Ldl;

    move-result-object p1

    iput-object p1, p0, Lads_mobile_sdk/am3;->e:Ldl;

    return-void
.end method


# virtual methods
.method public final h(Lvx;)Ljava/lang/Object;
    .registers 5

    new-instance p1, Lads_mobile_sdk/x;

    const/16 v0, 0xe

    const/4 v1, 0x0

    invoke-direct {p1, p0, v1, v0}, Lads_mobile_sdk/x;-><init>(Ljava/lang/Object;Lvx;I)V

    iget-object p0, p0, Lads_mobile_sdk/am3;->c:Lvy;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, La42;

    invoke-direct {v0, p1, v1}, La42;-><init>(Lpk0;Lvx;)V

    const/4 p1, 0x2

    sget-object v2, Ly90;->a:Ly90;

    invoke-static {p0, v2, v1, v0, p1}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    new-instance p0, Lads_mobile_sdk/hv0;

    sget-object p1, Lrg2;->a:Lrg2;

    invoke-direct {p0, p1}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    return-object p0
.end method

.method public final k(Lvx;)Ljava/lang/Object;
    .registers 12

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/yl3;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/yl3;

    iget v1, v0, Lads_mobile_sdk/yl3;->e:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/yl3;->e:I

    goto :goto_1a

    :cond_13
    new-instance v0, Lads_mobile_sdk/yl3;

    check-cast p1, Lwx;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/yl3;-><init>(Lads_mobile_sdk/am3;Lwx;)V

    :goto_1a
    iget-object p1, v0, Lads_mobile_sdk/yl3;->c:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/yl3;->e:I

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    sget-object v5, Lwy;->a:Lwy;

    if-eqz v1, :cond_3f

    if-eq v1, v4, :cond_39

    if-ne v1, v3, :cond_33

    iget-object p0, v0, Lads_mobile_sdk/yl3;->b:Landroid/net/Uri;

    iget-object v1, v0, Lads_mobile_sdk/yl3;->a:Lads_mobile_sdk/am3;

    :try_start_2d
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_30
    .catch Ljava/lang/Exception; {:try_start_2d .. :try_end_30} :catch_31

    goto :goto_78

    :catch_31
    move-exception p1

    goto :goto_8d

    :cond_33
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v2

    :cond_39
    iget-object p0, v0, Lads_mobile_sdk/yl3;->a:Lads_mobile_sdk/am3;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_51

    :cond_3f
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    :goto_42
    iget-object p1, p0, Lads_mobile_sdk/am3;->e:Ldl;

    iput-object p0, v0, Lads_mobile_sdk/yl3;->a:Lads_mobile_sdk/am3;

    iput-object v2, v0, Lads_mobile_sdk/yl3;->b:Landroid/net/Uri;

    iput v4, v0, Lads_mobile_sdk/yl3;->e:I

    invoke-virtual {p1, v0}, Ldl;->E(Lvx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v5, :cond_51

    goto :goto_74

    :cond_51
    :goto_51
    check-cast p1, Ldj1;

    iget-object v1, p1, Ldj1;->a:Ljava/lang/Object;

    check-cast v1, Landroid/net/Uri;

    iget-object p1, p1, Ldj1;->b:Ljava/lang/Object;

    check-cast p1, Ljava/util/Map;

    :try_start_5b
    iget-object v6, p0, Lads_mobile_sdk/am3;->d:Lq63;

    new-instance v7, Ljava/net/URL;

    invoke-virtual {v1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-direct {v7, v8}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    iput-object p0, v0, Lads_mobile_sdk/yl3;->a:Lads_mobile_sdk/am3;

    iput-object v1, v0, Lads_mobile_sdk/yl3;->b:Landroid/net/Uri;

    iput v3, v0, Lads_mobile_sdk/yl3;->e:I

    const/16 v8, 0x1a

    invoke-static {v6, v7, p1, v0, v8}, Lq63;->a(Lq63;Ljava/net/URL;Ljava/util/Map;Lwx;I)Ljava/lang/Object;

    move-result-object p1
    :try_end_72
    .catch Ljava/lang/Exception; {:try_start_5b .. :try_end_72} :catch_89

    if-ne p1, v5, :cond_75

    :goto_74
    return-object v5

    :cond_75
    move-object v9, v1

    move-object v1, p0

    move-object p0, v9

    :goto_78
    :try_start_78
    check-cast p1, Lb13;

    instance-of v6, p1, Lads_mobile_sdk/hv0;

    if-eqz v6, :cond_87

    check-cast p1, Lads_mobile_sdk/hv0;

    iget-object p1, p1, Lads_mobile_sdk/hv0;->b:Ljava/lang/Object;

    check-cast p1, Lads_mobile_sdk/j21;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_87
    .catch Ljava/lang/Exception; {:try_start_78 .. :try_end_87} :catch_31

    :cond_87
    :goto_87
    move-object p0, v1

    goto :goto_42

    :catch_89
    move-exception p1

    move-object v9, v1

    move-object v1, p0

    move-object p0, v9

    :goto_8d
    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    new-instance v6, Ljava/lang/StringBuilder;

    const-string v7, "Error while pinging URL: "

    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v6, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, ": "

    invoke-virtual {v6, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0, v2}, Lads_mobile_sdk/nw;->b(Ljava/lang/String;Ljava/lang/Throwable;)V

    goto :goto_87
.end method
