.class public final Lads_mobile_sdk/a90;
.super Lnp3;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final synthetic a:Lads_mobile_sdk/b90;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/b90;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/a90;->a:Lads_mobile_sdk/b90;

    return-void
.end method


# virtual methods
.method public final onNavigationEvent(I)V
    .registers 8

    .prologue
    iget-object p0, p0, Lads_mobile_sdk/a90;->a:Lads_mobile_sdk/b90;

    iget-object p0, p0, Lads_mobile_sdk/b90;->c:Lads_mobile_sdk/ux2;

    sget-object v0, Lads_mobile_sdk/fw0;->B0:Lads_mobile_sdk/fw0;

    new-instance v1, Lads_mobile_sdk/kh3;

    new-instance v2, Lads_mobile_sdk/eq2;

    invoke-direct {v2}, Lads_mobile_sdk/eq2;-><init>()V

    new-instance v3, Lads_mobile_sdk/ih1;

    invoke-direct {v3}, Lads_mobile_sdk/ih1;-><init>()V

    new-instance v4, Lads_mobile_sdk/dt2;

    invoke-direct {v4}, Lads_mobile_sdk/dt2;-><init>()V

    new-instance v5, Lads_mobile_sdk/s8;

    invoke-direct {v5}, Lads_mobile_sdk/s8;-><init>()V

    invoke-direct {v1, v2, v3, v4, v5}, Lads_mobile_sdk/kh3;-><init>(Lads_mobile_sdk/eq2;Lads_mobile_sdk/ih1;Lads_mobile_sdk/dt2;Lads_mobile_sdk/s8;)V

    sget-object v2, Lba0;->a:Lba0;

    invoke-static {}, Lads_mobile_sdk/hh3;->b()Lads_mobile_sdk/gh3;

    move-result-object v3

    iget-object v3, v3, Lads_mobile_sdk/gh3;->a:Lads_mobile_sdk/rg3;

    if-nez v3, :cond_76

    invoke-static {p0, v0, v2, v1}, Lads_mobile_sdk/ux2;->a(Lads_mobile_sdk/ux2;Lads_mobile_sdk/fw0;Ljava/util/List;Lads_mobile_sdk/kh3;)Lads_mobile_sdk/wk2;

    move-result-object p0

    :try_start_2d
    invoke-static {}, Lads_mobile_sdk/hh3;->a()Lads_mobile_sdk/rg3;

    move-result-object v0

    invoke-virtual {v0}, Lads_mobile_sdk/rg3;->e()Lads_mobile_sdk/ub2;

    move-result-object v0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    iput-object p1, v0, Lads_mobile_sdk/ub2;->A:Ljava/lang/Integer;
    :try_end_3b
    .catchall {:try_start_2d .. :try_end_3b} :catchall_3f

    invoke-virtual {p0}, Lads_mobile_sdk/rg3;->close()V

    return-void

    :catchall_3f
    move-exception p1

    :try_start_40
    invoke-virtual {p0, p1}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v0, p1, Lox2;

    if-nez v0, :cond_6f

    invoke-virtual {p0, p1}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of v0, p1, Lza2;

    if-nez v0, :cond_67

    instance-of v0, p1, Ljava/util/concurrent/CancellationException;

    if-nez v0, :cond_5f

    instance-of v0, p1, Lads_mobile_sdk/mv0;

    if-eqz v0, :cond_59

    throw p1

    :catchall_57
    move-exception p1

    goto :goto_70

    :cond_59
    new-instance v0, Lads_mobile_sdk/tu0;

    invoke-direct {v0, p1}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw v0

    :cond_5f
    new-instance v0, Lads_mobile_sdk/ou0;

    check-cast p1, Ljava/util/concurrent/CancellationException;

    invoke-direct {v0, p1}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw v0

    :cond_67
    new-instance v0, Lads_mobile_sdk/uw0;

    check-cast p1, Lza2;

    invoke-direct {v0, p1}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw v0

    :cond_6f
    throw p1
    :try_end_70
    .catchall {:try_start_40 .. :try_end_70} :catchall_57

    :goto_70
    :try_start_70
    throw p1
    :try_end_71
    .catchall {:try_start_70 .. :try_end_71} :catchall_71

    :catchall_71
    move-exception v0

    invoke-static {p0, p1}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0

    :cond_76
    const/4 p0, 0x1

    invoke-static {v0, v2, p0}, Lads_mobile_sdk/hh3;->a(Lads_mobile_sdk/fw0;Ljava/util/List;Z)Lads_mobile_sdk/rg3;

    move-result-object p0

    :try_start_7b
    invoke-static {}, Lads_mobile_sdk/hh3;->a()Lads_mobile_sdk/rg3;

    move-result-object v0

    invoke-virtual {v0}, Lads_mobile_sdk/rg3;->e()Lads_mobile_sdk/ub2;

    move-result-object v0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    iput-object p1, v0, Lads_mobile_sdk/ub2;->A:Ljava/lang/Integer;
    :try_end_89
    .catchall {:try_start_7b .. :try_end_89} :catchall_8d

    invoke-virtual {p0}, Lads_mobile_sdk/rg3;->close()V

    return-void

    :catchall_8d
    move-exception p1

    :try_start_8e
    invoke-virtual {p0, p1}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v0, p1, Lox2;

    if-nez v0, :cond_bd

    invoke-virtual {p0, p1}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of v0, p1, Lza2;

    if-nez v0, :cond_b5

    instance-of v0, p1, Ljava/util/concurrent/CancellationException;

    if-nez v0, :cond_ad

    instance-of v0, p1, Lads_mobile_sdk/mv0;

    if-eqz v0, :cond_a7

    throw p1

    :catchall_a5
    move-exception p1

    goto :goto_be

    :cond_a7
    new-instance v0, Lads_mobile_sdk/tu0;

    invoke-direct {v0, p1}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw v0

    :cond_ad
    new-instance v0, Lads_mobile_sdk/ou0;

    check-cast p1, Ljava/util/concurrent/CancellationException;

    invoke-direct {v0, p1}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw v0

    :cond_b5
    new-instance v0, Lads_mobile_sdk/uw0;

    check-cast p1, Lza2;

    invoke-direct {v0, p1}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw v0

    :cond_bd
    throw p1
    :try_end_be
    .catchall {:try_start_8e .. :try_end_be} :catchall_a5

    :goto_be
    :try_start_be
    throw p1
    :try_end_bf
    .catchall {:try_start_be .. :try_end_bf} :catchall_bf

    :catchall_bf
    move-exception v0

    invoke-static {p0, p1}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0
.end method
