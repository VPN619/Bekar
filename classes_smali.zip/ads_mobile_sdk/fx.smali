.class public final Lads_mobile_sdk/fx;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public a:I

.field public final synthetic b:Lads_mobile_sdk/lx;

.field public final synthetic t:I


# direct methods
.method public synthetic constructor <init>(Lads_mobile_sdk/lx;Lvx;I)V
    .registers 4

    iput p3, p0, Lads_mobile_sdk/fx;->t:I

    iput-object p1, p0, Lads_mobile_sdk/fx;->b:Lads_mobile_sdk/lx;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 4

    .prologue
    iget p2, p0, Lads_mobile_sdk/fx;->t:I

    iget-object p0, p0, Lads_mobile_sdk/fx;->b:Lads_mobile_sdk/lx;

    packed-switch p2, :pswitch_data_38

    new-instance p2, Lads_mobile_sdk/fx;

    const/4 v0, 0x6

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/fx;-><init>(Lads_mobile_sdk/lx;Lvx;I)V

    return-object p2

    :pswitch_e  #0x5
    new-instance p2, Lads_mobile_sdk/fx;

    const/4 v0, 0x5

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/fx;-><init>(Lads_mobile_sdk/lx;Lvx;I)V

    return-object p2

    :pswitch_15  #0x4
    new-instance p2, Lads_mobile_sdk/fx;

    const/4 v0, 0x4

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/fx;-><init>(Lads_mobile_sdk/lx;Lvx;I)V

    return-object p2

    :pswitch_1c  #0x3
    new-instance p2, Lads_mobile_sdk/fx;

    const/4 v0, 0x3

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/fx;-><init>(Lads_mobile_sdk/lx;Lvx;I)V

    return-object p2

    :pswitch_23  #0x2
    new-instance p2, Lads_mobile_sdk/fx;

    const/4 v0, 0x2

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/fx;-><init>(Lads_mobile_sdk/lx;Lvx;I)V

    return-object p2

    :pswitch_2a  #0x1
    new-instance p2, Lads_mobile_sdk/fx;

    const/4 v0, 0x1

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/fx;-><init>(Lads_mobile_sdk/lx;Lvx;I)V

    return-object p2

    :pswitch_31  #0x0
    new-instance p2, Lads_mobile_sdk/fx;

    const/4 v0, 0x0

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/fx;-><init>(Lads_mobile_sdk/lx;Lvx;I)V

    return-object p2

    :pswitch_data_38
    .packed-switch 0x0
        :pswitch_31  #00000000
        :pswitch_2a  #00000001
        :pswitch_23  #00000002
        :pswitch_1c  #00000003
        :pswitch_15  #00000004
        :pswitch_e  #00000005
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .prologue
    iget v0, p0, Lads_mobile_sdk/fx;->t:I

    sget-object v1, Lrg2;->a:Lrg2;

    iget-object p0, p0, Lads_mobile_sdk/fx;->b:Lads_mobile_sdk/lx;

    packed-switch v0, :pswitch_data_72

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/fx;

    const/4 v0, 0x6

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/fx;-><init>(Lads_mobile_sdk/lx;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/fx;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_18  #0x5
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/fx;

    const/4 v0, 0x5

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/fx;-><init>(Lads_mobile_sdk/lx;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/fx;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_27  #0x4
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/fx;

    const/4 v0, 0x4

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/fx;-><init>(Lads_mobile_sdk/lx;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/fx;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_36  #0x3
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/fx;

    const/4 v0, 0x3

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/fx;-><init>(Lads_mobile_sdk/lx;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/fx;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_45  #0x2
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/fx;

    const/4 v0, 0x2

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/fx;-><init>(Lads_mobile_sdk/lx;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/fx;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_54  #0x1
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/fx;

    const/4 v0, 0x1

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/fx;-><init>(Lads_mobile_sdk/lx;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/fx;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_63  #0x0
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/fx;

    const/4 v0, 0x0

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/fx;-><init>(Lads_mobile_sdk/lx;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/fx;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_data_72
    .packed-switch 0x0
        :pswitch_63  #00000000
        :pswitch_54  #00000001
        :pswitch_45  #00000002
        :pswitch_36  #00000003
        :pswitch_27  #00000004
        :pswitch_18  #00000005
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 12

    .prologue
    iget v0, p0, Lads_mobile_sdk/fx;->t:I

    const/4 v1, 0x2

    sget-object v2, Lrg2;->a:Lrg2;

    iget-object v3, p0, Lads_mobile_sdk/fx;->b:Lads_mobile_sdk/lx;

    const-string v4, "call to \'resume\' before \'invoke\' with coroutine"

    sget-object v5, Lwy;->a:Lwy;

    const/4 v6, 0x1

    const/4 v7, 0x0

    packed-switch v0, :pswitch_data_18e

    iget v0, p0, Lads_mobile_sdk/fx;->a:I

    if-eqz v0, :cond_1f

    if-ne v0, v6, :cond_1a

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_32

    :cond_1a
    invoke-static {v4}, Lz6;->w(Ljava/lang/String;)V

    move-object v2, v7

    goto :goto_32

    :cond_1f
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, v3, Lads_mobile_sdk/lx;->o:Lads_mobile_sdk/vz;

    iput v6, p0, Lads_mobile_sdk/fx;->a:I

    sget-object v0, Lads_mobile_sdk/vz;->R:Ljava/util/regex/Pattern;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1, v6, v6, p0}, Lads_mobile_sdk/vz;->b(Lads_mobile_sdk/vz;ZZLwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_32

    move-object v2, v5

    :cond_32
    :goto_32
    return-object v2

    :pswitch_33  #0x5
    iget v0, p0, Lads_mobile_sdk/fx;->a:I

    if-eqz v0, :cond_42

    if-ne v0, v6, :cond_3d

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_53

    :cond_3d
    invoke-static {v4}, Lz6;->w(Ljava/lang/String;)V

    move-object v2, v7

    goto :goto_53

    :cond_42
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, v3, Lads_mobile_sdk/lx;->j:Lads_mobile_sdk/sb;

    iput v6, p0, Lads_mobile_sdk/fx;->a:I

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1, p0}, Lads_mobile_sdk/sb;->b(Lads_mobile_sdk/sb;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_53

    move-object v2, v5

    :cond_53
    :goto_53
    return-object v2

    :pswitch_54  #0x4
    iget v0, p0, Lads_mobile_sdk/fx;->a:I

    if-eqz v0, :cond_63

    if-ne v0, v6, :cond_5e

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_74

    :cond_5e
    invoke-static {v4}, Lz6;->w(Ljava/lang/String;)V

    move-object v2, v7

    goto :goto_74

    :cond_63
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, v3, Lads_mobile_sdk/lx;->j:Lads_mobile_sdk/sb;

    iput v6, p0, Lads_mobile_sdk/fx;->a:I

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1, p0}, Lads_mobile_sdk/sb;->b(Lads_mobile_sdk/sb;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_74

    move-object v2, v5

    :cond_74
    :goto_74
    return-object v2

    :pswitch_75  #0x3
    iget-object v0, v3, Lads_mobile_sdk/lx;->d:Lvy;

    iget-object v8, v3, Lads_mobile_sdk/lx;->i:Lads_mobile_sdk/dk;

    iget v9, p0, Lads_mobile_sdk/fx;->a:I

    if-eqz v9, :cond_8f

    if-eq v9, v6, :cond_8b

    if-ne v9, v1, :cond_85

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_b4

    :cond_85
    invoke-static {v4}, Lz6;->w(Ljava/lang/String;)V

    move-object v2, v7

    goto/16 :goto_f7

    :cond_8b
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_a7

    :cond_8f
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iput v6, p0, Lads_mobile_sdk/fx;->a:I

    iget-object p1, v8, Lads_mobile_sdk/dk;->a:Lly;

    new-instance v4, Lads_mobile_sdk/x;

    const/4 v9, 0x7

    invoke-direct {v4, v8, v7, v9}, Lads_mobile_sdk/x;-><init>(Ljava/lang/Object;Lvx;I)V

    invoke-static {p1, v4, p0}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v5, :cond_a3

    goto :goto_a4

    :cond_a3
    move-object p1, v2

    :goto_a4
    if-ne p1, v5, :cond_a7

    goto :goto_b2

    :cond_a7
    :goto_a7
    iput v1, p0, Lads_mobile_sdk/fx;->a:I

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v8, p0}, Lads_mobile_sdk/dk;->a$1(Lads_mobile_sdk/dk;Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v5, :cond_b4

    :goto_b2
    move-object v2, v5

    goto :goto_f7

    :cond_b4
    :goto_b4
    check-cast p1, Lads_mobile_sdk/xi;

    invoke-virtual {p1}, Lads_mobile_sdk/xi;->u()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    sget-object p1, Ly90;->a:Ly90;

    if-lez p0, :cond_e7

    new-instance p0, Lads_mobile_sdk/fx;

    const/4 v4, 0x0

    invoke-direct {p0, v3, v7, v4}, Lads_mobile_sdk/fx;-><init>(Lads_mobile_sdk/lx;Lvx;I)V

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v4, La42;

    invoke-direct {v4, p0, v7}, La42;-><init>(Lpk0;Lvx;)V

    invoke-static {v0, p1, v7, v4, v1}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    new-instance p0, Lads_mobile_sdk/fx;

    invoke-direct {p0, v3, v7, v6}, Lads_mobile_sdk/fx;-><init>(Lads_mobile_sdk/lx;Lvx;I)V

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v3, La42;

    invoke-direct {v3, p0, v7}, La42;-><init>(Lpk0;Lvx;)V

    invoke-static {v0, p1, v7, v3, v1}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    goto :goto_f7

    :cond_e7
    new-instance p0, Lads_mobile_sdk/fx;

    invoke-direct {p0, v3, v7, v1}, Lads_mobile_sdk/fx;-><init>(Lads_mobile_sdk/lx;Lvx;I)V

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v3, La42;

    invoke-direct {v3, p0, v7}, La42;-><init>(Lpk0;Lvx;)V

    invoke-static {v0, p1, v7, v3, v1}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    :goto_f7
    return-object v2

    :pswitch_f8  #0x2
    iget v0, p0, Lads_mobile_sdk/fx;->a:I

    if-eqz v0, :cond_107

    if-ne v0, v6, :cond_102

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_11a

    :cond_102
    invoke-static {v4}, Lz6;->w(Ljava/lang/String;)V

    move-object v2, v7

    goto :goto_11a

    :cond_107
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iput v6, p0, Lads_mobile_sdk/fx;->a:I

    iget-object p1, v3, Lads_mobile_sdk/lx;->c:Lly;

    new-instance v0, Lt00;

    invoke-direct {v0, v3, v6, v7, v7}, Lt00;-><init>(Lads_mobile_sdk/lx;ZLjava/lang/String;Lvx;)V

    invoke-static {p1, v0, p0}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_11a

    move-object v2, v5

    :cond_11a
    :goto_11a
    return-object v2

    :pswitch_11b  #0x1
    iget v0, p0, Lads_mobile_sdk/fx;->a:I

    if-eqz v0, :cond_12a

    if-ne v0, v6, :cond_125

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_13b

    :cond_125
    invoke-static {v4}, Lz6;->w(Ljava/lang/String;)V

    move-object v2, v7

    goto :goto_13b

    :cond_12a
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, v3, Lads_mobile_sdk/lx;->j:Lads_mobile_sdk/sb;

    iput v6, p0, Lads_mobile_sdk/fx;->a:I

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1, p0}, Lads_mobile_sdk/sb;->b(Lads_mobile_sdk/sb;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_13b

    move-object v2, v5

    :cond_13b
    :goto_13b
    return-object v2

    :pswitch_13c  #0x0
    iget v0, p0, Lads_mobile_sdk/fx;->a:I

    if-eqz v0, :cond_151

    if-eq v0, v6, :cond_14d

    if-ne v0, v1, :cond_148

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_18d

    :cond_148
    invoke-static {v4}, Lz6;->w(Ljava/lang/String;)V

    move-object v2, v7

    goto :goto_18d

    :cond_14d
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_17d

    :cond_151
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, v3, Lads_mobile_sdk/lx;->m:Lads_mobile_sdk/qr0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lv60;->b:Lp80;

    const/16 v0, 0x3c

    sget-object v4, Ly60;->e:Ly60;

    invoke-static {v0, v4}, Li10;->G0(ILy60;)J

    move-result-wide v8

    new-instance v0, Lv60;

    invoke-direct {v0, v8, v9}, Lv60;-><init>(J)V

    sget-object v4, Lads_mobile_sdk/fo;->a$21:Lads_mobile_sdk/fo;

    const-string v8, "gads:cld_fetch_delay_on_cache_hit"

    invoke-virtual {p1, v8, v0, v4}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lv60;

    iget-wide v8, p1, Lv60;->a:J

    iput v6, p0, Lads_mobile_sdk/fx;->a:I

    invoke-static {v8, v9, p0}, Lsz;->u(JLvx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v5, :cond_17d

    goto :goto_18c

    :cond_17d
    :goto_17d
    iput v1, p0, Lads_mobile_sdk/fx;->a:I

    iget-object p1, v3, Lads_mobile_sdk/lx;->c:Lly;

    new-instance v0, Lt00;

    invoke-direct {v0, v3, v6, v7, v7}, Lt00;-><init>(Lads_mobile_sdk/lx;ZLjava/lang/String;Lvx;)V

    invoke-static {p1, v0, p0}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_18d

    :goto_18c
    move-object v2, v5

    :cond_18d
    :goto_18d
    return-object v2

    :pswitch_data_18e
    .packed-switch 0x0
        :pswitch_13c  #00000000
        :pswitch_11b  #00000001
        :pswitch_f8  #00000002
        :pswitch_75  #00000003
        :pswitch_54  #00000004
        :pswitch_33  #00000005
    .end packed-switch
.end method
