.class public final Lads_mobile_sdk/af;
.super Lads_mobile_sdk/ku0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field private static final DEFAULT_INSTANCE:Lads_mobile_sdk/af;

.field public static final c:I = 0x1


# instance fields
.field private logs_:Lads_mobile_sdk/gn1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lads_mobile_sdk/gn1;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lads_mobile_sdk/af;

    invoke-direct {v0}, Lads_mobile_sdk/af;-><init>()V

    sput-object v0, Lads_mobile_sdk/af;->DEFAULT_INSTANCE:Lads_mobile_sdk/af;

    const-class v1, Lads_mobile_sdk/af;

    invoke-static {v1, v0}, Lads_mobile_sdk/ku0;->a(Ljava/lang/Class;Lads_mobile_sdk/ku0;)V

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Lads_mobile_sdk/ku0;-><init>()V

    sget-object v0, Lads_mobile_sdk/gn1;->b:Lads_mobile_sdk/gn1;

    iput-object v0, p0, Lads_mobile_sdk/af;->logs_:Lads_mobile_sdk/gn1;

    return-void
.end method

.method public static a(Ljava/io/FileInputStream;)Lads_mobile_sdk/af;
    .registers 3

    sget-object v0, Lads_mobile_sdk/af;->DEFAULT_INSTANCE:Lads_mobile_sdk/af;

    new-instance v1, Lads_mobile_sdk/iv;

    invoke-direct {v1, p0}, Lads_mobile_sdk/iv;-><init>(Ljava/io/FileInputStream;)V

    invoke-static {}, Lads_mobile_sdk/ul0;->a()Lads_mobile_sdk/ul0;

    move-result-object p0

    invoke-static {v0, v1, p0}, Lads_mobile_sdk/ku0;->a(Lads_mobile_sdk/ku0;Lads_mobile_sdk/jv;Lads_mobile_sdk/ul0;)Lads_mobile_sdk/ku0;

    move-result-object p0

    invoke-static {p0}, Lads_mobile_sdk/ku0;->a(Lads_mobile_sdk/ku0;)V

    check-cast p0, Lads_mobile_sdk/af;

    return-object p0
.end method

.method public static bridge synthetic c(Lads_mobile_sdk/af;)Lads_mobile_sdk/gn1;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/af;->logs_:Lads_mobile_sdk/gn1;

    return-object p0
.end method

.method public static bridge synthetic d(Lads_mobile_sdk/af;Lads_mobile_sdk/gn1;)V
    .registers 2

    iput-object p1, p0, Lads_mobile_sdk/af;->logs_:Lads_mobile_sdk/gn1;

    return-void
.end method

.method public static o()Lads_mobile_sdk/af;
    .registers 1

    sget-object v0, Lads_mobile_sdk/af;->DEFAULT_INSTANCE:Lads_mobile_sdk/af;

    return-object v0
.end method


# virtual methods
.method public final a(ILads_mobile_sdk/ku0;)Ljava/lang/Object;
    .registers 4

    .prologue
    invoke-static {p1}, Lvr0;->a(I)I

    move-result p0

    if-eqz p0, :cond_41

    const/4 p1, 0x2

    if-eq p0, p1, :cond_2f

    const/4 p1, 0x3

    if-eq p0, p1, :cond_29

    const/4 p1, 0x4

    if-eq p0, p1, :cond_21

    const/4 p1, 0x5

    if-eq p0, p1, :cond_1e

    const/4 p1, 0x6

    if-ne p0, p1, :cond_1c

    const-class p0, Lads_mobile_sdk/af;

    invoke-static {p0}, Lads_mobile_sdk/ku0;->b(Ljava/lang/Class;)Lads_mobile_sdk/ju0;

    move-result-object p0

    return-object p0

    :cond_1c
    const/4 p0, 0x0

    throw p0

    :cond_1e
    sget-object p0, Lads_mobile_sdk/af;->DEFAULT_INSTANCE:Lads_mobile_sdk/af;

    return-object p0

    :cond_21
    new-instance p0, Ll73;

    sget-object p1, Lads_mobile_sdk/af;->DEFAULT_INSTANCE:Lads_mobile_sdk/af;

    invoke-direct {p0, p1}, Lads_mobile_sdk/iu0;-><init>(Lads_mobile_sdk/ku0;)V

    return-object p0

    :cond_29
    new-instance p0, Lads_mobile_sdk/af;

    invoke-direct {p0}, Lads_mobile_sdk/af;-><init>()V

    return-object p0

    :cond_2f
    const-string p0, "logs_"

    sget-object p1, Lja3;->a:Lads_mobile_sdk/dn1;

    filled-new-array {p0, p1}, [Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lads_mobile_sdk/af;->DEFAULT_INSTANCE:Lads_mobile_sdk/af;

    new-instance p2, Lads_mobile_sdk/zq2;

    const-string v0, "\u0004\u0001\u0000\u0000\u0001\u0001\u0001\u0001\u0000\u0000\u00012"

    invoke-direct {p2, p1, v0, p0}, Lads_mobile_sdk/zq2;-><init>(Lads_mobile_sdk/ku0;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object p2

    :cond_41
    const/4 p0, 0x1

    invoke-static {p0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p0

    return-object p0
.end method

.method public final p()Ljava/util/Map;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/af;->logs_:Lads_mobile_sdk/gn1;

    invoke-static {p0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object p0

    return-object p0
.end method
