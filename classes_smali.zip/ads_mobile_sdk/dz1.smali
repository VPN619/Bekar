.class public final Lads_mobile_sdk/dz1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpv2;


# instance fields
.field public final a:Ljava/util/Map;

.field public final synthetic b:I


# direct methods
.method public constructor <init>(Ljava/util/Map;)V
    .registers 3

    const/4 v0, 0x1

    iput v0, p0, Lads_mobile_sdk/dz1;->b:I

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/dz1;->a:Ljava/util/Map;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/util/Map;I)V
    .registers 3

    iput p2, p0, Lads_mobile_sdk/dz1;->b:I

    iput-object p1, p0, Lads_mobile_sdk/dz1;->a:Ljava/util/Map;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lc03;Lwx;)Ljava/lang/Object;
    .registers 13

    .prologue
    iget v0, p0, Lads_mobile_sdk/dz1;->b:I

    sget-object v1, Lrg2;->a:Lrg2;

    iget-object v2, p0, Lads_mobile_sdk/dz1;->a:Ljava/util/Map;

    const/4 v3, 0x0

    const-string v4, "call to \'resume\' before \'invoke\' with coroutine"

    sget-object v5, Lwy;->a:Lwy;

    const/high16 v6, -0x80000000

    const/4 v7, 0x1

    packed-switch v0, :pswitch_data_84

    instance-of v0, p2, Lads_mobile_sdk/w00;

    if-eqz v0, :cond_22

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/w00;

    iget v8, v0, Lads_mobile_sdk/w00;->c:I

    and-int v9, v8, v6

    if-eqz v9, :cond_22

    sub-int/2addr v8, v6

    iput v8, v0, Lads_mobile_sdk/w00;->c:I

    goto :goto_27

    :cond_22
    new-instance v0, Lads_mobile_sdk/w00;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/w00;-><init>(Lads_mobile_sdk/dz1;Lwx;)V

    :goto_27
    iget-object p0, v0, Lads_mobile_sdk/w00;->a:Ljava/lang/Object;

    iget p2, v0, Lads_mobile_sdk/w00;->c:I

    if-eqz p2, :cond_38

    if-ne p2, v7, :cond_33

    invoke-static {p0}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_49

    :cond_33
    invoke-static {v4}, Lz6;->w(Ljava/lang/String;)V

    move-object v1, v3

    goto :goto_49

    :cond_38
    invoke-static {p0}, Lt12;->W(Ljava/lang/Object;)V

    new-instance p0, Lads_mobile_sdk/dz1;

    invoke-direct {p0, v2}, Lads_mobile_sdk/dz1;-><init>(Ljava/util/Map;)V

    iput v7, v0, Lads_mobile_sdk/w00;->c:I

    invoke-virtual {p0, p1, v0}, Lads_mobile_sdk/dz1;->a(Lg33;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_49

    move-object v1, v5

    :cond_49
    :goto_49
    return-object v1

    :pswitch_4a  #0x7
    instance-of v0, p2, Lads_mobile_sdk/qj3;

    if-eqz v0, :cond_5b

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/qj3;

    iget v8, v0, Lads_mobile_sdk/qj3;->c:I

    and-int v9, v8, v6

    if-eqz v9, :cond_5b

    sub-int/2addr v8, v6

    iput v8, v0, Lads_mobile_sdk/qj3;->c:I

    goto :goto_60

    :cond_5b
    new-instance v0, Lads_mobile_sdk/qj3;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/qj3;-><init>(Lads_mobile_sdk/dz1;Lwx;)V

    :goto_60
    iget-object p0, v0, Lads_mobile_sdk/qj3;->a:Ljava/lang/Object;

    iget p2, v0, Lads_mobile_sdk/qj3;->c:I

    if-eqz p2, :cond_71

    if-ne p2, v7, :cond_6c

    invoke-static {p0}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_82

    :cond_6c
    invoke-static {v4}, Lz6;->w(Ljava/lang/String;)V

    move-object v1, v3

    goto :goto_82

    :cond_71
    invoke-static {p0}, Lt12;->W(Ljava/lang/Object;)V

    new-instance p0, Lads_mobile_sdk/dz1;

    invoke-direct {p0, v2}, Lads_mobile_sdk/dz1;-><init>(Ljava/util/Map;)V

    iput v7, v0, Lads_mobile_sdk/qj3;->c:I

    invoke-virtual {p0, p1, v0}, Lads_mobile_sdk/dz1;->a(Lg33;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_82

    move-object v1, v5

    :cond_82
    :goto_82
    return-object v1

    nop

    :pswitch_data_84
    .packed-switch 0x7
        :pswitch_4a  #00000007
    .end packed-switch
.end method

.method public a(Lg33;Lwx;)Ljava/lang/Object;
    .registers 13

    .prologue
    iget v0, p0, Lads_mobile_sdk/dz1;->b:I

    sget-object v1, Lrg2;->a:Lrg2;

    iget-object v2, p0, Lads_mobile_sdk/dz1;->a:Ljava/util/Map;

    const-string v3, "call to \'resume\' before \'invoke\' with coroutine"

    sget-object v4, Lwy;->a:Lwy;

    const/high16 v5, -0x80000000

    const/4 v6, 0x1

    const/4 v7, 0x0

    packed-switch v0, :pswitch_data_1d6

    :pswitch_11  #0x3
    instance-of v0, p2, Lads_mobile_sdk/rz1;

    if-eqz v0, :cond_22

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/rz1;

    iget v8, v0, Lads_mobile_sdk/rz1;->c:I

    and-int v9, v8, v5

    if-eqz v9, :cond_22

    sub-int/2addr v8, v5

    iput v8, v0, Lads_mobile_sdk/rz1;->c:I

    goto :goto_27

    :cond_22
    new-instance v0, Lads_mobile_sdk/rz1;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/rz1;-><init>(Lads_mobile_sdk/dz1;Lwx;)V

    :goto_27
    iget-object p0, v0, Lads_mobile_sdk/rz1;->a:Ljava/lang/Object;

    iget p2, v0, Lads_mobile_sdk/rz1;->c:I

    if-eqz p2, :cond_38

    if-ne p2, v6, :cond_33

    invoke-static {p0}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_49

    :cond_33
    invoke-static {v3}, Lz6;->w(Ljava/lang/String;)V

    move-object v1, v7

    goto :goto_49

    :cond_38
    invoke-static {p0}, Lt12;->W(Ljava/lang/Object;)V

    new-instance p0, Lads_mobile_sdk/dz1;

    invoke-direct {p0, v2}, Lads_mobile_sdk/dz1;-><init>(Ljava/util/Map;)V

    iput v6, v0, Lads_mobile_sdk/rz1;->c:I

    invoke-virtual {p0, p1, v0}, Lads_mobile_sdk/dz1;->a(Lg33;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v4, :cond_49

    move-object v1, v4

    :cond_49
    :goto_49
    return-object v1

    :pswitch_4a  #0x6
    instance-of v0, p2, Lads_mobile_sdk/qg2;

    if-eqz v0, :cond_5b

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/qg2;

    iget v8, v0, Lads_mobile_sdk/qg2;->c:I

    and-int v9, v8, v5

    if-eqz v9, :cond_5b

    sub-int/2addr v8, v5

    iput v8, v0, Lads_mobile_sdk/qg2;->c:I

    goto :goto_60

    :cond_5b
    new-instance v0, Lads_mobile_sdk/qg2;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/qg2;-><init>(Lads_mobile_sdk/dz1;Lwx;)V

    :goto_60
    iget-object p0, v0, Lads_mobile_sdk/qg2;->a:Ljava/lang/Object;

    iget p2, v0, Lads_mobile_sdk/qg2;->c:I

    if-eqz p2, :cond_71

    if-ne p2, v6, :cond_6c

    invoke-static {p0}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_82

    :cond_6c
    invoke-static {v3}, Lz6;->w(Ljava/lang/String;)V

    move-object v1, v7

    goto :goto_82

    :cond_71
    invoke-static {p0}, Lt12;->W(Ljava/lang/Object;)V

    new-instance p0, Lads_mobile_sdk/dz1;

    invoke-direct {p0, v2}, Lads_mobile_sdk/dz1;-><init>(Ljava/util/Map;)V

    iput v6, v0, Lads_mobile_sdk/qg2;->c:I

    invoke-virtual {p0, p1, v0}, Lads_mobile_sdk/dz1;->a(Lg33;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v4, :cond_82

    move-object v1, v4

    :cond_82
    :goto_82
    return-object v1

    :pswitch_83  #0x5
    instance-of v0, p2, Lads_mobile_sdk/m93;

    if-eqz v0, :cond_94

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/m93;

    iget v8, v0, Lads_mobile_sdk/m93;->c:I

    and-int v9, v8, v5

    if-eqz v9, :cond_94

    sub-int/2addr v8, v5

    iput v8, v0, Lads_mobile_sdk/m93;->c:I

    goto :goto_99

    :cond_94
    new-instance v0, Lads_mobile_sdk/m93;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/m93;-><init>(Lads_mobile_sdk/dz1;Lwx;)V

    :goto_99
    iget-object p0, v0, Lads_mobile_sdk/m93;->a:Ljava/lang/Object;

    iget p2, v0, Lads_mobile_sdk/m93;->c:I

    if-eqz p2, :cond_aa

    if-ne p2, v6, :cond_a5

    invoke-static {p0}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_bb

    :cond_a5
    invoke-static {v3}, Lz6;->w(Ljava/lang/String;)V

    move-object v1, v7

    goto :goto_bb

    :cond_aa
    invoke-static {p0}, Lt12;->W(Ljava/lang/Object;)V

    new-instance p0, Lads_mobile_sdk/dz1;

    invoke-direct {p0, v2}, Lads_mobile_sdk/dz1;-><init>(Ljava/util/Map;)V

    iput v6, v0, Lads_mobile_sdk/m93;->c:I

    invoke-virtual {p0, p1, v0}, Lads_mobile_sdk/dz1;->a(Lg33;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v4, :cond_bb

    move-object v1, v4

    :cond_bb
    :goto_bb
    return-object v1

    :pswitch_bc  #0x4
    instance-of v0, p2, Lads_mobile_sdk/i02;

    if-eqz v0, :cond_cd

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/i02;

    iget v8, v0, Lads_mobile_sdk/i02;->c:I

    and-int v9, v8, v5

    if-eqz v9, :cond_cd

    sub-int/2addr v8, v5

    iput v8, v0, Lads_mobile_sdk/i02;->c:I

    goto :goto_d2

    :cond_cd
    new-instance v0, Lads_mobile_sdk/i02;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/i02;-><init>(Lads_mobile_sdk/dz1;Lwx;)V

    :goto_d2
    iget-object p0, v0, Lads_mobile_sdk/i02;->a:Ljava/lang/Object;

    iget p2, v0, Lads_mobile_sdk/i02;->c:I

    if-eqz p2, :cond_e3

    if-ne p2, v6, :cond_de

    invoke-static {p0}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_f4

    :cond_de
    invoke-static {v3}, Lz6;->w(Ljava/lang/String;)V

    move-object v1, v7

    goto :goto_f4

    :cond_e3
    invoke-static {p0}, Lt12;->W(Ljava/lang/Object;)V

    new-instance p0, Lads_mobile_sdk/dz1;

    invoke-direct {p0, v2}, Lads_mobile_sdk/dz1;-><init>(Ljava/util/Map;)V

    iput v6, v0, Lads_mobile_sdk/i02;->c:I

    invoke-virtual {p0, p1, v0}, Lads_mobile_sdk/dz1;->a(Lg33;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v4, :cond_f4

    move-object v1, v4

    :cond_f4
    :goto_f4
    return-object v1

    :pswitch_f5  #0x2
    instance-of v0, p2, Lads_mobile_sdk/f91;

    if-eqz v0, :cond_106

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/f91;

    iget v8, v0, Lads_mobile_sdk/f91;->c:I

    and-int v9, v8, v5

    if-eqz v9, :cond_106

    sub-int/2addr v8, v5

    iput v8, v0, Lads_mobile_sdk/f91;->c:I

    goto :goto_10b

    :cond_106
    new-instance v0, Lads_mobile_sdk/f91;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/f91;-><init>(Lads_mobile_sdk/dz1;Lwx;)V

    :goto_10b
    iget-object p0, v0, Lads_mobile_sdk/f91;->a:Ljava/lang/Object;

    iget p2, v0, Lads_mobile_sdk/f91;->c:I

    if-eqz p2, :cond_11c

    if-ne p2, v6, :cond_117

    invoke-static {p0}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_12d

    :cond_117
    invoke-static {v3}, Lz6;->w(Ljava/lang/String;)V

    move-object v1, v7

    goto :goto_12d

    :cond_11c
    invoke-static {p0}, Lt12;->W(Ljava/lang/Object;)V

    new-instance p0, Lads_mobile_sdk/dz1;

    invoke-direct {p0, v2}, Lads_mobile_sdk/dz1;-><init>(Ljava/util/Map;)V

    iput v6, v0, Lads_mobile_sdk/f91;->c:I

    invoke-virtual {p0, p1, v0}, Lads_mobile_sdk/dz1;->a(Lg33;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v4, :cond_12d

    move-object v1, v4

    :cond_12d
    :goto_12d
    return-object v1

    :pswitch_12e  #0x1
    instance-of v0, p2, Lads_mobile_sdk/dz0;

    if-eqz v0, :cond_13f

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/dz0;

    iget v8, v0, Lads_mobile_sdk/dz0;->e:I

    and-int v9, v8, v5

    if-eqz v9, :cond_13f

    sub-int/2addr v8, v5

    iput v8, v0, Lads_mobile_sdk/dz0;->e:I

    goto :goto_144

    :cond_13f
    new-instance v0, Lads_mobile_sdk/dz0;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/dz0;-><init>(Lads_mobile_sdk/dz1;Lwx;)V

    :goto_144
    iget-object p0, v0, Lads_mobile_sdk/dz0;->c:Ljava/lang/Object;

    iget p2, v0, Lads_mobile_sdk/dz0;->e:I

    if-eqz p2, :cond_159

    if-ne p2, v6, :cond_154

    iget-object p1, v0, Lads_mobile_sdk/dz0;->b:Ljava/util/Iterator;

    iget-object p2, v0, Lads_mobile_sdk/dz0;->a:Lg33;

    invoke-static {p0}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_166

    :cond_154
    invoke-static {v3}, Lz6;->w(Ljava/lang/String;)V

    move-object v1, v7

    goto :goto_19c

    :cond_159
    invoke-static {p0}, Lt12;->W(Ljava/lang/Object;)V

    invoke-interface {v2}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    move-object p2, p1

    move-object p1, p0

    :cond_166
    :goto_166
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p0

    if-eqz p0, :cond_19c

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/util/Map$Entry;

    invoke-interface {p0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-interface {p0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lbw2;

    invoke-interface {p0}, Lbw2;->d()Ljava/lang/String;

    move-result-object v3

    const-string v5, "] adKey: ["

    const-string v8, "]"

    const-string v9, "Installing gmsg handler for ["

    invoke-static {v9, v2, v5, v3, v8}, Lrt2;->j(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3, v7}, Lads_mobile_sdk/nw;->b(Ljava/lang/String;Ljava/lang/Throwable;)V

    iput-object p2, v0, Lads_mobile_sdk/dz0;->a:Lg33;

    iput-object p1, v0, Lads_mobile_sdk/dz0;->b:Ljava/util/Iterator;

    iput v6, v0, Lads_mobile_sdk/dz0;->e:I

    invoke-interface {p2, v2, p0, v0}, Lg33;->a(Ljava/lang/String;Lbw2;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v4, :cond_166

    move-object v1, v4

    :cond_19c
    :goto_19c
    return-object v1

    :pswitch_19d  #0x0
    instance-of v0, p2, Lads_mobile_sdk/cz1;

    if-eqz v0, :cond_1ae

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/cz1;

    iget v8, v0, Lads_mobile_sdk/cz1;->c:I

    and-int v9, v8, v5

    if-eqz v9, :cond_1ae

    sub-int/2addr v8, v5

    iput v8, v0, Lads_mobile_sdk/cz1;->c:I

    goto :goto_1b3

    :cond_1ae
    new-instance v0, Lads_mobile_sdk/cz1;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/cz1;-><init>(Lads_mobile_sdk/dz1;Lwx;)V

    :goto_1b3
    iget-object p0, v0, Lads_mobile_sdk/cz1;->a:Ljava/lang/Object;

    iget p2, v0, Lads_mobile_sdk/cz1;->c:I

    if-eqz p2, :cond_1c4

    if-ne p2, v6, :cond_1bf

    invoke-static {p0}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_1d5

    :cond_1bf
    invoke-static {v3}, Lz6;->w(Ljava/lang/String;)V

    move-object v1, v7

    goto :goto_1d5

    :cond_1c4
    invoke-static {p0}, Lt12;->W(Ljava/lang/Object;)V

    new-instance p0, Lads_mobile_sdk/dz1;

    invoke-direct {p0, v2}, Lads_mobile_sdk/dz1;-><init>(Ljava/util/Map;)V

    iput v6, v0, Lads_mobile_sdk/cz1;->c:I

    invoke-virtual {p0, p1, v0}, Lads_mobile_sdk/dz1;->a(Lg33;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v4, :cond_1d5

    move-object v1, v4

    :cond_1d5
    :goto_1d5
    return-object v1

    :pswitch_data_1d6
    .packed-switch 0x0
        :pswitch_19d  #00000000
        :pswitch_12e  #00000001
        :pswitch_f5  #00000002
        :pswitch_11  #00000003
        :pswitch_bc  #00000004
        :pswitch_83  #00000005
        :pswitch_4a  #00000006
    .end packed-switch
.end method

.method public final bridge synthetic a(Ljava/lang/Object;Lads_mobile_sdk/rk1;)Ljava/lang/Object;
    .registers 4

    .prologue
    iget v0, p0, Lads_mobile_sdk/dz1;->b:I

    packed-switch v0, :pswitch_data_4c

    check-cast p1, Lc03;

    invoke-virtual {p0, p1, p2}, Lads_mobile_sdk/dz1;->a(Lc03;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_c  #0x8
    check-cast p1, Lg33;

    invoke-virtual {p0, p1, p2}, Lads_mobile_sdk/dz1;->a(Lg33;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_13  #0x7
    check-cast p1, Lc03;

    invoke-virtual {p0, p1, p2}, Lads_mobile_sdk/dz1;->a(Lc03;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_1a  #0x6
    check-cast p1, Lg33;

    invoke-virtual {p0, p1, p2}, Lads_mobile_sdk/dz1;->a(Lg33;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_21  #0x5
    check-cast p1, Lg33;

    invoke-virtual {p0, p1, p2}, Lads_mobile_sdk/dz1;->a(Lg33;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_28  #0x4
    check-cast p1, Lg33;

    invoke-virtual {p0, p1, p2}, Lads_mobile_sdk/dz1;->a(Lg33;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_2f  #0x3
    check-cast p1, Lsw2;

    invoke-virtual {p0, p1, p2}, Lads_mobile_sdk/dz1;->a(Lsw2;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_36  #0x2
    check-cast p1, Lg33;

    invoke-virtual {p0, p1, p2}, Lads_mobile_sdk/dz1;->a(Lg33;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_3d  #0x1
    check-cast p1, Lg33;

    invoke-virtual {p0, p1, p2}, Lads_mobile_sdk/dz1;->a(Lg33;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_44  #0x0
    check-cast p1, Lg33;

    invoke-virtual {p0, p1, p2}, Lads_mobile_sdk/dz1;->a(Lg33;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_4c
    .packed-switch 0x0
        :pswitch_44  #00000000
        :pswitch_3d  #00000001
        :pswitch_36  #00000002
        :pswitch_2f  #00000003
        :pswitch_28  #00000004
        :pswitch_21  #00000005
        :pswitch_1a  #00000006
        :pswitch_13  #00000007
        :pswitch_c  #00000008
    .end packed-switch
.end method

.method public a(Lsw2;Lwx;)Ljava/lang/Object;
    .registers 7

    .prologue
    instance-of v0, p2, Lads_mobile_sdk/fk1;

    if-eqz v0, :cond_13

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/fk1;

    iget v1, v0, Lads_mobile_sdk/fk1;->c:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/fk1;->c:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/fk1;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/fk1;-><init>(Lads_mobile_sdk/dz1;Lwx;)V

    :goto_18
    iget-object p2, v0, Lads_mobile_sdk/fk1;->a:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/fk1;->c:I

    const/4 v2, 0x1

    if-eqz v1, :cond_2c

    if-ne v1, v2, :cond_25

    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_41

    :cond_25
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0

    :cond_2c
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    new-instance p2, Lads_mobile_sdk/dz1;

    iget-object p0, p0, Lads_mobile_sdk/dz1;->a:Ljava/util/Map;

    invoke-direct {p2, p0}, Lads_mobile_sdk/dz1;-><init>(Ljava/util/Map;)V

    iput v2, v0, Lads_mobile_sdk/fk1;->c:I

    invoke-virtual {p2, p1, v0}, Lads_mobile_sdk/dz1;->a(Lg33;Lwx;)Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lwy;->a:Lwy;

    if-ne p0, p1, :cond_41

    return-object p1

    :cond_41
    :goto_41
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method
