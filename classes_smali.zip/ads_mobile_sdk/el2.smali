.class public final Lads_mobile_sdk/el2;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lmt2;


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:Ljava/util/concurrent/ExecutorService;

.field public final c:Lads_mobile_sdk/s11;

.field public final d:Ljava/lang/String;

.field public final e:I

.field public final f:Ljava/lang/String;

.field public final g:Lads_mobile_sdk/th3;

.field public final h:Lads_mobile_sdk/ql2;


# direct methods
.method public constructor <init>(Landroid/content/Context;Ljava/util/concurrent/ExecutorService;Lads_mobile_sdk/l7;Lads_mobile_sdk/s11;Lads_mobile_sdk/th3;Lads_mobile_sdk/ql2;)V
    .registers 7

    .prologue
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/el2;->a:Landroid/content/Context;

    iput-object p2, p0, Lads_mobile_sdk/el2;->b:Ljava/util/concurrent/ExecutorService;

    iput-object p4, p0, Lads_mobile_sdk/el2;->c:Lads_mobile_sdk/s11;

    iput-object p5, p0, Lads_mobile_sdk/el2;->g:Lads_mobile_sdk/th3;

    iput-object p6, p0, Lads_mobile_sdk/el2;->h:Lads_mobile_sdk/ql2;

    invoke-virtual {p3}, Lads_mobile_sdk/l7;->D()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lads_mobile_sdk/el2;->d:Ljava/lang/String;

    invoke-virtual {p3}, Lads_mobile_sdk/l7;->C()I

    move-result p1

    invoke-static {p1}, Lmz2;->_getNumber$1(I)I

    move-result p1

    const/4 p2, 0x1

    if-eqz p1, :cond_2c

    const/4 p4, 0x2

    if-eq p1, p2, :cond_2d

    const/4 p5, 0x3

    if-eq p1, p4, :cond_2a

    if-eq p1, p5, :cond_28

    const/4 p4, 0x0

    goto :goto_2d

    :cond_28
    const/4 p4, 0x4

    goto :goto_2d

    :cond_2a
    move p4, p5

    goto :goto_2d

    :cond_2c
    move p4, p2

    :cond_2d
    :goto_2d
    if-eqz p4, :cond_30

    move p2, p4

    :cond_30
    iput p2, p0, Lads_mobile_sdk/el2;->e:I

    invoke-virtual {p3}, Lads_mobile_sdk/l7;->J()Lads_mobile_sdk/ul2;

    move-result-object p1

    invoke-virtual {p1}, Lads_mobile_sdk/ul2;->t()Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lads_mobile_sdk/el2;->f:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final a()Ll;
    .registers 9

    .prologue
    sget-object v0, Lads_mobile_sdk/fl0;->P2:Lads_mobile_sdk/fl0;

    invoke-static {}, Lads_mobile_sdk/v7;->o()Li53;

    move-result-object v1

    invoke-static {}, Lck;->f()[B

    move-result-object v2

    array-length v3, v2

    const/4 v4, 0x0

    invoke-static {v2, v4, v3}, Lads_mobile_sdk/hr;->a([BII)Lads_mobile_sdk/fr;

    move-result-object v2

    invoke-virtual {v1}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v3, v1, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v3, Lads_mobile_sdk/v7;

    invoke-virtual {v3, v2}, Lads_mobile_sdk/v7;->a(Lads_mobile_sdk/fr;)V

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    int-to-long v2, v2

    invoke-virtual {v1}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v5, v1, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v5, Lads_mobile_sdk/v7;

    invoke-static {v5}, Lads_mobile_sdk/v7;->c(Lads_mobile_sdk/v7;)I

    move-result v6

    const/4 v7, 0x2

    or-int/2addr v6, v7

    invoke-static {v5, v6}, Lads_mobile_sdk/v7;->g(Lads_mobile_sdk/v7;I)V

    invoke-static {v5, v2, v3}, Lads_mobile_sdk/v7;->d(Lads_mobile_sdk/v7;J)V

    sget-object v2, Landroid/os/Build;->MODEL:Ljava/lang/String;

    invoke-virtual {v1}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v3, v1, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v3, Lads_mobile_sdk/v7;

    invoke-virtual {v3, v2}, Lads_mobile_sdk/v7;->d(Ljava/lang/String;)V

    iget-object v2, p0, Lads_mobile_sdk/el2;->a:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v5, v1, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v5, Lads_mobile_sdk/v7;

    invoke-virtual {v5, v3}, Lads_mobile_sdk/v7;->b(Ljava/lang/String;)V

    :try_start_4c
    invoke-virtual {v2}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v3

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v3, v2, v4}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v2

    iget v2, v2, Landroid/content/pm/PackageInfo;->versionCode:I
    :try_end_5a
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_4c .. :try_end_5a} :catch_5b

    goto :goto_5c

    :catch_5b
    const/4 v2, -0x1

    :goto_5c
    int-to-long v2, v2

    invoke-virtual {v1}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v5, v1, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v5, Lads_mobile_sdk/v7;

    invoke-static {v5}, Lads_mobile_sdk/v7;->c(Lads_mobile_sdk/v7;)I

    move-result v6

    or-int/lit8 v6, v6, 0x10

    invoke-static {v5, v6}, Lads_mobile_sdk/v7;->g(Lads_mobile_sdk/v7;I)V

    invoke-static {v5, v2, v3}, Lads_mobile_sdk/v7;->f(Lads_mobile_sdk/v7;J)V

    invoke-virtual {v1}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v2, v1, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v2, Lads_mobile_sdk/v7;

    iget-object v3, p0, Lads_mobile_sdk/el2;->d:Ljava/lang/String;

    invoke-virtual {v2, v3}, Lads_mobile_sdk/v7;->c(Ljava/lang/String;)V

    invoke-virtual {v1}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v2, v1, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v2, Lads_mobile_sdk/v7;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v7}, Lmz2;->b(I)I

    move-result v3

    invoke-static {v2, v3}, Lads_mobile_sdk/v7;->i(Lads_mobile_sdk/v7;I)V

    invoke-static {v2}, Lads_mobile_sdk/v7;->c(Lads_mobile_sdk/v7;)I

    move-result v3

    or-int/lit8 v3, v3, 0x40

    invoke-static {v2, v3}, Lads_mobile_sdk/v7;->g(Lads_mobile_sdk/v7;I)V

    invoke-virtual {v1}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v2, v1, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v2, Lads_mobile_sdk/v7;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget v3, p0, Lads_mobile_sdk/el2;->e:I

    invoke-static {v3}, Lmz2;->_getNumber$4(I)I

    move-result v3

    invoke-static {v2, v3}, Lads_mobile_sdk/v7;->h(Lads_mobile_sdk/v7;I)V

    invoke-static {v2}, Lads_mobile_sdk/v7;->c(Lads_mobile_sdk/v7;)I

    move-result v3

    or-int/lit16 v3, v3, 0x80

    invoke-static {v2, v3}, Lads_mobile_sdk/v7;->g(Lads_mobile_sdk/v7;I)V

    invoke-virtual {v1}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object v1

    check-cast v1, Lads_mobile_sdk/v7;

    invoke-virtual {v1}, Lads_mobile_sdk/g;->a()[B

    move-result-object v1

    const/4 v2, 0x1

    invoke-static {v2}, Lgt0;->H(Z)Ldi;

    move-result-object v3

    invoke-virtual {v3, v1}, Lfi;->c([B)Ljava/lang/String;

    move-result-object v1

    iget-object v3, p0, Lads_mobile_sdk/el2;->f:Ljava/lang/String;

    invoke-static {v3}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    invoke-virtual {v3}, Landroid/net/Uri;->buildUpon()Landroid/net/Uri$Builder;

    move-result-object v3

    const-string v5, "aspq"

    invoke-virtual {v3, v5, v1}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object v1

    invoke-virtual {v1}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object v1

    invoke-virtual {v1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v1

    new-array v3, v4, [B

    const/4 v5, 0x0

    iget-object v6, p0, Lads_mobile_sdk/el2;->c:Lads_mobile_sdk/s11;

    invoke-virtual {v6, v1, v4, v3, v5}, Lads_mobile_sdk/s11;->a(Ljava/lang/String;Z[BLjava/lang/String;)Lzm;

    move-result-object v1

    invoke-static {v1}, Lfg0;->r(Ld31;)Lfg0;

    move-result-object v1

    new-instance v3, Lhx2;

    invoke-direct {v3, p0, v4}, Lhx2;-><init>(Lads_mobile_sdk/el2;I)V

    iget-object v4, p0, Lads_mobile_sdk/el2;->b:Ljava/util/concurrent/ExecutorService;

    invoke-static {v1, v3, v4}, Lk1;->t(Ld31;Llk0;Ljava/util/concurrent/Executor;)Lj1;

    move-result-object v1

    new-instance v3, Lhx2;

    invoke-direct {v3, p0, v2}, Lhx2;-><init>(Lads_mobile_sdk/el2;I)V

    const-class v2, Ljava/net/UnknownHostException;

    sget-object v4, Lv40;->a:Lv40;

    invoke-virtual {v1, v2, v3, v4}, Lfg0;->q(Ljava/lang/Class;Llk0;Ljava/util/concurrent/Executor;)Ll;

    move-result-object v1

    new-instance v2, Lhx2;

    invoke-direct {v2, p0, v7}, Lhx2;-><init>(Lads_mobile_sdk/el2;I)V

    const-class v3, Ljava/net/SocketException;

    invoke-virtual {v1, v3, v2, v4}, Lfg0;->q(Ljava/lang/Class;Llk0;Ljava/util/concurrent/Executor;)Ll;

    move-result-object v1

    iget-object p0, p0, Lads_mobile_sdk/el2;->g:Lads_mobile_sdk/th3;

    invoke-virtual {p0, v0, v1}, Lads_mobile_sdk/th3;->a(Lads_mobile_sdk/fl0;Leg0;)V

    return-object v1
.end method
