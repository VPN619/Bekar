.class public final Lads_mobile_sdk/ci0;
.super Lzz0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lzj0;


# instance fields
.field public final synthetic a:Lads_mobile_sdk/ki0;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/ki0;)V
    .registers 2

    iput-object p1, p0, Lads_mobile_sdk/ci0;->a:Lads_mobile_sdk/ki0;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lzz0;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 4

    .prologue
    :try_start_0
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x21

    if-lt v0, v1, :cond_1b

    invoke-static {v1}, Landroid/os/ext/SdkExtensions;->getExtensionVersion(I)I

    move-result v1

    const/4 v2, 0x5

    if-lt v1, v2, :cond_1b

    const v0, 0xf4240

    invoke-static {v0}, Landroid/os/ext/SdkExtensions;->getExtensionVersion(I)I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    return-object p0

    :catch_19
    move-exception v0

    goto :goto_30

    :cond_1b
    const/16 v1, 0x1f

    if-lt v0, v1, :cond_39

    invoke-static {v1}, Landroid/os/ext/SdkExtensions;->getExtensionVersion(I)I

    move-result v0

    const/16 v2, 0x9

    if-lt v0, v2, :cond_39

    invoke-static {v1}, Landroid/os/ext/SdkExtensions;->getExtensionVersion(I)I

    move-result v0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0
    :try_end_2f
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_2f} :catch_19

    return-object p0

    :goto_30
    iget-object p0, p0, Lads_mobile_sdk/ci0;->a:Lads_mobile_sdk/ki0;

    iget-object p0, p0, Lads_mobile_sdk/ki0;->d:Lads_mobile_sdk/ah3;

    const-string v1, "DeviceProperties.adServicesExtensionVersion"

    invoke-virtual {p0, v1, v0}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_39
    const/4 p0, 0x0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    return-object p0
.end method
