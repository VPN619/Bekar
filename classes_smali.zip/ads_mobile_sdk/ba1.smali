.class public final Lads_mobile_sdk/ba1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Lvh2;


# direct methods
.method public constructor <init>(Lvh2;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/ba1;->a:Lvh2;

    return-void
.end method


# virtual methods
.method public final a(Lads_mobile_sdk/d91;Lads_mobile_sdk/cy0;Lgh1;)Lads_mobile_sdk/z91;
    .registers 20

    move-object/from16 v0, p0

    iget-object v0, v0, Lads_mobile_sdk/ba1;->a:Lvh2;

    iget-object v1, v0, Lvh2;->a:Ljava/lang/Object;

    check-cast v1, Ltv2;

    invoke-interface {v1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v1

    move-object v6, v1

    check-cast v6, Lads_mobile_sdk/g0;

    iget-object v1, v0, Lvh2;->b:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/ob1;

    iget-object v1, v1, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v7, v1

    check-cast v7, Landroid/content/Context;

    iget-object v1, v0, Lvh2;->c:Ljava/lang/Object;

    check-cast v1, Ltv2;

    invoke-interface {v1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v1

    move-object v8, v1

    check-cast v8, Lvy;

    iget-object v1, v0, Lvh2;->d:Ljava/lang/Object;

    check-cast v1, Ltv2;

    invoke-interface {v1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v1

    move-object v9, v1

    check-cast v9, Lly;

    iget-object v1, v0, Lvh2;->e:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/ah0;

    invoke-virtual {v1}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object v1

    move-object v10, v1

    check-cast v10, Lvy;

    iget-object v1, v0, Lvh2;->f:Ljava/lang/Object;

    check-cast v1, Ltv2;

    invoke-interface {v1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v1

    move-object v11, v1

    check-cast v11, Lads_mobile_sdk/qr0;

    iget-object v1, v0, Lvh2;->g:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/ah0;

    invoke-virtual {v1}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object v1

    move-object v12, v1

    check-cast v12, Lads_mobile_sdk/ah3;

    iget-object v1, v0, Lvh2;->h:Ljava/lang/Object;

    check-cast v1, Ltv2;

    invoke-interface {v1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v1

    move-object v13, v1

    check-cast v13, Ljava/lang/String;

    iget-object v0, v0, Lvh2;->i:Ljava/lang/Object;

    check-cast v0, Ltv2;

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v14, v0

    check-cast v14, Lads_mobile_sdk/ax0;

    new-instance v15, Lads_mobile_sdk/e7;

    const/16 v0, 0xb

    const/4 v1, 0x0

    invoke-direct {v15, v1, v0}, Lads_mobile_sdk/e7;-><init>(BI)V

    new-instance v2, Lads_mobile_sdk/z91;

    move-object/from16 v3, p1

    move-object/from16 v4, p2

    move-object/from16 v5, p3

    invoke-direct/range {v2 .. v15}, Lads_mobile_sdk/z91;-><init>(Lads_mobile_sdk/d91;Lads_mobile_sdk/cy0;Lgh1;Lads_mobile_sdk/g0;Landroid/content/Context;Lvy;Lly;Lvy;Lads_mobile_sdk/qr0;Lads_mobile_sdk/ah3;Ljava/lang/String;Lads_mobile_sdk/ax0;Lads_mobile_sdk/e7;)V

    return-object v2
.end method
