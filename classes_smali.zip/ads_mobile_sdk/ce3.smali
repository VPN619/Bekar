.class public final Lads_mobile_sdk/ce3;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public a:I

.field public final synthetic b:Lads_mobile_sdk/fe3;

.field public final synthetic t:I


# direct methods
.method public synthetic constructor <init>(Lads_mobile_sdk/fe3;Lvx;I)V
    .registers 4

    iput p3, p0, Lads_mobile_sdk/ce3;->t:I

    iput-object p1, p0, Lads_mobile_sdk/ce3;->b:Lads_mobile_sdk/fe3;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 4

    .prologue
    iget p2, p0, Lads_mobile_sdk/ce3;->t:I

    iget-object p0, p0, Lads_mobile_sdk/ce3;->b:Lads_mobile_sdk/fe3;

    packed-switch p2, :pswitch_data_16

    new-instance p2, Lads_mobile_sdk/ce3;

    const/4 v0, 0x1

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/ce3;-><init>(Lads_mobile_sdk/fe3;Lvx;I)V

    return-object p2

    :pswitch_e  #0x0
    new-instance p2, Lads_mobile_sdk/ce3;

    const/4 v0, 0x0

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/ce3;-><init>(Lads_mobile_sdk/fe3;Lvx;I)V

    return-object p2

    nop

    :pswitch_data_16
    .packed-switch 0x0
        :pswitch_e  #00000000
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .prologue
    iget v0, p0, Lads_mobile_sdk/ce3;->t:I

    sget-object v1, Lrg2;->a:Lrg2;

    iget-object p0, p0, Lads_mobile_sdk/ce3;->b:Lads_mobile_sdk/fe3;

    packed-switch v0, :pswitch_data_28

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/ce3;

    const/4 v0, 0x1

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/ce3;-><init>(Lads_mobile_sdk/fe3;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/ce3;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_18  #0x0
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/ce3;

    const/4 v0, 0x0

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/ce3;-><init>(Lads_mobile_sdk/fe3;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/ce3;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_28
    .packed-switch 0x0
        :pswitch_18  #00000000
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 9

    .prologue
    iget v0, p0, Lads_mobile_sdk/ce3;->t:I

    iget-object v1, p0, Lads_mobile_sdk/ce3;->b:Lads_mobile_sdk/fe3;

    const-string v2, "call to \'resume\' before \'invoke\' with coroutine"

    sget-object v3, Lwy;->a:Lwy;

    const/4 v4, 0x1

    sget-object v5, Lrg2;->a:Lrg2;

    const/4 v6, 0x0

    packed-switch v0, :pswitch_data_5a

    iget v0, p0, Lads_mobile_sdk/ce3;->a:I

    if-eqz v0, :cond_1f

    if-ne v0, v4, :cond_1a

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    :cond_18
    move-object v3, v5

    goto :goto_33

    :cond_1a
    invoke-static {v2}, Lz6;->w(Ljava/lang/String;)V

    move-object v3, v6

    goto :goto_33

    :cond_1f
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, v1, Lads_mobile_sdk/fe3;->b:Lads_mobile_sdk/z2;

    new-instance v0, Lxj0;

    const/4 v1, 0x4

    const-string v2, "Mediation adapter failed to show Ad."

    invoke-direct {v0, v1, v2, v6}, Lxj0;-><init>(ILjava/lang/String;Lc81;)V

    iput v4, p0, Lads_mobile_sdk/ce3;->a:I

    invoke-virtual {p1, v0, p0}, Lads_mobile_sdk/z2;->a(Lxj0;Lvx;)Ljava/lang/Object;

    if-ne v5, v3, :cond_18

    :goto_33
    return-object v3

    :pswitch_34  #0x0
    iget v0, p0, Lads_mobile_sdk/ce3;->a:I

    if-eqz v0, :cond_44

    if-ne v0, v4, :cond_3f

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    :cond_3d
    move-object v3, v5

    goto :goto_58

    :cond_3f
    invoke-static {v2}, Lz6;->w(Ljava/lang/String;)V

    move-object v3, v6

    goto :goto_58

    :cond_44
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, v1, Lads_mobile_sdk/fe3;->b:Lads_mobile_sdk/z2;

    new-instance v0, Lxj0;

    const/4 v1, 0x2

    const-string v2, "This ad has already been shown."

    invoke-direct {v0, v1, v2, v6}, Lxj0;-><init>(ILjava/lang/String;Lc81;)V

    iput v4, p0, Lads_mobile_sdk/ce3;->a:I

    invoke-virtual {p1, v0, p0}, Lads_mobile_sdk/z2;->a(Lxj0;Lvx;)Ljava/lang/Object;

    if-ne v5, v3, :cond_3d

    :goto_58
    return-object v3

    nop

    :pswitch_data_5a
    .packed-switch 0x0
        :pswitch_34  #00000000
    .end packed-switch
.end method
