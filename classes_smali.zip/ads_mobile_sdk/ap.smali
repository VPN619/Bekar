.class public final Lads_mobile_sdk/ap;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public a:I

.field public final synthetic b:Lbk0;

.field public final synthetic t:I


# direct methods
.method public synthetic constructor <init>(Lbk0;Lvx;I)V
    .registers 4

    iput p3, p0, Lads_mobile_sdk/ap;->t:I

    iput-object p1, p0, Lads_mobile_sdk/ap;->b:Lbk0;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 4

    .prologue
    iget p2, p0, Lads_mobile_sdk/ap;->t:I

    iget-object p0, p0, Lads_mobile_sdk/ap;->b:Lbk0;

    packed-switch p2, :pswitch_data_1c

    new-instance p2, Lads_mobile_sdk/ap;

    const/4 v0, 0x2

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/ap;-><init>(Lbk0;Lvx;I)V

    return-object p2

    :pswitch_e  #0x1
    new-instance p2, Lads_mobile_sdk/ap;

    const/4 v0, 0x1

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/ap;-><init>(Lbk0;Lvx;I)V

    return-object p2

    :pswitch_15  #0x0
    new-instance p2, Lads_mobile_sdk/ap;

    const/4 v0, 0x0

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/ap;-><init>(Lbk0;Lvx;I)V

    return-object p2

    :pswitch_data_1c
    .packed-switch 0x0
        :pswitch_15  #00000000
        :pswitch_e  #00000001
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .prologue
    iget v0, p0, Lads_mobile_sdk/ap;->t:I

    sget-object v1, Lrg2;->a:Lrg2;

    iget-object p0, p0, Lads_mobile_sdk/ap;->b:Lbk0;

    packed-switch v0, :pswitch_data_36

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/ap;

    const/4 v0, 0x2

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/ap;-><init>(Lbk0;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/ap;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_18  #0x1
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/ap;

    const/4 v0, 0x1

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/ap;-><init>(Lbk0;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/ap;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_27  #0x0
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/ap;

    const/4 v0, 0x0

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/ap;-><init>(Lbk0;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/ap;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_data_36
    .packed-switch 0x0
        :pswitch_27  #00000000
        :pswitch_18  #00000001
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 8

    .prologue
    iget v0, p0, Lads_mobile_sdk/ap;->t:I

    iget-object v1, p0, Lads_mobile_sdk/ap;->b:Lbk0;

    const-string v2, "call to \'resume\' before \'invoke\' with coroutine"

    sget-object v3, Lwy;->a:Lwy;

    const/4 v4, 0x1

    const/4 v5, 0x0

    packed-switch v0, :pswitch_data_68

    iget v0, p0, Lads_mobile_sdk/ap;->a:I

    if-eqz v0, :cond_1c

    if-ne v0, v4, :cond_17

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_28

    :cond_17
    invoke-static {v2}, Lz6;->w(Ljava/lang/String;)V

    move-object p1, v5

    goto :goto_28

    :cond_1c
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iput v4, p0, Lads_mobile_sdk/ap;->a:I

    invoke-interface {v1, p0}, Lbk0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v3, :cond_28

    move-object p1, v3

    :cond_28
    :goto_28
    return-object p1

    :pswitch_29  #0x1
    iget v0, p0, Lads_mobile_sdk/ap;->a:I

    if-eqz v0, :cond_38

    if-ne v0, v4, :cond_33

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_4b

    :cond_33
    invoke-static {v2}, Lz6;->w(Ljava/lang/String;)V

    move-object p1, v5

    goto :goto_4b

    :cond_38
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    invoke-static {}, Lads_mobile_sdk/hh3;->b()Lads_mobile_sdk/gh3;

    move-result-object p1

    invoke-static {p1, v5}, Lads_mobile_sdk/hh3;->a(Lads_mobile_sdk/gh3;Lads_mobile_sdk/rg3;)Lads_mobile_sdk/rg3;

    iput v4, p0, Lads_mobile_sdk/ap;->a:I

    invoke-interface {v1, p0}, Lbk0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v3, :cond_4b

    move-object p1, v3

    :cond_4b
    :goto_4b
    return-object p1

    :pswitch_4c  #0x0
    iget v0, p0, Lads_mobile_sdk/ap;->a:I

    if-eqz v0, :cond_5b

    if-ne v0, v4, :cond_56

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_67

    :cond_56
    invoke-static {v2}, Lz6;->w(Ljava/lang/String;)V

    move-object p1, v5

    goto :goto_67

    :cond_5b
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iput v4, p0, Lads_mobile_sdk/ap;->a:I

    invoke-interface {v1, p0}, Lbk0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v3, :cond_67

    move-object p1, v3

    :cond_67
    :goto_67
    return-object p1

    :pswitch_data_68
    .packed-switch 0x0
        :pswitch_4c  #00000000
        :pswitch_29  #00000001
    .end packed-switch
.end method
