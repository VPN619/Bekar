.class public final Lads_mobile_sdk/dt;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lbw2;


# instance fields
.field public final a:Lads_mobile_sdk/k8;

.field public final b:Lads_mobile_sdk/z2;

.field public final c:Lads_mobile_sdk/dl;

.field public final d:Lads_mobile_sdk/gn0;

.field public final e:Lads_mobile_sdk/a2;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/k8;Lads_mobile_sdk/z2;Lads_mobile_sdk/dl;Lads_mobile_sdk/gn0;Lads_mobile_sdk/a2;)V
    .registers 6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/dt;->a:Lads_mobile_sdk/k8;

    iput-object p2, p0, Lads_mobile_sdk/dt;->b:Lads_mobile_sdk/z2;

    iput-object p3, p0, Lads_mobile_sdk/dt;->c:Lads_mobile_sdk/dl;

    iput-object p4, p0, Lads_mobile_sdk/dt;->d:Lads_mobile_sdk/gn0;

    iput-object p5, p0, Lads_mobile_sdk/dt;->e:Lads_mobile_sdk/a2;

    return-void
.end method


# virtual methods
.method public final a(Lads_mobile_sdk/cy0;Ljava/util/Map;Lvx;)Ljava/lang/Object;
    .registers 14

    .prologue
    instance-of v0, p3, Lads_mobile_sdk/ct;

    if-eqz v0, :cond_13

    move-object v0, p3

    check-cast v0, Lads_mobile_sdk/ct;

    iget v1, v0, Lads_mobile_sdk/ct;->f:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/ct;->f:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/ct;

    invoke-direct {v0, p0, p3}, Lads_mobile_sdk/ct;-><init>(Lads_mobile_sdk/dt;Lvx;)V

    :goto_18
    iget-object p3, v0, Lads_mobile_sdk/ct;->d:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/ct;->f:I

    const/4 v2, 0x0

    const/4 v3, 0x3

    sget-object v4, Lrg2;->a:Lrg2;

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    sget-object v8, Lwy;->a:Lwy;

    if-eqz v1, :cond_4f

    if-eq v1, v6, :cond_43

    if-eq v1, v5, :cond_3a

    if-ne v1, v3, :cond_34

    :try_start_2d
    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_30
    .catch Ljava/lang/Exception; {:try_start_2d .. :try_end_30} :catch_31

    return-object v4

    :catch_31
    move-exception p0

    goto/16 :goto_c6

    :cond_34
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v7

    :cond_3a
    iget-object p0, v0, Lads_mobile_sdk/ct;->b:Lads_mobile_sdk/cy0;

    iget-object p1, v0, Lads_mobile_sdk/ct;->a:Lads_mobile_sdk/dt;

    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V

    goto/16 :goto_ae

    :cond_43
    iget-object p0, v0, Lads_mobile_sdk/ct;->c:Ljava/lang/String;

    iget-object p1, v0, Lads_mobile_sdk/ct;->b:Lads_mobile_sdk/cy0;

    iget-object p2, v0, Lads_mobile_sdk/ct;->a:Lads_mobile_sdk/dt;

    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V

    move-object p3, p0

    move-object p0, p2

    goto :goto_8f

    :cond_4f
    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V

    const-string p3, "u"

    invoke-interface {p2, p3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/String;

    if-nez p3, :cond_6f

    new-instance p0, Ljava/lang/StringBuilder;

    const-string p1, "URL is missing from a click GMSG: "

    invoke-direct {p0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 p1, 0x6

    invoke-static {p1, p0, v7}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    return-object v4

    :cond_6f
    const-string v1, "sc"

    invoke-interface {p2, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/String;

    const-string v1, "1"

    invoke-static {p2, v1, v2}, Lk72;->f0(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result p2

    if-eqz p2, :cond_8f

    iput-object p0, v0, Lads_mobile_sdk/ct;->a:Lads_mobile_sdk/dt;

    iput-object p1, v0, Lads_mobile_sdk/ct;->b:Lads_mobile_sdk/cy0;

    iput-object p3, v0, Lads_mobile_sdk/ct;->c:Ljava/lang/String;

    iput v6, v0, Lads_mobile_sdk/ct;->f:I

    iget-object p2, p0, Lads_mobile_sdk/dt;->b:Lads_mobile_sdk/z2;

    invoke-virtual {p2, v0}, Lads_mobile_sdk/z2;->n(Lvx;)Ljava/lang/Object;

    if-ne v4, v8, :cond_8f

    goto :goto_c4

    :cond_8f
    :goto_8f
    iget-object p2, p0, Lads_mobile_sdk/dt;->d:Lads_mobile_sdk/gn0;

    invoke-static {p3}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p3

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v1, p0, Lads_mobile_sdk/dt;->e:Lads_mobile_sdk/a2;

    iget-object v1, v1, Lads_mobile_sdk/a2;->q:Landroid/os/Bundle;

    iput-object p0, v0, Lads_mobile_sdk/ct;->a:Lads_mobile_sdk/dt;

    iput-object p1, v0, Lads_mobile_sdk/ct;->b:Lads_mobile_sdk/cy0;

    iput-object v7, v0, Lads_mobile_sdk/ct;->c:Ljava/lang/String;

    iput v5, v0, Lads_mobile_sdk/ct;->f:I

    invoke-virtual {p2, p3, v6, v1, v0}, Lads_mobile_sdk/gn0;->a(Landroid/net/Uri;ILandroid/os/Bundle;Lwx;)Ljava/lang/Comparable;

    move-result-object p3

    if-ne p3, v8, :cond_ab

    goto :goto_c4

    :cond_ab
    move-object v9, p1

    move-object p1, p0

    move-object p0, v9

    :goto_ae
    check-cast p3, Landroid/net/Uri;

    :try_start_b0
    iget-object p2, p1, Lads_mobile_sdk/dt;->a:Lads_mobile_sdk/k8;

    invoke-virtual {p2, p3, p0}, Lads_mobile_sdk/k8;->a(Landroid/net/Uri;Landroid/view/View;)Landroid/net/Uri;

    move-result-object p0

    iget-object p1, p1, Lads_mobile_sdk/dt;->c:Lads_mobile_sdk/dl;

    iput-object v7, v0, Lads_mobile_sdk/ct;->a:Lads_mobile_sdk/dt;

    iput-object v7, v0, Lads_mobile_sdk/ct;->b:Lads_mobile_sdk/cy0;

    iput v3, v0, Lads_mobile_sdk/ct;->f:I

    invoke-virtual {p1, p0, v0}, Lads_mobile_sdk/dl;->c(Landroid/net/Uri;Lwx;)Ljava/lang/Object;

    move-result-object p0
    :try_end_c2
    .catch Ljava/lang/Exception; {:try_start_b0 .. :try_end_c2} :catch_31

    if-ne p0, v8, :cond_c5

    :goto_c4
    return-object v8

    :cond_c5
    return-object v4

    :goto_c6
    invoke-static {v6, v7, p0, v2}, Lads_mobile_sdk/xh3;->a(ZLjava/lang/String;Ljava/lang/Throwable;Z)V

    return-object v4
.end method

.method public final b()I
    .registers 1

    const/4 p0, 0x5

    return p0
.end method
