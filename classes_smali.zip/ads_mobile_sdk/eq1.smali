.class public final Lads_mobile_sdk/eq1;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public final synthetic a:Landroid/app/Activity;

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:Ljava/lang/String;

.field public final synthetic d:Ljava/lang/String;

.field public final synthetic e:Ljava/lang/String;

.field public final synthetic f:Ljava/lang/String;

.field public final synthetic g:Ljava/lang/String;

.field public final synthetic h:Ljava/lang/String;

.field public final synthetic i:Ljava/lang/Long;

.field public final synthetic j:Ljava/lang/Long;

.field public final synthetic k:Lads_mobile_sdk/fq1;

.field public final synthetic l:Lads_mobile_sdk/cy0;


# direct methods
.method public constructor <init>(Landroid/app/Activity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Lads_mobile_sdk/fq1;Lads_mobile_sdk/cy0;Lvx;)V
    .registers 14

    iput-object p1, p0, Lads_mobile_sdk/eq1;->a:Landroid/app/Activity;

    iput-object p2, p0, Lads_mobile_sdk/eq1;->b:Ljava/lang/String;

    iput-object p3, p0, Lads_mobile_sdk/eq1;->c:Ljava/lang/String;

    iput-object p4, p0, Lads_mobile_sdk/eq1;->d:Ljava/lang/String;

    iput-object p5, p0, Lads_mobile_sdk/eq1;->e:Ljava/lang/String;

    iput-object p6, p0, Lads_mobile_sdk/eq1;->f:Ljava/lang/String;

    iput-object p7, p0, Lads_mobile_sdk/eq1;->g:Ljava/lang/String;

    iput-object p8, p0, Lads_mobile_sdk/eq1;->h:Ljava/lang/String;

    iput-object p9, p0, Lads_mobile_sdk/eq1;->i:Ljava/lang/Long;

    iput-object p10, p0, Lads_mobile_sdk/eq1;->j:Ljava/lang/Long;

    iput-object p11, p0, Lads_mobile_sdk/eq1;->k:Lads_mobile_sdk/fq1;

    iput-object p12, p0, Lads_mobile_sdk/eq1;->l:Lads_mobile_sdk/cy0;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p13}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 17

    new-instance v0, Lads_mobile_sdk/eq1;

    iget-object v11, p0, Lads_mobile_sdk/eq1;->k:Lads_mobile_sdk/fq1;

    iget-object v12, p0, Lads_mobile_sdk/eq1;->l:Lads_mobile_sdk/cy0;

    iget-object v1, p0, Lads_mobile_sdk/eq1;->a:Landroid/app/Activity;

    iget-object v2, p0, Lads_mobile_sdk/eq1;->b:Ljava/lang/String;

    iget-object v3, p0, Lads_mobile_sdk/eq1;->c:Ljava/lang/String;

    iget-object v4, p0, Lads_mobile_sdk/eq1;->d:Ljava/lang/String;

    iget-object v5, p0, Lads_mobile_sdk/eq1;->e:Ljava/lang/String;

    iget-object v6, p0, Lads_mobile_sdk/eq1;->f:Ljava/lang/String;

    iget-object v7, p0, Lads_mobile_sdk/eq1;->g:Ljava/lang/String;

    iget-object v8, p0, Lads_mobile_sdk/eq1;->h:Ljava/lang/String;

    iget-object v9, p0, Lads_mobile_sdk/eq1;->i:Ljava/lang/Long;

    iget-object v10, p0, Lads_mobile_sdk/eq1;->j:Ljava/lang/Long;

    move-object v13, p1

    invoke-direct/range {v0 .. v13}, Lads_mobile_sdk/eq1;-><init>(Landroid/app/Activity;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Lads_mobile_sdk/fq1;Lads_mobile_sdk/cy0;Lvx;)V

    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    invoke-virtual {p0, p2, p1}, Lads_mobile_sdk/eq1;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/eq1;

    sget-object p1, Lrg2;->a:Lrg2;

    invoke-virtual {p0, p1}, Lads_mobile_sdk/eq1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 10

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    new-instance p1, Landroid/app/AlertDialog$Builder;

    iget-object v0, p0, Lads_mobile_sdk/eq1;->a:Landroid/app/Activity;

    const v1, 0x1030226

    invoke-direct {p1, v0, v1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;I)V

    iget-object v0, p0, Lads_mobile_sdk/eq1;->b:Ljava/lang/String;

    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    iget-object v0, p0, Lads_mobile_sdk/eq1;->c:Ljava/lang/String;

    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    new-instance v1, Lmx2;

    iget-object v2, p0, Lads_mobile_sdk/eq1;->f:Ljava/lang/String;

    iget-object v3, p0, Lads_mobile_sdk/eq1;->g:Ljava/lang/String;

    iget-object v4, p0, Lads_mobile_sdk/eq1;->h:Ljava/lang/String;

    iget-object v5, p0, Lads_mobile_sdk/eq1;->i:Ljava/lang/Long;

    iget-object v6, p0, Lads_mobile_sdk/eq1;->j:Ljava/lang/Long;

    iget-object v7, p0, Lads_mobile_sdk/eq1;->k:Lads_mobile_sdk/fq1;

    invoke-direct/range {v1 .. v7}, Lmx2;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Long;Ljava/lang/Long;Lads_mobile_sdk/fq1;)V

    iget-object v0, p0, Lads_mobile_sdk/eq1;->d:Ljava/lang/String;

    invoke-virtual {p1, v0, v1}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    new-instance v0, Lmv2;

    const/4 v1, 0x1

    iget-object v2, p0, Lads_mobile_sdk/eq1;->l:Lads_mobile_sdk/cy0;

    invoke-direct {v0, v1, v7, v2}, Lmv2;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    iget-object p0, p0, Lads_mobile_sdk/eq1;->e:Ljava/lang/String;

    invoke-virtual {p1, p0, v0}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object p0

    invoke-virtual {p0}, Landroid/app/Dialog;->show()V

    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method
