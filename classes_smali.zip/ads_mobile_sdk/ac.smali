.class public final Lads_mobile_sdk/ac;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lo23;


# instance fields
.field public final a:Lads_mobile_sdk/sb;

.field public final b:Ljava/util/List;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/qr0;Lads_mobile_sdk/sb;)V
    .registers 20

    move-object/from16 v0, p0

    invoke-virtual/range {p1 .. p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p2 .. p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    move-object/from16 v1, p2

    iput-object v1, v0, Lads_mobile_sdk/ac;->a:Lads_mobile_sdk/sb;

    const-string v15, "com.google.ads.mediation.fyber.FyberMediationAdapter"

    const-string v16, "com.google.ads.mediation.verizon.VerizonMediationAdapter"

    const-string v1, "com.google.ads.mediation.inmobi.InMobiMediationAdapter"

    const-string v2, "com.google.ads.mediation.imobile.IMobileMediationAdapter"

    const-string v3, "com.google.ads.mediation.nend.NendMediationAdapter"

    const-string v4, "com.google.ads.mediation.adcolony.AdColonyMediationAdapter"

    const-string v5, "com.google.ads.mediation.facebook.FacebookMediationAdapter"

    const-string v6, "com.google.ads.mediation.mopub.MoPubMediationAdapter"

    const-string v7, "com.google.ads.mediation.applovin.AppLovinMediationAdapter"

    const-string v8, "com.google.ads.mediation.tapjoy.TapjoyMediationAdapter"

    const-string v9, "com.google.ads.mediation.vungle.VungleMediationAdapter"

    const-string v10, "com.google.ads.mediation.unity.UnityMediationAdapter"

    const-string v11, "com.google.ads.mediation.chartboost.ChartboostMediationAdapter"

    const-string v12, "com.google.ads.mediation.mytarget.MyTargetMediationAdapter"

    const-string v13, "com.google.ads.mediation.maio.MaioMediationAdapter"

    const-string v14, "com.google.ads.mediation.ironsource.IronSourceMediationAdapter"

    filled-new-array/range {v1 .. v16}, [Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lcs;->U([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v1

    sget-object v2, Lads_mobile_sdk/fo;->a$22:Lads_mobile_sdk/fo;

    const-string v3, "gads:logged_adapter_version_classes"

    move-object/from16 v4, p1

    invoke-virtual {v4, v3, v1, v2}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    iput-object v1, v0, Lads_mobile_sdk/ac;->b:Ljava/util/List;

    return-void
.end method


# virtual methods
.method public final a()Lads_mobile_sdk/lw0;
    .registers 1

    sget-object p0, Lads_mobile_sdk/lw0;->c:Lads_mobile_sdk/lw0;

    return-object p0
.end method

.method public final d(Lvx;)Ljava/lang/Object;
    .registers 9

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/zb;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/zb;

    iget v1, v0, Lads_mobile_sdk/zb;->e:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/zb;->e:I

    goto :goto_1a

    :cond_13
    new-instance v0, Lads_mobile_sdk/zb;

    check-cast p1, Lwx;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/zb;-><init>(Lads_mobile_sdk/ac;Lwx;)V

    :goto_1a
    iget-object p1, v0, Lads_mobile_sdk/zb;->c:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/zb;->e:I

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_36

    if-ne v1, v3, :cond_30

    iget-object p0, v0, Lads_mobile_sdk/zb;->b:Ljava/util/LinkedHashMap;

    iget-object v0, v0, Lads_mobile_sdk/zb;->a:Lads_mobile_sdk/ac;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    move-object v6, p1

    move-object p1, p0

    move-object p0, v0

    move-object v0, v6

    goto :goto_67

    :cond_30
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v2

    :cond_36
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/ac;->b:Ljava/util/List;

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_4e

    new-instance p0, Lads_mobile_sdk/hv0;

    new-instance p1, Lads_mobile_sdk/yb;

    sget-object v0, Lca0;->a:Lca0;

    invoke-direct {p1, v0}, Lads_mobile_sdk/yb;-><init>(Ljava/util/Map;)V

    invoke-direct {p0, p1}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    return-object p0

    :cond_4e
    new-instance p1, Ljava/util/LinkedHashMap;

    invoke-direct {p1}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object p0, v0, Lads_mobile_sdk/zb;->a:Lads_mobile_sdk/ac;

    iput-object p1, v0, Lads_mobile_sdk/zb;->b:Ljava/util/LinkedHashMap;

    iput v3, v0, Lads_mobile_sdk/zb;->e:I

    iget-object v1, p0, Lads_mobile_sdk/ac;->a:Lads_mobile_sdk/sb;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v1, v0}, Lads_mobile_sdk/sb;->a(Lads_mobile_sdk/sb;Lwx;)Ljava/lang/Object;

    move-result-object v0

    sget-object v1, Lwy;->a:Lwy;

    if-ne v0, v1, :cond_67

    return-object v1

    :cond_67
    :goto_67
    check-cast v0, Ljava/util/Map;

    iget-object p0, p0, Lads_mobile_sdk/ac;->b:Ljava/util/List;

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_6f
    :goto_6f
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_a1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lads_mobile_sdk/ma;

    if-eqz v3, :cond_89

    iget-object v3, v3, Lads_mobile_sdk/ma;->a:Lads_mobile_sdk/va;

    iget-object v3, v3, Lads_mobile_sdk/va;->a:La5;

    if-nez v3, :cond_8b

    :cond_89
    sget-object v3, La5;->a:La5;

    :cond_8b
    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lads_mobile_sdk/ma;

    if-eqz v4, :cond_96

    iget-object v4, v4, Lads_mobile_sdk/ma;->b:Lb5;

    goto :goto_97

    :cond_96
    move-object v4, v2

    :goto_97
    sget-object v5, La5;->c:La5;

    if-ne v3, v5, :cond_6f

    if-eqz v4, :cond_6f

    invoke-interface {p1, v1, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_6f

    :cond_a1
    new-instance p0, Lads_mobile_sdk/hv0;

    new-instance v0, Lads_mobile_sdk/yb;

    invoke-direct {v0, p1}, Lads_mobile_sdk/yb;-><init>(Ljava/util/Map;)V

    invoke-direct {p0, v0}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    return-object p0
.end method
