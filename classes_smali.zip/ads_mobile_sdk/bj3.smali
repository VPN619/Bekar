.class public final Lads_mobile_sdk/bj3;
.super Lads_mobile_sdk/sr;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final l:Lads_mobile_sdk/vz;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/vz;Lads_mobile_sdk/qr0;Lads_mobile_sdk/g0;Lads_mobile_sdk/ux2;Lx43;Lvy;)V
    .registers 13

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-object v0, p0

    move-object v4, p2

    move-object v5, p3

    move-object v3, p4

    move-object v1, p5

    move-object v2, p6

    invoke-direct/range {v0 .. v5}, Lads_mobile_sdk/sr;-><init>(Lx43;Lvy;Lads_mobile_sdk/ux2;Lads_mobile_sdk/qr0;Lads_mobile_sdk/g0;)V

    iput-object p1, v0, Lads_mobile_sdk/bj3;->l:Lads_mobile_sdk/vz;

    return-void
.end method


# virtual methods
.method public final a()Lads_mobile_sdk/lw0;
    .registers 1

    sget-object p0, Lads_mobile_sdk/lw0;->T:Lads_mobile_sdk/lw0;

    return-object p0
.end method

.method public final d(Lvx;)Ljava/lang/Object;
    .registers 9

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/zi3;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/zi3;

    iget v1, v0, Lads_mobile_sdk/zi3;->c:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/zi3;->c:I

    goto :goto_1a

    :cond_13
    new-instance v0, Lads_mobile_sdk/zi3;

    check-cast p1, Lwx;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/zi3;-><init>(Lads_mobile_sdk/bj3;Lwx;)V

    :goto_1a
    iget-object p1, v0, Lads_mobile_sdk/zi3;->a:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/zi3;->c:I

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-eqz v1, :cond_35

    if-eq v1, v4, :cond_31

    if-ne v1, v3, :cond_2b

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_80

    :cond_2b
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v2

    :cond_31
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_61

    :cond_35
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/sr;->f:Lads_mobile_sdk/qr0;

    iget-object p1, p1, Lads_mobile_sdk/qr0;->r:Lz43;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sget-object v5, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    const-string v6, "gads:trustless_token_caching_in_signal_source_enabled"

    invoke-virtual {p1, v6, v1, v5}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    sget-object v1, Lwy;->a:Lwy;

    iget-object p0, p0, Lads_mobile_sdk/bj3;->l:Lads_mobile_sdk/vz;

    if-eqz p1, :cond_74

    iput v4, v0, Lads_mobile_sdk/zi3;->c:I

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p0, v0}, Lads_mobile_sdk/vz;->g(Lads_mobile_sdk/vz;Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v1, :cond_61

    goto :goto_7f

    :cond_61
    :goto_61
    check-cast p1, Lb13;

    if-eqz p1, :cond_92

    instance-of p0, p1, Lads_mobile_sdk/av0;

    if-eqz p0, :cond_6c

    check-cast p1, Lads_mobile_sdk/av0;

    return-object p1

    :cond_6c
    check-cast p1, Lads_mobile_sdk/hv0;

    iget-object p0, p1, Lads_mobile_sdk/hv0;->b:Ljava/lang/Object;

    move-object v2, p0

    check-cast v2, Ljava/lang/String;

    goto :goto_92

    :cond_74
    iput v3, v0, Lads_mobile_sdk/zi3;->c:I

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p0, v0}, Lads_mobile_sdk/vz;->h(Lads_mobile_sdk/vz;Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v1, :cond_80

    :goto_7f
    return-object v1

    :cond_80
    :goto_80
    check-cast p1, Lb13;

    if-eqz p1, :cond_92

    instance-of p0, p1, Lads_mobile_sdk/av0;

    if-eqz p0, :cond_8b

    check-cast p1, Lads_mobile_sdk/av0;

    return-object p1

    :cond_8b
    check-cast p1, Lads_mobile_sdk/hv0;

    iget-object p0, p1, Lads_mobile_sdk/hv0;->b:Ljava/lang/Object;

    move-object v2, p0

    check-cast v2, Ljava/lang/String;

    :cond_92
    :goto_92
    new-instance p0, Lads_mobile_sdk/hv0;

    new-instance p1, Lads_mobile_sdk/yi3;

    invoke-direct {p1, v2}, Lads_mobile_sdk/yi3;-><init>(Ljava/lang/String;)V

    invoke-direct {p0, p1}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    return-object p0
.end method

.method public final k(Lvx;)Ljava/lang/Object;
    .registers 10

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/aj3;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/aj3;

    iget v1, v0, Lads_mobile_sdk/aj3;->d:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/aj3;->d:I

    goto :goto_1a

    :cond_13
    new-instance v0, Lads_mobile_sdk/aj3;

    check-cast p1, Lwx;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/aj3;-><init>(Lads_mobile_sdk/bj3;Lwx;)V

    :goto_1a
    iget-object p1, v0, Lads_mobile_sdk/aj3;->b:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/aj3;->d:I

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    sget-object v5, Lwy;->a:Lwy;

    if-eqz v1, :cond_39

    if-eq v1, v4, :cond_33

    if-ne v1, v3, :cond_2d

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    return-object p1

    :cond_2d
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v2

    :cond_33
    iget-object p0, v0, Lads_mobile_sdk/aj3;->a:Lads_mobile_sdk/bj3;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_65

    :cond_39
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/sr;->f:Lads_mobile_sdk/qr0;

    iget-object p1, p1, Lads_mobile_sdk/qr0;->r:Lz43;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sget-object v6, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    const-string v7, "gads:trustless_token_caching_in_signal_source_enabled"

    invoke-virtual {p1, v7, v1, v6}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_7d

    iput-object p0, v0, Lads_mobile_sdk/aj3;->a:Lads_mobile_sdk/bj3;

    iput v4, v0, Lads_mobile_sdk/aj3;->d:I

    iget-object p1, p0, Lads_mobile_sdk/bj3;->l:Lads_mobile_sdk/vz;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1, v0}, Lads_mobile_sdk/vz;->j(Lads_mobile_sdk/vz;Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v5, :cond_65

    goto :goto_7b

    :cond_65
    :goto_65
    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-nez p1, :cond_6e

    goto :goto_7d

    :cond_6e
    iput-object v2, v0, Lads_mobile_sdk/aj3;->a:Lads_mobile_sdk/bj3;

    iput v3, v0, Lads_mobile_sdk/aj3;->d:I

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p0, v0}, Lads_mobile_sdk/sr;->b(Lads_mobile_sdk/sr;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_7c

    :goto_7b
    return-object v5

    :cond_7c
    return-object p0

    :cond_7d
    :goto_7d
    return-object v2
.end method
