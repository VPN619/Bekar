.class public final Lads_mobile_sdk/co2;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public a:I

.field public final synthetic b:Lads_mobile_sdk/uo2;

.field public final synthetic t:I


# direct methods
.method public synthetic constructor <init>(Lads_mobile_sdk/uo2;Lvx;I)V
    .registers 4

    iput p3, p0, Lads_mobile_sdk/co2;->t:I

    iput-object p1, p0, Lads_mobile_sdk/co2;->b:Lads_mobile_sdk/uo2;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 4

    .prologue
    iget p2, p0, Lads_mobile_sdk/co2;->t:I

    iget-object p0, p0, Lads_mobile_sdk/co2;->b:Lads_mobile_sdk/uo2;

    packed-switch p2, :pswitch_data_16

    new-instance p2, Lads_mobile_sdk/co2;

    const/4 v0, 0x1

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/co2;-><init>(Lads_mobile_sdk/uo2;Lvx;I)V

    return-object p2

    :pswitch_e  #0x0
    new-instance p2, Lads_mobile_sdk/co2;

    const/4 v0, 0x0

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/co2;-><init>(Lads_mobile_sdk/uo2;Lvx;I)V

    return-object p2

    nop

    :pswitch_data_16
    .packed-switch 0x0
        :pswitch_e  #00000000
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .prologue
    iget v0, p0, Lads_mobile_sdk/co2;->t:I

    sget-object v1, Lrg2;->a:Lrg2;

    iget-object p0, p0, Lads_mobile_sdk/co2;->b:Lads_mobile_sdk/uo2;

    packed-switch v0, :pswitch_data_28

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/co2;

    const/4 v0, 0x1

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/co2;-><init>(Lads_mobile_sdk/uo2;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/co2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_18  #0x0
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/co2;

    const/4 v0, 0x0

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/co2;-><init>(Lads_mobile_sdk/uo2;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/co2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_28
    .packed-switch 0x0
        :pswitch_18  #00000000
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 9

    .prologue
    iget v0, p0, Lads_mobile_sdk/co2;->t:I

    sget-object v1, Lrg2;->a:Lrg2;

    iget-object v2, p0, Lads_mobile_sdk/co2;->b:Lads_mobile_sdk/uo2;

    const-string v3, "call to \'resume\' before \'invoke\' with coroutine"

    sget-object v4, Lwy;->a:Lwy;

    const/4 v5, 0x1

    const/4 v6, 0x0

    packed-switch v0, :pswitch_data_60

    iget v0, p0, Lads_mobile_sdk/co2;->a:I

    if-eqz v0, :cond_1e

    if-ne v0, v5, :cond_19

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_32

    :cond_19
    invoke-static {v3}, Lz6;->w(Ljava/lang/String;)V

    move-object v1, v6

    goto :goto_32

    :cond_1e
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, v2, Lads_mobile_sdk/uo2;->n:Lly;

    new-instance v0, Lads_mobile_sdk/eo2;

    const/4 v3, 0x0

    invoke-direct {v0, v2, v6, v3}, Lads_mobile_sdk/eo2;-><init>(Lads_mobile_sdk/uo2;Lvx;I)V

    iput v5, p0, Lads_mobile_sdk/co2;->a:I

    invoke-static {p1, v0, p0}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v4, :cond_32

    move-object v1, v4

    :cond_32
    :goto_32
    return-object v1

    :pswitch_33  #0x0
    iget v0, p0, Lads_mobile_sdk/co2;->a:I

    if-eqz v0, :cond_42

    if-ne v0, v5, :cond_3d

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_51

    :cond_3d
    invoke-static {v3}, Lz6;->w(Ljava/lang/String;)V

    move-object v1, v6

    goto :goto_5e

    :cond_42
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, v2, Lads_mobile_sdk/uo2;->q:Lads_mobile_sdk/vs2;

    iput v5, p0, Lads_mobile_sdk/co2;->a:I

    invoke-virtual {p1, p0}, Lads_mobile_sdk/vs2;->c(Lvx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v4, :cond_51

    move-object v1, v4

    goto :goto_5e

    :cond_51
    :goto_51
    iget-object p0, v2, Lads_mobile_sdk/uo2;->t:Lads_mobile_sdk/e7;

    const-string p1, "The backing field has not yet been initialized."

    invoke-virtual {p0, p1}, Lads_mobile_sdk/e7;->a(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/td1;

    invoke-virtual {p0}, Lads_mobile_sdk/cc1;->destroy()V

    :goto_5e
    return-object v1

    nop

    :pswitch_data_60
    .packed-switch 0x0
        :pswitch_33  #00000000
    .end packed-switch
.end method
