.class public final Lads_mobile_sdk/ah0;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lnt2;


# instance fields
.field public a:Ltv2;


# direct methods
.method public static a(Ltv2;Ltv2;)V
    .registers 3

    .prologue
    check-cast p0, Lads_mobile_sdk/ah0;

    iget-object v0, p0, Lads_mobile_sdk/ah0;->a:Ltv2;

    if-nez v0, :cond_9

    iput-object p1, p0, Lads_mobile_sdk/ah0;->a:Ltv2;

    return-void

    :cond_9
    invoke-static {}, Ldm2;->i()V

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 1

    .prologue
    iget-object p0, p0, Lads_mobile_sdk/ah0;->a:Ltv2;

    if-eqz p0, :cond_9

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :cond_9
    invoke-static {}, Ldm2;->i()V

    const/4 p0, 0x0

    return-object p0
.end method
