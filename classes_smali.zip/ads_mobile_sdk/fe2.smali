.class public final Lads_mobile_sdk/fe2;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Lads_mobile_sdk/av2;

.field public final c:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Lads_mobile_sdk/av2;Ljava/lang/String;)V
    .registers 4

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/fe2;->a:Ljava/lang/String;

    iput-object p2, p0, Lads_mobile_sdk/fe2;->b:Lads_mobile_sdk/av2;

    iput-object p3, p0, Lads_mobile_sdk/fe2;->c:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    .prologue
    if-ne p0, p1, :cond_3

    goto :goto_28

    :cond_3
    instance-of v0, p1, Lads_mobile_sdk/fe2;

    if-nez v0, :cond_8

    goto :goto_26

    :cond_8
    check-cast p1, Lads_mobile_sdk/fe2;

    iget-object v0, p0, Lads_mobile_sdk/fe2;->a:Ljava/lang/String;

    iget-object v1, p1, Lads_mobile_sdk/fe2;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_15

    goto :goto_26

    :cond_15
    iget-object v0, p0, Lads_mobile_sdk/fe2;->b:Lads_mobile_sdk/av2;

    iget-object v1, p1, Lads_mobile_sdk/fe2;->b:Lads_mobile_sdk/av2;

    if-eq v0, v1, :cond_1c

    goto :goto_26

    :cond_1c
    iget-object p0, p0, Lads_mobile_sdk/fe2;->c:Ljava/lang/String;

    iget-object p1, p1, Lads_mobile_sdk/fe2;->c:Ljava/lang/String;

    invoke-static {p0, p1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_28

    :goto_26
    const/4 p0, 0x0

    return p0

    :cond_28
    :goto_28
    const/4 p0, 0x1

    return p0
.end method

.method public final hashCode()I
    .registers 3

    iget-object v0, p0, Lads_mobile_sdk/fe2;->a:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, Lads_mobile_sdk/fe2;->b:Lads_mobile_sdk/av2;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    mul-int/lit8 v1, v1, 0x1f

    iget-object p0, p0, Lads_mobile_sdk/fe2;->c:Ljava/lang/String;

    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result p0

    add-int/2addr p0, v1

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "PersistentCacheToken(filename="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lads_mobile_sdk/fe2;->a:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", adFormat="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lads_mobile_sdk/fe2;->b:Lads_mobile_sdk/av2;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", adRequest="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ")"

    iget-object p0, p0, Lads_mobile_sdk/fe2;->c:Ljava/lang/String;

    invoke-static {v0, p0, v1}, Ly41;->s(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
