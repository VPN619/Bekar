.class public final Lads_mobile_sdk/dd1;
.super Lh0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final e:I

.field public final f:Lads_mobile_sdk/o32;

.field public final g:Lads_mobile_sdk/qr0;


# direct methods
.method public constructor <init>(Ljava/lang/String;ILads_mobile_sdk/kh3;Lx63;Lads_mobile_sdk/o32;Lads_mobile_sdk/qr0;)V
    .registers 7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0, p1, p2, p3, p4}, Lh0;-><init>(Ljava/lang/String;ILads_mobile_sdk/kh3;Lx63;)V

    iput p2, p0, Lads_mobile_sdk/dd1;->e:I

    iput-object p5, p0, Lads_mobile_sdk/dd1;->f:Lads_mobile_sdk/o32;

    iput-object p6, p0, Lads_mobile_sdk/dd1;->g:Lads_mobile_sdk/qr0;

    return-void
.end method

.method public static a(Lads_mobile_sdk/dd1;Lwx;)Ljava/lang/Object;
    .registers 11

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/bd1;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/bd1;

    iget v1, v0, Lads_mobile_sdk/bd1;->d:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/bd1;->d:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/bd1;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/bd1;-><init>(Lads_mobile_sdk/dd1;Lwx;)V

    :goto_18
    iget-object p1, v0, Lads_mobile_sdk/bd1;->b:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/bd1;->d:I

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    sget-object v5, Lwy;->a:Lwy;

    if-eqz v1, :cond_39

    if-eq v1, v4, :cond_33

    if-ne v1, v3, :cond_2d

    :try_start_27
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_2a
    .catch Lza2; {:try_start_27 .. :try_end_2a} :catch_2b

    goto :goto_94

    :catch_2b
    move-exception p0

    goto :goto_97

    :cond_2d
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v2

    :cond_33
    iget-object p0, v0, Lads_mobile_sdk/bd1;->a:Lads_mobile_sdk/dd1;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_63

    :cond_39
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iput-object p0, v0, Lads_mobile_sdk/bd1;->a:Lads_mobile_sdk/dd1;

    iput v4, v0, Lads_mobile_sdk/bd1;->d:I

    iget-object p1, p0, Lh0;->d:Ljava/lang/Object;

    check-cast p1, Lads_mobile_sdk/kh3;

    invoke-static {}, Lads_mobile_sdk/hh3;->a()Lads_mobile_sdk/rg3;

    move-result-object v1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, v1, Lads_mobile_sdk/rg3;->a:Lads_mobile_sdk/kh3;

    iget-object p1, p1, Lads_mobile_sdk/kh3;->b:Lads_mobile_sdk/ih1;

    iget-object v1, p0, Lh0;->b:Ljava/lang/String;

    iput-object v1, p1, Lads_mobile_sdk/ih1;->a:Ljava/lang/String;

    iget v1, p0, Lh0;->c:I

    iput v1, p1, Lads_mobile_sdk/ih1;->c:I

    iget-object p1, p0, Lh0;->k:Ljava/lang/Object;

    check-cast p1, Lx63;

    invoke-virtual {p1, v0}, Lx63;->b(Lvx;)Ljava/lang/Object;

    sget-object p1, Lrg2;->a:Lrg2;

    if-ne p1, v5, :cond_63

    goto :goto_93

    :cond_63
    :goto_63
    :try_start_63
    iget-object p1, p0, Lads_mobile_sdk/dd1;->g:Lads_mobile_sdk/qr0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v1, "gads:load_timeout:milliseconds"

    sget-object v6, Lv60;->b:Lp80;

    sget-object v6, Ly60;->f:Ly60;

    const/4 v7, 0x5

    invoke-static {v7, v6}, Li10;->G0(ILy60;)J

    move-result-wide v6

    new-instance v8, Lv60;

    invoke-direct {v8, v6, v7}, Lv60;-><init>(J)V

    sget-object v6, Lads_mobile_sdk/fo;->a$18:Lads_mobile_sdk/fo;

    invoke-virtual {p1, v1, v8, v6}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lv60;

    iget-wide v6, p1, Lv60;->a:J

    new-instance p1, Lqd;

    const/16 v1, 0xd

    invoke-direct {p1, p0, v2, v1}, Lqd;-><init>(Ljava/lang/Object;Lvx;I)V

    iput-object v2, v0, Lads_mobile_sdk/bd1;->a:Lads_mobile_sdk/dd1;

    iput v3, v0, Lads_mobile_sdk/bd1;->d:I

    invoke-static {v6, v7, p1, v0}, Lla1;->W(JLpk0;Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v5, :cond_94

    :goto_93
    return-object v5

    :cond_94
    :goto_94
    check-cast p1, Lb13;
    :try_end_96
    .catch Lza2; {:try_start_63 .. :try_end_96} :catch_2b

    return-object p1

    :goto_97
    new-instance p1, Lads_mobile_sdk/iv0;

    invoke-direct {p1, p0, v4}, Lads_mobile_sdk/iv0;-><init>(Lza2;I)V

    return-object p1
.end method
