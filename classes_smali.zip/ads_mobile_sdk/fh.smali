.class public final Lads_mobile_sdk/fh;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lnt2;


# instance fields
.field public final a:Ltv2;

.field public final b:Lnt2;

.field public final synthetic c:I


# direct methods
.method public synthetic constructor <init>(Lnt2;Ltv2;I)V
    .registers 4

    iput p3, p0, Lads_mobile_sdk/fh;->c:I

    iput-object p1, p0, Lads_mobile_sdk/fh;->b:Lnt2;

    iput-object p2, p0, Lads_mobile_sdk/fh;->a:Ltv2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Ltv2;Lnt2;I)V
    .registers 4

    iput p3, p0, Lads_mobile_sdk/fh;->c:I

    iput-object p1, p0, Lads_mobile_sdk/fh;->a:Ltv2;

    iput-object p2, p0, Lads_mobile_sdk/fh;->b:Lnt2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 9

    .prologue
    iget v0, p0, Lads_mobile_sdk/fh;->c:I

    iget-object v1, p0, Lads_mobile_sdk/fh;->b:Lnt2;

    iget-object p0, p0, Lads_mobile_sdk/fh;->a:Ltv2;

    packed-switch v0, :pswitch_data_1ae

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/qr0;

    check-cast v1, Lads_mobile_sdk/hf;

    invoke-virtual {v1}, Lads_mobile_sdk/hf;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Lads_mobile_sdk/e7;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lads_mobile_sdk/w32;

    sget-object v0, Lads_mobile_sdk/lw0;->D:Lads_mobile_sdk/lw0;

    invoke-static {p0, v0}, Lt12;->c(Lads_mobile_sdk/qr0;Lads_mobile_sdk/lw0;)J

    move-result-wide v5

    const/4 v7, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct/range {v1 .. v7}, Lads_mobile_sdk/w32;-><init>(Lo23;IIJLrh1;)V

    return-object v1

    :pswitch_2a  #0xc
    check-cast v1, Lads_mobile_sdk/da;

    invoke-virtual {v1}, Lads_mobile_sdk/da;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Lads_mobile_sdk/e7;

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/qr0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lads_mobile_sdk/w32;

    sget-object v0, Lads_mobile_sdk/lw0;->C:Lads_mobile_sdk/lw0;

    invoke-static {p0, v0}, Lt12;->c(Lads_mobile_sdk/qr0;Lads_mobile_sdk/lw0;)J

    move-result-wide v5

    const/4 v7, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct/range {v1 .. v7}, Lads_mobile_sdk/w32;-><init>(Lo23;IIJLrh1;)V

    return-object v1

    :pswitch_4b  #0xb
    check-cast p0, Lads_mobile_sdk/ah0;

    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/vz;

    check-cast v1, Lads_mobile_sdk/ah0;

    invoke-virtual {v1}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/ah3;

    new-instance v1, Lads_mobile_sdk/ql3;

    invoke-direct {v1, p0, v0}, Lads_mobile_sdk/ql3;-><init>(Lads_mobile_sdk/vz;Lads_mobile_sdk/ah3;)V

    return-object v1

    :pswitch_61  #0xa
    check-cast v1, Lads_mobile_sdk/e6;

    invoke-virtual {v1}, Lads_mobile_sdk/e6;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Lads_mobile_sdk/pb1;

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/qr0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lads_mobile_sdk/w32;

    sget-object v0, Lads_mobile_sdk/lw0;->x:Lads_mobile_sdk/lw0;

    invoke-static {p0, v0}, Lt12;->c(Lads_mobile_sdk/qr0;Lads_mobile_sdk/lw0;)J

    move-result-wide v5

    const/4 v7, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct/range {v1 .. v7}, Lads_mobile_sdk/w32;-><init>(Lo23;IIJLrh1;)V

    return-object v1

    :pswitch_82  #0x9
    check-cast v1, Lads_mobile_sdk/am;

    invoke-virtual {v1}, Lads_mobile_sdk/am;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Lads_mobile_sdk/e7;

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/qr0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lads_mobile_sdk/w32;

    sget-object v0, Lads_mobile_sdk/lw0;->w:Lads_mobile_sdk/lw0;

    invoke-static {p0, v0}, Lt12;->c(Lads_mobile_sdk/qr0;Lads_mobile_sdk/lw0;)J

    move-result-wide v5

    const/4 v7, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct/range {v1 .. v7}, Lads_mobile_sdk/w32;-><init>(Lo23;IIJLrh1;)V

    return-object v1

    :pswitch_a3  #0x8
    check-cast v1, Lads_mobile_sdk/hl;

    invoke-virtual {v1}, Lads_mobile_sdk/hl;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Lz4;

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/qr0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lads_mobile_sdk/w32;

    sget-object v0, Lads_mobile_sdk/lw0;->E:Lads_mobile_sdk/lw0;

    invoke-static {p0, v0}, Lt12;->c(Lads_mobile_sdk/qr0;Lads_mobile_sdk/lw0;)J

    move-result-wide v5

    const/4 v7, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-direct/range {v1 .. v7}, Lads_mobile_sdk/w32;-><init>(Lo23;IIJLrh1;)V

    return-object v1

    :pswitch_c4  #0x7
    check-cast v1, Lads_mobile_sdk/bt;

    invoke-virtual {v1}, Lads_mobile_sdk/bt;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Lads_mobile_sdk/at;

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/qr0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lads_mobile_sdk/w32;

    sget-object v0, Lads_mobile_sdk/lw0;->s:Lads_mobile_sdk/lw0;

    invoke-static {p0, v0}, Lt12;->c(Lads_mobile_sdk/qr0;Lads_mobile_sdk/lw0;)J

    move-result-wide v5

    const/4 v7, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct/range {v1 .. v7}, Lads_mobile_sdk/w32;-><init>(Lo23;IIJLrh1;)V

    return-object v1

    :pswitch_e5  #0x6
    check-cast p0, Lads_mobile_sdk/ah0;

    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lvy;

    invoke-interface {v1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map;

    new-instance v1, Lyx2;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {v1, p0, v0}, Lpb;-><init>(Lvy;Ljava/util/Map;)V

    return-object v1

    :pswitch_ff  #0x5
    check-cast v1, Lads_mobile_sdk/b7;

    invoke-virtual {v1}, Lads_mobile_sdk/b7;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Lads_mobile_sdk/w8;

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/qr0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lads_mobile_sdk/w32;

    sget-object v0, Lads_mobile_sdk/lw0;->k:Lads_mobile_sdk/lw0;

    invoke-static {p0, v0}, Lt12;->c(Lads_mobile_sdk/qr0;Lads_mobile_sdk/lw0;)J

    move-result-wide v5

    const/4 v7, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-direct/range {v1 .. v7}, Lads_mobile_sdk/w32;-><init>(Lo23;IIJLrh1;)V

    return-object v1

    :pswitch_120  #0x4
    check-cast v1, Lads_mobile_sdk/o8;

    invoke-virtual {v1}, Lads_mobile_sdk/o8;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Lads_mobile_sdk/e7;

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/qr0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lads_mobile_sdk/w32;

    sget-object v0, Lads_mobile_sdk/lw0;->j:Lads_mobile_sdk/lw0;

    invoke-static {p0, v0}, Lt12;->c(Lads_mobile_sdk/qr0;Lads_mobile_sdk/lw0;)J

    move-result-wide v5

    const/4 v7, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-direct/range {v1 .. v7}, Lads_mobile_sdk/w32;-><init>(Lo23;IIJLrh1;)V

    return-object v1

    :pswitch_141  #0x3
    check-cast v1, Lads_mobile_sdk/h0;

    invoke-virtual {v1}, Lads_mobile_sdk/h0;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Lads_mobile_sdk/az2;

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/qr0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lads_mobile_sdk/w32;

    sget-object v0, Lads_mobile_sdk/lw0;->M:Lads_mobile_sdk/lw0;

    invoke-static {p0, v0}, Lt12;->c(Lads_mobile_sdk/qr0;Lads_mobile_sdk/lw0;)J

    move-result-wide v5

    const/4 v7, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct/range {v1 .. v7}, Lads_mobile_sdk/w32;-><init>(Lo23;IIJLrh1;)V

    return-object v1

    :pswitch_162  #0x2
    check-cast v1, Lads_mobile_sdk/g8;

    invoke-virtual {v1}, Lads_mobile_sdk/g8;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Lads_mobile_sdk/f8;

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/qr0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lads_mobile_sdk/w32;

    sget-object v0, Lads_mobile_sdk/lw0;->i:Lads_mobile_sdk/lw0;

    invoke-static {p0, v0}, Lt12;->c(Lads_mobile_sdk/qr0;Lads_mobile_sdk/lw0;)J

    move-result-wide v5

    const/4 v7, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-direct/range {v1 .. v7}, Lads_mobile_sdk/w32;-><init>(Lo23;IIJLrh1;)V

    return-object v1

    :pswitch_183  #0x1
    check-cast p0, Lads_mobile_sdk/ah0;

    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/z2;

    check-cast v1, Lads_mobile_sdk/a3;

    invoke-virtual {v1}, Lads_mobile_sdk/a3;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/uv2;

    new-instance v1, Lads_mobile_sdk/zx1;

    invoke-direct {v1, p0, v0}, Lads_mobile_sdk/zx1;-><init>(Lads_mobile_sdk/z2;Lads_mobile_sdk/uv2;)V

    return-object v1

    :pswitch_199  #0x0
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/jd1;

    check-cast v1, Lads_mobile_sdk/az1;

    invoke-virtual {v1}, Lads_mobile_sdk/az1;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lz03;

    new-instance v1, Lads_mobile_sdk/eh;

    invoke-direct {v1, p0, v0}, Lads_mobile_sdk/eh;-><init>(Lads_mobile_sdk/jd1;Lz03;)V

    return-object v1

    nop

    :pswitch_data_1ae
    .packed-switch 0x0
        :pswitch_199  #00000000
        :pswitch_183  #00000001
        :pswitch_162  #00000002
        :pswitch_141  #00000003
        :pswitch_120  #00000004
        :pswitch_ff  #00000005
        :pswitch_e5  #00000006
        :pswitch_c4  #00000007
        :pswitch_a3  #00000008
        :pswitch_82  #00000009
        :pswitch_61  #0000000a
        :pswitch_4b  #0000000b
        :pswitch_2a  #0000000c
    .end packed-switch
.end method
