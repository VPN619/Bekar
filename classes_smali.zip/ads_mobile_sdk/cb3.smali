.class public final Lads_mobile_sdk/cb3;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lz53;


# instance fields
.field public final a:Lads_mobile_sdk/mm0;

.field public final b:Lads_mobile_sdk/mm0;

.field public final c:Lv03;

.field public final d:Lads_mobile_sdk/th3;

.field public final e:Ljava/util/concurrent/ExecutorService;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/mm0;Lads_mobile_sdk/mm0;Lv03;Ljava/util/concurrent/ExecutorService;Lads_mobile_sdk/th3;)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/cb3;->a:Lads_mobile_sdk/mm0;

    iput-object p2, p0, Lads_mobile_sdk/cb3;->b:Lads_mobile_sdk/mm0;

    iput-object p3, p0, Lads_mobile_sdk/cb3;->c:Lv03;

    iput-object p5, p0, Lads_mobile_sdk/cb3;->d:Lads_mobile_sdk/th3;

    iput-object p4, p0, Lads_mobile_sdk/cb3;->e:Ljava/util/concurrent/ExecutorService;

    return-void
.end method


# virtual methods
.method public final a(Lads_mobile_sdk/jl2;[B)Ld31;
    .registers 5

    sget-object v0, Lads_mobile_sdk/fl0;->n3:Lads_mobile_sdk/fl0;

    iget-object v1, p0, Lads_mobile_sdk/cb3;->b:Lads_mobile_sdk/mm0;

    invoke-virtual {v1, p2}, Lads_mobile_sdk/mm0;->a(Ljava/lang/Object;)Lpd2;

    move-result-object p2

    iget-object v1, p0, Lads_mobile_sdk/cb3;->d:Lads_mobile_sdk/th3;

    invoke-virtual {v1, v0, p2}, Lads_mobile_sdk/th3;->a(Lads_mobile_sdk/fl0;Leg0;)V

    invoke-static {p2}, Lfg0;->r(Ld31;)Lfg0;

    move-result-object p2

    new-instance v0, Lbv2;

    const/4 v1, 0x1

    invoke-direct {v0, v1, p0, p1}, Lbv2;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    sget-object p0, Lv40;->a:Lv40;

    invoke-static {p2, v0, p0}, Lk1;->s(Lfg0;Lcf;Ljava/util/concurrent/Executor;)Li1;

    move-result-object p0

    return-object p0
.end method

.method public final a(Lads_mobile_sdk/jl2;[B[B)Ld31;
    .registers 7

    sget-object v0, Lads_mobile_sdk/fl0;->p3:Lads_mobile_sdk/fl0;

    iget-object v1, p0, Lads_mobile_sdk/cb3;->c:Lv03;

    invoke-interface {v1}, Lv03;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lads_mobile_sdk/mm0;

    invoke-virtual {v1, p2}, Lads_mobile_sdk/mm0;->a(Ljava/lang/Object;)Lpd2;

    move-result-object p2

    iget-object v1, p0, Lads_mobile_sdk/cb3;->d:Lads_mobile_sdk/th3;

    invoke-virtual {v1, v0, p2}, Lads_mobile_sdk/th3;->a(Lads_mobile_sdk/fl0;Leg0;)V

    sget-object v0, Lads_mobile_sdk/fl0;->n3:Lads_mobile_sdk/fl0;

    iget-object v2, p0, Lads_mobile_sdk/cb3;->b:Lads_mobile_sdk/mm0;

    invoke-virtual {v2, p3}, Lads_mobile_sdk/mm0;->a(Ljava/lang/Object;)Lpd2;

    move-result-object p3

    invoke-virtual {v1, v0, p3}, Lads_mobile_sdk/th3;->a(Lads_mobile_sdk/fl0;Leg0;)V

    const/4 v0, 0x2

    new-array v0, v0, [Ld31;

    const/4 v1, 0x0

    aput-object p2, v0, v1

    const/4 p2, 0x1

    aput-object p3, v0, p2

    new-instance p2, Lwr;

    sget-object p3, Ljq0;->b:Lhq0;

    invoke-virtual {v0}, [Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object p3

    check-cast p3, [Ljava/lang/Object;

    array-length v0, p3

    invoke-static {v0, p3}, Lvr0;->j(I[Ljava/lang/Object;)V

    array-length v0, p3

    invoke-static {v0, p3}, Ljq0;->o(I[Ljava/lang/Object;)Lps1;

    move-result-object p3

    invoke-direct {p2, p3}, Lwr;-><init>(Ljq0;)V

    invoke-static {p2}, Lfg0;->r(Ld31;)Lfg0;

    move-result-object p2

    new-instance p3, Lbv2;

    invoke-direct {p3, v1, p0, p1}, Lbv2;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    sget-object p0, Lv40;->a:Lv40;

    invoke-static {p2, p3, p0}, Lk1;->s(Lfg0;Lcf;Ljava/util/concurrent/Executor;)Li1;

    move-result-object p0

    return-object p0
.end method

.method public final a()Lpd2;
    .registers 5

    sget-object v0, Lads_mobile_sdk/fl0;->k3:Lads_mobile_sdk/fl0;

    iget-object v1, p0, Lads_mobile_sdk/cb3;->a:Lads_mobile_sdk/mm0;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v2, Lyp0;

    const/16 v3, 0x9

    invoke-direct {v2, v3, v1}, Lyp0;-><init>(ILjava/lang/Object;)V

    iget-object v1, v1, Lads_mobile_sdk/mm0;->b:Ljava/util/concurrent/ExecutorService;

    invoke-static {v1, v2}, Lpy2;->N(Ljava/util/concurrent/Executor;Ljava/util/concurrent/Callable;)Lpd2;

    move-result-object v1

    iget-object p0, p0, Lads_mobile_sdk/cb3;->d:Lads_mobile_sdk/th3;

    invoke-virtual {p0, v0, v1}, Lads_mobile_sdk/th3;->a(Lads_mobile_sdk/fl0;Leg0;)V

    return-object v1
.end method

.method public final b()Leq0;
    .registers 1

    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-static {p0}, Lpy2;->z(Ljava/lang/Object;)Leq0;

    move-result-object p0

    return-object p0
.end method
