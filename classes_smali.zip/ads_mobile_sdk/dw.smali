.class public final Lads_mobile_sdk/dw;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lnt2;


# instance fields
.field public final a:Ltv2;

.field public final b:Lads_mobile_sdk/ah0;

.field public final synthetic c:I


# direct methods
.method public synthetic constructor <init>(Lads_mobile_sdk/ah0;Ltv2;I)V
    .registers 4

    iput p3, p0, Lads_mobile_sdk/dw;->c:I

    iput-object p1, p0, Lads_mobile_sdk/dw;->b:Lads_mobile_sdk/ah0;

    iput-object p2, p0, Lads_mobile_sdk/dw;->a:Ltv2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Ltv2;Lads_mobile_sdk/ah0;I)V
    .registers 4

    iput p3, p0, Lads_mobile_sdk/dw;->c:I

    iput-object p1, p0, Lads_mobile_sdk/dw;->a:Ltv2;

    iput-object p2, p0, Lads_mobile_sdk/dw;->b:Lads_mobile_sdk/ah0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 8

    .prologue
    iget v0, p0, Lads_mobile_sdk/dw;->c:I

    const/4 v1, 0x0

    iget-object v2, p0, Lads_mobile_sdk/dw;->a:Ltv2;

    iget-object p0, p0, Lads_mobile_sdk/dw;->b:Lads_mobile_sdk/ah0;

    packed-switch v0, :pswitch_data_206

    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/yq3;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/qr0;

    new-instance v1, Lads_mobile_sdk/wp3;

    invoke-direct {v1, p0, v0}, Lads_mobile_sdk/wp3;-><init>(Lads_mobile_sdk/yq3;Lads_mobile_sdk/qr0;)V

    return-object v1

    :pswitch_1c  #0xf
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lvy;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map;

    new-instance v1, Ly43;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {v1, p0, v0}, Lpb;-><init>(Lvy;Ljava/util/Map;)V

    return-object v1

    :pswitch_34  #0xe
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lvy;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/qr0;

    new-instance v1, Lads_mobile_sdk/se2;

    invoke-direct {v1, p0, v0}, Lads_mobile_sdk/se2;-><init>(Lvy;Lads_mobile_sdk/qr0;)V

    return-object v1

    :pswitch_46  #0xd
    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/sb;

    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/ah3;

    new-instance v1, Lads_mobile_sdk/o71;

    invoke-direct {v1, v0, p0}, Lads_mobile_sdk/o71;-><init>(Lads_mobile_sdk/sb;Lads_mobile_sdk/ah3;)V

    return-object v1

    :pswitch_58  #0xc
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/vz;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/bn0;

    new-instance v1, Lads_mobile_sdk/nn0;

    invoke-direct {v1, p0, v0}, Lads_mobile_sdk/nn0;-><init>(Lads_mobile_sdk/vz;Lads_mobile_sdk/bn0;)V

    return-object v1

    :pswitch_6a  #0xb
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lvy;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/qr0;

    new-instance v1, Lads_mobile_sdk/l0;

    invoke-direct {v1, p0, v0}, Lads_mobile_sdk/l0;-><init>(Lvy;Lads_mobile_sdk/qr0;)V

    return-object v1

    :pswitch_7c  #0xa
    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/qw;

    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/uu0;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, v0, Lads_mobile_sdk/qw;->h:Loa1;

    new-instance v1, Lzb0;

    invoke-direct {v1, v0}, Lzb0;-><init>(Ljava/util/concurrent/Executor;)V

    invoke-static {v1, p0}, Lns2;->x(Ljy;Lly;)Lly;

    move-result-object p0

    new-instance v0, Lads_mobile_sdk/rh3;

    invoke-direct {v0}, Lads_mobile_sdk/rh3;-><init>()V

    invoke-interface {p0, v0}, Lly;->plus(Lly;)Lly;

    move-result-object p0

    invoke-static {p0}, Lhi1;->o(Ljava/lang/Object;)V

    check-cast p0, Lly;

    return-object p0

    :pswitch_a8  #0x9
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/d91;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lx43;

    new-instance v1, Llm0;

    invoke-direct {v1}, Llm0;-><init>()V

    new-instance v2, Lcom/google/android/libraries/ads/mobile/sdk/internal/util/AndroidBundleTypeAdapterFactory;

    invoke-direct {v2}, Lcom/google/android/libraries/ads/mobile/sdk/internal/util/AndroidBundleTypeAdapterFactory;-><init>()V

    invoke-virtual {v1, v2}, Llm0;->c(Lcom/google/android/libraries/ads/mobile/sdk/internal/util/AndroidBundleTypeAdapterFactory;)V

    new-instance v2, Lkm0;

    invoke-direct {v2, v1}, Lkm0;-><init>(Llm0;)V

    new-instance v1, Lads_mobile_sdk/k71;

    invoke-direct {v1, p0, v0, v2}, Lads_mobile_sdk/k71;-><init>(Lads_mobile_sdk/d91;Lx43;Lkm0;)V

    return-object v1

    :pswitch_cc  #0x8
    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/qw;

    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/uu0;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lh50;->a:Li20;

    sget-object v0, Lh51;->a:Lum0;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v0, p0}, Lns2;->x(Ljy;Lly;)Lly;

    move-result-object p0

    new-instance v0, Lads_mobile_sdk/rh3;

    invoke-direct {v0}, Lads_mobile_sdk/rh3;-><init>()V

    invoke-interface {p0, v0}, Lly;->plus(Lly;)Lly;

    move-result-object p0

    invoke-static {p0}, Lhi1;->o(Ljava/lang/Object;)V

    check-cast p0, Lly;

    return-object p0

    :pswitch_f8  #0x7
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/d91;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/uo3;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lads_mobile_sdk/m41;

    const/4 v2, 0x5

    invoke-direct {v1, p0, v0, v2}, Lads_mobile_sdk/m41;-><init>(Lads_mobile_sdk/d91;Ljava/lang/Object;I)V

    return-object v1

    :pswitch_111  #0x6
    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/qw;

    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/uu0;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, v0, Lads_mobile_sdk/qw;->f:Loa1;

    new-instance v1, Lzb0;

    invoke-direct {v1, v0}, Lzb0;-><init>(Ljava/util/concurrent/Executor;)V

    invoke-static {v1, p0}, Lns2;->x(Ljy;Lly;)Lly;

    move-result-object p0

    new-instance v0, Lads_mobile_sdk/rh3;

    invoke-direct {v0}, Lads_mobile_sdk/rh3;-><init>()V

    invoke-interface {p0, v0}, Lly;->plus(Lly;)Lly;

    move-result-object p0

    invoke-static {p0}, Lhi1;->o(Ljava/lang/Object;)V

    check-cast p0, Lly;

    return-object p0

    :pswitch_13d  #0x5
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/ah3;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lvy;

    new-instance v1, Lads_mobile_sdk/en3;

    invoke-direct {v1, p0, v0}, Lads_mobile_sdk/en3;-><init>(Lads_mobile_sdk/ah3;Lvy;)V

    return-object v1

    :pswitch_14f  #0x4
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/d91;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lq63;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lads_mobile_sdk/m41;

    const/4 v2, 0x2

    invoke-direct {v1, p0, v0, v2}, Lads_mobile_sdk/m41;-><init>(Lads_mobile_sdk/d91;Ljava/lang/Object;I)V

    return-object v1

    :pswitch_168  #0x3
    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/bk1;

    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/vz;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v2, Lads_mobile_sdk/m41;

    invoke-direct {v2, v1, v0, p0}, Lads_mobile_sdk/m41;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    return-object v2

    :pswitch_180  #0x2
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/yq3;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/qr0;

    new-instance v1, Lads_mobile_sdk/aq3;

    invoke-direct {v1, p0, v0}, Lads_mobile_sdk/aq3;-><init>(Lads_mobile_sdk/yq3;Lads_mobile_sdk/qr0;)V

    return-object v1

    :pswitch_192  #0x1
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lvy;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lro;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v2, Lso;

    sget-object v2, Lro;->Bo:Lqo;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget v2, Lqo;->b:I

    if-lez v2, :cond_1b0

    goto :goto_1b1

    :cond_1b0
    move v2, v1

    :goto_1b1
    new-instance v3, Lso;

    const/4 v4, -0x3

    sget-object v5, Ly90;->a:Ly90;

    sget-object v6, Lwk;->a:Lwk;

    invoke-direct {v3, v0, v5, v4, v6}, Lso;-><init>(Lro;Lly;ILwk;)V

    invoke-static {v1, v2, v6}, Lsz;->b(IILwk;)Lt22;

    move-result-object v0

    sget-object v1, Lx22;->a:Lns1;

    sget-object v2, Lx22;->b:Lxx1;

    if-eq v2, v1, :cond_1c8

    sget-object v1, Lyy;->d:Lyy;

    goto :goto_1ca

    :cond_1c8
    sget-object v1, Lyy;->a:Lyy;

    :goto_1ca
    new-instance v2, Lyh;

    const/4 v4, 0x0

    const/4 v6, 0x6

    invoke-direct {v2, v3, v0, v4, v6}, Lyh;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lvx;I)V

    invoke-static {p0, v5, v1, v2}, Lg73;->B(Lvy;Lly;Lyy;Lpk0;)Lx52;

    new-instance p0, Lyp1;

    invoke-direct {p0, v0}, Lyp1;-><init>(Lt22;)V

    return-object p0

    :pswitch_1da  #0x0
    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/qw;

    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/uu0;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, v0, Lads_mobile_sdk/qw;->c:Loa1;

    new-instance v1, Lzb0;

    invoke-direct {v1, v0}, Lzb0;-><init>(Ljava/util/concurrent/Executor;)V

    invoke-static {v1, p0}, Lns2;->x(Ljy;Lly;)Lly;

    move-result-object p0

    new-instance v0, Lads_mobile_sdk/rh3;

    invoke-direct {v0}, Lads_mobile_sdk/rh3;-><init>()V

    invoke-interface {p0, v0}, Lly;->plus(Lly;)Lly;

    move-result-object p0

    invoke-static {p0}, Lhi1;->o(Ljava/lang/Object;)V

    check-cast p0, Lly;

    return-object p0

    :pswitch_data_206
    .packed-switch 0x0
        :pswitch_1da  #00000000
        :pswitch_192  #00000001
        :pswitch_180  #00000002
        :pswitch_168  #00000003
        :pswitch_14f  #00000004
        :pswitch_13d  #00000005
        :pswitch_111  #00000006
        :pswitch_f8  #00000007
        :pswitch_cc  #00000008
        :pswitch_a8  #00000009
        :pswitch_7c  #0000000a
        :pswitch_6a  #0000000b
        :pswitch_58  #0000000c
        :pswitch_46  #0000000d
        :pswitch_34  #0000000e
        :pswitch_1c  #0000000f
    .end packed-switch
.end method
