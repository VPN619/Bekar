.class public Lads_mobile_sdk/bj1;
.super Ljava/io/IOException;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public a:Z
