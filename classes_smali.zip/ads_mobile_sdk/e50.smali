.class public final Lads_mobile_sdk/e50;
.super Lads_mobile_sdk/ku0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field private static final DEFAULT_INSTANCE:Lads_mobile_sdk/e50;

.field public static final c:I = 0x1

.field public static final d:I = 0x2

.field public static final e:I = 0x3

.field public static final f:I = 0x4

.field public static final g:I = 0x5


# instance fields
.field private bitField0_:I

.field private body_:Lads_mobile_sdk/hr;

.field private bodydigest_:Lads_mobile_sdk/hr;

.field private bodylength_:I

.field private firstline_:Lads_mobile_sdk/d50;

.field private headers_:Lw63;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lw63;"
        }
    .end annotation
.end field

.field private memoizedIsInitialized:B


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lads_mobile_sdk/e50;

    invoke-direct {v0}, Lads_mobile_sdk/e50;-><init>()V

    sput-object v0, Lads_mobile_sdk/e50;->DEFAULT_INSTANCE:Lads_mobile_sdk/e50;

    const-class v1, Lads_mobile_sdk/e50;

    invoke-static {v1, v0}, Lads_mobile_sdk/ku0;->a(Ljava/lang/Class;Lads_mobile_sdk/ku0;)V

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Lads_mobile_sdk/ku0;-><init>()V

    const/4 v0, 0x2

    iput-byte v0, p0, Lads_mobile_sdk/e50;->memoizedIsInitialized:B

    sget-object v0, Lads_mobile_sdk/am2;->e:Lads_mobile_sdk/am2;

    iput-object v0, p0, Lads_mobile_sdk/e50;->headers_:Lw63;

    sget-object v0, Lads_mobile_sdk/hr;->b:Lads_mobile_sdk/fr;

    iput-object v0, p0, Lads_mobile_sdk/e50;->body_:Lads_mobile_sdk/hr;

    iput-object v0, p0, Lads_mobile_sdk/e50;->bodydigest_:Lads_mobile_sdk/hr;

    return-void
.end method

.method public static bridge synthetic c(Lads_mobile_sdk/e50;)Lw63;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/e50;->headers_:Lw63;

    return-object p0
.end method

.method public static o()Lbu2;
    .registers 1

    sget-object v0, Lads_mobile_sdk/e50;->DEFAULT_INSTANCE:Lads_mobile_sdk/e50;

    invoke-virtual {v0}, Lads_mobile_sdk/ku0;->e()Lads_mobile_sdk/iu0;

    move-result-object v0

    check-cast v0, Lbu2;

    return-object v0
.end method


# virtual methods
.method public final a(ILads_mobile_sdk/ku0;)Ljava/lang/Object;
    .registers 10

    .prologue
    invoke-static {p1}, Lvr0;->a(I)I

    move-result p1

    const/4 v0, 0x0

    packed-switch p1, :pswitch_data_4e

    throw v0

    :pswitch_9  #0x6
    const-class p0, Lads_mobile_sdk/e50;

    invoke-static {p0}, Lads_mobile_sdk/ku0;->b(Ljava/lang/Class;)Lads_mobile_sdk/ju0;

    move-result-object p0

    return-object p0

    :pswitch_10  #0x5
    sget-object p0, Lads_mobile_sdk/e50;->DEFAULT_INSTANCE:Lads_mobile_sdk/e50;

    return-object p0

    :pswitch_13  #0x4
    new-instance p0, Lbu2;

    sget-object p1, Lads_mobile_sdk/e50;->DEFAULT_INSTANCE:Lads_mobile_sdk/e50;

    invoke-direct {p0, p1}, Lads_mobile_sdk/iu0;-><init>(Lads_mobile_sdk/ku0;)V

    return-object p0

    :pswitch_1b  #0x3
    new-instance p0, Lads_mobile_sdk/e50;

    invoke-direct {p0}, Lads_mobile_sdk/e50;-><init>()V

    return-object p0

    :pswitch_21  #0x2
    const-string v5, "bodydigest_"

    const-string v6, "bodylength_"

    const-string v0, "bitField0_"

    const-string v1, "firstline_"

    const-string v2, "headers_"

    const-class v3, Lads_mobile_sdk/a50;

    const-string v4, "body_"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lads_mobile_sdk/e50;->DEFAULT_INSTANCE:Lads_mobile_sdk/e50;

    new-instance p2, Lads_mobile_sdk/zq2;

    const-string v0, "\u0001\u0005\u0000\u0001\u0001\u0005\u0005\u0000\u0001\u0001\u0001ဉ\u0000\u0002Л\u0003ည\u0001\u0004ည\u0002\u0005င\u0003"

    invoke-direct {p2, p1, v0, p0}, Lads_mobile_sdk/zq2;-><init>(Lads_mobile_sdk/ku0;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object p2

    :pswitch_3d  #0x1
    if-nez p2, :cond_41

    const/4 p1, 0x0

    goto :goto_42

    :cond_41
    const/4 p1, 0x1

    :goto_42
    int-to-byte p1, p1

    iput-byte p1, p0, Lads_mobile_sdk/e50;->memoizedIsInitialized:B

    return-object v0

    :pswitch_46  #0x0
    iget-byte p0, p0, Lads_mobile_sdk/e50;->memoizedIsInitialized:B

    invoke-static {p0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_4e
    .packed-switch 0x0
        :pswitch_46  #00000000
        :pswitch_3d  #00000001
        :pswitch_21  #00000002
        :pswitch_1b  #00000003
        :pswitch_13  #00000004
        :pswitch_10  #00000005
        :pswitch_9  #00000006
    .end packed-switch
.end method

.method public final a(Lads_mobile_sdk/a50;)V
    .registers 4

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/e50;->headers_:Lw63;

    move-object v1, v0

    check-cast v1, Lads_mobile_sdk/j;

    iget-boolean v1, v1, Lads_mobile_sdk/j;->a:Z

    if-nez v1, :cond_f

    invoke-static {v0}, Li10;->I(Lw63;)Lw63;

    move-result-object v0

    iput-object v0, p0, Lads_mobile_sdk/e50;->headers_:Lw63;

    :cond_f
    invoke-interface {v0, p1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    return-void
.end method
