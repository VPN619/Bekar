.class public final Lads_mobile_sdk/cb;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lbk0;


# instance fields
.field public a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic t:I


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Lvx;I)V
    .registers 4

    iput p3, p0, Lads_mobile_sdk/cb;->t:I

    iput-object p1, p0, Lads_mobile_sdk/cb;->b:Ljava/lang/Object;

    const/4 p1, 0x1

    invoke-direct {p0, p1, p2}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .prologue
    iget v0, p0, Lads_mobile_sdk/cb;->t:I

    sget-object v1, Lrg2;->a:Lrg2;

    iget-object p0, p0, Lads_mobile_sdk/cb;->b:Ljava/lang/Object;

    packed-switch v0, :pswitch_data_36

    check-cast p1, Lvx;

    new-instance v0, Lads_mobile_sdk/cb;

    check-cast p0, Lads_mobile_sdk/s52;

    const/4 v2, 0x2

    invoke-direct {v0, p0, p1, v2}, Lads_mobile_sdk/cb;-><init>(Ljava/lang/Object;Lvx;I)V

    invoke-virtual {v0, v1}, Lads_mobile_sdk/cb;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_18  #0x1
    check-cast p1, Lvx;

    new-instance v0, Lads_mobile_sdk/cb;

    check-cast p0, Lads_mobile_sdk/e3;

    const/4 v2, 0x1

    invoke-direct {v0, p0, p1, v2}, Lads_mobile_sdk/cb;-><init>(Ljava/lang/Object;Lvx;I)V

    invoke-virtual {v0, v1}, Lads_mobile_sdk/cb;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_27  #0x0
    check-cast p1, Lvx;

    new-instance v0, Lads_mobile_sdk/cb;

    check-cast p0, Lv20;

    const/4 v2, 0x0

    invoke-direct {v0, p0, p1, v2}, Lads_mobile_sdk/cb;-><init>(Ljava/lang/Object;Lvx;I)V

    invoke-virtual {v0, v1}, Lads_mobile_sdk/cb;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_data_36
    .packed-switch 0x0
        :pswitch_27  #00000000
        :pswitch_18  #00000001
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 9

    .prologue
    iget v0, p0, Lads_mobile_sdk/cb;->t:I

    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    sget-object v2, Lwy;->a:Lwy;

    const/4 v3, 0x1

    iget-object v4, p0, Lads_mobile_sdk/cb;->b:Ljava/lang/Object;

    const/4 v5, 0x0

    packed-switch v0, :pswitch_data_8a

    check-cast v4, Lads_mobile_sdk/s52;

    iget v0, p0, Lads_mobile_sdk/cb;->a:I

    const/4 v6, 0x2

    if-eqz v0, :cond_25

    if-eq v0, v3, :cond_21

    if-ne v0, v6, :cond_1c

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_43

    :cond_1c
    invoke-static {v1}, Lz6;->w(Ljava/lang/String;)V

    move-object v2, v5

    goto :goto_4a

    :cond_21
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_31

    :cond_25
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iput v3, p0, Lads_mobile_sdk/cb;->a:I

    invoke-static {p0}, Lvr0;->M(Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v2, :cond_31

    goto :goto_4a

    :cond_31
    :goto_31
    iget-object p1, v4, Lads_mobile_sdk/s52;->d:Lly;

    new-instance v0, Lc4;

    const/16 v1, 0xa

    invoke-direct {v0, v4, v5, v1}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    iput v6, p0, Lads_mobile_sdk/cb;->a:I

    invoke-static {p1, v0, p0}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v2, :cond_43

    goto :goto_4a

    :cond_43
    :goto_43
    iget-object p0, v4, Lads_mobile_sdk/s52;->i:Lhv0;

    invoke-virtual {p0}, Lhv0;->a0()V

    sget-object v2, Lrg2;->a:Lrg2;

    :goto_4a
    return-object v2

    :pswitch_4b  #0x1
    iget v0, p0, Lads_mobile_sdk/cb;->a:I

    if-eqz v0, :cond_5a

    if-ne v0, v3, :cond_55

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_6a

    :cond_55
    invoke-static {v1}, Lz6;->w(Ljava/lang/String;)V

    move-object p1, v5

    goto :goto_6a

    :cond_5a
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    check-cast v4, Lads_mobile_sdk/e3;

    iget-object p1, v4, Lads_mobile_sdk/e3;->l:Lads_mobile_sdk/vz;

    iput v3, p0, Lads_mobile_sdk/cb;->a:I

    invoke-virtual {p1, p0}, Lads_mobile_sdk/vz;->w(Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v2, :cond_6a

    move-object p1, v2

    :cond_6a
    :goto_6a
    return-object p1

    :pswitch_6b  #0x0
    iget v0, p0, Lads_mobile_sdk/cb;->a:I

    if-eqz v0, :cond_7a

    if-ne v0, v3, :cond_75

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_88

    :cond_75
    invoke-static {v1}, Lz6;->w(Ljava/lang/String;)V

    move-object p1, v5

    goto :goto_88

    :cond_7a
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    check-cast v4, Lv20;

    iput v3, p0, Lads_mobile_sdk/cb;->a:I

    invoke-virtual {v4, p0}, Lnv0;->q(Lvx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v2, :cond_88

    move-object p1, v2

    :cond_88
    :goto_88
    return-object p1

    nop

    :pswitch_data_8a
    .packed-switch 0x0
        :pswitch_6b  #00000000
        :pswitch_4b  #00000001
    .end packed-switch
.end method
