.class public final Lads_mobile_sdk/c92;
.super Lwx;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public a:Ljava/lang/Object;

.field public b:Lads_mobile_sdk/cy0;

.field public c:Ljava/util/Map;

.field public d:Ljava/lang/Object;

.field public e:Landroid/content/Intent;

.field public f:I

.field public g:I

.field public h:Z

.field public synthetic i:Ljava/lang/Object;

.field public final synthetic j:Lads_mobile_sdk/f92;

.field public k:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/f92;Lvx;)V
    .registers 3

    iput-object p1, p0, Lads_mobile_sdk/c92;->j:Lads_mobile_sdk/f92;

    invoke-direct {p0, p2}, Lwx;-><init>(Lvx;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    iput-object p1, p0, Lads_mobile_sdk/c92;->i:Ljava/lang/Object;

    iget p1, p0, Lads_mobile_sdk/c92;->k:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, Lads_mobile_sdk/c92;->k:I

    iget-object p1, p0, Lads_mobile_sdk/c92;->j:Lads_mobile_sdk/f92;

    const/4 v0, 0x0

    invoke-virtual {p1, v0, v0, p0}, Lads_mobile_sdk/f92;->a(Lads_mobile_sdk/cy0;Ljava/util/Map;Lvx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
