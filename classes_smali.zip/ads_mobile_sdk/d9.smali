.class public final Lads_mobile_sdk/d9;
.super Lads_mobile_sdk/ku0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field private static final DEFAULT_INSTANCE:Lads_mobile_sdk/d9;

.field public static final c:I = 0x1


# instance fields
.field private adUnitPatterns_:Lw63;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lw63;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lads_mobile_sdk/d9;

    invoke-direct {v0}, Lads_mobile_sdk/d9;-><init>()V

    sput-object v0, Lads_mobile_sdk/d9;->DEFAULT_INSTANCE:Lads_mobile_sdk/d9;

    const-class v1, Lads_mobile_sdk/d9;

    invoke-static {v1, v0}, Lads_mobile_sdk/ku0;->a(Ljava/lang/Class;Lads_mobile_sdk/ku0;)V

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Lads_mobile_sdk/ku0;-><init>()V

    sget-object v0, Lads_mobile_sdk/am2;->e:Lads_mobile_sdk/am2;

    iput-object v0, p0, Lads_mobile_sdk/d9;->adUnitPatterns_:Lw63;

    return-void
.end method

.method public static bridge synthetic c(Lads_mobile_sdk/d9;)Lw63;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/d9;->adUnitPatterns_:Lw63;

    return-object p0
.end method

.method public static bridge synthetic d(Lads_mobile_sdk/d9;Lw63;)V
    .registers 2

    iput-object p1, p0, Lads_mobile_sdk/d9;->adUnitPatterns_:Lw63;

    return-void
.end method

.method public static p()Lads_mobile_sdk/d9;
    .registers 1

    sget-object v0, Lads_mobile_sdk/d9;->DEFAULT_INSTANCE:Lads_mobile_sdk/d9;

    return-object v0
.end method

.method public static q()Lzu2;
    .registers 1

    sget-object v0, Lads_mobile_sdk/d9;->DEFAULT_INSTANCE:Lads_mobile_sdk/d9;

    invoke-virtual {v0}, Lads_mobile_sdk/ku0;->e()Lads_mobile_sdk/iu0;

    move-result-object v0

    check-cast v0, Lzu2;

    return-object v0
.end method


# virtual methods
.method public final a(ILads_mobile_sdk/ku0;)Ljava/lang/Object;
    .registers 4

    .prologue
    invoke-static {p1}, Lvr0;->a(I)I

    move-result p0

    if-eqz p0, :cond_41

    const/4 p1, 0x2

    if-eq p0, p1, :cond_2f

    const/4 p1, 0x3

    if-eq p0, p1, :cond_29

    const/4 p1, 0x4

    if-eq p0, p1, :cond_21

    const/4 p1, 0x5

    if-eq p0, p1, :cond_1e

    const/4 p1, 0x6

    if-ne p0, p1, :cond_1c

    const-class p0, Lads_mobile_sdk/d9;

    invoke-static {p0}, Lads_mobile_sdk/ku0;->b(Ljava/lang/Class;)Lads_mobile_sdk/ju0;

    move-result-object p0

    return-object p0

    :cond_1c
    const/4 p0, 0x0

    throw p0

    :cond_1e
    sget-object p0, Lads_mobile_sdk/d9;->DEFAULT_INSTANCE:Lads_mobile_sdk/d9;

    return-object p0

    :cond_21
    new-instance p0, Lzu2;

    sget-object p1, Lads_mobile_sdk/d9;->DEFAULT_INSTANCE:Lads_mobile_sdk/d9;

    invoke-direct {p0, p1}, Lads_mobile_sdk/iu0;-><init>(Lads_mobile_sdk/ku0;)V

    return-object p0

    :cond_29
    new-instance p0, Lads_mobile_sdk/d9;

    invoke-direct {p0}, Lads_mobile_sdk/d9;-><init>()V

    return-object p0

    :cond_2f
    const-string p0, "adUnitPatterns_"

    const-class p1, Lads_mobile_sdk/z8;

    filled-new-array {p0, p1}, [Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lads_mobile_sdk/d9;->DEFAULT_INSTANCE:Lads_mobile_sdk/d9;

    new-instance p2, Lads_mobile_sdk/zq2;

    const-string v0, "\u0004\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001b"

    invoke-direct {p2, p1, v0, p0}, Lads_mobile_sdk/zq2;-><init>(Lads_mobile_sdk/ku0;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object p2

    :cond_41
    const/4 p0, 0x1

    invoke-static {p0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p0

    return-object p0
.end method

.method public final o()Lw63;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/d9;->adUnitPatterns_:Lw63;

    check-cast p0, Lw63;

    return-object p0
.end method
