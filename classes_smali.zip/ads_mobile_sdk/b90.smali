.class public final Lads_mobile_sdk/b90;
.super Lg00;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:Lvy;

.field public final c:Lads_mobile_sdk/ux2;

.field public d:Ltd;

.field public e:Lec;

.field public final f:Ljava/util/concurrent/atomic/AtomicBoolean;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lvy;Lads_mobile_sdk/ux2;)V
    .registers 4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/b90;->a:Landroid/content/Context;

    iput-object p2, p0, Lads_mobile_sdk/b90;->b:Lvy;

    iput-object p3, p0, Lads_mobile_sdk/b90;->c:Lads_mobile_sdk/ux2;

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 p2, 0x0

    invoke-direct {p1, p2}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object p1, p0, Lads_mobile_sdk/b90;->f:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-void
.end method


# virtual methods
.method public final onCustomTabsServiceConnected(Landroid/content/ComponentName;Lec;)V
    .registers 5

    .prologue
    iget-object v0, p2, Lec;->b:Ljava/lang/Object;

    check-cast v0, Ltp0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p2, p0, Lads_mobile_sdk/b90;->e:Lec;

    :try_start_9
    move-object p1, v0

    check-cast p1, Lrp0;

    invoke-virtual {p1}, Lrp0;->d()Z
    :try_end_f
    .catch Landroid/os/RemoteException; {:try_start_9 .. :try_end_f} :catch_f

    :catch_f
    new-instance p1, Lads_mobile_sdk/a90;

    invoke-direct {p1, p0}, Lads_mobile_sdk/a90;-><init>(Lads_mobile_sdk/b90;)V

    new-instance v1, Lc00;

    invoke-direct {v1, p1}, Lc00;-><init>(Lnp3;)V

    :try_start_19
    move-object p1, v0

    check-cast p1, Lrp0;

    invoke-virtual {p1, v1}, Lrp0;->c(Lc00;)Z

    move-result p1
    :try_end_20
    .catch Landroid/os/RemoteException; {:try_start_19 .. :try_end_20} :catch_2d

    if-nez p1, :cond_23

    goto :goto_2d

    :cond_23
    new-instance p1, Ltd;

    iget-object p2, p2, Lec;->c:Ljava/lang/Object;

    check-cast p2, Landroid/content/ComponentName;

    invoke-direct {p1, v0, v1, p2}, Ltd;-><init>(Ltp0;Lc00;Landroid/content/ComponentName;)V

    goto :goto_2e

    :catch_2d
    :goto_2d
    const/4 p1, 0x0

    :goto_2e
    iput-object p1, p0, Lads_mobile_sdk/b90;->d:Ltd;

    return-void
.end method

.method public final onServiceDisconnected(Landroid/content/ComponentName;)V
    .registers 2

    const/4 p1, 0x0

    iput-object p1, p0, Lads_mobile_sdk/b90;->d:Ltd;

    iput-object p1, p0, Lads_mobile_sdk/b90;->e:Lec;

    return-void
.end method
