.class public abstract Lads_mobile_sdk/cc1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lga3;


# instance fields
.field private final b:Lads_mobile_sdk/a2;

.field private final c:Lads_mobile_sdk/xv;

.field private final d:Lads_mobile_sdk/kh3;

.field private final f:Lads_mobile_sdk/z2;

.field private final g:Lads_mobile_sdk/ph0;

.field private final h:Lads_mobile_sdk/se2;

.field private final i:Lads_mobile_sdk/jz2;

.field private final j:Lads_mobile_sdk/ve2;

.field public k:Llu1;


# direct methods
.method public constructor <init>(Ljava/lang/String;Lads_mobile_sdk/a2;Lads_mobile_sdk/xv;Lads_mobile_sdk/kh3;Ljava/util/Optional;Lads_mobile_sdk/z2;Lads_mobile_sdk/ph0;Lads_mobile_sdk/se2;Lads_mobile_sdk/jz2;Lads_mobile_sdk/ve2;Lli;)V
    .registers 12

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Lads_mobile_sdk/cc1;->b:Lads_mobile_sdk/a2;

    iput-object p3, p0, Lads_mobile_sdk/cc1;->c:Lads_mobile_sdk/xv;

    iput-object p4, p0, Lads_mobile_sdk/cc1;->d:Lads_mobile_sdk/kh3;

    iput-object p6, p0, Lads_mobile_sdk/cc1;->f:Lads_mobile_sdk/z2;

    iput-object p7, p0, Lads_mobile_sdk/cc1;->g:Lads_mobile_sdk/ph0;

    iput-object p8, p0, Lads_mobile_sdk/cc1;->h:Lads_mobile_sdk/se2;

    iput-object p9, p0, Lads_mobile_sdk/cc1;->i:Lads_mobile_sdk/jz2;

    iput-object p10, p0, Lads_mobile_sdk/cc1;->j:Lads_mobile_sdk/ve2;

    iget-object p0, p4, Lads_mobile_sdk/kh3;->d:Lads_mobile_sdk/s8;

    iput-object p1, p0, Lads_mobile_sdk/s8;->b:Ljava/lang/String;

    iget-object p1, p2, Lads_mobile_sdk/a2;->e0:Ljava/lang/String;

    iput-object p1, p0, Lads_mobile_sdk/s8;->c:Ljava/lang/String;

    return-void
.end method

.method public static a(Lads_mobile_sdk/cc1;Lwx;)Ljava/lang/Object;
    .registers 8

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/bc1;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/bc1;

    iget v1, v0, Lads_mobile_sdk/bc1;->d:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/bc1;->d:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/bc1;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/bc1;-><init>(Lads_mobile_sdk/cc1;Lwx;)V

    :goto_18
    iget-object p1, v0, Lads_mobile_sdk/bc1;->b:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/bc1;->d:I

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    sget-object v5, Lwy;->a:Lwy;

    if-eqz v1, :cond_37

    if-eq v1, v4, :cond_31

    if-ne v1, v3, :cond_2b

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_59

    :cond_2b
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v2

    :cond_31
    iget-object p0, v0, Lads_mobile_sdk/bc1;->a:Lads_mobile_sdk/cc1;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_47

    :cond_37
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/cc1;->f:Lads_mobile_sdk/z2;

    iput-object p0, v0, Lads_mobile_sdk/bc1;->a:Lads_mobile_sdk/cc1;

    iput v4, v0, Lads_mobile_sdk/bc1;->d:I

    invoke-virtual {p1, v0}, Lads_mobile_sdk/z2;->i(Lvx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v5, :cond_47

    goto :goto_58

    :cond_47
    :goto_47
    iget-object p1, p0, Lads_mobile_sdk/cc1;->h:Lads_mobile_sdk/se2;

    iget-object v1, p0, Lads_mobile_sdk/cc1;->i:Lads_mobile_sdk/jz2;

    iput-object v2, v0, Lads_mobile_sdk/bc1;->a:Lads_mobile_sdk/cc1;

    iput v3, v0, Lads_mobile_sdk/bc1;->d:I

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1, p0, v1, v0}, Lads_mobile_sdk/se2;->a(Lads_mobile_sdk/se2;Ljava/lang/Object;Lg13;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_59

    :goto_58
    return-object v5

    :cond_59
    :goto_59
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method


# virtual methods
.method public final a()Lads_mobile_sdk/kh3;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/cc1;->d:Lads_mobile_sdk/kh3;

    return-object p0
.end method

.method public a(Lads_mobile_sdk/xm2;)Ljava/lang/Object;
    .registers 2

    invoke-static {p0, p1}, Lads_mobile_sdk/cc1;->a(Lads_mobile_sdk/cc1;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final a(Lads_mobile_sdk/xm2;)V
    .registers 2

    iget-object p0, p0, Lads_mobile_sdk/cc1;->f:Lads_mobile_sdk/z2;

    invoke-virtual {p0}, Lads_mobile_sdk/z2;->e()Lrg2;

    return-void
.end method

.method public final a(Llu1;)V
    .registers 2

    iput-object p1, p0, Lads_mobile_sdk/cc1;->k:Llu1;

    return-void
.end method

.method public final b()Lads_mobile_sdk/a2;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/cc1;->b:Lads_mobile_sdk/a2;

    return-object p0
.end method

.method public final c()Lads_mobile_sdk/ve2;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/cc1;->j:Lads_mobile_sdk/ve2;

    return-object p0
.end method

.method public destroy()V
    .registers 8

    .prologue
    iget-object p0, p0, Lads_mobile_sdk/cc1;->f:Lads_mobile_sdk/z2;

    iget-object v0, p0, Lads_mobile_sdk/z2;->f:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->getAndSet(Z)Z

    move-result v0

    if-nez v0, :cond_47

    iget-object v0, p0, Lpb;->b:Ljava/lang/Object;

    check-cast v0, Ljava/util/Map;

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_17
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_47

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    iget-object v3, p0, Lpb;->a:Ljava/lang/Object;

    check-cast v3, Lvy;

    new-instance v4, Lads_mobile_sdk/ha;

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-direct {v4, v2, v1, v6, v5}, Lads_mobile_sdk/ha;-><init>(Ljava/lang/String;Ljava/lang/Object;Lvx;I)V

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, La42;

    invoke-direct {v1, v4, v6}, La42;-><init>(Lpk0;Lvx;)V

    const/4 v2, 0x2

    sget-object v4, Ly90;->a:Ly90;

    invoke-static {v3, v4, v6, v1, v2}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    goto :goto_17

    :cond_47
    return-void
.end method

.method public g()Lfx0;
    .registers 1

    const/4 p0, 0x0

    return-object p0
.end method

.method public final getResponseInfo()Llu1;
    .registers 1

    .prologue
    iget-object p0, p0, Lads_mobile_sdk/cc1;->k:Llu1;

    if-eqz p0, :cond_5

    return-object p0

    :cond_5
    const-string p0, "responseInfo"

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0
.end method

.method public final i()Lads_mobile_sdk/xv;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/cc1;->c:Lads_mobile_sdk/xv;

    return-object p0
.end method

.method public final j()Lads_mobile_sdk/ph0;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/cc1;->g:Lads_mobile_sdk/ph0;

    return-object p0
.end method
