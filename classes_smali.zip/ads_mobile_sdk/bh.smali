.class public final Lads_mobile_sdk/bh;
.super Lads_mobile_sdk/ov;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lce;


# static fields
.field public static final d:Lzx1;

.field public static final synthetic e:[Liy0;


# instance fields
.field public final b:Lads_mobile_sdk/jd1;

.field public final c:Lads_mobile_sdk/ji;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    const-string v0, "adEventCallback"

    const-string v1, "getAdEventCallback()Lcom/google/android/libraries/ads/mobile/sdk/appopen/AppOpenAdEventCallback;"

    const-class v2, Lads_mobile_sdk/bh;

    invoke-static {v0, v1, v2}, Lv13;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Class;)Lhb1;

    move-result-object v0

    const/4 v1, 0x1

    new-array v1, v1, [Liy0;

    const/4 v2, 0x0

    aput-object v0, v1, v2

    sput-object v1, Lads_mobile_sdk/bh;->e:[Liy0;

    new-instance v0, Lzx1;

    const/16 v1, 0xd

    invoke-direct {v0, v1}, Lzx1;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/bh;->d:Lzx1;

    return-void
.end method

.method public constructor <init>(Lads_mobile_sdk/jd1;)V
    .registers 4

    invoke-direct {p0, p1}, Lads_mobile_sdk/ov;-><init>(Ljava/lang/Object;)V

    iput-object p1, p0, Lads_mobile_sdk/bh;->b:Lads_mobile_sdk/jd1;

    new-instance p1, Lads_mobile_sdk/ji;

    new-instance v0, Lo20;

    const/4 v1, 0x4

    invoke-direct {v0, v1, p0}, Lo20;-><init>(ILjava/lang/Object;)V

    const/4 v1, 0x0

    invoke-direct {p1, v0, v1}, Lads_mobile_sdk/ji;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    iput-object p1, p0, Lads_mobile_sdk/bh;->c:Lads_mobile_sdk/ji;

    return-void
.end method
