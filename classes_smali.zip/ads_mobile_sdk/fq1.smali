.class public final Lads_mobile_sdk/fq1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Lads_mobile_sdk/ki0;

.field public final b:Lads_mobile_sdk/bq1;

.field public final c:Lads_mobile_sdk/ax0;

.field public final d:Lvy;

.field public final e:Lads_mobile_sdk/g0;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/ki0;Lads_mobile_sdk/bq1;Lads_mobile_sdk/ax0;Lvy;Lads_mobile_sdk/g0;)V
    .registers 6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/fq1;->a:Lads_mobile_sdk/ki0;

    iput-object p2, p0, Lads_mobile_sdk/fq1;->b:Lads_mobile_sdk/bq1;

    iput-object p3, p0, Lads_mobile_sdk/fq1;->c:Lads_mobile_sdk/ax0;

    iput-object p4, p0, Lads_mobile_sdk/fq1;->d:Lvy;

    iput-object p5, p0, Lads_mobile_sdk/fq1;->e:Lads_mobile_sdk/g0;

    return-void
.end method
