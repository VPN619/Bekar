.class public final Lads_mobile_sdk/el;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lnt2;


# instance fields
.field public final a:Ltv2;

.field public final b:Ltv2;

.field public final c:Lads_mobile_sdk/ah0;

.field public final d:Ltv2;

.field public final e:Ltv2;

.field public final f:Lads_mobile_sdk/ah0;

.field public final synthetic g:I


# direct methods
.method public synthetic constructor <init>(Lads_mobile_sdk/ah0;Lads_mobile_sdk/ah0;Ltv2;Ltv2;Ltv2;Ltv2;I)V
    .registers 8

    iput p7, p0, Lads_mobile_sdk/el;->g:I

    iput-object p1, p0, Lads_mobile_sdk/el;->c:Lads_mobile_sdk/ah0;

    iput-object p2, p0, Lads_mobile_sdk/el;->f:Lads_mobile_sdk/ah0;

    iput-object p3, p0, Lads_mobile_sdk/el;->a:Ltv2;

    iput-object p4, p0, Lads_mobile_sdk/el;->b:Ltv2;

    iput-object p5, p0, Lads_mobile_sdk/el;->d:Ltv2;

    iput-object p6, p0, Lads_mobile_sdk/el;->e:Ltv2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Ltv2;Ltv2;Lads_mobile_sdk/ah0;Ltv2;Ltv2;Lads_mobile_sdk/ah0;I)V
    .registers 8

    iput p7, p0, Lads_mobile_sdk/el;->g:I

    iput-object p1, p0, Lads_mobile_sdk/el;->a:Ltv2;

    iput-object p2, p0, Lads_mobile_sdk/el;->b:Ltv2;

    iput-object p3, p0, Lads_mobile_sdk/el;->c:Lads_mobile_sdk/ah0;

    iput-object p4, p0, Lads_mobile_sdk/el;->d:Ltv2;

    iput-object p5, p0, Lads_mobile_sdk/el;->e:Ltv2;

    iput-object p6, p0, Lads_mobile_sdk/el;->f:Lads_mobile_sdk/ah0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 14

    .prologue
    iget v0, p0, Lads_mobile_sdk/el;->g:I

    iget-object v1, p0, Lads_mobile_sdk/el;->e:Ltv2;

    iget-object v2, p0, Lads_mobile_sdk/el;->d:Ltv2;

    iget-object v3, p0, Lads_mobile_sdk/el;->b:Ltv2;

    iget-object v4, p0, Lads_mobile_sdk/el;->a:Ltv2;

    iget-object v5, p0, Lads_mobile_sdk/el;->f:Lads_mobile_sdk/ah0;

    iget-object p0, p0, Lads_mobile_sdk/el;->c:Lads_mobile_sdk/ah0;

    packed-switch v0, :pswitch_data_d2

    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v7, p0

    check-cast v7, Lvy;

    invoke-virtual {v5}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v8, p0

    check-cast v8, Lly;

    invoke-interface {v4}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v9, p0

    check-cast v9, Lads_mobile_sdk/lu2;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v10, p0

    check-cast v10, Lx43;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v11, p0

    check-cast v11, Lads_mobile_sdk/mt2;

    invoke-interface {v1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v12, p0

    check-cast v12, Ll03;

    new-instance v6, Lads_mobile_sdk/xa2;

    invoke-direct/range {v6 .. v12}, Lads_mobile_sdk/xa2;-><init>(Lvy;Lly;Lads_mobile_sdk/lu2;Lx43;Lads_mobile_sdk/mt2;Ll03;)V

    return-object v6

    :pswitch_41  #0x2
    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v12, p0

    check-cast v12, Lvy;

    invoke-virtual {v5}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v7, p0

    check-cast v7, Lads_mobile_sdk/vz;

    invoke-interface {v4}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v11, p0

    check-cast v11, Lx43;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v8, p0

    check-cast v8, Lads_mobile_sdk/qr0;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v10, p0

    check-cast v10, Lads_mobile_sdk/ux2;

    invoke-interface {v1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v9, p0

    check-cast v9, Lads_mobile_sdk/g0;

    new-instance v6, Lads_mobile_sdk/e3;

    invoke-direct/range {v6 .. v12}, Lads_mobile_sdk/e3;-><init>(Lads_mobile_sdk/vz;Lads_mobile_sdk/qr0;Lads_mobile_sdk/g0;Lads_mobile_sdk/ux2;Lx43;Lvy;)V

    return-object v6

    :pswitch_71  #0x1
    invoke-interface {v4}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v8, v0

    check-cast v8, Lads_mobile_sdk/qr0;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v11, v0

    check-cast v11, Lx43;

    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v12, p0

    check-cast v12, Lvy;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v10, p0

    check-cast v10, Lads_mobile_sdk/ux2;

    invoke-interface {v1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v9, p0

    check-cast v9, Lads_mobile_sdk/g0;

    invoke-virtual {v5}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v7, p0

    check-cast v7, Lads_mobile_sdk/vz;

    new-instance v6, Lads_mobile_sdk/bj3;

    invoke-direct/range {v6 .. v12}, Lads_mobile_sdk/bj3;-><init>(Lads_mobile_sdk/vz;Lads_mobile_sdk/qr0;Lads_mobile_sdk/g0;Lads_mobile_sdk/ux2;Lx43;Lvy;)V

    return-object v6

    :pswitch_a1  #0x0
    invoke-interface {v4}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v7, v0

    check-cast v7, Lads_mobile_sdk/uv2;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v8, v0

    check-cast v8, Lads_mobile_sdk/gp3;

    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v9, p0

    check-cast v9, Lads_mobile_sdk/vz;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v10, p0

    check-cast v10, Ln63;

    invoke-interface {v1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v11, p0

    check-cast v11, Lads_mobile_sdk/qr0;

    invoke-virtual {v5}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    move-object v12, p0

    check-cast v12, Lads_mobile_sdk/ah3;

    new-instance v6, Lads_mobile_sdk/dl;

    invoke-direct/range {v6 .. v12}, Lads_mobile_sdk/dl;-><init>(Lads_mobile_sdk/uv2;Lads_mobile_sdk/gp3;Lads_mobile_sdk/vz;Ln63;Lads_mobile_sdk/qr0;Lads_mobile_sdk/ah3;)V

    return-object v6

    nop

    :pswitch_data_d2
    .packed-switch 0x0
        :pswitch_a1  #00000000
        :pswitch_71  #00000001
        :pswitch_41  #00000002
    .end packed-switch
.end method
