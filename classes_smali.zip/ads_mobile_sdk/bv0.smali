.class public final Lads_mobile_sdk/bv0;
.super Lads_mobile_sdk/av0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final c:Ljava/lang/Throwable;

.field public final d:I

.field public final e:Ljava/lang/String;


# direct methods
.method public constructor <init>(ILjava/lang/String;Ljava/lang/Throwable;)V
    .registers 4

    .prologue
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-eqz p1, :cond_f

    invoke-direct {p0, p1}, Lads_mobile_sdk/av0;-><init>(I)V

    iput-object p3, p0, Lads_mobile_sdk/bv0;->c:Ljava/lang/Throwable;

    iput p1, p0, Lads_mobile_sdk/bv0;->d:I

    iput-object p2, p0, Lads_mobile_sdk/bv0;->e:Ljava/lang/String;

    return-void

    :cond_f
    const/4 p0, 0x0

    throw p0
.end method

.method public synthetic constructor <init>(ILjava/lang/String;Ljava/lang/Throwable;I)V
    .registers 6

    .prologue
    and-int/lit8 v0, p4, 0x2

    if-eqz v0, :cond_5

    const/4 p1, 0x1

    :cond_5
    and-int/lit8 p4, p4, 0x4

    if-eqz p4, :cond_a

    const/4 p2, 0x0

    :cond_a
    invoke-direct {p0, p1, p2, p3}, Lads_mobile_sdk/bv0;-><init>(ILjava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method


# virtual methods
.method public final a()I
    .registers 1

    iget p0, p0, Lads_mobile_sdk/bv0;->d:I

    return p0
.end method

.method public final b()Ljava/lang/Throwable;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/bv0;->c:Ljava/lang/Throwable;

    return-object p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    .prologue
    if-ne p0, p1, :cond_3

    goto :goto_28

    :cond_3
    instance-of v0, p1, Lads_mobile_sdk/bv0;

    if-nez v0, :cond_8

    goto :goto_26

    :cond_8
    check-cast p1, Lads_mobile_sdk/bv0;

    iget-object v0, p0, Lads_mobile_sdk/bv0;->c:Ljava/lang/Throwable;

    iget-object v1, p1, Lads_mobile_sdk/bv0;->c:Ljava/lang/Throwable;

    invoke-static {v0, v1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_15

    goto :goto_26

    :cond_15
    iget v0, p0, Lads_mobile_sdk/bv0;->d:I

    iget v1, p1, Lads_mobile_sdk/bv0;->d:I

    if-eq v0, v1, :cond_1c

    goto :goto_26

    :cond_1c
    iget-object p0, p0, Lads_mobile_sdk/bv0;->e:Ljava/lang/String;

    iget-object p1, p1, Lads_mobile_sdk/bv0;->e:Ljava/lang/String;

    invoke-static {p0, p1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_28

    :goto_26
    const/4 p0, 0x0

    return p0

    :cond_28
    :goto_28
    const/4 p0, 0x1

    return p0
.end method

.method public final hashCode()I
    .registers 3

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/bv0;->c:Ljava/lang/Throwable;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, Lads_mobile_sdk/bv0;->d:I

    invoke-static {v1}, Lc33;->x(I)I

    move-result v1

    add-int/2addr v1, v0

    mul-int/lit8 v1, v1, 0x1f

    iget-object p0, p0, Lads_mobile_sdk/bv0;->e:Ljava/lang/String;

    if-nez p0, :cond_17

    const/4 p0, 0x0

    goto :goto_1b

    :cond_17
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result p0

    :goto_1b
    add-int/2addr v1, p0

    return v1
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "ExceptionError(exception="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lads_mobile_sdk/bv0;->c:Ljava/lang/Throwable;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", internalErrorCode="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lads_mobile_sdk/bv0;->d:I

    invoke-static {v1}, Ly41;->C(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", message="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, Lads_mobile_sdk/bv0;->e:Ljava/lang/String;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
