.class public final Lads_mobile_sdk/dt3;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:J

.field public final b:J

.field public final c:J


# direct methods
.method public constructor <init>(JJJ)V
    .registers 7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, Lads_mobile_sdk/dt3;->a:J

    iput-wide p3, p0, Lads_mobile_sdk/dt3;->c:J

    iput-wide p5, p0, Lads_mobile_sdk/dt3;->b:J

    return-void
.end method
