.class public final Lads_mobile_sdk/ee2;
.super Lads_mobile_sdk/ku0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field private static final DEFAULT_INSTANCE:Lads_mobile_sdk/ee2;

.field public static final c:I = 0x1

.field public static final d:I = 0x2

.field public static final e:I = 0x3

.field public static final f:I = 0x4

.field public static final g:I = 0x5

.field public static final h:I = 0x6


# instance fields
.field private bitField0_:I

.field private cacheHit_:Z

.field private cacheMissReason_:I

.field private isFromPreviousSession_:Z

.field private numAdsInCachedResponse_:I

.field private numRequestedAds_:I

.field private timeInCacheMs_:J


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lads_mobile_sdk/ee2;

    invoke-direct {v0}, Lads_mobile_sdk/ku0;-><init>()V

    sput-object v0, Lads_mobile_sdk/ee2;->DEFAULT_INSTANCE:Lads_mobile_sdk/ee2;

    const-class v1, Lads_mobile_sdk/ee2;

    invoke-static {v1, v0}, Lads_mobile_sdk/ku0;->a(Ljava/lang/Class;Lads_mobile_sdk/ku0;)V

    return-void
.end method

.method public static bridge synthetic c(Lads_mobile_sdk/ee2;)I
    .registers 1

    iget p0, p0, Lads_mobile_sdk/ee2;->bitField0_:I

    return p0
.end method

.method public static bridge synthetic d(Lads_mobile_sdk/ee2;I)V
    .registers 2

    iput p1, p0, Lads_mobile_sdk/ee2;->bitField0_:I

    return-void
.end method

.method public static bridge synthetic f(Lads_mobile_sdk/ee2;Z)V
    .registers 2

    iput-boolean p1, p0, Lads_mobile_sdk/ee2;->cacheHit_:Z

    return-void
.end method

.method public static bridge synthetic g(Lads_mobile_sdk/ee2;I)V
    .registers 2

    iput p1, p0, Lads_mobile_sdk/ee2;->cacheMissReason_:I

    return-void
.end method

.method public static bridge synthetic h(Lads_mobile_sdk/ee2;Z)V
    .registers 2

    iput-boolean p1, p0, Lads_mobile_sdk/ee2;->isFromPreviousSession_:Z

    return-void
.end method

.method public static bridge synthetic i(Lads_mobile_sdk/ee2;I)V
    .registers 2

    iput p1, p0, Lads_mobile_sdk/ee2;->numAdsInCachedResponse_:I

    return-void
.end method

.method public static bridge synthetic m(Lads_mobile_sdk/ee2;I)V
    .registers 2

    iput p1, p0, Lads_mobile_sdk/ee2;->numRequestedAds_:I

    return-void
.end method

.method public static o()Lev2;
    .registers 1

    sget-object v0, Lads_mobile_sdk/ee2;->DEFAULT_INSTANCE:Lads_mobile_sdk/ee2;

    invoke-virtual {v0}, Lads_mobile_sdk/ku0;->e()Lads_mobile_sdk/iu0;

    move-result-object v0

    check-cast v0, Lev2;

    return-object v0
.end method

.method public static bridge synthetic o(Lads_mobile_sdk/ee2;J)V
    .registers 3

    iput-wide p1, p0, Lads_mobile_sdk/ee2;->timeInCacheMs_:J

    return-void
.end method


# virtual methods
.method public final a(ILads_mobile_sdk/ku0;)Ljava/lang/Object;
    .registers 10

    .prologue
    invoke-static {p1}, Lvr0;->a(I)I

    move-result p0

    if-eqz p0, :cond_4b

    const/4 p1, 0x2

    if-eq p0, p1, :cond_2f

    const/4 p1, 0x3

    if-eq p0, p1, :cond_29

    const/4 p1, 0x4

    if-eq p0, p1, :cond_21

    const/4 p1, 0x5

    if-eq p0, p1, :cond_1e

    const/4 p1, 0x6

    if-ne p0, p1, :cond_1c

    const-class p0, Lads_mobile_sdk/ee2;

    invoke-static {p0}, Lads_mobile_sdk/ku0;->b(Ljava/lang/Class;)Lads_mobile_sdk/ju0;

    move-result-object p0

    return-object p0

    :cond_1c
    const/4 p0, 0x0

    throw p0

    :cond_1e
    sget-object p0, Lads_mobile_sdk/ee2;->DEFAULT_INSTANCE:Lads_mobile_sdk/ee2;

    return-object p0

    :cond_21
    new-instance p0, Lev2;

    sget-object p1, Lads_mobile_sdk/ee2;->DEFAULT_INSTANCE:Lads_mobile_sdk/ee2;

    invoke-direct {p0, p1}, Lads_mobile_sdk/iu0;-><init>(Lads_mobile_sdk/ku0;)V

    return-object p0

    :cond_29
    new-instance p0, Lads_mobile_sdk/ee2;

    invoke-direct {p0}, Lads_mobile_sdk/ku0;-><init>()V

    return-object p0

    :cond_2f
    const-string v5, "numAdsInCachedResponse_"

    const-string v6, "timeInCacheMs_"

    const-string v0, "bitField0_"

    const-string v1, "cacheHit_"

    const-string v2, "isFromPreviousSession_"

    const-string v3, "cacheMissReason_"

    const-string v4, "numRequestedAds_"

    filled-new-array/range {v0 .. v6}, [Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lads_mobile_sdk/ee2;->DEFAULT_INSTANCE:Lads_mobile_sdk/ee2;

    new-instance p2, Lads_mobile_sdk/zq2;

    const-string v0, "\u0004\u0006\u0000\u0001\u0001\u0006\u0006\u0000\u0000\u0000\u0001ဇ\u0000\u0002ဇ\u0001\u0003ဌ\u0002\u0004င\u0003\u0005င\u0004\u0006ဂ\u0005"

    invoke-direct {p2, p1, v0, p0}, Lads_mobile_sdk/zq2;-><init>(Lads_mobile_sdk/ku0;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object p2

    :cond_4b
    const/4 p0, 0x1

    invoke-static {p0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p0

    return-object p0
.end method
