.class public final Lads_mobile_sdk/fm;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ldv2;


# instance fields
.field public final a:Lli;

.field public final b:Lqh;

.field public final c:Lads_mobile_sdk/cu2;

.field public final d:Landroid/content/Context;

.field public final e:Lads_mobile_sdk/g0;

.field public final f:Lads_mobile_sdk/rh0;

.field public final g:Ltv2;

.field public final h:Lc73;


# direct methods
.method public constructor <init>(Lli;Lqh;Lads_mobile_sdk/cu2;Landroid/content/Context;Lads_mobile_sdk/g0;Lads_mobile_sdk/rh0;Lads_mobile_sdk/ab0;Lc73;)V
    .registers 9

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/fm;->a:Lli;

    iput-object p2, p0, Lads_mobile_sdk/fm;->b:Lqh;

    iput-object p3, p0, Lads_mobile_sdk/fm;->c:Lads_mobile_sdk/cu2;

    iput-object p4, p0, Lads_mobile_sdk/fm;->d:Landroid/content/Context;

    iput-object p5, p0, Lads_mobile_sdk/fm;->e:Lads_mobile_sdk/g0;

    iput-object p6, p0, Lads_mobile_sdk/fm;->f:Lads_mobile_sdk/rh0;

    iput-object p7, p0, Lads_mobile_sdk/fm;->g:Ltv2;

    iput-object p8, p0, Lads_mobile_sdk/fm;->h:Lc73;

    return-void
.end method


# virtual methods
.method public final a(Lads_mobile_sdk/n13;Lads_mobile_sdk/a2;Lk53;)Lm23;
    .registers 4

    .prologue
    check-cast p3, Lads_mobile_sdk/z42;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p1, p0, Lads_mobile_sdk/fm;->g:Ltv2;

    invoke-interface {p1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lads_mobile_sdk/ue0;

    iget-object p2, p3, Lads_mobile_sdk/z42;->b:Landroid/view/View;

    if-eqz p2, :cond_21

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p2, p1, Lads_mobile_sdk/ue0;->q:Landroid/view/View;

    iget-object p0, p0, Lads_mobile_sdk/fm;->h:Lc73;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p0, p1, Lads_mobile_sdk/ue0;->p:Lc73;

    return-object p1

    :cond_21
    const-string p0, "view"

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0
.end method

.method public final a(Lads_mobile_sdk/n13;Lads_mobile_sdk/a2;Lk53;Lads_mobile_sdk/os;)V
    .registers 24

    .prologue
    move-object/from16 v0, p0

    move-object/from16 v1, p4

    move-object/from16 v2, p3

    check-cast v2, Lads_mobile_sdk/z42;

    invoke-virtual/range {p1 .. p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p2 .. p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v3, v0, Lads_mobile_sdk/fm;->b:Lqh;

    invoke-interface {v3}, Lqh;->k()Ls4;

    move-result-object v3

    const-string v4, "com.google.android.libraries.ads.mobile.sdk"

    const/4 v5, 0x0

    if-nez v3, :cond_27

    new-instance v0, Lcom/google/android/gms/ads/AdError;

    const-string v2, "No AdSize available for banner mediation. This may happen when a server-to-server ad response triggers mediation but no AdSize was provided in the signal request."

    invoke-direct {v0, v5, v2, v4}, Lcom/google/android/gms/ads/AdError;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Lads_mobile_sdk/os;->a(Lcom/google/android/gms/ads/AdError;)V

    return-void

    :cond_27
    iget-object v6, v0, Lads_mobile_sdk/fm;->e:Lads_mobile_sdk/g0;

    invoke-virtual {v6}, Lads_mobile_sdk/g0;->b()Landroid/app/Activity;

    move-result-object v6

    if-eqz v6, :cond_31

    :goto_2f
    move-object v8, v6

    goto :goto_34

    :cond_31
    iget-object v6, v0, Lads_mobile_sdk/fm;->d:Landroid/content/Context;

    goto :goto_2f

    :goto_34
    iget-object v6, v0, Lads_mobile_sdk/fm;->c:Lads_mobile_sdk/cu2;

    invoke-virtual {v6}, Lads_mobile_sdk/cu2;->a()Lut1;

    move-result-object v6

    move-object/from16 v7, p2

    iget-object v7, v7, Lads_mobile_sdk/a2;->c:Lfx0;

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v9, v0, Lads_mobile_sdk/fm;->a:Lli;

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, v0, Lads_mobile_sdk/fm;->f:Lads_mobile_sdk/rh0;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v10, v2, Lads_mobile_sdk/z42;->a:Lcom/google/android/gms/ads/mediation/MediationAdapter;

    instance-of v11, v10, Lcom/google/android/gms/ads/mediation/MediationBannerAdapter;

    if-nez v11, :cond_98

    new-instance v0, Lcom/google/android/gms/ads/AdError;

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v2

    const-class v3, Lcom/google/android/gms/ads/mediation/MediationBannerAdapter;

    invoke-virtual {v3}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v3}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v3

    const-string v8, " to "

    const-string v9, ". Does "

    const-string v10, "Failed to cast "

    invoke-static {v10, v2, v8, v6, v9}, Ly41;->t(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, " implement "

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "?"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v5, v2, v4}, Lcom/google/android/gms/ads/AdError;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Lads_mobile_sdk/os;->a(Lcom/google/android/gms/ads/AdError;)V

    return-void

    :cond_98
    new-instance v11, Lads_mobile_sdk/bo1;

    iget-object v12, v9, Lli;->e:Ljava/util/HashSet;

    invoke-virtual {v6, v8}, Lut1;->a(Landroid/content/Context;)Z

    move-result v13

    const/4 v15, -0x1

    invoke-static {v7, v6}, Lmu2;->d(Lfx0;Lut1;)Ljava/lang/String;

    move-result-object v16

    const/4 v14, -0x1

    invoke-direct/range {v11 .. v16}, Lads_mobile_sdk/bo1;-><init>(Ljava/util/HashSet;ZIILjava/lang/String;)V

    move-object v4, v7

    move-object v7, v10

    check-cast v7, Lcom/google/android/gms/ads/mediation/MediationBannerAdapter;

    new-instance v5, Lads_mobile_sdk/v42;

    invoke-direct {v5, v0, v1, v2}, Lads_mobile_sdk/v42;-><init>(Lads_mobile_sdk/rh0;Lads_mobile_sdk/os;Lads_mobile_sdk/z42;)V

    invoke-static {v4}, Lmu2;->b(Lfx0;)Landroid/os/Bundle;

    move-result-object v0

    iget v13, v3, Ls4;->a:I

    iget v14, v3, Ls4;->b:I

    iget-object v15, v3, Ls4;->f:Ljava/lang/String;

    iget-boolean v1, v3, Ls4;->c:Z

    iget-boolean v2, v3, Ls4;->d:Z

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v12, Lcom/google/android/gms/ads/AdSize;

    move/from16 v18, v14

    move/from16 v16, v1

    move/from16 v17, v2

    invoke-direct/range {v12 .. v18}, Lcom/google/android/gms/ads/AdSize;-><init>(IILjava/lang/String;ZZI)V

    invoke-static {v9, v10}, Lmu2;->a(Lli;Lcom/google/android/gms/ads/mediation/MediationExtrasReceiver;)Landroid/os/Bundle;

    move-result-object v13

    move-object v9, v12

    move-object v12, v11

    move-object v11, v9

    move-object v10, v0

    move-object v9, v5

    invoke-interface/range {v7 .. v13}, Lcom/google/android/gms/ads/mediation/MediationBannerAdapter;->requestBannerAd(Landroid/content/Context;Lcom/google/android/gms/ads/mediation/MediationBannerListener;Landroid/os/Bundle;Lcom/google/android/gms/ads/AdSize;Lcom/google/android/gms/ads/mediation/MediationAdRequest;Landroid/os/Bundle;)V

    return-void
.end method

.method public final a(Lz23;)V
    .registers 2

    check-cast p1, Lads_mobile_sdk/ve0;

    iget-object p0, p1, Lads_mobile_sdk/ve0;->P:Ltv2;

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ldx2;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void
.end method
