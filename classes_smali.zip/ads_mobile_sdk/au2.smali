.class public final Lads_mobile_sdk/au2;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Lads_mobile_sdk/qr0;

.field public final b:Lads_mobile_sdk/ek;

.field public final c:Lads_mobile_sdk/ah3;

.field public final d:Lads_mobile_sdk/wp;

.field public final e:Ljava/util/Optional;

.field public final f:Ln63;

.field public final g:Lads_mobile_sdk/bk1;

.field public final h:I

.field public final i:Landroid/content/Context;

.field public j:Ljava/lang/String;

.field public k:Z

.field public l:Z

.field public final m:Ljava/util/LinkedHashSet;

.field public final n:Ljava/util/LinkedHashSet;

.field public final o:Ljava/util/LinkedHashMap;

.field public p:Ljava/util/Map;

.field public final q:Ljava/util/LinkedHashMap;

.field public final r:Lkm0;

.field public s:Lg32;

.field public t:Lfx0;

.field public final u:Lfx0;

.field public final v:Ljava/util/LinkedHashMap;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/qr0;Lads_mobile_sdk/ek;Lads_mobile_sdk/ah3;Lads_mobile_sdk/wp;Ljava/util/Optional;Ln63;Lads_mobile_sdk/bk1;ILandroid/content/Context;)V
    .registers 10

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/au2;->a:Lads_mobile_sdk/qr0;

    iput-object p2, p0, Lads_mobile_sdk/au2;->b:Lads_mobile_sdk/ek;

    iput-object p3, p0, Lads_mobile_sdk/au2;->c:Lads_mobile_sdk/ah3;

    iput-object p4, p0, Lads_mobile_sdk/au2;->d:Lads_mobile_sdk/wp;

    iput-object p5, p0, Lads_mobile_sdk/au2;->e:Ljava/util/Optional;

    iput-object p6, p0, Lads_mobile_sdk/au2;->f:Ln63;

    iput-object p7, p0, Lads_mobile_sdk/au2;->g:Lads_mobile_sdk/bk1;

    iput p8, p0, Lads_mobile_sdk/au2;->h:I

    iput-object p9, p0, Lads_mobile_sdk/au2;->i:Landroid/content/Context;

    const-string p1, "https://googleads.g.doubleclick.net/mads/gma"

    iput-object p1, p0, Lads_mobile_sdk/au2;->j:Ljava/lang/String;

    new-instance p1, Ljava/util/LinkedHashSet;

    invoke-direct {p1}, Ljava/util/LinkedHashSet;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/au2;->m:Ljava/util/LinkedHashSet;

    new-instance p1, Ljava/util/LinkedHashSet;

    invoke-direct {p1}, Ljava/util/LinkedHashSet;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/au2;->n:Ljava/util/LinkedHashSet;

    new-instance p1, Ljava/util/LinkedHashMap;

    invoke-direct {p1}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/au2;->o:Ljava/util/LinkedHashMap;

    new-instance p1, Ljava/util/LinkedHashMap;

    invoke-direct {p1}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/au2;->q:Ljava/util/LinkedHashMap;

    new-instance p1, Llm0;

    invoke-direct {p1}, Llm0;-><init>()V

    new-instance p2, Lcom/google/android/libraries/ads/mobile/sdk/internal/util/AndroidBundleTypeAdapterFactory;

    invoke-direct {p2}, Lcom/google/android/libraries/ads/mobile/sdk/internal/util/AndroidBundleTypeAdapterFactory;-><init>()V

    invoke-virtual {p1, p2}, Llm0;->c(Lcom/google/android/libraries/ads/mobile/sdk/internal/util/AndroidBundleTypeAdapterFactory;)V

    new-instance p2, Lkm0;

    invoke-direct {p2, p1}, Lkm0;-><init>(Llm0;)V

    iput-object p2, p0, Lads_mobile_sdk/au2;->r:Lkm0;

    new-instance p1, Lfx0;

    invoke-direct {p1}, Lfx0;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/au2;->u:Lfx0;

    new-instance p1, Ljava/util/LinkedHashMap;

    invoke-direct {p1}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/au2;->v:Ljava/util/LinkedHashMap;

    return-void
.end method

.method public static a(Lads_mobile_sdk/au2;Lg32;Lads_mobile_sdk/mg2;Lads_mobile_sdk/hb2;Ljava/util/Map;Lwx;)Ljava/lang/Object;
    .registers 25

    .prologue
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p5

    instance-of v3, v2, Lads_mobile_sdk/ut2;

    if-eqz v3, :cond_19

    move-object v3, v2

    check-cast v3, Lads_mobile_sdk/ut2;

    iget v4, v3, Lads_mobile_sdk/ut2;->h:I

    const/high16 v5, -0x80000000

    and-int v6, v4, v5

    if-eqz v6, :cond_19

    sub-int/2addr v4, v5

    iput v4, v3, Lads_mobile_sdk/ut2;->h:I

    goto :goto_1e

    :cond_19
    new-instance v3, Lads_mobile_sdk/ut2;

    invoke-direct {v3, v0, v2}, Lads_mobile_sdk/ut2;-><init>(Lads_mobile_sdk/au2;Lwx;)V

    :goto_1e
    iget-object v2, v3, Lads_mobile_sdk/ut2;->f:Ljava/lang/Object;

    iget v4, v3, Lads_mobile_sdk/ut2;->h:I

    sget-object v6, Lba0;->a:Lba0;

    const/4 v13, 0x5

    const/4 v5, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x1

    const/4 v14, 0x0

    sget-object v15, Lwy;->a:Lwy;

    if-eqz v4, :cond_97

    if-eq v4, v9, :cond_7d

    if-eq v4, v8, :cond_6e

    if-eq v4, v7, :cond_5f

    if-eq v4, v5, :cond_50

    if-ne v4, v13, :cond_4a

    iget-object v0, v3, Lads_mobile_sdk/ut2;->b:Ljava/lang/Object;

    move-object v1, v0

    check-cast v1, Ljava/io/Closeable;

    iget-object v0, v3, Lads_mobile_sdk/ut2;->a:Ljava/lang/Object;

    move-object v3, v0

    check-cast v3, Lads_mobile_sdk/rg3;

    :try_start_42
    invoke-static {v2}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_45
    .catchall {:try_start_42 .. :try_end_45} :catchall_47

    goto/16 :goto_2cb

    :catchall_47
    move-exception v0

    goto/16 :goto_2dc

    :cond_4a
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {v0}, Lz6;->w(Ljava/lang/String;)V

    return-object v14

    :cond_50
    iget-object v0, v3, Lads_mobile_sdk/ut2;->b:Ljava/lang/Object;

    move-object v1, v0

    check-cast v1, Ljava/io/Closeable;

    iget-object v0, v3, Lads_mobile_sdk/ut2;->a:Ljava/lang/Object;

    move-object v3, v0

    check-cast v3, Lads_mobile_sdk/rg3;

    :try_start_5a
    invoke-static {v2}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_5d
    .catchall {:try_start_5a .. :try_end_5d} :catchall_47

    goto/16 :goto_28e

    :cond_5f
    iget-object v0, v3, Lads_mobile_sdk/ut2;->b:Ljava/lang/Object;

    move-object v1, v0

    check-cast v1, Ljava/io/Closeable;

    iget-object v0, v3, Lads_mobile_sdk/ut2;->a:Ljava/lang/Object;

    move-object v3, v0

    check-cast v3, Lads_mobile_sdk/rg3;

    :try_start_69
    invoke-static {v2}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_6c
    .catchall {:try_start_69 .. :try_end_6c} :catchall_47

    goto/16 :goto_25e

    :cond_6e
    iget-object v0, v3, Lads_mobile_sdk/ut2;->b:Ljava/lang/Object;

    move-object v1, v0

    check-cast v1, Ljava/io/Closeable;

    iget-object v0, v3, Lads_mobile_sdk/ut2;->a:Ljava/lang/Object;

    move-object v3, v0

    check-cast v3, Lads_mobile_sdk/rg3;

    :try_start_78
    invoke-static {v2}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_7b
    .catchall {:try_start_78 .. :try_end_7b} :catchall_47

    goto/16 :goto_195

    :cond_7d
    iget-object v1, v3, Lads_mobile_sdk/ut2;->e:Lads_mobile_sdk/rg3;

    iget-object v4, v3, Lads_mobile_sdk/ut2;->d:Lads_mobile_sdk/rg3;

    iget-object v0, v3, Lads_mobile_sdk/ut2;->c:Lads_mobile_sdk/hb2;

    iget-object v10, v3, Lads_mobile_sdk/ut2;->b:Ljava/lang/Object;

    check-cast v10, Lg32;

    iget-object v11, v3, Lads_mobile_sdk/ut2;->a:Ljava/lang/Object;

    check-cast v11, Lads_mobile_sdk/au2;

    :try_start_8b
    invoke-static {v2}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_8e
    .catchall {:try_start_8b .. :try_end_8e} :catchall_93

    move-object v2, v4

    move-object v4, v0

    move-object v0, v11

    goto/16 :goto_14c

    :catchall_93
    move-exception v0

    move-object v3, v4

    goto/16 :goto_2dc

    :cond_97
    invoke-static {v2}, Lt12;->W(Ljava/lang/Object;)V

    sget-object v2, Lads_mobile_sdk/fw0;->v1:Lads_mobile_sdk/fw0;

    invoke-static {v2, v6, v9}, Lads_mobile_sdk/hh3;->a(Lads_mobile_sdk/fw0;Ljava/util/List;Z)Lads_mobile_sdk/rg3;

    move-result-object v2

    move-object/from16 v4, p4

    :try_start_a2
    iput-object v4, v0, Lads_mobile_sdk/au2;->p:Ljava/util/Map;

    iput-object v1, v0, Lads_mobile_sdk/au2;->s:Lg32;

    invoke-virtual {v0}, Lads_mobile_sdk/au2;->f()V

    iget-object v4, v0, Lads_mobile_sdk/au2;->r:Lkm0;

    invoke-virtual {v4, v1}, Lkm0;->j(Ljava/lang/Object;)Lkw0;

    move-result-object v4

    invoke-virtual {v4}, Lkw0;->h()Lfx0;

    move-result-object v4

    iput-object v4, v0, Lads_mobile_sdk/au2;->t:Lfx0;

    move-object/from16 v4, p2

    invoke-virtual {v0, v4}, Lads_mobile_sdk/au2;->a(Lads_mobile_sdk/mg2;)V

    iget-object v4, v0, Lads_mobile_sdk/au2;->v:Ljava/util/LinkedHashMap;

    invoke-virtual {v4}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    move-result-object v4

    const/16 v10, 0xa

    invoke-static {v4, v10}, Lds;->Y(Ljava/lang/Iterable;I)I

    move-result v10

    invoke-static {v10}, Lb61;->Q(I)I

    move-result v10

    const/16 v11, 0x10

    if-ge v10, v11, :cond_cf

    move v10, v11

    :cond_cf
    new-instance v11, Ljava/util/LinkedHashMap;

    invoke-direct {v11, v10}, Ljava/util/LinkedHashMap;-><init>(I)V

    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_d8
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_132

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/Map$Entry;

    invoke-interface {v10}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v12

    invoke-interface {v10}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Lads_mobile_sdk/n33;

    invoke-virtual {v10}, Lads_mobile_sdk/n33;->t()Z

    move-result v16

    if-eqz v16, :cond_103

    invoke-virtual {v10}, Lads_mobile_sdk/n33;->o()Z

    move-result v10

    if-eqz v10, :cond_100

    const-string v10, "1"

    goto :goto_12e

    :catchall_fd
    move-exception v0

    goto/16 :goto_2de

    :cond_100
    const-string v10, "0"

    goto :goto_12e

    :cond_103
    invoke-virtual {v10}, Lads_mobile_sdk/n33;->w()Z

    move-result v16

    if-eqz v16, :cond_10e

    invoke-virtual {v10}, Lads_mobile_sdk/n33;->s()Ljava/lang/String;

    move-result-object v10

    goto :goto_12e

    :cond_10e
    invoke-virtual {v10}, Lads_mobile_sdk/n33;->u()Z

    move-result v16

    if-eqz v16, :cond_11d

    invoke-virtual {v10}, Lads_mobile_sdk/n33;->q()D

    move-result-wide v16

    invoke-static/range {v16 .. v17}, Ljava/lang/String;->valueOf(D)Ljava/lang/String;

    move-result-object v10

    goto :goto_12e

    :cond_11d
    invoke-virtual {v10}, Lads_mobile_sdk/n33;->v()Z

    move-result v16

    if-eqz v16, :cond_12c

    invoke-virtual {v10}, Lads_mobile_sdk/n33;->r()J

    move-result-wide v16

    invoke-static/range {v16 .. v17}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v10

    goto :goto_12e

    :cond_12c
    const-string v10, ""

    :goto_12e
    invoke-interface {v11, v12, v10}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_d8

    :cond_132
    iput-object v11, v1, Lg32;->Q1:Ljava/util/Map;

    iput-object v0, v3, Lads_mobile_sdk/ut2;->a:Ljava/lang/Object;

    iput-object v1, v3, Lads_mobile_sdk/ut2;->b:Ljava/lang/Object;

    move-object/from16 v4, p3

    iput-object v4, v3, Lads_mobile_sdk/ut2;->c:Lads_mobile_sdk/hb2;

    iput-object v2, v3, Lads_mobile_sdk/ut2;->d:Lads_mobile_sdk/rg3;

    iput-object v2, v3, Lads_mobile_sdk/ut2;->e:Lads_mobile_sdk/rg3;

    iput v9, v3, Lads_mobile_sdk/ut2;->h:I

    invoke-virtual {v0, v3}, Lads_mobile_sdk/au2;->a(Lwx;)Ljava/lang/Object;

    move-result-object v10
    :try_end_146
    .catchall {:try_start_a2 .. :try_end_146} :catchall_fd

    if-ne v10, v15, :cond_14a

    goto/16 :goto_2c8

    :cond_14a
    move-object v10, v1

    move-object v1, v2

    :goto_14c
    :try_start_14c
    iget-object v11, v0, Lads_mobile_sdk/au2;->u:Lfx0;

    iget-object v12, v0, Lads_mobile_sdk/au2;->n:Ljava/util/LinkedHashSet;

    iput-object v11, v10, Lg32;->T1:Lfx0;

    iget-object v11, v0, Lads_mobile_sdk/au2;->r:Lkm0;

    invoke-virtual {v11, v10}, Lkm0;->j(Ljava/lang/Object;)Lkw0;

    move-result-object v11

    invoke-virtual {v11}, Lkw0;->h()Lfx0;

    move-result-object v11

    iput-object v11, v0, Lads_mobile_sdk/au2;->t:Lfx0;

    invoke-virtual {v4}, Lads_mobile_sdk/hb2;->q()Lw63;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_166
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_19d

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lads_mobile_sdk/fb2;

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0, v11}, Lads_mobile_sdk/au2;->b(Lads_mobile_sdk/fb2;)Lb13;

    move-result-object v11

    instance-of v13, v11, Lads_mobile_sdk/av0;

    if-eqz v13, :cond_199

    check-cast v11, Lads_mobile_sdk/av0;

    iput-object v2, v3, Lads_mobile_sdk/ut2;->a:Ljava/lang/Object;

    iput-object v1, v3, Lads_mobile_sdk/ut2;->b:Ljava/lang/Object;

    iput-object v14, v3, Lads_mobile_sdk/ut2;->c:Lads_mobile_sdk/hb2;

    iput-object v14, v3, Lads_mobile_sdk/ut2;->d:Lads_mobile_sdk/rg3;

    iput-object v14, v3, Lads_mobile_sdk/ut2;->e:Lads_mobile_sdk/rg3;

    iput v8, v3, Lads_mobile_sdk/ut2;->h:I

    invoke-virtual {v0, v11, v3}, Lads_mobile_sdk/au2;->a(Lb13;Lwx;)Ljava/lang/Object;

    move-result-object v0
    :try_end_18f
    .catchall {:try_start_14c .. :try_end_18f} :catchall_234

    if-ne v0, v15, :cond_193

    goto/16 :goto_2c8

    :cond_193
    move-object v3, v2

    move-object v2, v0

    :goto_195
    :try_start_195
    check-cast v2, Lb13;
    :try_end_197
    .catchall {:try_start_195 .. :try_end_197} :catchall_47

    goto/16 :goto_2cd

    :cond_199
    :try_start_199
    check-cast v11, Lads_mobile_sdk/hv0;

    const/4 v13, 0x5

    goto :goto_166

    :cond_19d
    invoke-virtual {v0}, Lads_mobile_sdk/au2;->g()V

    iget-object v4, v0, Lads_mobile_sdk/au2;->q:Ljava/util/LinkedHashMap;

    invoke-virtual {v4}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_1aa
    :goto_1aa
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_1d8

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/util/Map$Entry;

    invoke-interface {v8}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    invoke-interface {v8}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/StringBuilder;

    invoke-interface {v12}, Ljava/util/Set;->isEmpty()Z

    move-result v13

    if-nez v13, :cond_1ce

    invoke-interface {v12, v11}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_1aa

    :cond_1ce
    iget-object v13, v0, Lads_mobile_sdk/au2;->o:Ljava/util/LinkedHashMap;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-interface {v13, v11, v8}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_1aa

    :cond_1d8
    iget-object v4, v10, Lg32;->o1:Landroid/os/Bundle;

    if-eqz v4, :cond_1e6

    const-string v8, "_testRequestUri"

    invoke-virtual {v4, v8}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    if-eqz v4, :cond_1e6

    iput-object v4, v0, Lads_mobile_sdk/au2;->j:Ljava/lang/String;

    :cond_1e6
    iget-object v4, v10, Lg32;->N1:Ljava/lang/Boolean;

    sget-object v8, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-static {v4, v8}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_1f5

    invoke-virtual {v0}, Lads_mobile_sdk/au2;->b()Landroid/net/Uri;

    move-result-object v8

    goto :goto_1f9

    :cond_1f5
    invoke-virtual {v0}, Lads_mobile_sdk/au2;->a()Landroid/net/Uri;

    move-result-object v8

    :goto_1f9
    if-nez v4, :cond_237

    invoke-virtual {v8}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/String;->length()I

    move-result v10

    iget-object v11, v0, Lads_mobile_sdk/au2;->a:Lads_mobile_sdk/qr0;

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v12, "gads:url_size_to_post"

    const/16 v13, 0x3a98

    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v13

    sget-object v5, Lads_mobile_sdk/fo;->a$11:Lads_mobile_sdk/fo;

    invoke-virtual {v11, v12, v13, v5}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Number;

    invoke-virtual {v5}, Ljava/lang/Number;->intValue()I

    move-result v5

    if-lt v10, v5, :cond_237

    invoke-virtual {v8}, Landroid/net/Uri;->getEncodedQuery()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v8}, Landroid/net/Uri;->buildUpon()Landroid/net/Uri$Builder;

    move-result-object v8

    invoke-virtual {v8}, Landroid/net/Uri$Builder;->clearQuery()Landroid/net/Uri$Builder;

    move-result-object v8

    invoke-virtual {v8}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object v8

    move-object/from16 v18, v8

    move-object v8, v5

    move-object/from16 v5, v18

    goto :goto_239

    :catchall_234
    move-exception v0

    goto/16 :goto_2df

    :cond_237
    move-object v5, v8

    move-object v8, v14

    :goto_239
    if-eqz v4, :cond_297

    invoke-virtual {v5}, Landroid/net/Uri;->getQuery()Ljava/lang/String;

    move-result-object v4

    if-nez v4, :cond_262

    new-instance v4, Lads_mobile_sdk/ev0;

    const-string v5, "Csrb scar query result is empty"

    invoke-direct {v4, v5, v9}, Lads_mobile_sdk/ev0;-><init>(Ljava/lang/String;I)V

    iput-object v2, v3, Lads_mobile_sdk/ut2;->a:Ljava/lang/Object;

    iput-object v1, v3, Lads_mobile_sdk/ut2;->b:Ljava/lang/Object;

    iput-object v14, v3, Lads_mobile_sdk/ut2;->c:Lads_mobile_sdk/hb2;

    iput-object v14, v3, Lads_mobile_sdk/ut2;->d:Lads_mobile_sdk/rg3;

    iput-object v14, v3, Lads_mobile_sdk/ut2;->e:Lads_mobile_sdk/rg3;

    iput v7, v3, Lads_mobile_sdk/ut2;->h:I

    invoke-virtual {v0, v4, v3}, Lads_mobile_sdk/au2;->a(Lb13;Lwx;)Ljava/lang/Object;

    move-result-object v0
    :try_end_258
    .catchall {:try_start_199 .. :try_end_258} :catchall_234

    if-ne v0, v15, :cond_25c

    goto/16 :goto_2c8

    :cond_25c
    move-object v3, v2

    move-object v2, v0

    :goto_25e
    :try_start_25e
    check-cast v2, Lb13;
    :try_end_260
    .catchall {:try_start_25e .. :try_end_260} :catchall_47

    goto/16 :goto_2cd

    :cond_262
    :try_start_262
    iget-object v5, v0, Lads_mobile_sdk/au2;->d:Lads_mobile_sdk/wp;

    invoke-virtual {v5, v4}, Lads_mobile_sdk/wp;->a(Ljava/lang/String;)Lb13;

    move-result-object v4

    instance-of v5, v4, Lads_mobile_sdk/hv0;

    if-eqz v5, :cond_274

    check-cast v4, Lads_mobile_sdk/hv0;

    iget-object v4, v4, Lads_mobile_sdk/hv0;->b:Ljava/lang/Object;

    check-cast v4, Ljava/lang/String;

    :goto_272
    move-object v10, v4

    goto :goto_29f

    :cond_274
    instance-of v5, v4, Lads_mobile_sdk/av0;

    if-eqz v5, :cond_291

    iput-object v2, v3, Lads_mobile_sdk/ut2;->a:Ljava/lang/Object;

    iput-object v1, v3, Lads_mobile_sdk/ut2;->b:Ljava/lang/Object;

    iput-object v14, v3, Lads_mobile_sdk/ut2;->c:Lads_mobile_sdk/hb2;

    iput-object v14, v3, Lads_mobile_sdk/ut2;->d:Lads_mobile_sdk/rg3;

    iput-object v14, v3, Lads_mobile_sdk/ut2;->e:Lads_mobile_sdk/rg3;

    const/4 v5, 0x4

    iput v5, v3, Lads_mobile_sdk/ut2;->h:I

    invoke-virtual {v0, v4, v3}, Lads_mobile_sdk/au2;->a(Lb13;Lwx;)Ljava/lang/Object;

    move-result-object v0
    :try_end_289
    .catchall {:try_start_262 .. :try_end_289} :catchall_234

    if-ne v0, v15, :cond_28c

    goto :goto_2c8

    :cond_28c
    move-object v3, v2

    move-object v2, v0

    :goto_28e
    :try_start_28e
    check-cast v2, Lb13;
    :try_end_290
    .catchall {:try_start_28e .. :try_end_290} :catchall_47

    goto :goto_2cd

    :cond_291
    :try_start_291
    new-instance v0, Lft;

    invoke-direct {v0}, Ljava/lang/RuntimeException;-><init>()V

    throw v0

    :cond_297
    invoke-virtual {v5}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    goto :goto_272

    :goto_29f
    new-instance v4, Lads_mobile_sdk/hv0;

    new-instance v5, Lads_mobile_sdk/uq;

    iget-boolean v9, v0, Lads_mobile_sdk/au2;->l:Z

    invoke-virtual {v0}, Lads_mobile_sdk/au2;->b()Landroid/net/Uri;

    move-result-object v7

    invoke-virtual {v7}, Landroid/net/Uri;->getQuery()Ljava/lang/String;

    move-result-object v11

    const/4 v12, 0x0

    const/4 v7, 0x0

    invoke-direct/range {v5 .. v12}, Lads_mobile_sdk/uq;-><init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;ZLjava/lang/String;Ljava/lang/String;Ljava/util/List;)V

    invoke-direct {v4, v5}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    iput-object v2, v3, Lads_mobile_sdk/ut2;->a:Ljava/lang/Object;

    iput-object v1, v3, Lads_mobile_sdk/ut2;->b:Ljava/lang/Object;

    iput-object v14, v3, Lads_mobile_sdk/ut2;->c:Lads_mobile_sdk/hb2;

    iput-object v14, v3, Lads_mobile_sdk/ut2;->d:Lads_mobile_sdk/rg3;

    iput-object v14, v3, Lads_mobile_sdk/ut2;->e:Lads_mobile_sdk/rg3;

    const/4 v5, 0x5

    iput v5, v3, Lads_mobile_sdk/ut2;->h:I

    invoke-virtual {v0, v4, v3}, Lads_mobile_sdk/au2;->a(Lb13;Lwx;)Ljava/lang/Object;

    move-result-object v0
    :try_end_2c6
    .catchall {:try_start_291 .. :try_end_2c6} :catchall_234

    if-ne v0, v15, :cond_2c9

    :goto_2c8
    return-object v15

    :cond_2c9
    move-object v3, v2

    move-object v2, v0

    :goto_2cb
    :try_start_2cb
    check-cast v2, Lb13;

    :goto_2cd
    instance-of v0, v2, Lads_mobile_sdk/av0;

    if-eqz v0, :cond_2d8

    move-object v0, v2

    check-cast v0, Lads_mobile_sdk/av0;

    const/4 v4, 0x0

    invoke-static {v0, v4}, Lads_mobile_sdk/xh3;->a(Lads_mobile_sdk/av0;Z)V
    :try_end_2d8
    .catchall {:try_start_2cb .. :try_end_2d8} :catchall_47

    :cond_2d8
    invoke-static {v1, v14}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object v2

    :goto_2dc
    move-object v2, v3

    goto :goto_2df

    :goto_2de
    move-object v1, v2

    :goto_2df
    :try_start_2df
    invoke-virtual {v2, v0}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v3, v0, Lox2;

    if-nez v3, :cond_30f

    invoke-virtual {v2, v0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of v2, v0, Lza2;

    if-nez v2, :cond_307

    instance-of v2, v0, Ljava/util/concurrent/CancellationException;

    if-nez v2, :cond_2ff

    instance-of v2, v0, Lads_mobile_sdk/mv0;

    if-eqz v2, :cond_2f9

    throw v0

    :catchall_2f6
    move-exception v0

    move-object v2, v0

    goto :goto_310

    :cond_2f9
    new-instance v2, Lads_mobile_sdk/tu0;

    invoke-direct {v2, v0}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw v2

    :cond_2ff
    new-instance v2, Lads_mobile_sdk/ou0;

    check-cast v0, Ljava/util/concurrent/CancellationException;

    invoke-direct {v2, v0}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw v2

    :cond_307
    new-instance v2, Lads_mobile_sdk/uw0;

    check-cast v0, Lza2;

    invoke-direct {v2, v0}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw v2

    :cond_30f
    throw v0
    :try_end_310
    .catchall {:try_start_2df .. :try_end_310} :catchall_2f6

    :goto_310
    :try_start_310
    throw v2
    :try_end_311
    .catchall {:try_start_310 .. :try_end_311} :catchall_311

    :catchall_311
    move-exception v0

    invoke-static {v1, v2}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0
.end method


# virtual methods
.method public final a()Landroid/net/Uri;
    .registers 9

    .prologue
    new-instance v0, Landroid/net/Uri$Builder;

    invoke-direct {v0}, Landroid/net/Uri$Builder;-><init>()V

    iget-object v1, p0, Lads_mobile_sdk/au2;->m:Ljava/util/LinkedHashSet;

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_b
    :goto_b
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    iget-object v4, p0, Lads_mobile_sdk/au2;->o:Ljava/util/LinkedHashMap;

    if-eqz v3, :cond_25

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-virtual {v4, v3}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    if-eqz v4, :cond_b

    invoke-static {v0, v3, v4}, Lw53;->j(Landroid/net/Uri$Builder;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_b

    :cond_25
    invoke-virtual {v0}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object v0

    invoke-virtual {v0}, Landroid/net/Uri;->getQuery()Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_31

    const-string v0, ""

    :cond_31
    iget-object v2, p0, Lads_mobile_sdk/au2;->d:Lads_mobile_sdk/wp;

    invoke-virtual {v2, v0}, Lads_mobile_sdk/wp;->a(Ljava/lang/String;)Lb13;

    move-result-object v0

    instance-of v2, v0, Lads_mobile_sdk/hv0;

    const/4 v3, 0x0

    if-eqz v2, :cond_3f

    check-cast v0, Lads_mobile_sdk/hv0;

    goto :goto_40

    :cond_3f
    move-object v0, v3

    :goto_40
    if-eqz v0, :cond_47

    iget-object v0, v0, Lads_mobile_sdk/hv0;->b:Ljava/lang/Object;

    move-object v3, v0

    check-cast v3, Ljava/lang/String;

    :cond_47
    iget-object v0, p0, Lads_mobile_sdk/au2;->j:Ljava/lang/String;

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    invoke-virtual {v0}, Landroid/net/Uri;->buildUpon()Landroid/net/Uri$Builder;

    move-result-object v0

    invoke-virtual {v4}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_59
    :goto_59
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_90

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/util/Map$Entry;

    invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    iget-object v6, p0, Lads_mobile_sdk/au2;->n:Ljava/util/LinkedHashSet;

    invoke-interface {v6}, Ljava/util/Set;->isEmpty()Z

    move-result v7

    if-nez v7, :cond_7f

    invoke-interface {v6, v5}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_59

    :cond_7f
    invoke-interface {v1, v5}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_8c

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v0, v5, v4}, Lw53;->j(Landroid/net/Uri$Builder;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_59

    :cond_8c
    invoke-interface {v1, v5}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    goto :goto_59

    :cond_90
    if-eqz v3, :cond_ac

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v1

    if-lez v1, :cond_ac

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v1, "blob"

    sget-object v2, Lads_mobile_sdk/fo;->a$23:Lads_mobile_sdk/fo;

    iget-object p0, p0, Lads_mobile_sdk/au2;->a:Lads_mobile_sdk/qr0;

    const-string v4, "gads:blob_url_key"

    invoke-virtual {p0, v4, v1, v2}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    invoke-static {v0, p0, v3}, Lw53;->j(Landroid/net/Uri$Builder;Ljava/lang/String;Ljava/lang/String;)V

    :cond_ac
    invoke-virtual {v0}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object p0
.end method

.method public final a(Lb13;Lwx;)Ljava/lang/Object;
    .registers 12

    .prologue
    instance-of v0, p2, Lads_mobile_sdk/yt2;

    if-eqz v0, :cond_13

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/yt2;

    iget v1, v0, Lads_mobile_sdk/yt2;->e:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/yt2;->e:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/yt2;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/yt2;-><init>(Lads_mobile_sdk/au2;Lwx;)V

    :goto_18
    iget-object p2, v0, Lads_mobile_sdk/yt2;->c:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/yt2;->e:I

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    sget-object v5, Lwy;->a:Lwy;

    if-eqz v1, :cond_47

    if-eq v1, v4, :cond_3a

    if-ne v1, v3, :cond_34

    iget-object p0, v0, Lads_mobile_sdk/yt2;->b:Ljava/lang/Object;

    check-cast p0, Lw43;

    iget-object p1, v0, Lads_mobile_sdk/yt2;->a:Ljava/lang/Object;

    check-cast p1, Lb13;

    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    goto/16 :goto_110

    :cond_34
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v2

    :cond_3a
    iget-object p0, v0, Lads_mobile_sdk/yt2;->b:Ljava/lang/Object;

    move-object p1, p0

    check-cast p1, Lb13;

    iget-object p0, v0, Lads_mobile_sdk/yt2;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/au2;

    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_62

    :cond_47
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p2, p0, Lads_mobile_sdk/au2;->a:Lads_mobile_sdk/qr0;

    iget p2, p2, Lads_mobile_sdk/qr0;->y:I

    if-eq p2, v3, :cond_6c

    if-ne p2, v4, :cond_6b

    iput-object p0, v0, Lads_mobile_sdk/yt2;->a:Ljava/lang/Object;

    iput-object p1, v0, Lads_mobile_sdk/yt2;->b:Ljava/lang/Object;

    iput v4, v0, Lads_mobile_sdk/yt2;->e:I

    iget-object p2, p0, Lads_mobile_sdk/au2;->g:Lads_mobile_sdk/bk1;

    invoke-virtual {p2, v0}, Lads_mobile_sdk/al0;->c(Lwx;)Ljava/lang/Object;

    move-result-object p2

    if-ne p2, v5, :cond_62

    goto/16 :goto_10e

    :cond_62
    :goto_62
    check-cast p2, Ljava/lang/Boolean;

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    if-eqz p2, :cond_6b

    goto :goto_6c

    :cond_6b
    const/4 v4, 0x0

    :cond_6c
    :goto_6c
    if-nez v4, :cond_6f

    return-object p1

    :cond_6f
    new-instance p2, Lfx0;

    invoke-direct {p2}, Lfx0;-><init>()V

    iget-object v1, p0, Lads_mobile_sdk/au2;->t:Lfx0;

    if-eqz v1, :cond_142

    const-string v4, "signals"

    invoke-virtual {p2, v4, v1}, Lfx0;->o(Ljava/lang/String;Lkw0;)V

    instance-of v1, p1, Lads_mobile_sdk/ev0;

    const-string v4, "error"

    if-eqz v1, :cond_8c

    move-object v1, p1

    check-cast v1, Lads_mobile_sdk/ev0;

    iget-object v1, v1, Lads_mobile_sdk/ev0;->c:Ljava/lang/String;

    invoke-virtual {p2, v4, v1}, Lfx0;->s(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_f5

    :cond_8c
    instance-of v1, p1, Lads_mobile_sdk/av0;

    if-eqz v1, :cond_98

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p2, v4, v1}, Lfx0;->s(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_f5

    :cond_98
    instance-of v1, p1, Lads_mobile_sdk/hv0;

    if-eqz v1, :cond_f5

    move-object v1, p1

    check-cast v1, Lads_mobile_sdk/hv0;

    iget-object v1, v1, Lads_mobile_sdk/hv0;->b:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/uq;

    iget-boolean v4, v1, Lads_mobile_sdk/uq;->d:Z

    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v4

    const-string v6, "cookies_include"

    invoke-virtual {p2, v6, v4}, Lfx0;->r(Ljava/lang/String;Ljava/lang/Boolean;)V

    iget-object v4, v1, Lads_mobile_sdk/uq;->e:Ljava/lang/String;

    const-string v6, "url"

    invoke-virtual {p2, v6, v4}, Lfx0;->s(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v4, Lfx0;

    invoke-direct {v4}, Lfx0;-><init>()V

    iget-object v6, p0, Lads_mobile_sdk/au2;->o:Ljava/util/LinkedHashMap;

    invoke-virtual {v6}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    move-result-object v6

    invoke-interface {v6}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v6

    :goto_c4
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_e0

    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/util/Map$Entry;

    invoke-interface {v7}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    invoke-interface {v7}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    invoke-virtual {v4, v8, v7}, Lfx0;->s(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_c4

    :cond_e0
    const-string v6, "c_params"

    invoke-virtual {p2, v6, v4}, Lfx0;->o(Ljava/lang/String;Lkw0;)V

    iget-object v1, v1, Lads_mobile_sdk/uq;->c:Ljava/lang/String;

    if-eqz v1, :cond_f5

    const-string v4, "post_body"

    invoke-virtual {p2, v4, v1}, Lfx0;->s(Ljava/lang/String;Ljava/lang/String;)V

    const-string v1, "content_type"

    const-string v4, "text/plain"

    invoke-virtual {p2, v1, v4}, Lfx0;->s(Ljava/lang/String;Ljava/lang/String;)V

    :cond_f5
    :goto_f5
    iget-object p0, p0, Lads_mobile_sdk/au2;->g:Lads_mobile_sdk/bk1;

    iput-object p1, v0, Lads_mobile_sdk/yt2;->a:Ljava/lang/Object;

    sget-object v1, Lads_mobile_sdk/uq;->h:Lw43;

    iput-object v1, v0, Lads_mobile_sdk/yt2;->b:Ljava/lang/Object;

    iput v3, v0, Lads_mobile_sdk/yt2;->e:I

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Lkw0;->toString()Ljava/lang/String;

    move-result-object p2

    const-string v3, "google.afma.request.patchCSRB"

    invoke-virtual {p0, v3, p2, v0}, Lads_mobile_sdk/al0;->a(Ljava/lang/String;Ljava/lang/String;Lwx;)Ljava/lang/Object;

    move-result-object p2

    if-ne p2, v5, :cond_10f

    :goto_10e
    return-object v5

    :cond_10f
    move-object p0, v1

    :goto_110
    check-cast p2, Lb13;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p2}, Lw43;->a(Lb13;)Lb13;

    move-result-object p0

    instance-of p2, p0, Lads_mobile_sdk/av0;

    if-eqz p2, :cond_11e

    return-object p0

    :cond_11e
    instance-of p2, p0, Lads_mobile_sdk/hv0;

    if-eqz p2, :cond_13e

    move-object p2, p0

    check-cast p2, Lads_mobile_sdk/hv0;

    iget-object p2, p2, Lads_mobile_sdk/hv0;->b:Ljava/lang/Object;

    check-cast p2, Lads_mobile_sdk/uq;

    instance-of v0, p1, Lads_mobile_sdk/hv0;

    if-eqz v0, :cond_130

    check-cast p1, Lads_mobile_sdk/hv0;

    goto :goto_131

    :cond_130
    move-object p1, v2

    :goto_131
    if-eqz p1, :cond_13b

    iget-object p1, p1, Lads_mobile_sdk/hv0;->b:Ljava/lang/Object;

    check-cast p1, Lads_mobile_sdk/uq;

    if-eqz p1, :cond_13b

    iget-object v2, p1, Lads_mobile_sdk/uq;->f:Ljava/lang/String;

    :cond_13b
    iput-object v2, p2, Lads_mobile_sdk/uq;->f:Ljava/lang/String;

    return-object p0

    :cond_13e
    invoke-static {}, Ldm2;->q()V

    return-object v2

    :cond_142
    const-string p0, "signalJson"

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v2
.end method

.method public final a(Lwx;)Ljava/lang/Object;
    .registers 28

    .prologue
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    sget-object v2, Lads_mobile_sdk/fo;->a$23:Lads_mobile_sdk/fo;

    instance-of v3, v1, Lads_mobile_sdk/wt2;

    if-eqz v3, :cond_19

    move-object v3, v1

    check-cast v3, Lads_mobile_sdk/wt2;

    iget v4, v3, Lads_mobile_sdk/wt2;->d:I

    const/high16 v5, -0x80000000

    and-int v6, v4, v5

    if-eqz v6, :cond_19

    sub-int/2addr v4, v5

    iput v4, v3, Lads_mobile_sdk/wt2;->d:I

    goto :goto_1e

    :cond_19
    new-instance v3, Lads_mobile_sdk/wt2;

    invoke-direct {v3, v0, v1}, Lads_mobile_sdk/wt2;-><init>(Lads_mobile_sdk/au2;Lwx;)V

    :goto_1e
    iget-object v1, v3, Lads_mobile_sdk/wt2;->b:Ljava/lang/Object;

    iget v4, v3, Lads_mobile_sdk/wt2;->d:I

    const-string v5, "."

    const-string v6, "signals"

    const/4 v7, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x0

    if-eqz v4, :cond_3c

    if-ne v4, v8, :cond_36

    iget-object v0, v3, Lads_mobile_sdk/wt2;->a:Lads_mobile_sdk/au2;

    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V

    move-object/from16 p1, v9

    goto/16 :goto_49c

    :cond_36
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {v0}, Lz6;->w(Ljava/lang/String;)V

    return-object v9

    :cond_3c
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V

    sget-object v1, Lads_mobile_sdk/aq;->Fd:Lads_mobile_sdk/aq;

    invoke-virtual {v1}, Lads_mobile_sdk/aq;->b()Ljava/lang/String;

    move-result-object v1

    iget-object v4, v0, Lads_mobile_sdk/au2;->v:Ljava/util/LinkedHashMap;

    invoke-virtual {v4, v1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lads_mobile_sdk/n33;

    if-eqz v1, :cond_54

    invoke-virtual {v1}, Lads_mobile_sdk/n33;->o()Z

    move-result v1

    goto :goto_55

    :cond_54
    move v1, v7

    :goto_55
    sget-object v10, Lads_mobile_sdk/aq;->Zj:Lads_mobile_sdk/aq;

    invoke-virtual {v10}, Lads_mobile_sdk/aq;->b()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v4, v10}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Lads_mobile_sdk/n33;

    if-eqz v10, :cond_68

    invoke-virtual {v10}, Lads_mobile_sdk/n33;->o()Z

    move-result v10

    goto :goto_69

    :cond_68
    move v10, v7

    :goto_69
    iget-object v11, v0, Lads_mobile_sdk/au2;->s:Lg32;

    if-eqz v11, :cond_590

    iget-object v11, v11, Lg32;->m0:Landroid/os/Bundle;

    const-string v12, "IABTCF_CmpSdkID"

    invoke-virtual {v11, v12, v7}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    move-result v11

    const/16 v12, 0x12c

    if-ne v11, v12, :cond_7b

    move v11, v8

    goto :goto_7c

    :cond_7b
    move v11, v7

    :goto_7c
    if-eqz v10, :cond_80

    const/4 v10, 0x2

    goto :goto_81

    :cond_80
    move v10, v7

    :goto_81
    if-eqz v1, :cond_85

    or-int/lit8 v10, v10, 0x8

    :cond_85
    if-eqz v11, :cond_89

    or-int/lit16 v10, v10, 0x80

    :cond_89
    sget-object v1, Lads_mobile_sdk/aq;->z8:Lads_mobile_sdk/aq;

    invoke-virtual {v1}, Lads_mobile_sdk/aq;->b()Ljava/lang/String;

    move-result-object v1

    new-instance v11, Ljava/lang/StringBuilder;

    const-string v13, "0.0.0.0.0.0.0."

    invoke-direct {v11, v13}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v11, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    iget-object v11, v0, Lads_mobile_sdk/au2;->u:Lfx0;

    invoke-virtual {v11, v1, v10}, Lfx0;->s(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v1, v0, Lads_mobile_sdk/au2;->e:Ljava/util/Optional;

    invoke-static {v1}, Lw53;->I(Ljava/util/Optional;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lxb1;

    const-string v10, "="

    const/16 v13, 0xa

    if-nez v1, :cond_b8

    move/from16 v18, v8

    move-object/from16 p1, v9

    const/16 v17, 0x2

    goto/16 :goto_23b

    :cond_b8
    invoke-static {}, Lads_mobile_sdk/vw1;->o()Lt53;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {v1}, Lxb1;->c()Z

    move-result v15

    if-eqz v15, :cond_db

    invoke-virtual {v14}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v15, v14, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v15, Lads_mobile_sdk/vw1;

    invoke-static {v15}, Lads_mobile_sdk/vw1;->c(Lads_mobile_sdk/vw1;)I

    move-result v16

    move-object/from16 p1, v9

    or-int/lit8 v9, v16, 0x10

    invoke-static {v15, v9}, Lads_mobile_sdk/vw1;->d(Lads_mobile_sdk/vw1;I)V

    invoke-static {v15}, Lads_mobile_sdk/vw1;->f(Lads_mobile_sdk/vw1;)V

    goto :goto_dd

    :cond_db
    move-object/from16 p1, v9

    :goto_dd
    invoke-interface {v1}, Lxb1;->i()Z

    move-result v9

    if-eqz v9, :cond_f6

    invoke-virtual {v14}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v9, v14, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v9, Lads_mobile_sdk/vw1;

    invoke-static {v9}, Lads_mobile_sdk/vw1;->c(Lads_mobile_sdk/vw1;)I

    move-result v15

    or-int/lit8 v15, v15, 0x4

    invoke-static {v9, v15}, Lads_mobile_sdk/vw1;->d(Lads_mobile_sdk/vw1;I)V

    invoke-static {v9}, Lads_mobile_sdk/vw1;->m(Lads_mobile_sdk/vw1;)V

    :cond_f6
    invoke-interface {v1}, Lxb1;->h()Lsb1;

    move-result-object v9

    sget-object v15, Lsb1;->a:Lsb1;

    if-eq v9, v15, :cond_119

    invoke-interface {v1}, Lxb1;->h()Lsb1;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v9

    sget-object v15, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v9, v15}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v14}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v15, v14, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v15, Lads_mobile_sdk/vw1;

    invoke-virtual {v15, v9}, Lads_mobile_sdk/vw1;->b(Ljava/lang/String;)V

    :cond_119
    invoke-interface {v1}, Lxb1;->g()Lt3;

    move-result-object v9

    iget v9, v9, Lt3;->a:I

    invoke-virtual {v14}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v15, v14, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v15, Lads_mobile_sdk/vw1;

    invoke-static {v15}, Lads_mobile_sdk/vw1;->c(Lads_mobile_sdk/vw1;)I

    move-result v16

    const/16 v17, 0x2

    or-int/lit8 v12, v16, 0x8

    invoke-static {v15, v12}, Lads_mobile_sdk/vw1;->d(Lads_mobile_sdk/vw1;I)V

    invoke-static {v15, v9}, Lads_mobile_sdk/vw1;->i(Lads_mobile_sdk/vw1;I)V

    invoke-interface {v1}, Lxb1;->d()Ltb1;

    move-result-object v9

    if-eqz v9, :cond_182

    invoke-static {}, Lads_mobile_sdk/xw1;->o()Ls63;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget v9, v9, Ltb1;->a:I

    invoke-virtual {v12}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v15, v12, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v15, Lads_mobile_sdk/xw1;

    invoke-static {v15}, Lads_mobile_sdk/xw1;->c(Lads_mobile_sdk/xw1;)I

    move-result v16

    move/from16 v18, v8

    or-int/lit8 v8, v16, 0x1

    invoke-static {v15, v8}, Lads_mobile_sdk/xw1;->d(Lads_mobile_sdk/xw1;I)V

    invoke-static {v15, v9}, Lads_mobile_sdk/xw1;->f(Lads_mobile_sdk/xw1;I)V

    invoke-interface {v1}, Lxb1;->j()Z

    move-result v8

    if-eqz v8, :cond_171

    invoke-virtual {v12}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v8, v12, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v8, Lads_mobile_sdk/xw1;

    invoke-static {v8}, Lads_mobile_sdk/xw1;->c(Lads_mobile_sdk/xw1;)I

    move-result v9

    or-int/lit8 v9, v9, 0x2

    invoke-static {v8, v9}, Lads_mobile_sdk/xw1;->d(Lads_mobile_sdk/xw1;I)V

    invoke-static {v8}, Lads_mobile_sdk/xw1;->g(Lads_mobile_sdk/xw1;)V

    :cond_171
    invoke-virtual {v12}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object v8

    check-cast v8, Lads_mobile_sdk/xw1;

    invoke-virtual {v14}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v9, v14, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v9, Lads_mobile_sdk/vw1;

    invoke-virtual {v9, v8}, Lads_mobile_sdk/vw1;->a(Lads_mobile_sdk/xw1;)V

    goto :goto_184

    :cond_182
    move/from16 v18, v8

    :goto_184
    invoke-interface {v1}, Lqh;->k()Ls4;

    move-result-object v8

    if-eqz v8, :cond_1b0

    invoke-virtual {v14}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v8, v14, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v8, Lads_mobile_sdk/vw1;

    invoke-static {v8}, Lads_mobile_sdk/vw1;->c(Lads_mobile_sdk/vw1;)I

    move-result v9

    or-int/lit16 v9, v9, 0x80

    invoke-static {v8, v9}, Lads_mobile_sdk/vw1;->d(Lads_mobile_sdk/vw1;I)V

    invoke-static {v8}, Lads_mobile_sdk/vw1;->h(Lads_mobile_sdk/vw1;)V

    invoke-virtual {v14}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v8, v14, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v8, Lads_mobile_sdk/vw1;

    invoke-static {v8}, Lads_mobile_sdk/vw1;->c(Lads_mobile_sdk/vw1;)I

    move-result v9

    or-int/lit8 v9, v9, 0x40

    invoke-static {v8, v9}, Lads_mobile_sdk/vw1;->d(Lads_mobile_sdk/vw1;I)V

    invoke-static {v8}, Lads_mobile_sdk/vw1;->g(Lads_mobile_sdk/vw1;)V

    :cond_1b0
    invoke-interface {v1}, Lqh;->e()Lpj2;

    move-result-object v1

    if-eqz v1, :cond_212

    invoke-static {}, Lads_mobile_sdk/zw1;->o()Lq73;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-boolean v9, v1, Lpj2;->a:Z

    if-eqz v9, :cond_1d4

    invoke-virtual {v8}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v9, v8, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v9, Lads_mobile_sdk/zw1;

    invoke-static {v9}, Lads_mobile_sdk/zw1;->c(Lads_mobile_sdk/zw1;)I

    move-result v12

    or-int/lit8 v12, v12, 0x1

    invoke-static {v9, v12}, Lads_mobile_sdk/zw1;->d(Lads_mobile_sdk/zw1;I)V

    invoke-static {v9}, Lads_mobile_sdk/zw1;->h(Lads_mobile_sdk/zw1;)V

    :cond_1d4
    iget-boolean v9, v1, Lpj2;->c:Z

    if-eqz v9, :cond_1eb

    invoke-virtual {v8}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v9, v8, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v9, Lads_mobile_sdk/zw1;

    invoke-static {v9}, Lads_mobile_sdk/zw1;->c(Lads_mobile_sdk/zw1;)I

    move-result v12

    or-int/lit8 v12, v12, 0x2

    invoke-static {v9, v12}, Lads_mobile_sdk/zw1;->d(Lads_mobile_sdk/zw1;I)V

    invoke-static {v9}, Lads_mobile_sdk/zw1;->f(Lads_mobile_sdk/zw1;)V

    :cond_1eb
    iget-boolean v1, v1, Lpj2;->b:Z

    if-eqz v1, :cond_202

    invoke-virtual {v8}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v1, v8, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v1, Lads_mobile_sdk/zw1;

    invoke-static {v1}, Lads_mobile_sdk/zw1;->c(Lads_mobile_sdk/zw1;)I

    move-result v9

    or-int/lit8 v9, v9, 0x4

    invoke-static {v1, v9}, Lads_mobile_sdk/zw1;->d(Lads_mobile_sdk/zw1;I)V

    invoke-static {v1}, Lads_mobile_sdk/zw1;->g(Lads_mobile_sdk/zw1;)V

    :cond_202
    invoke-virtual {v8}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object v1

    check-cast v1, Lads_mobile_sdk/zw1;

    invoke-virtual {v14}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v8, v14, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v8, Lads_mobile_sdk/vw1;

    invoke-virtual {v8, v1}, Lads_mobile_sdk/vw1;->a(Lads_mobile_sdk/zw1;)V

    :cond_212
    invoke-virtual {v14}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object v1

    check-cast v1, Lads_mobile_sdk/vw1;

    sget-object v8, Lads_mobile_sdk/aq;->jd:Lads_mobile_sdk/aq;

    iget-object v8, v8, Lads_mobile_sdk/aq;->a:Ljava/util/ArrayList;

    invoke-virtual {v8, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    invoke-virtual {v1}, Lads_mobile_sdk/g;->a()[B

    move-result-object v1

    invoke-static {v1, v13}, Landroid/util/Base64;->encode([BI)[B

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v9, Ljava/lang/String;

    sget-object v12, Lip;->a:Ljava/nio/charset/Charset;

    invoke-direct {v9, v1, v12}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    invoke-static {v9, v10, v5, v7}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v11, v8, v1}, Lfx0;->s(Ljava/lang/String;Ljava/lang/String;)V

    :goto_23b
    iget-object v1, v0, Lads_mobile_sdk/au2;->s:Lg32;

    if-eqz v1, :cond_58c

    iget-object v1, v1, Lg32;->I:Ljava/util/Set;

    if-eqz v1, :cond_281

    new-instance v8, Ljava/util/ArrayList;

    invoke-static {v1, v13}, Lds;->Y(Ljava/lang/Iterable;I)I

    move-result v9

    invoke-direct {v8, v9}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_250
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_264

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    invoke-static {v9}, Landroid/net/Uri;->encode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_250

    :cond_264
    new-instance v1, Lvv0;

    invoke-direct {v1}, Lvv0;-><init>()V

    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    move-result v9

    move v12, v7

    :goto_26e
    if-ge v12, v9, :cond_27c

    invoke-virtual {v8, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v13

    add-int/lit8 v12, v12, 0x1

    check-cast v13, Ljava/lang/String;

    invoke-virtual {v1, v13}, Lvv0;->q(Ljava/lang/String;)V

    goto :goto_26e

    :cond_27c
    const-string v8, "neighboring_content_urls"

    invoke-virtual {v11, v8, v1}, Lfx0;->o(Ljava/lang/String;Lkw0;)V

    :cond_281
    iget-object v1, v0, Lads_mobile_sdk/au2;->a:Lads_mobile_sdk/qr0;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v8, Ldj1;

    const-string v9, "IAB_AUDIENCE_1_1"

    const-string v12, "3"

    invoke-direct {v8, v9, v12}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance v9, Ldj1;

    const-string v12, "IAB_CONTENT_2_1"

    const-string v13, "4"

    invoke-direct {v9, v12, v13}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    new-instance v12, Ldj1;

    const-string v13, "IAB_CONTENT_2_2"

    const-string v14, "5"

    invoke-direct {v12, v13, v14}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    filled-new-array {v8, v9, v12}, [Ldj1;

    move-result-object v8

    invoke-static {v8}, Lb61;->R([Ldj1;)Ljava/util/Map;

    move-result-object v8

    sget-object v9, Lads_mobile_sdk/fo;->a$24:Lads_mobile_sdk/fo;

    const-string v12, "pps_tx"

    invoke-virtual {v1, v12, v8, v9}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/util/Map;

    new-instance v9, Ljava/util/ArrayList;

    invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v8}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v8

    invoke-interface {v8}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :cond_2c0
    :goto_2c0
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_34a

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/util/Map$Entry;

    invoke-interface {v12}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/String;

    invoke-interface {v12}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/String;

    iget-object v14, v0, Lads_mobile_sdk/au2;->s:Lg32;

    if-eqz v14, :cond_346

    iget-object v14, v14, Lg32;->o1:Landroid/os/Bundle;

    if-eqz v14, :cond_2ea

    invoke-virtual {v14, v13}, Landroid/os/Bundle;->getIntegerArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v14

    if-nez v14, :cond_2e7

    goto :goto_2ea

    :cond_2e7
    :goto_2e7
    move-object/from16 v19, v14

    goto :goto_2f9

    :cond_2ea
    :goto_2ea
    iget-object v14, v0, Lads_mobile_sdk/au2;->s:Lg32;

    if-eqz v14, :cond_342

    iget-object v14, v14, Lg32;->o1:Landroid/os/Bundle;

    if-eqz v14, :cond_2f7

    invoke-virtual {v14, v13}, Landroid/os/Bundle;->getStringArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v14

    goto :goto_2e7

    :cond_2f7
    move-object/from16 v19, p1

    :goto_2f9
    if-eqz v19, :cond_339

    const/16 v24, 0x0

    const/16 v25, 0x3e

    const-string v20, "|"

    const/16 v21, 0x0

    const/16 v22, 0x0

    const/16 v23, 0x0

    invoke-static/range {v19 .. v25}, Lbs;->p0(Ljava/lang/Iterable;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILbk0;I)Ljava/lang/String;

    move-result-object v13

    new-instance v14, Ljava/lang/StringBuilder;

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v14, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v14, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v14, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    const-string v13, "pps_rg"

    const-string v14, "\\d+=([a-zA-Z0-9]+)(\\|[a-zA-Z0-9]+)*$"

    invoke-virtual {v1, v13, v14, v2}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/String;

    invoke-static {v13}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v13, v12}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v13

    invoke-virtual {v13}, Ljava/util/regex/Matcher;->matches()Z

    move-result v13

    if-eqz v13, :cond_339

    goto :goto_33b

    :cond_339
    move-object/from16 v12, p1

    :goto_33b
    if-eqz v12, :cond_2c0

    invoke-virtual {v9, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_2c0

    :cond_342
    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_346
    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_34a
    const/16 v24, 0x0

    const/16 v25, 0x3e

    const-string v20, "~"

    const/16 v21, 0x0

    const/16 v22, 0x0

    const/16 v23, 0x0

    move-object/from16 v19, v9

    invoke-static/range {v19 .. v25}, Lbs;->p0(Ljava/lang/Iterable;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILbk0;I)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v8

    if-nez v8, :cond_36f

    sget-object v8, Lads_mobile_sdk/aq;->Ag:Lads_mobile_sdk/aq;

    iget-object v8, v8, Lads_mobile_sdk/aq;->a:Ljava/util/ArrayList;

    invoke-virtual {v8, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    invoke-virtual {v11, v8, v1}, Lfx0;->s(Ljava/lang/String;Ljava/lang/String;)V

    :cond_36f
    iget-object v1, v0, Lads_mobile_sdk/au2;->s:Lg32;

    if-eqz v1, :cond_588

    iget-object v1, v1, Lg32;->U:Lzo1;

    if-eqz v1, :cond_3a9

    iget-object v1, v1, Lzo1;->a:Lee;

    if-eqz v1, :cond_3a9

    iget-wide v8, v1, Lee;->d:J

    sget-object v1, Lads_mobile_sdk/aq;->Hk:Lads_mobile_sdk/aq;

    iget-object v1, v1, Lads_mobile_sdk/aq;->a:Ljava/util/ArrayList;

    invoke-virtual {v1, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    invoke-static {v8, v9}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v11, v1, v10}, Lfx0;->s(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v12

    sub-long/2addr v12, v8

    const-wide/32 v8, 0xea60

    div-long/2addr v12, v8

    sget-object v1, Lads_mobile_sdk/aq;->Xi:Lads_mobile_sdk/aq;

    iget-object v1, v1, Lads_mobile_sdk/aq;->a:Ljava/util/ArrayList;

    invoke-virtual {v1, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    mul-long/2addr v12, v8

    invoke-static {v12, v13}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v11, v1, v8}, Lfx0;->s(Ljava/lang/String;Ljava/lang/String;)V

    :cond_3a9
    iget-object v1, v0, Lads_mobile_sdk/au2;->s:Lg32;

    if-eqz v1, :cond_584

    iget-object v1, v1, Lg32;->h:Ljava/lang/String;

    if-eqz v1, :cond_3be

    sget-object v8, Lads_mobile_sdk/aq;->Bb:Lads_mobile_sdk/aq;

    iget-object v8, v8, Lads_mobile_sdk/aq;->a:Ljava/util/ArrayList;

    invoke-virtual {v8, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    invoke-virtual {v11, v8, v1}, Lfx0;->s(Ljava/lang/String;Ljava/lang/String;)V

    :cond_3be
    iget-object v1, v0, Lads_mobile_sdk/au2;->s:Lg32;

    if-eqz v1, :cond_580

    iget-object v1, v1, Lg32;->f:Ljava/lang/String;

    if-eqz v1, :cond_415

    const-string v8, "request_type"

    invoke-virtual {v4, v8}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lads_mobile_sdk/n33;

    if-eqz v4, :cond_408

    invoke-virtual {v4}, Lads_mobile_sdk/n33;->r()J

    move-result-wide v8

    packed-switch v17, :pswitch_data_596

    throw p1

    :pswitch_3d8  #0x6
    const/4 v12, -0x1

    goto :goto_3e5

    :pswitch_3da  #0x5
    const/4 v12, 0x6

    goto :goto_3e5

    :pswitch_3dc  #0x4
    const/4 v12, 0x3

    goto :goto_3e5

    :pswitch_3de  #0x3
    move/from16 v12, v17

    goto :goto_3e5

    :pswitch_3e1  #0x2
    move/from16 v12, v18

    goto :goto_3e5

    :pswitch_3e4  #0x1
    move v12, v7

    :goto_3e5
    int-to-long v12, v12

    cmp-long v4, v8, v12

    if-nez v4, :cond_408

    const-string v4, "interstitial_mb"

    invoke-virtual {v1, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_408

    sget-object v4, Lads_mobile_sdk/aq;->l8:Lads_mobile_sdk/aq;

    iget-object v4, v4, Lads_mobile_sdk/aq;->a:Ljava/util/ArrayList;

    invoke-virtual {v4, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    const-string v8, "_as"

    const-string v9, "_mb"

    invoke-static {v1, v8, v9, v7}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v11, v4, v1}, Lfx0;->s(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_415

    :cond_408
    sget-object v4, Lads_mobile_sdk/aq;->l8:Lads_mobile_sdk/aq;

    iget-object v4, v4, Lads_mobile_sdk/aq;->a:Ljava/util/ArrayList;

    invoke-virtual {v4, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-virtual {v11, v4, v1}, Lfx0;->s(Ljava/lang/String;Ljava/lang/String;)V

    :cond_415
    :goto_415
    iget-object v1, v0, Lads_mobile_sdk/au2;->s:Lg32;

    if-eqz v1, :cond_57c

    iget-object v1, v1, Lg32;->b:Ljava/util/ArrayList;

    invoke-static {v1}, Lbs;->l0(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lt4;

    if-eqz v1, :cond_443

    new-instance v4, Lfx0;

    invoke-direct {v4}, Lfx0;-><init>()V

    iget v8, v1, Lt4;->a:I

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    const-string v9, "width"

    invoke-virtual {v4, v8, v9}, Lfx0;->q(Ljava/lang/Number;Ljava/lang/String;)V

    iget v1, v1, Lt4;->b:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const-string v8, "height"

    invoke-virtual {v4, v1, v8}, Lfx0;->q(Ljava/lang/Number;Ljava/lang/String;)V

    const-string v1, "p_sz"

    invoke-virtual {v11, v1, v4}, Lfx0;->o(Ljava/lang/String;Lkw0;)V

    :cond_443
    sget-object v1, Lads_mobile_sdk/aq;->fd:Lads_mobile_sdk/aq;

    iget-object v1, v1, Lads_mobile_sdk/aq;->a:Ljava/util/ArrayList;

    invoke-virtual {v1, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iget-object v4, v0, Lads_mobile_sdk/au2;->s:Lg32;

    if-eqz v4, :cond_578

    iget v8, v4, Lg32;->j:I

    iget v4, v4, Lg32;->k:I

    if-le v8, v4, :cond_45a

    const-string v4, "l"

    goto :goto_45c

    :cond_45a
    const-string v4, "p"

    :goto_45c
    invoke-virtual {v11, v1, v4}, Lfx0;->s(Ljava/lang/String;Ljava/lang/String;)V

    sget-object v1, Lads_mobile_sdk/aq;->zi:Lads_mobile_sdk/aq;

    iget-object v1, v1, Lads_mobile_sdk/aq;->a:Ljava/util/ArrayList;

    invoke-virtual {v1, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iget-object v4, v0, Lads_mobile_sdk/au2;->s:Lg32;

    if-eqz v4, :cond_574

    iget v4, v4, Lg32;->l:I

    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v11, v1, v4}, Lfx0;->s(Ljava/lang/String;Ljava/lang/String;)V

    sget-object v1, Lads_mobile_sdk/aq;->yi:Lads_mobile_sdk/aq;

    iget-object v1, v1, Lads_mobile_sdk/aq;->a:Ljava/util/ArrayList;

    invoke-virtual {v1, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    iget-object v4, v0, Lads_mobile_sdk/au2;->s:Lg32;

    if-eqz v4, :cond_570

    iget v4, v4, Lg32;->m:I

    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v11, v1, v4}, Lfx0;->s(Ljava/lang/String;Ljava/lang/String;)V

    iput-object v0, v3, Lads_mobile_sdk/wt2;->a:Lads_mobile_sdk/au2;

    move/from16 v1, v18

    iput v1, v3, Lads_mobile_sdk/wt2;->d:I

    invoke-virtual {v0, v3}, Lads_mobile_sdk/au2;->b(Lwx;)Ljava/lang/Object;

    move-result-object v1

    sget-object v3, Lwy;->a:Lwy;

    if-ne v1, v3, :cond_49c

    return-object v3

    :cond_49c
    :goto_49c
    iget-object v1, v0, Lads_mobile_sdk/au2;->u:Lfx0;

    iget-object v3, v0, Lads_mobile_sdk/au2;->f:Ln63;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v3, Ljava/util/Random;

    invoke-direct {v3}, Ljava/util/Random;-><init>()V

    invoke-virtual {v3}, Ljava/util/Random;->nextLong()J

    move-result-wide v3

    invoke-static {v3, v4}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v3

    const-string v4, "c"

    invoke-virtual {v1, v4, v3}, Lfx0;->s(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v3, v0, Lads_mobile_sdk/au2;->s:Lg32;

    if-eqz v3, :cond_56c

    iget-object v3, v3, Lg32;->W1:Ljava/lang/Integer;

    if-eqz v3, :cond_536

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    const/4 v4, 0x1

    if-gt v3, v4, :cond_4c6

    goto/16 :goto_536

    :cond_4c6
    iget-object v4, v0, Lads_mobile_sdk/au2;->s:Lg32;

    if-eqz v4, :cond_532

    iget-object v4, v4, Lg32;->G1:Ljava/lang/Boolean;

    if-eqz v4, :cond_4db

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    if-eqz v4, :cond_4db

    const/16 v4, 0x14

    invoke-static {v3, v4}, Ljava/lang/Math;->min(II)I

    move-result v3

    goto :goto_4e0

    :cond_4db
    const/4 v4, 0x5

    invoke-static {v3, v4}, Ljava/lang/Math;->min(II)I

    move-result v3

    :goto_4e0
    iget-object v4, v0, Lads_mobile_sdk/au2;->s:Lg32;

    if-eqz v4, :cond_52e

    iget-object v4, v4, Lg32;->o:Ljava/lang/String;

    if-nez v4, :cond_4ea

    const-string v4, ""

    :cond_4ea
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v6

    if-nez v6, :cond_4f1

    goto :goto_536

    :cond_4f1
    iget-object v6, v0, Lads_mobile_sdk/au2;->v:Ljava/util/LinkedHashMap;

    const-string v8, "sra_regex"

    invoke-virtual {v6, v8}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lads_mobile_sdk/n33;

    if-eqz v6, :cond_50d

    invoke-virtual {v6}, Lads_mobile_sdk/n33;->s()Ljava/lang/String;

    move-result-object v6

    if-eqz v6, :cond_50d

    sget-object v8, Lads_mobile_sdk/ax0;->f:Lzn1;

    invoke-static {v6, v4}, Lzn1;->j(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    if-nez v6, :cond_50c

    goto :goto_50d

    :cond_50c
    move-object v4, v6

    :cond_50d
    :goto_50d
    new-array v6, v3, [Ljava/lang/String;

    :goto_50f
    if-ge v7, v3, :cond_51c

    const-string v8, "slotname="

    invoke-virtual {v8, v4}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    aput-object v8, v6, v7

    add-int/lit8 v7, v7, 0x1

    goto :goto_50f

    :cond_51c
    sget-object v3, Lads_mobile_sdk/aq;->Ej:Lads_mobile_sdk/aq;

    invoke-virtual {v3}, Lads_mobile_sdk/aq;->b()Ljava/lang/String;

    move-result-object v3

    const-string v4, ","

    const/16 v7, 0x3e

    invoke-static {v6, v4, v7}, Laf;->n0([Ljava/lang/Object;Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v3, v4}, Lfx0;->s(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_536

    :cond_52e
    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_532
    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_536
    :goto_536
    iget v3, v0, Lads_mobile_sdk/au2;->h:I

    iget-object v4, v0, Lads_mobile_sdk/au2;->i:Landroid/content/Context;

    invoke-virtual {v4}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    iget-object v0, v0, Lads_mobile_sdk/au2;->a:Lads_mobile_sdk/qr0;

    const-string v6, "gads:client_default_content_url_domain_suffix"

    const-string v7, "adsenseformobileapps.com"

    invoke-virtual {v0, v6, v7, v2}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v3, ".android."

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v2, "a_url"

    invoke-virtual {v1, v2, v0}, Lfx0;->s(Ljava/lang/String;Ljava/lang/String;)V

    sget-object v0, Lrg2;->a:Lrg2;

    return-object v0

    :cond_56c
    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_570
    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_574
    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_578
    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_57c
    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_580
    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_584
    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_588
    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_58c
    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_590
    move-object/from16 p1, v9

    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :pswitch_data_596
    .packed-switch 0x1
        :pswitch_3e4  #00000001
        :pswitch_3e1  #00000002
        :pswitch_3de  #00000003
        :pswitch_3dc  #00000004
        :pswitch_3da  #00000005
        :pswitch_3d8  #00000006
    .end packed-switch
.end method

.method public final a(Lads_mobile_sdk/mg2;)V
    .registers 6

    .prologue
    invoke-virtual {p1}, Lads_mobile_sdk/mg2;->q()Lw63;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_8
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_5a

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/kg2;

    invoke-virtual {v0}, Lads_mobile_sdk/kg2;->q()Z

    move-result v1

    if-eqz v1, :cond_27

    invoke-virtual {v0}, Lads_mobile_sdk/kg2;->p()Lads_mobile_sdk/vm1;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0, v1}, Lads_mobile_sdk/au2;->a(Lads_mobile_sdk/vm1;)Z

    move-result v1

    if-eqz v1, :cond_8

    :cond_27
    invoke-virtual {v0}, Lads_mobile_sdk/kg2;->o()Ljava/util/Map;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_36
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_8

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lads_mobile_sdk/n33;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v3, p0, Lads_mobile_sdk/au2;->v:Ljava/util/LinkedHashMap;

    invoke-interface {v3, v2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_36

    :cond_5a
    return-void
.end method

.method public final a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .registers 7

    .prologue
    invoke-static {p1}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v0

    iget-object v1, p0, Lads_mobile_sdk/au2;->c:Lads_mobile_sdk/ah3;

    if-eqz v0, :cond_19

    const-string p0, "Rule "

    const-string p1, " attempted to set a blank URL parameter."

    invoke-static {p0, p3, p1}, Lrt2;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    new-instance p1, Ljava/lang/Exception;

    invoke-direct {p1, p0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0, p1}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void

    :cond_19
    iget-object v0, p0, Lads_mobile_sdk/au2;->o:Ljava/util/LinkedHashMap;

    invoke-interface {v0, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_34

    const-string p0, " was attempted to be overwritten by rule "

    const-string p2, "."

    const-string v0, "URL parameter "

    invoke-static {v0, p1, p0, p3, p2}, Lrt2;->j(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    new-instance p1, Ljava/lang/Exception;

    invoke-direct {p1, p0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0, p1}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void

    :cond_34
    iget-object p3, p0, Lads_mobile_sdk/au2;->p:Ljava/util/Map;

    const/4 v1, 0x0

    const-string v2, "concatenatedSignalsRules"

    if-eqz p3, :cond_75

    invoke-interface {p3, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result p3

    if-eqz p3, :cond_71

    iget-object p3, p0, Lads_mobile_sdk/au2;->p:Ljava/util/Map;

    if-eqz p3, :cond_6d

    invoke-interface {p3, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p3

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p3, Ljava/lang/String;

    iget-object p0, p0, Lads_mobile_sdk/au2;->q:Ljava/util/LinkedHashMap;

    invoke-virtual {p0, p1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/StringBuilder;

    if-nez v0, :cond_5d

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    :cond_5d
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result v1

    if-lez v1, :cond_66

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_66
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-interface {p0, p1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_6d
    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw v1

    :cond_71
    invoke-interface {v0, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_75
    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw v1
.end method

.method public final a(Lads_mobile_sdk/vm1;)Z
    .registers 3

    .prologue
    invoke-virtual {p1}, Lads_mobile_sdk/vm1;->o$1()Lw63;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    if-lez v0, :cond_37

    invoke-virtual {p1}, Lads_mobile_sdk/vm1;->o$1()Lw63;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    instance-of v0, p1, Ljava/util/Collection;

    if-eqz v0, :cond_1d

    invoke-interface {p1}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_1d

    goto/16 :goto_a0

    :cond_1d
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_21
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_a0

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/vm1;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0, v0}, Lads_mobile_sdk/au2;->a(Lads_mobile_sdk/vm1;)Z

    move-result v0

    if-nez v0, :cond_21

    goto :goto_81

    :cond_37
    invoke-virtual {p1}, Lads_mobile_sdk/vm1;->s()Lw63;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    if-lez v0, :cond_6d

    invoke-virtual {p1}, Lads_mobile_sdk/vm1;->s()Lw63;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    instance-of v0, p1, Ljava/util/Collection;

    if-eqz v0, :cond_53

    invoke-interface {p1}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_53

    goto :goto_81

    :cond_53
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_57
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_81

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/vm1;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0, v0}, Lads_mobile_sdk/au2;->a(Lads_mobile_sdk/vm1;)Z

    move-result v0

    if-eqz v0, :cond_57

    goto :goto_a0

    :cond_6d
    invoke-virtual {p1}, Lads_mobile_sdk/vm1;->u()Z

    move-result v0

    if-eqz v0, :cond_83

    invoke-virtual {p1}, Lads_mobile_sdk/vm1;->r()Lads_mobile_sdk/vm1;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0, p1}, Lads_mobile_sdk/au2;->a(Lads_mobile_sdk/vm1;)Z

    move-result p0

    if-nez p0, :cond_81

    goto :goto_a0

    :cond_81
    :goto_81
    const/4 p0, 0x0

    return p0

    :cond_83
    invoke-virtual {p1}, Lads_mobile_sdk/vm1;->t()Z

    move-result v0

    if-eqz v0, :cond_a0

    iget-object p0, p0, Lads_mobile_sdk/au2;->t:Lfx0;

    if-eqz p0, :cond_99

    invoke-virtual {p1}, Lads_mobile_sdk/vm1;->q()Lads_mobile_sdk/mn1;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p0, p1}, Lw53;->p(Lfx0;Lads_mobile_sdk/mn1;)Z

    move-result p0

    return p0

    :cond_99
    const-string p0, "signalJson"

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0

    :cond_a0
    :goto_a0
    const/4 p0, 0x1

    return p0
.end method

.method public final b()Landroid/net/Uri;
    .registers 7

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/au2;->j:Ljava/lang/String;

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    invoke-virtual {v0}, Landroid/net/Uri;->buildUpon()Landroid/net/Uri$Builder;

    move-result-object v0

    iget-object v1, p0, Lads_mobile_sdk/au2;->o:Ljava/util/LinkedHashMap;

    invoke-virtual {v1}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_14
    :goto_14
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_41

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    iget-object v4, p0, Lads_mobile_sdk/au2;->n:Ljava/util/LinkedHashSet;

    invoke-interface {v4}, Ljava/util/Set;->isEmpty()Z

    move-result v5

    if-nez v5, :cond_3a

    invoke-interface {v4, v3}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_14

    :cond_3a
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v0, v3, v2}, Lw53;->j(Landroid/net/Uri$Builder;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_14

    :cond_41
    invoke-virtual {v0}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object p0

    return-object p0
.end method

.method public final b(Lads_mobile_sdk/fb2;)Lb13;
    .registers 16

    .prologue
    invoke-virtual {p1}, Lads_mobile_sdk/fb2;->F()Z

    move-result v0

    sget-object v1, Lrg2;->a:Lrg2;

    if-eqz v0, :cond_3b

    invoke-virtual {p1}, Lads_mobile_sdk/fb2;->z()Lads_mobile_sdk/vm1;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0, v0}, Lads_mobile_sdk/au2;->a(Lads_mobile_sdk/vm1;)Z

    move-result v0

    if-eqz v0, :cond_16

    goto :goto_3b

    :cond_16
    invoke-virtual {p1}, Lads_mobile_sdk/fb2;->u()Lw63;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_1e
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_2bd

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/fb2;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0, v0}, Lads_mobile_sdk/au2;->b(Lads_mobile_sdk/fb2;)Lb13;

    move-result-object v0

    instance-of v2, v0, Lads_mobile_sdk/av0;

    if-eqz v2, :cond_38

    check-cast v0, Lads_mobile_sdk/av0;

    return-object v0

    :cond_38
    check-cast v0, Lads_mobile_sdk/hv0;

    goto :goto_1e

    :cond_3b
    :goto_3b
    invoke-virtual {p1}, Lads_mobile_sdk/fb2;->x()Ljava/util/Map;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_4a
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_73

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/util/Map$Entry;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Lads_mobile_sdk/fb2;->A()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0, v3, v2, v4}, Lads_mobile_sdk/au2;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_4a

    :cond_73
    invoke-virtual {p1}, Lads_mobile_sdk/fb2;->y()Lw63;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_7b
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget-object v8, p0, Lads_mobile_sdk/au2;->c:Lads_mobile_sdk/ah3;

    const-string v9, "Rule "

    if-eqz v2, :cond_1cb

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lads_mobile_sdk/h41;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v10, p0, Lads_mobile_sdk/au2;->t:Lfx0;

    if-eqz v10, :cond_1c5

    invoke-virtual {v2}, Lads_mobile_sdk/h41;->z()Lw63;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v10, v11}, Lw53;->t(Lfx0;Lw63;)Lkw0;

    move-result-object v10

    if-nez v10, :cond_a5

    goto :goto_7b

    :cond_a5
    invoke-virtual {v2}, Lads_mobile_sdk/h41;->B()I

    move-result v11

    invoke-static {v11}, Lc33;->x(I)I

    move-result v11

    if-eqz v11, :cond_143

    if-eq v11, v6, :cond_13e

    const-string v12, "0"

    const-string v13, "1"

    if-eq v11, v5, :cond_11f

    if-eq v11, v4, :cond_c1

    if-ne v11, v3, :cond_bd

    goto/16 :goto_143

    :cond_bd
    invoke-static {}, Ldm2;->q()V

    return-object v7

    :cond_c1
    instance-of v3, v10, Lox0;

    if-eqz v3, :cond_e1

    invoke-virtual {v10}, Lkw0;->i()Lox0;

    move-result-object v4

    iget-object v4, v4, Lox0;->a:Ljava/io/Serializable;

    instance-of v4, v4, Ljava/lang/Number;

    if-eqz v4, :cond_e1

    invoke-virtual {v10}, Lkw0;->i()Lox0;

    move-result-object v3

    invoke-virtual {v3}, Lox0;->l()Ljava/lang/Number;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v3

    invoke-static {v3, v4, v2}, Lw53;->h(DLads_mobile_sdk/h41;)Ljava/lang/String;

    move-result-object v12

    goto/16 :goto_144

    :cond_e1
    if-eqz v3, :cond_107

    invoke-virtual {v10}, Lkw0;->i()Lox0;

    move-result-object v4

    iget-object v4, v4, Lox0;->a:Ljava/io/Serializable;

    instance-of v4, v4, Ljava/lang/String;

    if-eqz v4, :cond_107

    invoke-virtual {v10}, Lkw0;->i()Lox0;

    move-result-object v3

    invoke-virtual {v3}, Lox0;->m()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v3}, Li72;->Z(Ljava/lang/String;)Ljava/lang/Double;

    move-result-object v3

    if-eqz v3, :cond_143

    invoke-virtual {v3}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v3

    invoke-static {v3, v4, v2}, Lw53;->h(DLads_mobile_sdk/h41;)Ljava/lang/String;

    move-result-object v12

    goto :goto_144

    :cond_107
    if-eqz v3, :cond_143

    invoke-virtual {v10}, Lkw0;->i()Lox0;

    move-result-object v3

    iget-object v3, v3, Lox0;->a:Ljava/io/Serializable;

    instance-of v3, v3, Ljava/lang/Boolean;

    if-eqz v3, :cond_143

    invoke-virtual {v10}, Lkw0;->i()Lox0;

    move-result-object v3

    invoke-virtual {v3}, Lox0;->b()Z

    move-result v3

    if-eqz v3, :cond_144

    :goto_11d
    move-object v12, v13

    goto :goto_144

    :cond_11f
    invoke-static {v10, v6}, Lw53;->g(Lkw0;Z)Ljava/lang/Boolean;

    move-result-object v3

    if-eqz v3, :cond_143

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-eqz v3, :cond_132

    invoke-virtual {v2}, Lads_mobile_sdk/h41;->t()Z

    move-result v4

    if-eqz v4, :cond_132

    goto :goto_143

    :cond_132
    if-nez v3, :cond_13b

    invoke-virtual {v2}, Lads_mobile_sdk/h41;->s()Z

    move-result v4

    if-eqz v4, :cond_13b

    goto :goto_143

    :cond_13b
    if-eqz v3, :cond_144

    goto :goto_11d

    :cond_13e
    invoke-static {v10, v2}, Lw53;->A(Lkw0;Lads_mobile_sdk/h41;)Ljava/lang/String;

    move-result-object v12

    goto :goto_144

    :cond_143
    :goto_143
    move-object v12, v7

    :cond_144
    :goto_144
    if-nez v12, :cond_148

    goto/16 :goto_7b

    :cond_148
    invoke-virtual {v2}, Lads_mobile_sdk/h41;->E()Z

    move-result v3

    if-eqz v3, :cond_170

    invoke-virtual {v2}, Lads_mobile_sdk/h41;->q()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v3

    if-lez v3, :cond_170

    sget-object v3, Lads_mobile_sdk/ax0;->f:Lzn1;

    invoke-virtual {v2}, Lads_mobile_sdk/h41;->q()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v3, v12}, Lzn1;->j(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_16c

    move-object v7, v1

    move-object v12, v3

    :cond_16c
    if-nez v7, :cond_170

    goto/16 :goto_7b

    :cond_170
    invoke-virtual {v2}, Lads_mobile_sdk/h41;->F()Z

    move-result v3

    if-eqz v3, :cond_182

    invoke-virtual {v12}, Ljava/lang/String;->length()I

    move-result v3

    invoke-virtual {v2}, Lads_mobile_sdk/h41;->w()I

    move-result v4

    if-le v3, v4, :cond_182

    goto/16 :goto_7b

    :cond_182
    invoke-virtual {v2}, Lads_mobile_sdk/h41;->C()Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_18e

    invoke-static {v3}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_19c

    :cond_18e
    invoke-virtual {v2}, Lads_mobile_sdk/h41;->z()Lw63;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v2}, Lbs;->r0(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v2

    move-object v3, v2

    check-cast v3, Ljava/lang/String;

    :cond_19c
    if-eqz v3, :cond_1b1

    invoke-static {v3}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_1a5

    goto :goto_1b1

    :cond_1a5
    invoke-virtual {p1}, Lads_mobile_sdk/fb2;->A()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0, v3, v12, v2}, Lads_mobile_sdk/au2;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_7b

    :cond_1b1
    :goto_1b1
    invoke-virtual {p1}, Lads_mobile_sdk/fb2;->A()Ljava/lang/String;

    move-result-object v2

    const-string v3, " attempted to include a signal with no URL key or path."

    invoke-static {v9, v2, v3}, Lrt2;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/Exception;

    invoke-direct {v3, v2}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    invoke-virtual {v8, v2, v3}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V

    goto/16 :goto_7b

    :cond_1c5
    const-string p0, "signalJson"

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v7

    :cond_1cb
    invoke-virtual {p1}, Lads_mobile_sdk/fb2;->s()Lw63;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_1d3
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_1e8

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v10, p0, Lads_mobile_sdk/au2;->m:Ljava/util/LinkedHashSet;

    invoke-interface {v10, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto :goto_1d3

    :cond_1e8
    invoke-virtual {p1}, Lads_mobile_sdk/fb2;->t()Lw63;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_1f0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_203

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v2, v7}, Lads_mobile_sdk/nw;->b(Ljava/lang/String;Ljava/lang/Throwable;)V

    goto :goto_1f0

    :cond_203
    invoke-virtual {p1}, Lads_mobile_sdk/fb2;->p()Lw63;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_20b
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_220

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v7, p0, Lads_mobile_sdk/au2;->n:Ljava/util/LinkedHashSet;

    invoke-interface {v7, v2}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto :goto_20b

    :cond_220
    invoke-virtual {p1}, Lads_mobile_sdk/fb2;->B()Z

    move-result v0

    if-eqz v0, :cond_22c

    invoke-virtual {p1}, Lads_mobile_sdk/fb2;->o()Z

    move-result v0

    iput-boolean v0, p0, Lads_mobile_sdk/au2;->l:Z

    :cond_22c
    invoke-virtual {p1}, Lads_mobile_sdk/fb2;->E()Z

    move-result v0

    if-eqz v0, :cond_262

    invoke-virtual {p1}, Lads_mobile_sdk/fb2;->D()Z

    move-result v0

    if-eqz v0, :cond_23f

    invoke-virtual {p1}, Lads_mobile_sdk/fb2;->v()I

    move-result v0

    packed-switch v0, :pswitch_data_2c4

    :cond_23f
    :pswitch_23f  #0x6, 0x7, 0x9
    move v3, v6

    goto :goto_255

    :pswitch_241  #0xc
    const/16 v3, 0xa

    goto :goto_255

    :pswitch_244  #0xb
    const/16 v3, 0xe

    goto :goto_255

    :pswitch_247  #0xa
    const/16 v3, 0xf

    goto :goto_255

    :pswitch_24a  #0x5
    const/16 v3, 0x11

    goto :goto_255

    :pswitch_24d  #0x4
    const/16 v3, 0x10

    goto :goto_255

    :pswitch_250  #0x3
    move v3, v4

    goto :goto_255

    :pswitch_252  #0x2
    const/4 v3, 0x5

    goto :goto_255

    :pswitch_254  #0x1
    move v3, v5

    :goto_255
    :pswitch_255  #0x8
    new-instance v0, Lads_mobile_sdk/ev0;

    invoke-virtual {p1}, Lads_mobile_sdk/fb2;->w()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {v0, v2, v3}, Lads_mobile_sdk/ev0;-><init>(Ljava/lang/String;I)V

    goto :goto_28f

    :cond_262
    invoke-virtual {p1}, Lads_mobile_sdk/fb2;->C()Z

    move-result v0

    if-eqz v0, :cond_28a

    iget-boolean v0, p0, Lads_mobile_sdk/au2;->k:Z

    if-eqz v0, :cond_27f

    invoke-virtual {p1}, Lads_mobile_sdk/fb2;->A()Ljava/lang/String;

    move-result-object v0

    const-string v2, " attempted to modify the base URL after it has been set."

    invoke-static {v9, v0, v2}, Lrt2;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-instance v2, Ljava/lang/Exception;

    invoke-direct {v2, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    invoke-virtual {v8, v0, v2}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V

    goto :goto_28a

    :cond_27f
    invoke-virtual {p1}, Lads_mobile_sdk/fb2;->r()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object v0, p0, Lads_mobile_sdk/au2;->j:Ljava/lang/String;

    iput-boolean v6, p0, Lads_mobile_sdk/au2;->k:Z

    :cond_28a
    :goto_28a
    new-instance v0, Lads_mobile_sdk/hv0;

    invoke-direct {v0, v1}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    :goto_28f
    instance-of v2, v0, Lads_mobile_sdk/av0;

    if-eqz v2, :cond_296

    check-cast v0, Lads_mobile_sdk/av0;

    return-object v0

    :cond_296
    check-cast v0, Lads_mobile_sdk/hv0;

    invoke-virtual {p1}, Lads_mobile_sdk/fb2;->q()Lw63;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_2a0
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_2bd

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/fb2;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0, v0}, Lads_mobile_sdk/au2;->b(Lads_mobile_sdk/fb2;)Lb13;

    move-result-object v0

    instance-of v2, v0, Lads_mobile_sdk/av0;

    if-eqz v2, :cond_2ba

    check-cast v0, Lads_mobile_sdk/av0;

    return-object v0

    :cond_2ba
    check-cast v0, Lads_mobile_sdk/hv0;

    goto :goto_2a0

    :cond_2bd
    new-instance p0, Lads_mobile_sdk/hv0;

    invoke-direct {p0, v1}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    return-object p0

    nop

    :pswitch_data_2c4
    .packed-switch 0x1
        :pswitch_254  #00000001
        :pswitch_252  #00000002
        :pswitch_250  #00000003
        :pswitch_24d  #00000004
        :pswitch_24a  #00000005
        :pswitch_23f  #00000006
        :pswitch_23f  #00000007
        :pswitch_255  #00000008
        :pswitch_23f  #00000009
        :pswitch_247  #0000000a
        :pswitch_244  #0000000b
        :pswitch_241  #0000000c
    .end packed-switch
.end method

.method public final b(Lwx;)Ljava/lang/Object;
    .registers 7

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/xt2;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/xt2;

    iget v1, v0, Lads_mobile_sdk/xt2;->g:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/xt2;->g:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/xt2;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/xt2;-><init>(Lads_mobile_sdk/au2;Lwx;)V

    :goto_18
    iget-object p1, v0, Lads_mobile_sdk/xt2;->e:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/xt2;->g:I

    const/4 v2, 0x1

    if-eqz v1, :cond_34

    if-ne v1, v2, :cond_2d

    iget-object p0, v0, Lads_mobile_sdk/xt2;->d:Ljava/lang/String;

    iget-object v1, v0, Lads_mobile_sdk/xt2;->c:Lfx0;

    iget-object v2, v0, Lads_mobile_sdk/xt2;->b:Lfx0;

    iget-object v0, v0, Lads_mobile_sdk/xt2;->a:Lfx0;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_5e

    :cond_2d
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0

    :cond_34
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    new-instance p1, Lfx0;

    invoke-direct {p1}, Lfx0;-><init>()V

    iput-object p1, v0, Lads_mobile_sdk/xt2;->a:Lfx0;

    iput-object p1, v0, Lads_mobile_sdk/xt2;->b:Lfx0;

    iget-object v1, p0, Lads_mobile_sdk/au2;->u:Lfx0;

    iput-object v1, v0, Lads_mobile_sdk/xt2;->c:Lfx0;

    const-string v3, "sdk_core"

    iput-object v3, v0, Lads_mobile_sdk/xt2;->d:Ljava/lang/String;

    iput v2, v0, Lads_mobile_sdk/xt2;->g:I

    iget-object p0, p0, Lads_mobile_sdk/au2;->b:Lads_mobile_sdk/ek;

    iget-object p0, p0, Lads_mobile_sdk/ek;->a:Lads_mobile_sdk/xq0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p0, v0}, Lads_mobile_sdk/xq0;->c(Lads_mobile_sdk/xq0;Lwx;)Ljava/lang/Object;

    move-result-object p0

    sget-object v0, Lwy;->a:Lwy;

    if-ne p0, v0, :cond_5a

    return-object v0

    :cond_5a
    move-object v0, p1

    move-object v2, v0

    move-object p1, p0

    move-object p0, v3

    :goto_5e
    check-cast p1, Ljava/util/Map;

    invoke-interface {p1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_68
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_84

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/util/Map$Entry;

    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-virtual {v2, v4, v3}, Lfx0;->s(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_68

    :cond_84
    invoke-virtual {v1, p0, v0}, Lfx0;->o(Ljava/lang/String;Lkw0;)V

    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method

.method public final f()V
    .registers 8

    .prologue
    :try_start_0
    iget-object v0, p0, Lads_mobile_sdk/au2;->s:Lg32;
    :try_end_2
    .catchall {:try_start_0 .. :try_end_2} :catchall_bd

    const-string v1, "signals"

    const/4 v2, 0x0

    if-eqz v0, :cond_b9

    :try_start_7
    iget-object v0, v0, Lg32;->o1:Landroid/os/Bundle;

    if-nez v0, :cond_10

    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    :cond_10
    iget-object v3, p0, Lads_mobile_sdk/au2;->r:Lkm0;

    iget-object v4, p0, Lads_mobile_sdk/au2;->s:Lg32;

    if-eqz v4, :cond_b5

    iget-object v4, v4, Lg32;->s0:Ljava/lang/String;

    if-nez v4, :cond_1c

    const-string v4, "{}"

    :cond_1c
    const-class v5, Lfx0;

    invoke-virtual {v3, v5, v4}, Lkm0;->a(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lfx0;

    const-string v4, "global_extras"
    :try_end_26
    .catchall {:try_start_7 .. :try_end_26} :catchall_bd

    if-nez v3, :cond_29

    goto :goto_2e

    :cond_29
    :try_start_29
    invoke-virtual {v3, v4}, Lfx0;->x(Ljava/lang/String;)Lfx0;

    move-result-object v4
    :try_end_2d
    .catch Ljava/lang/Exception; {:try_start_29 .. :try_end_2d} :catch_2e
    .catchall {:try_start_29 .. :try_end_2d} :catchall_bd

    goto :goto_2f

    :catch_2e
    :goto_2e
    move-object v4, v2

    :goto_2f
    if-eqz v4, :cond_61

    :try_start_31
    iget-object v4, v4, Lfx0;->a:Lf21;

    invoke-virtual {v4}, Lf21;->entrySet()Ljava/util/Set;

    move-result-object v4

    check-cast v4, Ld21;

    invoke-virtual {v4}, Ld21;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_3d
    move-object v5, v4

    check-cast v5, Lc21;

    invoke-virtual {v5}, Lc21;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_61

    move-object v5, v4

    check-cast v5, Lc21;

    invoke-virtual {v5}, Lc21;->b()Le21;

    move-result-object v5

    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lkw0;

    invoke-virtual {v5}, Lkw0;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v6, v5}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_3d

    :cond_61
    iget-object v4, p0, Lads_mobile_sdk/au2;->s:Lg32;

    if-eqz v4, :cond_b1

    iget-object v4, v4, Lg32;->o:Ljava/lang/String;

    if-nez v4, :cond_6b

    const-string v4, ""
    :try_end_6b
    .catchall {:try_start_31 .. :try_end_6b} :catchall_bd

    :cond_6b
    if-nez v3, :cond_6e

    goto :goto_73

    :cond_6e
    :try_start_6e
    invoke-virtual {v3, v4}, Lfx0;->x(Ljava/lang/String;)Lfx0;

    move-result-object v3
    :try_end_72
    .catch Ljava/lang/Exception; {:try_start_6e .. :try_end_72} :catch_73
    .catchall {:try_start_6e .. :try_end_72} :catchall_bd

    goto :goto_74

    :catch_73
    :goto_73
    move-object v3, v2

    :goto_74
    if-eqz v3, :cond_a6

    :try_start_76
    iget-object v3, v3, Lfx0;->a:Lf21;

    invoke-virtual {v3}, Lf21;->entrySet()Ljava/util/Set;

    move-result-object v3

    check-cast v3, Ld21;

    invoke-virtual {v3}, Ld21;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_82
    move-object v4, v3

    check-cast v4, Lc21;

    invoke-virtual {v4}, Lc21;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_a6

    move-object v4, v3

    check-cast v4, Lc21;

    invoke-virtual {v4}, Lc21;->b()Le21;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lkw0;

    invoke-virtual {v4}, Lkw0;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v5, v4}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_82

    :cond_a6
    iget-object p0, p0, Lads_mobile_sdk/au2;->s:Lg32;

    if-eqz p0, :cond_ad

    iput-object v0, p0, Lg32;->o1:Landroid/os/Bundle;

    goto :goto_bd

    :cond_ad
    invoke-static {v1}, Lgt0;->F0(Ljava/lang/String;)V

    throw v2

    :cond_b1
    invoke-static {v1}, Lgt0;->F0(Ljava/lang/String;)V

    throw v2

    :cond_b5
    invoke-static {v1}, Lgt0;->F0(Ljava/lang/String;)V

    throw v2

    :cond_b9
    invoke-static {v1}, Lgt0;->F0(Ljava/lang/String;)V

    throw v2
    :try_end_bd
    .catchall {:try_start_76 .. :try_end_bd} :catchall_bd

    :catchall_bd
    :goto_bd
    return-void
.end method

.method public final g()V
    .registers 18

    .prologue
    move-object/from16 v0, p0

    invoke-static {}, Lads_mobile_sdk/sq;->p()Lxv2;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v2, Lads_mobile_sdk/w8;

    invoke-direct {v2, v1}, Lads_mobile_sdk/w8;-><init>(Ljava/lang/Cloneable;)V

    new-instance v1, Ljava/util/LinkedHashSet;

    invoke-direct {v1}, Ljava/util/LinkedHashSet;-><init>()V

    iget-object v3, v0, Lads_mobile_sdk/au2;->s:Lg32;

    const-string v5, "signals"

    if-eqz v3, :cond_2d5

    iget-object v3, v3, Lg32;->E0:Ljava/util/List;

    if-nez v3, :cond_1f

    sget-object v3, Lba0;->a:Lba0;

    :cond_1f
    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_23
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    const/4 v7, 0x0

    const/4 v8, 0x1

    if-eqz v6, :cond_198

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lads_mobile_sdk/dy2;

    invoke-virtual {v2}, Lads_mobile_sdk/w8;->b()Lads_mobile_sdk/vj0;

    move-result-object v9

    invoke-static {}, Lads_mobile_sdk/rq;->o()Lk13;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v11, v6, Lads_mobile_sdk/dy2;->a:Ljava/lang/String;

    const-string v12, ""

    if-nez v11, :cond_43

    move-object v11, v12

    :cond_43
    invoke-virtual {v10}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v13, v10, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v13, Lads_mobile_sdk/rq;

    invoke-virtual {v13, v11}, Lads_mobile_sdk/rq;->b(Ljava/lang/String;)V

    iget-object v11, v10, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v11, Lads_mobile_sdk/rq;

    invoke-static {v11}, Lads_mobile_sdk/rq;->c(Lads_mobile_sdk/rq;)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {v1, v11}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    iget-object v11, v6, Lads_mobile_sdk/dy2;->c:Ljava/lang/String;

    invoke-static {v11}, Lw53;->e(Ljava/lang/String;)Lads_mobile_sdk/qq;

    move-result-object v11

    invoke-virtual {v10}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v13, v10, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v13, Lads_mobile_sdk/rq;

    invoke-virtual {v13, v11}, Lads_mobile_sdk/rq;->b(Lads_mobile_sdk/qq;)V

    iget-object v11, v6, Lads_mobile_sdk/dy2;->b:Ljava/lang/String;

    invoke-static {v11}, Lw53;->e(Ljava/lang/String;)Lads_mobile_sdk/qq;

    move-result-object v11

    invoke-virtual {v10}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v13, v10, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v13, Lads_mobile_sdk/rq;

    invoke-virtual {v13, v11}, Lads_mobile_sdk/rq;->a(Lads_mobile_sdk/qq;)V

    invoke-virtual {v10}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v11, v10, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v11, Lads_mobile_sdk/rq;

    invoke-static {v11}, Lads_mobile_sdk/rq;->d(Lads_mobile_sdk/rq;)I

    move-result v13

    or-int/lit16 v13, v13, 0x80

    invoke-static {v11, v13}, Lads_mobile_sdk/rq;->g(Lads_mobile_sdk/rq;I)V

    invoke-static {v11, v8}, Lads_mobile_sdk/rq;->f(Lads_mobile_sdk/rq;I)V

    iget-object v11, v6, Lads_mobile_sdk/dy2;->d:Ljava/lang/String;

    if-eqz v11, :cond_a9

    invoke-static {v11}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v11

    if-eqz v11, :cond_99

    goto :goto_a9

    :cond_99
    iget-object v11, v6, Lads_mobile_sdk/dy2;->d:Ljava/lang/String;

    if-nez v11, :cond_9e

    goto :goto_9f

    :cond_9e
    move-object v12, v11

    :goto_9f
    invoke-virtual {v10}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v11, v10, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v11, Lads_mobile_sdk/rq;

    invoke-virtual {v11, v12}, Lads_mobile_sdk/rq;->c(Ljava/lang/String;)V

    :cond_a9
    :goto_a9
    iget-object v11, v6, Lads_mobile_sdk/dy2;->g:Ljava/lang/Long;

    if-eqz v11, :cond_b2

    invoke-virtual {v11}, Ljava/lang/Long;->longValue()J

    move-result-wide v11

    goto :goto_b4

    :cond_b2
    const-wide/16 v11, 0x0

    :goto_b4
    invoke-virtual {v10}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v13, v10, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v13, Lads_mobile_sdk/rq;

    invoke-static {v13}, Lads_mobile_sdk/rq;->d(Lads_mobile_sdk/rq;)I

    move-result v14

    or-int/lit8 v14, v14, 0x40

    invoke-static {v13, v14}, Lads_mobile_sdk/rq;->g(Lads_mobile_sdk/rq;I)V

    invoke-static {v13, v11, v12}, Lads_mobile_sdk/rq;->h(Lads_mobile_sdk/rq;J)V

    iget-object v11, v6, Lads_mobile_sdk/dy2;->e:Ljava/lang/String;

    if-nez v11, :cond_da

    iget-object v11, v6, Lads_mobile_sdk/dy2;->f:Ljava/lang/Integer;

    if-eqz v11, :cond_d6

    invoke-virtual {v11}, Ljava/lang/Integer;->intValue()I

    move-result v11

    if-eqz v11, :cond_d6

    goto :goto_da

    :cond_d6
    const/16 v16, 0x0

    goto/16 :goto_18d

    :cond_da
    :goto_da
    invoke-static {}, Lads_mobile_sdk/oq;->o()Lz13;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v12, v6, Lads_mobile_sdk/dy2;->f:Ljava/lang/Integer;

    const/4 v14, 0x4

    const/4 v15, 0x3

    const/16 v16, 0x0

    const/4 v4, 0x2

    if-nez v12, :cond_eb

    goto :goto_f3

    :cond_eb
    invoke-virtual {v12}, Ljava/lang/Integer;->intValue()I

    move-result v13

    if-ne v13, v8, :cond_f3

    move v12, v4

    goto :goto_10a

    :cond_f3
    :goto_f3
    if-nez v12, :cond_f6

    goto :goto_fe

    :cond_f6
    invoke-virtual {v12}, Ljava/lang/Integer;->intValue()I

    move-result v13

    if-ne v13, v4, :cond_fe

    move v12, v15

    goto :goto_10a

    :cond_fe
    :goto_fe
    if-nez v12, :cond_101

    goto :goto_109

    :cond_101
    invoke-virtual {v12}, Ljava/lang/Integer;->intValue()I

    move-result v12

    if-ne v12, v15, :cond_109

    move v12, v14

    goto :goto_10a

    :cond_109
    :goto_109
    const/4 v12, 0x5

    :goto_10a
    invoke-virtual {v11}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v13, v11, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v13, Lads_mobile_sdk/oq;

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    packed-switch v12, :pswitch_data_2dc

    throw v16

    :pswitch_118  #0x17
    const/16 v7, 0xc9

    goto :goto_154

    :pswitch_11b  #0x16
    const/16 v7, 0xc8

    goto :goto_154

    :pswitch_11e  #0x15
    const/16 v7, 0x72

    goto :goto_154

    :pswitch_121  #0x14
    const/16 v7, 0x71

    goto :goto_154

    :pswitch_124  #0x13
    const/16 v7, 0x6f

    goto :goto_154

    :pswitch_127  #0x12
    const/16 v7, 0x70

    goto :goto_154

    :pswitch_12a  #0x11
    const/16 v7, 0x6e

    goto :goto_154

    :pswitch_12d  #0x10
    const/16 v7, 0x6d

    goto :goto_154

    :pswitch_130  #0xf
    const/16 v7, 0x6c

    goto :goto_154

    :pswitch_133  #0xe
    const/16 v7, 0x6b

    goto :goto_154

    :pswitch_136  #0xd
    const/16 v7, 0x6a

    goto :goto_154

    :pswitch_139  #0xc
    const/16 v7, 0x69

    goto :goto_154

    :pswitch_13c  #0xb
    const/16 v7, 0x68

    goto :goto_154

    :pswitch_13f  #0xa
    const/16 v7, 0x67

    goto :goto_154

    :pswitch_142  #0x9
    const/16 v7, 0x66

    goto :goto_154

    :pswitch_145  #0x8
    const/16 v7, 0x65

    goto :goto_154

    :pswitch_148  #0x7
    const/16 v7, 0x64

    goto :goto_154

    :pswitch_14b  #0x6
    const/4 v7, 0x5

    goto :goto_154

    :pswitch_14d  #0x5
    move v7, v14

    goto :goto_154

    :pswitch_14f  #0x4
    move v7, v15

    goto :goto_154

    :pswitch_151  #0x3
    move v7, v4

    goto :goto_154

    :pswitch_153  #0x2
    move v7, v8

    :goto_154
    :pswitch_154  #0x1
    invoke-static {v13, v7}, Lads_mobile_sdk/oq;->f(Lads_mobile_sdk/oq;I)V

    invoke-static {v13}, Lads_mobile_sdk/oq;->c(Lads_mobile_sdk/oq;)I

    move-result v4

    or-int/2addr v4, v8

    invoke-static {v13, v4}, Lads_mobile_sdk/oq;->d(Lads_mobile_sdk/oq;I)V

    iget-object v4, v6, Lads_mobile_sdk/dy2;->e:Ljava/lang/String;

    if-nez v4, :cond_173

    iget-object v4, v6, Lads_mobile_sdk/dy2;->f:Ljava/lang/Integer;

    new-instance v6, Ljava/lang/StringBuilder;

    const-string v7, "An undefined error occurred. Error code = "

    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    :cond_173
    invoke-virtual {v11}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v6, v11, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v6, Lads_mobile_sdk/oq;

    invoke-virtual {v6, v4}, Lads_mobile_sdk/oq;->b(Ljava/lang/String;)V

    invoke-virtual {v11}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object v4

    check-cast v4, Lads_mobile_sdk/oq;

    invoke-virtual {v10}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v6, v10, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v6, Lads_mobile_sdk/rq;

    invoke-virtual {v6, v4}, Lads_mobile_sdk/rq;->a(Lads_mobile_sdk/oq;)V

    :goto_18d
    invoke-virtual {v10}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object v4

    check-cast v4, Lads_mobile_sdk/rq;

    invoke-virtual {v2, v9, v4}, Lads_mobile_sdk/w8;->a(Lads_mobile_sdk/vj0;Lads_mobile_sdk/rq;)V

    goto/16 :goto_23

    :cond_198
    const/16 v16, 0x0

    iget-object v3, v0, Lads_mobile_sdk/au2;->s:Lg32;

    if-eqz v3, :cond_2d1

    iget-object v3, v3, Lg32;->Q:Ljava/util/Map;

    invoke-interface {v3}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_1a8
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_21f

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/util/Map$Entry;

    invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lb5;

    invoke-interface {v1, v6}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_1c7

    goto :goto_1a8

    :cond_1c7
    invoke-interface {v1, v6}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    invoke-virtual {v2}, Lads_mobile_sdk/w8;->b()Lads_mobile_sdk/vj0;

    move-result-object v9

    invoke-static {}, Lads_mobile_sdk/rq;->o()Lk13;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v10}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v11, v10, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v11, Lads_mobile_sdk/rq;

    invoke-virtual {v11, v6}, Lads_mobile_sdk/rq;->b(Ljava/lang/String;)V

    invoke-virtual {v10}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v6, v10, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v6, Lads_mobile_sdk/rq;

    invoke-static {v6}, Lads_mobile_sdk/rq;->d(Lads_mobile_sdk/rq;)I

    move-result v11

    or-int/lit16 v11, v11, 0x80

    invoke-static {v6, v11}, Lads_mobile_sdk/rq;->g(Lads_mobile_sdk/rq;I)V

    invoke-static {v6, v7}, Lads_mobile_sdk/rq;->f(Lads_mobile_sdk/rq;I)V

    iget-object v6, v4, Lb5;->b:Ljava/lang/String;

    invoke-static {v6}, Lw53;->e(Ljava/lang/String;)Lads_mobile_sdk/qq;

    move-result-object v6

    invoke-virtual {v10}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v11, v10, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v11, Lads_mobile_sdk/rq;

    invoke-virtual {v11, v6}, Lads_mobile_sdk/rq;->b(Lads_mobile_sdk/qq;)V

    iget-object v4, v4, Lb5;->a:Ljava/lang/String;

    invoke-static {v4}, Lw53;->e(Ljava/lang/String;)Lads_mobile_sdk/qq;

    move-result-object v4

    invoke-virtual {v10}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v6, v10, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v6, Lads_mobile_sdk/rq;

    invoke-virtual {v6, v4}, Lads_mobile_sdk/rq;->a(Lads_mobile_sdk/qq;)V

    invoke-virtual {v10}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object v4

    check-cast v4, Lads_mobile_sdk/rq;

    invoke-virtual {v2, v9, v4}, Lads_mobile_sdk/w8;->a(Lads_mobile_sdk/vj0;Lads_mobile_sdk/rq;)V

    goto :goto_1a8

    :cond_21f
    iget-object v1, v0, Lads_mobile_sdk/au2;->s:Lg32;

    if-eqz v1, :cond_2cd

    iget-object v1, v1, Lg32;->o1:Landroid/os/Bundle;

    if-nez v1, :cond_22c

    new-instance v1, Landroid/os/Bundle;

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    :cond_22c
    const-string v3, "a3p_cs"

    invoke-virtual {v1, v3}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    iget-object v3, v0, Lads_mobile_sdk/au2;->s:Lg32;

    if-eqz v3, :cond_2c9

    iget-object v3, v3, Lg32;->x0:Ljava/lang/String;

    if-eqz v1, :cond_291

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v4

    if-nez v4, :cond_241

    goto :goto_291

    :cond_241
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v3

    if-nez v3, :cond_248

    goto :goto_291

    :cond_248
    invoke-virtual {v2}, Lads_mobile_sdk/w8;->b()Lads_mobile_sdk/vj0;

    move-result-object v3

    invoke-static {}, Lads_mobile_sdk/rq;->o()Lk13;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v6, v0, Lads_mobile_sdk/au2;->s:Lg32;

    if-eqz v6, :cond_28d

    iget-object v5, v6, Lg32;->x0:Ljava/lang/String;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v4}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v6, v4, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v6, Lads_mobile_sdk/rq;

    invoke-virtual {v6, v5}, Lads_mobile_sdk/rq;->b(Ljava/lang/String;)V

    invoke-virtual {v4}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v5, v4, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v5, Lads_mobile_sdk/rq;

    invoke-virtual {v5, v1}, Lads_mobile_sdk/rq;->c(Ljava/lang/String;)V

    invoke-virtual {v4}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v1, v4, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v1, Lads_mobile_sdk/rq;

    invoke-static {v1}, Lads_mobile_sdk/rq;->d(Lads_mobile_sdk/rq;)I

    move-result v5

    or-int/lit16 v5, v5, 0x80

    invoke-static {v1, v5}, Lads_mobile_sdk/rq;->g(Lads_mobile_sdk/rq;I)V

    invoke-static {v1, v8}, Lads_mobile_sdk/rq;->f(Lads_mobile_sdk/rq;I)V

    invoke-virtual {v4}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object v1

    check-cast v1, Lads_mobile_sdk/rq;

    invoke-virtual {v2, v3, v1}, Lads_mobile_sdk/w8;->a(Lads_mobile_sdk/vj0;Lads_mobile_sdk/rq;)V

    goto :goto_291

    :cond_28d
    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v16

    :cond_291
    :goto_291
    iget-object v1, v2, Lads_mobile_sdk/w8;->a:Ljava/lang/Object;

    check-cast v1, Lxv2;

    invoke-virtual {v1}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object v1

    check-cast v1, Lads_mobile_sdk/sq;

    invoke-virtual {v1}, Lads_mobile_sdk/sq;->o()Lw63;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    if-lez v2, :cond_2c8

    invoke-virtual {v1}, Lads_mobile_sdk/g;->a()[B

    move-result-object v1

    const/16 v2, 0xa

    invoke-static {v1, v2}, Landroid/util/Base64;->encode([BI)[B

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v2, Ljava/lang/String;

    sget-object v3, Lip;->a:Ljava/nio/charset/Charset;

    invoke-direct {v2, v1, v3}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const-string v1, "="

    const-string v3, "."

    invoke-static {v2, v1, v3, v7}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v1

    const-string v2, "a3p"

    const-string v3, "third_party_params"

    invoke-virtual {v0, v2, v1, v3}, Lads_mobile_sdk/au2;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    :cond_2c8
    return-void

    :cond_2c9
    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v16

    :cond_2cd
    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v16

    :cond_2d1
    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v16

    :cond_2d5
    const/16 v16, 0x0

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v16

    nop

    :pswitch_data_2dc
    .packed-switch 0x1
        :pswitch_154  #00000001
        :pswitch_153  #00000002
        :pswitch_151  #00000003
        :pswitch_14f  #00000004
        :pswitch_14d  #00000005
        :pswitch_14b  #00000006
        :pswitch_148  #00000007
        :pswitch_145  #00000008
        :pswitch_142  #00000009
        :pswitch_13f  #0000000a
        :pswitch_13c  #0000000b
        :pswitch_139  #0000000c
        :pswitch_136  #0000000d
        :pswitch_133  #0000000e
        :pswitch_130  #0000000f
        :pswitch_12d  #00000010
        :pswitch_12a  #00000011
        :pswitch_127  #00000012
        :pswitch_124  #00000013
        :pswitch_121  #00000014
        :pswitch_11e  #00000015
        :pswitch_11b  #00000016
        :pswitch_118  #00000017
    .end packed-switch
.end method
