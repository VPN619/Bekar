.class public final Lads_mobile_sdk/f92;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lbw2;


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:Lads_mobile_sdk/qr0;

.field public final c:Lads_mobile_sdk/ax0;

.field public final d:Lads_mobile_sdk/k8;

.field public final e:Lads_mobile_sdk/z2;

.field public final f:Lads_mobile_sdk/g0;

.field public final g:Ltv2;

.field public final h:Ltv2;

.field public final i:Lads_mobile_sdk/rr1;

.field public final j:Lads_mobile_sdk/dl;

.field public final k:Lads_mobile_sdk/av2;

.field public final l:Lads_mobile_sdk/b90;

.field public final m:Lads_mobile_sdk/gn0;

.field public final n:Lads_mobile_sdk/a2;

.field public final o:Lads_mobile_sdk/jz2;

.field public final p:Lads_mobile_sdk/o42;

.field public final q:Lads_mobile_sdk/qf2;

.field public final r:Lads_mobile_sdk/s01;

.field public final s:Lads_mobile_sdk/ah3;

.field public final t:Lads_mobile_sdk/xv;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lads_mobile_sdk/qr0;Lads_mobile_sdk/ax0;Lads_mobile_sdk/k8;Lads_mobile_sdk/z2;Lads_mobile_sdk/g0;Lads_mobile_sdk/i12;Ltv2;Lads_mobile_sdk/rr1;Lads_mobile_sdk/dl;Lads_mobile_sdk/av2;Lads_mobile_sdk/b90;Lads_mobile_sdk/gn0;Lads_mobile_sdk/a2;Lads_mobile_sdk/jz2;Lads_mobile_sdk/o42;Lads_mobile_sdk/qf2;Lads_mobile_sdk/s01;Lads_mobile_sdk/ah3;Lads_mobile_sdk/xv;)V
    .registers 21

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p16 .. p16}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p17 .. p17}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p18 .. p18}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p19 .. p19}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p20 .. p20}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/f92;->a:Landroid/content/Context;

    iput-object p2, p0, Lads_mobile_sdk/f92;->b:Lads_mobile_sdk/qr0;

    iput-object p3, p0, Lads_mobile_sdk/f92;->c:Lads_mobile_sdk/ax0;

    iput-object p4, p0, Lads_mobile_sdk/f92;->d:Lads_mobile_sdk/k8;

    iput-object p5, p0, Lads_mobile_sdk/f92;->e:Lads_mobile_sdk/z2;

    iput-object p6, p0, Lads_mobile_sdk/f92;->f:Lads_mobile_sdk/g0;

    iput-object p7, p0, Lads_mobile_sdk/f92;->g:Ltv2;

    iput-object p8, p0, Lads_mobile_sdk/f92;->h:Ltv2;

    iput-object p9, p0, Lads_mobile_sdk/f92;->i:Lads_mobile_sdk/rr1;

    iput-object p10, p0, Lads_mobile_sdk/f92;->j:Lads_mobile_sdk/dl;

    iput-object p11, p0, Lads_mobile_sdk/f92;->k:Lads_mobile_sdk/av2;

    iput-object p12, p0, Lads_mobile_sdk/f92;->l:Lads_mobile_sdk/b90;

    iput-object p13, p0, Lads_mobile_sdk/f92;->m:Lads_mobile_sdk/gn0;

    iput-object p14, p0, Lads_mobile_sdk/f92;->n:Lads_mobile_sdk/a2;

    iput-object p15, p0, Lads_mobile_sdk/f92;->o:Lads_mobile_sdk/jz2;

    move-object/from16 p1, p16

    iput-object p1, p0, Lads_mobile_sdk/f92;->p:Lads_mobile_sdk/o42;

    move-object/from16 p1, p17

    iput-object p1, p0, Lads_mobile_sdk/f92;->q:Lads_mobile_sdk/qf2;

    move-object/from16 p1, p18

    iput-object p1, p0, Lads_mobile_sdk/f92;->r:Lads_mobile_sdk/s01;

    move-object/from16 p1, p19

    iput-object p1, p0, Lads_mobile_sdk/f92;->s:Lads_mobile_sdk/ah3;

    move-object/from16 p1, p20

    iput-object p1, p0, Lads_mobile_sdk/f92;->t:Lads_mobile_sdk/xv;

    return-void
.end method

.method public static b(Ljava/util/Map;)I
    .registers 3

    .prologue
    const-string v0, "o"

    invoke-interface {p0, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    if-eqz p0, :cond_3c

    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/16 v1, 0x63

    if-eq v0, v1, :cond_30

    const/16 v1, 0x6c

    if-eq v0, v1, :cond_26

    const/16 v1, 0x70

    if-eq v0, v1, :cond_1b

    goto :goto_3c

    :cond_1b
    const-string v0, "p"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_24

    goto :goto_3c

    :cond_24
    const/4 p0, 0x7

    return p0

    :cond_26
    const-string v0, "l"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_3c

    const/4 p0, 0x6

    return p0

    :cond_30
    const-string v0, "c"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_39

    goto :goto_3c

    :cond_39
    const/16 p0, 0xe

    return p0

    :cond_3c
    :goto_3c
    const/4 p0, -0x1

    return p0
.end method


# virtual methods
.method public final a(Landroid/content/Intent;Ljava/util/List;)Landroid/content/pm/ResolveInfo;
    .registers 6

    .prologue
    iget-object p0, p0, Lads_mobile_sdk/f92;->a:Landroid/content/Context;

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/high16 v0, 0x10000

    invoke-virtual {p0, p1, v0}, Landroid/content/pm/PackageManager;->resolveActivity(Landroid/content/Intent;I)Landroid/content/pm/ResolveInfo;

    move-result-object p0

    const/4 p1, 0x0

    if-nez p0, :cond_10

    goto :goto_34

    :cond_10
    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :cond_14
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_30

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Landroid/content/pm/ResolveInfo;

    iget-object v1, v1, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    iget-object v1, v1, Landroid/content/pm/ActivityInfo;->name:Ljava/lang/String;

    iget-object v2, p0, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    iget-object v2, v2, Landroid/content/pm/ActivityInfo;->name:Ljava/lang/String;

    invoke-static {v1, v2}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_14

    goto :goto_31

    :cond_30
    move-object v0, p1

    :goto_31
    if-eqz v0, :cond_34

    return-object p0

    :cond_34
    :goto_34
    return-object p1
.end method

.method public final a(Lads_mobile_sdk/cy0;Ljava/util/Map;Lvx;)Ljava/lang/Object;
    .registers 23

    .prologue
    move-object/from16 v1, p0

    move-object/from16 v2, p2

    move-object/from16 v0, p3

    instance-of v3, v0, Lads_mobile_sdk/c92;

    if-eqz v3, :cond_1a

    move-object v3, v0

    check-cast v3, Lads_mobile_sdk/c92;

    iget v4, v3, Lads_mobile_sdk/c92;->k:I

    const/high16 v5, -0x80000000

    and-int v6, v4, v5

    if-eqz v6, :cond_1a

    sub-int/2addr v4, v5

    iput v4, v3, Lads_mobile_sdk/c92;->k:I

    :goto_18
    move-object v6, v3

    goto :goto_20

    :cond_1a
    new-instance v3, Lads_mobile_sdk/c92;

    invoke-direct {v3, v1, v0}, Lads_mobile_sdk/c92;-><init>(Lads_mobile_sdk/f92;Lvx;)V

    goto :goto_18

    :goto_20
    iget-object v0, v6, Lads_mobile_sdk/c92;->i:Ljava/lang/Object;

    sget-object v12, Lwy;->a:Lwy;

    iget v3, v6, Lads_mobile_sdk/c92;->k:I

    const/16 v4, 0x1b

    const/4 v5, 0x2

    const/4 v7, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x0

    const/4 v13, 0x0

    packed-switch v3, :pswitch_data_6ce

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {v0}, Lz6;->w(Ljava/lang/String;)V

    return-object v13

    :pswitch_36  #0xa
    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    goto/16 :goto_6b4

    :pswitch_3b  #0x9
    iget v1, v6, Lads_mobile_sdk/c92;->g:I

    iget-boolean v2, v6, Lads_mobile_sdk/c92;->h:Z

    iget v3, v6, Lads_mobile_sdk/c92;->f:I

    iget-object v4, v6, Lads_mobile_sdk/c92;->d:Ljava/lang/Object;

    check-cast v4, Landroid/content/Intent;

    iget-object v5, v6, Lads_mobile_sdk/c92;->c:Ljava/util/Map;

    iget-object v7, v6, Lads_mobile_sdk/c92;->b:Lads_mobile_sdk/cy0;

    iget-object v8, v6, Lads_mobile_sdk/c92;->a:Ljava/lang/Object;

    check-cast v8, Lads_mobile_sdk/f92;

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    move v9, v2

    move-object v10, v7

    move-object v15, v12

    goto/16 :goto_676

    :pswitch_55  #0x8
    iget v1, v6, Lads_mobile_sdk/c92;->g:I

    iget-boolean v2, v6, Lads_mobile_sdk/c92;->h:Z

    iget v3, v6, Lads_mobile_sdk/c92;->f:I

    iget-object v7, v6, Lads_mobile_sdk/c92;->d:Ljava/lang/Object;

    check-cast v7, Landroid/content/Intent;

    iget-object v8, v6, Lads_mobile_sdk/c92;->c:Ljava/util/Map;

    iget-object v9, v6, Lads_mobile_sdk/c92;->b:Lads_mobile_sdk/cy0;

    iget-object v14, v6, Lads_mobile_sdk/c92;->a:Ljava/lang/Object;

    check-cast v14, Lads_mobile_sdk/f92;

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    move-object v4, v7

    move v7, v2

    move-object v2, v4

    move-object v5, v8

    move-object v8, v9

    move/from16 v16, v10

    move-object v4, v14

    move-object v9, v6

    goto/16 :goto_5dc

    :pswitch_75  #0x7
    iget v1, v6, Lads_mobile_sdk/c92;->g:I

    iget-boolean v2, v6, Lads_mobile_sdk/c92;->h:Z

    iget v3, v6, Lads_mobile_sdk/c92;->f:I

    iget-object v7, v6, Lads_mobile_sdk/c92;->e:Landroid/content/Intent;

    iget-object v8, v6, Lads_mobile_sdk/c92;->d:Ljava/lang/Object;

    check-cast v8, Ljava/lang/String;

    iget-object v9, v6, Lads_mobile_sdk/c92;->c:Ljava/util/Map;

    iget-object v14, v6, Lads_mobile_sdk/c92;->b:Lads_mobile_sdk/cy0;

    iget-object v15, v6, Lads_mobile_sdk/c92;->a:Ljava/lang/Object;

    check-cast v15, Lads_mobile_sdk/f92;

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    move-object v0, v9

    move/from16 v16, v10

    move-object v9, v6

    goto/16 :goto_598

    :pswitch_92  #0x6
    iget v1, v6, Lads_mobile_sdk/c92;->g:I

    iget-boolean v2, v6, Lads_mobile_sdk/c92;->h:Z

    iget v3, v6, Lads_mobile_sdk/c92;->f:I

    iget-object v7, v6, Lads_mobile_sdk/c92;->d:Ljava/lang/Object;

    check-cast v7, Ljava/lang/String;

    iget-object v8, v6, Lads_mobile_sdk/c92;->c:Ljava/util/Map;

    iget-object v9, v6, Lads_mobile_sdk/c92;->b:Lads_mobile_sdk/cy0;

    iget-object v14, v6, Lads_mobile_sdk/c92;->a:Ljava/lang/Object;

    check-cast v14, Lads_mobile_sdk/f92;

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    move-object/from16 v16, v9

    move-object v9, v6

    move-object/from16 v6, v16

    move/from16 v16, v10

    goto/16 :goto_433

    :pswitch_b0  #0x5
    iget v1, v6, Lads_mobile_sdk/c92;->g:I

    iget-boolean v2, v6, Lads_mobile_sdk/c92;->h:Z

    iget v3, v6, Lads_mobile_sdk/c92;->f:I

    iget-object v7, v6, Lads_mobile_sdk/c92;->d:Ljava/lang/Object;

    check-cast v7, Ljava/lang/String;

    iget-object v8, v6, Lads_mobile_sdk/c92;->c:Ljava/util/Map;

    iget-object v9, v6, Lads_mobile_sdk/c92;->b:Lads_mobile_sdk/cy0;

    iget-object v14, v6, Lads_mobile_sdk/c92;->a:Ljava/lang/Object;

    check-cast v14, Lads_mobile_sdk/f92;

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    move-object/from16 v16, v9

    move-object v9, v6

    move-object/from16 v6, v16

    move/from16 v16, v10

    goto/16 :goto_3f3

    :pswitch_ce  #0x4
    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    goto/16 :goto_36f

    :pswitch_d3  #0x3
    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    goto/16 :goto_26e

    :pswitch_d8  #0x2
    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    goto/16 :goto_24f

    :pswitch_dd  #0x1
    iget-object v1, v6, Lads_mobile_sdk/c92;->a:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_127

    :pswitch_e5  #0x0
    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    const-string v0, "a"

    invoke-interface {v2, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    move-object v3, v0

    check-cast v3, Ljava/lang/String;

    if-eqz v3, :cond_f9

    invoke-static {v3}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_fc

    :cond_f9
    move-object v8, v2

    goto/16 :goto_6b7

    :cond_fc
    const-string v0, "Handling \""

    const-string v8, "\" open GMSG"

    invoke-static {v0, v3, v8, v13}, Lrt2;->s(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    iget-object v0, v1, Lads_mobile_sdk/f92;->o:Lads_mobile_sdk/jz2;

    invoke-virtual {v0}, Lads_mobile_sdk/jz2;->a()Z

    move-result v0

    if-nez v0, :cond_13b

    const-string v0, "u"

    invoke-interface {v2, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    if-nez v0, :cond_117

    const-string v0, "NO_URL"

    :cond_117
    iget-object v1, v1, Lads_mobile_sdk/f92;->o:Lads_mobile_sdk/jz2;

    iput-object v0, v6, Lads_mobile_sdk/c92;->a:Ljava/lang/Object;

    iput v10, v6, Lads_mobile_sdk/c92;->k:I

    invoke-virtual {v1, v0, v6}, Lads_mobile_sdk/jz2;->b(Ljava/lang/String;Lwx;)Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v12, :cond_126

    :goto_123
    move-object v15, v12

    goto/16 :goto_6b3

    :cond_126
    move-object v1, v0

    :goto_127
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "Safe browsing blocked auto click: "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v7, v0, v13}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    sget-object v0, Lrg2;->a:Lrg2;

    return-object v0

    :cond_13b
    iget-object v0, v1, Lads_mobile_sdk/f92;->t:Lads_mobile_sdk/xv;

    iget-boolean v8, v0, Lads_mobile_sdk/xv;->u:Z

    const-string v0, "sc"

    invoke-interface {v2, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v9, "0"

    invoke-static {v0, v9, v11}, Lk72;->f0(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_150

    goto :goto_16e

    :cond_150
    const-string v0, "ig_cl"

    invoke-interface {v2, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v9, "true"

    invoke-static {v0, v9, v11}, Lk72;->f0(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v0

    if-eqz v0, :cond_161

    goto :goto_16e

    :cond_161
    iget-object v0, v1, Lads_mobile_sdk/f92;->k:Lads_mobile_sdk/av2;

    sget-object v9, Lads_mobile_sdk/av2;->i:Lads_mobile_sdk/av2;

    if-eq v0, v9, :cond_16e

    sget-object v9, Lads_mobile_sdk/av2;->g:Lads_mobile_sdk/av2;

    if-ne v0, v9, :cond_16c

    goto :goto_16e

    :cond_16c
    move v9, v10

    goto :goto_16f

    :cond_16e
    :goto_16e
    move v9, v11

    :goto_16f
    const-string v0, "expand"

    invoke-virtual {v0, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    const/4 v14, 0x4

    if-eqz v0, :cond_252

    iget-object v0, v1, Lads_mobile_sdk/f92;->i:Lads_mobile_sdk/rr1;

    invoke-virtual {v0, v11}, Lads_mobile_sdk/rr1;->a(Z)V

    iput v5, v6, Lads_mobile_sdk/c92;->k:I

    iget-object v0, v1, Lads_mobile_sdk/f92;->g:Ltv2;

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/v82;

    const-string v1, "custom_close"

    invoke-interface {v2, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const-string v3, "1"

    invoke-static {v1, v3}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    invoke-static {v2}, Lads_mobile_sdk/f92;->b(Ljava/util/Map;)I

    move-result v2

    iget-object v3, v0, Lads_mobile_sdk/v82;->Q:Ljava/util/Optional;

    invoke-static {v3}, Lw53;->I(Ljava/util/Optional;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lads_mobile_sdk/sy0;

    if-eqz v3, :cond_244

    iput-object v3, v0, Lads_mobile_sdk/mt0;->q:Landroid/view/ViewGroup;

    iget-object v3, v0, Lads_mobile_sdk/v82;->Q:Ljava/util/Optional;

    invoke-static {v3}, Lw53;->I(Ljava/util/Optional;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lads_mobile_sdk/sy0;

    if-nez v3, :cond_1b1

    sget-object v0, Lrg2;->a:Lrg2;

    goto/16 :goto_246

    :cond_1b1
    iput-object v3, v0, Lads_mobile_sdk/ks0;->G:Lads_mobile_sdk/sy0;

    iget-object v3, v0, Lads_mobile_sdk/ks0;->H:Lw82;

    invoke-virtual {v3}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lads_mobile_sdk/cy0;

    iget-object v3, v3, Lads_mobile_sdk/cy0;->n:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v3

    if-nez v3, :cond_23c

    iget-object v3, v0, Lads_mobile_sdk/ks0;->H:Lw82;

    invoke-virtual {v3}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lads_mobile_sdk/cy0;

    invoke-virtual {v3}, Lads_mobile_sdk/cy0;->e()Lads_mobile_sdk/cr3;

    move-result-object v3

    iget v3, v3, Lads_mobile_sdk/cr3;->a:I

    if-ne v3, v14, :cond_1d4

    goto :goto_23c

    :cond_1d4
    iput-boolean v1, v0, Lads_mobile_sdk/mt0;->s:Z

    iput v2, v0, Lads_mobile_sdk/ks0;->J:I

    iput-boolean v11, v0, Lads_mobile_sdk/mt0;->u:Z

    iput-boolean v9, v0, Lads_mobile_sdk/st0;->O:Z

    iget-object v1, v0, Lads_mobile_sdk/ks0;->H:Lw82;

    invoke-virtual {v1}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lads_mobile_sdk/cy0;

    iget-object v1, v1, Lads_mobile_sdk/cy0;->n:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v1, v10}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    invoke-virtual {v0}, Lads_mobile_sdk/mt0;->g()Landroid/view/View;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v1

    if-eqz v1, :cond_234

    instance-of v2, v1, Landroid/view/ViewGroup;

    if-eqz v2, :cond_234

    new-instance v2, Lads_mobile_sdk/rp3;

    invoke-virtual {v0}, Lads_mobile_sdk/mt0;->g()Landroid/view/View;

    move-result-object v3

    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-object v5, v1

    check-cast v5, Landroid/view/ViewGroup;

    invoke-virtual {v0}, Lads_mobile_sdk/mt0;->g()Landroid/view/View;

    move-result-object v7

    invoke-virtual {v5, v7}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    move-result v7

    iget-object v8, v0, Lads_mobile_sdk/ks0;->H:Lw82;

    invoke-virtual {v8}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lads_mobile_sdk/cy0;

    invoke-virtual {v8}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {v2, v3, v7, v5, v8}, Lads_mobile_sdk/rp3;-><init>(Landroid/view/ViewGroup$LayoutParams;ILandroid/view/ViewGroup;Landroid/content/Context;)V

    iput-object v2, v0, Lads_mobile_sdk/v82;->R:Lads_mobile_sdk/rp3;

    iget-object v2, v0, Lads_mobile_sdk/mt0;->c:Lly;

    new-instance v3, Lb11;

    invoke-direct {v3, v1, v0, v13, v4}, Lb11;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lvx;I)V

    invoke-static {v2, v3, v6}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object v0

    if-ne v0, v12, :cond_231

    goto :goto_246

    :cond_231
    sget-object v0, Lrg2;->a:Lrg2;

    goto :goto_246

    :cond_234
    const-string v0, "Could not get parent of webview for one-piece expandable"

    invoke-static {v7, v0, v13}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    sget-object v0, Lrg2;->a:Lrg2;

    goto :goto_246

    :cond_23c
    :goto_23c
    const-string v0, "Tried to one-piece expand an expanded webview"

    invoke-static {v7, v0, v13}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    sget-object v0, Lrg2;->a:Lrg2;

    goto :goto_246

    :cond_244
    sget-object v0, Lrg2;->a:Lrg2;

    :goto_246
    if-ne v0, v12, :cond_249

    goto :goto_24b

    :cond_249
    sget-object v0, Lrg2;->a:Lrg2;

    :goto_24b
    if-ne v0, v12, :cond_24f

    goto/16 :goto_123

    :cond_24f
    :goto_24f
    sget-object v0, Lrg2;->a:Lrg2;

    return-object v0

    :cond_252
    const-string v0, "webapp"

    invoke-virtual {v0, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    iget-object v15, v1, Lads_mobile_sdk/f92;->i:Lads_mobile_sdk/rr1;

    if-eqz v0, :cond_271

    invoke-virtual {v15, v11}, Lads_mobile_sdk/rr1;->a(Z)V

    const/4 v0, 0x3

    iput v0, v6, Lads_mobile_sdk/c92;->k:I

    move-object/from16 v5, p1

    move v4, v8

    move v3, v9

    invoke-virtual/range {v1 .. v6}, Lads_mobile_sdk/f92;->b(Ljava/util/Map;ZZLads_mobile_sdk/cy0;Lwx;)Ljava/lang/Object;

    move-result-object v0

    if-ne v0, v12, :cond_26e

    goto/16 :goto_123

    :cond_26e
    :goto_26e
    sget-object v0, Lrg2;->a:Lrg2;

    return-object v0

    :cond_271
    move/from16 v18, v8

    move v8, v4

    move v4, v9

    move v9, v5

    move/from16 v5, v18

    invoke-virtual {v15, v10}, Lads_mobile_sdk/rr1;->a(Z)V

    const-string v0, "intent_async"

    invoke-virtual {v0, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_28d

    const-string v0, "event_id"

    invoke-interface {v2, v0}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_28d

    move v15, v10

    goto :goto_28e

    :cond_28d
    move v15, v11

    :goto_28e
    const-string v0, "chrome_custom_tab"

    invoke-virtual {v0, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_383

    iget-object v0, v1, Lads_mobile_sdk/f92;->b:Lads_mobile_sdk/qr0;

    const-string v8, "gads:cct_v2_optimization:enabled"

    move/from16 v16, v10

    sget-object v10, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sget-object v9, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    invoke-virtual {v0, v8, v10, v9}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    iget-object v8, v1, Lads_mobile_sdk/f92;->a:Landroid/content/Context;

    if-eqz v0, :cond_2c9

    invoke-static {v8}, Lec;->D(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_2bc

    :cond_2b4
    :goto_2b4
    move-object v8, v2

    move-object v9, v6

    move-object/from16 v6, p1

    move-object v2, v1

    move v1, v15

    goto/16 :goto_37d

    :cond_2bc
    iget-object v8, v1, Lads_mobile_sdk/f92;->a:Landroid/content/Context;

    invoke-virtual {v8}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v8

    invoke-static {v8, v0}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_323

    goto :goto_2b4

    :cond_2c9
    invoke-virtual {v8}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    new-instance v8, Landroid/content/Intent;

    const-string v9, "http://"

    invoke-static {v9}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v9

    const-string v10, "android.intent.action.VIEW"

    invoke-direct {v8, v10, v9}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    invoke-virtual {v0, v8, v11}, Landroid/content/pm/PackageManager;->resolveActivity(Landroid/content/Intent;I)Landroid/content/pm/ResolveInfo;

    move-result-object v9

    if-nez v9, :cond_2e1

    goto :goto_2b4

    :cond_2e1
    const/high16 v10, 0x10000

    invoke-virtual {v0, v8, v10}, Landroid/content/pm/PackageManager;->queryIntentActivities(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    instance-of v8, v0, Ljava/util/Collection;

    if-eqz v8, :cond_2f5

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v8

    if-eqz v8, :cond_2f5

    goto :goto_2b4

    :cond_2f5
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_2f9
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_2b4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Landroid/content/pm/ResolveInfo;

    iget-object v10, v9, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    iget-object v10, v10, Landroid/content/pm/ActivityInfo;->name:Ljava/lang/String;

    iget-object v8, v8, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    iget-object v8, v8, Landroid/content/pm/ActivityInfo;->name:Ljava/lang/String;

    invoke-static {v10, v8}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_372

    iget-object v8, v9, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    iget-object v8, v8, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    iget-object v10, v1, Lads_mobile_sdk/f92;->a:Landroid/content/Context;

    invoke-static {v10}, Lec;->D(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v10

    invoke-static {v8, v10}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_372

    :cond_323
    iget-object v0, v1, Lads_mobile_sdk/f92;->f:Lads_mobile_sdk/g0;

    invoke-virtual {v0}, Lads_mobile_sdk/g0;->b()Landroid/app/Activity;

    move-result-object v0

    if-nez v0, :cond_337

    const-string v0, "Chrome Custom Tabs can only be launched from an Activity context."

    invoke-static {v7, v0, v13}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    :goto_330
    move-object v8, v2

    move-object v9, v6

    :goto_332
    move-object/from16 v6, p1

    move-object v2, v1

    move v1, v15

    goto :goto_388

    :cond_337
    iget-object v0, v1, Lads_mobile_sdk/f92;->b:Lads_mobile_sdk/qr0;

    const-string v8, "gads:cct_v2_connection:enabled"

    sget-object v9, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sget-object v10, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    invoke-virtual {v0, v8, v9, v10}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-nez v0, :cond_361

    iget-object v0, v1, Lads_mobile_sdk/f92;->b:Lads_mobile_sdk/qr0;

    const-string v8, "gads:cct_v2_optimization:enabled"

    invoke-virtual {v0, v8, v9, v10}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-nez v0, :cond_361

    const-string v0, "None of the CCT Connection and optimization experiments are enabled."

    invoke-static {v7, v0, v13}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    goto :goto_330

    :cond_361
    iput v14, v6, Lads_mobile_sdk/c92;->k:I

    move-object v7, v6

    move v3, v15

    move-object/from16 v6, p1

    invoke-virtual/range {v1 .. v7}, Lads_mobile_sdk/f92;->a(Ljava/util/Map;ZZZLads_mobile_sdk/cy0;Lwx;)Ljava/lang/Object;

    move-result-object v0

    if-ne v0, v12, :cond_36f

    goto/16 :goto_123

    :cond_36f
    :goto_36f
    sget-object v0, Lrg2;->a:Lrg2;

    return-object v0

    :cond_372
    move-object v8, v2

    move-object v10, v9

    move-object v2, v1

    move-object v9, v6

    move-object/from16 v6, p1

    move-object v2, v8

    move-object v6, v9

    move-object v9, v10

    goto/16 :goto_2f9

    :goto_37d
    const-string v0, "Chrome Custom Tabs is not supported."

    invoke-static {v7, v0, v13}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    goto :goto_388

    :cond_383
    move-object v8, v2

    move-object v9, v6

    move/from16 v16, v10

    goto :goto_332

    :goto_388
    const-string v0, "open_app"

    invoke-virtual {v0, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_3be

    const-string v0, "p"

    invoke-interface {v8, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    if-nez v0, :cond_3ad

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v10, "Package name missing from open app action: "

    invoke-direct {v0, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v7, v0, v13}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    move-object v0, v13

    goto :goto_3b7

    :cond_3ad
    iget-object v7, v2, Lads_mobile_sdk/f92;->a:Landroid/content/Context;

    invoke-virtual {v7}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v7

    invoke-virtual {v7, v0}, Landroid/content/pm/PackageManager;->getLaunchIntentForPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v0

    :goto_3b7
    move-object v7, v0

    move-object v14, v2

    move-object v0, v3

    move v3, v4

    move v2, v5

    goto/16 :goto_564

    :cond_3be
    const-string v0, "app"

    invoke-virtual {v0, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_3fc

    const-string v0, "system_browser"

    invoke-interface {v8, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    const-string v10, "true"

    invoke-virtual {v10, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_3fc

    iput-object v2, v9, Lads_mobile_sdk/c92;->a:Ljava/lang/Object;

    iput-object v6, v9, Lads_mobile_sdk/c92;->b:Lads_mobile_sdk/cy0;

    iput-object v8, v9, Lads_mobile_sdk/c92;->c:Ljava/util/Map;

    iput-object v3, v9, Lads_mobile_sdk/c92;->d:Ljava/lang/Object;

    iput v4, v9, Lads_mobile_sdk/c92;->f:I

    iput-boolean v5, v9, Lads_mobile_sdk/c92;->h:Z

    iput v1, v9, Lads_mobile_sdk/c92;->g:I

    const/4 v0, 0x5

    iput v0, v9, Lads_mobile_sdk/c92;->k:I

    invoke-virtual {v2, v6, v8, v9}, Lads_mobile_sdk/f92;->b(Lads_mobile_sdk/cy0;Ljava/util/Map;Lwx;)Ljava/lang/Object;

    move-result-object v0

    if-ne v0, v12, :cond_3ef

    goto/16 :goto_123

    :cond_3ef
    move-object v14, v2

    move-object v7, v3

    move v3, v4

    move v2, v5

    :goto_3f3
    check-cast v0, Landroid/content/Intent;

    :goto_3f5
    move-object/from16 v18, v7

    move-object v7, v0

    move-object/from16 v0, v18

    goto/16 :goto_564

    :cond_3fc
    const-string v0, "chrome_custom_tab"

    invoke-virtual {v0, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_436

    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0, v8}, Ljava/util/LinkedHashMap;-><init>(Ljava/util/Map;)V

    const-string v10, "use_first_package"

    const-string v14, "true"

    invoke-interface {v0, v10, v14}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v10, "use_running_process"

    const-string v14, "true"

    invoke-interface {v0, v10, v14}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iput-object v2, v9, Lads_mobile_sdk/c92;->a:Ljava/lang/Object;

    iput-object v6, v9, Lads_mobile_sdk/c92;->b:Lads_mobile_sdk/cy0;

    iput-object v8, v9, Lads_mobile_sdk/c92;->c:Ljava/util/Map;

    iput-object v3, v9, Lads_mobile_sdk/c92;->d:Ljava/lang/Object;

    iput v4, v9, Lads_mobile_sdk/c92;->f:I

    iput-boolean v5, v9, Lads_mobile_sdk/c92;->h:Z

    iput v1, v9, Lads_mobile_sdk/c92;->g:I

    iput v7, v9, Lads_mobile_sdk/c92;->k:I

    invoke-virtual {v2, v6, v0, v9}, Lads_mobile_sdk/f92;->b(Lads_mobile_sdk/cy0;Ljava/util/Map;Lwx;)Ljava/lang/Object;

    move-result-object v0

    if-ne v0, v12, :cond_42f

    goto/16 :goto_123

    :cond_42f
    move-object v14, v2

    move-object v7, v3

    move v3, v4

    move v2, v5

    :goto_433
    check-cast v0, Landroid/content/Intent;

    goto :goto_3f5

    :cond_436
    const-string v10, "): "

    iget-object v14, v2, Lads_mobile_sdk/f92;->d:Lads_mobile_sdk/k8;

    const-string v0, "intent_url"

    invoke-interface {v8, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    move-object v15, v0

    check-cast v15, Ljava/lang/String;

    if-eqz v15, :cond_47e

    invoke-static {v15}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_44c

    goto :goto_47e

    :cond_44c
    :try_start_44c
    invoke-static {v15, v11}, Landroid/content/Intent;->parseUri(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v7
    :try_end_450
    .catch Ljava/net/URISyntaxException; {:try_start_44c .. :try_end_450} :catch_464

    :try_start_450
    invoke-virtual {v7}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v0

    if-eqz v0, :cond_47f

    invoke-virtual {v14, v0, v6}, Lads_mobile_sdk/k8;->a(Landroid/net/Uri;Landroid/view/View;)Landroid/net/Uri;

    move-result-object v0

    invoke-virtual {v7}, Landroid/content/Intent;->getType()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v7, v0, v13}, Landroid/content/Intent;->setDataAndType(Landroid/net/Uri;Ljava/lang/String;)Landroid/content/Intent;
    :try_end_461
    .catch Ljava/net/URISyntaxException; {:try_start_450 .. :try_end_461} :catch_462

    goto :goto_47f

    :catch_462
    move-exception v0

    goto :goto_466

    :catch_464
    move-exception v0

    const/4 v7, 0x0

    :goto_466
    new-instance v13, Ljava/lang/StringBuilder;

    const-string v11, "Error parsing the intent url ("

    invoke-direct {v13, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v13, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lads_mobile_sdk/xh3;->a(Ljava/lang/String;)V

    goto :goto_47f

    :cond_47e
    :goto_47e
    const/4 v7, 0x0

    :cond_47f
    :goto_47f
    if-nez v7, :cond_55b

    const-string v0, "u"

    invoke-interface {v8, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    if-eqz v0, :cond_491

    invoke-static {v0}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v11

    if-eqz v11, :cond_496

    :cond_491
    move/from16 v17, v1

    const/4 v11, 0x0

    goto/16 :goto_547

    :cond_496
    const-string v7, "m"

    invoke-interface {v8, v7}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    const-string v11, "p"

    invoke-interface {v8, v11}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    const-string v13, "c"

    invoke-interface {v8, v13}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/String;

    const-string v15, "f"

    invoke-interface {v8, v15}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Ljava/lang/String;

    move/from16 v17, v1

    new-instance v1, Landroid/content/Intent;

    invoke-direct {v1}, Landroid/content/Intent;-><init>()V

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    invoke-virtual {v14, v0, v6}, Lads_mobile_sdk/k8;->a(Landroid/net/Uri;Landroid/view/View;)Landroid/net/Uri;

    move-result-object v0

    if-eqz v7, :cond_4d2

    invoke-static {v7}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v14

    if-eqz v14, :cond_4ce

    goto :goto_4d2

    :cond_4ce
    invoke-virtual {v1, v0, v7}, Landroid/content/Intent;->setDataAndType(Landroid/net/Uri;Ljava/lang/String;)Landroid/content/Intent;

    goto :goto_4d5

    :cond_4d2
    :goto_4d2
    invoke-virtual {v1, v0}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    :goto_4d5
    const-string v0, "android.intent.action.VIEW"

    invoke-virtual {v1, v0}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    if-eqz v11, :cond_4e6

    invoke-static {v11}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_4e3

    goto :goto_4e6

    :cond_4e3
    invoke-virtual {v1, v11}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    :cond_4e6
    :goto_4e6
    if-eqz v13, :cond_4ee

    invoke-static {v13}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_4f0

    :cond_4ee
    const/4 v11, 0x0

    goto :goto_51c

    :cond_4f0
    new-instance v0, Ljs1;

    const-string v7, "/"

    invoke-direct {v0, v7}, Ljs1;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x2

    invoke-virtual {v0, v13, v7}, Ljs1;->e(Ljava/lang/CharSequence;I)Ljava/util/List;

    move-result-object v0

    const/4 v11, 0x0

    new-array v14, v11, [Ljava/lang/String;

    invoke-interface {v0, v14}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Ljava/lang/String;

    array-length v14, v0

    if-ge v14, v7, :cond_515

    const-string v0, "Could not parse component name from open GMSG: "

    invoke-virtual {v0, v13}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x6

    const/4 v7, 0x0

    invoke-static {v1, v0, v7}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    const/4 v1, 0x0

    goto :goto_545

    :cond_515
    aget-object v7, v0, v11

    aget-object v0, v0, v16

    invoke-virtual {v1, v7, v0}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    :goto_51c
    if-eqz v15, :cond_545

    invoke-static {v15}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_525

    goto :goto_545

    :cond_525
    :try_start_525
    invoke-static {v15}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v0

    invoke-virtual {v1, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;
    :try_end_52c
    .catch Ljava/lang/NumberFormatException; {:try_start_525 .. :try_end_52c} :catch_52d

    goto :goto_545

    :catch_52d
    move-exception v0

    new-instance v7, Ljava/lang/StringBuilder;

    const-string v13, "Could not parse intent flags ("

    invoke-direct {v7, v13}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v7, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lads_mobile_sdk/xh3;->a(Ljava/lang/String;)V

    :cond_545
    :goto_545
    move-object v7, v1

    goto :goto_55e

    :goto_547
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Blank URL and invalid intent URL for an open GMSG: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x6

    const/4 v10, 0x0

    invoke-static {v1, v0, v10}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    goto :goto_55e

    :cond_55b
    move/from16 v17, v1

    const/4 v11, 0x0

    :goto_55e
    move-object v14, v2

    move-object v0, v3

    move v3, v4

    move v2, v5

    move/from16 v1, v17

    :goto_564
    if-eqz v7, :cond_593

    invoke-virtual {v7}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v4

    if-eqz v4, :cond_593

    iget-object v5, v14, Lads_mobile_sdk/f92;->o:Lads_mobile_sdk/jz2;

    invoke-virtual {v4}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object v14, v9, Lads_mobile_sdk/c92;->a:Ljava/lang/Object;

    iput-object v6, v9, Lads_mobile_sdk/c92;->b:Lads_mobile_sdk/cy0;

    iput-object v8, v9, Lads_mobile_sdk/c92;->c:Ljava/util/Map;

    iput-object v0, v9, Lads_mobile_sdk/c92;->d:Ljava/lang/Object;

    iput-object v7, v9, Lads_mobile_sdk/c92;->e:Landroid/content/Intent;

    iput v3, v9, Lads_mobile_sdk/c92;->f:I

    iput-boolean v2, v9, Lads_mobile_sdk/c92;->h:Z

    iput v1, v9, Lads_mobile_sdk/c92;->g:I

    const/4 v10, 0x7

    iput v10, v9, Lads_mobile_sdk/c92;->k:I

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v5, v4, v9}, Lads_mobile_sdk/jz2;->a(Lads_mobile_sdk/jz2;Ljava/lang/String;Lwx;)Ljava/lang/Object;

    move-result-object v4

    if-ne v4, v12, :cond_593

    goto/16 :goto_123

    :cond_593
    move-object v15, v8

    move-object v8, v0

    move-object v0, v15

    move-object v15, v14

    move-object v14, v6

    :goto_598
    const-string v4, "open_app"

    invoke-virtual {v4, v8}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_5a9

    const-string v4, "p"

    invoke-interface {v0, v4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    goto :goto_5b7

    :cond_5a9
    if-eqz v7, :cond_5b6

    invoke-virtual {v7}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v4

    if-eqz v4, :cond_5b6

    invoke-virtual {v4}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v4

    goto :goto_5b7

    :cond_5b6
    const/4 v4, 0x0

    :goto_5b7
    iput-object v15, v9, Lads_mobile_sdk/c92;->a:Ljava/lang/Object;

    iput-object v14, v9, Lads_mobile_sdk/c92;->b:Lads_mobile_sdk/cy0;

    iput-object v0, v9, Lads_mobile_sdk/c92;->c:Ljava/util/Map;

    iput-object v7, v9, Lads_mobile_sdk/c92;->d:Ljava/lang/Object;

    const/4 v10, 0x0

    iput-object v10, v9, Lads_mobile_sdk/c92;->e:Landroid/content/Intent;

    iput v3, v9, Lads_mobile_sdk/c92;->f:I

    iput-boolean v2, v9, Lads_mobile_sdk/c92;->h:Z

    iput v1, v9, Lads_mobile_sdk/c92;->g:I

    const/16 v5, 0x8

    iput v5, v9, Lads_mobile_sdk/c92;->k:I

    invoke-virtual {v15, v14, v4, v9}, Lads_mobile_sdk/f92;->a(Lads_mobile_sdk/cy0;Ljava/lang/String;Lwx;)V

    sget-object v4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    if-ne v4, v12, :cond_5d5

    goto/16 :goto_123

    :cond_5d5
    move-object v5, v7

    move v7, v2

    move-object v2, v5

    move-object v5, v0

    move-object v0, v4

    move-object v8, v14

    move-object v4, v15

    :goto_5dc
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_5e7

    sget-object v0, Lrg2;->a:Lrg2;

    return-object v0

    :cond_5e7
    iget-object v0, v4, Lads_mobile_sdk/f92;->b:Lads_mobile_sdk/qr0;

    const-string v6, "gads:post_click_lifecycle_monitoring:enabled"

    sget-object v10, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sget-object v13, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    invoke-virtual {v0, v6, v10, v13}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_652

    iget-object v0, v4, Lads_mobile_sdk/f92;->q:Lads_mobile_sdk/qf2;

    iget-object v6, v0, Lads_mobile_sdk/qf2;->f:Ljava/lang/Object;

    monitor-enter v6

    :try_start_600
    iget-object v10, v0, Lads_mobile_sdk/qf2;->a:Lads_mobile_sdk/a2;

    iget-wide v13, v10, Lads_mobile_sdk/a2;->B0:J

    move-object v15, v12

    const-wide/16 v11, 0x0

    invoke-static {v13, v14, v11, v12}, Lv60;->c(JJ)I

    move-result v10

    if-lez v10, :cond_64e

    iget-boolean v10, v0, Lads_mobile_sdk/qf2;->h:Z

    if-nez v10, :cond_64e

    iget-boolean v10, v0, Lads_mobile_sdk/qf2;->i:Z

    if-eqz v10, :cond_616

    goto :goto_64e

    :cond_616
    iget-object v10, v0, Lads_mobile_sdk/qf2;->g:Lh43;

    iget-object v11, v0, Lads_mobile_sdk/qf2;->b:Lx43;

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v11

    invoke-virtual {v10}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v10, v10, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v10, Lads_mobile_sdk/tf2;

    invoke-static {v10, v11, v12}, Lads_mobile_sdk/tf2;->c(Lads_mobile_sdk/tf2;J)V

    move/from16 v10, v16

    iput-boolean v10, v0, Lads_mobile_sdk/qf2;->h:Z

    iget-object v11, v0, Lads_mobile_sdk/qf2;->d:Lvy;

    new-instance v12, Lqd;

    const/16 v13, 0x1b

    const/4 v14, 0x0

    invoke-direct {v12, v0, v14, v13}, Lqd;-><init>(Ljava/lang/Object;Lvx;I)V

    sget-object v13, Ly90;->a:Ly90;

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v10, La42;

    invoke-direct {v10, v12, v14}, La42;-><init>(Lpk0;Lvx;)V

    const/4 v12, 0x2

    invoke-static {v11, v13, v14, v10, v12}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    move-result-object v10

    iput-object v10, v0, Lads_mobile_sdk/qf2;->j:Lx52;
    :try_end_64a
    .catchall {:try_start_600 .. :try_end_64a} :catchall_64c

    monitor-exit v6

    goto :goto_653

    :catchall_64c
    move-exception v0

    goto :goto_650

    :cond_64e
    :goto_64e
    monitor-exit v6

    goto :goto_653

    :goto_650
    monitor-exit v6

    throw v0

    :cond_652
    move-object v15, v12

    :goto_653
    if-eqz v3, :cond_657

    const/4 v6, 0x1

    goto :goto_658

    :cond_657
    const/4 v6, 0x0

    :goto_658
    iput-object v4, v9, Lads_mobile_sdk/c92;->a:Ljava/lang/Object;

    iput-object v8, v9, Lads_mobile_sdk/c92;->b:Lads_mobile_sdk/cy0;

    iput-object v5, v9, Lads_mobile_sdk/c92;->c:Ljava/util/Map;

    iput-object v2, v9, Lads_mobile_sdk/c92;->d:Ljava/lang/Object;

    iput v3, v9, Lads_mobile_sdk/c92;->f:I

    iput-boolean v7, v9, Lads_mobile_sdk/c92;->h:Z

    iput v1, v9, Lads_mobile_sdk/c92;->g:I

    const/16 v0, 0x9

    iput v0, v9, Lads_mobile_sdk/c92;->k:I

    invoke-virtual/range {v4 .. v9}, Lads_mobile_sdk/f92;->a(Ljava/util/Map;ZZLads_mobile_sdk/cy0;Lwx;)Ljava/lang/Object;

    move-result-object v0

    move-object v6, v9

    if-ne v0, v15, :cond_672

    goto :goto_6b3

    :cond_672
    move v9, v7

    move-object v10, v8

    move-object v8, v4

    move-object v4, v2

    :goto_676
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_681

    sget-object v0, Lrg2;->a:Lrg2;

    return-object v0

    :cond_681
    if-eqz v1, :cond_685

    const/4 v7, 0x1

    goto :goto_686

    :cond_685
    const/4 v7, 0x0

    :goto_686
    if-eqz v3, :cond_68c

    const/16 v16, 0x1

    :goto_68a
    const/4 v14, 0x0

    goto :goto_68f

    :cond_68c
    const/16 v16, 0x0

    goto :goto_68a

    :goto_68f
    iput-object v14, v6, Lads_mobile_sdk/c92;->a:Ljava/lang/Object;

    iput-object v14, v6, Lads_mobile_sdk/c92;->b:Lads_mobile_sdk/cy0;

    iput-object v14, v6, Lads_mobile_sdk/c92;->c:Ljava/util/Map;

    iput-object v14, v6, Lads_mobile_sdk/c92;->d:Ljava/lang/Object;

    const/16 v0, 0xa

    iput v0, v6, Lads_mobile_sdk/c92;->k:I

    iget-object v0, v8, Lads_mobile_sdk/f92;->c:Lads_mobile_sdk/ax0;

    invoke-virtual {v0, v4}, Lads_mobile_sdk/ax0;->a(Landroid/content/Intent;)Z

    move-result v0

    move-object v11, v6

    move-object v4, v8

    move/from16 v8, v16

    move v6, v0

    invoke-virtual/range {v4 .. v11}, Lads_mobile_sdk/f92;->a(Ljava/util/Map;ZZZZLads_mobile_sdk/cy0;Lwx;)Ljava/lang/Object;

    move-result-object v0

    sget-object v1, Lwy;->a:Lwy;

    if-ne v0, v1, :cond_6af

    goto :goto_6b1

    :cond_6af
    sget-object v0, Lrg2;->a:Lrg2;

    :goto_6b1
    if-ne v0, v15, :cond_6b4

    :goto_6b3
    return-object v15

    :cond_6b4
    :goto_6b4
    sget-object v0, Lrg2;->a:Lrg2;

    return-object v0

    :goto_6b7
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Action is missing from an open GMSG: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x6

    const/4 v14, 0x0

    invoke-static {v1, v0, v14}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    sget-object v0, Lrg2;->a:Lrg2;

    return-object v0

    nop

    :pswitch_data_6ce
    .packed-switch 0x0
        :pswitch_e5  #00000000
        :pswitch_dd  #00000001
        :pswitch_d8  #00000002
        :pswitch_d3  #00000003
        :pswitch_ce  #00000004
        :pswitch_b0  #00000005
        :pswitch_92  #00000006
        :pswitch_75  #00000007
        :pswitch_55  #00000008
        :pswitch_3b  #00000009
        :pswitch_36  #0000000a
    .end packed-switch
.end method

.method public final a(Ljava/util/Map;ZZLads_mobile_sdk/cy0;Lwx;)Ljava/lang/Object;
    .registers 22

    .prologue
    move-object/from16 v1, p0

    move-object/from16 v0, p1

    move-object/from16 v2, p5

    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const-string v4, "HSDP service parameters missing."

    sget-object v5, Lrg2;->a:Lrg2;

    sget-object v6, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    instance-of v7, v2, Lads_mobile_sdk/a92;

    if-eqz v7, :cond_22

    move-object v7, v2

    check-cast v7, Lads_mobile_sdk/a92;

    iget v8, v7, Lads_mobile_sdk/a92;->i:I

    const/high16 v9, -0x80000000

    and-int v10, v8, v9

    if-eqz v10, :cond_22

    sub-int/2addr v8, v9

    iput v8, v7, Lads_mobile_sdk/a92;->i:I

    :goto_20
    move-object v13, v7

    goto :goto_28

    :cond_22
    new-instance v7, Lads_mobile_sdk/a92;

    invoke-direct {v7, v1, v2}, Lads_mobile_sdk/a92;-><init>(Lads_mobile_sdk/f92;Lwx;)V

    goto :goto_20

    :goto_28
    iget-object v2, v13, Lads_mobile_sdk/a92;->g:Ljava/lang/Object;

    sget-object v7, Lwy;->a:Lwy;

    iget v8, v13, Lads_mobile_sdk/a92;->i:I

    const/4 v15, 0x3

    const/4 v9, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x0

    if-eqz v8, :cond_99

    if-eq v8, v11, :cond_75

    if-eq v8, v9, :cond_5a

    if-ne v8, v15, :cond_54

    iget-object v1, v13, Lads_mobile_sdk/a92;->c:Ljava/io/Closeable;

    iget-object v0, v13, Lads_mobile_sdk/a92;->b:Ljava/lang/Object;

    move-object v4, v0

    check-cast v4, Lads_mobile_sdk/rg3;

    iget-object v5, v13, Lads_mobile_sdk/a92;->a:Lads_mobile_sdk/f92;

    :try_start_43
    invoke-static {v2}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_46
    .catch Ljava/lang/Exception; {:try_start_43 .. :try_end_46} :catch_4d
    .catchall {:try_start_43 .. :try_end_46} :catchall_4a

    move-object v8, v4

    move-object v4, v12

    goto/16 :goto_17f

    :catchall_4a
    move-exception v0

    goto/16 :goto_27a

    :catch_4d
    move-exception v0

    move-object v2, v1

    move-object v1, v5

    :goto_50
    move-object v7, v12

    :goto_51
    const/4 v5, 0x4

    goto/16 :goto_20d

    :cond_54
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {v0}, Lz6;->w(Ljava/lang/String;)V

    return-object v12

    :cond_5a
    iget-boolean v0, v13, Lads_mobile_sdk/a92;->e:Z

    iget-object v1, v13, Lads_mobile_sdk/a92;->d:Ljava/io/Closeable;

    iget-object v4, v13, Lads_mobile_sdk/a92;->c:Ljava/io/Closeable;

    check-cast v4, Lads_mobile_sdk/rg3;

    iget-object v5, v13, Lads_mobile_sdk/a92;->b:Ljava/lang/Object;

    check-cast v5, Lads_mobile_sdk/cy0;

    iget-object v8, v13, Lads_mobile_sdk/a92;->a:Lads_mobile_sdk/f92;

    :try_start_68
    invoke-static {v2}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_6b
    .catch Ljava/lang/Exception; {:try_start_68 .. :try_end_6b} :catch_71
    .catchall {:try_start_68 .. :try_end_6b} :catchall_4a

    move-object v2, v1

    move-object v1, v8

    move-object v8, v4

    move-object v4, v12

    goto/16 :goto_165

    :catch_71
    move-exception v0

    move-object v2, v1

    move-object v1, v8

    goto :goto_50

    :cond_75
    iget-boolean v0, v13, Lads_mobile_sdk/a92;->f:Z

    iget-boolean v1, v13, Lads_mobile_sdk/a92;->e:Z

    iget-object v4, v13, Lads_mobile_sdk/a92;->d:Ljava/io/Closeable;

    iget-object v8, v13, Lads_mobile_sdk/a92;->c:Ljava/io/Closeable;

    check-cast v8, Lads_mobile_sdk/rg3;

    iget-object v11, v13, Lads_mobile_sdk/a92;->b:Ljava/lang/Object;

    check-cast v11, Lads_mobile_sdk/cy0;

    iget-object v9, v13, Lads_mobile_sdk/a92;->a:Lads_mobile_sdk/f92;

    :try_start_85
    invoke-static {v2}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_88
    .catch Ljava/lang/Exception; {:try_start_85 .. :try_end_88} :catch_94
    .catchall {:try_start_85 .. :try_end_88} :catchall_90

    move v15, v0

    move v14, v1

    move-object v2, v4

    move-object v1, v9

    move-object v4, v12

    const/4 v0, 0x2

    goto/16 :goto_131

    :catchall_90
    move-exception v0

    move-object v1, v4

    goto/16 :goto_15c

    :catch_94
    move-exception v0

    move-object v2, v4

    move-object v4, v8

    move-object v1, v9

    goto :goto_50

    :cond_99
    invoke-static {v2}, Lt12;->W(Ljava/lang/Object;)V

    iget-object v2, v1, Lads_mobile_sdk/f92;->b:Lads_mobile_sdk/qr0;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v8, "gads:hsdp_service:enabled"

    invoke-virtual {v2, v8, v3, v6}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Boolean;

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_2b1

    iget-object v2, v1, Lads_mobile_sdk/f92;->n:Lads_mobile_sdk/a2;

    iget-object v2, v2, Lads_mobile_sdk/a2;->v0:Lads_mobile_sdk/lf2;

    if-eqz v2, :cond_2b1

    iget-boolean v2, v2, Lads_mobile_sdk/lf2;->d:Z

    if-ne v2, v11, :cond_2b1

    const-string v2, "hf"

    invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const-string v8, "2"

    invoke-static {v2, v8}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2b1

    const-string v2, "hstp"

    invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    if-eqz v8, :cond_2b1

    sget-object v8, Lads_mobile_sdk/fw0;->S1:Lads_mobile_sdk/fw0;

    sget-object v9, Lads_mobile_sdk/hh3;->a:Ljava/util/WeakHashMap;

    sget-object v9, Lba0;->a:Lba0;

    invoke-static {v8, v9, v11}, Lads_mobile_sdk/hh3;->a(Lads_mobile_sdk/fw0;Ljava/util/List;Z)Lads_mobile_sdk/rg3;

    move-result-object v8

    :try_start_d9
    invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    move-object v9, v2

    check-cast v9, Ljava/lang/String;

    const-string v2, "hsr"

    invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    const-string v10, "hseqp"

    invoke-interface {v0, v10}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;
    :try_end_f0
    .catch Ljava/lang/Exception; {:try_start_d9 .. :try_end_f0} :catch_208
    .catchall {:try_start_d9 .. :try_end_f0} :catchall_1bf

    :try_start_f0
    const-string v12, "hsat"

    invoke-interface {v0, v12}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const-string v12, "true"

    invoke-static {v0, v12}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v12
    :try_end_fc
    .catch Ljava/lang/Exception; {:try_start_f0 .. :try_end_fc} :catch_203
    .catchall {:try_start_f0 .. :try_end_fc} :catchall_1bf

    if-eqz v9, :cond_102

    if-eqz v2, :cond_102

    if-nez v10, :cond_107

    :cond_102
    move-object v2, v8

    const/4 v5, 0x4

    const/4 v7, 0x0

    goto/16 :goto_1c6

    :cond_107
    :try_start_107
    invoke-virtual {v1, v10}, Lads_mobile_sdk/f92;->b(Ljava/lang/String;)Ljava/util/Map;

    move-result-object v0

    iget-object v4, v1, Lads_mobile_sdk/f92;->r:Lads_mobile_sdk/s01;
    :try_end_10d
    .catch Ljava/lang/Exception; {:try_start_107 .. :try_end_10d} :catch_1bb
    .catchall {:try_start_107 .. :try_end_10d} :catchall_1bf

    :try_start_10d
    iput-object v1, v13, Lads_mobile_sdk/a92;->a:Lads_mobile_sdk/f92;
    :try_end_10f
    .catch Ljava/lang/Exception; {:try_start_10d .. :try_end_10f} :catch_1c2
    .catchall {:try_start_10d .. :try_end_10f} :catchall_1bf

    move-object/from16 v10, p4

    :try_start_111
    iput-object v10, v13, Lads_mobile_sdk/a92;->b:Ljava/lang/Object;
    :try_end_113
    .catch Ljava/lang/Exception; {:try_start_111 .. :try_end_113} :catch_1bb
    .catchall {:try_start_111 .. :try_end_113} :catchall_1bf

    :try_start_113
    iput-object v8, v13, Lads_mobile_sdk/a92;->c:Ljava/io/Closeable;

    iput-object v8, v13, Lads_mobile_sdk/a92;->d:Ljava/io/Closeable;
    :try_end_117
    .catch Ljava/lang/Exception; {:try_start_113 .. :try_end_117} :catch_1c2
    .catchall {:try_start_113 .. :try_end_117} :catchall_1bf

    move/from16 v14, p2

    :try_start_119
    iput-boolean v14, v13, Lads_mobile_sdk/a92;->e:Z

    move/from16 v15, p3

    iput-boolean v15, v13, Lads_mobile_sdk/a92;->f:Z

    iput v11, v13, Lads_mobile_sdk/a92;->i:I
    :try_end_121
    .catch Ljava/lang/Exception; {:try_start_119 .. :try_end_121} :catch_1bb
    .catchall {:try_start_119 .. :try_end_121} :catchall_1bf

    move-object v11, v0

    move-object v10, v2

    move-object v2, v8

    const/4 v0, 0x2

    move-object v8, v4

    const/4 v4, 0x0

    :try_start_127
    invoke-virtual/range {v8 .. v13}, Lads_mobile_sdk/s01;->a(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;ZLads_mobile_sdk/a92;)Ljava/lang/Object;

    move-result-object v8
    :try_end_12b
    .catch Ljava/lang/Exception; {:try_start_127 .. :try_end_12b} :catch_1b7
    .catchall {:try_start_127 .. :try_end_12b} :catchall_1f9

    if-ne v8, v7, :cond_12e

    goto :goto_17c

    :cond_12e
    move-object/from16 v11, p4

    move-object v8, v2

    :goto_131
    :try_start_131
    iget-object v9, v1, Lads_mobile_sdk/f92;->b:Lads_mobile_sdk/qr0;

    const-string v10, "gads:hsdp_service_trigger_on_ad_clicked:enabled"

    sget-object v12, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {v9, v10, v12, v6}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/Boolean;

    invoke-virtual {v9}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v9

    if-eqz v9, :cond_163

    if-eqz v14, :cond_163

    iget-object v9, v1, Lads_mobile_sdk/f92;->e:Lads_mobile_sdk/z2;
    :try_end_147
    .catch Ljava/lang/Exception; {:try_start_131 .. :try_end_147} :catch_191
    .catchall {:try_start_131 .. :try_end_147} :catchall_182

    :try_start_147
    iput-object v1, v13, Lads_mobile_sdk/a92;->a:Lads_mobile_sdk/f92;
    :try_end_149
    .catch Ljava/lang/Exception; {:try_start_147 .. :try_end_149} :catch_159
    .catchall {:try_start_147 .. :try_end_149} :catchall_182

    :try_start_149
    iput-object v11, v13, Lads_mobile_sdk/a92;->b:Ljava/lang/Object;
    :try_end_14b
    .catch Ljava/lang/Exception; {:try_start_149 .. :try_end_14b} :catch_191
    .catchall {:try_start_149 .. :try_end_14b} :catchall_182

    :try_start_14b
    iput-object v8, v13, Lads_mobile_sdk/a92;->c:Ljava/io/Closeable;

    iput-object v2, v13, Lads_mobile_sdk/a92;->d:Ljava/io/Closeable;
    :try_end_14f
    .catch Ljava/lang/Exception; {:try_start_14b .. :try_end_14f} :catch_159
    .catchall {:try_start_14b .. :try_end_14f} :catchall_182

    :try_start_14f
    iput-boolean v15, v13, Lads_mobile_sdk/a92;->e:Z

    iput v0, v13, Lads_mobile_sdk/a92;->i:I

    invoke-virtual {v9, v13}, Lads_mobile_sdk/z2;->n(Lvx;)Ljava/lang/Object;
    :try_end_156
    .catch Ljava/lang/Exception; {:try_start_14f .. :try_end_156} :catch_191
    .catchall {:try_start_14f .. :try_end_156} :catchall_182

    if-ne v5, v7, :cond_163

    goto :goto_17c

    :catch_159
    move-exception v0

    goto :goto_15f

    :goto_15b
    move-object v1, v2

    :goto_15c
    move-object v4, v8

    goto/16 :goto_27a

    :goto_15f
    move-object v7, v4

    move-object v4, v8

    goto/16 :goto_51

    :cond_163
    move-object v5, v11

    move v0, v15

    :goto_165
    if-eqz v0, :cond_184

    :try_start_167
    iget-object v0, v5, Lads_mobile_sdk/cy0;->o:Lads_mobile_sdk/mt0;

    if-eqz v0, :cond_184

    iput-object v1, v13, Lads_mobile_sdk/a92;->a:Lads_mobile_sdk/f92;

    iput-object v8, v13, Lads_mobile_sdk/a92;->b:Ljava/lang/Object;

    iput-object v2, v13, Lads_mobile_sdk/a92;->c:Ljava/io/Closeable;

    iput-object v4, v13, Lads_mobile_sdk/a92;->d:Ljava/io/Closeable;

    const/4 v5, 0x3

    iput v5, v13, Lads_mobile_sdk/a92;->i:I

    invoke-interface {v0, v13}, Ll13;->a(Lwx;)Lrg2;

    move-result-object v0
    :try_end_17a
    .catch Ljava/lang/Exception; {:try_start_167 .. :try_end_17a} :catch_159
    .catchall {:try_start_167 .. :try_end_17a} :catchall_182

    if-ne v0, v7, :cond_17d

    :goto_17c
    return-object v7

    :cond_17d
    move-object v5, v1

    move-object v1, v2

    :goto_17f
    move-object v2, v1

    move-object v1, v5

    goto :goto_184

    :catchall_182
    move-exception v0

    goto :goto_15b

    :cond_184
    :goto_184
    :try_start_184
    invoke-static {}, Lads_mobile_sdk/hh3;->b()Lads_mobile_sdk/gh3;

    move-result-object v0

    iget-object v0, v0, Lads_mobile_sdk/gh3;->a:Lads_mobile_sdk/rg3;

    if-eqz v0, :cond_194

    invoke-virtual {v0}, Lads_mobile_sdk/rg3;->e()Lads_mobile_sdk/ub2;

    move-result-object v12

    goto :goto_195

    :catch_191
    move-exception v0

    const/4 v5, 0x4

    goto :goto_1b3

    :cond_194
    move-object v12, v4

    :goto_195
    if-nez v12, :cond_199

    const/4 v5, 0x4

    goto :goto_1ac

    :cond_199
    invoke-static {}, Lads_mobile_sdk/w01;->o()Lb53;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_1a0
    .catch Ljava/lang/Exception; {:try_start_184 .. :try_end_1a0} :catch_191
    .catchall {:try_start_184 .. :try_end_1a0} :catchall_182

    const/4 v5, 0x4

    :try_start_1a1
    invoke-virtual {v0, v5}, Lb53;->b(I)V

    invoke-virtual {v0}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/w01;

    iput-object v0, v12, Lads_mobile_sdk/ub2;->I:Lads_mobile_sdk/w01;

    :goto_1ac
    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;
    :try_end_1ae
    .catch Ljava/lang/Exception; {:try_start_1a1 .. :try_end_1ae} :catch_1b2
    .catchall {:try_start_1a1 .. :try_end_1ae} :catchall_182

    invoke-static {v2, v4}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object v0

    :catch_1b2
    move-exception v0

    :goto_1b3
    move-object v7, v4

    move-object v4, v8

    goto/16 :goto_20d

    :catch_1b7
    move-exception v0

    :goto_1b8
    const/4 v5, 0x4

    move-object v7, v4

    goto :goto_201

    :catch_1bb
    move-exception v0

    move-object v2, v8

    const/4 v4, 0x0

    goto :goto_1b8

    :catchall_1bf
    move-exception v0

    move-object v2, v8

    goto :goto_1fd

    :catch_1c2
    move-exception v0

    move-object v2, v8

    const/4 v4, 0x0

    goto :goto_1b8

    :goto_1c6
    :try_start_1c6
    invoke-static {v4, v7}, Lads_mobile_sdk/nw;->b(Ljava/lang/String;Ljava/lang/Throwable;)V

    invoke-static {}, Lads_mobile_sdk/hh3;->b()Lads_mobile_sdk/gh3;

    move-result-object v0

    iget-object v0, v0, Lads_mobile_sdk/gh3;->a:Lads_mobile_sdk/rg3;

    if-eqz v0, :cond_1d6

    invoke-virtual {v0}, Lads_mobile_sdk/rg3;->e()Lads_mobile_sdk/ub2;

    move-result-object v12

    goto :goto_1d7

    :cond_1d6
    move-object v12, v7

    :goto_1d7
    if-nez v12, :cond_1da

    goto :goto_1f6

    :cond_1da
    invoke-static {}, Lads_mobile_sdk/w01;->o()Lb53;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0, v5}, Lb53;->b(I)V

    invoke-virtual {v0}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v8, v0, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v8, Lads_mobile_sdk/w01;

    invoke-virtual {v8, v4}, Lads_mobile_sdk/w01;->b(Ljava/lang/String;)V

    invoke-virtual {v0}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/w01;

    iput-object v0, v12, Lads_mobile_sdk/ub2;->I:Lads_mobile_sdk/w01;
    :try_end_1f6
    .catch Ljava/lang/Exception; {:try_start_1c6 .. :try_end_1f6} :catch_1fb
    .catchall {:try_start_1c6 .. :try_end_1f6} :catchall_1f9

    :goto_1f6
    move-object v8, v2

    goto/16 :goto_276

    :catchall_1f9
    move-exception v0

    goto :goto_1fd

    :catch_1fb
    move-exception v0

    goto :goto_201

    :goto_1fd
    move-object v1, v2

    move-object v4, v1

    goto/16 :goto_27a

    :goto_201
    move-object v4, v2

    goto :goto_20d

    :catch_203
    move-exception v0

    move-object v2, v8

    const/4 v5, 0x4

    const/4 v7, 0x0

    goto :goto_201

    :catch_208
    move-exception v0

    move-object v2, v8

    move-object v7, v12

    const/4 v5, 0x4

    goto :goto_201

    :goto_20d
    :try_start_20d
    invoke-static {}, Lads_mobile_sdk/hh3;->b()Lads_mobile_sdk/gh3;

    move-result-object v8

    iget-object v8, v8, Lads_mobile_sdk/gh3;->a:Lads_mobile_sdk/rg3;

    if-eqz v8, :cond_21d

    invoke-virtual {v8}, Lads_mobile_sdk/rg3;->e()Lads_mobile_sdk/ub2;

    move-result-object v12

    goto :goto_21e

    :catchall_21a
    move-exception v0

    move-object v1, v2

    goto :goto_27a

    :cond_21d
    move-object v12, v7

    :goto_21e
    if-nez v12, :cond_221

    goto :goto_245

    :cond_221
    invoke-static {}, Lads_mobile_sdk/w01;->o()Lb53;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v8, v5}, Lb53;->b(I)V

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v5

    if-nez v5, :cond_233

    const-string v5, ""

    :cond_233
    invoke-virtual {v8}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v9, v8, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v9, Lads_mobile_sdk/w01;

    invoke-virtual {v9, v5}, Lads_mobile_sdk/w01;->b(Ljava/lang/String;)V

    invoke-virtual {v8}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object v5

    check-cast v5, Lads_mobile_sdk/w01;

    iput-object v5, v12, Lads_mobile_sdk/ub2;->I:Lads_mobile_sdk/w01;

    :goto_245
    invoke-static {}, Lads_mobile_sdk/hh3;->a()Lads_mobile_sdk/rg3;

    move-result-object v5

    invoke-virtual {v5}, Lads_mobile_sdk/rg3;->e()Lads_mobile_sdk/ub2;

    move-result-object v8

    const/4 v9, 0x0

    iput-boolean v9, v8, Lads_mobile_sdk/ub2;->m:Z

    invoke-virtual {v5, v0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    iget-object v5, v1, Lads_mobile_sdk/f92;->b:Lads_mobile_sdk/qr0;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v8, "gads:hsdp_unsampled_crash_reporting:enabled"

    sget-object v9, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {v5, v8, v9, v6}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5
    :try_end_266
    .catchall {:try_start_20d .. :try_end_266} :catchall_21a

    iget-object v1, v1, Lads_mobile_sdk/f92;->s:Lads_mobile_sdk/ah3;

    if-eqz v5, :cond_270

    :try_start_26a
    const-string v5, "HsdpServiceUnsampled.open"

    invoke-virtual {v1, v5, v0}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Exception;)V

    goto :goto_1f6

    :cond_270
    const-string v5, "HsdpService.open"

    invoke-virtual {v1, v5, v0}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_275
    .catchall {:try_start_26a .. :try_end_275} :catchall_21a

    goto :goto_1f6

    :goto_276
    invoke-static {v8, v7}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object v3

    :goto_27a
    :try_start_27a
    invoke-virtual {v4, v0}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v2, v0, Lox2;

    if-nez v2, :cond_2aa

    invoke-virtual {v4, v0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of v2, v0, Lza2;

    if-nez v2, :cond_2a2

    instance-of v2, v0, Ljava/util/concurrent/CancellationException;

    if-nez v2, :cond_29a

    instance-of v2, v0, Lads_mobile_sdk/mv0;

    if-eqz v2, :cond_294

    throw v0

    :catchall_291
    move-exception v0

    move-object v2, v0

    goto :goto_2ab

    :cond_294
    new-instance v2, Lads_mobile_sdk/tu0;

    invoke-direct {v2, v0}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw v2

    :cond_29a
    new-instance v2, Lads_mobile_sdk/ou0;

    check-cast v0, Ljava/util/concurrent/CancellationException;

    invoke-direct {v2, v0}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw v2

    :cond_2a2
    new-instance v2, Lads_mobile_sdk/uw0;

    check-cast v0, Lza2;

    invoke-direct {v2, v0}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw v2

    :cond_2aa
    throw v0
    :try_end_2ab
    .catchall {:try_start_27a .. :try_end_2ab} :catchall_291

    :goto_2ab
    :try_start_2ab
    throw v2
    :try_end_2ac
    .catchall {:try_start_2ab .. :try_end_2ac} :catchall_2ac

    :catchall_2ac
    move-exception v0

    invoke-static {v1, v2}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0

    :cond_2b1
    return-object v3
.end method

.method public final a(Ljava/util/Map;ZZZLads_mobile_sdk/cy0;Lwx;)Ljava/lang/Object;
    .registers 23

    .prologue
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p6

    instance-of v3, v2, Lads_mobile_sdk/y82;

    if-eqz v3, :cond_1a

    move-object v3, v2

    check-cast v3, Lads_mobile_sdk/y82;

    iget v4, v3, Lads_mobile_sdk/y82;->m:I

    const/high16 v5, -0x80000000

    and-int v6, v4, v5

    if-eqz v6, :cond_1a

    sub-int/2addr v4, v5

    iput v4, v3, Lads_mobile_sdk/y82;->m:I

    :goto_18
    move-object v11, v3

    goto :goto_20

    :cond_1a
    new-instance v3, Lads_mobile_sdk/y82;

    invoke-direct {v3, v0, v2}, Lads_mobile_sdk/y82;-><init>(Lads_mobile_sdk/f92;Lwx;)V

    goto :goto_18

    :goto_20
    iget-object v2, v11, Lads_mobile_sdk/y82;->k:Ljava/lang/Object;

    iget v3, v11, Lads_mobile_sdk/y82;->m:I

    const/4 v5, 0x6

    sget-object v12, Lrg2;->a:Lrg2;

    const/4 v6, 0x0

    sget-object v13, Lwy;->a:Lwy;

    packed-switch v3, :pswitch_data_268

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {v0}, Lz6;->w(Ljava/lang/String;)V

    return-object v6

    :pswitch_33  #0x7
    invoke-static {v2}, Lt12;->W(Ljava/lang/Object;)V

    return-object v12

    :pswitch_37  #0x6
    iget-boolean v0, v11, Lads_mobile_sdk/y82;->j:Z

    iget-boolean v1, v11, Lads_mobile_sdk/y82;->i:Z

    iget-boolean v3, v11, Lads_mobile_sdk/y82;->h:Z

    iget-object v4, v11, Lads_mobile_sdk/y82;->c:Lads_mobile_sdk/cy0;

    iget-object v5, v11, Lads_mobile_sdk/y82;->b:Ljava/util/Map;

    iget-object v7, v11, Lads_mobile_sdk/y82;->a:Lads_mobile_sdk/f92;

    invoke-static {v2}, Lt12;->W(Ljava/lang/Object;)V

    move-object v10, v4

    move-object v4, v6

    move-object v2, v7

    :goto_49
    move v9, v0

    move v8, v1

    move v7, v3

    goto/16 :goto_247

    :pswitch_4e  #0x5
    invoke-static {v2}, Lt12;->W(Ljava/lang/Object;)V

    return-object v12

    :pswitch_52  #0x4
    iget-boolean v0, v11, Lads_mobile_sdk/y82;->j:Z

    iget-boolean v1, v11, Lads_mobile_sdk/y82;->i:Z

    iget-boolean v3, v11, Lads_mobile_sdk/y82;->h:Z

    iget-object v4, v11, Lads_mobile_sdk/y82;->c:Lads_mobile_sdk/cy0;

    iget-object v5, v11, Lads_mobile_sdk/y82;->b:Ljava/util/Map;

    iget-object v7, v11, Lads_mobile_sdk/y82;->a:Lads_mobile_sdk/f92;

    invoke-static {v2}, Lt12;->W(Ljava/lang/Object;)V

    move-object v10, v4

    move-object v4, v6

    move-object v2, v7

    :goto_64
    move v9, v0

    move v8, v1

    move v7, v3

    goto/16 :goto_1e2

    :pswitch_69  #0x3
    iget-boolean v0, v11, Lads_mobile_sdk/y82;->j:Z

    iget-boolean v1, v11, Lads_mobile_sdk/y82;->i:Z

    iget-boolean v3, v11, Lads_mobile_sdk/y82;->h:Z

    iget-object v7, v11, Lads_mobile_sdk/y82;->g:Ljava/lang/String;

    iget-object v8, v11, Lads_mobile_sdk/y82;->f:Landroid/net/Uri;

    iget-object v9, v11, Lads_mobile_sdk/y82;->e:Landroid/app/Activity;

    iget-object v10, v11, Lads_mobile_sdk/y82;->d:Ljava/lang/String;

    iget-object v14, v11, Lads_mobile_sdk/y82;->c:Lads_mobile_sdk/cy0;

    iget-object v15, v11, Lads_mobile_sdk/y82;->b:Ljava/util/Map;

    iget-object v4, v11, Lads_mobile_sdk/y82;->a:Lads_mobile_sdk/f92;

    invoke-static {v2}, Lt12;->W(Ljava/lang/Object;)V

    goto/16 :goto_165

    :pswitch_82  #0x2
    iget-boolean v0, v11, Lads_mobile_sdk/y82;->j:Z

    iget-boolean v1, v11, Lads_mobile_sdk/y82;->i:Z

    iget-boolean v3, v11, Lads_mobile_sdk/y82;->h:Z

    iget-object v4, v11, Lads_mobile_sdk/y82;->e:Landroid/app/Activity;

    iget-object v7, v11, Lads_mobile_sdk/y82;->d:Ljava/lang/String;

    iget-object v8, v11, Lads_mobile_sdk/y82;->c:Lads_mobile_sdk/cy0;

    iget-object v9, v11, Lads_mobile_sdk/y82;->b:Ljava/util/Map;

    iget-object v10, v11, Lads_mobile_sdk/y82;->a:Lads_mobile_sdk/f92;

    invoke-static {v2}, Lt12;->W(Ljava/lang/Object;)V

    :goto_95
    move-object v15, v9

    move-object v9, v4

    move-object v4, v10

    move-object v10, v7

    goto/16 :goto_129

    :pswitch_9b  #0x1
    iget-boolean v0, v11, Lads_mobile_sdk/y82;->j:Z

    iget-boolean v1, v11, Lads_mobile_sdk/y82;->i:Z

    iget-boolean v3, v11, Lads_mobile_sdk/y82;->h:Z

    iget-object v4, v11, Lads_mobile_sdk/y82;->e:Landroid/app/Activity;

    iget-object v7, v11, Lads_mobile_sdk/y82;->d:Ljava/lang/String;

    iget-object v8, v11, Lads_mobile_sdk/y82;->c:Lads_mobile_sdk/cy0;

    iget-object v9, v11, Lads_mobile_sdk/y82;->b:Ljava/util/Map;

    iget-object v10, v11, Lads_mobile_sdk/y82;->a:Lads_mobile_sdk/f92;

    invoke-static {v2}, Lt12;->W(Ljava/lang/Object;)V

    move v14, v0

    goto :goto_107

    :pswitch_b0  #0x0
    invoke-static {v2}, Lt12;->W(Ljava/lang/Object;)V

    const-string v2, "u"

    invoke-interface {v1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    move-object v7, v2

    check-cast v7, Ljava/lang/String;

    if-eqz v7, :cond_c4

    invoke-static {v7}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_c8

    :cond_c4
    move v1, v5

    move-object v4, v6

    goto/16 :goto_262

    :cond_c8
    iget-object v2, v0, Lads_mobile_sdk/f92;->f:Lads_mobile_sdk/g0;

    invoke-virtual {v2}, Lads_mobile_sdk/g0;->b()Landroid/app/Activity;

    move-result-object v4

    if-nez v4, :cond_d6

    const-string v0, "Chrome Custom Tabs can only be launched from an Activity context."

    invoke-static {v5, v0, v6}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    return-object v12

    :cond_d6
    invoke-static {v7}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    iget-object v3, v0, Lads_mobile_sdk/f92;->n:Lads_mobile_sdk/a2;

    iget-object v3, v3, Lads_mobile_sdk/a2;->q:Landroid/os/Bundle;

    iput-object v0, v11, Lads_mobile_sdk/y82;->a:Lads_mobile_sdk/f92;

    iput-object v1, v11, Lads_mobile_sdk/y82;->b:Ljava/util/Map;

    move-object/from16 v8, p5

    iput-object v8, v11, Lads_mobile_sdk/y82;->c:Lads_mobile_sdk/cy0;

    iput-object v7, v11, Lads_mobile_sdk/y82;->d:Ljava/lang/String;

    iput-object v4, v11, Lads_mobile_sdk/y82;->e:Landroid/app/Activity;

    move/from16 v9, p2

    iput-boolean v9, v11, Lads_mobile_sdk/y82;->h:Z

    move/from16 v10, p3

    iput-boolean v10, v11, Lads_mobile_sdk/y82;->i:Z

    move/from16 v14, p4

    iput-boolean v14, v11, Lads_mobile_sdk/y82;->j:Z

    const/4 v15, 0x1

    iput v15, v11, Lads_mobile_sdk/y82;->m:I

    iget-object v5, v0, Lads_mobile_sdk/f92;->m:Lads_mobile_sdk/gn0;

    invoke-virtual {v5, v2, v15, v3, v11}, Lads_mobile_sdk/gn0;->a(Landroid/net/Uri;ILandroid/os/Bundle;Lwx;)Ljava/lang/Comparable;

    move-result-object v2

    if-ne v2, v13, :cond_103

    goto/16 :goto_258

    :cond_103
    move v3, v9

    move-object v9, v1

    move v1, v10

    move-object v10, v0

    :goto_107
    check-cast v2, Landroid/net/Uri;

    iget-object v0, v10, Lads_mobile_sdk/f92;->j:Lads_mobile_sdk/dl;

    iput-object v10, v11, Lads_mobile_sdk/y82;->a:Lads_mobile_sdk/f92;

    iput-object v9, v11, Lads_mobile_sdk/y82;->b:Ljava/util/Map;

    iput-object v8, v11, Lads_mobile_sdk/y82;->c:Lads_mobile_sdk/cy0;

    iput-object v7, v11, Lads_mobile_sdk/y82;->d:Ljava/lang/String;

    iput-object v4, v11, Lads_mobile_sdk/y82;->e:Landroid/app/Activity;

    iput-boolean v3, v11, Lads_mobile_sdk/y82;->h:Z

    iput-boolean v1, v11, Lads_mobile_sdk/y82;->i:Z

    iput-boolean v14, v11, Lads_mobile_sdk/y82;->j:Z

    const/4 v5, 0x2

    iput v5, v11, Lads_mobile_sdk/y82;->m:I

    invoke-virtual {v0, v2, v11}, Lads_mobile_sdk/dl;->b(Landroid/net/Uri;Lwx;)Ljava/lang/Comparable;

    move-result-object v2

    if-ne v2, v13, :cond_126

    goto/16 :goto_258

    :cond_126
    move v0, v14

    goto/16 :goto_95

    :goto_129
    check-cast v2, Landroid/net/Uri;

    iget-object v5, v4, Lads_mobile_sdk/f92;->d:Lads_mobile_sdk/k8;

    invoke-virtual {v5, v2, v8}, Lads_mobile_sdk/k8;->a(Landroid/net/Uri;Landroid/view/View;)Landroid/net/Uri;

    move-result-object v2

    invoke-static {v9}, Lec;->D(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v7

    if-nez v7, :cond_13e

    const-string v0, "Unable to get package name for Custom Tabs."

    const/4 v1, 0x6

    invoke-static {v1, v0, v6}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    return-object v12

    :cond_13e
    invoke-virtual {v2}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v5

    iput-object v4, v11, Lads_mobile_sdk/y82;->a:Lads_mobile_sdk/f92;

    iput-object v15, v11, Lads_mobile_sdk/y82;->b:Ljava/util/Map;

    iput-object v8, v11, Lads_mobile_sdk/y82;->c:Lads_mobile_sdk/cy0;

    iput-object v10, v11, Lads_mobile_sdk/y82;->d:Ljava/lang/String;

    iput-object v9, v11, Lads_mobile_sdk/y82;->e:Landroid/app/Activity;

    iput-object v2, v11, Lads_mobile_sdk/y82;->f:Landroid/net/Uri;

    iput-object v7, v11, Lads_mobile_sdk/y82;->g:Ljava/lang/String;

    iput-boolean v3, v11, Lads_mobile_sdk/y82;->h:Z

    iput-boolean v1, v11, Lads_mobile_sdk/y82;->i:Z

    iput-boolean v0, v11, Lads_mobile_sdk/y82;->j:Z

    const/4 v14, 0x3

    iput v14, v11, Lads_mobile_sdk/y82;->m:I

    invoke-virtual {v4, v8, v5, v11}, Lads_mobile_sdk/f92;->a(Lads_mobile_sdk/cy0;Ljava/lang/String;Lwx;)V

    sget-object v5, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    if-ne v5, v13, :cond_162

    goto/16 :goto_258

    :cond_162
    move-object v14, v8

    move-object v8, v2

    move-object v2, v5

    :goto_165
    check-cast v2, Ljava/lang/Boolean;

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_16f

    goto/16 :goto_259

    :cond_16f
    iget-object v2, v4, Lads_mobile_sdk/f92;->b:Lads_mobile_sdk/qr0;

    iget-object v5, v4, Lads_mobile_sdk/f92;->o:Lads_mobile_sdk/jz2;

    sget-object v6, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    move-object/from16 p4, v7

    sget-object v7, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    move-object/from16 p3, v8

    const-string v8, "gads:cct_v2_optimization:enabled"

    invoke-virtual {v2, v8, v6, v7}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Boolean;

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_1f4

    iget-object v2, v4, Lads_mobile_sdk/f92;->l:Lads_mobile_sdk/b90;

    iget-object v6, v2, Lads_mobile_sdk/b90;->d:Ltd;

    if-nez v6, :cond_1ac

    iget-object v6, v2, Lads_mobile_sdk/b90;->b:Lvy;

    new-instance v7, Lc4;

    const/16 v8, 0x16

    move-object/from16 p0, v4

    const/4 v4, 0x0

    invoke-direct {v7, v2, v4, v8}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v8, La42;

    invoke-direct {v8, v7, v4}, La42;-><init>(Lpk0;Lvx;)V

    sget-object v7, Ly90;->a:Ly90;

    move-object/from16 p2, v9

    const/4 v9, 0x2

    invoke-static {v6, v7, v4, v8, v9}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    goto :goto_1b1

    :cond_1ac
    move-object/from16 p0, v4

    move-object/from16 p2, v9

    const/4 v4, 0x0

    :goto_1b1
    iget-object v2, v2, Lads_mobile_sdk/b90;->d:Ltd;

    move-object/from16 p1, v2

    move-object/from16 p5, v15

    invoke-virtual/range {p0 .. p5}, Lads_mobile_sdk/f92;->a(Ltd;Landroid/app/Activity;Landroid/net/Uri;Ljava/lang/String;Ljava/util/Map;)V

    move-object/from16 v2, p0

    iput-object v2, v11, Lads_mobile_sdk/y82;->a:Lads_mobile_sdk/f92;

    iput-object v15, v11, Lads_mobile_sdk/y82;->b:Ljava/util/Map;

    iput-object v14, v11, Lads_mobile_sdk/y82;->c:Lads_mobile_sdk/cy0;

    iput-object v4, v11, Lads_mobile_sdk/y82;->d:Ljava/lang/String;

    iput-object v4, v11, Lads_mobile_sdk/y82;->e:Landroid/app/Activity;

    iput-object v4, v11, Lads_mobile_sdk/y82;->f:Landroid/net/Uri;

    iput-object v4, v11, Lads_mobile_sdk/y82;->g:Ljava/lang/String;

    iput-boolean v3, v11, Lads_mobile_sdk/y82;->h:Z

    iput-boolean v1, v11, Lads_mobile_sdk/y82;->i:Z

    iput-boolean v0, v11, Lads_mobile_sdk/y82;->j:Z

    const/4 v6, 0x4

    iput v6, v11, Lads_mobile_sdk/y82;->m:I

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v5, v10, v11}, Lads_mobile_sdk/jz2;->a(Lads_mobile_sdk/jz2;Ljava/lang/String;Lwx;)Ljava/lang/Object;

    move-result-object v5

    if-ne v5, v13, :cond_1de

    goto/16 :goto_258

    :cond_1de
    move-object v10, v14

    move-object v5, v15

    goto/16 :goto_64

    :goto_1e2
    iput-object v4, v11, Lads_mobile_sdk/y82;->a:Lads_mobile_sdk/f92;

    iput-object v4, v11, Lads_mobile_sdk/y82;->b:Ljava/util/Map;

    iput-object v4, v11, Lads_mobile_sdk/y82;->c:Lads_mobile_sdk/cy0;

    const/4 v0, 0x5

    iput v0, v11, Lads_mobile_sdk/y82;->m:I

    const/4 v6, 0x1

    move-object v4, v2

    invoke-virtual/range {v4 .. v11}, Lads_mobile_sdk/f92;->a(Ljava/util/Map;ZZZZLads_mobile_sdk/cy0;Lwx;)Ljava/lang/Object;

    move-result-object v0

    if-ne v0, v13, :cond_259

    goto :goto_258

    :cond_1f4
    move-object/from16 v8, p3

    move-object v2, v4

    iget-object v4, v2, Lads_mobile_sdk/f92;->b:Lads_mobile_sdk/qr0;

    move-object/from16 p0, v2

    const-string v2, "gads:cct_v2_connection:enabled"

    invoke-virtual {v4, v2, v6, v7}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Boolean;

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_25a

    new-instance v2, Lads_mobile_sdk/z82;

    move-object/from16 p1, p0

    move-object/from16 p0, v2

    move-object/from16 p3, v8

    move-object/from16 p2, v9

    move-object/from16 p5, v15

    invoke-direct/range {p0 .. p5}, Lads_mobile_sdk/z82;-><init>(Lads_mobile_sdk/f92;Landroid/app/Activity;Landroid/net/Uri;Ljava/lang/String;Ljava/util/Map;)V

    move-object/from16 v4, p0

    move-object/from16 v2, p1

    move-object/from16 v7, p4

    invoke-static {v9, v7, v4}, Lec;->f(Landroid/content/Context;Ljava/lang/String;Lg00;)V

    iput-object v2, v11, Lads_mobile_sdk/y82;->a:Lads_mobile_sdk/f92;

    iput-object v15, v11, Lads_mobile_sdk/y82;->b:Ljava/util/Map;

    iput-object v14, v11, Lads_mobile_sdk/y82;->c:Lads_mobile_sdk/cy0;

    const/4 v4, 0x0

    iput-object v4, v11, Lads_mobile_sdk/y82;->d:Ljava/lang/String;

    iput-object v4, v11, Lads_mobile_sdk/y82;->e:Landroid/app/Activity;

    iput-object v4, v11, Lads_mobile_sdk/y82;->f:Landroid/net/Uri;

    iput-object v4, v11, Lads_mobile_sdk/y82;->g:Ljava/lang/String;

    iput-boolean v3, v11, Lads_mobile_sdk/y82;->h:Z

    iput-boolean v1, v11, Lads_mobile_sdk/y82;->i:Z

    iput-boolean v0, v11, Lads_mobile_sdk/y82;->j:Z

    const/4 v6, 0x6

    iput v6, v11, Lads_mobile_sdk/y82;->m:I

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v5, v10, v11}, Lads_mobile_sdk/jz2;->a(Lads_mobile_sdk/jz2;Ljava/lang/String;Lwx;)Ljava/lang/Object;

    move-result-object v5

    if-ne v5, v13, :cond_243

    goto :goto_258

    :cond_243
    move-object v10, v14

    move-object v5, v15

    goto/16 :goto_49

    :goto_247
    iput-object v4, v11, Lads_mobile_sdk/y82;->a:Lads_mobile_sdk/f92;

    iput-object v4, v11, Lads_mobile_sdk/y82;->b:Ljava/util/Map;

    iput-object v4, v11, Lads_mobile_sdk/y82;->c:Lads_mobile_sdk/cy0;

    const/4 v0, 0x7

    iput v0, v11, Lads_mobile_sdk/y82;->m:I

    const/4 v6, 0x1

    move-object v4, v2

    invoke-virtual/range {v4 .. v11}, Lads_mobile_sdk/f92;->a(Ljava/util/Map;ZZZZLads_mobile_sdk/cy0;Lwx;)Ljava/lang/Object;

    move-result-object v0

    if-ne v0, v13, :cond_259

    :goto_258
    return-object v13

    :cond_259
    :goto_259
    return-object v12

    :cond_25a
    const/4 v4, 0x0

    const-string v0, "launchCustomTabs invoked when neither experiment arm is enabled."

    const/4 v1, 0x6

    invoke-static {v1, v0, v4}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    return-object v12

    :goto_262
    const-string v0, "Blank URL for browser open GMSG."

    invoke-static {v1, v0, v4}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    return-object v12

    :pswitch_data_268
    .packed-switch 0x0
        :pswitch_b0  #00000000
        :pswitch_9b  #00000001
        :pswitch_82  #00000002
        :pswitch_69  #00000003
        :pswitch_52  #00000004
        :pswitch_4e  #00000005
        :pswitch_37  #00000006
        :pswitch_33  #00000007
    .end packed-switch
.end method

.method public final a(Ljava/util/Map;ZZZZLads_mobile_sdk/cy0;Lwx;)Ljava/lang/Object;
    .registers 16

    .prologue
    instance-of v0, p7, Lads_mobile_sdk/d92;

    if-eqz v0, :cond_13

    move-object v0, p7

    check-cast v0, Lads_mobile_sdk/d92;

    iget v1, v0, Lads_mobile_sdk/d92;->h:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/d92;->h:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/d92;

    invoke-direct {v0, p0, p7}, Lads_mobile_sdk/d92;-><init>(Lads_mobile_sdk/f92;Lwx;)V

    :goto_18
    iget-object p7, v0, Lads_mobile_sdk/d92;->f:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/d92;->h:I

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    sget-object v6, Lrg2;->a:Lrg2;

    sget-object v7, Lwy;->a:Lwy;

    if-eqz v1, :cond_50

    if-eq v1, v5, :cond_42

    if-eq v1, v4, :cond_36

    if-ne v1, v3, :cond_30

    invoke-static {p7}, Lt12;->W(Ljava/lang/Object;)V

    return-object v6

    :cond_30
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v2

    :cond_36
    iget-boolean p0, v0, Lads_mobile_sdk/d92;->d:Z

    iget-boolean p1, v0, Lads_mobile_sdk/d92;->c:Z

    iget-object p2, v0, Lads_mobile_sdk/d92;->b:Lads_mobile_sdk/cy0;

    iget-object p3, v0, Lads_mobile_sdk/d92;->a:Ljava/util/Map;

    invoke-static {p7}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_88

    :cond_42
    iget-boolean p5, v0, Lads_mobile_sdk/d92;->e:Z

    iget-boolean p3, v0, Lads_mobile_sdk/d92;->d:Z

    iget-boolean p2, v0, Lads_mobile_sdk/d92;->c:Z

    iget-object p6, v0, Lads_mobile_sdk/d92;->b:Lads_mobile_sdk/cy0;

    iget-object p1, v0, Lads_mobile_sdk/d92;->a:Ljava/util/Map;

    invoke-static {p7}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_6b

    :cond_50
    invoke-static {p7}, Lt12;->W(Ljava/lang/Object;)V

    if-eqz p2, :cond_6b

    if-eqz p4, :cond_6b

    iput-object p1, v0, Lads_mobile_sdk/d92;->a:Ljava/util/Map;

    iput-object p6, v0, Lads_mobile_sdk/d92;->b:Lads_mobile_sdk/cy0;

    iput-boolean p2, v0, Lads_mobile_sdk/d92;->c:Z

    iput-boolean p3, v0, Lads_mobile_sdk/d92;->d:Z

    iput-boolean p5, v0, Lads_mobile_sdk/d92;->e:Z

    iput v5, v0, Lads_mobile_sdk/d92;->h:I

    iget-object p0, p0, Lads_mobile_sdk/f92;->e:Lads_mobile_sdk/z2;

    invoke-virtual {p0, v0}, Lads_mobile_sdk/z2;->n(Lvx;)Ljava/lang/Object;

    if-ne v6, v7, :cond_6b

    goto :goto_ac

    :cond_6b
    :goto_6b
    if-eqz p2, :cond_84

    if-eqz p5, :cond_84

    iget-object p0, p6, Lads_mobile_sdk/cy0;->o:Lads_mobile_sdk/mt0;

    if-eqz p0, :cond_84

    iput-object p1, v0, Lads_mobile_sdk/d92;->a:Ljava/util/Map;

    iput-object p6, v0, Lads_mobile_sdk/d92;->b:Lads_mobile_sdk/cy0;

    iput-boolean p2, v0, Lads_mobile_sdk/d92;->c:Z

    iput-boolean p3, v0, Lads_mobile_sdk/d92;->d:Z

    iput v4, v0, Lads_mobile_sdk/d92;->h:I

    invoke-interface {p0, v0}, Ll13;->a(Lwx;)Lrg2;

    move-result-object p0

    if-ne p0, v7, :cond_84

    goto :goto_ac

    :cond_84
    move p0, p3

    move-object p3, p1

    move p1, p2

    move-object p2, p6

    :goto_88
    if-eqz p0, :cond_ad

    new-instance p0, Lfx0;

    invoke-direct {p0}, Lfx0;-><init>()V

    const-string p4, "event_id"

    invoke-interface {p3, p4}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/String;

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    invoke-virtual {p0, p3, p1}, Lfx0;->r(Ljava/lang/String;Ljava/lang/Boolean;)V

    iput-object v2, v0, Lads_mobile_sdk/d92;->a:Ljava/util/Map;

    iput-object v2, v0, Lads_mobile_sdk/d92;->b:Lads_mobile_sdk/cy0;

    iput v3, v0, Lads_mobile_sdk/d92;->h:I

    const-string p1, "openIntentAsync"

    invoke-virtual {p2, p0, p1, v0}, Lads_mobile_sdk/cy0;->a(Lfx0;Ljava/lang/String;Lvx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v7, :cond_ad

    :goto_ac
    return-object v7

    :cond_ad
    return-object v6
.end method

.method public final a(Lads_mobile_sdk/cy0;Ljava/lang/String;Lwx;)V
    .registers 12

    .prologue
    instance-of v0, p3, Lads_mobile_sdk/b92;

    if-eqz v0, :cond_13

    move-object v0, p3

    check-cast v0, Lads_mobile_sdk/b92;

    iget v1, v0, Lads_mobile_sdk/b92;->c:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/b92;->c:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/b92;

    invoke-direct {v0, p0, p3}, Lads_mobile_sdk/b92;-><init>(Lads_mobile_sdk/f92;Lwx;)V

    :goto_18
    iget-object p3, v0, Lads_mobile_sdk/b92;->a:Ljava/lang/Object;

    iget v0, v0, Lads_mobile_sdk/b92;->c:I

    const/4 v1, 0x1

    if-eqz v0, :cond_2c

    if-ne v0, v1, :cond_26

    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V

    goto/16 :goto_e4

    :cond_26
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-void

    :cond_2c
    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p0, p0, Lads_mobile_sdk/f92;->p:Lads_mobile_sdk/o42;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p3, p0, Lads_mobile_sdk/o42;->a:Lads_mobile_sdk/a2;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-eqz p2, :cond_e4

    iget-object p1, p3, Lads_mobile_sdk/a2;->t0:Lads_mobile_sdk/a42;

    if-eqz p1, :cond_e4

    sget-object p1, Lads_mobile_sdk/hh3;->a:Ljava/util/WeakHashMap;

    sget-object p1, Lba0;->a:Lba0;

    sget-object p2, Lads_mobile_sdk/fw0;->t1:Lads_mobile_sdk/fw0;

    invoke-static {p2, p1, v1}, Lads_mobile_sdk/hh3;->a(Lads_mobile_sdk/fw0;Ljava/util/List;Z)Lads_mobile_sdk/rg3;

    move-result-object p1

    :try_start_49
    iget-object p2, p0, Lads_mobile_sdk/o42;->c:Lads_mobile_sdk/p22;

    iget-object p2, p2, Lads_mobile_sdk/p22;->l:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {p2}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result p2

    const/4 v0, 0x0

    if-eqz p2, :cond_75

    iget-object v3, p0, Lads_mobile_sdk/o42;->d:Lads_mobile_sdk/j42;

    iget-object p0, p0, Lads_mobile_sdk/o42;->b:Lads_mobile_sdk/xv;

    iget-object v4, p0, Lads_mobile_sdk/xv;->h:Ljava/lang/String;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v2, Lhn1;

    const/4 v6, 0x3

    const/4 v7, 0x0

    const/4 v5, 0x0

    invoke-direct/range {v2 .. v7}, Lhn1;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lvx;IZ)V

    iget-object p0, v3, Lads_mobile_sdk/j42;->a:Lvy;

    new-instance p2, Lb10;

    const/4 p3, 0x2

    invoke-direct {p2, v3, v2, v5, p3}, Lb10;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lvx;I)V

    const/4 p3, 0x3

    invoke-static {p0, v5, v5, p2, p3}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    goto :goto_a8

    :catchall_72
    move-exception v0

    move-object p0, v0

    goto :goto_ac

    :cond_75
    iget-object p2, p3, Lads_mobile_sdk/a2;->t0:Lads_mobile_sdk/a42;

    if-eqz p2, :cond_7c

    iget-boolean p2, p2, Lads_mobile_sdk/a42;->c:Z

    goto :goto_7d

    :cond_7c
    move p2, v0

    :goto_7d
    iget-object p3, p3, Lads_mobile_sdk/a2;->v0:Lads_mobile_sdk/lf2;

    if-eqz p3, :cond_92

    iget-boolean v2, p3, Lads_mobile_sdk/lf2;->a:Z

    if-eqz v2, :cond_92

    iget-object v2, p3, Lads_mobile_sdk/lf2;->b:Ljava/lang/String;

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    if-lez v2, :cond_92

    iget-boolean p3, p3, Lads_mobile_sdk/lf2;->c:Z

    if-eqz p3, :cond_92

    goto :goto_93

    :cond_92
    move v1, v0

    :goto_93
    if-eqz p2, :cond_a8

    if-eqz v1, :cond_a8

    iget-object p0, p0, Lads_mobile_sdk/o42;->e:Lads_mobile_sdk/qr0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string p2, "gads:skip_offline_notification_flow:enabled"

    sget-object p3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sget-object v0, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    invoke-virtual {p0, p2, p3, v0}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;
    :try_end_a8
    .catchall {:try_start_49 .. :try_end_a8} :catchall_72

    :cond_a8
    :goto_a8
    invoke-virtual {p1}, Lads_mobile_sdk/rg3;->close()V

    goto :goto_e4

    :goto_ac
    :try_start_ac
    invoke-virtual {p1, p0}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of p2, p0, Lox2;

    if-nez p2, :cond_dc

    invoke-virtual {p1, p0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of p2, p0, Lza2;

    if-nez p2, :cond_d4

    instance-of p2, p0, Ljava/util/concurrent/CancellationException;

    if-nez p2, :cond_cc

    instance-of p2, p0, Lads_mobile_sdk/mv0;

    if-eqz p2, :cond_c6

    throw p0

    :catchall_c3
    move-exception v0

    move-object p0, v0

    goto :goto_dd

    :cond_c6
    new-instance p2, Lads_mobile_sdk/tu0;

    invoke-direct {p2, p0}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw p2

    :cond_cc
    new-instance p2, Lads_mobile_sdk/ou0;

    check-cast p0, Ljava/util/concurrent/CancellationException;

    invoke-direct {p2, p0}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw p2

    :cond_d4
    new-instance p2, Lads_mobile_sdk/uw0;

    check-cast p0, Lza2;

    invoke-direct {p2, p0}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw p2

    :cond_dc
    throw p0
    :try_end_dd
    .catchall {:try_start_ac .. :try_end_dd} :catchall_c3

    :goto_dd
    :try_start_dd
    throw p0
    :try_end_de
    .catchall {:try_start_dd .. :try_end_de} :catchall_de

    :catchall_de
    move-exception v0

    move-object p2, v0

    invoke-static {p1, p0}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw p2

    :cond_e4
    :goto_e4
    return-void
.end method

.method public final a(Ltd;Landroid/app/Activity;Landroid/net/Uri;Ljava/lang/String;Ljava/util/Map;)V
    .registers 11

    .prologue
    new-instance v0, Landroid/content/Intent;

    const-string v1, "android.intent.action.VIEW"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v1, "android.support.customtabs.extra.SESSION"

    if-eqz p1, :cond_25

    iget-object v2, p1, Ltd;->d:Ljava/lang/Object;

    check-cast v2, Landroid/content/ComponentName;

    invoke-virtual {v2}, Landroid/content/ComponentName;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    iget-object p1, p1, Ltd;->c:Ljava/lang/Object;

    check-cast p1, Lc00;

    new-instance v2, Landroid/os/Bundle;

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    invoke-virtual {v2, v1, p1}, Landroid/os/Bundle;->putBinder(Ljava/lang/String;Landroid/os/IBinder;)V

    invoke-virtual {v0, v2}, Landroid/content/Intent;->putExtras(Landroid/os/Bundle;)Landroid/content/Intent;

    :cond_25
    iget-object p0, p0, Lads_mobile_sdk/f92;->b:Lads_mobile_sdk/qr0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    sget-object v2, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    const-string v3, "gads:cct_v2_partial_custom_tab_config:enabled"

    invoke-virtual {p0, v3, p1, v2}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Boolean;

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 p1, 0x0

    if-nez p0, :cond_3e

    goto :goto_9e

    :cond_3e
    const-string p0, "cct_init_h"

    invoke-interface {p5, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    const-string v2, "cct_bp"

    invoke-interface {p5, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p5

    check-cast p5, Ljava/lang/String;

    if-eqz p0, :cond_74

    invoke-static {p0}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_57

    goto :goto_74

    :cond_57
    invoke-static {p0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v2

    if-lez v2, :cond_74

    invoke-static {p0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p0

    if-lez p0, :cond_6e

    const-string v2, "androidx.browser.customtabs.extra.INITIAL_ACTIVITY_HEIGHT_PX"

    invoke-virtual {v0, v2, p0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string p0, "androidx.browser.customtabs.extra.ACTIVITY_HEIGHT_RESIZE_BEHAVIOR"

    invoke-virtual {v0, p0, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    goto :goto_74

    :cond_6e
    const-string p0, "Invalid value for the initialHeightPx argument"

    invoke-static {p0}, Lz6;->s(Ljava/lang/String;)V

    return-void

    :cond_74
    :goto_74
    if-eqz p5, :cond_9e

    invoke-static {p5}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result p0

    if-eqz p0, :cond_7d

    goto :goto_9e

    :cond_7d
    invoke-static {p5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p0

    if-ltz p0, :cond_9e

    invoke-static {p5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p0

    const/4 v2, 0x2

    if-gt p0, v2, :cond_9e

    invoke-static {p5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p0

    if-ltz p0, :cond_98

    if-gt p0, v2, :cond_98

    const-string p5, "androidx.browser.customtabs.extra.CLOSE_BUTTON_POSITION"

    invoke-virtual {v0, p5, p0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    goto :goto_9e

    :cond_98
    const-string p0, "Invalid value for the position argument"

    invoke-static {p0}, Lz6;->s(Ljava/lang/String;)V

    return-void

    :cond_9e
    :goto_9e
    invoke-virtual {v0, v1}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result p0

    const/4 p5, 0x0

    if-nez p0, :cond_b0

    new-instance p0, Landroid/os/Bundle;

    invoke-direct {p0}, Landroid/os/Bundle;-><init>()V

    invoke-virtual {p0, v1, p5}, Landroid/os/Bundle;->putBinder(Ljava/lang/String;Landroid/os/IBinder;)V

    invoke-virtual {v0, p0}, Landroid/content/Intent;->putExtras(Landroid/os/Bundle;)Landroid/content/Intent;

    :cond_b0
    const-string p0, "android.support.customtabs.extra.EXTRA_ENABLE_INSTANT_APPS"

    const/4 v1, 0x1

    invoke-virtual {v0, p0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    new-instance p0, Landroid/os/Bundle;

    invoke-direct {p0}, Landroid/os/Bundle;-><init>()V

    invoke-virtual {v0, p0}, Landroid/content/Intent;->putExtras(Landroid/os/Bundle;)Landroid/content/Intent;

    const-string p0, "androidx.browser.customtabs.extra.SHARE_STATE"

    invoke-virtual {v0, p0, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    invoke-static {}, Le00;->a()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_ed

    const-string v1, "com.android.browser.headers"

    invoke-virtual {v0, v1}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_da

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getBundleExtra(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v2

    goto :goto_df

    :cond_da
    new-instance v2, Landroid/os/Bundle;

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    :goto_df
    const-string v3, "Accept-Language"

    invoke-virtual {v2, v3}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v4

    if-nez v4, :cond_ed

    invoke-virtual {v2, v3, p0}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Bundle;)Landroid/content/Intent;

    :cond_ed
    sget p0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x22

    if-lt p0, v1, :cond_fb

    invoke-static {}, Ld00;->a()Landroid/app/ActivityOptions;

    move-result-object p0

    invoke-static {p0, p1}, Lf00;->a(Landroid/app/ActivityOptions;Z)V

    goto :goto_fc

    :cond_fb
    move-object p0, p5

    :goto_fc
    if-eqz p0, :cond_102

    invoke-virtual {p0}, Landroid/app/ActivityOptions;->toBundle()Landroid/os/Bundle;

    move-result-object p5

    :cond_102
    invoke-virtual {v0, p4}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    invoke-virtual {v0, p3}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    invoke-static {p2, v0, p5}, Lqx;->startActivity(Landroid/content/Context;Landroid/content/Intent;Landroid/os/Bundle;)V

    return-void
.end method

.method public final b()I
    .registers 1

    const/4 p0, 0x4

    return p0
.end method

.method public final b(Lads_mobile_sdk/cy0;Ljava/util/Map;Lwx;)Ljava/lang/Object;
    .registers 14

    .prologue
    instance-of v0, p3, Lads_mobile_sdk/x82;

    if-eqz v0, :cond_13

    move-object v0, p3

    check-cast v0, Lads_mobile_sdk/x82;

    iget v1, v0, Lads_mobile_sdk/x82;->f:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/x82;->f:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/x82;

    invoke-direct {v0, p0, p3}, Lads_mobile_sdk/x82;-><init>(Lads_mobile_sdk/f92;Lwx;)V

    :goto_18
    iget-object p3, v0, Lads_mobile_sdk/x82;->d:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/x82;->f:I

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    sget-object v5, Lwy;->a:Lwy;

    if-eqz v1, :cond_41

    if-eq v1, v3, :cond_37

    if-ne v1, v2, :cond_31

    iget-object p0, v0, Lads_mobile_sdk/x82;->c:Lads_mobile_sdk/cy0;

    iget-object p1, v0, Lads_mobile_sdk/x82;->b:Ljava/util/Map;

    iget-object p2, v0, Lads_mobile_sdk/x82;->a:Lads_mobile_sdk/f92;

    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_86

    :cond_31
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v4

    :cond_37
    iget-object p1, v0, Lads_mobile_sdk/x82;->c:Lads_mobile_sdk/cy0;

    iget-object p2, v0, Lads_mobile_sdk/x82;->b:Ljava/util/Map;

    iget-object p0, v0, Lads_mobile_sdk/x82;->a:Lads_mobile_sdk/f92;

    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_6f

    :cond_41
    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V

    const-string p3, "u"

    invoke-interface {p2, p3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/String;

    if-eqz p3, :cond_1d0

    invoke-static {p3}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_56

    goto/16 :goto_1d0

    :cond_56
    invoke-static {p3}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p3

    iget-object v1, p0, Lads_mobile_sdk/f92;->n:Lads_mobile_sdk/a2;

    iget-object v1, v1, Lads_mobile_sdk/a2;->q:Landroid/os/Bundle;

    iput-object p0, v0, Lads_mobile_sdk/x82;->a:Lads_mobile_sdk/f92;

    iput-object p2, v0, Lads_mobile_sdk/x82;->b:Ljava/util/Map;

    iput-object p1, v0, Lads_mobile_sdk/x82;->c:Lads_mobile_sdk/cy0;

    iput v3, v0, Lads_mobile_sdk/x82;->f:I

    iget-object v6, p0, Lads_mobile_sdk/f92;->m:Lads_mobile_sdk/gn0;

    invoke-virtual {v6, p3, v3, v1, v0}, Lads_mobile_sdk/gn0;->a(Landroid/net/Uri;ILandroid/os/Bundle;Lwx;)Ljava/lang/Comparable;

    move-result-object p3

    if-ne p3, v5, :cond_6f

    goto :goto_81

    :cond_6f
    :goto_6f
    check-cast p3, Landroid/net/Uri;

    iget-object v1, p0, Lads_mobile_sdk/f92;->j:Lads_mobile_sdk/dl;

    iput-object p0, v0, Lads_mobile_sdk/x82;->a:Lads_mobile_sdk/f92;

    iput-object p2, v0, Lads_mobile_sdk/x82;->b:Ljava/util/Map;

    iput-object p1, v0, Lads_mobile_sdk/x82;->c:Lads_mobile_sdk/cy0;

    iput v2, v0, Lads_mobile_sdk/x82;->f:I

    invoke-virtual {v1, p3, v0}, Lads_mobile_sdk/dl;->b(Landroid/net/Uri;Lwx;)Ljava/lang/Comparable;

    move-result-object p3

    if-ne p3, v5, :cond_82

    :goto_81
    return-object v5

    :cond_82
    move-object v9, p2

    move-object p2, p0

    move-object p0, p1

    move-object p1, v9

    :goto_86
    check-cast p3, Landroid/net/Uri;

    iget-object v0, p2, Lads_mobile_sdk/f92;->d:Lads_mobile_sdk/k8;

    iget-object v1, p2, Lads_mobile_sdk/f92;->a:Landroid/content/Context;

    invoke-virtual {v0, p3, p0}, Lads_mobile_sdk/k8;->a(Landroid/net/Uri;Landroid/view/View;)Landroid/net/Uri;

    move-result-object p0

    new-instance p3, Landroid/content/Intent;

    const-string v0, "android.intent.action.VIEW"

    invoke-direct {p3, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/high16 v2, 0x10000000

    invoke-virtual {p3, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {p3, p0}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    invoke-virtual {p3, v0}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    invoke-virtual {v1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v3

    const/high16 v5, 0x10000

    invoke-virtual {v3, p3, v5}, Landroid/content/pm/PackageManager;->queryIntentActivities(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2, p3, v3}, Lads_mobile_sdk/f92;->a(Landroid/content/Intent;Ljava/util/List;)Landroid/content/pm/ResolveInfo;

    move-result-object v6

    if-eqz v6, :cond_c4

    new-instance p0, Landroid/content/Intent;

    invoke-direct {p0, p3}, Landroid/content/Intent;-><init>(Landroid/content/Intent;)V

    iget-object p1, v6, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    iget-object p2, p1, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    iget-object p1, p1, Landroid/content/pm/ActivityInfo;->name:Ljava/lang/String;

    invoke-virtual {p0, p2, p1}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    return-object p0

    :cond_c4
    invoke-virtual {p0}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    move-result-object v6

    const-string v7, "http"

    invoke-virtual {v7, v6}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v6

    const-string v8, "https"

    if-eqz v6, :cond_df

    invoke-virtual {p0}, Landroid/net/Uri;->buildUpon()Landroid/net/Uri$Builder;

    move-result-object p0

    invoke-virtual {p0, v8}, Landroid/net/Uri$Builder;->scheme(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object p0

    invoke-virtual {p0}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object p0

    goto :goto_f5

    :cond_df
    invoke-virtual {p0}, Landroid/net/Uri;->getScheme()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v8, v6}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_1cf

    invoke-virtual {p0}, Landroid/net/Uri;->buildUpon()Landroid/net/Uri$Builder;

    move-result-object p0

    invoke-virtual {p0, v7}, Landroid/net/Uri$Builder;->scheme(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object p0

    invoke-virtual {p0}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object p0

    :goto_f5
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v6, Landroid/content/Intent;

    invoke-direct {v6, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual {v6, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    invoke-virtual {v6, p0}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    invoke-virtual {v6, v0}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    invoke-virtual {v1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    invoke-virtual {p0, v6, v5}, Landroid/content/pm/PackageManager;->queryIntentActivities(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2, v6, p0}, Lads_mobile_sdk/f92;->a(Landroid/content/Intent;Ljava/util/List;)Landroid/content/pm/ResolveInfo;

    move-result-object p0

    if-eqz p0, :cond_137

    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0, v6}, Landroid/content/Intent;-><init>(Landroid/content/Intent;)V

    iget-object p0, p0, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    iget-object v2, p0, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    iget-object p0, p0, Landroid/content/pm/ActivityInfo;->name:Ljava/lang/String;

    invoke-virtual {v0, v2, p0}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    invoke-virtual {v1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    invoke-virtual {p0, v0, v5}, Landroid/content/pm/PackageManager;->queryIntentActivities(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2, v0, p0}, Lads_mobile_sdk/f92;->a(Landroid/content/Intent;Ljava/util/List;)Landroid/content/pm/ResolveInfo;

    move-result-object p0

    if-eqz p0, :cond_137

    return-object v0

    :cond_137
    invoke-interface {v3}, Ljava/util/List;->isEmpty()Z

    move-result p0

    if-eqz p0, :cond_13f

    goto/16 :goto_1cf

    :cond_13f
    const-string p0, "use_running_process"

    invoke-interface {p1, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    invoke-static {p0}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result p0

    if-eqz p0, :cond_1a8

    const-class p0, Landroid/app/ActivityManager;

    invoke-virtual {v1, p0}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/app/ActivityManager;

    invoke-virtual {p0}, Landroid/app/ActivityManager;->getRunningAppProcesses()Ljava/util/List;

    move-result-object p0

    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :cond_15d
    :goto_15d
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_195

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Landroid/content/pm/ResolveInfo;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    instance-of v2, p0, Ljava/util/Collection;

    if-eqz v2, :cond_178

    invoke-interface {p0}, Ljava/util/Collection;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_178

    goto :goto_15d

    :cond_178
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_17c
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_15d

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/app/ActivityManager$RunningAppProcessInfo;

    iget-object v6, v1, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    iget-object v6, v6, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    iget-object v5, v5, Landroid/app/ActivityManager$RunningAppProcessInfo;->processName:Ljava/lang/String;

    invoke-static {v6, v5}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_17c

    move-object v4, v0

    :cond_195
    check-cast v4, Landroid/content/pm/ResolveInfo;

    if-eqz v4, :cond_1a8

    new-instance p0, Landroid/content/Intent;

    invoke-direct {p0, p3}, Landroid/content/Intent;-><init>(Landroid/content/Intent;)V

    iget-object p1, v4, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    iget-object p2, p1, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    iget-object p1, p1, Landroid/content/pm/ActivityInfo;->name:Ljava/lang/String;

    invoke-virtual {p0, p2, p1}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    return-object p0

    :cond_1a8
    const-string p0, "use_first_package"

    invoke-interface {p1, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    invoke-static {p0}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result p0

    if-eqz p0, :cond_1cf

    const/4 p0, 0x0

    invoke-interface {v3, p0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p0, Landroid/content/pm/ResolveInfo;

    new-instance p1, Landroid/content/Intent;

    invoke-direct {p1, p3}, Landroid/content/Intent;-><init>(Landroid/content/Intent;)V

    iget-object p0, p0, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    iget-object p2, p0, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    iget-object p0, p0, Landroid/content/pm/ActivityInfo;->name:Ljava/lang/String;

    invoke-virtual {p1, p2, p0}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    return-object p1

    :cond_1cf
    :goto_1cf
    return-object p3

    :cond_1d0
    :goto_1d0
    const-string p0, "Blank URL for browser open GMSG."

    const/4 p1, 0x6

    invoke-static {p1, p0, v4}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    return-object v4
.end method

.method public final b(Ljava/util/Map;ZZLads_mobile_sdk/cy0;Lwx;)Ljava/lang/Object;
    .registers 22

    .prologue
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p5

    instance-of v3, v2, Lads_mobile_sdk/e92;

    if-eqz v3, :cond_1a

    move-object v3, v2

    check-cast v3, Lads_mobile_sdk/e92;

    iget v4, v3, Lads_mobile_sdk/e92;->m:I

    const/high16 v5, -0x80000000

    and-int v6, v4, v5

    if-eqz v6, :cond_1a

    sub-int/2addr v4, v5

    iput v4, v3, Lads_mobile_sdk/e92;->m:I

    :goto_18
    move-object v14, v3

    goto :goto_20

    :cond_1a
    new-instance v3, Lads_mobile_sdk/e92;

    invoke-direct {v3, v0, v2}, Lads_mobile_sdk/e92;-><init>(Lads_mobile_sdk/f92;Lwx;)V

    goto :goto_18

    :goto_20
    iget-object v2, v14, Lads_mobile_sdk/e92;->k:Ljava/lang/Object;

    iget v3, v14, Lads_mobile_sdk/e92;->m:I

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    sget-object v15, Lwy;->a:Lwy;

    if-eqz v3, :cond_5c

    if-eq v3, v6, :cond_3a

    if-ne v3, v5, :cond_34

    invoke-static {v2}, Lt12;->W(Ljava/lang/Object;)V

    goto/16 :goto_110

    :cond_34
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {v0}, Lz6;->w(Ljava/lang/String;)V

    return-object v7

    :cond_3a
    iget v0, v14, Lads_mobile_sdk/e92;->j:I

    iget v1, v14, Lads_mobile_sdk/e92;->i:I

    iget-boolean v3, v14, Lads_mobile_sdk/e92;->c:Z

    iget-boolean v8, v14, Lads_mobile_sdk/e92;->b:Z

    iget-boolean v9, v14, Lads_mobile_sdk/e92;->a:Z

    iget-object v10, v14, Lads_mobile_sdk/e92;->h:Lads_mobile_sdk/nj3;

    iget-object v11, v14, Lads_mobile_sdk/e92;->g:Ljava/lang/String;

    iget-object v12, v14, Lads_mobile_sdk/e92;->f:Ljava/lang/String;

    iget-object v13, v14, Lads_mobile_sdk/e92;->e:Ljava/lang/String;

    iget-object v4, v14, Lads_mobile_sdk/e92;->d:Lads_mobile_sdk/cy0;

    invoke-static {v2}, Lt12;->W(Ljava/lang/Object;)V

    move-object v5, v11

    move-object v11, v4

    move-object v4, v10

    move-object v10, v5

    move-object v5, v13

    move v13, v8

    move-object v8, v5

    move v5, v9

    :goto_59
    move-object v9, v12

    goto/16 :goto_f4

    :cond_5c
    invoke-static {v2}, Lt12;->W(Ljava/lang/Object;)V

    const-string v2, "custom_close"

    invoke-interface {v1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const-string v3, "1"

    invoke-static {v2, v3}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    invoke-static {v1}, Lads_mobile_sdk/f92;->b(Ljava/util/Map;)I

    move-result v4

    const-string v8, "u"

    invoke-interface {v1, v8}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    move-object v13, v8

    check-cast v13, Ljava/lang/String;

    const-string v8, "html"

    invoke-interface {v1, v8}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    move-object v12, v8

    check-cast v12, Ljava/lang/String;

    const-string v8, "baseurl"

    invoke-interface {v1, v8}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v8

    move-object v11, v8

    check-cast v11, Ljava/lang/String;

    iget-object v8, v0, Lads_mobile_sdk/f92;->b:Lads_mobile_sdk/qr0;

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v9, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    sget-object v10, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    const-string v5, "gads:lockscreen_custom_webview:enabled"

    invoke-virtual {v8, v5, v9, v10}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    if-eqz v5, :cond_af

    const-string v5, "is_allowed_for_lock_screen"

    invoke-interface {v1, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    invoke-static {v1, v3}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_af

    move v1, v6

    goto :goto_b0

    :cond_af
    const/4 v1, 0x0

    :goto_b0
    iget-object v3, v0, Lads_mobile_sdk/f92;->h:Ltv2;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v3

    move-object v10, v3

    check-cast v10, Lads_mobile_sdk/nj3;

    if-eqz v13, :cond_e3

    move-object/from16 v3, p4

    iput-object v3, v14, Lads_mobile_sdk/e92;->d:Lads_mobile_sdk/cy0;

    iput-object v13, v14, Lads_mobile_sdk/e92;->e:Ljava/lang/String;

    iput-object v12, v14, Lads_mobile_sdk/e92;->f:Ljava/lang/String;

    iput-object v11, v14, Lads_mobile_sdk/e92;->g:Ljava/lang/String;

    iput-object v10, v14, Lads_mobile_sdk/e92;->h:Lads_mobile_sdk/nj3;

    move/from16 v5, p2

    iput-boolean v5, v14, Lads_mobile_sdk/e92;->a:Z

    move/from16 v8, p3

    iput-boolean v8, v14, Lads_mobile_sdk/e92;->b:Z

    iput-boolean v2, v14, Lads_mobile_sdk/e92;->c:Z

    iput v4, v14, Lads_mobile_sdk/e92;->i:I

    iput v1, v14, Lads_mobile_sdk/e92;->j:I

    iput v6, v14, Lads_mobile_sdk/e92;->m:I

    iget-object v0, v0, Lads_mobile_sdk/f92;->o:Lads_mobile_sdk/jz2;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v0, v13, v14}, Lads_mobile_sdk/jz2;->a(Lads_mobile_sdk/jz2;Ljava/lang/String;Lwx;)Ljava/lang/Object;

    move-result-object v0

    if-ne v0, v15, :cond_e9

    goto :goto_10f

    :cond_e3
    move/from16 v5, p2

    move/from16 v8, p3

    move-object/from16 v3, p4

    :cond_e9
    move-object v0, v13

    move v13, v8

    move-object v8, v0

    move v0, v1

    move v1, v4

    move-object v4, v10

    move-object v10, v11

    move-object v11, v3

    move v3, v2

    goto/16 :goto_59

    :goto_f4
    if-eqz v0, :cond_f8

    move v12, v6

    goto :goto_f9

    :cond_f8
    const/4 v12, 0x0

    :goto_f9
    iput-object v7, v14, Lads_mobile_sdk/e92;->d:Lads_mobile_sdk/cy0;

    iput-object v7, v14, Lads_mobile_sdk/e92;->e:Ljava/lang/String;

    iput-object v7, v14, Lads_mobile_sdk/e92;->f:Ljava/lang/String;

    iput-object v7, v14, Lads_mobile_sdk/e92;->g:Ljava/lang/String;

    iput-object v7, v14, Lads_mobile_sdk/e92;->h:Lads_mobile_sdk/nj3;

    const/4 v0, 0x2

    iput v0, v14, Lads_mobile_sdk/e92;->m:I

    move v6, v1

    move v7, v5

    move v5, v3

    invoke-virtual/range {v4 .. v14}, Lads_mobile_sdk/nj3;->a(ZIZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Lads_mobile_sdk/cy0;ZZLwx;)Ljava/lang/Object;

    move-result-object v0

    if-ne v0, v15, :cond_110

    :goto_10f
    return-object v15

    :cond_110
    :goto_110
    sget-object v0, Lrg2;->a:Lrg2;

    return-object v0
.end method

.method public final b(Ljava/lang/String;)Ljava/util/Map;
    .registers 6

    .prologue
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    sget-object v1, Lca0;->a:Lca0;

    if-nez v0, :cond_9

    return-object v1

    :cond_9
    :try_start_9
    new-instance v0, Lkm0;

    invoke-direct {v0}, Lkm0;-><init>()V

    const-class v2, Lfx0;

    invoke-virtual {v0, v2, p1}, Lkm0;->a(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p1, Lfx0;

    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    iget-object p1, p1, Lfx0;->a:Lf21;

    invoke-virtual {p1}, Lf21;->entrySet()Ljava/util/Set;

    move-result-object p1

    check-cast p1, Ld21;

    invoke-virtual {p1}, Ld21;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_2a
    move-object v2, p1

    check-cast v2, Lc21;

    invoke-virtual {v2}, Lc21;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_56

    move-object v2, p1

    check-cast v2, Lc21;

    invoke-virtual {v2}, Lc21;->b()Le21;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lkw0;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v2}, Lkw0;->m()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {v0, v3, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_53
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_53} :catch_54

    goto :goto_2a

    :catch_54
    move-exception p1

    goto :goto_57

    :cond_56
    return-object v0

    :goto_57
    const-string v0, "Failed to parse extra query params"

    invoke-static {v0, p1}, Lads_mobile_sdk/nw;->b(Ljava/lang/String;Ljava/lang/Throwable;)V

    iget-object p0, p0, Lads_mobile_sdk/f92;->s:Lads_mobile_sdk/ah3;

    const-string v0, "OpenGmsgHandler.parseHsdpExtraQueryParams"

    invoke-virtual {p0, v0, p1}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-object v1
.end method
