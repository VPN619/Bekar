.class public abstract Lads_mobile_sdk/al0;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Liz2;


# instance fields
.field public final a:Lnb1;

.field public c:Lads_mobile_sdk/ue1;


# direct methods
.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lnb1;

    invoke-direct {v0}, Lnb1;-><init>()V

    iput-object v0, p0, Lads_mobile_sdk/al0;->a:Lnb1;

    return-void
.end method


# virtual methods
.method public a(Lads_mobile_sdk/ue1;Lvx;)Ljava/lang/Object;
    .registers 3

    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method

.method public final a(Lads_mobile_sdk/zj;Lvx;)Ljava/lang/Object;
    .registers 13

    .prologue
    instance-of v0, p2, Lads_mobile_sdk/xk0;

    if-eqz v0, :cond_13

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/xk0;

    iget v1, v0, Lads_mobile_sdk/xk0;->e:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/xk0;->e:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/xk0;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/xk0;-><init>(Lads_mobile_sdk/al0;Lvx;)V

    :goto_18
    iget-object p2, v0, Lads_mobile_sdk/xk0;->c:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/xk0;->e:I

    sget-object v2, Lrg2;->a:Lrg2;

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x0

    sget-object v9, Lwy;->a:Lwy;

    if-eqz v1, :cond_60

    if-eq v1, v7, :cond_57

    if-eq v1, v6, :cond_4d

    if-eq v1, v5, :cond_45

    if-eq v1, v4, :cond_41

    if-eq v1, v3, :cond_38

    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v8

    :cond_38
    iget-object p0, v0, Lads_mobile_sdk/xk0;->a:Ljava/lang/Object;

    check-cast p0, Ljava/lang/Throwable;

    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    goto/16 :goto_c1

    :cond_41
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    return-object v2

    :cond_45
    iget-object p0, v0, Lads_mobile_sdk/xk0;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/ue1;

    :try_start_49
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_4c
    .catchall {:try_start_49 .. :try_end_4c} :catchall_ab

    goto :goto_98

    :cond_4d
    iget-object p0, v0, Lads_mobile_sdk/xk0;->b:Lads_mobile_sdk/ue1;

    iget-object p1, v0, Lads_mobile_sdk/xk0;->a:Ljava/lang/Object;

    check-cast p1, Lpk0;

    :try_start_53
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_56
    .catchall {:try_start_53 .. :try_end_56} :catchall_ab

    goto :goto_8b

    :cond_57
    iget-object p0, v0, Lads_mobile_sdk/xk0;->a:Ljava/lang/Object;

    move-object p1, p0

    check-cast p1, Lpk0;

    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_6e

    :cond_60
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    iput-object p1, v0, Lads_mobile_sdk/xk0;->a:Ljava/lang/Object;

    iput v7, v0, Lads_mobile_sdk/xk0;->e:I

    invoke-virtual {p0, v0}, Lads_mobile_sdk/al0;->b(Lwx;)Ljava/lang/Object;

    move-result-object p2

    if-ne p2, v9, :cond_6e

    goto :goto_bf

    :cond_6e
    :goto_6e
    check-cast p2, Lb13;

    instance-of p0, p2, Lads_mobile_sdk/av0;

    if-eqz p0, :cond_75

    goto :goto_aa

    :cond_75
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Lads_mobile_sdk/hv0;

    iget-object p0, p2, Lads_mobile_sdk/hv0;->b:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/ue1;

    :try_start_7e
    iput-object p1, v0, Lads_mobile_sdk/xk0;->a:Ljava/lang/Object;

    iput-object p0, v0, Lads_mobile_sdk/xk0;->b:Lads_mobile_sdk/ue1;

    iput v6, v0, Lads_mobile_sdk/xk0;->e:I

    invoke-virtual {p0, v0}, Lads_mobile_sdk/ue1;->d(Lwx;)Ljava/lang/Object;

    move-result-object p2

    if-ne p2, v9, :cond_8b

    goto :goto_bf

    :cond_8b
    :goto_8b
    iput-object p0, v0, Lads_mobile_sdk/xk0;->a:Ljava/lang/Object;

    iput-object v8, v0, Lads_mobile_sdk/xk0;->b:Lads_mobile_sdk/ue1;

    iput v5, v0, Lads_mobile_sdk/xk0;->e:I

    invoke-interface {p1, p0, v0}, Lpk0;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1
    :try_end_95
    .catchall {:try_start_7e .. :try_end_95} :catchall_ab

    if-ne p1, v9, :cond_98

    goto :goto_bf

    :cond_98
    :goto_98
    sget-object p1, Lxf1;->b:Lxf1;

    new-instance p2, Lads_mobile_sdk/te1;

    invoke-direct {p2, p0, v8, v6}, Lads_mobile_sdk/te1;-><init>(Lads_mobile_sdk/ue1;Lvx;I)V

    iput-object v8, v0, Lads_mobile_sdk/xk0;->a:Ljava/lang/Object;

    iput v4, v0, Lads_mobile_sdk/xk0;->e:I

    invoke-static {p1, p2, v0}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v9, :cond_aa

    goto :goto_bf

    :cond_aa
    :goto_aa
    return-object v2

    :catchall_ab
    move-exception p1

    sget-object p2, Lxf1;->b:Lxf1;

    new-instance v1, Lads_mobile_sdk/te1;

    invoke-direct {v1, p0, v8, v6}, Lads_mobile_sdk/te1;-><init>(Lads_mobile_sdk/ue1;Lvx;I)V

    iput-object p1, v0, Lads_mobile_sdk/xk0;->a:Ljava/lang/Object;

    iput-object v8, v0, Lads_mobile_sdk/xk0;->b:Lads_mobile_sdk/ue1;

    iput v3, v0, Lads_mobile_sdk/xk0;->e:I

    invoke-static {p2, v1, v0}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v9, :cond_c0

    :goto_bf
    return-object v9

    :cond_c0
    move-object p0, p1

    :goto_c1
    throw p0
.end method

.method public final a(Lfx0;Lvx;)Ljava/lang/Object;
    .registers 6

    .prologue
    new-instance v0, Lads_mobile_sdk/zj;

    const/4 v1, 0x0

    const/16 v2, 0x8

    invoke-direct {v0, p1, v1, v2}, Lads_mobile_sdk/zj;-><init>(Ljava/lang/Object;Lvx;I)V

    invoke-virtual {p0, v0, p2}, Lads_mobile_sdk/al0;->a(Lads_mobile_sdk/zj;Lvx;)Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lwy;->a:Lwy;

    if-ne p0, p1, :cond_11

    return-object p0

    :cond_11
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method

.method public final a(Ljava/lang/String;Ljava/lang/String;Lwx;)Ljava/lang/Object;
    .registers 10

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lnw;

    const/4 v4, 0x0

    const/16 v5, 0x9

    move-object v1, p1

    move-object v2, p2

    invoke-direct/range {v0 .. v5}, Lnw;-><init>(Ljava/lang/Object;Ljava/io/Serializable;Ljava/io/Serializable;Lvx;I)V

    invoke-virtual {p0, v0, p3}, Lads_mobile_sdk/al0;->a(Lnw;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public abstract a(Ljava/lang/String;Lvx;)Ljava/lang/Object;
.end method

.method public final a(Lnw;Lwx;)Ljava/lang/Object;
    .registers 12

    .prologue
    instance-of v0, p2, Lads_mobile_sdk/vk0;

    if-eqz v0, :cond_13

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/vk0;

    iget v1, v0, Lads_mobile_sdk/vk0;->e:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/vk0;->e:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/vk0;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/vk0;-><init>(Lads_mobile_sdk/al0;Lwx;)V

    :goto_18
    iget-object p2, v0, Lads_mobile_sdk/vk0;->c:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/vk0;->e:I

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    sget-object v8, Lwy;->a:Lwy;

    if-eqz v1, :cond_62

    if-eq v1, v6, :cond_59

    if-eq v1, v5, :cond_4f

    if-eq v1, v4, :cond_47

    if-eq v1, v3, :cond_3f

    if-eq v1, v2, :cond_36

    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v7

    :cond_36
    iget-object p0, v0, Lads_mobile_sdk/vk0;->a:Ljava/lang/Object;

    check-cast p0, Ljava/lang/Throwable;

    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    goto/16 :goto_c7

    :cond_3f
    iget-object p0, v0, Lads_mobile_sdk/vk0;->a:Ljava/lang/Object;

    check-cast p0, Lb13;

    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    return-object p0

    :cond_47
    iget-object p0, v0, Lads_mobile_sdk/vk0;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/ue1;

    :try_start_4b
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_4e
    .catchall {:try_start_4b .. :try_end_4e} :catchall_b1

    goto :goto_9c

    :cond_4f
    iget-object p0, v0, Lads_mobile_sdk/vk0;->b:Lads_mobile_sdk/ue1;

    iget-object p1, v0, Lads_mobile_sdk/vk0;->a:Ljava/lang/Object;

    check-cast p1, Lpk0;

    :try_start_55
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_58
    .catchall {:try_start_55 .. :try_end_58} :catchall_b1

    goto :goto_8f

    :cond_59
    iget-object p0, v0, Lads_mobile_sdk/vk0;->a:Ljava/lang/Object;

    move-object p1, p0

    check-cast p1, Lpk0;

    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_70

    :cond_62
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    iput-object p1, v0, Lads_mobile_sdk/vk0;->a:Ljava/lang/Object;

    iput v6, v0, Lads_mobile_sdk/vk0;->e:I

    invoke-virtual {p0, v0}, Lads_mobile_sdk/al0;->b(Lwx;)Ljava/lang/Object;

    move-result-object p2

    if-ne p2, v8, :cond_70

    goto :goto_c5

    :cond_70
    :goto_70
    check-cast p2, Lb13;

    instance-of p0, p2, Lads_mobile_sdk/av0;

    if-eqz p0, :cond_79

    check-cast p2, Lads_mobile_sdk/av0;

    return-object p2

    :cond_79
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Lads_mobile_sdk/hv0;

    iget-object p0, p2, Lads_mobile_sdk/hv0;->b:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/ue1;

    :try_start_82
    iput-object p1, v0, Lads_mobile_sdk/vk0;->a:Ljava/lang/Object;

    iput-object p0, v0, Lads_mobile_sdk/vk0;->b:Lads_mobile_sdk/ue1;

    iput v5, v0, Lads_mobile_sdk/vk0;->e:I

    invoke-virtual {p0, v0}, Lads_mobile_sdk/ue1;->d(Lwx;)Ljava/lang/Object;

    move-result-object p2

    if-ne p2, v8, :cond_8f

    goto :goto_c5

    :cond_8f
    :goto_8f
    iput-object p0, v0, Lads_mobile_sdk/vk0;->a:Ljava/lang/Object;

    iput-object v7, v0, Lads_mobile_sdk/vk0;->b:Lads_mobile_sdk/ue1;

    iput v4, v0, Lads_mobile_sdk/vk0;->e:I

    invoke-interface {p1, p0, v0}, Lpk0;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    if-ne p2, v8, :cond_9c

    goto :goto_c5

    :cond_9c
    :goto_9c
    check-cast p2, Lb13;
    :try_end_9e
    .catchall {:try_start_82 .. :try_end_9e} :catchall_b1

    sget-object p1, Lxf1;->b:Lxf1;

    new-instance v1, Lads_mobile_sdk/te1;

    invoke-direct {v1, p0, v7, v6}, Lads_mobile_sdk/te1;-><init>(Lads_mobile_sdk/ue1;Lvx;I)V

    iput-object p2, v0, Lads_mobile_sdk/vk0;->a:Ljava/lang/Object;

    iput v3, v0, Lads_mobile_sdk/vk0;->e:I

    invoke-static {p1, v1, v0}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v8, :cond_b0

    goto :goto_c5

    :cond_b0
    return-object p2

    :catchall_b1
    move-exception p1

    sget-object p2, Lxf1;->b:Lxf1;

    new-instance v1, Lads_mobile_sdk/te1;

    invoke-direct {v1, p0, v7, v6}, Lads_mobile_sdk/te1;-><init>(Lads_mobile_sdk/ue1;Lvx;I)V

    iput-object p1, v0, Lads_mobile_sdk/vk0;->a:Ljava/lang/Object;

    iput-object v7, v0, Lads_mobile_sdk/vk0;->b:Lads_mobile_sdk/ue1;

    iput v2, v0, Lads_mobile_sdk/vk0;->e:I

    invoke-static {p2, v1, v0}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v8, :cond_c6

    :goto_c5
    return-object v8

    :cond_c6
    move-object p0, p1

    :goto_c7
    throw p0
.end method

.method public final b(Lads_mobile_sdk/ue1;Lwx;)Ljava/lang/Object;
    .registers 9

    .prologue
    instance-of v0, p2, Lads_mobile_sdk/ok0;

    if-eqz v0, :cond_13

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/ok0;

    iget v1, v0, Lads_mobile_sdk/ok0;->e:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/ok0;->e:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/ok0;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/ok0;-><init>(Lads_mobile_sdk/al0;Lwx;)V

    :goto_18
    iget-object p2, v0, Lads_mobile_sdk/ok0;->c:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/ok0;->e:I

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    sget-object v5, Lwy;->a:Lwy;

    if-eqz v1, :cond_39

    if-eq v1, v4, :cond_31

    if-ne v1, v3, :cond_2b

    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_5c

    :cond_2b
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v2

    :cond_31
    iget-object p1, v0, Lads_mobile_sdk/ok0;->b:Lads_mobile_sdk/ue1;

    iget-object p0, v0, Lads_mobile_sdk/ok0;->a:Lads_mobile_sdk/al0;

    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_4f

    :cond_39
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p2, p0, Lads_mobile_sdk/al0;->c:Lads_mobile_sdk/ue1;

    iput-object p1, p0, Lads_mobile_sdk/al0;->c:Lads_mobile_sdk/ue1;

    if-eqz p2, :cond_4f

    iput-object p0, v0, Lads_mobile_sdk/ok0;->a:Lads_mobile_sdk/al0;

    iput-object p1, v0, Lads_mobile_sdk/ok0;->b:Lads_mobile_sdk/ue1;

    iput v4, v0, Lads_mobile_sdk/ok0;->e:I

    invoke-virtual {p2, v0}, Lads_mobile_sdk/ue1;->c(Lwx;)Ljava/lang/Object;

    move-result-object p2

    if-ne p2, v5, :cond_4f

    goto :goto_5b

    :cond_4f
    :goto_4f
    iput-object v2, v0, Lads_mobile_sdk/ok0;->a:Lads_mobile_sdk/al0;

    iput-object v2, v0, Lads_mobile_sdk/ok0;->b:Lads_mobile_sdk/ue1;

    iput v3, v0, Lads_mobile_sdk/ok0;->e:I

    invoke-virtual {p0, p1, v0}, Lads_mobile_sdk/al0;->a(Lads_mobile_sdk/ue1;Lvx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_5c

    :goto_5b
    return-object v5

    :cond_5c
    :goto_5c
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method

.method public final b(Lwx;)Ljava/lang/Object;
    .registers 10

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/sk0;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/sk0;

    iget v1, v0, Lads_mobile_sdk/sk0;->e:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/sk0;->e:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/sk0;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/sk0;-><init>(Lads_mobile_sdk/al0;Lwx;)V

    :goto_18
    iget-object p1, v0, Lads_mobile_sdk/sk0;->c:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/sk0;->e:I

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    sget-object v6, Lwy;->a:Lwy;

    if-eqz v1, :cond_5a

    if-eq v1, v4, :cond_4c

    if-eq v1, v3, :cond_40

    if-ne v1, v2, :cond_3a

    iget-object p0, v0, Lads_mobile_sdk/sk0;->b:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/ue1;

    iget-object v0, v0, Lads_mobile_sdk/sk0;->a:Ljava/lang/Object;

    check-cast v0, Llb1;

    :try_start_32
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_35
    .catchall {:try_start_32 .. :try_end_35} :catchall_37

    goto/16 :goto_b7

    :catchall_37
    move-exception p0

    goto/16 :goto_c3

    :cond_3a
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v5

    :cond_40
    iget-object p0, v0, Lads_mobile_sdk/sk0;->b:Ljava/lang/Object;

    check-cast p0, Llb1;

    iget-object v1, v0, Lads_mobile_sdk/sk0;->a:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/al0;

    :try_start_48
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_4b
    .catchall {:try_start_48 .. :try_end_4b} :catchall_c1

    goto :goto_96

    :cond_4c
    iget-object p0, v0, Lads_mobile_sdk/sk0;->b:Ljava/lang/Object;

    check-cast p0, Llb1;

    iget-object v1, v0, Lads_mobile_sdk/sk0;->a:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/al0;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    move-object p1, p0

    move-object p0, v1

    goto :goto_6c

    :cond_5a
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iput-object p0, v0, Lads_mobile_sdk/sk0;->a:Ljava/lang/Object;

    iget-object p1, p0, Lads_mobile_sdk/al0;->a:Lnb1;

    iput-object p1, v0, Lads_mobile_sdk/sk0;->b:Ljava/lang/Object;

    iput v4, v0, Lads_mobile_sdk/sk0;->e:I

    invoke-virtual {p1, v0}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v6, :cond_6c

    goto :goto_b4

    :cond_6c
    :goto_6c
    :try_start_6c
    iget-object v1, p0, Lads_mobile_sdk/al0;->c:Lads_mobile_sdk/ue1;

    if-eqz v1, :cond_85

    iget-object v4, v1, Lads_mobile_sdk/ue1;->a:Lads_mobile_sdk/cy0;

    if-eqz v4, :cond_85

    iget-object v4, v4, Lads_mobile_sdk/cy0;->k:Ljava/util/concurrent/atomic/AtomicBoolean;

    if-eqz v4, :cond_85

    invoke-virtual {v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v4

    if-eqz v4, :cond_7f

    goto :goto_85

    :cond_7f
    move-object v0, p1

    move-object p0, v1

    goto :goto_b7

    :catchall_82
    move-exception p0

    move-object v0, p1

    goto :goto_c3

    :cond_85
    :goto_85
    iput-object p0, v0, Lads_mobile_sdk/sk0;->a:Ljava/lang/Object;

    iput-object p1, v0, Lads_mobile_sdk/sk0;->b:Ljava/lang/Object;

    iput v3, v0, Lads_mobile_sdk/sk0;->e:I

    invoke-virtual {p0, v5, v0}, Lads_mobile_sdk/al0;->a(Ljava/lang/String;Lvx;)Ljava/lang/Object;

    move-result-object v1
    :try_end_8f
    .catchall {:try_start_6c .. :try_end_8f} :catchall_82

    if-ne v1, v6, :cond_92

    goto :goto_b4

    :cond_92
    move-object v7, v1

    move-object v1, p0

    move-object p0, p1

    move-object p1, v7

    :goto_96
    :try_start_96
    check-cast p1, Lb13;

    instance-of v3, p1, Lads_mobile_sdk/av0;

    if-eqz v3, :cond_9f

    check-cast p1, Lads_mobile_sdk/av0;

    goto :goto_bd

    :cond_9f
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p1, Lads_mobile_sdk/hv0;

    iget-object p1, p1, Lads_mobile_sdk/hv0;->b:Ljava/lang/Object;

    check-cast p1, Lads_mobile_sdk/ue1;

    iput-object p0, v0, Lads_mobile_sdk/sk0;->a:Ljava/lang/Object;

    iput-object p1, v0, Lads_mobile_sdk/sk0;->b:Ljava/lang/Object;

    iput v2, v0, Lads_mobile_sdk/sk0;->e:I

    invoke-virtual {v1, p1, v0}, Lads_mobile_sdk/al0;->b(Lads_mobile_sdk/ue1;Lwx;)Ljava/lang/Object;

    move-result-object v0
    :try_end_b2
    .catchall {:try_start_96 .. :try_end_b2} :catchall_c1

    if-ne v0, v6, :cond_b5

    :goto_b4
    return-object v6

    :cond_b5
    move-object v0, p0

    move-object p0, p1

    :goto_b7
    :try_start_b7
    new-instance p1, Lads_mobile_sdk/hv0;

    invoke-direct {p1, p0}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V
    :try_end_bc
    .catchall {:try_start_b7 .. :try_end_bc} :catchall_37

    move-object p0, v0

    :goto_bd
    invoke-interface {p0, v5}, Llb1;->b(Ljava/lang/Object;)V

    return-object p1

    :catchall_c1
    move-exception p1

    goto :goto_c5

    :goto_c3
    move-object p1, p0

    move-object p0, v0

    :goto_c5
    invoke-interface {p0, v5}, Llb1;->b(Ljava/lang/Object;)V

    throw p1
.end method

.method public final c(Lads_mobile_sdk/ue1;Lwx;)Ljava/lang/Object;
    .registers 9

    .prologue
    instance-of v0, p2, Lads_mobile_sdk/pk0;

    if-eqz v0, :cond_13

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/pk0;

    iget v1, v0, Lads_mobile_sdk/pk0;->f:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/pk0;->f:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/pk0;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/pk0;-><init>(Lads_mobile_sdk/al0;Lwx;)V

    :goto_18
    iget-object p2, v0, Lads_mobile_sdk/pk0;->d:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/pk0;->f:I

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    sget-object v5, Lwy;->a:Lwy;

    if-eqz v1, :cond_45

    if-eq v1, v3, :cond_37

    if-ne v1, v2, :cond_31

    iget-object p0, v0, Lads_mobile_sdk/pk0;->a:Ljava/lang/Object;

    check-cast p0, Llb1;

    :try_start_2b
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_2e
    .catchall {:try_start_2b .. :try_end_2e} :catchall_2f

    goto :goto_69

    :catchall_2f
    move-exception p1

    goto :goto_6f

    :cond_31
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v4

    :cond_37
    iget-object p0, v0, Lads_mobile_sdk/pk0;->c:Lnb1;

    iget-object p1, v0, Lads_mobile_sdk/pk0;->b:Lads_mobile_sdk/ue1;

    iget-object v1, v0, Lads_mobile_sdk/pk0;->a:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/al0;

    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    move-object p2, p0

    move-object p0, v1

    goto :goto_59

    :cond_45
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    iput-object p0, v0, Lads_mobile_sdk/pk0;->a:Ljava/lang/Object;

    iput-object p1, v0, Lads_mobile_sdk/pk0;->b:Lads_mobile_sdk/ue1;

    iget-object p2, p0, Lads_mobile_sdk/al0;->a:Lnb1;

    iput-object p2, v0, Lads_mobile_sdk/pk0;->c:Lnb1;

    iput v3, v0, Lads_mobile_sdk/pk0;->f:I

    invoke-virtual {p2, v0}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v5, :cond_59

    goto :goto_67

    :cond_59
    :goto_59
    :try_start_59
    iput-object p2, v0, Lads_mobile_sdk/pk0;->a:Ljava/lang/Object;

    iput-object v4, v0, Lads_mobile_sdk/pk0;->b:Lads_mobile_sdk/ue1;

    iput-object v4, v0, Lads_mobile_sdk/pk0;->c:Lnb1;

    iput v2, v0, Lads_mobile_sdk/pk0;->f:I

    invoke-virtual {p0, p1, v0}, Lads_mobile_sdk/al0;->b(Lads_mobile_sdk/ue1;Lwx;)Ljava/lang/Object;

    move-result-object p0
    :try_end_65
    .catchall {:try_start_59 .. :try_end_65} :catchall_71

    if-ne p0, v5, :cond_68

    :goto_67
    return-object v5

    :cond_68
    move-object p0, p2

    :goto_69
    :try_start_69
    sget-object p1, Lrg2;->a:Lrg2;
    :try_end_6b
    .catchall {:try_start_69 .. :try_end_6b} :catchall_2f

    invoke-interface {p0, v4}, Llb1;->b(Ljava/lang/Object;)V

    return-object p1

    :goto_6f
    move-object p2, p0

    goto :goto_73

    :catchall_71
    move-exception p0

    move-object p1, p0

    :goto_73
    invoke-interface {p2, v4}, Llb1;->b(Ljava/lang/Object;)V

    throw p1
.end method

.method public final c(Lwx;)Ljava/lang/Object;
    .registers 6

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/tk0;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/tk0;

    iget v1, v0, Lads_mobile_sdk/tk0;->e:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/tk0;->e:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/tk0;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/tk0;-><init>(Lads_mobile_sdk/al0;Lwx;)V

    :goto_18
    iget-object p1, v0, Lads_mobile_sdk/tk0;->c:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/tk0;->e:I

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v1, :cond_32

    if-ne v1, v2, :cond_2c

    iget-object p0, v0, Lads_mobile_sdk/tk0;->b:Lnb1;

    iget-object v0, v0, Lads_mobile_sdk/tk0;->a:Lads_mobile_sdk/al0;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    move-object p1, p0

    move-object p0, v0

    goto :goto_46

    :cond_2c
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v3

    :cond_32
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iput-object p0, v0, Lads_mobile_sdk/tk0;->a:Lads_mobile_sdk/al0;

    iget-object p1, p0, Lads_mobile_sdk/al0;->a:Lnb1;

    iput-object p1, v0, Lads_mobile_sdk/tk0;->b:Lnb1;

    iput v2, v0, Lads_mobile_sdk/tk0;->e:I

    invoke-virtual {p1, v0}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v0

    sget-object v1, Lwy;->a:Lwy;

    if-ne v0, v1, :cond_46

    return-object v1

    :cond_46
    :goto_46
    :try_start_46
    iget-object p0, p0, Lads_mobile_sdk/al0;->c:Lads_mobile_sdk/ue1;

    if-eqz p0, :cond_5b

    iget-object p0, p0, Lads_mobile_sdk/ue1;->a:Lads_mobile_sdk/cy0;

    if-eqz p0, :cond_5b

    iget-object p0, p0, Lads_mobile_sdk/cy0;->k:Ljava/util/concurrent/atomic/AtomicBoolean;

    if-eqz p0, :cond_5b

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result p0

    if-nez p0, :cond_5b

    goto :goto_5c

    :catchall_59
    move-exception p0

    goto :goto_64

    :cond_5b
    const/4 v2, 0x0

    :goto_5c
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0
    :try_end_60
    .catchall {:try_start_46 .. :try_end_60} :catchall_59

    invoke-virtual {p1, v3}, Lnb1;->b(Ljava/lang/Object;)V

    return-object p0

    :goto_64
    invoke-virtual {p1, v3}, Lnb1;->b(Ljava/lang/Object;)V

    throw p0
.end method

.method public final d(Lwx;)Ljava/lang/Object;
    .registers 6

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/uk0;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/uk0;

    iget v1, v0, Lads_mobile_sdk/uk0;->c:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/uk0;->c:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/uk0;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/uk0;-><init>(Lads_mobile_sdk/al0;Lwx;)V

    :goto_18
    iget-object p1, v0, Lads_mobile_sdk/uk0;->a:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/uk0;->c:I

    const/4 v2, 0x1

    if-eqz v1, :cond_2c

    if-ne v1, v2, :cond_25

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_3a

    :cond_25
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0

    :cond_2c
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iput v2, v0, Lads_mobile_sdk/uk0;->c:I

    invoke-virtual {p0, v0}, Lads_mobile_sdk/al0;->b(Lwx;)Ljava/lang/Object;

    move-result-object p1

    sget-object p0, Lwy;->a:Lwy;

    if-ne p1, p0, :cond_3a

    return-object p0

    :cond_3a
    :goto_3a
    check-cast p1, Lb13;

    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method
