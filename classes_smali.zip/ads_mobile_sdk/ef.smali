.class public final Lads_mobile_sdk/ef;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Lv03;


# direct methods
.method public constructor <init>(Lv03;)V
    .registers 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/ef;->a:Lv03;

    return-void
.end method


# virtual methods
.method public final a(Lwx;)Ljava/lang/Object;
    .registers 6

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/df;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/df;

    iget v1, v0, Lads_mobile_sdk/df;->c:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/df;->c:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/df;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/df;-><init>(Lads_mobile_sdk/ef;Lwx;)V

    :goto_18
    iget-object p1, v0, Lads_mobile_sdk/df;->a:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/df;->c:I

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_2c

    if-ne v1, v3, :cond_26

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_44

    :cond_26
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v2

    :cond_2c
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p0, p0, Lads_mobile_sdk/ef;->a:Lv03;

    invoke-interface {p0}, Lv03;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lc42;

    iget-object p0, p0, Lc42;->c:Lsw;

    iput v3, v0, Lads_mobile_sdk/df;->c:I

    invoke-static {p0, v0}, Lla1;->u(Lff0;Lwx;)Ljava/lang/Object;

    move-result-object p1

    sget-object p0, Lwy;->a:Lwy;

    if-ne p1, p0, :cond_44

    return-object p0

    :cond_44
    :goto_44
    check-cast p1, Lads_mobile_sdk/af;

    if-eqz p1, :cond_4d

    invoke-virtual {p1}, Lads_mobile_sdk/af;->p()Ljava/util/Map;

    move-result-object p0

    return-object p0

    :cond_4d
    return-object v2
.end method
