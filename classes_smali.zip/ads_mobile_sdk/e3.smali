.class public final Lads_mobile_sdk/e3;
.super Lads_mobile_sdk/sr;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final l:Lads_mobile_sdk/vz;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/vz;Lads_mobile_sdk/qr0;Lads_mobile_sdk/g0;Lads_mobile_sdk/ux2;Lx43;Lvy;)V
    .registers 13

    invoke-virtual {p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-object v0, p0

    move-object v4, p2

    move-object v5, p3

    move-object v3, p4

    move-object v1, p5

    move-object v2, p6

    invoke-direct/range {v0 .. v5}, Lads_mobile_sdk/sr;-><init>(Lx43;Lvy;Lads_mobile_sdk/ux2;Lads_mobile_sdk/qr0;Lads_mobile_sdk/g0;)V

    iput-object p1, v0, Lads_mobile_sdk/e3;->l:Lads_mobile_sdk/vz;

    return-void
.end method

.method public static a(Lads_mobile_sdk/e3;Lwx;)Ljava/lang/Object;
    .registers 7

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/c3;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/c3;

    iget v1, v0, Lads_mobile_sdk/c3;->c:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/c3;->c:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/c3;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/c3;-><init>(Lads_mobile_sdk/e3;Lwx;)V

    :goto_18
    iget-object p1, v0, Lads_mobile_sdk/c3;->a:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/c3;->c:I

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v1, :cond_2c

    if-ne v1, v2, :cond_26

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_50

    :cond_26
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v3

    :cond_2c
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/sr;->d:Lvy;

    new-instance v1, Lads_mobile_sdk/cb;

    invoke-direct {v1, p0, v3, v2}, Lads_mobile_sdk/cb;-><init>(Ljava/lang/Object;Lvx;I)V

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance p0, Lads_mobile_sdk/ap;

    invoke-direct {p0, v1, v3, v2}, Lads_mobile_sdk/ap;-><init>(Lbk0;Lvx;I)V

    const/4 v1, 0x2

    sget-object v4, Ly90;->a:Ly90;

    invoke-static {p1, v4, p0, v1}, Lg73;->g(Lvy;Lly;Lpk0;I)Lv20;

    move-result-object p0

    iput v2, v0, Lads_mobile_sdk/c3;->c:I

    invoke-virtual {p0, v0}, Lnv0;->q(Lvx;)Ljava/lang/Object;

    move-result-object p1

    sget-object p0, Lwy;->a:Lwy;

    if-ne p1, p0, :cond_50

    return-object p0

    :cond_50
    :goto_50
    check-cast p1, Lb13;

    if-eqz p1, :cond_62

    instance-of p0, p1, Lads_mobile_sdk/av0;

    if-eqz p0, :cond_5b

    check-cast p1, Lads_mobile_sdk/av0;

    return-object p1

    :cond_5b
    check-cast p1, Lads_mobile_sdk/hv0;

    iget-object p0, p1, Lads_mobile_sdk/hv0;->b:Ljava/lang/Object;

    move-object v3, p0

    check-cast v3, Lcom/google/android/gms/ads/identifier/AdvertisingIdClient$Info;

    :cond_62
    new-instance p0, Lads_mobile_sdk/hv0;

    new-instance p1, Lads_mobile_sdk/b3;

    invoke-direct {p1, v3}, Lads_mobile_sdk/b3;-><init>(Lcom/google/android/gms/ads/identifier/AdvertisingIdClient$Info;)V

    invoke-direct {p0, p1}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    return-object p0
.end method


# virtual methods
.method public final a()Lads_mobile_sdk/lw0;
    .registers 1

    sget-object p0, Lads_mobile_sdk/lw0;->d:Lads_mobile_sdk/lw0;

    return-object p0
.end method

.method public final d(Lvx;)Ljava/lang/Object;
    .registers 2

    check-cast p1, Lwx;

    invoke-static {p0, p1}, Lads_mobile_sdk/e3;->a(Lads_mobile_sdk/e3;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final h(Lvx;)Ljava/lang/Object;
    .registers 6

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/sr;->f:Lads_mobile_sdk/qr0;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sget-object v2, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    const-string v3, "gads:ad_id_init_from_signal_source_enabled"

    invoke-virtual {v0, v3, v1, v2}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_1e

    check-cast p1, Lwx;

    invoke-static {p0, p1}, Lads_mobile_sdk/sr;->c(Lads_mobile_sdk/sr;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :cond_1e
    new-instance p0, Lads_mobile_sdk/hv0;

    sget-object p1, Lrg2;->a:Lrg2;

    invoke-direct {p0, p1}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    return-object p0
.end method
