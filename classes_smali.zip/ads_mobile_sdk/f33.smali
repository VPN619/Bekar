.class public final Lads_mobile_sdk/f33;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lw02;


# static fields
.field public static final a:Lads_mobile_sdk/f33;

.field public static final b:Lads_mobile_sdk/u23;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lads_mobile_sdk/f33;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lads_mobile_sdk/f33;->a:Lads_mobile_sdk/f33;

    invoke-static {}, Lads_mobile_sdk/u23;->o()Lads_mobile_sdk/u23;

    move-result-object v0

    sput-object v0, Lads_mobile_sdk/f33;->b:Lads_mobile_sdk/u23;

    return-void
.end method


# virtual methods
.method public final getDefaultValue()Ljava/lang/Object;
    .registers 1

    sget-object p0, Lads_mobile_sdk/f33;->b:Lads_mobile_sdk/u23;

    return-object p0
.end method

.method public final readFrom(Ljava/io/FileInputStream;)Ljava/lang/Object;
    .registers 3

    .prologue
    :try_start_0
    invoke-static {p1}, Lads_mobile_sdk/u23;->a(Ljava/io/FileInputStream;)Lads_mobile_sdk/u23;

    move-result-object p0
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_4} :catch_5

    return-object p0

    :catch_5
    move-exception p0

    new-instance p1, Ljava/lang/StringBuilder;

    const-string v0, "Stored shared settings data has been corrupted: "

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 p1, 0x0

    invoke-static {p0, p1}, Lads_mobile_sdk/nw;->c(Ljava/lang/String;Ljava/lang/Exception;)V

    sget-object p0, Lads_mobile_sdk/f33;->b:Lads_mobile_sdk/u23;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object p0
.end method

.method public final writeTo(Ljava/lang/Object;Lo32;)V
    .registers 3

    check-cast p1, Lads_mobile_sdk/u23;

    invoke-virtual {p1, p2}, Lads_mobile_sdk/g;->a(Ljava/io/OutputStream;)V

    return-void
.end method
