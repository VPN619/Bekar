.class public final enum Lads_mobile_sdk/av2;
.super Ljava/lang/Enum;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final b:Lzx1;

.field public static final c:Ljava/util/LinkedHashMap;

.field public static final enum d:Lads_mobile_sdk/av2;

.field public static final enum e:Lads_mobile_sdk/av2;

.field public static final enum f:Lads_mobile_sdk/av2;

.field public static final enum g:Lads_mobile_sdk/av2;

.field public static final enum h:Lads_mobile_sdk/av2;

.field public static final enum i:Lads_mobile_sdk/av2;

.field public static final enum j:Lads_mobile_sdk/av2;

.field public static final enum k:Lads_mobile_sdk/av2;

.field public static final enum l:Lads_mobile_sdk/av2;

.field public static final synthetic m:[Lads_mobile_sdk/av2;

.field public static final synthetic n:Lza0;


# instance fields
.field public final a:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 13

    .prologue
    new-instance v0, Lads_mobile_sdk/av2;

    const-string v1, "UNKNOWN"

    const-string v2, ""

    const/4 v9, 0x0

    invoke-direct {v0, v9, v1, v2}, Lads_mobile_sdk/av2;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    sput-object v0, Lads_mobile_sdk/av2;->d:Lads_mobile_sdk/av2;

    new-instance v1, Lads_mobile_sdk/av2;

    const-string v2, "APP_OPEN"

    const-string v3, "app_open_ad"

    const/4 v4, 0x1

    invoke-direct {v1, v4, v2, v3}, Lads_mobile_sdk/av2;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    sput-object v1, Lads_mobile_sdk/av2;->e:Lads_mobile_sdk/av2;

    new-instance v2, Lads_mobile_sdk/av2;

    const-string v3, "BANNER"

    const-string v4, "banner"

    const/4 v5, 0x2

    invoke-direct {v2, v5, v3, v4}, Lads_mobile_sdk/av2;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    sput-object v2, Lads_mobile_sdk/av2;->f:Lads_mobile_sdk/av2;

    new-instance v3, Lads_mobile_sdk/av2;

    const-string v4, "ICON"

    const-string v5, "icon"

    const/4 v6, 0x3

    invoke-direct {v3, v6, v4, v5}, Lads_mobile_sdk/av2;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    sput-object v3, Lads_mobile_sdk/av2;->g:Lads_mobile_sdk/av2;

    new-instance v4, Lads_mobile_sdk/av2;

    const-string v5, "INTERSTITIAL"

    const-string v6, "interstitial"

    const/4 v7, 0x4

    invoke-direct {v4, v7, v5, v6}, Lads_mobile_sdk/av2;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    sput-object v4, Lads_mobile_sdk/av2;->h:Lads_mobile_sdk/av2;

    new-instance v5, Lads_mobile_sdk/av2;

    const-string v6, "NATIVE"

    const-string v7, "native"

    const/4 v8, 0x5

    invoke-direct {v5, v8, v6, v7}, Lads_mobile_sdk/av2;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    sput-object v5, Lads_mobile_sdk/av2;->i:Lads_mobile_sdk/av2;

    new-instance v6, Lads_mobile_sdk/av2;

    const-string v7, "REWARDED"

    const-string v8, "rewarded"

    const/4 v10, 0x6

    invoke-direct {v6, v10, v7, v8}, Lads_mobile_sdk/av2;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    sput-object v6, Lads_mobile_sdk/av2;->j:Lads_mobile_sdk/av2;

    new-instance v7, Lads_mobile_sdk/av2;

    const-string v8, "REWARDED_INTERSTITIAL"

    const-string v10, "rewarded_interstitial"

    const/4 v11, 0x7

    invoke-direct {v7, v11, v8, v10}, Lads_mobile_sdk/av2;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    sput-object v7, Lads_mobile_sdk/av2;->k:Lads_mobile_sdk/av2;

    new-instance v8, Lads_mobile_sdk/av2;

    const-string v10, "SWIPEABLE_INTERSTITIAL"

    const-string v11, "swipeable_interstitial"

    const/16 v12, 0x8

    invoke-direct {v8, v12, v10, v11}, Lads_mobile_sdk/av2;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    sput-object v8, Lads_mobile_sdk/av2;->l:Lads_mobile_sdk/av2;

    filled-new-array/range {v0 .. v8}, [Lads_mobile_sdk/av2;

    move-result-object v0

    sput-object v0, Lads_mobile_sdk/av2;->m:[Lads_mobile_sdk/av2;

    new-instance v1, Lza0;

    invoke-direct {v1, v0}, Lza0;-><init>([Ljava/lang/Enum;)V

    sput-object v1, Lads_mobile_sdk/av2;->n:Lza0;

    new-instance v0, Lzx1;

    const/16 v2, 0xc

    invoke-direct {v0, v2}, Lzx1;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/av2;->b:Lzx1;

    const/16 v0, 0xa

    invoke-static {v1, v0}, Lds;->Y(Ljava/lang/Iterable;I)I

    move-result v0

    invoke-static {v0}, Lb61;->Q(I)I

    move-result v0

    const/16 v2, 0x10

    if-ge v0, v2, :cond_92

    move v0, v2

    :cond_92
    new-instance v2, Ljava/util/LinkedHashMap;

    invoke-direct {v2, v0}, Ljava/util/LinkedHashMap;-><init>(I)V

    new-instance v0, Lk0;

    invoke-direct {v0, v9, v1}, Lk0;-><init>(ILjava/lang/Object;)V

    :goto_9c
    invoke-virtual {v0}, Lk0;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_af

    invoke-virtual {v0}, Lk0;->next()Ljava/lang/Object;

    move-result-object v1

    move-object v3, v1

    check-cast v3, Lads_mobile_sdk/av2;

    iget-object v3, v3, Lads_mobile_sdk/av2;->a:Ljava/lang/String;

    invoke-interface {v2, v3, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_9c

    :cond_af
    sput-object v2, Lads_mobile_sdk/av2;->c:Ljava/util/LinkedHashMap;

    return-void
.end method

.method public constructor <init>(ILjava/lang/String;Ljava/lang/String;)V
    .registers 4

    invoke-direct {p0, p2, p1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput-object p3, p0, Lads_mobile_sdk/av2;->a:Ljava/lang/String;

    return-void
.end method

.method public static values()[Lads_mobile_sdk/av2;
    .registers 1

    sget-object v0, Lads_mobile_sdk/av2;->m:[Lads_mobile_sdk/av2;

    invoke-virtual {v0}, [Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lads_mobile_sdk/av2;

    return-object v0
.end method
