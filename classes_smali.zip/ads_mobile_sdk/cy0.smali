.class public final Lads_mobile_sdk/cy0;
.super Landroid/webkit/WebView;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Lly;

.field public final b:Lvy;

.field public final c:Lvy;

.field public final d:Lads_mobile_sdk/q70;

.field public final e:Lads_mobile_sdk/ah3;

.field public final f:Lads_mobile_sdk/k8;

.field public final g:Lads_mobile_sdk/ko3;

.field public final h:Lads_mobile_sdk/y01;

.field public final i:Lads_mobile_sdk/qr0;

.field public final j:Lads_mobile_sdk/ek;

.field public final k:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public final l:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public final m:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public final n:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public o:Lads_mobile_sdk/mt0;

.field public volatile p:Lc73;

.field public volatile q:Lads_mobile_sdk/gp3;

.field public r:Lads_mobile_sdk/bz0;

.field public s:Lads_mobile_sdk/cr3;

.field public t:I

.field public u:Lrz2;

.field public final v:Lads_mobile_sdk/wf3;

.field public w:Lads_mobile_sdk/wf3;

.field public final x:Landroid/util/DisplayMetrics;

.field public y:Lg33;

.field public z:Lads_mobile_sdk/ry0;


# direct methods
.method public constructor <init>(Lly;Lvy;Lvy;Lads_mobile_sdk/q70;Lads_mobile_sdk/ah3;Lads_mobile_sdk/k8;Landroid/content/Context;Ljava/lang/String;Lads_mobile_sdk/cr3;Lads_mobile_sdk/ko3;Lads_mobile_sdk/y01;Lads_mobile_sdk/qr0;Lads_mobile_sdk/ek;)V
    .registers 14

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0, p7}, Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V

    iput-object p1, p0, Lads_mobile_sdk/cy0;->a:Lly;

    iput-object p2, p0, Lads_mobile_sdk/cy0;->b:Lvy;

    iput-object p3, p0, Lads_mobile_sdk/cy0;->c:Lvy;

    iput-object p4, p0, Lads_mobile_sdk/cy0;->d:Lads_mobile_sdk/q70;

    iput-object p5, p0, Lads_mobile_sdk/cy0;->e:Lads_mobile_sdk/ah3;

    iput-object p6, p0, Lads_mobile_sdk/cy0;->f:Lads_mobile_sdk/k8;

    iput-object p10, p0, Lads_mobile_sdk/cy0;->g:Lads_mobile_sdk/ko3;

    iput-object p11, p0, Lads_mobile_sdk/cy0;->h:Lads_mobile_sdk/y01;

    iput-object p12, p0, Lads_mobile_sdk/cy0;->i:Lads_mobile_sdk/qr0;

    iput-object p13, p0, Lads_mobile_sdk/cy0;->j:Lads_mobile_sdk/ek;

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 p2, 0x0

    invoke-direct {p1, p2}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object p1, p0, Lads_mobile_sdk/cy0;->k:Ljava/util/concurrent/atomic/AtomicBoolean;

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {p1, p2}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object p1, p0, Lads_mobile_sdk/cy0;->l:Ljava/util/concurrent/atomic/AtomicBoolean;

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {p1, p2}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object p1, p0, Lads_mobile_sdk/cy0;->m:Ljava/util/concurrent/atomic/AtomicBoolean;

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {p1, p2}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object p1, p0, Lads_mobile_sdk/cy0;->n:Ljava/util/concurrent/atomic/AtomicBoolean;

    iput-object p9, p0, Lads_mobile_sdk/cy0;->s:Lads_mobile_sdk/cr3;

    const/4 p1, -0x1

    iput p1, p0, Lads_mobile_sdk/cy0;->t:I

    new-instance p1, Lads_mobile_sdk/by0;

    const/4 p3, 0x0

    invoke-direct {p1, p0, p3, p2}, Lads_mobile_sdk/by0;-><init>(Lads_mobile_sdk/cy0;Lvx;I)V

    sget-object p4, Ly90;->a:Ly90;

    invoke-static {p4, p1}, Lw53;->Q(Lly;Lpk0;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lads_mobile_sdk/wf3;

    iput-object p1, p0, Lads_mobile_sdk/cy0;->v:Lads_mobile_sdk/wf3;

    invoke-static {p7}, Lt12;->h(Landroid/content/Context;)Landroid/util/DisplayMetrics;

    move-result-object p1

    iput-object p1, p0, Lads_mobile_sdk/cy0;->x:Landroid/util/DisplayMetrics;

    new-instance p1, Lads_mobile_sdk/by0;

    const/4 p4, 0x1

    invoke-direct {p1, p0, p3, p4}, Lads_mobile_sdk/by0;-><init>(Lads_mobile_sdk/cy0;Lvx;I)V

    invoke-static {p1}, Lw53;->R(Lpk0;)Ljava/lang/Object;

    invoke-virtual {p0}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object p1

    invoke-virtual {p1, p2}, Landroid/webkit/WebSettings;->setAllowContentAccess(Z)V

    invoke-virtual {p1, p2}, Landroid/webkit/WebSettings;->setAllowFileAccess(Z)V

    const/4 p5, 0x2

    invoke-virtual {p1, p5}, Landroid/webkit/WebSettings;->setMixedContentMode(I)V

    invoke-virtual {p1, p4}, Landroid/webkit/WebSettings;->setBuiltInZoomControls(Z)V

    invoke-virtual {p1, p2}, Landroid/webkit/WebSettings;->setDisplayZoomControls(Z)V

    const/16 p5, 0x64

    invoke-virtual {p1, p5}, Landroid/webkit/WebSettings;->setTextZoom(I)V

    invoke-virtual {p1, p4}, Landroid/webkit/WebSettings;->setSupportMultipleWindows(Z)V

    invoke-virtual {p1, p4}, Landroid/webkit/WebSettings;->setSupportZoom(Z)V

    invoke-virtual {p1, p4}, Landroid/webkit/WebSettings;->setDatabaseEnabled(Z)V

    invoke-virtual {p1, p4}, Landroid/webkit/WebSettings;->setDomStorageEnabled(Z)V

    invoke-virtual {p1, p4}, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V

    invoke-virtual {p1, p4}, Landroid/webkit/WebSettings;->setJavaScriptCanOpenWindowsAutomatically(Z)V

    invoke-virtual {p1, p2}, Landroid/webkit/WebSettings;->setMediaPlaybackRequiresUserGesture(Z)V

    invoke-virtual {p1, p8}, Landroid/webkit/WebSettings;->setUserAgentString(Ljava/lang/String;)V

    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sget-object p5, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    const-string p6, "gads:clear_webview_cache:enabled"

    invoke-virtual {p12, p6, p1, p5}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_c2

    invoke-virtual {p0, p4}, Landroid/webkit/WebView;->clearCache(Z)V

    :cond_c2
    invoke-virtual {p0, p2}, Landroid/view/View;->setWillNotDraw(Z)V

    invoke-virtual {p0, p2, p3}, Landroid/webkit/WebView;->setLayerType(ILandroid/graphics/Paint;)V

    const-string p1, "accessibility"

    invoke-virtual {p0, p1}, Landroid/webkit/WebView;->removeJavascriptInterface(Ljava/lang/String;)V

    const-string p1, "accessibilityTraversal"

    invoke-virtual {p0, p1}, Landroid/webkit/WebView;->removeJavascriptInterface(Ljava/lang/String;)V

    invoke-virtual {p0, p2}, Landroid/view/View;->setBackgroundColor(I)V

    const-string p1, "gads:webview_sound_effects:disabled"

    sget-object p3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {p12, p1, p3, p5}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_e8

    invoke-virtual {p0, p2}, Landroid/view/View;->setSoundEffectsEnabled(Z)V

    :cond_e8
    return-void
.end method

.method public static synthetic a(Lads_mobile_sdk/cy0;Ljava/lang/String;Ljava/lang/String;ZLwx;I)Ljava/lang/Object;
    .registers 13

    .prologue
    and-int/lit8 p5, p5, 0x2

    if-eqz p5, :cond_5

    const/4 p2, 0x0

    :cond_5
    move-object v2, p2

    const-string v3, "text/html"

    const-string v4, "UTF-8"

    move-object v0, p0

    move-object v1, p1

    move v5, p3

    move-object v6, p4

    invoke-virtual/range {v0 .. v6}, Lads_mobile_sdk/cy0;->a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method


# virtual methods
.method public final a(Lfx0;Ljava/lang/String;Lvx;)Ljava/lang/Object;
    .registers 6

    .prologue
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "(window.AFMA_ReceiveMessage || function() {})(\'"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p2, "\', "

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p1, ");"

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string p2, "Dispatching AFMA event: "

    invoke-virtual {p2, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v0, 0x0

    invoke-static {p2, v0}, Lads_mobile_sdk/nw;->b(Ljava/lang/String;Ljava/lang/Throwable;)V

    invoke-virtual {p0, p1, p3}, Lads_mobile_sdk/cy0;->a(Ljava/lang/String;Lvx;)Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lwy;->a:Lwy;

    if-ne p0, p1, :cond_2e

    return-object p0

    :cond_2e
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method

.method public final a(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZLwx;)Ljava/lang/Object;
    .registers 24

    .prologue
    move-object/from16 v1, p0

    move-object/from16 v0, p6

    instance-of v2, v0, Lads_mobile_sdk/rx0;

    if-eqz v2, :cond_18

    move-object v2, v0

    check-cast v2, Lads_mobile_sdk/rx0;

    iget v3, v2, Lads_mobile_sdk/rx0;->g:I

    const/high16 v4, -0x80000000

    and-int v5, v3, v4

    if-eqz v5, :cond_18

    sub-int/2addr v3, v4

    iput v3, v2, Lads_mobile_sdk/rx0;->g:I

    :goto_16
    move-object v7, v2

    goto :goto_1e

    :cond_18
    new-instance v2, Lads_mobile_sdk/rx0;

    invoke-direct {v2, v1, v0}, Lads_mobile_sdk/rx0;-><init>(Lads_mobile_sdk/cy0;Lwx;)V

    goto :goto_16

    :goto_1e
    iget-object v0, v7, Lads_mobile_sdk/rx0;->e:Ljava/lang/Object;

    iget v2, v7, Lads_mobile_sdk/rx0;->g:I

    const/16 v8, 0xf

    const/4 v9, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x2

    const/4 v13, 0x0

    const/4 v14, 0x1

    const/4 v15, 0x0

    sget-object v3, Lwy;->a:Lwy;

    if-eqz v2, :cond_ad

    if-eq v2, v14, :cond_8b

    if-eq v2, v12, :cond_68

    if-eq v2, v11, :cond_59

    if-eq v2, v10, :cond_4e

    if-eq v2, v9, :cond_3f

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {v0}, Lz6;->w(Ljava/lang/String;)V

    return-object v15

    :cond_3f
    iget-object v1, v7, Lads_mobile_sdk/rx0;->c:Ljava/lang/Object;

    check-cast v1, Ljava/lang/Throwable;

    iget-object v2, v7, Lads_mobile_sdk/rx0;->b:Ljava/io/Closeable;

    iget-object v3, v7, Lads_mobile_sdk/rx0;->a:Ljava/lang/Object;

    check-cast v3, Lads_mobile_sdk/rg3;

    :try_start_49
    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_4c
    .catchall {:try_start_49 .. :try_end_4c} :catchall_20d

    goto/16 :goto_212

    :cond_4e
    iget-object v1, v7, Lads_mobile_sdk/rx0;->c:Ljava/lang/Object;

    check-cast v1, Lb13;

    iget-object v2, v7, Lads_mobile_sdk/rx0;->b:Ljava/io/Closeable;

    iget-object v3, v7, Lads_mobile_sdk/rx0;->a:Ljava/lang/Object;

    check-cast v3, Lads_mobile_sdk/rg3;

    goto :goto_63

    :cond_59
    iget-object v1, v7, Lads_mobile_sdk/rx0;->c:Ljava/lang/Object;

    check-cast v1, Lb13;

    iget-object v2, v7, Lads_mobile_sdk/rx0;->b:Ljava/io/Closeable;

    iget-object v3, v7, Lads_mobile_sdk/rx0;->a:Ljava/lang/Object;

    check-cast v3, Lads_mobile_sdk/rg3;

    :goto_63
    :try_start_63
    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_66
    .catchall {:try_start_63 .. :try_end_66} :catchall_20d

    goto/16 :goto_1e1

    :cond_68
    iget-object v1, v7, Lads_mobile_sdk/rx0;->c:Ljava/lang/Object;

    check-cast v1, Ljava/io/Closeable;

    iget-object v2, v7, Lads_mobile_sdk/rx0;->b:Ljava/io/Closeable;

    check-cast v2, Lads_mobile_sdk/rg3;

    iget-object v4, v7, Lads_mobile_sdk/rx0;->a:Ljava/lang/Object;

    check-cast v4, Lads_mobile_sdk/cy0;

    :try_start_74
    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_77
    .catch Ljava/lang/Exception; {:try_start_74 .. :try_end_77} :catch_84
    .catchall {:try_start_74 .. :try_end_77} :catchall_7d

    move-object v11, v3

    move-object v3, v2

    move-object v2, v1

    move-object v1, v4

    goto/16 :goto_171

    :catchall_7d
    move-exception v0

    move-object v11, v3

    move-object v3, v2

    move-object v2, v1

    move-object v1, v4

    goto/16 :goto_1f0

    :catch_84
    move-exception v0

    move-object v11, v3

    move-object v3, v2

    move-object v2, v1

    move-object v1, v4

    goto/16 :goto_1b0

    :cond_8b
    iget-object v1, v7, Lads_mobile_sdk/rx0;->d:Lbt;

    iget-object v2, v7, Lads_mobile_sdk/rx0;->c:Ljava/lang/Object;

    check-cast v2, Ljava/io/Closeable;

    iget-object v4, v7, Lads_mobile_sdk/rx0;->b:Ljava/io/Closeable;

    check-cast v4, Lads_mobile_sdk/rg3;

    iget-object v5, v7, Lads_mobile_sdk/rx0;->a:Ljava/lang/Object;

    check-cast v5, Lads_mobile_sdk/cy0;

    :try_start_99
    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_9c
    .catch Ljava/lang/Exception; {:try_start_99 .. :try_end_9c} :catch_a7
    .catchall {:try_start_99 .. :try_end_9c} :catchall_a1

    move-object v10, v1

    move-object v11, v3

    move-object v1, v5

    goto/16 :goto_15e

    :catchall_a1
    move-exception v0

    move-object v11, v3

    move-object v3, v4

    move-object v1, v5

    goto/16 :goto_1f0

    :catch_a7
    move-exception v0

    move-object v11, v3

    move-object v3, v4

    move-object v1, v5

    goto/16 :goto_1b0

    :cond_ad
    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    if-eqz p5, :cond_f9

    iget-object v0, v1, Lads_mobile_sdk/cy0;->h:Lads_mobile_sdk/y01;

    iget-object v2, v0, Lads_mobile_sdk/y01;->a:Lads_mobile_sdk/qr0;

    const-string v4, "3.0"

    sget-object v5, Lads_mobile_sdk/fo;->a$23:Lads_mobile_sdk/fo;

    const-string v6, "gad:mraid:version"

    invoke-virtual {v2, v6, v4, v5}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    iget-object v0, v0, Lads_mobile_sdk/y01;->b:Ljava/lang/String;

    new-instance v4, Ljava/lang/StringBuilder;

    const-string v5, "\n      {\"version\": \""

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "\", \"sdk\": \"Google Mobile Ads\", \"sdkVersion\": \""

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "\"}\n    "

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lc72;->I0(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v2, "MRAID_ENV"

    invoke-static {v2, v0}, Lads_mobile_sdk/y01;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Luz;->G(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    move-object/from16 v2, p1

    invoke-static {v2, v0}, Lads_mobile_sdk/y01;->a(Ljava/lang/String;Ljava/util/List;)Ljava/lang/String;

    move-result-object v0

    move-object v4, v0

    goto :goto_fc

    :cond_f9
    move-object/from16 v2, p1

    move-object v4, v2

    :goto_fc
    sget-object v0, Lads_mobile_sdk/hh3;->a:Ljava/util/WeakHashMap;

    sget-object v0, Lba0;->a:Lba0;

    sget-object v2, Lads_mobile_sdk/fw0;->P:Lads_mobile_sdk/fw0;

    invoke-static {v2, v0, v14}, Lads_mobile_sdk/hh3;->a(Lads_mobile_sdk/fw0;Ljava/util/List;Z)Lads_mobile_sdk/rg3;

    move-result-object v2

    :try_start_106
    iget-object v0, v1, Lads_mobile_sdk/cy0;->k:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    if-eqz v0, :cond_113

    sget-object v1, Lads_mobile_sdk/kv0;->c:Lads_mobile_sdk/kv0;

    move-object v3, v2

    goto/16 :goto_1e1

    :cond_113
    new-instance v0, Lbt;

    invoke-direct {v0}, Lbt;-><init>()V

    invoke-virtual {v1}, Lads_mobile_sdk/cy0;->b()Lads_mobile_sdk/ry0;

    move-result-object v5

    iget-object v6, v5, Lads_mobile_sdk/ry0;->i:Lads_mobile_sdk/ji;

    sget-object v16, Lads_mobile_sdk/ry0;->w:[Liy0;

    aget-object v9, v16, v13

    invoke-virtual {v6, v5, v9}, Lads_mobile_sdk/ji;->getValue(Ljava/lang/Object;Liy0;)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lat;

    if-eqz v9, :cond_132

    invoke-interface {v9, v15}, Lfv0;->a(Ljava/util/concurrent/CancellationException;)V

    goto :goto_132

    :catchall_12e
    move-exception v0

    move-object v13, v2

    goto/16 :goto_213

    :cond_132
    :goto_132
    aget-object v9, v16, v13

    invoke-virtual {v6, v5, v9, v0}, Lads_mobile_sdk/ji;->setValue(Ljava/lang/Object;Liy0;Ljava/lang/Object;)V
    :try_end_137
    .catchall {:try_start_106 .. :try_end_137} :catchall_12e

    :try_start_137
    iget-object v9, v1, Lads_mobile_sdk/cy0;->a:Lly;

    move-object v5, v0

    new-instance v0, Lads_mobile_sdk/jx0;
    :try_end_13c
    .catch Ljava/lang/Exception; {:try_start_137 .. :try_end_13c} :catch_1ac
    .catchall {:try_start_137 .. :try_end_13c} :catchall_1a8

    move-object v6, v2

    const/4 v2, 0x0

    move-object v11, v3

    move-object v10, v5

    move-object v13, v6

    move-object/from16 v3, p2

    move-object/from16 v5, p3

    move-object/from16 v6, p4

    :try_start_147
    invoke-direct/range {v0 .. v6}, Lads_mobile_sdk/jx0;-><init>(Lads_mobile_sdk/cy0;Lvx;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    iput-object v1, v7, Lads_mobile_sdk/rx0;->a:Ljava/lang/Object;

    iput-object v13, v7, Lads_mobile_sdk/rx0;->b:Ljava/io/Closeable;

    iput-object v13, v7, Lads_mobile_sdk/rx0;->c:Ljava/lang/Object;

    iput-object v10, v7, Lads_mobile_sdk/rx0;->d:Lbt;

    iput v14, v7, Lads_mobile_sdk/rx0;->g:I

    invoke-static {v9, v0, v7}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object v0
    :try_end_158
    .catch Ljava/lang/Exception; {:try_start_147 .. :try_end_158} :catch_1a0
    .catchall {:try_start_147 .. :try_end_158} :catchall_19e

    if-ne v0, v11, :cond_15c

    goto/16 :goto_20c

    :cond_15c
    move-object v2, v13

    move-object v4, v2

    :goto_15e
    :try_start_15e
    iput-object v1, v7, Lads_mobile_sdk/rx0;->a:Ljava/lang/Object;

    iput-object v4, v7, Lads_mobile_sdk/rx0;->b:Ljava/io/Closeable;

    iput-object v2, v7, Lads_mobile_sdk/rx0;->c:Ljava/lang/Object;

    iput-object v15, v7, Lads_mobile_sdk/rx0;->d:Lbt;

    iput v12, v7, Lads_mobile_sdk/rx0;->g:I

    invoke-virtual {v10, v7}, Lnv0;->q(Lvx;)Ljava/lang/Object;

    move-result-object v0
    :try_end_16c
    .catch Ljava/lang/Exception; {:try_start_15e .. :try_end_16c} :catch_199
    .catchall {:try_start_15e .. :try_end_16c} :catchall_197

    if-ne v0, v11, :cond_170

    goto/16 :goto_20c

    :cond_170
    move-object v3, v4

    :goto_171
    :try_start_171
    check-cast v0, Lb13;
    :try_end_173
    .catch Ljava/lang/Exception; {:try_start_171 .. :try_end_173} :catch_195
    .catchall {:try_start_171 .. :try_end_173} :catchall_192

    :try_start_173
    iget-object v4, v1, Lads_mobile_sdk/cy0;->d:Lads_mobile_sdk/q70;

    if-eqz v4, :cond_18f

    sget-object v4, Lxf1;->b:Lxf1;

    new-instance v5, Lads_mobile_sdk/zj;

    invoke-direct {v5, v1, v15, v8}, Lads_mobile_sdk/zj;-><init>(Ljava/lang/Object;Lvx;I)V

    iput-object v3, v7, Lads_mobile_sdk/rx0;->a:Ljava/lang/Object;

    iput-object v2, v7, Lads_mobile_sdk/rx0;->b:Ljava/io/Closeable;

    iput-object v0, v7, Lads_mobile_sdk/rx0;->c:Ljava/lang/Object;

    const/4 v1, 0x3

    iput v1, v7, Lads_mobile_sdk/rx0;->g:I

    invoke-static {v4, v5, v7}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object v1
    :try_end_18b
    .catchall {:try_start_173 .. :try_end_18b} :catchall_20d

    if-ne v1, v11, :cond_18f

    goto/16 :goto_20c

    :cond_18f
    move-object v1, v0

    goto/16 :goto_1e1

    :catchall_192
    move-exception v0

    goto/16 :goto_1f0

    :catch_195
    move-exception v0

    goto :goto_1b0

    :catchall_197
    move-exception v0

    goto :goto_19c

    :catch_199
    move-exception v0

    move-object v3, v4

    goto :goto_1b0

    :goto_19c
    move-object v3, v4

    goto :goto_1f0

    :catchall_19e
    move-exception v0

    goto :goto_1a2

    :catch_1a0
    move-exception v0

    goto :goto_1a5

    :goto_1a2
    move-object v2, v13

    move-object v3, v2

    goto :goto_1f0

    :goto_1a5
    move-object v2, v13

    move-object v3, v2

    goto :goto_1b0

    :catchall_1a8
    move-exception v0

    move-object v13, v2

    move-object v11, v3

    goto :goto_1a2

    :catch_1ac
    move-exception v0

    move-object v13, v2

    move-object v11, v3

    goto :goto_1a5

    :goto_1b0
    :try_start_1b0
    iget-object v4, v1, Lads_mobile_sdk/cy0;->b:Lvy;

    new-instance v5, Lads_mobile_sdk/by0;

    const/4 v6, 0x4

    invoke-direct {v5, v1, v15, v6}, Lads_mobile_sdk/by0;-><init>(Lads_mobile_sdk/cy0;Lvx;I)V

    const/4 v6, 0x3

    invoke-static {v4, v15, v15, v5, v6}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    new-instance v4, Lads_mobile_sdk/bv0;

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-direct {v4, v6, v15, v0, v5}, Lads_mobile_sdk/bv0;-><init>(ILjava/lang/String;Ljava/lang/Throwable;I)V
    :try_end_1c3
    .catchall {:try_start_1b0 .. :try_end_1c3} :catchall_192

    :try_start_1c3
    iget-object v0, v1, Lads_mobile_sdk/cy0;->d:Lads_mobile_sdk/q70;

    if-eqz v0, :cond_1e0

    sget-object v0, Lxf1;->b:Lxf1;

    new-instance v5, Lads_mobile_sdk/zj;

    invoke-direct {v5, v1, v15, v8}, Lads_mobile_sdk/zj;-><init>(Ljava/lang/Object;Lvx;I)V

    iput-object v3, v7, Lads_mobile_sdk/rx0;->a:Ljava/lang/Object;

    iput-object v2, v7, Lads_mobile_sdk/rx0;->b:Ljava/io/Closeable;

    iput-object v4, v7, Lads_mobile_sdk/rx0;->c:Ljava/lang/Object;

    iput-object v15, v7, Lads_mobile_sdk/rx0;->d:Lbt;

    const/4 v6, 0x4

    iput v6, v7, Lads_mobile_sdk/rx0;->g:I

    invoke-static {v0, v5, v7}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object v0

    if-ne v0, v11, :cond_1e0

    goto :goto_20c

    :cond_1e0
    move-object v1, v4

    :goto_1e1
    instance-of v0, v1, Lads_mobile_sdk/av0;

    if-eqz v0, :cond_1ec

    move-object v0, v1

    check-cast v0, Lads_mobile_sdk/av0;

    const/4 v6, 0x0

    invoke-static {v0, v6}, Lads_mobile_sdk/xh3;->a(Lads_mobile_sdk/av0;Z)V
    :try_end_1ec
    .catchall {:try_start_1c3 .. :try_end_1ec} :catchall_20d

    :cond_1ec
    invoke-static {v2, v15}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object v1

    :goto_1f0
    :try_start_1f0
    iget-object v4, v1, Lads_mobile_sdk/cy0;->d:Lads_mobile_sdk/q70;

    if-eqz v4, :cond_211

    sget-object v4, Lxf1;->b:Lxf1;

    new-instance v5, Lads_mobile_sdk/zj;

    invoke-direct {v5, v1, v15, v8}, Lads_mobile_sdk/zj;-><init>(Ljava/lang/Object;Lvx;I)V

    iput-object v3, v7, Lads_mobile_sdk/rx0;->a:Ljava/lang/Object;

    iput-object v2, v7, Lads_mobile_sdk/rx0;->b:Ljava/io/Closeable;

    iput-object v0, v7, Lads_mobile_sdk/rx0;->c:Ljava/lang/Object;

    iput-object v15, v7, Lads_mobile_sdk/rx0;->d:Lbt;

    const/4 v1, 0x5

    iput v1, v7, Lads_mobile_sdk/rx0;->g:I

    invoke-static {v4, v5, v7}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v11, :cond_211

    :goto_20c
    return-object v11

    :catchall_20d
    move-exception v0

    move-object v13, v2

    move-object v2, v3

    goto :goto_214

    :cond_211
    move-object v1, v0

    :goto_212
    throw v1
    :try_end_213
    .catchall {:try_start_1f0 .. :try_end_213} :catchall_20d

    :goto_213
    move-object v2, v13

    :goto_214
    :try_start_214
    invoke-virtual {v2, v0}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v1, v0, Lox2;

    if-nez v1, :cond_244

    invoke-virtual {v2, v0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of v1, v0, Lza2;

    if-nez v1, :cond_23c

    instance-of v1, v0, Ljava/util/concurrent/CancellationException;

    if-nez v1, :cond_234

    instance-of v1, v0, Lads_mobile_sdk/mv0;

    if-eqz v1, :cond_22e

    throw v0

    :catchall_22b
    move-exception v0

    move-object v1, v0

    goto :goto_245

    :cond_22e
    new-instance v1, Lads_mobile_sdk/tu0;

    invoke-direct {v1, v0}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw v1

    :cond_234
    new-instance v1, Lads_mobile_sdk/ou0;

    check-cast v0, Ljava/util/concurrent/CancellationException;

    invoke-direct {v1, v0}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw v1

    :cond_23c
    new-instance v1, Lads_mobile_sdk/uw0;

    check-cast v0, Lza2;

    invoke-direct {v1, v0}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw v1

    :cond_244
    throw v0
    :try_end_245
    .catchall {:try_start_214 .. :try_end_245} :catchall_22b

    :goto_245
    :try_start_245
    throw v1
    :try_end_246
    .catchall {:try_start_245 .. :try_end_246} :catchall_246

    :catchall_246
    move-exception v0

    invoke-static {v13, v1}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0
.end method

.method public final a(Ljava/lang/String;Ljava/lang/String;Ljava/util/UUID;Lwx;)Ljava/lang/Object;
    .registers 21

    .prologue
    move-object/from16 v0, p0

    move-object/from16 v1, p4

    instance-of v2, v1, Lads_mobile_sdk/ix0;

    if-eqz v2, :cond_17

    move-object v2, v1

    check-cast v2, Lads_mobile_sdk/ix0;

    iget v3, v2, Lads_mobile_sdk/ix0;->h:I

    const/high16 v4, -0x80000000

    and-int v5, v3, v4

    if-eqz v5, :cond_17

    sub-int/2addr v3, v4

    iput v3, v2, Lads_mobile_sdk/ix0;->h:I

    goto :goto_1c

    :cond_17
    new-instance v2, Lads_mobile_sdk/ix0;

    invoke-direct {v2, v0, v1}, Lads_mobile_sdk/ix0;-><init>(Lads_mobile_sdk/cy0;Lwx;)V

    :goto_1c
    iget-object v1, v2, Lads_mobile_sdk/ix0;->f:Ljava/lang/Object;

    iget v3, v2, Lads_mobile_sdk/ix0;->h:I

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    sget-object v8, Lwy;->a:Lwy;

    if-eqz v3, :cond_5e

    if-eq v3, v6, :cond_49

    if-eq v3, v5, :cond_3e

    if-ne v3, v4, :cond_38

    iget-object v2, v2, Lads_mobile_sdk/ix0;->a:Lads_mobile_sdk/cy0;

    :try_start_30
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_33
    .catch Ljava/lang/Exception; {:try_start_30 .. :try_end_33} :catch_35

    goto/16 :goto_f4

    :catch_35
    move-exception v0

    goto/16 :goto_fe

    :cond_38
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {v0}, Lz6;->w(Ljava/lang/String;)V

    return-object v7

    :cond_3e
    iget-object v0, v2, Lads_mobile_sdk/ix0;->b:Ljava/lang/Object;

    check-cast v0, Lat;

    iget-object v3, v2, Lads_mobile_sdk/ix0;->a:Lads_mobile_sdk/cy0;

    :try_start_44
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_47
    .catch Ljava/lang/Exception; {:try_start_44 .. :try_end_47} :catch_fa

    goto/16 :goto_e6

    :cond_49
    iget-object v0, v2, Lads_mobile_sdk/ix0;->e:Lbt;

    iget-object v3, v2, Lads_mobile_sdk/ix0;->d:Ljava/util/UUID;

    iget-object v9, v2, Lads_mobile_sdk/ix0;->c:Ljava/lang/String;

    iget-object v10, v2, Lads_mobile_sdk/ix0;->b:Ljava/lang/Object;

    check-cast v10, Ljava/lang/String;

    iget-object v11, v2, Lads_mobile_sdk/ix0;->a:Lads_mobile_sdk/cy0;

    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V

    move-object v12, v11

    move-object v11, v10

    move-object v10, v12

    move-object v12, v3

    move-object v13, v9

    goto :goto_9a

    :cond_5e
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object v1, v0, Lads_mobile_sdk/cy0;->k:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v1

    if-eqz v1, :cond_6c

    sget-object v0, Lads_mobile_sdk/kv0;->c:Lads_mobile_sdk/kv0;

    return-object v0

    :cond_6c
    new-instance v1, Lbt;

    invoke-direct {v1}, Lbt;-><init>()V

    invoke-virtual {v0}, Lads_mobile_sdk/cy0;->c()Lg33;

    move-result-object v3

    invoke-virtual/range {p3 .. p3}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object v0, v2, Lads_mobile_sdk/ix0;->a:Lads_mobile_sdk/cy0;

    move-object/from16 v10, p1

    iput-object v10, v2, Lads_mobile_sdk/ix0;->b:Ljava/lang/Object;

    move-object/from16 v11, p2

    iput-object v11, v2, Lads_mobile_sdk/ix0;->c:Ljava/lang/String;

    move-object/from16 v12, p3

    iput-object v12, v2, Lads_mobile_sdk/ix0;->d:Ljava/util/UUID;

    iput-object v1, v2, Lads_mobile_sdk/ix0;->e:Lbt;

    iput v6, v2, Lads_mobile_sdk/ix0;->h:I

    invoke-interface {v3, v9, v1, v2}, Lg33;->a(Ljava/lang/String;Lbt;Lads_mobile_sdk/ix0;)Ljava/lang/Object;

    move-result-object v3

    if-ne v3, v8, :cond_95

    goto :goto_f2

    :cond_95
    move-object v13, v11

    move-object v11, v10

    move-object v10, v0

    move-object v0, v1

    move-object v1, v3

    :goto_9a
    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-nez v1, :cond_aa

    new-instance v0, Lads_mobile_sdk/ev0;

    const-string v1, "Unable to register result listener. Did you forget to register the result GMSG handler?"

    invoke-direct {v0, v1, v6}, Lads_mobile_sdk/ev0;-><init>(Ljava/lang/String;I)V

    return-object v0

    :cond_aa
    iget-object v1, v10, Lads_mobile_sdk/cy0;->i:Lads_mobile_sdk/qr0;

    iget-object v1, v1, Lads_mobile_sdk/qr0;->s:Ly23;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    sget-object v6, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    const-string v9, "gads:use_javascript_interface_for_result:enabled"

    invoke-virtual {v1, v9, v3, v6}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_c7

    const-string v1, "1"

    :goto_c5
    move-object v14, v1

    goto :goto_ca

    :cond_c7
    const-string v1, "0"

    goto :goto_c5

    :goto_ca
    :try_start_ca
    iget-object v1, v10, Lads_mobile_sdk/cy0;->a:Lly;

    new-instance v9, Lads_mobile_sdk/jx0;

    const/4 v15, 0x0

    invoke-direct/range {v9 .. v15}, Lads_mobile_sdk/jx0;-><init>(Lads_mobile_sdk/cy0;Ljava/lang/String;Ljava/util/UUID;Ljava/lang/String;Ljava/lang/String;Lvx;)V

    iput-object v10, v2, Lads_mobile_sdk/ix0;->a:Lads_mobile_sdk/cy0;

    iput-object v0, v2, Lads_mobile_sdk/ix0;->b:Ljava/lang/Object;

    iput-object v7, v2, Lads_mobile_sdk/ix0;->c:Ljava/lang/String;

    iput-object v7, v2, Lads_mobile_sdk/ix0;->d:Ljava/util/UUID;

    iput-object v7, v2, Lads_mobile_sdk/ix0;->e:Lbt;

    iput v5, v2, Lads_mobile_sdk/ix0;->h:I

    invoke-static {v1, v9, v2}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object v1
    :try_end_e2
    .catch Ljava/lang/Exception; {:try_start_ca .. :try_end_e2} :catch_fc

    if-ne v1, v8, :cond_e5

    goto :goto_f2

    :cond_e5
    move-object v3, v10

    :goto_e6
    :try_start_e6
    iput-object v3, v2, Lads_mobile_sdk/ix0;->a:Lads_mobile_sdk/cy0;

    iput-object v7, v2, Lads_mobile_sdk/ix0;->b:Ljava/lang/Object;

    iput v4, v2, Lads_mobile_sdk/ix0;->h:I

    invoke-interface {v0, v2}, Lu20;->b(Lwx;)Ljava/lang/Object;

    move-result-object v1
    :try_end_f0
    .catch Ljava/lang/Exception; {:try_start_e6 .. :try_end_f0} :catch_fa

    if-ne v1, v8, :cond_f3

    :goto_f2
    return-object v8

    :cond_f3
    move-object v2, v3

    :goto_f4
    :try_start_f4
    new-instance v0, Lads_mobile_sdk/hv0;

    invoke-direct {v0, v1}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V
    :try_end_f9
    .catch Ljava/lang/Exception; {:try_start_f4 .. :try_end_f9} :catch_35

    return-object v0

    :catch_fa
    move-exception v0

    goto :goto_ff

    :catch_fc
    move-exception v0

    move-object v2, v10

    :goto_fe
    move-object v3, v2

    :goto_ff
    instance-of v1, v0, Ljava/util/concurrent/CancellationException;

    if-nez v1, :cond_10d

    iget-object v1, v3, Lads_mobile_sdk/cy0;->b:Lvy;

    new-instance v2, Lads_mobile_sdk/by0;

    invoke-direct {v2, v3, v7, v5}, Lads_mobile_sdk/by0;-><init>(Lads_mobile_sdk/cy0;Lvx;I)V

    invoke-static {v1, v7, v7, v2, v4}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    :cond_10d
    new-instance v1, Lads_mobile_sdk/bv0;

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {v1, v3, v7, v0, v2}, Lads_mobile_sdk/bv0;-><init>(ILjava/lang/String;Ljava/lang/Throwable;I)V

    return-object v1
.end method

.method public final a(Ljava/lang/String;Lvx;)Ljava/lang/Object;
    .registers 7

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/cy0;->k:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    sget-object v1, Lrg2;->a:Lrg2;

    if-eqz v0, :cond_b

    goto :goto_2b

    :cond_b
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/Looper;->isCurrentThread()Z

    move-result v0

    const/4 v2, 0x0

    if-eqz v0, :cond_1a

    invoke-virtual {p0, p1, v2}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V

    return-object v1

    :cond_1a
    new-instance v0, Lads_mobile_sdk/px0;

    const/4 v3, 0x0

    invoke-direct {v0, p0, p1, v2, v3}, Lads_mobile_sdk/px0;-><init>(Lads_mobile_sdk/cy0;Ljava/lang/String;Lvx;I)V

    iget-object p0, p0, Lads_mobile_sdk/cy0;->a:Lly;

    invoke-static {p0, v0, p2}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lwy;->a:Lwy;

    if-ne p0, p1, :cond_2b

    return-object p0

    :cond_2b
    :goto_2b
    return-object v1
.end method

.method public final a(Lvx;)Ljava/lang/Object;
    .registers 8

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/mx0;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/mx0;

    iget v1, v0, Lads_mobile_sdk/mx0;->d:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/mx0;->d:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/mx0;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/mx0;-><init>(Lads_mobile_sdk/cy0;Lvx;)V

    :goto_18
    iget-object p1, v0, Lads_mobile_sdk/mx0;->b:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/mx0;->d:I

    const/4 v2, 0x0

    sget-object v3, Lrg2;->a:Lrg2;

    const/4 v4, 0x1

    if-eqz v1, :cond_32

    if-ne v1, v4, :cond_2c

    iget-object p0, v0, Lads_mobile_sdk/mx0;->a:Lads_mobile_sdk/cy0;

    :try_start_26
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_29
    .catchall {:try_start_26 .. :try_end_29} :catchall_2a

    return-object v3

    :catchall_2a
    move-exception p1

    goto :goto_69

    :cond_2c
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v2

    :cond_32
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/cy0;->k:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {p1, v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->getAndSet(Z)Z

    move-result p1

    if-eqz p1, :cond_3e

    goto :goto_68

    :cond_3e
    iget-object p1, p0, Lads_mobile_sdk/cy0;->l:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {p1, v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->getAndSet(Z)Z

    move-result p1

    if-nez p1, :cond_53

    iget-object p1, p0, Lads_mobile_sdk/cy0;->j:Lads_mobile_sdk/ek;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object p1, Lads_mobile_sdk/rl1;->a:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    move-result p1

    sput p1, Lads_mobile_sdk/rl1;->b:I

    :cond_53
    :try_start_53
    iget-object p1, p0, Lads_mobile_sdk/cy0;->a:Lly;

    new-instance v1, Lads_mobile_sdk/gy1;

    const/4 v5, 0x3

    invoke-direct {v1, p0, v2, v5}, Lads_mobile_sdk/gy1;-><init>(Lads_mobile_sdk/cy0;Lvx;I)V

    iput-object p0, v0, Lads_mobile_sdk/mx0;->a:Lads_mobile_sdk/cy0;

    iput v4, v0, Lads_mobile_sdk/mx0;->d:I

    invoke-static {p1, v1, v0}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object p0
    :try_end_63
    .catchall {:try_start_53 .. :try_end_63} :catchall_2a

    sget-object p1, Lwy;->a:Lwy;

    if-ne p0, p1, :cond_68

    return-object p1

    :cond_68
    :goto_68
    return-object v3

    :goto_69
    iget-object p0, p0, Lads_mobile_sdk/cy0;->e:Lads_mobile_sdk/ah3;

    const-string v0, "GmaWebView.destroySafe"

    invoke-virtual {p0, v0, p1}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-object v3
.end method

.method public final a(Lads_mobile_sdk/cr3;)V
    .registers 2

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    monitor-enter p0

    :try_start_4
    iput-object p1, p0, Lads_mobile_sdk/cy0;->s:Lads_mobile_sdk/cr3;
    :try_end_6
    .catchall {:try_start_4 .. :try_end_6} :catchall_b

    monitor-exit p0

    invoke-virtual {p0}, Landroid/view/View;->requestLayout()V

    return-void

    :catchall_b
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public final b()Lads_mobile_sdk/ry0;
    .registers 1

    .prologue
    iget-object p0, p0, Lads_mobile_sdk/cy0;->z:Lads_mobile_sdk/ry0;

    if-eqz p0, :cond_5

    return-object p0

    :cond_5
    const-string p0, "gmaWebViewClient"

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0
.end method

.method public final b(Lfx0;Ljava/lang/String;Lvx;)Ljava/lang/Object;
    .registers 5

    .prologue
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string p2, "("

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p1, ");"

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1, p3}, Lads_mobile_sdk/cy0;->a(Ljava/lang/String;Lvx;)Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lwy;->a:Lwy;

    if-ne p0, p1, :cond_1f

    return-object p0

    :cond_1f
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method

.method public final b(Ljava/lang/String;Ljava/lang/String;Ljava/util/UUID;Lwx;)Ljava/lang/Object;
    .registers 9

    .prologue
    instance-of v0, p4, Lads_mobile_sdk/lx0;

    if-eqz v0, :cond_13

    move-object v0, p4

    check-cast v0, Lads_mobile_sdk/lx0;

    iget v1, v0, Lads_mobile_sdk/lx0;->d:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/lx0;->d:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/lx0;

    invoke-direct {v0, p0, p4}, Lads_mobile_sdk/lx0;-><init>(Lads_mobile_sdk/cy0;Lwx;)V

    :goto_18
    iget-object p4, v0, Lads_mobile_sdk/lx0;->b:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/lx0;->d:I

    const/4 v2, 0x1

    if-eqz v1, :cond_2e

    if-ne v1, v2, :cond_27

    iget-object p1, v0, Lads_mobile_sdk/lx0;->a:Ljava/lang/String;

    invoke-static {p4}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_3e

    :cond_27
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0

    :cond_2e
    invoke-static {p4}, Lt12;->W(Ljava/lang/Object;)V

    iput-object p1, v0, Lads_mobile_sdk/lx0;->a:Ljava/lang/String;

    iput v2, v0, Lads_mobile_sdk/lx0;->d:I

    invoke-virtual {p0, p1, p2, p3, v0}, Lads_mobile_sdk/cy0;->a(Ljava/lang/String;Ljava/lang/String;Ljava/util/UUID;Lwx;)Ljava/lang/Object;

    move-result-object p4

    sget-object p0, Lwy;->a:Lwy;

    if-ne p4, p0, :cond_3e

    return-object p0

    :cond_3e
    :goto_3e
    check-cast p4, Lb13;

    instance-of p0, p4, Lads_mobile_sdk/av0;

    if-eqz p0, :cond_47

    check-cast p4, Lads_mobile_sdk/av0;

    return-object p4

    :cond_47
    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p4, Lads_mobile_sdk/hv0;

    iget-object p0, p4, Lads_mobile_sdk/hv0;->b:Ljava/lang/Object;

    check-cast p0, Lfx0;

    if-nez p0, :cond_5e

    new-instance p0, Lads_mobile_sdk/ev0;

    const-string p2, "Null response from "

    invoke-static {p2, p1}, Lrt2;->h(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1, v2}, Lads_mobile_sdk/ev0;-><init>(Ljava/lang/String;I)V

    return-object p0

    :cond_5e
    new-instance p1, Lads_mobile_sdk/hv0;

    invoke-direct {p1, p0}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    return-object p1
.end method

.method public final b(Ljava/lang/String;Lwx;)Ljava/lang/Object;
    .registers 19

    .prologue
    move-object/from16 v1, p0

    move-object/from16 v0, p2

    instance-of v2, v0, Lads_mobile_sdk/vx0;

    if-eqz v2, :cond_17

    move-object v2, v0

    check-cast v2, Lads_mobile_sdk/vx0;

    iget v3, v2, Lads_mobile_sdk/vx0;->g:I

    const/high16 v4, -0x80000000

    and-int v5, v3, v4

    if-eqz v5, :cond_17

    sub-int/2addr v3, v4

    iput v3, v2, Lads_mobile_sdk/vx0;->g:I

    goto :goto_1c

    :cond_17
    new-instance v2, Lads_mobile_sdk/vx0;

    invoke-direct {v2, v1, v0}, Lads_mobile_sdk/vx0;-><init>(Lads_mobile_sdk/cy0;Lwx;)V

    :goto_1c
    iget-object v0, v2, Lads_mobile_sdk/vx0;->e:Ljava/lang/Object;

    iget v3, v2, Lads_mobile_sdk/vx0;->g:I

    const/16 v4, 0xf

    const/4 v5, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x0

    sget-object v12, Lwy;->a:Lwy;

    if-eqz v3, :cond_a3

    if-eq v3, v10, :cond_85

    if-eq v3, v8, :cond_69

    if-eq v3, v7, :cond_5a

    if-eq v3, v6, :cond_4f

    if-eq v3, v5, :cond_3d

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {v0}, Lz6;->w(Ljava/lang/String;)V

    return-object v11

    :cond_3d
    iget-object v1, v2, Lads_mobile_sdk/vx0;->c:Ljava/lang/Object;

    check-cast v1, Ljava/lang/Throwable;

    iget-object v3, v2, Lads_mobile_sdk/vx0;->b:Ljava/io/Closeable;

    iget-object v2, v2, Lads_mobile_sdk/vx0;->a:Ljava/lang/Object;

    check-cast v2, Lads_mobile_sdk/rg3;

    :try_start_47
    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_4a
    .catchall {:try_start_47 .. :try_end_4a} :catchall_4c

    goto/16 :goto_1a8

    :catchall_4c
    move-exception v0

    goto/16 :goto_1a9

    :cond_4f
    iget-object v1, v2, Lads_mobile_sdk/vx0;->c:Ljava/lang/Object;

    check-cast v1, Lb13;

    iget-object v3, v2, Lads_mobile_sdk/vx0;->b:Ljava/io/Closeable;

    iget-object v2, v2, Lads_mobile_sdk/vx0;->a:Ljava/lang/Object;

    check-cast v2, Lads_mobile_sdk/rg3;

    goto :goto_64

    :cond_5a
    iget-object v1, v2, Lads_mobile_sdk/vx0;->c:Ljava/lang/Object;

    check-cast v1, Lb13;

    iget-object v3, v2, Lads_mobile_sdk/vx0;->b:Ljava/io/Closeable;

    iget-object v2, v2, Lads_mobile_sdk/vx0;->a:Ljava/lang/Object;

    check-cast v2, Lads_mobile_sdk/rg3;

    :goto_64
    :try_start_64
    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_67
    .catchall {:try_start_64 .. :try_end_67} :catchall_4c

    goto/16 :goto_173

    :cond_69
    iget-object v1, v2, Lads_mobile_sdk/vx0;->c:Ljava/lang/Object;

    check-cast v1, Ljava/io/Closeable;

    iget-object v3, v2, Lads_mobile_sdk/vx0;->b:Ljava/io/Closeable;

    check-cast v3, Lads_mobile_sdk/rg3;

    iget-object v8, v2, Lads_mobile_sdk/vx0;->a:Ljava/lang/Object;

    check-cast v8, Lads_mobile_sdk/cy0;

    :try_start_75
    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_78
    .catch Ljava/lang/Exception; {:try_start_75 .. :try_end_78} :catch_81
    .catchall {:try_start_75 .. :try_end_78} :catchall_7b

    move-object v13, v8

    goto/16 :goto_112

    :catchall_7b
    move-exception v0

    move-object v5, v1

    move-object v13, v8

    :goto_7e
    move-object v1, v0

    goto/16 :goto_186

    :catch_81
    move-exception v0

    move-object v13, v8

    goto/16 :goto_144

    :cond_85
    iget-object v1, v2, Lads_mobile_sdk/vx0;->d:Lbt;

    iget-object v3, v2, Lads_mobile_sdk/vx0;->c:Ljava/lang/Object;

    check-cast v3, Ljava/io/Closeable;

    iget-object v10, v2, Lads_mobile_sdk/vx0;->b:Ljava/io/Closeable;

    check-cast v10, Lads_mobile_sdk/rg3;

    iget-object v13, v2, Lads_mobile_sdk/vx0;->a:Ljava/lang/Object;

    check-cast v13, Lads_mobile_sdk/cy0;

    :try_start_93
    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_96
    .catch Ljava/lang/Exception; {:try_start_93 .. :try_end_96} :catch_9e
    .catchall {:try_start_93 .. :try_end_96} :catchall_98

    goto/16 :goto_fe

    :catchall_98
    move-exception v0

    move-object v1, v0

    move-object v5, v3

    move-object v3, v10

    goto/16 :goto_186

    :catch_9e
    move-exception v0

    move-object v1, v3

    move-object v3, v10

    goto/16 :goto_144

    :cond_a3
    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    sget-object v0, Lads_mobile_sdk/hh3;->a:Ljava/util/WeakHashMap;

    sget-object v0, Lba0;->a:Lba0;

    sget-object v3, Lads_mobile_sdk/fw0;->P:Lads_mobile_sdk/fw0;

    invoke-static {v3, v0, v10}, Lads_mobile_sdk/hh3;->a(Lads_mobile_sdk/fw0;Ljava/util/List;Z)Lads_mobile_sdk/rg3;

    move-result-object v3

    :try_start_b0
    iget-object v0, v1, Lads_mobile_sdk/cy0;->k:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    if-eqz v0, :cond_bd

    sget-object v0, Lads_mobile_sdk/kv0;->c:Lads_mobile_sdk/kv0;

    move-object v2, v3

    goto/16 :goto_174

    :cond_bd
    new-instance v0, Lbt;

    invoke-direct {v0}, Lbt;-><init>()V

    invoke-virtual {v1}, Lads_mobile_sdk/cy0;->b()Lads_mobile_sdk/ry0;

    move-result-object v13

    iget-object v14, v13, Lads_mobile_sdk/ry0;->i:Lads_mobile_sdk/ji;

    sget-object v15, Lads_mobile_sdk/ry0;->w:[Liy0;

    aget-object v5, v15, v9

    invoke-virtual {v14, v13, v5}, Lads_mobile_sdk/ji;->getValue(Ljava/lang/Object;Liy0;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lat;

    if-eqz v5, :cond_db

    invoke-interface {v5, v11}, Lfv0;->a(Ljava/util/concurrent/CancellationException;)V

    goto :goto_db

    :catchall_d8
    move-exception v0

    goto/16 :goto_1ac

    :cond_db
    :goto_db
    aget-object v5, v15, v9

    invoke-virtual {v14, v13, v5, v0}, Lads_mobile_sdk/ji;->setValue(Ljava/lang/Object;Liy0;Ljava/lang/Object;)V
    :try_end_e0
    .catchall {:try_start_b0 .. :try_end_e0} :catchall_d8

    :try_start_e0
    iget-object v5, v1, Lads_mobile_sdk/cy0;->a:Lly;

    new-instance v13, Lads_mobile_sdk/px0;

    move-object/from16 v14, p1

    invoke-direct {v13, v1, v14, v11, v10}, Lads_mobile_sdk/px0;-><init>(Lads_mobile_sdk/cy0;Ljava/lang/String;Lvx;I)V

    iput-object v1, v2, Lads_mobile_sdk/vx0;->a:Ljava/lang/Object;

    iput-object v3, v2, Lads_mobile_sdk/vx0;->b:Ljava/io/Closeable;

    iput-object v3, v2, Lads_mobile_sdk/vx0;->c:Ljava/lang/Object;

    iput-object v0, v2, Lads_mobile_sdk/vx0;->d:Lbt;

    iput v10, v2, Lads_mobile_sdk/vx0;->g:I

    invoke-static {v5, v13, v2}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object v5
    :try_end_f7
    .catch Ljava/lang/Exception; {:try_start_e0 .. :try_end_f7} :catch_13c
    .catchall {:try_start_e0 .. :try_end_f7} :catchall_13a

    if-ne v5, v12, :cond_fb

    goto/16 :goto_1a2

    :cond_fb
    move-object v13, v1

    move-object v10, v3

    move-object v1, v0

    :goto_fe
    :try_start_fe
    iput-object v13, v2, Lads_mobile_sdk/vx0;->a:Ljava/lang/Object;

    iput-object v10, v2, Lads_mobile_sdk/vx0;->b:Ljava/io/Closeable;

    iput-object v3, v2, Lads_mobile_sdk/vx0;->c:Ljava/lang/Object;

    iput-object v11, v2, Lads_mobile_sdk/vx0;->d:Lbt;

    iput v8, v2, Lads_mobile_sdk/vx0;->g:I

    invoke-virtual {v1, v2}, Lnv0;->q(Lvx;)Ljava/lang/Object;

    move-result-object v0
    :try_end_10c
    .catch Ljava/lang/Exception; {:try_start_fe .. :try_end_10c} :catch_9e
    .catchall {:try_start_fe .. :try_end_10c} :catchall_98

    if-ne v0, v12, :cond_110

    goto/16 :goto_1a2

    :cond_110
    move-object v1, v3

    move-object v3, v10

    :goto_112
    :try_start_112
    check-cast v0, Lb13;
    :try_end_114
    .catch Ljava/lang/Exception; {:try_start_112 .. :try_end_114} :catch_138
    .catchall {:try_start_112 .. :try_end_114} :catchall_136

    :try_start_114
    iget-object v5, v13, Lads_mobile_sdk/cy0;->d:Lads_mobile_sdk/q70;

    if-eqz v5, :cond_132

    sget-object v5, Lxf1;->b:Lxf1;

    new-instance v6, Lads_mobile_sdk/zj;

    invoke-direct {v6, v13, v11, v4}, Lads_mobile_sdk/zj;-><init>(Ljava/lang/Object;Lvx;I)V

    iput-object v3, v2, Lads_mobile_sdk/vx0;->a:Ljava/lang/Object;

    iput-object v1, v2, Lads_mobile_sdk/vx0;->b:Ljava/io/Closeable;

    iput-object v0, v2, Lads_mobile_sdk/vx0;->c:Ljava/lang/Object;

    iput v7, v2, Lads_mobile_sdk/vx0;->g:I

    invoke-static {v5, v6, v2}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object v2
    :try_end_12b
    .catchall {:try_start_114 .. :try_end_12b} :catchall_12f

    if-ne v2, v12, :cond_132

    goto/16 :goto_1a2

    :catchall_12f
    move-exception v0

    goto/16 :goto_1ad

    :cond_132
    move-object v2, v3

    move-object v3, v1

    move-object v1, v0

    goto :goto_173

    :catchall_136
    move-exception v0

    goto :goto_183

    :catch_138
    move-exception v0

    goto :goto_144

    :catchall_13a
    move-exception v0

    goto :goto_13e

    :catch_13c
    move-exception v0

    goto :goto_142

    :goto_13e
    move-object v13, v1

    move-object v5, v3

    goto/16 :goto_7e

    :goto_142
    move-object v13, v1

    move-object v1, v3

    :goto_144
    :try_start_144
    iget-object v5, v13, Lads_mobile_sdk/cy0;->b:Lvy;

    new-instance v8, Lads_mobile_sdk/by0;

    invoke-direct {v8, v13, v11, v6}, Lads_mobile_sdk/by0;-><init>(Lads_mobile_sdk/cy0;Lvx;I)V

    invoke-static {v5, v11, v11, v8, v7}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    new-instance v5, Lads_mobile_sdk/bv0;

    const/4 v7, 0x6

    invoke-direct {v5, v9, v11, v0, v7}, Lads_mobile_sdk/bv0;-><init>(ILjava/lang/String;Ljava/lang/Throwable;I)V
    :try_end_154
    .catchall {:try_start_144 .. :try_end_154} :catchall_136

    :try_start_154
    iget-object v0, v13, Lads_mobile_sdk/cy0;->d:Lads_mobile_sdk/q70;

    if-eqz v0, :cond_170

    sget-object v0, Lxf1;->b:Lxf1;

    new-instance v7, Lads_mobile_sdk/zj;

    invoke-direct {v7, v13, v11, v4}, Lads_mobile_sdk/zj;-><init>(Ljava/lang/Object;Lvx;I)V

    iput-object v3, v2, Lads_mobile_sdk/vx0;->a:Ljava/lang/Object;

    iput-object v1, v2, Lads_mobile_sdk/vx0;->b:Ljava/io/Closeable;

    iput-object v5, v2, Lads_mobile_sdk/vx0;->c:Ljava/lang/Object;

    iput-object v11, v2, Lads_mobile_sdk/vx0;->d:Lbt;

    iput v6, v2, Lads_mobile_sdk/vx0;->g:I

    invoke-static {v0, v7, v2}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object v0
    :try_end_16d
    .catchall {:try_start_154 .. :try_end_16d} :catchall_12f

    if-ne v0, v12, :cond_170

    goto :goto_1a2

    :cond_170
    move-object v2, v3

    move-object v3, v1

    move-object v1, v5

    :goto_173
    move-object v0, v1

    :goto_174
    :try_start_174
    nop

    instance-of v1, v0, Lads_mobile_sdk/av0;

    if-eqz v1, :cond_17f

    move-object v1, v0

    check-cast v1, Lads_mobile_sdk/av0;

    invoke-static {v1, v9}, Lads_mobile_sdk/xh3;->a(Lads_mobile_sdk/av0;Z)V
    :try_end_17f
    .catchall {:try_start_174 .. :try_end_17f} :catchall_4c

    :cond_17f
    invoke-static {v3, v11}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object v0

    :goto_183
    move-object v5, v1

    goto/16 :goto_7e

    :goto_186
    :try_start_186
    iget-object v0, v13, Lads_mobile_sdk/cy0;->d:Lads_mobile_sdk/q70;

    if-eqz v0, :cond_1a6

    sget-object v0, Lxf1;->b:Lxf1;

    new-instance v6, Lads_mobile_sdk/zj;

    invoke-direct {v6, v13, v11, v4}, Lads_mobile_sdk/zj;-><init>(Ljava/lang/Object;Lvx;I)V

    iput-object v3, v2, Lads_mobile_sdk/vx0;->a:Ljava/lang/Object;

    iput-object v5, v2, Lads_mobile_sdk/vx0;->b:Ljava/io/Closeable;

    iput-object v1, v2, Lads_mobile_sdk/vx0;->c:Ljava/lang/Object;

    iput-object v11, v2, Lads_mobile_sdk/vx0;->d:Lbt;

    const/4 v4, 0x5

    iput v4, v2, Lads_mobile_sdk/vx0;->g:I

    invoke-static {v0, v6, v2}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object v0
    :try_end_1a0
    .catchall {:try_start_186 .. :try_end_1a0} :catchall_1a3

    if-ne v0, v12, :cond_1a6

    :goto_1a2
    return-object v12

    :catchall_1a3
    move-exception v0

    move-object v1, v5

    goto :goto_1ad

    :cond_1a6
    move-object v2, v3

    move-object v3, v5

    :goto_1a8
    :try_start_1a8
    throw v1
    :try_end_1a9
    .catchall {:try_start_1a8 .. :try_end_1a9} :catchall_4c

    :goto_1a9
    move-object v1, v3

    move-object v3, v2

    goto :goto_1ad

    :goto_1ac
    move-object v1, v3

    :goto_1ad
    :try_start_1ad
    invoke-virtual {v3, v0}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v2, v0, Lox2;

    if-nez v2, :cond_1dd

    invoke-virtual {v3, v0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of v2, v0, Lza2;

    if-nez v2, :cond_1d5

    instance-of v2, v0, Ljava/util/concurrent/CancellationException;

    if-nez v2, :cond_1cd

    instance-of v2, v0, Lads_mobile_sdk/mv0;

    if-eqz v2, :cond_1c7

    throw v0

    :catchall_1c4
    move-exception v0

    move-object v2, v0

    goto :goto_1de

    :cond_1c7
    new-instance v2, Lads_mobile_sdk/tu0;

    invoke-direct {v2, v0}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw v2

    :cond_1cd
    new-instance v2, Lads_mobile_sdk/ou0;

    check-cast v0, Ljava/util/concurrent/CancellationException;

    invoke-direct {v2, v0}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw v2

    :cond_1d5
    new-instance v2, Lads_mobile_sdk/uw0;

    check-cast v0, Lza2;

    invoke-direct {v2, v0}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw v2

    :cond_1dd
    throw v0
    :try_end_1de
    .catchall {:try_start_1ad .. :try_end_1de} :catchall_1c4

    :goto_1de
    :try_start_1de
    throw v2
    :try_end_1df
    .catchall {:try_start_1de .. :try_end_1df} :catchall_1df

    :catchall_1df
    move-exception v0

    invoke-static {v1, v2}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0
.end method

.method public final c()Lg33;
    .registers 1

    .prologue
    iget-object p0, p0, Lads_mobile_sdk/cy0;->y:Lg33;

    if-eqz p0, :cond_5

    return-object p0

    :cond_5
    const-string p0, "jsContext"

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0
.end method

.method public final c(Ljava/lang/String;Lwx;)Ljava/lang/Object;
    .registers 11

    .prologue
    instance-of v0, p2, Lads_mobile_sdk/ay0;

    if-eqz v0, :cond_14

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/ay0;

    iget v1, v0, Lads_mobile_sdk/ay0;->c:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_14

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/ay0;->c:I

    :goto_12
    move-object v6, v0

    goto :goto_1a

    :cond_14
    new-instance v0, Lads_mobile_sdk/ay0;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/ay0;-><init>(Lads_mobile_sdk/cy0;Lwx;)V

    goto :goto_12

    :goto_1a
    iget-object p2, v6, Lads_mobile_sdk/ay0;->a:Ljava/lang/Object;

    iget v0, v6, Lads_mobile_sdk/ay0;->c:I

    const/4 v1, 0x0

    sget-object v7, Lrg2;->a:Lrg2;

    const/4 v2, 0x1

    if-eqz v0, :cond_30

    if-ne v0, v2, :cond_2a

    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    return-object v7

    :cond_2a
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v1

    :cond_30
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p2, p0, Lads_mobile_sdk/cy0;->v:Lads_mobile_sdk/wf3;

    if-eqz p2, :cond_60

    iget-object p0, p0, Lads_mobile_sdk/cy0;->d:Lads_mobile_sdk/q70;

    if-eqz p0, :cond_60

    iput v2, v6, Lads_mobile_sdk/ay0;->c:I

    iget-object v3, p2, Lads_mobile_sdk/wf3;->a:Ljava/lang/String;

    sget-object p2, Lv60;->b:Lp80;

    iget-object p2, p0, Lads_mobile_sdk/q70;->c:Lx43;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v0

    sget-object p2, Ly60;->d:Ly60;

    invoke-static {v0, v1, p2}, Li10;->H0(JLy60;)J

    move-result-wide v4

    move-object v1, p0

    move-object v2, p1

    invoke-virtual/range {v1 .. v6}, Lads_mobile_sdk/q70;->a(Ljava/lang/String;Ljava/lang/String;JLwx;)Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lwy;->a:Lwy;

    if-ne p0, p1, :cond_5b

    goto :goto_5c

    :cond_5b
    move-object p0, v7

    :goto_5c
    if-ne p0, p1, :cond_5f

    return-object p1

    :cond_5f
    return-object v7

    :cond_60
    return-object v1
.end method

.method public final d()Lads_mobile_sdk/bz0;
    .registers 2

    .prologue
    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Lads_mobile_sdk/cy0;->r:Lads_mobile_sdk/bz0;
    :try_end_3
    .catchall {:try_start_1 .. :try_end_3} :catchall_5

    monitor-exit p0

    return-object v0

    :catchall_5
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public final destroy()V
    .registers 6

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/cy0;->l:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->getAndSet(Z)Z

    move-result v0

    if-nez v0, :cond_16

    iget-object v0, p0, Lads_mobile_sdk/cy0;->j:Lads_mobile_sdk/ek;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lads_mobile_sdk/rl1;->a:Ljava/util/concurrent/atomic/AtomicInteger;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->decrementAndGet()I

    move-result v0

    sput v0, Lads_mobile_sdk/rl1;->b:I

    :cond_16
    iget-object v0, p0, Lads_mobile_sdk/cy0;->k:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    iget-object v0, p0, Lads_mobile_sdk/cy0;->d:Lads_mobile_sdk/q70;

    if-eqz v0, :cond_37

    iget-object v1, v0, Lads_mobile_sdk/q70;->a:Lvy;

    new-instance v2, Lqd;

    const/16 v3, 0x16

    const/4 v4, 0x0

    invoke-direct {v2, v0, v4, v3}, Lqd;-><init>(Ljava/lang/Object;Lvx;I)V

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, La42;

    invoke-direct {v0, v2, v4}, La42;-><init>(Lpk0;Lvx;)V

    const/4 v2, 0x2

    sget-object v3, Ly90;->a:Ly90;

    invoke-static {v1, v3, v4, v0, v2}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    :cond_37
    invoke-super {p0}, Landroid/webkit/WebView;->destroy()V

    return-void
.end method

.method public final e()Lads_mobile_sdk/cr3;
    .registers 2

    .prologue
    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Lads_mobile_sdk/cy0;->s:Lads_mobile_sdk/cr3;
    :try_end_3
    .catchall {:try_start_1 .. :try_end_3} :catchall_5

    monitor-exit p0

    return-object v0

    :catchall_5
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public final onMeasure(II)V
    .registers 13

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/cy0;->k:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_d

    invoke-virtual {p0, v1, v1}, Landroid/view/View;->setMeasuredDimension(II)V

    return-void

    :cond_d
    invoke-virtual {p0}, Lads_mobile_sdk/cy0;->e()Lads_mobile_sdk/cr3;

    move-result-object v0

    invoke-virtual {p0}, Landroid/view/View;->isInEditMode()Z

    move-result v2

    if-nez v2, :cond_12a

    iget v2, v0, Lads_mobile_sdk/cr3;->a:I

    const/4 v3, 0x1

    if-ne v2, v3, :cond_1e

    goto/16 :goto_12a

    :cond_1e
    iget-object v2, p0, Lads_mobile_sdk/cy0;->n:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v2

    if-nez v2, :cond_12a

    iget v2, v0, Lads_mobile_sdk/cr3;->a:I

    const/4 v4, 0x4

    if-ne v2, v4, :cond_2d

    goto/16 :goto_12a

    :cond_2d
    const/4 v4, 0x5

    if-ne v2, v4, :cond_78

    invoke-virtual {p0}, Lads_mobile_sdk/cy0;->d()Lads_mobile_sdk/bz0;

    move-result-object v0

    const/4 v1, 0x0

    if-eqz v0, :cond_41

    iget-object v2, v0, Lads_mobile_sdk/bz0;->f:Ljava/lang/Object;

    monitor-enter v2

    :try_start_3a
    iget v0, v0, Lads_mobile_sdk/bz0;->h:F
    :try_end_3c
    .catchall {:try_start_3a .. :try_end_3c} :catchall_3e

    monitor-exit v2

    goto :goto_42

    :catchall_3e
    move-exception p0

    monitor-exit v2

    throw p0

    :cond_41
    move v0, v1

    :goto_42
    cmpg-float v1, v0, v1

    if-gtz v1, :cond_4a

    invoke-super {p0, p1, p2}, Landroid/webkit/WebView;->onMeasure(II)V

    return-void

    :cond_4a
    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result p1

    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result p2

    int-to-float v1, p2

    mul-float/2addr v1, v0

    float-to-int v1, v1

    int-to-float v2, p1

    div-float/2addr v2, v0

    float-to-int v0, v2

    if-nez p2, :cond_5f

    if-eqz v0, :cond_5f

    move v1, p1

    move p2, v0

    goto :goto_6c

    :cond_5f
    if-nez p1, :cond_66

    if-eqz v1, :cond_66

    move v0, p2

    move p1, v1

    goto :goto_6c

    :cond_66
    move v9, v1

    move v1, p1

    move p1, v9

    move v9, v0

    move v0, p2

    move p2, v9

    :goto_6c
    invoke-static {p1, v1}, Ljava/lang/Math;->min(II)I

    move-result p1

    invoke-static {p2, v0}, Ljava/lang/Math;->min(II)I

    move-result p2

    invoke-virtual {p0, p1, p2}, Landroid/view/View;->setMeasuredDimension(II)V

    return-void

    :cond_78
    iget-boolean v2, v0, Lads_mobile_sdk/cr3;->d:Z

    const/4 v5, 0x0

    if-eqz v2, :cond_a5

    iget-object v0, p0, Lads_mobile_sdk/cy0;->c:Lvy;

    new-instance v1, Lads_mobile_sdk/by0;

    invoke-direct {v1, p0, v5, v4}, Lads_mobile_sdk/by0;-><init>(Lads_mobile_sdk/cy0;Lvx;I)V

    invoke-static {v0, v1}, Lads_mobile_sdk/xh3;->a(Lvy;Lpk0;)Lx52;

    monitor-enter p0

    :try_start_88
    iget v0, p0, Lads_mobile_sdk/cy0;->t:I
    :try_end_8a
    .catchall {:try_start_88 .. :try_end_8a} :catchall_a2

    monitor-exit p0

    iget-object v1, p0, Lads_mobile_sdk/cy0;->x:Landroid/util/DisplayMetrics;

    iget v1, v1, Landroid/util/DisplayMetrics;->density:F

    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result p1

    const/4 v2, -0x1

    if-ne v0, v2, :cond_9b

    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result p2

    goto :goto_9e

    :cond_9b
    int-to-float p2, v0

    mul-float/2addr p2, v1

    float-to-int p2, p2

    :goto_9e
    invoke-virtual {p0, p1, p2}, Landroid/view/View;->setMeasuredDimension(II)V

    return-void

    :catchall_a2
    move-exception p1

    monitor-exit p0

    throw p1

    :cond_a5
    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v2

    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result p1

    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getMode(I)I

    move-result v4

    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getSize(I)I

    move-result p2

    const v6, 0x7fffffff

    const/high16 v7, 0x40000000  # 2.0f

    const/high16 v8, -0x80000000

    if-eq v2, v8, :cond_c2

    if-eq v2, v7, :cond_c2

    move v2, v6

    goto :goto_c3

    :cond_c2
    move v2, p1

    :goto_c3
    if-eq v4, v8, :cond_c8

    if-eq v4, v7, :cond_c8

    goto :goto_c9

    :cond_c8
    move v6, p2

    :goto_c9
    iget v4, v0, Lads_mobile_sdk/cr3;->b:I

    if-gt v4, v2, :cond_d1

    iget v2, v0, Lads_mobile_sdk/cr3;->c:I

    if-le v2, v6, :cond_117

    :cond_d1
    iget-object v2, p0, Lads_mobile_sdk/cy0;->x:Landroid/util/DisplayMetrics;

    iget v2, v2, Landroid/util/DisplayMetrics;->density:F

    int-to-float p1, p1

    div-float/2addr p1, v2

    float-to-int p1, p1

    int-to-float p2, p2

    div-float/2addr p2, v2

    float-to-int p2, p2

    int-to-float v4, v4

    div-float/2addr v4, v2

    float-to-int v4, v4

    iget v6, v0, Lads_mobile_sdk/cr3;->c:I

    int-to-float v6, v6

    div-float/2addr v6, v2

    float-to-int v2, v6

    const-string v6, "Not enough space to show the full ad. Need "

    const-string v7, "x"

    const-string v8, " dp, but only have "

    invoke-static {v4, v2, v6, v7, v8}, Lrt2;->l(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, "x"

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, " dp."

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1, v5}, Lads_mobile_sdk/nw;->c(Ljava/lang/String;Ljava/lang/Exception;)V

    iget-object p2, p0, Lads_mobile_sdk/cy0;->m:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {p2, v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->getAndSet(Z)Z

    move-result p2

    if-nez p2, :cond_117

    iget-object p2, p0, Lads_mobile_sdk/cy0;->c:Lvy;

    new-instance v2, Lads_mobile_sdk/px0;

    const/4 v3, 0x2

    invoke-direct {v2, p0, p1, v5, v3}, Lads_mobile_sdk/px0;-><init>(Lads_mobile_sdk/cy0;Ljava/lang/String;Lvx;I)V

    invoke-static {p2, v2}, Lads_mobile_sdk/xh3;->a(Lvy;Lpk0;)Lx52;

    :cond_117
    invoke-virtual {p0}, Landroid/view/View;->getVisibility()I

    move-result p1

    const/16 p2, 0x8

    if-eq p1, p2, :cond_122

    invoke-virtual {p0, v1}, Landroid/view/View;->setVisibility(I)V

    :cond_122
    iget p1, v0, Lads_mobile_sdk/cr3;->b:I

    iget p2, v0, Lads_mobile_sdk/cr3;->c:I

    invoke-virtual {p0, p1, p2}, Landroid/view/View;->setMeasuredDimension(II)V

    return-void

    :cond_12a
    :goto_12a
    invoke-super {p0, p1, p2}, Landroid/webkit/WebView;->onMeasure(II)V

    return-void
.end method

.method public final onPause()V
    .registers 2

    .prologue
    invoke-super {p0}, Landroid/webkit/WebView;->onPause()V

    iget-object v0, p0, Lads_mobile_sdk/cy0;->g:Lads_mobile_sdk/ko3;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_8
    const-string v0, "MUTE_AUDIO"

    invoke-static {v0}, Lyn2;->b(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_14

    const/4 v0, 0x1

    invoke-static {p0, v0}, Landroidx/webkit/WebViewCompat;->setAudioMuted(Landroid/webkit/WebView;Z)V
    :try_end_14
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_14} :catch_14

    :catch_14
    :cond_14
    return-void
.end method

.method public final onResume()V
    .registers 2

    .prologue
    invoke-super {p0}, Landroid/webkit/WebView;->onResume()V

    iget-object v0, p0, Lads_mobile_sdk/cy0;->g:Lads_mobile_sdk/ko3;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_8
    const-string v0, "MUTE_AUDIO"

    invoke-static {v0}, Lyn2;->b(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_14

    const/4 v0, 0x0

    invoke-static {p0, v0}, Landroidx/webkit/WebViewCompat;->setAudioMuted(Landroid/webkit/WebView;Z)V
    :try_end_14
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_14} :catch_14

    :catch_14
    :cond_14
    return-void
.end method

.method public final onTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 4

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Lads_mobile_sdk/cy0;->u:Lrz2;

    const/4 v1, 0x0

    if-eqz v0, :cond_11

    iget-object v0, v0, Lrz2;->a:Ljava/lang/Object;

    check-cast v0, Lads_mobile_sdk/ew1;

    invoke-virtual {v0, v1, p1}, Lads_mobile_sdk/ew1;->onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z

    sget-object v1, Lrg2;->a:Lrg2;

    :cond_11
    if-nez v1, :cond_3e

    iget-object v0, p0, Lads_mobile_sdk/cy0;->f:Lads_mobile_sdk/k8;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Lads_mobile_sdk/k8;->b()Lads_mobile_sdk/e7;

    move-result-object v0

    iget-object v0, v0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    check-cast v0, Lads_mobile_sdk/h7;

    iget-object v0, v0, Lads_mobile_sdk/h7;->b:Lads_mobile_sdk/u83;

    iget-object v1, v0, Lads_mobile_sdk/u83;->f:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lc23;

    if-nez v1, :cond_34

    iget-object v0, v0, Lads_mobile_sdk/u83;->e:Lads_mobile_sdk/th3;

    sget-object v1, Lads_mobile_sdk/fl0;->j:Lads_mobile_sdk/fl0;

    invoke-virtual {v0, v1}, Lads_mobile_sdk/th3;->b(Lads_mobile_sdk/fl0;)V

    goto :goto_37

    :cond_34
    invoke-interface {v1, p1}, Lc23;->a(Landroid/view/MotionEvent;)V

    :goto_37
    iget-object v0, p0, Lads_mobile_sdk/cy0;->q:Lads_mobile_sdk/gp3;

    if-nez v0, :cond_3c

    goto :goto_3e

    :cond_3c
    iput-object p1, v0, Lads_mobile_sdk/gp3;->a:Landroid/view/MotionEvent;

    :cond_3e
    :goto_3e
    iget-object v0, p0, Lads_mobile_sdk/cy0;->k:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    if-eqz v0, :cond_48

    const/4 p0, 0x0

    return p0

    :cond_48
    invoke-super {p0, p1}, Landroid/webkit/WebView;->onTouchEvent(Landroid/view/MotionEvent;)Z

    move-result p0

    return p0
.end method
