.class public final Lads_mobile_sdk/c60;
.super Lads_mobile_sdk/ku0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field private static final DEFAULT_INSTANCE:Lads_mobile_sdk/c60;

.field public static final c:I = 0x1

.field public static final d:I = 0x2

.field public static final e:I = 0x3

.field public static final f:I = 0x4

.field public static final g:I = 0x5

.field public static final h:I = 0x6

.field public static final i:I = 0x7

.field public static final j:I = 0x8

.field public static final k:I = 0x9


# instance fields
.field private adResourceType_:I

.field private bitField0_:I

.field private childIds_:Ls43;

.field private id_:I

.field private matchedBlacklist_:Lw63;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lw63;"
        }
    .end annotation
.end field

.field private memoizedIsInitialized:B

.field private parentId_:I

.field private request_:Lads_mobile_sdk/e50;

.field private response_:Lads_mobile_sdk/i50;

.field private tagName_:Ljava/lang/String;

.field private url_:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lads_mobile_sdk/c60;

    invoke-direct {v0}, Lads_mobile_sdk/c60;-><init>()V

    sput-object v0, Lads_mobile_sdk/c60;->DEFAULT_INSTANCE:Lads_mobile_sdk/c60;

    const-class v1, Lads_mobile_sdk/c60;

    invoke-static {v1, v0}, Lads_mobile_sdk/ku0;->a(Ljava/lang/Class;Lads_mobile_sdk/ku0;)V

    return-void
.end method

.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Lads_mobile_sdk/ku0;-><init>()V

    const/4 v0, 0x2

    iput-byte v0, p0, Lads_mobile_sdk/c60;->memoizedIsInitialized:B

    const-string v0, ""

    iput-object v0, p0, Lads_mobile_sdk/c60;->url_:Ljava/lang/String;

    sget-object v1, Lads_mobile_sdk/qb1;->e:Lads_mobile_sdk/qb1;

    iput-object v1, p0, Lads_mobile_sdk/c60;->childIds_:Ls43;

    iput-object v0, p0, Lads_mobile_sdk/c60;->tagName_:Ljava/lang/String;

    sget-object v0, Lads_mobile_sdk/am2;->e:Lads_mobile_sdk/am2;

    iput-object v0, p0, Lads_mobile_sdk/c60;->matchedBlacklist_:Lw63;

    return-void
.end method

.method public static bridge synthetic c(Lads_mobile_sdk/c60;)I
    .registers 1

    iget p0, p0, Lads_mobile_sdk/c60;->bitField0_:I

    return p0
.end method

.method public static bridge synthetic d(Lads_mobile_sdk/c60;I)V
    .registers 2

    iput p1, p0, Lads_mobile_sdk/c60;->adResourceType_:I

    return-void
.end method

.method public static bridge synthetic f(Lads_mobile_sdk/c60;I)V
    .registers 2

    iput p1, p0, Lads_mobile_sdk/c60;->bitField0_:I

    return-void
.end method

.method public static bridge synthetic g(Lads_mobile_sdk/c60;I)V
    .registers 2

    iput p1, p0, Lads_mobile_sdk/c60;->id_:I

    return-void
.end method

.method public static o()Ldu2;
    .registers 1

    sget-object v0, Lads_mobile_sdk/c60;->DEFAULT_INSTANCE:Lads_mobile_sdk/c60;

    invoke-virtual {v0}, Lads_mobile_sdk/ku0;->e()Lads_mobile_sdk/iu0;

    move-result-object v0

    check-cast v0, Ldu2;

    return-object v0
.end method


# virtual methods
.method public final a(ILads_mobile_sdk/ku0;)Ljava/lang/Object;
    .registers 14

    .prologue
    invoke-static {p1}, Lvr0;->a(I)I

    move-result p1

    const/4 v0, 0x0

    packed-switch p1, :pswitch_data_56

    throw v0

    :pswitch_9  #0x6
    const-class p0, Lads_mobile_sdk/c60;

    invoke-static {p0}, Lads_mobile_sdk/ku0;->b(Ljava/lang/Class;)Lads_mobile_sdk/ju0;

    move-result-object p0

    return-object p0

    :pswitch_10  #0x5
    sget-object p0, Lads_mobile_sdk/c60;->DEFAULT_INSTANCE:Lads_mobile_sdk/c60;

    return-object p0

    :pswitch_13  #0x4
    new-instance p0, Ldu2;

    sget-object p1, Lads_mobile_sdk/c60;->DEFAULT_INSTANCE:Lads_mobile_sdk/c60;

    invoke-direct {p0, p1}, Lads_mobile_sdk/iu0;-><init>(Lads_mobile_sdk/ku0;)V

    return-object p0

    :pswitch_1b  #0x3
    new-instance p0, Lads_mobile_sdk/c60;

    invoke-direct {p0}, Lads_mobile_sdk/c60;-><init>()V

    return-object p0

    :pswitch_21  #0x2
    sget-object v9, Lads_mobile_sdk/st;->a$11:Lads_mobile_sdk/st;

    const-string v10, "matchedBlacklist_"

    const-string v0, "bitField0_"

    const-string v1, "id_"

    const-string v2, "url_"

    const-string v3, "request_"

    const-string v4, "response_"

    const-string v5, "parentId_"

    const-string v6, "childIds_"

    const-string v7, "tagName_"

    const-string v8, "adResourceType_"

    filled-new-array/range {v0 .. v10}, [Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lads_mobile_sdk/c60;->DEFAULT_INSTANCE:Lads_mobile_sdk/c60;

    new-instance p2, Lads_mobile_sdk/zq2;

    const-string v0, "\u0001\t\u0000\u0001\u0001\t\t\u0000\u0002\u0003\u0001ᔄ\u0000\u0002ဈ\u0001\u0003ᐉ\u0002\u0004ᐉ\u0003\u0005င\u0004\u0006\u0016\u0007ဈ\u0005\b᠌\u0006\t\u001a"

    invoke-direct {p2, p1, v0, p0}, Lads_mobile_sdk/zq2;-><init>(Lads_mobile_sdk/ku0;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object p2

    :pswitch_45  #0x1
    if-nez p2, :cond_49

    const/4 p1, 0x0

    goto :goto_4a

    :cond_49
    const/4 p1, 0x1

    :goto_4a
    int-to-byte p1, p1

    iput-byte p1, p0, Lads_mobile_sdk/c60;->memoizedIsInitialized:B

    return-object v0

    :pswitch_4e  #0x0
    iget-byte p0, p0, Lads_mobile_sdk/c60;->memoizedIsInitialized:B

    invoke-static {p0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_56
    .packed-switch 0x0
        :pswitch_4e  #00000000
        :pswitch_45  #00000001
        :pswitch_21  #00000002
        :pswitch_1b  #00000003
        :pswitch_13  #00000004
        :pswitch_10  #00000005
        :pswitch_9  #00000006
    .end packed-switch
.end method

.method public final a(Lads_mobile_sdk/e50;)V
    .registers 2

    iput-object p1, p0, Lads_mobile_sdk/c60;->request_:Lads_mobile_sdk/e50;

    iget p1, p0, Lads_mobile_sdk/c60;->bitField0_:I

    or-int/lit8 p1, p1, 0x4

    iput p1, p0, Lads_mobile_sdk/c60;->bitField0_:I

    return-void
.end method

.method public final b(Ljava/lang/String;)V
    .registers 3

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget v0, p0, Lads_mobile_sdk/c60;->bitField0_:I

    or-int/lit8 v0, v0, 0x2

    iput v0, p0, Lads_mobile_sdk/c60;->bitField0_:I

    iput-object p1, p0, Lads_mobile_sdk/c60;->url_:Ljava/lang/String;

    return-void
.end method
