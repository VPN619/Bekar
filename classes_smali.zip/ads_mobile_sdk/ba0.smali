.class public final Lads_mobile_sdk/ba0;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Lads_mobile_sdk/sb0;

.field public b:Lads_mobile_sdk/xv;

.field public c:Lads_mobile_sdk/a2;

.field public d:Lads_mobile_sdk/n13;

.field public e:Ljava/lang/Long;

.field public f:Ljava/lang/Integer;

.field public g:Lli;

.field public h:Lads_mobile_sdk/av2;

.field public i:Ljava/lang/String;

.field public j:Lads_mobile_sdk/eq2;

.field public k:Lads_mobile_sdk/ih1;

.field public l:Ljava/lang/Boolean;

.field public m:Lads_mobile_sdk/j71;

.field public n:Lads_mobile_sdk/i8;

.field public o:Lc73;

.field public p:Lqh;

.field public q:Ljava/lang/Boolean;

.field public r:Lads_mobile_sdk/jm;

.field public s:Lia3;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/sb0;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/ba0;->a:Lads_mobile_sdk/sb0;

    return-void
.end method
