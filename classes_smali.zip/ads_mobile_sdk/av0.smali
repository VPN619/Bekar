.class public abstract Lads_mobile_sdk/av0;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lb13;


# instance fields
.field public final b:I


# direct methods
.method public constructor <init>(I)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lads_mobile_sdk/av0;->b:I

    return-void
.end method


# virtual methods
.method public a()I
    .registers 1

    iget p0, p0, Lads_mobile_sdk/av0;->b:I

    return p0
.end method

.method public b()Ljava/lang/Throwable;
    .registers 1

    const/4 p0, 0x0

    return-object p0
.end method
