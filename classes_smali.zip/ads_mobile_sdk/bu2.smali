.class public final Lads_mobile_sdk/bu2;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lnt2;


# instance fields
.field public final a:Ltv2;

.field public final b:Ltv2;

.field public final c:Lads_mobile_sdk/ah0;

.field public final d:Ltv2;

.field public final e:Ltv2;

.field public final f:Ltv2;

.field public final g:Ltv2;

.field public final h:Ltv2;

.field public final i:Lads_mobile_sdk/ob1;

.field public final synthetic j:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/ah0;Ltv2;Ltv2;Ltv2;Ltv2;Lads_mobile_sdk/ob1;Ltv2;Ltv2;Ltv2;)V
    .registers 11

    const/4 v0, 0x1

    iput v0, p0, Lads_mobile_sdk/bu2;->j:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/bu2;->c:Lads_mobile_sdk/ah0;

    iput-object p2, p0, Lads_mobile_sdk/bu2;->a:Ltv2;

    iput-object p3, p0, Lads_mobile_sdk/bu2;->b:Ltv2;

    iput-object p4, p0, Lads_mobile_sdk/bu2;->d:Ltv2;

    iput-object p5, p0, Lads_mobile_sdk/bu2;->e:Ltv2;

    iput-object p6, p0, Lads_mobile_sdk/bu2;->i:Lads_mobile_sdk/ob1;

    iput-object p7, p0, Lads_mobile_sdk/bu2;->f:Ltv2;

    iput-object p8, p0, Lads_mobile_sdk/bu2;->g:Ltv2;

    iput-object p9, p0, Lads_mobile_sdk/bu2;->h:Ltv2;

    return-void
.end method

.method public constructor <init>(Ltv2;Ltv2;Lads_mobile_sdk/ah0;Ltv2;Ltv2;Ltv2;Ltv2;Ltv2;Lads_mobile_sdk/ob1;)V
    .registers 11

    const/4 v0, 0x0

    iput v0, p0, Lads_mobile_sdk/bu2;->j:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/bu2;->a:Ltv2;

    iput-object p2, p0, Lads_mobile_sdk/bu2;->b:Ltv2;

    iput-object p3, p0, Lads_mobile_sdk/bu2;->c:Lads_mobile_sdk/ah0;

    iput-object p4, p0, Lads_mobile_sdk/bu2;->d:Ltv2;

    iput-object p5, p0, Lads_mobile_sdk/bu2;->e:Ltv2;

    iput-object p6, p0, Lads_mobile_sdk/bu2;->f:Ltv2;

    iput-object p7, p0, Lads_mobile_sdk/bu2;->g:Ltv2;

    iput-object p8, p0, Lads_mobile_sdk/bu2;->h:Ltv2;

    iput-object p9, p0, Lads_mobile_sdk/bu2;->i:Lads_mobile_sdk/ob1;

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 21

    .prologue
    move-object/from16 v0, p0

    iget v1, v0, Lads_mobile_sdk/bu2;->j:I

    iget-object v2, v0, Lads_mobile_sdk/bu2;->h:Ltv2;

    iget-object v3, v0, Lads_mobile_sdk/bu2;->g:Ltv2;

    iget-object v4, v0, Lads_mobile_sdk/bu2;->f:Ltv2;

    iget-object v5, v0, Lads_mobile_sdk/bu2;->i:Lads_mobile_sdk/ob1;

    iget-object v6, v0, Lads_mobile_sdk/bu2;->e:Ltv2;

    iget-object v7, v0, Lads_mobile_sdk/bu2;->d:Ltv2;

    iget-object v8, v0, Lads_mobile_sdk/bu2;->b:Ltv2;

    iget-object v9, v0, Lads_mobile_sdk/bu2;->a:Ltv2;

    iget-object v0, v0, Lads_mobile_sdk/bu2;->c:Lads_mobile_sdk/ah0;

    packed-switch v1, :pswitch_data_a8

    invoke-virtual {v0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v11, v0

    check-cast v11, Lvy;

    invoke-interface {v9}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v12, v0

    check-cast v12, Lly;

    invoke-interface {v8}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v13, v0

    check-cast v13, Lads_mobile_sdk/qr0;

    invoke-interface {v7}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v14, v0

    check-cast v14, Lads_mobile_sdk/qw;

    invoke-interface {v6}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v15, v0

    check-cast v15, Ljx2;

    iget-object v0, v5, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object/from16 v16, v0

    check-cast v16, Landroid/content/Context;

    invoke-interface {v4}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v17, v0

    check-cast v17, Lads_mobile_sdk/ux2;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v18, v0

    check-cast v18, Lads_mobile_sdk/i41;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v19, v0

    check-cast v19, Lads_mobile_sdk/mi0;

    new-instance v10, Lads_mobile_sdk/p30;

    invoke-direct/range {v10 .. v19}, Lads_mobile_sdk/p30;-><init>(Lvy;Lly;Lads_mobile_sdk/qr0;Lads_mobile_sdk/qw;Ljx2;Landroid/content/Context;Lads_mobile_sdk/ux2;Lads_mobile_sdk/i41;Lads_mobile_sdk/mi0;)V

    return-object v10

    :pswitch_60  #0x0
    invoke-interface {v9}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v1

    move-object v10, v1

    check-cast v10, Lads_mobile_sdk/qr0;

    invoke-interface {v8}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v1

    move-object v11, v1

    check-cast v11, Lads_mobile_sdk/ek;

    invoke-virtual {v0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v12, v0

    check-cast v12, Lads_mobile_sdk/ah3;

    invoke-interface {v7}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v13, v0

    check-cast v13, Lads_mobile_sdk/wp;

    invoke-interface {v6}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v14, v0

    check-cast v14, Ljava/util/Optional;

    invoke-interface {v4}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v15, v0

    check-cast v15, Ln63;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v16, v0

    check-cast v16, Lads_mobile_sdk/bk1;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v17

    iget-object v0, v5, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object/from16 v18, v0

    check-cast v18, Landroid/content/Context;

    new-instance v9, Lads_mobile_sdk/au2;

    invoke-direct/range {v9 .. v18}, Lads_mobile_sdk/au2;-><init>(Lads_mobile_sdk/qr0;Lads_mobile_sdk/ek;Lads_mobile_sdk/ah3;Lads_mobile_sdk/wp;Ljava/util/Optional;Ln63;Lads_mobile_sdk/bk1;ILandroid/content/Context;)V

    return-object v9

    :pswitch_data_a8
    .packed-switch 0x0
        :pswitch_60  #00000000
    .end packed-switch
.end method
