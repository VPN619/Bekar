.class public final Lads_mobile_sdk/ab3;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lz53;


# instance fields
.field public final a:Lads_mobile_sdk/yk2;

.field public final b:Ljava/util/concurrent/ExecutorService;

.field public final c:Lads_mobile_sdk/th3;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/yk2;Ljava/util/concurrent/ExecutorService;Lads_mobile_sdk/th3;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/ab3;->a:Lads_mobile_sdk/yk2;

    iput-object p2, p0, Lads_mobile_sdk/ab3;->b:Ljava/util/concurrent/ExecutorService;

    iput-object p3, p0, Lads_mobile_sdk/ab3;->c:Lads_mobile_sdk/th3;

    return-void
.end method


# virtual methods
.method public final a(Lads_mobile_sdk/jl2;[B)Ld31;
    .registers 6

    sget-object v0, Lads_mobile_sdk/fl0;->y2:Lads_mobile_sdk/fl0;

    new-instance v1, Li30;

    const/4 v2, 0x2

    invoke-direct {v1, p0, p1, p2, v2}, Li30;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    iget-object p1, p0, Lads_mobile_sdk/ab3;->b:Ljava/util/concurrent/ExecutorService;

    invoke-static {p1, v1}, Lpy2;->N(Ljava/util/concurrent/Executor;Ljava/util/concurrent/Callable;)Lpd2;

    move-result-object p1

    iget-object p0, p0, Lads_mobile_sdk/ab3;->c:Lads_mobile_sdk/th3;

    invoke-virtual {p0, v0, p1}, Lads_mobile_sdk/th3;->a(Lads_mobile_sdk/fl0;Leg0;)V

    return-object p1
.end method

.method public final a(Lads_mobile_sdk/jl2;[B[B)Ld31;
    .registers 6

    sget-object v0, Lads_mobile_sdk/fl0;->O2:Lads_mobile_sdk/fl0;

    new-instance v1, Lft2;

    invoke-direct {v1, p0, p1, p2, p3}, Lft2;-><init>(Lads_mobile_sdk/ab3;Lads_mobile_sdk/jl2;[B[B)V

    iget-object p1, p0, Lads_mobile_sdk/ab3;->b:Ljava/util/concurrent/ExecutorService;

    invoke-static {p1, v1}, Lpy2;->N(Ljava/util/concurrent/Executor;Ljava/util/concurrent/Callable;)Lpd2;

    move-result-object p1

    iget-object p0, p0, Lads_mobile_sdk/ab3;->c:Lads_mobile_sdk/th3;

    invoke-virtual {p0, v0, p1}, Lads_mobile_sdk/th3;->a(Lads_mobile_sdk/fl0;Leg0;)V

    return-object p1
.end method

.method public final a()Lpd2;
    .registers 4

    sget-object v0, Lads_mobile_sdk/fl0;->v2:Lads_mobile_sdk/fl0;

    new-instance v1, Let2;

    const/4 v2, 0x1

    invoke-direct {v1, p0, v2}, Let2;-><init>(Lads_mobile_sdk/ab3;I)V

    iget-object v2, p0, Lads_mobile_sdk/ab3;->b:Ljava/util/concurrent/ExecutorService;

    invoke-static {v2, v1}, Lpy2;->N(Ljava/util/concurrent/Executor;Ljava/util/concurrent/Callable;)Lpd2;

    move-result-object v1

    iget-object p0, p0, Lads_mobile_sdk/ab3;->c:Lads_mobile_sdk/th3;

    invoke-virtual {p0, v0, v1}, Lads_mobile_sdk/th3;->a(Lads_mobile_sdk/fl0;Leg0;)V

    return-object v1
.end method

.method public final b()Leq0;
    .registers 1

    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-static {p0}, Lpy2;->z(Ljava/lang/Object;)Leq0;

    move-result-object p0

    return-object p0
.end method
