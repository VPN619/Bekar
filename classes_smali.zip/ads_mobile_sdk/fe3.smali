.class public final Lads_mobile_sdk/fe3;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lz03;


# instance fields
.field public final a:Lvy;

.field public final b:Lads_mobile_sdk/z2;

.field public final c:Lads_mobile_sdk/ae3;

.field public final d:Lxy2;

.field public final e:Ljava/util/concurrent/atomic/AtomicBoolean;


# direct methods
.method public constructor <init>(Lvy;Lads_mobile_sdk/z2;Lads_mobile_sdk/ae3;Lxy2;)V
    .registers 5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/fe3;->a:Lvy;

    iput-object p2, p0, Lads_mobile_sdk/fe3;->b:Lads_mobile_sdk/z2;

    iput-object p3, p0, Lads_mobile_sdk/fe3;->c:Lads_mobile_sdk/ae3;

    iput-object p4, p0, Lads_mobile_sdk/fe3;->d:Lxy2;

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 p2, 0x0

    invoke-direct {p1, p2}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object p1, p0, Lads_mobile_sdk/fe3;->e:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-void
.end method


# virtual methods
.method public final a(Landroid/content/Context;ZZ)V
    .registers 7

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p1, p0, Lads_mobile_sdk/fe3;->e:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 p2, 0x1

    invoke-virtual {p1, p2}, Ljava/util/concurrent/atomic/AtomicBoolean;->getAndSet(Z)Z

    move-result p1

    const/4 p3, 0x6

    iget-object v0, p0, Lads_mobile_sdk/fe3;->a:Lvy;

    const/4 v1, 0x0

    if-eqz p1, :cond_24

    const-string p1, "This ad has already been shown."

    invoke-static {p1, v1}, Lads_mobile_sdk/nw;->a(Ljava/lang/String;Ljava/lang/Exception;)V

    new-instance p1, Lads_mobile_sdk/ce3;

    const/4 p2, 0x0

    invoke-direct {p1, p0, v1, p2}, Lads_mobile_sdk/ce3;-><init>(Lads_mobile_sdk/fe3;Lvx;I)V

    invoke-static {v0, p1}, Lads_mobile_sdk/xh3;->a(Lvy;Lpk0;)Lx52;

    const-string p0, "The ad has already been shown"

    invoke-static {p3, p0, v1}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    return-void

    :cond_24
    :try_start_24
    iget-object p1, p0, Lads_mobile_sdk/fe3;->d:Lxy2;

    invoke-interface {p1}, Lxy2;->a()V
    :try_end_29
    .catch Ljava/lang/Exception; {:try_start_24 .. :try_end_29} :catch_3d

    new-instance p1, Lc4;

    invoke-direct {p1, p0, v1, p3}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance p0, La42;

    invoke-direct {p0, p1, v1}, La42;-><init>(Lpk0;Lvx;)V

    const/4 p1, 0x2

    sget-object p2, Ly90;->a:Ly90;

    invoke-static {v0, p2, v1, p0, p1}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    return-void

    :catch_3d
    move-exception p1

    const-string p3, "Mediation Fullscreen Ad failed to show."

    const/4 v2, 0x4

    invoke-static {v2, p3, p1}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    new-instance p1, Lads_mobile_sdk/ce3;

    invoke-direct {p1, p0, v1, p2}, Lads_mobile_sdk/ce3;-><init>(Lads_mobile_sdk/fe3;Lvx;I)V

    invoke-static {v0, p1}, Lads_mobile_sdk/xh3;->a(Lvy;Lpk0;)Lx52;

    return-void
.end method
