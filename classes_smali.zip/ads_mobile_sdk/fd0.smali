.class public final Lads_mobile_sdk/fd0;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lm23;


# instance fields
.field public final a:Lads_mobile_sdk/sb0;

.field public b:Lli;

.field public c:Ljava/lang/Long;

.field public d:Lads_mobile_sdk/av2;

.field public e:Ljava/lang/Integer;

.field public f:Lads_mobile_sdk/a2;

.field public g:Lads_mobile_sdk/xv;

.field public h:Lads_mobile_sdk/n13;

.field public i:Ljava/lang/Boolean;

.field public j:Lads_mobile_sdk/eq2;

.field public k:Lads_mobile_sdk/ih1;

.field public l:Lads_mobile_sdk/dt2;

.field public m:Lads_mobile_sdk/s8;

.field public n:Lads_mobile_sdk/ve2;

.field public o:Lads_mobile_sdk/v31;

.field public p:Lqx2;

.field public q:Lads_mobile_sdk/it1;

.field public r:Lcom/google/android/libraries/ads/mobile/sdk/internal/webview/PerAdNativeJavscriptEngineJsContext;

.field public s:Lads_mobile_sdk/q70;

.field public t:Lfx0;

.field public u:Lxb1;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/sb0;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/fd0;->a:Lads_mobile_sdk/sb0;

    return-void
.end method


# virtual methods
.method public final a()Ljava/lang/Object;
    .registers 24

    move-object/from16 v0, p0

    iget-object v1, v0, Lads_mobile_sdk/fd0;->b:Lli;

    const-class v2, Lli;

    invoke-static {v1, v2}, Lhi1;->g(Ljava/lang/Object;Ljava/lang/Class;)V

    iget-object v1, v0, Lads_mobile_sdk/fd0;->c:Ljava/lang/Long;

    const-class v2, Ljava/lang/Long;

    invoke-static {v1, v2}, Lhi1;->g(Ljava/lang/Object;Ljava/lang/Class;)V

    iget-object v1, v0, Lads_mobile_sdk/fd0;->d:Lads_mobile_sdk/av2;

    const-class v2, Lads_mobile_sdk/av2;

    invoke-static {v1, v2}, Lhi1;->g(Ljava/lang/Object;Ljava/lang/Class;)V

    iget-object v1, v0, Lads_mobile_sdk/fd0;->e:Ljava/lang/Integer;

    const-class v2, Ljava/lang/Integer;

    invoke-static {v1, v2}, Lhi1;->g(Ljava/lang/Object;Ljava/lang/Class;)V

    iget-object v1, v0, Lads_mobile_sdk/fd0;->f:Lads_mobile_sdk/a2;

    const-class v2, Lads_mobile_sdk/a2;

    invoke-static {v1, v2}, Lhi1;->g(Ljava/lang/Object;Ljava/lang/Class;)V

    iget-object v1, v0, Lads_mobile_sdk/fd0;->g:Lads_mobile_sdk/xv;

    const-class v2, Lads_mobile_sdk/xv;

    invoke-static {v1, v2}, Lhi1;->g(Ljava/lang/Object;Ljava/lang/Class;)V

    iget-object v1, v0, Lads_mobile_sdk/fd0;->h:Lads_mobile_sdk/n13;

    const-class v2, Lads_mobile_sdk/n13;

    invoke-static {v1, v2}, Lhi1;->g(Ljava/lang/Object;Ljava/lang/Class;)V

    iget-object v1, v0, Lads_mobile_sdk/fd0;->i:Ljava/lang/Boolean;

    const-class v2, Ljava/lang/Boolean;

    invoke-static {v1, v2}, Lhi1;->g(Ljava/lang/Object;Ljava/lang/Class;)V

    iget-object v1, v0, Lads_mobile_sdk/fd0;->j:Lads_mobile_sdk/eq2;

    const-class v2, Lads_mobile_sdk/eq2;

    invoke-static {v1, v2}, Lhi1;->g(Ljava/lang/Object;Ljava/lang/Class;)V

    iget-object v1, v0, Lads_mobile_sdk/fd0;->k:Lads_mobile_sdk/ih1;

    const-class v2, Lads_mobile_sdk/ih1;

    invoke-static {v1, v2}, Lhi1;->g(Ljava/lang/Object;Ljava/lang/Class;)V

    iget-object v1, v0, Lads_mobile_sdk/fd0;->l:Lads_mobile_sdk/dt2;

    const-class v2, Lads_mobile_sdk/dt2;

    invoke-static {v1, v2}, Lhi1;->g(Ljava/lang/Object;Ljava/lang/Class;)V

    iget-object v1, v0, Lads_mobile_sdk/fd0;->m:Lads_mobile_sdk/s8;

    const-class v2, Lads_mobile_sdk/s8;

    invoke-static {v1, v2}, Lhi1;->g(Ljava/lang/Object;Ljava/lang/Class;)V

    iget-object v1, v0, Lads_mobile_sdk/fd0;->n:Lads_mobile_sdk/ve2;

    const-class v2, Lads_mobile_sdk/ve2;

    invoke-static {v1, v2}, Lhi1;->g(Ljava/lang/Object;Ljava/lang/Class;)V

    iget-object v1, v0, Lads_mobile_sdk/fd0;->o:Lads_mobile_sdk/v31;

    const-class v2, Lads_mobile_sdk/v31;

    invoke-static {v1, v2}, Lhi1;->g(Ljava/lang/Object;Ljava/lang/Class;)V

    iget-object v1, v0, Lads_mobile_sdk/fd0;->p:Lqx2;

    const-class v2, Lqx2;

    invoke-static {v1, v2}, Lhi1;->g(Ljava/lang/Object;Ljava/lang/Class;)V

    iget-object v1, v0, Lads_mobile_sdk/fd0;->q:Lads_mobile_sdk/it1;

    const-class v2, Lads_mobile_sdk/it1;

    invoke-static {v1, v2}, Lhi1;->g(Ljava/lang/Object;Ljava/lang/Class;)V

    iget-object v1, v0, Lads_mobile_sdk/fd0;->r:Lcom/google/android/libraries/ads/mobile/sdk/internal/webview/PerAdNativeJavscriptEngineJsContext;

    const-class v2, Lcom/google/android/libraries/ads/mobile/sdk/internal/webview/PerAdNativeJavscriptEngineJsContext;

    invoke-static {v1, v2}, Lhi1;->g(Ljava/lang/Object;Ljava/lang/Class;)V

    iget-object v1, v0, Lads_mobile_sdk/fd0;->s:Lads_mobile_sdk/q70;

    const-class v2, Lads_mobile_sdk/q70;

    invoke-static {v1, v2}, Lhi1;->g(Ljava/lang/Object;Ljava/lang/Class;)V

    iget-object v1, v0, Lads_mobile_sdk/fd0;->t:Lfx0;

    const-class v2, Lfx0;

    invoke-static {v1, v2}, Lhi1;->g(Ljava/lang/Object;Ljava/lang/Class;)V

    iget-object v1, v0, Lads_mobile_sdk/fd0;->u:Lxb1;

    const-class v2, Lxb1;

    invoke-static {v1, v2}, Lhi1;->g(Ljava/lang/Object;Ljava/lang/Class;)V

    new-instance v3, Lads_mobile_sdk/gd0;

    iget-object v5, v0, Lads_mobile_sdk/fd0;->b:Lli;

    iget-object v6, v0, Lads_mobile_sdk/fd0;->d:Lads_mobile_sdk/av2;

    iget-object v7, v0, Lads_mobile_sdk/fd0;->e:Ljava/lang/Integer;

    iget-object v8, v0, Lads_mobile_sdk/fd0;->f:Lads_mobile_sdk/a2;

    iget-object v9, v0, Lads_mobile_sdk/fd0;->g:Lads_mobile_sdk/xv;

    iget-object v10, v0, Lads_mobile_sdk/fd0;->h:Lads_mobile_sdk/n13;

    iget-object v11, v0, Lads_mobile_sdk/fd0;->j:Lads_mobile_sdk/eq2;

    iget-object v12, v0, Lads_mobile_sdk/fd0;->k:Lads_mobile_sdk/ih1;

    iget-object v13, v0, Lads_mobile_sdk/fd0;->l:Lads_mobile_sdk/dt2;

    iget-object v14, v0, Lads_mobile_sdk/fd0;->m:Lads_mobile_sdk/s8;

    iget-object v15, v0, Lads_mobile_sdk/fd0;->n:Lads_mobile_sdk/ve2;

    iget-object v1, v0, Lads_mobile_sdk/fd0;->o:Lads_mobile_sdk/v31;

    iget-object v2, v0, Lads_mobile_sdk/fd0;->p:Lqx2;

    iget-object v4, v0, Lads_mobile_sdk/fd0;->q:Lads_mobile_sdk/it1;

    move-object/from16 v16, v1

    iget-object v1, v0, Lads_mobile_sdk/fd0;->r:Lcom/google/android/libraries/ads/mobile/sdk/internal/webview/PerAdNativeJavscriptEngineJsContext;

    move-object/from16 v19, v1

    iget-object v1, v0, Lads_mobile_sdk/fd0;->s:Lads_mobile_sdk/q70;

    move-object/from16 v20, v1

    iget-object v1, v0, Lads_mobile_sdk/fd0;->t:Lfx0;

    move-object/from16 v21, v1

    iget-object v1, v0, Lads_mobile_sdk/fd0;->u:Lxb1;

    iget-object v0, v0, Lads_mobile_sdk/fd0;->a:Lads_mobile_sdk/sb0;

    move-object/from16 v22, v1

    move-object/from16 v17, v2

    move-object/from16 v18, v4

    move-object v4, v0

    invoke-direct/range {v3 .. v22}, Lads_mobile_sdk/gd0;-><init>(Lads_mobile_sdk/sb0;Lli;Lads_mobile_sdk/av2;Ljava/lang/Integer;Lads_mobile_sdk/a2;Lads_mobile_sdk/xv;Lads_mobile_sdk/n13;Lads_mobile_sdk/eq2;Lads_mobile_sdk/ih1;Lads_mobile_sdk/dt2;Lads_mobile_sdk/s8;Lads_mobile_sdk/ve2;Lads_mobile_sdk/v31;Lqx2;Lads_mobile_sdk/it1;Lcom/google/android/libraries/ads/mobile/sdk/internal/webview/PerAdNativeJavscriptEngineJsContext;Lads_mobile_sdk/q70;Lfx0;Lxb1;)V

    return-object v3
.end method

.method public final a(I)Ljava/lang/Object;
    .registers 2

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    iput-object p1, p0, Lads_mobile_sdk/fd0;->e:Ljava/lang/Integer;

    return-object p0
.end method

.method public final a(J)Ljava/lang/Object;
    .registers 3

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    iput-object p1, p0, Lads_mobile_sdk/fd0;->c:Ljava/lang/Long;

    return-object p0
.end method

.method public final a(Lads_mobile_sdk/a2;)Ljava/lang/Object;
    .registers 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Lads_mobile_sdk/fd0;->f:Lads_mobile_sdk/a2;

    return-object p0
.end method

.method public final a(Lads_mobile_sdk/av2;)Ljava/lang/Object;
    .registers 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Lads_mobile_sdk/fd0;->d:Lads_mobile_sdk/av2;

    return-object p0
.end method

.method public final a(Lads_mobile_sdk/dt2;)Ljava/lang/Object;
    .registers 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Lads_mobile_sdk/fd0;->l:Lads_mobile_sdk/dt2;

    return-object p0
.end method

.method public final a(Lads_mobile_sdk/eq2;)Ljava/lang/Object;
    .registers 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Lads_mobile_sdk/fd0;->j:Lads_mobile_sdk/eq2;

    return-object p0
.end method

.method public final a(Lads_mobile_sdk/ih1;)Ljava/lang/Object;
    .registers 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Lads_mobile_sdk/fd0;->k:Lads_mobile_sdk/ih1;

    return-object p0
.end method

.method public final a(Lads_mobile_sdk/n13;)Ljava/lang/Object;
    .registers 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Lads_mobile_sdk/fd0;->h:Lads_mobile_sdk/n13;

    return-object p0
.end method

.method public final a(Lads_mobile_sdk/s8;)Ljava/lang/Object;
    .registers 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Lads_mobile_sdk/fd0;->m:Lads_mobile_sdk/s8;

    return-object p0
.end method

.method public final a(Lads_mobile_sdk/v31;)Ljava/lang/Object;
    .registers 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Lads_mobile_sdk/fd0;->o:Lads_mobile_sdk/v31;

    return-object p0
.end method

.method public final a(Lads_mobile_sdk/ve2;)Ljava/lang/Object;
    .registers 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Lads_mobile_sdk/fd0;->n:Lads_mobile_sdk/ve2;

    return-object p0
.end method

.method public final a(Lads_mobile_sdk/xv;)Ljava/lang/Object;
    .registers 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Lads_mobile_sdk/fd0;->g:Lads_mobile_sdk/xv;

    return-object p0
.end method

.method public final a(Lli;)Ljava/lang/Object;
    .registers 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Lads_mobile_sdk/fd0;->b:Lli;

    return-object p0
.end method

.method public final a(Z)Ljava/lang/Object;
    .registers 2

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    iput-object p1, p0, Lads_mobile_sdk/fd0;->i:Ljava/lang/Boolean;

    return-object p0
.end method
