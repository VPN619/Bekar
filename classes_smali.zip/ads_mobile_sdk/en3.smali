.class public final Lads_mobile_sdk/en3;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lbw2;


# instance fields
.field public final a:Lads_mobile_sdk/ah3;

.field public final b:Lvy;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/ah3;Lvy;)V
    .registers 3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/en3;->a:Lads_mobile_sdk/ah3;

    iput-object p2, p0, Lads_mobile_sdk/en3;->b:Lvy;

    return-void
.end method


# virtual methods
.method public final a(Lads_mobile_sdk/cy0;Ljava/util/Map;Lvx;)Ljava/lang/Object;
    .registers 20

    .prologue
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v0, p2

    const/4 v3, 0x4

    :try_start_7
    invoke-virtual {v2}, Lads_mobile_sdk/cy0;->d()Lads_mobile_sdk/bz0;

    move-result-object v4

    const-string v5, "duration"

    invoke-interface {v0, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-eqz v5, :cond_b9

    invoke-static {v5}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    if-nez v4, :cond_51

    const-string v4, "1"

    const-string v5, "customControlsAllowed"

    invoke-interface {v0, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    const-string v4, "1"

    const-string v5, "clickToExpandAllowed"

    invoke-interface {v0, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v4, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    new-instance v4, Lads_mobile_sdk/bz0;

    iget-object v5, v1, Lads_mobile_sdk/en3;->b:Lvy;

    invoke-direct {v4, v5, v2}, Lads_mobile_sdk/bz0;-><init>(Lvy;Lads_mobile_sdk/cy0;)V

    monitor-enter p1
    :try_end_3a
    .catch Ljava/lang/NumberFormatException; {:try_start_7 .. :try_end_3a} :catch_4c

    :try_start_3a
    invoke-virtual {v2}, Lads_mobile_sdk/cy0;->d()Lads_mobile_sdk/bz0;

    move-result-object v5

    if-eqz v5, :cond_48

    const-string v5, "Attempt to create multiple GmaWebViewVideoController."

    invoke-static {v5, v7}, Lads_mobile_sdk/nw;->a(Ljava/lang/String;Ljava/lang/Exception;)V

    goto :goto_4a

    :catchall_46
    move-exception v0

    goto :goto_4f

    :cond_48
    iput-object v4, v2, Lads_mobile_sdk/cy0;->r:Lads_mobile_sdk/bz0;
    :try_end_4a
    .catchall {:try_start_3a .. :try_end_4a} :catchall_46

    :goto_4a
    :try_start_4a
    monitor-exit p1

    goto :goto_51

    :catch_4c
    move-exception v0

    goto/16 :goto_c1

    :goto_4f
    monitor-exit p1

    throw v0

    :cond_51
    :goto_51
    const-string v2, "1"

    const-string v5, "muted"

    invoke-interface {v0, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    const-string v5, "playbackState"

    invoke-interface {v0, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    if-eqz v5, :cond_b1

    invoke-static {v5}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v5

    const/4 v8, 0x5

    invoke-static {v8}, Lc33;->A(I)[I

    move-result-object v9

    array-length v10, v9

    const/4 v12, 0x0

    :goto_72
    const/4 v13, 0x1

    if-ge v12, v10, :cond_92

    aget v14, v9, v12

    if-eq v14, v13, :cond_8a

    const/4 v15, 0x2

    if-eq v14, v15, :cond_88

    const/4 v11, 0x3

    if-eq v14, v11, :cond_8b

    if-eq v14, v3, :cond_86

    if-ne v14, v8, :cond_85

    move v15, v8

    goto :goto_8b

    :cond_85
    throw v7

    :cond_86
    move v15, v11

    goto :goto_8b

    :cond_88
    move v15, v13

    goto :goto_8b

    :cond_8a
    const/4 v15, 0x0

    :cond_8b
    :goto_8b
    if-ne v15, v5, :cond_8f

    move v11, v14

    goto :goto_93

    :cond_8f
    add-int/lit8 v12, v12, 0x1

    goto :goto_72

    :cond_92
    const/4 v11, 0x0

    :goto_93
    if-nez v11, :cond_96

    goto :goto_97

    :cond_96
    move v13, v11

    :goto_97
    const-string v5, "aspectRatio"

    invoke-interface {v0, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    if-eqz v0, :cond_a9

    invoke-static {v0}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v0

    invoke-virtual {v4, v0, v13, v2}, Lads_mobile_sdk/bz0;->a(FIZ)V

    goto :goto_cd

    :cond_a9
    const-string v0, "Invalid videoMeta gmsg with no aspect ratio."

    invoke-static {v6, v0, v7}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    sget-object v0, Lrg2;->a:Lrg2;

    return-object v0

    :cond_b1
    const-string v0, "Invalid videoMeta gmsg with no playback state."

    invoke-static {v6, v0, v7}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    sget-object v0, Lrg2;->a:Lrg2;

    return-object v0

    :cond_b9
    const-string v0, "Invalid videoMeta gmsg with no duration."

    invoke-static {v6, v0, v7}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    sget-object v0, Lrg2;->a:Lrg2;
    :try_end_c0
    .catch Ljava/lang/NumberFormatException; {:try_start_4a .. :try_end_c0} :catch_4c

    return-object v0

    :goto_c1
    const-string v2, "Exception handling video metadata"

    invoke-static {v3, v2, v0}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    iget-object v1, v1, Lads_mobile_sdk/en3;->a:Lads_mobile_sdk/ah3;

    const-string v2, "VideoMetadataGmsgHandler.onGmsg"

    invoke-virtual {v1, v2, v0}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_cd
    sget-object v0, Lrg2;->a:Lrg2;

    return-object v0
.end method

.method public final b()I
    .registers 1

    const/16 p0, 0xa

    return p0
.end method

.method public final c()Z
    .registers 1

    const/4 p0, 0x1

    return p0
.end method
