.class public final Lads_mobile_sdk/da1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lt13;


# instance fields
.field public final a:Lads_mobile_sdk/d91;

.field public final synthetic b:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/d91;I)V
    .registers 3

    .prologue
    iput p2, p0, Lads_mobile_sdk/da1;->b:I

    packed-switch p2, :pswitch_data_20

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/da1;->a:Lads_mobile_sdk/d91;

    return-void

    :pswitch_e  #0x2
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/da1;->a:Lads_mobile_sdk/d91;

    return-void

    :pswitch_17  #0x1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/da1;->a:Lads_mobile_sdk/d91;

    return-void

    :pswitch_data_20
    .packed-switch 0x1
        :pswitch_17  #00000001
        :pswitch_e  #00000002
    .end packed-switch
.end method


# virtual methods
.method public final a(Lfx0;Lvx;)Ljava/lang/Object;
    .registers 7

    .prologue
    iget v0, p0, Lads_mobile_sdk/da1;->b:I

    const-string v1, ""

    sget-object v2, Lwy;->a:Lwy;

    iget-object p0, p0, Lads_mobile_sdk/da1;->a:Lads_mobile_sdk/d91;

    sget-object v3, Lrg2;->a:Lrg2;

    packed-switch v0, :pswitch_data_8c

    const-string v0, "test_mode_enabled"

    :try_start_f
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1, v0}, Lfx0;->v(Ljava/lang/String;)Lkw0;

    move-result-object p1

    invoke-virtual {p1}, Lkw0;->m()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_1d
    .catch Ljava/lang/Exception; {:try_start_f .. :try_end_1d} :catch_1e

    move-object v1, p1

    :catch_1e
    invoke-static {v1}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result p1

    if-nez p1, :cond_34

    invoke-static {v1}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result p1

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Lwx;

    invoke-static {p0, p1, p2}, Lads_mobile_sdk/d91;->b(Lads_mobile_sdk/d91;ZLwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v2, :cond_34

    move-object v3, p0

    :cond_34
    return-object v3

    :pswitch_35  #0x1
    const-string v0, "gesture"

    :try_start_37
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1, v0}, Lfx0;->v(Ljava/lang/String;)Lkw0;

    move-result-object p1

    invoke-virtual {p1}, Lkw0;->m()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_45
    .catch Ljava/lang/Exception; {:try_start_37 .. :try_end_45} :catch_46

    move-object v1, p1

    :catch_46
    const-string p1, "shake"

    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_5c

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Lwx;

    const/4 p1, 0x2

    invoke-static {p0, p1, p2}, Lads_mobile_sdk/d91;->a(Lads_mobile_sdk/d91;ILwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v2, :cond_7e

    :goto_5a
    move-object v3, p0

    goto :goto_7e

    :cond_5c
    const-string p1, "flick"

    invoke-virtual {v1, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_71

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Lwx;

    const/4 p1, 0x3

    invoke-static {p0, p1, p2}, Lads_mobile_sdk/d91;->a(Lads_mobile_sdk/d91;ILwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v2, :cond_7e

    goto :goto_5a

    :cond_71
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Lwx;

    const/4 p1, 0x1

    invoke-static {p0, p1, p2}, Lads_mobile_sdk/d91;->a(Lads_mobile_sdk/d91;ILwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v2, :cond_7e

    goto :goto_5a

    :cond_7e
    :goto_7e
    return-object v3

    :pswitch_7f  #0x0
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Lwx;

    invoke-static {p0, p1, p2}, Lads_mobile_sdk/d91;->a(Lads_mobile_sdk/d91;Lfx0;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v2, :cond_8b

    move-object v3, p0

    :cond_8b
    return-object v3

    :pswitch_data_8c
    .packed-switch 0x0
        :pswitch_7f  #00000000
        :pswitch_35  #00000001
    .end packed-switch
.end method
