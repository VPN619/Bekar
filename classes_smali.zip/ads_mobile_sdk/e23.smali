.class public final Lads_mobile_sdk/e23;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lt13;


# instance fields
.field public final a:Ljava/lang/Object;

.field public final synthetic b:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/a33;)V
    .registers 3

    const/4 v0, 0x0

    iput v0, p0, Lads_mobile_sdk/e23;->b:I

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/e23;->a:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lads_mobile_sdk/vz;)V
    .registers 3

    const/4 v0, 0x1

    iput v0, p0, Lads_mobile_sdk/e23;->b:I

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/e23;->a:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final a(Lfx0;Lvx;)Ljava/lang/Object;
    .registers 7

    .prologue
    iget v0, p0, Lads_mobile_sdk/e23;->b:I

    sget-object v1, Lrg2;->a:Lrg2;

    iget-object p0, p0, Lads_mobile_sdk/e23;->a:Ljava/lang/Object;

    sget-object v2, Lwy;->a:Lwy;

    packed-switch v0, :pswitch_data_70

    check-cast p0, Lads_mobile_sdk/vz;

    const-string v0, "clear"

    const-string v3, ""

    invoke-static {p1, v0, v3}, Lads_mobile_sdk/bw2;->a(Lfx0;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    if-lez v0, :cond_25

    check-cast p2, Lwx;

    invoke-virtual {p0, p2}, Lads_mobile_sdk/vz;->v(Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v2, :cond_3a

    :goto_23
    move-object v1, p0

    goto :goto_3a

    :cond_25
    const-string v0, "cookie"

    invoke-static {p1, v0, v3}, Lads_mobile_sdk/bw2;->a(Lfx0;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    if-lez v0, :cond_3a

    check-cast p2, Lwx;

    invoke-virtual {p0, p1, p2}, Lads_mobile_sdk/vz;->b(Ljava/lang/String;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v2, :cond_3a

    goto :goto_23

    :cond_3a
    :goto_3a
    return-object v1

    :pswitch_3b  #0x0
    const-string v0, "total_inflight_ad_limit"

    const/4 v3, 0x0

    invoke-static {p1, v0, v3}, Lads_mobile_sdk/bw2;->a(Lfx0;Ljava/lang/String;I)I

    move-result p1

    if-lez p1, :cond_5c

    check-cast p0, Lads_mobile_sdk/a33;

    check-cast p2, Lads_mobile_sdk/k;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lads_mobile_sdk/x23;

    invoke-direct {v0, p1}, Lads_mobile_sdk/x23;-><init>(I)V

    invoke-static {p0, v0, p2}, Lads_mobile_sdk/a33;->a(Lads_mobile_sdk/a33;Lbk0;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v2, :cond_57

    goto :goto_58

    :cond_57
    move-object p0, v1

    :goto_58
    if-ne p0, v2, :cond_6e

    move-object v1, p0

    goto :goto_6e

    :cond_5c
    new-instance p0, Ljava/lang/StringBuilder;

    const-string p2, "Received non-positive total_inflight_ad_limit: "

    invoke-direct {p0, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 p1, 0x0

    invoke-static {p0, p1}, Lads_mobile_sdk/nw;->b(Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_6e
    :goto_6e
    return-object v1

    nop

    :pswitch_data_70
    .packed-switch 0x0
        :pswitch_3b  #00000000
    .end packed-switch
.end method
