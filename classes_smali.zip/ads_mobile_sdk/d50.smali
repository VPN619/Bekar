.class public final Lads_mobile_sdk/d50;
.super Lads_mobile_sdk/ku0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field private static final DEFAULT_INSTANCE:Lads_mobile_sdk/d50;

.field public static final c:I = 0x1

.field public static final d:I = 0x2

.field public static final e:I = 0x3


# instance fields
.field private bitField0_:I

.field private uri_:Lads_mobile_sdk/hr;

.field private verb_:Lads_mobile_sdk/hr;

.field private version_:Lads_mobile_sdk/hr;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lads_mobile_sdk/d50;

    invoke-direct {v0}, Lads_mobile_sdk/d50;-><init>()V

    sput-object v0, Lads_mobile_sdk/d50;->DEFAULT_INSTANCE:Lads_mobile_sdk/d50;

    const-class v1, Lads_mobile_sdk/d50;

    invoke-static {v1, v0}, Lads_mobile_sdk/ku0;->a(Ljava/lang/Class;Lads_mobile_sdk/ku0;)V

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Lads_mobile_sdk/ku0;-><init>()V

    sget-object v0, Lads_mobile_sdk/hr;->b:Lads_mobile_sdk/fr;

    iput-object v0, p0, Lads_mobile_sdk/d50;->verb_:Lads_mobile_sdk/hr;

    iput-object v0, p0, Lads_mobile_sdk/d50;->uri_:Lads_mobile_sdk/hr;

    iput-object v0, p0, Lads_mobile_sdk/d50;->version_:Lads_mobile_sdk/hr;

    return-void
.end method


# virtual methods
.method public final a(ILads_mobile_sdk/ku0;)Ljava/lang/Object;
    .registers 4

    .prologue
    invoke-static {p1}, Lvr0;->a(I)I

    move-result p0

    if-eqz p0, :cond_45

    const/4 p1, 0x2

    if-eq p0, p1, :cond_2f

    const/4 p1, 0x3

    if-eq p0, p1, :cond_29

    const/4 p1, 0x4

    if-eq p0, p1, :cond_21

    const/4 p1, 0x5

    if-eq p0, p1, :cond_1e

    const/4 p1, 0x6

    if-ne p0, p1, :cond_1c

    const-class p0, Lads_mobile_sdk/d50;

    invoke-static {p0}, Lads_mobile_sdk/ku0;->b(Ljava/lang/Class;)Lads_mobile_sdk/ju0;

    move-result-object p0

    return-object p0

    :cond_1c
    const/4 p0, 0x0

    throw p0

    :cond_1e
    sget-object p0, Lads_mobile_sdk/d50;->DEFAULT_INSTANCE:Lads_mobile_sdk/d50;

    return-object p0

    :cond_21
    new-instance p0, Lbt2;

    sget-object p1, Lads_mobile_sdk/d50;->DEFAULT_INSTANCE:Lads_mobile_sdk/d50;

    invoke-direct {p0, p1}, Lads_mobile_sdk/iu0;-><init>(Lads_mobile_sdk/ku0;)V

    return-object p0

    :cond_29
    new-instance p0, Lads_mobile_sdk/d50;

    invoke-direct {p0}, Lads_mobile_sdk/d50;-><init>()V

    return-object p0

    :cond_2f
    const-string p0, "uri_"

    const-string p1, "version_"

    const-string p2, "bitField0_"

    const-string v0, "verb_"

    filled-new-array {p2, v0, p0, p1}, [Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lads_mobile_sdk/d50;->DEFAULT_INSTANCE:Lads_mobile_sdk/d50;

    new-instance p2, Lads_mobile_sdk/zq2;

    const-string v0, "\u0001\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0000\u0000\u0001ည\u0000\u0002ည\u0001\u0003ည\u0002"

    invoke-direct {p2, p1, v0, p0}, Lads_mobile_sdk/zq2;-><init>(Lads_mobile_sdk/ku0;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object p2

    :cond_45
    const/4 p0, 0x1

    invoke-static {p0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p0

    return-object p0
.end method
