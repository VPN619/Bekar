.class public final Lads_mobile_sdk/ca3;
.super Ljava/util/AbstractMap;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public a:[Ljava/lang/Object;

.field public b:I

.field public c:Z

.field public volatile d:Lpe;


# direct methods
.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Ljava/util/AbstractMap;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Lads_mobile_sdk/ca3;->c:Z

    const/4 v1, 0x0

    iput-object v1, p0, Lads_mobile_sdk/ca3;->a:[Ljava/lang/Object;

    iput v0, p0, Lads_mobile_sdk/ca3;->b:I

    return-void
.end method


# virtual methods
.method public final a()V
    .registers 1

    .prologue
    iget-boolean p0, p0, Lads_mobile_sdk/ca3;->c:Z

    if-nez p0, :cond_5

    return-void

    :cond_5
    invoke-static {}, Lvx2;->p()V

    return-void
.end method

.method public final a(I)V
    .registers 5

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/ca3;->a:[Ljava/lang/Object;

    if-eqz v0, :cond_24

    array-length v1, v0

    if-nez v1, :cond_8

    goto :goto_24

    :cond_8
    array-length v1, v0

    if-le p1, v1, :cond_23

    array-length v1, v0

    shr-int/lit8 v2, v1, 0x1

    add-int/2addr v1, v2

    sub-int v2, v1, p1

    if-gez v2, :cond_14

    goto :goto_15

    :cond_14
    move p1, v1

    :goto_15
    const v1, 0x7ffffff7

    sub-int v2, p1, v1

    if-lez v2, :cond_1d

    move p1, v1

    :cond_1d
    invoke-static {v0, p1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p1

    iput-object p1, p0, Lads_mobile_sdk/ca3;->a:[Ljava/lang/Object;

    :cond_23
    return-void

    :cond_24
    :goto_24
    const/16 v0, 0x10

    invoke-static {v0, p1}, Ljava/lang/Math;->max(II)I

    move-result p1

    new-array p1, p1, [Ljava/lang/Object;

    iput-object p1, p0, Lads_mobile_sdk/ca3;->a:[Ljava/lang/Object;

    return-void
.end method

.method public final clear()V
    .registers 2

    .prologue
    invoke-virtual {p0}, Lads_mobile_sdk/ca3;->a()V

    iget v0, p0, Lads_mobile_sdk/ca3;->b:I

    if-eqz v0, :cond_d

    const/4 v0, 0x0

    iput-object v0, p0, Lads_mobile_sdk/ca3;->a:[Ljava/lang/Object;

    const/4 v0, 0x0

    iput v0, p0, Lads_mobile_sdk/ca3;->b:I

    :cond_d
    return-void
.end method

.method public final containsKey(Ljava/lang/Object;)Z
    .registers 2

    .prologue
    if-nez p1, :cond_18

    iget p1, p0, Lads_mobile_sdk/ca3;->b:I

    add-int/lit8 p1, p1, -0x1

    if-gez p1, :cond_a

    const/4 p0, 0x0

    return p0

    :cond_a
    ushr-int/lit8 p1, p1, 0x1

    iget-object p0, p0, Lads_mobile_sdk/ca3;->a:[Ljava/lang/Object;

    aget-object p0, p0, p1

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Lvx2;->b()V

    :goto_16
    const/4 p0, 0x0

    return p0

    :cond_18
    invoke-static {}, Lvx2;->b()V

    goto :goto_16
.end method

.method public final entrySet()Ljava/util/Set;
    .registers 3

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/ca3;->d:Lpe;

    if-nez v0, :cond_c

    new-instance v0, Lpe;

    const/4 v1, 0x2

    invoke-direct {v0, p0, v1}, Lpe;-><init>(Ljava/util/Map;I)V

    iput-object v0, p0, Lads_mobile_sdk/ca3;->d:Lpe;

    :cond_c
    iget-object p0, p0, Lads_mobile_sdk/ca3;->d:Lpe;

    return-object p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 7

    .prologue
    if-ne p0, p1, :cond_3

    goto :goto_2b

    :cond_3
    instance-of v0, p1, Lads_mobile_sdk/ca3;

    if-nez v0, :cond_c

    invoke-super {p0, p1}, Ljava/util/AbstractMap;->equals(Ljava/lang/Object;)Z

    move-result p0

    return p0

    :cond_c
    check-cast p1, Lads_mobile_sdk/ca3;

    iget v0, p0, Lads_mobile_sdk/ca3;->b:I

    iget v1, p1, Lads_mobile_sdk/ca3;->b:I

    const/4 v2, 0x0

    if-eq v0, v1, :cond_16

    goto :goto_27

    :cond_16
    iget-object p0, p0, Lads_mobile_sdk/ca3;->a:[Ljava/lang/Object;

    iget-object p1, p1, Lads_mobile_sdk/ca3;->a:[Ljava/lang/Object;

    move v1, v2

    :goto_1b
    if-ge v1, v0, :cond_2b

    aget-object v3, p0, v1

    aget-object v4, p1, v1

    invoke-virtual {v3, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_28

    :goto_27
    return v2

    :cond_28
    add-int/lit8 v1, v1, 0x1

    goto :goto_1b

    :cond_2b
    :goto_2b
    const/4 p0, 0x1

    return p0
.end method

.method public final get(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .prologue
    if-nez p1, :cond_18

    iget p1, p0, Lads_mobile_sdk/ca3;->b:I

    add-int/lit8 p1, p1, -0x1

    if-gez p1, :cond_a

    const/4 p0, 0x0

    return-object p0

    :cond_a
    ushr-int/lit8 p1, p1, 0x1

    iget-object p0, p0, Lads_mobile_sdk/ca3;->a:[Ljava/lang/Object;

    aget-object p0, p0, p1

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Lvx2;->b()V

    :goto_16
    const/4 p0, 0x0

    return-object p0

    :cond_18
    invoke-static {}, Lvx2;->b()V

    goto :goto_16
.end method

.method public final hashCode()I
    .registers 5

    .prologue
    iget v0, p0, Lads_mobile_sdk/ca3;->b:I

    const/4 v1, 0x0

    move v2, v1

    :goto_4
    if-ge v1, v0, :cond_12

    iget-object v3, p0, Lads_mobile_sdk/ca3;->a:[Ljava/lang/Object;

    aget-object v3, v3, v1

    invoke-virtual {v3}, Ljava/lang/Object;->hashCode()I

    move-result v3

    add-int/2addr v2, v3

    add-int/lit8 v1, v1, 0x1

    goto :goto_4

    :cond_12
    return v2
.end method

.method public final isEmpty()Z
    .registers 1

    .prologue
    iget p0, p0, Lads_mobile_sdk/ca3;->b:I

    if-nez p0, :cond_6

    const/4 p0, 0x1

    return p0

    :cond_6
    const/4 p0, 0x0

    return p0
.end method

.method public final put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .prologue
    if-nez p1, :cond_7

    invoke-virtual {p0}, Lads_mobile_sdk/ca3;->a()V

    const/4 p0, 0x0

    throw p0

    :cond_7
    new-instance p0, Ljava/lang/ClassCastException;

    invoke-direct {p0}, Ljava/lang/ClassCastException;-><init>()V

    throw p0
.end method

.method public final putAll(Ljava/util/Map;)V
    .registers 4

    .prologue
    invoke-virtual {p0}, Lads_mobile_sdk/ca3;->a()V

    instance-of v0, p1, Lads_mobile_sdk/ca3;

    iget v1, p0, Lads_mobile_sdk/ca3;->b:I

    if-eqz v0, :cond_25

    check-cast p1, Lads_mobile_sdk/ca3;

    iget v0, p1, Lads_mobile_sdk/ca3;->b:I

    add-int/2addr v1, v0

    invoke-virtual {p0, v1}, Lads_mobile_sdk/ca3;->a(I)V

    iget p0, p0, Lads_mobile_sdk/ca3;->b:I

    iget v0, p1, Lads_mobile_sdk/ca3;->b:I

    add-int/2addr v0, p0

    if-lt p0, v0, :cond_19

    goto :goto_53

    :cond_19
    iget-object p0, p1, Lads_mobile_sdk/ca3;->a:[Ljava/lang/Object;

    const/4 p1, 0x0

    aget-object p0, p0, p1

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Lvx2;->b()V

    return-void

    :cond_25
    invoke-interface {p1}, Ljava/util/Map;->size()I

    move-result v0

    add-int/2addr v0, v1

    invoke-virtual {p0, v0}, Lads_mobile_sdk/ca3;->a(I)V

    invoke-interface {p1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_53

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/Map$Entry;

    invoke-interface {p1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_4b

    invoke-static {}, Lvx2;->b()V

    return-void

    :cond_4b
    invoke-interface {p1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    invoke-virtual {p0}, Lads_mobile_sdk/ca3;->a()V

    const/4 p0, 0x0

    throw p0

    :cond_53
    :goto_53
    return-void
.end method

.method public final remove(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .prologue
    invoke-virtual {p0}, Lads_mobile_sdk/ca3;->a()V

    if-nez p1, :cond_1b

    iget p1, p0, Lads_mobile_sdk/ca3;->b:I

    add-int/lit8 p1, p1, -0x1

    if-gez p1, :cond_d

    const/4 p0, 0x0

    return-object p0

    :cond_d
    ushr-int/lit8 p1, p1, 0x1

    iget-object p0, p0, Lads_mobile_sdk/ca3;->a:[Ljava/lang/Object;

    aget-object p0, p0, p1

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Lvx2;->b()V

    :goto_19
    const/4 p0, 0x0

    return-object p0

    :cond_1b
    invoke-static {}, Lvx2;->b()V

    goto :goto_19
.end method

.method public final size()I
    .registers 1

    iget p0, p0, Lads_mobile_sdk/ca3;->b:I

    return p0
.end method
