.class public abstract Lads_mobile_sdk/bx0;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final a:Ljava/util/Set;


# direct methods
.method static constructor <clinit>()V
    .registers 26

    const-string v24, ".ota"

    const-string v25, ".imy"

    const-string v1, ".mp4"

    const-string v2, ".webm"

    const-string v3, ".mkv"

    const-string v4, ".3gp"

    const-string v5, ".m4v"

    const-string v6, ".ts"

    const-string v7, ".flv"

    const-string v8, ".ogv"

    const-string v9, ".avi"

    const-string v10, ".mov"

    const-string v11, ".qt"

    const-string v12, ".wmv"

    const-string v13, ".mp3"

    const-string v14, ".aac"

    const-string v15, ".wav"

    const-string v16, ".flac"

    const-string v17, ".ogg"

    const-string v18, ".m4a"

    const-string v19, ".mid"

    const-string v20, ".xmf"

    const-string v21, ".mxmf"

    const-string v22, ".rtttl"

    const-string v23, ".rtx"

    filled-new-array/range {v1 .. v25}, [Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Laf;->x0([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v0

    sput-object v0, Lads_mobile_sdk/bx0;->a:Ljava/util/Set;

    return-void
.end method
