.class public final Lads_mobile_sdk/ek3;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lnt2;


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    iput p1, p0, Lads_mobile_sdk/ek3;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 3

    .prologue
    iget p0, p0, Lads_mobile_sdk/ek3;->a:I

    packed-switch p0, :pswitch_data_38

    new-instance p0, Loy2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lads_mobile_sdk/ez1;

    const/4 v1, 0x6

    invoke-direct {v0, p0, v1}, Lads_mobile_sdk/ez1;-><init>(Lbw2;I)V

    return-object v0

    :pswitch_11  #0x2
    new-instance p0, Lads_mobile_sdk/e7;

    const/16 v0, 0xb

    const/4 v1, 0x0

    invoke-direct {p0, v1, v0}, Lads_mobile_sdk/e7;-><init>(BI)V

    new-instance v0, Lads_mobile_sdk/q71;

    invoke-direct {v0, p0}, Lads_mobile_sdk/q71;-><init>(Lads_mobile_sdk/e7;)V

    return-object v0

    :pswitch_1f  #0x1
    new-instance p0, Lads_mobile_sdk/ug0;

    invoke-direct {p0}, Lads_mobile_sdk/ug0;-><init>()V

    new-instance v0, Lads_mobile_sdk/ez1;

    const/4 v1, 0x6

    invoke-direct {v0, p0, v1}, Lads_mobile_sdk/ez1;-><init>(Lbw2;I)V

    return-object v0

    :pswitch_2b  #0x0
    new-instance p0, Lads_mobile_sdk/ug0;

    invoke-direct {p0}, Lads_mobile_sdk/ug0;-><init>()V

    new-instance v0, Lads_mobile_sdk/ez1;

    const/4 v1, 0x7

    invoke-direct {v0, p0, v1}, Lads_mobile_sdk/ez1;-><init>(Lbw2;I)V

    return-object v0

    nop

    :pswitch_data_38
    .packed-switch 0x0
        :pswitch_2b  #00000000
        :pswitch_1f  #00000001
        :pswitch_11  #00000002
    .end packed-switch
.end method
