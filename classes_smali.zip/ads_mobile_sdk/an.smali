.class public final Lads_mobile_sdk/an;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lnt2;


# instance fields
.field public final a:Lads_mobile_sdk/ob1;

.field public final b:Lads_mobile_sdk/ob1;

.field public final c:Ltv2;

.field public final d:Lads_mobile_sdk/ob1;

.field public final e:Ltv2;

.field public final f:Ltv2;

.field public final g:Lads_mobile_sdk/ab0;

.field public final h:Lads_mobile_sdk/ob1;

.field public final synthetic i:I


# direct methods
.method public synthetic constructor <init>(Lads_mobile_sdk/ob1;Lads_mobile_sdk/ob1;Ltv2;Lads_mobile_sdk/ob1;Ltv2;Ltv2;Lads_mobile_sdk/ab0;Lads_mobile_sdk/ob1;I)V
    .registers 10

    iput p9, p0, Lads_mobile_sdk/an;->i:I

    iput-object p1, p0, Lads_mobile_sdk/an;->a:Lads_mobile_sdk/ob1;

    iput-object p2, p0, Lads_mobile_sdk/an;->b:Lads_mobile_sdk/ob1;

    iput-object p3, p0, Lads_mobile_sdk/an;->c:Ltv2;

    iput-object p4, p0, Lads_mobile_sdk/an;->d:Lads_mobile_sdk/ob1;

    iput-object p5, p0, Lads_mobile_sdk/an;->e:Ltv2;

    iput-object p6, p0, Lads_mobile_sdk/an;->f:Ltv2;

    iput-object p7, p0, Lads_mobile_sdk/an;->g:Lads_mobile_sdk/ab0;

    iput-object p8, p0, Lads_mobile_sdk/an;->h:Lads_mobile_sdk/ob1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 18

    .prologue
    move-object/from16 v0, p0

    iget v1, v0, Lads_mobile_sdk/an;->i:I

    iget-object v2, v0, Lads_mobile_sdk/an;->h:Lads_mobile_sdk/ob1;

    iget-object v3, v0, Lads_mobile_sdk/an;->f:Ltv2;

    iget-object v4, v0, Lads_mobile_sdk/an;->e:Ltv2;

    iget-object v5, v0, Lads_mobile_sdk/an;->d:Lads_mobile_sdk/ob1;

    iget-object v6, v0, Lads_mobile_sdk/an;->c:Ltv2;

    iget-object v7, v0, Lads_mobile_sdk/an;->b:Lads_mobile_sdk/ob1;

    iget-object v8, v0, Lads_mobile_sdk/an;->a:Lads_mobile_sdk/ob1;

    packed-switch v1, :pswitch_data_ac

    iget-object v1, v8, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v9, v1

    check-cast v9, Lli;

    iget-object v1, v7, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v10, v1

    check-cast v10, Lqh;

    invoke-interface {v6}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v1

    move-object v11, v1

    check-cast v11, Lads_mobile_sdk/cu2;

    iget-object v1, v5, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v12, v1

    check-cast v12, Landroid/content/Context;

    invoke-interface {v4}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v1

    move-object v13, v1

    check-cast v13, Lads_mobile_sdk/g0;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v1

    move-object v14, v1

    check-cast v14, Lads_mobile_sdk/rh0;

    iget-object v1, v2, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object/from16 v16, v1

    check-cast v16, Lc73;

    new-instance v8, Lads_mobile_sdk/fm;

    iget-object v15, v0, Lads_mobile_sdk/an;->g:Lads_mobile_sdk/ab0;

    invoke-direct/range {v8 .. v16}, Lads_mobile_sdk/fm;-><init>(Lli;Lqh;Lads_mobile_sdk/cu2;Landroid/content/Context;Lads_mobile_sdk/g0;Lads_mobile_sdk/rh0;Lads_mobile_sdk/ab0;Lc73;)V

    return-object v8

    :pswitch_47  #0x1
    iget-object v1, v8, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v9, v1

    check-cast v9, Lli;

    iget-object v1, v7, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v10, v1

    check-cast v10, Lqh;

    invoke-interface {v6}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v1

    move-object v11, v1

    check-cast v11, Lads_mobile_sdk/cu2;

    iget-object v1, v5, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v12, v1

    check-cast v12, Landroid/content/Context;

    invoke-interface {v4}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v1

    move-object v13, v1

    check-cast v13, Lads_mobile_sdk/g0;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v1

    move-object v14, v1

    check-cast v14, Lads_mobile_sdk/rh0;

    iget-object v1, v2, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object/from16 v16, v1

    check-cast v16, Lc73;

    new-instance v8, Lads_mobile_sdk/bm;

    iget-object v15, v0, Lads_mobile_sdk/an;->g:Lads_mobile_sdk/ab0;

    invoke-direct/range {v8 .. v16}, Lads_mobile_sdk/bm;-><init>(Lli;Lqh;Lads_mobile_sdk/cu2;Landroid/content/Context;Lads_mobile_sdk/g0;Lads_mobile_sdk/rh0;Lads_mobile_sdk/ab0;Lc73;)V

    return-object v8

    :pswitch_79  #0x0
    iget-object v1, v8, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v9, v1

    check-cast v9, Lli;

    iget-object v1, v7, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v10, v1

    check-cast v10, Lqh;

    invoke-interface {v6}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v1

    move-object v11, v1

    check-cast v11, Lads_mobile_sdk/cu2;

    iget-object v1, v5, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v12, v1

    check-cast v12, Landroid/content/Context;

    invoke-interface {v4}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v1

    move-object v13, v1

    check-cast v13, Lads_mobile_sdk/g0;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v1

    move-object v14, v1

    check-cast v14, Lads_mobile_sdk/rh0;

    iget-object v1, v2, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object/from16 v16, v1

    check-cast v16, Lc73;

    new-instance v8, Lads_mobile_sdk/zm;

    iget-object v15, v0, Lads_mobile_sdk/an;->g:Lads_mobile_sdk/ab0;

    invoke-direct/range {v8 .. v16}, Lads_mobile_sdk/zm;-><init>(Lli;Lqh;Lads_mobile_sdk/cu2;Landroid/content/Context;Lads_mobile_sdk/g0;Lads_mobile_sdk/rh0;Lads_mobile_sdk/ab0;Lc73;)V

    return-object v8

    nop

    :pswitch_data_ac
    .packed-switch 0x0
        :pswitch_79  #00000000
        :pswitch_47  #00000001
    .end packed-switch
.end method
