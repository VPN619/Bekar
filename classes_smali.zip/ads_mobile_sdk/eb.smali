.class public final Lads_mobile_sdk/eb;
.super Lwx;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public a:Lads_mobile_sdk/sb;

.field public b:Lb4;

.field public c:Ljava/lang/Object;

.field public d:Ljava/io/Closeable;

.field public e:Ljava/lang/Object;

.field public f:Ljava/io/Serializable;

.field public g:Ljava/lang/Object;

.field public h:Lnb1;

.field public synthetic k:Ljava/lang/Object;

.field public final synthetic l:Lads_mobile_sdk/sb;

.field public m:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/sb;Lwx;)V
    .registers 3

    iput-object p1, p0, Lads_mobile_sdk/eb;->l:Lads_mobile_sdk/sb;

    invoke-direct {p0, p2}, Lwx;-><init>(Lvx;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    iput-object p1, p0, Lads_mobile_sdk/eb;->k:Ljava/lang/Object;

    iget p1, p0, Lads_mobile_sdk/eb;->m:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, Lads_mobile_sdk/eb;->m:I

    iget-object p1, p0, Lads_mobile_sdk/eb;->l:Lads_mobile_sdk/sb;

    const/4 v0, 0x0

    invoke-static {p1, v0, p0}, Lads_mobile_sdk/sb;->a(Lads_mobile_sdk/sb;Lb4;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
