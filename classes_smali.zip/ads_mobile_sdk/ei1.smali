.class public final Lads_mobile_sdk/ei1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lnt2;


# instance fields
.field public final a:Lads_mobile_sdk/ob1;

.field public final b:Ltv2;

.field public final c:Lads_mobile_sdk/ob1;

.field public final d:Ltv2;

.field public final e:Ltv2;

.field public final f:Lads_mobile_sdk/ab0;

.field public final synthetic g:I


# direct methods
.method public synthetic constructor <init>(Lads_mobile_sdk/ob1;Ltv2;Lads_mobile_sdk/ob1;Ltv2;Ltv2;Lads_mobile_sdk/ab0;I)V
    .registers 8

    iput p7, p0, Lads_mobile_sdk/ei1;->g:I

    iput-object p1, p0, Lads_mobile_sdk/ei1;->a:Lads_mobile_sdk/ob1;

    iput-object p2, p0, Lads_mobile_sdk/ei1;->b:Ltv2;

    iput-object p3, p0, Lads_mobile_sdk/ei1;->c:Lads_mobile_sdk/ob1;

    iput-object p4, p0, Lads_mobile_sdk/ei1;->d:Ltv2;

    iput-object p5, p0, Lads_mobile_sdk/ei1;->e:Ltv2;

    iput-object p6, p0, Lads_mobile_sdk/ei1;->f:Lads_mobile_sdk/ab0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 13

    .prologue
    iget v0, p0, Lads_mobile_sdk/ei1;->g:I

    iget-object v1, p0, Lads_mobile_sdk/ei1;->e:Ltv2;

    iget-object v2, p0, Lads_mobile_sdk/ei1;->d:Ltv2;

    iget-object v3, p0, Lads_mobile_sdk/ei1;->c:Lads_mobile_sdk/ob1;

    iget-object v4, p0, Lads_mobile_sdk/ei1;->b:Ltv2;

    iget-object v5, p0, Lads_mobile_sdk/ei1;->a:Lads_mobile_sdk/ob1;

    packed-switch v0, :pswitch_data_84

    iget-object v0, v5, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v6, v0

    check-cast v6, Lli;

    invoke-interface {v4}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v7, v0

    check-cast v7, Lads_mobile_sdk/cu2;

    iget-object v0, v3, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v8, v0

    check-cast v8, Landroid/content/Context;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v9, v0

    check-cast v9, Lads_mobile_sdk/g0;

    invoke-interface {v1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v10, v0

    check-cast v10, Lads_mobile_sdk/rh0;

    new-instance v5, Lads_mobile_sdk/xi1;

    iget-object v11, p0, Lads_mobile_sdk/ei1;->f:Lads_mobile_sdk/ab0;

    invoke-direct/range {v5 .. v11}, Lads_mobile_sdk/xi1;-><init>(Lli;Lads_mobile_sdk/cu2;Landroid/content/Context;Lads_mobile_sdk/g0;Lads_mobile_sdk/rh0;Lads_mobile_sdk/ab0;)V

    return-object v5

    :pswitch_36  #0x1
    iget-object v0, v5, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v6, v0

    check-cast v6, Lli;

    invoke-interface {v4}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v7, v0

    check-cast v7, Lads_mobile_sdk/cu2;

    iget-object v0, v3, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v8, v0

    check-cast v8, Landroid/content/Context;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v9, v0

    check-cast v9, Lads_mobile_sdk/g0;

    invoke-interface {v1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v10, v0

    check-cast v10, Lads_mobile_sdk/rh0;

    new-instance v5, Lads_mobile_sdk/fi1;

    iget-object v11, p0, Lads_mobile_sdk/ei1;->f:Lads_mobile_sdk/ab0;

    invoke-direct/range {v5 .. v11}, Lads_mobile_sdk/fi1;-><init>(Lli;Lads_mobile_sdk/cu2;Landroid/content/Context;Lads_mobile_sdk/g0;Lads_mobile_sdk/rh0;Lads_mobile_sdk/ab0;)V

    return-object v5

    :pswitch_5d  #0x0
    iget-object v0, v5, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v6, v0

    check-cast v6, Lli;

    invoke-interface {v4}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v7, v0

    check-cast v7, Lads_mobile_sdk/cu2;

    iget-object v0, v3, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v8, v0

    check-cast v8, Landroid/content/Context;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v9, v0

    check-cast v9, Lads_mobile_sdk/g0;

    invoke-interface {v1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v10, v0

    check-cast v10, Lads_mobile_sdk/rh0;

    new-instance v5, Lads_mobile_sdk/di1;

    iget-object v11, p0, Lads_mobile_sdk/ei1;->f:Lads_mobile_sdk/ab0;

    invoke-direct/range {v5 .. v11}, Lads_mobile_sdk/di1;-><init>(Lli;Lads_mobile_sdk/cu2;Landroid/content/Context;Lads_mobile_sdk/g0;Lads_mobile_sdk/rh0;Lads_mobile_sdk/ab0;)V

    return-object v5

    :pswitch_data_84
    .packed-switch 0x0
        :pswitch_5d  #00000000
        :pswitch_36  #00000001
    .end packed-switch
.end method
