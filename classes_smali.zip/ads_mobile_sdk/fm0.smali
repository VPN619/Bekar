.class public final Lads_mobile_sdk/fm0;
.super Lads_mobile_sdk/ku0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field private static final DEFAULT_INSTANCE:Lads_mobile_sdk/fm0;

.field public static final c:I = 0x1

.field public static final d:I = 0x2

.field public static final e:I = 0x3

.field public static final f:I = 0x4


# instance fields
.field private bitField0_:I

.field private bytecode_:Lads_mobile_sdk/hr;

.field private metadata_:Lads_mobile_sdk/jl2;

.field private status_:I

.field private vm_:Lads_mobile_sdk/hr;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lads_mobile_sdk/fm0;

    invoke-direct {v0}, Lads_mobile_sdk/fm0;-><init>()V

    sput-object v0, Lads_mobile_sdk/fm0;->DEFAULT_INSTANCE:Lads_mobile_sdk/fm0;

    const-class v1, Lads_mobile_sdk/fm0;

    invoke-static {v1, v0}, Lads_mobile_sdk/ku0;->a(Ljava/lang/Class;Lads_mobile_sdk/ku0;)V

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Lads_mobile_sdk/ku0;-><init>()V

    sget-object v0, Lads_mobile_sdk/hr;->b:Lads_mobile_sdk/fr;

    iput-object v0, p0, Lads_mobile_sdk/fm0;->bytecode_:Lads_mobile_sdk/hr;

    iput-object v0, p0, Lads_mobile_sdk/fm0;->vm_:Lads_mobile_sdk/hr;

    return-void
.end method

.method public static bridge synthetic c(Lads_mobile_sdk/fm0;)I
    .registers 1

    iget p0, p0, Lads_mobile_sdk/fm0;->bitField0_:I

    return p0
.end method

.method public static bridge synthetic d(Lads_mobile_sdk/fm0;I)V
    .registers 2

    iput p1, p0, Lads_mobile_sdk/fm0;->bitField0_:I

    return-void
.end method

.method public static bridge synthetic f(Lads_mobile_sdk/fm0;I)V
    .registers 2

    iput p1, p0, Lads_mobile_sdk/fm0;->status_:I

    return-void
.end method

.method public static s()Lix2;
    .registers 1

    sget-object v0, Lads_mobile_sdk/fm0;->DEFAULT_INSTANCE:Lads_mobile_sdk/fm0;

    invoke-virtual {v0}, Lads_mobile_sdk/ku0;->e()Lads_mobile_sdk/iu0;

    move-result-object v0

    check-cast v0, Lix2;

    return-object v0
.end method


# virtual methods
.method public final a(ILads_mobile_sdk/ku0;)Ljava/lang/Object;
    .registers 9

    .prologue
    invoke-static {p1}, Lvr0;->a(I)I

    move-result p0

    if-eqz p0, :cond_49

    const/4 p1, 0x2

    if-eq p0, p1, :cond_2f

    const/4 p1, 0x3

    if-eq p0, p1, :cond_29

    const/4 p1, 0x4

    if-eq p0, p1, :cond_21

    const/4 p1, 0x5

    if-eq p0, p1, :cond_1e

    const/4 p1, 0x6

    if-ne p0, p1, :cond_1c

    const-class p0, Lads_mobile_sdk/fm0;

    invoke-static {p0}, Lads_mobile_sdk/ku0;->b(Ljava/lang/Class;)Lads_mobile_sdk/ju0;

    move-result-object p0

    return-object p0

    :cond_1c
    const/4 p0, 0x0

    throw p0

    :cond_1e
    sget-object p0, Lads_mobile_sdk/fm0;->DEFAULT_INSTANCE:Lads_mobile_sdk/fm0;

    return-object p0

    :cond_21
    new-instance p0, Lix2;

    sget-object p1, Lads_mobile_sdk/fm0;->DEFAULT_INSTANCE:Lads_mobile_sdk/fm0;

    invoke-direct {p0, p1}, Lads_mobile_sdk/iu0;-><init>(Lads_mobile_sdk/ku0;)V

    return-object p0

    :cond_29
    new-instance p0, Lads_mobile_sdk/fm0;

    invoke-direct {p0}, Lads_mobile_sdk/fm0;-><init>()V

    return-object p0

    :cond_2f
    const-string v4, "status_"

    sget-object v5, Lads_mobile_sdk/ad;->a$29:Lads_mobile_sdk/ad;

    const-string v0, "bitField0_"

    const-string v1, "metadata_"

    const-string v2, "bytecode_"

    const-string v3, "vm_"

    filled-new-array/range {v0 .. v5}, [Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lads_mobile_sdk/fm0;->DEFAULT_INSTANCE:Lads_mobile_sdk/fm0;

    new-instance p2, Lads_mobile_sdk/zq2;

    const-string v0, "\u0004\u0004\u0000\u0001\u0001\u0004\u0004\u0000\u0000\u0000\u0001ဉ\u0000\u0002ည\u0001\u0003ည\u0002\u0004᠌\u0003"

    invoke-direct {p2, p1, v0, p0}, Lads_mobile_sdk/zq2;-><init>(Lads_mobile_sdk/ku0;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object p2

    :cond_49
    const/4 p0, 0x1

    invoke-static {p0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p0

    return-object p0
.end method

.method public final a(Lads_mobile_sdk/hr;)V
    .registers 3

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget v0, p0, Lads_mobile_sdk/fm0;->bitField0_:I

    or-int/lit8 v0, v0, 0x2

    iput v0, p0, Lads_mobile_sdk/fm0;->bitField0_:I

    iput-object p1, p0, Lads_mobile_sdk/fm0;->bytecode_:Lads_mobile_sdk/hr;

    return-void
.end method

.method public final a(Lads_mobile_sdk/jl2;)V
    .registers 2

    iput-object p1, p0, Lads_mobile_sdk/fm0;->metadata_:Lads_mobile_sdk/jl2;

    iget p1, p0, Lads_mobile_sdk/fm0;->bitField0_:I

    or-int/lit8 p1, p1, 0x1

    iput p1, p0, Lads_mobile_sdk/fm0;->bitField0_:I

    return-void
.end method

.method public final b(Lads_mobile_sdk/hr;)V
    .registers 3

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget v0, p0, Lads_mobile_sdk/fm0;->bitField0_:I

    or-int/lit8 v0, v0, 0x4

    iput v0, p0, Lads_mobile_sdk/fm0;->bitField0_:I

    iput-object p1, p0, Lads_mobile_sdk/fm0;->vm_:Lads_mobile_sdk/hr;

    return-void
.end method

.method public final o()Lads_mobile_sdk/hr;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/fm0;->bytecode_:Lads_mobile_sdk/hr;

    return-object p0
.end method

.method public final p()Lads_mobile_sdk/jl2;
    .registers 1

    .prologue
    iget-object p0, p0, Lads_mobile_sdk/fm0;->metadata_:Lads_mobile_sdk/jl2;

    if-nez p0, :cond_8

    invoke-static {}, Lads_mobile_sdk/jl2;->q()Lads_mobile_sdk/jl2;

    move-result-object p0

    :cond_8
    return-object p0
.end method

.method public final q$1()I
    .registers 1

    .prologue
    iget p0, p0, Lads_mobile_sdk/fm0;->status_:I

    invoke-static {p0}, Lmz2;->_a(I)I

    move-result p0

    if-nez p0, :cond_9

    const/4 p0, 0x1

    :cond_9
    return p0
.end method

.method public final r()Lads_mobile_sdk/hr;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/fm0;->vm_:Lads_mobile_sdk/hr;

    return-object p0
.end method
