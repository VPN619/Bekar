.class public final Lads_mobile_sdk/d03;
.super Lads_mobile_sdk/h83;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final f:Ljava/lang/Object;

.field public final g:Ljava/lang/Object;

.field public final h:Ljava/util/Map;

.field public final synthetic k:I


# direct methods
.method public constructor <init>(Lwy2;Lads_mobile_sdk/rp1;Lads_mobile_sdk/ga3;Landroid/content/Context;Ljava/util/Map;Lads_mobile_sdk/th3;)V
    .registers 14

    const/4 v0, 0x0

    iput v0, p0, Lads_mobile_sdk/d03;->k:I

    sget-object v0, Lads_mobile_sdk/fl0;->z:Lads_mobile_sdk/fl0;

    invoke-virtual {p6, v0}, Lads_mobile_sdk/th3;->a(Lads_mobile_sdk/fl0;)Lads_mobile_sdk/qg3;

    move-result-object v6

    const-string v2, "ee1jc+8NBSVAl9OExJcVRTwv+plL0Iy69FCE6Yx8F+GjR+v4lDH+ocizPm8vmx4v"

    const-string v3, "FZSVTnku4RuPrCRfw5BEpEB9NajIzKnpSVrmD7jH22A="

    move-object v1, p0

    move-object v4, p1

    move-object v5, p2

    invoke-direct/range {v1 .. v6}, Lads_mobile_sdk/h83;-><init>(Ljava/lang/String;Ljava/lang/String;Lwy2;Lads_mobile_sdk/rp1;Lads_mobile_sdk/qg3;)V

    iput-object p3, v1, Lads_mobile_sdk/d03;->f:Ljava/lang/Object;

    iput-object p4, v1, Lads_mobile_sdk/d03;->g:Ljava/lang/Object;

    iput-object p5, v1, Lads_mobile_sdk/d03;->h:Ljava/util/Map;

    return-void
.end method

.method public constructor <init>(Lwy2;Lads_mobile_sdk/rp1;Ljava/util/Map;Landroid/util/DisplayMetrics;Lads_mobile_sdk/th3;)V
    .registers 13

    const/4 v0, 0x1

    iput v0, p0, Lads_mobile_sdk/d03;->k:I

    sget-object v0, Lads_mobile_sdk/fl0;->B:Lads_mobile_sdk/fl0;

    invoke-virtual {p5, v0}, Lads_mobile_sdk/th3;->a(Lads_mobile_sdk/fl0;)Lads_mobile_sdk/qg3;

    move-result-object v6

    const-string v2, "IXorfg+Nbx0hDwqbWRiYwLgrt4YXfpamKgZy1XpkECay8DfCcoGadxEJireDy0DN"

    const-string v3, "Xwuf3PUSNKlxF2v17wyqCRsfRPS4OX+Ly1fwvUUAmiw="

    move-object v1, p0

    move-object v4, p1

    move-object v5, p2

    invoke-direct/range {v1 .. v6}, Lads_mobile_sdk/h83;-><init>(Ljava/lang/String;Ljava/lang/String;Lwy2;Lads_mobile_sdk/rp1;Lads_mobile_sdk/qg3;)V

    iput-object v5, v1, Lads_mobile_sdk/d03;->f:Ljava/lang/Object;

    iput-object p3, v1, Lads_mobile_sdk/d03;->h:Ljava/util/Map;

    iput-object p4, v1, Lads_mobile_sdk/d03;->g:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/reflect/Method;Lwy2;)V
    .registers 14

    .prologue
    iget v0, p0, Lads_mobile_sdk/d03;->k:I

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    packed-switch v0, :pswitch_data_2a6

    iget-object v0, p0, Lads_mobile_sdk/d03;->h:Ljava/util/Map;

    const-string v5, "nv"

    invoke-interface {v0, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/view/MotionEvent;

    :try_start_13
    const-string v5, ""

    iget-object v6, p0, Lads_mobile_sdk/d03;->g:Ljava/lang/Object;

    check-cast v6, Landroid/util/DisplayMetrics;

    filled-new-array {v0, v6}, [Ljava/lang/Object;

    move-result-object v6

    invoke-virtual {p1, v5, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, [Ljava/lang/Object;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Lads_mobile_sdk/md;->o()Lt03;

    move-result-object v5

    aget-object v2, p1, v2

    if-eqz v2, :cond_68

    aget-object v6, p1, v3

    if-eqz v6, :cond_68

    check-cast v2, Ljava/lang/Long;

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v6

    invoke-virtual {v5}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v2, v5, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v2, Lads_mobile_sdk/md;

    invoke-static {v2}, Lads_mobile_sdk/md;->c(Lads_mobile_sdk/md;)I

    move-result v8

    or-int/2addr v8, v3

    invoke-static {v2, v8}, Lads_mobile_sdk/md;->d(Lads_mobile_sdk/md;I)V

    invoke-static {v2, v6, v7}, Lads_mobile_sdk/md;->r(Lads_mobile_sdk/md;J)V

    aget-object v2, p1, v3

    check-cast v2, Ljava/lang/Long;

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v6

    invoke-virtual {v5}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v2, v5, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v2, Lads_mobile_sdk/md;

    invoke-static {v2}, Lads_mobile_sdk/md;->c(Lads_mobile_sdk/md;)I

    move-result v8

    or-int/2addr v8, v4

    invoke-static {v2, v8}, Lads_mobile_sdk/md;->d(Lads_mobile_sdk/md;I)V

    invoke-static {v2, v6, v7}, Lads_mobile_sdk/md;->t(Lads_mobile_sdk/md;J)V

    goto :goto_68

    :catchall_65
    move-exception p0

    goto/16 :goto_1e6

    :cond_68
    :goto_68
    aget-object v2, p1, v4

    if-eqz v2, :cond_85

    check-cast v2, Ljava/lang/Long;

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v6

    invoke-virtual {v5}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v2, v5, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v2, Lads_mobile_sdk/md;

    invoke-static {v2}, Lads_mobile_sdk/md;->c(Lads_mobile_sdk/md;)I

    move-result v8

    or-int/lit16 v8, v8, 0x80

    invoke-static {v2, v8}, Lads_mobile_sdk/md;->d(Lads_mobile_sdk/md;I)V

    invoke-static {v2, v6, v7}, Lads_mobile_sdk/md;->p(Lads_mobile_sdk/md;J)V

    :cond_85
    aget-object v1, p1, v1

    if-eqz v1, :cond_a2

    check-cast v1, Ljava/lang/Long;

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    invoke-virtual {v5}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v6, v5, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v6, Lads_mobile_sdk/md;

    invoke-static {v6}, Lads_mobile_sdk/md;->c(Lads_mobile_sdk/md;)I

    move-result v7

    or-int/lit8 v7, v7, 0x10

    invoke-static {v6, v7}, Lads_mobile_sdk/md;->d(Lads_mobile_sdk/md;I)V

    invoke-static {v6, v1, v2}, Lads_mobile_sdk/md;->o(Lads_mobile_sdk/md;J)V

    :cond_a2
    const/4 v1, 0x4

    aget-object v2, p1, v1

    if-eqz v2, :cond_bf

    check-cast v2, Ljava/lang/Long;

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v6

    invoke-virtual {v5}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v2, v5, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v2, Lads_mobile_sdk/md;

    invoke-static {v2}, Lads_mobile_sdk/md;->c(Lads_mobile_sdk/md;)I

    move-result v8

    or-int/2addr v8, v1

    invoke-static {v2, v8}, Lads_mobile_sdk/md;->d(Lads_mobile_sdk/md;I)V

    invoke-static {v2, v6, v7}, Lads_mobile_sdk/md;->m(Lads_mobile_sdk/md;J)V

    :cond_bf
    const/4 v2, 0x5

    aget-object v2, p1, v2

    const-wide/16 v6, 0x0

    if-eqz v2, :cond_ed

    check-cast v2, Ljava/lang/Long;

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v8

    cmp-long v2, v8, v6

    if-eqz v2, :cond_d2

    move v2, v4

    goto :goto_d3

    :cond_d2
    move v2, v3

    :goto_d3
    invoke-virtual {v5}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v8, v5, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v8, Lads_mobile_sdk/md;

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v2}, Lrt2;->a(I)I

    move-result v2

    invoke-static {v8, v2}, Lads_mobile_sdk/md;->g(Lads_mobile_sdk/md;I)V

    invoke-static {v8}, Lads_mobile_sdk/md;->c(Lads_mobile_sdk/md;)I

    move-result v2

    or-int/lit8 v2, v2, 0x40

    invoke-static {v8, v2}, Lads_mobile_sdk/md;->d(Lads_mobile_sdk/md;I)V

    :cond_ed
    const/4 v2, 0x6

    aget-object v2, p1, v2

    if-eqz v2, :cond_10b

    check-cast v2, Ljava/lang/Long;

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v8

    invoke-virtual {v5}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v2, v5, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v2, Lads_mobile_sdk/md;

    invoke-static {v2}, Lads_mobile_sdk/md;->c(Lads_mobile_sdk/md;)I

    move-result v10

    or-int/lit16 v10, v10, 0x200

    invoke-static {v2, v10}, Lads_mobile_sdk/md;->d(Lads_mobile_sdk/md;I)V

    invoke-static {v2, v8, v9}, Lads_mobile_sdk/md;->i(Lads_mobile_sdk/md;J)V

    :cond_10b
    const/4 v2, 0x7

    aget-object v2, p1, v2

    if-eqz v2, :cond_129

    check-cast v2, Ljava/lang/Long;

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v8

    invoke-virtual {v5}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v2, v5, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v2, Lads_mobile_sdk/md;

    invoke-static {v2}, Lads_mobile_sdk/md;->c(Lads_mobile_sdk/md;)I

    move-result v10

    or-int/lit16 v10, v10, 0x100

    invoke-static {v2, v10}, Lads_mobile_sdk/md;->d(Lads_mobile_sdk/md;I)V

    invoke-static {v2, v8, v9}, Lads_mobile_sdk/md;->u(Lads_mobile_sdk/md;J)V

    :cond_129
    const/16 v2, 0x8

    aget-object p1, p1, v2

    if-eqz p1, :cond_154

    check-cast p1, Ljava/lang/Long;

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v8

    cmp-long p1, v8, v6

    if-eqz p1, :cond_13a

    move v3, v4

    :cond_13a
    invoke-virtual {v5}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object p1, v5, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast p1, Lads_mobile_sdk/md;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v3}, Lrt2;->a(I)I

    move-result v3

    invoke-static {p1, v3}, Lads_mobile_sdk/md;->f(Lads_mobile_sdk/md;I)V

    invoke-static {p1}, Lads_mobile_sdk/md;->c(Lads_mobile_sdk/md;)I

    move-result v3

    or-int/lit16 v3, v3, 0x400

    invoke-static {p1, v3}, Lads_mobile_sdk/md;->d(Lads_mobile_sdk/md;I)V

    :cond_154
    monitor-enter p2
    :try_end_155
    .catchall {:try_start_13 .. :try_end_155} :catchall_65

    :try_start_155
    invoke-virtual {p0, p2}, Lads_mobile_sdk/d03;->a(Lwy2;)V

    iget-object p1, p0, Lads_mobile_sdk/d03;->h:Ljava/util/Map;

    const-string v3, "oe"

    invoke-interface {p1, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lads_mobile_sdk/w61;

    if-nez p1, :cond_165

    goto :goto_1c6

    :cond_165
    iget-wide v8, p1, Lads_mobile_sdk/w61;->a:J

    cmp-long v3, v8, v6

    if-lez v3, :cond_17d

    invoke-virtual {p2}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v3, p2, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v3, Lads_mobile_sdk/pd;

    invoke-static {v3}, Lads_mobile_sdk/pd;->d(Lads_mobile_sdk/pd;)I

    move-result v10

    or-int/2addr v2, v10

    invoke-static {v3, v2}, Lads_mobile_sdk/pd;->s(Lads_mobile_sdk/pd;I)V

    invoke-static {v3, v8, v9}, Lads_mobile_sdk/pd;->S(Lads_mobile_sdk/pd;J)V

    :cond_17d
    iget-wide v2, p1, Lads_mobile_sdk/w61;->b:J

    cmp-long v8, v2, v6

    if-lez v8, :cond_195

    invoke-virtual {p2}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v8, p2, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v8, Lads_mobile_sdk/pd;

    invoke-static {v8}, Lads_mobile_sdk/pd;->d(Lads_mobile_sdk/pd;)I

    move-result v9

    or-int/2addr v1, v9

    invoke-static {v8, v1}, Lads_mobile_sdk/pd;->s(Lads_mobile_sdk/pd;I)V

    invoke-static {v8, v2, v3}, Lads_mobile_sdk/pd;->T(Lads_mobile_sdk/pd;J)V

    :cond_195
    iget-wide v1, p1, Lads_mobile_sdk/w61;->c:J

    cmp-long v3, v1, v6

    if-lez v3, :cond_1ad

    invoke-virtual {p2}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v3, p2, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v3, Lads_mobile_sdk/pd;

    invoke-static {v3}, Lads_mobile_sdk/pd;->d(Lads_mobile_sdk/pd;)I

    move-result v8

    or-int/2addr v4, v8

    invoke-static {v3, v4}, Lads_mobile_sdk/pd;->s(Lads_mobile_sdk/pd;I)V

    invoke-static {v3, v1, v2}, Lads_mobile_sdk/pd;->W(Lads_mobile_sdk/pd;J)V

    :cond_1ad
    iget-wide v1, p1, Lads_mobile_sdk/w61;->d:J

    cmp-long p1, v1, v6

    if-lez p1, :cond_1c6

    invoke-virtual {p2}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object p1, p2, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast p1, Lads_mobile_sdk/pd;

    invoke-static {p1}, Lads_mobile_sdk/pd;->d(Lads_mobile_sdk/pd;)I

    move-result v3

    or-int/lit8 v3, v3, 0x10

    invoke-static {p1, v3}, Lads_mobile_sdk/pd;->s(Lads_mobile_sdk/pd;I)V

    invoke-static {p1, v1, v2}, Lads_mobile_sdk/pd;->Q(Lads_mobile_sdk/pd;J)V

    :cond_1c6
    :goto_1c6
    invoke-virtual {p0, v5}, Lads_mobile_sdk/d03;->a(Lt03;)V

    invoke-virtual {p2}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object p1, p2, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast p1, Lads_mobile_sdk/pd;

    invoke-virtual {v5}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object v1

    check-cast v1, Lads_mobile_sdk/md;

    invoke-virtual {p1, v1}, Lads_mobile_sdk/pd;->b(Lads_mobile_sdk/md;)V

    invoke-virtual {p0, p2}, Lads_mobile_sdk/d03;->b(Lwy2;)V

    monitor-exit p2
    :try_end_1dd
    .catchall {:try_start_155 .. :try_end_1dd} :catchall_1e3

    if-eqz v0, :cond_1e2

    invoke-virtual {v0}, Landroid/view/MotionEvent;->recycle()V

    :cond_1e2
    return-void

    :catchall_1e3
    move-exception p0

    :try_start_1e4
    monitor-exit p2
    :try_end_1e5
    .catchall {:try_start_1e4 .. :try_end_1e5} :catchall_1e3

    :try_start_1e5
    throw p0
    :try_end_1e6
    .catchall {:try_start_1e5 .. :try_end_1e6} :catchall_65

    :goto_1e6
    if-eqz v0, :cond_1eb

    invoke-virtual {v0}, Landroid/view/MotionEvent;->recycle()V

    :cond_1eb
    throw p0

    :pswitch_1ec  #0x0
    const-wide/16 v5, -0x1

    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    iget-object v5, p0, Lads_mobile_sdk/d03;->f:Ljava/lang/Object;

    check-cast v5, Lads_mobile_sdk/ga3;

    invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I

    move-result v5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    iget-object v6, p0, Lads_mobile_sdk/d03;->g:Ljava/lang/Object;

    check-cast v6, Landroid/content/Context;

    iget-object v7, p0, Lads_mobile_sdk/d03;->h:Ljava/util/Map;

    const-string v8, "up"

    invoke-interface {v7, v8}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    sget-object v8, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    if-eqz v7, :cond_20f

    goto :goto_210

    :cond_20f
    move-object v7, v8

    :goto_210
    filled-new-array {v5, v6, v7}, [Ljava/lang/Object;

    move-result-object v5

    const-string v6, ""

    invoke-virtual {p1, v6, v5}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, [Ljava/lang/Object;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    monitor-enter p2

    :try_start_220
    iget-object p0, p0, Lads_mobile_sdk/d03;->f:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/ga3;

    sget-object v5, Lads_mobile_sdk/ga3;->a:Lads_mobile_sdk/ga3;

    if-ne p0, v5, :cond_26a

    aget-object p0, p1, v2

    if-eqz p0, :cond_22d

    goto :goto_22e

    :cond_22d
    move-object p0, v0

    :goto_22e
    check-cast p0, Ljava/lang/Long;

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v5

    invoke-virtual {p2}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object p0, p2, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast p0, Lads_mobile_sdk/pd;

    invoke-static {p0}, Lads_mobile_sdk/pd;->c(Lads_mobile_sdk/pd;)I

    move-result v2

    const/high16 v7, 0x2000000

    or-int/2addr v2, v7

    invoke-static {p0, v2}, Lads_mobile_sdk/pd;->r(Lads_mobile_sdk/pd;I)V

    invoke-static {p0, v5, v6}, Lads_mobile_sdk/pd;->f0(Lads_mobile_sdk/pd;J)V

    aget-object p0, p1, v3

    if-eqz p0, :cond_24d

    move-object v0, p0

    :cond_24d
    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    invoke-virtual {p2}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object p0, p2, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast p0, Lads_mobile_sdk/pd;

    invoke-static {p0}, Lads_mobile_sdk/pd;->c(Lads_mobile_sdk/pd;)I

    move-result v0

    const/high16 v5, 0x4000000

    or-int/2addr v0, v5

    invoke-static {p0, v0}, Lads_mobile_sdk/pd;->r(Lads_mobile_sdk/pd;I)V

    invoke-static {p0, v2, v3}, Lads_mobile_sdk/pd;->a0(Lads_mobile_sdk/pd;J)V

    goto :goto_26a

    :catchall_268
    move-exception p0

    goto :goto_2a3

    :cond_26a
    :goto_26a
    aget-object p0, p1, v4

    check-cast p0, Ljava/lang/Long;

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    invoke-virtual {p2}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object p0, p2, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast p0, Lads_mobile_sdk/pd;

    invoke-static {p0}, Lads_mobile_sdk/pd;->c(Lads_mobile_sdk/pd;)I

    move-result v0

    or-int/lit16 v0, v0, 0x800

    invoke-static {p0, v0}, Lads_mobile_sdk/pd;->r(Lads_mobile_sdk/pd;I)V

    invoke-static {p0, v2, v3}, Lads_mobile_sdk/pd;->K(Lads_mobile_sdk/pd;J)V

    aget-object p0, p1, v1

    check-cast p0, Ljava/lang/Long;

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide p0

    invoke-virtual {p2}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v0, p2, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v0, Lads_mobile_sdk/pd;

    invoke-static {v0}, Lads_mobile_sdk/pd;->d(Lads_mobile_sdk/pd;)I

    move-result v1

    const/high16 v2, 0x800000

    or-int/2addr v1, v2

    invoke-static {v0, v1}, Lads_mobile_sdk/pd;->s(Lads_mobile_sdk/pd;I)V

    invoke-static {v0, p0, p1}, Lads_mobile_sdk/pd;->P(Lads_mobile_sdk/pd;J)V

    monitor-exit p2

    return-void

    :goto_2a3
    monitor-exit p2
    :try_end_2a4
    .catchall {:try_start_220 .. :try_end_2a4} :catchall_268

    throw p0

    nop

    :pswitch_data_2a6
    .packed-switch 0x0
        :pswitch_1ec  #00000000
    .end packed-switch
.end method

.method public a(Lt03;)V
    .registers 11

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/d03;->g:Ljava/lang/Object;

    check-cast v0, Landroid/util/DisplayMetrics;

    const-string v1, "oe"

    iget-object p0, p0, Lads_mobile_sdk/d03;->h:Ljava/util/Map;

    invoke-interface {p0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lads_mobile_sdk/w61;

    if-nez v1, :cond_12

    goto/16 :goto_12a

    :cond_12
    iget-wide v2, v1, Lads_mobile_sdk/w61;->a:J

    const-wide/16 v4, 0x0

    cmp-long v2, v2, v4

    if-eqz v2, :cond_12a

    if-eqz v0, :cond_12a

    iget v2, v0, Landroid/util/DisplayMetrics;->density:F

    const/4 v3, 0x0

    cmpl-float v3, v2, v3

    if-eqz v3, :cond_12a

    iget-wide v6, v1, Lads_mobile_sdk/w61;->g:D

    float-to-double v2, v2

    div-double/2addr v6, v2

    invoke-static {v6, v7}, Ljava/lang/Math;->round(D)J

    move-result-wide v2

    invoke-virtual {p1}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v6, p1, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v6, Lads_mobile_sdk/md;

    invoke-static {v6}, Lads_mobile_sdk/md;->c(Lads_mobile_sdk/md;)I

    move-result v7

    or-int/lit16 v7, v7, 0x1000

    invoke-static {v6, v7}, Lads_mobile_sdk/md;->d(Lads_mobile_sdk/md;I)V

    invoke-static {v6, v2, v3}, Lads_mobile_sdk/md;->h(Lads_mobile_sdk/md;J)V

    iget v2, v1, Lads_mobile_sdk/w61;->j:F

    iget v3, v1, Lads_mobile_sdk/w61;->h:F

    sub-float/2addr v2, v3

    float-to-double v2, v2

    iget v6, v0, Landroid/util/DisplayMetrics;->density:F

    float-to-double v6, v6

    div-double/2addr v2, v6

    invoke-static {v2, v3}, Ljava/lang/Math;->round(D)J

    move-result-wide v2

    invoke-virtual {p1}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v6, p1, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v6, Lads_mobile_sdk/md;

    invoke-static {v6}, Lads_mobile_sdk/md;->c(Lads_mobile_sdk/md;)I

    move-result v7

    or-int/lit16 v7, v7, 0x2000

    invoke-static {v6, v7}, Lads_mobile_sdk/md;->d(Lads_mobile_sdk/md;I)V

    invoke-static {v6, v2, v3}, Lads_mobile_sdk/md;->x(Lads_mobile_sdk/md;J)V

    iget v2, v1, Lads_mobile_sdk/w61;->k:F

    iget v3, v1, Lads_mobile_sdk/w61;->i:F

    sub-float/2addr v2, v3

    float-to-double v2, v2

    iget v6, v0, Landroid/util/DisplayMetrics;->density:F

    float-to-double v6, v6

    div-double/2addr v2, v6

    invoke-static {v2, v3}, Ljava/lang/Math;->round(D)J

    move-result-wide v2

    invoke-virtual {p1}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v6, p1, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v6, Lads_mobile_sdk/md;

    invoke-static {v6}, Lads_mobile_sdk/md;->c(Lads_mobile_sdk/md;)I

    move-result v7

    or-int/lit16 v7, v7, 0x4000

    invoke-static {v6, v7}, Lads_mobile_sdk/md;->d(Lads_mobile_sdk/md;I)V

    invoke-static {v6, v2, v3}, Lads_mobile_sdk/md;->y(Lads_mobile_sdk/md;J)V

    iget v2, v1, Lads_mobile_sdk/w61;->h:F

    float-to-double v2, v2

    iget v6, v0, Landroid/util/DisplayMetrics;->density:F

    float-to-double v6, v6

    div-double/2addr v2, v6

    invoke-static {v2, v3}, Ljava/lang/Math;->round(D)J

    move-result-wide v2

    invoke-virtual {p1}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v6, p1, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v6, Lads_mobile_sdk/md;

    invoke-static {v6}, Lads_mobile_sdk/md;->c(Lads_mobile_sdk/md;)I

    move-result v7

    const/high16 v8, 0x20000

    or-int/2addr v7, v8

    invoke-static {v6, v7}, Lads_mobile_sdk/md;->d(Lads_mobile_sdk/md;I)V

    invoke-static {v6, v2, v3}, Lads_mobile_sdk/md;->q(Lads_mobile_sdk/md;J)V

    iget v2, v1, Lads_mobile_sdk/w61;->i:F

    float-to-double v2, v2

    iget v6, v0, Landroid/util/DisplayMetrics;->density:F

    float-to-double v6, v6

    div-double/2addr v2, v6

    invoke-static {v2, v3}, Ljava/lang/Math;->round(D)J

    move-result-wide v2

    invoke-virtual {p1}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v6, p1, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v6, Lads_mobile_sdk/md;

    invoke-static {v6}, Lads_mobile_sdk/md;->c(Lads_mobile_sdk/md;)I

    move-result v7

    const/high16 v8, 0x40000

    or-int/2addr v7, v8

    invoke-static {v6, v7}, Lads_mobile_sdk/md;->d(Lads_mobile_sdk/md;I)V

    invoke-static {v6, v2, v3}, Lads_mobile_sdk/md;->s(Lads_mobile_sdk/md;J)V

    const-string v2, "nv"

    invoke-interface {p0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/view/MotionEvent;

    if-nez p0, :cond_c9

    goto :goto_12a

    :cond_c9
    iget v2, v1, Lads_mobile_sdk/w61;->h:F

    iget v3, v1, Lads_mobile_sdk/w61;->j:F

    sub-float/2addr v2, v3

    invoke-virtual {p0}, Landroid/view/MotionEvent;->getRawX()F

    move-result v3

    add-float/2addr v3, v2

    invoke-virtual {p0}, Landroid/view/MotionEvent;->getX()F

    move-result v2

    sub-float/2addr v3, v2

    float-to-double v2, v3

    iget v6, v0, Landroid/util/DisplayMetrics;->density:F

    float-to-double v6, v6

    div-double/2addr v2, v6

    invoke-static {v2, v3}, Ljava/lang/Math;->round(D)J

    move-result-wide v2

    cmp-long v6, v2, v4

    if-eqz v6, :cond_fa

    invoke-virtual {p1}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v6, p1, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v6, Lads_mobile_sdk/md;

    invoke-static {v6}, Lads_mobile_sdk/md;->c(Lads_mobile_sdk/md;)I

    move-result v7

    const v8, 0x8000

    or-int/2addr v7, v8

    invoke-static {v6, v7}, Lads_mobile_sdk/md;->d(Lads_mobile_sdk/md;I)V

    invoke-static {v6, v2, v3}, Lads_mobile_sdk/md;->v(Lads_mobile_sdk/md;J)V

    :cond_fa
    iget v2, v1, Lads_mobile_sdk/w61;->i:F

    iget v1, v1, Lads_mobile_sdk/w61;->k:F

    sub-float/2addr v2, v1

    invoke-virtual {p0}, Landroid/view/MotionEvent;->getRawY()F

    move-result v1

    add-float/2addr v1, v2

    invoke-virtual {p0}, Landroid/view/MotionEvent;->getY()F

    move-result p0

    sub-float/2addr v1, p0

    float-to-double v1, v1

    iget p0, v0, Landroid/util/DisplayMetrics;->density:F

    float-to-double v6, p0

    div-double/2addr v1, v6

    invoke-static {v1, v2}, Ljava/lang/Math;->round(D)J

    move-result-wide v0

    cmp-long p0, v0, v4

    if-eqz p0, :cond_12a

    invoke-virtual {p1}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object p0, p1, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast p0, Lads_mobile_sdk/md;

    invoke-static {p0}, Lads_mobile_sdk/md;->c(Lads_mobile_sdk/md;)I

    move-result p1

    const/high16 v2, 0x10000

    or-int/2addr p1, v2

    invoke-static {p0, p1}, Lads_mobile_sdk/md;->d(Lads_mobile_sdk/md;I)V

    invoke-static {p0, v0, v1}, Lads_mobile_sdk/md;->w(Lads_mobile_sdk/md;J)V

    :cond_12a
    :goto_12a
    return-void
.end method

.method public a(Lwy2;)V
    .registers 7

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/d03;->f:Ljava/lang/Object;

    check-cast v0, Lads_mobile_sdk/rp1;

    const-string v1, "VdziiBjAZXOVT0kD+N4+c4vQx7ti0Laa7nbvPHN+ohyV2LUCcHCx4QQavv/ahO4h"

    const-string v2, "t14stIcIGMDoWrbZ8CjaBf4GZLucaYzz/xYRv6GCoW8="

    invoke-virtual {v0, v1, v2}, Lads_mobile_sdk/rp1;->a(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/reflect/Method;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v1, p0, Lads_mobile_sdk/d03;->h:Ljava/util/Map;

    const-string v2, "nv"

    invoke-interface {v1, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/view/MotionEvent;

    iget-object p0, p0, Lads_mobile_sdk/d03;->g:Ljava/lang/Object;

    check-cast p0, Landroid/util/DisplayMetrics;

    filled-new-array {v1, p0}, [Ljava/lang/Object;

    move-result-object p0

    const-string v1, ""

    invoke-virtual {v0, v1, p0}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, [Ljava/lang/Object;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x0

    aget-object v0, p0, v0

    if-eqz v0, :cond_4a

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    invoke-virtual {p1}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v2, p1, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v2, Lads_mobile_sdk/pd;

    invoke-static {v2}, Lads_mobile_sdk/pd;->c(Lads_mobile_sdk/pd;)I

    move-result v3

    or-int/lit16 v3, v3, 0x2000

    invoke-static {v2, v3}, Lads_mobile_sdk/pd;->r(Lads_mobile_sdk/pd;I)V

    invoke-static {v2, v0, v1}, Lads_mobile_sdk/pd;->X(Lads_mobile_sdk/pd;J)V

    :cond_4a
    const/4 v0, 0x1

    aget-object v0, p0, v0

    if-eqz v0, :cond_68

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    invoke-virtual {p1}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v2, p1, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v2, Lads_mobile_sdk/pd;

    invoke-static {v2}, Lads_mobile_sdk/pd;->c(Lads_mobile_sdk/pd;)I

    move-result v3

    or-int/lit16 v3, v3, 0x4000

    invoke-static {v2, v3}, Lads_mobile_sdk/pd;->r(Lads_mobile_sdk/pd;I)V

    invoke-static {v2, v0, v1}, Lads_mobile_sdk/pd;->Y(Lads_mobile_sdk/pd;J)V

    :cond_68
    const/4 v0, 0x2

    aget-object v0, p0, v0

    if-eqz v0, :cond_88

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    invoke-virtual {p1}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v2, p1, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v2, Lads_mobile_sdk/pd;

    invoke-static {v2}, Lads_mobile_sdk/pd;->c(Lads_mobile_sdk/pd;)I

    move-result v3

    const v4, 0x8000

    or-int/2addr v3, v4

    invoke-static {v2, v3}, Lads_mobile_sdk/pd;->r(Lads_mobile_sdk/pd;I)V

    invoke-static {v2, v0, v1}, Lads_mobile_sdk/pd;->V(Lads_mobile_sdk/pd;J)V

    :cond_88
    const/4 v0, 0x3

    aget-object v0, p0, v0

    if-eqz v0, :cond_a7

    check-cast v0, Ljava/lang/Long;

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    invoke-virtual {p1}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v2, p1, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v2, Lads_mobile_sdk/pd;

    invoke-static {v2}, Lads_mobile_sdk/pd;->c(Lads_mobile_sdk/pd;)I

    move-result v3

    const/high16 v4, 0x40000000  # 2.0f

    or-int/2addr v3, v4

    invoke-static {v2, v3}, Lads_mobile_sdk/pd;->r(Lads_mobile_sdk/pd;I)V

    invoke-static {v2, v0, v1}, Lads_mobile_sdk/pd;->U(Lads_mobile_sdk/pd;J)V

    :cond_a7
    const/4 v0, 0x4

    aget-object p0, p0, v0

    if-eqz p0, :cond_c6

    check-cast p0, Ljava/lang/Long;

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    invoke-virtual {p1}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object p0, p1, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast p0, Lads_mobile_sdk/pd;

    invoke-static {p0}, Lads_mobile_sdk/pd;->c(Lads_mobile_sdk/pd;)I

    move-result p1

    const/high16 v2, -0x80000000

    or-int/2addr p1, v2

    invoke-static {p0, p1}, Lads_mobile_sdk/pd;->r(Lads_mobile_sdk/pd;I)V

    invoke-static {p0, v0, v1}, Lads_mobile_sdk/pd;->R(Lads_mobile_sdk/pd;J)V

    :cond_c6
    return-void
.end method

.method public b(Lwy2;)V
    .registers 10

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/d03;->g:Ljava/lang/Object;

    check-cast v0, Landroid/util/DisplayMetrics;

    iget-object p0, p0, Lads_mobile_sdk/d03;->h:Ljava/util/Map;

    const-string v1, "ro"

    invoke-interface {p0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, [Lads_mobile_sdk/x61;

    if-eqz p0, :cond_74

    if-eqz v0, :cond_74

    iget v1, v0, Landroid/util/DisplayMetrics;->density:F

    const/4 v2, 0x0

    cmpl-float v1, v1, v2

    if-eqz v1, :cond_74

    const/4 v1, 0x0

    :goto_1a
    array-length v2, p0

    add-int/lit8 v2, v2, -0x2

    if-gt v1, v2, :cond_74

    aget-object v2, p0, v1

    invoke-static {}, Lads_mobile_sdk/md;->o()Lt03;

    move-result-object v3

    iget v4, v2, Lads_mobile_sdk/x61;->a:F

    float-to-double v4, v4

    iget v6, v0, Landroid/util/DisplayMetrics;->density:F

    float-to-double v6, v6

    div-double/2addr v4, v6

    invoke-static {v4, v5}, Ljava/lang/Math;->round(D)J

    move-result-wide v4

    invoke-virtual {v3}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v6, v3, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v6, Lads_mobile_sdk/md;

    invoke-static {v6}, Lads_mobile_sdk/md;->c(Lads_mobile_sdk/md;)I

    move-result v7

    or-int/lit8 v7, v7, 0x1

    invoke-static {v6, v7}, Lads_mobile_sdk/md;->d(Lads_mobile_sdk/md;I)V

    invoke-static {v6, v4, v5}, Lads_mobile_sdk/md;->r(Lads_mobile_sdk/md;J)V

    iget v2, v2, Lads_mobile_sdk/x61;->b:F

    float-to-double v4, v2

    iget v2, v0, Landroid/util/DisplayMetrics;->density:F

    float-to-double v6, v2

    div-double/2addr v4, v6

    invoke-static {v4, v5}, Ljava/lang/Math;->round(D)J

    move-result-wide v4

    invoke-virtual {v3}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v2, v3, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v2, Lads_mobile_sdk/md;

    invoke-static {v2}, Lads_mobile_sdk/md;->c(Lads_mobile_sdk/md;)I

    move-result v6

    or-int/lit8 v6, v6, 0x2

    invoke-static {v2, v6}, Lads_mobile_sdk/md;->d(Lads_mobile_sdk/md;I)V

    invoke-static {v2, v4, v5}, Lads_mobile_sdk/md;->t(Lads_mobile_sdk/md;J)V

    invoke-virtual {v3}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object v2

    check-cast v2, Lads_mobile_sdk/md;

    invoke-virtual {p1}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v3, p1, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v3, Lads_mobile_sdk/pd;

    invoke-virtual {v3, v2}, Lads_mobile_sdk/pd;->a(Lads_mobile_sdk/md;)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_1a

    :cond_74
    return-void
.end method
