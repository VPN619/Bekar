.class public final Lads_mobile_sdk/eo2;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public final synthetic a:Lads_mobile_sdk/uo2;

.field public final synthetic t:I


# direct methods
.method public synthetic constructor <init>(Lads_mobile_sdk/uo2;Lvx;I)V
    .registers 4

    iput p3, p0, Lads_mobile_sdk/eo2;->t:I

    iput-object p1, p0, Lads_mobile_sdk/eo2;->a:Lads_mobile_sdk/uo2;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 4

    .prologue
    iget p2, p0, Lads_mobile_sdk/eo2;->t:I

    iget-object p0, p0, Lads_mobile_sdk/eo2;->a:Lads_mobile_sdk/uo2;

    packed-switch p2, :pswitch_data_16

    new-instance p2, Lads_mobile_sdk/eo2;

    const/4 v0, 0x1

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/eo2;-><init>(Lads_mobile_sdk/uo2;Lvx;I)V

    return-object p2

    :pswitch_e  #0x0
    new-instance p2, Lads_mobile_sdk/eo2;

    const/4 v0, 0x0

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/eo2;-><init>(Lads_mobile_sdk/uo2;Lvx;I)V

    return-object p2

    nop

    :pswitch_data_16
    .packed-switch 0x0
        :pswitch_e  #00000000
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .prologue
    iget v0, p0, Lads_mobile_sdk/eo2;->t:I

    sget-object v1, Lrg2;->a:Lrg2;

    iget-object p0, p0, Lads_mobile_sdk/eo2;->a:Lads_mobile_sdk/uo2;

    packed-switch v0, :pswitch_data_26

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/eo2;

    const/4 v0, 0x1

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/eo2;-><init>(Lads_mobile_sdk/uo2;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/eo2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object v1

    :pswitch_17  #0x0
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/eo2;

    const/4 v0, 0x0

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/eo2;-><init>(Lads_mobile_sdk/uo2;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/eo2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object v1

    nop

    :pswitch_data_26
    .packed-switch 0x0
        :pswitch_17  #00000000
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .prologue
    iget v0, p0, Lads_mobile_sdk/eo2;->t:I

    sget-object v1, Lrg2;->a:Lrg2;

    const/4 v2, 0x0

    iget-object p0, p0, Lads_mobile_sdk/eo2;->a:Lads_mobile_sdk/uo2;

    packed-switch v0, :pswitch_data_b8

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/uo2;->u:Lads_mobile_sdk/ji;

    sget-object v0, Lads_mobile_sdk/uo2;->B:[Liy0;

    const/4 v3, 0x0

    aget-object v0, v0, v3

    invoke-virtual {p1, p0, v0}, Lads_mobile_sdk/ji;->getValue(Ljava/lang/Object;Liy0;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, La4;

    if-eqz p0, :cond_80

    new-instance p0, Ljava/lang/StringBuilder;

    const-string p1, "BannerAd(onAdRefreshed) isShown("

    invoke-direct {p0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    sget-object p1, Lg4;->n:Lx4;

    if-eqz p1, :cond_30

    invoke-virtual {p1}, Landroid/view/View;->isShown()Z

    move-result p1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    goto :goto_31

    :cond_30
    move-object p1, v2

    :goto_31
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p1, ") isHovered("

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object p1, Lg4;->n:Lx4;

    if-eqz p1, :cond_46

    invoke-virtual {p1}, Landroid/view/View;->isHovered()Z

    move-result p1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    goto :goto_47

    :cond_46
    move-object p1, v2

    :goto_47
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p1, ") width("

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object p1, Lg4;->n:Lx4;

    if-eqz p1, :cond_5c

    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result p1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    goto :goto_5d

    :cond_5c
    move-object p1, v2

    :goto_5d
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p1, ") height("

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object p1, Lg4;->n:Lx4;

    if-eqz p1, :cond_71

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result p1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    :cond_71
    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 p1, 0x29

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string p1, "Ads-Show"

    nop

    :cond_80
    return-object v1

    :pswitch_81  #0x0
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    new-instance p1, Lads_mobile_sdk/fv2;

    iget-object v0, p0, Lads_mobile_sdk/uo2;->s:Lph;

    iget-object v0, v0, Lph;->j:Ls4;

    iget-object v3, p0, Lads_mobile_sdk/uo2;->m:Landroid/content/Context;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p1, v3}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    iput-object v0, p1, Lads_mobile_sdk/fv2;->a:Ls4;

    iget v0, v0, Ls4;->b:I

    invoke-static {v3, v0}, Lt12;->a(Landroid/content/Context;I)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/View;->setMinimumHeight(I)V

    iget-object v0, p1, Lads_mobile_sdk/fv2;->a:Ls4;

    iget v0, v0, Ls4;->a:I

    invoke-static {v3, v0}, Lt12;->a(Landroid/content/Context;I)I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/View;->setMinimumWidth(I)V

    iput-object p1, p0, Lads_mobile_sdk/uo2;->y:Lads_mobile_sdk/fv2;

    iget-object v0, p0, Lads_mobile_sdk/uo2;->A:Lx4;

    if-eqz v0, :cond_b4

    invoke-virtual {v0, p1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    :cond_b4
    iput-object v2, p0, Lads_mobile_sdk/uo2;->A:Lx4;

    return-object v1

    nop

    :pswitch_data_b8
    .packed-switch 0x0
        :pswitch_81  #00000000
    .end packed-switch
.end method
