.class public final Lads_mobile_sdk/ek;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Lads_mobile_sdk/xq0;

.field public final b:Lnb1;

.field public final c:Ljava/util/LinkedHashMap;

.field public final d:Ljava/util/concurrent/ConcurrentHashMap;

.field public final e:Ljava/util/concurrent/ConcurrentHashMap;

.field public final f:Ljava/util/concurrent/atomic/AtomicInteger;

.field public final g:Ljava/util/concurrent/atomic/AtomicReference;

.field public final h:Ljava/util/concurrent/atomic/AtomicBoolean;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/xq0;)V
    .registers 4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/ek;->a:Lads_mobile_sdk/xq0;

    new-instance p1, Lnb1;

    invoke-direct {p1}, Lnb1;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/ek;->b:Lnb1;

    new-instance p1, Ljava/util/LinkedHashMap;

    invoke-direct {p1}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/ek;->c:Ljava/util/LinkedHashMap;

    new-instance p1, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {p1}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/ek;->d:Ljava/util/concurrent/ConcurrentHashMap;

    new-instance p1, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {p1}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/ek;->e:Ljava/util/concurrent/ConcurrentHashMap;

    new-instance p1, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v0, 0x0

    invoke-direct {p1, v0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    iput-object p1, p0, Lads_mobile_sdk/ek;->f:Ljava/util/concurrent/atomic/AtomicInteger;

    new-instance p1, Ljava/util/concurrent/atomic/AtomicReference;

    const-string v1, ""

    invoke-direct {p1, v1}, Ljava/util/concurrent/atomic/AtomicReference;-><init>(Ljava/lang/Object;)V

    iput-object p1, p0, Lads_mobile_sdk/ek;->g:Ljava/util/concurrent/atomic/AtomicReference;

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {p1, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object p1, p0, Lads_mobile_sdk/ek;->h:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-void
.end method

.method public static a(Lads_mobile_sdk/ek;Ljava/lang/String;Ljava/lang/String;Lvx;)Ljava/lang/Object;
    .registers 8

    .prologue
    instance-of v0, p3, Lads_mobile_sdk/bk;

    if-eqz v0, :cond_13

    move-object v0, p3

    check-cast v0, Lads_mobile_sdk/bk;

    iget v1, v0, Lads_mobile_sdk/bk;->g:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/bk;->g:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/bk;

    invoke-direct {v0, p0, p3}, Lads_mobile_sdk/bk;-><init>(Lads_mobile_sdk/ek;Lvx;)V

    :goto_18
    iget-object p3, v0, Lads_mobile_sdk/bk;->e:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/bk;->g:I

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v1, :cond_36

    if-ne v1, v2, :cond_30

    iget-object p0, v0, Lads_mobile_sdk/bk;->d:Lnb1;

    iget-object p2, v0, Lads_mobile_sdk/bk;->c:Ljava/lang/String;

    iget-object p1, v0, Lads_mobile_sdk/bk;->b:Ljava/lang/String;

    iget-object v0, v0, Lads_mobile_sdk/bk;->a:Lads_mobile_sdk/ek;

    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V

    move-object p3, p0

    move-object p0, v0

    goto :goto_4e

    :cond_30
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v3

    :cond_36
    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p3, p0, Lads_mobile_sdk/ek;->b:Lnb1;

    iput-object p0, v0, Lads_mobile_sdk/bk;->a:Lads_mobile_sdk/ek;

    iput-object p1, v0, Lads_mobile_sdk/bk;->b:Ljava/lang/String;

    iput-object p2, v0, Lads_mobile_sdk/bk;->c:Ljava/lang/String;

    iput-object p3, v0, Lads_mobile_sdk/bk;->d:Lnb1;

    iput v2, v0, Lads_mobile_sdk/bk;->g:I

    invoke-virtual {p3, v0}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v0

    sget-object v1, Lwy;->a:Lwy;

    if-ne v0, v1, :cond_4e

    return-object v1

    :cond_4e
    :goto_4e
    if-eqz p2, :cond_5f

    :try_start_50
    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v0

    if-nez v0, :cond_57

    goto :goto_5f

    :cond_57
    iget-object p0, p0, Lads_mobile_sdk/ek;->c:Ljava/util/LinkedHashMap;

    invoke-interface {p0, p1, p2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_64

    :catchall_5d
    move-exception p0

    goto :goto_6a

    :cond_5f
    :goto_5f
    iget-object p0, p0, Lads_mobile_sdk/ek;->c:Ljava/util/LinkedHashMap;

    invoke-interface {p0, p1}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_64
    .catchall {:try_start_50 .. :try_end_64} :catchall_5d

    :goto_64
    invoke-virtual {p3, v3}, Lnb1;->b(Ljava/lang/Object;)V

    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0

    :goto_6a
    invoke-virtual {p3, v3}, Lnb1;->b(Ljava/lang/Object;)V

    throw p0
.end method

.method public static a(Lads_mobile_sdk/ek;Lwx;)Ljava/lang/Object;
    .registers 6

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/qj;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/qj;

    iget v1, v0, Lads_mobile_sdk/qj;->e:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/qj;->e:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/qj;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/qj;-><init>(Lads_mobile_sdk/ek;Lwx;)V

    :goto_18
    iget-object p1, v0, Lads_mobile_sdk/qj;->c:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/qj;->e:I

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v1, :cond_30

    if-ne v1, v2, :cond_2a

    iget-object p0, v0, Lads_mobile_sdk/qj;->b:Lnb1;

    iget-object v0, v0, Lads_mobile_sdk/qj;->a:Lads_mobile_sdk/ek;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_46

    :cond_2a
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v3

    :cond_30
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/ek;->b:Lnb1;

    iput-object p0, v0, Lads_mobile_sdk/qj;->a:Lads_mobile_sdk/ek;

    iput-object p1, v0, Lads_mobile_sdk/qj;->b:Lnb1;

    iput v2, v0, Lads_mobile_sdk/qj;->e:I

    invoke-virtual {p1, v0}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v0

    sget-object v1, Lwy;->a:Lwy;

    if-ne v0, v1, :cond_44

    return-object v1

    :cond_44
    move-object v0, p0

    move-object p0, p1

    :goto_46
    :try_start_46
    iget-object p1, v0, Lads_mobile_sdk/ek;->c:Ljava/util/LinkedHashMap;
    :try_end_48
    .catchall {:try_start_46 .. :try_end_48} :catchall_50

    invoke-virtual {p0, v3}, Lnb1;->b(Ljava/lang/Object;)V

    invoke-static {p1}, Lb61;->T(Ljava/util/Map;)Ljava/util/Map;

    move-result-object p0

    return-object p0

    :catchall_50
    move-exception p1

    invoke-virtual {p0, v3}, Lnb1;->b(Ljava/lang/Object;)V

    throw p1
.end method
