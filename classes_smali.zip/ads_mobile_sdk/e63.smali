.class public final Lads_mobile_sdk/e63;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Lads_mobile_sdk/lw0;

.field public final b:Lads_mobile_sdk/dw0;

.field public final c:Lads_mobile_sdk/e43;


# direct methods
.method public synthetic constructor <init>(Lads_mobile_sdk/lw0;I)V
    .registers 4

    .prologue
    and-int/lit8 p2, p2, 0x2

    const/4 v0, 0x0

    if-eqz p2, :cond_7

    move-object p2, v0

    goto :goto_9

    :cond_7
    sget-object p2, Lads_mobile_sdk/dw0;->c:Lads_mobile_sdk/dw0;

    :goto_9
    invoke-direct {p0, p1, p2, v0}, Lads_mobile_sdk/e63;-><init>(Lads_mobile_sdk/lw0;Lads_mobile_sdk/dw0;Lads_mobile_sdk/e43;)V

    return-void
.end method

.method public constructor <init>(Lads_mobile_sdk/lw0;Lads_mobile_sdk/dw0;Lads_mobile_sdk/e43;)V
    .registers 4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/e63;->a:Lads_mobile_sdk/lw0;

    iput-object p2, p0, Lads_mobile_sdk/e63;->b:Lads_mobile_sdk/dw0;

    iput-object p3, p0, Lads_mobile_sdk/e63;->c:Lads_mobile_sdk/e43;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .prologue
    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lads_mobile_sdk/e63;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, Lads_mobile_sdk/e63;

    iget-object v1, p0, Lads_mobile_sdk/e63;->a:Lads_mobile_sdk/lw0;

    iget-object v3, p1, Lads_mobile_sdk/e63;->a:Lads_mobile_sdk/lw0;

    if-eq v1, v3, :cond_13

    return v2

    :cond_13
    iget-object v1, p0, Lads_mobile_sdk/e63;->b:Lads_mobile_sdk/dw0;

    iget-object v3, p1, Lads_mobile_sdk/e63;->b:Lads_mobile_sdk/dw0;

    if-eq v1, v3, :cond_1a

    return v2

    :cond_1a
    iget-object p0, p0, Lads_mobile_sdk/e63;->c:Lads_mobile_sdk/e43;

    iget-object p1, p1, Lads_mobile_sdk/e63;->c:Lads_mobile_sdk/e43;

    invoke-static {p0, p1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_25

    return v2

    :cond_25
    return v0
.end method

.method public final hashCode()I
    .registers 4

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/e63;->a:Lads_mobile_sdk/lw0;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    const/4 v1, 0x0

    iget-object v2, p0, Lads_mobile_sdk/e63;->b:Lads_mobile_sdk/dw0;

    if-nez v2, :cond_f

    move v2, v1

    goto :goto_13

    :cond_f
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_13
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-object p0, p0, Lads_mobile_sdk/e63;->c:Lads_mobile_sdk/e43;

    if-nez p0, :cond_1b

    goto :goto_1f

    :cond_1b
    invoke-virtual {p0}, Lads_mobile_sdk/ku0;->hashCode()I

    move-result v1

    :goto_1f
    add-int/2addr v0, v1

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "SignalMeta(signalId="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lads_mobile_sdk/e63;->a:Lads_mobile_sdk/lw0;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", cacheState="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lads_mobile_sdk/e63;->b:Lads_mobile_sdk/dw0;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", signalData="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, Lads_mobile_sdk/e63;->c:Lads_mobile_sdk/e43;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
