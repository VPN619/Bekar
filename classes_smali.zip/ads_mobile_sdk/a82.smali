.class public final Lads_mobile_sdk/a82;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lrk0;


# instance fields
.field public synthetic a:Lads_mobile_sdk/q6;

.field public final synthetic b:Lads_mobile_sdk/b82;

.field public final synthetic c:Landroid/view/View;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/b82;Landroid/view/View;Lvx;)V
    .registers 4

    iput-object p1, p0, Lads_mobile_sdk/a82;->b:Lads_mobile_sdk/b82;

    iput-object p2, p0, Lads_mobile_sdk/a82;->c:Landroid/view/View;

    const/4 p1, 0x3

    invoke-direct {p0, p1, p3}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    check-cast p1, Lads_mobile_sdk/cy0;

    check-cast p2, Lads_mobile_sdk/q6;

    check-cast p3, Lvx;

    new-instance p1, Lads_mobile_sdk/a82;

    iget-object v0, p0, Lads_mobile_sdk/a82;->b:Lads_mobile_sdk/b82;

    iget-object p0, p0, Lads_mobile_sdk/a82;->c:Landroid/view/View;

    invoke-direct {p1, v0, p0, p3}, Lads_mobile_sdk/a82;-><init>(Lads_mobile_sdk/b82;Landroid/view/View;Lvx;)V

    iput-object p2, p1, Lads_mobile_sdk/a82;->a:Lads_mobile_sdk/q6;

    sget-object p0, Lrg2;->a:Lrg2;

    invoke-virtual {p1, p0}, Lads_mobile_sdk/a82;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/a82;->a:Lads_mobile_sdk/q6;

    iget-object v0, p0, Lads_mobile_sdk/a82;->b:Lads_mobile_sdk/b82;

    iget-object v1, v0, Lads_mobile_sdk/b82;->f:Lads_mobile_sdk/s52;

    iget-object p0, p0, Lads_mobile_sdk/a82;->c:Landroid/view/View;

    invoke-virtual {v1, p1, p0}, Lads_mobile_sdk/s52;->a(Lads_mobile_sdk/q6;Landroid/view/View;)Lrg2;

    iget-object p1, v0, Lads_mobile_sdk/b82;->n:Ljava/util/List;

    invoke-interface {p1, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method
