.class public final Lads_mobile_sdk/dl;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Lads_mobile_sdk/uv2;

.field public final b:Lads_mobile_sdk/gp3;

.field public final c:Lads_mobile_sdk/vz;

.field public final d:Ln63;

.field public final e:Lads_mobile_sdk/qr0;

.field public final f:Lads_mobile_sdk/ah3;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/uv2;Lads_mobile_sdk/gp3;Lads_mobile_sdk/vz;Ln63;Lads_mobile_sdk/qr0;Lads_mobile_sdk/ah3;)V
    .registers 7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/dl;->a:Lads_mobile_sdk/uv2;

    iput-object p2, p0, Lads_mobile_sdk/dl;->b:Lads_mobile_sdk/gp3;

    iput-object p3, p0, Lads_mobile_sdk/dl;->c:Lads_mobile_sdk/vz;

    iput-object p4, p0, Lads_mobile_sdk/dl;->d:Ln63;

    iput-object p5, p0, Lads_mobile_sdk/dl;->e:Lads_mobile_sdk/qr0;

    iput-object p6, p0, Lads_mobile_sdk/dl;->f:Lads_mobile_sdk/ah3;

    return-void
.end method


# virtual methods
.method public final a(Landroid/net/Uri;Lwx;)Ljava/lang/Object;
    .registers 12

    .prologue
    instance-of v0, p2, Lads_mobile_sdk/zk;

    if-eqz v0, :cond_13

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/zk;

    iget v1, v0, Lads_mobile_sdk/zk;->e:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/zk;->e:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/zk;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/zk;-><init>(Lads_mobile_sdk/dl;Lwx;)V

    :goto_18
    iget-object p2, v0, Lads_mobile_sdk/zk;->c:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/zk;->e:I

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v1, :cond_32

    if-ne v1, v2, :cond_2c

    iget-object p0, v0, Lads_mobile_sdk/zk;->b:Lads_mobile_sdk/rg3;

    iget-object p1, v0, Lads_mobile_sdk/zk;->a:Lads_mobile_sdk/rg3;

    :try_start_26
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_29
    .catchall {:try_start_26 .. :try_end_29} :catchall_2a

    goto :goto_76

    :catchall_2a
    move-exception p2

    goto :goto_8b

    :cond_2c
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v3

    :cond_32
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    sget-object p2, Lads_mobile_sdk/hh3;->a:Ljava/util/WeakHashMap;

    sget-object p2, Lba0;->a:Lba0;

    sget-object v1, Lads_mobile_sdk/fw0;->v0:Lads_mobile_sdk/fw0;

    invoke-static {v1, p2, v2}, Lads_mobile_sdk/hh3;->a(Lads_mobile_sdk/fw0;Ljava/util/List;Z)Lads_mobile_sdk/rg3;

    move-result-object p2

    :try_start_3f
    sget-object v1, Lads_mobile_sdk/ax0;->f:Lzn1;

    iget-object v4, p0, Lads_mobile_sdk/dl;->e:Lads_mobile_sdk/qr0;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v5, "gads:source_registration_timeout_in_millis"

    sget-object v6, Lv60;->b:Lp80;

    sget-object v6, Ly60;->f:Ly60;

    invoke-static {v2, v6}, Li10;->G0(ILy60;)J

    move-result-wide v6

    new-instance v8, Lv60;

    invoke-direct {v8, v6, v7}, Lv60;-><init>(J)V

    sget-object v6, Lads_mobile_sdk/fo;->a$18:Lads_mobile_sdk/fo;

    invoke-virtual {v4, v5, v8, v6}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lv60;

    iget-wide v4, v4, Lv60;->a:J

    new-instance v6, Lads_mobile_sdk/al;

    invoke-direct {v6, p0, p1, v3}, Lads_mobile_sdk/al;-><init>(Lads_mobile_sdk/dl;Landroid/net/Uri;Lvx;)V

    iput-object p2, v0, Lads_mobile_sdk/zk;->a:Lads_mobile_sdk/rg3;

    iput-object p2, v0, Lads_mobile_sdk/zk;->b:Lads_mobile_sdk/rg3;

    iput v2, v0, Lads_mobile_sdk/zk;->e:I

    invoke-virtual {v1, v4, v5, v6, v0}, Lzn1;->d(JLbk0;Lwx;)Ljava/lang/Object;

    move-result-object p0
    :try_end_6e
    .catchall {:try_start_3f .. :try_end_6e} :catchall_87

    sget-object p1, Lwy;->a:Lwy;

    if-ne p0, p1, :cond_73

    return-object p1

    :cond_73
    move-object p1, p2

    move-object p2, p0

    move-object p0, p1

    :goto_76
    :try_start_76
    check-cast p2, Lb13;

    instance-of v0, p2, Lads_mobile_sdk/av0;

    if-eqz v0, :cond_83

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/av0;

    const/4 v1, 0x0

    invoke-static {v0, v1}, Lads_mobile_sdk/xh3;->a(Lads_mobile_sdk/av0;Z)V
    :try_end_83
    .catchall {:try_start_76 .. :try_end_83} :catchall_2a

    :cond_83
    invoke-static {p0, v3}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object p2

    :catchall_87
    move-exception p0

    move-object p1, p2

    move-object p2, p0

    move-object p0, p1

    :goto_8b
    :try_start_8b
    invoke-virtual {p1, p2}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v0, p2, Lox2;

    if-nez v0, :cond_ba

    invoke-virtual {p1, p2}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of p1, p2, Lza2;

    if-nez p1, :cond_b2

    instance-of p1, p2, Ljava/util/concurrent/CancellationException;

    if-nez p1, :cond_aa

    instance-of p1, p2, Lads_mobile_sdk/mv0;

    if-eqz p1, :cond_a4

    throw p2

    :catchall_a2
    move-exception p1

    goto :goto_bb

    :cond_a4
    new-instance p1, Lads_mobile_sdk/tu0;

    invoke-direct {p1, p2}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw p1

    :cond_aa
    new-instance p1, Lads_mobile_sdk/ou0;

    check-cast p2, Ljava/util/concurrent/CancellationException;

    invoke-direct {p1, p2}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw p1

    :cond_b2
    new-instance p1, Lads_mobile_sdk/uw0;

    check-cast p2, Lza2;

    invoke-direct {p1, p2}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw p1

    :cond_ba
    throw p2
    :try_end_bb
    .catchall {:try_start_8b .. :try_end_bb} :catchall_a2

    :goto_bb
    :try_start_bb
    throw p1
    :try_end_bc
    .catchall {:try_start_bb .. :try_end_bc} :catchall_bc

    :catchall_bc
    move-exception p2

    invoke-static {p0, p1}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw p2
.end method

.method public final b(Landroid/net/Uri;Lwx;)Ljava/lang/Comparable;
    .registers 8

    .prologue
    instance-of v0, p2, Lads_mobile_sdk/bl;

    if-eqz v0, :cond_13

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/bl;

    iget v1, v0, Lads_mobile_sdk/bl;->d:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/bl;->d:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/bl;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/bl;-><init>(Lads_mobile_sdk/dl;Lwx;)V

    :goto_18
    iget-object p2, v0, Lads_mobile_sdk/bl;->b:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/bl;->d:I

    const/4 v2, 0x1

    if-eqz v1, :cond_2e

    if-ne v1, v2, :cond_27

    iget-object p1, v0, Lads_mobile_sdk/bl;->a:Landroid/net/Uri;

    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_55

    :cond_27
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0

    :cond_2e
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p2, p0, Lads_mobile_sdk/dl;->e:Lads_mobile_sdk/qr0;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sget-object v3, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    const-string v4, "gads:attribution_reporting:enabled"

    invoke-virtual {p2, v4, v1, v3}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/Boolean;

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    if-eqz p2, :cond_65

    iput-object p1, v0, Lads_mobile_sdk/bl;->a:Landroid/net/Uri;

    iput v2, v0, Lads_mobile_sdk/bl;->d:I

    invoke-virtual {p0, p1, v0}, Lads_mobile_sdk/dl;->a(Landroid/net/Uri;Lwx;)Ljava/lang/Object;

    move-result-object p2

    sget-object p0, Lwy;->a:Lwy;

    if-ne p2, p0, :cond_55

    return-object p0

    :cond_55
    :goto_55
    check-cast p2, Lb13;

    instance-of p0, p2, Lads_mobile_sdk/hv0;

    if-eqz p0, :cond_62

    check-cast p2, Lads_mobile_sdk/hv0;

    iget-object p0, p2, Lads_mobile_sdk/hv0;->b:Ljava/lang/Object;

    move-object p1, p0

    check-cast p1, Landroid/net/Uri;

    :cond_62
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :cond_65
    return-object p1
.end method

.method public final c(Landroid/net/Uri;Lwx;)Ljava/lang/Object;
    .registers 8

    .prologue
    instance-of v0, p2, Lads_mobile_sdk/cl;

    if-eqz v0, :cond_13

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/cl;

    iget v1, v0, Lads_mobile_sdk/cl;->e:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/cl;->e:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/cl;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/cl;-><init>(Lads_mobile_sdk/dl;Lwx;)V

    :goto_18
    iget-object p2, v0, Lads_mobile_sdk/cl;->c:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/cl;->e:I

    const/4 v2, 0x1

    if-eqz v1, :cond_30

    if-ne v1, v2, :cond_29

    iget-object p1, v0, Lads_mobile_sdk/cl;->b:Landroid/net/Uri;

    iget-object p0, v0, Lads_mobile_sdk/cl;->a:Lads_mobile_sdk/dl;

    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_59

    :cond_29
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0

    :cond_30
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p2, p0, Lads_mobile_sdk/dl;->e:Lads_mobile_sdk/qr0;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sget-object v3, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    const-string v4, "gads:attribution_reporting:enabled"

    invoke-virtual {p2, v4, v1, v3}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/Boolean;

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    if-eqz p2, :cond_9f

    iput-object p0, v0, Lads_mobile_sdk/cl;->a:Lads_mobile_sdk/dl;

    iput-object p1, v0, Lads_mobile_sdk/cl;->b:Landroid/net/Uri;

    iput v2, v0, Lads_mobile_sdk/cl;->e:I

    invoke-virtual {p0, p1, v0}, Lads_mobile_sdk/dl;->a(Landroid/net/Uri;Lwx;)Ljava/lang/Object;

    move-result-object p2

    sget-object v0, Lwy;->a:Lwy;

    if-ne p2, v0, :cond_59

    return-object v0

    :cond_59
    :goto_59
    check-cast p2, Lb13;

    instance-of v0, p2, Lads_mobile_sdk/hv0;

    if-eqz v0, :cond_82

    iget-object p0, p0, Lads_mobile_sdk/dl;->a:Lads_mobile_sdk/uv2;

    check-cast p2, Lads_mobile_sdk/hv0;

    iget-object p1, p2, Lads_mobile_sdk/hv0;->b:Ljava/lang/Object;

    check-cast p1, Landroid/net/Uri;

    invoke-virtual {p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance p2, Ljava/net/URL;

    invoke-direct {p2, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2}, Ljava/net/URL;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    invoke-static {p0, p1}, Lads_mobile_sdk/uv2;->a(Lads_mobile_sdk/uv2;Landroid/net/Uri;)V

    goto :goto_bb

    :cond_82
    iget-object p0, p0, Lads_mobile_sdk/dl;->a:Lads_mobile_sdk/uv2;

    invoke-virtual {p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance p2, Ljava/net/URL;

    invoke-direct {p2, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2}, Ljava/net/URL;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    invoke-static {p0, p1}, Lads_mobile_sdk/uv2;->a(Lads_mobile_sdk/uv2;Landroid/net/Uri;)V

    goto :goto_bb

    :cond_9f
    invoke-virtual {p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance p2, Ljava/net/URL;

    invoke-direct {p2, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2}, Ljava/net/URL;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    iget-object p0, p0, Lads_mobile_sdk/dl;->a:Lads_mobile_sdk/uv2;

    invoke-static {p0, p1}, Lads_mobile_sdk/uv2;->a(Lads_mobile_sdk/uv2;Landroid/net/Uri;)V

    :goto_bb
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method
