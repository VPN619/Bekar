.class public final Lads_mobile_sdk/bk1;
.super Lads_mobile_sdk/al0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final d:Lvy;

.field public final e:Lvy;

.field public final f:Lads_mobile_sdk/qr0;

.field public final g:Lx43;

.field public final h:Lq63;

.field public final i:Lads_mobile_sdk/gr0;

.field public final j:Lads_mobile_sdk/o03;

.field public final k:Lads_mobile_sdk/oo3;

.field public final l:Lads_mobile_sdk/ux2;

.field public final m:Lsw2;

.field public final n:Ltv2;

.field public final o:Lads_mobile_sdk/ax0;

.field public p:Lads_mobile_sdk/vz;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lvy;Lvy;Lads_mobile_sdk/qr0;Lx43;Lq63;Lads_mobile_sdk/gr0;Lads_mobile_sdk/o03;Ld03;Lads_mobile_sdk/oo3;Lads_mobile_sdk/ux2;Lsw2;Ltv2;Lads_mobile_sdk/ax0;)V
    .registers 15

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Lads_mobile_sdk/al0;-><init>()V

    iput-object p2, p0, Lads_mobile_sdk/bk1;->d:Lvy;

    iput-object p3, p0, Lads_mobile_sdk/bk1;->e:Lvy;

    iput-object p4, p0, Lads_mobile_sdk/bk1;->f:Lads_mobile_sdk/qr0;

    iput-object p5, p0, Lads_mobile_sdk/bk1;->g:Lx43;

    iput-object p6, p0, Lads_mobile_sdk/bk1;->h:Lq63;

    iput-object p7, p0, Lads_mobile_sdk/bk1;->i:Lads_mobile_sdk/gr0;

    iput-object p8, p0, Lads_mobile_sdk/bk1;->j:Lads_mobile_sdk/o03;

    iput-object p10, p0, Lads_mobile_sdk/bk1;->k:Lads_mobile_sdk/oo3;

    iput-object p11, p0, Lads_mobile_sdk/bk1;->l:Lads_mobile_sdk/ux2;

    iput-object p12, p0, Lads_mobile_sdk/bk1;->m:Lsw2;

    iput-object p13, p0, Lads_mobile_sdk/bk1;->n:Ltv2;

    iput-object p14, p0, Lads_mobile_sdk/bk1;->o:Lads_mobile_sdk/ax0;

    return-void
.end method

.method public static final a(Lads_mobile_sdk/bk1;Ljava/lang/String;Lwx;)Ljava/lang/Object;
    .registers 10

    .prologue
    instance-of v0, p2, Lads_mobile_sdk/xj1;

    if-eqz v0, :cond_13

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/xj1;

    iget v1, v0, Lads_mobile_sdk/xj1;->d:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/xj1;->d:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/xj1;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/xj1;-><init>(Lads_mobile_sdk/bk1;Lwx;)V

    :goto_18
    iget-object p2, v0, Lads_mobile_sdk/xj1;->b:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/xj1;->d:I

    const/4 v2, 0x0

    sget-object v3, Lrg2;->a:Lrg2;

    const/4 v4, 0x2

    const/4 v5, 0x1

    sget-object v6, Lwy;->a:Lwy;

    if-eqz v1, :cond_39

    if-eq v1, v5, :cond_33

    if-ne v1, v4, :cond_2d

    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    return-object v3

    :cond_2d
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v2

    :cond_33
    iget-object p0, v0, Lads_mobile_sdk/xj1;->a:Lads_mobile_sdk/bk1;

    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_47

    :cond_39
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    iput-object p0, v0, Lads_mobile_sdk/xj1;->a:Lads_mobile_sdk/bk1;

    iput v5, v0, Lads_mobile_sdk/xj1;->d:I

    invoke-virtual {p0, p1, v0}, Lads_mobile_sdk/bk1;->a(Ljava/lang/String;Lvx;)Ljava/lang/Object;

    move-result-object p2

    if-ne p2, v6, :cond_47

    goto :goto_61

    :cond_47
    :goto_47
    check-cast p2, Lb13;

    instance-of p1, p2, Lads_mobile_sdk/av0;

    if-eqz p1, :cond_4e

    goto :goto_62

    :cond_4e
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Lads_mobile_sdk/hv0;

    iget-object p1, p2, Lads_mobile_sdk/hv0;->b:Ljava/lang/Object;

    check-cast p1, Lads_mobile_sdk/ue1;

    iput-object v2, v0, Lads_mobile_sdk/xj1;->a:Lads_mobile_sdk/bk1;

    iput v4, v0, Lads_mobile_sdk/xj1;->d:I

    invoke-virtual {p0, p1, v0}, Lads_mobile_sdk/al0;->c(Lads_mobile_sdk/ue1;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v6, :cond_62

    :goto_61
    return-object v6

    :cond_62
    :goto_62
    return-object v3
.end method

.method public static final a(Lads_mobile_sdk/bk1;Lwx;)Ljava/lang/Object;
    .registers 16

    .prologue
    sget-object v0, Lads_mobile_sdk/fo;->a$21:Lads_mobile_sdk/fo;

    instance-of v1, p1, Lads_mobile_sdk/zj1;

    if-eqz v1, :cond_15

    move-object v1, p1

    check-cast v1, Lads_mobile_sdk/zj1;

    iget v2, v1, Lads_mobile_sdk/zj1;->e:I

    const/high16 v3, -0x80000000

    and-int v4, v2, v3

    if-eqz v4, :cond_15

    sub-int/2addr v2, v3

    iput v2, v1, Lads_mobile_sdk/zj1;->e:I

    goto :goto_1a

    :cond_15
    new-instance v1, Lads_mobile_sdk/zj1;

    invoke-direct {v1, p0, p1}, Lads_mobile_sdk/zj1;-><init>(Lads_mobile_sdk/bk1;Lwx;)V

    :goto_1a
    iget-object p1, v1, Lads_mobile_sdk/zj1;->c:Ljava/lang/Object;

    iget v2, v1, Lads_mobile_sdk/zj1;->e:I

    sget-object v3, Ly60;->d:Ly60;

    sget-object v4, Ly60;->h:Ly60;

    const/16 v5, 0x1e

    const-string v6, "gads:sdk_core_ttl_seconds"

    const/4 v7, 0x2

    const/4 v8, 0x1

    sget-object v9, Lwy;->a:Lwy;

    if-eqz v2, :cond_45

    if-eq v2, v8, :cond_3f

    if-ne v2, v7, :cond_38

    iget-wide v9, v1, Lads_mobile_sdk/zj1;->b:J

    iget-object p0, v1, Lads_mobile_sdk/zj1;->a:Lads_mobile_sdk/bk1;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_a9

    :cond_38
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0

    :cond_3f
    iget-object p0, v1, Lads_mobile_sdk/zj1;->a:Lads_mobile_sdk/bk1;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_58

    :cond_45
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/bk1;->j:Lads_mobile_sdk/o03;

    iput-object p0, v1, Lads_mobile_sdk/zj1;->a:Lads_mobile_sdk/bk1;

    iput v8, v1, Lads_mobile_sdk/zj1;->e:I

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1, v1}, Lads_mobile_sdk/o03;->a(Lads_mobile_sdk/o03;Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v9, :cond_58

    goto :goto_a7

    :cond_58
    :goto_58
    check-cast p1, Lads_mobile_sdk/i03;

    invoke-virtual {p1}, Lads_mobile_sdk/i03;->o()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result p1

    if-nez p1, :cond_d8

    iget-object p1, p0, Lads_mobile_sdk/bk1;->f:Lads_mobile_sdk/qr0;

    iget-object p1, p1, Lads_mobile_sdk/qr0;->s:Ly23;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v2, Lv60;->b:Lp80;

    invoke-static {v5, v4}, Li10;->G0(ILy60;)J

    move-result-wide v10

    new-instance v2, Lv60;

    invoke-direct {v2, v10, v11}, Lv60;-><init>(J)V

    invoke-virtual {p1, v6, v2, v0}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lv60;

    iget-wide v10, p1, Lv60;->a:J

    const-wide/16 v12, 0x0

    invoke-static {v10, v11, v12, v13}, Lv60;->c(JJ)I

    move-result p1

    if-lez p1, :cond_d9

    iget-object p1, p0, Lads_mobile_sdk/bk1;->g:Lx43;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v10

    invoke-static {v10, v11, v3}, Li10;->H0(JLy60;)J

    move-result-wide v10

    iget-object p1, p0, Lads_mobile_sdk/bk1;->j:Lads_mobile_sdk/o03;

    iput-object p0, v1, Lads_mobile_sdk/zj1;->a:Lads_mobile_sdk/bk1;

    iput-wide v10, v1, Lads_mobile_sdk/zj1;->b:J

    iput v7, v1, Lads_mobile_sdk/zj1;->e:I

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1, v1}, Lads_mobile_sdk/o03;->a(Lads_mobile_sdk/o03;Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v9, :cond_a8

    :goto_a7
    return-object v9

    :cond_a8
    move-wide v9, v10

    :goto_a9
    check-cast p1, Lads_mobile_sdk/i03;

    invoke-virtual {p1}, Lads_mobile_sdk/i03;->q()J

    move-result-wide v1

    invoke-static {v1, v2, v3}, Li10;->H0(JLy60;)J

    move-result-wide v1

    iget-object p0, p0, Lads_mobile_sdk/bk1;->f:Lads_mobile_sdk/qr0;

    iget-object p0, p0, Lads_mobile_sdk/qr0;->s:Ly23;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object p1, Lv60;->b:Lp80;

    invoke-static {v5, v4}, Li10;->G0(ILy60;)J

    move-result-wide v3

    new-instance p1, Lv60;

    invoke-direct {p1, v3, v4}, Lv60;-><init>(J)V

    invoke-virtual {p0, v6, p1, v0}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lv60;

    iget-wide p0, p0, Lv60;->a:J

    invoke-static {v1, v2, p0, p1}, Lv60;->i(JJ)J

    move-result-wide p0

    invoke-static {v9, v10, p0, p1}, Lv60;->c(JJ)I

    move-result p0

    if-gez p0, :cond_d8

    goto :goto_d9

    :cond_d8
    const/4 v8, 0x0

    :cond_d9
    :goto_d9
    invoke-static {v8}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    return-object p0
.end method

.method public static final b(Lads_mobile_sdk/bk1;Ljava/lang/String;Lwx;)Ljava/lang/Object;
    .registers 9

    .prologue
    instance-of v0, p2, Lads_mobile_sdk/ak1;

    if-eqz v0, :cond_13

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/ak1;

    iget v1, v0, Lads_mobile_sdk/ak1;->d:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/ak1;->d:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/ak1;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/ak1;-><init>(Lads_mobile_sdk/bk1;Lwx;)V

    :goto_18
    iget-object p2, v0, Lads_mobile_sdk/ak1;->b:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/ak1;->d:I

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    sget-object v5, Lwy;->a:Lwy;

    if-eqz v1, :cond_3d

    if-eq v1, v4, :cond_35

    if-ne v1, v3, :cond_2f

    iget-object p0, v0, Lads_mobile_sdk/ak1;->a:Ljava/lang/Object;

    check-cast p0, Ljava/lang/String;

    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    return-object p0

    :cond_2f
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v2

    :cond_35
    iget-object p0, v0, Lads_mobile_sdk/ak1;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/bk1;

    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_4b

    :cond_3d
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    iput-object p0, v0, Lads_mobile_sdk/ak1;->a:Ljava/lang/Object;

    iput v4, v0, Lads_mobile_sdk/ak1;->d:I

    invoke-virtual {p0, p1, v0}, Lads_mobile_sdk/bk1;->c(Ljava/lang/String;Lwx;)Ljava/lang/Object;

    move-result-object p2

    if-ne p2, v5, :cond_4b

    goto :goto_7b

    :cond_4b
    :goto_4b
    check-cast p2, Lb13;

    instance-of p1, p2, Lads_mobile_sdk/av0;

    if-eqz p1, :cond_52

    return-object v2

    :cond_52
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Lads_mobile_sdk/hv0;

    iget-object p1, p2, Lads_mobile_sdk/hv0;->b:Ljava/lang/Object;

    check-cast p1, Lads_mobile_sdk/j21;

    iget-object p1, p1, Lads_mobile_sdk/j21;->d:Lads_mobile_sdk/gv2;

    if-eqz p1, :cond_63

    invoke-static {p1}, Lads_mobile_sdk/gv2;->a(Lads_mobile_sdk/gv2;)Ljava/lang/String;

    move-result-object v2

    :cond_63
    if-eqz v2, :cond_7c

    invoke-static {v2}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result p1

    if-eqz p1, :cond_6c

    goto :goto_7c

    :cond_6c
    iget-object p0, p0, Lads_mobile_sdk/bk1;->j:Lads_mobile_sdk/o03;

    iput-object v2, v0, Lads_mobile_sdk/ak1;->a:Ljava/lang/Object;

    iput v3, v0, Lads_mobile_sdk/ak1;->d:I

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p0, v2, v0}, Lads_mobile_sdk/o03;->a(Lads_mobile_sdk/o03;Ljava/lang/String;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_7c

    :goto_7b
    return-object v5

    :cond_7c
    :goto_7c
    return-object v2
.end method


# virtual methods
.method public final a(Lads_mobile_sdk/ue1;Lvx;)Ljava/lang/Object;
    .registers 20

    .prologue
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    instance-of v3, v2, Lads_mobile_sdk/lj1;

    if-eqz v3, :cond_19

    move-object v3, v2

    check-cast v3, Lads_mobile_sdk/lj1;

    iget v4, v3, Lads_mobile_sdk/lj1;->e:I

    const/high16 v5, -0x80000000

    and-int v6, v4, v5

    if-eqz v6, :cond_19

    sub-int/2addr v4, v5

    iput v4, v3, Lads_mobile_sdk/lj1;->e:I

    goto :goto_20

    :cond_19
    new-instance v3, Lads_mobile_sdk/lj1;

    check-cast v2, Lwx;

    invoke-direct {v3, v0, v2}, Lads_mobile_sdk/lj1;-><init>(Lads_mobile_sdk/bk1;Lwx;)V

    :goto_20
    iget-object v2, v3, Lads_mobile_sdk/lj1;->c:Ljava/lang/Object;

    iget v4, v3, Lads_mobile_sdk/lj1;->e:I

    const-string v5, "consentStringsProvider"

    const/4 v6, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x1

    sget-object v9, Lrg2;->a:Lrg2;

    const/4 v10, 0x0

    sget-object v11, Lwy;->a:Lwy;

    if-eqz v4, :cond_59

    if-eq v4, v8, :cond_4a

    if-eq v4, v7, :cond_40

    if-ne v4, v6, :cond_3a

    invoke-static {v2}, Lt12;->W(Ljava/lang/Object;)V

    return-object v9

    :cond_3a
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {v0}, Lz6;->w(Ljava/lang/String;)V

    return-object v10

    :cond_40
    iget-object v0, v3, Lads_mobile_sdk/lj1;->b:Lads_mobile_sdk/ue1;

    iget-object v1, v3, Lads_mobile_sdk/lj1;->a:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/gr0;

    invoke-static {v2}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_a7

    :cond_4a
    iget-object v0, v3, Lads_mobile_sdk/lj1;->b:Lads_mobile_sdk/ue1;

    iget-object v1, v3, Lads_mobile_sdk/lj1;->a:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/bk1;

    invoke-static {v2}, Lt12;->W(Ljava/lang/Object;)V

    move-object/from16 v16, v1

    move-object v1, v0

    move-object/from16 v0, v16

    goto :goto_8e

    :cond_59
    invoke-static {v2}, Lt12;->W(Ljava/lang/Object;)V

    if-nez v1, :cond_5f

    goto :goto_b9

    :cond_5f
    iget-object v2, v0, Lads_mobile_sdk/bk1;->f:Lads_mobile_sdk/qr0;

    iget-boolean v4, v2, Lads_mobile_sdk/qr0;->w:Z

    if-nez v4, :cond_6d

    iget-wide v12, v2, Lads_mobile_sdk/qr0;->x:D

    const-wide/16 v14, 0x0

    cmpl-double v4, v12, v14

    if-lez v4, :cond_c2

    :cond_6d
    iget-object v2, v2, Lads_mobile_sdk/ov;->a:Ljava/lang/Object;

    check-cast v2, Ld03;

    check-cast v2, Lads_mobile_sdk/eo;

    iget-object v2, v2, Lads_mobile_sdk/eo;->o:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v2

    if-nez v2, :cond_c2

    iget-object v2, v0, Lads_mobile_sdk/bk1;->p:Lads_mobile_sdk/vz;

    if-eqz v2, :cond_be

    iget-object v2, v2, Lads_mobile_sdk/vz;->D:Lhv0;

    iput-object v0, v3, Lads_mobile_sdk/lj1;->a:Ljava/lang/Object;

    iput-object v1, v3, Lads_mobile_sdk/lj1;->b:Lads_mobile_sdk/ue1;

    iput v8, v3, Lads_mobile_sdk/lj1;->e:I

    invoke-virtual {v2, v3}, Lnv0;->H(Lwx;)Ljava/lang/Object;

    move-result-object v2

    if-ne v2, v11, :cond_8e

    goto :goto_b8

    :cond_8e
    :goto_8e
    iget-object v2, v0, Lads_mobile_sdk/bk1;->i:Lads_mobile_sdk/gr0;

    iget-object v0, v0, Lads_mobile_sdk/bk1;->p:Lads_mobile_sdk/vz;

    if-eqz v0, :cond_ba

    iput-object v2, v3, Lads_mobile_sdk/lj1;->a:Ljava/lang/Object;

    iput-object v1, v3, Lads_mobile_sdk/lj1;->b:Lads_mobile_sdk/ue1;

    iput v7, v3, Lads_mobile_sdk/lj1;->e:I

    invoke-static {v0, v3}, Lads_mobile_sdk/vz;->d(Lads_mobile_sdk/vz;Lwx;)Ljava/lang/Object;

    move-result-object v0

    if-ne v0, v11, :cond_a1

    goto :goto_b8

    :cond_a1
    move-object/from16 v16, v2

    move-object v2, v0

    move-object v0, v1

    move-object/from16 v1, v16

    :goto_a7
    check-cast v2, Lfx0;

    iput-object v10, v3, Lads_mobile_sdk/lj1;->a:Ljava/lang/Object;

    iput-object v10, v3, Lads_mobile_sdk/lj1;->b:Lads_mobile_sdk/ue1;

    iput v6, v3, Lads_mobile_sdk/lj1;->e:I

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v1, v0, v2, v3}, Lads_mobile_sdk/gr0;->a(Lads_mobile_sdk/gr0;Lads_mobile_sdk/ue1;Lfx0;Lwx;)Ljava/lang/Object;

    move-result-object v0

    if-ne v0, v11, :cond_b9

    :goto_b8
    return-object v11

    :cond_b9
    :goto_b9
    return-object v9

    :cond_ba
    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_be
    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_c2
    new-instance v2, Lnw;

    const/4 v3, 0x7

    invoke-direct {v2, v0, v1, v10, v3}, Lnw;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lvx;I)V

    iget-object v0, v0, Lads_mobile_sdk/bk1;->e:Lvy;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, La42;

    invoke-direct {v1, v2, v10}, La42;-><init>(Lpk0;Lvx;)V

    sget-object v2, Ly90;->a:Ly90;

    invoke-static {v0, v2, v10, v1, v7}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    return-object v9
.end method

.method public final a(Ljava/lang/String;Lvx;)Ljava/lang/Object;
    .registers 16

    .prologue
    instance-of v0, p2, Lads_mobile_sdk/oj1;

    if-eqz v0, :cond_13

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/oj1;

    iget v1, v0, Lads_mobile_sdk/oj1;->e:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/oj1;->e:I

    goto :goto_1a

    :cond_13
    new-instance v0, Lads_mobile_sdk/oj1;

    check-cast p2, Lwx;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/oj1;-><init>(Lads_mobile_sdk/bk1;Lwx;)V

    :goto_1a
    iget-object p2, v0, Lads_mobile_sdk/oj1;->c:Ljava/lang/Object;

    sget-object v1, Lwy;->a:Lwy;

    iget v2, v0, Lads_mobile_sdk/oj1;->e:I

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eqz v2, :cond_46

    if-eq v2, v5, :cond_3c

    if-ne v2, v4, :cond_36

    iget-object p0, v0, Lads_mobile_sdk/oj1;->b:Lads_mobile_sdk/rg3;

    iget-object p1, v0, Lads_mobile_sdk/oj1;->a:Lads_mobile_sdk/rg3;

    :try_start_2e
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_31
    .catchall {:try_start_2e .. :try_end_31} :catchall_33

    goto/16 :goto_e2

    :catchall_33
    move-exception p2

    goto/16 :goto_f6

    :cond_36
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v6

    :cond_3c
    iget-object p0, v0, Lads_mobile_sdk/oj1;->b:Lads_mobile_sdk/rg3;

    iget-object p1, v0, Lads_mobile_sdk/oj1;->a:Lads_mobile_sdk/rg3;

    :try_start_40
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_43
    .catchall {:try_start_40 .. :try_end_43} :catchall_44

    goto :goto_84

    :catchall_44
    move-exception p2

    goto :goto_98

    :cond_46
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p2, p0, Lads_mobile_sdk/bk1;->l:Lads_mobile_sdk/ux2;

    sget-object v2, Lads_mobile_sdk/fw0;->i:Lads_mobile_sdk/fw0;

    sget-object v7, Lba0;->a:Lba0;

    new-instance v8, Lads_mobile_sdk/kh3;

    new-instance v9, Lads_mobile_sdk/eq2;

    invoke-direct {v9}, Lads_mobile_sdk/eq2;-><init>()V

    new-instance v10, Lads_mobile_sdk/ih1;

    invoke-direct {v10}, Lads_mobile_sdk/ih1;-><init>()V

    new-instance v11, Lads_mobile_sdk/dt2;

    invoke-direct {v11}, Lads_mobile_sdk/dt2;-><init>()V

    new-instance v12, Lads_mobile_sdk/s8;

    invoke-direct {v12}, Lads_mobile_sdk/s8;-><init>()V

    invoke-direct {v8, v9, v10, v11, v12}, Lads_mobile_sdk/kh3;-><init>(Lads_mobile_sdk/eq2;Lads_mobile_sdk/ih1;Lads_mobile_sdk/dt2;Lads_mobile_sdk/s8;)V

    invoke-static {}, Lads_mobile_sdk/hh3;->b()Lads_mobile_sdk/gh3;

    move-result-object v9

    iget-object v9, v9, Lads_mobile_sdk/gh3;->a:Lads_mobile_sdk/rg3;

    if-nez v9, :cond_ce

    invoke-static {p2, v2, v7, v8}, Lads_mobile_sdk/ux2;->a(Lads_mobile_sdk/ux2;Lads_mobile_sdk/fw0;Ljava/util/List;Lads_mobile_sdk/kh3;)Lads_mobile_sdk/wk2;

    move-result-object p2

    :try_start_74
    iput-object p2, v0, Lads_mobile_sdk/oj1;->a:Lads_mobile_sdk/rg3;

    iput-object p2, v0, Lads_mobile_sdk/oj1;->b:Lads_mobile_sdk/rg3;

    iput v5, v0, Lads_mobile_sdk/oj1;->e:I

    invoke-virtual {p0, p1, v0}, Lads_mobile_sdk/bk1;->b(Ljava/lang/String;Lwx;)Ljava/lang/Object;

    move-result-object p0
    :try_end_7e
    .catchall {:try_start_74 .. :try_end_7e} :catchall_94

    if-ne p0, v1, :cond_81

    goto :goto_de

    :cond_81
    move-object p1, p2

    move-object p2, p0

    move-object p0, p1

    :goto_84
    :try_start_84
    check-cast p2, Lb13;

    instance-of v0, p2, Lads_mobile_sdk/av0;

    if-eqz v0, :cond_90

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/av0;

    invoke-static {v0, v3}, Lads_mobile_sdk/xh3;->a(Lads_mobile_sdk/av0;Z)V
    :try_end_90
    .catchall {:try_start_84 .. :try_end_90} :catchall_44

    :cond_90
    invoke-static {p0, v6}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object p2

    :catchall_94
    move-exception p0

    move-object p1, p2

    move-object p2, p0

    move-object p0, p1

    :goto_98
    :try_start_98
    invoke-virtual {p1, p2}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v0, p2, Lox2;

    if-nez v0, :cond_c7

    invoke-virtual {p1, p2}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of p1, p2, Lza2;

    if-nez p1, :cond_bf

    instance-of p1, p2, Ljava/util/concurrent/CancellationException;

    if-nez p1, :cond_b7

    instance-of p1, p2, Lads_mobile_sdk/mv0;

    if-eqz p1, :cond_b1

    throw p2

    :catchall_af
    move-exception p1

    goto :goto_c8

    :cond_b1
    new-instance p1, Lads_mobile_sdk/tu0;

    invoke-direct {p1, p2}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw p1

    :cond_b7
    new-instance p1, Lads_mobile_sdk/ou0;

    check-cast p2, Ljava/util/concurrent/CancellationException;

    invoke-direct {p1, p2}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw p1

    :cond_bf
    new-instance p1, Lads_mobile_sdk/uw0;

    check-cast p2, Lza2;

    invoke-direct {p1, p2}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw p1

    :cond_c7
    throw p2
    :try_end_c8
    .catchall {:try_start_98 .. :try_end_c8} :catchall_af

    :goto_c8
    :try_start_c8
    throw p1
    :try_end_c9
    .catchall {:try_start_c8 .. :try_end_c9} :catchall_c9

    :catchall_c9
    move-exception p2

    invoke-static {p0, p1}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw p2

    :cond_ce
    invoke-static {v2, v7, v5}, Lads_mobile_sdk/hh3;->a(Lads_mobile_sdk/fw0;Ljava/util/List;Z)Lads_mobile_sdk/rg3;

    move-result-object p2

    :try_start_d2
    iput-object p2, v0, Lads_mobile_sdk/oj1;->a:Lads_mobile_sdk/rg3;

    iput-object p2, v0, Lads_mobile_sdk/oj1;->b:Lads_mobile_sdk/rg3;

    iput v4, v0, Lads_mobile_sdk/oj1;->e:I

    invoke-virtual {p0, p1, v0}, Lads_mobile_sdk/bk1;->b(Ljava/lang/String;Lwx;)Ljava/lang/Object;

    move-result-object p0
    :try_end_dc
    .catchall {:try_start_d2 .. :try_end_dc} :catchall_f2

    if-ne p0, v1, :cond_df

    :goto_de
    return-object v1

    :cond_df
    move-object p1, p2

    move-object p2, p0

    move-object p0, p1

    :goto_e2
    :try_start_e2
    check-cast p2, Lb13;

    instance-of v0, p2, Lads_mobile_sdk/av0;

    if-eqz v0, :cond_ee

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/av0;

    invoke-static {v0, v3}, Lads_mobile_sdk/xh3;->a(Lads_mobile_sdk/av0;Z)V
    :try_end_ee
    .catchall {:try_start_e2 .. :try_end_ee} :catchall_33

    :cond_ee
    invoke-static {p0, v6}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object p2

    :catchall_f2
    move-exception p0

    move-object p1, p2

    move-object p2, p0

    move-object p0, p1

    :goto_f6
    :try_start_f6
    invoke-virtual {p1, p2}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v0, p2, Lox2;

    if-nez v0, :cond_125

    invoke-virtual {p1, p2}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of p1, p2, Lza2;

    if-nez p1, :cond_11d

    instance-of p1, p2, Ljava/util/concurrent/CancellationException;

    if-nez p1, :cond_115

    instance-of p1, p2, Lads_mobile_sdk/mv0;

    if-eqz p1, :cond_10f

    throw p2

    :catchall_10d
    move-exception p1

    goto :goto_126

    :cond_10f
    new-instance p1, Lads_mobile_sdk/tu0;

    invoke-direct {p1, p2}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw p1

    :cond_115
    new-instance p1, Lads_mobile_sdk/ou0;

    check-cast p2, Ljava/util/concurrent/CancellationException;

    invoke-direct {p1, p2}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw p1

    :cond_11d
    new-instance p1, Lads_mobile_sdk/uw0;

    check-cast p2, Lza2;

    invoke-direct {p1, p2}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw p1

    :cond_125
    throw p2
    :try_end_126
    .catchall {:try_start_f6 .. :try_end_126} :catchall_10d

    :goto_126
    :try_start_126
    throw p1
    :try_end_127
    .catchall {:try_start_126 .. :try_end_127} :catchall_127

    :catchall_127
    move-exception p2

    invoke-static {p0, p1}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw p2
.end method

.method public final b(Ljava/lang/String;Lwx;)Ljava/lang/Object;
    .registers 19

    .prologue
    move-object/from16 v3, p0

    move-object/from16 v0, p2

    sget-object v1, Lads_mobile_sdk/fo;->a$23:Lads_mobile_sdk/fo;

    instance-of v2, v0, Lads_mobile_sdk/pj1;

    if-eqz v2, :cond_1a

    move-object v2, v0

    check-cast v2, Lads_mobile_sdk/pj1;

    iget v4, v2, Lads_mobile_sdk/pj1;->e:I

    const/high16 v5, -0x80000000

    and-int v6, v4, v5

    if-eqz v6, :cond_1a

    sub-int/2addr v4, v5

    iput v4, v2, Lads_mobile_sdk/pj1;->e:I

    :goto_18
    move-object v8, v2

    goto :goto_20

    :cond_1a
    new-instance v2, Lads_mobile_sdk/pj1;

    invoke-direct {v2, v3, v0}, Lads_mobile_sdk/pj1;-><init>(Lads_mobile_sdk/bk1;Lwx;)V

    goto :goto_18

    :goto_20
    iget-object v0, v8, Lads_mobile_sdk/pj1;->c:Ljava/lang/Object;

    iget v2, v8, Lads_mobile_sdk/pj1;->e:I

    const/4 v9, 0x0

    const/4 v10, 0x2

    const-string v11, "Timed out waiting on /jsLoaded gmsg while loading a JavascriptEngine"

    const/4 v12, 0x0

    const/4 v13, 0x1

    if-eqz v2, :cond_43

    if-ne v2, v13, :cond_3d

    iget-object v1, v8, Lads_mobile_sdk/pj1;->b:Lvr1;

    iget-object v2, v8, Lads_mobile_sdk/pj1;->a:Lads_mobile_sdk/bk1;

    :try_start_32
    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_35
    .catch Lza2; {:try_start_32 .. :try_end_35} :catch_3a
    .catch Lads_mobile_sdk/uw0; {:try_start_32 .. :try_end_35} :catch_37

    goto/16 :goto_141

    :catch_37
    move-exception v0

    goto/16 :goto_14e

    :catch_3a
    move-exception v0

    goto/16 :goto_160

    :cond_3d
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {v0}, Lz6;->w(Ljava/lang/String;)V

    return-object v12

    :cond_43
    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    new-instance v5, Lvr1;

    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    iget-object v0, v3, Lads_mobile_sdk/bk1;->o:Lads_mobile_sdk/ax0;

    iget-object v0, v0, Lads_mobile_sdk/ax0;->a:Landroid/content/Context;

    invoke-static {v0}, Lads_mobile_sdk/ax0;->a(Landroid/content/Context;)Lads_mobile_sdk/zw0;

    move-result-object v0

    iget-object v0, v0, Lads_mobile_sdk/zw0;->b:Ljava/lang/String;

    if-eqz v0, :cond_67

    sget-object v2, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v0, v2}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v2, "ru"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    goto :goto_68

    :cond_67
    move v0, v9

    :goto_68
    const-string v2, "gads:sdk_core_location:decagon"

    iget-object v4, v3, Lads_mobile_sdk/bk1;->f:Lads_mobile_sdk/qr0;

    if-eqz v0, :cond_7c

    iget-object v0, v4, Lads_mobile_sdk/qr0;->s:Ly23;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v6, "https://mediation.goog/mads/static/sdk/native/sdk-core-v40.html"

    invoke-virtual {v0, v2, v6, v1}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    goto :goto_89

    :cond_7c
    iget-object v0, v4, Lads_mobile_sdk/qr0;->s:Ly23;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v6, "https://googleads.g.doubleclick.net/mads/static/sdk/native/sdk-core-android.html"

    invoke-virtual {v0, v2, v6, v1}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    :goto_89
    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    invoke-virtual {v0}, Landroid/net/Uri;->buildUpon()Landroid/net/Uri$Builder;

    move-result-object v0

    iget-object v1, v4, Lads_mobile_sdk/qr0;->s:Ly23;

    iget-object v2, v4, Lads_mobile_sdk/qr0;->s:Ly23;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v4, Lfx0;

    invoke-direct {v4}, Lfx0;-><init>()V

    sget-object v6, Lads_mobile_sdk/fo;->a$13:Lads_mobile_sdk/fo;

    const-string v7, "sdk_core_query_params"

    invoke-virtual {v1, v7, v4, v6}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lfx0;

    iget-object v1, v1, Lfx0;->a:Lf21;

    invoke-virtual {v1}, Lf21;->entrySet()Ljava/util/Set;

    move-result-object v1

    check-cast v1, Ld21;

    invoke-virtual {v1}, Ld21;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_b3
    :goto_b3
    move-object v4, v1

    check-cast v4, Lc21;

    invoke-virtual {v4}, Lc21;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_f4

    move-object v4, v1

    check-cast v4, Lc21;

    invoke-virtual {v4}, Lc21;->b()Le21;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lkw0;

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    instance-of v6, v6, Lox0;

    if-eqz v6, :cond_b3

    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lkw0;

    invoke-virtual {v6}, Lkw0;->i()Lox0;

    move-result-object v6

    iget-object v6, v6, Lox0;->a:Ljava/io/Serializable;

    instance-of v6, v6, Ljava/lang/String;

    if-eqz v6, :cond_b3

    invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lkw0;

    invoke-virtual {v4}, Lkw0;->m()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v6, v4}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    goto :goto_b3

    :cond_f4
    invoke-virtual {v0}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object v0

    invoke-virtual {v0}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    sget-object v1, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    const-string v4, "gads:cache_sdk_core:enabled"

    invoke-virtual {v2, v4, v0, v1}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v4, "gads:fetch_initial_sdk_core_separately:enabled"

    sget-object v7, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {v2, v4, v7, v1}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    :try_start_123
    invoke-virtual {v2}, Ly23;->o()J

    move-result-wide v14

    move v2, v0

    new-instance v0, Lads_mobile_sdk/tj1;

    const/4 v7, 0x0

    move-object/from16 v1, p1

    invoke-direct/range {v0 .. v7}, Lads_mobile_sdk/tj1;-><init>(Ljava/lang/String;ZLads_mobile_sdk/bk1;ZLvr1;Ljava/lang/String;Lvx;)V

    iput-object v3, v8, Lads_mobile_sdk/pj1;->a:Lads_mobile_sdk/bk1;

    iput-object v5, v8, Lads_mobile_sdk/pj1;->b:Lvr1;

    iput v13, v8, Lads_mobile_sdk/pj1;->e:I

    invoke-static {v14, v15, v0, v8}, Lla1;->W(JLpk0;Lwx;)Ljava/lang/Object;

    move-result-object v0
    :try_end_13a
    .catch Lza2; {:try_start_123 .. :try_end_13a} :catch_146
    .catch Lads_mobile_sdk/uw0; {:try_start_123 .. :try_end_13a} :catch_144

    sget-object v1, Lwy;->a:Lwy;

    if-ne v0, v1, :cond_13f

    return-object v1

    :cond_13f
    move-object v2, v3

    move-object v1, v5

    :goto_141
    :try_start_141
    check-cast v0, Lb13;
    :try_end_143
    .catch Lza2; {:try_start_141 .. :try_end_143} :catch_3a
    .catch Lads_mobile_sdk/uw0; {:try_start_141 .. :try_end_143} :catch_37

    return-object v0

    :catch_144
    move-exception v0

    goto :goto_148

    :catch_146
    move-exception v0

    goto :goto_14b

    :goto_148
    move-object v2, v3

    move-object v1, v5

    goto :goto_14e

    :goto_14b
    move-object v2, v3

    move-object v1, v5

    goto :goto_160

    :goto_14e
    iget-object v2, v2, Lads_mobile_sdk/bk1;->d:Lvy;

    sget-object v3, Lxf1;->b:Lxf1;

    new-instance v4, Lads_mobile_sdk/uj1;

    invoke-direct {v4, v1, v12, v13}, Lads_mobile_sdk/uj1;-><init>(Lvr1;Lvx;I)V

    invoke-static {v2, v3, v12, v4, v10}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    new-instance v1, Lads_mobile_sdk/iv0;

    invoke-direct {v1, v11, v0}, Lads_mobile_sdk/iv0;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    goto :goto_171

    :goto_160
    iget-object v2, v2, Lads_mobile_sdk/bk1;->d:Lvy;

    sget-object v3, Lxf1;->b:Lxf1;

    new-instance v4, Lads_mobile_sdk/uj1;

    invoke-direct {v4, v1, v12, v9}, Lads_mobile_sdk/uj1;-><init>(Lvr1;Lvx;I)V

    invoke-static {v2, v3, v12, v4, v10}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    new-instance v1, Lads_mobile_sdk/iv0;

    invoke-direct {v1, v11, v0}, Lads_mobile_sdk/iv0;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_171
    return-object v1
.end method

.method public final c(Ljava/lang/String;Lwx;)Ljava/lang/Object;
    .registers 16

    .prologue
    instance-of v0, p2, Lads_mobile_sdk/yj1;

    if-eqz v0, :cond_13

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/yj1;

    iget v1, v0, Lads_mobile_sdk/yj1;->e:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/yj1;->e:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/yj1;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/yj1;-><init>(Lads_mobile_sdk/bk1;Lwx;)V

    :goto_18
    iget-object p2, v0, Lads_mobile_sdk/yj1;->c:Ljava/lang/Object;

    sget-object v1, Lwy;->a:Lwy;

    iget v2, v0, Lads_mobile_sdk/yj1;->e:I

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eqz v2, :cond_44

    if-eq v2, v5, :cond_3a

    if-ne v2, v4, :cond_34

    iget-object p0, v0, Lads_mobile_sdk/yj1;->b:Lads_mobile_sdk/rg3;

    iget-object p1, v0, Lads_mobile_sdk/yj1;->a:Lads_mobile_sdk/rg3;

    :try_start_2c
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_2f
    .catchall {:try_start_2c .. :try_end_2f} :catchall_31

    goto/16 :goto_f0

    :catchall_31
    move-exception p2

    goto/16 :goto_104

    :cond_34
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v6

    :cond_3a
    iget-object p0, v0, Lads_mobile_sdk/yj1;->b:Lads_mobile_sdk/rg3;

    iget-object p1, v0, Lads_mobile_sdk/yj1;->a:Lads_mobile_sdk/rg3;

    :try_start_3e
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_41
    .catchall {:try_start_3e .. :try_end_41} :catchall_42

    goto :goto_8b

    :catchall_42
    move-exception p2

    goto :goto_9f

    :cond_44
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p2, p0, Lads_mobile_sdk/bk1;->l:Lads_mobile_sdk/ux2;

    sget-object v2, Lads_mobile_sdk/fw0;->k:Lads_mobile_sdk/fw0;

    sget-object v7, Lba0;->a:Lba0;

    new-instance v8, Lads_mobile_sdk/kh3;

    new-instance v9, Lads_mobile_sdk/eq2;

    invoke-direct {v9}, Lads_mobile_sdk/eq2;-><init>()V

    new-instance v10, Lads_mobile_sdk/ih1;

    invoke-direct {v10}, Lads_mobile_sdk/ih1;-><init>()V

    new-instance v11, Lads_mobile_sdk/dt2;

    invoke-direct {v11}, Lads_mobile_sdk/dt2;-><init>()V

    new-instance v12, Lads_mobile_sdk/s8;

    invoke-direct {v12}, Lads_mobile_sdk/s8;-><init>()V

    invoke-direct {v8, v9, v10, v11, v12}, Lads_mobile_sdk/kh3;-><init>(Lads_mobile_sdk/eq2;Lads_mobile_sdk/ih1;Lads_mobile_sdk/dt2;Lads_mobile_sdk/s8;)V

    invoke-static {}, Lads_mobile_sdk/hh3;->b()Lads_mobile_sdk/gh3;

    move-result-object v9

    iget-object v9, v9, Lads_mobile_sdk/gh3;->a:Lads_mobile_sdk/rg3;

    const/16 v10, 0x1e

    if-nez v9, :cond_d5

    invoke-static {p2, v2, v7, v8}, Lads_mobile_sdk/ux2;->a(Lads_mobile_sdk/ux2;Lads_mobile_sdk/fw0;Ljava/util/List;Lads_mobile_sdk/kh3;)Lads_mobile_sdk/wk2;

    move-result-object p2

    :try_start_74
    iget-object p0, p0, Lads_mobile_sdk/bk1;->h:Lq63;

    new-instance v2, Ljava/net/URL;

    invoke-direct {v2, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    iput-object p2, v0, Lads_mobile_sdk/yj1;->a:Lads_mobile_sdk/rg3;

    iput-object p2, v0, Lads_mobile_sdk/yj1;->b:Lads_mobile_sdk/rg3;

    iput v5, v0, Lads_mobile_sdk/yj1;->e:I

    invoke-static {p0, v2, v6, v0, v10}, Lq63;->a(Lq63;Ljava/net/URL;Ljava/util/Map;Lwx;I)Ljava/lang/Object;

    move-result-object p0
    :try_end_85
    .catchall {:try_start_74 .. :try_end_85} :catchall_9b

    if-ne p0, v1, :cond_88

    goto :goto_ec

    :cond_88
    move-object p1, p2

    move-object p2, p0

    move-object p0, p1

    :goto_8b
    :try_start_8b
    check-cast p2, Lb13;

    instance-of v0, p2, Lads_mobile_sdk/av0;

    if-eqz v0, :cond_97

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/av0;

    invoke-static {v0, v3}, Lads_mobile_sdk/xh3;->a(Lads_mobile_sdk/av0;Z)V
    :try_end_97
    .catchall {:try_start_8b .. :try_end_97} :catchall_42

    :cond_97
    invoke-static {p0, v6}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object p2

    :catchall_9b
    move-exception p0

    move-object p1, p2

    move-object p2, p0

    move-object p0, p1

    :goto_9f
    :try_start_9f
    invoke-virtual {p1, p2}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v0, p2, Lox2;

    if-nez v0, :cond_ce

    invoke-virtual {p1, p2}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of p1, p2, Lza2;

    if-nez p1, :cond_c6

    instance-of p1, p2, Ljava/util/concurrent/CancellationException;

    if-nez p1, :cond_be

    instance-of p1, p2, Lads_mobile_sdk/mv0;

    if-eqz p1, :cond_b8

    throw p2

    :catchall_b6
    move-exception p1

    goto :goto_cf

    :cond_b8
    new-instance p1, Lads_mobile_sdk/tu0;

    invoke-direct {p1, p2}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw p1

    :cond_be
    new-instance p1, Lads_mobile_sdk/ou0;

    check-cast p2, Ljava/util/concurrent/CancellationException;

    invoke-direct {p1, p2}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw p1

    :cond_c6
    new-instance p1, Lads_mobile_sdk/uw0;

    check-cast p2, Lza2;

    invoke-direct {p1, p2}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw p1

    :cond_ce
    throw p2
    :try_end_cf
    .catchall {:try_start_9f .. :try_end_cf} :catchall_b6

    :goto_cf
    :try_start_cf
    throw p1
    :try_end_d0
    .catchall {:try_start_cf .. :try_end_d0} :catchall_d0

    :catchall_d0
    move-exception p2

    invoke-static {p0, p1}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw p2

    :cond_d5
    invoke-static {v2, v7, v5}, Lads_mobile_sdk/hh3;->a(Lads_mobile_sdk/fw0;Ljava/util/List;Z)Lads_mobile_sdk/rg3;

    move-result-object p2

    :try_start_d9
    iget-object p0, p0, Lads_mobile_sdk/bk1;->h:Lq63;

    new-instance v2, Ljava/net/URL;

    invoke-direct {v2, p1}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    iput-object p2, v0, Lads_mobile_sdk/yj1;->a:Lads_mobile_sdk/rg3;

    iput-object p2, v0, Lads_mobile_sdk/yj1;->b:Lads_mobile_sdk/rg3;

    iput v4, v0, Lads_mobile_sdk/yj1;->e:I

    invoke-static {p0, v2, v6, v0, v10}, Lq63;->a(Lq63;Ljava/net/URL;Ljava/util/Map;Lwx;I)Ljava/lang/Object;

    move-result-object p0
    :try_end_ea
    .catchall {:try_start_d9 .. :try_end_ea} :catchall_100

    if-ne p0, v1, :cond_ed

    :goto_ec
    return-object v1

    :cond_ed
    move-object p1, p2

    move-object p2, p0

    move-object p0, p1

    :goto_f0
    :try_start_f0
    check-cast p2, Lb13;

    instance-of v0, p2, Lads_mobile_sdk/av0;

    if-eqz v0, :cond_fc

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/av0;

    invoke-static {v0, v3}, Lads_mobile_sdk/xh3;->a(Lads_mobile_sdk/av0;Z)V
    :try_end_fc
    .catchall {:try_start_f0 .. :try_end_fc} :catchall_31

    :cond_fc
    invoke-static {p0, v6}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object p2

    :catchall_100
    move-exception p0

    move-object p1, p2

    move-object p2, p0

    move-object p0, p1

    :goto_104
    :try_start_104
    invoke-virtual {p1, p2}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v0, p2, Lox2;

    if-nez v0, :cond_133

    invoke-virtual {p1, p2}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of p1, p2, Lza2;

    if-nez p1, :cond_12b

    instance-of p1, p2, Ljava/util/concurrent/CancellationException;

    if-nez p1, :cond_123

    instance-of p1, p2, Lads_mobile_sdk/mv0;

    if-eqz p1, :cond_11d

    throw p2

    :catchall_11b
    move-exception p1

    goto :goto_134

    :cond_11d
    new-instance p1, Lads_mobile_sdk/tu0;

    invoke-direct {p1, p2}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw p1

    :cond_123
    new-instance p1, Lads_mobile_sdk/ou0;

    check-cast p2, Ljava/util/concurrent/CancellationException;

    invoke-direct {p1, p2}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw p1

    :cond_12b
    new-instance p1, Lads_mobile_sdk/uw0;

    check-cast p2, Lza2;

    invoke-direct {p1, p2}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw p1

    :cond_133
    throw p2
    :try_end_134
    .catchall {:try_start_104 .. :try_end_134} :catchall_11b

    :goto_134
    :try_start_134
    throw p1
    :try_end_135
    .catchall {:try_start_134 .. :try_end_135} :catchall_135

    :catchall_135
    move-exception p2

    invoke-static {p0, p1}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw p2
.end method

.method public final e(Lwx;)Ljava/lang/Object;
    .registers 9

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/wj1;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/wj1;

    iget v1, v0, Lads_mobile_sdk/wj1;->d:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/wj1;->d:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/wj1;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/wj1;-><init>(Lads_mobile_sdk/bk1;Lwx;)V

    :goto_18
    iget-object p1, v0, Lads_mobile_sdk/wj1;->b:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/wj1;->d:I

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    sget-object v5, Lrg2;->a:Lrg2;

    sget-object v6, Lwy;->a:Lwy;

    if-eqz v1, :cond_3b

    if-eq v1, v4, :cond_35

    if-ne v1, v3, :cond_2f

    iget-object p0, v0, Lads_mobile_sdk/wj1;->a:Lads_mobile_sdk/bk1;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_82

    :cond_2f
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v2

    :cond_35
    iget-object p0, v0, Lads_mobile_sdk/wj1;->a:Lads_mobile_sdk/bk1;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_61

    :cond_3b
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iput-object p0, v0, Lads_mobile_sdk/wj1;->a:Lads_mobile_sdk/bk1;

    iput v4, v0, Lads_mobile_sdk/wj1;->d:I

    iget-object p1, p0, Lads_mobile_sdk/bk1;->f:Lads_mobile_sdk/qr0;

    iget-object p1, p1, Lads_mobile_sdk/ov;->a:Ljava/lang/Object;

    check-cast p1, Ld03;

    check-cast p1, Lads_mobile_sdk/eo;

    iget-object v1, p1, Lads_mobile_sdk/eo;->o:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v1

    if-eqz v1, :cond_54

    :cond_52
    move-object p1, v5

    goto :goto_5a

    :cond_54
    invoke-virtual {p1, v2, v0}, Lads_mobile_sdk/eo;->a(Lads_mobile_sdk/t70;Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v6, :cond_52

    :goto_5a
    if-ne p1, v6, :cond_5d

    goto :goto_5e

    :cond_5d
    move-object p1, v5

    :goto_5e
    if-ne p1, v6, :cond_61

    goto :goto_81

    :cond_61
    :goto_61
    iget-object p1, p0, Lads_mobile_sdk/bk1;->f:Lads_mobile_sdk/qr0;

    iget-object p1, p1, Lads_mobile_sdk/ov;->a:Ljava/lang/Object;

    check-cast p1, Ld03;

    check-cast p1, Lads_mobile_sdk/eo;

    iget-object p1, p1, Lads_mobile_sdk/eo;->o:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result p1

    if-eqz p1, :cond_77

    new-instance p0, Lads_mobile_sdk/hv0;

    invoke-direct {p0, v5}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    return-object p0

    :cond_77
    iput-object p0, v0, Lads_mobile_sdk/wj1;->a:Lads_mobile_sdk/bk1;

    iput v3, v0, Lads_mobile_sdk/wj1;->d:I

    invoke-virtual {p0, v0}, Lads_mobile_sdk/al0;->b(Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v6, :cond_82

    :goto_81
    return-object v6

    :cond_82
    :goto_82
    check-cast p1, Lb13;

    instance-of v0, p1, Lads_mobile_sdk/av0;

    if-eqz v0, :cond_8b

    check-cast p1, Lads_mobile_sdk/av0;

    return-object p1

    :cond_8b
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p1, Lads_mobile_sdk/hv0;

    iget-object p1, p1, Lads_mobile_sdk/hv0;->b:Ljava/lang/Object;

    check-cast p1, Lads_mobile_sdk/ue1;

    iget-object p0, p0, Lads_mobile_sdk/bk1;->f:Lads_mobile_sdk/qr0;

    iget-object p0, p0, Lads_mobile_sdk/ov;->a:Ljava/lang/Object;

    check-cast p0, Ld03;

    check-cast p0, Lads_mobile_sdk/eo;

    iget-object p0, p0, Lads_mobile_sdk/eo;->o:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {p0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result p0

    if-eqz p0, :cond_aa

    new-instance p0, Lads_mobile_sdk/hv0;

    invoke-direct {p0, v5}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    return-object p0

    :cond_aa
    new-instance p0, Lads_mobile_sdk/ev0;

    const-string p1, "Failed to get the CSRB flags"

    invoke-direct {p0, p1, v4}, Lads_mobile_sdk/ev0;-><init>(Ljava/lang/String;I)V

    return-object p0
.end method
