.class public final enum Lads_mobile_sdk/de2;
.super Ljava/lang/Enum;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lu33;


# static fields
.field public static final enum b:Lads_mobile_sdk/de2;

.field public static final enum c:Lads_mobile_sdk/de2;

.field public static final enum d:Lads_mobile_sdk/de2;

.field public static final enum e:Lads_mobile_sdk/de2;

.field public static final synthetic f:[Lads_mobile_sdk/de2;


# instance fields
.field public final a:I


# direct methods
.method static constructor <clinit>()V
    .registers 8

    new-instance v0, Lads_mobile_sdk/de2;

    const-string v1, "MISS_REASON_UNKNOWN"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, Lads_mobile_sdk/de2;-><init>(Ljava/lang/String;II)V

    new-instance v1, Lads_mobile_sdk/de2;

    const-string v2, "MISS_REASON_EMPTY"

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3, v3}, Lads_mobile_sdk/de2;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lads_mobile_sdk/de2;->b:Lads_mobile_sdk/de2;

    new-instance v2, Lads_mobile_sdk/de2;

    const-string v3, "MISS_REASON_EXPIRED"

    const/4 v4, 0x2

    invoke-direct {v2, v3, v4, v4}, Lads_mobile_sdk/de2;-><init>(Ljava/lang/String;II)V

    sput-object v2, Lads_mobile_sdk/de2;->c:Lads_mobile_sdk/de2;

    new-instance v3, Lads_mobile_sdk/de2;

    const-string v4, "MISS_REASON_CORRUPTED"

    const/4 v5, 0x3

    invoke-direct {v3, v4, v5, v5}, Lads_mobile_sdk/de2;-><init>(Ljava/lang/String;II)V

    sput-object v3, Lads_mobile_sdk/de2;->d:Lads_mobile_sdk/de2;

    new-instance v4, Lads_mobile_sdk/de2;

    const/4 v5, 0x4

    const/4 v6, -0x1

    const-string v7, "UNRECOGNIZED"

    invoke-direct {v4, v7, v5, v6}, Lads_mobile_sdk/de2;-><init>(Ljava/lang/String;II)V

    sput-object v4, Lads_mobile_sdk/de2;->e:Lads_mobile_sdk/de2;

    filled-new-array {v0, v1, v2, v3, v4}, [Lads_mobile_sdk/de2;

    move-result-object v0

    sput-object v0, Lads_mobile_sdk/de2;->f:[Lads_mobile_sdk/de2;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;II)V
    .registers 4

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput p3, p0, Lads_mobile_sdk/de2;->a:I

    return-void
.end method

.method public static values()[Lads_mobile_sdk/de2;
    .registers 1

    sget-object v0, Lads_mobile_sdk/de2;->f:[Lads_mobile_sdk/de2;

    invoke-virtual {v0}, [Lads_mobile_sdk/de2;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lads_mobile_sdk/de2;

    return-object v0
.end method


# virtual methods
.method public final getNumber()I
    .registers 2

    .prologue
    sget-object v0, Lads_mobile_sdk/de2;->e:Lads_mobile_sdk/de2;

    if-eq p0, v0, :cond_7

    iget p0, p0, Lads_mobile_sdk/de2;->a:I

    return p0

    :cond_7
    sget-object p0, Lads_mobile_sdk/yb1;->a:[B

    const-string p0, "Can\'t get the number of an unknown enum value."

    invoke-static {p0}, Lz6;->s(Ljava/lang/String;)V

    const/4 p0, 0x0

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    .prologue
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "<"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-class v1, Lads_mobile_sdk/de2;

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v1, 0x40

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-static {p0}, Ljava/lang/System;->identityHashCode(Ljava/lang/Object;)I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    sget-object v1, Lads_mobile_sdk/de2;->e:Lads_mobile_sdk/de2;

    if-eq p0, v1, :cond_30

    const-string v1, " number="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lads_mobile_sdk/de2;->getNumber()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    :cond_30
    const-string v1, " name="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 p0, 0x3e

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
