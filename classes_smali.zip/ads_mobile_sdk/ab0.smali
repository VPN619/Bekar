.class public final Lads_mobile_sdk/ab0;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ltv2;


# instance fields
.field public final synthetic a:Lads_mobile_sdk/sb0;

.field public final synthetic b:I


# direct methods
.method public synthetic constructor <init>(Lads_mobile_sdk/sb0;I)V
    .registers 3

    iput p2, p0, Lads_mobile_sdk/ab0;->b:I

    iput-object p1, p0, Lads_mobile_sdk/ab0;->a:Lads_mobile_sdk/sb0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 3

    .prologue
    iget v0, p0, Lads_mobile_sdk/ab0;->b:I

    iget-object p0, p0, Lads_mobile_sdk/ab0;->a:Lads_mobile_sdk/sb0;

    packed-switch v0, :pswitch_data_ea

    new-instance v0, Lads_mobile_sdk/ue0;

    iget-object p0, p0, Lads_mobile_sdk/sb0;->c:Lads_mobile_sdk/sb0;

    invoke-direct {v0, p0}, Lads_mobile_sdk/ue0;-><init>(Lads_mobile_sdk/sb0;)V

    return-object v0

    :pswitch_f  #0x1a
    new-instance v0, Lads_mobile_sdk/z90;

    iget-object p0, p0, Lads_mobile_sdk/sb0;->c:Lads_mobile_sdk/sb0;

    invoke-direct {v0, p0}, Lads_mobile_sdk/z90;-><init>(Lads_mobile_sdk/sb0;)V

    return-object v0

    :pswitch_17  #0x19
    new-instance v0, Lads_mobile_sdk/x90;

    iget-object p0, p0, Lads_mobile_sdk/sb0;->c:Lads_mobile_sdk/sb0;

    invoke-direct {v0, p0}, Lads_mobile_sdk/x90;-><init>(Lads_mobile_sdk/sb0;)V

    return-object v0

    :pswitch_1f  #0x18
    new-instance v0, Lads_mobile_sdk/ke0;

    iget-object p0, p0, Lads_mobile_sdk/sb0;->c:Lads_mobile_sdk/sb0;

    invoke-direct {v0, p0}, Lads_mobile_sdk/ke0;-><init>(Lads_mobile_sdk/sb0;)V

    return-object v0

    :pswitch_27  #0x17
    new-instance v0, Lads_mobile_sdk/dd0;

    iget-object p0, p0, Lads_mobile_sdk/sb0;->c:Lads_mobile_sdk/sb0;

    invoke-direct {v0, p0}, Lads_mobile_sdk/dd0;-><init>(Lads_mobile_sdk/sb0;)V

    return-object v0

    :pswitch_2f  #0x16
    new-instance v0, Lads_mobile_sdk/jd0;

    iget-object p0, p0, Lads_mobile_sdk/sb0;->c:Lads_mobile_sdk/sb0;

    invoke-direct {v0, p0}, Lads_mobile_sdk/jd0;-><init>(Lads_mobile_sdk/sb0;)V

    return-object v0

    :pswitch_37  #0x15
    new-instance v0, Lads_mobile_sdk/bd0;

    iget-object p0, p0, Lads_mobile_sdk/sb0;->c:Lads_mobile_sdk/sb0;

    invoke-direct {v0, p0}, Lads_mobile_sdk/bd0;-><init>(Lads_mobile_sdk/sb0;)V

    return-object v0

    :pswitch_3f  #0x14
    new-instance v0, Lads_mobile_sdk/fc0;

    iget-object p0, p0, Lads_mobile_sdk/sb0;->c:Lads_mobile_sdk/sb0;

    invoke-direct {v0, p0}, Lads_mobile_sdk/fc0;-><init>(Lads_mobile_sdk/sb0;)V

    return-object v0

    :pswitch_47  #0x13
    new-instance v0, Lads_mobile_sdk/ba0;

    iget-object p0, p0, Lads_mobile_sdk/sb0;->c:Lads_mobile_sdk/sb0;

    invoke-direct {v0, p0}, Lads_mobile_sdk/ba0;-><init>(Lads_mobile_sdk/sb0;)V

    return-object v0

    :pswitch_4f  #0x12
    new-instance v0, Lads_mobile_sdk/bc0;

    iget-object p0, p0, Lads_mobile_sdk/sb0;->c:Lads_mobile_sdk/sb0;

    invoke-direct {v0, p0}, Lads_mobile_sdk/bc0;-><init>(Lads_mobile_sdk/sb0;)V

    return-object v0

    :pswitch_57  #0x11
    new-instance v0, Lads_mobile_sdk/bw2;

    iget-object p0, p0, Lads_mobile_sdk/sb0;->c:Lads_mobile_sdk/sb0;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    return-object v0

    :pswitch_5f  #0x10
    new-instance v0, Lads_mobile_sdk/pd0;

    iget-object p0, p0, Lads_mobile_sdk/sb0;->c:Lads_mobile_sdk/sb0;

    invoke-direct {v0, p0}, Lads_mobile_sdk/pd0;-><init>(Lads_mobile_sdk/sb0;)V

    return-object v0

    :pswitch_67  #0xf
    new-instance v0, Lads_mobile_sdk/ee0;

    iget-object p0, p0, Lads_mobile_sdk/sb0;->c:Lads_mobile_sdk/sb0;

    invoke-direct {v0, p0}, Lads_mobile_sdk/ee0;-><init>(Lads_mobile_sdk/sb0;)V

    return-object v0

    :pswitch_6f  #0xe
    new-instance v0, Lads_mobile_sdk/be0;

    iget-object p0, p0, Lads_mobile_sdk/sb0;->c:Lads_mobile_sdk/sb0;

    invoke-direct {v0, p0}, Lads_mobile_sdk/be0;-><init>(Lads_mobile_sdk/sb0;)V

    return-object v0

    :pswitch_77  #0xd
    new-instance v0, Lads_mobile_sdk/yd0;

    iget-object p0, p0, Lads_mobile_sdk/sb0;->c:Lads_mobile_sdk/sb0;

    invoke-direct {v0, p0}, Lads_mobile_sdk/yd0;-><init>(Lads_mobile_sdk/sb0;)V

    return-object v0

    :pswitch_7f  #0xc
    new-instance v0, Lads_mobile_sdk/se0;

    iget-object p0, p0, Lads_mobile_sdk/sb0;->c:Lads_mobile_sdk/sb0;

    invoke-direct {v0, p0}, Lads_mobile_sdk/se0;-><init>(Lads_mobile_sdk/sb0;)V

    return-object v0

    :pswitch_87  #0xb
    new-instance v0, Lads_mobile_sdk/ie0;

    iget-object p0, p0, Lads_mobile_sdk/sb0;->c:Lads_mobile_sdk/sb0;

    const/4 v1, 0x1

    invoke-direct {v0, p0, v1}, Lads_mobile_sdk/ie0;-><init>(Lads_mobile_sdk/sb0;I)V

    return-object v0

    :pswitch_90  #0xa
    new-instance v0, Lads_mobile_sdk/af0;

    iget-object p0, p0, Lads_mobile_sdk/sb0;->c:Lads_mobile_sdk/sb0;

    invoke-direct {v0, p0}, Lads_mobile_sdk/af0;-><init>(Lads_mobile_sdk/sb0;)V

    return-object v0

    :pswitch_98  #0x9
    new-instance v0, Lads_mobile_sdk/vc0;

    iget-object p0, p0, Lads_mobile_sdk/sb0;->c:Lads_mobile_sdk/sb0;

    invoke-direct {v0, p0}, Lads_mobile_sdk/vc0;-><init>(Lads_mobile_sdk/sb0;)V

    return-object v0

    :pswitch_a0  #0x8
    new-instance v0, Lads_mobile_sdk/ie0;

    iget-object p0, p0, Lads_mobile_sdk/sb0;->c:Lads_mobile_sdk/sb0;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lads_mobile_sdk/ie0;-><init>(Lads_mobile_sdk/sb0;I)V

    return-object v0

    :pswitch_a9  #0x7
    new-instance v0, Lads_mobile_sdk/rc0;

    iget-object p0, p0, Lads_mobile_sdk/sb0;->c:Lads_mobile_sdk/sb0;

    invoke-direct {v0, p0}, Lads_mobile_sdk/rc0;-><init>(Lads_mobile_sdk/sb0;)V

    return-object v0

    :pswitch_b1  #0x6
    new-instance v0, Lads_mobile_sdk/ye0;

    iget-object p0, p0, Lads_mobile_sdk/sb0;->c:Lads_mobile_sdk/sb0;

    invoke-direct {v0, p0}, Lads_mobile_sdk/ye0;-><init>(Lads_mobile_sdk/sb0;)V

    return-object v0

    :pswitch_b9  #0x5
    new-instance v0, Lads_mobile_sdk/nc0;

    iget-object p0, p0, Lads_mobile_sdk/sb0;->c:Lads_mobile_sdk/sb0;

    invoke-direct {v0, p0}, Lads_mobile_sdk/nc0;-><init>(Lads_mobile_sdk/sb0;)V

    return-object v0

    :pswitch_c1  #0x4
    new-instance v0, Lads_mobile_sdk/hd0;

    iget-object p0, p0, Lads_mobile_sdk/sb0;->c:Lads_mobile_sdk/sb0;

    invoke-direct {v0, p0}, Lads_mobile_sdk/hd0;-><init>(Lads_mobile_sdk/sb0;)V

    return-object v0

    :pswitch_c9  #0x3
    new-instance v0, Lads_mobile_sdk/fd0;

    iget-object p0, p0, Lads_mobile_sdk/sb0;->c:Lads_mobile_sdk/sb0;

    invoke-direct {v0, p0}, Lads_mobile_sdk/fd0;-><init>(Lads_mobile_sdk/sb0;)V

    return-object v0

    :pswitch_d1  #0x2
    new-instance v0, Lads_mobile_sdk/we0;

    iget-object p0, p0, Lads_mobile_sdk/sb0;->c:Lads_mobile_sdk/sb0;

    invoke-direct {v0, p0}, Lads_mobile_sdk/we0;-><init>(Lads_mobile_sdk/sb0;)V

    return-object v0

    :pswitch_d9  #0x1
    new-instance v0, Lads_mobile_sdk/ie0;

    iget-object p0, p0, Lads_mobile_sdk/sb0;->c:Lads_mobile_sdk/sb0;

    const/4 v1, 0x2

    invoke-direct {v0, p0, v1}, Lads_mobile_sdk/ie0;-><init>(Lads_mobile_sdk/sb0;I)V

    return-object v0

    :pswitch_e2  #0x0
    new-instance v0, Lads_mobile_sdk/sd0;

    iget-object p0, p0, Lads_mobile_sdk/sb0;->c:Lads_mobile_sdk/sb0;

    invoke-direct {v0, p0}, Lads_mobile_sdk/sd0;-><init>(Lads_mobile_sdk/sb0;)V

    return-object v0

    :pswitch_data_ea
    .packed-switch 0x0
        :pswitch_e2  #00000000
        :pswitch_d9  #00000001
        :pswitch_d1  #00000002
        :pswitch_c9  #00000003
        :pswitch_c1  #00000004
        :pswitch_b9  #00000005
        :pswitch_b1  #00000006
        :pswitch_a9  #00000007
        :pswitch_a0  #00000008
        :pswitch_98  #00000009
        :pswitch_90  #0000000a
        :pswitch_87  #0000000b
        :pswitch_7f  #0000000c
        :pswitch_77  #0000000d
        :pswitch_6f  #0000000e
        :pswitch_67  #0000000f
        :pswitch_5f  #00000010
        :pswitch_57  #00000011
        :pswitch_4f  #00000012
        :pswitch_47  #00000013
        :pswitch_3f  #00000014
        :pswitch_37  #00000015
        :pswitch_2f  #00000016
        :pswitch_27  #00000017
        :pswitch_1f  #00000018
        :pswitch_17  #00000019
        :pswitch_f  #0000001a
    .end packed-switch
.end method
