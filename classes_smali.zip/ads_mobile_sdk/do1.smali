.class public final Lads_mobile_sdk/do1;
.super Lzz0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lbk0;


# instance fields
.field public final synthetic a:Lads_mobile_sdk/ko1;

.field public final synthetic i:I


# direct methods
.method public synthetic constructor <init>(Lads_mobile_sdk/ko1;I)V
    .registers 3

    iput p2, p0, Lads_mobile_sdk/do1;->i:I

    iput-object p1, p0, Lads_mobile_sdk/do1;->a:Lads_mobile_sdk/ko1;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lzz0;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .prologue
    iget v0, p0, Lads_mobile_sdk/do1;->i:I

    packed-switch v0, :pswitch_data_78

    check-cast p1, Lcom/google/android/gms/ads/mediation/MediationRewardedAd;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p0, Lads_mobile_sdk/do1;->a:Lads_mobile_sdk/ko1;

    monitor-enter p0

    :try_start_d
    iput-object p1, p0, Lads_mobile_sdk/ko1;->e:Lcom/google/android/gms/ads/mediation/MediationRewardedAd;

    sget-object p1, Lrg2;->a:Lrg2;
    :try_end_11
    .catchall {:try_start_d .. :try_end_11} :catchall_13

    monitor-exit p0

    return-object p1

    :catchall_13
    move-exception p1

    monitor-exit p0

    throw p1

    :pswitch_16  #0x5
    check-cast p1, Lcom/google/android/gms/ads/mediation/MediationRewardedAd;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p0, Lads_mobile_sdk/do1;->a:Lads_mobile_sdk/ko1;

    monitor-enter p0

    :try_start_1e
    iput-object p1, p0, Lads_mobile_sdk/ko1;->e:Lcom/google/android/gms/ads/mediation/MediationRewardedAd;

    sget-object p1, Lrg2;->a:Lrg2;
    :try_end_22
    .catchall {:try_start_1e .. :try_end_22} :catchall_24

    monitor-exit p0

    return-object p1

    :catchall_24
    move-exception p1

    monitor-exit p0

    throw p1

    :pswitch_27  #0x4
    check-cast p1, Lcom/google/android/gms/ads/mediation/UnifiedNativeAdMapper;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p0, Lads_mobile_sdk/do1;->a:Lads_mobile_sdk/ko1;

    new-instance v0, Lads_mobile_sdk/vk3;

    invoke-direct {v0, p1}, Lads_mobile_sdk/vk3;-><init>(Lcom/google/android/gms/ads/mediation/UnifiedNativeAdMapper;)V

    iput-object v0, p0, Lads_mobile_sdk/ko1;->c:Ley2;

    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0

    :pswitch_38  #0x3
    check-cast p1, Lcom/google/android/gms/ads/mediation/NativeAdMapper;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p0, Lads_mobile_sdk/do1;->a:Lads_mobile_sdk/ko1;

    new-instance v0, Lads_mobile_sdk/ju1;

    invoke-direct {v0, p1}, Lads_mobile_sdk/ju1;-><init>(Lcom/google/android/gms/ads/mediation/NativeAdMapper;)V

    iput-object v0, p0, Lads_mobile_sdk/ko1;->c:Ley2;

    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0

    :pswitch_49  #0x2
    check-cast p1, Lcom/google/android/gms/ads/mediation/MediationInterstitialAd;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p0, Lads_mobile_sdk/do1;->a:Lads_mobile_sdk/ko1;

    monitor-enter p0

    :try_start_51
    iput-object p1, p0, Lads_mobile_sdk/ko1;->d:Lcom/google/android/gms/ads/mediation/MediationInterstitialAd;

    sget-object p1, Lrg2;->a:Lrg2;
    :try_end_55
    .catchall {:try_start_51 .. :try_end_55} :catchall_57

    monitor-exit p0

    return-object p1

    :catchall_57
    move-exception p1

    monitor-exit p0

    throw p1

    :pswitch_5a  #0x1
    check-cast p1, Landroid/view/View;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p0, Lads_mobile_sdk/do1;->a:Lads_mobile_sdk/ko1;

    iput-object p1, p0, Lads_mobile_sdk/ko1;->b:Landroid/view/View;

    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0

    :pswitch_66  #0x0
    check-cast p1, Lcom/google/android/gms/ads/mediation/MediationAppOpenAd;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p0, Lads_mobile_sdk/do1;->a:Lads_mobile_sdk/ko1;

    monitor-enter p0

    :try_start_6e
    iput-object p1, p0, Lads_mobile_sdk/ko1;->f:Lcom/google/android/gms/ads/mediation/MediationAppOpenAd;

    sget-object p1, Lrg2;->a:Lrg2;
    :try_end_72
    .catchall {:try_start_6e .. :try_end_72} :catchall_74

    monitor-exit p0

    return-object p1

    :catchall_74
    move-exception p1

    monitor-exit p0

    throw p1

    nop

    :pswitch_data_78
    .packed-switch 0x0
        :pswitch_66  #00000000
        :pswitch_5a  #00000001
        :pswitch_49  #00000002
        :pswitch_38  #00000003
        :pswitch_27  #00000004
        :pswitch_16  #00000005
    .end packed-switch
.end method
