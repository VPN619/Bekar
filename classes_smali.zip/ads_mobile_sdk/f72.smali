.class public final Lads_mobile_sdk/f72;
.super Lpb;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final c:Lads_mobile_sdk/s52;

.field public final d:Lads_mobile_sdk/a2;

.field public final e:Lnb1;

.field public f:Lads_mobile_sdk/gj1;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/s52;Lads_mobile_sdk/a2;Lads_mobile_sdk/qr0;Lly;)V
    .registers 5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0, p3, p4}, Lpb;-><init>(Lads_mobile_sdk/qr0;Lly;)V

    iput-object p1, p0, Lads_mobile_sdk/f72;->c:Lads_mobile_sdk/s52;

    iput-object p2, p0, Lads_mobile_sdk/f72;->d:Lads_mobile_sdk/a2;

    new-instance p1, Lnb1;

    invoke-direct {p1}, Lnb1;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/f72;->e:Lnb1;

    return-void
.end method

.method public static a(Lads_mobile_sdk/f72;Lads_mobile_sdk/cy0;ZLwx;)Ljava/lang/Object;
    .registers 13

    .prologue
    instance-of v0, p3, Lads_mobile_sdk/d72;

    if-eqz v0, :cond_13

    move-object v0, p3

    check-cast v0, Lads_mobile_sdk/d72;

    iget v1, v0, Lads_mobile_sdk/d72;->g:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/d72;->g:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/d72;

    invoke-direct {v0, p0, p3}, Lads_mobile_sdk/d72;-><init>(Lads_mobile_sdk/f72;Lwx;)V

    :goto_18
    iget-object p3, v0, Lads_mobile_sdk/d72;->e:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/d72;->g:I

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    sget-object v5, Lwy;->a:Lwy;

    if-eqz v1, :cond_51

    if-eq v1, v3, :cond_3f

    if-ne v1, v2, :cond_39

    iget-object p0, v0, Lads_mobile_sdk/d72;->c:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/f72;

    iget-object p1, v0, Lads_mobile_sdk/d72;->b:Ljava/lang/Object;

    check-cast p1, Llb1;

    iget-object p2, v0, Lads_mobile_sdk/d72;->a:Lads_mobile_sdk/f72;

    :try_start_31
    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_34
    .catchall {:try_start_31 .. :try_end_34} :catchall_36

    goto/16 :goto_d3

    :catchall_36
    move-exception p0

    goto/16 :goto_e5

    :cond_39
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v4

    :cond_3f
    iget-boolean p2, v0, Lads_mobile_sdk/d72;->d:Z

    iget-object p0, v0, Lads_mobile_sdk/d72;->c:Ljava/lang/Object;

    check-cast p0, Llb1;

    iget-object p1, v0, Lads_mobile_sdk/d72;->b:Ljava/lang/Object;

    check-cast p1, Landroid/webkit/WebView;

    iget-object v1, v0, Lads_mobile_sdk/d72;->a:Lads_mobile_sdk/f72;

    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V

    move-object p3, p0

    move-object p0, v1

    goto :goto_67

    :cond_51
    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p3, p0, Lads_mobile_sdk/f72;->e:Lnb1;

    iput-object p0, v0, Lads_mobile_sdk/d72;->a:Lads_mobile_sdk/f72;

    iput-object p1, v0, Lads_mobile_sdk/d72;->b:Ljava/lang/Object;

    iput-object p3, v0, Lads_mobile_sdk/d72;->c:Ljava/lang/Object;

    iput-boolean p2, v0, Lads_mobile_sdk/d72;->d:Z

    iput v3, v0, Lads_mobile_sdk/d72;->g:I

    invoke-virtual {p3, v0}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v5, :cond_67

    goto :goto_ce

    :cond_67
    :goto_67
    :try_start_67
    iget-object v1, p0, Lads_mobile_sdk/f72;->d:Lads_mobile_sdk/a2;

    iget-boolean v1, v1, Lads_mobile_sdk/a2;->O:Z

    if-eqz v1, :cond_e7

    iget-object v1, p0, Lads_mobile_sdk/f72;->c:Lads_mobile_sdk/s52;

    iget-object v1, v1, Lads_mobile_sdk/s52;->f:Lads_mobile_sdk/ah3;

    const-string v6, "IsActive"

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_76
    .catchall {:try_start_67 .. :try_end_76} :catchall_7f

    :try_start_76
    sget-object v7, Lgt0;->o:Llv;

    iget-boolean v7, v7, Llv;->a:Z

    invoke-static {v7}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1
    :try_end_7e
    .catch Ljava/lang/Exception; {:try_start_76 .. :try_end_7e} :catch_82
    .catchall {:try_start_76 .. :try_end_7e} :catchall_7f

    goto :goto_87

    :catchall_7f
    move-exception p0

    goto/16 :goto_ed

    :catch_82
    move-exception v7

    :try_start_83
    invoke-virtual {v1, v6, v7}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V

    move-object v1, v4

    :goto_87
    if-eqz v1, :cond_e7

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_e7

    iget-object v1, p0, Lads_mobile_sdk/f72;->d:Lads_mobile_sdk/a2;

    iget-object v1, v1, Lads_mobile_sdk/a2;->S:Lads_mobile_sdk/j82;

    iget-boolean v1, v1, Lads_mobile_sdk/j82;->c:Z

    if-eqz v1, :cond_e7

    iget-object v1, p0, Lpb;->a:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/qr0;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v6, "gads:omid_javascript_session_service:enabled"

    sget-object v7, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sget-object v8, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    invoke-virtual {v1, v6, v7, v8}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-nez v1, :cond_b1

    goto :goto_e7

    :cond_b1
    iget-object v1, p0, Lads_mobile_sdk/f72;->f:Lads_mobile_sdk/gj1;

    if-eqz v1, :cond_bb

    const-string p0, "Already started javascript session service"

    invoke-static {p0, v4}, Lads_mobile_sdk/nw;->c(Ljava/lang/String;Ljava/lang/Exception;)V

    goto :goto_e7

    :cond_bb
    new-instance v1, Lads_mobile_sdk/e72;

    invoke-direct {v1, p0, p1, p2, v4}, Lads_mobile_sdk/e72;-><init>(Lads_mobile_sdk/f72;Landroid/webkit/WebView;ZLvx;)V

    iput-object p0, v0, Lads_mobile_sdk/d72;->a:Lads_mobile_sdk/f72;

    iput-object p3, v0, Lads_mobile_sdk/d72;->b:Ljava/lang/Object;

    iput-object p0, v0, Lads_mobile_sdk/d72;->c:Ljava/lang/Object;

    iput v2, v0, Lads_mobile_sdk/d72;->g:I

    invoke-virtual {p0, v1, v0}, Lpb;->a(Lbk0;Lwx;)Ljava/lang/Object;

    move-result-object p1
    :try_end_cc
    .catchall {:try_start_83 .. :try_end_cc} :catchall_7f

    if-ne p1, v5, :cond_cf

    :goto_ce
    return-object v5

    :cond_cf
    move-object p2, p3

    move-object p3, p1

    move-object p1, p2

    move-object p2, p0

    :goto_d3
    :try_start_d3
    check-cast p3, Lads_mobile_sdk/gj1;

    iput-object p3, p0, Lads_mobile_sdk/f72;->f:Lads_mobile_sdk/gj1;

    iget-object p0, p2, Lads_mobile_sdk/f72;->f:Lads_mobile_sdk/gj1;

    if-eqz p0, :cond_dc

    goto :goto_dd

    :cond_dc
    const/4 v3, 0x0

    :goto_dd
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0
    :try_end_e1
    .catchall {:try_start_d3 .. :try_end_e1} :catchall_36

    invoke-interface {p1, v4}, Llb1;->b(Ljava/lang/Object;)V

    return-object p0

    :goto_e5
    move-object p3, p1

    goto :goto_ed

    :cond_e7
    :goto_e7
    :try_start_e7
    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;
    :try_end_e9
    .catchall {:try_start_e7 .. :try_end_e9} :catchall_7f

    invoke-interface {p3, v4}, Llb1;->b(Ljava/lang/Object;)V

    return-object p0

    :goto_ed
    invoke-interface {p3, v4}, Llb1;->b(Ljava/lang/Object;)V

    throw p0
.end method

.method public static a(Lads_mobile_sdk/f72;Lads_mobile_sdk/sy0;Lwx;)Ljava/lang/Object;
    .registers 14

    .prologue
    instance-of v0, p2, Lads_mobile_sdk/a72;

    if-eqz v0, :cond_13

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/a72;

    iget v1, v0, Lads_mobile_sdk/a72;->f:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/a72;->f:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/a72;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/a72;-><init>(Lads_mobile_sdk/f72;Lwx;)V

    :goto_18
    iget-object p2, v0, Lads_mobile_sdk/a72;->d:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/a72;->f:I

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v8, 0x0

    sget-object v10, Lwy;->a:Lwy;

    if-eqz v1, :cond_47

    if-eq v1, v3, :cond_39

    if-ne v1, v2, :cond_32

    iget-object p0, v0, Lads_mobile_sdk/a72;->a:Ljava/lang/Object;

    check-cast p0, Llb1;

    :try_start_2b
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_2e
    .catchall {:try_start_2b .. :try_end_2e} :catchall_2f

    goto :goto_78

    :catchall_2f
    move-exception v0

    move-object p1, v0

    goto :goto_7e

    :cond_32
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0

    :cond_39
    iget-object p0, v0, Lads_mobile_sdk/a72;->c:Lnb1;

    iget-object p1, v0, Lads_mobile_sdk/a72;->b:Lads_mobile_sdk/sy0;

    iget-object v1, v0, Lads_mobile_sdk/a72;->a:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/f72;

    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    move-object v6, v1

    :goto_45
    move-object v5, p1

    goto :goto_5e

    :cond_47
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p2, p0, Lads_mobile_sdk/f72;->e:Lnb1;

    iput-object p0, v0, Lads_mobile_sdk/a72;->a:Ljava/lang/Object;

    iput-object p1, v0, Lads_mobile_sdk/a72;->b:Lads_mobile_sdk/sy0;

    iput-object p2, v0, Lads_mobile_sdk/a72;->c:Lnb1;

    iput v3, v0, Lads_mobile_sdk/a72;->f:I

    invoke-virtual {p2, v0}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v10, :cond_5b

    goto :goto_77

    :cond_5b
    move-object v6, p0

    move-object p0, p2

    goto :goto_45

    :goto_5e
    :try_start_5e
    iget-object v7, v6, Lads_mobile_sdk/f72;->f:Lads_mobile_sdk/gj1;

    if-nez v7, :cond_63

    goto :goto_78

    :cond_63
    new-instance v4, Lads_mobile_sdk/al;

    const/4 v9, 0x1

    invoke-direct/range {v4 .. v9}, Lads_mobile_sdk/al;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lvx;I)V

    iput-object p0, v0, Lads_mobile_sdk/a72;->a:Ljava/lang/Object;

    iput-object v8, v0, Lads_mobile_sdk/a72;->b:Lads_mobile_sdk/sy0;

    iput-object v8, v0, Lads_mobile_sdk/a72;->c:Lnb1;

    iput v2, v0, Lads_mobile_sdk/a72;->f:I

    invoke-virtual {v6, v4, v0}, Lpb;->a(Lbk0;Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v10, :cond_78

    :goto_77
    return-object v10

    :cond_78
    :goto_78
    sget-object p1, Lrg2;->a:Lrg2;
    :try_end_7a
    .catchall {:try_start_5e .. :try_end_7a} :catchall_2f

    invoke-interface {p0, v8}, Llb1;->b(Ljava/lang/Object;)V

    return-object p1

    :goto_7e
    invoke-interface {p0, v8}, Llb1;->b(Ljava/lang/Object;)V

    throw p1
.end method

.method public static a(Lads_mobile_sdk/f72;Landroid/view/View;Lads_mobile_sdk/fs0;Lwx;)Ljava/lang/Object;
    .registers 16

    .prologue
    instance-of v0, p3, Lads_mobile_sdk/w62;

    if-eqz v0, :cond_13

    move-object v0, p3

    check-cast v0, Lads_mobile_sdk/w62;

    iget v1, v0, Lads_mobile_sdk/w62;->h:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/w62;->h:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/w62;

    invoke-direct {v0, p0, p3}, Lads_mobile_sdk/w62;-><init>(Lads_mobile_sdk/f72;Lwx;)V

    :goto_18
    iget-object p3, v0, Lads_mobile_sdk/w62;->f:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/w62;->h:I

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    sget-object v5, Lwy;->a:Lwy;

    if-eqz v1, :cond_49

    if-eq v1, v3, :cond_38

    if-ne v1, v2, :cond_32

    iget-object p0, v0, Lads_mobile_sdk/w62;->a:Ljava/lang/Object;

    check-cast p0, Llb1;

    :try_start_2b
    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_2e
    .catchall {:try_start_2b .. :try_end_2e} :catchall_2f

    goto :goto_7e

    :catchall_2f
    move-exception v0

    move-object p1, v0

    goto :goto_84

    :cond_32
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v4

    :cond_38
    iget-object p0, v0, Lads_mobile_sdk/w62;->e:Lnb1;

    iget-object p2, v0, Lads_mobile_sdk/w62;->c:Lads_mobile_sdk/fs0;

    iget-object p1, v0, Lads_mobile_sdk/w62;->b:Landroid/view/View;

    iget-object v1, v0, Lads_mobile_sdk/w62;->a:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/f72;

    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V

    move-object v7, v1

    :goto_46
    move-object v9, p1

    move-object v10, p2

    goto :goto_62

    :cond_49
    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p3, p0, Lads_mobile_sdk/f72;->e:Lnb1;

    iput-object p0, v0, Lads_mobile_sdk/w62;->a:Ljava/lang/Object;

    iput-object p1, v0, Lads_mobile_sdk/w62;->b:Landroid/view/View;

    iput-object p2, v0, Lads_mobile_sdk/w62;->c:Lads_mobile_sdk/fs0;

    iput-object p3, v0, Lads_mobile_sdk/w62;->e:Lnb1;

    iput v3, v0, Lads_mobile_sdk/w62;->h:I

    invoke-virtual {p3, v0}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v5, :cond_5f

    goto :goto_7d

    :cond_5f
    move-object v7, p0

    move-object p0, p3

    goto :goto_46

    :goto_62
    :try_start_62
    iget-object v8, v7, Lads_mobile_sdk/f72;->f:Lads_mobile_sdk/gj1;

    if-nez v8, :cond_67

    goto :goto_7e

    :cond_67
    new-instance v6, Lads_mobile_sdk/x62;

    const/4 v11, 0x0

    invoke-direct/range {v6 .. v11}, Lads_mobile_sdk/x62;-><init>(Lads_mobile_sdk/f72;Lads_mobile_sdk/gj1;Landroid/view/View;Lads_mobile_sdk/fs0;Lvx;)V

    iput-object p0, v0, Lads_mobile_sdk/w62;->a:Ljava/lang/Object;

    iput-object v4, v0, Lads_mobile_sdk/w62;->b:Landroid/view/View;

    iput-object v4, v0, Lads_mobile_sdk/w62;->c:Lads_mobile_sdk/fs0;

    iput-object v4, v0, Lads_mobile_sdk/w62;->e:Lnb1;

    iput v2, v0, Lads_mobile_sdk/w62;->h:I

    invoke-virtual {v7, v6, v0}, Lpb;->a(Lbk0;Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v5, :cond_7e

    :goto_7d
    return-object v5

    :cond_7e
    :goto_7e
    sget-object p1, Lrg2;->a:Lrg2;
    :try_end_80
    .catchall {:try_start_62 .. :try_end_80} :catchall_2f

    invoke-interface {p0, v4}, Llb1;->b(Ljava/lang/Object;)V

    return-object p1

    :goto_84
    invoke-interface {p0, v4}, Llb1;->b(Ljava/lang/Object;)V

    throw p1
.end method

.method public static a(Lads_mobile_sdk/f72;Ltz2;Lwx;)Ljava/lang/Object;
    .registers 14

    .prologue
    instance-of v0, p2, Lads_mobile_sdk/y62;

    if-eqz v0, :cond_13

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/y62;

    iget v1, v0, Lads_mobile_sdk/y62;->f:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/y62;->f:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/y62;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/y62;-><init>(Lads_mobile_sdk/f72;Lwx;)V

    :goto_18
    iget-object p2, v0, Lads_mobile_sdk/y62;->d:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/y62;->f:I

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v8, 0x0

    sget-object v10, Lwy;->a:Lwy;

    if-eqz v1, :cond_49

    if-eq v1, v3, :cond_3b

    if-ne v1, v2, :cond_34

    iget-object p0, v0, Lads_mobile_sdk/y62;->b:Ljava/lang/Object;

    check-cast p0, Llb1;

    iget-object p1, v0, Lads_mobile_sdk/y62;->a:Lads_mobile_sdk/f72;

    :try_start_2d
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_30
    .catchall {:try_start_2d .. :try_end_30} :catchall_31

    goto :goto_7a

    :catchall_31
    move-exception v0

    move-object p1, v0

    goto :goto_84

    :cond_34
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0

    :cond_3b
    iget-object p0, v0, Lads_mobile_sdk/y62;->c:Lnb1;

    iget-object p1, v0, Lads_mobile_sdk/y62;->b:Ljava/lang/Object;

    check-cast p1, Ltz2;

    iget-object v1, v0, Lads_mobile_sdk/y62;->a:Lads_mobile_sdk/f72;

    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    move-object v5, v1

    :goto_47
    move-object v7, p1

    goto :goto_60

    :cond_49
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p2, p0, Lads_mobile_sdk/f72;->e:Lnb1;

    iput-object p0, v0, Lads_mobile_sdk/y62;->a:Lads_mobile_sdk/f72;

    iput-object p1, v0, Lads_mobile_sdk/y62;->b:Ljava/lang/Object;

    iput-object p2, v0, Lads_mobile_sdk/y62;->c:Lnb1;

    iput v3, v0, Lads_mobile_sdk/y62;->f:I

    invoke-virtual {p2, v0}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v10, :cond_5d

    goto :goto_78

    :cond_5d
    move-object v5, p0

    move-object p0, p2

    goto :goto_47

    :goto_60
    :try_start_60
    iget-object v6, v5, Lads_mobile_sdk/f72;->f:Lads_mobile_sdk/gj1;

    if-eqz v6, :cond_7f

    new-instance v4, Lads_mobile_sdk/m62;

    const/4 v9, 0x2

    invoke-direct/range {v4 .. v9}, Lads_mobile_sdk/m62;-><init>(Lpb;Ljava/lang/Object;Ljava/lang/Object;Lvx;I)V

    iput-object v5, v0, Lads_mobile_sdk/y62;->a:Lads_mobile_sdk/f72;

    iput-object p0, v0, Lads_mobile_sdk/y62;->b:Ljava/lang/Object;

    iput-object v8, v0, Lads_mobile_sdk/y62;->c:Lnb1;

    iput v2, v0, Lads_mobile_sdk/y62;->f:I

    invoke-virtual {v5, v4, v0}, Lpb;->a(Lbk0;Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v10, :cond_79

    :goto_78
    return-object v10

    :cond_79
    move-object p1, v5

    :goto_7a
    iput-object v8, p1, Lads_mobile_sdk/f72;->f:Lads_mobile_sdk/gj1;

    sget-object p1, Lrg2;->a:Lrg2;
    :try_end_7e
    .catchall {:try_start_60 .. :try_end_7e} :catchall_31

    goto :goto_80

    :cond_7f
    move-object p1, v8

    :goto_80
    invoke-interface {p0, v8}, Llb1;->b(Ljava/lang/Object;)V

    return-object p1

    :goto_84
    invoke-interface {p0, v8}, Llb1;->b(Ljava/lang/Object;)V

    throw p1
.end method

.method public static a(Lads_mobile_sdk/f72;Lwx;)Ljava/lang/Object;
    .registers 6

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/c72;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/c72;

    iget v1, v0, Lads_mobile_sdk/c72;->e:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/c72;->e:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/c72;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/c72;-><init>(Lads_mobile_sdk/f72;Lwx;)V

    :goto_18
    iget-object p1, v0, Lads_mobile_sdk/c72;->c:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/c72;->e:I

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v1, :cond_32

    if-ne v1, v2, :cond_2c

    iget-object p0, v0, Lads_mobile_sdk/c72;->b:Lnb1;

    iget-object v0, v0, Lads_mobile_sdk/c72;->a:Lads_mobile_sdk/f72;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    move-object p1, p0

    move-object p0, v0

    goto :goto_46

    :cond_2c
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v3

    :cond_32
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/f72;->e:Lnb1;

    iput-object p0, v0, Lads_mobile_sdk/c72;->a:Lads_mobile_sdk/f72;

    iput-object p1, v0, Lads_mobile_sdk/c72;->b:Lnb1;

    iput v2, v0, Lads_mobile_sdk/c72;->e:I

    invoke-virtual {p1, v0}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v0

    sget-object v1, Lwy;->a:Lwy;

    if-ne v0, v1, :cond_46

    return-object v1

    :cond_46
    :goto_46
    :try_start_46
    iget-object p0, p0, Lads_mobile_sdk/f72;->f:Lads_mobile_sdk/gj1;

    if-eqz p0, :cond_4b

    goto :goto_4c

    :cond_4b
    const/4 v2, 0x0

    :goto_4c
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0
    :try_end_50
    .catchall {:try_start_46 .. :try_end_50} :catchall_54

    invoke-virtual {p1, v3}, Lnb1;->b(Ljava/lang/Object;)V

    return-object p0

    :catchall_54
    move-exception p0

    invoke-virtual {p1, v3}, Lnb1;->b(Ljava/lang/Object;)V

    throw p0
.end method
