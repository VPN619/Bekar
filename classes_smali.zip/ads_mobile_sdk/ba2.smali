.class public final Lads_mobile_sdk/ba2;
.super Lads_mobile_sdk/oa3;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final d:Landroid/content/Context;

.field public final e:I

.field public final f:Lads_mobile_sdk/i41;


# direct methods
.method public constructor <init>(Landroid/content/Context;ILads_mobile_sdk/i41;)V
    .registers 6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0, v0, v1}, Lads_mobile_sdk/k61;-><init>(Lads_mobile_sdk/fw0;I)V

    iput-object p1, p0, Lads_mobile_sdk/ba2;->d:Landroid/content/Context;

    iput p2, p0, Lads_mobile_sdk/ba2;->e:I

    iput-object p3, p0, Lads_mobile_sdk/ba2;->f:Lads_mobile_sdk/i41;

    return-void
.end method


# virtual methods
.method public final a()Lads_mobile_sdk/lw0;
    .registers 1

    sget-object p0, Lads_mobile_sdk/lw0;->G:Lads_mobile_sdk/lw0;

    return-object p0
.end method

.method public final d(Lvx;)Ljava/lang/Object;
    .registers 16

    .prologue
    new-instance p1, Lads_mobile_sdk/hv0;

    new-instance v0, Lads_mobile_sdk/aa2;

    iget-object v1, p0, Lads_mobile_sdk/ba2;->d:Landroid/content/Context;

    move-object v2, v1

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v2}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v3

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    const/16 v5, 0x80

    invoke-virtual {v3, v4, v5}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v3

    iget-object v3, v3, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;

    move-object v4, v2

    move-object v2, v3

    new-instance v3, Ljava/lang/Integer;

    iget v5, p0, Lads_mobile_sdk/ba2;->e:I

    invoke-direct {v3, v5}, Ljava/lang/Integer;-><init>(I)V

    invoke-virtual {v4}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v6

    invoke-virtual {v4}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v7

    invoke-virtual {v6, v7}, Landroid/content/pm/PackageManager;->getApplicationLabel(Landroid/content/pm/ApplicationInfo;)Ljava/lang/CharSequence;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v6

    const/16 v7, 0x1e

    const/4 v8, 0x0

    :try_start_3a
    sget v9, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v9, v7, :cond_51

    invoke-virtual {v4}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v9

    invoke-virtual {v4}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v10

    iget-object v10, v10, Landroid/content/pm/ApplicationInfo;->packageName:Ljava/lang/String;

    invoke-virtual {v9, v10}, Landroid/content/pm/PackageManager;->getInstallSourceInfo(Ljava/lang/String;)Landroid/content/pm/InstallSourceInfo;

    move-result-object v9

    invoke-virtual {v9}, Landroid/content/pm/InstallSourceInfo;->getInstallingPackageName()Ljava/lang/String;

    move-result-object v9

    goto :goto_61

    :cond_51
    invoke-virtual {v4}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v9

    invoke-virtual {v4}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v10

    iget-object v10, v10, Landroid/content/pm/ApplicationInfo;->packageName:Ljava/lang/String;

    invoke-virtual {v9, v10}, Landroid/content/pm/PackageManager;->getInstallerPackageName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9
    :try_end_5f
    .catchall {:try_start_3a .. :try_end_5f} :catchall_60

    goto :goto_61

    :catchall_60
    move-object v9, v8

    :goto_61
    :try_start_61
    sget v10, Landroid/os/Build$VERSION;->SDK_INT:I

    if-lt v10, v7, :cond_78

    invoke-virtual {v4}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v7

    invoke-virtual {v4}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v10

    iget-object v10, v10, Landroid/content/pm/ApplicationInfo;->packageName:Ljava/lang/String;

    invoke-virtual {v7, v10}, Landroid/content/pm/PackageManager;->getInstallSourceInfo(Ljava/lang/String;)Landroid/content/pm/InstallSourceInfo;

    move-result-object v7

    invoke-virtual {v7}, Landroid/content/pm/InstallSourceInfo;->getInitiatingPackageName()Ljava/lang/String;

    move-result-object v7
    :try_end_77
    .catchall {:try_start_61 .. :try_end_77} :catchall_78

    goto :goto_79

    :catchall_78
    :cond_78
    move-object v7, v8

    :goto_79
    invoke-virtual {v4}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v10, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v5, ".android."

    invoke-virtual {v10, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    sget-object v5, Lads_mobile_sdk/ax0;->f:Lzn1;

    iget-object p0, p0, Lads_mobile_sdk/ba2;->f:Lads_mobile_sdk/i41;

    invoke-virtual {p0}, Lads_mobile_sdk/i41;->a()Lfm0;

    move-result-object v5

    const-string v10, ""

    if-eqz v5, :cond_a2

    iget-object v5, v5, Lfm0;->b:Ljava/lang/Object;

    check-cast v5, Ljava/lang/String;

    goto :goto_a3

    :cond_a2
    move-object v5, v10

    :goto_a3
    sget-object v11, Lads_mobile_sdk/ax0;->h:Ljs1;

    invoke-static {v11, v5}, Ljs1;->a(Ljs1;Ljava/lang/CharSequence;)Lx5;

    move-result-object v5

    if-eqz v5, :cond_b9

    iget-object v5, v5, Lx5;->e:Ljava/lang/Object;

    check-cast v5, Le61;

    const/4 v12, 0x1

    invoke-virtual {v5, v12}, Le61;->e(I)Lc61;

    move-result-object v5

    if-eqz v5, :cond_b9

    iget-object v5, v5, Lc61;->a:Ljava/lang/String;

    goto :goto_ba

    :cond_b9
    move-object v5, v8

    :goto_ba
    invoke-virtual {p0}, Lads_mobile_sdk/i41;->a()Lfm0;

    move-result-object p0

    if-eqz p0, :cond_c5

    iget-object p0, p0, Lfm0;->b:Ljava/lang/Object;

    move-object v10, p0

    check-cast v10, Ljava/lang/String;

    :cond_c5
    invoke-static {v11, v10}, Ljs1;->a(Ljs1;Ljava/lang/CharSequence;)Lx5;

    move-result-object p0

    if-eqz p0, :cond_d8

    iget-object p0, p0, Lx5;->e:Ljava/lang/Object;

    check-cast p0, Le61;

    const/4 v10, 0x2

    invoke-virtual {p0, v10}, Le61;->e(I)Lc61;

    move-result-object p0

    if-eqz p0, :cond_d8

    iget-object v8, p0, Lc61;->a:Ljava/lang/String;

    :cond_d8
    move-object v13, v7

    move-object v7, v4

    move-object v4, v6

    move-object v6, v13

    move-object v13, v8

    move-object v8, v5

    move-object v5, v9

    move-object v9, v13

    invoke-direct/range {v0 .. v9}, Lads_mobile_sdk/aa2;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-direct {p1, v0}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    return-object p1
.end method
