.class public final Lads_mobile_sdk/d6;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Ljava/io/File;

.field public volatile b:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .registers 4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/io/File;

    invoke-virtual {p1}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    move-result-object p1

    const-string v1, "gma_ad_responses"

    invoke-direct {v0, p1, v1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    iput-object v0, p0, Lads_mobile_sdk/d6;->a:Ljava/io/File;

    return-void
.end method

.method public static a(Ljava/lang/String;)Ljava/lang/String;
    .registers 7

    .prologue
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_3
    const-string v0, "MD5"

    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v0

    sget-object v1, Lip;->a:Ljava/nio/charset/Charset;

    invoke-virtual {p0, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0, p0}, Ljava/security/MessageDigest;->update([B)V

    invoke-virtual {v0}, Ljava/security/MessageDigest;->digest()[B

    move-result-object p0

    array-length v0, p0

    mul-int/lit8 v0, v0, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(I)V

    array-length v0, p0

    const/4 v2, 0x0

    :goto_23
    if-ge v2, v0, :cond_40

    aget-byte v3, p0, v2

    const-string v4, "%02x"

    invoke-static {v3}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v3

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x1

    invoke-static {v3, v5}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v3

    invoke-static {v4, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v2, v2, 0x1

    goto :goto_23

    :cond_40
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_44
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_44} :catch_45

    return-object p0

    :catch_45
    move-exception p0

    const-string v0, "Failed to calculate checksum"

    const/4 v1, 0x4

    invoke-static {v1, v0, p0}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    const/4 p0, 0x0

    return-object p0
.end method


# virtual methods
.method public final a(Ljava/lang/String;Ljava/lang/String;)Lb13;
    .registers 7

    .prologue
    sget-object v0, Lads_mobile_sdk/fw0;->H1:Lads_mobile_sdk/fw0;

    sget-object v1, Lads_mobile_sdk/hh3;->a:Ljava/util/WeakHashMap;

    sget-object v1, Lba0;->a:Lba0;

    const/4 v2, 0x1

    invoke-static {v0, v1, v2}, Lads_mobile_sdk/hh3;->a(Lads_mobile_sdk/fw0;Ljava/util/List;Z)Lads_mobile_sdk/rg3;

    move-result-object v0

    :try_start_b
    iget-boolean v1, p0, Lads_mobile_sdk/d6;->b:Z

    const/4 v3, 0x0

    if-eqz v1, :cond_11

    goto :goto_27

    :cond_11
    iget-object v1, p0, Lads_mobile_sdk/d6;->a:Ljava/io/File;

    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v1

    iput-boolean v1, p0, Lads_mobile_sdk/d6;->b:Z

    iget-boolean v1, p0, Lads_mobile_sdk/d6;->b:Z

    if-nez v1, :cond_27

    new-instance p0, Lads_mobile_sdk/ev0;

    const-string p1, "Cache directory not found"

    invoke-direct {p0, p1, v2}, Lads_mobile_sdk/ev0;-><init>(Ljava/lang/String;I)V

    goto :goto_6d

    :catchall_25
    move-exception p0

    goto :goto_7b

    :cond_27
    :goto_27
    invoke-virtual {p0, p1}, Lads_mobile_sdk/d6;->b(Ljava/lang/String;)Ljava/io/File;

    move-result-object p0

    if-nez p0, :cond_35

    new-instance p0, Lads_mobile_sdk/ev0;

    const-string p1, "Invalid filename"

    invoke-direct {p0, p1, v2}, Lads_mobile_sdk/ev0;-><init>(Ljava/lang/String;I)V

    goto :goto_6d

    :cond_35
    invoke-virtual {p0}, Ljava/io/File;->exists()Z

    move-result p1

    if-nez p1, :cond_43

    new-instance p0, Lads_mobile_sdk/ev0;

    const-string p1, "File not found"

    invoke-direct {p0, p1, v2}, Lads_mobile_sdk/ev0;-><init>(Ljava/lang/String;I)V
    :try_end_42
    .catchall {:try_start_b .. :try_end_42} :catchall_25

    goto :goto_6d

    :cond_43
    :try_start_43
    invoke-static {p0}, Lwd0;->h0(Ljava/io/File;)Ljava/lang/String;

    move-result-object p0

    if-eqz p2, :cond_5d

    invoke-static {p0}, Lads_mobile_sdk/d6;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1, p2}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_5d

    new-instance p0, Lads_mobile_sdk/ev0;

    const-string p1, "Checksum mismatch for file"

    invoke-direct {p0, p1, v2}, Lads_mobile_sdk/ev0;-><init>(Ljava/lang/String;I)V

    goto :goto_6d

    :catch_5b
    move-exception p0

    goto :goto_64

    :cond_5d
    new-instance p1, Lads_mobile_sdk/hv0;

    invoke-direct {p1, p0}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V
    :try_end_62
    .catch Ljava/lang/Exception; {:try_start_43 .. :try_end_62} :catch_5b
    .catchall {:try_start_43 .. :try_end_62} :catchall_25

    :goto_62
    move-object p0, p1

    goto :goto_6d

    :goto_64
    :try_start_64
    new-instance p1, Lads_mobile_sdk/bv0;

    const-string p2, "Failed to read file"

    const/4 v1, 0x2

    invoke-direct {p1, v3, p2, p0, v1}, Lads_mobile_sdk/bv0;-><init>(ILjava/lang/String;Ljava/lang/Throwable;I)V

    goto :goto_62

    :goto_6d
    instance-of p1, p0, Lads_mobile_sdk/av0;

    if-eqz p1, :cond_77

    move-object p1, p0

    check-cast p1, Lads_mobile_sdk/av0;

    invoke-static {p1, v3}, Lads_mobile_sdk/xh3;->a(Lads_mobile_sdk/av0;Z)V
    :try_end_77
    .catchall {:try_start_64 .. :try_end_77} :catchall_25

    :cond_77
    invoke-virtual {v0}, Lads_mobile_sdk/rg3;->close()V

    return-object p0

    :goto_7b
    :try_start_7b
    invoke-virtual {v0, p0}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of p1, p0, Lox2;

    if-nez p1, :cond_aa

    invoke-virtual {v0, p0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of p1, p0, Lza2;

    if-nez p1, :cond_a2

    instance-of p1, p0, Ljava/util/concurrent/CancellationException;

    if-nez p1, :cond_9a

    instance-of p1, p0, Lads_mobile_sdk/mv0;

    if-eqz p1, :cond_94

    throw p0

    :catchall_92
    move-exception p0

    goto :goto_ab

    :cond_94
    new-instance p1, Lads_mobile_sdk/tu0;

    invoke-direct {p1, p0}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw p1

    :cond_9a
    new-instance p1, Lads_mobile_sdk/ou0;

    check-cast p0, Ljava/util/concurrent/CancellationException;

    invoke-direct {p1, p0}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw p1

    :cond_a2
    new-instance p1, Lads_mobile_sdk/uw0;

    check-cast p0, Lza2;

    invoke-direct {p1, p0}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw p1

    :cond_aa
    throw p0
    :try_end_ab
    .catchall {:try_start_7b .. :try_end_ab} :catchall_92

    :goto_ab
    :try_start_ab
    throw p0
    :try_end_ac
    .catchall {:try_start_ab .. :try_end_ac} :catchall_ac

    :catchall_ac
    move-exception p1

    invoke-static {v0, p0}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw p1
.end method

.method public final a()Ljava/util/List;
    .registers 3

    .prologue
    sget-object v0, Lba0;->a:Lba0;

    iget-boolean v1, p0, Lads_mobile_sdk/d6;->b:Z

    if-eqz v1, :cond_7

    goto :goto_14

    :cond_7
    iget-object v1, p0, Lads_mobile_sdk/d6;->a:Ljava/io/File;

    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v1

    iput-boolean v1, p0, Lads_mobile_sdk/d6;->b:Z

    iget-boolean v1, p0, Lads_mobile_sdk/d6;->b:Z

    if-nez v1, :cond_14

    goto :goto_21

    :cond_14
    :goto_14
    iget-object p0, p0, Lads_mobile_sdk/d6;->a:Ljava/io/File;

    invoke-virtual {p0}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object p0

    if-eqz p0, :cond_21

    invoke-static {p0}, Laf;->v0([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    return-object p0

    :cond_21
    :goto_21
    return-object v0
.end method

.method public final b(Ljava/lang/String;Ljava/lang/String;)Lb13;
    .registers 9

    .prologue
    sget-object v0, Lrg2;->a:Lrg2;

    const-string v1, ".tmp"

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v2, Lads_mobile_sdk/fw0;->K1:Lads_mobile_sdk/fw0;

    sget-object v3, Lads_mobile_sdk/hh3;->a:Ljava/util/WeakHashMap;

    sget-object v3, Lba0;->a:Lba0;

    const/4 v4, 0x1

    invoke-static {v2, v3, v4}, Lads_mobile_sdk/hh3;->a(Lads_mobile_sdk/fw0;Ljava/util/List;Z)Lads_mobile_sdk/rg3;

    move-result-object v2

    :try_start_12
    iget-boolean v3, p0, Lads_mobile_sdk/d6;->b:Z

    if-eqz v3, :cond_1f

    new-instance v3, Lads_mobile_sdk/hv0;

    invoke-direct {v3, v0}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    goto :goto_47

    :catchall_1c
    move-exception p0

    goto/16 :goto_cc

    :cond_1f
    iget-boolean v3, p0, Lads_mobile_sdk/d6;->b:Z

    if-eqz v3, :cond_24

    goto :goto_40

    :cond_24
    iget-object v3, p0, Lads_mobile_sdk/d6;->a:Ljava/io/File;

    invoke-virtual {v3}, Ljava/io/File;->exists()Z

    move-result v3

    iput-boolean v3, p0, Lads_mobile_sdk/d6;->b:Z

    iget-boolean v3, p0, Lads_mobile_sdk/d6;->b:Z

    if-nez v3, :cond_40

    iget-object v3, p0, Lads_mobile_sdk/d6;->a:Ljava/io/File;

    invoke-virtual {v3}, Ljava/io/File;->mkdirs()Z

    move-result v3

    if-nez v3, :cond_40

    new-instance v3, Lads_mobile_sdk/ev0;

    const-string v0, "Failed to create cache directory"

    invoke-direct {v3, v0, v4}, Lads_mobile_sdk/ev0;-><init>(Ljava/lang/String;I)V

    goto :goto_47

    :cond_40
    :goto_40
    iput-boolean v4, p0, Lads_mobile_sdk/d6;->b:Z

    new-instance v3, Lads_mobile_sdk/hv0;

    invoke-direct {v3, v0}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    :goto_47
    instance-of v0, v3, Lads_mobile_sdk/av0;

    const/4 v5, 0x0

    if-eqz v0, :cond_50

    check-cast v3, Lads_mobile_sdk/av0;

    goto/16 :goto_be

    :cond_50
    check-cast v3, Lads_mobile_sdk/hv0;

    invoke-static {p2}, Lads_mobile_sdk/d6;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_60

    new-instance v3, Lads_mobile_sdk/ev0;

    const-string p0, "Failed to calculate checksum"

    invoke-direct {v3, p0, v4}, Lads_mobile_sdk/ev0;-><init>(Ljava/lang/String;I)V

    goto :goto_be

    :cond_60
    invoke-virtual {p1, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {p0, v1}, Lads_mobile_sdk/d6;->b(Ljava/lang/String;)Ljava/io/File;

    move-result-object v1
    :try_end_68
    .catchall {:try_start_12 .. :try_end_68} :catchall_1c

    const-string v3, "Invalid filename"

    if-nez v1, :cond_73

    :try_start_6c
    new-instance p0, Lads_mobile_sdk/ev0;

    invoke-direct {p0, v3, v4}, Lads_mobile_sdk/ev0;-><init>(Ljava/lang/String;I)V

    :goto_71
    move-object v3, p0

    goto :goto_be

    :cond_73
    invoke-virtual {p0, p1}, Lads_mobile_sdk/d6;->b(Ljava/lang/String;)Ljava/io/File;

    move-result-object p0

    if-nez p0, :cond_7f

    new-instance p0, Lads_mobile_sdk/ev0;

    invoke-direct {p0, v3, v4}, Lads_mobile_sdk/ev0;-><init>(Ljava/lang/String;I)V
    :try_end_7e
    .catchall {:try_start_6c .. :try_end_7e} :catchall_1c

    goto :goto_71

    :cond_7f
    :try_start_7f
    new-instance p1, Ljava/io/FileOutputStream;

    invoke-direct {p1, v1}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_84
    .catch Ljava/io/IOException; {:try_start_7f .. :try_end_84} :catch_a4
    .catchall {:try_start_7f .. :try_end_84} :catchall_1c

    :try_start_84
    sget-object v3, Lip;->a:Ljava/nio/charset/Charset;

    invoke-virtual {p2, v3}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1, p2}, Ljava/io/FileOutputStream;->write([B)V
    :try_end_90
    .catchall {:try_start_84 .. :try_end_90} :catchall_ac

    :try_start_90
    invoke-virtual {p1}, Ljava/io/FileOutputStream;->close()V

    invoke-virtual {v1, p0}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    move-result p0

    if-nez p0, :cond_a6

    invoke-virtual {v1}, Ljava/io/File;->delete()Z

    new-instance v3, Lads_mobile_sdk/ev0;

    const-string p0, "Failed to rename temp file"

    invoke-direct {v3, p0, v4}, Lads_mobile_sdk/ev0;-><init>(Ljava/lang/String;I)V

    goto :goto_be

    :catch_a4
    move-exception p0

    goto :goto_b3

    :cond_a6
    new-instance v3, Lads_mobile_sdk/hv0;

    invoke-direct {v3, v0}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V
    :try_end_ab
    .catch Ljava/io/IOException; {:try_start_90 .. :try_end_ab} :catch_a4
    .catchall {:try_start_90 .. :try_end_ab} :catchall_1c

    goto :goto_be

    :catchall_ac
    move-exception p0

    :try_start_ad
    throw p0
    :try_end_ae
    .catchall {:try_start_ad .. :try_end_ae} :catchall_ae

    :catchall_ae
    move-exception p2

    :try_start_af
    invoke-static {p1, p0}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw p2
    :try_end_b3
    .catch Ljava/io/IOException; {:try_start_af .. :try_end_b3} :catch_a4
    .catchall {:try_start_af .. :try_end_b3} :catchall_1c

    :goto_b3
    :try_start_b3
    invoke-virtual {v1}, Ljava/io/File;->delete()Z

    new-instance v3, Lads_mobile_sdk/bv0;

    const-string p1, "Failed to write to temp file"

    const/4 p2, 0x2

    invoke-direct {v3, v5, p1, p0, p2}, Lads_mobile_sdk/bv0;-><init>(ILjava/lang/String;Ljava/lang/Throwable;I)V

    :goto_be
    instance-of p0, v3, Lads_mobile_sdk/av0;

    if-eqz p0, :cond_c8

    move-object p0, v3

    check-cast p0, Lads_mobile_sdk/av0;

    invoke-static {p0, v5}, Lads_mobile_sdk/xh3;->a(Lads_mobile_sdk/av0;Z)V
    :try_end_c8
    .catchall {:try_start_b3 .. :try_end_c8} :catchall_1c

    :cond_c8
    invoke-virtual {v2}, Lads_mobile_sdk/rg3;->close()V

    return-object v3

    :goto_cc
    :try_start_cc
    invoke-virtual {v2, p0}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of p1, p0, Lox2;

    if-nez p1, :cond_fb

    invoke-virtual {v2, p0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of p1, p0, Lza2;

    if-nez p1, :cond_f3

    instance-of p1, p0, Ljava/util/concurrent/CancellationException;

    if-nez p1, :cond_eb

    instance-of p1, p0, Lads_mobile_sdk/mv0;

    if-eqz p1, :cond_e5

    throw p0

    :catchall_e3
    move-exception p0

    goto :goto_fc

    :cond_e5
    new-instance p1, Lads_mobile_sdk/tu0;

    invoke-direct {p1, p0}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw p1

    :cond_eb
    new-instance p1, Lads_mobile_sdk/ou0;

    check-cast p0, Ljava/util/concurrent/CancellationException;

    invoke-direct {p1, p0}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw p1

    :cond_f3
    new-instance p1, Lads_mobile_sdk/uw0;

    check-cast p0, Lza2;

    invoke-direct {p1, p0}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw p1

    :cond_fb
    throw p0
    :try_end_fc
    .catchall {:try_start_cc .. :try_end_fc} :catchall_e3

    :goto_fc
    :try_start_fc
    throw p0
    :try_end_fd
    .catchall {:try_start_fc .. :try_end_fd} :catchall_fd

    :catchall_fd
    move-exception p1

    invoke-static {v2, p0}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw p1
.end method

.method public final b(Ljava/lang/String;)Ljava/io/File;
    .registers 7

    .prologue
    const-string v0, "Path traversal detected: "

    new-instance v1, Ljava/io/File;

    iget-object p0, p0, Lads_mobile_sdk/d6;->a:Ljava/io/File;

    invoke-direct {v1, p0, p1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v2, 0x0

    :try_start_a
    invoke-virtual {v1}, Ljava/io/File;->getCanonicalPath()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/io/File;->getCanonicalPath()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v4, 0x0

    invoke-static {v3, p0, v4}, Lk72;->k0(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result p0

    if-eqz p0, :cond_20

    return-object v1

    :cond_20
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v0, 0x6

    invoke-static {v0, p0, v2}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V
    :try_end_30
    .catch Ljava/io/IOException; {:try_start_a .. :try_end_30} :catch_31

    return-object v2

    :catch_31
    move-exception p0

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Failed to resolve canonical path for "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v0, 0x4

    invoke-static {v0, p1, p0}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    return-object v2
.end method
