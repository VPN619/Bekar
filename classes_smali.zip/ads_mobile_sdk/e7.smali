.class public Lads_mobile_sdk/e7;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lzx2;
.implements Landroidx/webkit/WebViewCompat$WebViewStartUpCallback;
.implements Lo23;
.implements Lw03;
.implements Lvn2;
.implements Lwu1;
.implements Lbl0;


# static fields
.field public static final b:Ljava/lang/Object;

.field public static c:Lads_mobile_sdk/e7;


# instance fields
.field public a:Ljava/lang/Object;

.field public final synthetic d:I


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lads_mobile_sdk/e7;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(BI)V
    .registers 3

    .prologue
    iput p2, p0, Lads_mobile_sdk/e7;->d:I

    packed-switch p2, :pswitch_data_1a

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 p2, 0x1

    invoke-direct {p1, p2}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object p1, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    return-void

    :pswitch_11  #0xf
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 p1, 0x2

    new-array p1, p1, [I

    iput-object p1, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    return-void

    :pswitch_data_1a
    .packed-switch 0xf
        :pswitch_11  #0000000f
    .end packed-switch
.end method

.method public synthetic constructor <init>(CI)V
    .registers 3

    iput p2, p0, Lads_mobile_sdk/e7;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(I)V
    .registers 3

    const/4 v0, 0x6

    iput v0, p0, Lads_mobile_sdk/e7;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-static {p1}, Lns2;->b(I)Ljava/util/LinkedHashMap;

    move-result-object p1

    iput-object p1, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    iput p1, p0, Lads_mobile_sdk/e7;->d:I

    iput-object p2, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Lads_mobile_sdk/d91;)V
    .registers 3

    const/16 v0, 0x17

    iput v0, p0, Lads_mobile_sdk/e7;->d:I

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lads_mobile_sdk/ek;)V
    .registers 3

    const/16 v0, 0xa

    iput v0, p0, Lads_mobile_sdk/e7;->d:I

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lads_mobile_sdk/j90;)V
    .registers 3

    const/4 v0, 0x0

    iput v0, p0, Lads_mobile_sdk/e7;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iget-object p1, p1, Lads_mobile_sdk/j90;->B:Ltv2;

    invoke-interface {p1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lads_mobile_sdk/h7;

    iput-object p1, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lads_mobile_sdk/k8;)V
    .registers 3

    const/16 v0, 0x10

    iput v0, p0, Lads_mobile_sdk/e7;->d:I

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lads_mobile_sdk/ov;)V
    .registers 3

    const/16 v0, 0x15

    iput v0, p0, Lads_mobile_sdk/e7;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget-object v0, Lads_mobile_sdk/yb1;->a:[B

    iput-object p1, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    iput-object p0, p1, Lads_mobile_sdk/ov;->a:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lads_mobile_sdk/mi0;)V
    .registers 4

    const/16 v0, 0x14

    iput v0, p0, Lads_mobile_sdk/e7;->d:I

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/io/ByteArrayOutputStream;I)V
    .registers 3

    const/16 p2, 0x18

    iput p2, p0, Lads_mobile_sdk/e7;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .registers 4

    const/16 v0, 0x11

    iput v0, p0, Lads_mobile_sdk/e7;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "UID: ["

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-static {}, Landroid/os/Process;->myUid()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "]  PID: ["

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, "] "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    iput-object p1, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Ljava/nio/ByteBuffer;)V
    .registers 3

    const/4 v0, 0x5

    iput v0, p0, Lads_mobile_sdk/e7;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->slice()Ljava/nio/ByteBuffer;

    move-result-object p1

    iput-object p1, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Ljava/util/HashMap;)V
    .registers 3

    const/16 v0, 0x16

    iput v0, p0, Lads_mobile_sdk/e7;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0, p1}, Ljava/util/HashMap;-><init>(Ljava/util/Map;)V

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object p1

    iput-object p1, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    return-void
.end method

.method public static varargs a(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    .registers 6

    .prologue
    array-length v0, p2

    if-lez v0, :cond_30

    :try_start_3
    sget-object v0, Ljava/util/Locale;->US:Ljava/util/Locale;

    invoke-static {v0, p1, p2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1
    :try_end_9
    .catch Ljava/util/IllegalFormatException; {:try_start_3 .. :try_end_9} :catch_a

    goto :goto_30

    :catch_a
    move-exception v0

    const-string v1, "Unable to format "

    invoke-virtual {v1, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "PlayCore"

    nop

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string p1, " ["

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, ", "

    invoke-static {p1, p2}, Landroid/text/TextUtils;->join(Ljava/lang/CharSequence;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, "]"

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    :cond_30
    :goto_30
    const-string p2, " : "

    invoke-static {p0, p2, p1}, Lrt2;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method private final onFailure$ads_mobile_sdk$t83(Ljava/lang/Throwable;)V
    .registers 2

    return-void
.end method


# virtual methods
.method public a()Lads_mobile_sdk/lw0;
    .registers 1

    .prologue
    iget p0, p0, Lads_mobile_sdk/e7;->d:I

    sparse-switch p0, :sswitch_data_12

    sget-object p0, Lads_mobile_sdk/lw0;->C:Lads_mobile_sdk/lw0;

    return-object p0

    :sswitch_8
    sget-object p0, Lads_mobile_sdk/lw0;->w:Lads_mobile_sdk/lw0;

    return-object p0

    :sswitch_b
    sget-object p0, Lads_mobile_sdk/lw0;->j:Lads_mobile_sdk/lw0;

    return-object p0

    :sswitch_e
    sget-object p0, Lads_mobile_sdk/lw0;->D:Lads_mobile_sdk/lw0;

    return-object p0

    nop

    :sswitch_data_12
    .sparse-switch
        0xa -> :sswitch_e
        0x10 -> :sswitch_b
        0x14 -> :sswitch_8
    .end sparse-switch
.end method

.method public a()Ljava/lang/Object;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/jl2;

    return-object p0
.end method

.method public a(Ljava/io/FileInputStream;)Ljava/lang/Object;
    .registers 4

    .prologue
    :try_start_0
    iget-object p0, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/jl2;

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-virtual {p0, v0, v1}, Lads_mobile_sdk/ku0;->a(ILads_mobile_sdk/ku0;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/ju0;

    invoke-static {}, Lads_mobile_sdk/ul0;->a()Lads_mobile_sdk/ul0;

    move-result-object v0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lads_mobile_sdk/iv;

    invoke-direct {v1, p1}, Lads_mobile_sdk/iv;-><init>(Ljava/io/FileInputStream;)V

    iget-object p0, p0, Lads_mobile_sdk/ju0;->a:Lads_mobile_sdk/ku0;

    invoke-static {p0, v1, v0}, Lads_mobile_sdk/ku0;->a(Lads_mobile_sdk/ku0;Lads_mobile_sdk/jv;Lads_mobile_sdk/ul0;)Lads_mobile_sdk/ku0;

    move-result-object p0

    const/4 p1, 0x0

    invoke-virtual {v1, p1}, Lads_mobile_sdk/iv;->a(I)V

    invoke-static {p0}, Lads_mobile_sdk/ku0;->a(Lads_mobile_sdk/ku0;)Z

    move-result p1

    if-eqz p1, :cond_29

    return-object p0

    :cond_29
    new-instance p0, Lk63;

    invoke-direct {p0}, Lk63;-><init>()V

    new-instance p1, Lads_mobile_sdk/bj1;

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_38
    .catch Lads_mobile_sdk/bj1; {:try_start_0 .. :try_end_38} :catch_38

    :catch_38
    move-exception p0

    new-instance p1, Lb03;

    const-string v0, "Cannot read proto."

    invoke-direct {p1, v0, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw p1
.end method

.method public a(Ljava/lang/String;)Ljava/lang/Object;
    .registers 3

    .prologue
    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;
    :try_end_3
    .catchall {:try_start_1 .. :try_end_3} :catchall_11

    if-eqz v0, :cond_7

    monitor-exit p0

    return-object v0

    :cond_7
    :try_start_7
    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
    :try_end_11
    .catchall {:try_start_7 .. :try_end_11} :catchall_11

    :catchall_11
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public a(Landroid/view/View;)Lorg/json/JSONObject;
    .registers 7

    .prologue
    iget v0, p0, Lads_mobile_sdk/e7;->d:I

    const/4 v1, 0x1

    const/4 v2, 0x0

    packed-switch v0, :pswitch_data_58

    iget-object p0, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    check-cast p0, [I

    if-nez p1, :cond_12

    invoke-static {v2, v2, v2, v2}, Lads_mobile_sdk/v62;->a(IIII)Lorg/json/JSONObject;

    move-result-object p0

    goto :goto_25

    :cond_12
    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    move-result v0

    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    move-result v3

    invoke-virtual {p1, p0}, Landroid/view/View;->getLocationOnScreen([I)V

    aget p1, p0, v2

    aget p0, p0, v1

    invoke-static {p1, p0, v0, v3}, Lads_mobile_sdk/v62;->a(IIII)Lorg/json/JSONObject;

    move-result-object p0

    :goto_25
    return-object p0

    :pswitch_26  #0x3
    invoke-static {v2, v2, v2, v2}, Lads_mobile_sdk/v62;->a(IIII)Lorg/json/JSONObject;

    move-result-object p0

    sget-object p1, Lads_mobile_sdk/nw;->a:Landroid/app/UiModeManager;

    const/4 v0, 0x2

    const/4 v3, 0x3

    if-nez p1, :cond_31

    goto :goto_3e

    :cond_31
    :try_start_31
    invoke-virtual {p1}, Landroid/app/UiModeManager;->getCurrentModeType()I

    move-result p1
    :try_end_35
    .catch Ljava/lang/RuntimeException; {:try_start_31 .. :try_end_35} :catch_3e

    if-eq p1, v1, :cond_3d

    const/4 v4, 0x4

    if-eq p1, v4, :cond_3b

    goto :goto_3e

    :cond_3b
    move v3, v1

    goto :goto_3e

    :cond_3d
    move v3, v0

    :catch_3e
    :goto_3e
    if-eq v3, v1, :cond_41

    goto :goto_43

    :cond_41
    sget v0, Lns2;->j:I

    :goto_43
    invoke-static {v0}, Lvr0;->a(I)I

    move-result p1

    if-eqz p1, :cond_4a

    move v1, v2

    :cond_4a
    :try_start_4a
    const-string p1, "noOutputDevice"

    invoke-virtual {p0, p1, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Z)Lorg/json/JSONObject;
    :try_end_4f
    .catch Lorg/json/JSONException; {:try_start_4a .. :try_end_4f} :catch_50

    goto :goto_56

    :catch_50
    move-exception p1

    const-string v0, "Error with setting output device status"

    const-string v1, "OMIDLIB"

    nop

    :goto_56
    return-object p0

    nop

    :pswitch_data_58
    .packed-switch 0x3
        :pswitch_26  #00000003
    .end packed-switch
.end method

.method public a(I)V
    .registers 5

    iget-object p0, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/mb1;

    iget-object v0, p0, Lads_mobile_sdk/mb1;->c:Lvy;

    new-instance v1, Lads_mobile_sdk/ib1;

    const/4 v2, 0x0

    invoke-direct {v1, p1, v2, p0}, Lads_mobile_sdk/ib1;-><init>(ILvx;Lads_mobile_sdk/mb1;)V

    const/4 p0, 0x3

    invoke-static {v0, v2, v2, v1, p0}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    return-void
.end method

.method public a(Lads_mobile_sdk/ah2;)V
    .registers 5

    .prologue
    iget-object p0, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/lk2;

    sget-object v0, Lads_mobile_sdk/lk2;->c:Lads_mobile_sdk/e7;

    iget-object v1, p0, Lads_mobile_sdk/lk2;->b:Ljava/lang/String;

    filled-new-array {v1}, [Ljava/lang/Object;

    move-result-object v1

    const-string v2, "prewarm(%s)"

    invoke-virtual {v0, v2, v1}, Lads_mobile_sdk/e7;->a(Ljava/lang/String;[Ljava/lang/Object;)V

    iget-object v1, p0, Lads_mobile_sdk/lk2;->a:Lads_mobile_sdk/u13;

    if-nez v1, :cond_30

    const-string p0, "Play Store not found."

    filled-new-array {p0}, [Ljava/lang/Object;

    move-result-object p0

    const/4 p1, 0x6

    const-string v1, "PlayCore"

    invoke-static {v1, p1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result p1

    if-eqz p1, :cond_2f

    iget-object p1, v0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    check-cast p1, Ljava/lang/String;

    const-string v0, "error: %s"

    invoke-static {p1, v0, p0}, Lads_mobile_sdk/e7;->a(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    nop

    :cond_2f
    return-void

    :cond_30
    new-instance v0, Lcom/google/android/gms/tasks/TaskCompletionSource;

    invoke-direct {v0}, Lcom/google/android/gms/tasks/TaskCompletionSource;-><init>()V

    new-instance v2, Lads_mobile_sdk/jk2;

    invoke-direct {v2, p0, v0, p1, v0}, Lads_mobile_sdk/jk2;-><init>(Lads_mobile_sdk/lk2;Lcom/google/android/gms/tasks/TaskCompletionSource;Lads_mobile_sdk/ah2;Lcom/google/android/gms/tasks/TaskCompletionSource;)V

    new-instance p0, Lads_mobile_sdk/jk2;

    invoke-direct {p0, v1, v0, v0, v2}, Lads_mobile_sdk/jk2;-><init>(Lads_mobile_sdk/u13;Lcom/google/android/gms/tasks/TaskCompletionSource;Lcom/google/android/gms/tasks/TaskCompletionSource;Lads_mobile_sdk/jk2;)V

    invoke-virtual {v1, p0}, Lads_mobile_sdk/u13;->b(Lads_mobile_sdk/oz2;)V

    return-void
.end method

.method public a(Lads_mobile_sdk/vj0;Lads_mobile_sdk/ox;)V
    .registers 3

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    check-cast p0, Lx23;

    invoke-virtual {p0}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object p0, p0, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast p0, Lads_mobile_sdk/qx;

    invoke-virtual {p0, p2}, Lads_mobile_sdk/qx;->a(Lads_mobile_sdk/ox;)V

    return-void
.end method

.method public a(Landroid/widget/ImageView$ScaleType;)V
    .registers 3

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    check-cast p0, Lwb1;

    invoke-virtual {p0}, Luh;->getNativeAdViewContainer()Lads_mobile_sdk/ew1;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    monitor-enter p0

    :try_start_f
    iget-object v0, p0, Lads_mobile_sdk/ew1;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0
    :try_end_15
    .catchall {:try_start_f .. :try_end_15} :catchall_1d

    if-eqz v0, :cond_19

    monitor-exit p0

    return-void

    :cond_19
    :try_start_19
    iput-object p1, p0, Lads_mobile_sdk/ew1;->f:Landroid/widget/ImageView$ScaleType;
    :try_end_1b
    .catchall {:try_start_19 .. :try_end_1b} :catchall_1d

    monitor-exit p0

    return-void

    :catchall_1d
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public a(Ljava/lang/Object;Ljava/io/FileOutputStream;)V
    .registers 3

    check-cast p1, Lads_mobile_sdk/g;

    invoke-virtual {p1, p2}, Lads_mobile_sdk/g;->a(Ljava/io/OutputStream;)V

    return-void
.end method

.method public a(Ljava/lang/String;Ltv2;)V
    .registers 3

    .prologue
    iget-object p0, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    check-cast p0, Ljava/util/LinkedHashMap;

    if-eqz p2, :cond_a

    invoke-virtual {p0, p1, p2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_a
    const-string p0, "provider"

    invoke-static {p0}, Ldm2;->n(Ljava/lang/String;)V

    return-void
.end method

.method public varargs a(Ljava/lang/String;[Ljava/lang/Object;)V
    .registers 5

    .prologue
    const/4 v0, 0x4

    const-string v1, "PlayCore"

    invoke-static {v1, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v0

    if-eqz v0, :cond_12

    iget-object p0, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    check-cast p0, Ljava/lang/String;

    invoke-static {p0, p1, p2}, Lads_mobile_sdk/e7;->a(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    nop

    :cond_12
    return-void
.end method

.method public a([Ljava/security/MessageDigest;JI)V
    .registers 7

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    check-cast v0, Ljava/nio/ByteBuffer;

    monitor-enter v0

    :try_start_5
    iget-object v1, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    check-cast v1, Ljava/nio/ByteBuffer;

    long-to-int p2, p2

    invoke-virtual {v1, p2}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    iget-object p3, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    check-cast p3, Ljava/nio/ByteBuffer;

    add-int/2addr p2, p4

    invoke-virtual {p3, p2}, Ljava/nio/ByteBuffer;->limit(I)Ljava/nio/Buffer;

    iget-object p0, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    check-cast p0, Ljava/nio/ByteBuffer;

    invoke-virtual {p0}, Ljava/nio/ByteBuffer;->slice()Ljava/nio/ByteBuffer;

    move-result-object p0

    monitor-exit v0
    :try_end_1e
    .catchall {:try_start_5 .. :try_end_1e} :catchall_2f

    array-length p2, p1

    const/4 p3, 0x0

    move p4, p3

    :goto_21
    if-ge p4, p2, :cond_2e

    aget-object v0, p1, p4

    invoke-virtual {p0, p3}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    invoke-virtual {v0, p0}, Ljava/security/MessageDigest;->update(Ljava/nio/ByteBuffer;)V

    add-int/lit8 p4, p4, 0x1

    goto :goto_21

    :cond_2e
    return-void

    :catchall_2f
    move-exception p0

    :try_start_30
    monitor-exit v0
    :try_end_31
    .catchall {:try_start_30 .. :try_end_31} :catchall_2f

    throw p0
.end method

.method public synthetic b()Lads_mobile_sdk/vj0;
    .registers 2

    new-instance v0, Lads_mobile_sdk/vj0;

    iget-object p0, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    check-cast p0, Lx23;

    invoke-virtual {p0}, Lx23;->c()Lads_mobile_sdk/vb1;

    move-result-object p0

    invoke-direct {v0, p0}, Lads_mobile_sdk/vj0;-><init>(Ljava/util/List;)V

    return-object v0
.end method

.method public b(ILus2;Ljava/lang/Object;)V
    .registers 6

    check-cast p3, Lads_mobile_sdk/g;

    iget-object v0, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    check-cast v0, Lads_mobile_sdk/ov;

    const/4 v1, 0x2

    invoke-virtual {v0, p1, v1}, Lads_mobile_sdk/ov;->g(II)V

    invoke-virtual {p3, p2}, Lads_mobile_sdk/g;->a(Lus2;)I

    move-result p1

    invoke-virtual {v0, p1}, Lads_mobile_sdk/ov;->m(I)V

    invoke-interface {p2, p3, p0}, Lus2;->a(Ljava/lang/Object;Lads_mobile_sdk/e7;)V

    return-void
.end method

.method public varargs b(Ljava/lang/String;[Ljava/lang/Object;)V
    .registers 5

    .prologue
    const/4 v0, 0x5

    const-string v1, "PlayCore"

    invoke-static {v1, v0}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v0

    if-eqz v0, :cond_12

    iget-object p0, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    check-cast p0, Ljava/lang/String;

    invoke-static {p0, p1, p2}, Lads_mobile_sdk/e7;->a(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    nop

    :cond_12
    return-void
.end method

.method public d(Lvx;)Ljava/lang/Object;
    .registers 10

    .prologue
    iget v0, p0, Lads_mobile_sdk/e7;->d:I

    const/4 v1, 0x1

    sparse-switch v0, :sswitch_data_1b4

    instance-of v0, p1, Lads_mobile_sdk/qa1;

    if-eqz v0, :cond_19

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/qa1;

    iget v2, v0, Lads_mobile_sdk/qa1;->c:I

    const/high16 v3, -0x80000000

    and-int v4, v2, v3

    if-eqz v4, :cond_19

    sub-int/2addr v2, v3

    iput v2, v0, Lads_mobile_sdk/qa1;->c:I

    goto :goto_20

    :cond_19
    new-instance v0, Lads_mobile_sdk/qa1;

    check-cast p1, Lwx;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/qa1;-><init>(Lads_mobile_sdk/e7;Lwx;)V

    :goto_20
    iget-object p1, v0, Lads_mobile_sdk/qa1;->a:Ljava/lang/Object;

    sget-object v2, Lwy;->a:Lwy;

    iget v3, v0, Lads_mobile_sdk/qa1;->c:I

    if-eqz v3, :cond_35

    if-ne v3, v1, :cond_2e

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_45

    :cond_2e
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    const/4 v2, 0x0

    goto :goto_4a

    :cond_35
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p0, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/d91;

    iput v1, v0, Lads_mobile_sdk/qa1;->c:I

    invoke-virtual {p0, v0}, Lads_mobile_sdk/d91;->s(Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v2, :cond_45

    goto :goto_4a

    :cond_45
    :goto_45
    new-instance v2, Lads_mobile_sdk/hv0;

    invoke-direct {v2, p1}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    :goto_4a
    return-object v2

    :sswitch_4b
    new-instance p1, Lads_mobile_sdk/hv0;

    new-instance v0, Lads_mobile_sdk/oi0;

    iget-object p0, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/mi0;

    iget-object v1, p0, Lads_mobile_sdk/mi0;->b:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lads_mobile_sdk/wh0;

    invoke-virtual {v1}, Lads_mobile_sdk/wh0;->getNumber()I

    move-result v1

    new-instance v2, Ljava/lang/Integer;

    invoke-direct {v2, v1}, Ljava/lang/Integer;-><init>(I)V

    invoke-virtual {p0}, Lads_mobile_sdk/mi0;->a()Lads_mobile_sdk/xh0;

    move-result-object v1

    invoke-virtual {v1}, Lads_mobile_sdk/xh0;->getNumber()I

    move-result v1

    new-instance v3, Ljava/lang/Integer;

    invoke-direct {v3, v1}, Ljava/lang/Integer;-><init>(I)V

    iget-object v1, p0, Lads_mobile_sdk/mi0;->a:Lads_mobile_sdk/qr0;

    iget-object v4, p0, Lads_mobile_sdk/mi0;->c:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v5, "gads:device_tier_manager:enabled"

    sget-object v6, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    sget-object v7, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    invoke-virtual {v1, v5, v6, v7}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    if-eqz v5, :cond_b7

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v5, "gads:available_processors_tier:enabled"

    sget-object v6, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {v1, v5, v6, v7}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-nez v1, :cond_9e

    goto :goto_b7

    :cond_9e
    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Runtime;->availableProcessors()I

    move-result v1

    invoke-virtual {p0, v1}, Lads_mobile_sdk/mi0;->a(I)Lads_mobile_sdk/yh0;

    move-result-object p0

    invoke-virtual {v4, p0}, Ljava/util/concurrent/atomic/AtomicReference;->set(Ljava/lang/Object;)V

    invoke-virtual {v4}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p0, Lads_mobile_sdk/yh0;

    goto :goto_b9

    :cond_b7
    :goto_b7
    sget-object p0, Lads_mobile_sdk/yh0;->b:Lads_mobile_sdk/yh0;

    :goto_b9
    invoke-virtual {p0}, Lads_mobile_sdk/yh0;->getNumber()I

    move-result p0

    new-instance v1, Ljava/lang/Integer;

    invoke-direct {v1, p0}, Ljava/lang/Integer;-><init>(I)V

    invoke-direct {v0, v2, v3, v1}, Lads_mobile_sdk/oi0;-><init>(Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;)V

    invoke-direct {p1, v0}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    return-object p1

    :sswitch_c9
    new-instance p1, Lads_mobile_sdk/hv0;

    new-instance v2, Lads_mobile_sdk/m8;

    iget-object p0, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/k8;

    invoke-virtual {p0}, Lads_mobile_sdk/k8;->b()Lads_mobile_sdk/e7;

    move-result-object v0

    invoke-virtual {p0}, Lads_mobile_sdk/k8;->c()Landroid/content/Context;

    move-result-object p0

    iget-object v0, v0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    move-object v3, v0

    check-cast v3, Lads_mobile_sdk/h7;

    iget-boolean v0, v3, Lads_mobile_sdk/h7;->j:Z

    if-eqz v0, :cond_f0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    iget-wide v6, v3, Lads_mobile_sdk/h7;->i:J

    sub-long/2addr v4, v6

    iget-wide v6, v3, Lads_mobile_sdk/h7;->k:J

    cmp-long v0, v4, v6

    if-gtz v0, :cond_f0

    goto :goto_f1

    :cond_f0
    const/4 v1, 0x0

    :goto_f1
    iget-object v0, v3, Lads_mobile_sdk/h7;->d:Lads_mobile_sdk/th3;

    sget-object v4, Lads_mobile_sdk/fl0;->d:Lads_mobile_sdk/fl0;

    new-instance v5, Lads_mobile_sdk/qg3;

    iget-object v6, v0, Lads_mobile_sdk/th3;->b:Lx43;

    iget-object v0, v0, Lads_mobile_sdk/th3;->a:Lads_mobile_sdk/qm1;

    invoke-direct {v5, v4, v6, v0}, Lads_mobile_sdk/qg3;-><init>(Lads_mobile_sdk/fl0;Lx43;Lads_mobile_sdk/qm1;)V

    :try_start_fe
    invoke-virtual {v5}, Lads_mobile_sdk/qg3;->b()V

    iget-object v4, v3, Lads_mobile_sdk/h7;->a:Lads_mobile_sdk/n61;

    monitor-enter v4
    :try_end_104
    .catch Ljava/util/concurrent/TimeoutException; {:try_start_fe .. :try_end_104} :catch_170
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_fe .. :try_end_104} :catch_121
    .catch Ljava/lang/InterruptedException; {:try_start_fe .. :try_end_104} :catch_11e
    .catchall {:try_start_fe .. :try_end_104} :catchall_11b

    :try_start_104
    iget-object v0, v4, Lads_mobile_sdk/n61;->e:Lj1;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_109
    .catchall {:try_start_104 .. :try_end_109} :catchall_137

    :try_start_109
    monitor-exit v4

    new-instance v4, Lbv2;

    const/4 v6, 0x2

    invoke-direct {v4, v6, v3, p0}, Lbv2;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    sget-object p0, Lv40;->a:Lv40;

    invoke-static {v0, v4, p0}, Lk1;->s(Lfg0;Lcf;Ljava/util/concurrent/Executor;)Li1;

    move-result-object p0

    if-eqz v1, :cond_124

    iget-wide v6, v3, Lads_mobile_sdk/h7;->h:J

    goto :goto_126

    :catchall_11b
    move-exception v0

    move-object p0, v0

    goto :goto_13b

    :catch_11e
    move-exception v0

    move-object p0, v0

    goto :goto_142

    :catch_121
    move-exception v0

    move-object p0, v0

    goto :goto_157

    :cond_124
    iget-wide v6, v3, Lads_mobile_sdk/h7;->f:J

    :goto_126
    sget-object v0, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    invoke-virtual {p0, v6, v7, v0}, Lf0;->get(JLjava/util/concurrent/TimeUnit;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;
    :try_end_12e
    .catch Ljava/util/concurrent/TimeoutException; {:try_start_109 .. :try_end_12e} :catch_170
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_109 .. :try_end_12e} :catch_121
    .catch Ljava/lang/InterruptedException; {:try_start_109 .. :try_end_12e} :catch_11e
    .catchall {:try_start_109 .. :try_end_12e} :catchall_11b

    invoke-virtual {v5}, Lads_mobile_sdk/qg3;->a()V

    iget-object v0, v3, Lads_mobile_sdk/h7;->e:Lr73;

    invoke-interface {v0}, Lr73;->a()V

    goto :goto_17c

    :catchall_137
    move-exception v0

    move-object p0, v0

    :try_start_139
    monitor-exit v4

    throw p0
    :try_end_13b
    .catch Ljava/util/concurrent/TimeoutException; {:try_start_139 .. :try_end_13b} :catch_170
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_139 .. :try_end_13b} :catch_121
    .catch Ljava/lang/InterruptedException; {:try_start_139 .. :try_end_13b} :catch_11e
    .catchall {:try_start_139 .. :try_end_13b} :catchall_11b

    :goto_13b
    :try_start_13b
    invoke-virtual {v5, p0}, Lads_mobile_sdk/qg3;->a(Ljava/lang/Throwable;)V

    throw p0

    :catchall_13f
    move-exception v0

    move-object p0, v0

    goto :goto_186

    :goto_142
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Thread;->interrupt()V

    invoke-virtual {v5, p0}, Lads_mobile_sdk/qg3;->a(Ljava/lang/Throwable;)V

    const-string p0, ""
    :try_end_14e
    .catchall {:try_start_13b .. :try_end_14e} :catchall_13f

    invoke-virtual {v5}, Lads_mobile_sdk/qg3;->a()V

    iget-object v0, v3, Lads_mobile_sdk/h7;->e:Lr73;

    invoke-interface {v0}, Lr73;->a()V

    goto :goto_17c

    :goto_157
    :try_start_157
    invoke-virtual {p0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v0

    if-nez v0, :cond_15e

    goto :goto_15f

    :cond_15e
    move-object p0, v0

    :goto_15f
    invoke-virtual {v5, p0}, Lads_mobile_sdk/qg3;->a(Ljava/lang/Throwable;)V

    const/4 p0, 0x3

    invoke-static {p0}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object p0
    :try_end_167
    .catchall {:try_start_157 .. :try_end_167} :catchall_13f

    invoke-virtual {v5}, Lads_mobile_sdk/qg3;->a()V

    iget-object v0, v3, Lads_mobile_sdk/h7;->e:Lr73;

    invoke-interface {v0}, Lr73;->a()V

    goto :goto_17c

    :catch_170
    :try_start_170
    invoke-virtual {v3, v1}, Lads_mobile_sdk/h7;->a(Z)Ljava/lang/String;

    move-result-object p0
    :try_end_174
    .catchall {:try_start_170 .. :try_end_174} :catchall_13f

    invoke-virtual {v5}, Lads_mobile_sdk/qg3;->a()V

    iget-object v0, v3, Lads_mobile_sdk/h7;->e:Lr73;

    invoke-interface {v0}, Lr73;->a()V

    :goto_17c
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {v2, p0}, Lads_mobile_sdk/m8;-><init>(Ljava/lang/String;)V

    invoke-direct {p1, v2}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    return-object p1

    :goto_186
    invoke-virtual {v5}, Lads_mobile_sdk/qg3;->a()V

    iget-object p1, v3, Lads_mobile_sdk/h7;->e:Lr73;

    invoke-interface {p1}, Lr73;->a()V

    throw p0

    :sswitch_18f
    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Runtime;->freeMemory()J

    move-result-wide v1

    invoke-virtual {p1}, Ljava/lang/Runtime;->maxMemory()J

    move-result-wide v3

    invoke-virtual {p1}, Ljava/lang/Runtime;->totalMemory()J

    move-result-wide v5

    iget-object p0, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/ek;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget v7, Lads_mobile_sdk/rl1;->b:I

    new-instance p0, Lads_mobile_sdk/hv0;

    new-instance v0, Lads_mobile_sdk/hp1;

    invoke-direct/range {v0 .. v7}, Lads_mobile_sdk/hp1;-><init>(JJJI)V

    invoke-direct {p0, v0}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    return-object p0

    nop

    :sswitch_data_1b4
    .sparse-switch
        0xa -> :sswitch_18f
        0x10 -> :sswitch_c9
        0x14 -> :sswitch_4b
    .end sparse-switch
.end method

.method public getAmount()I
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    check-cast p0, Lcom/google/android/gms/ads/rewarded/RewardItem;

    invoke-interface {p0}, Lcom/google/android/gms/ads/rewarded/RewardItem;->getAmount()I

    move-result p0

    return p0
.end method

.method public getType()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    check-cast p0, Lcom/google/android/gms/ads/rewarded/RewardItem;

    invoke-interface {p0}, Lcom/google/android/gms/ads/rewarded/RewardItem;->getType()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public onFailure(Ljava/lang/Throwable;)V
    .registers 3

    .prologue
    iget v0, p0, Lads_mobile_sdk/e7;->d:I

    packed-switch v0, :pswitch_data_12

    return-void

    :pswitch_6  #0x1a
    iget-object p0, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/qg3;

    invoke-virtual {p0, p1}, Lads_mobile_sdk/qg3;->a(Ljava/lang/Throwable;)V

    invoke-virtual {p0}, Lads_mobile_sdk/qg3;->a()V

    return-void

    nop

    :pswitch_data_12
    .packed-switch 0x1a
        :pswitch_6  #0000001a
    .end packed-switch
.end method

.method public onPostMessage(Landroid/webkit/WebView;Lkn2;Landroid/net/Uri;ZLbu0;)V
    .registers 6

    .prologue
    iget-object p0, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/ji;

    const/4 p1, 0x0

    invoke-virtual {p2, p1}, Lkn2;->a(I)V

    iget-object p1, p2, Lkn2;->b:Ljava/lang/String;

    :try_start_a
    new-instance p2, Lorg/json/JSONObject;

    invoke-direct {p2, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string p1, "method"

    invoke-virtual {p2, p1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const-string p3, "data"

    invoke-virtual {p2, p3}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p2

    iget-object p0, p0, Lads_mobile_sdk/ji;->b:Ljava/lang/Object;

    check-cast p0, Lj33;

    invoke-interface {p0, p1, p2}, Lj33;->a(Ljava/lang/String;Lorg/json/JSONObject;)V
    :try_end_22
    .catch Lorg/json/JSONException; {:try_start_a .. :try_end_22} :catch_23

    return-void

    :catch_23
    move-exception p0

    const-string p1, "Error parsing JS message"

    const-string p2, "OMIDLIB"

    nop

    return-void
.end method

.method public onSuccess(Landroidx/webkit/WebViewStartUpResult;)V
    .registers 3

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/cp3;

    if-eqz p0, :cond_1a

    sget-object v0, Lads_mobile_sdk/ho3;->a:Ljava/util/concurrent/atomic/AtomicBoolean;

    new-instance v0, Lads_mobile_sdk/go3;

    invoke-direct {v0, p1}, Lads_mobile_sdk/go3;-><init>(Landroidx/webkit/WebViewStartUpResult;)V

    iget-object p0, p0, Lads_mobile_sdk/cp3;->a:Ljn;

    new-instance p1, Lads_mobile_sdk/hv0;

    invoke-direct {p1, v0}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    invoke-virtual {p0, p1}, Ljn;->resumeWith(Ljava/lang/Object;)V

    :cond_1a
    return-void
.end method

.method public onSuccess(Ljava/lang/Object;)V
    .registers 3

    .prologue
    iget v0, p0, Lads_mobile_sdk/e7;->d:I

    packed-switch v0, :pswitch_data_2e

    check-cast p1, Lc23;

    iget-object p0, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/u83;

    iget-object p0, p0, Lads_mobile_sdk/u83;->c:Lads_mobile_sdk/qm1;

    iget-object v0, p0, Lads_mobile_sdk/qm1;->n:Ljava/lang/Object;

    monitor-enter v0

    :try_start_10
    iget-object p0, p0, Lads_mobile_sdk/qm1;->q:Ld43;

    invoke-interface {p1}, Lc23;->b()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object p0, p0, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast p0, Lads_mobile_sdk/t7;

    invoke-virtual {p0, p1}, Lads_mobile_sdk/t7;->b(Ljava/lang/String;)V

    monitor-exit v0

    return-void

    :catchall_22
    move-exception p0

    monitor-exit v0
    :try_end_24
    .catchall {:try_start_10 .. :try_end_24} :catchall_22

    throw p0

    :pswitch_25  #0x1a
    iget-object p0, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/qg3;

    invoke-virtual {p0}, Lads_mobile_sdk/qg3;->a()V

    return-void

    nop

    :pswitch_data_2e
    .packed-switch 0x1a
        :pswitch_25  #0000001a
    .end packed-switch
.end method

.method public size()J
    .registers 3

    iget-object p0, p0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    check-cast p0, Ljava/nio/ByteBuffer;

    invoke-virtual {p0}, Ljava/nio/Buffer;->capacity()I

    move-result p0

    int-to-long v0, p0

    return-wide v0
.end method
