.class public final Lads_mobile_sdk/a;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public a:Ljava/security/MessageDigest;

.field public final b:Lads_mobile_sdk/th3;

.field public final c:Ljava/lang/Object;

.field public d:Z

.field public e:Ljava/security/SecureRandom;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/th3;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lads_mobile_sdk/a;->c:Ljava/lang/Object;

    const/4 v0, 0x0

    iput-boolean v0, p0, Lads_mobile_sdk/a;->d:Z

    iput-object p1, p0, Lads_mobile_sdk/a;->b:Lads_mobile_sdk/th3;

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/String;[B)Ln03;
    .registers 11

    .prologue
    invoke-static {}, Lads_mobile_sdk/le;->o()Ln03;

    move-result-object v0

    invoke-virtual {p0, p2}, Lads_mobile_sdk/a;->a([B)[B

    move-result-object v1

    array-length v2, v1

    const/4 v3, 0x0

    invoke-static {v1, v3, v2}, Lads_mobile_sdk/hr;->a([BII)Lads_mobile_sdk/fr;

    move-result-object v1

    invoke-virtual {v0}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v2, v0, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v2, Lads_mobile_sdk/le;

    invoke-virtual {v2, v1}, Lads_mobile_sdk/le;->b(Lads_mobile_sdk/fr;)V

    array-length v1, p2

    add-int/lit8 v1, v1, -0x1

    div-int/lit16 v1, v1, 0xff

    add-int/lit8 v1, v1, 0x1

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    move v4, v3

    :goto_25
    if-ge v4, v1, :cond_3a

    mul-int/lit16 v5, v4, 0xff

    array-length v6, p2

    add-int/lit16 v7, v5, 0xff

    if-le v6, v7, :cond_2f

    goto :goto_30

    :cond_2f
    array-length v7, p2

    :goto_30
    invoke-static {p2, v5, v7}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v4, v4, 0x1

    goto :goto_25

    :cond_3a
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result p2

    move v1, v3

    :goto_3f
    if-ge v1, p2, :cond_5e

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    add-int/lit8 v1, v1, 0x1

    check-cast v4, [B

    invoke-virtual {p0, v4, p1, v3}, Lads_mobile_sdk/a;->a([BLjava/lang/String;Z)[B

    move-result-object v4

    const/16 v5, 0x100

    invoke-static {v4, v3, v5}, Lads_mobile_sdk/hr;->a([BII)Lads_mobile_sdk/fr;

    move-result-object v4

    invoke-virtual {v0}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v5, v0, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v5, Lads_mobile_sdk/le;

    invoke-virtual {v5, v4}, Lads_mobile_sdk/le;->a(Lads_mobile_sdk/fr;)V

    goto :goto_3f

    :cond_5e
    return-object v0
.end method

.method public final a()V
    .registers 6

    .prologue
    monitor-enter p0

    :try_start_1
    iget-boolean v0, p0, Lads_mobile_sdk/a;->d:Z
    :try_end_3
    .catchall {:try_start_1 .. :try_end_3} :catchall_45

    monitor-exit p0

    if-nez v0, :cond_44

    new-instance v0, Ljava/security/SecureRandom;

    invoke-direct {v0}, Ljava/security/SecureRandom;-><init>()V

    monitor-enter p0

    :try_start_c
    iget-object v1, p0, Lads_mobile_sdk/a;->b:Lads_mobile_sdk/th3;

    sget-object v2, Lads_mobile_sdk/fl0;->G:Lads_mobile_sdk/fl0;

    new-instance v3, Lads_mobile_sdk/qg3;

    iget-object v4, v1, Lads_mobile_sdk/th3;->b:Lx43;

    iget-object v1, v1, Lads_mobile_sdk/th3;->a:Lads_mobile_sdk/qm1;

    invoke-direct {v3, v2, v4, v1}, Lads_mobile_sdk/qg3;-><init>(Lads_mobile_sdk/fl0;Lx43;Lads_mobile_sdk/qm1;)V
    :try_end_19
    .catchall {:try_start_c .. :try_end_19} :catchall_3c

    :try_start_19
    invoke-virtual {v3}, Lads_mobile_sdk/qg3;->b()V

    iput-object v0, p0, Lads_mobile_sdk/a;->e:Ljava/security/SecureRandom;

    const-string v0, "MD5"

    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v0

    iput-object v0, p0, Lads_mobile_sdk/a;->a:Ljava/security/MessageDigest;

    const/4 v0, 0x1

    iput-boolean v0, p0, Lads_mobile_sdk/a;->d:Z
    :try_end_29
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_19 .. :try_end_29} :catch_2c
    .catchall {:try_start_19 .. :try_end_29} :catchall_2a

    goto :goto_37

    :catchall_2a
    move-exception v0

    goto :goto_2e

    :catch_2c
    move-exception v0

    goto :goto_34

    :goto_2e
    :try_start_2e
    invoke-virtual {v3, v0}, Lads_mobile_sdk/qg3;->a(Ljava/lang/Throwable;)V

    throw v0

    :catchall_32
    move-exception v0

    goto :goto_3e

    :goto_34
    invoke-virtual {v3, v0}, Lads_mobile_sdk/qg3;->a(Ljava/lang/Throwable;)V
    :try_end_37
    .catchall {:try_start_2e .. :try_end_37} :catchall_32

    :goto_37
    :try_start_37
    invoke-virtual {v3}, Lads_mobile_sdk/qg3;->a()V
    :try_end_3a
    .catchall {:try_start_37 .. :try_end_3a} :catchall_3c

    monitor-exit p0

    return-void

    :catchall_3c
    move-exception v0

    goto :goto_42

    :goto_3e
    :try_start_3e
    invoke-virtual {v3}, Lads_mobile_sdk/qg3;->a()V

    throw v0

    :goto_42
    monitor-exit p0
    :try_end_43
    .catchall {:try_start_3e .. :try_end_43} :catchall_3c

    throw v0

    :cond_44
    return-void

    :catchall_45
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public final a([B)[B
    .registers 4

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/a;->c:Ljava/lang/Object;

    monitor-enter v0

    :try_start_3
    iget-object v1, p0, Lads_mobile_sdk/a;->a:Ljava/security/MessageDigest;

    invoke-virtual {v1}, Ljava/security/MessageDigest;->reset()V

    iget-object v1, p0, Lads_mobile_sdk/a;->a:Ljava/security/MessageDigest;

    invoke-virtual {v1, p1}, Ljava/security/MessageDigest;->update([B)V

    iget-object p0, p0, Lads_mobile_sdk/a;->a:Ljava/security/MessageDigest;

    invoke-virtual {p0}, Ljava/security/MessageDigest;->digest()[B

    move-result-object p0

    monitor-exit v0

    return-object p0

    :catchall_15
    move-exception p0

    monitor-exit v0
    :try_end_17
    .catchall {:try_start_3 .. :try_end_17} :catchall_15

    throw p0
.end method

.method public final a([BLjava/lang/String;Z)[B
    .registers 12

    .prologue
    const/16 v0, 0xff

    if-eqz p3, :cond_7

    const/16 v1, 0xef

    goto :goto_8

    :cond_7
    move v1, v0

    :goto_8
    array-length v2, p1

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-gt v2, v1, :cond_f

    move v2, v3

    goto :goto_10

    :cond_f
    move v2, v4

    :goto_10
    invoke-static {v2}, Lgt0;->R(Z)V

    add-int/lit8 v2, v1, 0x1

    invoke-static {v2}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v2

    array-length v5, p1

    int-to-byte v5, v5

    invoke-virtual {v2, v5}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    move-result-object v2

    array-length v5, p1

    if-lt v5, v1, :cond_23

    goto :goto_37

    :cond_23
    array-length v5, p1

    sub-int/2addr v1, v5

    new-array v5, v1, [B

    iget-object v6, p0, Lads_mobile_sdk/a;->e:Ljava/security/SecureRandom;

    invoke-virtual {v6, v5}, Ljava/security/SecureRandom;->nextBytes([B)V

    array-length v6, p1

    add-int/2addr v6, v1

    invoke-static {p1, v6}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object v6

    array-length p1, p1

    invoke-static {v5, v4, v6, p1, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    move-object p1, v6

    :goto_37
    invoke-virtual {v2, p1}, Ljava/nio/ByteBuffer;->put([B)Ljava/nio/ByteBuffer;

    move-result-object p1

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object p1

    const/16 v1, 0x100

    if-eqz p3, :cond_57

    invoke-static {v1}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object p3

    invoke-virtual {p0, p1}, Lads_mobile_sdk/a;->a([B)[B

    move-result-object p0

    invoke-virtual {p3, p0}, Ljava/nio/ByteBuffer;->put([B)Ljava/nio/ByteBuffer;

    move-result-object p0

    invoke-virtual {p0, p1}, Ljava/nio/ByteBuffer;->put([B)Ljava/nio/ByteBuffer;

    move-result-object p0

    invoke-virtual {p0}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object p1

    :cond_57
    new-array p0, v1, [B

    new-instance p3, Lads_mobile_sdk/nk0;

    invoke-direct {p3}, Lads_mobile_sdk/nk0;-><init>()V

    iget-object p3, p3, Lads_mobile_sdk/nk0;->K2:[Lads_mobile_sdk/bk0;

    array-length v2, p3

    move v5, v4

    :goto_62
    if-ge v5, v2, :cond_6c

    aget-object v6, p3, v5

    invoke-virtual {v6, p1, p0}, Lads_mobile_sdk/bk0;->a([B[B)V

    add-int/lit8 v5, v5, 0x1

    goto :goto_62

    :cond_6c
    invoke-static {p2}, Lck1;->a(Ljava/lang/String;)Z

    move-result p1

    if-nez p1, :cond_b2

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result p1

    const/16 p3, 0x20

    if-le p1, p3, :cond_85

    invoke-virtual {p2, v4, p3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p1

    sget-object p2, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {p1, p2}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p1

    goto :goto_8b

    :cond_85
    sget-object p1, Ljava/nio/charset/StandardCharsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {p2, p1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p1

    :goto_8b
    new-instance p2, Lads_mobile_sdk/c;

    invoke-direct {p2, p1, v4}, Lads_mobile_sdk/c;-><init>([BI)V

    move p1, v4

    move p3, p1

    :goto_92
    if-ge v4, v1, :cond_b2

    add-int/2addr p1, v3

    and-int/2addr p1, v0

    iget-object v2, p2, Lads_mobile_sdk/c;->a:[B

    aget-byte v5, v2, p1

    add-int/2addr p3, v5

    and-int/2addr p3, v0

    aget-byte v6, v2, p3

    aput-byte v6, v2, p1

    aput-byte v5, v2, p3

    aget-byte v6, p0, v4

    aget-byte v7, v2, p1

    add-int/2addr v7, v5

    and-int/lit16 v5, v7, 0xff

    aget-byte v2, v2, v5

    xor-int/2addr v2, v6

    int-to-byte v2, v2

    aput-byte v2, p0, v4

    add-int/lit8 v4, v4, 0x1

    goto :goto_92

    :cond_b2
    return-object p0
.end method
