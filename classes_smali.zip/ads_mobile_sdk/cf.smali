.class public final Lads_mobile_sdk/cf;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public synthetic a:Ljava/lang/Object;

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic t:I


# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/Object;Lvx;I)V
    .registers 5

    iput p4, p0, Lads_mobile_sdk/cf;->t:I

    iput-object p1, p0, Lads_mobile_sdk/cf;->b:Ljava/lang/String;

    iput-object p2, p0, Lads_mobile_sdk/cf;->a:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lm82;-><init>(ILvx;)V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/String;Lvx;I)V
    .registers 4

    iput p3, p0, Lads_mobile_sdk/cf;->t:I

    iput-object p1, p0, Lads_mobile_sdk/cf;->b:Ljava/lang/String;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 5

    .prologue
    iget v0, p0, Lads_mobile_sdk/cf;->t:I

    iget-object v1, p0, Lads_mobile_sdk/cf;->b:Ljava/lang/String;

    packed-switch v0, :pswitch_data_82

    new-instance p2, Lads_mobile_sdk/cf;

    iget-object p0, p0, Lads_mobile_sdk/cf;->a:Ljava/lang/Object;

    const/16 v0, 0xc

    invoke-direct {p2, v1, p0, p1, v0}, Lads_mobile_sdk/cf;-><init>(Ljava/lang/String;Ljava/lang/Object;Lvx;I)V

    return-object p2

    :pswitch_11  #0xb
    new-instance p2, Lads_mobile_sdk/cf;

    iget-object p0, p0, Lads_mobile_sdk/cf;->a:Ljava/lang/Object;

    const/16 v0, 0xb

    invoke-direct {p2, v1, p0, p1, v0}, Lads_mobile_sdk/cf;-><init>(Ljava/lang/String;Ljava/lang/Object;Lvx;I)V

    return-object p2

    :pswitch_1b  #0xa
    new-instance p0, Lads_mobile_sdk/cf;

    const/16 v0, 0xa

    invoke-direct {p0, v1, p1, v0}, Lads_mobile_sdk/cf;-><init>(Ljava/lang/String;Lvx;I)V

    iput-object p2, p0, Lads_mobile_sdk/cf;->a:Ljava/lang/Object;

    return-object p0

    :pswitch_25  #0x9
    new-instance p2, Lads_mobile_sdk/cf;

    iget-object p0, p0, Lads_mobile_sdk/cf;->a:Ljava/lang/Object;

    const/16 v0, 0x9

    invoke-direct {p2, v1, p0, p1, v0}, Lads_mobile_sdk/cf;-><init>(Ljava/lang/String;Ljava/lang/Object;Lvx;I)V

    return-object p2

    :pswitch_2f  #0x8
    new-instance p2, Lads_mobile_sdk/cf;

    iget-object p0, p0, Lads_mobile_sdk/cf;->a:Ljava/lang/Object;

    const/16 v0, 0x8

    invoke-direct {p2, v1, p0, p1, v0}, Lads_mobile_sdk/cf;-><init>(Ljava/lang/String;Ljava/lang/Object;Lvx;I)V

    return-object p2

    :pswitch_39  #0x7
    new-instance p2, Lads_mobile_sdk/cf;

    iget-object p0, p0, Lads_mobile_sdk/cf;->a:Ljava/lang/Object;

    const/4 v0, 0x7

    invoke-direct {p2, v1, p0, p1, v0}, Lads_mobile_sdk/cf;-><init>(Ljava/lang/String;Ljava/lang/Object;Lvx;I)V

    return-object p2

    :pswitch_42  #0x6
    new-instance p2, Lads_mobile_sdk/cf;

    iget-object p0, p0, Lads_mobile_sdk/cf;->a:Ljava/lang/Object;

    const/4 v0, 0x6

    invoke-direct {p2, v1, p0, p1, v0}, Lads_mobile_sdk/cf;-><init>(Ljava/lang/String;Ljava/lang/Object;Lvx;I)V

    return-object p2

    :pswitch_4b  #0x5
    new-instance p2, Lads_mobile_sdk/cf;

    iget-object p0, p0, Lads_mobile_sdk/cf;->a:Ljava/lang/Object;

    const/4 v0, 0x5

    invoke-direct {p2, v1, p0, p1, v0}, Lads_mobile_sdk/cf;-><init>(Ljava/lang/String;Ljava/lang/Object;Lvx;I)V

    return-object p2

    :pswitch_54  #0x4
    new-instance p2, Lads_mobile_sdk/cf;

    iget-object p0, p0, Lads_mobile_sdk/cf;->a:Ljava/lang/Object;

    const/4 v0, 0x4

    invoke-direct {p2, v1, p0, p1, v0}, Lads_mobile_sdk/cf;-><init>(Ljava/lang/String;Ljava/lang/Object;Lvx;I)V

    return-object p2

    :pswitch_5d  #0x3
    new-instance p2, Lads_mobile_sdk/cf;

    iget-object p0, p0, Lads_mobile_sdk/cf;->a:Ljava/lang/Object;

    const/4 v0, 0x3

    invoke-direct {p2, v1, p0, p1, v0}, Lads_mobile_sdk/cf;-><init>(Ljava/lang/String;Ljava/lang/Object;Lvx;I)V

    return-object p2

    :pswitch_66  #0x2
    new-instance p2, Lads_mobile_sdk/cf;

    iget-object p0, p0, Lads_mobile_sdk/cf;->a:Ljava/lang/Object;

    const/4 v0, 0x2

    invoke-direct {p2, v1, p0, p1, v0}, Lads_mobile_sdk/cf;-><init>(Ljava/lang/String;Ljava/lang/Object;Lvx;I)V

    return-object p2

    :pswitch_6f  #0x1
    new-instance p2, Lads_mobile_sdk/cf;

    iget-object p0, p0, Lads_mobile_sdk/cf;->a:Ljava/lang/Object;

    const/4 v0, 0x1

    invoke-direct {p2, v1, p0, p1, v0}, Lads_mobile_sdk/cf;-><init>(Ljava/lang/String;Ljava/lang/Object;Lvx;I)V

    return-object p2

    :pswitch_78  #0x0
    new-instance p0, Lads_mobile_sdk/cf;

    const/4 v0, 0x0

    invoke-direct {p0, v1, p1, v0}, Lads_mobile_sdk/cf;-><init>(Ljava/lang/String;Lvx;I)V

    iput-object p2, p0, Lads_mobile_sdk/cf;->a:Ljava/lang/Object;

    return-object p0

    nop

    :pswitch_data_82
    .packed-switch 0x0
        :pswitch_78  #00000000
        :pswitch_6f  #00000001
        :pswitch_66  #00000002
        :pswitch_5d  #00000003
        :pswitch_54  #00000004
        :pswitch_4b  #00000005
        :pswitch_42  #00000006
        :pswitch_39  #00000007
        :pswitch_2f  #00000008
        :pswitch_25  #00000009
        :pswitch_1b  #0000000a
        :pswitch_11  #0000000b
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .prologue
    iget v0, p0, Lads_mobile_sdk/cf;->t:I

    iget-object v1, p0, Lads_mobile_sdk/cf;->b:Ljava/lang/String;

    sget-object v2, Lrg2;->a:Lrg2;

    packed-switch v0, :pswitch_data_c6

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    invoke-virtual {p0, p2, p1}, Lads_mobile_sdk/cf;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/cf;

    invoke-virtual {p0, v2}, Lads_mobile_sdk/cf;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object v2

    :pswitch_17  #0xb
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    invoke-virtual {p0, p2, p1}, Lads_mobile_sdk/cf;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/cf;

    invoke-virtual {p0, v2}, Lads_mobile_sdk/cf;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object v2

    :pswitch_25  #0xa
    check-cast p1, Lads_mobile_sdk/jq0;

    check-cast p2, Lvx;

    new-instance p0, Lads_mobile_sdk/cf;

    const/16 v0, 0xa

    invoke-direct {p0, v1, p2, v0}, Lads_mobile_sdk/cf;-><init>(Ljava/lang/String;Lvx;I)V

    iput-object p1, p0, Lads_mobile_sdk/cf;->a:Ljava/lang/Object;

    invoke-virtual {p0, v2}, Lads_mobile_sdk/cf;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_37  #0x9
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    invoke-virtual {p0, p2, p1}, Lads_mobile_sdk/cf;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/cf;

    invoke-virtual {p0, v2}, Lads_mobile_sdk/cf;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object v2

    :pswitch_45  #0x8
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    invoke-virtual {p0, p2, p1}, Lads_mobile_sdk/cf;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/cf;

    invoke-virtual {p0, v2}, Lads_mobile_sdk/cf;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object v2

    :pswitch_53  #0x7
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    invoke-virtual {p0, p2, p1}, Lads_mobile_sdk/cf;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/cf;

    invoke-virtual {p0, v2}, Lads_mobile_sdk/cf;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object v2

    :pswitch_61  #0x6
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    invoke-virtual {p0, p2, p1}, Lads_mobile_sdk/cf;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/cf;

    invoke-virtual {p0, v2}, Lads_mobile_sdk/cf;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object v2

    :pswitch_6f  #0x5
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    invoke-virtual {p0, p2, p1}, Lads_mobile_sdk/cf;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/cf;

    invoke-virtual {p0, v2}, Lads_mobile_sdk/cf;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object v2

    :pswitch_7d  #0x4
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    invoke-virtual {p0, p2, p1}, Lads_mobile_sdk/cf;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/cf;

    invoke-virtual {p0, v2}, Lads_mobile_sdk/cf;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object v2

    :pswitch_8b  #0x3
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    invoke-virtual {p0, p2, p1}, Lads_mobile_sdk/cf;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/cf;

    invoke-virtual {p0, v2}, Lads_mobile_sdk/cf;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object v2

    :pswitch_99  #0x2
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    invoke-virtual {p0, p2, p1}, Lads_mobile_sdk/cf;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/cf;

    invoke-virtual {p0, v2}, Lads_mobile_sdk/cf;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object v2

    :pswitch_a7  #0x1
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    invoke-virtual {p0, p2, p1}, Lads_mobile_sdk/cf;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/cf;

    invoke-virtual {p0, v2}, Lads_mobile_sdk/cf;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object v2

    :pswitch_b5  #0x0
    check-cast p1, Lads_mobile_sdk/af;

    check-cast p2, Lvx;

    new-instance p0, Lads_mobile_sdk/cf;

    const/4 v0, 0x0

    invoke-direct {p0, v1, p2, v0}, Lads_mobile_sdk/cf;-><init>(Ljava/lang/String;Lvx;I)V

    iput-object p1, p0, Lads_mobile_sdk/cf;->a:Ljava/lang/Object;

    invoke-virtual {p0, v2}, Lads_mobile_sdk/cf;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_data_c6
    .packed-switch 0x0
        :pswitch_b5  #00000000
        :pswitch_a7  #00000001
        :pswitch_99  #00000002
        :pswitch_8b  #00000003
        :pswitch_7d  #00000004
        :pswitch_6f  #00000005
        :pswitch_61  #00000006
        :pswitch_53  #00000007
        :pswitch_45  #00000008
        :pswitch_37  #00000009
        :pswitch_25  #0000000a
        :pswitch_17  #0000000b
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7

    .prologue
    iget v0, p0, Lads_mobile_sdk/cf;->t:I

    sget-object v1, Lrg2;->a:Lrg2;

    const/4 v2, 0x0

    const-string v3, "]"

    iget-object v4, p0, Lads_mobile_sdk/cf;->b:Ljava/lang/String;

    packed-switch v0, :pswitch_data_136

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    const-string p1, "Invoking function [onUserLeaveHint] on listener ["

    invoke-static {p1, v4, v3, v2}, Lrt2;->s(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    iget-object p0, p0, Lads_mobile_sdk/cf;->a:Ljava/lang/Object;

    check-cast p0, Lu63;

    invoke-interface {p0}, Lu63;->b()V

    return-object v1

    :pswitch_1c  #0xb
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    const-string p1, "Invoking function [onStop] on listener ["

    invoke-static {p1, v4, v3, v2}, Lrt2;->s(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    iget-object p0, p0, Lads_mobile_sdk/cf;->a:Ljava/lang/Object;

    check-cast p0, Lu63;

    invoke-interface {p0}, Lu63;->onStop()V

    return-object v1

    :pswitch_2c  #0xa
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p0, p0, Lads_mobile_sdk/cf;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/jq0;

    invoke-virtual {p0}, Lads_mobile_sdk/ku0;->n()Lads_mobile_sdk/iu0;

    move-result-object p0

    check-cast p0, Lnz2;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object p1, p0, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast p1, Lads_mobile_sdk/jq0;

    invoke-virtual {p1, v4}, Lads_mobile_sdk/jq0;->b(Ljava/lang/String;)V

    invoke-virtual {p0}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/jq0;

    return-object p0

    :pswitch_4d  #0x9
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    const-string p1, "Invoking function [onStart] on listener ["

    invoke-static {p1, v4, v3, v2}, Lrt2;->s(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    iget-object p0, p0, Lads_mobile_sdk/cf;->a:Ljava/lang/Object;

    check-cast p0, Lu63;

    invoke-interface {p0}, Lu63;->a$2()V

    return-object v1

    :pswitch_5d  #0x8
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    const-string p1, "Invoking function [onResume] on listener ["

    invoke-static {p1, v4, v3, v2}, Lrt2;->s(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    iget-object p0, p0, Lads_mobile_sdk/cf;->a:Ljava/lang/Object;

    check-cast p0, Lu63;

    invoke-interface {p0}, Lu63;->onResume()V

    return-object v1

    :pswitch_6d  #0x7
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    const-string p1, "Invoking function [onRestart] on listener ["

    invoke-static {p1, v4, v3, v2}, Lrt2;->s(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    iget-object p0, p0, Lads_mobile_sdk/cf;->a:Ljava/lang/Object;

    check-cast p0, Lu63;

    invoke-interface {p0}, Lu63;->c()V

    return-object v1

    :pswitch_7d  #0x6
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    const-string p1, "Invoking function [onPause] on listener ["

    invoke-static {p1, v4, v3, v2}, Lrt2;->s(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    iget-object p0, p0, Lads_mobile_sdk/cf;->a:Ljava/lang/Object;

    check-cast p0, Lu63;

    invoke-interface {p0}, Lu63;->onPause()V

    return-object v1

    :pswitch_8d  #0x5
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    const-string p1, "Invoking function [onDestroy] on listener ["

    invoke-static {p1, v4, v3, v2}, Lrt2;->s(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    iget-object p0, p0, Lads_mobile_sdk/cf;->a:Ljava/lang/Object;

    check-cast p0, Lu63;

    invoke-interface {p0}, Lu63;->onDestroy()V

    return-object v1

    :pswitch_9d  #0x4
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    const-string p1, "Invoking function [onCreate] on listener ["

    invoke-static {p1, v4, v3, v2}, Lrt2;->s(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    iget-object p0, p0, Lads_mobile_sdk/cf;->a:Ljava/lang/Object;

    check-cast p0, Lu63;

    invoke-interface {p0}, Lu63;->d()V

    return-object v1

    :pswitch_ad  #0x3
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    const-string p1, "Invoking function [onVideoPlay] on listener ["

    invoke-static {p1, v4, v3, v2}, Lrt2;->s(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    iget-object p0, p0, Lads_mobile_sdk/cf;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/pf3;

    iget-object p0, p0, Lads_mobile_sdk/pf3;->a:Lads_mobile_sdk/it1;

    iget-object p0, p0, Lads_mobile_sdk/it1;->m:Loj2;

    if-eqz p0, :cond_c2

    invoke-interface {p0}, Loj2;->getVideoLifecycleCallbacks()V

    :cond_c2
    return-object v1

    :pswitch_c3  #0x2
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    const-string p1, "Invoking function [onVideoPause] on listener ["

    invoke-static {p1, v4, v3, v2}, Lrt2;->s(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    iget-object p0, p0, Lads_mobile_sdk/cf;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/pf3;

    iget-object p0, p0, Lads_mobile_sdk/pf3;->a:Lads_mobile_sdk/it1;

    iget-object p0, p0, Lads_mobile_sdk/it1;->m:Loj2;

    if-eqz p0, :cond_d8

    invoke-interface {p0}, Loj2;->getVideoLifecycleCallbacks()V

    :cond_d8
    return-object v1

    :pswitch_d9  #0x1
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    const-string p1, "Invoking function [onVideoEnd] on listener ["

    invoke-static {p1, v4, v3, v2}, Lrt2;->s(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    iget-object p0, p0, Lads_mobile_sdk/cf;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/pf3;

    iget-object p0, p0, Lads_mobile_sdk/pf3;->a:Lads_mobile_sdk/it1;

    iget-object p0, p0, Lads_mobile_sdk/it1;->m:Loj2;

    if-eqz p0, :cond_ee

    invoke-interface {p0}, Loj2;->getVideoLifecycleCallbacks()V

    :cond_ee
    return-object v1

    :pswitch_ef  #0x0
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p0, p0, Lads_mobile_sdk/cf;->a:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/af;

    invoke-virtual {p0}, Lads_mobile_sdk/ku0;->n()Lads_mobile_sdk/iu0;

    move-result-object p0

    check-cast p0, Ll73;

    iget-object p1, p0, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast p1, Lads_mobile_sdk/af;

    invoke-static {p1}, Lads_mobile_sdk/af;->c(Lads_mobile_sdk/af;)Lads_mobile_sdk/gn1;

    move-result-object p1

    invoke-static {p1}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object p1

    invoke-static {p1}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object p1, p0, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast p1, Lads_mobile_sdk/af;

    invoke-static {p1}, Lads_mobile_sdk/af;->c(Lads_mobile_sdk/af;)Lads_mobile_sdk/gn1;

    move-result-object v0

    iget-boolean v1, v0, Lads_mobile_sdk/gn1;->a:Z

    if-nez v1, :cond_128

    invoke-virtual {v0}, Lads_mobile_sdk/gn1;->b()Lads_mobile_sdk/gn1;

    move-result-object v0

    invoke-static {p1, v0}, Lads_mobile_sdk/af;->d(Lads_mobile_sdk/af;Lads_mobile_sdk/gn1;)V

    :cond_128
    invoke-static {p1}, Lads_mobile_sdk/af;->c(Lads_mobile_sdk/af;)Lads_mobile_sdk/gn1;

    move-result-object p1

    invoke-virtual {p1, v4}, Lads_mobile_sdk/gn1;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p0}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/af;

    return-object p0

    :pswitch_data_136
    .packed-switch 0x0
        :pswitch_ef  #00000000
        :pswitch_d9  #00000001
        :pswitch_c3  #00000002
        :pswitch_ad  #00000003
        :pswitch_9d  #00000004
        :pswitch_8d  #00000005
        :pswitch_7d  #00000006
        :pswitch_6d  #00000007
        :pswitch_5d  #00000008
        :pswitch_4d  #00000009
        :pswitch_2c  #0000000a
        :pswitch_1c  #0000000b
    .end packed-switch
.end method
