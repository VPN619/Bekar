.class public final Lads_mobile_sdk/f0;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public a:I

.field public final synthetic b:Z

.field public final synthetic c:Lot2;

.field public final synthetic d:J

.field public final synthetic t:I


# direct methods
.method public synthetic constructor <init>(ZLot2;JLvx;I)V
    .registers 7

    iput p6, p0, Lads_mobile_sdk/f0;->t:I

    iput-boolean p1, p0, Lads_mobile_sdk/f0;->b:Z

    iput-object p2, p0, Lads_mobile_sdk/f0;->c:Lot2;

    iput-wide p3, p0, Lads_mobile_sdk/f0;->d:J

    const/4 p1, 0x2

    invoke-direct {p0, p1, p5}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 11

    .prologue
    iget p2, p0, Lads_mobile_sdk/f0;->t:I

    packed-switch p2, :pswitch_data_26

    new-instance v0, Lads_mobile_sdk/f0;

    iget-object p2, p0, Lads_mobile_sdk/f0;->c:Lot2;

    move-object v2, p2

    check-cast v2, Lads_mobile_sdk/xj2;

    iget-wide v3, p0, Lads_mobile_sdk/f0;->d:J

    const/4 v6, 0x1

    iget-boolean v1, p0, Lads_mobile_sdk/f0;->b:Z

    move-object v5, p1

    invoke-direct/range {v0 .. v6}, Lads_mobile_sdk/f0;-><init>(ZLot2;JLvx;I)V

    return-object v0

    :pswitch_16  #0x0
    move-object v5, p1

    new-instance v1, Lads_mobile_sdk/f0;

    move-object v6, v5

    iget-wide v4, p0, Lads_mobile_sdk/f0;->d:J

    const/4 v7, 0x0

    iget-boolean v2, p0, Lads_mobile_sdk/f0;->b:Z

    iget-object v3, p0, Lads_mobile_sdk/f0;->c:Lot2;

    invoke-direct/range {v1 .. v7}, Lads_mobile_sdk/f0;-><init>(ZLot2;JLvx;I)V

    return-object v1

    nop

    :pswitch_data_26
    .packed-switch 0x0
        :pswitch_16  #00000000
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .prologue
    iget v0, p0, Lads_mobile_sdk/f0;->t:I

    sget-object v1, Lrg2;->a:Lrg2;

    packed-switch v0, :pswitch_data_26

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    invoke-virtual {p0, p2, p1}, Lads_mobile_sdk/f0;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/f0;

    invoke-virtual {p0, v1}, Lads_mobile_sdk/f0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_16  #0x0
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    invoke-virtual {p0, p2, p1}, Lads_mobile_sdk/f0;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/f0;

    invoke-virtual {p0, v1}, Lads_mobile_sdk/f0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_26
    .packed-switch 0x0
        :pswitch_16  #00000000
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 13

    .prologue
    iget v0, p0, Lads_mobile_sdk/f0;->t:I

    sget-object v1, Lrg2;->a:Lrg2;

    iget-object v2, p0, Lads_mobile_sdk/f0;->c:Lot2;

    iget-boolean v3, p0, Lads_mobile_sdk/f0;->b:Z

    const/4 v4, 0x0

    const-string v5, "call to \'resume\' before \'invoke\' with coroutine"

    sget-object v6, Lwy;->a:Lwy;

    const/4 v7, 0x1

    const/4 v8, 0x2

    iget-wide v9, p0, Lads_mobile_sdk/f0;->d:J

    packed-switch v0, :pswitch_data_70

    iget v0, p0, Lads_mobile_sdk/f0;->a:I

    if-eqz v0, :cond_26

    if-eq v0, v7, :cond_22

    if-ne v0, v8, :cond_1d

    goto :goto_22

    :cond_1d
    invoke-static {v5}, Lz6;->w(Ljava/lang/String;)V

    move-object v1, v4

    goto :goto_45

    :cond_22
    :goto_22
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_45

    :cond_26
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    check-cast v2, Lads_mobile_sdk/xj2;

    if-eqz v3, :cond_39

    iput v7, p0, Lads_mobile_sdk/f0;->a:I

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v2, v9, v10, p0}, Lads_mobile_sdk/xj2;->c(Lads_mobile_sdk/xj2;JLwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v6, :cond_45

    goto :goto_44

    :cond_39
    iput v8, p0, Lads_mobile_sdk/f0;->a:I

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v2, v9, v10, p0}, Lads_mobile_sdk/xj2;->d(Lads_mobile_sdk/xj2;JLwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v6, :cond_45

    :goto_44
    move-object v1, v6

    :cond_45
    :goto_45
    return-object v1

    :pswitch_46  #0x0
    iget v0, p0, Lads_mobile_sdk/f0;->a:I

    if-eqz v0, :cond_58

    if-eq v0, v7, :cond_54

    if-ne v0, v8, :cond_4f

    goto :goto_54

    :cond_4f
    invoke-static {v5}, Lz6;->w(Ljava/lang/String;)V

    move-object v1, v4

    goto :goto_6f

    :cond_54
    :goto_54
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_6f

    :cond_58
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    if-eqz v3, :cond_66

    iput v7, p0, Lads_mobile_sdk/f0;->a:I

    invoke-interface {v2, v9, v10, p0}, Lot2;->d(JLm82;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v6, :cond_6f

    goto :goto_6e

    :cond_66
    iput v8, p0, Lads_mobile_sdk/f0;->a:I

    invoke-interface {v2, v9, v10, p0}, Lot2;->b(JLm82;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v6, :cond_6f

    :goto_6e
    move-object v1, v6

    :cond_6f
    :goto_6f
    return-object v1

    :pswitch_data_70
    .packed-switch 0x0
        :pswitch_46  #00000000
    .end packed-switch
.end method
