.class public final Lads_mobile_sdk/ff2;
.super Lwx;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public a:Lads_mobile_sdk/if2;

.field public b:Lnb1;

.field public synthetic c:Ljava/lang/Object;

.field public final synthetic d:Lads_mobile_sdk/if2;

.field public e:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/if2;Lwx;)V
    .registers 3

    iput-object p1, p0, Lads_mobile_sdk/ff2;->d:Lads_mobile_sdk/if2;

    invoke-direct {p0, p2}, Lwx;-><init>(Lvx;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    iput-object p1, p0, Lads_mobile_sdk/ff2;->c:Ljava/lang/Object;

    iget p1, p0, Lads_mobile_sdk/ff2;->e:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, Lads_mobile_sdk/ff2;->e:I

    iget-object p1, p0, Lads_mobile_sdk/ff2;->d:Lads_mobile_sdk/if2;

    invoke-static {p1, p0}, Lads_mobile_sdk/if2;->a(Lads_mobile_sdk/if2;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
