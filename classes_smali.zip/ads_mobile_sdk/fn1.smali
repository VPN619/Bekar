.class public final Lads_mobile_sdk/fn1;
.super Lads_mobile_sdk/e;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final b:Lads_mobile_sdk/ob1;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    sget-object v0, Ljava/util/Collections;->EMPTY_MAP:Ljava/util/Map;

    invoke-static {v0}, Lads_mobile_sdk/ob1;->a(Ljava/lang/Object;)Lads_mobile_sdk/ob1;

    move-result-object v0

    sput-object v0, Lads_mobile_sdk/fn1;->b:Lads_mobile_sdk/ob1;

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 4

    .prologue
    iget-object p0, p0, Lads_mobile_sdk/e;->a:Ljava/util/Map;

    invoke-interface {p0}, Ljava/util/Map;->size()I

    move-result v0

    new-instance v1, Ljava/util/LinkedHashMap;

    const/4 v2, 0x3

    if-ge v0, v2, :cond_e

    add-int/lit8 v0, v0, 0x1

    goto :goto_1e

    :cond_e
    const/high16 v2, 0x40000000  # 2.0f

    if-ge v0, v2, :cond_1b

    int-to-float v0, v0

    const/high16 v2, 0x3f400000  # 0.75f

    div-float/2addr v0, v2

    const/high16 v2, 0x3f800000  # 1.0f

    add-float/2addr v0, v2

    float-to-int v0, v0

    goto :goto_1e

    :cond_1b
    const v0, 0x7fffffff

    :goto_1e
    invoke-direct {v1, v0}, Ljava/util/LinkedHashMap;-><init>(I)V

    invoke-interface {p0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_29
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_47

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map$Entry;

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ltv2;

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    invoke-interface {v1, v2, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_29

    :cond_47
    invoke-static {v1}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object p0

    return-object p0
.end method
