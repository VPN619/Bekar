.class public final Lads_mobile_sdk/dm;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lk33;


# instance fields
.field public final a:Ljava/lang/Object;

.field public final b:Ljava/lang/Object;

.field public final synthetic c:I


# direct methods
.method public constructor <init>(Lc73;)V
    .registers 3

    const/4 v0, 0x0

    iput v0, p0, Lads_mobile_sdk/dm;->c:I

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/dm;->a:Ljava/lang/Object;

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-direct {p1, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object p1, p0, Lads_mobile_sdk/dm;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lvy;Lads_mobile_sdk/cy0;)V
    .registers 4

    const/4 v0, 0x1

    iput v0, p0, Lads_mobile_sdk/dm;->c:I

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Lads_mobile_sdk/dm;->a:Ljava/lang/Object;

    iput-object p1, p0, Lads_mobile_sdk/dm;->b:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final c(Lvx;)Ljava/lang/Object;
    .registers 6

    .prologue
    iget v0, p0, Lads_mobile_sdk/dm;->c:I

    sget-object v1, Lrg2;->a:Lrg2;

    iget-object v2, p0, Lads_mobile_sdk/dm;->b:Ljava/lang/Object;

    iget-object p0, p0, Lads_mobile_sdk/dm;->a:Ljava/lang/Object;

    packed-switch v0, :pswitch_data_40

    check-cast p0, Lads_mobile_sdk/cy0;

    iget-object p0, p0, Lads_mobile_sdk/cy0;->o:Lads_mobile_sdk/mt0;

    if-eqz p0, :cond_28

    check-cast v2, Lvy;

    new-instance p1, Lc4;

    const/4 v0, 0x4

    const/4 v3, 0x0

    invoke-direct {p1, p0, v3, v0}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance p0, La42;

    invoke-direct {p0, p1, v3}, La42;-><init>(Lpk0;Lvx;)V

    const/4 p1, 0x2

    sget-object v0, Ly90;->a:Ly90;

    invoke-static {v2, v0, v3, p0, p1}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    :cond_28
    return-object v1

    :pswitch_29  #0x0
    check-cast v2, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v0, 0x0

    const/4 v3, 0x1

    invoke-virtual {v2, v0, v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v0

    if-eqz v0, :cond_3e

    check-cast p0, Lc73;

    invoke-interface {p0, p1}, Lc73;->a(Lvx;)Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lwy;->a:Lwy;

    if-ne p0, p1, :cond_3e

    move-object v1, p0

    :cond_3e
    return-object v1

    nop

    :pswitch_data_40
    .packed-switch 0x0
        :pswitch_29  #00000000
    .end packed-switch
.end method
