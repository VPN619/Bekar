.class public final Lads_mobile_sdk/f63;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:Ljava/lang/String;

.field public final c:[Ljava/lang/Class;


# direct methods
.method public varargs constructor <init>(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Class;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/f63;->a:Ljava/lang/String;

    iput-object p2, p0, Lads_mobile_sdk/f63;->b:Ljava/lang/String;

    iput-object p3, p0, Lads_mobile_sdk/f63;->c:[Ljava/lang/Class;

    return-void
.end method
