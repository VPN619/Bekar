.class public final Lads_mobile_sdk/ad;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lf43;


# static fields
.field public static final a:Lads_mobile_sdk/ad;

.field public static final a$1:Lads_mobile_sdk/ad;

.field public static final a$10:Lads_mobile_sdk/ad;

.field public static final a$11:Lads_mobile_sdk/ad;

.field public static final a$12:Lads_mobile_sdk/ad;

.field public static final a$13:Lads_mobile_sdk/ad;

.field public static final a$14:Lads_mobile_sdk/ad;

.field public static final a$15:Lads_mobile_sdk/ad;

.field public static final a$16:Lads_mobile_sdk/ad;

.field public static final a$17:Lads_mobile_sdk/ad;

.field public static final a$18:Lads_mobile_sdk/ad;

.field public static final a$19:Lads_mobile_sdk/ad;

.field public static final a$2:Lads_mobile_sdk/ad;

.field public static final a$20:Lads_mobile_sdk/ad;

.field public static final a$21:Lads_mobile_sdk/ad;

.field public static final a$22:Lads_mobile_sdk/ad;

.field public static final a$23:Lads_mobile_sdk/ad;

.field public static final a$24:Lads_mobile_sdk/ad;

.field public static final a$25:Lads_mobile_sdk/ad;

.field public static final a$26:Lads_mobile_sdk/ad;

.field public static final a$27:Lads_mobile_sdk/ad;

.field public static final a$28:Lads_mobile_sdk/ad;

.field public static final a$29:Lads_mobile_sdk/ad;

.field public static final a$3:Lads_mobile_sdk/ad;

.field public static final a$4:Lads_mobile_sdk/ad;

.field public static final a$5:Lads_mobile_sdk/ad;

.field public static final a$6:Lads_mobile_sdk/ad;

.field public static final a$7:Lads_mobile_sdk/ad;

.field public static final a$8:Lads_mobile_sdk/ad;

.field public static final a$9:Lads_mobile_sdk/ad;


# instance fields
.field public final synthetic b:I


# direct methods
.method static synthetic constructor <clinit>()V
    .registers 2

    new-instance v0, Lads_mobile_sdk/ad;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lads_mobile_sdk/ad;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/ad;->a$1:Lads_mobile_sdk/ad;

    new-instance v0, Lads_mobile_sdk/ad;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lads_mobile_sdk/ad;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/ad;->a:Lads_mobile_sdk/ad;

    new-instance v0, Lads_mobile_sdk/ad;

    const/4 v1, 0x2

    invoke-direct {v0, v1}, Lads_mobile_sdk/ad;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/ad;->a$2:Lads_mobile_sdk/ad;

    new-instance v0, Lads_mobile_sdk/ad;

    const/4 v1, 0x3

    invoke-direct {v0, v1}, Lads_mobile_sdk/ad;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/ad;->a$3:Lads_mobile_sdk/ad;

    new-instance v0, Lads_mobile_sdk/ad;

    const/4 v1, 0x4

    invoke-direct {v0, v1}, Lads_mobile_sdk/ad;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/ad;->a$4:Lads_mobile_sdk/ad;

    new-instance v0, Lads_mobile_sdk/ad;

    const/4 v1, 0x5

    invoke-direct {v0, v1}, Lads_mobile_sdk/ad;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/ad;->a$5:Lads_mobile_sdk/ad;

    new-instance v0, Lads_mobile_sdk/ad;

    const/4 v1, 0x6

    invoke-direct {v0, v1}, Lads_mobile_sdk/ad;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/ad;->a$6:Lads_mobile_sdk/ad;

    new-instance v0, Lads_mobile_sdk/ad;

    const/4 v1, 0x7

    invoke-direct {v0, v1}, Lads_mobile_sdk/ad;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/ad;->a$7:Lads_mobile_sdk/ad;

    new-instance v0, Lads_mobile_sdk/ad;

    const/16 v1, 0x8

    invoke-direct {v0, v1}, Lads_mobile_sdk/ad;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/ad;->a$8:Lads_mobile_sdk/ad;

    new-instance v0, Lads_mobile_sdk/ad;

    const/16 v1, 0x9

    invoke-direct {v0, v1}, Lads_mobile_sdk/ad;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/ad;->a$9:Lads_mobile_sdk/ad;

    new-instance v0, Lads_mobile_sdk/ad;

    const/16 v1, 0xa

    invoke-direct {v0, v1}, Lads_mobile_sdk/ad;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/ad;->a$10:Lads_mobile_sdk/ad;

    new-instance v0, Lads_mobile_sdk/ad;

    const/16 v1, 0xb

    invoke-direct {v0, v1}, Lads_mobile_sdk/ad;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/ad;->a$11:Lads_mobile_sdk/ad;

    new-instance v0, Lads_mobile_sdk/ad;

    const/16 v1, 0xc

    invoke-direct {v0, v1}, Lads_mobile_sdk/ad;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/ad;->a$12:Lads_mobile_sdk/ad;

    new-instance v0, Lads_mobile_sdk/ad;

    const/16 v1, 0xd

    invoke-direct {v0, v1}, Lads_mobile_sdk/ad;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/ad;->a$13:Lads_mobile_sdk/ad;

    new-instance v0, Lads_mobile_sdk/ad;

    const/16 v1, 0xe

    invoke-direct {v0, v1}, Lads_mobile_sdk/ad;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/ad;->a$14:Lads_mobile_sdk/ad;

    new-instance v0, Lads_mobile_sdk/ad;

    const/16 v1, 0xf

    invoke-direct {v0, v1}, Lads_mobile_sdk/ad;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/ad;->a$15:Lads_mobile_sdk/ad;

    new-instance v0, Lads_mobile_sdk/ad;

    const/16 v1, 0x10

    invoke-direct {v0, v1}, Lads_mobile_sdk/ad;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/ad;->a$16:Lads_mobile_sdk/ad;

    new-instance v0, Lads_mobile_sdk/ad;

    const/16 v1, 0x11

    invoke-direct {v0, v1}, Lads_mobile_sdk/ad;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/ad;->a$17:Lads_mobile_sdk/ad;

    new-instance v0, Lads_mobile_sdk/ad;

    const/16 v1, 0x12

    invoke-direct {v0, v1}, Lads_mobile_sdk/ad;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/ad;->a$18:Lads_mobile_sdk/ad;

    new-instance v0, Lads_mobile_sdk/ad;

    const/16 v1, 0x13

    invoke-direct {v0, v1}, Lads_mobile_sdk/ad;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/ad;->a$19:Lads_mobile_sdk/ad;

    new-instance v0, Lads_mobile_sdk/ad;

    const/16 v1, 0x14

    invoke-direct {v0, v1}, Lads_mobile_sdk/ad;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/ad;->a$20:Lads_mobile_sdk/ad;

    new-instance v0, Lads_mobile_sdk/ad;

    const/16 v1, 0x15

    invoke-direct {v0, v1}, Lads_mobile_sdk/ad;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/ad;->a$21:Lads_mobile_sdk/ad;

    new-instance v0, Lads_mobile_sdk/ad;

    const/16 v1, 0x16

    invoke-direct {v0, v1}, Lads_mobile_sdk/ad;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/ad;->a$22:Lads_mobile_sdk/ad;

    new-instance v0, Lads_mobile_sdk/ad;

    const/16 v1, 0x17

    invoke-direct {v0, v1}, Lads_mobile_sdk/ad;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/ad;->a$23:Lads_mobile_sdk/ad;

    new-instance v0, Lads_mobile_sdk/ad;

    const/16 v1, 0x18

    invoke-direct {v0, v1}, Lads_mobile_sdk/ad;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/ad;->a$24:Lads_mobile_sdk/ad;

    new-instance v0, Lads_mobile_sdk/ad;

    const/16 v1, 0x19

    invoke-direct {v0, v1}, Lads_mobile_sdk/ad;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/ad;->a$25:Lads_mobile_sdk/ad;

    new-instance v0, Lads_mobile_sdk/ad;

    const/16 v1, 0x1a

    invoke-direct {v0, v1}, Lads_mobile_sdk/ad;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/ad;->a$26:Lads_mobile_sdk/ad;

    new-instance v0, Lads_mobile_sdk/ad;

    const/16 v1, 0x1b

    invoke-direct {v0, v1}, Lads_mobile_sdk/ad;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/ad;->a$27:Lads_mobile_sdk/ad;

    new-instance v0, Lads_mobile_sdk/ad;

    const/16 v1, 0x1c

    invoke-direct {v0, v1}, Lads_mobile_sdk/ad;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/ad;->a$28:Lads_mobile_sdk/ad;

    new-instance v0, Lads_mobile_sdk/ad;

    const/16 v1, 0x1d

    invoke-direct {v0, v1}, Lads_mobile_sdk/ad;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/ad;->a$29:Lads_mobile_sdk/ad;

    return-void
.end method

.method public synthetic constructor <init>(I)V
    .registers 2

    iput p1, p0, Lads_mobile_sdk/ad;->b:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(I)Z
    .registers 9

    .prologue
    iget p0, p0, Lads_mobile_sdk/ad;->b:I

    const/4 v0, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    packed-switch p0, :pswitch_data_13c

    invoke-static {p1}, Lmz2;->_a(I)I

    move-result p0

    if-eqz p0, :cond_13

    move v5, v6

    :cond_13
    return v5

    :pswitch_14  #0x1c
    if-eqz p1, :cond_1f

    if-eq p1, v6, :cond_1f

    if-eq p1, v4, :cond_1f

    if-eq p1, v3, :cond_1f

    if-eq p1, v2, :cond_1f

    goto :goto_20

    :cond_1f
    move v5, v6

    :goto_20
    return v5

    :pswitch_21  #0x1b
    if-eqz p1, :cond_2a

    if-eq p1, v6, :cond_2a

    if-eq p1, v4, :cond_2a

    if-eq p1, v3, :cond_2a

    goto :goto_2b

    :cond_2a
    move v5, v6

    :goto_2b
    return v5

    :pswitch_2c  #0x1a
    if-eqz p1, :cond_31

    if-eq p1, v6, :cond_31

    goto :goto_32

    :cond_31
    move v5, v6

    :goto_32
    return v5

    :pswitch_33  #0x19
    packed-switch p1, :pswitch_data_17a

    goto :goto_38

    :pswitch_37  #0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9, 0xa, 0xb, 0xc, 0xd, 0xe, 0xf, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c
    move v5, v6

    :goto_38
    return v5

    :pswitch_39  #0x18
    invoke-static {p1}, Lads_mobile_sdk/nf2;->a(I)Lads_mobile_sdk/nf2;

    move-result-object p0

    if-eqz p0, :cond_40

    move v5, v6

    :cond_40
    return v5

    :pswitch_41  #0x17
    packed-switch p1, :pswitch_data_1b8

    goto :goto_46

    :pswitch_45  #0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9
    move v5, v6

    :goto_46
    return v5

    :pswitch_47  #0x16
    invoke-static {p1}, Lads_mobile_sdk/mk;->a(I)Lads_mobile_sdk/mk;

    move-result-object p0

    if-eqz p0, :cond_4e

    move v5, v6

    :cond_4e
    return v5

    :pswitch_4f  #0x15
    if-eqz p1, :cond_58

    if-eq p1, v6, :cond_58

    if-eq p1, v4, :cond_58

    if-eq p1, v3, :cond_58

    goto :goto_59

    :cond_58
    move v5, v6

    :goto_59
    return v5

    :pswitch_5a  #0x14
    if-eqz p1, :cond_62

    if-eq p1, v6, :cond_5f

    goto :goto_64

    :cond_5f
    sget-object v0, Lads_mobile_sdk/lq;->c:Lads_mobile_sdk/lq;

    goto :goto_64

    :cond_62
    sget-object v0, Lads_mobile_sdk/lq;->b:Lads_mobile_sdk/lq;

    :goto_64
    if-eqz v0, :cond_67

    move v5, v6

    :cond_67
    return v5

    :pswitch_68  #0x13
    if-eqz p1, :cond_73

    if-eq p1, v6, :cond_73

    if-eq p1, v4, :cond_73

    if-eq p1, v3, :cond_73

    if-eq p1, v2, :cond_73

    goto :goto_74

    :cond_73
    move v5, v6

    :goto_74
    return v5

    :pswitch_75  #0x12
    packed-switch p1, :pswitch_data_1d0

    goto :goto_7a

    :pswitch_79  #0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9, 0xa, 0xb, 0xc, 0xd, 0xe, 0xf
    move v5, v6

    :goto_7a
    return v5

    :pswitch_7b  #0x11
    packed-switch p1, :pswitch_data_1f4

    :pswitch_7e  #0xe, 0x11
    goto :goto_80

    :pswitch_7f  #0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9, 0xa, 0xb, 0xc, 0xd, 0xf, 0x10, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17
    move v5, v6

    :goto_80
    return v5

    :pswitch_81  #0x10
    if-eqz p1, :cond_86

    if-eq p1, v6, :cond_86

    goto :goto_87

    :cond_86
    move v5, v6

    :goto_87
    return v5

    :pswitch_88  #0xf
    packed-switch p1, :pswitch_data_228

    goto :goto_8d

    :pswitch_8c  #0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6
    move v5, v6

    :goto_8d
    return v5

    :pswitch_8e  #0xe
    if-eqz p1, :cond_97

    if-eq p1, v6, :cond_97

    if-eq p1, v4, :cond_97

    if-eq p1, v3, :cond_97

    goto :goto_98

    :cond_97
    move v5, v6

    :goto_98
    return v5

    :pswitch_99  #0xd
    packed-switch p1, :pswitch_data_23a

    goto :goto_9e

    :pswitch_9d  #0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9, 0xa, 0xb, 0xc, 0xd, 0xe, 0xf, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f, 0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3a, 0x3b, 0x3c, 0x3d, 0x3e, 0x3f, 0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47, 0x48, 0x49, 0x4a, 0x4b, 0x4c, 0x4d, 0x4e, 0x4f, 0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59, 0x5a, 0x5b, 0x5c, 0x5d, 0x5e, 0x5f, 0x60, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6a, 0x6b, 0x6c, 0x6d, 0x6e, 0x6f, 0x70, 0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78, 0x79, 0x7a, 0x7b
    move v5, v6

    :goto_9e
    return v5

    :pswitch_9f  #0xc
    packed-switch p1, :pswitch_data_336

    goto :goto_a4

    :pswitch_a3  #0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7
    move v5, v6

    :goto_a4
    return v5

    :pswitch_a5  #0xb
    packed-switch p1, :pswitch_data_348

    goto :goto_aa

    :pswitch_a9  #0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8, 0x9, 0xa
    move v5, v6

    :goto_aa
    return v5

    :pswitch_ab  #0xa
    if-eqz p1, :cond_c7

    if-eq p1, v6, :cond_c4

    if-eq p1, v4, :cond_c1

    if-eq p1, v3, :cond_be

    if-eq p1, v2, :cond_bb

    if-eq p1, v1, :cond_b8

    goto :goto_c9

    :cond_b8
    sget-object v0, Lads_mobile_sdk/g40;->g:Lads_mobile_sdk/g40;

    goto :goto_c9

    :cond_bb
    sget-object v0, Lads_mobile_sdk/g40;->f:Lads_mobile_sdk/g40;

    goto :goto_c9

    :cond_be
    sget-object v0, Lads_mobile_sdk/g40;->e:Lads_mobile_sdk/g40;

    goto :goto_c9

    :cond_c1
    sget-object v0, Lads_mobile_sdk/g40;->d:Lads_mobile_sdk/g40;

    goto :goto_c9

    :cond_c4
    sget-object v0, Lads_mobile_sdk/g40;->c:Lads_mobile_sdk/g40;

    goto :goto_c9

    :cond_c7
    sget-object v0, Lads_mobile_sdk/g40;->b:Lads_mobile_sdk/g40;

    :goto_c9
    if-eqz v0, :cond_cc

    move v5, v6

    :cond_cc
    return v5

    :pswitch_cd  #0x9
    if-eqz p1, :cond_d8

    if-eq p1, v6, :cond_d8

    if-eq p1, v4, :cond_d8

    if-eq p1, v3, :cond_d8

    if-eq p1, v2, :cond_d8

    goto :goto_d9

    :cond_d8
    move v5, v6

    :goto_d9
    return v5

    :pswitch_da  #0x8
    const/16 p0, 0xc8

    if-eq p1, p0, :cond_f2

    const/16 p0, 0xc9

    if-eq p1, p0, :cond_f2

    if-eqz p1, :cond_f2

    if-eq p1, v6, :cond_f2

    if-eq p1, v4, :cond_f2

    if-eq p1, v3, :cond_f2

    if-eq p1, v2, :cond_f2

    if-eq p1, v1, :cond_f2

    packed-switch p1, :pswitch_data_362

    goto :goto_f3

    :cond_f2
    :pswitch_f2  #0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6a, 0x6b, 0x6c, 0x6d, 0x6e, 0x6f, 0x70, 0x71, 0x72
    move v5, v6

    :goto_f3
    return v5

    :pswitch_f4  #0x7
    if-eqz p1, :cond_fd

    if-eq p1, v6, :cond_fd

    if-eq p1, v4, :cond_fd

    if-eq p1, v3, :cond_fd

    goto :goto_fe

    :cond_fd
    move v5, v6

    :goto_fe
    return v5

    :pswitch_ff  #0x6
    if-eqz p1, :cond_106

    if-eq p1, v6, :cond_106

    if-eq p1, v4, :cond_106

    goto :goto_107

    :cond_106
    move v5, v6

    :goto_107
    return v5

    :pswitch_108  #0x5
    packed-switch p1, :pswitch_data_384

    goto :goto_10d

    :pswitch_10c  #0x0, 0x1, 0x2, 0x3, 0x4, 0x5, 0x6, 0x7, 0x8
    move v5, v6

    :goto_10d
    return v5

    :pswitch_10e  #0x4
    invoke-static {p1}, Lrt2;->_a$2(I)I

    move-result p0

    if-eqz p0, :cond_115

    move v5, v6

    :cond_115
    return v5

    :pswitch_116  #0x3
    if-eqz p1, :cond_123

    if-eq p1, v6, :cond_123

    if-eq p1, v4, :cond_123

    if-eq p1, v3, :cond_123

    if-eq p1, v2, :cond_123

    if-eq p1, v1, :cond_123

    goto :goto_124

    :cond_123
    move v5, v6

    :goto_124
    return v5

    :pswitch_125  #0x2
    invoke-static {p1}, Lrt2;->_a$1(I)I

    move-result p0

    if-eqz p0, :cond_12c

    move v5, v6

    :cond_12c
    return v5

    :pswitch_12d  #0x1
    if-eqz p1, :cond_132

    if-eq p1, v6, :cond_132

    goto :goto_133

    :cond_132
    move v5, v6

    :goto_133
    return v5

    :pswitch_134  #0x0
    invoke-static {p1}, Lrt2;->_a(I)I

    move-result p0

    if-eqz p0, :cond_13b

    move v5, v6

    :cond_13b
    return v5

    :pswitch_data_13c
    .packed-switch 0x0
        :pswitch_134  #00000000
        :pswitch_12d  #00000001
        :pswitch_125  #00000002
        :pswitch_116  #00000003
        :pswitch_10e  #00000004
        :pswitch_108  #00000005
        :pswitch_ff  #00000006
        :pswitch_f4  #00000007
        :pswitch_da  #00000008
        :pswitch_cd  #00000009
        :pswitch_ab  #0000000a
        :pswitch_a5  #0000000b
        :pswitch_9f  #0000000c
        :pswitch_99  #0000000d
        :pswitch_8e  #0000000e
        :pswitch_88  #0000000f
        :pswitch_81  #00000010
        :pswitch_7b  #00000011
        :pswitch_75  #00000012
        :pswitch_68  #00000013
        :pswitch_5a  #00000014
        :pswitch_4f  #00000015
        :pswitch_47  #00000016
        :pswitch_41  #00000017
        :pswitch_39  #00000018
        :pswitch_33  #00000019
        :pswitch_2c  #0000001a
        :pswitch_21  #0000001b
        :pswitch_14  #0000001c
    .end packed-switch

    :pswitch_data_17a
    .packed-switch 0x0
        :pswitch_37  #00000000
        :pswitch_37  #00000001
        :pswitch_37  #00000002
        :pswitch_37  #00000003
        :pswitch_37  #00000004
        :pswitch_37  #00000005
        :pswitch_37  #00000006
        :pswitch_37  #00000007
        :pswitch_37  #00000008
        :pswitch_37  #00000009
        :pswitch_37  #0000000a
        :pswitch_37  #0000000b
        :pswitch_37  #0000000c
        :pswitch_37  #0000000d
        :pswitch_37  #0000000e
        :pswitch_37  #0000000f
        :pswitch_37  #00000010
        :pswitch_37  #00000011
        :pswitch_37  #00000012
        :pswitch_37  #00000013
        :pswitch_37  #00000014
        :pswitch_37  #00000015
        :pswitch_37  #00000016
        :pswitch_37  #00000017
        :pswitch_37  #00000018
        :pswitch_37  #00000019
        :pswitch_37  #0000001a
        :pswitch_37  #0000001b
        :pswitch_37  #0000001c
    .end packed-switch

    :pswitch_data_1b8
    .packed-switch 0x0
        :pswitch_45  #00000000
        :pswitch_45  #00000001
        :pswitch_45  #00000002
        :pswitch_45  #00000003
        :pswitch_45  #00000004
        :pswitch_45  #00000005
        :pswitch_45  #00000006
        :pswitch_45  #00000007
        :pswitch_45  #00000008
        :pswitch_45  #00000009
    .end packed-switch

    :pswitch_data_1d0
    .packed-switch 0x0
        :pswitch_79  #00000000
        :pswitch_79  #00000001
        :pswitch_79  #00000002
        :pswitch_79  #00000003
        :pswitch_79  #00000004
        :pswitch_79  #00000005
        :pswitch_79  #00000006
        :pswitch_79  #00000007
        :pswitch_79  #00000008
        :pswitch_79  #00000009
        :pswitch_79  #0000000a
        :pswitch_79  #0000000b
        :pswitch_79  #0000000c
        :pswitch_79  #0000000d
        :pswitch_79  #0000000e
        :pswitch_79  #0000000f
    .end packed-switch

    :pswitch_data_1f4
    .packed-switch 0x0
        :pswitch_7f  #00000000
        :pswitch_7f  #00000001
        :pswitch_7f  #00000002
        :pswitch_7f  #00000003
        :pswitch_7f  #00000004
        :pswitch_7f  #00000005
        :pswitch_7f  #00000006
        :pswitch_7f  #00000007
        :pswitch_7f  #00000008
        :pswitch_7f  #00000009
        :pswitch_7f  #0000000a
        :pswitch_7f  #0000000b
        :pswitch_7f  #0000000c
        :pswitch_7f  #0000000d
        :pswitch_7e  #0000000e
        :pswitch_7f  #0000000f
        :pswitch_7f  #00000010
        :pswitch_7e  #00000011
        :pswitch_7f  #00000012
        :pswitch_7f  #00000013
        :pswitch_7f  #00000014
        :pswitch_7f  #00000015
        :pswitch_7f  #00000016
        :pswitch_7f  #00000017
    .end packed-switch

    :pswitch_data_228
    .packed-switch 0x0
        :pswitch_8c  #00000000
        :pswitch_8c  #00000001
        :pswitch_8c  #00000002
        :pswitch_8c  #00000003
        :pswitch_8c  #00000004
        :pswitch_8c  #00000005
        :pswitch_8c  #00000006
    .end packed-switch

    :pswitch_data_23a
    .packed-switch 0x0
        :pswitch_9d  #00000000
        :pswitch_9d  #00000001
        :pswitch_9d  #00000002
        :pswitch_9d  #00000003
        :pswitch_9d  #00000004
        :pswitch_9d  #00000005
        :pswitch_9d  #00000006
        :pswitch_9d  #00000007
        :pswitch_9d  #00000008
        :pswitch_9d  #00000009
        :pswitch_9d  #0000000a
        :pswitch_9d  #0000000b
        :pswitch_9d  #0000000c
        :pswitch_9d  #0000000d
        :pswitch_9d  #0000000e
        :pswitch_9d  #0000000f
        :pswitch_9d  #00000010
        :pswitch_9d  #00000011
        :pswitch_9d  #00000012
        :pswitch_9d  #00000013
        :pswitch_9d  #00000014
        :pswitch_9d  #00000015
        :pswitch_9d  #00000016
        :pswitch_9d  #00000017
        :pswitch_9d  #00000018
        :pswitch_9d  #00000019
        :pswitch_9d  #0000001a
        :pswitch_9d  #0000001b
        :pswitch_9d  #0000001c
        :pswitch_9d  #0000001d
        :pswitch_9d  #0000001e
        :pswitch_9d  #0000001f
        :pswitch_9d  #00000020
        :pswitch_9d  #00000021
        :pswitch_9d  #00000022
        :pswitch_9d  #00000023
        :pswitch_9d  #00000024
        :pswitch_9d  #00000025
        :pswitch_9d  #00000026
        :pswitch_9d  #00000027
        :pswitch_9d  #00000028
        :pswitch_9d  #00000029
        :pswitch_9d  #0000002a
        :pswitch_9d  #0000002b
        :pswitch_9d  #0000002c
        :pswitch_9d  #0000002d
        :pswitch_9d  #0000002e
        :pswitch_9d  #0000002f
        :pswitch_9d  #00000030
        :pswitch_9d  #00000031
        :pswitch_9d  #00000032
        :pswitch_9d  #00000033
        :pswitch_9d  #00000034
        :pswitch_9d  #00000035
        :pswitch_9d  #00000036
        :pswitch_9d  #00000037
        :pswitch_9d  #00000038
        :pswitch_9d  #00000039
        :pswitch_9d  #0000003a
        :pswitch_9d  #0000003b
        :pswitch_9d  #0000003c
        :pswitch_9d  #0000003d
        :pswitch_9d  #0000003e
        :pswitch_9d  #0000003f
        :pswitch_9d  #00000040
        :pswitch_9d  #00000041
        :pswitch_9d  #00000042
        :pswitch_9d  #00000043
        :pswitch_9d  #00000044
        :pswitch_9d  #00000045
        :pswitch_9d  #00000046
        :pswitch_9d  #00000047
        :pswitch_9d  #00000048
        :pswitch_9d  #00000049
        :pswitch_9d  #0000004a
        :pswitch_9d  #0000004b
        :pswitch_9d  #0000004c
        :pswitch_9d  #0000004d
        :pswitch_9d  #0000004e
        :pswitch_9d  #0000004f
        :pswitch_9d  #00000050
        :pswitch_9d  #00000051
        :pswitch_9d  #00000052
        :pswitch_9d  #00000053
        :pswitch_9d  #00000054
        :pswitch_9d  #00000055
        :pswitch_9d  #00000056
        :pswitch_9d  #00000057
        :pswitch_9d  #00000058
        :pswitch_9d  #00000059
        :pswitch_9d  #0000005a
        :pswitch_9d  #0000005b
        :pswitch_9d  #0000005c
        :pswitch_9d  #0000005d
        :pswitch_9d  #0000005e
        :pswitch_9d  #0000005f
        :pswitch_9d  #00000060
        :pswitch_9d  #00000061
        :pswitch_9d  #00000062
        :pswitch_9d  #00000063
        :pswitch_9d  #00000064
        :pswitch_9d  #00000065
        :pswitch_9d  #00000066
        :pswitch_9d  #00000067
        :pswitch_9d  #00000068
        :pswitch_9d  #00000069
        :pswitch_9d  #0000006a
        :pswitch_9d  #0000006b
        :pswitch_9d  #0000006c
        :pswitch_9d  #0000006d
        :pswitch_9d  #0000006e
        :pswitch_9d  #0000006f
        :pswitch_9d  #00000070
        :pswitch_9d  #00000071
        :pswitch_9d  #00000072
        :pswitch_9d  #00000073
        :pswitch_9d  #00000074
        :pswitch_9d  #00000075
        :pswitch_9d  #00000076
        :pswitch_9d  #00000077
        :pswitch_9d  #00000078
        :pswitch_9d  #00000079
        :pswitch_9d  #0000007a
        :pswitch_9d  #0000007b
    .end packed-switch

    :pswitch_data_336
    .packed-switch 0x1
        :pswitch_a3  #00000001
        :pswitch_a3  #00000002
        :pswitch_a3  #00000003
        :pswitch_a3  #00000004
        :pswitch_a3  #00000005
        :pswitch_a3  #00000006
        :pswitch_a3  #00000007
    .end packed-switch

    :pswitch_data_348
    .packed-switch 0x0
        :pswitch_a9  #00000000
        :pswitch_a9  #00000001
        :pswitch_a9  #00000002
        :pswitch_a9  #00000003
        :pswitch_a9  #00000004
        :pswitch_a9  #00000005
        :pswitch_a9  #00000006
        :pswitch_a9  #00000007
        :pswitch_a9  #00000008
        :pswitch_a9  #00000009
        :pswitch_a9  #0000000a
    .end packed-switch

    :pswitch_data_362
    .packed-switch 0x64
        :pswitch_f2  #00000064
        :pswitch_f2  #00000065
        :pswitch_f2  #00000066
        :pswitch_f2  #00000067
        :pswitch_f2  #00000068
        :pswitch_f2  #00000069
        :pswitch_f2  #0000006a
        :pswitch_f2  #0000006b
        :pswitch_f2  #0000006c
        :pswitch_f2  #0000006d
        :pswitch_f2  #0000006e
        :pswitch_f2  #0000006f
        :pswitch_f2  #00000070
        :pswitch_f2  #00000071
        :pswitch_f2  #00000072
    .end packed-switch

    :pswitch_data_384
    .packed-switch 0x0
        :pswitch_10c  #00000000
        :pswitch_10c  #00000001
        :pswitch_10c  #00000002
        :pswitch_10c  #00000003
        :pswitch_10c  #00000004
        :pswitch_10c  #00000005
        :pswitch_10c  #00000006
        :pswitch_10c  #00000007
        :pswitch_10c  #00000008
    .end packed-switch
.end method
