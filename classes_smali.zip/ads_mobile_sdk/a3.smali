.class public final Lads_mobile_sdk/a3;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lnt2;


# instance fields
.field public final a:Ltv2;

.field public final b:Ltv2;

.field public final c:Lnt2;

.field public final synthetic d:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/ah0;Lads_mobile_sdk/ob1;Lads_mobile_sdk/ah0;)V
    .registers 5

    const/4 v0, 0x5

    iput v0, p0, Lads_mobile_sdk/a3;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/a3;->a:Ltv2;

    iput-object p2, p0, Lads_mobile_sdk/a3;->c:Lnt2;

    iput-object p3, p0, Lads_mobile_sdk/a3;->b:Ltv2;

    return-void
.end method

.method public constructor <init>(Lads_mobile_sdk/ob1;Lads_mobile_sdk/ob1;Lads_mobile_sdk/ob1;)V
    .registers 5

    const/4 v0, 0x2

    iput v0, p0, Lads_mobile_sdk/a3;->d:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/a3;->c:Lnt2;

    iput-object p2, p0, Lads_mobile_sdk/a3;->a:Ltv2;

    iput-object p3, p0, Lads_mobile_sdk/a3;->b:Ltv2;

    return-void
.end method

.method public synthetic constructor <init>(Ltv2;Ltv2;Lnt2;I)V
    .registers 5

    iput p4, p0, Lads_mobile_sdk/a3;->d:I

    iput-object p1, p0, Lads_mobile_sdk/a3;->a:Ltv2;

    iput-object p2, p0, Lads_mobile_sdk/a3;->b:Ltv2;

    iput-object p3, p0, Lads_mobile_sdk/a3;->c:Lnt2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 5

    .prologue
    iget v0, p0, Lads_mobile_sdk/a3;->d:I

    iget-object v1, p0, Lads_mobile_sdk/a3;->b:Ltv2;

    iget-object v2, p0, Lads_mobile_sdk/a3;->c:Lnt2;

    iget-object p0, p0, Lads_mobile_sdk/a3;->a:Ltv2;

    packed-switch v0, :pswitch_data_d8

    check-cast p0, Lads_mobile_sdk/ah0;

    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lvy;

    check-cast v2, Lads_mobile_sdk/ob1;

    iget-object v0, v2, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v0, Landroid/content/Context;

    check-cast v1, Lads_mobile_sdk/ah0;

    invoke-virtual {v1}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lads_mobile_sdk/ah3;

    new-instance v2, Lads_mobile_sdk/wi3;

    invoke-direct {v2, p0, v0, v1}, Lads_mobile_sdk/wi3;-><init>(Lvy;Landroid/content/Context;Lads_mobile_sdk/ah3;)V

    return-object v2

    :pswitch_27  #0x4
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/a2;

    invoke-interface {v1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/xv;

    check-cast v2, Lads_mobile_sdk/ef2;

    invoke-virtual {v2}, Lads_mobile_sdk/ef2;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lads_mobile_sdk/tv2;

    new-instance v2, Lads_mobile_sdk/uv2;

    invoke-direct {v2, p0, v0, v1}, Lads_mobile_sdk/uv2;-><init>(Lads_mobile_sdk/a2;Lads_mobile_sdk/xv;Lads_mobile_sdk/tv2;)V

    return-object v2

    :pswitch_41  #0x3
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/ux2;

    invoke-interface {v1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/oo3;

    check-cast v2, Lads_mobile_sdk/m;

    invoke-virtual {v2}, Lads_mobile_sdk/m;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lht2;

    new-instance v2, Lads_mobile_sdk/g02;

    invoke-direct {v2, p0, v0, v1}, Lads_mobile_sdk/g02;-><init>(Lads_mobile_sdk/ux2;Lads_mobile_sdk/oo3;Lht2;)V

    return-object v2

    :pswitch_5b  #0x2
    check-cast v2, Lads_mobile_sdk/ob1;

    iget-object v0, v2, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v0, Ljava/util/Optional;

    check-cast p0, Lads_mobile_sdk/ob1;

    iget-object p0, p0, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast p0, Ljava/util/Optional;

    check-cast v1, Lads_mobile_sdk/ob1;

    iget-object v1, v1, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v1, Ljava/util/Optional;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v2, Lads_mobile_sdk/kh3;

    new-instance v3, Lads_mobile_sdk/eq2;

    invoke-direct {v3}, Lads_mobile_sdk/eq2;-><init>()V

    invoke-static {v0, v3}, Lw53;->H(Ljava/util/Optional;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/eq2;

    new-instance v3, Lads_mobile_sdk/ih1;

    invoke-direct {v3}, Lads_mobile_sdk/ih1;-><init>()V

    invoke-static {p0, v3}, Lw53;->H(Ljava/util/Optional;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/ih1;

    new-instance v3, Lads_mobile_sdk/dt2;

    invoke-direct {v3}, Lads_mobile_sdk/dt2;-><init>()V

    invoke-static {v1, v3}, Lw53;->H(Ljava/util/Optional;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lads_mobile_sdk/dt2;

    new-instance v3, Lads_mobile_sdk/s8;

    invoke-direct {v3}, Lads_mobile_sdk/s8;-><init>()V

    invoke-direct {v2, v0, p0, v1, v3}, Lads_mobile_sdk/kh3;-><init>(Lads_mobile_sdk/eq2;Lads_mobile_sdk/ih1;Lads_mobile_sdk/dt2;Lads_mobile_sdk/s8;)V

    return-object v2

    :pswitch_a2  #0x1
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/ux2;

    invoke-interface {v1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/oo3;

    check-cast v2, Lads_mobile_sdk/m;

    invoke-virtual {v2}, Lads_mobile_sdk/m;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lht2;

    new-instance v2, Lads_mobile_sdk/a02;

    invoke-direct {v2, p0, v0, v1}, Lads_mobile_sdk/a02;-><init>(Lads_mobile_sdk/ux2;Lads_mobile_sdk/oo3;Lht2;)V

    return-object v2

    :pswitch_bc  #0x0
    check-cast p0, Lads_mobile_sdk/ah0;

    invoke-virtual {p0}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lvy;

    check-cast v1, Lads_mobile_sdk/fn1;

    invoke-virtual {v1}, Lads_mobile_sdk/fn1;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map;

    check-cast v2, Lads_mobile_sdk/ob1;

    iget-object v1, v2, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/a2;

    new-instance v2, Lads_mobile_sdk/z2;

    invoke-direct {v2, p0, v0, v1}, Lads_mobile_sdk/z2;-><init>(Lvy;Ljava/util/Map;Lads_mobile_sdk/a2;)V

    return-object v2

    :pswitch_data_d8
    .packed-switch 0x0
        :pswitch_bc  #00000000
        :pswitch_a2  #00000001
        :pswitch_5b  #00000002
        :pswitch_41  #00000003
        :pswitch_27  #00000004
    .end packed-switch
.end method
