.class public final Lads_mobile_sdk/by0;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public a:I

.field public final synthetic b:Lads_mobile_sdk/cy0;

.field public final synthetic t:I


# direct methods
.method public synthetic constructor <init>(Lads_mobile_sdk/cy0;Lvx;I)V
    .registers 4

    iput p3, p0, Lads_mobile_sdk/by0;->t:I

    iput-object p1, p0, Lads_mobile_sdk/by0;->b:Lads_mobile_sdk/cy0;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 4

    .prologue
    iget p2, p0, Lads_mobile_sdk/by0;->t:I

    iget-object p0, p0, Lads_mobile_sdk/by0;->b:Lads_mobile_sdk/cy0;

    packed-switch p2, :pswitch_data_40

    new-instance p2, Lads_mobile_sdk/by0;

    const/4 v0, 0x7

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/by0;-><init>(Lads_mobile_sdk/cy0;Lvx;I)V

    return-object p2

    :pswitch_e  #0x6
    new-instance p2, Lads_mobile_sdk/by0;

    const/4 v0, 0x6

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/by0;-><init>(Lads_mobile_sdk/cy0;Lvx;I)V

    return-object p2

    :pswitch_15  #0x5
    new-instance p2, Lads_mobile_sdk/by0;

    const/4 v0, 0x5

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/by0;-><init>(Lads_mobile_sdk/cy0;Lvx;I)V

    return-object p2

    :pswitch_1c  #0x4
    new-instance p2, Lads_mobile_sdk/by0;

    const/4 v0, 0x4

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/by0;-><init>(Lads_mobile_sdk/cy0;Lvx;I)V

    return-object p2

    :pswitch_23  #0x3
    new-instance p2, Lads_mobile_sdk/by0;

    const/4 v0, 0x3

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/by0;-><init>(Lads_mobile_sdk/cy0;Lvx;I)V

    return-object p2

    :pswitch_2a  #0x2
    new-instance p2, Lads_mobile_sdk/by0;

    const/4 v0, 0x2

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/by0;-><init>(Lads_mobile_sdk/cy0;Lvx;I)V

    return-object p2

    :pswitch_31  #0x1
    new-instance p2, Lads_mobile_sdk/by0;

    const/4 v0, 0x1

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/by0;-><init>(Lads_mobile_sdk/cy0;Lvx;I)V

    return-object p2

    :pswitch_38  #0x0
    new-instance p2, Lads_mobile_sdk/by0;

    const/4 v0, 0x0

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/by0;-><init>(Lads_mobile_sdk/cy0;Lvx;I)V

    return-object p2

    nop

    :pswitch_data_40
    .packed-switch 0x0
        :pswitch_38  #00000000
        :pswitch_31  #00000001
        :pswitch_2a  #00000002
        :pswitch_23  #00000003
        :pswitch_1c  #00000004
        :pswitch_15  #00000005
        :pswitch_e  #00000006
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .prologue
    iget v0, p0, Lads_mobile_sdk/by0;->t:I

    sget-object v1, Lrg2;->a:Lrg2;

    iget-object p0, p0, Lads_mobile_sdk/by0;->b:Lads_mobile_sdk/cy0;

    packed-switch v0, :pswitch_data_82

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/by0;

    const/4 v0, 0x7

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/by0;-><init>(Lads_mobile_sdk/cy0;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/by0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_18  #0x6
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/by0;

    const/4 v0, 0x6

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/by0;-><init>(Lads_mobile_sdk/cy0;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/by0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_27  #0x5
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/by0;

    const/4 v0, 0x5

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/by0;-><init>(Lads_mobile_sdk/cy0;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/by0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_36  #0x4
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/by0;

    const/4 v0, 0x4

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/by0;-><init>(Lads_mobile_sdk/cy0;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/by0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_45  #0x3
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/by0;

    const/4 v0, 0x3

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/by0;-><init>(Lads_mobile_sdk/cy0;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/by0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_54  #0x2
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/by0;

    const/4 v0, 0x2

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/by0;-><init>(Lads_mobile_sdk/cy0;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/by0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_63  #0x1
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/by0;

    const/4 v0, 0x1

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/by0;-><init>(Lads_mobile_sdk/cy0;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/by0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_72  #0x0
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/by0;

    const/4 v0, 0x0

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/by0;-><init>(Lads_mobile_sdk/cy0;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/by0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_82
    .packed-switch 0x0
        :pswitch_72  #00000000
        :pswitch_63  #00000001
        :pswitch_54  #00000002
        :pswitch_45  #00000003
        :pswitch_36  #00000004
        :pswitch_27  #00000005
        :pswitch_18  #00000006
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7

    .prologue
    iget v0, p0, Lads_mobile_sdk/by0;->t:I

    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    const/4 v2, 0x1

    const/4 v3, 0x0

    packed-switch v0, :pswitch_data_12e

    sget-object v0, Lwy;->a:Lwy;

    iget v4, p0, Lads_mobile_sdk/by0;->a:I

    if-eqz v4, :cond_19

    if-ne v4, v2, :cond_15

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_2c

    :cond_15
    invoke-static {v1}, Lz6;->w(Ljava/lang/String;)V

    goto :goto_2e

    :cond_19
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/by0;->b:Lads_mobile_sdk/cy0;

    iget-object p1, p1, Lads_mobile_sdk/cy0;->p:Lc73;

    if-eqz p1, :cond_2c

    iput v2, p0, Lads_mobile_sdk/by0;->a:I

    invoke-interface {p1, p0}, Lc73;->a(Lvx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v0, :cond_2c

    move-object v3, v0

    goto :goto_2e

    :cond_2c
    :goto_2c
    sget-object v3, Lrg2;->a:Lrg2;

    :goto_2e
    return-object v3

    :pswitch_2f  #0x6
    sget-object v0, Lwy;->a:Lwy;

    iget v4, p0, Lads_mobile_sdk/by0;->a:I

    if-eqz v4, :cond_3f

    if-ne v4, v2, :cond_3b

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_4e

    :cond_3b
    invoke-static {v1}, Lz6;->w(Ljava/lang/String;)V

    goto :goto_50

    :cond_3f
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/by0;->b:Lads_mobile_sdk/cy0;

    iput v2, p0, Lads_mobile_sdk/by0;->a:I

    invoke-virtual {p1, p0}, Lads_mobile_sdk/cy0;->a(Lvx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v0, :cond_4e

    move-object v3, v0

    goto :goto_50

    :cond_4e
    :goto_4e
    sget-object v3, Lrg2;->a:Lrg2;

    :goto_50
    return-object v3

    :pswitch_51  #0x5
    sget-object v0, Lwy;->a:Lwy;

    iget v4, p0, Lads_mobile_sdk/by0;->a:I

    if-eqz v4, :cond_61

    if-ne v4, v2, :cond_5d

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_72

    :cond_5d
    invoke-static {v1}, Lz6;->w(Ljava/lang/String;)V

    goto :goto_74

    :cond_61
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/by0;->b:Lads_mobile_sdk/cy0;

    iput v2, p0, Lads_mobile_sdk/by0;->a:I

    const-string v1, "(function() {  var height = -1;  if (document.body) {    height = document.body.offsetHeight;  } else if (document.documentElement) {    height = document.documentElement.offsetHeight;  }  var url = \'gmsg://mobileads.google.com/contentHeight?\';  url += \'height=\' + height;  try {    window.googleAdsJsInterface.notify(url);  } catch (e) {    var frame = document.getElementById(\'afma-notify-fluid\');    if (!frame) {      frame = document.createElement(\'IFRAME\');      frame.id = \'afma-notify-fluid\';      frame.style.display = \'none\';      var body = document.body || document.documentElement;      body.appendChild(frame);    }    frame.src = url;  }})();"

    invoke-virtual {p1, v1, p0}, Lads_mobile_sdk/cy0;->a(Ljava/lang/String;Lvx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v0, :cond_72

    move-object v3, v0

    goto :goto_74

    :cond_72
    :goto_72
    sget-object v3, Lrg2;->a:Lrg2;

    :goto_74
    return-object v3

    :pswitch_75  #0x4
    sget-object v0, Lwy;->a:Lwy;

    iget v4, p0, Lads_mobile_sdk/by0;->a:I

    if-eqz v4, :cond_85

    if-ne v4, v2, :cond_81

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_94

    :cond_81
    invoke-static {v1}, Lz6;->w(Ljava/lang/String;)V

    goto :goto_96

    :cond_85
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/by0;->b:Lads_mobile_sdk/cy0;

    iput v2, p0, Lads_mobile_sdk/by0;->a:I

    invoke-virtual {p1, p0}, Lads_mobile_sdk/cy0;->a(Lvx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v0, :cond_94

    move-object v3, v0

    goto :goto_96

    :cond_94
    :goto_94
    sget-object v3, Lrg2;->a:Lrg2;

    :goto_96
    return-object v3

    :pswitch_97  #0x3
    sget-object v0, Lwy;->a:Lwy;

    iget v4, p0, Lads_mobile_sdk/by0;->a:I

    if-eqz v4, :cond_a7

    if-ne v4, v2, :cond_a3

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_b6

    :cond_a3
    invoke-static {v1}, Lz6;->w(Ljava/lang/String;)V

    goto :goto_b8

    :cond_a7
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/by0;->b:Lads_mobile_sdk/cy0;

    iput v2, p0, Lads_mobile_sdk/by0;->a:I

    invoke-virtual {p1, p0}, Lads_mobile_sdk/cy0;->a(Lvx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v0, :cond_b6

    move-object v3, v0

    goto :goto_b8

    :cond_b6
    :goto_b6
    sget-object v3, Lrg2;->a:Lrg2;

    :goto_b8
    return-object v3

    :pswitch_b9  #0x2
    sget-object v0, Lwy;->a:Lwy;

    iget v4, p0, Lads_mobile_sdk/by0;->a:I

    if-eqz v4, :cond_c9

    if-ne v4, v2, :cond_c5

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_d8

    :cond_c5
    invoke-static {v1}, Lz6;->w(Ljava/lang/String;)V

    goto :goto_da

    :cond_c9
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/by0;->b:Lads_mobile_sdk/cy0;

    iput v2, p0, Lads_mobile_sdk/by0;->a:I

    invoke-virtual {p1, p0}, Lads_mobile_sdk/cy0;->a(Lvx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v0, :cond_d8

    move-object v3, v0

    goto :goto_da

    :cond_d8
    :goto_d8
    sget-object v3, Lrg2;->a:Lrg2;

    :goto_da
    return-object v3

    :pswitch_db  #0x1
    sget-object v0, Lwy;->a:Lwy;

    iget v4, p0, Lads_mobile_sdk/by0;->a:I

    if-eqz v4, :cond_eb

    if-ne v4, v2, :cond_e7

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_102

    :cond_e7
    invoke-static {v1}, Lz6;->w(Ljava/lang/String;)V

    goto :goto_104

    :cond_eb
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/by0;->b:Lads_mobile_sdk/cy0;

    iget-object p1, p1, Lads_mobile_sdk/cy0;->d:Lads_mobile_sdk/q70;

    if-eqz p1, :cond_104

    iput v2, p0, Lads_mobile_sdk/by0;->a:I

    const-string v1, "action"

    const-string v3, "make_wv"

    invoke-virtual {p1, v1, v3, v2, p0}, Lads_mobile_sdk/q70;->a(Ljava/lang/String;Ljava/lang/String;ZLwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v0, :cond_102

    move-object v3, v0

    goto :goto_104

    :cond_102
    :goto_102
    sget-object v3, Lrg2;->a:Lrg2;

    :cond_104
    :goto_104
    return-object v3

    :pswitch_105  #0x0
    sget-object v0, Lwy;->a:Lwy;

    iget v4, p0, Lads_mobile_sdk/by0;->a:I

    if-eqz v4, :cond_115

    if-ne v4, v2, :cond_111

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_12a

    :cond_111
    invoke-static {v1}, Lz6;->w(Ljava/lang/String;)V

    goto :goto_12d

    :cond_115
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/by0;->b:Lads_mobile_sdk/cy0;

    iget-object p1, p1, Lads_mobile_sdk/cy0;->d:Lads_mobile_sdk/q70;

    if-eqz p1, :cond_12d

    iput v2, p0, Lads_mobile_sdk/by0;->a:I

    const-string v1, "native:view_create"

    invoke-static {p1, v1, p0}, Lads_mobile_sdk/q70;->a(Lads_mobile_sdk/q70;Ljava/lang/String;Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_12a

    move-object v3, v0

    goto :goto_12d

    :cond_12a
    :goto_12a
    move-object v3, p1

    check-cast v3, Lads_mobile_sdk/wf3;

    :cond_12d
    :goto_12d
    return-object v3

    :pswitch_data_12e
    .packed-switch 0x0
        :pswitch_105  #00000000
        :pswitch_db  #00000001
        :pswitch_b9  #00000002
        :pswitch_97  #00000003
        :pswitch_75  #00000004
        :pswitch_51  #00000005
        :pswitch_2f  #00000006
    .end packed-switch
.end method
