.class public final Lads_mobile_sdk/ce0;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lb73;


# instance fields
.field public final synthetic a:I

.field public b:Lads_mobile_sdk/ob1;

.field public c:Ltv2;

.field public d:Ltv2;

.field public e:Lads_mobile_sdk/ob1;

.field public f:Lads_mobile_sdk/ob1;

.field public g:Lads_mobile_sdk/n90;

.field public h:Ltv2;

.field public j:Ltv2;


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    iput p1, p0, Lads_mobile_sdk/ce0;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Lads_mobile_sdk/j71;
    .registers 2

    .prologue
    iget v0, p0, Lads_mobile_sdk/ce0;->a:I

    packed-switch v0, :pswitch_data_18

    iget-object p0, p0, Lads_mobile_sdk/ce0;->h:Ltv2;

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/j71;

    return-object p0

    :pswitch_e  #0x0
    iget-object p0, p0, Lads_mobile_sdk/ce0;->h:Ltv2;

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/j71;

    return-object p0

    nop

    :pswitch_data_18
    .packed-switch 0x0
        :pswitch_e  #00000000
    .end packed-switch
.end method

.method public final b()Lads_mobile_sdk/on2;
    .registers 2

    .prologue
    iget v0, p0, Lads_mobile_sdk/ce0;->a:I

    packed-switch v0, :pswitch_data_18

    iget-object p0, p0, Lads_mobile_sdk/ce0;->j:Ltv2;

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/jp2;

    return-object p0

    :pswitch_e  #0x0
    iget-object p0, p0, Lads_mobile_sdk/ce0;->j:Ltv2;

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/on2;

    return-object p0

    nop

    :pswitch_data_18
    .packed-switch 0x0
        :pswitch_e  #00000000
    .end packed-switch
.end method
