.class public final Lads_mobile_sdk/cg2;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpv2;


# instance fields
.field public final synthetic a:Lus1;

.field public final synthetic b:I


# direct methods
.method public synthetic constructor <init>(Lus1;I)V
    .registers 3

    iput p2, p0, Lads_mobile_sdk/cg2;->b:I

    iput-object p1, p0, Lads_mobile_sdk/cg2;->a:Lus1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Lc03;Lwx;)Ljava/lang/Object;
    .registers 7

    .prologue
    instance-of v0, p2, Lads_mobile_sdk/bg2;

    if-eqz v0, :cond_13

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/bg2;

    iget v1, v0, Lads_mobile_sdk/bg2;->c:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/bg2;->c:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/bg2;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/bg2;-><init>(Lads_mobile_sdk/cg2;Lwx;)V

    :goto_18
    iget-object p2, v0, Lads_mobile_sdk/bg2;->a:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/bg2;->c:I

    const/4 v2, 0x1

    if-eqz v1, :cond_2c

    if-ne v1, v2, :cond_25

    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_41

    :cond_25
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0

    :cond_2c
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    new-instance p2, Lads_mobile_sdk/dz1;

    iget-object p0, p0, Lads_mobile_sdk/cg2;->a:Lus1;

    invoke-direct {p2, p0}, Lads_mobile_sdk/dz1;-><init>(Ljava/util/Map;)V

    iput v2, v0, Lads_mobile_sdk/bg2;->c:I

    invoke-virtual {p2, p1, v0}, Lads_mobile_sdk/dz1;->a(Lg33;Lwx;)Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lwy;->a:Lwy;

    if-ne p0, p1, :cond_41

    return-object p1

    :cond_41
    :goto_41
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method

.method public a(Lg33;Lwx;)Ljava/lang/Object;
    .registers 7

    .prologue
    instance-of v0, p2, Lads_mobile_sdk/xf2;

    if-eqz v0, :cond_13

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/xf2;

    iget v1, v0, Lads_mobile_sdk/xf2;->c:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/xf2;->c:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/xf2;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/xf2;-><init>(Lads_mobile_sdk/cg2;Lwx;)V

    :goto_18
    iget-object p2, v0, Lads_mobile_sdk/xf2;->a:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/xf2;->c:I

    const/4 v2, 0x1

    if-eqz v1, :cond_2c

    if-ne v1, v2, :cond_25

    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_41

    :cond_25
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0

    :cond_2c
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    new-instance p2, Lads_mobile_sdk/dz1;

    iget-object p0, p0, Lads_mobile_sdk/cg2;->a:Lus1;

    invoke-direct {p2, p0}, Lads_mobile_sdk/dz1;-><init>(Ljava/util/Map;)V

    iput v2, v0, Lads_mobile_sdk/xf2;->c:I

    invoke-virtual {p2, p1, v0}, Lads_mobile_sdk/dz1;->a(Lg33;Lwx;)Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lwy;->a:Lwy;

    if-ne p0, p1, :cond_41

    return-object p1

    :cond_41
    :goto_41
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method

.method public final bridge synthetic a(Ljava/lang/Object;Lads_mobile_sdk/rk1;)Ljava/lang/Object;
    .registers 4

    .prologue
    iget v0, p0, Lads_mobile_sdk/cg2;->b:I

    packed-switch v0, :pswitch_data_14

    check-cast p1, Lg33;

    invoke-virtual {p0, p1, p2}, Lads_mobile_sdk/cg2;->a(Lg33;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_c  #0x0
    check-cast p1, Lc03;

    invoke-virtual {p0, p1, p2}, Lads_mobile_sdk/cg2;->a(Lc03;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_14
    .packed-switch 0x0
        :pswitch_c  #00000000
    .end packed-switch
.end method
