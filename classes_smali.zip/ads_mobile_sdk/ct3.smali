.class public final synthetic Lads_mobile_sdk/ct3;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ljava/util/function/Supplier;


# static fields
.field public static final synthetic b:Lads_mobile_sdk/ct3;

.field public static final synthetic c:Lads_mobile_sdk/ct3;


# instance fields
.field public final synthetic a:I


# direct methods
.method public static synthetic constructor <clinit>()V
    .registers 2

    new-instance v0, Lads_mobile_sdk/ct3;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lads_mobile_sdk/ct3;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/ct3;->c:Lads_mobile_sdk/ct3;

    new-instance v0, Lads_mobile_sdk/ct3;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lads_mobile_sdk/ct3;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/ct3;->b:Lads_mobile_sdk/ct3;

    return-void
.end method

.method public synthetic constructor <init>(I)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lads_mobile_sdk/ct3;->a:I

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 1

    .prologue
    iget p0, p0, Lads_mobile_sdk/ct3;->a:I

    if-eqz p0, :cond_a

    const/4 p0, 0x0

    invoke-static {p0}, Lads_mobile_sdk/st3;->a(Ljava/lang/Object;)Lads_mobile_sdk/st3;

    move-result-object p0

    return-object p0

    :cond_a
    new-instance p0, Ldy2;

    invoke-direct {p0}, Ljava/lang/Exception;-><init>()V

    return-object p0
.end method
