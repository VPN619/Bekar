.class public final Lads_mobile_sdk/ev2;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:I

.field public final b:I

.field public final c:I

.field public final d:I

.field public final e:Z

.field public final f:Lads_mobile_sdk/av;

.field public final g:Landroid/graphics/Rect;

.field public final h:Ldj1;

.field public final i:Ldj1;


# direct methods
.method public constructor <init>(IIIIZLads_mobile_sdk/av;Landroid/graphics/Rect;Ldj1;Ldj1;)V
    .registers 10

    invoke-virtual {p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lads_mobile_sdk/ev2;->a:I

    iput p2, p0, Lads_mobile_sdk/ev2;->b:I

    iput p3, p0, Lads_mobile_sdk/ev2;->c:I

    iput p4, p0, Lads_mobile_sdk/ev2;->d:I

    iput-boolean p5, p0, Lads_mobile_sdk/ev2;->e:Z

    iput-object p6, p0, Lads_mobile_sdk/ev2;->f:Lads_mobile_sdk/av;

    iput-object p7, p0, Lads_mobile_sdk/ev2;->g:Landroid/graphics/Rect;

    iput-object p8, p0, Lads_mobile_sdk/ev2;->h:Ldj1;

    iput-object p9, p0, Lads_mobile_sdk/ev2;->i:Ldj1;

    return-void
.end method


# virtual methods
.method public final a()Landroid/graphics/Point;
    .registers 8

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/ev2;->g:Landroid/graphics/Rect;

    iget v1, v0, Landroid/graphics/Rect;->left:I

    iget v2, p0, Lads_mobile_sdk/ev2;->c:I

    add-int/2addr v1, v2

    iget v0, v0, Landroid/graphics/Rect;->top:I

    iget v2, p0, Lads_mobile_sdk/ev2;->d:I

    add-int/2addr v0, v2

    iget-boolean v2, p0, Lads_mobile_sdk/ev2;->e:Z

    if-nez v2, :cond_44

    iget-object v2, p0, Lads_mobile_sdk/ev2;->i:Ldj1;

    iget-object v3, v2, Ldj1;->a:Ljava/lang/Object;

    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    move-result v3

    iget-object v2, v2, Ldj1;->b:Ljava/lang/Object;

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    iget-object v4, p0, Lads_mobile_sdk/ev2;->h:Ldj1;

    iget-object v4, v4, Ldj1;->a:Ljava/lang/Object;

    check-cast v4, Ljava/lang/Number;

    invoke-virtual {v4}, Ljava/lang/Number;->intValue()I

    move-result v4

    if-gez v1, :cond_30

    const/4 v1, 0x0

    goto :goto_38

    :cond_30
    iget v5, p0, Lads_mobile_sdk/ev2;->a:I

    add-int v6, v1, v5

    if-le v6, v4, :cond_38

    sub-int v1, v4, v5

    :cond_38
    :goto_38
    if-ge v0, v3, :cond_3c

    move v0, v3

    goto :goto_44

    :cond_3c
    iget p0, p0, Lads_mobile_sdk/ev2;->b:I

    add-int v3, v0, p0

    if-le v3, v2, :cond_44

    sub-int v0, v2, p0

    :cond_44
    :goto_44
    new-instance p0, Landroid/graphics/Point;

    invoke-direct {p0, v1, v0}, Landroid/graphics/Point;-><init>(II)V

    return-object p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    .prologue
    if-ne p0, p1, :cond_3

    goto :goto_56

    :cond_3
    instance-of v0, p1, Lads_mobile_sdk/ev2;

    if-nez v0, :cond_8

    goto :goto_54

    :cond_8
    check-cast p1, Lads_mobile_sdk/ev2;

    iget v0, p0, Lads_mobile_sdk/ev2;->a:I

    iget v1, p1, Lads_mobile_sdk/ev2;->a:I

    if-eq v0, v1, :cond_11

    goto :goto_54

    :cond_11
    iget v0, p0, Lads_mobile_sdk/ev2;->b:I

    iget v1, p1, Lads_mobile_sdk/ev2;->b:I

    if-eq v0, v1, :cond_18

    goto :goto_54

    :cond_18
    iget v0, p0, Lads_mobile_sdk/ev2;->c:I

    iget v1, p1, Lads_mobile_sdk/ev2;->c:I

    if-eq v0, v1, :cond_1f

    goto :goto_54

    :cond_1f
    iget v0, p0, Lads_mobile_sdk/ev2;->d:I

    iget v1, p1, Lads_mobile_sdk/ev2;->d:I

    if-eq v0, v1, :cond_26

    goto :goto_54

    :cond_26
    iget-boolean v0, p0, Lads_mobile_sdk/ev2;->e:Z

    iget-boolean v1, p1, Lads_mobile_sdk/ev2;->e:Z

    if-eq v0, v1, :cond_2d

    goto :goto_54

    :cond_2d
    iget-object v0, p0, Lads_mobile_sdk/ev2;->f:Lads_mobile_sdk/av;

    iget-object v1, p1, Lads_mobile_sdk/ev2;->f:Lads_mobile_sdk/av;

    if-eq v0, v1, :cond_34

    goto :goto_54

    :cond_34
    iget-object v0, p0, Lads_mobile_sdk/ev2;->g:Landroid/graphics/Rect;

    iget-object v1, p1, Lads_mobile_sdk/ev2;->g:Landroid/graphics/Rect;

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3f

    goto :goto_54

    :cond_3f
    iget-object v0, p0, Lads_mobile_sdk/ev2;->h:Ldj1;

    iget-object v1, p1, Lads_mobile_sdk/ev2;->h:Ldj1;

    invoke-virtual {v0, v1}, Ldj1;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_4a

    goto :goto_54

    :cond_4a
    iget-object p0, p0, Lads_mobile_sdk/ev2;->i:Ldj1;

    iget-object p1, p1, Lads_mobile_sdk/ev2;->i:Ldj1;

    invoke-virtual {p0, p1}, Ldj1;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_56

    :goto_54
    const/4 p0, 0x0

    return p0

    :cond_56
    :goto_56
    const/4 p0, 0x1

    return p0
.end method

.method public final hashCode()I
    .registers 3

    .prologue
    iget v0, p0, Lads_mobile_sdk/ev2;->a:I

    invoke-static {v0}, Ljava/lang/Integer;->hashCode(I)I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, Lads_mobile_sdk/ev2;->b:I

    invoke-static {v1, v0}, Lsz;->c(II)I

    move-result v0

    iget v1, p0, Lads_mobile_sdk/ev2;->c:I

    invoke-static {v1, v0}, Lsz;->c(II)I

    move-result v0

    iget v1, p0, Lads_mobile_sdk/ev2;->d:I

    invoke-static {v1, v0}, Lsz;->c(II)I

    move-result v0

    iget-boolean v1, p0, Lads_mobile_sdk/ev2;->e:Z

    if-eqz v1, :cond_1f

    const/4 v1, 0x1

    :cond_1f
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, Lads_mobile_sdk/ev2;->f:Lads_mobile_sdk/av;

    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    mul-int/lit8 v1, v1, 0x1f

    iget-object v0, p0, Lads_mobile_sdk/ev2;->g:Landroid/graphics/Rect;

    invoke-virtual {v0}, Landroid/graphics/Rect;->hashCode()I

    move-result v0

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-object v1, p0, Lads_mobile_sdk/ev2;->h:Ldj1;

    invoke-virtual {v1}, Ldj1;->hashCode()I

    move-result v1

    add-int/2addr v1, v0

    mul-int/lit8 v1, v1, 0x1f

    iget-object p0, p0, Lads_mobile_sdk/ev2;->i:Ldj1;

    invoke-virtual {p0}, Ldj1;->hashCode()I

    move-result p0

    add-int/2addr p0, v1

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 6

    const-string v0, ", heightDips="

    const-string v1, ", offsetXDips="

    iget v2, p0, Lads_mobile_sdk/ev2;->a:I

    iget v3, p0, Lads_mobile_sdk/ev2;->b:I

    const-string v4, "ResizeParams(widthDips="

    invoke-static {v2, v3, v4, v0, v1}, Lrt2;->l(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p0, Lads_mobile_sdk/ev2;->c:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", offsetYDips="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lads_mobile_sdk/ev2;->d:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", allowOffScreen="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, Lads_mobile_sdk/ev2;->e:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, ", closeButtonPosition="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lads_mobile_sdk/ev2;->f:Lads_mobile_sdk/av;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", originalAdPosition="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lads_mobile_sdk/ev2;->g:Landroid/graphics/Rect;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", activityWindowDimensions="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lads_mobile_sdk/ev2;->h:Ldj1;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", activityVerticalLimits="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, Lads_mobile_sdk/ev2;->i:Ldj1;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
