.class public final Lads_mobile_sdk/bm0;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lc23;


# instance fields
.field public final a:Ljava/util/concurrent/ExecutorService;

.field public final b:Lv03;

.field public final c:Lv03;

.field public final d:Lads_mobile_sdk/ia3;

.field public final e:Lv03;

.field public final f:Lads_mobile_sdk/n90;

.field public final g:Lads_mobile_sdk/l7;


# direct methods
.method public constructor <init>(Ljava/util/concurrent/ExecutorService;Lv03;Lv03;Lads_mobile_sdk/ia3;Lv03;Lads_mobile_sdk/n90;Lads_mobile_sdk/l7;)V
    .registers 8

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/bm0;->a:Ljava/util/concurrent/ExecutorService;

    iput-object p2, p0, Lads_mobile_sdk/bm0;->b:Lv03;

    iput-object p3, p0, Lads_mobile_sdk/bm0;->c:Lv03;

    iput-object p4, p0, Lads_mobile_sdk/bm0;->d:Lads_mobile_sdk/ia3;

    iput-object p5, p0, Lads_mobile_sdk/bm0;->e:Lv03;

    iput-object p6, p0, Lads_mobile_sdk/bm0;->f:Lads_mobile_sdk/n90;

    iput-object p7, p0, Lads_mobile_sdk/bm0;->g:Lads_mobile_sdk/l7;

    return-void
.end method


# virtual methods
.method public final a()Ld31;
    .registers 3

    new-instance v0, Lyp0;

    const/4 v1, 0x6

    invoke-direct {v0, v1, p0}, Lyp0;-><init>(ILjava/lang/Object;)V

    iget-object p0, p0, Lads_mobile_sdk/bm0;->a:Ljava/util/concurrent/ExecutorService;

    invoke-static {p0, v0}, Lpy2;->N(Ljava/util/concurrent/Executor;Ljava/util/concurrent/Callable;)Lpd2;

    move-result-object p0

    return-object p0
.end method

.method public final a(Landroid/content/Context;)Ld31;
    .registers 4

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/bm0;->f:Lads_mobile_sdk/n90;

    invoke-virtual {v0}, Lads_mobile_sdk/n90;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lvh2;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, v0, Lvh2;->a:Ljava/lang/Object;

    iget-object p0, p0, Lads_mobile_sdk/bm0;->d:Lads_mobile_sdk/ia3;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance p1, Ljava/util/HashMap;

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    iget-object p0, p0, Lads_mobile_sdk/ia3;->a:Ljava/util/Set;

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_1d
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_2d

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lku2;

    invoke-interface {v1, p1}, Lku2;->a(Ljava/util/HashMap;)V

    goto :goto_1d

    :cond_2d
    iput-object p1, v0, Lvh2;->g:Ljava/lang/Object;

    invoke-static {}, Lads_mobile_sdk/pd;->w()Lwy2;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p0, v0, Lvh2;->h:Ljava/lang/Object;

    sget-object p0, Lads_mobile_sdk/ga3;->a:Lads_mobile_sdk/ga3;

    iput-object p0, v0, Lvh2;->i:Ljava/lang/Object;

    invoke-virtual {v0}, Lvh2;->a()Lads_mobile_sdk/s90;

    move-result-object p0

    iget-object p0, p0, Lads_mobile_sdk/s90;->B:Ltv2;

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/j63;

    invoke-virtual {p0}, Lads_mobile_sdk/j63;->b()Ld31;

    move-result-object p0

    return-object p0
.end method

.method public final a(Landroid/content/Context;Ljava/lang/String;Landroid/view/View;Landroid/app/Activity;)Ld31;
    .registers 6

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/bm0;->f:Lads_mobile_sdk/n90;

    invoke-virtual {v0}, Lads_mobile_sdk/n90;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lvh2;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, v0, Lvh2;->a:Ljava/lang/Object;

    iput-object p3, v0, Lvh2;->d:Ljava/lang/Object;

    iput-object p4, v0, Lvh2;->e:Ljava/lang/Object;

    iget-object p4, p0, Lads_mobile_sdk/bm0;->g:Lads_mobile_sdk/l7;

    invoke-virtual {p4}, Lads_mobile_sdk/l7;->y()Z

    move-result p4

    if-eqz p4, :cond_1a

    goto :goto_1c

    :cond_1a
    const-string p2, ""

    :goto_1c
    iput-object p2, v0, Lvh2;->f:Ljava/lang/Object;

    iget-object p0, p0, Lads_mobile_sdk/bm0;->d:Lads_mobile_sdk/ia3;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance p2, Ljava/util/HashMap;

    invoke-direct {p2}, Ljava/util/HashMap;-><init>()V

    iget-object p0, p0, Lads_mobile_sdk/ia3;->a:Ljava/util/Set;

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_2e
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p4

    if-eqz p4, :cond_3e

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p4

    check-cast p4, Lku2;

    invoke-interface {p4, p2, p1, p3}, Lku2;->a(Ljava/util/HashMap;Landroid/content/Context;Landroid/view/View;)V

    goto :goto_2e

    :cond_3e
    iput-object p2, v0, Lvh2;->g:Ljava/lang/Object;

    invoke-static {}, Lads_mobile_sdk/pd;->w()Lwy2;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p0, v0, Lvh2;->h:Ljava/lang/Object;

    sget-object p0, Lads_mobile_sdk/ga3;->b:Lads_mobile_sdk/ga3;

    iput-object p0, v0, Lvh2;->i:Ljava/lang/Object;

    invoke-virtual {v0}, Lvh2;->a()Lads_mobile_sdk/s90;

    move-result-object p0

    iget-object p0, p0, Lads_mobile_sdk/s90;->B:Ltv2;

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/j63;

    invoke-virtual {p0}, Lads_mobile_sdk/j63;->b()Ld31;

    move-result-object p0

    return-object p0
.end method

.method public final a(Landroid/view/MotionEvent;)V
    .registers 11

    .prologue
    iget-object p0, p0, Lads_mobile_sdk/bm0;->e:Lv03;

    invoke-interface {p0}, Lv03;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/y61;

    monitor-enter p0

    :try_start_9
    iput-object p1, p0, Lads_mobile_sdk/y61;->b:Landroid/view/MotionEvent;

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_1c

    invoke-static {p1}, Landroid/view/MotionEvent;->obtain(Landroid/view/MotionEvent;)Landroid/view/MotionEvent;

    move-result-object v0

    iput-object v0, p0, Lads_mobile_sdk/y61;->c:Landroid/view/MotionEvent;

    goto :goto_1c

    :catchall_19
    move-exception p1

    goto/16 :goto_e0

    :cond_1c
    :goto_1c
    iget-object v0, p0, Lads_mobile_sdk/y61;->d:Lads_mobile_sdk/w61;

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v2

    const-wide/16 v3, 0x1

    if-eqz v2, :cond_97

    if-eq v2, v1, :cond_6a

    const/4 v5, 0x2

    if-eq v2, v5, :cond_37

    const/4 v1, 0x3

    if-eq v2, v1, :cond_30

    goto/16 :goto_c6

    :cond_30
    iget-wide v1, v0, Lads_mobile_sdk/w61;->d:J

    add-long/2addr v1, v3

    iput-wide v1, v0, Lads_mobile_sdk/w61;->d:J

    goto/16 :goto_c6

    :cond_37
    iget-wide v2, v0, Lads_mobile_sdk/w61;->b:J

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getHistorySize()I

    move-result v4

    add-int/2addr v4, v1

    int-to-long v4, v4

    add-long/2addr v2, v4

    iput-wide v2, v0, Lads_mobile_sdk/w61;->b:J

    iget-wide v1, v0, Lads_mobile_sdk/w61;->e:D

    iget-wide v3, v0, Lads_mobile_sdk/w61;->f:D

    iget-wide v5, v0, Lads_mobile_sdk/w61;->g:D

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawX()F

    move-result v7

    float-to-double v7, v7

    sub-double/2addr v7, v1

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawY()F

    move-result v1

    float-to-double v1, v1

    sub-double/2addr v1, v3

    invoke-static {v7, v8, v1, v2}, Ljava/lang/Math;->hypot(DD)D

    move-result-wide v1

    add-double/2addr v1, v5

    iput-wide v1, v0, Lads_mobile_sdk/w61;->g:D

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawX()F

    move-result v1

    float-to-double v1, v1

    iput-wide v1, v0, Lads_mobile_sdk/w61;->e:D

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawY()F

    move-result v1

    float-to-double v1, v1

    iput-wide v1, v0, Lads_mobile_sdk/w61;->f:D

    goto :goto_c6

    :cond_6a
    iget-wide v1, v0, Lads_mobile_sdk/w61;->c:J

    add-long/2addr v1, v3

    iput-wide v1, v0, Lads_mobile_sdk/w61;->c:J

    iget-wide v1, v0, Lads_mobile_sdk/w61;->e:D

    iget-wide v3, v0, Lads_mobile_sdk/w61;->f:D

    iget-wide v5, v0, Lads_mobile_sdk/w61;->g:D

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawX()F

    move-result v7

    float-to-double v7, v7

    sub-double/2addr v7, v1

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawY()F

    move-result v1

    float-to-double v1, v1

    sub-double/2addr v1, v3

    invoke-static {v7, v8, v1, v2}, Ljava/lang/Math;->hypot(DD)D

    move-result-wide v1

    add-double/2addr v1, v5

    iput-wide v1, v0, Lads_mobile_sdk/w61;->g:D

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawX()F

    move-result v1

    float-to-double v1, v1

    iput-wide v1, v0, Lads_mobile_sdk/w61;->e:D

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawY()F

    move-result v1

    float-to-double v1, v1

    iput-wide v1, v0, Lads_mobile_sdk/w61;->f:D

    goto :goto_c6

    :cond_97
    iget-wide v1, v0, Lads_mobile_sdk/w61;->a:J

    add-long/2addr v1, v3

    iput-wide v1, v0, Lads_mobile_sdk/w61;->a:J

    const-wide/16 v1, 0x0

    iput-wide v1, v0, Lads_mobile_sdk/w61;->g:D

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawX()F

    move-result v1

    float-to-double v1, v1

    iput-wide v1, v0, Lads_mobile_sdk/w61;->e:D

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawY()F

    move-result v1

    float-to-double v1, v1

    iput-wide v1, v0, Lads_mobile_sdk/w61;->f:D

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    move-result v1

    iput v1, v0, Lads_mobile_sdk/w61;->h:F

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    move-result v1

    iput v1, v0, Lads_mobile_sdk/w61;->i:F

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawX()F

    move-result v1

    iput v1, v0, Lads_mobile_sdk/w61;->j:F

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getRawY()F

    move-result v1

    iput v1, v0, Lads_mobile_sdk/w61;->k:F

    :goto_c6
    iget-object v0, p0, Lads_mobile_sdk/y61;->a:Ljava/util/ArrayDeque;

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->size()I

    move-result v0

    const/4 v1, 0x6

    if-lt v0, v1, :cond_d4

    iget-object v0, p0, Lads_mobile_sdk/y61;->a:Ljava/util/ArrayDeque;

    invoke-virtual {v0}, Ljava/util/ArrayDeque;->remove()Ljava/lang/Object;

    :cond_d4
    iget-object v0, p0, Lads_mobile_sdk/y61;->a:Ljava/util/ArrayDeque;

    new-instance v1, Lads_mobile_sdk/x61;

    invoke-direct {v1, p1}, Lads_mobile_sdk/x61;-><init>(Landroid/view/MotionEvent;)V

    invoke-virtual {v0, v1}, Ljava/util/ArrayDeque;->add(Ljava/lang/Object;)Z
    :try_end_de
    .catchall {:try_start_9 .. :try_end_de} :catchall_19

    monitor-exit p0

    return-void

    :goto_e0
    :try_start_e0
    monitor-exit p0
    :try_end_e1
    .catchall {:try_start_e0 .. :try_end_e1} :catchall_19

    throw p1
.end method

.method public final b(Landroid/content/Context;Ljava/lang/String;Landroid/view/View;Landroid/app/Activity;)Ld31;
    .registers 9

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/bm0;->d:Lads_mobile_sdk/ia3;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    iget-object v0, v0, Lads_mobile_sdk/ia3;->a:Ljava/util/Set;

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_10
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_20

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lku2;

    invoke-interface {v2, v1}, Lku2;->b(Ljava/util/HashMap;)V

    goto :goto_10

    :cond_20
    iget-object v0, p0, Lads_mobile_sdk/bm0;->e:Lv03;

    invoke-interface {v0}, Lv03;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/y61;

    monitor-enter v0

    :try_start_29
    iget-object v2, v0, Lads_mobile_sdk/y61;->b:Landroid/view/MotionEvent;

    if-eqz v2, :cond_35

    const-string v3, "evt"

    invoke-virtual {v1, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_35

    :catchall_33
    move-exception p0

    goto :goto_a2

    :cond_35
    :goto_35
    iget-object v2, v0, Lads_mobile_sdk/y61;->c:Landroid/view/MotionEvent;

    if-eqz v2, :cond_3e

    const-string v3, "nv"

    invoke-virtual {v1, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_3e
    iget-object v2, v0, Lads_mobile_sdk/y61;->d:Lads_mobile_sdk/w61;

    const-string v3, "oe"

    invoke-virtual {v1, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v2, v0, Lads_mobile_sdk/y61;->a:Ljava/util/ArrayDeque;

    invoke-virtual {v2}, Ljava/util/ArrayDeque;->size()I

    move-result v3

    new-array v3, v3, [Lads_mobile_sdk/x61;

    invoke-virtual {v2, v3}, Ljava/util/ArrayDeque;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v2

    const-string v3, "ro"

    invoke-virtual {v1, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v2, Lads_mobile_sdk/w61;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    iput-object v2, v0, Lads_mobile_sdk/y61;->d:Lads_mobile_sdk/w61;

    iget-object v2, v0, Lads_mobile_sdk/y61;->a:Ljava/util/ArrayDeque;

    invoke-virtual {v2}, Ljava/util/ArrayDeque;->clear()V

    iget-object v2, v0, Lads_mobile_sdk/y61;->c:Landroid/view/MotionEvent;

    const/4 v3, 0x0

    if-eqz v2, :cond_6c

    invoke-virtual {v2}, Landroid/view/MotionEvent;->recycle()V

    iput-object v3, v0, Lads_mobile_sdk/y61;->c:Landroid/view/MotionEvent;

    :cond_6c
    iput-object v3, v0, Lads_mobile_sdk/y61;->b:Landroid/view/MotionEvent;
    :try_end_6e
    .catchall {:try_start_29 .. :try_end_6e} :catchall_33

    monitor-exit v0

    iget-object p0, p0, Lads_mobile_sdk/bm0;->f:Lads_mobile_sdk/n90;

    invoke-virtual {p0}, Lads_mobile_sdk/n90;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lvh2;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Lvh2;->a:Ljava/lang/Object;

    iput-object p3, p0, Lvh2;->d:Ljava/lang/Object;

    iput-object p4, p0, Lvh2;->e:Ljava/lang/Object;

    iput-object p2, p0, Lvh2;->f:Ljava/lang/Object;

    iput-object v1, p0, Lvh2;->g:Ljava/lang/Object;

    sget-object p1, Lads_mobile_sdk/ga3;->c:Lads_mobile_sdk/ga3;

    iput-object p1, p0, Lvh2;->i:Ljava/lang/Object;

    invoke-static {}, Lads_mobile_sdk/pd;->w()Lwy2;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Lvh2;->h:Ljava/lang/Object;

    invoke-virtual {p0}, Lvh2;->a()Lads_mobile_sdk/s90;

    move-result-object p0

    iget-object p0, p0, Lads_mobile_sdk/s90;->B:Ltv2;

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/j63;

    invoke-virtual {p0}, Lads_mobile_sdk/j63;->b()Ld31;

    move-result-object p0

    return-object p0

    :goto_a2
    :try_start_a2
    monitor-exit v0
    :try_end_a3
    .catchall {:try_start_a2 .. :try_end_a3} :catchall_33

    throw p0
.end method

.method public final b()Ljava/lang/String;
    .registers 1

    const-string p0, "1.945319811"

    return-object p0
.end method
