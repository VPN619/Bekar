.class public final Lads_mobile_sdk/f8;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lo23;


# instance fields
.field public final a:Ljava/util/Optional;

.field public final b:Ljava/util/Optional;

.field public final c:Lads_mobile_sdk/av2;

.field public final d:Landroid/content/Context;

.field public final e:Lads_mobile_sdk/qr0;

.field public final f:Lads_mobile_sdk/kj0;


# direct methods
.method public constructor <init>(Ljava/util/Optional;Ljava/util/Optional;Lads_mobile_sdk/av2;Landroid/content/Context;Lads_mobile_sdk/qr0;Lads_mobile_sdk/kj0;)V
    .registers 7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/f8;->a:Ljava/util/Optional;

    iput-object p2, p0, Lads_mobile_sdk/f8;->b:Ljava/util/Optional;

    iput-object p3, p0, Lads_mobile_sdk/f8;->c:Lads_mobile_sdk/av2;

    iput-object p4, p0, Lads_mobile_sdk/f8;->d:Landroid/content/Context;

    iput-object p5, p0, Lads_mobile_sdk/f8;->e:Lads_mobile_sdk/qr0;

    iput-object p6, p0, Lads_mobile_sdk/f8;->f:Lads_mobile_sdk/kj0;

    return-void
.end method


# virtual methods
.method public final a(I)I
    .registers 4

    .prologue
    int-to-float p1, p1

    iget-object p0, p0, Lads_mobile_sdk/f8;->d:Landroid/content/Context;

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x22

    if-lt v0, v1, :cond_16

    invoke-static {p1, p0}, Ls1;->c(FLandroid/util/DisplayMetrics;)F

    move-result p0

    goto :goto_21

    :cond_16
    iget p0, p0, Landroid/util/DisplayMetrics;->density:F

    const/4 v0, 0x0

    cmpl-float v1, p0, v0

    if-nez v1, :cond_1f

    move p0, v0

    goto :goto_21

    :cond_1f
    div-float p0, p1, p0

    :goto_21
    float-to-double p0, p0

    invoke-static {p0, p1}, Ljava/lang/Math;->ceil(D)D

    move-result-wide p0

    double-to-float p0, p0

    float-to-int p0, p0

    return p0
.end method

.method public final a()Lads_mobile_sdk/lw0;
    .registers 1

    sget-object p0, Lads_mobile_sdk/lw0;->i:Lads_mobile_sdk/lw0;

    return-object p0
.end method

.method public final d(Lvx;)Ljava/lang/Object;
    .registers 34

    .prologue
    move-object/from16 v0, p0

    sget-object v1, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    iget-object v2, v0, Lads_mobile_sdk/f8;->d:Landroid/content/Context;

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    invoke-virtual {v3}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v3

    iget v6, v3, Landroid/util/DisplayMetrics;->density:F

    iget v7, v3, Landroid/util/DisplayMetrics;->widthPixels:I

    iget v8, v3, Landroid/util/DisplayMetrics;->heightPixels:I

    int-to-float v3, v7

    div-float/2addr v3, v6

    float-to-double v3, v3

    invoke-static {v3, v4}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v3

    double-to-float v3, v3

    float-to-int v9, v3

    int-to-float v3, v8

    div-float/2addr v3, v6

    float-to-double v3, v3

    invoke-static {v3, v4}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v3

    double-to-float v3, v3

    float-to-int v10, v3

    iget-object v3, v0, Lads_mobile_sdk/f8;->a:Ljava/util/Optional;

    invoke-static {v3}, Lw53;->I(Ljava/util/Optional;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lqh;

    iget-object v4, v0, Lads_mobile_sdk/f8;->b:Ljava/util/Optional;

    invoke-static {v4}, Lw53;->I(Ljava/util/Optional;)Ljava/lang/Object;

    move-result-object v4

    const/4 v5, 0x0

    if-nez v4, :cond_4bd

    if-eqz v3, :cond_3e

    invoke-interface {v3}, Lqh;->k()Ls4;

    move-result-object v4

    goto :goto_3f

    :cond_3e
    move-object v4, v5

    :goto_3f
    if-eqz v3, :cond_46

    invoke-interface {v3}, Lqh;->a()Ljava/util/List;

    move-result-object v11

    goto :goto_47

    :cond_46
    move-object v11, v5

    :goto_47
    if-eqz v11, :cond_57

    invoke-interface {v11}, Ljava/util/Collection;->isEmpty()Z

    move-result v11

    if-eqz v11, :cond_50

    goto :goto_57

    :cond_50
    if-eqz v3, :cond_57

    invoke-interface {v3}, Lqh;->a()Ljava/util/List;

    move-result-object v3

    goto :goto_58

    :cond_57
    :goto_57
    move-object v3, v5

    :goto_58
    const-string v11, "320x50_mb"

    iget-object v12, v0, Lads_mobile_sdk/f8;->e:Lads_mobile_sdk/qr0;

    const/4 v13, 0x1

    if-eqz v4, :cond_69

    invoke-virtual {v4}, Ls4;->a()Z

    move-result v14

    if-ne v14, v13, :cond_69

    :pswitch_65  #0x3, 0x5
    move-object/from16 p1, v5

    :cond_67
    :goto_67
    move-object v5, v11

    goto :goto_a2

    :cond_69
    if-eqz v4, :cond_74

    iget-object v14, v4, Ls4;->f:Ljava/lang/String;

    if-nez v14, :cond_70

    goto :goto_74

    :cond_70
    move-object/from16 p1, v5

    move-object v5, v14

    goto :goto_a2

    :cond_74
    :goto_74
    iget-object v14, v0, Lads_mobile_sdk/f8;->c:Lads_mobile_sdk/av2;

    invoke-virtual {v14}, Ljava/lang/Enum;->ordinal()I

    move-result v14

    const-string v15, ""

    packed-switch v14, :pswitch_data_4c4

    invoke-static {}, Ldm2;->q()V

    return-object v5

    :pswitch_83  #0x2
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v14, "gads:drop_format_string_if_not_set:enabled"

    move-object/from16 p1, v5

    sget-object v5, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {v12, v14, v5, v1}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    if-eqz v5, :cond_67

    :goto_98
    move-object v5, v15

    goto :goto_a2

    :pswitch_9a  #0x1, 0x4, 0x6, 0x7, 0x8
    move-object/from16 p1, v5

    const-string v11, "interstitial_mb"

    goto :goto_67

    :pswitch_9f  #0x0
    move-object/from16 p1, v5

    goto :goto_98

    :goto_a2
    if-eqz v4, :cond_b9

    iget-boolean v11, v4, Ls4;->e:Z

    if-eqz v11, :cond_ab

    const-string v11, "108"

    goto :goto_bb

    :cond_ab
    iget-boolean v11, v4, Ls4;->c:Z

    if-eqz v11, :cond_b2

    const-string v11, "102"

    goto :goto_bb

    :cond_b2
    iget-boolean v11, v4, Ls4;->d:Z

    if-eqz v11, :cond_b9

    const-string v11, "103"

    goto :goto_bb

    :cond_b9
    move-object/from16 v11, p1

    :goto_bb
    if-eqz v4, :cond_c4

    iget-boolean v14, v4, Ls4;->d:Z

    invoke-static {v14}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v14

    goto :goto_c6

    :cond_c4
    move-object/from16 v14, p1

    :goto_c6
    if-eqz v4, :cond_cf

    invoke-virtual {v4}, Ls4;->a()Z

    move-result v4

    if-ne v4, v13, :cond_cf

    goto :goto_ee

    :cond_cf
    if-eqz v3, :cond_f1

    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    move-result v4

    if-eqz v4, :cond_d8

    goto :goto_f1

    :cond_d8
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :cond_dc
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v15

    if-eqz v15, :cond_f1

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Ls4;

    invoke-virtual {v15}, Ls4;->a()Z

    move-result v15

    if-eqz v15, :cond_dc

    :goto_ee
    const-string v4, "height"

    goto :goto_f3

    :cond_f1
    :goto_f1
    move-object/from16 v4, p1

    :goto_f3
    new-instance v15, Ljava/util/ArrayList;

    invoke-direct {v15}, Ljava/util/ArrayList;-><init>()V

    if-eqz v3, :cond_167

    move/from16 v16, v13

    new-instance v13, Ljava/util/ArrayList;

    move-object/from16 v17, v4

    const/16 v4, 0xa

    invoke-static {v3, v4}, Lds;->Y(Ljava/lang/Iterable;I)I

    move-result v4

    invoke-direct {v13, v4}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_10d
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v18

    if-eqz v18, :cond_15d

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v18

    move-object/from16 v19, v3

    move-object/from16 v3, v18

    check-cast v3, Ls4;

    move-object/from16 v18, v4

    new-instance v4, Lt4;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v3}, Ls4;->a()Z

    move-result v20

    if-eqz v20, :cond_133

    const/16 v20, 0x140

    move/from16 v31, v20

    move-object/from16 v20, v5

    move/from16 v5, v31

    goto :goto_137

    :cond_133
    move-object/from16 v20, v5

    iget v5, v3, Ls4;->a:I

    :goto_137
    invoke-virtual {v3}, Ls4;->a()Z

    move-result v21

    if-eqz v21, :cond_146

    const/16 v21, 0x32

    move/from16 v31, v21

    move/from16 v21, v6

    move/from16 v6, v31

    goto :goto_14a

    :cond_146
    move/from16 v21, v6

    iget v6, v3, Ls4;->b:I

    :goto_14a
    invoke-virtual {v3}, Ls4;->a()Z

    move-result v3

    invoke-direct {v4, v5, v6, v3}, Lt4;-><init>(IIZ)V

    invoke-virtual {v13, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move-object/from16 v4, v18

    move-object/from16 v3, v19

    move-object/from16 v5, v20

    move/from16 v6, v21

    goto :goto_10d

    :cond_15d
    move-object/from16 v19, v3

    move-object/from16 v20, v5

    move/from16 v21, v6

    invoke-virtual {v15, v13}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    goto :goto_171

    :cond_167
    move-object/from16 v19, v3

    move-object/from16 v17, v4

    move-object/from16 v20, v5

    move/from16 v21, v6

    move/from16 v16, v13

    :goto_171
    invoke-static {v15}, Lbs;->l0(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lt4;

    if-nez v3, :cond_17a

    goto :goto_189

    :cond_17a
    invoke-static {v9, v10}, Ljava/lang/Math;->max(II)I

    move-result v5

    add-int/lit8 v5, v5, 0x1

    iget v6, v3, Lt4;->a:I

    if-gt v6, v5, :cond_18c

    iget v3, v3, Lt4;->b:I

    if-le v3, v5, :cond_189

    goto :goto_18c

    :cond_189
    :goto_189
    const/16 v18, 0x0

    goto :goto_18e

    :cond_18c
    :goto_18c
    move/from16 v18, v16

    :goto_18e
    if-eqz v19, :cond_1e2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-interface/range {v19 .. v19}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v5

    const/4 v6, 0x0

    :goto_19a
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    const-string v4, "|"

    if-eqz v13, :cond_1ca

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ls4;

    invoke-virtual {v13}, Ls4;->a()Z

    move-result v22

    if-eqz v22, :cond_1b1

    move/from16 v6, v16

    goto :goto_19a

    :cond_1b1
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->length()I

    move-result v22

    if-lez v22, :cond_1ba

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_1ba
    iget v4, v13, Ls4;->a:I

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v4, "x"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v4, v13, Ls4;->b:I

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    goto :goto_19a

    :cond_1ca
    if-eqz v6, :cond_1dd

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->length()I

    move-result v5

    if-lez v5, :cond_1d7

    const/4 v5, 0x0

    invoke-virtual {v3, v5, v4}, Ljava/lang/StringBuilder;->insert(ILjava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_1d8

    :cond_1d7
    const/4 v5, 0x0

    :goto_1d8
    const-string v4, "320x50"

    invoke-virtual {v3, v5, v4}, Ljava/lang/StringBuilder;->insert(ILjava/lang/String;)Ljava/lang/StringBuilder;

    :cond_1dd
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    goto :goto_1e4

    :cond_1e2
    move-object/from16 v3, p1

    :goto_1e4
    new-instance v4, Lads_mobile_sdk/hv0;

    move-object v5, v4

    new-instance v4, Lads_mobile_sdk/e8;

    sget v6, Landroid/os/Build$VERSION;->SDK_INT:I

    iget-object v13, v0, Lads_mobile_sdk/f8;->f:Lads_mobile_sdk/kj0;

    move-object/from16 v22, v3

    const/16 v3, 0x23

    move-object/from16 v23, v4

    if-ge v6, v3, :cond_1ff

    move-object/from16 v26, v5

    move/from16 v27, v7

    :cond_1f9
    move/from16 v29, v8

    move/from16 v30, v9

    goto/16 :goto_40b

    :cond_1ff
    invoke-virtual {v13, v2}, Lads_mobile_sdk/kj0;->b(Landroid/content/Context;)Landroid/view/WindowManager;

    move-result-object v24

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v25

    invoke-virtual/range {v25 .. v25}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v3

    iget v3, v3, Landroid/util/DisplayMetrics;->heightPixels:I

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v25

    invoke-virtual/range {v25 .. v25}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v4

    iget v4, v4, Landroid/util/DisplayMetrics;->widthPixels:I

    if-lt v3, v4, :cond_21c

    move/from16 v3, v16

    goto :goto_21d

    :cond_21c
    const/4 v3, 0x0

    :goto_21d
    iget-object v4, v12, Lads_mobile_sdk/qr0;->t:Lcw2;

    move/from16 v25, v3

    iget-object v3, v12, Lads_mobile_sdk/qr0;->t:Lcw2;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-object/from16 v26, v5

    const-string v5, "gads:safe_area_margin_signals:enabled"

    move/from16 v27, v7

    sget-object v7, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {v4, v5, v7, v1}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Boolean;

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    if-eqz v4, :cond_24e

    invoke-interface/range {v24 .. v24}, Landroid/view/WindowManager;->getCurrentWindowMetrics()Landroid/view/WindowMetrics;

    move-result-object v4

    invoke-virtual {v4}, Landroid/view/WindowMetrics;->getWindowInsets()Landroid/view/WindowInsets;

    move-result-object v4

    const/16 v5, 0x287

    invoke-virtual {v4, v5}, Landroid/view/WindowInsets;->getInsets(I)Landroid/graphics/Insets;

    move-result-object v4

    move/from16 v29, v8

    move/from16 v30, v9

    goto/16 :goto_393

    :cond_24e
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v4, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const-string v5, "gads:notch_safe_area_signals:enabled"

    invoke-virtual {v3, v5, v4, v1}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Boolean;

    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v5

    if-eqz v5, :cond_1f9

    invoke-interface/range {v24 .. v24}, Landroid/view/WindowManager;->getCurrentWindowMetrics()Landroid/view/WindowMetrics;

    move-result-object v5

    invoke-virtual {v5}, Landroid/view/WindowMetrics;->getWindowInsets()Landroid/view/WindowInsets;

    move-result-object v5

    const/16 v7, 0x80

    invoke-virtual {v5, v7}, Landroid/view/WindowInsets;->getInsets(I)Landroid/graphics/Insets;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v7, "gads:include_corner_in_safe_area_margin:enabled"

    invoke-virtual {v3, v7, v4, v1}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Boolean;

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    if-eqz v4, :cond_38b

    if-eqz v25, :cond_309

    invoke-interface/range {v24 .. v24}, Landroid/view/WindowManager;->getCurrentWindowMetrics()Landroid/view/WindowMetrics;

    move-result-object v4

    invoke-virtual {v4}, Landroid/view/WindowMetrics;->getWindowInsets()Landroid/view/WindowInsets;

    move-result-object v4

    const/4 v7, 0x0

    invoke-virtual {v4, v7}, Landroid/view/WindowInsets;->getRoundedCorner(I)Landroid/view/RoundedCorner;

    move-result-object v4

    if-eqz v4, :cond_299

    invoke-virtual {v4}, Landroid/view/RoundedCorner;->getRadius()I

    move-result v4

    goto :goto_29a

    :cond_299
    const/4 v4, 0x0

    :goto_29a
    invoke-interface/range {v24 .. v24}, Landroid/view/WindowManager;->getCurrentWindowMetrics()Landroid/view/WindowMetrics;

    move-result-object v7

    invoke-virtual {v7}, Landroid/view/WindowMetrics;->getWindowInsets()Landroid/view/WindowInsets;

    move-result-object v7

    move-object/from16 v28, v5

    move/from16 v5, v16

    invoke-virtual {v7, v5}, Landroid/view/WindowInsets;->getRoundedCorner(I)Landroid/view/RoundedCorner;

    move-result-object v7

    if-eqz v7, :cond_2b1

    invoke-virtual {v7}, Landroid/view/RoundedCorner;->getRadius()I

    move-result v5

    goto :goto_2b2

    :cond_2b1
    const/4 v5, 0x0

    :goto_2b2
    invoke-static {v4, v5}, Ljava/lang/Math;->max(II)I

    move-result v4

    invoke-interface/range {v24 .. v24}, Landroid/view/WindowManager;->getCurrentWindowMetrics()Landroid/view/WindowMetrics;

    move-result-object v5

    invoke-virtual {v5}, Landroid/view/WindowMetrics;->getWindowInsets()Landroid/view/WindowInsets;

    move-result-object v5

    const/4 v7, 0x3

    invoke-virtual {v5, v7}, Landroid/view/WindowInsets;->getRoundedCorner(I)Landroid/view/RoundedCorner;

    move-result-object v5

    if-eqz v5, :cond_2ca

    invoke-virtual {v5}, Landroid/view/RoundedCorner;->getRadius()I

    move-result v5

    goto :goto_2cb

    :cond_2ca
    const/4 v5, 0x0

    :goto_2cb
    invoke-interface/range {v24 .. v24}, Landroid/view/WindowManager;->getCurrentWindowMetrics()Landroid/view/WindowMetrics;

    move-result-object v7

    invoke-virtual {v7}, Landroid/view/WindowMetrics;->getWindowInsets()Landroid/view/WindowInsets;

    move-result-object v7

    move/from16 v29, v8

    const/4 v8, 0x2

    invoke-virtual {v7, v8}, Landroid/view/WindowInsets;->getRoundedCorner(I)Landroid/view/RoundedCorner;

    move-result-object v7

    if-eqz v7, :cond_2e1

    invoke-virtual {v7}, Landroid/view/RoundedCorner;->getRadius()I

    move-result v7

    goto :goto_2e2

    :cond_2e1
    const/4 v7, 0x0

    :goto_2e2
    invoke-static {v5, v7}, Ljava/lang/Math;->max(II)I

    move-result v5

    invoke-static/range {v28 .. v28}, Ldm2;->f(Landroid/graphics/Insets;)I

    move-result v7

    invoke-static/range {v28 .. v28}, Ldm2;->p(Landroid/graphics/Insets;)I

    move-result v8

    invoke-static {v8, v4}, Ljava/lang/Math;->max(II)I

    move-result v4

    invoke-static/range {v28 .. v28}, Ldm2;->s(Landroid/graphics/Insets;)I

    move-result v8

    move/from16 v30, v9

    invoke-static/range {v28 .. v28}, Ldm2;->t(Landroid/graphics/Insets;)I

    move-result v9

    invoke-static {v9, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    invoke-static {v7, v4, v8, v5}, Landroid/graphics/Insets;->of(IIII)Landroid/graphics/Insets;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    goto/16 :goto_393

    :cond_309
    move-object/from16 v28, v5

    move/from16 v29, v8

    move/from16 v30, v9

    invoke-interface/range {v24 .. v24}, Landroid/view/WindowManager;->getCurrentWindowMetrics()Landroid/view/WindowMetrics;

    move-result-object v4

    invoke-virtual {v4}, Landroid/view/WindowMetrics;->getWindowInsets()Landroid/view/WindowInsets;

    move-result-object v4

    const/4 v5, 0x0

    invoke-virtual {v4, v5}, Landroid/view/WindowInsets;->getRoundedCorner(I)Landroid/view/RoundedCorner;

    move-result-object v4

    if-eqz v4, :cond_323

    invoke-virtual {v4}, Landroid/view/RoundedCorner;->getRadius()I

    move-result v5

    goto :goto_324

    :cond_323
    const/4 v5, 0x0

    :goto_324
    invoke-interface/range {v24 .. v24}, Landroid/view/WindowManager;->getCurrentWindowMetrics()Landroid/view/WindowMetrics;

    move-result-object v4

    invoke-virtual {v4}, Landroid/view/WindowMetrics;->getWindowInsets()Landroid/view/WindowInsets;

    move-result-object v4

    const/4 v7, 0x3

    invoke-virtual {v4, v7}, Landroid/view/WindowInsets;->getRoundedCorner(I)Landroid/view/RoundedCorner;

    move-result-object v4

    if-eqz v4, :cond_338

    invoke-virtual {v4}, Landroid/view/RoundedCorner;->getRadius()I

    move-result v4

    goto :goto_339

    :cond_338
    const/4 v4, 0x0

    :goto_339
    invoke-static {v5, v4}, Ljava/lang/Math;->max(II)I

    move-result v4

    invoke-interface/range {v24 .. v24}, Landroid/view/WindowManager;->getCurrentWindowMetrics()Landroid/view/WindowMetrics;

    move-result-object v5

    invoke-virtual {v5}, Landroid/view/WindowMetrics;->getWindowInsets()Landroid/view/WindowInsets;

    move-result-object v5

    const/4 v7, 0x1

    invoke-virtual {v5, v7}, Landroid/view/WindowInsets;->getRoundedCorner(I)Landroid/view/RoundedCorner;

    move-result-object v5

    if-eqz v5, :cond_351

    invoke-virtual {v5}, Landroid/view/RoundedCorner;->getRadius()I

    move-result v5

    goto :goto_352

    :cond_351
    const/4 v5, 0x0

    :goto_352
    invoke-interface/range {v24 .. v24}, Landroid/view/WindowManager;->getCurrentWindowMetrics()Landroid/view/WindowMetrics;

    move-result-object v7

    invoke-virtual {v7}, Landroid/view/WindowMetrics;->getWindowInsets()Landroid/view/WindowInsets;

    move-result-object v7

    const/4 v8, 0x2

    invoke-virtual {v7, v8}, Landroid/view/WindowInsets;->getRoundedCorner(I)Landroid/view/RoundedCorner;

    move-result-object v7

    if-eqz v7, :cond_366

    invoke-virtual {v7}, Landroid/view/RoundedCorner;->getRadius()I

    move-result v7

    goto :goto_367

    :cond_366
    const/4 v7, 0x0

    :goto_367
    invoke-static {v5, v7}, Ljava/lang/Math;->max(II)I

    move-result v5

    invoke-static/range {v28 .. v28}, Ldm2;->f(Landroid/graphics/Insets;)I

    move-result v7

    invoke-static {v7, v4}, Ljava/lang/Math;->max(II)I

    move-result v4

    invoke-static/range {v28 .. v28}, Ldm2;->p(Landroid/graphics/Insets;)I

    move-result v7

    invoke-static/range {v28 .. v28}, Ldm2;->s(Landroid/graphics/Insets;)I

    move-result v8

    invoke-static {v8, v5}, Ljava/lang/Math;->max(II)I

    move-result v5

    invoke-static/range {v28 .. v28}, Ldm2;->t(Landroid/graphics/Insets;)I

    move-result v8

    invoke-static {v4, v7, v5, v8}, Landroid/graphics/Insets;->of(IIII)Landroid/graphics/Insets;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    goto :goto_393

    :cond_38b
    move-object/from16 v28, v5

    move/from16 v29, v8

    move/from16 v30, v9

    move-object/from16 v4, v28

    :goto_393
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-nez v25, :cond_3c9

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v5, "gads:center_safe_area_side_margins:enabled"

    sget-object v7, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {v3, v5, v7, v1}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Boolean;

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    if-eqz v3, :cond_3c9

    invoke-static {v4}, Ldm2;->f(Landroid/graphics/Insets;)I

    move-result v3

    invoke-static {v4}, Ldm2;->s(Landroid/graphics/Insets;)I

    move-result v5

    invoke-static {v3, v5}, Ljava/lang/Math;->max(II)I

    move-result v3

    invoke-virtual {v0, v3}, Lads_mobile_sdk/f8;->a(I)I

    move-result v3

    new-instance v5, Ldj1;

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-direct {v5, v7, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    goto :goto_3e6

    :cond_3c9
    new-instance v5, Ldj1;

    invoke-static {v4}, Ldm2;->f(Landroid/graphics/Insets;)I

    move-result v3

    invoke-virtual {v0, v3}, Lads_mobile_sdk/f8;->a(I)I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v4}, Ldm2;->s(Landroid/graphics/Insets;)I

    move-result v7

    invoke-virtual {v0, v7}, Lads_mobile_sdk/f8;->a(I)I

    move-result v7

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-direct {v5, v3, v7}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    :goto_3e6
    iget-object v3, v5, Ldj1;->a:Ljava/lang/Object;

    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    move-result v3

    iget-object v5, v5, Ldj1;->b:Ljava/lang/Object;

    check-cast v5, Ljava/lang/Number;

    invoke-virtual {v5}, Ljava/lang/Number;->intValue()I

    move-result v5

    invoke-static {v4}, Ldm2;->p(Landroid/graphics/Insets;)I

    move-result v7

    invoke-virtual {v0, v7}, Lads_mobile_sdk/f8;->a(I)I

    move-result v7

    invoke-static {v4}, Ldm2;->t(Landroid/graphics/Insets;)I

    move-result v4

    invoke-virtual {v0, v4}, Lads_mobile_sdk/f8;->a(I)I

    move-result v4

    invoke-static {v3, v7, v5, v4}, Landroid/graphics/Insets;->of(IIII)Landroid/graphics/Insets;

    move-result-object v3

    goto :goto_40d

    :goto_40b
    move-object/from16 v3, p1

    :goto_40d
    iget-object v4, v12, Lads_mobile_sdk/qr0;->t:Lcw2;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v5, "gads:rounded_corner_radii_signals:enabled"

    sget-object v7, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {v4, v5, v7, v1}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-eqz v1, :cond_49d

    const/16 v1, 0x23

    if-ge v6, v1, :cond_428

    goto/16 :goto_49d

    :cond_428
    invoke-virtual {v13, v2}, Lads_mobile_sdk/kj0;->b(Landroid/content/Context;)Landroid/view/WindowManager;

    move-result-object v1

    invoke-interface {v1}, Landroid/view/WindowManager;->getCurrentWindowMetrics()Landroid/view/WindowMetrics;

    move-result-object v1

    invoke-virtual {v1}, Landroid/view/WindowMetrics;->getWindowInsets()Landroid/view/WindowInsets;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v5, 0x0

    invoke-virtual {v1, v5}, Landroid/view/WindowInsets;->getRoundedCorner(I)Landroid/view/RoundedCorner;

    move-result-object v2

    if-eqz v2, :cond_448

    invoke-virtual {v2}, Landroid/view/RoundedCorner;->getRadius()I

    move-result v2

    invoke-virtual {v0, v2}, Lads_mobile_sdk/f8;->a(I)I

    move-result v2

    :goto_446
    const/4 v7, 0x1

    goto :goto_44a

    :cond_448
    move v2, v5

    goto :goto_446

    :goto_44a
    invoke-virtual {v1, v7}, Landroid/view/WindowInsets;->getRoundedCorner(I)Landroid/view/RoundedCorner;

    move-result-object v4

    if-eqz v4, :cond_45a

    invoke-virtual {v4}, Landroid/view/RoundedCorner;->getRadius()I

    move-result v4

    invoke-virtual {v0, v4}, Lads_mobile_sdk/f8;->a(I)I

    move-result v4

    :goto_458
    const/4 v8, 0x2

    goto :goto_45c

    :cond_45a
    move v4, v5

    goto :goto_458

    :goto_45c
    invoke-virtual {v1, v8}, Landroid/view/WindowInsets;->getRoundedCorner(I)Landroid/view/RoundedCorner;

    move-result-object v6

    if-eqz v6, :cond_46c

    invoke-virtual {v6}, Landroid/view/RoundedCorner;->getRadius()I

    move-result v6

    invoke-virtual {v0, v6}, Lads_mobile_sdk/f8;->a(I)I

    move-result v6

    :goto_46a
    const/4 v7, 0x3

    goto :goto_46e

    :cond_46c
    move v6, v5

    goto :goto_46a

    :goto_46e
    invoke-virtual {v1, v7}, Landroid/view/WindowInsets;->getRoundedCorner(I)Landroid/view/RoundedCorner;

    move-result-object v1

    if-eqz v1, :cond_47d

    invoke-virtual {v1}, Landroid/view/RoundedCorner;->getRadius()I

    move-result v1

    invoke-virtual {v0, v1}, Lads_mobile_sdk/f8;->a(I)I

    move-result v0

    goto :goto_47e

    :cond_47d
    move v0, v5

    :goto_47e
    new-instance v5, Lads_mobile_sdk/ay2;

    invoke-direct {v5, v2, v4, v6, v0}, Lads_mobile_sdk/ay2;-><init>(IIII)V

    move-object v13, v14

    move-object/from16 v14, v17

    move-object/from16 v17, v5

    move-object v12, v11

    move-object/from16 v16, v15

    move/from16 v6, v21

    move-object/from16 v15, v22

    move-object/from16 v4, v23

    move-object/from16 v0, v26

    move/from16 v7, v27

    move/from16 v8, v29

    move/from16 v9, v30

    move-object v11, v3

    move-object/from16 v5, v20

    goto :goto_4b6

    :cond_49d
    :goto_49d
    move-object v13, v14

    move-object/from16 v14, v17

    move-object/from16 v17, p1

    move-object v12, v11

    move-object/from16 v16, v15

    move-object/from16 v5, v20

    move/from16 v6, v21

    move-object/from16 v15, v22

    move-object/from16 v4, v23

    move-object/from16 v0, v26

    move/from16 v7, v27

    move/from16 v8, v29

    move/from16 v9, v30

    move-object v11, v3

    :goto_4b6
    invoke-direct/range {v4 .. v18}, Lads_mobile_sdk/e8;-><init>(Ljava/lang/String;FIIIILandroid/graphics/Insets;Ljava/lang/String;Ljava/lang/Boolean;Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;Lads_mobile_sdk/ay2;Z)V

    invoke-direct {v0, v4}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    return-object v0

    :cond_4bd
    move-object/from16 p1, v5

    invoke-static {}, Lvx2;->b()V

    return-object p1

    nop

    :pswitch_data_4c4
    .packed-switch 0x0
        :pswitch_9f  #00000000
        :pswitch_9a  #00000001
        :pswitch_83  #00000002
        :pswitch_65  #00000003
        :pswitch_9a  #00000004
        :pswitch_65  #00000005
        :pswitch_9a  #00000006
        :pswitch_9a  #00000007
        :pswitch_9a  #00000008
    .end packed-switch
.end method
