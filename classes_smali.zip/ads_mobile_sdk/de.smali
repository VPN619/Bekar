.class public final Lads_mobile_sdk/de;
.super Lads_mobile_sdk/ku0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field private static final DEFAULT_INSTANCE:Lads_mobile_sdk/de;

.field public static final c:I = 0x1

.field public static final d:I = 0x2

.field public static final e:I = 0x3

.field public static final f:I = 0x4

.field public static final g:I = 0x5

.field public static final h:I = 0x6

.field public static final i:I = 0x7


# instance fields
.field private adshieldVersion_:Ljava/lang/String;

.field private afmaVersion_:Ljava/lang/String;

.field private appIdSignal_:Ljava/lang/String;

.field private bitField0_:I

.field private cerSignal_:Ljava/lang/String;

.field private evtTime_:J

.field private uptSignal_:J

.field private vcdSignal_:J


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lads_mobile_sdk/de;

    invoke-direct {v0}, Lads_mobile_sdk/de;-><init>()V

    sput-object v0, Lads_mobile_sdk/de;->DEFAULT_INSTANCE:Lads_mobile_sdk/de;

    const-class v1, Lads_mobile_sdk/de;

    invoke-static {v1, v0}, Lads_mobile_sdk/ku0;->a(Ljava/lang/Class;Lads_mobile_sdk/ku0;)V

    return-void
.end method

.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Lads_mobile_sdk/ku0;-><init>()V

    const-string v0, ""

    iput-object v0, p0, Lads_mobile_sdk/de;->adshieldVersion_:Ljava/lang/String;

    iput-object v0, p0, Lads_mobile_sdk/de;->afmaVersion_:Ljava/lang/String;

    const-string v1, "D"

    iput-object v1, p0, Lads_mobile_sdk/de;->appIdSignal_:Ljava/lang/String;

    iput-object v0, p0, Lads_mobile_sdk/de;->cerSignal_:Ljava/lang/String;

    return-void
.end method

.method public static bridge synthetic c(Lads_mobile_sdk/de;)I
    .registers 1

    iget p0, p0, Lads_mobile_sdk/de;->bitField0_:I

    return p0
.end method

.method public static bridge synthetic d(Lads_mobile_sdk/de;I)V
    .registers 2

    iput p1, p0, Lads_mobile_sdk/de;->bitField0_:I

    return-void
.end method

.method public static bridge synthetic f(Lads_mobile_sdk/de;J)V
    .registers 3

    iput-wide p1, p0, Lads_mobile_sdk/de;->evtTime_:J

    return-void
.end method

.method public static bridge synthetic g(Lads_mobile_sdk/de;J)V
    .registers 3

    iput-wide p1, p0, Lads_mobile_sdk/de;->uptSignal_:J

    return-void
.end method

.method public static bridge synthetic h(Lads_mobile_sdk/de;J)V
    .registers 3

    iput-wide p1, p0, Lads_mobile_sdk/de;->vcdSignal_:J

    return-void
.end method

.method public static o()Lfv2;
    .registers 1

    sget-object v0, Lads_mobile_sdk/de;->DEFAULT_INSTANCE:Lads_mobile_sdk/de;

    invoke-virtual {v0}, Lads_mobile_sdk/ku0;->e()Lads_mobile_sdk/iu0;

    move-result-object v0

    check-cast v0, Lfv2;

    return-object v0
.end method


# virtual methods
.method public final a(ILads_mobile_sdk/ku0;)Ljava/lang/Object;
    .registers 11

    .prologue
    invoke-static {p1}, Lvr0;->a(I)I

    move-result p0

    if-eqz p0, :cond_4d

    const/4 p1, 0x2

    if-eq p0, p1, :cond_2f

    const/4 p1, 0x3

    if-eq p0, p1, :cond_29

    const/4 p1, 0x4

    if-eq p0, p1, :cond_21

    const/4 p1, 0x5

    if-eq p0, p1, :cond_1e

    const/4 p1, 0x6

    if-ne p0, p1, :cond_1c

    const-class p0, Lads_mobile_sdk/de;

    invoke-static {p0}, Lads_mobile_sdk/ku0;->b(Ljava/lang/Class;)Lads_mobile_sdk/ju0;

    move-result-object p0

    return-object p0

    :cond_1c
    const/4 p0, 0x0

    throw p0

    :cond_1e
    sget-object p0, Lads_mobile_sdk/de;->DEFAULT_INSTANCE:Lads_mobile_sdk/de;

    return-object p0

    :cond_21
    new-instance p0, Lfv2;

    sget-object p1, Lads_mobile_sdk/de;->DEFAULT_INSTANCE:Lads_mobile_sdk/de;

    invoke-direct {p0, p1}, Lads_mobile_sdk/iu0;-><init>(Lads_mobile_sdk/ku0;)V

    return-object p0

    :cond_29
    new-instance p0, Lads_mobile_sdk/de;

    invoke-direct {p0}, Lads_mobile_sdk/de;-><init>()V

    return-object p0

    :cond_2f
    const-string v6, "uptSignal_"

    const-string v7, "cerSignal_"

    const-string v0, "bitField0_"

    const-string v1, "adshieldVersion_"

    const-string v2, "afmaVersion_"

    const-string v3, "evtTime_"

    const-string v4, "appIdSignal_"

    const-string v5, "vcdSignal_"

    filled-new-array/range {v0 .. v7}, [Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lads_mobile_sdk/de;->DEFAULT_INSTANCE:Lads_mobile_sdk/de;

    new-instance p2, Lads_mobile_sdk/zq2;

    const-string v0, "\u0001\u0007\u0000\u0001\u0001\u0007\u0007\u0000\u0000\u0000\u0001ဈ\u0000\u0002ဈ\u0001\u0003ဂ\u0002\u0004ဈ\u0003\u0005ဂ\u0004\u0006ဂ\u0005\u0007ဈ\u0006"

    invoke-direct {p2, p1, v0, p0}, Lads_mobile_sdk/zq2;-><init>(Lads_mobile_sdk/ku0;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object p2

    :cond_4d
    const/4 p0, 0x1

    invoke-static {p0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p0

    return-object p0
.end method

.method public final b(Ljava/lang/String;)V
    .registers 3

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget v0, p0, Lads_mobile_sdk/de;->bitField0_:I

    or-int/lit8 v0, v0, 0x2

    iput v0, p0, Lads_mobile_sdk/de;->bitField0_:I

    iput-object p1, p0, Lads_mobile_sdk/de;->afmaVersion_:Ljava/lang/String;

    return-void
.end method

.method public final c(Ljava/lang/String;)V
    .registers 3

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget v0, p0, Lads_mobile_sdk/de;->bitField0_:I

    or-int/lit8 v0, v0, 0x8

    iput v0, p0, Lads_mobile_sdk/de;->bitField0_:I

    iput-object p1, p0, Lads_mobile_sdk/de;->appIdSignal_:Ljava/lang/String;

    return-void
.end method

.method public final d(Ljava/lang/String;)V
    .registers 3

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget v0, p0, Lads_mobile_sdk/de;->bitField0_:I

    or-int/lit8 v0, v0, 0x40

    iput v0, p0, Lads_mobile_sdk/de;->bitField0_:I

    iput-object p1, p0, Lads_mobile_sdk/de;->cerSignal_:Ljava/lang/String;

    return-void
.end method

.method public final p()V
    .registers 2

    iget v0, p0, Lads_mobile_sdk/de;->bitField0_:I

    or-int/lit8 v0, v0, 0x1

    iput v0, p0, Lads_mobile_sdk/de;->bitField0_:I

    const-string v0, "0.945319811"

    iput-object v0, p0, Lads_mobile_sdk/de;->adshieldVersion_:Ljava/lang/String;

    return-void
.end method
