.class public final Lads_mobile_sdk/aa;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lnt2;


# instance fields
.field public final a:Ltv2;

.field public final b:Lads_mobile_sdk/fn1;

.field public final synthetic c:I


# direct methods
.method public synthetic constructor <init>(Ltv2;Lads_mobile_sdk/fn1;I)V
    .registers 4

    iput p3, p0, Lads_mobile_sdk/aa;->c:I

    iput-object p1, p0, Lads_mobile_sdk/aa;->a:Ltv2;

    iput-object p2, p0, Lads_mobile_sdk/aa;->b:Lads_mobile_sdk/fn1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 3

    .prologue
    iget v0, p0, Lads_mobile_sdk/aa;->c:I

    iget-object v1, p0, Lads_mobile_sdk/aa;->b:Lads_mobile_sdk/fn1;

    iget-object p0, p0, Lads_mobile_sdk/aa;->a:Ltv2;

    packed-switch v0, :pswitch_data_82

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lvy;

    invoke-virtual {v1}, Lads_mobile_sdk/fn1;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map;

    new-instance v1, Lv53;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {v1, p0, v0}, Lpb;-><init>(Lvy;Ljava/util/Map;)V

    return-object v1

    :pswitch_21  #0x4
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lvy;

    invoke-virtual {v1}, Lads_mobile_sdk/fn1;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map;

    new-instance v1, Lm43;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {v1, p0, v0}, Lpb;-><init>(Lvy;Ljava/util/Map;)V

    return-object v1

    :pswitch_39  #0x3
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lvy;

    invoke-virtual {v1}, Lads_mobile_sdk/fn1;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map;

    new-instance v1, Lads_mobile_sdk/qr3;

    invoke-direct {v1, p0, v0}, Lads_mobile_sdk/qr3;-><init>(Lvy;Ljava/util/Map;)V

    return-object v1

    :pswitch_4b  #0x2
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lvy;

    invoke-virtual {v1}, Lads_mobile_sdk/fn1;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map;

    new-instance v1, Lads_mobile_sdk/ja;

    invoke-direct {v1, p0, v0}, Lads_mobile_sdk/ja;-><init>(Lvy;Ljava/util/Map;)V

    return-object v1

    :pswitch_5d  #0x1
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lvy;

    invoke-virtual {v1}, Lads_mobile_sdk/fn1;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map;

    new-instance v1, Lads_mobile_sdk/fr3;

    invoke-direct {v1, p0, v0}, Lads_mobile_sdk/fr3;-><init>(Lvy;Ljava/util/Map;)V

    return-object v1

    :pswitch_6f  #0x0
    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lvy;

    invoke-virtual {v1}, Lads_mobile_sdk/fn1;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map;

    new-instance v1, Lads_mobile_sdk/z9;

    invoke-direct {v1, p0, v0}, Lads_mobile_sdk/z9;-><init>(Lvy;Ljava/util/Map;)V

    return-object v1

    nop

    :pswitch_data_82
    .packed-switch 0x0
        :pswitch_6f  #00000000
        :pswitch_5d  #00000001
        :pswitch_4b  #00000002
        :pswitch_39  #00000003
        :pswitch_21  #00000004
    .end packed-switch
.end method
