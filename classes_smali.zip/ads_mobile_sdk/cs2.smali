.class public final Lads_mobile_sdk/cs2;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lbk0;


# instance fields
.field public a:Lnb1;

.field public b:Lads_mobile_sdk/vs2;

.field public c:I

.field public final synthetic d:Lads_mobile_sdk/vs2;

.field public final synthetic t:I


# direct methods
.method public synthetic constructor <init>(Lads_mobile_sdk/vs2;Lvx;I)V
    .registers 4

    iput p3, p0, Lads_mobile_sdk/cs2;->t:I

    iput-object p1, p0, Lads_mobile_sdk/cs2;->d:Lads_mobile_sdk/vs2;

    const/4 p1, 0x1

    invoke-direct {p0, p1, p2}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .prologue
    iget v0, p0, Lads_mobile_sdk/cs2;->t:I

    sget-object v1, Lrg2;->a:Lrg2;

    iget-object p0, p0, Lads_mobile_sdk/cs2;->d:Lads_mobile_sdk/vs2;

    packed-switch v0, :pswitch_data_24

    check-cast p1, Lvx;

    new-instance v0, Lads_mobile_sdk/cs2;

    const/4 v2, 0x1

    invoke-direct {v0, p0, p1, v2}, Lads_mobile_sdk/cs2;-><init>(Lads_mobile_sdk/vs2;Lvx;I)V

    invoke-virtual {v0, v1}, Lads_mobile_sdk/cs2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_16  #0x0
    check-cast p1, Lvx;

    new-instance v0, Lads_mobile_sdk/cs2;

    const/4 v2, 0x0

    invoke-direct {v0, p0, p1, v2}, Lads_mobile_sdk/cs2;-><init>(Lads_mobile_sdk/vs2;Lvx;I)V

    invoke-virtual {v0, v1}, Lads_mobile_sdk/cs2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_24
    .packed-switch 0x0
        :pswitch_16  #00000000
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 8

    .prologue
    iget v0, p0, Lads_mobile_sdk/cs2;->t:I

    iget-object v1, p0, Lads_mobile_sdk/cs2;->d:Lads_mobile_sdk/vs2;

    const-string v2, "call to \'resume\' before \'invoke\' with coroutine"

    sget-object v3, Lwy;->a:Lwy;

    const/4 v4, 0x1

    const/4 v5, 0x0

    packed-switch v0, :pswitch_data_7a

    iget v0, p0, Lads_mobile_sdk/cs2;->c:I

    if-eqz v0, :cond_20

    if-ne v0, v4, :cond_1b

    iget-object v1, p0, Lads_mobile_sdk/cs2;->b:Lads_mobile_sdk/vs2;

    iget-object p0, p0, Lads_mobile_sdk/cs2;->a:Lnb1;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_33

    :cond_1b
    invoke-static {v2}, Lz6;->w(Ljava/lang/String;)V

    move-object v3, v5

    goto :goto_3d

    :cond_20
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, v1, Lads_mobile_sdk/vs2;->e:Lnb1;

    iput-object p1, p0, Lads_mobile_sdk/cs2;->a:Lnb1;

    iput-object v1, p0, Lads_mobile_sdk/cs2;->b:Lads_mobile_sdk/vs2;

    iput v4, p0, Lads_mobile_sdk/cs2;->c:I

    invoke-virtual {p1, p0}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v3, :cond_32

    goto :goto_3d

    :cond_32
    move-object p0, p1

    :goto_33
    :try_start_33
    iget-wide v0, v1, Lads_mobile_sdk/vs2;->n:J

    new-instance v3, Lv60;

    invoke-direct {v3, v0, v1}, Lv60;-><init>(J)V
    :try_end_3a
    .catchall {:try_start_33 .. :try_end_3a} :catchall_3e

    invoke-virtual {p0, v5}, Lnb1;->b(Ljava/lang/Object;)V

    :goto_3d
    return-object v3

    :catchall_3e
    move-exception p1

    invoke-virtual {p0, v5}, Lnb1;->b(Ljava/lang/Object;)V

    throw p1

    :pswitch_43  #0x0
    iget v0, p0, Lads_mobile_sdk/cs2;->c:I

    if-eqz v0, :cond_56

    if-ne v0, v4, :cond_51

    iget-object v1, p0, Lads_mobile_sdk/cs2;->b:Lads_mobile_sdk/vs2;

    iget-object p0, p0, Lads_mobile_sdk/cs2;->a:Lnb1;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_69

    :cond_51
    invoke-static {v2}, Lz6;->w(Ljava/lang/String;)V

    move-object v3, v5

    goto :goto_73

    :cond_56
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, v1, Lads_mobile_sdk/vs2;->e:Lnb1;

    iput-object p1, p0, Lads_mobile_sdk/cs2;->a:Lnb1;

    iput-object v1, p0, Lads_mobile_sdk/cs2;->b:Lads_mobile_sdk/vs2;

    iput v4, p0, Lads_mobile_sdk/cs2;->c:I

    invoke-virtual {p1, p0}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v3, :cond_68

    goto :goto_73

    :cond_68
    move-object p0, p1

    :goto_69
    :try_start_69
    iget-wide v0, v1, Lads_mobile_sdk/vs2;->m:J

    new-instance v3, Lv60;

    invoke-direct {v3, v0, v1}, Lv60;-><init>(J)V
    :try_end_70
    .catchall {:try_start_69 .. :try_end_70} :catchall_74

    invoke-virtual {p0, v5}, Lnb1;->b(Ljava/lang/Object;)V

    :goto_73
    return-object v3

    :catchall_74
    move-exception p1

    invoke-virtual {p0, v5}, Lnb1;->b(Ljava/lang/Object;)V

    throw p1

    nop

    :pswitch_data_7a
    .packed-switch 0x0
        :pswitch_43  #00000000
    .end packed-switch
.end method
