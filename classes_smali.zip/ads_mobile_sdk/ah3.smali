.class public final Lads_mobile_sdk/ah3;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:Lads_mobile_sdk/qr0;

.field public final c:Lx43;

.field public final d:Lads_mobile_sdk/mh3;

.field public final e:Lads_mobile_sdk/kl0;

.field public final f:Lads_mobile_sdk/i41;

.field public final g:Ljava/lang/String;

.field public final h:Ljava/lang/String;

.field public final i:Lv03;

.field public final j:Lads_mobile_sdk/mi0;

.field public k:Z

.field public l:Z

.field public m:Z

.field public n:Z

.field public o:Ljava/util/Map;

.field public p:Z

.field public q:I

.field public final r:Ljava/util/HashSet;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lads_mobile_sdk/qr0;Lx43;Lads_mobile_sdk/mh3;Lads_mobile_sdk/kl0;Lads_mobile_sdk/i41;Ljava/lang/String;Ljava/lang/String;Lv03;Lads_mobile_sdk/mi0;)V
    .registers 11

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/ah3;->a:Landroid/content/Context;

    iput-object p2, p0, Lads_mobile_sdk/ah3;->b:Lads_mobile_sdk/qr0;

    iput-object p3, p0, Lads_mobile_sdk/ah3;->c:Lx43;

    iput-object p4, p0, Lads_mobile_sdk/ah3;->d:Lads_mobile_sdk/mh3;

    iput-object p5, p0, Lads_mobile_sdk/ah3;->e:Lads_mobile_sdk/kl0;

    iput-object p6, p0, Lads_mobile_sdk/ah3;->f:Lads_mobile_sdk/i41;

    iput-object p7, p0, Lads_mobile_sdk/ah3;->g:Ljava/lang/String;

    iput-object p8, p0, Lads_mobile_sdk/ah3;->h:Ljava/lang/String;

    iput-object p9, p0, Lads_mobile_sdk/ah3;->i:Lv03;

    iput-object p10, p0, Lads_mobile_sdk/ah3;->j:Lads_mobile_sdk/mi0;

    sget-object p1, Lca0;->a:Lca0;

    iput-object p1, p0, Lads_mobile_sdk/ah3;->o:Ljava/util/Map;

    new-instance p1, Ljava/util/HashSet;

    invoke-direct {p1}, Ljava/util/HashSet;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/ah3;->r:Ljava/util/HashSet;

    return-void
.end method

.method public static a(Lads_mobile_sdk/ah3;Ljava/lang/String;Lads_mobile_sdk/cb;Lwx;)Ljava/lang/Object;
    .registers 8

    .prologue
    instance-of v0, p3, Lads_mobile_sdk/tg3;

    if-eqz v0, :cond_13

    move-object v0, p3

    check-cast v0, Lads_mobile_sdk/tg3;

    iget v1, v0, Lads_mobile_sdk/tg3;->e:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/tg3;->e:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/tg3;

    invoke-direct {v0, p0, p3}, Lads_mobile_sdk/tg3;-><init>(Lads_mobile_sdk/ah3;Lwx;)V

    :goto_18
    iget-object p3, v0, Lads_mobile_sdk/tg3;->c:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/tg3;->e:I

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_32

    if-ne v1, v3, :cond_2c

    iget-object p1, v0, Lads_mobile_sdk/tg3;->b:Ljava/lang/String;

    iget-object p0, v0, Lads_mobile_sdk/tg3;->a:Lads_mobile_sdk/ah3;

    :try_start_26
    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_29
    .catch Ljava/lang/Exception; {:try_start_26 .. :try_end_29} :catch_2a

    return-object p3

    :catch_2a
    move-exception p2

    goto :goto_45

    :cond_2c
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v2

    :cond_32
    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V

    :try_start_35
    iput-object p0, v0, Lads_mobile_sdk/tg3;->a:Lads_mobile_sdk/ah3;

    iput-object p1, v0, Lads_mobile_sdk/tg3;->b:Ljava/lang/String;

    iput v3, v0, Lads_mobile_sdk/tg3;->e:I

    invoke-virtual {p2, v0}, Lads_mobile_sdk/cb;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0
    :try_end_3f
    .catch Ljava/lang/Exception; {:try_start_35 .. :try_end_3f} :catch_2a

    sget-object p1, Lwy;->a:Lwy;

    if-ne p0, p1, :cond_44

    return-object p1

    :cond_44
    return-object p0

    :goto_45
    invoke-virtual {p0, p1, p2}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-object v2
.end method


# virtual methods
.method public final a(Ljava/lang/String;Ljava/lang/Exception;)V
    .registers 13

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/ah3;->e:Lads_mobile_sdk/kl0;

    new-instance v1, Lads_mobile_sdk/ml0;

    invoke-static {}, Lads_mobile_sdk/hh3;->b()Lads_mobile_sdk/gh3;

    move-result-object v2

    iget-object v2, v2, Lads_mobile_sdk/gh3;->a:Lads_mobile_sdk/rg3;

    if-eqz v2, :cond_10

    iget-object v2, v2, Lads_mobile_sdk/rg3;->a:Lads_mobile_sdk/kh3;

    :goto_e
    move-object v4, v2

    goto :goto_12

    :cond_10
    const/4 v2, 0x0

    goto :goto_e

    :goto_12
    iget-object p0, p0, Lads_mobile_sdk/ah3;->c:Lx43;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v6

    sget v8, Lads_mobile_sdk/rl1;->b:I

    const/4 v9, 0x1

    const/4 v5, 0x1

    move-object v3, p1

    move-object v2, p2

    invoke-direct/range {v1 .. v9}, Lads_mobile_sdk/ml0;-><init>(Ljava/lang/Throwable;Ljava/lang/String;Lads_mobile_sdk/kh3;ZJIZ)V

    invoke-virtual {v0, v1}, Lads_mobile_sdk/st2;->a(Ljava/lang/Object;)V

    return-void
.end method

.method public final a(Ljava/lang/String;Ljava/lang/Throwable;)V
    .registers 13

    .prologue
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-boolean v0, p0, Lads_mobile_sdk/ah3;->l:Z

    if-eqz v0, :cond_31

    iget-object v0, p0, Lads_mobile_sdk/ah3;->e:Lads_mobile_sdk/kl0;

    new-instance v1, Lads_mobile_sdk/ml0;

    invoke-static {}, Lads_mobile_sdk/hh3;->b()Lads_mobile_sdk/gh3;

    move-result-object v2

    iget-object v2, v2, Lads_mobile_sdk/gh3;->a:Lads_mobile_sdk/rg3;

    if-eqz v2, :cond_1a

    iget-object v2, v2, Lads_mobile_sdk/rg3;->a:Lads_mobile_sdk/kh3;

    :goto_18
    move-object v4, v2

    goto :goto_1c

    :cond_1a
    const/4 v2, 0x0

    goto :goto_18

    :goto_1c
    iget-object p0, p0, Lads_mobile_sdk/ah3;->c:Lx43;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v6

    sget v8, Lads_mobile_sdk/rl1;->b:I

    const/4 v9, 0x0

    const/4 v5, 0x1

    move-object v3, p1

    move-object v2, p2

    invoke-direct/range {v1 .. v9}, Lads_mobile_sdk/ml0;-><init>(Ljava/lang/Throwable;Ljava/lang/String;Lads_mobile_sdk/kh3;ZJIZ)V

    invoke-virtual {v0, v1}, Lads_mobile_sdk/st2;->a(Ljava/lang/Object;)V

    :cond_31
    return-void
.end method

.method public final a(Ljava/lang/Throwable;)V
    .registers 14

    .prologue
    iget-boolean v0, p0, Lads_mobile_sdk/ah3;->p:Z

    if-nez v0, :cond_6

    goto/16 :goto_c0

    :cond_6
    invoke-static {p1}, Lnp3;->n(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    move-result-object v0

    const/4 v1, 0x0

    move v2, v1

    :goto_c
    if-eqz v0, :cond_85

    invoke-virtual {v0}, Ljava/lang/Throwable;->getStackTrace()[Ljava/lang/StackTraceElement;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    array-length v4, v3

    move v5, v1

    :goto_17
    if-ge v5, v4, :cond_78

    aget-object v6, v3, v5

    const-class v7, Lads_mobile_sdk/ah3;

    invoke-virtual {v7}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6}, Ljava/lang/StackTraceElement;->getClassName()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_2d

    goto/16 :goto_c0

    :cond_2d
    invoke-virtual {v6}, Ljava/lang/StackTraceElement;->getClassName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v7, p0, Lads_mobile_sdk/ah3;->b:Lads_mobile_sdk/qr0;

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v8, "org.chromium"

    const-string v9, "android.webkit"

    const-string v10, "com.google"

    const-string v11, "ads_mobile_sdk"

    filled-new-array {v10, v11, v8, v9}, [Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Lcs;->U([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v8

    sget-object v9, Lads_mobile_sdk/fo;->a$15:Lads_mobile_sdk/fo;

    const-string v10, "gads:uncaught_exception_handler_prefix"

    invoke-virtual {v7, v10, v8, v9}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/util/List;

    instance-of v8, v7, Ljava/util/Collection;

    if-eqz v8, :cond_5e

    invoke-interface {v7}, Ljava/util/Collection;->isEmpty()Z

    move-result v8

    if-eqz v8, :cond_5e

    goto :goto_75

    :cond_5e
    invoke-interface {v7}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :cond_62
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_75

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    invoke-static {v6, v8, v1}, Lk72;->k0(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v8

    if-eqz v8, :cond_62

    const/4 v2, 0x1

    :cond_75
    :goto_75
    add-int/lit8 v5, v5, 0x1

    goto :goto_17

    :cond_78
    invoke-virtual {v0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v0

    if-eqz v0, :cond_83

    invoke-static {v0}, Lnp3;->n(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    move-result-object v0

    goto :goto_c

    :cond_83
    const/4 v0, 0x0

    goto :goto_c

    :cond_85
    if-nez v2, :cond_88

    goto :goto_c0

    :cond_88
    iget v0, p0, Lads_mobile_sdk/ah3;->q:I

    if-lez v0, :cond_c4

    iget-object v0, p0, Lads_mobile_sdk/ah3;->r:Ljava/util/HashSet;

    invoke-virtual {v0}, Ljava/util/HashSet;->size()I

    move-result v1

    iget v2, p0, Lads_mobile_sdk/ah3;->q:I

    if-lt v1, v2, :cond_97

    goto :goto_c0

    :cond_97
    invoke-static {p1}, Lnp3;->n(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v2, Ljava/io/StringWriter;

    invoke-direct {v2}, Ljava/io/StringWriter;-><init>()V

    new-instance v3, Ljava/io/PrintWriter;

    invoke-direct {v3, v2}, Ljava/io/PrintWriter;-><init>(Ljava/io/Writer;)V

    invoke-virtual {v1, v3}, Ljava/lang/Throwable;->printStackTrace(Ljava/io/PrintWriter;)V

    invoke-virtual {v2}, Ljava/io/StringWriter;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v1}, Lnp3;->m(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_ba

    const-string v1, ""

    :cond_ba
    invoke-virtual {v0, v1}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_c1

    :goto_c0
    return-void

    :cond_c1
    invoke-virtual {v0, v1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    :cond_c4
    invoke-virtual {p0, p1}, Lads_mobile_sdk/ah3;->b(Ljava/lang/Throwable;)V

    return-void
.end method

.method public final a(Lvy;)V
    .registers 24

    .prologue
    move-object/from16 v0, p0

    sget-object v2, Lads_mobile_sdk/fo;->a$7:Lads_mobile_sdk/fo;

    const-wide v3, 0x3fb999999999999aL  # 0.1

    invoke-static {v3, v4}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v3

    const-wide v4, 0x3f9eb851eb851eb8L  # 0.03

    invoke-static {v4, v5}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v4

    invoke-virtual/range {p1 .. p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v5, v0, Lads_mobile_sdk/ah3;->j:Lads_mobile_sdk/mi0;

    invoke-virtual {v5}, Lads_mobile_sdk/mi0;->b()V

    sput-object v0, Lads_mobile_sdk/nw;->a:Lads_mobile_sdk/ah3;

    iget-object v6, v0, Lads_mobile_sdk/ah3;->b:Lads_mobile_sdk/qr0;

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v7, v6, Lads_mobile_sdk/ov;->a:Ljava/lang/Object;

    check-cast v7, Ld03;

    const/16 v8, 0xa

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    sget-object v9, Lads_mobile_sdk/fo;->a$11:Lads_mobile_sdk/fo;

    const-string v10, "gads:max_duplicate_crash:amount"

    invoke-virtual {v6, v10, v8, v9}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/Number;

    invoke-virtual {v8}, Ljava/lang/Number;->intValue()I

    move-result v8

    iput v8, v0, Lads_mobile_sdk/ah3;->q:I

    iget-object v8, v0, Lads_mobile_sdk/ah3;->a:Landroid/content/Context;

    invoke-virtual {v8}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v10

    const/16 v11, 0x80

    if-eqz v10, :cond_5c

    invoke-virtual {v8}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v10, v12, v11}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v10

    if-eqz v10, :cond_5c

    iget-object v10, v10, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;

    if-eqz v10, :cond_5c

    goto :goto_5e

    :cond_5c
    const-string v10, ""

    :goto_5e
    :try_start_5e
    invoke-virtual {v8}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v12

    if-eqz v12, :cond_79

    invoke-virtual {v8}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v12, v8, v11}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    move-result-object v8

    if-eqz v8, :cond_79

    iget-object v8, v8, Landroid/content/pm/ApplicationInfo;->metaData:Landroid/os/Bundle;

    if-eqz v8, :cond_79

    const-string v11, "com.google.unity.ads.UNITY_VERSION"

    invoke-virtual {v8, v11}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8
    :try_end_78
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_5e .. :try_end_78} :catch_79

    goto :goto_7a

    :catch_79
    :cond_79
    const/4 v8, 0x0

    :goto_7a
    invoke-static {}, Lads_mobile_sdk/nw0;->o()Law2;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v11}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v12, v11, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v12, Lads_mobile_sdk/nw0;

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v13, 0x1

    invoke-static {v12, v13}, Lads_mobile_sdk/nw0;->D(Lads_mobile_sdk/nw0;I)V

    sget-object v12, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v11}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v14, v11, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v14, Lads_mobile_sdk/nw0;

    invoke-virtual {v14}, Lads_mobile_sdk/nw0;->q()V

    sget-object v14, Landroid/os/Build;->MODEL:Ljava/lang/String;

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v11}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v15, v11, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v15, Lads_mobile_sdk/nw0;

    invoke-virtual {v15, v14}, Lads_mobile_sdk/nw0;->l(Ljava/lang/String;)V

    sget v15, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-virtual {v11}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v13, v11, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v13, Lads_mobile_sdk/nw0;

    invoke-static {v13, v15}, Lads_mobile_sdk/nw0;->P(Lads_mobile_sdk/nw0;I)V

    iget-object v13, v0, Lads_mobile_sdk/ah3;->g:Ljava/lang/String;

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v11}, Lads_mobile_sdk/iu0;->b$1()V

    move-object/from16 v17, v7

    iget-object v7, v11, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v7, Lads_mobile_sdk/nw0;

    invoke-virtual {v7, v13}, Lads_mobile_sdk/nw0;->z(Ljava/lang/String;)V

    iget-object v7, v0, Lads_mobile_sdk/ah3;->h:Ljava/lang/String;

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v11}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v1, v11, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v1, Lads_mobile_sdk/nw0;

    invoke-virtual {v1, v7}, Lads_mobile_sdk/nw0;->h(Ljava/lang/String;)V

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v11}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v1, v11, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v1, Lads_mobile_sdk/nw0;

    invoke-virtual {v1, v9}, Lads_mobile_sdk/nw0;->e(Ljava/lang/String;)V

    invoke-virtual {v11}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v1, v11, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v1, Lads_mobile_sdk/nw0;

    invoke-virtual {v1, v10}, Lads_mobile_sdk/nw0;->f(Ljava/lang/String;)V

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v1

    invoke-virtual {v1}, Ljava/util/Locale;->getCountry()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v11}, Lads_mobile_sdk/iu0;->b$1()V

    move-object/from16 v18, v3

    iget-object v3, v11, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v3, Lads_mobile_sdk/nw0;

    invoke-virtual {v3, v1}, Lads_mobile_sdk/nw0;->j(Ljava/lang/String;)V

    iget-object v1, v0, Lads_mobile_sdk/ah3;->f:Lads_mobile_sdk/i41;

    invoke-virtual {v1}, Lads_mobile_sdk/i41;->a()Lfm0;

    iget-object v3, v5, Lads_mobile_sdk/mi0;->b:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v3}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v3, Lads_mobile_sdk/wh0;

    invoke-virtual {v11}, Lads_mobile_sdk/iu0;->b$1()V

    move-object/from16 v19, v1

    iget-object v1, v11, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v1, Lads_mobile_sdk/nw0;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v3}, Lads_mobile_sdk/wh0;->getNumber()I

    move-result v3

    invoke-static {v1, v3}, Lads_mobile_sdk/nw0;->o(Lads_mobile_sdk/nw0;I)V

    iget-object v1, v5, Lads_mobile_sdk/mi0;->c:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v1, Lads_mobile_sdk/yh0;

    invoke-virtual {v11}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v3, v11, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v3, Lads_mobile_sdk/nw0;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Lads_mobile_sdk/yh0;->getNumber()I

    move-result v1

    invoke-static {v3, v1}, Lads_mobile_sdk/nw0;->q(Lads_mobile_sdk/nw0;I)V

    invoke-virtual {v5}, Lads_mobile_sdk/mi0;->a()Lads_mobile_sdk/xh0;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v11}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v3, v11, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v3, Lads_mobile_sdk/nw0;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Lads_mobile_sdk/xh0;->getNumber()I

    move-result v1

    invoke-static {v3, v1}, Lads_mobile_sdk/nw0;->p(Lads_mobile_sdk/nw0;I)V

    move-object/from16 v1, v17

    check-cast v1, Lads_mobile_sdk/eo;

    iget-boolean v1, v1, Lads_mobile_sdk/eo;->r:Z

    invoke-virtual {v11}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v3, v11, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v3, Lads_mobile_sdk/nw0;

    invoke-static {v3, v1}, Lads_mobile_sdk/nw0;->v(Lads_mobile_sdk/nw0;Z)V

    move-object/from16 v1, v17

    check-cast v1, Lads_mobile_sdk/eo;

    iget-boolean v1, v1, Lads_mobile_sdk/eo;->p:Z

    invoke-virtual {v11}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v3, v11, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v3, Lads_mobile_sdk/nw0;

    invoke-static {v3, v1}, Lads_mobile_sdk/nw0;->u(Lads_mobile_sdk/nw0;Z)V

    move-object/from16 v1, v17

    check-cast v1, Lads_mobile_sdk/eo;

    iget-boolean v1, v1, Lads_mobile_sdk/eo;->q:Z

    invoke-virtual {v11}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v3, v11, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v3, Lads_mobile_sdk/nw0;

    invoke-static {v3, v1}, Lads_mobile_sdk/nw0;->U(Lads_mobile_sdk/nw0;Z)V

    if-eqz v8, :cond_19a

    invoke-virtual {v11}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v1, v11, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v1, Lads_mobile_sdk/nw0;

    invoke-virtual {v1, v8}, Lads_mobile_sdk/nw0;->E(Ljava/lang/String;)V

    :cond_19a
    invoke-virtual {v11}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object v1

    check-cast v1, Lads_mobile_sdk/nw0;

    invoke-static {}, Lads_mobile_sdk/tv0;->p()Lm33;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v3}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v5, v3, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v5, Lads_mobile_sdk/tv0;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v11, 0x2

    invoke-static {v11}, Lmz2;->f(I)I

    move-result v11

    invoke-static {v5, v11}, Lads_mobile_sdk/tv0;->z(Lads_mobile_sdk/tv0;I)V

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v3}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v5, v3, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v5, Lads_mobile_sdk/tv0;

    invoke-virtual {v5, v12}, Lads_mobile_sdk/tv0;->p(Ljava/lang/String;)V

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v3}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v5, v3, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v5, Lads_mobile_sdk/tv0;

    invoke-virtual {v5, v14}, Lads_mobile_sdk/tv0;->j(Ljava/lang/String;)V

    invoke-virtual {v3}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v5, v3, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v5, Lads_mobile_sdk/tv0;

    invoke-static {v5, v15}, Lads_mobile_sdk/tv0;->B(Lads_mobile_sdk/tv0;I)V

    invoke-virtual {v3}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v5, v3, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v5, Lads_mobile_sdk/tv0;

    invoke-virtual {v5, v7}, Lads_mobile_sdk/tv0;->t(Ljava/lang/String;)V

    invoke-virtual {v3}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v5, v3, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v5, Lads_mobile_sdk/tv0;

    invoke-virtual {v5, v13}, Lads_mobile_sdk/tv0;->d(Ljava/lang/String;)V

    invoke-virtual {v3}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v5, v3, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v5, Lads_mobile_sdk/tv0;

    invoke-virtual {v5, v9}, Lads_mobile_sdk/tv0;->f(Ljava/lang/String;)V

    invoke-virtual {v3}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v5, v3, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v5, Lads_mobile_sdk/tv0;

    invoke-virtual {v5, v10}, Lads_mobile_sdk/tv0;->g(Ljava/lang/String;)V

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v5

    invoke-virtual {v5}, Ljava/util/Locale;->getCountry()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v3}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v7, v3, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v7, Lads_mobile_sdk/tv0;

    invoke-virtual {v7, v5}, Lads_mobile_sdk/tv0;->i(Ljava/lang/String;)V

    if-eqz v8, :cond_226

    invoke-virtual {v3}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v5, v3, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v5, Lads_mobile_sdk/tv0;

    invoke-virtual {v5, v8}, Lads_mobile_sdk/tv0;->y(Ljava/lang/String;)V

    :cond_226
    invoke-virtual/range {v19 .. v19}, Lads_mobile_sdk/i41;->a()Lfm0;

    invoke-virtual {v3}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object v3

    check-cast v3, Lads_mobile_sdk/tv0;

    sget-object v5, Lpp1;->a:Lv0;

    invoke-virtual {v5}, Lpp1;->g()D

    move-result-wide v7

    const-string v9, "gads:cui_monitoring_session_sample_rate"

    invoke-virtual {v6, v9, v4, v2}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/Number;

    invoke-virtual {v10}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v10

    cmpg-double v7, v7, v10

    const/4 v8, 0x0

    if-gez v7, :cond_248

    const/4 v7, 0x1

    goto :goto_249

    :cond_248
    move v7, v8

    :goto_249
    iput-boolean v7, v0, Lads_mobile_sdk/ah3;->k:Z

    invoke-virtual {v5}, Lpp1;->g()D

    move-result-wide v10

    const-string v7, "gads:trapped_exception_monitoring_session_sample_rate"

    invoke-virtual {v6, v7, v4, v2}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/Number;

    invoke-virtual {v12}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v12

    cmpg-double v10, v10, v12

    if-gez v10, :cond_261

    const/4 v10, 0x1

    goto :goto_262

    :cond_261
    move v10, v8

    :goto_262
    iput-boolean v10, v0, Lads_mobile_sdk/ah3;->l:Z

    invoke-virtual {v5}, Lpp1;->g()D

    move-result-wide v10

    const-string v12, "gads:untrapped_exception_monitoring_session_sample_rate"

    move-object/from16 v13, v18

    invoke-virtual {v6, v12, v13, v2}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/lang/Number;

    invoke-virtual {v14}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v14

    cmpg-double v10, v10, v14

    if-gez v10, :cond_27c

    const/4 v10, 0x1

    goto :goto_27d

    :cond_27c
    move v10, v8

    :goto_27d
    iput-boolean v10, v0, Lads_mobile_sdk/ah3;->m:Z

    invoke-virtual {v5}, Lpp1;->g()D

    move-result-wide v10

    const-wide v14, 0x3f847ae147ae147bL  # 0.01

    invoke-static {v14, v15}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v5

    const-string v14, "gads:cui_monitoring_trace_failure_stacktrace_rate"

    invoke-virtual {v6, v14, v5, v2}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Number;

    invoke-virtual {v5}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v14

    cmpg-double v5, v10, v14

    if-gez v5, :cond_29e

    const/4 v5, 0x1

    goto :goto_29f

    :cond_29e
    move v5, v8

    :goto_29f
    iput-boolean v5, v0, Lads_mobile_sdk/ah3;->n:Z

    invoke-virtual {v6}, Lads_mobile_sdk/qr0;->h0()Ljava/util/Map;

    move-result-object v5

    new-instance v10, Ljava/util/LinkedHashMap;

    invoke-interface {v5}, Ljava/util/Map;->size()I

    move-result v11

    invoke-static {v11}, Lb61;->Q(I)I

    move-result v11

    invoke-direct {v10, v11}, Ljava/util/LinkedHashMap;-><init>(I)V

    invoke-interface {v5}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v5

    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_2ba
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_2e9

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/util/Map$Entry;

    invoke-interface {v11}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v14

    sget-object v15, Lpp1;->a:Lv0;

    invoke-virtual {v15}, Lpp1;->g()D

    move-result-wide v17

    invoke-interface {v11}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/Number;

    invoke-virtual {v11}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v20

    cmpg-double v11, v17, v20

    if-gez v11, :cond_2e0

    const/4 v11, 0x1

    goto :goto_2e1

    :cond_2e0
    move v11, v8

    :goto_2e1
    invoke-static {v11}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v11

    invoke-interface {v10, v14, v11}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_2ba

    :cond_2e9
    iput-object v10, v0, Lads_mobile_sdk/ah3;->o:Ljava/util/Map;

    iget-object v5, v0, Lads_mobile_sdk/ah3;->i:Lv03;

    invoke-interface {v5}, Lv03;->get()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lads_mobile_sdk/ws;

    invoke-virtual {v6, v9, v4, v2}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/Number;

    invoke-virtual {v8}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v8

    iget-object v10, v0, Lads_mobile_sdk/ah3;->d:Lads_mobile_sdk/mh3;

    iput-wide v8, v10, Lads_mobile_sdk/mh3;->l:D

    invoke-virtual {v6}, Lads_mobile_sdk/qr0;->h0()Ljava/util/Map;

    move-result-object v8

    iput-object v8, v10, Lads_mobile_sdk/mh3;->m:Ljava/util/Map;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-object/from16 v8, p1

    invoke-virtual {v10, v8, v1, v5}, Lads_mobile_sdk/st2;->a(Lvy;Lads_mobile_sdk/ku0;Lads_mobile_sdk/ws;)V

    iget-object v1, v0, Lads_mobile_sdk/ah3;->e:Lads_mobile_sdk/kl0;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v9, v1, Lads_mobile_sdk/st2;->c:Lads_mobile_sdk/qr0;

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v9, v7, v4, v2}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/Number;

    invoke-virtual {v10}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v10

    const-wide/16 v14, 0x0

    cmpl-double v10, v10, v14

    const-wide/high16 v16, 0x3ff0000000000000L  # 1.0

    if-lez v10, :cond_33a

    invoke-virtual {v9, v7, v4, v2}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Number;

    invoke-virtual {v4}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v10

    div-double v10, v16, v10

    double-to-long v10, v10

    iput-wide v10, v1, Lads_mobile_sdk/kl0;->l:J

    :cond_33a
    invoke-virtual {v9, v12, v13, v2}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/Number;

    invoke-virtual {v4}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v10

    cmpl-double v4, v10, v14

    if-lez v4, :cond_357

    invoke-virtual {v9, v12, v13, v2}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v9

    div-double v9, v16, v9

    double-to-long v9, v9

    iput-wide v9, v1, Lads_mobile_sdk/kl0;->m:J

    :cond_357
    invoke-virtual {v1, v8, v3, v5}, Lads_mobile_sdk/st2;->a(Lvy;Lads_mobile_sdk/ku0;Lads_mobile_sdk/ws;)V

    invoke-virtual/range {v19 .. v19}, Lads_mobile_sdk/i41;->a()Lfm0;

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sget-object v2, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    const-string v3, "gads:uncaught_exception_handler"

    invoke-virtual {v6, v3, v1, v2}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    iput-boolean v1, v0, Lads_mobile_sdk/ah3;->p:Z

    if-eqz v1, :cond_394

    invoke-static {}, Ljava/lang/Thread;->getDefaultUncaughtExceptionHandler()Ljava/lang/Thread$UncaughtExceptionHandler;

    move-result-object v1

    new-instance v2, Ljt2;

    invoke-direct {v2, v0, v1}, Ljt2;-><init>(Lads_mobile_sdk/ah3;Ljava/lang/Thread$UncaughtExceptionHandler;)V

    invoke-static {v2}, Ljava/lang/Thread;->setDefaultUncaughtExceptionHandler(Ljava/lang/Thread$UncaughtExceptionHandler;)V

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-virtual {v1}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/Thread;->getUncaughtExceptionHandler()Ljava/lang/Thread$UncaughtExceptionHandler;

    move-result-object v2

    new-instance v3, Lads_mobile_sdk/vg3;

    invoke-direct {v3, v0, v2}, Lads_mobile_sdk/vg3;-><init>(Lads_mobile_sdk/ah3;Ljava/lang/Thread$UncaughtExceptionHandler;)V

    invoke-virtual {v1, v3}, Ljava/lang/Thread;->setUncaughtExceptionHandler(Ljava/lang/Thread$UncaughtExceptionHandler;)V

    :cond_394
    return-void
.end method

.method public final b(Ljava/lang/Throwable;)V
    .registers 15

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-boolean v0, p0, Lads_mobile_sdk/ah3;->m:Z

    if-eqz v0, :cond_74

    const/4 v0, 0x0

    move-object v1, p1

    move v2, v0

    move v3, v2

    :goto_b
    if-eqz v1, :cond_55

    invoke-virtual {v1}, Ljava/lang/Throwable;->getStackTrace()[Ljava/lang/StackTraceElement;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    array-length v5, v4

    move v6, v0

    :goto_16
    if-ge v6, v5, :cond_50

    aget-object v7, v4, v6

    invoke-virtual {v7}, Ljava/lang/StackTraceElement;->getClassName()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v9, "com.google.android.libraries.ads.mobile.sdk"

    invoke-static {v8, v9, v0}, Lk72;->k0(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v8

    const/4 v9, 0x1

    if-eqz v8, :cond_2b

    move v2, v9

    :cond_2b
    invoke-virtual {v7}, Ljava/lang/StackTraceElement;->getClassName()Ljava/lang/String;

    move-result-object v8

    const-class v10, Lads_mobile_sdk/ah3;

    invoke-virtual {v10}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v10

    invoke-static {v8, v10}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_4f

    invoke-virtual {v7}, Ljava/lang/StackTraceElement;->getClassName()Ljava/lang/String;

    move-result-object v7

    const-class v8, Lads_mobile_sdk/kl0;

    invoke-virtual {v8}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v8

    invoke-static {v7, v8}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_4c

    goto :goto_4f

    :cond_4c
    add-int/lit8 v6, v6, 0x1

    goto :goto_16

    :cond_4f
    :goto_4f
    move v3, v9

    :cond_50
    invoke-virtual {v1}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v1

    goto :goto_b

    :cond_55
    if-eqz v2, :cond_74

    if-nez v3, :cond_74

    new-instance v4, Lads_mobile_sdk/ml0;

    iget-object v0, p0, Lads_mobile_sdk/ah3;->c:Lx43;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v9

    sget v11, Lads_mobile_sdk/rl1;->b:I

    const/4 v12, 0x0

    const-string v6, "UNTRAPPED_EXCEPTION"

    const/4 v7, 0x0

    const/4 v8, 0x0

    move-object v5, p1

    invoke-direct/range {v4 .. v12}, Lads_mobile_sdk/ml0;-><init>(Ljava/lang/Throwable;Ljava/lang/String;Lads_mobile_sdk/kh3;ZJIZ)V

    iget-object p1, p0, Lads_mobile_sdk/ah3;->e:Lads_mobile_sdk/kl0;

    invoke-virtual {p1, v4}, Lads_mobile_sdk/st2;->a(Ljava/lang/Object;)V

    :cond_74
    sget-object p1, Lxf1;->b:Lxf1;

    new-instance v0, Lads_mobile_sdk/x;

    const/16 v1, 0xd

    const/4 v2, 0x0

    invoke-direct {v0, p0, v2, v1}, Lads_mobile_sdk/x;-><init>(Ljava/lang/Object;Lvx;I)V

    invoke-static {p1, v0}, Lw53;->Q(Lly;Lpk0;)Ljava/lang/Object;

    return-void
.end method
