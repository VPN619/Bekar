.class public abstract Lads_mobile_sdk/bl1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lg33;


# instance fields
.field public final a:Lads_mobile_sdk/ux2;

.field public final b:Lads_mobile_sdk/kh3;

.field public final c:Lads_mobile_sdk/ax0;

.field public final d:Lvy;

.field public final e:Lads_mobile_sdk/qr0;

.field public final f:Lnb1;

.field public final g:Ljava/util/LinkedHashMap;

.field public final h:Ljava/util/LinkedHashMap;

.field public final i:Lads_mobile_sdk/ft1;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/ux2;Lads_mobile_sdk/kh3;Lads_mobile_sdk/ax0;Lvy;Lads_mobile_sdk/qr0;)V
    .registers 6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/bl1;->a:Lads_mobile_sdk/ux2;

    iput-object p2, p0, Lads_mobile_sdk/bl1;->b:Lads_mobile_sdk/kh3;

    iput-object p3, p0, Lads_mobile_sdk/bl1;->c:Lads_mobile_sdk/ax0;

    iput-object p4, p0, Lads_mobile_sdk/bl1;->d:Lvy;

    iput-object p5, p0, Lads_mobile_sdk/bl1;->e:Lads_mobile_sdk/qr0;

    new-instance p1, Lnb1;

    invoke-direct {p1}, Lnb1;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/bl1;->f:Lnb1;

    new-instance p1, Ljava/util/LinkedHashMap;

    invoke-direct {p1}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/bl1;->g:Ljava/util/LinkedHashMap;

    new-instance p1, Ljava/util/LinkedHashMap;

    invoke-direct {p1}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/bl1;->h:Ljava/util/LinkedHashMap;

    new-instance p1, Lads_mobile_sdk/ft1;

    const/4 p2, 0x0

    invoke-direct {p1, p2}, Lads_mobile_sdk/ft1;-><init>(Ljava/lang/Object;)V

    iput-object p1, p0, Lads_mobile_sdk/bl1;->i:Lads_mobile_sdk/ft1;

    return-void
.end method

.method public static a(Lads_mobile_sdk/bl1;Lads_mobile_sdk/cy0;Landroid/net/Uri;Lwx;)Ljava/lang/Object;
    .registers 31

    .prologue
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    sget-object v4, Lrg2;->a:Lrg2;

    const-string v5, "GMSG handler for: "

    instance-of v6, v3, Lads_mobile_sdk/tk1;

    if-eqz v6, :cond_1f

    move-object v6, v3

    check-cast v6, Lads_mobile_sdk/tk1;

    iget v7, v6, Lads_mobile_sdk/tk1;->j:I

    const/high16 v8, -0x80000000

    and-int v9, v7, v8

    if-eqz v9, :cond_1f

    sub-int/2addr v7, v8

    iput v7, v6, Lads_mobile_sdk/tk1;->j:I

    goto :goto_24

    :cond_1f
    new-instance v6, Lads_mobile_sdk/tk1;

    invoke-direct {v6, v0, v3}, Lads_mobile_sdk/tk1;-><init>(Lads_mobile_sdk/bl1;Lwx;)V

    :goto_24
    iget-object v3, v6, Lads_mobile_sdk/tk1;->h:Ljava/lang/Object;

    sget-object v7, Lwy;->a:Lwy;

    iget v8, v6, Lads_mobile_sdk/tk1;->j:I

    const/4 v9, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x2

    const/4 v13, 0x0

    if-eqz v8, :cond_8e

    if-eq v8, v9, :cond_73

    if-eq v8, v12, :cond_5b

    if-eq v8, v11, :cond_43

    if-ne v8, v10, :cond_3d

    invoke-static {v3}, Lt12;->W(Ljava/lang/Object;)V

    return-object v4

    :cond_3d
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {v0}, Lz6;->w(Ljava/lang/String;)V

    return-object v13

    :cond_43
    iget-object v0, v6, Lads_mobile_sdk/tk1;->g:Lnb1;

    iget-object v1, v6, Lads_mobile_sdk/tk1;->f:Lvr1;

    iget-object v2, v6, Lads_mobile_sdk/tk1;->e:Ljava/lang/String;

    iget-object v5, v6, Lads_mobile_sdk/tk1;->d:Ljava/lang/String;

    iget-object v8, v6, Lads_mobile_sdk/tk1;->c:Landroid/net/Uri;

    iget-object v12, v6, Lads_mobile_sdk/tk1;->b:Lads_mobile_sdk/cy0;

    iget-object v14, v6, Lads_mobile_sdk/tk1;->a:Lads_mobile_sdk/bl1;

    invoke-static {v3}, Lt12;->W(Ljava/lang/Object;)V

    move-object v3, v8

    move-object v8, v2

    move-object v2, v3

    move-object v3, v5

    move-object v5, v0

    goto/16 :goto_176

    :cond_5b
    iget-object v0, v6, Lads_mobile_sdk/tk1;->g:Lnb1;

    iget-object v1, v6, Lads_mobile_sdk/tk1;->f:Lvr1;

    iget-object v2, v6, Lads_mobile_sdk/tk1;->e:Ljava/lang/String;

    iget-object v8, v6, Lads_mobile_sdk/tk1;->d:Ljava/lang/String;

    iget-object v12, v6, Lads_mobile_sdk/tk1;->c:Landroid/net/Uri;

    iget-object v14, v6, Lads_mobile_sdk/tk1;->b:Lads_mobile_sdk/cy0;

    iget-object v15, v6, Lads_mobile_sdk/tk1;->a:Lads_mobile_sdk/bl1;

    invoke-static {v3}, Lt12;->W(Ljava/lang/Object;)V

    move-object/from16 v26, v1

    move-object v1, v0

    move-object/from16 v0, v26

    goto/16 :goto_105

    :cond_73
    iget-object v0, v6, Lads_mobile_sdk/tk1;->f:Lvr1;

    iget-object v1, v6, Lads_mobile_sdk/tk1;->e:Ljava/lang/String;

    iget-object v2, v6, Lads_mobile_sdk/tk1;->d:Ljava/lang/String;

    iget-object v5, v6, Lads_mobile_sdk/tk1;->c:Landroid/net/Uri;

    iget-object v8, v6, Lads_mobile_sdk/tk1;->b:Lads_mobile_sdk/cy0;

    iget-object v12, v6, Lads_mobile_sdk/tk1;->a:Lads_mobile_sdk/bl1;

    invoke-static {v3}, Lt12;->W(Ljava/lang/Object;)V

    move-object/from16 v26, v8

    move-object v8, v1

    move-object/from16 v1, v26

    move-object/from16 v26, v3

    move-object v3, v2

    move-object v2, v5

    move-object/from16 v5, v26

    goto :goto_ce

    :cond_8e
    invoke-static {v3}, Lt12;->W(Ljava/lang/Object;)V

    invoke-virtual {v2}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object v3

    if-nez v3, :cond_99

    goto/16 :goto_20b

    :cond_99
    const-string v8, "ad_mid"

    invoke-virtual {v2, v8}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    new-instance v14, Lvr1;

    invoke-direct {v14}, Ljava/lang/Object;-><init>()V

    const-string v15, "Unknown/Unexpected GMSG without a handler: "

    invoke-virtual {v15, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    iput-object v15, v14, Lvr1;->a:Ljava/lang/Object;

    const-string v15, "/result"

    invoke-virtual {v3, v15}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v15

    if-eqz v15, :cond_d9

    iget-object v5, v0, Lads_mobile_sdk/bl1;->i:Lads_mobile_sdk/ft1;

    iput-object v0, v6, Lads_mobile_sdk/tk1;->a:Lads_mobile_sdk/bl1;

    iput-object v1, v6, Lads_mobile_sdk/tk1;->b:Lads_mobile_sdk/cy0;

    iput-object v2, v6, Lads_mobile_sdk/tk1;->c:Landroid/net/Uri;

    iput-object v3, v6, Lads_mobile_sdk/tk1;->d:Ljava/lang/String;

    iput-object v8, v6, Lads_mobile_sdk/tk1;->e:Ljava/lang/String;

    iput-object v14, v6, Lads_mobile_sdk/tk1;->f:Lvr1;

    iput v9, v6, Lads_mobile_sdk/tk1;->j:I

    invoke-virtual {v5, v6}, Lads_mobile_sdk/ft1;->a(Lwx;)Ljava/lang/Object;

    move-result-object v5

    if-ne v5, v7, :cond_cc

    goto/16 :goto_1cb

    :cond_cc
    move-object v12, v0

    move-object v0, v14

    :goto_ce
    check-cast v5, Lbw2;

    move-object/from16 v17, v1

    move-object/from16 v18, v2

    move-object/from16 v16, v5

    move-object v15, v12

    goto/16 :goto_189

    :cond_d9
    if-eqz v8, :cond_15a

    invoke-static {v8}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v15

    if-eqz v15, :cond_e3

    goto/16 :goto_15a

    :cond_e3
    iget-object v15, v0, Lads_mobile_sdk/bl1;->f:Lnb1;

    iput-object v0, v6, Lads_mobile_sdk/tk1;->a:Lads_mobile_sdk/bl1;

    iput-object v1, v6, Lads_mobile_sdk/tk1;->b:Lads_mobile_sdk/cy0;

    iput-object v2, v6, Lads_mobile_sdk/tk1;->c:Landroid/net/Uri;

    iput-object v3, v6, Lads_mobile_sdk/tk1;->d:Ljava/lang/String;

    iput-object v8, v6, Lads_mobile_sdk/tk1;->e:Ljava/lang/String;

    iput-object v14, v6, Lads_mobile_sdk/tk1;->f:Lvr1;

    iput-object v15, v6, Lads_mobile_sdk/tk1;->g:Lnb1;

    iput v12, v6, Lads_mobile_sdk/tk1;->j:I

    invoke-virtual {v15, v6}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v12

    if-ne v12, v7, :cond_fd

    goto/16 :goto_1cb

    :cond_fd
    move-object v12, v15

    move-object v15, v0

    move-object v0, v14

    move-object v14, v1

    move-object v1, v12

    move-object v12, v2

    move-object v2, v8

    move-object v8, v3

    :goto_105
    :try_start_105
    iget-object v3, v15, Lads_mobile_sdk/bl1;->h:Ljava/util/LinkedHashMap;

    invoke-virtual {v3, v2}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/util/Map;

    if-eqz v3, :cond_118

    invoke-interface {v3, v8}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/ref/WeakReference;

    goto :goto_119

    :catchall_116
    move-exception v0

    goto :goto_156

    :cond_118
    move-object v3, v13

    :goto_119
    if-eqz v3, :cond_134

    invoke-virtual {v3}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v16

    if-nez v16, :cond_134

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, " has been garbage collected"

    invoke-virtual {v9, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    iput-object v5, v0, Lvr1;->a:Ljava/lang/Object;

    :cond_134
    if-eqz v3, :cond_141

    invoke-virtual {v3}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lbw2;

    if-nez v3, :cond_13f

    goto :goto_141

    :cond_13f
    :goto_13f
    move-object v5, v3

    goto :goto_14a

    :cond_141
    :goto_141
    iget-object v3, v15, Lads_mobile_sdk/bl1;->g:Ljava/util/LinkedHashMap;

    invoke-virtual {v3, v8}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lbw2;
    :try_end_149
    .catchall {:try_start_105 .. :try_end_149} :catchall_116

    goto :goto_13f

    :goto_14a
    invoke-virtual {v1, v13}, Lnb1;->b(Ljava/lang/Object;)V

    move-object/from16 v16, v5

    move-object v3, v8

    move-object/from16 v18, v12

    move-object/from16 v17, v14

    move-object v8, v2

    goto :goto_189

    :goto_156
    invoke-virtual {v1, v13}, Lnb1;->b(Ljava/lang/Object;)V

    throw v0

    :cond_15a
    :goto_15a
    iget-object v5, v0, Lads_mobile_sdk/bl1;->f:Lnb1;

    iput-object v0, v6, Lads_mobile_sdk/tk1;->a:Lads_mobile_sdk/bl1;

    iput-object v1, v6, Lads_mobile_sdk/tk1;->b:Lads_mobile_sdk/cy0;

    iput-object v2, v6, Lads_mobile_sdk/tk1;->c:Landroid/net/Uri;

    iput-object v3, v6, Lads_mobile_sdk/tk1;->d:Ljava/lang/String;

    iput-object v8, v6, Lads_mobile_sdk/tk1;->e:Ljava/lang/String;

    iput-object v14, v6, Lads_mobile_sdk/tk1;->f:Lvr1;

    iput-object v5, v6, Lads_mobile_sdk/tk1;->g:Lnb1;

    iput v11, v6, Lads_mobile_sdk/tk1;->j:I

    invoke-virtual {v5, v6}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v9

    if-ne v9, v7, :cond_173

    goto :goto_1cb

    :cond_173
    move-object v12, v1

    move-object v1, v14

    move-object v14, v0

    :goto_176
    :try_start_176
    iget-object v0, v14, Lads_mobile_sdk/bl1;->g:Ljava/util/LinkedHashMap;

    invoke-virtual {v0, v3}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lbw2;
    :try_end_17e
    .catchall {:try_start_176 .. :try_end_17e} :catchall_2f1

    invoke-virtual {v5, v13}, Lnb1;->b(Ljava/lang/Object;)V

    move-object/from16 v16, v0

    move-object v0, v1

    move-object/from16 v18, v2

    move-object/from16 v17, v12

    move-object v15, v14

    :goto_189
    if-eqz v16, :cond_1d8

    invoke-virtual/range {v18 .. v18}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object v0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Dispatching gmsg: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " "

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v13}, Lads_mobile_sdk/nw;->b(Ljava/lang/String;Ljava/lang/Throwable;)V

    new-instance v14, Lads_mobile_sdk/nr;

    const/16 v19, 0x0

    invoke-direct/range {v14 .. v19}, Lads_mobile_sdk/nr;-><init>(Lads_mobile_sdk/bl1;Lbw2;Lads_mobile_sdk/cy0;Landroid/net/Uri;Lvx;)V

    invoke-interface/range {v16 .. v16}, Lbw2;->c()Z

    move-result v0

    if-eqz v0, :cond_1cc

    iput-object v13, v6, Lads_mobile_sdk/tk1;->a:Lads_mobile_sdk/bl1;

    iput-object v13, v6, Lads_mobile_sdk/tk1;->b:Lads_mobile_sdk/cy0;

    iput-object v13, v6, Lads_mobile_sdk/tk1;->c:Landroid/net/Uri;

    iput-object v13, v6, Lads_mobile_sdk/tk1;->d:Ljava/lang/String;

    iput-object v13, v6, Lads_mobile_sdk/tk1;->e:Ljava/lang/String;

    iput-object v13, v6, Lads_mobile_sdk/tk1;->f:Lvr1;

    iput-object v13, v6, Lads_mobile_sdk/tk1;->g:Lnb1;

    iput v10, v6, Lads_mobile_sdk/tk1;->j:I

    invoke-virtual {v14, v6}, Lads_mobile_sdk/nr;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    if-ne v0, v7, :cond_20b

    :goto_1cb
    return-object v7

    :cond_1cc
    iget-object v0, v15, Lads_mobile_sdk/bl1;->d:Lvy;

    new-instance v1, Lads_mobile_sdk/x;

    const/4 v2, 0x5

    invoke-direct {v1, v14, v13, v2}, Lads_mobile_sdk/x;-><init>(Ljava/lang/Object;Lvx;I)V

    invoke-static {v0, v13, v13, v1, v11}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    return-object v4

    :cond_1d8
    iget-object v1, v15, Lads_mobile_sdk/bl1;->e:Lads_mobile_sdk/qr0;

    iget-object v1, v1, Lads_mobile_sdk/qr0;->s:Ly23;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v24, "/closeStoreOverlay"

    const-string v25, "/instrument"

    const-string v16, "/noop"

    const-string v17, "/updateActiveView"

    const-string v18, "/trackActiveViewUnit"

    const-string v19, "/jsLoaded"

    const-string v20, "/impressionRecorded"

    const-string v21, "/refresh"

    const-string v22, "/requestReload"

    const-string v23, "/navigation"

    filled-new-array/range {v16 .. v25}, [Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcs;->U([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    sget-object v5, Lads_mobile_sdk/fo;->a$15:Lads_mobile_sdk/fo;

    const-string v6, "gads:missing_gmsg_handlers_to_ignore"

    invoke-virtual {v1, v6, v2, v5}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/List;

    invoke-interface {v1, v3}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_20c

    :cond_20b
    :goto_20b
    return-object v4

    :cond_20c
    iget-object v1, v15, Lads_mobile_sdk/bl1;->a:Lads_mobile_sdk/ux2;

    sget-object v2, Lads_mobile_sdk/fw0;->P0:Lads_mobile_sdk/fw0;

    sget-object v3, Lba0;->a:Lba0;

    iget-object v5, v15, Lads_mobile_sdk/bl1;->b:Lads_mobile_sdk/kh3;

    invoke-static {}, Lads_mobile_sdk/hh3;->b()Lads_mobile_sdk/gh3;

    move-result-object v6

    iget-object v6, v6, Lads_mobile_sdk/gh3;->a:Lads_mobile_sdk/rg3;

    const/4 v7, 0x6

    const-string v9, ". Ad Key: "

    if-nez v6, :cond_288

    invoke-static {v1, v2, v3, v5}, Lads_mobile_sdk/ux2;->a(Lads_mobile_sdk/ux2;Lads_mobile_sdk/fw0;Ljava/util/List;Lads_mobile_sdk/kh3;)Lads_mobile_sdk/wk2;

    move-result-object v1

    :try_start_223
    invoke-static {}, Lads_mobile_sdk/hh3;->a()Lads_mobile_sdk/rg3;

    move-result-object v2

    invoke-virtual {v2}, Lads_mobile_sdk/rg3;->e()Lads_mobile_sdk/ub2;

    move-result-object v2

    const/4 v3, 0x1

    iput v3, v2, Lads_mobile_sdk/ub2;->l:I

    iget-object v2, v0, Lvr1;->a:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    invoke-static {v2, v13}, Lads_mobile_sdk/nw;->c(Ljava/lang/String;Ljava/lang/Exception;)V

    iget-object v0, v0, Lvr1;->a:Ljava/lang/Object;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v7, v0, v13}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V
    :try_end_24c
    .catchall {:try_start_223 .. :try_end_24c} :catchall_250

    invoke-virtual {v1}, Lads_mobile_sdk/rg3;->close()V

    return-object v4

    :catchall_250
    move-exception v0

    :try_start_251
    invoke-virtual {v1, v0}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v2, v0, Lox2;

    if-nez v2, :cond_281

    invoke-virtual {v1, v0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of v2, v0, Lza2;

    if-nez v2, :cond_279

    instance-of v2, v0, Ljava/util/concurrent/CancellationException;

    if-nez v2, :cond_271

    instance-of v2, v0, Lads_mobile_sdk/mv0;

    if-eqz v2, :cond_26b

    throw v0

    :catchall_268
    move-exception v0

    move-object v2, v0

    goto :goto_282

    :cond_26b
    new-instance v2, Lads_mobile_sdk/tu0;

    invoke-direct {v2, v0}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw v2

    :cond_271
    new-instance v2, Lads_mobile_sdk/ou0;

    check-cast v0, Ljava/util/concurrent/CancellationException;

    invoke-direct {v2, v0}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw v2

    :cond_279
    new-instance v2, Lads_mobile_sdk/uw0;

    check-cast v0, Lza2;

    invoke-direct {v2, v0}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw v2

    :cond_281
    throw v0
    :try_end_282
    .catchall {:try_start_251 .. :try_end_282} :catchall_268

    :goto_282
    :try_start_282
    throw v2
    :try_end_283
    .catchall {:try_start_282 .. :try_end_283} :catchall_283

    :catchall_283
    move-exception v0

    invoke-static {v1, v2}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0

    :cond_288
    const/4 v1, 0x1

    invoke-static {v2, v3, v1}, Lads_mobile_sdk/hh3;->a(Lads_mobile_sdk/fw0;Ljava/util/List;Z)Lads_mobile_sdk/rg3;

    move-result-object v2

    :try_start_28d
    invoke-static {}, Lads_mobile_sdk/hh3;->a()Lads_mobile_sdk/rg3;

    move-result-object v3

    invoke-virtual {v3}, Lads_mobile_sdk/rg3;->e()Lads_mobile_sdk/ub2;

    move-result-object v3

    iput v1, v3, Lads_mobile_sdk/ub2;->l:I

    iget-object v1, v0, Lvr1;->a:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    invoke-static {v1, v13}, Lads_mobile_sdk/nw;->c(Ljava/lang/String;Ljava/lang/Exception;)V

    iget-object v0, v0, Lvr1;->a:Ljava/lang/Object;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v7, v0, v13}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V
    :try_end_2b5
    .catchall {:try_start_28d .. :try_end_2b5} :catchall_2b9

    invoke-virtual {v2}, Lads_mobile_sdk/rg3;->close()V

    return-object v4

    :catchall_2b9
    move-exception v0

    :try_start_2ba
    invoke-virtual {v2, v0}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v1, v0, Lox2;

    if-nez v1, :cond_2ea

    invoke-virtual {v2, v0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of v1, v0, Lza2;

    if-nez v1, :cond_2e2

    instance-of v1, v0, Ljava/util/concurrent/CancellationException;

    if-nez v1, :cond_2da

    instance-of v1, v0, Lads_mobile_sdk/mv0;

    if-eqz v1, :cond_2d4

    throw v0

    :catchall_2d1
    move-exception v0

    move-object v1, v0

    goto :goto_2eb

    :cond_2d4
    new-instance v1, Lads_mobile_sdk/tu0;

    invoke-direct {v1, v0}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw v1

    :cond_2da
    new-instance v1, Lads_mobile_sdk/ou0;

    check-cast v0, Ljava/util/concurrent/CancellationException;

    invoke-direct {v1, v0}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw v1

    :cond_2e2
    new-instance v1, Lads_mobile_sdk/uw0;

    check-cast v0, Lza2;

    invoke-direct {v1, v0}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw v1

    :cond_2ea
    throw v0
    :try_end_2eb
    .catchall {:try_start_2ba .. :try_end_2eb} :catchall_2d1

    :goto_2eb
    :try_start_2eb
    throw v1
    :try_end_2ec
    .catchall {:try_start_2eb .. :try_end_2ec} :catchall_2ec

    :catchall_2ec
    move-exception v0

    invoke-static {v2, v1}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0

    :catchall_2f1
    move-exception v0

    invoke-virtual {v5, v13}, Lnb1;->b(Ljava/lang/Object;)V

    throw v0
.end method

.method public static a(Lads_mobile_sdk/bl1;Ljava/lang/String;Lbt;Lwx;)Ljava/lang/Object;
    .registers 10

    .prologue
    instance-of v0, p3, Lads_mobile_sdk/al1;

    if-eqz v0, :cond_13

    move-object v0, p3

    check-cast v0, Lads_mobile_sdk/al1;

    iget v1, v0, Lads_mobile_sdk/al1;->e:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/al1;->e:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/al1;

    invoke-direct {v0, p0, p3}, Lads_mobile_sdk/al1;-><init>(Lads_mobile_sdk/bl1;Lwx;)V

    :goto_18
    iget-object p3, v0, Lads_mobile_sdk/al1;->c:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/al1;->e:I

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    sget-object v5, Lwy;->a:Lwy;

    if-eqz v1, :cond_39

    if-eq v1, v4, :cond_31

    if-ne v1, v3, :cond_2b

    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_5f

    :cond_2b
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v2

    :cond_31
    iget-object p2, v0, Lads_mobile_sdk/al1;->b:Lat;

    iget-object p1, v0, Lads_mobile_sdk/al1;->a:Ljava/lang/String;

    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_4b

    :cond_39
    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p0, p0, Lads_mobile_sdk/bl1;->i:Lads_mobile_sdk/ft1;

    iput-object p1, v0, Lads_mobile_sdk/al1;->a:Ljava/lang/String;

    iput-object p2, v0, Lads_mobile_sdk/al1;->b:Lat;

    iput v4, v0, Lads_mobile_sdk/al1;->e:I

    invoke-virtual {p0, v0}, Lads_mobile_sdk/ft1;->a(Lwx;)Ljava/lang/Object;

    move-result-object p3

    if-ne p3, v5, :cond_4b

    goto :goto_5e

    :cond_4b
    :goto_4b
    check-cast p3, Lads_mobile_sdk/kv2;

    if-nez p3, :cond_52

    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    return-object p0

    :cond_52
    iput-object v2, v0, Lads_mobile_sdk/al1;->a:Ljava/lang/String;

    iput-object v2, v0, Lads_mobile_sdk/al1;->b:Lat;

    iput v3, v0, Lads_mobile_sdk/al1;->e:I

    invoke-virtual {p3, p1, p2, v0}, Lads_mobile_sdk/kv2;->a(Ljava/lang/String;Lat;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_5f

    :goto_5e
    return-object v5

    :cond_5f
    :goto_5f
    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    return-object p0
.end method

.method public static a(Lads_mobile_sdk/bl1;Ljava/lang/String;Lbw2;Lwx;)Ljava/lang/Object;
    .registers 13

    .prologue
    instance-of v0, p3, Lads_mobile_sdk/zk1;

    if-eqz v0, :cond_13

    move-object v0, p3

    check-cast v0, Lads_mobile_sdk/zk1;

    iget v1, v0, Lads_mobile_sdk/zk1;->h:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/zk1;->h:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/zk1;

    invoke-direct {v0, p0, p3}, Lads_mobile_sdk/zk1;-><init>(Lads_mobile_sdk/bl1;Lwx;)V

    :goto_18
    iget-object p3, v0, Lads_mobile_sdk/zk1;->f:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/zk1;->h:I

    sget-object v2, Lrg2;->a:Lrg2;

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eqz v1, :cond_59

    if-eq v1, v5, :cond_55

    if-eq v1, v4, :cond_41

    if-ne v1, v3, :cond_3b

    iget-object p0, v0, Lads_mobile_sdk/zk1;->d:Ljava/lang/Object;

    check-cast p0, Llb1;

    iget-object p1, v0, Lads_mobile_sdk/zk1;->c:Lbw2;

    iget-object p2, v0, Lads_mobile_sdk/zk1;->b:Ljava/lang/String;

    iget-object v0, v0, Lads_mobile_sdk/zk1;->a:Lads_mobile_sdk/bl1;

    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V

    move-object p3, p1

    move-object p1, p2

    goto/16 :goto_d3

    :cond_3b
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v6

    :cond_41
    iget-object p0, v0, Lads_mobile_sdk/zk1;->e:Lnb1;

    iget-object p1, v0, Lads_mobile_sdk/zk1;->d:Ljava/lang/Object;

    check-cast p1, Ljava/lang/String;

    iget-object p2, v0, Lads_mobile_sdk/zk1;->c:Lbw2;

    iget-object v1, v0, Lads_mobile_sdk/zk1;->b:Ljava/lang/String;

    iget-object v0, v0, Lads_mobile_sdk/zk1;->a:Lads_mobile_sdk/bl1;

    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V

    move-object p3, p2

    move-object p2, v1

    move-object v1, p0

    move-object p0, v0

    goto :goto_97

    :cond_55
    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V

    return-object v2

    :cond_59
    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V

    invoke-interface {p2}, Lbw2;->a()Lbw2;

    move-result-object p3

    instance-of v1, p3, Lads_mobile_sdk/kv2;

    sget-object v7, Lwy;->a:Lwy;

    if-eqz v1, :cond_72

    iget-object p0, p0, Lads_mobile_sdk/bl1;->i:Lads_mobile_sdk/ft1;

    iput v5, v0, Lads_mobile_sdk/zk1;->h:I

    invoke-virtual {p0, p3, v0}, Lads_mobile_sdk/ft1;->a(Ljava/lang/Object;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v7, :cond_71

    goto :goto_d0

    :cond_71
    return-object v2

    :cond_72
    invoke-interface {p2}, Lbw2;->d()Ljava/lang/String;

    move-result-object p2

    if-eqz p2, :cond_be

    invoke-static {p2}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_7f

    goto :goto_be

    :cond_7f
    iget-object v1, p0, Lads_mobile_sdk/bl1;->f:Lnb1;

    iput-object p0, v0, Lads_mobile_sdk/zk1;->a:Lads_mobile_sdk/bl1;

    iput-object p1, v0, Lads_mobile_sdk/zk1;->b:Ljava/lang/String;

    iput-object p3, v0, Lads_mobile_sdk/zk1;->c:Lbw2;

    iput-object p2, v0, Lads_mobile_sdk/zk1;->d:Ljava/lang/Object;

    iput-object v1, v0, Lads_mobile_sdk/zk1;->e:Lnb1;

    iput v4, v0, Lads_mobile_sdk/zk1;->h:I

    invoke-virtual {v1, v0}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v0

    if-ne v0, v7, :cond_94

    goto :goto_d0

    :cond_94
    move-object v8, p2

    move-object p2, p1

    move-object p1, v8

    :goto_97
    :try_start_97
    iget-object v0, p0, Lads_mobile_sdk/bl1;->h:Ljava/util/LinkedHashMap;

    invoke-virtual {v0, p1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/util/Map;

    if-nez v0, :cond_a9

    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    goto :goto_a9

    :catchall_a7
    move-exception p0

    goto :goto_ba

    :cond_a9
    :goto_a9
    new-instance v3, Ljava/lang/ref/WeakReference;

    invoke-direct {v3, p3}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    invoke-interface {v0, p2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object p0, p0, Lads_mobile_sdk/bl1;->h:Ljava/util/LinkedHashMap;

    invoke-interface {p0, p1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_b6
    .catchall {:try_start_97 .. :try_end_b6} :catchall_a7

    invoke-virtual {v1, v6}, Lnb1;->b(Ljava/lang/Object;)V

    return-object v2

    :goto_ba
    invoke-virtual {v1, v6}, Lnb1;->b(Ljava/lang/Object;)V

    throw p0

    :cond_be
    :goto_be
    iget-object p2, p0, Lads_mobile_sdk/bl1;->f:Lnb1;

    iput-object p0, v0, Lads_mobile_sdk/zk1;->a:Lads_mobile_sdk/bl1;

    iput-object p1, v0, Lads_mobile_sdk/zk1;->b:Ljava/lang/String;

    iput-object p3, v0, Lads_mobile_sdk/zk1;->c:Lbw2;

    iput-object p2, v0, Lads_mobile_sdk/zk1;->d:Ljava/lang/Object;

    iput v3, v0, Lads_mobile_sdk/zk1;->h:I

    invoke-virtual {p2, v0}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v0

    if-ne v0, v7, :cond_d1

    :goto_d0
    return-object v7

    :cond_d1
    move-object v0, p0

    move-object p0, p2

    :goto_d3
    :try_start_d3
    iget-object p2, v0, Lads_mobile_sdk/bl1;->g:Ljava/util/LinkedHashMap;

    invoke-interface {p2, p1, p3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_d8
    .catchall {:try_start_d3 .. :try_end_d8} :catchall_dc

    invoke-interface {p0, v6}, Llb1;->b(Ljava/lang/Object;)V

    return-object v2

    :catchall_dc
    move-exception p1

    invoke-interface {p0, v6}, Llb1;->b(Ljava/lang/Object;)V

    throw p1
.end method

.method public static a(Lads_mobile_sdk/bl1;Ljava/lang/String;Lwx;)Ljava/lang/Object;
    .registers 8

    .prologue
    instance-of v0, p2, Lads_mobile_sdk/wk1;

    if-eqz v0, :cond_13

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/wk1;

    iget v1, v0, Lads_mobile_sdk/wk1;->e:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/wk1;->e:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/wk1;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/wk1;-><init>(Lads_mobile_sdk/bl1;Lwx;)V

    :goto_18
    iget-object p2, v0, Lads_mobile_sdk/wk1;->c:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/wk1;->e:I

    const/4 v2, 0x1

    sget-object v3, Lrg2;->a:Lrg2;

    const/4 v4, 0x0

    if-eqz v1, :cond_39

    if-eq v1, v2, :cond_31

    const/4 p0, 0x2

    if-ne v1, p0, :cond_2b

    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    return-object v3

    :cond_2b
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v4

    :cond_31
    iget-object p1, v0, Lads_mobile_sdk/wk1;->b:Ljava/lang/String;

    iget-object p0, v0, Lads_mobile_sdk/wk1;->a:Lads_mobile_sdk/bl1;

    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_4d

    :cond_39
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p2, p0, Lads_mobile_sdk/bl1;->i:Lads_mobile_sdk/ft1;

    iput-object p0, v0, Lads_mobile_sdk/wk1;->a:Lads_mobile_sdk/bl1;

    iput-object p1, v0, Lads_mobile_sdk/wk1;->b:Ljava/lang/String;

    iput v2, v0, Lads_mobile_sdk/wk1;->e:I

    invoke-virtual {p2, v0}, Lads_mobile_sdk/ft1;->a(Lwx;)Ljava/lang/Object;

    move-result-object p2

    sget-object v0, Lwy;->a:Lwy;

    if-ne p2, v0, :cond_4d

    return-object v0

    :cond_4d
    :goto_4d
    check-cast p2, Lads_mobile_sdk/kv2;

    if-nez p2, :cond_5b

    const-string p0, "Unknown/Unexpected GMSG without a handler: result"

    invoke-static {p0, v4}, Lads_mobile_sdk/nw;->c(Ljava/lang/String;Ljava/lang/Exception;)V

    const/4 p1, 0x6

    invoke-static {p1, p0, v4}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    return-object v3

    :cond_5b
    :try_start_5b
    new-instance v0, Lkm0;

    invoke-direct {v0}, Lkm0;-><init>()V

    const-class v1, Lfx0;

    invoke-virtual {v0, v1, p1}, Lkm0;->a(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lfx0;
    :try_end_68
    .catch Ljava/lang/Exception; {:try_start_5b .. :try_end_68} :catch_69

    goto :goto_82

    :catch_69
    move-exception p1

    invoke-static {p1}, Lrt2;->c(Ljava/lang/Exception;)Lads_mobile_sdk/ub2;

    move-result-object v0

    iget-object v0, v0, Lads_mobile_sdk/ub2;->s:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_7e

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    :cond_7e
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move-object p1, v4

    :goto_82
    if-nez p1, :cond_85

    return-object v3

    :cond_85
    new-instance v0, Lads_mobile_sdk/ix1;

    invoke-direct {v0, p0, p2, p1, v4}, Lads_mobile_sdk/ix1;-><init>(Lads_mobile_sdk/bl1;Lads_mobile_sdk/kv2;Lfx0;Lvx;)V

    iget-object p0, p0, Lads_mobile_sdk/bl1;->d:Lvy;

    new-instance p1, Lads_mobile_sdk/x;

    const/16 p2, 0xb

    invoke-direct {p1, v0, v4, p2}, Lads_mobile_sdk/x;-><init>(Ljava/lang/Object;Lvx;I)V

    const/4 p2, 0x3

    invoke-static {p0, v4, v4, p1, p2}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    return-object v3
.end method


# virtual methods
.method public final a(Lads_mobile_sdk/cy0;Landroid/net/Uri;Lads_mobile_sdk/ey0;)Ljava/lang/Object;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lads_mobile_sdk/bl1;->a(Lads_mobile_sdk/bl1;Lads_mobile_sdk/cy0;Landroid/net/Uri;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final a(Lads_mobile_sdk/cy0;Ljava/lang/String;Lyh;)Ljava/lang/Object;
    .registers 4

    invoke-static {p0, p2, p3}, Lads_mobile_sdk/bl1;->a(Lads_mobile_sdk/bl1;Ljava/lang/String;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final a(Ljava/lang/String;Lbt;Lads_mobile_sdk/ix0;)Ljava/lang/Object;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lads_mobile_sdk/bl1;->a(Lads_mobile_sdk/bl1;Ljava/lang/String;Lbt;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final a(Ljava/lang/String;Lbw2;Lwx;)Ljava/lang/Object;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lads_mobile_sdk/bl1;->a(Lads_mobile_sdk/bl1;Ljava/lang/String;Lbw2;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
