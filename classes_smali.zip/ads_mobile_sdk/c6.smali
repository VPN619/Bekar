.class public final Lads_mobile_sdk/c6;
.super Lads_mobile_sdk/ku0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field private static final DEFAULT_INSTANCE:Lads_mobile_sdk/c6;

.field public static final c:I = 0x1

.field public static final d:I = 0x2

.field public static final e:I = 0x3

.field public static final f:I = 0x4


# instance fields
.field private bitField0_:I

.field private checksum_:Ljava/lang/String;

.field private createTimeMs_:J

.field private filename_:Ljava/lang/String;

.field private status_:I


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lads_mobile_sdk/c6;

    invoke-direct {v0}, Lads_mobile_sdk/c6;-><init>()V

    sput-object v0, Lads_mobile_sdk/c6;->DEFAULT_INSTANCE:Lads_mobile_sdk/c6;

    const-class v1, Lads_mobile_sdk/c6;

    invoke-static {v1, v0}, Lads_mobile_sdk/ku0;->a(Ljava/lang/Class;Lads_mobile_sdk/ku0;)V

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Lads_mobile_sdk/ku0;-><init>()V

    const-string v0, ""

    iput-object v0, p0, Lads_mobile_sdk/c6;->filename_:Ljava/lang/String;

    iput-object v0, p0, Lads_mobile_sdk/c6;->checksum_:Ljava/lang/String;

    return-void
.end method

.method public static bridge synthetic c(Lads_mobile_sdk/c6;)I
    .registers 1

    iget p0, p0, Lads_mobile_sdk/c6;->bitField0_:I

    return p0
.end method

.method public static bridge synthetic d(ILads_mobile_sdk/c6;)V
    .registers 2

    iput p0, p1, Lads_mobile_sdk/c6;->bitField0_:I

    return-void
.end method

.method public static bridge synthetic f(Lads_mobile_sdk/c6;J)V
    .registers 3

    iput-wide p1, p0, Lads_mobile_sdk/c6;->createTimeMs_:J

    return-void
.end method

.method public static bridge synthetic g(ILads_mobile_sdk/c6;)V
    .registers 2

    iput p0, p1, Lads_mobile_sdk/c6;->status_:I

    return-void
.end method

.method public static s()Leu2;
    .registers 1

    sget-object v0, Lads_mobile_sdk/c6;->DEFAULT_INSTANCE:Lads_mobile_sdk/c6;

    invoke-virtual {v0}, Lads_mobile_sdk/ku0;->e()Lads_mobile_sdk/iu0;

    move-result-object v0

    check-cast v0, Leu2;

    return-object v0
.end method


# virtual methods
.method public final a(ILads_mobile_sdk/ku0;)Ljava/lang/Object;
    .registers 5

    .prologue
    invoke-static {p1}, Lvr0;->a(I)I

    move-result p0

    if-eqz p0, :cond_47

    const/4 p1, 0x2

    if-eq p0, p1, :cond_2f

    const/4 p1, 0x3

    if-eq p0, p1, :cond_29

    const/4 p1, 0x4

    if-eq p0, p1, :cond_21

    const/4 p1, 0x5

    if-eq p0, p1, :cond_1e

    const/4 p1, 0x6

    if-ne p0, p1, :cond_1c

    const-class p0, Lads_mobile_sdk/c6;

    invoke-static {p0}, Lads_mobile_sdk/ku0;->b(Ljava/lang/Class;)Lads_mobile_sdk/ju0;

    move-result-object p0

    return-object p0

    :cond_1c
    const/4 p0, 0x0

    throw p0

    :cond_1e
    sget-object p0, Lads_mobile_sdk/c6;->DEFAULT_INSTANCE:Lads_mobile_sdk/c6;

    return-object p0

    :cond_21
    new-instance p0, Leu2;

    sget-object p1, Lads_mobile_sdk/c6;->DEFAULT_INSTANCE:Lads_mobile_sdk/c6;

    invoke-direct {p0, p1}, Lads_mobile_sdk/iu0;-><init>(Lads_mobile_sdk/ku0;)V

    return-object p0

    :cond_29
    new-instance p0, Lads_mobile_sdk/c6;

    invoke-direct {p0}, Lads_mobile_sdk/c6;-><init>()V

    return-object p0

    :cond_2f
    const-string p0, "checksum_"

    const-string p1, "status_"

    const-string p2, "bitField0_"

    const-string v0, "filename_"

    const-string v1, "createTimeMs_"

    filled-new-array {p2, v0, v1, p0, p1}, [Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lads_mobile_sdk/c6;->DEFAULT_INSTANCE:Lads_mobile_sdk/c6;

    new-instance p2, Lads_mobile_sdk/zq2;

    const-string v0, "\u0004\u0004\u0000\u0001\u0001\u0004\u0004\u0000\u0000\u0000\u0001ለ\u0000\u0002ဂ\u0001\u0003ለ\u0002\u0004ဌ\u0003"

    invoke-direct {p2, p1, v0, p0}, Lads_mobile_sdk/zq2;-><init>(Lads_mobile_sdk/ku0;Ljava/lang/String;[Ljava/lang/Object;)V

    return-object p2

    :cond_47
    const/4 p0, 0x1

    invoke-static {p0}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object p0

    return-object p0
.end method

.method public final b(Ljava/lang/String;)V
    .registers 3

    invoke-static {p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    iget v0, p0, Lads_mobile_sdk/c6;->bitField0_:I

    or-int/lit8 v0, v0, 0x4

    iput v0, p0, Lads_mobile_sdk/c6;->bitField0_:I

    iput-object p1, p0, Lads_mobile_sdk/c6;->checksum_:Ljava/lang/String;

    return-void
.end method

.method public final c(Ljava/lang/String;)V
    .registers 3

    iget v0, p0, Lads_mobile_sdk/c6;->bitField0_:I

    or-int/lit8 v0, v0, 0x1

    iput v0, p0, Lads_mobile_sdk/c6;->bitField0_:I

    iput-object p1, p0, Lads_mobile_sdk/c6;->filename_:Ljava/lang/String;

    return-void
.end method

.method public final o()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/c6;->checksum_:Ljava/lang/String;

    return-object p0
.end method

.method public final p()J
    .registers 3

    iget-wide v0, p0, Lads_mobile_sdk/c6;->createTimeMs_:J

    return-wide v0
.end method

.method public final q()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/c6;->filename_:Ljava/lang/String;

    return-object p0
.end method

.method public final r$1()I
    .registers 3

    .prologue
    iget p0, p0, Lads_mobile_sdk/c6;->status_:I

    const/4 v0, 0x1

    if-eqz p0, :cond_f

    const/4 v1, 0x2

    if-eq p0, v0, :cond_e

    if-eq p0, v1, :cond_c

    const/4 v0, 0x0

    goto :goto_f

    :cond_c
    const/4 v0, 0x3

    goto :goto_f

    :cond_e
    move v0, v1

    :cond_f
    :goto_f
    if-nez v0, :cond_13

    const/4 p0, 0x4

    return p0

    :cond_13
    return v0
.end method
