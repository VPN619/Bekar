.class public final Lads_mobile_sdk/ej1;
.super Ljava/util/TimerTask;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final synthetic a:Ltz2;

.field public final synthetic b:Ljava/util/Timer;

.field public final synthetic c:Lads_mobile_sdk/gj1;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/gj1;Ltz2;Ljava/util/Timer;)V
    .registers 4

    iput-object p1, p0, Lads_mobile_sdk/ej1;->c:Lads_mobile_sdk/gj1;

    iput-object p2, p0, Lads_mobile_sdk/ej1;->a:Ltz2;

    iput-object p3, p0, Lads_mobile_sdk/ej1;->b:Ljava/util/Timer;

    invoke-direct {p0}, Ljava/util/TimerTask;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 6

    iget-object v0, p0, Lads_mobile_sdk/ej1;->c:Lads_mobile_sdk/gj1;

    iget-object v0, v0, Lads_mobile_sdk/gj1;->g:Lads_mobile_sdk/ji;

    iget-object v1, v0, Lads_mobile_sdk/ji;->a:Ljava/lang/Object;

    check-cast v1, Landroid/webkit/WebView;

    iget-object v0, v0, Lads_mobile_sdk/ji;->b:Ljava/lang/Object;

    check-cast v0, Lj33;

    invoke-interface {v0}, Lj33;->a()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroidx/webkit/WebViewCompat;->removeWebMessageListener(Landroid/webkit/WebView;Ljava/lang/String;)V

    iget-object v0, p0, Lads_mobile_sdk/ej1;->a:Ltz2;

    iget-object v0, v0, Ltz2;->a:Lads_mobile_sdk/r62;

    iget-object v1, v0, Lads_mobile_sdk/r62;->c:Lvy;

    new-instance v2, Lqd;

    const/16 v3, 0x13

    const/4 v4, 0x0

    invoke-direct {v2, v0, v4, v3}, Lqd;-><init>(Ljava/lang/Object;Lvx;I)V

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, La42;

    invoke-direct {v0, v2, v4}, La42;-><init>(Lpk0;Lvx;)V

    const/4 v2, 0x2

    sget-object v3, Ly90;->a:Ly90;

    invoke-static {v1, v3, v4, v0, v2}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    iget-object p0, p0, Lads_mobile_sdk/ej1;->b:Ljava/util/Timer;

    invoke-virtual {p0}, Ljava/util/Timer;->cancel()V

    return-void
.end method
