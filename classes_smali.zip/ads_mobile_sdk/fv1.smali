.class public final Lads_mobile_sdk/fv1;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public final synthetic a:J


# direct methods
.method public constructor <init>(JLvx;)V
    .registers 4

    iput-wide p1, p0, Lads_mobile_sdk/fv1;->a:J

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 5

    new-instance p2, Lads_mobile_sdk/fv1;

    iget-wide v0, p0, Lads_mobile_sdk/fv1;->a:J

    invoke-direct {p2, v0, v1, p1}, Lads_mobile_sdk/fv1;-><init>(JLvx;)V

    return-object p2
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    check-cast p1, Lads_mobile_sdk/zu1;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/fv1;

    iget-wide v0, p0, Lads_mobile_sdk/fv1;->a:J

    invoke-direct {p1, v0, v1, p2}, Lads_mobile_sdk/fv1;-><init>(JLvx;)V

    sget-object p0, Lrg2;->a:Lrg2;

    invoke-virtual {p1, p0}, Lads_mobile_sdk/fv1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    invoke-static {}, Lads_mobile_sdk/zu1;->r()Lp73;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v0, p1, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v0, Lads_mobile_sdk/zu1;

    iget-wide v1, p0, Lads_mobile_sdk/fv1;->a:J

    invoke-static {v0, v1, v2}, Lads_mobile_sdk/zu1;->f(Lads_mobile_sdk/zu1;J)V

    invoke-virtual {p1}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/zu1;

    return-object p0
.end method
