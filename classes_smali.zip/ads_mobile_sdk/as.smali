.class public final Lads_mobile_sdk/as;
.super Lzz0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lbk0;


# instance fields
.field public final synthetic a:Landroid/content/Intent;

.field public final synthetic i:I


# direct methods
.method public synthetic constructor <init>(ILandroid/content/Intent;)V
    .registers 3

    iput p1, p0, Lads_mobile_sdk/as;->i:I

    iput-object p2, p0, Lads_mobile_sdk/as;->a:Landroid/content/Intent;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lzz0;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .prologue
    iget v0, p0, Lads_mobile_sdk/as;->i:I

    iget-object p0, p0, Lads_mobile_sdk/as;->a:Landroid/content/Intent;

    packed-switch v0, :pswitch_data_60

    check-cast p1, Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0, p1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    return-object p0

    :pswitch_11  #0x3
    check-cast p1, Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    move-result-object p0

    return-object p0

    :pswitch_1f  #0x2
    check-cast p1, Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Ljs1;

    const-string v1, "/"

    invoke-direct {v0, v1}, Ljs1;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x2

    invoke-virtual {v0, p1, v1}, Ljs1;->e(Ljava/lang/CharSequence;I)Ljava/util/List;

    move-result-object p1

    const/4 v0, 0x0

    new-array v2, v0, [Ljava/lang/String;

    invoke-interface {p1, v2}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p1

    check-cast p1, [Ljava/lang/String;

    array-length v2, p1

    if-ne v2, v1, :cond_49

    new-instance v1, Landroid/content/ComponentName;

    aget-object v0, p1, v0

    const/4 v2, 0x1

    aget-object p1, p1, v2

    invoke-direct {v1, v0, p1}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p0, v1}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    :cond_49
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0

    :pswitch_4c  #0x1
    check-cast p1, Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0, p1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    return-object p0

    :pswitch_56  #0x0
    check-cast p1, Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0, p1}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    return-object p0

    :pswitch_data_60
    .packed-switch 0x0
        :pswitch_56  #00000000
        :pswitch_4c  #00000001
        :pswitch_1f  #00000002
        :pswitch_11  #00000003
    .end packed-switch
.end method
