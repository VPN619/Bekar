.class public final Lads_mobile_sdk/ej0;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lnt2;


# instance fields
.field public final a:Lads_mobile_sdk/ob1;

.field public final b:Lads_mobile_sdk/ob1;

.field public final c:Ltv2;

.field public final synthetic d:I


# direct methods
.method public synthetic constructor <init>(Lads_mobile_sdk/ob1;Lads_mobile_sdk/ob1;Ltv2;I)V
    .registers 5

    iput p4, p0, Lads_mobile_sdk/ej0;->d:I

    iput-object p1, p0, Lads_mobile_sdk/ej0;->a:Lads_mobile_sdk/ob1;

    iput-object p2, p0, Lads_mobile_sdk/ej0;->b:Lads_mobile_sdk/ob1;

    iput-object p3, p0, Lads_mobile_sdk/ej0;->c:Ltv2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 4

    .prologue
    iget v0, p0, Lads_mobile_sdk/ej0;->d:I

    packed-switch v0, :pswitch_data_3a

    iget-object v0, p0, Lads_mobile_sdk/ej0;->a:Lads_mobile_sdk/ob1;

    iget-object v0, v0, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v0, Landroid/content/Context;

    iget-object v0, p0, Lads_mobile_sdk/ej0;->b:Lads_mobile_sdk/ob1;

    iget-object v0, v0, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v0, Ljava/util/concurrent/ExecutorService;

    iget-object p0, p0, Lads_mobile_sdk/ej0;->c:Ltv2;

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/qm1;

    new-instance v0, Lads_mobile_sdk/z6;

    invoke-direct {v0, p0}, Lads_mobile_sdk/z6;-><init>(Lads_mobile_sdk/qm1;)V

    return-object v0

    :pswitch_1f  #0x0
    iget-object v0, p0, Lads_mobile_sdk/ej0;->a:Lads_mobile_sdk/ob1;

    iget-object v0, v0, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v0, Landroid/content/Context;

    iget-object v1, p0, Lads_mobile_sdk/ej0;->b:Lads_mobile_sdk/ob1;

    iget-object v1, v1, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/l7;

    iget-object p0, p0, Lads_mobile_sdk/ej0;->c:Ltv2;

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/ia3;

    new-instance v2, Lads_mobile_sdk/dj0;

    invoke-direct {v2, v0, v1, p0}, Lads_mobile_sdk/dj0;-><init>(Landroid/content/Context;Lads_mobile_sdk/l7;Lads_mobile_sdk/ia3;)V

    return-object v2

    nop

    :pswitch_data_3a
    .packed-switch 0x0
        :pswitch_1f  #00000000
    .end packed-switch
.end method
