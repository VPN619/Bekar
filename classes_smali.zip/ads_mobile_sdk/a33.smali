.class public final Lads_mobile_sdk/a33;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Lv03;

.field public final b:Lnb1;

.field public c:Lads_mobile_sdk/u23;


# direct methods
.method public constructor <init>(Lv03;)V
    .registers 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/a33;->a:Lv03;

    new-instance p1, Lnb1;

    invoke-direct {p1}, Lnb1;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/a33;->b:Lnb1;

    return-void
.end method

.method public static a(Lads_mobile_sdk/a33;Lbk0;Lwx;)Ljava/lang/Object;
    .registers 10

    .prologue
    instance-of v0, p2, Lads_mobile_sdk/y23;

    if-eqz v0, :cond_13

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/y23;

    iget v1, v0, Lads_mobile_sdk/y23;->f:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/y23;->f:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/y23;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/y23;-><init>(Lads_mobile_sdk/a33;Lwx;)V

    :goto_18
    iget-object p2, v0, Lads_mobile_sdk/y23;->d:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/y23;->f:I

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    sget-object v5, Lwy;->a:Lwy;

    if-eqz v1, :cond_3f

    if-eq v1, v3, :cond_39

    if-ne v1, v2, :cond_33

    iget-object p0, v0, Lads_mobile_sdk/y23;->c:Lnb1;

    iget-object p1, v0, Lads_mobile_sdk/y23;->b:Lads_mobile_sdk/u23;

    iget-object v0, v0, Lads_mobile_sdk/y23;->a:Lads_mobile_sdk/a33;

    :try_start_2d
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_30
    .catchall {:try_start_2d .. :try_end_30} :catchall_31

    goto :goto_71

    :catchall_31
    move-exception p0

    goto :goto_7c

    :cond_33
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v4

    :cond_39
    iget-object p0, v0, Lads_mobile_sdk/y23;->a:Lads_mobile_sdk/a33;

    :try_start_3b
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_3e
    .catchall {:try_start_3b .. :try_end_3e} :catchall_31

    goto :goto_5b

    :cond_3f
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    :try_start_42
    iget-object p2, p0, Lads_mobile_sdk/a33;->a:Lv03;

    invoke-interface {p2}, Lv03;->get()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Lc42;

    new-instance v1, Lo00;

    const/4 v6, 0x3

    invoke-direct {v1, p1, v4, v6}, Lo00;-><init>(Lbk0;Lvx;I)V

    iput-object p0, v0, Lads_mobile_sdk/y23;->a:Lads_mobile_sdk/a33;

    iput v3, v0, Lads_mobile_sdk/y23;->f:I

    invoke-virtual {p2, v1, v0}, Lc42;->i(Lpk0;Lwx;)Ljava/lang/Object;

    move-result-object p2

    if-ne p2, v5, :cond_5b

    goto :goto_6e

    :cond_5b
    :goto_5b
    move-object p1, p2

    check-cast p1, Lads_mobile_sdk/u23;

    iget-object p2, p0, Lads_mobile_sdk/a33;->b:Lnb1;

    iput-object p0, v0, Lads_mobile_sdk/y23;->a:Lads_mobile_sdk/a33;

    iput-object p1, v0, Lads_mobile_sdk/y23;->b:Lads_mobile_sdk/u23;

    iput-object p2, v0, Lads_mobile_sdk/y23;->c:Lnb1;

    iput v2, v0, Lads_mobile_sdk/y23;->f:I

    invoke-virtual {p2, v0}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v0
    :try_end_6c
    .catchall {:try_start_42 .. :try_end_6c} :catchall_31

    if-ne v0, v5, :cond_6f

    :goto_6e
    return-object v5

    :cond_6f
    move-object v0, p0

    move-object p0, p2

    :goto_71
    :try_start_71
    iput-object p1, v0, Lads_mobile_sdk/a33;->c:Lads_mobile_sdk/u23;
    :try_end_73
    .catchall {:try_start_71 .. :try_end_73} :catchall_77

    :try_start_73
    invoke-virtual {p0, v4}, Lnb1;->b(Ljava/lang/Object;)V

    goto :goto_8d

    :catchall_77
    move-exception p1

    invoke-virtual {p0, v4}, Lnb1;->b(Ljava/lang/Object;)V

    throw p1
    :try_end_7c
    .catchall {:try_start_73 .. :try_end_7c} :catchall_31

    :goto_7c
    new-instance p1, Ljava/lang/StringBuilder;

    const-string p2, "Failed to update shared settings: "

    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0, v4}, Lads_mobile_sdk/nw;->c(Ljava/lang/String;Ljava/lang/Exception;)V

    :goto_8d
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method

.method public static a(Lads_mobile_sdk/a33;Lwx;)Ljava/lang/Object;
    .registers 9

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/v23;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/v23;

    iget v1, v0, Lads_mobile_sdk/v23;->f:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/v23;->f:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/v23;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/v23;-><init>(Lads_mobile_sdk/a33;Lwx;)V

    :goto_18
    iget-object p1, v0, Lads_mobile_sdk/v23;->d:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/v23;->f:I

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    sget-object v6, Lwy;->a:Lwy;

    if-eqz v1, :cond_4e

    if-eq v1, v4, :cond_42

    if-eq v1, v3, :cond_3c

    if-ne v1, v2, :cond_36

    iget-object p0, v0, Lads_mobile_sdk/v23;->c:Lnb1;

    iget-object v1, v0, Lads_mobile_sdk/v23;->b:Ljava/lang/Object;

    check-cast v1, Lads_mobile_sdk/u23;

    iget-object v0, v0, Lads_mobile_sdk/v23;->a:Lads_mobile_sdk/a33;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_9b

    :cond_36
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v5

    :cond_3c
    iget-object p0, v0, Lads_mobile_sdk/v23;->a:Lads_mobile_sdk/a33;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_7f

    :cond_42
    iget-object p0, v0, Lads_mobile_sdk/v23;->b:Ljava/lang/Object;

    check-cast p0, Llb1;

    iget-object v1, v0, Lads_mobile_sdk/v23;->a:Lads_mobile_sdk/a33;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    move-object p1, p0

    move-object p0, v1

    goto :goto_60

    :cond_4e
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/a33;->b:Lnb1;

    iput-object p0, v0, Lads_mobile_sdk/v23;->a:Lads_mobile_sdk/a33;

    iput-object p1, v0, Lads_mobile_sdk/v23;->b:Ljava/lang/Object;

    iput v4, v0, Lads_mobile_sdk/v23;->f:I

    invoke-virtual {p1, v0}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v6, :cond_60

    goto :goto_98

    :cond_60
    :goto_60
    :try_start_60
    iget-object v1, p0, Lads_mobile_sdk/a33;->c:Lads_mobile_sdk/u23;
    :try_end_62
    .catchall {:try_start_60 .. :try_end_62} :catchall_a9

    invoke-interface {p1, v5}, Llb1;->b(Ljava/lang/Object;)V

    if-eqz v1, :cond_68

    return-object v1

    :cond_68
    iget-object p1, p0, Lads_mobile_sdk/a33;->a:Lv03;

    invoke-interface {p1}, Lv03;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lc42;

    iget-object p1, p1, Lc42;->c:Lsw;

    iput-object p0, v0, Lads_mobile_sdk/v23;->a:Lads_mobile_sdk/a33;

    iput-object v5, v0, Lads_mobile_sdk/v23;->b:Ljava/lang/Object;

    iput v3, v0, Lads_mobile_sdk/v23;->f:I

    invoke-static {p1, v0}, Lla1;->u(Lff0;Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v6, :cond_7f

    goto :goto_98

    :cond_7f
    :goto_7f
    check-cast p1, Lads_mobile_sdk/u23;

    if-nez p1, :cond_87

    invoke-static {}, Lads_mobile_sdk/u23;->o()Lads_mobile_sdk/u23;

    move-result-object p1

    :cond_87
    move-object v1, p1

    iget-object p1, p0, Lads_mobile_sdk/a33;->b:Lnb1;

    iput-object p0, v0, Lads_mobile_sdk/v23;->a:Lads_mobile_sdk/a33;

    iput-object v1, v0, Lads_mobile_sdk/v23;->b:Ljava/lang/Object;

    iput-object p1, v0, Lads_mobile_sdk/v23;->c:Lnb1;

    iput v2, v0, Lads_mobile_sdk/v23;->f:I

    invoke-virtual {p1, v0}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v0

    if-ne v0, v6, :cond_99

    :goto_98
    return-object v6

    :cond_99
    move-object v0, p0

    move-object p0, p1

    :goto_9b
    :try_start_9b
    iput-object v1, v0, Lads_mobile_sdk/a33;->c:Lads_mobile_sdk/u23;
    :try_end_9d
    .catchall {:try_start_9b .. :try_end_9d} :catchall_a4

    invoke-virtual {p0, v5}, Lnb1;->b(Ljava/lang/Object;)V

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object v1

    :catchall_a4
    move-exception p1

    invoke-virtual {p0, v5}, Lnb1;->b(Ljava/lang/Object;)V

    throw p1

    :catchall_a9
    move-exception p0

    invoke-interface {p1, v5}, Llb1;->b(Ljava/lang/Object;)V

    throw p0
.end method

.method public static b(Lads_mobile_sdk/a33;Lwx;)Ljava/lang/Object;
    .registers 6

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/w23;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/w23;

    iget v1, v0, Lads_mobile_sdk/w23;->c:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/w23;->c:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/w23;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/w23;-><init>(Lads_mobile_sdk/a33;Lwx;)V

    :goto_18
    iget-object p1, v0, Lads_mobile_sdk/w23;->a:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/w23;->c:I

    const/4 v2, 0x1

    if-eqz v1, :cond_2c

    if-ne v1, v2, :cond_25

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_3d

    :cond_25
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0

    :cond_2c
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iput v2, v0, Lads_mobile_sdk/w23;->c:I

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p0, v0}, Lads_mobile_sdk/a33;->a(Lads_mobile_sdk/a33;Lwx;)Ljava/lang/Object;

    move-result-object p1

    sget-object p0, Lwy;->a:Lwy;

    if-ne p1, p0, :cond_3d

    return-object p0

    :cond_3d
    :goto_3d
    check-cast p1, Lads_mobile_sdk/u23;

    invoke-virtual {p1}, Lads_mobile_sdk/u23;->q()I

    move-result p0

    new-instance p1, Ljava/lang/Integer;

    invoke-direct {p1, p0}, Ljava/lang/Integer;-><init>(I)V

    return-object p1
.end method
