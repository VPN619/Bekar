.class public final Lads_mobile_sdk/d90;
.super Lads_mobile_sdk/k61;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lia3;
.implements Lyz2;
.implements Lgt2;


# instance fields
.field public final c:Lads_mobile_sdk/b90;

.field public final d:Lvy;

.field public final e:Lads_mobile_sdk/qr0;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/b90;Lvy;Lads_mobile_sdk/qr0;)V
    .registers 6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0, v0, v1}, Lads_mobile_sdk/k61;-><init>(Lads_mobile_sdk/fw0;I)V

    iput-object p1, p0, Lads_mobile_sdk/d90;->c:Lads_mobile_sdk/b90;

    iput-object p2, p0, Lads_mobile_sdk/d90;->d:Lvy;

    iput-object p3, p0, Lads_mobile_sdk/d90;->e:Lads_mobile_sdk/qr0;

    return-void
.end method


# virtual methods
.method public final a(Lads_mobile_sdk/n13;Lads_mobile_sdk/a2;Llu1;Lvx;)Ljava/lang/Object;
    .registers 5

    .prologue
    iget-object p1, p0, Lads_mobile_sdk/d90;->e:Lads_mobile_sdk/qr0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object p2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sget-object p3, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    const-string p4, "gads:cct_v2_prewarm_on_ad_loaded:enabled"

    invoke-virtual {p1, p4, p2, p3}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_1a

    invoke-virtual {p0}, Lads_mobile_sdk/d90;->b()V

    :cond_1a
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method

.method public final b()V
    .registers 5

    new-instance v0, Lc4;

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-direct {v0, p0, v2, v1}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    iget-object p0, p0, Lads_mobile_sdk/d90;->d:Lvy;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, La42;

    invoke-direct {v1, v0, v2}, La42;-><init>(Lpk0;Lvx;)V

    const/4 v0, 0x2

    sget-object v3, Ly90;->a:Ly90;

    invoke-static {p0, v3, v2, v1, v0}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    return-void
.end method

.method public final f()V
    .registers 5

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/d90;->e:Lads_mobile_sdk/qr0;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sget-object v2, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    const-string v3, "gads:cct_v2_prewarm_on_signal_generated:enabled"

    invoke-virtual {v0, v3, v1, v2}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_1a

    invoke-virtual {p0}, Lads_mobile_sdk/d90;->b()V

    :cond_1a
    return-void
.end method

.method public final h(Lvx;)Ljava/lang/Object;
    .registers 5

    .prologue
    iget-object p1, p0, Lads_mobile_sdk/d90;->e:Lads_mobile_sdk/qr0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sget-object v1, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    const-string v2, "gads:cct_v2_prewarm_at_init:enabled"

    invoke-virtual {p1, v2, v0, v1}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_1a

    invoke-virtual {p0}, Lads_mobile_sdk/d90;->b()V

    :cond_1a
    new-instance p0, Lads_mobile_sdk/hv0;

    sget-object p1, Lrg2;->a:Lrg2;

    invoke-direct {p0, p1}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    return-object p0
.end method

.method public final q(Lvx;)Ljava/lang/Object;
    .registers 5

    .prologue
    iget-object p1, p0, Lads_mobile_sdk/d90;->e:Lads_mobile_sdk/qr0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sget-object v1, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    const-string v2, "gads:cct_v2_prewarm_on_impression:enabled"

    invoke-virtual {p1, v2, v0, v1}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_1a

    invoke-virtual {p0}, Lads_mobile_sdk/d90;->b()V

    :cond_1a
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method
