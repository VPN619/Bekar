.class public final Lads_mobile_sdk/ew1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lxw2;


# instance fields
.field public final b:Luh;

.field public final c:Landroid/widget/FrameLayout;

.field public final d:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public e:Landroid/view/View;

.field public f:Landroid/widget/ImageView$ScaleType;

.field public g:Landroid/view/GestureDetector;

.field public final h:Ljava/util/LinkedHashMap;

.field public i:Lcom/google/android/libraries/ads/mobile/sdk/internal/nativead/InternalNativeAd;


# direct methods
.method public constructor <init>(Luh;Landroid/widget/FrameLayout;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/ew1;->b:Luh;

    iput-object p2, p0, Lads_mobile_sdk/ew1;->c:Landroid/widget/FrameLayout;

    invoke-virtual {p1, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    invoke-virtual {p1, p0}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 p2, 0x0

    invoke-direct {p1, p2}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object p1, p0, Lads_mobile_sdk/ew1;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    new-instance p1, Ljava/util/LinkedHashMap;

    invoke-direct {p1}, Ljava/util/LinkedHashMap;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/ew1;->h:Ljava/util/LinkedHashMap;

    return-void
.end method


# virtual methods
.method public final a(Landroid/view/View;Ljava/lang/String;)V
    .registers 5

    .prologue
    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Lads_mobile_sdk/ew1;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0
    :try_end_7
    .catchall {:try_start_1 .. :try_end_7} :catchall_18

    if-eqz v0, :cond_b

    monitor-exit p0

    return-void

    :cond_b
    iget-object v0, p0, Lads_mobile_sdk/ew1;->h:Ljava/util/LinkedHashMap;

    if-eqz p1, :cond_1a

    :try_start_f
    new-instance v1, Ljava/lang/ref/WeakReference;

    invoke-direct {v1, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    invoke-interface {v0, p2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_1d

    :catchall_18
    move-exception p1

    goto :goto_3a

    :cond_1a
    invoke-interface {v0, p2}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :goto_1d
    const-string v0, "3011"

    invoke-virtual {v0, p2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p2
    :try_end_23
    .catchall {:try_start_f .. :try_end_23} :catchall_18

    if-eqz p2, :cond_27

    monitor-exit p0

    return-void

    :cond_27
    if-eqz p1, :cond_2c

    :try_start_29
    invoke-virtual {p1, p0}, Landroid/view/View;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    :cond_2c
    if-nez p1, :cond_2f

    goto :goto_33

    :cond_2f
    const/4 p2, 0x1

    invoke-virtual {p1, p2}, Landroid/view/View;->setClickable(Z)V

    :goto_33
    if-eqz p1, :cond_38

    invoke-virtual {p1, p0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V
    :try_end_38
    .catchall {:try_start_29 .. :try_end_38} :catchall_18

    :cond_38
    monitor-exit p0

    return-void

    :goto_3a
    monitor-exit p0

    throw p1
.end method

.method public final b(Ljava/lang/String;)Landroid/view/View;
    .registers 4

    .prologue
    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Lads_mobile_sdk/ew1;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0
    :try_end_7
    .catchall {:try_start_1 .. :try_end_7} :catchall_1e

    const/4 v1, 0x0

    if-eqz v0, :cond_c

    monitor-exit p0

    return-object v1

    :cond_c
    :try_start_c
    iget-object v0, p0, Lads_mobile_sdk/ew1;->h:Ljava/util/LinkedHashMap;

    invoke-virtual {v0, p1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/ref/WeakReference;

    if-eqz p1, :cond_20

    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p1

    move-object v1, p1

    check-cast v1, Landroid/view/View;
    :try_end_1d
    .catchall {:try_start_c .. :try_end_1d} :catchall_1e

    goto :goto_20

    :catchall_1e
    move-exception p1

    goto :goto_22

    :cond_20
    :goto_20
    monitor-exit p0

    return-object v1

    :goto_22
    monitor-exit p0

    throw p1
.end method

.method public final b()Ljava/util/Map;
    .registers 2

    .prologue
    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Lads_mobile_sdk/ew1;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    if-eqz v0, :cond_f

    sget-object v0, Lca0;->a:Lca0;
    :try_end_b
    .catchall {:try_start_1 .. :try_end_b} :catchall_d

    monitor-exit p0

    return-object v0

    :catchall_d
    move-exception v0

    goto :goto_17

    :cond_f
    :try_start_f
    iget-object v0, p0, Lads_mobile_sdk/ew1;->h:Ljava/util/LinkedHashMap;

    invoke-static {v0}, Lb61;->T(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v0
    :try_end_15
    .catchall {:try_start_f .. :try_end_15} :catchall_d

    monitor-exit p0

    return-object v0

    :goto_17
    monitor-exit p0

    throw v0
.end method

.method public final b(Lcom/google/android/libraries/ads/mobile/sdk/internal/nativead/InternalNativeAd;)V
    .registers 13

    .prologue
    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Lads_mobile_sdk/ew1;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0
    :try_end_7
    .catchall {:try_start_1 .. :try_end_7} :catchall_38

    if-eqz v0, :cond_b

    monitor-exit p0

    return-void

    :cond_b
    :try_start_b
    iget-object v0, p1, Lcom/google/android/libraries/ads/mobile/sdk/internal/nativead/InternalNativeAd;->q:Lads_mobile_sdk/qw1;

    invoke-virtual {v0, p0}, Lads_mobile_sdk/qw1;->a(Lads_mobile_sdk/ew1;)V

    iget-object v0, p1, Lcom/google/android/libraries/ads/mobile/sdk/internal/nativead/InternalNativeAd;->l:Lads_mobile_sdk/iw1;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v1, v0, Lads_mobile_sdk/iw1;->a:Lvy;

    new-instance v2, Lb11;

    const/16 v3, 0xe

    const/4 v4, 0x0

    invoke-direct {v2, v0, p0, v4, v3}, Lb11;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lvx;I)V

    const/4 v0, 0x3

    invoke-static {v1, v4, v4, v2, v0}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    iget-object v5, p1, Lcom/google/android/libraries/ads/mobile/sdk/internal/nativead/InternalNativeAd;->e:Lads_mobile_sdk/zt1;

    new-instance v6, Ljava/lang/ref/WeakReference;

    invoke-direct {v6, p0}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iget-object v7, p0, Lads_mobile_sdk/ew1;->b:Luh;

    iget-object v8, p0, Lads_mobile_sdk/ew1;->h:Ljava/util/LinkedHashMap;
    :try_end_2e
    .catchall {:try_start_b .. :try_end_2e} :catchall_38

    move-object v10, p0

    move-object v9, p0

    :try_start_30
    invoke-virtual/range {v5 .. v10}, Lads_mobile_sdk/zt1;->a(Ljava/lang/ref/WeakReference;Luh;Ljava/util/LinkedHashMap;Lads_mobile_sdk/ew1;Lads_mobile_sdk/ew1;)V
    :try_end_33
    .catchall {:try_start_30 .. :try_end_33} :catchall_35

    monitor-exit v9

    return-void

    :catchall_35
    move-exception v0

    :goto_36
    move-object p0, v0

    goto :goto_3b

    :catchall_38
    move-exception v0

    move-object v9, p0

    goto :goto_36

    :goto_3b
    monitor-exit v9

    throw p0
.end method

.method public final c()Landroid/widget/FrameLayout;
    .registers 2

    .prologue
    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Lads_mobile_sdk/ew1;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0
    :try_end_7
    .catchall {:try_start_1 .. :try_end_7} :catchall_10

    if-eqz v0, :cond_c

    monitor-exit p0

    const/4 p0, 0x0

    return-object p0

    :cond_c
    :try_start_c
    iget-object v0, p0, Lads_mobile_sdk/ew1;->b:Luh;
    :try_end_e
    .catchall {:try_start_c .. :try_end_e} :catchall_10

    monitor-exit p0

    return-object v0

    :catchall_10
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public final c(Lcom/google/android/libraries/ads/mobile/sdk/internal/nativead/InternalNativeAd;)V
    .registers 5

    .prologue
    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Lads_mobile_sdk/ew1;->c:Landroid/widget/FrameLayout;

    const/4 v1, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setClickable(Z)V

    iget-object v0, p0, Lads_mobile_sdk/ew1;->c:Landroid/widget/FrameLayout;

    invoke-virtual {v0}, Landroid/view/ViewGroup;->removeAllViews()V

    iget-object v0, p1, Lcom/google/android/libraries/ads/mobile/sdk/internal/nativead/InternalNativeAd;->q:Lads_mobile_sdk/qw1;

    iget-object v0, v0, Lads_mobile_sdk/qw1;->a:Lk23;

    iget-object v1, v0, Lads_mobile_sdk/jp;->i:Landroid/view/View;

    if-eqz v1, :cond_17

    invoke-virtual {v1, v0}, Landroid/view/View;->removeOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    :cond_17
    iget-object v1, v0, Lads_mobile_sdk/jp;->o:Lads_mobile_sdk/fp;

    if-eqz v1, :cond_20

    iget-object v2, v0, Lads_mobile_sdk/jp;->h:Lads_mobile_sdk/g0;

    invoke-virtual {v2, v1}, Lads_mobile_sdk/g0;->a(Lot2;)V

    :cond_20
    const/4 v1, 0x0

    iput-object v1, v0, Lads_mobile_sdk/jp;->o:Lads_mobile_sdk/fp;

    invoke-virtual {v0}, Lads_mobile_sdk/jp;->b()V

    iput-object v1, v0, Lads_mobile_sdk/jp;->i:Landroid/view/View;

    iget-object p1, p1, Lcom/google/android/libraries/ads/mobile/sdk/internal/nativead/InternalNativeAd;->e:Lads_mobile_sdk/zt1;

    iget-object v0, p0, Lads_mobile_sdk/ew1;->b:Luh;

    iget-object v1, p0, Lads_mobile_sdk/ew1;->h:Ljava/util/LinkedHashMap;

    invoke-virtual {p1, v0, v1}, Lads_mobile_sdk/zt1;->a(Luh;Ljava/util/LinkedHashMap;)V
    :try_end_31
    .catchall {:try_start_1 .. :try_end_31} :catchall_33

    monitor-exit p0

    return-void

    :catchall_33
    move-exception p1

    monitor-exit p0

    throw p1
.end method

.method public final d()Landroid/widget/FrameLayout;
    .registers 2

    .prologue
    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Lads_mobile_sdk/ew1;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0
    :try_end_7
    .catchall {:try_start_1 .. :try_end_7} :catchall_10

    if-eqz v0, :cond_c

    monitor-exit p0

    const/4 p0, 0x0

    return-object p0

    :cond_c
    :try_start_c
    iget-object v0, p0, Lads_mobile_sdk/ew1;->c:Landroid/widget/FrameLayout;
    :try_end_e
    .catchall {:try_start_c .. :try_end_e} :catchall_10

    monitor-exit p0

    return-object v0

    :catchall_10
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public final e()Landroid/widget/ImageView$ScaleType;
    .registers 2

    .prologue
    monitor-enter p0

    :try_start_1
    iget-object v0, p0, Lads_mobile_sdk/ew1;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0
    :try_end_7
    .catchall {:try_start_1 .. :try_end_7} :catchall_10

    if-eqz v0, :cond_c

    monitor-exit p0

    const/4 p0, 0x0

    return-object p0

    :cond_c
    :try_start_c
    iget-object v0, p0, Lads_mobile_sdk/ew1;->f:Landroid/widget/ImageView$ScaleType;
    :try_end_e
    .catchall {:try_start_c .. :try_end_e} :catchall_10

    monitor-exit p0

    return-object v0

    :catchall_10
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public final onClick(Landroid/view/View;)V
    .registers 6

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    monitor-enter p0

    :try_start_4
    iget-object v0, p0, Lads_mobile_sdk/ew1;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    if-nez v0, :cond_2b

    iget-object v0, p0, Lads_mobile_sdk/ew1;->g:Landroid/view/GestureDetector;

    if-eqz v0, :cond_11

    goto :goto_2b

    :cond_11
    iget-object v0, p0, Lads_mobile_sdk/ew1;->i:Lcom/google/android/libraries/ads/mobile/sdk/internal/nativead/InternalNativeAd;

    if-eqz v0, :cond_29

    iget-object v0, v0, Lcom/google/android/libraries/ads/mobile/sdk/internal/nativead/InternalNativeAd;->e:Lads_mobile_sdk/zt1;

    if-eqz v0, :cond_29

    iget-object v1, p0, Lads_mobile_sdk/ew1;->b:Luh;

    iget-object v2, p0, Lads_mobile_sdk/ew1;->h:Ljava/util/LinkedHashMap;

    iget-object v3, p0, Lads_mobile_sdk/ew1;->f:Landroid/widget/ImageView$ScaleType;

    if-nez v3, :cond_26

    sget-object v3, Lads_mobile_sdk/iw1;->i:Landroid/widget/ImageView$ScaleType;

    goto :goto_26

    :catchall_24
    move-exception p1

    goto :goto_2d

    :cond_26
    :goto_26
    invoke-virtual {v0, p1, v1, v2, v3}, Lads_mobile_sdk/zt1;->a(Landroid/view/View;Luh;Ljava/util/LinkedHashMap;Landroid/widget/ImageView$ScaleType;)V
    :try_end_29
    .catchall {:try_start_4 .. :try_end_29} :catchall_24

    :cond_29
    monitor-exit p0

    return-void

    :cond_2b
    :goto_2b
    monitor-exit p0

    return-void

    :goto_2d
    monitor-exit p0

    throw p1
.end method

.method public final onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .registers 9

    .prologue
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    monitor-enter p0

    :try_start_4
    iget-object v0, p0, Lads_mobile_sdk/ew1;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0
    :try_end_a
    .catchall {:try_start_4 .. :try_end_a} :catchall_35

    const/4 v1, 0x0

    if-eqz v0, :cond_f

    monitor-exit p0

    return v1

    :cond_f
    :try_start_f
    iget-object v0, p0, Lads_mobile_sdk/ew1;->i:Lcom/google/android/libraries/ads/mobile/sdk/internal/nativead/InternalNativeAd;

    if-eqz v0, :cond_71

    iget-object v2, v0, Lcom/google/android/libraries/ads/mobile/sdk/internal/nativead/InternalNativeAd;->e:Lads_mobile_sdk/zt1;

    if-nez v2, :cond_18

    goto :goto_71

    :cond_18
    iget-object v0, v0, Lcom/google/android/libraries/ads/mobile/sdk/internal/nativead/InternalNativeAd;->r:Lads_mobile_sdk/qr0;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v3, "gads:report_touch_event_on_intercept_touch:enabled"

    sget-object v4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sget-object v5, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    invoke-virtual {v0, v3, v4, v5}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-nez v0, :cond_37

    iget-object v0, p0, Lads_mobile_sdk/ew1;->b:Luh;

    invoke-virtual {v2, v0, p2}, Lads_mobile_sdk/zt1;->a(Luh;Landroid/view/MotionEvent;)V

    goto :goto_37

    :catchall_35
    move-exception p1

    goto :goto_73

    :cond_37
    :goto_37
    iget-object v0, p0, Lads_mobile_sdk/ew1;->i:Lcom/google/android/libraries/ads/mobile/sdk/internal/nativead/InternalNativeAd;

    if-eqz v0, :cond_6f

    iget-object v0, v0, Lcom/google/android/libraries/ads/mobile/sdk/internal/nativead/InternalNativeAd;->r:Lads_mobile_sdk/qr0;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v3, "gads:native_ad_view:on_intercept_touch_event:enabled"

    sget-object v4, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {v0, v3, v4, v5}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-nez v0, :cond_6f

    iget-object v0, p0, Lads_mobile_sdk/ew1;->i:Lcom/google/android/libraries/ads/mobile/sdk/internal/nativead/InternalNativeAd;

    if-eqz v0, :cond_5b

    iget-object v0, v0, Lcom/google/android/libraries/ads/mobile/sdk/internal/nativead/InternalNativeAd;->s:Lads_mobile_sdk/hg0;

    if-eqz v0, :cond_5b

    invoke-virtual {v0, p2}, Lads_mobile_sdk/hg0;->a(Landroid/view/MotionEvent;)V

    :cond_5b
    invoke-virtual {v2}, Lads_mobile_sdk/zt1;->e()I

    move-result v0

    if-eqz v0, :cond_6f

    new-instance v0, Ljava/lang/ref/WeakReference;

    invoke-direct {v0, p1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    iput-object v0, v2, Lads_mobile_sdk/zt1;->f:Ljava/lang/ref/WeakReference;

    iget-object p1, p0, Lads_mobile_sdk/ew1;->g:Landroid/view/GestureDetector;

    if-eqz p1, :cond_6f

    invoke-virtual {p1, p2}, Landroid/view/GestureDetector;->onTouchEvent(Landroid/view/MotionEvent;)Z
    :try_end_6f
    .catchall {:try_start_f .. :try_end_6f} :catchall_35

    :cond_6f
    monitor-exit p0

    return v1

    :cond_71
    :goto_71
    monitor-exit p0

    return v1

    :goto_73
    monitor-exit p0

    throw p1
.end method
