.class public final Lads_mobile_sdk/fl;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lb23;


# instance fields
.field public final a:I

.field public final b:Z

.field public final c:Z

.field public final d:I

.field public final e:Ldj1;

.field public final f:I

.field public final g:I

.field public final h:F

.field public final i:Z

.field public final j:Ljava/lang/Double;


# direct methods
.method public constructor <init>(IZZILdj1;IIFZLjava/lang/Double;)V
    .registers 11

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lads_mobile_sdk/fl;->a:I

    iput-boolean p2, p0, Lads_mobile_sdk/fl;->b:Z

    iput-boolean p3, p0, Lads_mobile_sdk/fl;->c:Z

    iput p4, p0, Lads_mobile_sdk/fl;->d:I

    iput-object p5, p0, Lads_mobile_sdk/fl;->e:Ldj1;

    iput p6, p0, Lads_mobile_sdk/fl;->f:I

    iput p7, p0, Lads_mobile_sdk/fl;->g:I

    iput p8, p0, Lads_mobile_sdk/fl;->h:F

    iput-boolean p9, p0, Lads_mobile_sdk/fl;->i:Z

    iput-object p10, p0, Lads_mobile_sdk/fl;->j:Ljava/lang/Double;

    return-void
.end method


# virtual methods
.method public final a(Lg32;)V
    .registers 4

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget v0, p0, Lads_mobile_sdk/fl;->a:I

    iput v0, p1, Lg32;->V:I

    iget-boolean v0, p0, Lads_mobile_sdk/fl;->b:Z

    iput-boolean v0, p1, Lg32;->W:Z

    iget-boolean v0, p0, Lads_mobile_sdk/fl;->c:Z

    iput-boolean v0, p1, Lg32;->X:Z

    iget v0, p0, Lads_mobile_sdk/fl;->d:I

    iput v0, p1, Lg32;->Y:I

    iget-object v0, p0, Lads_mobile_sdk/fl;->e:Ldj1;

    if-eqz v0, :cond_23

    iget-object v1, v0, Ldj1;->a:Ljava/lang/Object;

    check-cast v1, Ljava/lang/Integer;

    iput-object v1, p1, Lg32;->Z:Ljava/lang/Integer;

    iget-object v0, v0, Ldj1;->b:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    iput-object v0, p1, Lg32;->a0:Ljava/lang/Integer;

    :cond_23
    iget v0, p0, Lads_mobile_sdk/fl;->f:I

    iput v0, p1, Lg32;->c0:I

    iget v0, p0, Lads_mobile_sdk/fl;->g:I

    iput v0, p1, Lg32;->d0:I

    iget v0, p0, Lads_mobile_sdk/fl;->h:F

    iput v0, p1, Lg32;->e0:F

    iget-boolean v0, p0, Lads_mobile_sdk/fl;->i:Z

    iput-boolean v0, p1, Lg32;->f0:Z

    iget-object p0, p0, Lads_mobile_sdk/fl;->j:Ljava/lang/Double;

    iput-object p0, p1, Lg32;->b0:Ljava/lang/Double;

    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .prologue
    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lads_mobile_sdk/fl;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, Lads_mobile_sdk/fl;

    iget v1, p0, Lads_mobile_sdk/fl;->a:I

    iget v3, p1, Lads_mobile_sdk/fl;->a:I

    if-eq v1, v3, :cond_13

    return v2

    :cond_13
    iget-boolean v1, p0, Lads_mobile_sdk/fl;->b:Z

    iget-boolean v3, p1, Lads_mobile_sdk/fl;->b:Z

    if-eq v1, v3, :cond_1a

    return v2

    :cond_1a
    iget-boolean v1, p0, Lads_mobile_sdk/fl;->c:Z

    iget-boolean v3, p1, Lads_mobile_sdk/fl;->c:Z

    if-eq v1, v3, :cond_21

    return v2

    :cond_21
    iget v1, p0, Lads_mobile_sdk/fl;->d:I

    iget v3, p1, Lads_mobile_sdk/fl;->d:I

    if-eq v1, v3, :cond_28

    return v2

    :cond_28
    iget-object v1, p0, Lads_mobile_sdk/fl;->e:Ldj1;

    iget-object v3, p1, Lads_mobile_sdk/fl;->e:Ldj1;

    invoke-static {v1, v3}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_33

    return v2

    :cond_33
    iget v1, p0, Lads_mobile_sdk/fl;->f:I

    iget v3, p1, Lads_mobile_sdk/fl;->f:I

    if-eq v1, v3, :cond_3a

    return v2

    :cond_3a
    iget v1, p0, Lads_mobile_sdk/fl;->g:I

    iget v3, p1, Lads_mobile_sdk/fl;->g:I

    if-eq v1, v3, :cond_41

    return v2

    :cond_41
    iget v1, p0, Lads_mobile_sdk/fl;->h:F

    iget v3, p1, Lads_mobile_sdk/fl;->h:F

    invoke-static {v1, v3}, Ljava/lang/Float;->compare(FF)I

    move-result v1

    if-eqz v1, :cond_4c

    return v2

    :cond_4c
    iget-boolean v1, p0, Lads_mobile_sdk/fl;->i:Z

    iget-boolean v3, p1, Lads_mobile_sdk/fl;->i:Z

    if-eq v1, v3, :cond_53

    return v2

    :cond_53
    iget-object p0, p0, Lads_mobile_sdk/fl;->j:Ljava/lang/Double;

    iget-object p1, p1, Lads_mobile_sdk/fl;->j:Ljava/lang/Double;

    invoke-static {p0, p1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_5e

    return v2

    :cond_5e
    return v0
.end method

.method public final hashCode()I
    .registers 5

    .prologue
    iget v0, p0, Lads_mobile_sdk/fl;->a:I

    invoke-static {v0}, Ljava/lang/Integer;->hashCode(I)I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    const/4 v1, 0x1

    iget-boolean v2, p0, Lads_mobile_sdk/fl;->b:Z

    if-eqz v2, :cond_e

    move v2, v1

    :cond_e
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget-boolean v2, p0, Lads_mobile_sdk/fl;->c:Z

    if-eqz v2, :cond_16

    move v2, v1

    :cond_16
    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    iget v2, p0, Lads_mobile_sdk/fl;->d:I

    invoke-static {v2, v0}, Lsz;->c(II)I

    move-result v0

    const/4 v2, 0x0

    iget-object v3, p0, Lads_mobile_sdk/fl;->e:Ldj1;

    if-nez v3, :cond_26

    move v3, v2

    goto :goto_2a

    :cond_26
    invoke-virtual {v3}, Ldj1;->hashCode()I

    move-result v3

    :goto_2a
    add-int/2addr v0, v3

    mul-int/lit8 v0, v0, 0x1f

    iget v3, p0, Lads_mobile_sdk/fl;->f:I

    invoke-static {v3, v0}, Lsz;->c(II)I

    move-result v0

    iget v3, p0, Lads_mobile_sdk/fl;->g:I

    invoke-static {v3, v0}, Lsz;->c(II)I

    move-result v0

    iget v3, p0, Lads_mobile_sdk/fl;->h:F

    invoke-static {v3}, Ljava/lang/Float;->hashCode(F)I

    move-result v3

    add-int/2addr v3, v0

    mul-int/lit8 v3, v3, 0x1f

    iget-boolean v0, p0, Lads_mobile_sdk/fl;->i:Z

    if-eqz v0, :cond_47

    goto :goto_48

    :cond_47
    move v1, v0

    :goto_48
    add-int/2addr v3, v1

    mul-int/lit8 v3, v3, 0x1f

    iget-object p0, p0, Lads_mobile_sdk/fl;->j:Ljava/lang/Double;

    if-nez p0, :cond_50

    goto :goto_54

    :cond_50
    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result v2

    :goto_54
    add-int/2addr v3, v2

    return v3
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "AudioSignal(audioMode="

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v1, p0, Lads_mobile_sdk/fl;->a:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", isMusicActive="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, Lads_mobile_sdk/fl;->b:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, ", isSpeakerPhoneOn="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, Lads_mobile_sdk/fl;->c:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, ", musicVolume="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lads_mobile_sdk/fl;->d:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", minMaxMusicVolume="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lads_mobile_sdk/fl;->e:Ldj1;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", ringerMode="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lads_mobile_sdk/fl;->f:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", ringerVolume="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lads_mobile_sdk/fl;->g:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", appVolume="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lads_mobile_sdk/fl;->h:F

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const-string v1, ", isAppMuted="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, Lads_mobile_sdk/fl;->i:Z

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, ", musicVolumePercent="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object p0, p0, Lads_mobile_sdk/fl;->j:Ljava/lang/Double;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
