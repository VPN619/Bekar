.class public final Lads_mobile_sdk/di1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ldv2;


# instance fields
.field public final a:Lli;

.field public final b:Lads_mobile_sdk/cu2;

.field public final c:Landroid/content/Context;

.field public final d:Lads_mobile_sdk/g0;

.field public final e:Lads_mobile_sdk/rh0;

.field public final f:Ltv2;


# direct methods
.method public constructor <init>(Lli;Lads_mobile_sdk/cu2;Landroid/content/Context;Lads_mobile_sdk/g0;Lads_mobile_sdk/rh0;Lads_mobile_sdk/ab0;)V
    .registers 7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/di1;->a:Lli;

    iput-object p2, p0, Lads_mobile_sdk/di1;->b:Lads_mobile_sdk/cu2;

    iput-object p3, p0, Lads_mobile_sdk/di1;->c:Landroid/content/Context;

    iput-object p4, p0, Lads_mobile_sdk/di1;->d:Lads_mobile_sdk/g0;

    iput-object p5, p0, Lads_mobile_sdk/di1;->e:Lads_mobile_sdk/rh0;

    iput-object p6, p0, Lads_mobile_sdk/di1;->f:Ltv2;

    return-void
.end method


# virtual methods
.method public final a(Lads_mobile_sdk/n13;Lads_mobile_sdk/a2;Lk53;)Lm23;
    .registers 5

    check-cast p3, Lads_mobile_sdk/ko1;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p1, p0, Lads_mobile_sdk/di1;->f:Ltv2;

    invoke-interface {p1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lads_mobile_sdk/we0;

    new-instance p2, Lrw2;

    const/4 v0, 0x0

    invoke-direct {p2, p3, p0, v0}, Lrw2;-><init>(Lads_mobile_sdk/q61;Ldv2;I)V

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p2, p1, Lads_mobile_sdk/we0;->p:Lxy2;

    return-object p1
.end method

.method public final a(Lads_mobile_sdk/n13;Lads_mobile_sdk/a2;Lk53;Lads_mobile_sdk/os;)V
    .registers 19

    .prologue
    move-object/from16 v0, p3

    check-cast v0, Lads_mobile_sdk/ko1;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p2 .. p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v1, v0, Lads_mobile_sdk/q61;->a:Lcom/google/android/gms/ads/mediation/Adapter;

    iget-object v2, p0, Lads_mobile_sdk/di1;->d:Lads_mobile_sdk/g0;

    invoke-virtual {v2}, Lads_mobile_sdk/g0;->b()Landroid/app/Activity;

    move-result-object v2

    if-eqz v2, :cond_19

    :goto_17
    move-object v4, v2

    goto :goto_1c

    :cond_19
    iget-object v2, p0, Lads_mobile_sdk/di1;->c:Landroid/content/Context;

    goto :goto_17

    :goto_1c
    iget-object v2, p0, Lads_mobile_sdk/di1;->b:Lads_mobile_sdk/cu2;

    invoke-virtual {v2}, Lads_mobile_sdk/cu2;->a()Lut1;

    move-result-object v2

    move-object/from16 v3, p2

    iget-object v3, v3, Lads_mobile_sdk/a2;->c:Lfx0;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v5, p0, Lads_mobile_sdk/di1;->a:Lli;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p0, Lads_mobile_sdk/di1;->e:Lads_mobile_sdk/rh0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v6, Lcom/google/android/gms/ads/mediation/MediationInterstitialAdConfiguration;

    move-object v7, v6

    invoke-static {v3}, Lmu2;->b(Lfx0;)Landroid/os/Bundle;

    move-result-object v6

    invoke-static {v5, v1}, Lmu2;->a(Lli;Lcom/google/android/gms/ads/mediation/MediationExtrasReceiver;)Landroid/os/Bundle;

    move-result-object v5

    invoke-virtual {v2, v4}, Lut1;->a(Landroid/content/Context;)Z

    move-result v8

    invoke-static {v3, v2}, Lmu2;->d(Lfx0;Lut1;)Ljava/lang/String;

    move-result-object v12

    const/4 v9, 0x0

    const-string v13, ""

    move-object v3, v7

    move-object v7, v5

    const-string v5, ""

    const/4 v10, -0x1

    const/4 v11, -0x1

    invoke-direct/range {v3 .. v13}, Lcom/google/android/gms/ads/mediation/MediationInterstitialAdConfiguration;-><init>(Landroid/content/Context;Ljava/lang/String;Landroid/os/Bundle;Landroid/os/Bundle;ZLandroid/location/Location;IILjava/lang/String;Ljava/lang/String;)V

    new-instance v2, Lads_mobile_sdk/do1;

    const/4 v4, 0x2

    invoke-direct {v2, v0, v4}, Lads_mobile_sdk/do1;-><init>(Lads_mobile_sdk/ko1;I)V

    new-instance v0, Lads_mobile_sdk/ap1;

    const/4 v4, 0x3

    move-object/from16 v5, p4

    invoke-direct {v0, p0, v5, v2, v4}, Lads_mobile_sdk/ap1;-><init>(Lads_mobile_sdk/rh0;Lads_mobile_sdk/os;Lbk0;I)V

    invoke-virtual {v1, v3, v0}, Lcom/google/android/gms/ads/mediation/Adapter;->loadInterstitialAd(Lcom/google/android/gms/ads/mediation/MediationInterstitialAdConfiguration;Lcom/google/android/gms/ads/mediation/MediationAdLoadCallback;)V

    return-void
.end method
