.class public final Lads_mobile_sdk/bw2;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Loj2;


# static fields
.field public static final a:Lads_mobile_sdk/bw2;

.field public static final a$1:Lads_mobile_sdk/bw2;

.field public static final b:Lxx1;


# direct methods
.method static synthetic constructor <clinit>()V
    .registers 2

    new-instance v0, Lxx1;

    const/4 v1, 0x7

    invoke-direct {v0, v1}, Lxx1;-><init>(I)V

    sput-object v0, Lads_mobile_sdk/bw2;->b:Lxx1;

    new-instance v0, Lads_mobile_sdk/bw2;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lads_mobile_sdk/bw2;->a:Lads_mobile_sdk/bw2;

    new-instance v0, Lads_mobile_sdk/bw2;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lads_mobile_sdk/bw2;->a$1:Lads_mobile_sdk/bw2;

    return-void
.end method

.method public static a(Lfx0;Ljava/lang/String;I)I
    .registers 3

    .prologue
    if-nez p0, :cond_3

    goto :goto_c

    :cond_3
    :try_start_3
    invoke-virtual {p0, p1}, Lfx0;->v(Ljava/lang/String;)Lkw0;

    move-result-object p0

    invoke-virtual {p0}, Lkw0;->e()I

    move-result p0
    :try_end_b
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_b} :catch_c

    return p0

    :catch_c
    :goto_c
    return p2
.end method

.method public static a(Ljava/lang/String;)Landroid/os/Bundle;
    .registers 3

    .prologue
    :try_start_0
    invoke-static {p0}, Llk;->B(Ljava/lang/String;)Lkw0;

    move-result-object p0

    invoke-virtual {p0}, Lkw0;->h()Lfx0;

    move-result-object p0

    invoke-static {p0}, Lads_mobile_sdk/bw2;->c(Lfx0;)Landroid/os/Bundle;

    move-result-object p0
    :try_end_c
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_c} :catch_d

    return-object p0

    :catch_d
    move-exception p0

    invoke-static {p0}, Lrt2;->c(Ljava/lang/Exception;)Lads_mobile_sdk/ub2;

    move-result-object v0

    iget-object v0, v0, Lads_mobile_sdk/ub2;->s:Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_22

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    :cond_22
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 p0, 0x0

    return-object p0
.end method

.method public static a(Lkw0;)Lfx0;
    .registers 1

    .prologue
    if-nez p0, :cond_3

    goto :goto_8

    :cond_3
    :try_start_3
    invoke-virtual {p0}, Lkw0;->h()Lfx0;

    move-result-object p0
    :try_end_7
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_7} :catch_8

    return-object p0

    :catch_8
    :goto_8
    const/4 p0, 0x0

    return-object p0
.end method

.method public static a(Lvv0;I)Lfx0;
    .registers 3

    .prologue
    if-nez p0, :cond_3

    goto :goto_17

    :cond_3
    iget-object p0, p0, Lvv0;->a:Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-lt p1, v0, :cond_c

    goto :goto_17

    :cond_c
    :try_start_c
    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lkw0;

    invoke-virtual {p0}, Lkw0;->h()Lfx0;

    move-result-object p0
    :try_end_16
    .catch Ljava/lang/Exception; {:try_start_c .. :try_end_16} :catch_17

    return-object p0

    :catch_17
    :goto_17
    const/4 p0, 0x0

    return-object p0
.end method

.method public static a(Lfx0;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 3

    .prologue
    if-nez p0, :cond_3

    goto :goto_f

    :cond_3
    :try_start_3
    invoke-virtual {p0, p1}, Lfx0;->v(Ljava/lang/String;)Lkw0;

    move-result-object p0

    invoke-virtual {p0}, Lkw0;->m()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_e
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_e} :catch_f

    return-object p0

    :catch_f
    :goto_f
    return-object p2
.end method

.method public static a(Landroid/webkit/WebView;Ljava/lang/String;)V
    .registers 4

    .prologue
    const-string v0, "javascript: "

    if-eqz p0, :cond_23

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_23

    const/4 v1, 0x0

    :try_start_b
    invoke-virtual {p0, p1, v1}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V
    :try_end_e
    .catch Ljava/lang/IllegalStateException; {:try_start_b .. :try_end_e} :catch_f
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_e} :catch_1f

    return-void

    :catch_f
    :try_start_f
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
    :try_end_1e
    .catch Ljava/lang/Exception; {:try_start_f .. :try_end_1e} :catch_1f

    goto :goto_23

    :catch_1f
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    :cond_23
    :goto_23
    return-void
.end method

.method public static a(Lox0;Landroid/os/Bundle;Ljava/lang/String;)V
    .registers 8

    .prologue
    iget-object v0, p0, Lox0;->a:Ljava/io/Serializable;

    instance-of v1, v0, Ljava/lang/Boolean;

    if-eqz v1, :cond_e

    invoke-virtual {p0}, Lox0;->b()Z

    move-result p0

    invoke-virtual {p1, p2, p0}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    return-void

    :cond_e
    instance-of v1, v0, Ljava/lang/Number;

    if-eqz v1, :cond_2b

    invoke-virtual {p0}, Lox0;->l()Ljava/lang/Number;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Number;->intValue()I

    move-result v0

    invoke-virtual {p0}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v1

    int-to-double v3, v0

    cmpg-double p0, v3, v1

    if-nez p0, :cond_27

    invoke-virtual {p1, p2, v0}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    return-void

    :cond_27
    invoke-virtual {p1, p2, v1, v2}, Landroid/os/BaseBundle;->putDouble(Ljava/lang/String;D)V

    return-void

    :cond_2b
    instance-of v0, v0, Ljava/lang/String;

    if-eqz v0, :cond_37

    invoke-virtual {p0}, Lox0;->m()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1, p2, p0}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_37
    new-instance p1, Ljava/lang/StringBuilder;

    const-string p2, "Unexpected primitive json type: "

    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 p1, 0x0

    invoke-static {p0, p1}, Lads_mobile_sdk/nw;->c(Ljava/lang/String;Ljava/lang/Exception;)V

    return-void
.end method

.method public static a(Lvv0;Landroid/os/Bundle;Ljava/lang/String;)V
    .registers 16

    .prologue
    iget-object v0, p0, Lvv0;->a:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_13

    const-string p0, "Unable to parse empty JsonArray for key: "

    invoke-virtual {p0, p2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0, v2}, Lads_mobile_sdk/nw;->c(Ljava/lang/String;Ljava/lang/Exception;)V

    return-void

    :cond_13
    invoke-static {p0}, Lbs;->j0(Ljava/lang/Iterable;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lkw0;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    instance-of v3, v1, Lfx0;

    const/16 v4, 0xa

    const/4 v5, 0x0

    if-eqz v3, :cond_53

    new-instance v1, Ljava/util/ArrayList;

    invoke-static {p0, v4}, Lds;->Y(Ljava/lang/Iterable;I)I

    move-result p0

    invoke-direct {v1, p0}, Ljava/util/ArrayList;-><init>(I)V

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result p0

    move v2, v5

    :goto_31
    if-ge v2, p0, :cond_47

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    add-int/lit8 v2, v2, 0x1

    check-cast v3, Lkw0;

    invoke-virtual {v3}, Lkw0;->h()Lfx0;

    move-result-object v3

    invoke-static {v3}, Lads_mobile_sdk/bw2;->b(Lfx0;)Landroid/os/Bundle;

    move-result-object v3

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_31

    :cond_47
    new-array p0, v5, [Landroid/os/Bundle;

    invoke-virtual {v1, p0}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p0

    check-cast p0, [Landroid/os/Parcelable;

    invoke-virtual {p1, p2, p0}, Landroid/os/Bundle;->putParcelableArray(Ljava/lang/String;[Landroid/os/Parcelable;)V

    return-void

    :cond_53
    instance-of v3, v1, Lox0;

    const-string v6, "Unable to parse array element type: "

    if-eqz v3, :cond_17d

    new-instance v1, Ljava/util/ArrayList;

    invoke-static {p0, v4}, Lds;->Y(Ljava/lang/Iterable;I)I

    move-result p0

    invoke-direct {v1, p0}, Ljava/util/ArrayList;-><init>(I)V

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result p0

    move v3, v5

    :goto_67
    if-ge v3, p0, :cond_c5

    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    add-int/lit8 v3, v3, 0x1

    check-cast v7, Lkw0;

    invoke-virtual {v7}, Lkw0;->i()Lox0;

    move-result-object v7

    iget-object v8, v7, Lox0;->a:Ljava/io/Serializable;

    instance-of v9, v8, Ljava/lang/Boolean;

    if-eqz v9, :cond_84

    invoke-virtual {v7}, Lox0;->b()Z

    move-result v7

    invoke-static {v7}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v7

    goto :goto_be

    :cond_84
    instance-of v9, v8, Ljava/lang/Number;

    if-eqz v9, :cond_a3

    invoke-virtual {v7}, Lox0;->l()Ljava/lang/Number;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Number;->intValue()I

    move-result v8

    invoke-virtual {v7}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v9

    int-to-double v11, v8

    cmpg-double v7, v11, v9

    if-nez v7, :cond_9e

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    goto :goto_be

    :cond_9e
    invoke-static {v9, v10}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v7

    goto :goto_be

    :cond_a3
    instance-of v8, v8, Ljava/lang/String;

    if-eqz v8, :cond_ac

    invoke-virtual {v7}, Lox0;->m()Ljava/lang/String;

    move-result-object v7

    goto :goto_be

    :cond_ac
    new-instance v8, Ljava/lang/StringBuilder;

    const-string v9, "Unexpected primitive json type: "

    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-static {v7, v2}, Lads_mobile_sdk/nw;->c(Ljava/lang/String;Ljava/lang/Exception;)V

    move-object v7, v2

    :goto_be
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_67

    :cond_c5
    invoke-static {v1}, Lbs;->k0(Ljava/util/List;)Ljava/lang/Object;

    move-result-object p0

    instance-of p0, p0, Ljava/lang/String;

    if-eqz p0, :cond_f7

    new-instance p0, Ljava/util/ArrayList;

    invoke-static {v1, v4}, Lds;->Y(Ljava/lang/Iterable;I)I

    move-result v0

    invoke-direct {p0, v0}, Ljava/util/ArrayList;-><init>(I)V

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v0

    move v2, v5

    :goto_db
    if-ge v2, v0, :cond_eb

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    add-int/lit8 v2, v2, 0x1

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {p0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_db

    :cond_eb
    new-array v0, v5, [Ljava/lang/String;

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p0

    check-cast p0, [Ljava/lang/String;

    invoke-virtual {p1, p2, p0}, Landroid/os/BaseBundle;->putStringArray(Ljava/lang/String;[Ljava/lang/String;)V

    return-void

    :cond_f7
    invoke-static {v1}, Lbs;->k0(Ljava/util/List;)Ljava/lang/Object;

    move-result-object p0

    instance-of p0, p0, Ljava/lang/Integer;

    if-eqz p0, :cond_11d

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result p0

    new-array v0, p0, [I

    :goto_105
    if-ge v5, p0, :cond_119

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    aput v2, v0, v5

    add-int/lit8 v5, v5, 0x1

    goto :goto_105

    :cond_119
    invoke-virtual {p1, p2, v0}, Landroid/os/BaseBundle;->putIntArray(Ljava/lang/String;[I)V

    return-void

    :cond_11d
    invoke-static {v1}, Lbs;->k0(Ljava/util/List;)Ljava/lang/Object;

    move-result-object p0

    instance-of p0, p0, Ljava/lang/Double;

    if-eqz p0, :cond_143

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result p0

    new-array v0, p0, [D

    :goto_12b
    if-ge v5, p0, :cond_13f

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v2, Ljava/lang/Double;

    invoke-virtual {v2}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v2

    aput-wide v2, v0, v5

    add-int/lit8 v5, v5, 0x1

    goto :goto_12b

    :cond_13f
    invoke-virtual {p1, p2, v0}, Landroid/os/BaseBundle;->putDoubleArray(Ljava/lang/String;[D)V

    return-void

    :cond_143
    invoke-static {v1}, Lbs;->k0(Ljava/util/List;)Ljava/lang/Object;

    move-result-object p0

    instance-of p0, p0, Ljava/lang/Boolean;

    if-eqz p0, :cond_169

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result p0

    new-array v0, p0, [Z

    :goto_151
    if-ge v5, p0, :cond_165

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v2, Ljava/lang/Boolean;

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    aput-boolean v2, v0, v5

    add-int/lit8 v5, v5, 0x1

    goto :goto_151

    :cond_165
    invoke-virtual {p1, p2, v0}, Landroid/os/BaseBundle;->putBooleanArray(Ljava/lang/String;[Z)V

    return-void

    :cond_169
    invoke-static {v1}, Lbs;->k0(Ljava/util/List;)Ljava/lang/Object;

    move-result-object p0

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0, v2}, Lads_mobile_sdk/nw;->c(Ljava/lang/String;Ljava/lang/Exception;)V

    return-void

    :cond_17d
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0, v2}, Lads_mobile_sdk/nw;->c(Ljava/lang/String;Ljava/lang/Exception;)V

    return-void
.end method

.method public static a(Lfx0;Ljava/lang/String;Z)Z
    .registers 3

    .prologue
    if-nez p0, :cond_3

    goto :goto_c

    :cond_3
    :try_start_3
    invoke-virtual {p0, p1}, Lfx0;->v(Ljava/lang/String;)Lkw0;

    move-result-object p0

    invoke-virtual {p0}, Lkw0;->b()Z

    move-result p0
    :try_end_b
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_b} :catch_c

    return p0

    :catch_c
    :goto_c
    return p2
.end method

.method public static b(Lfx0;)Landroid/os/Bundle;
    .registers 1

    .prologue
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p0}, Lads_mobile_sdk/bw2;->c(Lfx0;)Landroid/os/Bundle;

    move-result-object p0

    if-nez p0, :cond_e

    new-instance p0, Landroid/os/Bundle;

    invoke-direct {p0}, Landroid/os/Bundle;-><init>()V

    :cond_e
    return-object p0
.end method

.method public static c(Lfx0;)Landroid/os/Bundle;
    .registers 6

    .prologue
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_3
    new-instance v0, Landroid/os/Bundle;

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    iget-object v1, p0, Lfx0;->a:Lf21;

    invoke-virtual {v1}, Lf21;->keySet()Ljava/util/Set;

    move-result-object v1

    check-cast v1, Ld21;

    invoke-virtual {v1}, Ld21;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_14
    :goto_14
    move-object v2, v1

    check-cast v2, Lc21;

    invoke-virtual {v2}, Lc21;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_5d

    move-object v2, v1

    check-cast v2, Lc21;

    invoke-virtual {v2}, Lc21;->b()Le21;

    move-result-object v2

    iget-object v2, v2, Le21;->f:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    invoke-virtual {p0, v2}, Lfx0;->v(Ljava/lang/String;)Lkw0;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    instance-of v4, v3, Lox0;

    if-eqz v4, :cond_3e

    invoke-virtual {v3}, Lkw0;->i()Lox0;

    move-result-object v3

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v3, v0, v2}, Lads_mobile_sdk/bw2;->a(Lox0;Landroid/os/Bundle;Ljava/lang/String;)V

    goto :goto_14

    :cond_3e
    instance-of v4, v3, Lvv0;

    if-eqz v4, :cond_4d

    invoke-virtual {v3}, Lkw0;->f()Lvv0;

    move-result-object v3

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v3, v0, v2}, Lads_mobile_sdk/bw2;->a(Lvv0;Landroid/os/Bundle;Ljava/lang/String;)V

    goto :goto_14

    :cond_4d
    instance-of v4, v3, Lfx0;

    if-eqz v4, :cond_14

    invoke-virtual {v3}, Lkw0;->h()Lfx0;

    move-result-object v3

    invoke-static {v3}, Lads_mobile_sdk/bw2;->b(Lfx0;)Landroid/os/Bundle;

    move-result-object v3

    invoke-virtual {v0, v2, v3}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V
    :try_end_5c
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_5c} :catch_5e

    goto :goto_14

    :cond_5d
    return-object v0

    :catch_5e
    move-exception p0

    invoke-static {p0}, Lrt2;->c(Ljava/lang/Exception;)Lads_mobile_sdk/ub2;

    move-result-object v0

    iget-object v0, v0, Lads_mobile_sdk/ub2;->s:Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_73

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    :cond_73
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 p0, 0x0

    return-object p0
.end method

.method public static e(Lfx0;Ljava/lang/String;)Lvv0;
    .registers 2

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-nez p0, :cond_6

    goto :goto_b

    :cond_6
    :try_start_6
    invoke-virtual {p0, p1}, Lfx0;->w(Ljava/lang/String;)Lvv0;

    move-result-object p0
    :try_end_a
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_a} :catch_b

    return-object p0

    :catch_b
    :goto_b
    const/4 p0, 0x0

    return-object p0
.end method


# virtual methods
.method public varargs a(Landroid/webkit/WebView;Ljava/lang/String;[Ljava/lang/Object;)V
    .registers 8

    .prologue
    if-eqz p1, :cond_89

    new-instance v0, Ljava/lang/StringBuilder;

    const/16 v1, 0x80

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string v1, "if(window.omidBridge!==undefined){omidBridge."

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p2, "("

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    array-length p2, p3

    if-lez p2, :cond_5b

    array-length p2, p3

    const/4 v1, 0x0

    :goto_1b
    if-ge v1, p2, :cond_52

    aget-object v2, p3, v1

    if-nez v2, :cond_27

    const-string v2, "null"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_4a

    :cond_27
    instance-of v3, v2, Ljava/lang/String;

    if-eqz v3, :cond_47

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, "{"

    invoke-virtual {v2, v3}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_3b

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_4a

    :cond_3b
    const/16 v3, 0x22

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_4a

    :cond_47
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    :goto_4a
    const-string v2, ","

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v1, v1, 0x1

    goto :goto_1b

    :cond_52
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->length()I

    move-result p2

    add-int/lit8 p2, p2, -0x1

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->setLength(I)V

    :cond_5b
    const-string p2, ")}"

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1}, Landroid/webkit/WebView;->getHandler()Landroid/os/Handler;

    move-result-object p3

    if-nez p3, :cond_73

    new-instance p3, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-direct {p3, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    :cond_73
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-virtual {p3}, Landroid/os/Handler;->getLooper()Landroid/os/Looper;

    move-result-object v1

    if-ne v0, v1, :cond_81

    invoke-static {p1, p2}, Lads_mobile_sdk/bw2;->a(Landroid/webkit/WebView;Ljava/lang/String;)V

    return-void

    :cond_81
    new-instance v0, Lads_mobile_sdk/x52;

    invoke-direct {v0, p0, p1, p2}, Lads_mobile_sdk/x52;-><init>(Lads_mobile_sdk/bw2;Landroid/webkit/WebView;Ljava/lang/String;)V

    invoke-virtual {p3, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_89
    return-void
.end method

.method public getVideoLifecycleCallbacks()V
    .registers 1

    monitor-enter p0

    monitor-exit p0

    return-void
.end method
