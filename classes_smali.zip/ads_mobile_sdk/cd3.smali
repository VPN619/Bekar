.class public final Lads_mobile_sdk/cd3;
.super Lads_mobile_sdk/f2;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final l:Ldv2;

.field public final m:Ldv2;

.field public final n:Ljava/util/Optional;

.field public final o:Ly03;

.field public final p:Lads_mobile_sdk/rh0;

.field public final q:Lvy;

.field public final r:Lads_mobile_sdk/sb;

.field public s:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ldv2;Ldv2;Ljava/util/Optional;Ly03;Lads_mobile_sdk/rh0;Lvy;Lads_mobile_sdk/sb;Lads_mobile_sdk/kh3;Lli;Lads_mobile_sdk/av2;JILads_mobile_sdk/a2;Lads_mobile_sdk/xv;Lads_mobile_sdk/n13;Ljava/lang/String;Lads_mobile_sdk/ve2;)V
    .registers 31

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p4 .. p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p5 .. p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p6 .. p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p7 .. p7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p8 .. p8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p9 .. p9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p10 .. p10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p14 .. p14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p15 .. p15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p16 .. p16}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p17 .. p17}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p18 .. p18}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-object v0, p0

    move-object/from16 v1, p8

    move-object/from16 v2, p9

    move-object/from16 v3, p10

    move-wide/from16 v4, p11

    move/from16 v6, p13

    move-object/from16 v7, p14

    move-object/from16 v8, p15

    move-object/from16 v9, p16

    move-object/from16 v10, p17

    move-object/from16 v11, p18

    invoke-direct/range {v0 .. v11}, Lads_mobile_sdk/f2;-><init>(Lads_mobile_sdk/kh3;Lli;Lads_mobile_sdk/av2;JILads_mobile_sdk/a2;Lads_mobile_sdk/xv;Lads_mobile_sdk/n13;Ljava/lang/String;Lads_mobile_sdk/ve2;)V

    iput-object p1, p0, Lads_mobile_sdk/cd3;->l:Ldv2;

    iput-object p2, p0, Lads_mobile_sdk/cd3;->m:Ldv2;

    iput-object p3, p0, Lads_mobile_sdk/cd3;->n:Ljava/util/Optional;

    move-object/from16 p1, p4

    iput-object p1, p0, Lads_mobile_sdk/cd3;->o:Ly03;

    move-object/from16 p1, p5

    iput-object p1, p0, Lads_mobile_sdk/cd3;->p:Lads_mobile_sdk/rh0;

    move-object/from16 p1, p6

    iput-object p1, p0, Lads_mobile_sdk/cd3;->q:Lvy;

    move-object/from16 p1, p7

    iput-object p1, p0, Lads_mobile_sdk/cd3;->r:Lads_mobile_sdk/sb;

    return-void
.end method


# virtual methods
.method public final a(Ljava/util/ArrayList;ZLwx;)Ljava/lang/Object;
    .registers 11

    .prologue
    instance-of v0, p3, Lads_mobile_sdk/yc3;

    if-eqz v0, :cond_13

    move-object v0, p3

    check-cast v0, Lads_mobile_sdk/yc3;

    iget v1, v0, Lads_mobile_sdk/yc3;->h:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/yc3;->h:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/yc3;

    invoke-direct {v0, p0, p3}, Lads_mobile_sdk/yc3;-><init>(Lads_mobile_sdk/cd3;Lwx;)V

    :goto_18
    iget-object p3, v0, Lads_mobile_sdk/yc3;->f:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/yc3;->h:I

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_3c

    if-ne v1, v3, :cond_36

    iget-boolean p0, v0, Lads_mobile_sdk/yc3;->e:Z

    iget-object p1, v0, Lads_mobile_sdk/yc3;->d:Ljava/lang/String;

    iget-object p2, v0, Lads_mobile_sdk/yc3;->c:Ljava/util/Iterator;

    iget-object v1, v0, Lads_mobile_sdk/yc3;->b:Lb13;

    iget-object v2, v0, Lads_mobile_sdk/yc3;->a:Lads_mobile_sdk/cd3;

    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V

    move-object v6, p2

    move p2, p0

    move-object p0, v2

    move-object v2, v1

    move-object v1, p3

    :goto_34
    move-object p3, v6

    goto :goto_72

    :cond_36
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v2

    :cond_3c
    invoke-static {p3}, Lt12;->W(Ljava/lang/Object;)V

    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    move v6, p2

    move-object p2, p1

    move p1, v6

    :goto_46
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result p3

    if-eqz p3, :cond_a2

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Ljava/lang/String;

    iget-object v1, p0, Lads_mobile_sdk/cd3;->r:Lads_mobile_sdk/sb;

    iget-object v4, p0, Lads_mobile_sdk/f2;->b:Lli;

    iput-object p0, v0, Lads_mobile_sdk/yc3;->a:Lads_mobile_sdk/cd3;

    iput-object v2, v0, Lads_mobile_sdk/yc3;->b:Lb13;

    iput-object p2, v0, Lads_mobile_sdk/yc3;->c:Ljava/util/Iterator;

    iput-object p3, v0, Lads_mobile_sdk/yc3;->d:Ljava/lang/String;

    iput-boolean p1, v0, Lads_mobile_sdk/yc3;->e:Z

    iput v3, v0, Lads_mobile_sdk/yc3;->h:I

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v1, v4, p3, v0}, Lads_mobile_sdk/sb;->a(Lads_mobile_sdk/sb;Lli;Ljava/lang/String;Lwx;)Ljava/lang/Object;

    move-result-object v1

    sget-object v4, Lwy;->a:Lwy;

    if-ne v1, v4, :cond_6e

    return-object v4

    :cond_6e
    move-object v6, p2

    move p2, p1

    move-object p1, p3

    goto :goto_34

    :goto_72
    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-nez v1, :cond_8e

    if-nez v2, :cond_8e

    new-instance v2, Lads_mobile_sdk/ev0;

    const-string v1, "The adapter requested for this mediation element ("

    const-string v4, ") is not eligible because it was excluded by AdRequest.skipUninitializedAdapters and has not yet successfully initialized."

    invoke-static {v1, p1, v4}, Lrt2;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/16 v1, 0xe

    invoke-direct {v2, p1, v1}, Lads_mobile_sdk/ev0;-><init>(Ljava/lang/String;I)V

    :goto_8b
    move p1, p2

    move-object p2, p3

    goto :goto_46

    :cond_8e
    iput-object p1, p0, Lads_mobile_sdk/cd3;->s:Ljava/lang/String;

    iget-object v1, p0, Lads_mobile_sdk/cd3;->o:Ly03;

    iget-object v4, p0, Lads_mobile_sdk/f2;->c:Lads_mobile_sdk/av2;

    const/4 v5, 0x4

    invoke-static {v1, p1, p2, v4, v5}, Ly03;->a(Ly03;Ljava/lang/String;ZLads_mobile_sdk/av2;I)Lk53;

    move-result-object p1

    if-nez p1, :cond_9c

    goto :goto_8b

    :cond_9c
    new-instance p0, Lads_mobile_sdk/hv0;

    invoke-direct {p0, p1}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    return-object p0

    :cond_a2
    return-object v2
.end method

.method public final a(Lk53;Lwx;)Ljava/lang/Object;
    .registers 13

    .prologue
    instance-of v0, p2, Lads_mobile_sdk/ad3;

    if-eqz v0, :cond_13

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/ad3;

    iget v1, v0, Lads_mobile_sdk/ad3;->e:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/ad3;->e:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/ad3;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/ad3;-><init>(Lads_mobile_sdk/cd3;Lwx;)V

    :goto_18
    iget-object p2, v0, Lads_mobile_sdk/ad3;->c:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/ad3;->e:I

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_30

    if-ne v1, v3, :cond_2a

    iget-object p1, v0, Lads_mobile_sdk/ad3;->b:Lk53;

    iget-object p0, v0, Lads_mobile_sdk/ad3;->a:Lads_mobile_sdk/cd3;

    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_81

    :cond_2a
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v2

    :cond_30
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    iput-object p0, v0, Lads_mobile_sdk/ad3;->a:Lads_mobile_sdk/cd3;

    iput-object p1, v0, Lads_mobile_sdk/ad3;->b:Lk53;

    iput v3, v0, Lads_mobile_sdk/ad3;->e:I

    instance-of p2, p1, Lads_mobile_sdk/z42;

    if-eqz p2, :cond_4f

    iget-object p2, p0, Lads_mobile_sdk/cd3;->n:Ljava/util/Optional;

    invoke-virtual {p2}, Ljava/util/Optional;->isPresent()Z

    move-result p2

    if-nez p2, :cond_4f

    new-instance p2, Lads_mobile_sdk/ev0;

    const-string v0, "oldAdapterWrapper is empty for OldMediationAdapterProxy"

    invoke-direct {p2, v0, v3}, Lads_mobile_sdk/ev0;-><init>(Ljava/lang/String;I)V

    move-object v6, p0

    move-object v5, p1

    goto :goto_7a

    :cond_4f
    new-instance v7, Ljn;

    invoke-static {v0}, Lpy2;->A(Lvx;)Lvx;

    move-result-object p2

    invoke-direct {v7, v3, p2}, Ljn;-><init>(ILvx;)V

    invoke-virtual {v7}, Ljn;->t()V

    new-instance v4, Lhn1;

    const/16 v9, 0x9

    const/4 v8, 0x0

    move-object v6, p0

    move-object v5, p1

    invoke-direct/range {v4 .. v9}, Lhn1;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lvx;I)V

    iget-object p0, v6, Lads_mobile_sdk/cd3;->q:Lvy;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance p1, La42;

    invoke-direct {p1, v4, v8}, La42;-><init>(Lpk0;Lvx;)V

    const/4 p2, 0x2

    sget-object v0, Ly90;->a:Ly90;

    invoke-static {p0, v0, v8, p1, p2}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    invoke-virtual {v7}, Ljn;->r()Ljava/lang/Object;

    move-result-object p0

    move-object p2, p0

    :goto_7a
    sget-object p0, Lwy;->a:Lwy;

    if-ne p2, p0, :cond_7f

    return-object p0

    :cond_7f
    move-object p1, v5

    move-object p0, v6

    :goto_81
    check-cast p2, Lb13;

    instance-of v0, p2, Lads_mobile_sdk/av0;

    if-eqz v0, :cond_88

    return-object p2

    :cond_88
    instance-of p2, p2, Lads_mobile_sdk/hv0;

    if-eqz p2, :cond_145

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p2, p0, Lads_mobile_sdk/cd3;->m:Ldv2;

    iget-object v0, p0, Lads_mobile_sdk/cd3;->l:Ldv2;

    iget-object v1, p0, Lads_mobile_sdk/cd3;->n:Ljava/util/Optional;

    iget-object v4, p0, Lads_mobile_sdk/f2;->f:Lads_mobile_sdk/a2;

    iget-object v5, p0, Lads_mobile_sdk/f2;->h:Lads_mobile_sdk/n13;

    instance-of v6, p1, Lads_mobile_sdk/ko1;

    if-eqz v6, :cond_a7

    new-instance v2, Lads_mobile_sdk/hv0;

    invoke-interface {v0, v5, v4, p1}, Ldv2;->a(Lads_mobile_sdk/n13;Lads_mobile_sdk/a2;Lk53;)Lm23;

    move-result-object v3

    invoke-direct {v2, v3}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    goto :goto_e7

    :cond_a7
    instance-of v6, p1, Lads_mobile_sdk/ly2;

    if-eqz v6, :cond_b5

    new-instance v2, Lads_mobile_sdk/hv0;

    invoke-interface {p2, v5, v4, p1}, Ldv2;->a(Lads_mobile_sdk/n13;Lads_mobile_sdk/a2;Lk53;)Lm23;

    move-result-object v3

    invoke-direct {v2, v3}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    goto :goto_e7

    :cond_b5
    instance-of v6, p1, Lads_mobile_sdk/z42;

    if-eqz v6, :cond_141

    invoke-virtual {v1}, Ljava/util/Optional;->isPresent()Z

    move-result v2

    if-eqz v2, :cond_cf

    new-instance v2, Lads_mobile_sdk/hv0;

    invoke-virtual {v1}, Ljava/util/Optional;->get()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ldv2;

    invoke-interface {v3, v5, v4, p1}, Ldv2;->a(Lads_mobile_sdk/n13;Lads_mobile_sdk/a2;Lk53;)Lm23;

    move-result-object v3

    invoke-direct {v2, v3}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    goto :goto_e7

    :cond_cf
    new-instance v2, Lads_mobile_sdk/ev0;

    new-instance v4, Ljava/lang/StringBuilder;

    const-string v5, "OldAdapterWrapper is empty, unable to wrap "

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v5, "."

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v2, v4, v3}, Lads_mobile_sdk/ev0;-><init>(Ljava/lang/String;I)V

    :goto_e7
    instance-of v3, v2, Lads_mobile_sdk/av0;

    if-eqz v3, :cond_ee

    check-cast v2, Lads_mobile_sdk/av0;

    return-object v2

    :cond_ee
    check-cast v2, Lads_mobile_sdk/hv0;

    iget-object v2, v2, Lads_mobile_sdk/hv0;->b:Ljava/lang/Object;

    check-cast v2, Lm23;

    instance-of v3, p1, Lads_mobile_sdk/ly2;

    invoke-virtual {p0, v2, v3}, Lads_mobile_sdk/f2;->a(Lm23;Z)Lm23;

    move-result-object v2

    invoke-interface {v2}, Lm23;->a()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lz23;

    iget-object p0, p0, Lads_mobile_sdk/cd3;->p:Lads_mobile_sdk/rh0;

    invoke-interface {v2}, Lz23;->f()Lads_mobile_sdk/ae3;

    move-result-object v4

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v5, p0, Lads_mobile_sdk/rh0;->a:Lads_mobile_sdk/ji;

    sget-object v6, Lads_mobile_sdk/rh0;->b:[Liy0;

    const/4 v7, 0x0

    aget-object v6, v6, v7

    invoke-virtual {v5, p0, v6, v4}, Lads_mobile_sdk/ji;->setValue(Ljava/lang/Object;Liy0;Ljava/lang/Object;)V

    instance-of p0, p1, Lads_mobile_sdk/ko1;

    if-eqz p0, :cond_11e

    invoke-interface {v0, v2}, Ldv2;->a(Lz23;)V

    goto :goto_137

    :cond_11e
    if-eqz v3, :cond_124

    invoke-interface {p2, v2}, Ldv2;->a(Lz23;)V

    goto :goto_137

    :cond_124
    instance-of p0, p1, Lads_mobile_sdk/z42;

    if-eqz p0, :cond_137

    invoke-virtual {v1}, Ljava/util/Optional;->isPresent()Z

    move-result p0

    if-eqz p0, :cond_137

    invoke-virtual {v1}, Ljava/util/Optional;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ldv2;

    invoke-interface {p0, v2}, Ldv2;->a(Lz23;)V

    :cond_137
    :goto_137
    new-instance p0, Lads_mobile_sdk/hv0;

    invoke-interface {v2}, Lz23;->a()Lga3;

    move-result-object p1

    invoke-direct {p0, p1}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    return-object p0

    :cond_141
    invoke-static {}, Ldm2;->q()V

    return-object v2

    :cond_145
    invoke-static {}, Ldm2;->q()V

    return-object v2
.end method

.method public final a(ZLvx;)Ljava/lang/Object;
    .registers 9

    .prologue
    instance-of v0, p2, Lads_mobile_sdk/bd3;

    if-eqz v0, :cond_13

    move-object v0, p2

    check-cast v0, Lads_mobile_sdk/bd3;

    iget v1, v0, Lads_mobile_sdk/bd3;->d:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/bd3;->d:I

    goto :goto_1a

    :cond_13
    new-instance v0, Lads_mobile_sdk/bd3;

    check-cast p2, Lwx;

    invoke-direct {v0, p0, p2}, Lads_mobile_sdk/bd3;-><init>(Lads_mobile_sdk/cd3;Lwx;)V

    :goto_1a
    iget-object p2, v0, Lads_mobile_sdk/bd3;->b:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/bd3;->d:I

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    sget-object v5, Lwy;->a:Lwy;

    if-eqz v1, :cond_39

    if-eq v1, v4, :cond_33

    if-ne v1, v3, :cond_2d

    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_69

    :cond_2d
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v2

    :cond_33
    iget-object p0, v0, Lads_mobile_sdk/bd3;->a:Lads_mobile_sdk/cd3;

    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_4b

    :cond_39
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p2, p0, Lads_mobile_sdk/f2;->f:Lads_mobile_sdk/a2;

    iget-object p2, p2, Lads_mobile_sdk/a2;->b:Ljava/util/ArrayList;

    iput-object p0, v0, Lads_mobile_sdk/bd3;->a:Lads_mobile_sdk/cd3;

    iput v4, v0, Lads_mobile_sdk/bd3;->d:I

    invoke-virtual {p0, p2, p1, v0}, Lads_mobile_sdk/cd3;->a(Ljava/util/ArrayList;ZLwx;)Ljava/lang/Object;

    move-result-object p2

    if-ne p2, v5, :cond_4b

    goto :goto_68

    :cond_4b
    :goto_4b
    check-cast p2, Lb13;

    if-eqz p2, :cond_83

    instance-of p1, p2, Lads_mobile_sdk/av0;

    if-eqz p1, :cond_56

    check-cast p2, Lads_mobile_sdk/av0;

    return-object p2

    :cond_56
    check-cast p2, Lads_mobile_sdk/hv0;

    iget-object p1, p2, Lads_mobile_sdk/hv0;->b:Ljava/lang/Object;

    check-cast p1, Lk53;

    if-eqz p1, :cond_83

    iput-object v2, v0, Lads_mobile_sdk/bd3;->a:Lads_mobile_sdk/cd3;

    iput v3, v0, Lads_mobile_sdk/bd3;->d:I

    invoke-virtual {p0, p1, v0}, Lads_mobile_sdk/cd3;->a(Lk53;Lwx;)Ljava/lang/Object;

    move-result-object p2

    if-ne p2, v5, :cond_69

    :goto_68
    return-object v5

    :cond_69
    :goto_69
    check-cast p2, Lb13;

    instance-of p0, p2, Lads_mobile_sdk/av0;

    if-eqz p0, :cond_70

    return-object p2

    :cond_70
    instance-of p0, p2, Lads_mobile_sdk/hv0;

    if-eqz p0, :cond_7f

    new-instance p0, Lads_mobile_sdk/hv0;

    new-instance p1, Lsw;

    invoke-direct {p1, v4, p2}, Lsw;-><init>(ILjava/lang/Object;)V

    invoke-direct {p0, p1}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    return-object p0

    :cond_7f
    invoke-static {}, Ldm2;->q()V

    return-object v2

    :cond_83
    new-instance p1, Lads_mobile_sdk/dv0;

    new-instance p2, Lc81;

    iget-object p0, p0, Lads_mobile_sdk/f2;->f:Lads_mobile_sdk/a2;

    iget-object p0, p0, Lads_mobile_sdk/a2;->b:Ljava/util/ArrayList;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Unable to instantiate any mediation adapter class: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, "."

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string v0, "undefined"

    const/4 v1, 0x7

    invoke-direct {p2, v1, p0, v0}, Lc81;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    invoke-direct {p1, p2}, Lads_mobile_sdk/dv0;-><init>(Lc81;)V

    return-object p1
.end method

.method public final a(I)Ljava/lang/String;
    .registers 4

    .prologue
    iget-object p0, p0, Lads_mobile_sdk/cd3;->s:Ljava/lang/String;

    if-eqz p0, :cond_1b

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Error from: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, ", code: "

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_1b
    const-string p0, "renderedAdapterClassName"

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0
.end method

.method public final b()Z
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/f2;->f:Lads_mobile_sdk/a2;

    iget-object p0, p0, Lads_mobile_sdk/a2;->b:Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result p0

    xor-int/lit8 p0, p0, 0x1

    return p0
.end method
