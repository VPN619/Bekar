.class public final Lads_mobile_sdk/ay2;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:I

.field public final b:I

.field public final c:I

.field public final d:I


# direct methods
.method public constructor <init>(IIII)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lads_mobile_sdk/ay2;->a:I

    iput p2, p0, Lads_mobile_sdk/ay2;->b:I

    iput p3, p0, Lads_mobile_sdk/ay2;->c:I

    iput p4, p0, Lads_mobile_sdk/ay2;->d:I

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .prologue
    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lads_mobile_sdk/ay2;

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    check-cast p1, Lads_mobile_sdk/ay2;

    iget v1, p0, Lads_mobile_sdk/ay2;->a:I

    iget v3, p1, Lads_mobile_sdk/ay2;->a:I

    if-eq v1, v3, :cond_13

    return v2

    :cond_13
    iget v1, p0, Lads_mobile_sdk/ay2;->b:I

    iget v3, p1, Lads_mobile_sdk/ay2;->b:I

    if-eq v1, v3, :cond_1a

    return v2

    :cond_1a
    iget v1, p0, Lads_mobile_sdk/ay2;->c:I

    iget v3, p1, Lads_mobile_sdk/ay2;->c:I

    if-eq v1, v3, :cond_21

    return v2

    :cond_21
    iget p0, p0, Lads_mobile_sdk/ay2;->d:I

    iget p1, p1, Lads_mobile_sdk/ay2;->d:I

    if-eq p0, p1, :cond_28

    return v2

    :cond_28
    return v0
.end method

.method public final hashCode()I
    .registers 3

    iget v0, p0, Lads_mobile_sdk/ay2;->a:I

    invoke-static {v0}, Ljava/lang/Integer;->hashCode(I)I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, Lads_mobile_sdk/ay2;->b:I

    invoke-static {v1, v0}, Lsz;->c(II)I

    move-result v0

    iget v1, p0, Lads_mobile_sdk/ay2;->c:I

    invoke-static {v1, v0}, Lsz;->c(II)I

    move-result v0

    iget p0, p0, Lads_mobile_sdk/ay2;->d:I

    invoke-static {p0}, Ljava/lang/Integer;->hashCode(I)I

    move-result p0

    add-int/2addr p0, v0

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 6

    const-string v0, ", topRight="

    const-string v1, ", bottomRight="

    iget v2, p0, Lads_mobile_sdk/ay2;->a:I

    iget v3, p0, Lads_mobile_sdk/ay2;->b:I

    const-string v4, "RoundedCornerRadii(topLeft="

    invoke-static {v2, v3, v4, v0, v1}, Lrt2;->l(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget v1, p0, Lads_mobile_sdk/ay2;->c:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ", bottomLeft="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget p0, p0, Lads_mobile_sdk/ay2;->d:I

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
