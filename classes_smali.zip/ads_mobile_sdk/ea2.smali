.class public final Lads_mobile_sdk/ea2;
.super Lzz0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lzj0;


# instance fields
.field public final synthetic a:Lads_mobile_sdk/ha2;

.field public final synthetic i:I


# direct methods
.method public synthetic constructor <init>(Lads_mobile_sdk/ha2;I)V
    .registers 3

    iput p2, p0, Lads_mobile_sdk/ea2;->i:I

    iput-object p1, p0, Lads_mobile_sdk/ea2;->a:Lads_mobile_sdk/ha2;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lzz0;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 6

    .prologue
    iget v0, p0, Lads_mobile_sdk/ea2;->i:I

    packed-switch v0, :pswitch_data_50

    iget-object p0, p0, Lads_mobile_sdk/ea2;->a:Lads_mobile_sdk/ha2;

    iget-object p0, p0, Lads_mobile_sdk/ha2;->b:Landroid/content/Context;

    sget-object v0, Lads_mobile_sdk/ma2;->h:Lads_mobile_sdk/ma2;

    const-class v0, Lads_mobile_sdk/ma2;

    monitor-enter v0

    :try_start_e
    sget-object v1, Lads_mobile_sdk/ma2;->h:Lads_mobile_sdk/ma2;

    if-nez v1, :cond_22

    new-instance v1, Lads_mobile_sdk/ma2;

    const-string v2, "paidv2_id"

    const-string v3, "paidv2_creation_time"

    const-string v4, "PaidV2LifecycleImpl"

    invoke-direct {v1, p0, v2, v3, v4}, Lads_mobile_sdk/da2;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    sput-object v1, Lads_mobile_sdk/ma2;->h:Lads_mobile_sdk/ma2;

    goto :goto_22

    :catchall_20
    move-exception p0

    goto :goto_24

    :cond_22
    :goto_22
    monitor-exit v0

    return-object v1

    :goto_24
    monitor-exit v0
    :try_end_25
    .catchall {:try_start_e .. :try_end_25} :catchall_20

    throw p0

    :pswitch_26  #0x1
    iget-object p0, p0, Lads_mobile_sdk/ea2;->a:Lads_mobile_sdk/ha2;

    iget-object p0, p0, Lads_mobile_sdk/ha2;->b:Landroid/content/Context;

    sget-object v0, Lads_mobile_sdk/ka2;->h:Lads_mobile_sdk/ka2;

    const-class v0, Lads_mobile_sdk/ka2;

    monitor-enter v0

    :try_start_2f
    sget-object v1, Lads_mobile_sdk/ka2;->h:Lads_mobile_sdk/ka2;

    if-nez v1, :cond_43

    new-instance v1, Lads_mobile_sdk/ka2;

    const-string v2, "paidv1_id"

    const-string v3, "paidv1_creation_time"

    const-string v4, "PaidV1LifecycleImpl"

    invoke-direct {v1, p0, v2, v3, v4}, Lads_mobile_sdk/da2;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    sput-object v1, Lads_mobile_sdk/ka2;->h:Lads_mobile_sdk/ka2;

    goto :goto_43

    :catchall_41
    move-exception p0

    goto :goto_45

    :cond_43
    :goto_43
    monitor-exit v0

    return-object v1

    :goto_45
    monitor-exit v0
    :try_end_46
    .catchall {:try_start_2f .. :try_end_46} :catchall_41

    throw p0

    :pswitch_47  #0x0
    iget-object p0, p0, Lads_mobile_sdk/ea2;->a:Lads_mobile_sdk/ha2;

    iget-object p0, p0, Lads_mobile_sdk/ha2;->b:Landroid/content/Context;

    invoke-static {p0}, Lads_mobile_sdk/hz0;->a(Landroid/content/Context;)Lads_mobile_sdk/hz0;

    move-result-object p0

    return-object p0

    :pswitch_data_50
    .packed-switch 0x0
        :pswitch_47  #00000000
        :pswitch_26  #00000001
    .end packed-switch
.end method
