.class public final Lads_mobile_sdk/dx1;
.super Lzz0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lzj0;


# instance fields
.field public final synthetic a:Lads_mobile_sdk/hv0;

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:D

.field public final synthetic d:I

.field public final synthetic e:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/hv0;Ljava/lang/String;DII)V
    .registers 7

    iput-object p1, p0, Lads_mobile_sdk/dx1;->a:Lads_mobile_sdk/hv0;

    iput-object p2, p0, Lads_mobile_sdk/dx1;->b:Ljava/lang/String;

    iput-wide p3, p0, Lads_mobile_sdk/dx1;->c:D

    iput p5, p0, Lads_mobile_sdk/dx1;->d:I

    iput p6, p0, Lads_mobile_sdk/dx1;->e:I

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lzz0;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 8

    new-instance v0, Lads_mobile_sdk/zf1;

    new-instance v1, Landroid/graphics/drawable/BitmapDrawable;

    invoke-static {}, Landroid/content/res/Resources;->getSystem()Landroid/content/res/Resources;

    move-result-object v2

    iget-object v3, p0, Lads_mobile_sdk/dx1;->a:Lads_mobile_sdk/hv0;

    iget-object v3, v3, Lads_mobile_sdk/hv0;->b:Ljava/lang/Object;

    check-cast v3, Landroid/graphics/Bitmap;

    invoke-direct {v1, v2, v3}, Landroid/graphics/drawable/BitmapDrawable;-><init>(Landroid/content/res/Resources;Landroid/graphics/Bitmap;)V

    iget-object v2, p0, Lads_mobile_sdk/dx1;->b:Ljava/lang/String;

    invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget v5, p0, Lads_mobile_sdk/dx1;->d:I

    iget v6, p0, Lads_mobile_sdk/dx1;->e:I

    iget-wide v3, p0, Lads_mobile_sdk/dx1;->c:D

    invoke-direct/range {v0 .. v6}, Lads_mobile_sdk/zf1;-><init>(Landroid/graphics/drawable/Drawable;Landroid/net/Uri;DII)V

    return-object v0
.end method
