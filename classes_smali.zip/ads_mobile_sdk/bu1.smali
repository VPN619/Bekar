.class public final Lads_mobile_sdk/bu1;
.super Lads_mobile_sdk/ov;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# direct methods
.method static constructor <clinit>()V
    .registers 3

    const-string v0, "adEventCallback"

    const-string v1, "getAdEventCallback()Lcom/google/android/libraries/ads/mobile/sdk/nativead/NativeAdEventCallback;"

    const-class v2, Lads_mobile_sdk/bu1;

    invoke-static {v0, v1, v2}, Lv13;->c(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Class;)Lhb1;

    return-void
.end method
