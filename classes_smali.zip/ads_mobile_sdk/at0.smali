.class public final Lads_mobile_sdk/at0;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public a:I

.field public final synthetic b:Lads_mobile_sdk/mt0;

.field public final synthetic t:I


# direct methods
.method public synthetic constructor <init>(Lads_mobile_sdk/mt0;Lvx;I)V
    .registers 4

    iput p3, p0, Lads_mobile_sdk/at0;->t:I

    iput-object p1, p0, Lads_mobile_sdk/at0;->b:Lads_mobile_sdk/mt0;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 4

    .prologue
    iget p2, p0, Lads_mobile_sdk/at0;->t:I

    iget-object p0, p0, Lads_mobile_sdk/at0;->b:Lads_mobile_sdk/mt0;

    packed-switch p2, :pswitch_data_38

    new-instance p2, Lads_mobile_sdk/at0;

    const/4 v0, 0x6

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/at0;-><init>(Lads_mobile_sdk/mt0;Lvx;I)V

    return-object p2

    :pswitch_e  #0x5
    new-instance p2, Lads_mobile_sdk/at0;

    const/4 v0, 0x5

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/at0;-><init>(Lads_mobile_sdk/mt0;Lvx;I)V

    return-object p2

    :pswitch_15  #0x4
    new-instance p2, Lads_mobile_sdk/at0;

    const/4 v0, 0x4

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/at0;-><init>(Lads_mobile_sdk/mt0;Lvx;I)V

    return-object p2

    :pswitch_1c  #0x3
    new-instance p2, Lads_mobile_sdk/at0;

    const/4 v0, 0x3

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/at0;-><init>(Lads_mobile_sdk/mt0;Lvx;I)V

    return-object p2

    :pswitch_23  #0x2
    new-instance p2, Lads_mobile_sdk/at0;

    const/4 v0, 0x2

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/at0;-><init>(Lads_mobile_sdk/mt0;Lvx;I)V

    return-object p2

    :pswitch_2a  #0x1
    new-instance p2, Lads_mobile_sdk/at0;

    const/4 v0, 0x1

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/at0;-><init>(Lads_mobile_sdk/mt0;Lvx;I)V

    return-object p2

    :pswitch_31  #0x0
    new-instance p2, Lads_mobile_sdk/at0;

    const/4 v0, 0x0

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/at0;-><init>(Lads_mobile_sdk/mt0;Lvx;I)V

    return-object p2

    :pswitch_data_38
    .packed-switch 0x0
        :pswitch_31  #00000000
        :pswitch_2a  #00000001
        :pswitch_23  #00000002
        :pswitch_1c  #00000003
        :pswitch_15  #00000004
        :pswitch_e  #00000005
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .prologue
    iget v0, p0, Lads_mobile_sdk/at0;->t:I

    sget-object v1, Lrg2;->a:Lrg2;

    iget-object p0, p0, Lads_mobile_sdk/at0;->b:Lads_mobile_sdk/mt0;

    packed-switch v0, :pswitch_data_72

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/at0;

    const/4 v0, 0x6

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/at0;-><init>(Lads_mobile_sdk/mt0;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/at0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_18  #0x5
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/at0;

    const/4 v0, 0x5

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/at0;-><init>(Lads_mobile_sdk/mt0;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/at0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_27  #0x4
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/at0;

    const/4 v0, 0x4

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/at0;-><init>(Lads_mobile_sdk/mt0;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/at0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_36  #0x3
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/at0;

    const/4 v0, 0x3

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/at0;-><init>(Lads_mobile_sdk/mt0;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/at0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_45  #0x2
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/at0;

    const/4 v0, 0x2

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/at0;-><init>(Lads_mobile_sdk/mt0;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/at0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_54  #0x1
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/at0;

    const/4 v0, 0x1

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/at0;-><init>(Lads_mobile_sdk/mt0;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/at0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_63  #0x0
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/at0;

    const/4 v0, 0x0

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/at0;-><init>(Lads_mobile_sdk/mt0;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/at0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_data_72
    .packed-switch 0x0
        :pswitch_63  #00000000
        :pswitch_54  #00000001
        :pswitch_45  #00000002
        :pswitch_36  #00000003
        :pswitch_27  #00000004
        :pswitch_18  #00000005
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 13

    .prologue
    iget v0, p0, Lads_mobile_sdk/at0;->t:I

    const-string v1, "Internal error attempting to show fullscreen content."

    sget-object v2, Lrg2;->a:Lrg2;

    iget-object v3, p0, Lads_mobile_sdk/at0;->b:Lads_mobile_sdk/mt0;

    const-string v4, "call to \'resume\' before \'invoke\' with coroutine"

    sget-object v5, Lwy;->a:Lwy;

    const/4 v6, 0x1

    const/4 v7, 0x0

    packed-switch v0, :pswitch_data_13c

    iget v0, p0, Lads_mobile_sdk/at0;->a:I

    if-eqz v0, :cond_20

    if-ne v0, v6, :cond_1b

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_31

    :cond_1b
    invoke-static {v4}, Lz6;->w(Ljava/lang/String;)V

    move-object v2, v7

    goto :goto_31

    :cond_20
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    new-instance p1, Lxj0;

    invoke-direct {p1, v6, v1, v7}, Lxj0;-><init>(ILjava/lang/String;Lc81;)V

    iput v6, p0, Lads_mobile_sdk/at0;->a:I

    invoke-virtual {v3, p1, p0}, Lads_mobile_sdk/mt0;->a(Lxj0;Lvx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_31

    move-object v2, v5

    :cond_31
    :goto_31
    return-object v2

    :pswitch_32  #0x5
    iget v0, p0, Lads_mobile_sdk/at0;->a:I

    if-eqz v0, :cond_41

    if-ne v0, v6, :cond_3c

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_52

    :cond_3c
    invoke-static {v4}, Lz6;->w(Ljava/lang/String;)V

    move-object v2, v7

    goto :goto_52

    :cond_41
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    new-instance p1, Lxj0;

    invoke-direct {p1, v6, v1, v7}, Lxj0;-><init>(ILjava/lang/String;Lc81;)V

    iput v6, p0, Lads_mobile_sdk/at0;->a:I

    invoke-virtual {v3, p1, p0}, Lads_mobile_sdk/mt0;->a(Lxj0;Lvx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_52

    move-object v2, v5

    :cond_52
    :goto_52
    return-object v2

    :pswitch_53  #0x4
    iget v0, p0, Lads_mobile_sdk/at0;->a:I

    if-eqz v0, :cond_62

    if-ne v0, v6, :cond_5d

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_79

    :cond_5d
    invoke-static {v4}, Lz6;->w(Ljava/lang/String;)V

    move-object v2, v7

    goto :goto_79

    :cond_62
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    invoke-virtual {v3}, Lads_mobile_sdk/mt0;->j()Lads_mobile_sdk/cy0;

    move-result-object p1

    new-instance v0, Lfx0;

    invoke-direct {v0}, Lfx0;-><init>()V

    iput v6, p0, Lads_mobile_sdk/at0;->a:I

    const-string v1, "onbackblocked"

    invoke-virtual {p1, v0, v1, p0}, Lads_mobile_sdk/cy0;->a(Lfx0;Ljava/lang/String;Lvx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_79

    move-object v2, v5

    :cond_79
    :goto_79
    return-object v2

    :pswitch_7a  #0x3
    iget v0, p0, Lads_mobile_sdk/at0;->a:I

    if-eqz v0, :cond_89

    if-ne v0, v6, :cond_84

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_95

    :cond_84
    invoke-static {v4}, Lz6;->w(Ljava/lang/String;)V

    move-object v2, v7

    goto :goto_95

    :cond_89
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iput v6, p0, Lads_mobile_sdk/at0;->a:I

    invoke-virtual {v3, p0}, Lads_mobile_sdk/mt0;->b(Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_95

    move-object v2, v5

    :cond_95
    :goto_95
    return-object v2

    :pswitch_96  #0x2
    iget v0, p0, Lads_mobile_sdk/at0;->a:I

    if-eqz v0, :cond_a5

    if-ne v0, v6, :cond_a0

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_b5

    :cond_a0
    invoke-static {v4}, Lz6;->w(Ljava/lang/String;)V

    move-object v2, v7

    goto :goto_b5

    :cond_a5
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    invoke-virtual {v3}, Lads_mobile_sdk/mt0;->j()Lads_mobile_sdk/cy0;

    move-result-object p1

    iput v6, p0, Lads_mobile_sdk/at0;->a:I

    invoke-virtual {v3, p1, p0}, Lads_mobile_sdk/mt0;->b(Lads_mobile_sdk/cy0;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_b5

    move-object v2, v5

    :cond_b5
    :goto_b5
    return-object v2

    :pswitch_b6  #0x1
    iget v0, p0, Lads_mobile_sdk/at0;->a:I

    if-eqz v0, :cond_c5

    if-ne v0, v6, :cond_c0

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_d1

    :cond_c0
    invoke-static {v4}, Lz6;->w(Ljava/lang/String;)V

    move-object v2, v7

    goto :goto_d1

    :cond_c5
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iput v6, p0, Lads_mobile_sdk/at0;->a:I

    invoke-virtual {v3, p0}, Lads_mobile_sdk/mt0;->c(Lm82;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_d1

    move-object v2, v5

    :cond_d1
    :goto_d1
    return-object v2

    :pswitch_d2  #0x0
    iget v0, p0, Lads_mobile_sdk/at0;->a:I

    const/4 v1, 0x3

    const/4 v8, 0x2

    if-eqz v0, :cond_ef

    if-eq v0, v6, :cond_eb

    if-eq v0, v8, :cond_e7

    if-ne v0, v1, :cond_e2

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_13b

    :cond_e2
    invoke-static {v4}, Lz6;->w(Ljava/lang/String;)V

    move-object v2, v7

    goto :goto_13b

    :cond_e7
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_132

    :cond_eb
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_11b

    :cond_ef
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, v3, Lads_mobile_sdk/mt0;->e:Lads_mobile_sdk/qr0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lv60;->b:Lp80;

    const/16 v0, 0xbb8

    sget-object v4, Ly60;->d:Ly60;

    invoke-static {v0, v4}, Li10;->G0(ILy60;)J

    move-result-wide v9

    new-instance v0, Lv60;

    invoke-direct {v0, v9, v10}, Lv60;-><init>(J)V

    sget-object v4, Lads_mobile_sdk/fo;->a$18:Lads_mobile_sdk/fo;

    const-string v9, "gads:timeout_for_show_call_succeed:ms"

    invoke-virtual {p1, v9, v0, v4}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lv60;

    iget-wide v9, p1, Lv60;->a:J

    iput v6, p0, Lads_mobile_sdk/at0;->a:I

    invoke-static {v9, v10, p0}, Lsz;->u(JLvx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v5, :cond_11b

    goto :goto_13a

    :cond_11b
    :goto_11b
    iget-object p1, v3, Lads_mobile_sdk/mt0;->n:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {p1}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result p1

    if-eqz p1, :cond_124

    goto :goto_13b

    :cond_124
    const-string p1, "Full screen Activity took too long to start."

    invoke-static {p1, v7}, Lads_mobile_sdk/nw;->c(Ljava/lang/String;Ljava/lang/Exception;)V

    iput v8, p0, Lads_mobile_sdk/at0;->a:I

    invoke-virtual {v3, p0}, Lads_mobile_sdk/mt0;->e(Lads_mobile_sdk/at0;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v5, :cond_132

    goto :goto_13a

    :cond_132
    :goto_132
    iput v1, p0, Lads_mobile_sdk/at0;->a:I

    invoke-virtual {v3, p0}, Lads_mobile_sdk/mt0;->c(Lm82;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v5, :cond_13b

    :goto_13a
    move-object v2, v5

    :cond_13b
    :goto_13b
    return-object v2

    :pswitch_data_13c
    .packed-switch 0x0
        :pswitch_d2  #00000000
        :pswitch_b6  #00000001
        :pswitch_96  #00000002
        :pswitch_7a  #00000003
        :pswitch_53  #00000004
        :pswitch_32  #00000005
    .end packed-switch
.end method
