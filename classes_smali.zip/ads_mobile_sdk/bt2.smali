.class public final Lads_mobile_sdk/bt2;
.super Lads_mobile_sdk/ov;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lmh;


# instance fields
.field public final c:Lads_mobile_sdk/fv2;

.field public final e:Lads_mobile_sdk/uo2;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/td1;Lads_mobile_sdk/fv2;Lads_mobile_sdk/uo2;)V
    .registers 4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0, p1}, Lads_mobile_sdk/ov;-><init>(Ljava/lang/Object;)V

    iput-object p2, p0, Lads_mobile_sdk/bt2;->c:Lads_mobile_sdk/fv2;

    iput-object p3, p0, Lads_mobile_sdk/bt2;->e:Lads_mobile_sdk/uo2;

    return-void
.end method


# virtual methods
.method public final a()Lga3;
    .registers 2

    iget-object p0, p0, Lads_mobile_sdk/bt2;->e:Lads_mobile_sdk/uo2;

    iget-object p0, p0, Lads_mobile_sdk/uo2;->t:Lads_mobile_sdk/e7;

    const-string v0, "The backing field has not yet been initialized."

    invoke-virtual {p0, v0}, Lads_mobile_sdk/e7;->a(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lga3;

    return-object p0
.end method
