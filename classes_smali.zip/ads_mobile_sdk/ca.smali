.class public final Lads_mobile_sdk/ca;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lgu2;


# instance fields
.field public final a:Lads_mobile_sdk/z2;

.field public final b:Ljava/util/concurrent/atomic/AtomicBoolean;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/z2;)V
    .registers 3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/ca;->a:Lads_mobile_sdk/z2;

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v0, 0x0

    invoke-direct {p1, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object p1, p0, Lads_mobile_sdk/ca;->b:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-void
.end method


# virtual methods
.method public final a(Lads_mobile_sdk/nn3;Lvx;)Ljava/lang/Object;
    .registers 6

    .prologue
    iget-boolean p1, p1, Lads_mobile_sdk/nn3;->b:Z

    sget-object v0, Lrg2;->a:Lrg2;

    if-eqz p1, :cond_15

    const/4 p1, 0x0

    const/4 v1, 0x1

    iget-object v2, p0, Lads_mobile_sdk/ca;->b:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v2, p1, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result p1

    if-eqz p1, :cond_15

    iget-object p0, p0, Lads_mobile_sdk/ca;->a:Lads_mobile_sdk/z2;

    invoke-virtual {p0, p2}, Lads_mobile_sdk/z2;->q(Lvx;)Ljava/lang/Object;

    :cond_15
    return-object v0
.end method
