.class public final enum Lads_mobile_sdk/ds3;
.super Ljava/lang/Enum;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final enum b:Lads_mobile_sdk/ds3;

.field public static final enum c:Lads_mobile_sdk/ds3;

.field public static final enum d:Lads_mobile_sdk/ds3;

.field public static final enum e:Lads_mobile_sdk/ds3;

.field public static final enum f:Lads_mobile_sdk/ds3;

.field public static final enum g:Lads_mobile_sdk/ds3;

.field public static final enum h:Lads_mobile_sdk/ds3;

.field public static final enum i:Lads_mobile_sdk/ds3;

.field public static final enum j:Lads_mobile_sdk/ds3;

.field public static final synthetic k:[Lads_mobile_sdk/ds3;


# direct methods
.method static constructor <clinit>()V
    .registers 11

    new-instance v0, Lads_mobile_sdk/ds3;

    const-string v1, "INT"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lads_mobile_sdk/ds3;->b:Lads_mobile_sdk/ds3;

    new-instance v1, Lads_mobile_sdk/ds3;

    const-string v2, "LONG"

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v1, Lads_mobile_sdk/ds3;->c:Lads_mobile_sdk/ds3;

    new-instance v2, Lads_mobile_sdk/ds3;

    const-string v3, "FLOAT"

    const/4 v4, 0x2

    invoke-direct {v2, v3, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v2, Lads_mobile_sdk/ds3;->d:Lads_mobile_sdk/ds3;

    new-instance v3, Lads_mobile_sdk/ds3;

    const-string v4, "DOUBLE"

    const/4 v5, 0x3

    invoke-direct {v3, v4, v5}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v3, Lads_mobile_sdk/ds3;->e:Lads_mobile_sdk/ds3;

    new-instance v4, Lads_mobile_sdk/ds3;

    const-string v5, "BOOLEAN"

    const/4 v6, 0x4

    invoke-direct {v4, v5, v6}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v4, Lads_mobile_sdk/ds3;->f:Lads_mobile_sdk/ds3;

    new-instance v5, Lads_mobile_sdk/ds3;

    const-string v6, "STRING"

    const/4 v7, 0x5

    invoke-direct {v5, v6, v7}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v5, Lads_mobile_sdk/ds3;->g:Lads_mobile_sdk/ds3;

    new-instance v6, Lads_mobile_sdk/ds3;

    sget-object v7, Lads_mobile_sdk/hr;->b:Lads_mobile_sdk/fr;

    const-string v7, "BYTE_STRING"

    const/4 v8, 0x6

    invoke-direct {v6, v7, v8}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v6, Lads_mobile_sdk/ds3;->h:Lads_mobile_sdk/ds3;

    new-instance v7, Lads_mobile_sdk/ds3;

    const-string v8, "ENUM"

    const/4 v9, 0x7

    invoke-direct {v7, v8, v9}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v7, Lads_mobile_sdk/ds3;->i:Lads_mobile_sdk/ds3;

    new-instance v8, Lads_mobile_sdk/ds3;

    const-string v9, "MESSAGE"

    const/16 v10, 0x8

    invoke-direct {v8, v9, v10}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v8, Lads_mobile_sdk/ds3;->j:Lads_mobile_sdk/ds3;

    filled-new-array/range {v0 .. v8}, [Lads_mobile_sdk/ds3;

    move-result-object v0

    sput-object v0, Lads_mobile_sdk/ds3;->k:[Lads_mobile_sdk/ds3;

    return-void
.end method

.method public static values()[Lads_mobile_sdk/ds3;
    .registers 1

    sget-object v0, Lads_mobile_sdk/ds3;->k:[Lads_mobile_sdk/ds3;

    invoke-virtual {v0}, [Lads_mobile_sdk/ds3;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lads_mobile_sdk/ds3;

    return-object v0
.end method
