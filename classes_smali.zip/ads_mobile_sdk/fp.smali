.class public final Lads_mobile_sdk/fp;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lot2;


# instance fields
.field public final a:Ljava/lang/ref/WeakReference;

.field public final b:Lads_mobile_sdk/g0;


# direct methods
.method public constructor <init>(Ljava/lang/ref/WeakReference;Lads_mobile_sdk/g0;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/fp;->a:Ljava/lang/ref/WeakReference;

    iput-object p2, p0, Lads_mobile_sdk/fp;->b:Lads_mobile_sdk/g0;

    return-void
.end method


# virtual methods
.method public final b(JLm82;)Ljava/lang/Object;
    .registers 6

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/fp;->a:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/jp;

    sget-object v1, Lrg2;->a:Lrg2;

    if-eqz v0, :cond_10

    invoke-virtual {v0, p1, p2, p3}, Lads_mobile_sdk/jp;->b(JLm82;)Ljava/lang/Object;

    return-object v1

    :cond_10
    iget-object p1, p0, Lads_mobile_sdk/fp;->b:Lads_mobile_sdk/g0;

    invoke-virtual {p1, p0}, Lads_mobile_sdk/g0;->a(Lot2;)V

    return-object v1
.end method

.method public final d(JLm82;)Ljava/lang/Object;
    .registers 6

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/fp;->a:Ljava/lang/ref/WeakReference;

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/jp;

    sget-object v1, Lrg2;->a:Lrg2;

    if-eqz v0, :cond_10

    invoke-virtual {v0, p1, p2, p3}, Lads_mobile_sdk/jp;->d(JLm82;)Ljava/lang/Object;

    return-object v1

    :cond_10
    iget-object p1, p0, Lads_mobile_sdk/fp;->b:Lads_mobile_sdk/g0;

    invoke-virtual {p1, p0}, Lads_mobile_sdk/g0;->a(Lot2;)V

    return-object v1
.end method
