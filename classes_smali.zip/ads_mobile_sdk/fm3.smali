.class public final Lads_mobile_sdk/fm3;
.super Lwx;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public a:Ljava/lang/Object;

.field public b:Ljava/lang/Object;

.field public c:Lv20;

.field public synthetic d:Ljava/lang/Object;

.field public final synthetic e:Lads_mobile_sdk/im3;

.field public f:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/im3;Lwx;)V
    .registers 3

    iput-object p1, p0, Lads_mobile_sdk/fm3;->e:Lads_mobile_sdk/im3;

    invoke-direct {p0, p2}, Lwx;-><init>(Lvx;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    iput-object p1, p0, Lads_mobile_sdk/fm3;->d:Ljava/lang/Object;

    iget p1, p0, Lads_mobile_sdk/fm3;->f:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, Lads_mobile_sdk/fm3;->f:I

    iget-object p1, p0, Lads_mobile_sdk/fm3;->e:Lads_mobile_sdk/im3;

    invoke-static {p1, p0}, Lads_mobile_sdk/im3;->a(Lads_mobile_sdk/im3;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
