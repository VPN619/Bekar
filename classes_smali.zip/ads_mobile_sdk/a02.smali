.class public final Lads_mobile_sdk/a02;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Lads_mobile_sdk/ux2;

.field public final b:Lads_mobile_sdk/oo3;

.field public final c:Lht2;

.field public d:Lads_mobile_sdk/cy0;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/ux2;Lads_mobile_sdk/oo3;Lht2;)V
    .registers 4

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/a02;->a:Lads_mobile_sdk/ux2;

    iput-object p2, p0, Lads_mobile_sdk/a02;->b:Lads_mobile_sdk/oo3;

    iput-object p3, p0, Lads_mobile_sdk/a02;->c:Lht2;

    return-void
.end method

.method public static a(Lads_mobile_sdk/a02;Lwx;)Ljava/lang/Object;
    .registers 18

    .prologue
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    instance-of v2, v1, Lads_mobile_sdk/yz1;

    if-eqz v2, :cond_17

    move-object v2, v1

    check-cast v2, Lads_mobile_sdk/yz1;

    iget v3, v2, Lads_mobile_sdk/yz1;->g:I

    const/high16 v4, -0x80000000

    and-int v5, v3, v4

    if-eqz v5, :cond_17

    sub-int/2addr v3, v4

    iput v3, v2, Lads_mobile_sdk/yz1;->g:I

    goto :goto_1c

    :cond_17
    new-instance v2, Lads_mobile_sdk/yz1;

    invoke-direct {v2, v0, v1}, Lads_mobile_sdk/yz1;-><init>(Lads_mobile_sdk/a02;Lwx;)V

    :goto_1c
    iget-object v1, v2, Lads_mobile_sdk/yz1;->e:Ljava/lang/Object;

    sget-object v3, Lwy;->a:Lwy;

    iget v4, v2, Lads_mobile_sdk/yz1;->g:I

    const/16 v5, 0x8

    const/4 v6, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x0

    if-eqz v4, :cond_6e

    if-eq v4, v6, :cond_64

    if-eq v4, v9, :cond_54

    if-eq v4, v8, :cond_49

    if-ne v4, v7, :cond_43

    iget-object v0, v2, Lads_mobile_sdk/yz1;->d:Lads_mobile_sdk/cy0;

    iget-object v3, v2, Lads_mobile_sdk/yz1;->c:Ljava/io/Closeable;

    iget-object v4, v2, Lads_mobile_sdk/yz1;->b:Lads_mobile_sdk/rg3;

    iget-object v2, v2, Lads_mobile_sdk/yz1;->a:Lads_mobile_sdk/a02;

    :try_start_3b
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_3e
    .catchall {:try_start_3b .. :try_end_3e} :catchall_40

    goto/16 :goto_15a

    :catchall_40
    move-exception v0

    goto/16 :goto_163

    :cond_43
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {v0}, Lz6;->w(Ljava/lang/String;)V

    return-object v10

    :cond_49
    iget-object v4, v2, Lads_mobile_sdk/yz1;->c:Ljava/io/Closeable;

    iget-object v6, v2, Lads_mobile_sdk/yz1;->b:Lads_mobile_sdk/rg3;

    iget-object v0, v2, Lads_mobile_sdk/yz1;->a:Lads_mobile_sdk/a02;

    :try_start_4f
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_52
    .catchall {:try_start_4f .. :try_end_52} :catchall_166

    goto/16 :goto_13c

    :cond_54
    iget-object v0, v2, Lads_mobile_sdk/yz1;->d:Lads_mobile_sdk/cy0;

    iget-object v3, v2, Lads_mobile_sdk/yz1;->c:Ljava/io/Closeable;

    iget-object v4, v2, Lads_mobile_sdk/yz1;->b:Lads_mobile_sdk/rg3;

    iget-object v2, v2, Lads_mobile_sdk/yz1;->a:Lads_mobile_sdk/a02;

    :try_start_5c
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_5f
    .catchall {:try_start_5c .. :try_end_5f} :catchall_61

    goto/16 :goto_d7

    :catchall_61
    move-exception v0

    goto/16 :goto_e0

    :cond_64
    iget-object v4, v2, Lads_mobile_sdk/yz1;->c:Ljava/io/Closeable;

    iget-object v6, v2, Lads_mobile_sdk/yz1;->b:Lads_mobile_sdk/rg3;

    iget-object v0, v2, Lads_mobile_sdk/yz1;->a:Lads_mobile_sdk/a02;

    :try_start_6a
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_6d
    .catchall {:try_start_6a .. :try_end_6d} :catchall_e3

    goto :goto_b9

    :cond_6e
    invoke-static {v1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object v1, v0, Lads_mobile_sdk/a02;->a:Lads_mobile_sdk/ux2;

    sget-object v4, Lads_mobile_sdk/fw0;->b1:Lads_mobile_sdk/fw0;

    sget-object v11, Lba0;->a:Lba0;

    new-instance v12, Lads_mobile_sdk/kh3;

    new-instance v13, Lads_mobile_sdk/eq2;

    invoke-direct {v13}, Lads_mobile_sdk/eq2;-><init>()V

    new-instance v14, Lads_mobile_sdk/ih1;

    invoke-direct {v14}, Lads_mobile_sdk/ih1;-><init>()V

    new-instance v15, Lads_mobile_sdk/dt2;

    invoke-direct {v15}, Lads_mobile_sdk/dt2;-><init>()V

    new-instance v7, Lads_mobile_sdk/s8;

    invoke-direct {v7}, Lads_mobile_sdk/s8;-><init>()V

    invoke-direct {v12, v13, v14, v15, v7}, Lads_mobile_sdk/kh3;-><init>(Lads_mobile_sdk/eq2;Lads_mobile_sdk/ih1;Lads_mobile_sdk/dt2;Lads_mobile_sdk/s8;)V

    invoke-static {}, Lads_mobile_sdk/hh3;->b()Lads_mobile_sdk/gh3;

    move-result-object v7

    iget-object v7, v7, Lads_mobile_sdk/gh3;->a:Lads_mobile_sdk/rg3;

    const/16 v13, 0xe

    const/4 v14, 0x0

    if-nez v7, :cond_11f

    invoke-static {v1, v4, v11, v12}, Lads_mobile_sdk/ux2;->a(Lads_mobile_sdk/ux2;Lads_mobile_sdk/fw0;Ljava/util/List;Lads_mobile_sdk/kh3;)Lads_mobile_sdk/wk2;

    move-result-object v1

    :try_start_9f
    iget-object v4, v0, Lads_mobile_sdk/a02;->b:Lads_mobile_sdk/oo3;

    new-instance v7, Lads_mobile_sdk/cr3;

    invoke-direct {v7, v6, v14, v14, v13}, Lads_mobile_sdk/cr3;-><init>(IIII)V

    iput-object v0, v2, Lads_mobile_sdk/yz1;->a:Lads_mobile_sdk/a02;

    iput-object v1, v2, Lads_mobile_sdk/yz1;->b:Lads_mobile_sdk/rg3;

    iput-object v1, v2, Lads_mobile_sdk/yz1;->c:Ljava/io/Closeable;

    iput v6, v2, Lads_mobile_sdk/yz1;->g:I

    invoke-virtual {v4, v7, v10, v2}, Lads_mobile_sdk/oo3;->a(Lads_mobile_sdk/cr3;Lg03;Lwx;)Ljava/lang/Object;

    move-result-object v4
    :try_end_b2
    .catchall {:try_start_9f .. :try_end_b2} :catchall_e6

    if-ne v4, v3, :cond_b6

    goto/16 :goto_155

    :cond_b6
    move-object v6, v1

    move-object v1, v4

    move-object v4, v6

    :goto_b9
    :try_start_b9
    check-cast v1, Lads_mobile_sdk/cy0;

    iget-object v7, v0, Lads_mobile_sdk/a02;->c:Lht2;

    invoke-virtual {v1}, Lads_mobile_sdk/cy0;->c()Lg33;

    move-result-object v8

    iput-object v0, v2, Lads_mobile_sdk/yz1;->a:Lads_mobile_sdk/a02;

    iput-object v6, v2, Lads_mobile_sdk/yz1;->b:Lads_mobile_sdk/rg3;

    iput-object v4, v2, Lads_mobile_sdk/yz1;->c:Ljava/io/Closeable;

    iput-object v1, v2, Lads_mobile_sdk/yz1;->d:Lads_mobile_sdk/cy0;

    iput v9, v2, Lads_mobile_sdk/yz1;->g:I

    invoke-virtual {v7, v8, v2}, Lads_mobile_sdk/ov;->a(Lg33;Lwx;)Ljava/lang/Object;

    move-result-object v2
    :try_end_cf
    .catchall {:try_start_b9 .. :try_end_cf} :catchall_e3

    if-ne v2, v3, :cond_d3

    goto/16 :goto_155

    :cond_d3
    move-object v2, v0

    move-object v0, v1

    move-object v3, v4

    move-object v4, v6

    :goto_d7
    :try_start_d7
    invoke-virtual {v0, v5}, Landroid/view/View;->setVisibility(I)V

    iput-object v0, v2, Lads_mobile_sdk/a02;->d:Lads_mobile_sdk/cy0;
    :try_end_dc
    .catchall {:try_start_d7 .. :try_end_dc} :catchall_61

    invoke-static {v3, v10}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object v0

    :goto_e0
    move-object v1, v4

    move-object v4, v3

    goto :goto_e8

    :catchall_e3
    move-exception v0

    move-object v1, v6

    goto :goto_e8

    :catchall_e6
    move-exception v0

    move-object v4, v1

    :goto_e8
    :try_start_e8
    invoke-virtual {v1, v0}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v2, v0, Lox2;

    if-nez v2, :cond_118

    invoke-virtual {v1, v0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of v1, v0, Lza2;

    if-nez v1, :cond_110

    instance-of v1, v0, Ljava/util/concurrent/CancellationException;

    if-nez v1, :cond_108

    instance-of v1, v0, Lads_mobile_sdk/mv0;

    if-eqz v1, :cond_102

    throw v0

    :catchall_ff
    move-exception v0

    move-object v1, v0

    goto :goto_119

    :cond_102
    new-instance v1, Lads_mobile_sdk/tu0;

    invoke-direct {v1, v0}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw v1

    :cond_108
    new-instance v1, Lads_mobile_sdk/ou0;

    check-cast v0, Ljava/util/concurrent/CancellationException;

    invoke-direct {v1, v0}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw v1

    :cond_110
    new-instance v1, Lads_mobile_sdk/uw0;

    check-cast v0, Lza2;

    invoke-direct {v1, v0}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw v1

    :cond_118
    throw v0
    :try_end_119
    .catchall {:try_start_e8 .. :try_end_119} :catchall_ff

    :goto_119
    :try_start_119
    throw v1
    :try_end_11a
    .catchall {:try_start_119 .. :try_end_11a} :catchall_11a

    :catchall_11a
    move-exception v0

    invoke-static {v4, v1}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0

    :cond_11f
    invoke-static {v4, v11, v6}, Lads_mobile_sdk/hh3;->a(Lads_mobile_sdk/fw0;Ljava/util/List;Z)Lads_mobile_sdk/rg3;

    move-result-object v1

    :try_start_123
    iget-object v4, v0, Lads_mobile_sdk/a02;->b:Lads_mobile_sdk/oo3;

    new-instance v7, Lads_mobile_sdk/cr3;

    invoke-direct {v7, v6, v14, v14, v13}, Lads_mobile_sdk/cr3;-><init>(IIII)V

    iput-object v0, v2, Lads_mobile_sdk/yz1;->a:Lads_mobile_sdk/a02;

    iput-object v1, v2, Lads_mobile_sdk/yz1;->b:Lads_mobile_sdk/rg3;

    iput-object v1, v2, Lads_mobile_sdk/yz1;->c:Ljava/io/Closeable;

    iput v8, v2, Lads_mobile_sdk/yz1;->g:I

    invoke-virtual {v4, v7, v10, v2}, Lads_mobile_sdk/oo3;->a(Lads_mobile_sdk/cr3;Lg03;Lwx;)Ljava/lang/Object;

    move-result-object v4
    :try_end_136
    .catchall {:try_start_123 .. :try_end_136} :catchall_169

    if-ne v4, v3, :cond_139

    goto :goto_155

    :cond_139
    move-object v6, v1

    move-object v1, v4

    move-object v4, v6

    :goto_13c
    :try_start_13c
    check-cast v1, Lads_mobile_sdk/cy0;

    iget-object v7, v0, Lads_mobile_sdk/a02;->c:Lht2;

    invoke-virtual {v1}, Lads_mobile_sdk/cy0;->c()Lg33;

    move-result-object v8

    iput-object v0, v2, Lads_mobile_sdk/yz1;->a:Lads_mobile_sdk/a02;

    iput-object v6, v2, Lads_mobile_sdk/yz1;->b:Lads_mobile_sdk/rg3;

    iput-object v4, v2, Lads_mobile_sdk/yz1;->c:Ljava/io/Closeable;

    iput-object v1, v2, Lads_mobile_sdk/yz1;->d:Lads_mobile_sdk/cy0;

    const/4 v9, 0x4

    iput v9, v2, Lads_mobile_sdk/yz1;->g:I

    invoke-virtual {v7, v8, v2}, Lads_mobile_sdk/ov;->a(Lg33;Lwx;)Ljava/lang/Object;

    move-result-object v2
    :try_end_153
    .catchall {:try_start_13c .. :try_end_153} :catchall_166

    if-ne v2, v3, :cond_156

    :goto_155
    return-object v3

    :cond_156
    move-object v2, v0

    move-object v0, v1

    move-object v3, v4

    move-object v4, v6

    :goto_15a
    :try_start_15a
    invoke-virtual {v0, v5}, Landroid/view/View;->setVisibility(I)V

    iput-object v0, v2, Lads_mobile_sdk/a02;->d:Lads_mobile_sdk/cy0;
    :try_end_15f
    .catchall {:try_start_15a .. :try_end_15f} :catchall_40

    invoke-static {v3, v10}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    return-object v0

    :goto_163
    move-object v1, v4

    move-object v4, v3

    goto :goto_16b

    :catchall_166
    move-exception v0

    move-object v1, v6

    goto :goto_16b

    :catchall_169
    move-exception v0

    move-object v4, v1

    :goto_16b
    :try_start_16b
    invoke-virtual {v1, v0}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of v2, v0, Lox2;

    if-nez v2, :cond_19b

    invoke-virtual {v1, v0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of v1, v0, Lza2;

    if-nez v1, :cond_193

    instance-of v1, v0, Ljava/util/concurrent/CancellationException;

    if-nez v1, :cond_18b

    instance-of v1, v0, Lads_mobile_sdk/mv0;

    if-eqz v1, :cond_185

    throw v0

    :catchall_182
    move-exception v0

    move-object v1, v0

    goto :goto_19c

    :cond_185
    new-instance v1, Lads_mobile_sdk/tu0;

    invoke-direct {v1, v0}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw v1

    :cond_18b
    new-instance v1, Lads_mobile_sdk/ou0;

    check-cast v0, Ljava/util/concurrent/CancellationException;

    invoke-direct {v1, v0}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw v1

    :cond_193
    new-instance v1, Lads_mobile_sdk/uw0;

    check-cast v0, Lza2;

    invoke-direct {v1, v0}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw v1

    :cond_19b
    throw v0
    :try_end_19c
    .catchall {:try_start_16b .. :try_end_19c} :catchall_182

    :goto_19c
    :try_start_19c
    throw v1
    :try_end_19d
    .catchall {:try_start_19c .. :try_end_19d} :catchall_19d

    :catchall_19d
    move-exception v0

    invoke-static {v4, v1}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v0
.end method

.method public static b(Lads_mobile_sdk/a02;Lwx;)Ljava/lang/Object;
    .registers 6

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/zz1;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/zz1;

    iget v1, v0, Lads_mobile_sdk/zz1;->d:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/zz1;->d:I

    goto :goto_18

    :cond_13
    new-instance v0, Lads_mobile_sdk/zz1;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/zz1;-><init>(Lads_mobile_sdk/a02;Lwx;)V

    :goto_18
    iget-object p1, v0, Lads_mobile_sdk/zz1;->b:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/zz1;->d:I

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_2e

    if-ne v1, v3, :cond_28

    iget-object p0, v0, Lads_mobile_sdk/zz1;->a:Lads_mobile_sdk/a02;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_42

    :cond_28
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v2

    :cond_2e
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/a02;->d:Lads_mobile_sdk/cy0;

    if-eqz p1, :cond_42

    iput-object p0, v0, Lads_mobile_sdk/zz1;->a:Lads_mobile_sdk/a02;

    iput v3, v0, Lads_mobile_sdk/zz1;->d:I

    invoke-virtual {p1, v0}, Lads_mobile_sdk/cy0;->a(Lvx;)Ljava/lang/Object;

    move-result-object p1

    sget-object v0, Lwy;->a:Lwy;

    if-ne p1, v0, :cond_42

    return-object v0

    :cond_42
    :goto_42
    iput-object v2, p0, Lads_mobile_sdk/a02;->d:Lads_mobile_sdk/cy0;

    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method
