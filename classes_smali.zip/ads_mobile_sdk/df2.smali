.class public final Lads_mobile_sdk/df2;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lgt2;


# instance fields
.field public final a:Lads_mobile_sdk/a2;

.field public final b:Lads_mobile_sdk/if2;

.field public final c:Lads_mobile_sdk/qr0;

.field public final d:Lads_mobile_sdk/ux2;

.field public final e:Lads_mobile_sdk/s01;

.field public final f:Lads_mobile_sdk/ah3;

.field public final g:Lvy;

.field public final h:Lads_mobile_sdk/g0;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lads_mobile_sdk/a2;Lads_mobile_sdk/if2;Lads_mobile_sdk/qr0;Lads_mobile_sdk/ux2;Lads_mobile_sdk/s01;Lads_mobile_sdk/ah3;Lvy;Lads_mobile_sdk/g0;)V
    .registers 10

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Lads_mobile_sdk/df2;->a:Lads_mobile_sdk/a2;

    iput-object p3, p0, Lads_mobile_sdk/df2;->b:Lads_mobile_sdk/if2;

    iput-object p4, p0, Lads_mobile_sdk/df2;->c:Lads_mobile_sdk/qr0;

    iput-object p5, p0, Lads_mobile_sdk/df2;->d:Lads_mobile_sdk/ux2;

    iput-object p6, p0, Lads_mobile_sdk/df2;->e:Lads_mobile_sdk/s01;

    iput-object p7, p0, Lads_mobile_sdk/df2;->f:Lads_mobile_sdk/ah3;

    iput-object p8, p0, Lads_mobile_sdk/df2;->g:Lvy;

    iput-object p9, p0, Lads_mobile_sdk/df2;->h:Lads_mobile_sdk/g0;

    return-void
.end method

.method public static final a(Lads_mobile_sdk/df2;ZLwx;)Ljava/lang/Object;
    .registers 15

    .prologue
    sget-object v0, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    sget-object v1, Lrg2;->a:Lrg2;

    instance-of v2, p2, Lads_mobile_sdk/af2;

    if-eqz v2, :cond_17

    move-object v2, p2

    check-cast v2, Lads_mobile_sdk/af2;

    iget v3, v2, Lads_mobile_sdk/af2;->e:I

    const/high16 v4, -0x80000000

    and-int v5, v3, v4

    if-eqz v5, :cond_17

    sub-int/2addr v3, v4

    iput v3, v2, Lads_mobile_sdk/af2;->e:I

    goto :goto_1c

    :cond_17
    new-instance v2, Lads_mobile_sdk/af2;

    invoke-direct {v2, p0, p2}, Lads_mobile_sdk/af2;-><init>(Lads_mobile_sdk/df2;Lwx;)V

    :goto_1c
    iget-object p2, v2, Lads_mobile_sdk/af2;->c:Ljava/lang/Object;

    sget-object v3, Lwy;->a:Lwy;

    iget v4, v2, Lads_mobile_sdk/af2;->e:I

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eqz v4, :cond_3a

    if-ne v4, v5, :cond_34

    iget p0, v2, Lads_mobile_sdk/af2;->b:I

    iget-object p1, v2, Lads_mobile_sdk/af2;->a:Lads_mobile_sdk/df2;

    :try_start_2c
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_2f
    .catch Ljava/lang/Exception; {:try_start_2c .. :try_end_2f} :catch_31

    goto/16 :goto_e2

    :catch_31
    move-exception p2

    goto/16 :goto_104

    :cond_34
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v6

    :cond_3a
    invoke-static {p2}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p2, p0, Lads_mobile_sdk/df2;->a:Lads_mobile_sdk/a2;

    iget-object p2, p2, Lads_mobile_sdk/a2;->v0:Lads_mobile_sdk/lf2;

    if-nez p2, :cond_45

    goto/16 :goto_169

    :cond_45
    iget-object v4, p2, Lads_mobile_sdk/lf2;->e:Ljava/lang/String;

    if-eqz p1, :cond_c4

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v7

    if-lez v7, :cond_c4

    sget-object v7, Ljava/util/Collections;->EMPTY_MAP:Ljava/util/Map;

    if-eqz v7, :cond_be

    iget-object v8, p2, Lads_mobile_sdk/lf2;->g:Ljava/lang/String;

    invoke-virtual {v8}, Ljava/lang/String;->length()I

    move-result v8

    if-lez v8, :cond_5e

    iget-object v8, p2, Lads_mobile_sdk/lf2;->g:Ljava/lang/String;

    goto :goto_5f

    :cond_5e
    move-object v8, v6

    :goto_5f
    iget-object v9, p2, Lads_mobile_sdk/lf2;->h:Ljava/util/Map;

    invoke-interface {v9}, Ljava/util/Map;->isEmpty()Z

    move-result v9

    if-nez v9, :cond_69

    iget-object v7, p2, Lads_mobile_sdk/lf2;->h:Ljava/util/Map;

    :cond_69
    iget-object p2, p0, Lads_mobile_sdk/df2;->c:Lads_mobile_sdk/qr0;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v9, "gads:hsdp_service_pass_activity_token:enabled"

    sget-object v10, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {p2, v9, v10, v0}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/Boolean;

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    if-eqz p2, :cond_9b

    iget-object p2, p0, Lads_mobile_sdk/df2;->h:Lads_mobile_sdk/g0;

    invoke-virtual {p2}, Lads_mobile_sdk/g0;->b()Landroid/app/Activity;

    move-result-object p2

    if-eqz p2, :cond_97

    invoke-virtual {p2}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p2

    if-eqz p2, :cond_97

    invoke-virtual {p2}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p2

    if-eqz p2, :cond_97

    invoke-virtual {p2}, Landroid/view/View;->getWindowToken()Landroid/os/IBinder;

    move-result-object p2

    goto :goto_98

    :cond_97
    move-object p2, v6

    :goto_98
    if-eqz p2, :cond_9b

    goto :goto_9c

    :cond_9b
    move-object p2, v6

    :goto_9c
    if-eqz v8, :cond_a4

    new-instance v9, Lof3;

    invoke-direct {v9, v4, v8, v7, p2}, Lof3;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/Map;Landroid/os/IBinder;)V

    goto :goto_c5

    :cond_a4
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    if-nez v8, :cond_b0

    const-string p1, " referrer"

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_b0
    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const-string p1, "Missing required properties:"

    invoke-virtual {p1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v6

    :cond_be
    const-string p0, "Null extraQueryParams"

    invoke-static {p0}, Ldm2;->n(Ljava/lang/String;)V

    return-object v6

    :cond_c4
    move-object v9, v6

    :goto_c5
    if-eqz p1, :cond_cf

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result p1

    if-lez p1, :cond_cf

    const/4 p1, 0x3

    goto :goto_d0

    :cond_cf
    const/4 p1, 0x2

    :goto_d0
    :try_start_d0
    iget-object p2, p0, Lads_mobile_sdk/df2;->e:Lads_mobile_sdk/s01;

    iput-object p0, v2, Lads_mobile_sdk/af2;->a:Lads_mobile_sdk/df2;

    iput p1, v2, Lads_mobile_sdk/af2;->b:I

    iput v5, v2, Lads_mobile_sdk/af2;->e:I

    invoke-virtual {p2, v9, v2}, Lads_mobile_sdk/s01;->a(Lof3;Lads_mobile_sdk/af2;)Ljava/lang/Object;

    move-result-object p2
    :try_end_dc
    .catch Ljava/lang/Exception; {:try_start_d0 .. :try_end_dc} :catch_108

    if-ne p2, v3, :cond_df

    return-object v3

    :cond_df
    move v11, p1

    move-object p1, p0

    move p0, v11

    :goto_e2
    :try_start_e2
    invoke-static {}, Lads_mobile_sdk/hh3;->b()Lads_mobile_sdk/gh3;

    move-result-object p2

    iget-object p2, p2, Lads_mobile_sdk/gh3;->a:Lads_mobile_sdk/rg3;

    if-eqz p2, :cond_ef

    invoke-virtual {p2}, Lads_mobile_sdk/rg3;->e()Lads_mobile_sdk/ub2;

    move-result-object p2

    goto :goto_f0

    :cond_ef
    move-object p2, v6

    :goto_f0
    if-nez p2, :cond_f4

    goto/16 :goto_169

    :cond_f4
    invoke-static {}, Lads_mobile_sdk/w01;->o()Lb53;

    move-result-object v2

    invoke-virtual {v2, p0}, Lb53;->b(I)V

    invoke-virtual {v2}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object v2

    check-cast v2, Lads_mobile_sdk/w01;

    iput-object v2, p2, Lads_mobile_sdk/ub2;->I:Lads_mobile_sdk/w01;
    :try_end_103
    .catch Ljava/lang/Exception; {:try_start_e2 .. :try_end_103} :catch_31

    return-object v1

    :goto_104
    move-object v11, p1

    move p1, p0

    move-object p0, v11

    goto :goto_109

    :catch_108
    move-exception p2

    :goto_109
    invoke-static {}, Lads_mobile_sdk/hh3;->b()Lads_mobile_sdk/gh3;

    move-result-object v2

    iget-object v2, v2, Lads_mobile_sdk/gh3;->a:Lads_mobile_sdk/rg3;

    if-eqz v2, :cond_115

    invoke-virtual {v2}, Lads_mobile_sdk/rg3;->e()Lads_mobile_sdk/ub2;

    move-result-object v6

    :cond_115
    if-nez v6, :cond_118

    goto :goto_139

    :cond_118
    invoke-static {}, Lads_mobile_sdk/w01;->o()Lb53;

    move-result-object v2

    invoke-virtual {v2, p1}, Lb53;->b(I)V

    invoke-virtual {p2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    if-nez p1, :cond_127

    const-string p1, ""

    :cond_127
    invoke-virtual {v2}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v3, v2, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v3, Lads_mobile_sdk/w01;

    invoke-virtual {v3, p1}, Lads_mobile_sdk/w01;->b(Ljava/lang/String;)V

    invoke-virtual {v2}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object p1

    check-cast p1, Lads_mobile_sdk/w01;

    iput-object p1, v6, Lads_mobile_sdk/ub2;->I:Lads_mobile_sdk/w01;

    :goto_139
    invoke-static {}, Lads_mobile_sdk/hh3;->a()Lads_mobile_sdk/rg3;

    move-result-object p1

    invoke-virtual {p1}, Lads_mobile_sdk/rg3;->e()Lads_mobile_sdk/ub2;

    move-result-object v2

    const/4 v3, 0x0

    iput-boolean v3, v2, Lads_mobile_sdk/ub2;->m:Z

    invoke-virtual {p1, p2}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    iget-object p1, p0, Lads_mobile_sdk/df2;->c:Lads_mobile_sdk/qr0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v2, "gads:hsdp_unsampled_crash_reporting:enabled"

    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {p1, v2, v3, v0}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    iget-object p0, p0, Lads_mobile_sdk/df2;->f:Lads_mobile_sdk/ah3;

    if-eqz p1, :cond_164

    const-string p1, "HsdpServiceUnsampled.prewarm"

    invoke-virtual {p0, p1, p2}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Exception;)V

    goto :goto_169

    :cond_164
    const-string p1, "HsdpService.prewarm"

    invoke-virtual {p0, p1, p2}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_169
    return-object v1
.end method


# virtual methods
.method public final a(Lvx;)Ljava/lang/Object;
    .registers 16

    .prologue
    sget-object p1, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    sget-object v0, Lrg2;->a:Lrg2;

    iget-object v1, p0, Lads_mobile_sdk/df2;->a:Lads_mobile_sdk/a2;

    iget-object v1, v1, Lads_mobile_sdk/a2;->v0:Lads_mobile_sdk/lf2;

    if-nez v1, :cond_c

    goto/16 :goto_1e7

    :cond_c
    iget-object v1, v1, Lads_mobile_sdk/lf2;->e:Ljava/lang/String;

    invoke-virtual {p0}, Lads_mobile_sdk/df2;->a()Z

    move-result v2

    if-eqz v2, :cond_1e7

    iget-object v2, p0, Lads_mobile_sdk/df2;->c:Lads_mobile_sdk/qr0;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string v3, "gads:hsdp_service_end_session:enabled"

    sget-object v4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {v2, v3, v4, p1}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Boolean;

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_1e7

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    if-lez v2, :cond_1e7

    iget-object v2, p0, Lads_mobile_sdk/df2;->d:Lads_mobile_sdk/ux2;

    sget-object v3, Lads_mobile_sdk/fw0;->S1:Lads_mobile_sdk/fw0;

    sget-object v4, Lba0;->a:Lba0;

    new-instance v5, Lads_mobile_sdk/kh3;

    new-instance v6, Lads_mobile_sdk/eq2;

    invoke-direct {v6}, Lads_mobile_sdk/eq2;-><init>()V

    new-instance v7, Lads_mobile_sdk/ih1;

    invoke-direct {v7}, Lads_mobile_sdk/ih1;-><init>()V

    new-instance v8, Lads_mobile_sdk/dt2;

    invoke-direct {v8}, Lads_mobile_sdk/dt2;-><init>()V

    new-instance v9, Lads_mobile_sdk/s8;

    invoke-direct {v9}, Lads_mobile_sdk/s8;-><init>()V

    invoke-direct {v5, v6, v7, v8, v9}, Lads_mobile_sdk/kh3;-><init>(Lads_mobile_sdk/eq2;Lads_mobile_sdk/ih1;Lads_mobile_sdk/dt2;Lads_mobile_sdk/s8;)V

    invoke-static {}, Lads_mobile_sdk/hh3;->b()Lads_mobile_sdk/gh3;

    move-result-object v6

    iget-object v6, v6, Lads_mobile_sdk/gh3;->a:Lads_mobile_sdk/rg3;

    const-string v7, "HsdpService.endSession"

    const-string v8, "HsdpServiceUnsampled.endSession"

    const-string v9, "gads:hsdp_unsampled_crash_reporting:enabled"

    const-string v10, ""

    const/4 v11, 0x0

    const/4 v12, 0x5

    const/4 v13, 0x0

    if-nez v6, :cond_124

    invoke-static {v2, v3, v4, v5}, Lads_mobile_sdk/ux2;->a(Lads_mobile_sdk/ux2;Lads_mobile_sdk/fw0;Ljava/util/List;Lads_mobile_sdk/kh3;)Lads_mobile_sdk/wk2;

    move-result-object v2

    :try_start_65
    invoke-static {}, Lads_mobile_sdk/hh3;->b()Lads_mobile_sdk/gh3;

    move-result-object v3

    iget-object v3, v3, Lads_mobile_sdk/gh3;->a:Lads_mobile_sdk/rg3;

    if-eqz v3, :cond_77

    invoke-virtual {v3}, Lads_mobile_sdk/rg3;->e()Lads_mobile_sdk/ub2;

    move-result-object v3

    goto :goto_78

    :catchall_72
    move-exception p0

    goto/16 :goto_ee

    :catch_75
    move-exception v1

    goto :goto_90

    :cond_77
    move-object v3, v13

    :goto_78
    if-nez v3, :cond_7b

    goto :goto_8a

    :cond_7b
    invoke-static {}, Lads_mobile_sdk/w01;->o()Lb53;

    move-result-object v4

    invoke-virtual {v4, v12}, Lb53;->b(I)V

    invoke-virtual {v4}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object v4

    check-cast v4, Lads_mobile_sdk/w01;

    iput-object v4, v3, Lads_mobile_sdk/ub2;->I:Lads_mobile_sdk/w01;

    :goto_8a
    iget-object v3, p0, Lads_mobile_sdk/df2;->e:Lads_mobile_sdk/s01;

    invoke-virtual {v3, v1}, Lads_mobile_sdk/s01;->a(Ljava/lang/String;)V
    :try_end_8f
    .catch Ljava/lang/Exception; {:try_start_65 .. :try_end_8f} :catch_75
    .catchall {:try_start_65 .. :try_end_8f} :catchall_72

    goto :goto_e9

    :goto_90
    :try_start_90
    invoke-static {}, Lads_mobile_sdk/hh3;->b()Lads_mobile_sdk/gh3;

    move-result-object v3

    iget-object v3, v3, Lads_mobile_sdk/gh3;->a:Lads_mobile_sdk/rg3;

    if-eqz v3, :cond_9c

    invoke-virtual {v3}, Lads_mobile_sdk/rg3;->e()Lads_mobile_sdk/ub2;

    move-result-object v13

    :cond_9c
    if-nez v13, :cond_9f

    goto :goto_c0

    :cond_9f
    invoke-static {}, Lads_mobile_sdk/w01;->o()Lb53;

    move-result-object v3

    invoke-virtual {v3, v12}, Lb53;->b(I)V

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v4

    if-nez v4, :cond_ad

    goto :goto_ae

    :cond_ad
    move-object v10, v4

    :goto_ae
    invoke-virtual {v3}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v4, v3, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v4, Lads_mobile_sdk/w01;

    invoke-virtual {v4, v10}, Lads_mobile_sdk/w01;->b(Ljava/lang/String;)V

    invoke-virtual {v3}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object v3

    check-cast v3, Lads_mobile_sdk/w01;

    iput-object v3, v13, Lads_mobile_sdk/ub2;->I:Lads_mobile_sdk/w01;

    :goto_c0
    invoke-static {}, Lads_mobile_sdk/hh3;->a()Lads_mobile_sdk/rg3;

    move-result-object v3

    invoke-virtual {v3}, Lads_mobile_sdk/rg3;->e()Lads_mobile_sdk/ub2;

    move-result-object v4

    iput-boolean v11, v4, Lads_mobile_sdk/ub2;->m:Z

    invoke-virtual {v3, v1}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    iget-object v3, p0, Lads_mobile_sdk/df2;->c:Lads_mobile_sdk/qr0;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {v3, v9, v4, p1}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1
    :try_end_de
    .catchall {:try_start_90 .. :try_end_de} :catchall_72

    iget-object p0, p0, Lads_mobile_sdk/df2;->f:Lads_mobile_sdk/ah3;

    if-eqz p1, :cond_e6

    :try_start_e2
    invoke-virtual {p0, v8, v1}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Exception;)V

    goto :goto_e9

    :cond_e6
    invoke-virtual {p0, v7, v1}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_e9
    .catchall {:try_start_e2 .. :try_end_e9} :catchall_72

    :goto_e9
    invoke-virtual {v2}, Lads_mobile_sdk/rg3;->close()V

    goto/16 :goto_1e7

    :goto_ee
    :try_start_ee
    invoke-virtual {v2, p0}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of p1, p0, Lox2;

    if-nez p1, :cond_11d

    invoke-virtual {v2, p0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of p1, p0, Lza2;

    if-nez p1, :cond_115

    instance-of p1, p0, Ljava/util/concurrent/CancellationException;

    if-nez p1, :cond_10d

    instance-of p1, p0, Lads_mobile_sdk/mv0;

    if-eqz p1, :cond_107

    throw p0

    :catchall_105
    move-exception p0

    goto :goto_11e

    :cond_107
    new-instance p1, Lads_mobile_sdk/tu0;

    invoke-direct {p1, p0}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw p1

    :cond_10d
    new-instance p1, Lads_mobile_sdk/ou0;

    check-cast p0, Ljava/util/concurrent/CancellationException;

    invoke-direct {p1, p0}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw p1

    :cond_115
    new-instance p1, Lads_mobile_sdk/uw0;

    check-cast p0, Lza2;

    invoke-direct {p1, p0}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw p1

    :cond_11d
    throw p0
    :try_end_11e
    .catchall {:try_start_ee .. :try_end_11e} :catchall_105

    :goto_11e
    :try_start_11e
    throw p0
    :try_end_11f
    .catchall {:try_start_11e .. :try_end_11f} :catchall_11f

    :catchall_11f
    move-exception p1

    invoke-static {v2, p0}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw p1

    :cond_124
    const/4 v2, 0x1

    invoke-static {v3, v4, v2}, Lads_mobile_sdk/hh3;->a(Lads_mobile_sdk/fw0;Ljava/util/List;Z)Lads_mobile_sdk/rg3;

    move-result-object v2

    :try_start_129
    invoke-static {}, Lads_mobile_sdk/hh3;->b()Lads_mobile_sdk/gh3;

    move-result-object v3

    iget-object v3, v3, Lads_mobile_sdk/gh3;->a:Lads_mobile_sdk/rg3;

    if-eqz v3, :cond_13b

    invoke-virtual {v3}, Lads_mobile_sdk/rg3;->e()Lads_mobile_sdk/ub2;

    move-result-object v3

    goto :goto_13c

    :catchall_136
    move-exception p0

    goto/16 :goto_1b1

    :catch_139
    move-exception v1

    goto :goto_154

    :cond_13b
    move-object v3, v13

    :goto_13c
    if-nez v3, :cond_13f

    goto :goto_14e

    :cond_13f
    invoke-static {}, Lads_mobile_sdk/w01;->o()Lb53;

    move-result-object v4

    invoke-virtual {v4, v12}, Lb53;->b(I)V

    invoke-virtual {v4}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object v4

    check-cast v4, Lads_mobile_sdk/w01;

    iput-object v4, v3, Lads_mobile_sdk/ub2;->I:Lads_mobile_sdk/w01;

    :goto_14e
    iget-object v3, p0, Lads_mobile_sdk/df2;->e:Lads_mobile_sdk/s01;

    invoke-virtual {v3, v1}, Lads_mobile_sdk/s01;->a(Ljava/lang/String;)V
    :try_end_153
    .catch Ljava/lang/Exception; {:try_start_129 .. :try_end_153} :catch_139
    .catchall {:try_start_129 .. :try_end_153} :catchall_136

    goto :goto_1ad

    :goto_154
    :try_start_154
    invoke-static {}, Lads_mobile_sdk/hh3;->b()Lads_mobile_sdk/gh3;

    move-result-object v3

    iget-object v3, v3, Lads_mobile_sdk/gh3;->a:Lads_mobile_sdk/rg3;

    if-eqz v3, :cond_160

    invoke-virtual {v3}, Lads_mobile_sdk/rg3;->e()Lads_mobile_sdk/ub2;

    move-result-object v13

    :cond_160
    if-nez v13, :cond_163

    goto :goto_184

    :cond_163
    invoke-static {}, Lads_mobile_sdk/w01;->o()Lb53;

    move-result-object v3

    invoke-virtual {v3, v12}, Lb53;->b(I)V

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v4

    if-nez v4, :cond_171

    goto :goto_172

    :cond_171
    move-object v10, v4

    :goto_172
    invoke-virtual {v3}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v4, v3, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v4, Lads_mobile_sdk/w01;

    invoke-virtual {v4, v10}, Lads_mobile_sdk/w01;->b(Ljava/lang/String;)V

    invoke-virtual {v3}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object v3

    check-cast v3, Lads_mobile_sdk/w01;

    iput-object v3, v13, Lads_mobile_sdk/ub2;->I:Lads_mobile_sdk/w01;

    :goto_184
    invoke-static {}, Lads_mobile_sdk/hh3;->a()Lads_mobile_sdk/rg3;

    move-result-object v3

    invoke-virtual {v3}, Lads_mobile_sdk/rg3;->e()Lads_mobile_sdk/ub2;

    move-result-object v4

    iput-boolean v11, v4, Lads_mobile_sdk/ub2;->m:Z

    invoke-virtual {v3, v1}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    iget-object v3, p0, Lads_mobile_sdk/df2;->c:Lads_mobile_sdk/qr0;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {v3, v9, v4, p1}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1
    :try_end_1a2
    .catchall {:try_start_154 .. :try_end_1a2} :catchall_136

    iget-object p0, p0, Lads_mobile_sdk/df2;->f:Lads_mobile_sdk/ah3;

    if-eqz p1, :cond_1aa

    :try_start_1a6
    invoke-virtual {p0, v8, v1}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Exception;)V

    goto :goto_1ad

    :cond_1aa
    invoke-virtual {p0, v7, v1}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_1ad
    .catchall {:try_start_1a6 .. :try_end_1ad} :catchall_136

    :goto_1ad
    invoke-virtual {v2}, Lads_mobile_sdk/rg3;->close()V

    goto :goto_1e7

    :goto_1b1
    :try_start_1b1
    invoke-virtual {v2, p0}, Lads_mobile_sdk/rg3;->b(Ljava/lang/Throwable;)V

    instance-of p1, p0, Lox2;

    if-nez p1, :cond_1e0

    invoke-virtual {v2, p0}, Lads_mobile_sdk/rg3;->a(Ljava/lang/Throwable;)V

    instance-of p1, p0, Lza2;

    if-nez p1, :cond_1d8

    instance-of p1, p0, Ljava/util/concurrent/CancellationException;

    if-nez p1, :cond_1d0

    instance-of p1, p0, Lads_mobile_sdk/mv0;

    if-eqz p1, :cond_1ca

    throw p0

    :catchall_1c8
    move-exception p0

    goto :goto_1e1

    :cond_1ca
    new-instance p1, Lads_mobile_sdk/tu0;

    invoke-direct {p1, p0}, Lads_mobile_sdk/tu0;-><init>(Ljava/lang/Throwable;)V

    throw p1

    :cond_1d0
    new-instance p1, Lads_mobile_sdk/ou0;

    check-cast p0, Ljava/util/concurrent/CancellationException;

    invoke-direct {p1, p0}, Lads_mobile_sdk/ou0;-><init>(Ljava/util/concurrent/CancellationException;)V

    throw p1

    :cond_1d8
    new-instance p1, Lads_mobile_sdk/uw0;

    check-cast p0, Lza2;

    invoke-direct {p1, p0}, Lads_mobile_sdk/uw0;-><init>(Lza2;)V

    throw p1

    :cond_1e0
    throw p0
    :try_end_1e1
    .catchall {:try_start_1b1 .. :try_end_1e1} :catchall_1c8

    :goto_1e1
    :try_start_1e1
    throw p0
    :try_end_1e2
    .catchall {:try_start_1e1 .. :try_end_1e2} :catchall_1e2

    :catchall_1e2
    move-exception p1

    invoke-static {v2, p0}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw p1

    :cond_1e7
    :goto_1e7
    return-object v0
.end method

.method public final a()Z
    .registers 5

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/df2;->c:Lads_mobile_sdk/qr0;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sget-object v2, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    const-string v3, "gads:hsdp_service:enabled"

    invoke-virtual {v0, v3, v1, v2}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    if-eqz v0, :cond_23

    iget-object p0, p0, Lads_mobile_sdk/df2;->a:Lads_mobile_sdk/a2;

    iget-object p0, p0, Lads_mobile_sdk/a2;->v0:Lads_mobile_sdk/lf2;

    if-eqz p0, :cond_23

    iget-boolean p0, p0, Lads_mobile_sdk/lf2;->d:Z

    const/4 v0, 0x1

    if-ne p0, v0, :cond_23

    return v0

    :cond_23
    const/4 p0, 0x0

    return p0
.end method

.method public final a(I)Z
    .registers 3

    .prologue
    iget-object p0, p0, Lads_mobile_sdk/df2;->a:Lads_mobile_sdk/a2;

    iget-object p0, p0, Lads_mobile_sdk/a2;->v0:Lads_mobile_sdk/lf2;

    const/4 v0, 0x0

    if-eqz p0, :cond_a

    iget p0, p0, Lads_mobile_sdk/lf2;->f:I

    goto :goto_b

    :cond_a
    move p0, v0

    :goto_b
    and-int/2addr p0, p1

    if-eqz p0, :cond_10

    const/4 p0, 0x1

    return p0

    :cond_10
    return v0
.end method

.method public final i(Lvx;)Ljava/lang/Object;
    .registers 10

    .prologue
    iget-object p1, p0, Lads_mobile_sdk/df2;->a:Lads_mobile_sdk/a2;

    iget-object p1, p1, Lads_mobile_sdk/a2;->v0:Lads_mobile_sdk/lf2;

    sget-object v0, Lrg2;->a:Lrg2;

    if-nez p1, :cond_9

    goto :goto_64

    :cond_9
    invoke-virtual {p0}, Lads_mobile_sdk/df2;->a()Z

    move-result v1

    const/4 v2, 0x2

    sget-object v3, Ly90;->a:Ly90;

    const/4 v4, 0x0

    if-eqz v1, :cond_32

    const/4 p1, 0x1

    invoke-virtual {p0, p1}, Lads_mobile_sdk/df2;->a(I)Z

    move-result v1

    if-nez v1, :cond_1b

    goto :goto_64

    :cond_1b
    invoke-virtual {p0, v2}, Lads_mobile_sdk/df2;->a(I)Z

    move-result v1

    new-instance v5, Lads_mobile_sdk/bf2;

    invoke-direct {v5, p0, v1, v4, p1}, Lads_mobile_sdk/bf2;-><init>(Lads_mobile_sdk/df2;ZLvx;I)V

    iget-object p0, p0, Lads_mobile_sdk/df2;->g:Lvy;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance p1, La42;

    invoke-direct {p1, v5, v4}, La42;-><init>(Lpk0;Lvx;)V

    invoke-static {p0, v3, v4, p1, v2}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    return-object v0

    :cond_32
    iget-object v1, p0, Lads_mobile_sdk/df2;->c:Lads_mobile_sdk/qr0;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v5, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    sget-object v6, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    const-string v7, "gads:play_prewarm:enabled"

    invoke-virtual {v1, v7, v5, v6}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    if-nez v1, :cond_4a

    goto :goto_64

    :cond_4a
    iget-boolean v1, p1, Lads_mobile_sdk/lf2;->a:Z

    if-eqz v1, :cond_64

    iget-object p1, p1, Lads_mobile_sdk/lf2;->b:Ljava/lang/String;

    iget-object p0, p0, Lads_mobile_sdk/df2;->b:Lads_mobile_sdk/if2;

    iget-object v1, p0, Lads_mobile_sdk/if2;->a:Lvy;

    new-instance v5, Lads_mobile_sdk/hf2;

    invoke-direct {v5, p0, p1, v4}, Lads_mobile_sdk/hf2;-><init>(Lads_mobile_sdk/if2;Ljava/lang/String;Lvx;)V

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance p0, La42;

    invoke-direct {p0, v5, v4}, La42;-><init>(Lpk0;Lvx;)V

    invoke-static {v1, v3, v4, p0, v2}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    :cond_64
    :goto_64
    return-object v0
.end method

.method public final q(Lvx;)Ljava/lang/Object;
    .registers 8

    .prologue
    iget-object p1, p0, Lads_mobile_sdk/df2;->a:Lads_mobile_sdk/a2;

    iget-object p1, p1, Lads_mobile_sdk/a2;->v0:Lads_mobile_sdk/lf2;

    sget-object v0, Lrg2;->a:Lrg2;

    if-nez p1, :cond_9

    goto :goto_5e

    :cond_9
    invoke-virtual {p0}, Lads_mobile_sdk/df2;->a()Z

    move-result v1

    const/4 v2, 0x2

    sget-object v3, Ly90;->a:Ly90;

    const/4 v4, 0x0

    if-eqz v1, :cond_35

    const/4 p1, 0x4

    invoke-virtual {p0, p1}, Lads_mobile_sdk/df2;->a(I)Z

    move-result p1

    if-nez p1, :cond_1b

    goto :goto_5e

    :cond_1b
    const/16 p1, 0x8

    invoke-virtual {p0, p1}, Lads_mobile_sdk/df2;->a(I)Z

    move-result p1

    new-instance v1, Lads_mobile_sdk/bf2;

    const/4 v5, 0x0

    invoke-direct {v1, p0, p1, v4, v5}, Lads_mobile_sdk/bf2;-><init>(Lads_mobile_sdk/df2;ZLvx;I)V

    iget-object p0, p0, Lads_mobile_sdk/df2;->g:Lvy;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance p1, La42;

    invoke-direct {p1, v1, v4}, La42;-><init>(Lpk0;Lvx;)V

    invoke-static {p0, v3, v4, p1, v2}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    return-object v0

    :cond_35
    const/16 v1, 0x100

    invoke-virtual {p0, v1}, Lads_mobile_sdk/df2;->a(I)Z

    move-result v1

    if-eqz v1, :cond_5e

    const/16 v1, 0x200

    invoke-virtual {p0, v1}, Lads_mobile_sdk/df2;->a(I)Z

    move-result v1

    if-eqz v1, :cond_48

    iget-object p1, p1, Lads_mobile_sdk/lf2;->b:Ljava/lang/String;

    goto :goto_4a

    :cond_48
    const-string p1, ""

    :goto_4a
    iget-object p0, p0, Lads_mobile_sdk/df2;->b:Lads_mobile_sdk/if2;

    iget-object v1, p0, Lads_mobile_sdk/if2;->a:Lvy;

    new-instance v5, Lads_mobile_sdk/hf2;

    invoke-direct {v5, p0, p1, v4}, Lads_mobile_sdk/hf2;-><init>(Lads_mobile_sdk/if2;Ljava/lang/String;Lvx;)V

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance p0, La42;

    invoke-direct {p0, v5, v4}, La42;-><init>(Lpk0;Lvx;)V

    invoke-static {v1, v3, v4, p0, v2}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    :cond_5e
    :goto_5e
    return-object v0
.end method
