.class public final Lads_mobile_sdk/a92;
.super Lwx;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public a:Lads_mobile_sdk/f92;

.field public b:Ljava/lang/Object;

.field public c:Ljava/io/Closeable;

.field public d:Ljava/io/Closeable;

.field public e:Z

.field public f:Z

.field public synthetic g:Ljava/lang/Object;

.field public final synthetic h:Lads_mobile_sdk/f92;

.field public i:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/f92;Lwx;)V
    .registers 3

    iput-object p1, p0, Lads_mobile_sdk/a92;->h:Lads_mobile_sdk/f92;

    invoke-direct {p0, p2}, Lwx;-><init>(Lvx;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 8

    iput-object p1, p0, Lads_mobile_sdk/a92;->g:Ljava/lang/Object;

    iget p1, p0, Lads_mobile_sdk/a92;->i:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, Lads_mobile_sdk/a92;->i:I

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object v0, p0, Lads_mobile_sdk/a92;->h:Lads_mobile_sdk/f92;

    const/4 v1, 0x0

    const/4 v2, 0x0

    move-object v5, p0

    invoke-virtual/range {v0 .. v5}, Lads_mobile_sdk/f92;->a(Ljava/util/Map;ZZLads_mobile_sdk/cy0;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
