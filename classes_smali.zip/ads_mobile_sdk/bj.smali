.class public final Lads_mobile_sdk/bj;
.super Lzz0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lzj0;


# instance fields
.field public final synthetic a:Landroid/content/Context;

.field public final synthetic i:I


# direct methods
.method public synthetic constructor <init>(Landroid/content/Context;I)V
    .registers 3

    iput p2, p0, Lads_mobile_sdk/bj;->i:I

    iput-object p1, p0, Lads_mobile_sdk/bj;->a:Landroid/content/Context;

    const/4 p1, 0x0

    invoke-direct {p0, p1}, Lzz0;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .prologue
    iget v0, p0, Lads_mobile_sdk/bj;->i:I

    iget-object p0, p0, Lads_mobile_sdk/bj;->a:Landroid/content/Context;

    packed-switch v0, :pswitch_data_46

    const-string v0, "google_mobile_ads_csrb_data.pb"

    invoke-static {p0, v0}, Llk;->j(Landroid/content/Context;Ljava/lang/String;)Ljava/io/File;

    move-result-object p0

    return-object p0

    :pswitch_e  #0x7
    const-string v0, "google_mobile_ads_inspector_settings.pb"

    invoke-static {p0, v0}, Llk;->j(Landroid/content/Context;Ljava/lang/String;)Ljava/io/File;

    move-result-object p0

    return-object p0

    :pswitch_15  #0x6
    const-string v0, "google_mobile_ads_ad_cache_manifest.pb"

    invoke-static {p0, v0}, Llk;->j(Landroid/content/Context;Ljava/lang/String;)Ljava/io/File;

    move-result-object p0

    return-object p0

    :pswitch_1c  #0x5
    const-string v0, "google_mobile_ads_native_ad_settings.pb"

    invoke-static {p0, v0}, Llk;->j(Landroid/content/Context;Ljava/lang/String;)Ljava/io/File;

    move-result-object p0

    return-object p0

    :pswitch_23  #0x4
    const-string v0, "google_mobile_ads_anr_logs.pb"

    invoke-static {p0, v0}, Llk;->j(Landroid/content/Context;Ljava/lang/String;)Ljava/io/File;

    move-result-object p0

    return-object p0

    :pswitch_2a  #0x3
    const-string v0, "google_mobile_ads_shared_settings.pb"

    invoke-static {p0, v0}, Llk;->j(Landroid/content/Context;Ljava/lang/String;)Ljava/io/File;

    move-result-object p0

    return-object p0

    :pswitch_31  #0x2
    const-string v0, "google_mobile_ads_sdk_core.pb"

    invoke-static {p0, v0}, Llk;->j(Landroid/content/Context;Ljava/lang/String;)Ljava/io/File;

    move-result-object p0

    return-object p0

    :pswitch_38  #0x1
    const-string v0, "google_mobile_ads_flags.pb"

    invoke-static {p0, v0}, Llk;->j(Landroid/content/Context;Ljava/lang/String;)Ljava/io/File;

    move-result-object p0

    return-object p0

    :pswitch_3f  #0x0
    const-string v0, "google_mobile_ads_app_settings.pb"

    invoke-static {p0, v0}, Llk;->j(Landroid/content/Context;Ljava/lang/String;)Ljava/io/File;

    move-result-object p0

    return-object p0

    :pswitch_data_46
    .packed-switch 0x0
        :pswitch_3f  #00000000
        :pswitch_38  #00000001
        :pswitch_31  #00000002
        :pswitch_2a  #00000003
        :pswitch_23  #00000004
        :pswitch_1c  #00000005
        :pswitch_15  #00000006
        :pswitch_e  #00000007
    .end packed-switch
.end method
