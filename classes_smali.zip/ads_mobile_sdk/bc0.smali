.class public final Lads_mobile_sdk/bc0;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Le33;


# instance fields
.field public final a:Lads_mobile_sdk/sb0;

.field public b:Lads_mobile_sdk/av2;

.field public c:Lm4;

.field public d:Lads_mobile_sdk/eq2;

.field public e:Lads_mobile_sdk/ih1;

.field public f:Lads_mobile_sdk/j71;

.field public g:Ljava/lang/Boolean;

.field public h:Lads_mobile_sdk/dr2;

.field public i:Ljava/lang/Boolean;

.field public j:Ljava/lang/Boolean;

.field public k:Lads_mobile_sdk/i8;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/sb0;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/bc0;->a:Lads_mobile_sdk/sb0;

    return-void
.end method


# virtual methods
.method public final a()Lads_mobile_sdk/cc0;
    .registers 15

    iget-object v0, p0, Lads_mobile_sdk/bc0;->b:Lads_mobile_sdk/av2;

    const-class v1, Lads_mobile_sdk/av2;

    invoke-static {v0, v1}, Lhi1;->g(Ljava/lang/Object;Ljava/lang/Class;)V

    iget-object v0, p0, Lads_mobile_sdk/bc0;->c:Lm4;

    const-class v1, Lli;

    invoke-static {v0, v1}, Lhi1;->g(Ljava/lang/Object;Ljava/lang/Class;)V

    iget-object v0, p0, Lads_mobile_sdk/bc0;->d:Lads_mobile_sdk/eq2;

    const-class v1, Lads_mobile_sdk/eq2;

    invoke-static {v0, v1}, Lhi1;->g(Ljava/lang/Object;Ljava/lang/Class;)V

    iget-object v0, p0, Lads_mobile_sdk/bc0;->e:Lads_mobile_sdk/ih1;

    const-class v1, Lads_mobile_sdk/ih1;

    invoke-static {v0, v1}, Lhi1;->g(Ljava/lang/Object;Ljava/lang/Class;)V

    iget-object v0, p0, Lads_mobile_sdk/bc0;->f:Lads_mobile_sdk/j71;

    const-class v1, Lads_mobile_sdk/j71;

    invoke-static {v0, v1}, Lhi1;->g(Ljava/lang/Object;Ljava/lang/Class;)V

    iget-object v0, p0, Lads_mobile_sdk/bc0;->g:Ljava/lang/Boolean;

    const-class v1, Ljava/lang/Boolean;

    invoke-static {v0, v1}, Lhi1;->g(Ljava/lang/Object;Ljava/lang/Class;)V

    iget-object v0, p0, Lads_mobile_sdk/bc0;->h:Lads_mobile_sdk/dr2;

    const-class v2, Lads_mobile_sdk/dr2;

    invoke-static {v0, v2}, Lhi1;->g(Ljava/lang/Object;Ljava/lang/Class;)V

    iget-object v0, p0, Lads_mobile_sdk/bc0;->i:Ljava/lang/Boolean;

    invoke-static {v0, v1}, Lhi1;->g(Ljava/lang/Object;Ljava/lang/Class;)V

    iget-object v0, p0, Lads_mobile_sdk/bc0;->j:Ljava/lang/Boolean;

    invoke-static {v0, v1}, Lhi1;->g(Ljava/lang/Object;Ljava/lang/Class;)V

    iget-object v0, p0, Lads_mobile_sdk/bc0;->k:Lads_mobile_sdk/i8;

    const-class v1, Lads_mobile_sdk/i8;

    invoke-static {v0, v1}, Lhi1;->g(Ljava/lang/Object;Ljava/lang/Class;)V

    new-instance v2, Lads_mobile_sdk/cc0;

    iget-object v4, p0, Lads_mobile_sdk/bc0;->b:Lads_mobile_sdk/av2;

    iget-object v5, p0, Lads_mobile_sdk/bc0;->c:Lm4;

    iget-object v6, p0, Lads_mobile_sdk/bc0;->d:Lads_mobile_sdk/eq2;

    iget-object v7, p0, Lads_mobile_sdk/bc0;->e:Lads_mobile_sdk/ih1;

    iget-object v8, p0, Lads_mobile_sdk/bc0;->f:Lads_mobile_sdk/j71;

    iget-object v9, p0, Lads_mobile_sdk/bc0;->g:Ljava/lang/Boolean;

    iget-object v10, p0, Lads_mobile_sdk/bc0;->h:Lads_mobile_sdk/dr2;

    iget-object v11, p0, Lads_mobile_sdk/bc0;->i:Ljava/lang/Boolean;

    iget-object v12, p0, Lads_mobile_sdk/bc0;->j:Ljava/lang/Boolean;

    iget-object v13, p0, Lads_mobile_sdk/bc0;->k:Lads_mobile_sdk/i8;

    iget-object v3, p0, Lads_mobile_sdk/bc0;->a:Lads_mobile_sdk/sb0;

    invoke-direct/range {v2 .. v13}, Lads_mobile_sdk/cc0;-><init>(Lads_mobile_sdk/sb0;Lads_mobile_sdk/av2;Lm4;Lads_mobile_sdk/eq2;Lads_mobile_sdk/ih1;Lads_mobile_sdk/j71;Ljava/lang/Boolean;Lads_mobile_sdk/dr2;Ljava/lang/Boolean;Ljava/lang/Boolean;Lads_mobile_sdk/i8;)V

    return-object v2
.end method

.method public final a(Lads_mobile_sdk/av2;)Ljava/lang/Object;
    .registers 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Lads_mobile_sdk/bc0;->b:Lads_mobile_sdk/av2;

    return-object p0
.end method

.method public final a(Lads_mobile_sdk/dr2;)Ljava/lang/Object;
    .registers 2

    iput-object p1, p0, Lads_mobile_sdk/bc0;->h:Lads_mobile_sdk/dr2;

    return-object p0
.end method

.method public final a(Lads_mobile_sdk/eq2;)Ljava/lang/Object;
    .registers 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Lads_mobile_sdk/bc0;->d:Lads_mobile_sdk/eq2;

    return-object p0
.end method

.method public final a(Lads_mobile_sdk/i8;)Ljava/lang/Object;
    .registers 2

    iput-object p1, p0, Lads_mobile_sdk/bc0;->k:Lads_mobile_sdk/i8;

    return-object p0
.end method

.method public final a(Lads_mobile_sdk/ih1;)Ljava/lang/Object;
    .registers 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Lads_mobile_sdk/bc0;->e:Lads_mobile_sdk/ih1;

    return-object p0
.end method

.method public final a(Lads_mobile_sdk/j71;)Ljava/lang/Object;
    .registers 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Lads_mobile_sdk/bc0;->f:Lads_mobile_sdk/j71;

    return-object p0
.end method

.method public final a(Lm4;)Ljava/lang/Object;
    .registers 2

    iput-object p1, p0, Lads_mobile_sdk/bc0;->c:Lm4;

    return-object p0
.end method

.method public final a(Z)Ljava/lang/Object;
    .registers 2

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    iput-object p1, p0, Lads_mobile_sdk/bc0;->g:Ljava/lang/Boolean;

    return-object p0
.end method

.method public final b()Ljava/lang/Object;
    .registers 2

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    iput-object v0, p0, Lads_mobile_sdk/bc0;->i:Ljava/lang/Boolean;

    return-object p0
.end method

.method public final c(Z)Ljava/lang/Object;
    .registers 2

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    iput-object p1, p0, Lads_mobile_sdk/bc0;->j:Ljava/lang/Boolean;

    return-object p0
.end method
