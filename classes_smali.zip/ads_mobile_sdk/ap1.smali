.class public final Lads_mobile_sdk/ap1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lcom/google/android/gms/ads/mediation/MediationAdLoadCallback;


# instance fields
.field public final synthetic a:Lbk0;

.field public final synthetic b:Lads_mobile_sdk/os;

.field public final synthetic c:Lads_mobile_sdk/rh0;

.field public final synthetic d:I


# direct methods
.method public synthetic constructor <init>(Lads_mobile_sdk/rh0;Lads_mobile_sdk/os;Lbk0;I)V
    .registers 5

    iput p4, p0, Lads_mobile_sdk/ap1;->d:I

    iput-object p3, p0, Lads_mobile_sdk/ap1;->a:Lbk0;

    iput-object p2, p0, Lads_mobile_sdk/ap1;->b:Lads_mobile_sdk/os;

    iput-object p1, p0, Lads_mobile_sdk/ap1;->c:Lads_mobile_sdk/rh0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onFailure(Lcom/google/android/gms/ads/AdError;)V
    .registers 3

    .prologue
    iget v0, p0, Lads_mobile_sdk/ap1;->d:I

    iget-object p0, p0, Lads_mobile_sdk/ap1;->b:Lads_mobile_sdk/os;

    packed-switch v0, :pswitch_data_32

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0, p1}, Lads_mobile_sdk/os;->a(Lcom/google/android/gms/ads/AdError;)V

    return-void

    :pswitch_e  #0x4
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0, p1}, Lads_mobile_sdk/os;->a(Lcom/google/android/gms/ads/AdError;)V

    return-void

    :pswitch_15  #0x3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0, p1}, Lads_mobile_sdk/os;->a(Lcom/google/android/gms/ads/AdError;)V

    return-void

    :pswitch_1c  #0x2
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0, p1}, Lads_mobile_sdk/os;->a(Lcom/google/android/gms/ads/AdError;)V

    return-void

    :pswitch_23  #0x1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0, p1}, Lads_mobile_sdk/os;->a(Lcom/google/android/gms/ads/AdError;)V

    return-void

    :pswitch_2a  #0x0
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0, p1}, Lads_mobile_sdk/os;->a(Lcom/google/android/gms/ads/AdError;)V

    return-void

    nop

    :pswitch_data_32
    .packed-switch 0x0
        :pswitch_2a  #00000000
        :pswitch_23  #00000001
        :pswitch_1c  #00000002
        :pswitch_15  #00000003
        :pswitch_e  #00000004
    .end packed-switch
.end method

.method public final onFailure(Ljava/lang/String;)V
    .registers 5

    .prologue
    iget v0, p0, Lads_mobile_sdk/ap1;->d:I

    const-string v1, "undefined"

    const/4 v2, 0x0

    iget-object p0, p0, Lads_mobile_sdk/ap1;->b:Lads_mobile_sdk/os;

    packed-switch v0, :pswitch_data_52

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lcom/google/android/gms/ads/AdError;

    invoke-direct {v0, v2, p1, v1}, Lcom/google/android/gms/ads/AdError;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Lads_mobile_sdk/os;->a(Lcom/google/android/gms/ads/AdError;)V

    return-void

    :pswitch_16  #0x4
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lcom/google/android/gms/ads/AdError;

    invoke-direct {v0, v2, p1, v1}, Lcom/google/android/gms/ads/AdError;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Lads_mobile_sdk/os;->a(Lcom/google/android/gms/ads/AdError;)V

    return-void

    :pswitch_22  #0x3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lcom/google/android/gms/ads/AdError;

    invoke-direct {v0, v2, p1, v1}, Lcom/google/android/gms/ads/AdError;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Lads_mobile_sdk/os;->a(Lcom/google/android/gms/ads/AdError;)V

    return-void

    :pswitch_2e  #0x2
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lcom/google/android/gms/ads/AdError;

    invoke-direct {v0, v2, p1, v1}, Lcom/google/android/gms/ads/AdError;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Lads_mobile_sdk/os;->a(Lcom/google/android/gms/ads/AdError;)V

    return-void

    :pswitch_3a  #0x1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lcom/google/android/gms/ads/AdError;

    invoke-direct {v0, v2, p1, v1}, Lcom/google/android/gms/ads/AdError;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Lads_mobile_sdk/os;->a(Lcom/google/android/gms/ads/AdError;)V

    return-void

    :pswitch_46  #0x0
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lcom/google/android/gms/ads/AdError;

    invoke-direct {v0, v2, p1, v1}, Lcom/google/android/gms/ads/AdError;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Lads_mobile_sdk/os;->a(Lcom/google/android/gms/ads/AdError;)V

    return-void

    :pswitch_data_52
    .packed-switch 0x0
        :pswitch_46  #00000000
        :pswitch_3a  #00000001
        :pswitch_2e  #00000002
        :pswitch_22  #00000003
        :pswitch_16  #00000004
    .end packed-switch
.end method

.method public final onSuccess(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .prologue
    iget v0, p0, Lads_mobile_sdk/ap1;->d:I

    iget-object v1, p0, Lads_mobile_sdk/ap1;->c:Lads_mobile_sdk/rh0;

    iget-object v2, p0, Lads_mobile_sdk/ap1;->a:Lbk0;

    iget-object p0, p0, Lads_mobile_sdk/ap1;->b:Lads_mobile_sdk/os;

    packed-switch v0, :pswitch_data_78

    check-cast p1, Lcom/google/android/gms/ads/mediation/MediationRewardedAd;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Lads_mobile_sdk/os;->a()V

    invoke-interface {v2, p1}, Lbk0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance p0, Lads_mobile_sdk/xo1;

    invoke-direct {p0, v1}, Lads_mobile_sdk/xo1;-><init>(Lads_mobile_sdk/rh0;)V

    return-object p0

    :pswitch_1c  #0x4
    check-cast p1, Lcom/google/android/gms/ads/mediation/NativeAdMapper;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {v2, p1}, Lbk0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p0}, Lads_mobile_sdk/os;->a()V

    new-instance p0, Lads_mobile_sdk/vo1;

    const/4 p1, 0x0

    invoke-direct {p0, v1, p1}, Lads_mobile_sdk/vo1;-><init>(Lads_mobile_sdk/rh0;I)V

    return-object p0

    :pswitch_2e  #0x3
    check-cast p1, Lcom/google/android/gms/ads/mediation/MediationInterstitialAd;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Lads_mobile_sdk/os;->a()V

    invoke-interface {v2, p1}, Lbk0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance p0, Lads_mobile_sdk/to1;

    invoke-direct {p0, v1}, Lads_mobile_sdk/to1;-><init>(Lads_mobile_sdk/rh0;)V

    return-object p0

    :pswitch_3f  #0x2
    check-cast p1, Lcom/google/android/gms/ads/mediation/MediationBannerAd;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {p1}, Lcom/google/android/gms/ads/mediation/MediationBannerAd;->getView()Landroid/view/View;

    move-result-object p1

    invoke-interface {v2, p1}, Lbk0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p0}, Lads_mobile_sdk/os;->a()V

    new-instance p0, Lads_mobile_sdk/ro1;

    invoke-direct {p0, v1}, Lads_mobile_sdk/ro1;-><init>(Lads_mobile_sdk/rh0;)V

    return-object p0

    :pswitch_54  #0x1
    check-cast p1, Lcom/google/android/gms/ads/mediation/MediationAppOpenAd;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Lads_mobile_sdk/os;->a()V

    invoke-interface {v2, p1}, Lbk0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance p0, Lads_mobile_sdk/po1;

    invoke-direct {p0, v1}, Lads_mobile_sdk/po1;-><init>(Lads_mobile_sdk/rh0;)V

    return-object p0

    :pswitch_65  #0x0
    check-cast p1, Lcom/google/android/gms/ads/mediation/UnifiedNativeAdMapper;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {v2, p1}, Lbk0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p0}, Lads_mobile_sdk/os;->a()V

    new-instance p0, Lads_mobile_sdk/vo1;

    const/4 p1, 0x1

    invoke-direct {p0, v1, p1}, Lads_mobile_sdk/vo1;-><init>(Lads_mobile_sdk/rh0;I)V

    return-object p0

    nop

    :pswitch_data_78
    .packed-switch 0x0
        :pswitch_65  #00000000
        :pswitch_54  #00000001
        :pswitch_3f  #00000002
        :pswitch_2e  #00000003
        :pswitch_1c  #00000004
    .end packed-switch
.end method
