.class public final Lads_mobile_sdk/cf3;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public final synthetic b:Ljava/lang/String;

.field public synthetic c:Ljava/lang/Object;

.field public final synthetic d:Z

.field public final synthetic t:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/wm0;Ljava/lang/String;ZLvx;)V
    .registers 6

    const/4 v0, 0x2

    iput v0, p0, Lads_mobile_sdk/cf3;->t:I

    iput-object p1, p0, Lads_mobile_sdk/cf3;->c:Ljava/lang/Object;

    iput-object p2, p0, Lads_mobile_sdk/cf3;->b:Ljava/lang/String;

    iput-boolean p3, p0, Lads_mobile_sdk/cf3;->d:Z

    invoke-direct {p0, v0, p4}, Lm82;-><init>(ILvx;)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/Object;Lvx;Z)V
    .registers 6

    const/4 v0, 0x0

    iput v0, p0, Lads_mobile_sdk/cf3;->t:I

    iput-object p1, p0, Lads_mobile_sdk/cf3;->b:Ljava/lang/String;

    iput-object p2, p0, Lads_mobile_sdk/cf3;->c:Ljava/lang/Object;

    iput-boolean p4, p0, Lads_mobile_sdk/cf3;->d:Z

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lm82;-><init>(ILvx;)V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Lvx;Z)V
    .registers 5

    const/4 v0, 0x1

    iput v0, p0, Lads_mobile_sdk/cf3;->t:I

    iput-object p1, p0, Lads_mobile_sdk/cf3;->b:Ljava/lang/String;

    iput-boolean p3, p0, Lads_mobile_sdk/cf3;->d:Z

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 6

    .prologue
    iget v0, p0, Lads_mobile_sdk/cf3;->t:I

    iget-boolean v1, p0, Lads_mobile_sdk/cf3;->d:Z

    iget-object v2, p0, Lads_mobile_sdk/cf3;->b:Ljava/lang/String;

    packed-switch v0, :pswitch_data_24

    new-instance p2, Lads_mobile_sdk/cf3;

    iget-object p0, p0, Lads_mobile_sdk/cf3;->c:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/wm0;

    invoke-direct {p2, p0, v2, v1, p1}, Lads_mobile_sdk/cf3;-><init>(Lads_mobile_sdk/wm0;Ljava/lang/String;ZLvx;)V

    return-object p2

    :pswitch_13  #0x1
    new-instance p0, Lads_mobile_sdk/cf3;

    invoke-direct {p0, v2, p1, v1}, Lads_mobile_sdk/cf3;-><init>(Ljava/lang/String;Lvx;Z)V

    iput-object p2, p0, Lads_mobile_sdk/cf3;->c:Ljava/lang/Object;

    return-object p0

    :pswitch_1b  #0x0
    new-instance p2, Lads_mobile_sdk/cf3;

    iget-object p0, p0, Lads_mobile_sdk/cf3;->c:Ljava/lang/Object;

    invoke-direct {p2, v2, p0, p1, v1}, Lads_mobile_sdk/cf3;-><init>(Ljava/lang/String;Ljava/lang/Object;Lvx;Z)V

    return-object p2

    nop

    :pswitch_data_24
    .packed-switch 0x0
        :pswitch_1b  #00000000
        :pswitch_13  #00000001
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .prologue
    iget v0, p0, Lads_mobile_sdk/cf3;->t:I

    sget-object v1, Lrg2;->a:Lrg2;

    packed-switch v0, :pswitch_data_32

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    invoke-virtual {p0, p2, p1}, Lads_mobile_sdk/cf3;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/cf3;

    invoke-virtual {p0, v1}, Lads_mobile_sdk/cf3;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object v1

    :pswitch_15  #0x1
    check-cast p1, Lads_mobile_sdk/zu1;

    check-cast p2, Lvx;

    invoke-virtual {p0, p2, p1}, Lads_mobile_sdk/cf3;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/cf3;

    invoke-virtual {p0, v1}, Lads_mobile_sdk/cf3;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_24  #0x0
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    invoke-virtual {p0, p2, p1}, Lads_mobile_sdk/cf3;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/cf3;

    invoke-virtual {p0, v1}, Lads_mobile_sdk/cf3;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object v1

    :pswitch_data_32
    .packed-switch 0x0
        :pswitch_24  #00000000
        :pswitch_15  #00000001
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7

    .prologue
    iget v0, p0, Lads_mobile_sdk/cf3;->t:I

    sget-object v1, Lrg2;->a:Lrg2;

    iget-boolean v2, p0, Lads_mobile_sdk/cf3;->d:Z

    iget-object v3, p0, Lads_mobile_sdk/cf3;->b:Ljava/lang/String;

    packed-switch v0, :pswitch_data_b4

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p0, p0, Lads_mobile_sdk/cf3;->c:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/wm0;

    iget-object p0, p0, Lads_mobile_sdk/wm0;->b:Lads_mobile_sdk/bn0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p1, p0, Lads_mobile_sdk/bn0;->e:Lw82;

    :try_start_19
    invoke-virtual {p1}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v0

    if-eqz v0, :cond_4f

    iget-object v0, p0, Lads_mobile_sdk/bn0;->d:Lads_mobile_sdk/qr0;

    invoke-virtual {v0}, Lads_mobile_sdk/qr0;->N()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    if-eqz v2, :cond_30

    const-string v2, "beginAdUnitExposure"

    goto :goto_32

    :catch_2e
    move-exception p1

    goto :goto_48

    :cond_30
    const-string v2, "endAdUnitExposure"

    :goto_32
    const-class v4, Ljava/lang/String;

    filled-new-array {v4}, [Ljava/lang/Class;

    move-result-object v4

    invoke-virtual {v0, v2, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    invoke-virtual {p1}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object p1

    filled-new-array {v3}, [Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v0, p1, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_47
    .catch Ljava/lang/Exception; {:try_start_19 .. :try_end_47} :catch_2e

    goto :goto_4f

    :goto_48
    iget-object p0, p0, Lads_mobile_sdk/bn0;->b:Lads_mobile_sdk/ah3;

    const-string v0, "FirebaseAnalyticsAdapter.invokeMethod AdUnitExposure"

    invoke-virtual {p0, v0, p1}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_4f
    :goto_4f
    return-object v1

    :pswitch_50  #0x1
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p0, p0, Lads_mobile_sdk/cf3;->c:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/zu1;

    invoke-virtual {p0}, Lads_mobile_sdk/ku0;->n()Lads_mobile_sdk/iu0;

    move-result-object p0

    check-cast p0, Lp73;

    iget-object p1, p0, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast p1, Lads_mobile_sdk/zu1;

    invoke-static {p1}, Lads_mobile_sdk/zu1;->c(Lads_mobile_sdk/zu1;)Lads_mobile_sdk/gn1;

    move-result-object p1

    invoke-static {p1}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object p1

    invoke-static {p1}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object p1, p0, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast p1, Lads_mobile_sdk/zu1;

    invoke-static {p1}, Lads_mobile_sdk/zu1;->c(Lads_mobile_sdk/zu1;)Lads_mobile_sdk/gn1;

    move-result-object v0

    iget-boolean v1, v0, Lads_mobile_sdk/gn1;->a:Z

    if-nez v1, :cond_89

    invoke-virtual {v0}, Lads_mobile_sdk/gn1;->b()Lads_mobile_sdk/gn1;

    move-result-object v0

    invoke-static {p1, v0}, Lads_mobile_sdk/zu1;->d(Lads_mobile_sdk/zu1;Lads_mobile_sdk/gn1;)V

    :cond_89
    invoke-static {p1}, Lads_mobile_sdk/zu1;->c(Lads_mobile_sdk/zu1;)Lads_mobile_sdk/gn1;

    move-result-object p1

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {p1, v3, v0}, Lads_mobile_sdk/gn1;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p0}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/zu1;

    return-object p0

    :pswitch_9b  #0x0
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    const-string p1, "]"

    const/4 v0, 0x0

    const-string v2, "Invoking function [onVideoMute] on listener ["

    invoke-static {v2, v3, p1, v0}, Lrt2;->s(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    iget-object p0, p0, Lads_mobile_sdk/cf3;->c:Ljava/lang/Object;

    check-cast p0, Lads_mobile_sdk/pf3;

    iget-object p0, p0, Lads_mobile_sdk/pf3;->a:Lads_mobile_sdk/it1;

    iget-object p0, p0, Lads_mobile_sdk/it1;->m:Loj2;

    if-eqz p0, :cond_b3

    invoke-interface {p0}, Loj2;->getVideoLifecycleCallbacks()V

    :cond_b3
    return-object v1

    :pswitch_data_b4
    .packed-switch 0x0
        :pswitch_9b  #00000000
        :pswitch_50  #00000001
    .end packed-switch
.end method
