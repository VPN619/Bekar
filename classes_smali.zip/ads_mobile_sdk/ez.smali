.class public final Lads_mobile_sdk/ez;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public a:I

.field public final synthetic b:Lads_mobile_sdk/vz;

.field public final synthetic t:I


# direct methods
.method public synthetic constructor <init>(Lads_mobile_sdk/vz;Lvx;I)V
    .registers 4

    iput p3, p0, Lads_mobile_sdk/ez;->t:I

    iput-object p1, p0, Lads_mobile_sdk/ez;->b:Lads_mobile_sdk/vz;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 4

    .prologue
    iget p2, p0, Lads_mobile_sdk/ez;->t:I

    iget-object p0, p0, Lads_mobile_sdk/ez;->b:Lads_mobile_sdk/vz;

    packed-switch p2, :pswitch_data_32

    new-instance p2, Lads_mobile_sdk/ez;

    const/4 v0, 0x5

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/ez;-><init>(Lads_mobile_sdk/vz;Lvx;I)V

    return-object p2

    :pswitch_e  #0x4
    new-instance p2, Lads_mobile_sdk/ez;

    const/4 v0, 0x4

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/ez;-><init>(Lads_mobile_sdk/vz;Lvx;I)V

    return-object p2

    :pswitch_15  #0x3
    new-instance p2, Lads_mobile_sdk/ez;

    const/4 v0, 0x3

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/ez;-><init>(Lads_mobile_sdk/vz;Lvx;I)V

    return-object p2

    :pswitch_1c  #0x2
    new-instance p2, Lads_mobile_sdk/ez;

    const/4 v0, 0x2

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/ez;-><init>(Lads_mobile_sdk/vz;Lvx;I)V

    return-object p2

    :pswitch_23  #0x1
    new-instance p2, Lads_mobile_sdk/ez;

    const/4 v0, 0x1

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/ez;-><init>(Lads_mobile_sdk/vz;Lvx;I)V

    return-object p2

    :pswitch_2a  #0x0
    new-instance p2, Lads_mobile_sdk/ez;

    const/4 v0, 0x0

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/ez;-><init>(Lads_mobile_sdk/vz;Lvx;I)V

    return-object p2

    nop

    :pswitch_data_32
    .packed-switch 0x0
        :pswitch_2a  #00000000
        :pswitch_23  #00000001
        :pswitch_1c  #00000002
        :pswitch_15  #00000003
        :pswitch_e  #00000004
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .prologue
    iget v0, p0, Lads_mobile_sdk/ez;->t:I

    sget-object v1, Lrg2;->a:Lrg2;

    iget-object p0, p0, Lads_mobile_sdk/ez;->b:Lads_mobile_sdk/vz;

    packed-switch v0, :pswitch_data_64

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/ez;

    const/4 v0, 0x5

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/ez;-><init>(Lads_mobile_sdk/vz;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/ez;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_18  #0x4
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/ez;

    const/4 v0, 0x4

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/ez;-><init>(Lads_mobile_sdk/vz;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/ez;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_27  #0x3
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/ez;

    const/4 v0, 0x3

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/ez;-><init>(Lads_mobile_sdk/vz;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/ez;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_36  #0x2
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/ez;

    const/4 v0, 0x2

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/ez;-><init>(Lads_mobile_sdk/vz;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/ez;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_45  #0x1
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/ez;

    const/4 v0, 0x1

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/ez;-><init>(Lads_mobile_sdk/vz;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/ez;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_54  #0x0
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/ez;

    const/4 v0, 0x0

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/ez;-><init>(Lads_mobile_sdk/vz;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/ez;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_64
    .packed-switch 0x0
        :pswitch_54  #00000000
        :pswitch_45  #00000001
        :pswitch_36  #00000002
        :pswitch_27  #00000003
        :pswitch_18  #00000004
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 10

    .prologue
    iget v0, p0, Lads_mobile_sdk/ez;->t:I

    const/4 v1, 0x0

    sget-object v2, Lrg2;->a:Lrg2;

    iget-object v3, p0, Lads_mobile_sdk/ez;->b:Lads_mobile_sdk/vz;

    const/4 v4, 0x0

    const-string v5, "call to \'resume\' before \'invoke\' with coroutine"

    sget-object v6, Lwy;->a:Lwy;

    const/4 v7, 0x1

    packed-switch v0, :pswitch_data_cc

    iget v0, p0, Lads_mobile_sdk/ez;->a:I

    if-eqz v0, :cond_1f

    if-ne v0, v7, :cond_1a

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_32

    :cond_1a
    invoke-static {v5}, Lz6;->w(Ljava/lang/String;)V

    move-object v2, v4

    goto :goto_32

    :cond_1f
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, v3, Lads_mobile_sdk/vz;->x:Lads_mobile_sdk/ae2;

    iput v7, p0, Lads_mobile_sdk/ez;->a:I

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lads_mobile_sdk/bc2;->b:Lads_mobile_sdk/bc2;

    invoke-static {p1, v0, v1, p0}, Lads_mobile_sdk/ae2;->a(Lads_mobile_sdk/ae2;Lads_mobile_sdk/bc2;ZLwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v6, :cond_32

    move-object v2, v6

    :cond_32
    :goto_32
    return-object v2

    :pswitch_33  #0x4
    iget v0, p0, Lads_mobile_sdk/ez;->a:I

    if-eqz v0, :cond_42

    if-ne v0, v7, :cond_3d

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_55

    :cond_3d
    invoke-static {v5}, Lz6;->w(Ljava/lang/String;)V

    move-object v2, v4

    goto :goto_55

    :cond_42
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, v3, Lads_mobile_sdk/vz;->x:Lads_mobile_sdk/ae2;

    iput v7, p0, Lads_mobile_sdk/ez;->a:I

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lads_mobile_sdk/bc2;->c:Lads_mobile_sdk/bc2;

    invoke-static {p1, v0, v7, p0}, Lads_mobile_sdk/ae2;->a(Lads_mobile_sdk/ae2;Lads_mobile_sdk/bc2;ZLwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v6, :cond_55

    move-object v2, v6

    :cond_55
    :goto_55
    return-object v2

    :pswitch_56  #0x3
    iget v0, p0, Lads_mobile_sdk/ez;->a:I

    if-eqz v0, :cond_65

    if-ne v0, v7, :cond_60

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_72

    :cond_60
    invoke-static {v5}, Lz6;->w(Ljava/lang/String;)V

    move-object v2, v4

    goto :goto_74

    :cond_65
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iput v7, p0, Lads_mobile_sdk/ez;->a:I

    invoke-static {v3, p0}, Lads_mobile_sdk/vz;->h(Lads_mobile_sdk/vz;Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v6, :cond_72

    move-object v2, v6

    goto :goto_74

    :cond_72
    :goto_72
    check-cast p1, Lb13;

    :goto_74
    return-object v2

    :pswitch_75  #0x2
    iget v0, p0, Lads_mobile_sdk/ez;->a:I

    if-eqz v0, :cond_84

    if-ne v0, v7, :cond_7f

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_91

    :cond_7f
    invoke-static {v5}, Lz6;->w(Ljava/lang/String;)V

    move-object v2, v4

    goto :goto_93

    :cond_84
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iput v7, p0, Lads_mobile_sdk/ez;->a:I

    invoke-virtual {v3, p0}, Lads_mobile_sdk/vz;->y(Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v6, :cond_91

    move-object v2, v6

    goto :goto_93

    :cond_91
    :goto_91
    check-cast p1, Lb13;

    :goto_93
    return-object v2

    :pswitch_94  #0x1
    iget v0, p0, Lads_mobile_sdk/ez;->a:I

    if-eqz v0, :cond_a3

    if-ne v0, v7, :cond_9e

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_af

    :cond_9e
    invoke-static {v5}, Lz6;->w(Ljava/lang/String;)V

    move-object v2, v4

    goto :goto_af

    :cond_a3
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iput v7, p0, Lads_mobile_sdk/ez;->a:I

    invoke-static {v3, p0}, Lads_mobile_sdk/vz;->a(Lads_mobile_sdk/vz;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v6, :cond_af

    move-object v2, v6

    :cond_af
    :goto_af
    return-object v2

    :pswitch_b0  #0x0
    iget v0, p0, Lads_mobile_sdk/ez;->a:I

    if-eqz v0, :cond_bf

    if-ne v0, v7, :cond_ba

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_cb

    :cond_ba
    invoke-static {v5}, Lz6;->w(Ljava/lang/String;)V

    move-object v2, v4

    goto :goto_cb

    :cond_bf
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iput v7, p0, Lads_mobile_sdk/ez;->a:I

    invoke-static {v3, v1, v7, p0}, Lads_mobile_sdk/vz;->b(Lads_mobile_sdk/vz;ZZLwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v6, :cond_cb

    move-object v2, v6

    :cond_cb
    :goto_cb
    return-object v2

    :pswitch_data_cc
    .packed-switch 0x0
        :pswitch_b0  #00000000
        :pswitch_94  #00000001
        :pswitch_75  #00000002
        :pswitch_56  #00000003
        :pswitch_33  #00000004
    .end packed-switch
.end method
