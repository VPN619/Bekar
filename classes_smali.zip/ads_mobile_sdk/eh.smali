.class public final Lads_mobile_sdk/eh;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lgu2;


# instance fields
.field public final a:Lads_mobile_sdk/jd1;

.field public final b:Lz03;

.field public final c:Ljava/util/concurrent/atomic/AtomicBoolean;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/jd1;Lz03;)V
    .registers 3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/eh;->a:Lads_mobile_sdk/jd1;

    iput-object p2, p0, Lads_mobile_sdk/eh;->b:Lz03;

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 p2, 0x0

    invoke-direct {p1, p2}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object p1, p0, Lads_mobile_sdk/eh;->c:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-void
.end method


# virtual methods
.method public final a(Lads_mobile_sdk/nn3;Lvx;)Ljava/lang/Object;
    .registers 4

    .prologue
    iget-boolean p1, p1, Lads_mobile_sdk/nn3;->b:Z

    if-eqz p1, :cond_1d

    const/4 p1, 0x0

    const/4 p2, 0x1

    iget-object v0, p0, Lads_mobile_sdk/eh;->c:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {v0, p1, p2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result p1

    if-eqz p1, :cond_1d

    iget-object p1, p0, Lads_mobile_sdk/eh;->a:Lads_mobile_sdk/jd1;

    invoke-virtual {p1}, Lads_mobile_sdk/cc1;->i()Lads_mobile_sdk/xv;

    move-result-object p1

    iget-boolean p1, p1, Lads_mobile_sdk/xv;->u:Z

    if-eqz p1, :cond_1d

    iget-object p0, p0, Lads_mobile_sdk/eh;->b:Lz03;

    invoke-interface {p0}, Lz03;->d()V

    :cond_1d
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method
