.class public final Lads_mobile_sdk/d92;
.super Lwx;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public a:Ljava/util/Map;

.field public b:Lads_mobile_sdk/cy0;

.field public c:Z

.field public d:Z

.field public e:Z

.field public synthetic f:Ljava/lang/Object;

.field public final synthetic g:Lads_mobile_sdk/f92;

.field public h:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/f92;Lwx;)V
    .registers 3

    iput-object p1, p0, Lads_mobile_sdk/d92;->g:Lads_mobile_sdk/f92;

    invoke-direct {p0, p2}, Lwx;-><init>(Lvx;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 10

    iput-object p1, p0, Lads_mobile_sdk/d92;->f:Ljava/lang/Object;

    iget p1, p0, Lads_mobile_sdk/d92;->h:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, Lads_mobile_sdk/d92;->h:I

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object v0, p0, Lads_mobile_sdk/d92;->g:Lads_mobile_sdk/f92;

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    move-object v7, p0

    invoke-virtual/range {v0 .. v7}, Lads_mobile_sdk/f92;->a(Ljava/util/Map;ZZZZLads_mobile_sdk/cy0;Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
