.class public final Lads_mobile_sdk/dt2;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public a:Ljava/lang/String;

.field public b:I

.field public c:Ljava/lang/String;

.field public d:Ljava/lang/String;

.field public e:Ljava/lang/String;

.field public f:Ljava/lang/Boolean;

.field public g:Z

.field public h:Z


# direct methods
.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v0, ""

    iput-object v0, p0, Lads_mobile_sdk/dt2;->a:Ljava/lang/String;

    const/4 v1, 0x0

    iput v1, p0, Lads_mobile_sdk/dt2;->b:I

    iput-object v0, p0, Lads_mobile_sdk/dt2;->c:Ljava/lang/String;

    iput-object v0, p0, Lads_mobile_sdk/dt2;->d:Ljava/lang/String;

    iput-object v0, p0, Lads_mobile_sdk/dt2;->e:Ljava/lang/String;

    const/4 v0, 0x0

    iput-object v0, p0, Lads_mobile_sdk/dt2;->f:Ljava/lang/Boolean;

    iput-boolean v1, p0, Lads_mobile_sdk/dt2;->g:Z

    iput-boolean v1, p0, Lads_mobile_sdk/dt2;->h:Z

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    .prologue
    if-ne p0, p1, :cond_3

    goto :goto_57

    :cond_3
    instance-of v0, p1, Lads_mobile_sdk/dt2;

    if-nez v0, :cond_8

    goto :goto_55

    :cond_8
    check-cast p1, Lads_mobile_sdk/dt2;

    iget-object v0, p0, Lads_mobile_sdk/dt2;->a:Ljava/lang/String;

    iget-object v1, p1, Lads_mobile_sdk/dt2;->a:Ljava/lang/String;

    invoke-static {v0, v1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_15

    goto :goto_55

    :cond_15
    iget v0, p0, Lads_mobile_sdk/dt2;->b:I

    iget v1, p1, Lads_mobile_sdk/dt2;->b:I

    if-eq v0, v1, :cond_1c

    goto :goto_55

    :cond_1c
    iget-object v0, p0, Lads_mobile_sdk/dt2;->c:Ljava/lang/String;

    iget-object v1, p1, Lads_mobile_sdk/dt2;->c:Ljava/lang/String;

    invoke-static {v0, v1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_27

    goto :goto_55

    :cond_27
    iget-object v0, p0, Lads_mobile_sdk/dt2;->d:Ljava/lang/String;

    iget-object v1, p1, Lads_mobile_sdk/dt2;->d:Ljava/lang/String;

    invoke-static {v0, v1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_32

    goto :goto_55

    :cond_32
    iget-object v0, p0, Lads_mobile_sdk/dt2;->e:Ljava/lang/String;

    iget-object v1, p1, Lads_mobile_sdk/dt2;->e:Ljava/lang/String;

    invoke-static {v0, v1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_3d

    goto :goto_55

    :cond_3d
    iget-object v0, p0, Lads_mobile_sdk/dt2;->f:Ljava/lang/Boolean;

    iget-object v1, p1, Lads_mobile_sdk/dt2;->f:Ljava/lang/Boolean;

    invoke-static {v0, v1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_48

    goto :goto_55

    :cond_48
    iget-boolean v0, p0, Lads_mobile_sdk/dt2;->g:Z

    iget-boolean v1, p1, Lads_mobile_sdk/dt2;->g:Z

    if-eq v0, v1, :cond_4f

    goto :goto_55

    :cond_4f
    iget-boolean p0, p0, Lads_mobile_sdk/dt2;->h:Z

    iget-boolean p1, p1, Lads_mobile_sdk/dt2;->h:Z

    if-eq p0, p1, :cond_57

    :goto_55
    const/4 p0, 0x0

    return p0

    :cond_57
    :goto_57
    const/4 p0, 0x1

    return p0
.end method

.method public final hashCode()I
    .registers 4

    .prologue
    iget-object v0, p0, Lads_mobile_sdk/dt2;->a:Ljava/lang/String;

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget v1, p0, Lads_mobile_sdk/dt2;->b:I

    invoke-static {v1, v0}, Lsz;->c(II)I

    move-result v0

    iget-object v1, p0, Lads_mobile_sdk/dt2;->c:Ljava/lang/String;

    invoke-static {v1, v0}, Luz;->e(Ljava/lang/String;I)I

    move-result v0

    iget-object v1, p0, Lads_mobile_sdk/dt2;->d:Ljava/lang/String;

    invoke-static {v1, v0}, Luz;->e(Ljava/lang/String;I)I

    move-result v0

    iget-object v1, p0, Lads_mobile_sdk/dt2;->e:Ljava/lang/String;

    invoke-static {v1, v0}, Luz;->e(Ljava/lang/String;I)I

    move-result v0

    iget-object v1, p0, Lads_mobile_sdk/dt2;->f:Ljava/lang/Boolean;

    if-nez v1, :cond_26

    const/4 v1, 0x0

    goto :goto_2a

    :cond_26
    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    move-result v1

    :goto_2a
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-boolean v1, p0, Lads_mobile_sdk/dt2;->g:Z

    const/4 v2, 0x1

    if-eqz v1, :cond_33

    move v1, v2

    :cond_33
    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-boolean p0, p0, Lads_mobile_sdk/dt2;->h:Z

    if-eqz p0, :cond_3b

    goto :goto_3c

    :cond_3b
    move v2, p0

    :goto_3c
    add-int/2addr v0, v2

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 11

    iget-object v0, p0, Lads_mobile_sdk/dt2;->a:Ljava/lang/String;

    iget v1, p0, Lads_mobile_sdk/dt2;->b:I

    iget-object v2, p0, Lads_mobile_sdk/dt2;->c:Ljava/lang/String;

    iget-object v3, p0, Lads_mobile_sdk/dt2;->d:Ljava/lang/String;

    iget-object v4, p0, Lads_mobile_sdk/dt2;->e:Ljava/lang/String;

    iget-object v5, p0, Lads_mobile_sdk/dt2;->f:Ljava/lang/Boolean;

    iget-boolean v6, p0, Lads_mobile_sdk/dt2;->g:Z

    iget-boolean p0, p0, Lads_mobile_sdk/dt2;->h:Z

    const-string v7, ", adConfigIndex="

    const-string v8, ", renderer="

    const-string v9, "RenderTraceMeta(renderId="

    invoke-static {v1, v9, v0, v7, v8}, Lrt2;->m(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, ", adapterName="

    const-string v7, ", adapterVersion="

    invoke-static {v0, v2, v1, v3, v7}, Ly41;->x(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", winningAd="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", isOfflineAd="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string v1, ", isHtmlAdResponse="

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string p0, ")"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
