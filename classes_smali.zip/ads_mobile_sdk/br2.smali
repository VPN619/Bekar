.class public final Lads_mobile_sdk/br2;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lnt2;


# instance fields
.field public final a:Ltv2;

.field public final b:Ltv2;

.field public final c:Ltv2;

.field public final d:Lads_mobile_sdk/ob1;

.field public final e:Ltv2;

.field public final synthetic f:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/ob1;Ltv2;Ltv2;Ltv2;Ltv2;)V
    .registers 7

    const/4 v0, 0x3

    iput v0, p0, Lads_mobile_sdk/br2;->f:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/br2;->d:Lads_mobile_sdk/ob1;

    iput-object p2, p0, Lads_mobile_sdk/br2;->a:Ltv2;

    iput-object p3, p0, Lads_mobile_sdk/br2;->b:Ltv2;

    iput-object p4, p0, Lads_mobile_sdk/br2;->c:Ltv2;

    iput-object p5, p0, Lads_mobile_sdk/br2;->e:Ltv2;

    return-void
.end method

.method public constructor <init>(Ltv2;Ltv2;Lads_mobile_sdk/ob1;Ltv2;Ltv2;)V
    .registers 7

    const/4 v0, 0x7

    iput v0, p0, Lads_mobile_sdk/br2;->f:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/br2;->a:Ltv2;

    iput-object p2, p0, Lads_mobile_sdk/br2;->b:Ltv2;

    iput-object p3, p0, Lads_mobile_sdk/br2;->d:Lads_mobile_sdk/ob1;

    iput-object p4, p0, Lads_mobile_sdk/br2;->c:Ltv2;

    iput-object p5, p0, Lads_mobile_sdk/br2;->e:Ltv2;

    return-void
.end method

.method public synthetic constructor <init>(Ltv2;Ltv2;Ltv2;Lads_mobile_sdk/ob1;Ltv2;I)V
    .registers 7

    iput p6, p0, Lads_mobile_sdk/br2;->f:I

    iput-object p1, p0, Lads_mobile_sdk/br2;->a:Ltv2;

    iput-object p2, p0, Lads_mobile_sdk/br2;->b:Ltv2;

    iput-object p3, p0, Lads_mobile_sdk/br2;->c:Ltv2;

    iput-object p4, p0, Lads_mobile_sdk/br2;->d:Lads_mobile_sdk/ob1;

    iput-object p5, p0, Lads_mobile_sdk/br2;->e:Ltv2;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Ltv2;Ltv2;Ltv2;Ltv2;Lads_mobile_sdk/ob1;I)V
    .registers 7

    iput p6, p0, Lads_mobile_sdk/br2;->f:I

    iput-object p1, p0, Lads_mobile_sdk/br2;->a:Ltv2;

    iput-object p2, p0, Lads_mobile_sdk/br2;->b:Ltv2;

    iput-object p3, p0, Lads_mobile_sdk/br2;->c:Ltv2;

    iput-object p4, p0, Lads_mobile_sdk/br2;->e:Ltv2;

    iput-object p5, p0, Lads_mobile_sdk/br2;->d:Lads_mobile_sdk/ob1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 24

    .prologue
    move-object/from16 v0, p0

    iget v1, v0, Lads_mobile_sdk/br2;->f:I

    iget-object v2, v0, Lads_mobile_sdk/br2;->e:Ltv2;

    iget-object v3, v0, Lads_mobile_sdk/br2;->c:Ltv2;

    iget-object v4, v0, Lads_mobile_sdk/br2;->d:Lads_mobile_sdk/ob1;

    iget-object v5, v0, Lads_mobile_sdk/br2;->b:Ltv2;

    iget-object v0, v0, Lads_mobile_sdk/br2;->a:Ltv2;

    packed-switch v1, :pswitch_data_190

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v7, v0

    check-cast v7, Lads_mobile_sdk/k1;

    invoke-interface {v5}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v8, v0

    check-cast v8, Lads_mobile_sdk/d6;

    iget-object v0, v4, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v9, v0

    check-cast v9, Landroid/content/Context;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v10, v0

    check-cast v10, Ld03;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v11, v0

    check-cast v11, Ll53;

    new-instance v6, Lads_mobile_sdk/yc2;

    invoke-direct/range {v6 .. v11}, Lads_mobile_sdk/yc2;-><init>(Lads_mobile_sdk/k1;Lads_mobile_sdk/d6;Landroid/content/Context;Ld03;Ll53;)V

    return-object v6

    :pswitch_38  #0x6
    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v7, v0

    check-cast v7, Lwy2;

    invoke-interface {v5}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v8, v0

    check-cast v8, Lads_mobile_sdk/rp1;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v9, v0

    check-cast v9, Lads_mobile_sdk/ga3;

    iget-object v0, v4, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v10, v0

    check-cast v10, Ljava/util/Map;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v11, v0

    check-cast v11, Lads_mobile_sdk/th3;

    new-instance v6, Lads_mobile_sdk/q;

    invoke-direct/range {v6 .. v11}, Lads_mobile_sdk/q;-><init>(Lwy2;Lads_mobile_sdk/rp1;Lads_mobile_sdk/ga3;Ljava/util/Map;Lads_mobile_sdk/th3;)V

    return-object v6

    :pswitch_5f  #0x5
    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v7, v0

    check-cast v7, Landroid/content/Context;

    invoke-interface {v5}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v8, v0

    check-cast v8, Lr73;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v9, v0

    check-cast v9, Ljava/util/concurrent/ExecutorService;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v10, v0

    check-cast v10, Lads_mobile_sdk/s11;

    iget-object v0, v4, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v0, Lads_mobile_sdk/l7;

    new-instance v6, Lads_mobile_sdk/qm1;

    new-instance v11, Ljava/util/Random;

    invoke-direct {v11}, Ljava/util/Random;-><init>()V

    invoke-virtual {v0}, Lads_mobile_sdk/l7;->G()Lads_mobile_sdk/tm1;

    move-result-object v1

    invoke-virtual {v1}, Lads_mobile_sdk/tm1;->s()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v0}, Lads_mobile_sdk/l7;->G()Lads_mobile_sdk/tm1;

    move-result-object v1

    invoke-virtual {v1}, Lads_mobile_sdk/tm1;->p()J

    move-result-wide v13

    invoke-virtual {v0}, Lads_mobile_sdk/l7;->G()Lads_mobile_sdk/tm1;

    move-result-object v1

    invoke-virtual {v1}, Lads_mobile_sdk/tm1;->q()J

    move-result-wide v15

    invoke-virtual {v0}, Lads_mobile_sdk/l7;->G()Lads_mobile_sdk/tm1;

    move-result-object v1

    invoke-virtual {v1}, Lads_mobile_sdk/tm1;->r()F

    move-result v1

    float-to-double v1, v1

    invoke-virtual {v0}, Lads_mobile_sdk/l7;->D()Ljava/lang/String;

    move-result-object v19

    invoke-virtual {v0}, Lads_mobile_sdk/l7;->C()I

    move-result v20

    invoke-virtual {v0}, Lads_mobile_sdk/l7;->K()I

    move-result v0

    invoke-static {v0}, Lc33;->x(I)I

    move-result v0

    int-to-long v3, v0

    move-wide/from16 v17, v1

    move-wide/from16 v21, v3

    invoke-direct/range {v6 .. v22}, Lads_mobile_sdk/qm1;-><init>(Landroid/content/Context;Lr73;Ljava/util/concurrent/ExecutorService;Lads_mobile_sdk/s11;Ljava/util/Random;Ljava/lang/String;JJDLjava/lang/String;IJ)V

    return-object v6

    :pswitch_c0  #0x4
    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v7, v0

    check-cast v7, Lwy2;

    invoke-interface {v5}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v8, v0

    check-cast v8, Lads_mobile_sdk/rp1;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v9, v0

    check-cast v9, Landroid/util/DisplayMetrics;

    iget-object v0, v4, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v10, v0

    check-cast v10, Landroid/view/View;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v11, v0

    check-cast v11, Lads_mobile_sdk/th3;

    new-instance v6, Lads_mobile_sdk/q;

    invoke-direct/range {v6 .. v11}, Lads_mobile_sdk/q;-><init>(Lwy2;Lads_mobile_sdk/rp1;Landroid/util/DisplayMetrics;Landroid/view/View;Lads_mobile_sdk/th3;)V

    return-object v6

    :pswitch_e7  #0x3
    iget-object v1, v4, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v7, v1

    check-cast v7, Landroid/content/Context;

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v8, v0

    check-cast v8, Lads_mobile_sdk/xq0;

    invoke-interface {v5}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v9, v0

    check-cast v9, Lads_mobile_sdk/a80;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v10, v0

    check-cast v10, Lads_mobile_sdk/o03;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v11, v0

    check-cast v11, Lads_mobile_sdk/aj;

    new-instance v6, Lp03;

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct/range {v6 .. v11}, Lads_mobile_sdk/eo;-><init>(Landroid/content/Context;Lads_mobile_sdk/xq0;Lads_mobile_sdk/a80;Lads_mobile_sdk/o03;Lads_mobile_sdk/aj;)V

    return-object v6

    :pswitch_11d  #0x2
    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v7, v0

    check-cast v7, Lads_mobile_sdk/vn3;

    invoke-interface {v5}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v8, v0

    check-cast v8, Lads_mobile_sdk/ab3;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v9, v0

    check-cast v9, Le63;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v10, v0

    check-cast v10, Lads_mobile_sdk/th3;

    iget-object v0, v4, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v11, v0

    check-cast v11, Ljava/util/concurrent/ExecutorService;

    new-instance v6, Lads_mobile_sdk/g43;

    invoke-direct/range {v6 .. v11}, Lads_mobile_sdk/g43;-><init>(Lads_mobile_sdk/vn3;Lads_mobile_sdk/ab3;Le63;Lads_mobile_sdk/th3;Ljava/util/concurrent/ExecutorService;)V

    return-object v6

    :pswitch_144  #0x1
    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v7, v0

    check-cast v7, Lads_mobile_sdk/mm0;

    invoke-interface {v5}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v8, v0

    check-cast v8, Lads_mobile_sdk/mm0;

    invoke-static {v3}, Lads_mobile_sdk/nj0;->a(Ltv2;)Lv03;

    move-result-object v9

    iget-object v0, v4, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v10, v0

    check-cast v10, Ljava/util/concurrent/ExecutorService;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v11, v0

    check-cast v11, Lads_mobile_sdk/th3;

    new-instance v6, Lads_mobile_sdk/cb3;

    invoke-direct/range {v6 .. v11}, Lads_mobile_sdk/cb3;-><init>(Lads_mobile_sdk/mm0;Lads_mobile_sdk/mm0;Lv03;Ljava/util/concurrent/ExecutorService;Lads_mobile_sdk/th3;)V

    return-object v6

    :pswitch_168  #0x0
    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v7, v0

    check-cast v7, Lwy2;

    invoke-interface {v5}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v8, v0

    check-cast v8, Lads_mobile_sdk/rp1;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v9, v0

    check-cast v9, Ljava/util/Map;

    iget-object v0, v4, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    move-object v10, v0

    check-cast v10, Landroid/content/Context;

    invoke-interface {v2}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    move-object v11, v0

    check-cast v11, Lads_mobile_sdk/th3;

    new-instance v6, Lads_mobile_sdk/ar2;

    const/4 v12, 0x0

    invoke-direct/range {v6 .. v12}, Lads_mobile_sdk/ar2;-><init>(Lwy2;Lads_mobile_sdk/rp1;Ljava/util/Map;Landroid/content/Context;Lads_mobile_sdk/th3;I)V

    return-object v6

    :pswitch_data_190
    .packed-switch 0x0
        :pswitch_168  #00000000
        :pswitch_144  #00000001
        :pswitch_11d  #00000002
        :pswitch_e7  #00000003
        :pswitch_c0  #00000004
        :pswitch_5f  #00000005
        :pswitch_38  #00000006
    .end packed-switch
.end method
