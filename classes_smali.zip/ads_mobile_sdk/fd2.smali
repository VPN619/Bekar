.class public final Lads_mobile_sdk/fd2;
.super Lzz0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lbk0;


# instance fields
.field public final synthetic a:Ljava/util/ArrayList;

.field public final synthetic b:Lvr1;

.field public final synthetic c:Lvr1;

.field public final synthetic d:Lads_mobile_sdk/av2;

.field public final synthetic e:Ljava/lang/String;

.field public final synthetic f:Lads_mobile_sdk/ae2;

.field public final synthetic g:J

.field public final synthetic h:Z


# direct methods
.method public constructor <init>(Ljava/util/ArrayList;Lvr1;Lvr1;Lads_mobile_sdk/av2;Ljava/lang/String;Lads_mobile_sdk/ae2;JZ)V
    .registers 10

    iput-object p1, p0, Lads_mobile_sdk/fd2;->a:Ljava/util/ArrayList;

    iput-object p2, p0, Lads_mobile_sdk/fd2;->b:Lvr1;

    iput-object p3, p0, Lads_mobile_sdk/fd2;->c:Lvr1;

    iput-object p4, p0, Lads_mobile_sdk/fd2;->d:Lads_mobile_sdk/av2;

    iput-object p5, p0, Lads_mobile_sdk/fd2;->e:Ljava/lang/String;

    iput-object p6, p0, Lads_mobile_sdk/fd2;->f:Lads_mobile_sdk/ae2;

    iput-wide p7, p0, Lads_mobile_sdk/fd2;->g:J

    iput-boolean p9, p0, Lads_mobile_sdk/fd2;->h:Z

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lzz0;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 18

    .prologue
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    check-cast v1, Lads_mobile_sdk/h1;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v2, v0, Lads_mobile_sdk/fd2;->a:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    iget-object v3, v0, Lads_mobile_sdk/fd2;->b:Lvr1;

    const/4 v4, 0x0

    iput-object v4, v3, Lvr1;->a:Ljava/lang/Object;

    iget-object v5, v0, Lads_mobile_sdk/fd2;->c:Lvr1;

    iput-object v4, v5, Lvr1;->a:Ljava/lang/Object;

    iget-object v6, v0, Lads_mobile_sdk/fd2;->d:Lads_mobile_sdk/av2;

    invoke-virtual {v6}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v1}, Lads_mobile_sdk/h1;->u()Ljava/util/Map;

    move-result-object v7

    invoke-interface {v7, v6}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Lads_mobile_sdk/ds0;

    sget-object v8, Lads_mobile_sdk/de2;->b:Lads_mobile_sdk/de2;

    if-nez v7, :cond_2e

    iput-object v8, v5, Lvr1;->a:Ljava/lang/Object;

    return-object v1

    :cond_2e
    invoke-virtual {v7}, Lads_mobile_sdk/ds0;->o()Ljava/util/Map;

    move-result-object v9

    iget-object v10, v0, Lads_mobile_sdk/fd2;->e:Ljava/lang/String;

    invoke-interface {v9, v10}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lads_mobile_sdk/h6;

    if-nez v9, :cond_3f

    iput-object v8, v5, Lvr1;->a:Ljava/lang/Object;

    return-object v1

    :cond_3f
    invoke-static {v10, v9}, Ljava/util/Collections;->singletonMap(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v12, v0, Lads_mobile_sdk/fd2;->f:Lads_mobile_sdk/ae2;

    iget-wide v13, v0, Lads_mobile_sdk/fd2;->g:J

    invoke-virtual {v12, v11, v13, v14, v2}, Lads_mobile_sdk/ae2;->a(Ljava/util/Map;JLjava/util/ArrayList;)Ljava/util/LinkedHashMap;

    move-result-object v2

    invoke-virtual {v2, v10}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lads_mobile_sdk/h6;

    if-eqz v2, :cond_5a

    invoke-virtual {v2}, Lads_mobile_sdk/h6;->r()Lw63;

    move-result-object v4

    :cond_5a
    if-nez v4, :cond_5e

    sget-object v4, Lba0;->a:Lba0;

    :cond_5e
    invoke-virtual {v1}, Lads_mobile_sdk/ku0;->n()Lads_mobile_sdk/iu0;

    move-result-object v1

    check-cast v1, Ltx2;

    invoke-interface {v4}, Ljava/util/List;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_af

    sget-object v0, Lads_mobile_sdk/de2;->c:Lads_mobile_sdk/de2;

    iput-object v0, v5, Lvr1;->a:Ljava/lang/Object;

    invoke-virtual {v7}, Lads_mobile_sdk/ku0;->n()Lads_mobile_sdk/iu0;

    move-result-object v0

    check-cast v0, Lzv2;

    invoke-virtual {v0}, Lzv2;->e()Ljava/util/Map;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0, v10}, Lzv2;->b(Ljava/lang/String;)V

    invoke-virtual {v0}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/ds0;

    invoke-virtual {v0}, Lads_mobile_sdk/ds0;->o()Ljava/util/Map;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Map;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_a0

    invoke-virtual {v1}, Ltx2;->e()Ljava/util/Map;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1, v6}, Ltx2;->b(Ljava/lang/String;)V

    goto/16 :goto_205

    :cond_a0
    invoke-virtual {v1}, Ltx2;->e()Ljava/util/Map;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1, v6, v0}, Ltx2;->c(Ljava/lang/String;Lads_mobile_sdk/ds0;)V

    goto/16 :goto_205

    :cond_af
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v11

    :goto_b8
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    if-eqz v12, :cond_d4

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    move-object v15, v12

    check-cast v15, Lads_mobile_sdk/c6;

    invoke-virtual {v15}, Lads_mobile_sdk/c6;->r$1()I

    move-result v15

    move-object/from16 p1, v7

    const/4 v7, 0x2

    if-ne v15, v7, :cond_d1

    invoke-virtual {v2, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_d1
    move-object/from16 v7, p1

    goto :goto_b8

    :cond_d4
    move-object/from16 p1, v7

    new-instance v7, Laq;

    const/16 v11, 0x10

    invoke-direct {v7, v11}, Laq;-><init>(I)V

    invoke-static {v2, v7}, Lbs;->x0(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    move-result v7

    if-eqz v7, :cond_134

    iput-object v8, v5, Lvr1;->a:Ljava/lang/Object;

    invoke-virtual {v1}, Ltx2;->e()Ljava/util/Map;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p1 .. p1}, Lads_mobile_sdk/ku0;->n()Lads_mobile_sdk/iu0;

    move-result-object v0

    check-cast v0, Lzv2;

    invoke-virtual {v0}, Lzv2;->e()Ljava/util/Map;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v9}, Lads_mobile_sdk/ku0;->n()Lads_mobile_sdk/iu0;

    move-result-object v2

    check-cast v2, Lky2;

    invoke-virtual {v2}, Lky2;->f()Ljava/util/List;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v2}, Lky2;->e()V

    invoke-virtual {v2}, Lky2;->f()Ljava/util/List;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v2, v4}, Lky2;->c(Ljava/util/List;)V

    invoke-virtual {v2, v13, v14}, Lky2;->b(J)V

    invoke-virtual {v2}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object v2

    check-cast v2, Lads_mobile_sdk/h6;

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0, v10, v2}, Lzv2;->c(Ljava/lang/String;Lads_mobile_sdk/h6;)V

    invoke-virtual {v0}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/ds0;

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1, v6, v0}, Ltx2;->c(Ljava/lang/String;Lads_mobile_sdk/ds0;)V

    goto/16 :goto_205

    :cond_134
    invoke-static {v2}, Lbs;->k0(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lads_mobile_sdk/c6;

    iput-object v2, v3, Lvr1;->a:Ljava/lang/Object;

    iget-boolean v0, v0, Lads_mobile_sdk/fd2;->h:Z

    if-eqz v0, :cond_15c

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_149
    :goto_149
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_190

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    move-object v5, v4

    check-cast v5, Lads_mobile_sdk/c6;

    if-eq v5, v2, :cond_149

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_149

    :cond_15c
    new-instance v0, Ljava/util/ArrayList;

    const/16 v3, 0xa

    invoke-static {v4, v3}, Lds;->Y(Ljava/lang/Iterable;I)I

    move-result v3

    invoke-direct {v0, v3}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v4}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_16b
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_190

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lads_mobile_sdk/c6;

    if-ne v4, v2, :cond_18c

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v4}, Lads_mobile_sdk/ku0;->n()Lads_mobile_sdk/iu0;

    move-result-object v4

    check-cast v4, Leu2;

    const/4 v5, 0x3

    invoke-virtual {v4, v5}, Leu2;->b(I)V

    invoke-virtual {v4}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object v4

    check-cast v4, Lads_mobile_sdk/c6;

    :cond_18c
    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_16b

    :cond_190
    invoke-virtual/range {p1 .. p1}, Lads_mobile_sdk/ku0;->n()Lads_mobile_sdk/iu0;

    move-result-object v2

    check-cast v2, Lzv2;

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v3

    if-eqz v3, :cond_1aa

    invoke-virtual {v2}, Lzv2;->e()Ljava/util/Map;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v2, v10}, Lzv2;->b(Ljava/lang/String;)V

    goto :goto_1da

    :cond_1aa
    invoke-virtual {v2}, Lzv2;->e()Ljava/util/Map;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v9}, Lads_mobile_sdk/ku0;->n()Lads_mobile_sdk/iu0;

    move-result-object v3

    check-cast v3, Lky2;

    invoke-virtual {v3}, Lky2;->f()Ljava/util/List;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v3}, Lky2;->e()V

    invoke-virtual {v3}, Lky2;->f()Ljava/util/List;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v3, v0}, Lky2;->c(Ljava/util/List;)V

    invoke-virtual {v3, v13, v14}, Lky2;->b(J)V

    invoke-virtual {v3}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/h6;

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v2, v10, v0}, Lzv2;->c(Ljava/lang/String;Lads_mobile_sdk/h6;)V

    :goto_1da
    invoke-virtual {v2}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/ds0;

    invoke-virtual {v0}, Lads_mobile_sdk/ds0;->o()Ljava/util/Map;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/Map;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_1f8

    invoke-virtual {v1}, Ltx2;->e()Ljava/util/Map;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1, v6}, Ltx2;->b(Ljava/lang/String;)V

    goto :goto_205

    :cond_1f8
    invoke-virtual {v1}, Ltx2;->e()Ljava/util/Map;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1, v6, v0}, Ltx2;->c(Ljava/lang/String;Lads_mobile_sdk/ds0;)V

    :goto_205
    invoke-virtual {v1}, Lads_mobile_sdk/iu0;->a()Lads_mobile_sdk/ku0;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/h1;

    return-object v0
.end method
