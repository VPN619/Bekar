.class public final Lads_mobile_sdk/ep0;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public a:I

.field public final synthetic b:Lads_mobile_sdk/qp0;

.field public final synthetic t:I


# direct methods
.method public synthetic constructor <init>(Lads_mobile_sdk/qp0;Lvx;I)V
    .registers 4

    iput p3, p0, Lads_mobile_sdk/ep0;->t:I

    iput-object p1, p0, Lads_mobile_sdk/ep0;->b:Lads_mobile_sdk/qp0;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 4

    .prologue
    iget p2, p0, Lads_mobile_sdk/ep0;->t:I

    iget-object p0, p0, Lads_mobile_sdk/ep0;->b:Lads_mobile_sdk/qp0;

    packed-switch p2, :pswitch_data_16

    new-instance p2, Lads_mobile_sdk/ep0;

    const/4 v0, 0x1

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/ep0;-><init>(Lads_mobile_sdk/qp0;Lvx;I)V

    return-object p2

    :pswitch_e  #0x0
    new-instance p2, Lads_mobile_sdk/ep0;

    const/4 v0, 0x0

    invoke-direct {p2, p0, p1, v0}, Lads_mobile_sdk/ep0;-><init>(Lads_mobile_sdk/qp0;Lvx;I)V

    return-object p2

    nop

    :pswitch_data_16
    .packed-switch 0x0
        :pswitch_e  #00000000
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .prologue
    iget v0, p0, Lads_mobile_sdk/ep0;->t:I

    sget-object v1, Lrg2;->a:Lrg2;

    iget-object p0, p0, Lads_mobile_sdk/ep0;->b:Lads_mobile_sdk/qp0;

    packed-switch v0, :pswitch_data_28

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/ep0;

    const/4 v0, 0x1

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/ep0;-><init>(Lads_mobile_sdk/qp0;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/ep0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_18  #0x0
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/ep0;

    const/4 v0, 0x0

    invoke-direct {p1, p0, p2, v0}, Lads_mobile_sdk/ep0;-><init>(Lads_mobile_sdk/qp0;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/ep0;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_28
    .packed-switch 0x0
        :pswitch_18  #00000000
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 9

    .prologue
    iget v0, p0, Lads_mobile_sdk/ep0;->t:I

    sget-object v1, Lrg2;->a:Lrg2;

    const/4 v2, 0x0

    const-string v3, "call to \'resume\' before \'invoke\' with coroutine"

    sget-object v4, Lwy;->a:Lwy;

    const/4 v5, 0x1

    iget-object v6, p0, Lads_mobile_sdk/ep0;->b:Lads_mobile_sdk/qp0;

    packed-switch v0, :pswitch_data_5c

    iget v0, p0, Lads_mobile_sdk/ep0;->a:I

    if-eqz v0, :cond_1e

    if-ne v0, v5, :cond_19

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_34

    :cond_19
    invoke-static {v3}, Lz6;->w(Ljava/lang/String;)V

    move-object v1, v2

    goto :goto_34

    :cond_1e
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, v6, Lads_mobile_sdk/zt1;->c:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lxw2;

    if-eqz p1, :cond_34

    iput v5, p0, Lads_mobile_sdk/ep0;->a:I

    invoke-static {v6, p1, p0}, Lads_mobile_sdk/qp0;->a(Lads_mobile_sdk/qp0;Lxw2;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v4, :cond_34

    move-object v1, v4

    :cond_34
    :goto_34
    return-object v1

    :pswitch_35  #0x0
    iget v0, p0, Lads_mobile_sdk/ep0;->a:I

    if-eqz v0, :cond_44

    if-ne v0, v5, :cond_3f

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_5a

    :cond_3f
    invoke-static {v3}, Lz6;->w(Ljava/lang/String;)V

    move-object v1, v2

    goto :goto_5a

    :cond_44
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, v6, Lads_mobile_sdk/zt1;->c:Ljava/lang/ref/WeakReference;

    invoke-virtual {p1}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lxw2;

    if-eqz p1, :cond_5a

    iput v5, p0, Lads_mobile_sdk/ep0;->a:I

    invoke-static {v6, p1, p0}, Lads_mobile_sdk/qp0;->b(Lads_mobile_sdk/qp0;Lxw2;Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v4, :cond_5a

    move-object v1, v4

    :cond_5a
    :goto_5a
    return-object v1

    nop

    :pswitch_data_5c
    .packed-switch 0x0
        :pswitch_35  #00000000
    .end packed-switch
.end method
