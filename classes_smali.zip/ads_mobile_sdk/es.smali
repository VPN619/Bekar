.class public final Lads_mobile_sdk/es;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lbw2;


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:Lads_mobile_sdk/ah3;


# direct methods
.method public constructor <init>(Landroid/content/Context;Lads_mobile_sdk/ah3;)V
    .registers 3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/es;->a:Landroid/content/Context;

    iput-object p2, p0, Lads_mobile_sdk/es;->b:Lads_mobile_sdk/ah3;

    return-void
.end method


# virtual methods
.method public final a(Lads_mobile_sdk/cy0;Ljava/util/Map;Lvx;)Ljava/lang/Object;
    .registers 23

    .prologue
    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    iget-object v5, v1, Lads_mobile_sdk/es;->b:Lads_mobile_sdk/ah3;

    const-string v0, "data"

    invoke-interface {v3, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    sget-object v6, Lwy;->a:Lwy;

    const/4 v7, 0x6

    const/4 v8, 0x0

    const-string v9, "openableIntents"

    sget-object v10, Lrg2;->a:Lrg2;

    if-nez v0, :cond_31

    const-string v0, "Missing data argument for canOpenIntents gmsg"

    invoke-static {v7, v0, v8}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    new-instance v0, Lfx0;

    invoke-direct {v0}, Lfx0;-><init>()V

    invoke-virtual {v2, v0, v9, v4}, Lads_mobile_sdk/cy0;->a(Lfx0;Ljava/lang/String;Lvx;)Ljava/lang/Object;

    move-result-object v0

    if-ne v0, v6, :cond_2d

    return-object v0

    :cond_2d
    move-object/from16 v17, v10

    goto/16 :goto_155

    :cond_31
    :try_start_31
    new-instance v12, Lkm0;

    invoke-direct {v12}, Lkm0;-><init>()V

    const-class v13, Lfx0;

    invoke-virtual {v12, v13, v0}, Lkm0;->a(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lfx0;
    :try_end_3e
    .catch Ljava/lang/Exception; {:try_start_31 .. :try_end_3e} :catch_13d

    const-string v12, "intents"

    invoke-static {v0, v12}, Lads_mobile_sdk/bw2;->e(Lfx0;Ljava/lang/String;)Lvv0;

    move-result-object v12

    if-nez v12, :cond_57

    const-string v0, "Missing intents parameter for canOpenIntents gmsg"

    invoke-static {v7, v0, v8}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    new-instance v0, Lfx0;

    invoke-direct {v0}, Lfx0;-><init>()V

    invoke-virtual {v2, v0, v9, v4}, Lads_mobile_sdk/cy0;->a(Lfx0;Ljava/lang/String;Lvx;)Ljava/lang/Object;

    move-result-object v0

    if-ne v0, v6, :cond_2d

    return-object v0

    :cond_57
    new-instance v7, Lfx0;

    invoke-direct {v7}, Lfx0;-><init>()V

    iget-object v0, v12, Lvv0;->a:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v8

    const/4 v14, 0x0

    :goto_63
    if-ge v14, v8, :cond_120

    invoke-static {v12, v14}, Lads_mobile_sdk/bw2;->a(Lvv0;I)Lfx0;

    move-result-object v0

    if-nez v0, :cond_73

    move/from16 v16, v8

    move-object/from16 v17, v10

    move-object/from16 v18, v12

    goto/16 :goto_116

    :cond_73
    const-string v15, "id"

    const-string v13, ""

    invoke-static {v0, v15, v13}, Lads_mobile_sdk/bw2;->a(Lfx0;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    const-string v11, "intent_url"

    invoke-static {v0, v11, v13}, Lads_mobile_sdk/bw2;->a(Lfx0;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    move/from16 v16, v8

    new-instance v8, Lo20;

    move-object/from16 v17, v10

    const/4 v10, 0x5

    invoke-direct {v8, v10, v1}, Lo20;-><init>(ILjava/lang/Object;)V

    invoke-static {v11, v8}, Lla1;->c(Ljava/lang/String;Lbk0;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Landroid/content/Intent;

    if-nez v8, :cond_e6

    new-instance v8, Landroid/content/Intent;

    invoke-direct {v8}, Landroid/content/Intent;-><init>()V

    const-string v11, "u"

    invoke-static {v0, v11, v13}, Lads_mobile_sdk/bw2;->a(Lfx0;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    new-instance v10, Lads_mobile_sdk/as;

    move-object/from16 v18, v12

    const/4 v12, 0x3

    invoke-direct {v10, v12, v8}, Lads_mobile_sdk/as;-><init>(ILandroid/content/Intent;)V

    invoke-static {v11, v10}, Lla1;->c(Ljava/lang/String;Lbk0;)Ljava/lang/Object;

    const-string v10, "i"

    invoke-static {v0, v10, v13}, Lads_mobile_sdk/bw2;->a(Lfx0;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    new-instance v11, Lads_mobile_sdk/as;

    const/4 v12, 0x4

    invoke-direct {v11, v12, v8}, Lads_mobile_sdk/as;-><init>(ILandroid/content/Intent;)V

    invoke-static {v10, v11}, Lla1;->c(Ljava/lang/String;Lbk0;)Ljava/lang/Object;

    const-string v10, "m"

    invoke-static {v0, v10, v13}, Lads_mobile_sdk/bw2;->a(Lfx0;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    new-instance v11, Lads_mobile_sdk/as;

    const/4 v12, 0x0

    invoke-direct {v11, v12, v8}, Lads_mobile_sdk/as;-><init>(ILandroid/content/Intent;)V

    invoke-static {v10, v11}, Lla1;->c(Ljava/lang/String;Lbk0;)Ljava/lang/Object;

    const-string v10, "p"

    invoke-static {v0, v10, v13}, Lads_mobile_sdk/bw2;->a(Lfx0;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    new-instance v11, Lads_mobile_sdk/as;

    const/4 v12, 0x1

    invoke-direct {v11, v12, v8}, Lads_mobile_sdk/as;-><init>(ILandroid/content/Intent;)V

    invoke-static {v10, v11}, Lla1;->c(Ljava/lang/String;Lbk0;)Ljava/lang/Object;

    const-string v10, "c"

    invoke-static {v0, v10, v13}, Lads_mobile_sdk/bw2;->a(Lfx0;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-instance v10, Lads_mobile_sdk/as;

    const/4 v11, 0x2

    invoke-direct {v10, v11, v8}, Lads_mobile_sdk/as;-><init>(ILandroid/content/Intent;)V

    invoke-static {v0, v10}, Lla1;->c(Ljava/lang/String;Lbk0;)Ljava/lang/Object;

    goto :goto_e9

    :cond_e6
    move-object/from16 v18, v12

    const/4 v12, 0x1

    :goto_e9
    :try_start_e9
    iget-object v0, v1, Lads_mobile_sdk/es;->a:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/high16 v10, 0x10000

    invoke-virtual {v0, v8, v10}, Landroid/content/pm/PackageManager;->resolveActivity(Landroid/content/Intent;I)Landroid/content/pm/ResolveInfo;

    move-result-object v0
    :try_end_f5
    .catch Ljava/lang/Exception; {:try_start_e9 .. :try_end_f5} :catch_f6

    goto :goto_10a

    :catch_f6
    move-exception v0

    new-instance v10, Ljava/lang/StringBuilder;

    const-string v11, "Failed resolving intent: "

    invoke-direct {v10, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v10, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v8, v0}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V

    move-object/from16 v0, v17

    :goto_10a
    if-eqz v0, :cond_10e

    move v10, v12

    goto :goto_10f

    :cond_10e
    const/4 v10, 0x0

    :goto_10f
    invoke-static {v10}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    invoke-virtual {v7, v15, v0}, Lfx0;->r(Ljava/lang/String;Ljava/lang/Boolean;)V

    :goto_116
    add-int/lit8 v14, v14, 0x1

    move/from16 v8, v16

    move-object/from16 v10, v17

    move-object/from16 v12, v18

    goto/16 :goto_63

    :cond_120
    move-object/from16 v17, v10

    const-string v0, "ad_mid"

    invoke-interface {v3, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/String;

    if-eqz v1, :cond_136

    invoke-static {v1}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_133

    goto :goto_136

    :cond_133
    invoke-virtual {v7, v0, v1}, Lfx0;->s(Ljava/lang/String;Ljava/lang/String;)V

    :cond_136
    :goto_136
    invoke-virtual {v2, v7, v9, v4}, Lads_mobile_sdk/cy0;->a(Lfx0;Ljava/lang/String;Lvx;)Ljava/lang/Object;

    move-result-object v0

    if-ne v0, v6, :cond_155

    return-object v0

    :catch_13d
    move-exception v0

    move-object/from16 v17, v10

    const-string v1, "Invalid JSON data for canOpenIntents gmsg"

    const/4 v12, 0x4

    invoke-static {v12, v1, v0}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    invoke-virtual {v5, v1, v0}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V

    new-instance v0, Lfx0;

    invoke-direct {v0}, Lfx0;-><init>()V

    invoke-virtual {v2, v0, v9, v4}, Lads_mobile_sdk/cy0;->a(Lfx0;Ljava/lang/String;Lvx;)Ljava/lang/Object;

    move-result-object v0

    if-ne v0, v6, :cond_155

    return-object v0

    :cond_155
    :goto_155
    return-object v17
.end method

.method public final b()I
    .registers 1

    const/16 p0, 0x21

    return p0
.end method
