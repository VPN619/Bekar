.class public final Lads_mobile_sdk/az2;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lo23;


# instance fields
.field public final a:Ljava/util/Optional;

.field public final b:Ljava/util/Optional;

.field public final c:Lads_mobile_sdk/sy2;

.field public final d:Lads_mobile_sdk/av2;

.field public final e:Lli;

.field public final f:Ljava/util/List;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/qr0;Ljava/util/Optional;Ljava/util/Optional;Lads_mobile_sdk/sy2;Lads_mobile_sdk/av2;Lli;)V
    .registers 7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Lads_mobile_sdk/az2;->a:Ljava/util/Optional;

    iput-object p3, p0, Lads_mobile_sdk/az2;->b:Ljava/util/Optional;

    iput-object p4, p0, Lads_mobile_sdk/az2;->c:Lads_mobile_sdk/sy2;

    iput-object p5, p0, Lads_mobile_sdk/az2;->d:Lads_mobile_sdk/av2;

    iput-object p6, p0, Lads_mobile_sdk/az2;->e:Lli;

    const-string p2, "8"

    invoke-static {p2}, Luz;->G(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p2

    sget-object p3, Lads_mobile_sdk/fo;->a$15:Lads_mobile_sdk/fo;

    const-string p4, "gad:scar_rtb_signal:enabled_list"

    invoke-virtual {p1, p4, p2, p3}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/util/List;

    iput-object p1, p0, Lads_mobile_sdk/az2;->f:Ljava/util/List;

    return-void
.end method


# virtual methods
.method public final a()Lads_mobile_sdk/lw0;
    .registers 1

    sget-object p0, Lads_mobile_sdk/lw0;->M:Lads_mobile_sdk/lw0;

    return-object p0
.end method

.method public final d(Lvx;)Ljava/lang/Object;
    .registers 6

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/zy2;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/zy2;

    iget v1, v0, Lads_mobile_sdk/zy2;->c:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/zy2;->c:I

    goto :goto_1a

    :cond_13
    new-instance v0, Lads_mobile_sdk/zy2;

    check-cast p1, Lwx;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/zy2;-><init>(Lads_mobile_sdk/az2;Lwx;)V

    :goto_1a
    iget-object p1, v0, Lads_mobile_sdk/zy2;->a:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/zy2;->c:I

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_2e

    if-ne v1, v3, :cond_28

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_58

    :cond_28
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v2

    :cond_2e
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/az2;->b:Ljava/util/Optional;

    invoke-static {p1}, Lw53;->I(Ljava/util/Optional;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lf32;

    iget-object p1, p0, Lads_mobile_sdk/az2;->a:Ljava/util/Optional;

    invoke-static {p1}, Lw53;->I(Ljava/util/Optional;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lqh;

    if-eqz p1, :cond_47

    invoke-interface {p1}, Lqh;->k()Ls4;

    move-result-object v2

    :cond_47
    iput v3, v0, Lads_mobile_sdk/zy2;->c:I

    iget-object p1, p0, Lads_mobile_sdk/az2;->c:Lads_mobile_sdk/sy2;

    iget-object v1, p0, Lads_mobile_sdk/az2;->d:Lads_mobile_sdk/av2;

    iget-object p0, p0, Lads_mobile_sdk/az2;->e:Lli;

    invoke-virtual {p1, v2, v1, p0, v0}, Lads_mobile_sdk/sy2;->a(Ls4;Lads_mobile_sdk/av2;Lli;Lwx;)Ljava/io/Serializable;

    move-result-object p1

    sget-object p0, Lwy;->a:Lwy;

    if-ne p1, p0, :cond_58

    return-object p0

    :cond_58
    :goto_58
    check-cast p1, Ljava/util/List;

    new-instance p0, Lads_mobile_sdk/wy2;

    invoke-direct {p0, p1}, Lads_mobile_sdk/wy2;-><init>(Ljava/util/List;)V

    new-instance p1, Lads_mobile_sdk/hv0;

    invoke-direct {p1, p0}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    return-object p1
.end method
