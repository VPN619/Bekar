.class public final Lads_mobile_sdk/cn0;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lnt2;


# instance fields
.field public final a:Lads_mobile_sdk/ob1;

.field public final b:Lads_mobile_sdk/ah0;

.field public final c:Ltv2;

.field public final d:Ltv2;

.field public final synthetic e:I


# direct methods
.method public constructor <init>(Lads_mobile_sdk/ah0;Ltv2;Ltv2;Lads_mobile_sdk/ob1;)V
    .registers 6

    const/4 v0, 0x2

    iput v0, p0, Lads_mobile_sdk/cn0;->e:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/cn0;->b:Lads_mobile_sdk/ah0;

    iput-object p2, p0, Lads_mobile_sdk/cn0;->c:Ltv2;

    iput-object p3, p0, Lads_mobile_sdk/cn0;->d:Ltv2;

    iput-object p4, p0, Lads_mobile_sdk/cn0;->a:Lads_mobile_sdk/ob1;

    return-void
.end method

.method public constructor <init>(Lads_mobile_sdk/ob1;Lads_mobile_sdk/ah0;Ltv2;Ltv2;)V
    .registers 6

    const/4 v0, 0x0

    iput v0, p0, Lads_mobile_sdk/cn0;->e:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/cn0;->a:Lads_mobile_sdk/ob1;

    iput-object p2, p0, Lads_mobile_sdk/cn0;->b:Lads_mobile_sdk/ah0;

    iput-object p3, p0, Lads_mobile_sdk/cn0;->c:Ltv2;

    iput-object p4, p0, Lads_mobile_sdk/cn0;->d:Ltv2;

    return-void
.end method

.method public synthetic constructor <init>(Lads_mobile_sdk/ob1;Ltv2;Ltv2;Lads_mobile_sdk/ah0;I)V
    .registers 6

    iput p5, p0, Lads_mobile_sdk/cn0;->e:I

    iput-object p1, p0, Lads_mobile_sdk/cn0;->a:Lads_mobile_sdk/ob1;

    iput-object p2, p0, Lads_mobile_sdk/cn0;->c:Ltv2;

    iput-object p3, p0, Lads_mobile_sdk/cn0;->d:Ltv2;

    iput-object p4, p0, Lads_mobile_sdk/cn0;->b:Lads_mobile_sdk/ah0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Ltv2;Ltv2;Lads_mobile_sdk/ob1;Lads_mobile_sdk/ah0;)V
    .registers 6

    const/4 v0, 0x4

    iput v0, p0, Lads_mobile_sdk/cn0;->e:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/cn0;->c:Ltv2;

    iput-object p2, p0, Lads_mobile_sdk/cn0;->d:Ltv2;

    iput-object p3, p0, Lads_mobile_sdk/cn0;->a:Lads_mobile_sdk/ob1;

    iput-object p4, p0, Lads_mobile_sdk/cn0;->b:Lads_mobile_sdk/ah0;

    return-void
.end method


# virtual methods
.method public final get()Ljava/lang/Object;
    .registers 5

    .prologue
    iget v0, p0, Lads_mobile_sdk/cn0;->e:I

    iget-object v1, p0, Lads_mobile_sdk/cn0;->b:Lads_mobile_sdk/ah0;

    iget-object v2, p0, Lads_mobile_sdk/cn0;->a:Lads_mobile_sdk/ob1;

    iget-object v3, p0, Lads_mobile_sdk/cn0;->d:Ltv2;

    iget-object p0, p0, Lads_mobile_sdk/cn0;->c:Ltv2;

    packed-switch v0, :pswitch_data_a6

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lli;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/bn0;

    iget-object v2, v2, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v2, Lads_mobile_sdk/a2;

    invoke-virtual {v1}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lvy;

    new-instance v3, Lads_mobile_sdk/wm0;

    invoke-direct {v3, p0, v0, v2, v1}, Lads_mobile_sdk/wm0;-><init>(Lli;Lads_mobile_sdk/bn0;Lads_mobile_sdk/a2;Lvy;)V

    return-object v3

    :pswitch_29  #0x3
    iget-object v0, v2, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v0, Landroid/content/Context;

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/qr0;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lx43;

    invoke-virtual {v1}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lvy;

    new-instance v3, Lads_mobile_sdk/ur0;

    invoke-direct {v3, v0, p0, v2, v1}, Lads_mobile_sdk/ur0;-><init>(Landroid/content/Context;Lads_mobile_sdk/qr0;Lx43;Lvy;)V

    return-object v3

    :pswitch_45  #0x2
    invoke-virtual {v1}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lvy;

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/ek;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lads_mobile_sdk/x33;

    iget-object v2, v2, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v2, Lads_mobile_sdk/pm2;

    new-instance v3, Lads_mobile_sdk/bw2;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    return-object v3

    :pswitch_6d  #0x1
    iget-object v0, v2, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v0, Landroid/content/Context;

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/qr0;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lx43;

    invoke-virtual {v1}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lvy;

    new-instance v3, Lads_mobile_sdk/l23;

    invoke-direct {v3, v0, p0, v2, v1}, Lads_mobile_sdk/l23;-><init>(Landroid/content/Context;Lads_mobile_sdk/qr0;Lx43;Lvy;)V

    return-object v3

    :pswitch_89  #0x0
    iget-object v0, v2, Lads_mobile_sdk/ob1;->a:Ljava/lang/Object;

    check-cast v0, Landroid/content/Context;

    invoke-virtual {v1}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lads_mobile_sdk/ah3;

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/ux2;

    invoke-interface {v3}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lads_mobile_sdk/qr0;

    new-instance v3, Lads_mobile_sdk/bn0;

    invoke-direct {v3, v0, v1, p0, v2}, Lads_mobile_sdk/bn0;-><init>(Landroid/content/Context;Lads_mobile_sdk/ah3;Lads_mobile_sdk/ux2;Lads_mobile_sdk/qr0;)V

    return-object v3

    nop

    :pswitch_data_a6
    .packed-switch 0x0
        :pswitch_89  #00000000
        :pswitch_6d  #00000001
        :pswitch_45  #00000002
        :pswitch_29  #00000003
    .end packed-switch
.end method
