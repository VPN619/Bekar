.class public abstract Lads_mobile_sdk/cr2;
.super Lads_mobile_sdk/f2;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public l:Ljava/lang/String;

.field public final m:Lads_mobile_sdk/dr2;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/kh3;Lli;Lads_mobile_sdk/av2;JILads_mobile_sdk/a2;Lads_mobile_sdk/xv;Lads_mobile_sdk/n13;Ljava/lang/String;Lads_mobile_sdk/ve2;)V
    .registers 12

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct/range {p0 .. p11}, Lads_mobile_sdk/f2;-><init>(Lads_mobile_sdk/kh3;Lli;Lads_mobile_sdk/av2;JILads_mobile_sdk/a2;Lads_mobile_sdk/xv;Lads_mobile_sdk/n13;Ljava/lang/String;Lads_mobile_sdk/ve2;)V

    new-instance p1, Lads_mobile_sdk/dr2;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/cr2;->m:Lads_mobile_sdk/dr2;

    return-void
.end method


# virtual methods
.method public final a(Landroid/os/Bundle;Ljava/util/LinkedHashMap;)Lm4;
    .registers 13

    .prologue
    iget-object v1, p0, Lads_mobile_sdk/cr2;->l:Ljava/lang/String;

    if-eqz v1, :cond_1d

    iget-object p0, p0, Lads_mobile_sdk/f2;->b:Lli;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lm4;

    iget-object v2, p0, Lli;->a:Ljava/util/LinkedHashSet;

    iget-object v3, p0, Lli;->b:Ljava/lang/String;

    iget-object v4, p0, Lli;->c:Ljava/util/LinkedHashMap;

    iget-object v6, p0, Lli;->e:Ljava/util/HashSet;

    iget-object v7, p0, Lli;->f:Ljava/util/HashSet;

    iget-object v9, p0, Lli;->h:Ljava/lang/String;

    move-object v5, p1

    move-object v8, p2

    invoke-direct/range {v0 .. v9}, Lm4;-><init>(Ljava/lang/String;Ljava/util/LinkedHashSet;Ljava/lang/String;Ljava/util/LinkedHashMap;Landroid/os/Bundle;Ljava/util/HashSet;Ljava/util/HashSet;Ljava/util/LinkedHashMap;Ljava/lang/String;)V

    return-object v0

    :cond_1d
    const-string p0, "innerAdUnitId"

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0
.end method

.method public final b()Z
    .registers 2

    .prologue
    iget-object p0, p0, Lads_mobile_sdk/f2;->f:Lads_mobile_sdk/a2;

    iget-object p0, p0, Lads_mobile_sdk/a2;->c:Lfx0;

    const-string v0, "pubid"

    if-nez p0, :cond_9

    goto :goto_15

    :cond_9
    :try_start_9
    invoke-virtual {p0, v0}, Lfx0;->v(Ljava/lang/String;)Lkw0;

    move-result-object p0

    invoke-virtual {p0}, Lkw0;->m()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_14
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_14} :catch_15

    goto :goto_17

    :catch_15
    :goto_15
    const-string p0, ""

    :goto_17
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    if-lez p0, :cond_1f

    const/4 p0, 0x1

    goto :goto_20

    :cond_1f
    const/4 p0, 0x0

    :goto_20
    return p0
.end method

.method public final g()Landroid/os/Bundle;
    .registers 5

    .prologue
    new-instance v0, Lcom/google/android/gms/ads/mediation/admob/AdMobAdapter;

    invoke-direct {v0}, Lcom/google/android/gms/ads/mediation/admob/AdMobAdapter;-><init>()V

    iget-object v1, p0, Lads_mobile_sdk/f2;->b:Lli;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-class v2, Lcom/google/android/gms/ads/mediation/admob/AdMobAdapter;

    invoke-virtual {v2, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_15

    iget-object v1, v1, Lli;->d:Landroid/os/Bundle;

    goto :goto_21

    :cond_15
    iget-object v1, v1, Lli;->g:Ljava/util/LinkedHashMap;

    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Landroid/os/Bundle;

    :goto_21
    iget-object p0, p0, Lads_mobile_sdk/f2;->f:Lads_mobile_sdk/a2;

    iget-object p0, p0, Lads_mobile_sdk/a2;->c:Lfx0;

    invoke-static {p0}, Lads_mobile_sdk/bw2;->b(Lfx0;)Landroid/os/Bundle;

    move-result-object p0

    invoke-virtual {v0, v1, p0}, Lcom/google/android/gms/ads/mediation/admob/AdMobAdapter;->buildExtrasBundle(Landroid/os/Bundle;Landroid/os/Bundle;)Landroid/os/Bundle;

    move-result-object p0

    return-object p0
.end method

.method public final h()V
    .registers 19

    .prologue
    move-object/from16 v0, p0

    iget-object v2, v0, Lads_mobile_sdk/cr2;->l:Ljava/lang/String;

    if-eqz v2, :cond_19a

    iget-object v15, v0, Lads_mobile_sdk/f2;->f:Lads_mobile_sdk/a2;

    iget-object v3, v15, Lads_mobile_sdk/a2;->h:Ljava/lang/String;

    iget-object v1, v15, Lads_mobile_sdk/a2;->v:Ljava/util/ArrayList;

    new-instance v4, Ljava/util/ArrayList;

    const/16 v5, 0xa

    invoke-static {v1, v5}, Lds;->Y(Ljava/lang/Iterable;I)I

    move-result v6

    invoke-direct {v4, v6}, Ljava/util/ArrayList;-><init>(I)V

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v6

    const/16 v16, 0x0

    move/from16 v7, v16

    :goto_1f
    if-ge v7, v6, :cond_34

    invoke-virtual {v1, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    add-int/lit8 v7, v7, 0x1

    check-cast v8, Landroid/net/Uri;

    invoke-virtual {v8}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v4, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1f

    :cond_34
    iget-object v1, v15, Lads_mobile_sdk/a2;->H:Ljava/util/ArrayList;

    new-instance v6, Ljava/util/ArrayList;

    invoke-static {v1, v5}, Lds;->Y(Ljava/lang/Iterable;I)I

    move-result v7

    invoke-direct {v6, v7}, Ljava/util/ArrayList;-><init>(I)V

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v7

    move/from16 v8, v16

    :goto_45
    if-ge v8, v7, :cond_5a

    invoke-virtual {v1, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    add-int/lit8 v8, v8, 0x1

    check-cast v9, Landroid/net/Uri;

    invoke-virtual {v9}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v6, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_45

    :cond_5a
    iget-object v1, v15, Lads_mobile_sdk/a2;->Q:Ljava/util/ArrayList;

    move-object v7, v6

    new-instance v6, Ljava/util/ArrayList;

    invoke-static {v1, v5}, Lds;->Y(Ljava/lang/Iterable;I)I

    move-result v8

    invoke-direct {v6, v8}, Ljava/util/ArrayList;-><init>(I)V

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v8

    move/from16 v9, v16

    :goto_6c
    if-ge v9, v8, :cond_81

    invoke-virtual {v1, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    add-int/lit8 v9, v9, 0x1

    check-cast v10, Landroid/net/Uri;

    invoke-virtual {v10}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v6, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_6c

    :cond_81
    iget-object v1, v15, Lads_mobile_sdk/a2;->D:Ljava/util/ArrayList;

    move-object v8, v7

    new-instance v7, Ljava/util/ArrayList;

    invoke-static {v1, v5}, Lds;->Y(Ljava/lang/Iterable;I)I

    move-result v9

    invoke-direct {v7, v9}, Ljava/util/ArrayList;-><init>(I)V

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v9

    move/from16 v10, v16

    :goto_93
    if-ge v10, v9, :cond_a8

    invoke-virtual {v1, v10}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    add-int/lit8 v10, v10, 0x1

    check-cast v11, Landroid/net/Uri;

    invoke-virtual {v11}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v7, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_93

    :cond_a8
    iget-object v1, v15, Lads_mobile_sdk/a2;->j0:Ljava/util/ArrayList;

    move-object v9, v8

    new-instance v8, Ljava/util/ArrayList;

    invoke-static {v1, v5}, Lds;->Y(Ljava/lang/Iterable;I)I

    move-result v10

    invoke-direct {v8, v10}, Ljava/util/ArrayList;-><init>(I)V

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v10

    move/from16 v11, v16

    :goto_ba
    if-ge v11, v10, :cond_cf

    invoke-virtual {v1, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v12

    add-int/lit8 v11, v11, 0x1

    check-cast v12, Landroid/net/Uri;

    invoke-virtual {v12}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v8, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_ba

    :cond_cf
    iget-object v1, v15, Lads_mobile_sdk/a2;->f0:Ljava/util/ArrayList;

    move-object v10, v9

    new-instance v9, Ljava/util/ArrayList;

    invoke-static {v1, v5}, Lds;->Y(Ljava/lang/Iterable;I)I

    move-result v11

    invoke-direct {v9, v11}, Ljava/util/ArrayList;-><init>(I)V

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v11

    move/from16 v12, v16

    :goto_e1
    if-ge v12, v11, :cond_f6

    invoke-virtual {v1, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v13

    add-int/lit8 v12, v12, 0x1

    check-cast v13, Landroid/net/Uri;

    invoke-virtual {v13}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v9, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_e1

    :cond_f6
    iget-object v1, v15, Lads_mobile_sdk/a2;->i0:Ljava/util/ArrayList;

    move-object v11, v10

    new-instance v10, Ljava/util/ArrayList;

    invoke-static {v1, v5}, Lds;->Y(Ljava/lang/Iterable;I)I

    move-result v12

    invoke-direct {v10, v12}, Ljava/util/ArrayList;-><init>(I)V

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v12

    move/from16 v13, v16

    :goto_108
    if-ge v13, v12, :cond_11d

    invoke-virtual {v1, v13}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v14

    add-int/lit8 v13, v13, 0x1

    check-cast v14, Landroid/net/Uri;

    invoke-virtual {v14}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v10, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_108

    :cond_11d
    iget-boolean v1, v15, Lads_mobile_sdk/a2;->L:Z

    iget-object v12, v15, Lads_mobile_sdk/a2;->Y:Lfx0;

    iget-object v14, v15, Lads_mobile_sdk/a2;->Z:Lvv0;

    iget-boolean v13, v15, Lads_mobile_sdk/a2;->o0:Z

    move/from16 v17, v5

    move-object v5, v11

    move v11, v1

    new-instance v1, Lnj1;

    invoke-direct/range {v1 .. v14}, Lnj1;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;Ljava/util/ArrayList;ZLfx0;ZLvv0;)V

    iget-object v2, v15, Lads_mobile_sdk/a2;->k0:Lads_mobile_sdk/cw2;

    if-eqz v2, :cond_156

    iget v3, v2, Lads_mobile_sdk/cw2;->a:I

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    new-instance v4, Ldj1;

    const-string v5, "rb_amount"

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    iget-object v2, v2, Lads_mobile_sdk/cw2;->b:Ljava/lang/String;

    new-instance v3, Ldj1;

    const-string v5, "rb_type"

    invoke-direct {v3, v5, v2}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    filled-new-array {v4, v3}, [Ldj1;

    move-result-object v2

    invoke-static {v2}, Lnp3;->q([Ldj1;)Landroid/os/Bundle;

    move-result-object v2

    invoke-static {v2}, Luz;->G(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    iput-object v2, v1, Lnj1;->m:Ljava/util/List;

    :cond_156
    iget-object v2, v0, Lads_mobile_sdk/cr2;->m:Lads_mobile_sdk/dr2;

    iput-object v1, v2, Lads_mobile_sdk/dr2;->a:Lnj1;

    iget-object v0, v0, Lads_mobile_sdk/f2;->g:Lads_mobile_sdk/xv;

    iget-object v1, v0, Lads_mobile_sdk/xv;->m:Ljava/util/ArrayList;

    new-instance v4, Ljava/util/ArrayList;

    const/16 v3, 0xa

    invoke-static {v1, v3}, Lds;->Y(Ljava/lang/Iterable;I)I

    move-result v3

    invoke-direct {v4, v3}, Ljava/util/ArrayList;-><init>(I)V

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v3

    move/from16 v5, v16

    :goto_16f
    if-ge v5, v3, :cond_184

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    add-int/lit8 v5, v5, 0x1

    check-cast v6, Landroid/net/Uri;

    invoke-virtual {v6}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v4, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_16f

    :cond_184
    iget-wide v5, v0, Lads_mobile_sdk/xv;->n:J

    sget-object v1, Lv60;->b:Lp80;

    sget-object v1, Ly60;->e:Ly60;

    invoke-static {v5, v6, v1}, Lv60;->l(JLy60;)J

    move-result-wide v5

    iget-object v7, v0, Lads_mobile_sdk/xv;->h:Ljava/lang/String;

    iget-object v8, v0, Lads_mobile_sdk/xv;->q:Lfx0;

    new-instance v3, Loj1;

    invoke-direct/range {v3 .. v8}, Loj1;-><init>(Ljava/util/ArrayList;JLjava/lang/String;Lfx0;)V

    iput-object v3, v2, Lads_mobile_sdk/dr2;->b:Loj1;

    return-void

    :cond_19a
    const-string v0, "innerAdUnitId"

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    const/4 v0, 0x0

    throw v0
.end method
