.class public final enum Lads_mobile_sdk/fs0;
.super Ljava/lang/Enum;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final enum a:Lads_mobile_sdk/fs0;

.field public static final enum b:Lads_mobile_sdk/fs0;

.field public static final enum c:Lads_mobile_sdk/fs0;

.field public static final synthetic d:[Lads_mobile_sdk/fs0;


# direct methods
.method static constructor <clinit>()V
    .registers 6

    new-instance v0, Lads_mobile_sdk/fs0;

    const-string v1, "VIDEO_CONTROLS"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    new-instance v1, Lads_mobile_sdk/fs0;

    const-string v2, "CLOSE_AD"

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v1, Lads_mobile_sdk/fs0;->a:Lads_mobile_sdk/fs0;

    new-instance v2, Lads_mobile_sdk/fs0;

    const-string v3, "NOT_VISIBLE"

    const/4 v4, 0x2

    invoke-direct {v2, v3, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v2, Lads_mobile_sdk/fs0;->b:Lads_mobile_sdk/fs0;

    new-instance v3, Lads_mobile_sdk/fs0;

    const-string v4, "OTHER"

    const/4 v5, 0x3

    invoke-direct {v3, v4, v5}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v3, Lads_mobile_sdk/fs0;->c:Lads_mobile_sdk/fs0;

    filled-new-array {v0, v1, v2, v3}, [Lads_mobile_sdk/fs0;

    move-result-object v0

    sput-object v0, Lads_mobile_sdk/fs0;->d:[Lads_mobile_sdk/fs0;

    return-void
.end method

.method public static values()[Lads_mobile_sdk/fs0;
    .registers 1

    sget-object v0, Lads_mobile_sdk/fs0;->d:[Lads_mobile_sdk/fs0;

    invoke-virtual {v0}, [Lads_mobile_sdk/fs0;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lads_mobile_sdk/fs0;

    return-object v0
.end method
