.class public final Lads_mobile_sdk/fh2;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lgt2;


# instance fields
.field public final a:Lads_mobile_sdk/xj2;

.field public final b:Lvy;

.field public final c:Lads_mobile_sdk/av2;

.field public final d:Lads_mobile_sdk/qr0;

.field public final e:Ljava/util/concurrent/atomic/AtomicBoolean;

.field public final f:Lnb1;

.field public g:Lx52;

.field public final h:Z


# direct methods
.method public constructor <init>(Lads_mobile_sdk/xj2;Lvy;Lads_mobile_sdk/av2;Lads_mobile_sdk/qr0;Lads_mobile_sdk/ux2;)V
    .registers 7

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/fh2;->a:Lads_mobile_sdk/xj2;

    iput-object p2, p0, Lads_mobile_sdk/fh2;->b:Lvy;

    iput-object p3, p0, Lads_mobile_sdk/fh2;->c:Lads_mobile_sdk/av2;

    iput-object p4, p0, Lads_mobile_sdk/fh2;->d:Lads_mobile_sdk/qr0;

    new-instance p1, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 p2, 0x0

    invoke-direct {p1, p2}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    iput-object p1, p0, Lads_mobile_sdk/fh2;->e:Ljava/util/concurrent/atomic/AtomicBoolean;

    new-instance p1, Lnb1;

    invoke-direct {p1}, Lnb1;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/fh2;->f:Lnb1;

    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sget-object p5, Lads_mobile_sdk/fo;->a:Lads_mobile_sdk/fo;

    const-string v0, "gads:ad_close_listener:enabled"

    invoke-virtual {p4, v0, p1, p5}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Boolean;

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_52

    sget-object p1, Lads_mobile_sdk/av2;->h:Lads_mobile_sdk/av2;

    sget-object p4, Lads_mobile_sdk/av2;->j:Lads_mobile_sdk/av2;

    sget-object p5, Lads_mobile_sdk/av2;->k:Lads_mobile_sdk/av2;

    sget-object v0, Lads_mobile_sdk/av2;->e:Lads_mobile_sdk/av2;

    filled-new-array {p1, p4, p5, v0}, [Lads_mobile_sdk/av2;

    move-result-object p1

    invoke-static {p1}, Laf;->x0([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object p1

    invoke-interface {p1, p3}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_52

    const/4 p2, 0x1

    :cond_52
    iput-boolean p2, p0, Lads_mobile_sdk/fh2;->h:Z

    return-void
.end method


# virtual methods
.method public final e()Lrg2;
    .registers 10

    .prologue
    sget-object v0, Lads_mobile_sdk/fo;->a$18:Lads_mobile_sdk/fo;

    iget-boolean v1, p0, Lads_mobile_sdk/fh2;->h:Z

    sget-object v2, Lrg2;->a:Lrg2;

    if-nez v1, :cond_9

    return-object v2

    :cond_9
    iget-object v1, p0, Lads_mobile_sdk/fh2;->c:Lads_mobile_sdk/av2;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v3, 0x1

    const-wide/16 v4, 0x0

    sget-object v6, Ly60;->f:Ly60;

    const/4 v7, 0x3

    iget-object v8, p0, Lads_mobile_sdk/fh2;->d:Lads_mobile_sdk/qr0;

    if-eq v1, v3, :cond_71

    const/4 v3, 0x4

    if-eq v1, v3, :cond_58

    const/4 v3, 0x6

    if-eq v1, v3, :cond_3f

    const/4 v3, 0x7

    if-eq v1, v3, :cond_26

    sget-object v0, Lv60;->b:Lp80;

    move-wide v0, v4

    goto :goto_89

    :cond_26
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Lv60;->b:Lp80;

    invoke-static {v7, v6}, Li10;->G0(ILy60;)J

    move-result-wide v6

    new-instance v1, Lv60;

    invoke-direct {v1, v6, v7}, Lv60;-><init>(J)V

    const-string v3, "gads:rewarded_interstitial_ad_close_timeout"

    invoke-virtual {v8, v3, v1, v0}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lv60;

    iget-wide v0, v0, Lv60;->a:J

    goto :goto_89

    :cond_3f
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Lv60;->b:Lp80;

    invoke-static {v7, v6}, Li10;->G0(ILy60;)J

    move-result-wide v6

    new-instance v1, Lv60;

    invoke-direct {v1, v6, v7}, Lv60;-><init>(J)V

    const-string v3, "gads:rewarded_ad_close_timeout"

    invoke-virtual {v8, v3, v1, v0}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lv60;

    iget-wide v0, v0, Lv60;->a:J

    goto :goto_89

    :cond_58
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Lv60;->b:Lp80;

    invoke-static {v7, v6}, Li10;->G0(ILy60;)J

    move-result-wide v6

    new-instance v1, Lv60;

    invoke-direct {v1, v6, v7}, Lv60;-><init>(J)V

    const-string v3, "gads:interstitial_ad_close_timeout"

    invoke-virtual {v8, v3, v1, v0}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lv60;

    iget-wide v0, v0, Lv60;->a:J

    goto :goto_89

    :cond_71
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Lv60;->b:Lp80;

    invoke-static {v7, v6}, Li10;->G0(ILy60;)J

    move-result-wide v6

    new-instance v1, Lv60;

    invoke-direct {v1, v6, v7}, Lv60;-><init>(J)V

    const-string v3, "gads:app_open_ad_close_timeout"

    invoke-virtual {v8, v3, v1, v0}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lv60;

    iget-wide v0, v0, Lv60;->a:J

    :goto_89
    cmp-long v3, v0, v4

    if-lez v3, :cond_a3

    new-instance v3, Lads_mobile_sdk/eh2;

    const/4 v4, 0x0

    invoke-direct {v3, v0, v1, p0, v4}, Lads_mobile_sdk/eh2;-><init>(JLads_mobile_sdk/fh2;Lvx;)V

    iget-object p0, p0, Lads_mobile_sdk/fh2;->b:Lvy;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, La42;

    invoke-direct {v0, v3, v4}, La42;-><init>(Lpk0;Lvx;)V

    const/4 v1, 0x2

    sget-object v3, Ly90;->a:Ly90;

    invoke-static {p0, v3, v4, v0, v1}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    :cond_a3
    return-object v2
.end method

.method public final g(Lvx;)Ljava/lang/Object;
    .registers 7

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/bh2;

    if-eqz v0, :cond_13

    move-object v0, p1

    check-cast v0, Lads_mobile_sdk/bh2;

    iget v1, v0, Lads_mobile_sdk/bh2;->e:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lads_mobile_sdk/bh2;->e:I

    goto :goto_1a

    :cond_13
    new-instance v0, Lads_mobile_sdk/bh2;

    check-cast p1, Lwx;

    invoke-direct {v0, p0, p1}, Lads_mobile_sdk/bh2;-><init>(Lads_mobile_sdk/fh2;Lwx;)V

    :goto_1a
    iget-object p1, v0, Lads_mobile_sdk/bh2;->c:Ljava/lang/Object;

    iget v1, v0, Lads_mobile_sdk/bh2;->e:I

    sget-object v2, Lrg2;->a:Lrg2;

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v1, :cond_36

    if-ne v1, v3, :cond_30

    iget-object p0, v0, Lads_mobile_sdk/bh2;->b:Lnb1;

    iget-object v0, v0, Lads_mobile_sdk/bh2;->a:Lads_mobile_sdk/fh2;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    move-object p1, p0

    move-object p0, v0

    goto :goto_58

    :cond_30
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v4

    :cond_36
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-boolean p1, p0, Lads_mobile_sdk/fh2;->h:Z

    if-nez p1, :cond_3e

    goto :goto_83

    :cond_3e
    iget-object p1, p0, Lads_mobile_sdk/fh2;->e:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v1, 0x0

    invoke-virtual {p1, v1, v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result p1

    if-eqz p1, :cond_83

    iput-object p0, v0, Lads_mobile_sdk/bh2;->a:Lads_mobile_sdk/fh2;

    iget-object p1, p0, Lads_mobile_sdk/fh2;->f:Lnb1;

    iput-object p1, v0, Lads_mobile_sdk/bh2;->b:Lnb1;

    iput v3, v0, Lads_mobile_sdk/bh2;->e:I

    invoke-virtual {p1, v0}, Lnb1;->a(Lvx;)Ljava/lang/Object;

    move-result-object v0

    sget-object v1, Lwy;->a:Lwy;

    if-ne v0, v1, :cond_58

    return-object v1

    :cond_58
    :goto_58
    :try_start_58
    iget-object v0, p0, Lads_mobile_sdk/fh2;->g:Lx52;

    if-eqz v0, :cond_62

    invoke-virtual {v0, v4}, Lnv0;->a(Ljava/util/concurrent/CancellationException;)V

    goto :goto_62

    :catchall_60
    move-exception p0

    goto :goto_7f

    :cond_62
    :goto_62
    iput-object v4, p0, Lads_mobile_sdk/fh2;->g:Lx52;
    :try_end_64
    .catchall {:try_start_58 .. :try_end_64} :catchall_60

    invoke-virtual {p1, v4}, Lnb1;->b(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/fh2;->b:Lvy;

    new-instance v0, Lqd;

    const/16 v1, 0xe

    invoke-direct {v0, p0, v4, v1}, Lqd;-><init>(Ljava/lang/Object;Lvx;I)V

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance p0, La42;

    invoke-direct {p0, v0, v4}, La42;-><init>(Lpk0;Lvx;)V

    const/4 v0, 0x2

    sget-object v1, Ly90;->a:Ly90;

    invoke-static {p1, v1, v4, p0, v0}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    return-object v2

    :goto_7f
    invoke-virtual {p1, v4}, Lnb1;->b(Ljava/lang/Object;)V

    throw p0

    :cond_83
    :goto_83
    return-object v2
.end method
