.class public final Lads_mobile_sdk/ab2;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lo23;


# instance fields
.field public final a:Lads_mobile_sdk/dr2;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/dr2;)V
    .registers 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/ab2;->a:Lads_mobile_sdk/dr2;

    return-void
.end method


# virtual methods
.method public final a()Lads_mobile_sdk/lw0;
    .registers 1

    sget-object p0, Lads_mobile_sdk/lw0;->H:Lads_mobile_sdk/lw0;

    return-object p0
.end method

.method public final d(Lvx;)Ljava/lang/Object;
    .registers 3

    new-instance p1, Lads_mobile_sdk/hv0;

    new-instance v0, Lads_mobile_sdk/za2;

    iget-object p0, p0, Lads_mobile_sdk/ab2;->a:Lads_mobile_sdk/dr2;

    invoke-direct {v0, p0}, Lads_mobile_sdk/za2;-><init>(Lads_mobile_sdk/dr2;)V

    invoke-direct {p1, v0}, Lads_mobile_sdk/hv0;-><init>(Ljava/lang/Object;)V

    return-object p1
.end method
