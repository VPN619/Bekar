.class public final Lads_mobile_sdk/fq2;
.super Lads_mobile_sdk/on2;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final m:Lm4;

.field public final n:Ltv2;


# direct methods
.method public constructor <init>(Lm4;Lads_mobile_sdk/av2;Lads_mobile_sdk/qr0;Lads_mobile_sdk/i41;Lads_mobile_sdk/j71;Lads_mobile_sdk/ux2;Lads_mobile_sdk/kh3;Ljava/lang/String;Lads_mobile_sdk/ab0;Lvy;Lvy;Lq22;Z)V
    .registers 27

    invoke-virtual/range {p10 .. p10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p11 .. p11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p7 .. p7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p3 .. p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p6 .. p6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p8 .. p8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p4 .. p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p5 .. p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p9 .. p9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p12 .. p12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-object v0, p0

    move-object v8, p1

    move-object v7, p2

    move-object/from16 v4, p3

    move-object/from16 v10, p4

    move-object/from16 v11, p5

    move-object/from16 v5, p6

    move-object/from16 v3, p7

    move-object/from16 v6, p8

    move-object/from16 v1, p10

    move-object/from16 v2, p11

    move-object/from16 v12, p12

    move/from16 v9, p13

    invoke-direct/range {v0 .. v12}, Lads_mobile_sdk/on2;-><init>(Lvy;Lvy;Lads_mobile_sdk/kh3;Lads_mobile_sdk/qr0;Lads_mobile_sdk/ux2;Ljava/lang/String;Lads_mobile_sdk/av2;Lm4;ZLads_mobile_sdk/i41;Lads_mobile_sdk/j71;Lq22;)V

    iput-object p1, p0, Lads_mobile_sdk/fq2;->m:Lm4;

    move-object/from16 p1, p9

    iput-object p1, p0, Lads_mobile_sdk/fq2;->n:Ltv2;

    return-void
.end method


# virtual methods
.method public final b(Lvx;)Ljava/lang/Object;
    .registers 4

    iget-object v0, p0, Lads_mobile_sdk/fq2;->n:Ltv2;

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v0, Le33;

    iget-object v1, p0, Lads_mobile_sdk/fq2;->m:Lm4;

    invoke-virtual {p0, v0, v1}, Lads_mobile_sdk/on2;->a(Le33;Lm4;)Le33;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/vc0;

    invoke-virtual {p0}, Lads_mobile_sdk/vc0;->a()Lads_mobile_sdk/wc0;

    move-result-object p0

    iget-object p0, p0, Lads_mobile_sdk/wc0;->A0:Ltv2;

    invoke-interface {p0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lads_mobile_sdk/qc1;

    check-cast p1, Lwx;

    invoke-virtual {p0, p1}, Lads_mobile_sdk/qc1;->a(Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
