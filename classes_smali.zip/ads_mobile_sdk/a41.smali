.class public final Lads_mobile_sdk/a41;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lbw2;


# instance fields
.field public final a:Lads_mobile_sdk/ek;


# direct methods
.method public constructor <init>(Lads_mobile_sdk/ek;)V
    .registers 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/a41;->a:Lads_mobile_sdk/ek;

    return-void
.end method


# virtual methods
.method public final a(Lads_mobile_sdk/cy0;Ljava/util/Map;Lvx;)Ljava/lang/Object;
    .registers 5

    .prologue
    const-string p1, "key"

    invoke-interface {p2, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    const-string v0, "value"

    invoke-interface {p2, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Ljava/lang/String;

    if-eqz p1, :cond_27

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    if-nez v0, :cond_19

    goto :goto_27

    :cond_19
    iget-object p0, p0, Lads_mobile_sdk/a41;->a:Lads_mobile_sdk/ek;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p0, p1, p2, p3}, Lads_mobile_sdk/ek;->a(Lads_mobile_sdk/ek;Ljava/lang/String;Ljava/lang/String;Lvx;)Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lwy;->a:Lwy;

    if-ne p0, p1, :cond_27

    return-object p0

    :cond_27
    :goto_27
    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0
.end method

.method public final b()I
    .registers 1

    const/16 p0, 0x35

    return p0
.end method
