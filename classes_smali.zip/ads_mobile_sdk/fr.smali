.class public final Lads_mobile_sdk/fr;
.super Lnx2;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final d:[B


# direct methods
.method public constructor <init>([B)V
    .registers 2

    invoke-direct {p0}, Lads_mobile_sdk/hr;-><init>()V

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object p1, p0, Lads_mobile_sdk/fr;->d:[B

    return-void
.end method


# virtual methods
.method public final a(II)Lads_mobile_sdk/hr;
    .registers 4

    .prologue
    iget-object p0, p0, Lads_mobile_sdk/fr;->d:[B

    array-length v0, p0

    invoke-static {p1, p2, v0}, Lads_mobile_sdk/hr;->a(III)I

    move-result p2

    if-nez p2, :cond_c

    sget-object p0, Lads_mobile_sdk/hr;->b:Lads_mobile_sdk/fr;

    return-object p0

    :cond_c
    new-instance v0, Lads_mobile_sdk/br;

    invoke-direct {v0, p0, p1, p2}, Lads_mobile_sdk/br;-><init>([BII)V

    return-object v0
.end method

.method public final a()Ljava/lang/String;
    .registers 3

    sget-object v0, Ljava/nio/charset/StandardCharsets;->ISO_8859_1:Ljava/nio/charset/Charset;

    new-instance v1, Ljava/lang/String;

    iget-object p0, p0, Lads_mobile_sdk/fr;->d:[B

    invoke-direct {v1, p0, v0}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    return-object v1
.end method

.method public final a(III[B)V
    .registers 5

    iget-object p0, p0, Lads_mobile_sdk/fr;->d:[B

    invoke-static {p0, p1, p4, p2, p3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-void
.end method

.method public final a(Lads_mobile_sdk/ov;)V
    .registers 4

    const/4 v0, 0x0

    iget-object p0, p0, Lads_mobile_sdk/fr;->d:[B

    array-length v1, p0

    invoke-virtual {p1, p0, v0, v1}, Lads_mobile_sdk/ov;->a([BII)V

    return-void
.end method

.method public final a(Lads_mobile_sdk/hr;II)Z
    .registers 8

    .prologue
    invoke-virtual {p1}, Lads_mobile_sdk/hr;->size()I

    move-result v0

    const/4 v1, 0x0

    iget-object v2, p0, Lads_mobile_sdk/fr;->d:[B

    if-gt p3, v0, :cond_54

    add-int v0, p2, p3

    invoke-virtual {p1}, Lads_mobile_sdk/hr;->size()I

    move-result v3

    if-gt v0, v3, :cond_3b

    instance-of v3, p1, Lads_mobile_sdk/fr;

    if-eqz v3, :cond_1e

    check-cast p1, Lads_mobile_sdk/fr;

    iget-object p0, p1, Lads_mobile_sdk/fr;->d:[B

    invoke-static {v2, v1, p0, p2, p3}, Lads_mobile_sdk/hr;->a([BI[BII)Z

    move-result p0

    return p0

    :cond_1e
    instance-of v3, p1, Lads_mobile_sdk/br;

    if-eqz v3, :cond_2e

    check-cast p1, Lads_mobile_sdk/br;

    iget-object p0, p1, Lads_mobile_sdk/br;->d:[B

    iget p1, p1, Lads_mobile_sdk/br;->e:I

    add-int/2addr p1, p2

    invoke-static {v2, v1, p0, p1, p3}, Lads_mobile_sdk/hr;->a([BI[BII)Z

    move-result p0

    return p0

    :cond_2e
    invoke-virtual {p1, p2, v0}, Lads_mobile_sdk/hr;->b(II)Lads_mobile_sdk/hr;

    move-result-object p1

    invoke-virtual {p0, v1, p3}, Lads_mobile_sdk/fr;->b(II)Lads_mobile_sdk/hr;

    move-result-object p0

    invoke-virtual {p1, p0}, Lads_mobile_sdk/hr;->equals(Ljava/lang/Object;)Z

    move-result p0

    return p0

    :cond_3b
    new-instance p0, Ljava/lang/IllegalArgumentException;

    invoke-virtual {p1}, Lads_mobile_sdk/hr;->size()I

    move-result p1

    const-string v0, "Ran off end of other: "

    const-string v1, ", "

    invoke-static {p2, p3, v0, v1, v1}, Lrt2;->l(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_54
    array-length p0, v2

    invoke-static {p3, p0}, Ldm2;->k(II)V

    return v1
.end method

.method public final b(I)B
    .registers 2

    iget-object p0, p0, Lads_mobile_sdk/fr;->d:[B

    aget-byte p0, p0, p1

    return p0
.end method

.method public final b(III)I
    .registers 6

    .prologue
    sget-object v0, Lads_mobile_sdk/yb1;->a:[B

    move v0, p2

    :goto_3
    add-int v1, p2, p3

    if-ge v0, v1, :cond_11

    mul-int/lit8 p1, p1, 0x1f

    iget-object v1, p0, Lads_mobile_sdk/fr;->d:[B

    aget-byte v1, v1, v0

    add-int/2addr p1, v1

    add-int/lit8 v0, v0, 0x1

    goto :goto_3

    :cond_11
    return p1
.end method

.method public final b(II)Lads_mobile_sdk/hr;
    .registers 4

    .prologue
    iget-object p0, p0, Lads_mobile_sdk/fr;->d:[B

    array-length v0, p0

    invoke-static {p1, p2, v0}, Lads_mobile_sdk/hr;->a(III)I

    move-result p2

    if-nez p2, :cond_c

    sget-object p0, Lads_mobile_sdk/hr;->b:Lads_mobile_sdk/fr;

    return-object p0

    :cond_c
    new-instance v0, Lads_mobile_sdk/br;

    invoke-direct {v0, p0, p1, p2}, Lads_mobile_sdk/br;-><init>([BII)V

    return-object v0
.end method

.method public final b(Lads_mobile_sdk/hr;)Z
    .registers 4

    .prologue
    instance-of v0, p1, Lads_mobile_sdk/fr;

    iget-object v1, p0, Lads_mobile_sdk/fr;->d:[B

    if-eqz v0, :cond_f

    check-cast p1, Lads_mobile_sdk/fr;

    iget-object p0, p1, Lads_mobile_sdk/fr;->d:[B

    invoke-static {v1, p0}, Ljava/util/Arrays;->equals([B[B)Z

    move-result p0

    return p0

    :cond_f
    instance-of v0, p1, Lads_mobile_sdk/br;

    if-eqz v0, :cond_1a

    const/4 v0, 0x0

    array-length v1, v1

    invoke-virtual {p0, p1, v0, v1}, Lads_mobile_sdk/fr;->a(Lads_mobile_sdk/hr;II)Z

    move-result p0

    return p0

    :cond_1a
    invoke-virtual {p1, p0}, Lads_mobile_sdk/hr;->b(Lads_mobile_sdk/hr;)Z

    move-result p0

    return p0
.end method

.method public final size()I
    .registers 1

    iget-object p0, p0, Lads_mobile_sdk/fr;->d:[B

    array-length p0, p0

    return p0
.end method
