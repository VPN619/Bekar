.class public final Lads_mobile_sdk/bn3;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public final synthetic a:Ljava/util/Map;

.field public final synthetic b:Lads_mobile_sdk/bz0;

.field public final synthetic t:I


# direct methods
.method public synthetic constructor <init>(Ljava/util/Map;Lads_mobile_sdk/bz0;Lvx;I)V
    .registers 5

    iput p4, p0, Lads_mobile_sdk/bn3;->t:I

    iput-object p1, p0, Lads_mobile_sdk/bn3;->a:Ljava/util/Map;

    iput-object p2, p0, Lads_mobile_sdk/bn3;->b:Lads_mobile_sdk/bz0;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 5

    .prologue
    iget p2, p0, Lads_mobile_sdk/bn3;->t:I

    iget-object v0, p0, Lads_mobile_sdk/bn3;->b:Lads_mobile_sdk/bz0;

    iget-object p0, p0, Lads_mobile_sdk/bn3;->a:Ljava/util/Map;

    packed-switch p2, :pswitch_data_18

    new-instance p2, Lads_mobile_sdk/bn3;

    const/4 v1, 0x1

    invoke-direct {p2, p0, v0, p1, v1}, Lads_mobile_sdk/bn3;-><init>(Ljava/util/Map;Lads_mobile_sdk/bz0;Lvx;I)V

    return-object p2

    :pswitch_10  #0x0
    new-instance p2, Lads_mobile_sdk/bn3;

    const/4 v1, 0x0

    invoke-direct {p2, p0, v0, p1, v1}, Lads_mobile_sdk/bn3;-><init>(Ljava/util/Map;Lads_mobile_sdk/bz0;Lvx;I)V

    return-object p2

    nop

    :pswitch_data_18
    .packed-switch 0x0
        :pswitch_10  #00000000
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .prologue
    iget v0, p0, Lads_mobile_sdk/bn3;->t:I

    sget-object v1, Lrg2;->a:Lrg2;

    iget-object v2, p0, Lads_mobile_sdk/bn3;->b:Lads_mobile_sdk/bz0;

    iget-object p0, p0, Lads_mobile_sdk/bn3;->a:Ljava/util/Map;

    packed-switch v0, :pswitch_data_28

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/bn3;

    const/4 v0, 0x1

    invoke-direct {p1, p0, v2, p2, v0}, Lads_mobile_sdk/bn3;-><init>(Ljava/util/Map;Lads_mobile_sdk/bz0;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/bn3;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_1a  #0x0
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance p1, Lads_mobile_sdk/bn3;

    const/4 v0, 0x0

    invoke-direct {p1, p0, v2, p2, v0}, Lads_mobile_sdk/bn3;-><init>(Ljava/util/Map;Lads_mobile_sdk/bz0;Lvx;I)V

    invoke-virtual {p1, v1}, Lads_mobile_sdk/bn3;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object v1

    :pswitch_data_28
    .packed-switch 0x0
        :pswitch_1a  #00000000
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7

    .prologue
    iget v0, p0, Lads_mobile_sdk/bn3;->t:I

    const/4 v1, 0x6

    const/4 v2, 0x0

    packed-switch v0, :pswitch_data_7a

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/bn3;->a:Ljava/util/Map;

    const-string v0, "currentTime"

    invoke-interface {p1, v0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    if-nez p1, :cond_2c

    iget-object p0, p0, Lads_mobile_sdk/bn3;->a:Ljava/util/Map;

    new-instance p1, Ljava/lang/StringBuilder;

    const-string v0, "CurrentTime parameter missing from timeupdate video GMSG: "

    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v1, p0, v2}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    sget-object p0, Lrg2;->a:Lrg2;

    goto :goto_43

    :cond_2c
    :try_start_2c
    iget-object p0, p0, Lads_mobile_sdk/bn3;->b:Lads_mobile_sdk/bz0;

    invoke-static {p1}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    iget-object p0, p0, Lads_mobile_sdk/bz0;->f:Ljava/lang/Object;

    monitor-enter p0

    monitor-exit p0
    :try_end_35
    .catch Ljava/lang/NumberFormatException; {:try_start_2c .. :try_end_35} :catch_36

    goto :goto_41

    :catch_36
    move-exception p0

    const-string v0, "Could not parse currentTime from timeupdate video GMSG: "

    invoke-virtual {v0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v0, 0x4

    invoke-static {v0, p1, p0}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    :goto_41
    sget-object p0, Lrg2;->a:Lrg2;

    :goto_43
    return-object p0

    :pswitch_44  #0x0
    sget-object v0, Lrg2;->a:Lrg2;

    iget-object v3, p0, Lads_mobile_sdk/bn3;->b:Lads_mobile_sdk/bz0;

    iget-object v3, v3, Lads_mobile_sdk/bz0;->e:Lbt;

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p0, p0, Lads_mobile_sdk/bn3;->a:Ljava/util/Map;

    const-string p1, "src"

    invoke-interface {p0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/String;

    if-eqz p1, :cond_64

    invoke-static {p1}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_60

    goto :goto_64

    :cond_60
    invoke-virtual {v3, p1}, Lnv0;->N(Ljava/lang/Object;)Z

    goto :goto_78

    :cond_64
    :goto_64
    new-instance p1, Ljava/lang/StringBuilder;

    const-string v4, "Src parameter missing from video GMSG: "

    invoke-direct {p1, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v1, p0, v2}, Lads_mobile_sdk/xh3;->a(ILjava/lang/String;Ljava/lang/Exception;)V

    invoke-virtual {v3, v2}, Lnv0;->N(Ljava/lang/Object;)Z

    :goto_78
    return-object v0

    nop

    :pswitch_data_7a
    .packed-switch 0x0
        :pswitch_44  #00000000
    .end packed-switch
.end method
