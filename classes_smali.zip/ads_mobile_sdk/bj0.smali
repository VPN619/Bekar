.class public final Lads_mobile_sdk/bj0;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Le63;


# instance fields
.field public final a:Lv03;

.field public final b:Lads_mobile_sdk/th3;

.field public final c:Lx43;

.field public final d:J


# direct methods
.method public constructor <init>(Lv03;Lads_mobile_sdk/th3;Lx43;J)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lads_mobile_sdk/bj0;->a:Lv03;

    iput-object p2, p0, Lads_mobile_sdk/bj0;->b:Lads_mobile_sdk/th3;

    iput-object p3, p0, Lads_mobile_sdk/bj0;->c:Lx43;

    iput-wide p4, p0, Lads_mobile_sdk/bj0;->d:J

    return-void
.end method


# virtual methods
.method public final a(Lads_mobile_sdk/jl2;)Z
    .registers 8

    .prologue
    const/4 v0, 0x1

    iget-object v1, p0, Lads_mobile_sdk/bj0;->b:Lads_mobile_sdk/th3;

    if-eqz p1, :cond_47

    invoke-static {}, Lads_mobile_sdk/jl2;->q()Lads_mobile_sdk/jl2;

    move-result-object v2

    invoke-virtual {p1, v2}, Lads_mobile_sdk/ku0;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_10

    goto :goto_47

    :cond_10
    invoke-virtual {p1}, Lads_mobile_sdk/jl2;->p()Lads_mobile_sdk/mk;

    move-result-object v2

    iget-object v3, p0, Lads_mobile_sdk/bj0;->a:Lv03;

    invoke-interface {v3}, Lv03;->get()Ljava/lang/Object;

    move-result-object v3

    if-eq v2, v3, :cond_22

    sget-object p0, Lads_mobile_sdk/fl0;->k2:Lads_mobile_sdk/fl0;

    invoke-virtual {v1, p0}, Lads_mobile_sdk/th3;->b(Lads_mobile_sdk/fl0;)V

    return v0

    :cond_22
    invoke-virtual {p1}, Lads_mobile_sdk/jl2;->r()Lads_mobile_sdk/kl2;

    move-result-object p1

    invoke-virtual {p1}, Lads_mobile_sdk/kl2;->q()J

    move-result-wide v2

    const-wide/16 v4, 0x3e8

    mul-long/2addr v2, v4

    iget-object p1, p0, Lads_mobile_sdk/bj0;->c:Lx43;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    sub-long/2addr v2, v4

    iget-wide p0, p0, Lads_mobile_sdk/bj0;->d:J

    cmp-long p0, v2, p0

    if-gtz p0, :cond_3e

    goto :goto_3f

    :cond_3e
    const/4 v0, 0x0

    :goto_3f
    if-eqz v0, :cond_46

    sget-object p0, Lads_mobile_sdk/fl0;->l2:Lads_mobile_sdk/fl0;

    invoke-virtual {v1, p0}, Lads_mobile_sdk/th3;->b(Lads_mobile_sdk/fl0;)V

    :cond_46
    return v0

    :cond_47
    :goto_47
    sget-object p0, Lads_mobile_sdk/fl0;->j2:Lads_mobile_sdk/fl0;

    invoke-virtual {v1, p0}, Lads_mobile_sdk/th3;->b(Lads_mobile_sdk/fl0;)V

    return v0
.end method

.method public final b(Lads_mobile_sdk/jl2;)Z
    .registers 5

    .prologue
    const/4 v0, 0x0

    iget-object v1, p0, Lads_mobile_sdk/bj0;->b:Lads_mobile_sdk/th3;

    if-eqz p1, :cond_24

    invoke-static {}, Lads_mobile_sdk/jl2;->q()Lads_mobile_sdk/jl2;

    move-result-object v2

    invoke-virtual {p1, v2}, Lads_mobile_sdk/ku0;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_10

    goto :goto_24

    :cond_10
    invoke-virtual {p1}, Lads_mobile_sdk/jl2;->p()Lads_mobile_sdk/mk;

    move-result-object p1

    iget-object p0, p0, Lads_mobile_sdk/bj0;->a:Lv03;

    invoke-interface {p0}, Lv03;->get()Ljava/lang/Object;

    move-result-object p0

    if-eq p1, p0, :cond_22

    sget-object p0, Lads_mobile_sdk/fl0;->i2:Lads_mobile_sdk/fl0;

    invoke-virtual {v1, p0}, Lads_mobile_sdk/th3;->b(Lads_mobile_sdk/fl0;)V

    return v0

    :cond_22
    const/4 p0, 0x1

    return p0

    :cond_24
    :goto_24
    sget-object p0, Lads_mobile_sdk/fl0;->h2:Lads_mobile_sdk/fl0;

    invoke-virtual {v1, p0}, Lads_mobile_sdk/th3;->b(Lads_mobile_sdk/fl0;)V

    return v0
.end method
