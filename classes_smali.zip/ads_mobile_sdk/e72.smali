.class public final Lads_mobile_sdk/e72;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lbk0;


# instance fields
.field public final synthetic a:Lads_mobile_sdk/f72;

.field public final synthetic b:Landroid/webkit/WebView;

.field public final synthetic c:Z


# direct methods
.method public constructor <init>(Lads_mobile_sdk/f72;Landroid/webkit/WebView;ZLvx;)V
    .registers 5

    iput-object p1, p0, Lads_mobile_sdk/e72;->a:Lads_mobile_sdk/f72;

    iput-object p2, p0, Lads_mobile_sdk/e72;->b:Landroid/webkit/WebView;

    iput-boolean p3, p0, Lads_mobile_sdk/e72;->c:Z

    const/4 p1, 0x1

    invoke-direct {p0, p1, p4}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    check-cast p1, Lvx;

    new-instance v0, Lads_mobile_sdk/e72;

    iget-object v1, p0, Lads_mobile_sdk/e72;->b:Landroid/webkit/WebView;

    iget-boolean v2, p0, Lads_mobile_sdk/e72;->c:Z

    iget-object p0, p0, Lads_mobile_sdk/e72;->a:Lads_mobile_sdk/f72;

    invoke-direct {v0, p0, v1, v2, p1}, Lads_mobile_sdk/e72;-><init>(Lads_mobile_sdk/f72;Landroid/webkit/WebView;ZLvx;)V

    sget-object p0, Lrg2;->a:Lrg2;

    invoke-virtual {v0, p0}, Lads_mobile_sdk/e72;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .prologue
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, Lads_mobile_sdk/e72;->a:Lads_mobile_sdk/f72;

    iget-object p1, p1, Lads_mobile_sdk/f72;->c:Lads_mobile_sdk/s52;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p0, Lads_mobile_sdk/e72;->b:Landroid/webkit/WebView;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v1, p1, Lads_mobile_sdk/s52;->f:Lads_mobile_sdk/ah3;

    new-instance v2, Lads_mobile_sdk/e52;

    iget-boolean p0, p0, Lads_mobile_sdk/e72;->c:Z

    invoke-direct {v2, p1, v0, p0}, Lads_mobile_sdk/e52;-><init>(Lads_mobile_sdk/s52;Landroid/webkit/WebView;Z)V

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_1b
    invoke-virtual {v2}, Lads_mobile_sdk/e52;->invoke()Ljava/lang/Object;

    move-result-object p0
    :try_end_1f
    .catch Ljava/lang/Exception; {:try_start_1b .. :try_end_1f} :catch_20

    goto :goto_27

    :catch_20
    move-exception p0

    const-string p1, "CreateJavaScriptSessionService"

    invoke-virtual {v1, p1, p0}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 p0, 0x0

    :goto_27
    check-cast p0, Lads_mobile_sdk/gj1;

    return-object p0
.end method
