.class public final La90;
.super Lns2;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final synthetic k:Lb90;


# direct methods
.method public constructor <init>(Lb90;)V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La90;->k:Lb90;

    return-void
.end method


# virtual methods
.method public final v(Ljava/lang/Throwable;)V
    .registers 2

    iget-object p0, p0, La90;->k:Lb90;

    iget-object p0, p0, Lb90;->a:Lf90;

    invoke-virtual {p0, p1}, Lf90;->d(Ljava/lang/Throwable;)V

    return-void
.end method

.method public final w(Lx5;)V
    .registers 7

    .prologue
    iget-object p0, p0, La90;->k:Lb90;

    iput-object p1, p0, Lb90;->c:Lx5;

    new-instance p1, Ltd;

    iget-object v0, p0, Lb90;->c:Lx5;

    iget-object v1, p0, Lb90;->a:Lf90;

    iget-object v2, v1, Lf90;->g:Lvp1;

    iget-object v1, v1, Lf90;->i:Lu10;

    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v4, 0x22

    if-lt v3, v4, :cond_19

    invoke-static {}, Lk90;->a()Ljava/util/Set;

    move-result-object v3

    goto :goto_1d

    :cond_19
    invoke-static {}, Lpy2;->u()Ljava/util/Set;

    move-result-object v3

    :goto_1d
    invoke-direct {p1, v0, v2, v1, v3}, Ltd;-><init>(Lx5;Lvp1;Lu10;Ljava/util/Set;)V

    iput-object p1, p0, Lb90;->b:Ltd;

    iget-object p0, p0, Lb90;->a:Lf90;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iget-object v0, p0, Lf90;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->lock()V

    const/4 v0, 0x1

    :try_start_33
    iput v0, p0, Lf90;->c:I

    iget-object v0, p0, Lf90;->b:Lxe;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    iget-object v0, p0, Lf90;->b:Lxe;

    invoke-virtual {v0}, Lxe;->clear()V
    :try_end_3f
    .catchall {:try_start_33 .. :try_end_3f} :catchall_56

    iget-object v0, p0, Lf90;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    invoke-virtual {v0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    iget-object v0, p0, Lf90;->d:Landroid/os/Handler;

    new-instance v1, Lan;

    iget p0, p0, Lf90;->c:I

    const/4 v2, 0x0

    invoke-direct {v1, p1, p0, v2}, Lan;-><init>(Ljava/util/List;ILjava/lang/Throwable;)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void

    :catchall_56
    move-exception p1

    iget-object p0, p0, Lf90;->a:Ljava/util/concurrent/locks/ReentrantReadWriteLock;

    invoke-virtual {p0}, Ljava/util/concurrent/locks/ReentrantReadWriteLock;->writeLock()Ljava/util/concurrent/locks/Lock;

    move-result-object p0

    invoke-interface {p0}, Ljava/util/concurrent/locks/Lock;->unlock()V

    throw p1
.end method
