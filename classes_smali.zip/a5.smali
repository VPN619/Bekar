.class public final enum La5;
.super Ljava/lang/Enum;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final enum a:La5;

.field public static final enum b:La5;

.field public static final enum c:La5;

.field public static final enum d:La5;

.field public static final enum e:La5;

.field public static final synthetic f:[La5;


# direct methods
.method static constructor <clinit>()V
    .registers 7

    new-instance v0, La5;

    const-string v1, "NOT_STARTED"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v0, La5;->a:La5;

    new-instance v1, La5;

    const-string v2, "INITIALIZING"

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v1, La5;->b:La5;

    new-instance v2, La5;

    const-string v3, "COMPLETE"

    const/4 v4, 0x2

    invoke-direct {v2, v3, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v2, La5;->c:La5;

    new-instance v3, La5;

    const-string v4, "TIMED_OUT"

    const/4 v5, 0x3

    invoke-direct {v3, v4, v5}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v3, La5;->d:La5;

    new-instance v4, La5;

    const-string v5, "FAILED"

    const/4 v6, 0x4

    invoke-direct {v4, v5, v6}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v4, La5;->e:La5;

    filled-new-array {v0, v1, v2, v3, v4}, [La5;

    move-result-object v0

    sput-object v0, La5;->f:[La5;

    return-void
.end method

.method public static values()[La5;
    .registers 1

    sget-object v0, La5;->f:[La5;

    invoke-virtual {v0}, [Ljava/lang/Object;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [La5;

    return-object v0
.end method
