.class public final La71;
.super Lcr1;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final synthetic a:Lcom/google/android/material/datepicker/e;

.field public final synthetic b:Lb71;


# direct methods
.method public constructor <init>(Lb71;Lcom/google/android/material/datepicker/e;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La71;->b:Lb71;

    iput-object p2, p0, La71;->a:Lcom/google/android/material/datepicker/e;

    return-void
.end method


# virtual methods
.method public final a(Landroidx/recyclerview/widget/RecyclerView;I)V
    .registers 5

    .prologue
    if-nez p2, :cond_60

    iget-object p1, p0, La71;->b:Lb71;

    iget-object p2, p1, Lb71;->o:Lbj1;

    if-nez p2, :cond_9

    goto :goto_60

    :cond_9
    iget-object v0, p1, Lb71;->h:Landroidx/recyclerview/widget/RecyclerView;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Lzq1;

    move-result-object v0

    check-cast v0, Landroidx/recyclerview/widget/LinearLayoutManager;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->e()Z

    move-result v1

    if-eqz v1, :cond_20

    invoke-virtual {p2, v0}, Lbj1;->e(Lzq1;)Lc90;

    move-result-object p2

    invoke-static {v0, p2}, Lbj1;->c(Lzq1;Lc90;)Landroid/view/View;

    move-result-object p2

    goto :goto_30

    :cond_20
    invoke-virtual {v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->d()Z

    move-result v1

    if-eqz v1, :cond_2f

    invoke-virtual {p2, v0}, Lbj1;->d(Lzq1;)Lc90;

    move-result-object p2

    invoke-static {v0, p2}, Lbj1;->c(Lzq1;Lc90;)Landroid/view/View;

    move-result-object p2

    goto :goto_30

    :cond_2f
    const/4 p2, 0x0

    :goto_30
    if-eqz p2, :cond_5d

    invoke-static {p2}, Landroidx/recyclerview/widget/RecyclerView;->L(Landroid/view/View;)Lpr1;

    move-result-object p2

    const/4 v0, -0x1

    if-eqz p2, :cond_3d

    iget-object v1, p2, Lpr1;->r:Landroidx/recyclerview/widget/RecyclerView;

    if-nez v1, :cond_3f

    :cond_3d
    move p2, v0

    goto :goto_43

    :cond_3f
    invoke-virtual {v1, p2}, Landroidx/recyclerview/widget/RecyclerView;->I(Lpr1;)I

    move-result p2

    :goto_43
    if-eq p2, v0, :cond_5d

    iget-object p0, p0, La71;->a:Lcom/google/android/material/datepicker/e;

    invoke-virtual {p0, p2}, Lcom/google/android/material/datepicker/e;->i(I)Lma1;

    move-result-object v0

    iput-object v0, p1, Lb71;->d:Lma1;

    iget-object v0, p1, Lb71;->m:Lcom/google/android/material/button/MaterialButton;

    invoke-virtual {p0, p2}, Lcom/google/android/material/datepicker/e;->i(I)Lma1;

    move-result-object p0

    invoke-virtual {p0}, Lma1;->c()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {p1, p2}, Lb71;->h(I)V

    :cond_5d
    invoke-virtual {p1}, Lb71;->g()V

    :cond_60
    :goto_60
    return-void
.end method

.method public final b(Landroidx/recyclerview/widget/RecyclerView;II)V
    .registers 5

    .prologue
    iget-object p1, p0, La71;->b:Lb71;

    iget-object p3, p1, Lb71;->h:Landroidx/recyclerview/widget/RecyclerView;

    if-gez p2, :cond_1e

    invoke-virtual {p3}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Lzq1;

    move-result-object p2

    check-cast p2, Landroidx/recyclerview/widget/LinearLayoutManager;

    const/4 p3, 0x0

    invoke-virtual {p2}, Lzq1;->v()I

    move-result v0

    invoke-virtual {p2, p3, v0, p3}, Landroidx/recyclerview/widget/LinearLayoutManager;->P0(IIZ)Landroid/view/View;

    move-result-object p2

    if-nez p2, :cond_19

    const/4 p2, -0x1

    goto :goto_28

    :cond_19
    invoke-static {p2}, Lzq1;->G(Landroid/view/View;)I

    move-result p2

    goto :goto_28

    :cond_1e
    invoke-virtual {p3}, Landroidx/recyclerview/widget/RecyclerView;->getLayoutManager()Lzq1;

    move-result-object p2

    check-cast p2, Landroidx/recyclerview/widget/LinearLayoutManager;

    invoke-virtual {p2}, Landroidx/recyclerview/widget/LinearLayoutManager;->N0()I

    move-result p2

    :goto_28
    iget-object p3, p1, Lb71;->o:Lbj1;

    iget-object p0, p0, La71;->a:Lcom/google/android/material/datepicker/e;

    if-nez p3, :cond_34

    invoke-virtual {p0, p2}, Lcom/google/android/material/datepicker/e;->i(I)Lma1;

    move-result-object p3

    iput-object p3, p1, Lb71;->d:Lma1;

    :cond_34
    iget-object p3, p1, Lb71;->m:Lcom/google/android/material/button/MaterialButton;

    invoke-virtual {p0, p2}, Lcom/google/android/material/datepicker/e;->i(I)Lma1;

    move-result-object p0

    invoke-virtual {p0}, Lma1;->c()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p3, p0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    invoke-virtual {p1, p2}, Lb71;->h(I)V

    return-void
.end method
