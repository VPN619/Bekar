.class public abstract La11;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public a:Lam0;


# virtual methods
.method public abstract a(Lg11;)V
.end method

.method public abstract b(Lg11;)V
.end method
