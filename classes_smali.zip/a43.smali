.class public final synthetic La43;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lads_mobile_sdk/s11;

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:Lwm;

.field public final synthetic d:Z

.field public final synthetic e:Ljava/lang/String;

.field public final synthetic f:[B


# direct methods
.method public synthetic constructor <init>(Lads_mobile_sdk/s11;Ljava/lang/String;Lwm;ZLjava/lang/String;[B)V
    .registers 7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La43;->a:Lads_mobile_sdk/s11;

    iput-object p2, p0, La43;->b:Ljava/lang/String;

    iput-object p3, p0, La43;->c:Lwm;

    iput-boolean p4, p0, La43;->d:Z

    iput-object p5, p0, La43;->e:Ljava/lang/String;

    iput-object p6, p0, La43;->f:[B

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 11

    .prologue
    iget-object v0, p0, La43;->b:Ljava/lang/String;

    iget-object v1, p0, La43;->c:Lwm;

    iget-object v2, p0, La43;->f:[B

    iget-object v3, p0, La43;->a:Lads_mobile_sdk/s11;

    iget-wide v4, v3, Lads_mobile_sdk/s11;->c:J

    const-string v6, "Timeout: "

    const/4 v7, 0x0

    :try_start_d
    invoke-static {v0}, Ljava/net/URI;->create(Ljava/lang/String;)Ljava/net/URI;

    move-result-object v0

    invoke-virtual {v0}, Ljava/net/URI;->toURL()Ljava/net/URL;

    move-result-object v0

    invoke-virtual {v0}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v0

    check-cast v0, Ljava/net/HttpURLConnection;
    :try_end_1b
    .catch Ljava/net/SocketTimeoutException; {:try_start_d .. :try_end_1b} :catch_89
    .catchall {:try_start_d .. :try_end_1b} :catchall_87

    :try_start_1b
    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v7, Lx82;

    const/16 v8, 0x10

    invoke-direct {v7, v8, v0}, Lx82;-><init>(ILjava/lang/Object;)V

    iget-object v8, v3, Lads_mobile_sdk/s11;->a:Ljava/util/concurrent/ExecutorService;

    iget-object v9, v1, Lwm;->c:Lzt1;

    if-eqz v9, :cond_2e

    invoke-virtual {v9, v7, v8}, Lf1;->a(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    :cond_2e
    const-string v7, "User-Agent"

    iget-object v3, v3, Lads_mobile_sdk/s11;->b:Ljava/lang/String;

    invoke-virtual {v0, v7, v3}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    long-to-int v3, v4

    invoke-virtual {v0, v3}, Ljava/net/URLConnection;->setConnectTimeout(I)V

    invoke-virtual {v0, v3}, Ljava/net/URLConnection;->setReadTimeout(I)V
    :try_end_3c
    .catch Ljava/net/SocketTimeoutException; {:try_start_1b .. :try_end_3c} :catch_56
    .catchall {:try_start_1b .. :try_end_3c} :catchall_53

    iget-boolean v3, p0, La43;->d:Z

    if-eqz v3, :cond_73

    const/4 v3, 0x1

    :try_start_41
    invoke-virtual {v0, v3}, Ljava/net/URLConnection;->setDoOutput(Z)V

    const-string v3, "POST"

    invoke-virtual {v0, v3}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V
    :try_end_49
    .catch Ljava/net/SocketTimeoutException; {:try_start_41 .. :try_end_49} :catch_56
    .catchall {:try_start_41 .. :try_end_49} :catchall_53

    iget-object p0, p0, La43;->e:Ljava/lang/String;

    if-eqz p0, :cond_59

    :try_start_4d
    const-string v3, "Content-Type"

    invoke-virtual {v0, v3, p0}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_59

    :catchall_53
    move-exception p0

    move-object v7, v0

    goto :goto_8b

    :catch_56
    move-exception p0

    move-object v7, v0

    goto :goto_93

    :cond_59
    :goto_59
    new-instance p0, Ljava/io/BufferedOutputStream;

    invoke-virtual {v0}, Ljava/net/URLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v3

    invoke-direct {p0, v3}, Ljava/io/BufferedOutputStream;-><init>(Ljava/io/OutputStream;)V
    :try_end_62
    .catch Ljava/net/SocketTimeoutException; {:try_start_4d .. :try_end_62} :catch_56
    .catchall {:try_start_4d .. :try_end_62} :catchall_53

    :try_start_62
    invoke-virtual {p0, v2}, Ljava/io/OutputStream;->write([B)V
    :try_end_65
    .catchall {:try_start_62 .. :try_end_65} :catchall_69

    :try_start_65
    invoke-virtual {p0}, Ljava/io/OutputStream;->close()V
    :try_end_68
    .catch Ljava/net/SocketTimeoutException; {:try_start_65 .. :try_end_68} :catch_56
    .catchall {:try_start_65 .. :try_end_68} :catchall_53

    goto :goto_73

    :catchall_69
    move-exception v2

    :try_start_6a
    invoke-virtual {p0}, Ljava/io/OutputStream;->close()V
    :try_end_6d
    .catchall {:try_start_6a .. :try_end_6d} :catchall_6e

    goto :goto_72

    :catchall_6e
    move-exception p0

    :try_start_6f
    invoke-virtual {v2, p0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_72
    throw v2

    :cond_73
    :goto_73
    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result p0

    invoke-static {v0, p0}, Lads_mobile_sdk/s11;->a(Ljava/net/HttpURLConnection;I)[B

    move-result-object v2

    new-instance v3, Lads_mobile_sdk/r11;

    invoke-direct {v3, p0, v2}, Lads_mobile_sdk/r11;-><init>(I[B)V

    invoke-virtual {v1, v3}, Lwm;->a(Ljava/lang/Object;)V
    :try_end_83
    .catch Ljava/net/SocketTimeoutException; {:try_start_6f .. :try_end_83} :catch_56
    .catchall {:try_start_6f .. :try_end_83} :catchall_53

    invoke-virtual {v0}, Ljava/net/HttpURLConnection;->disconnect()V

    return-void

    :catchall_87
    move-exception p0

    goto :goto_8b

    :catch_89
    move-exception p0

    goto :goto_93

    :goto_8b
    :try_start_8b
    invoke-virtual {v1, p0}, Lwm;->b(Ljava/lang/Throwable;)V

    if-eqz v7, :cond_b0

    goto :goto_ad

    :catchall_91
    move-exception p0

    goto :goto_b1

    :goto_93
    new-instance v0, Ljava/util/concurrent/TimeoutException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/util/concurrent/TimeoutException;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Lwm;->b(Ljava/lang/Throwable;)V
    :try_end_ab
    .catchall {:try_start_8b .. :try_end_ab} :catchall_91

    if-eqz v7, :cond_b0

    :goto_ad
    invoke-virtual {v7}, Ljava/net/HttpURLConnection;->disconnect()V

    :cond_b0
    return-void

    :goto_b1
    if-eqz v7, :cond_b6

    invoke-virtual {v7}, Ljava/net/HttpURLConnection;->disconnect()V

    :cond_b6
    throw p0
.end method
