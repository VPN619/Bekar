.class public final La80;
.super Li32;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final o:Le80;

.field public final p:Loj0;


# direct methods
.method public constructor <init>(Le80;Loj0;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La80;->o:Le80;

    iput-object p2, p0, La80;->p:Loj0;

    return-void
.end method

.method public static V0(Le80;Loj0;)La80;
    .registers 5

    .prologue
    iget-object v0, p1, Loj0;->a:Ljava/lang/Object;

    check-cast v0, Lzl;

    iget-object v1, v0, Lzl;->a:[B

    array-length v1, v1

    const/16 v2, 0x20

    if-ne v1, v2, :cond_34

    iget-object v1, p0, Le80;->p:Lzl;

    invoke-virtual {v1}, Lzl;->b()[B

    move-result-object v1

    invoke-virtual {v0}, Lzl;->b()[B

    move-result-object v0

    invoke-static {v0}, Lgt0;->k0([B)[B

    move-result-object v0

    invoke-static {v0}, Lgt0;->y0([B)Ltd;

    move-result-object v0

    invoke-virtual {v0}, Ltd;->H()[B

    move-result-object v0

    invoke-static {v1, v0}, Ljava/util/Arrays;->equals([B[B)Z

    move-result v0

    if-eqz v0, :cond_2d

    new-instance v0, La80;

    invoke-direct {v0, p0, p1}, La80;-><init>(Le80;Loj0;)V

    return-object v0

    :cond_2d
    const-string p0, "Ed25519 keys mismatch"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0

    :cond_34
    new-instance p0, Ljava/security/GeneralSecurityException;

    iget-object p1, v0, Lzl;->a:[B

    array-length p1, p1

    const-string v0, "Ed25519 key must be constructed with key of length 32 bytes, not "

    invoke-static {p1, v0}, Lrt2;->f(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p0
.end method


# virtual methods
.method public final U0()Lj32;
    .registers 1

    iget-object p0, p0, La80;->o:Le80;

    return-object p0
.end method

.method public final h0()Lfj1;
    .registers 1

    iget-object p0, p0, La80;->o:Le80;

    iget-object p0, p0, Le80;->o:Ly70;

    return-object p0
.end method
