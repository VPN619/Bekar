.class public Lac;
.super Landroid/widget/ImageButton;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Lta;

.field public final b:Lbc;

.field public c:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V
    .registers 4

    invoke-static {p1}, Ldb2;->a(Landroid/content/Context;)V

    invoke-direct {p0, p1, p2, p3}, Landroid/widget/ImageButton;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    const/4 p1, 0x0

    iput-boolean p1, p0, Lac;->c:Z

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-static {p1, p0}, Lma2;->a(Landroid/content/Context;Landroid/view/View;)V

    new-instance p1, Lta;

    invoke-direct {p1, p0}, Lta;-><init>(Landroid/view/View;)V

    iput-object p1, p0, Lac;->a:Lta;

    invoke-virtual {p1, p2, p3}, Lta;->d(Landroid/util/AttributeSet;I)V

    new-instance p1, Lbc;

    invoke-direct {p1, p0}, Lbc;-><init>(Landroid/widget/ImageView;)V

    iput-object p1, p0, Lac;->b:Lbc;

    invoke-virtual {p1, p2, p3}, Lbc;->b(Landroid/util/AttributeSet;I)V

    return-void
.end method


# virtual methods
.method public final drawableStateChanged()V
    .registers 2

    .prologue
    invoke-super {p0}, Landroid/view/View;->drawableStateChanged()V

    iget-object v0, p0, Lac;->a:Lta;

    if-eqz v0, :cond_a

    invoke-virtual {v0}, Lta;->a()V

    :cond_a
    iget-object p0, p0, Lac;->b:Lbc;

    if-eqz p0, :cond_11

    invoke-virtual {p0}, Lbc;->a()V

    :cond_11
    return-void
.end method

.method public getSupportBackgroundTintList()Landroid/content/res/ColorStateList;
    .registers 1
    .annotation build Landroidx/annotation/Nullable;
    .end annotation

    .prologue
    iget-object p0, p0, Lac;->a:Lta;

    if-eqz p0, :cond_9

    invoke-virtual {p0}, Lta;->b()Landroid/content/res/ColorStateList;

    move-result-object p0

    return-object p0

    :cond_9
    const/4 p0, 0x0

    return-object p0
.end method

.method public getSupportBackgroundTintMode()Landroid/graphics/PorterDuff$Mode;
    .registers 1
    .annotation build Landroidx/annotation/Nullable;
    .end annotation

    .prologue
    iget-object p0, p0, Lac;->a:Lta;

    if-eqz p0, :cond_9

    invoke-virtual {p0}, Lta;->c()Landroid/graphics/PorterDuff$Mode;

    move-result-object p0

    return-object p0

    :cond_9
    const/4 p0, 0x0

    return-object p0
.end method

.method public getSupportImageTintList()Landroid/content/res/ColorStateList;
    .registers 2
    .annotation build Landroidx/annotation/Nullable;
    .end annotation

    .prologue
    const/4 v0, 0x0

    iget-object p0, p0, Lac;->b:Lbc;

    if-eqz p0, :cond_e

    iget-object p0, p0, Lbc;->b:Lcv;

    if-eqz p0, :cond_e

    iget-object p0, p0, Lcv;->c:Ljava/lang/Object;

    check-cast p0, Landroid/content/res/ColorStateList;

    return-object p0

    :cond_e
    return-object v0
.end method

.method public getSupportImageTintMode()Landroid/graphics/PorterDuff$Mode;
    .registers 2
    .annotation build Landroidx/annotation/Nullable;
    .end annotation

    .prologue
    const/4 v0, 0x0

    iget-object p0, p0, Lac;->b:Lbc;

    if-eqz p0, :cond_e

    iget-object p0, p0, Lbc;->b:Lcv;

    if-eqz p0, :cond_e

    iget-object p0, p0, Lcv;->d:Ljava/io/Serializable;

    check-cast p0, Landroid/graphics/PorterDuff$Mode;

    return-object p0

    :cond_e
    return-object v0
.end method

.method public final hasOverlappingRendering()Z
    .registers 2

    .prologue
    iget-object v0, p0, Lac;->b:Lbc;

    iget-object v0, v0, Lbc;->a:Landroid/widget/ImageView;

    invoke-virtual {v0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    instance-of v0, v0, Landroid/graphics/drawable/RippleDrawable;

    if-nez v0, :cond_14

    invoke-super {p0}, Landroid/view/View;->hasOverlappingRendering()Z

    move-result p0

    if-eqz p0, :cond_14

    const/4 p0, 0x1

    return p0

    :cond_14
    const/4 p0, 0x0

    return p0
.end method

.method public setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V
    .registers 2
    .param p1  # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    .prologue
    invoke-super {p0, p1}, Landroid/view/View;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    iget-object p0, p0, Lac;->a:Lta;

    if-eqz p0, :cond_a

    invoke-virtual {p0}, Lta;->e()V

    :cond_a
    return-void
.end method

.method public setBackgroundResource(I)V
    .registers 2

    .prologue
    invoke-super {p0, p1}, Landroid/view/View;->setBackgroundResource(I)V

    iget-object p0, p0, Lac;->a:Lta;

    if-eqz p0, :cond_a

    invoke-virtual {p0, p1}, Lta;->f(I)V

    :cond_a
    return-void
.end method

.method public setImageBitmap(Landroid/graphics/Bitmap;)V
    .registers 2

    .prologue
    invoke-super {p0, p1}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    iget-object p0, p0, Lac;->b:Lbc;

    if-eqz p0, :cond_a

    invoke-virtual {p0}, Lbc;->a()V

    :cond_a
    return-void
.end method

.method public setImageDrawable(Landroid/graphics/drawable/Drawable;)V
    .registers 4
    .param p1  # Landroid/graphics/drawable/Drawable;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    .prologue
    iget-object v0, p0, Lac;->b:Lbc;

    if-eqz v0, :cond_10

    if-eqz p1, :cond_10

    iget-boolean v1, p0, Lac;->c:Z

    if-nez v1, :cond_10

    invoke-virtual {p1}, Landroid/graphics/drawable/Drawable;->getLevel()I

    move-result v1

    iput v1, v0, Lbc;->c:I

    :cond_10
    invoke-super {p0, p1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    if-eqz v0, :cond_2d

    invoke-virtual {v0}, Lbc;->a()V

    iget-boolean p0, p0, Lac;->c:Z

    if-nez p0, :cond_2d

    iget-object p0, v0, Lbc;->a:Landroid/widget/ImageView;

    invoke-virtual {p0}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object p1

    if-eqz p1, :cond_2d

    invoke-virtual {p0}, Landroid/widget/ImageView;->getDrawable()Landroid/graphics/drawable/Drawable;

    move-result-object p0

    iget p1, v0, Lbc;->c:I

    invoke-virtual {p0, p1}, Landroid/graphics/drawable/Drawable;->setLevel(I)Z

    :cond_2d
    return-void
.end method

.method public setImageLevel(I)V
    .registers 2

    invoke-super {p0, p1}, Landroid/widget/ImageView;->setImageLevel(I)V

    const/4 p1, 0x1

    iput-boolean p1, p0, Lac;->c:Z

    return-void
.end method

.method public setImageResource(I)V
    .registers 2

    iget-object p0, p0, Lac;->b:Lbc;

    invoke-virtual {p0, p1}, Lbc;->c(I)V

    return-void
.end method

.method public setImageURI(Landroid/net/Uri;)V
    .registers 2
    .param p1  # Landroid/net/Uri;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    .prologue
    invoke-super {p0, p1}, Landroid/widget/ImageView;->setImageURI(Landroid/net/Uri;)V

    iget-object p0, p0, Lac;->b:Lbc;

    if-eqz p0, :cond_a

    invoke-virtual {p0}, Lbc;->a()V

    :cond_a
    return-void
.end method

.method public setSupportBackgroundTintList(Landroid/content/res/ColorStateList;)V
    .registers 2
    .param p1  # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    .prologue
    iget-object p0, p0, Lac;->a:Lta;

    if-eqz p0, :cond_7

    invoke-virtual {p0, p1}, Lta;->h(Landroid/content/res/ColorStateList;)V

    :cond_7
    return-void
.end method

.method public setSupportBackgroundTintMode(Landroid/graphics/PorterDuff$Mode;)V
    .registers 2
    .param p1  # Landroid/graphics/PorterDuff$Mode;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    .prologue
    iget-object p0, p0, Lac;->a:Lta;

    if-eqz p0, :cond_7

    invoke-virtual {p0, p1}, Lta;->i(Landroid/graphics/PorterDuff$Mode;)V

    :cond_7
    return-void
.end method

.method public setSupportImageTintList(Landroid/content/res/ColorStateList;)V
    .registers 3
    .param p1  # Landroid/content/res/ColorStateList;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    .prologue
    iget-object p0, p0, Lac;->b:Lbc;

    if-eqz p0, :cond_17

    iget-object v0, p0, Lbc;->b:Lcv;

    if-nez v0, :cond_f

    new-instance v0, Lcv;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lbc;->b:Lcv;

    :cond_f
    iput-object p1, v0, Lcv;->c:Ljava/lang/Object;

    const/4 p1, 0x1

    iput-boolean p1, v0, Lcv;->b:Z

    invoke-virtual {p0}, Lbc;->a()V

    :cond_17
    return-void
.end method

.method public setSupportImageTintMode(Landroid/graphics/PorterDuff$Mode;)V
    .registers 3
    .param p1  # Landroid/graphics/PorterDuff$Mode;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    .prologue
    iget-object p0, p0, Lac;->b:Lbc;

    if-eqz p0, :cond_17

    iget-object v0, p0, Lbc;->b:Lcv;

    if-nez v0, :cond_f

    new-instance v0, Lcv;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Lbc;->b:Lcv;

    :cond_f
    iput-object p1, v0, Lcv;->d:Ljava/io/Serializable;

    const/4 p1, 0x1

    iput-boolean p1, v0, Lcv;->a:Z

    invoke-virtual {p0}, Lbc;->a()V

    :cond_17
    return-void
.end method
