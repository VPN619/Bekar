.class public final La93;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic a:Landroid/app/Activity;

.field public final synthetic b:I

.field public final synthetic c:Lm3;

.field public final synthetic d:Lcom/google/android/gms/common/GoogleApiAvailability;


# direct methods
.method public constructor <init>(Lcom/google/android/gms/common/GoogleApiAvailability;Landroid/app/Activity;ILm3;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La93;->d:Lcom/google/android/gms/common/GoogleApiAvailability;

    iput-object p2, p0, La93;->a:Landroid/app/Activity;

    iput p3, p0, La93;->b:I

    iput-object p4, p0, La93;->c:Lm3;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 5

    .prologue
    invoke-interface {p1}, Landroid/content/DialogInterface;->dismiss()V

    iget-object p1, p0, La93;->d:Lcom/google/android/gms/common/GoogleApiAvailability;

    iget-object p2, p0, La93;->a:Landroid/app/Activity;

    iget v0, p0, La93;->b:I

    const/4 v1, 0x0

    invoke-virtual {p1, p2, v0, v1}, Lcom/google/android/gms/common/GoogleApiAvailability;->getErrorResolutionPendingIntent(Landroid/content/Context;II)Landroid/app/PendingIntent;

    move-result-object p1

    if-nez p1, :cond_11

    return-void

    :cond_11
    invoke-virtual {p1}, Landroid/app/PendingIntent;->getIntentSender()Landroid/content/IntentSender;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance p2, Lls0;

    const/4 v0, 0x0

    invoke-direct {p2, p1, v0, v1, v1}, Lls0;-><init>(Landroid/content/IntentSender;Landroid/content/Intent;II)V

    iget-object p0, p0, La93;->c:Lm3;

    invoke-virtual {p0, p2, v0}, Lm3;->a(Ljava/lang/Object;Lf3;)V

    return-void
.end method
