.class public abstract La22;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final a:Lb22;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lb22;

    invoke-direct {v0}, Lb22;-><init>()V

    sput-object v0, La22;->a:Lb22;

    return-void
.end method
