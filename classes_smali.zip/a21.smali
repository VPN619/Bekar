.class public final La21;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static q:Z


# instance fields
.field public a:I

.field public b:Z

.field public c:I

.field public final d:Lzm1;

.field public e:I

.field public f:I

.field public g:[Lwe;

.field public h:Z

.field public i:[Z

.field public j:I

.field public k:I

.field public l:I

.field public final m:Ltd;

.field public n:[Lq42;

.field public o:I

.field public p:Lwe;


# direct methods
.method public constructor <init>()V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x3e8

    iput v0, p0, La21;->a:I

    const/4 v1, 0x0

    iput-boolean v1, p0, La21;->b:Z

    iput v1, p0, La21;->c:I

    const/16 v2, 0x20

    iput v2, p0, La21;->e:I

    iput v2, p0, La21;->f:I

    iput-boolean v1, p0, La21;->h:Z

    new-array v3, v2, [Z

    iput-object v3, p0, La21;->i:[Z

    const/4 v3, 0x1

    iput v3, p0, La21;->j:I

    iput v1, p0, La21;->k:I

    iput v2, p0, La21;->l:I

    new-array v0, v0, [Lq42;

    iput-object v0, p0, La21;->n:[Lq42;

    iput v1, p0, La21;->o:I

    new-array v0, v2, [Lwe;

    iput-object v0, p0, La21;->g:[Lwe;

    invoke-virtual {p0}, La21;->s()V

    new-instance v0, Ltd;

    const/16 v3, 0x8

    const/4 v4, 0x0

    invoke-direct {v0, v3, v4}, Ltd;-><init>(IZ)V

    new-instance v3, Lyk1;

    invoke-direct {v3}, Lyk1;-><init>()V

    iput-object v3, v0, Ltd;->b:Ljava/lang/Object;

    new-instance v3, Lyk1;

    invoke-direct {v3}, Lyk1;-><init>()V

    iput-object v3, v0, Ltd;->c:Ljava/lang/Object;

    new-array v2, v2, [Lq42;

    iput-object v2, v0, Ltd;->d:Ljava/lang/Object;

    iput-object v0, p0, La21;->m:Ltd;

    new-instance v2, Lzm1;

    invoke-direct {v2, v0}, Lwe;-><init>(Ltd;)V

    const/16 v3, 0x80

    new-array v4, v3, [Lq42;

    iput-object v4, v2, Lzm1;->f:[Lq42;

    new-array v3, v3, [Lq42;

    iput-object v3, v2, Lzm1;->g:[Lq42;

    iput v1, v2, Lzm1;->h:I

    new-instance v1, Lfm0;

    const/16 v3, 0xa

    invoke-direct {v1, v3, v2}, Lfm0;-><init>(ILjava/lang/Object;)V

    iput-object v1, v2, Lzm1;->i:Lfm0;

    iput-object v2, p0, La21;->d:Lzm1;

    new-instance v1, Lwe;

    invoke-direct {v1, v0}, Lwe;-><init>(Ltd;)V

    iput-object v1, p0, La21;->p:Lwe;

    return-void
.end method

.method public static n(Ljava/lang/Object;)I
    .registers 2

    .prologue
    check-cast p0, Ltv;

    iget-object p0, p0, Ltv;->i:Lq42;

    if-eqz p0, :cond_d

    iget p0, p0, Lq42;->e:F

    const/high16 v0, 0x3f000000  # 0.5f

    add-float/2addr p0, v0

    float-to-int p0, p0

    return p0

    :cond_d
    const/4 p0, 0x0

    return p0
.end method


# virtual methods
.method public final a(I)Lq42;
    .registers 7

    .prologue
    iget-object v0, p0, La21;->m:Ltd;

    iget-object v0, v0, Ltd;->c:Ljava/lang/Object;

    check-cast v0, Lyk1;

    iget v1, v0, Lyk1;->b:I

    const/4 v2, 0x0

    if-lez v1, :cond_16

    add-int/lit8 v1, v1, -0x1

    iget-object v3, v0, Lyk1;->a:[Ljava/lang/Object;

    aget-object v4, v3, v1

    aput-object v2, v3, v1

    iput v1, v0, Lyk1;->b:I

    move-object v2, v4

    :cond_16
    check-cast v2, Lq42;

    if-nez v2, :cond_22

    new-instance v2, Lq42;

    invoke-direct {v2, p1}, Lq42;-><init>(I)V

    iput p1, v2, Lq42;->l:I

    goto :goto_27

    :cond_22
    invoke-virtual {v2}, Lq42;->c()V

    iput p1, v2, Lq42;->l:I

    :goto_27
    iget p1, p0, La21;->o:I

    iget v0, p0, La21;->a:I

    if-lt p1, v0, :cond_3b

    mul-int/lit8 v0, v0, 0x2

    iput v0, p0, La21;->a:I

    iget-object p1, p0, La21;->n:[Lq42;

    invoke-static {p1, v0}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p1

    check-cast p1, [Lq42;

    iput-object p1, p0, La21;->n:[Lq42;

    :cond_3b
    iget-object p1, p0, La21;->n:[Lq42;

    iget v0, p0, La21;->o:I

    add-int/lit8 v1, v0, 0x1

    iput v1, p0, La21;->o:I

    aput-object v2, p1, v0

    return-object v2
.end method

.method public final b(Lq42;Lq42;IFLq42;Lq42;II)V
    .registers 15

    .prologue
    invoke-virtual {p0}, La21;->l()Lwe;

    move-result-object v0

    const/high16 v1, 0x3f800000  # 1.0f

    if-ne p2, p5, :cond_1a

    iget-object p3, v0, Lwe;->d:Lne;

    invoke-virtual {p3, p1, v1}, Lne;->g(Lq42;F)V

    iget-object p1, v0, Lwe;->d:Lne;

    invoke-virtual {p1, p6, v1}, Lne;->g(Lq42;F)V

    iget-object p1, v0, Lwe;->d:Lne;

    const/high16 p3, -0x40000000  # -2.0f

    invoke-virtual {p1, p2, p3}, Lne;->g(Lq42;F)V

    goto :goto_88

    :cond_1a
    const/high16 v2, 0x3f000000  # 0.5f

    cmpl-float v2, p4, v2

    iget-object v3, v0, Lwe;->d:Lne;

    const/high16 v4, -0x40800000  # -1.0f

    if-nez v2, :cond_40

    invoke-virtual {v3, p1, v1}, Lne;->g(Lq42;F)V

    iget-object p1, v0, Lwe;->d:Lne;

    invoke-virtual {p1, p2, v4}, Lne;->g(Lq42;F)V

    iget-object p1, v0, Lwe;->d:Lne;

    invoke-virtual {p1, p5, v4}, Lne;->g(Lq42;F)V

    iget-object p1, v0, Lwe;->d:Lne;

    invoke-virtual {p1, p6, v1}, Lne;->g(Lq42;F)V

    if-gtz p3, :cond_3a

    if-lez p7, :cond_88

    :cond_3a
    neg-int p1, p3

    add-int/2addr p1, p7

    int-to-float p1, p1

    iput p1, v0, Lwe;->b:F

    goto :goto_88

    :cond_40
    const/4 v2, 0x0

    cmpg-float v2, p4, v2

    if-gtz v2, :cond_51

    invoke-virtual {v3, p1, v4}, Lne;->g(Lq42;F)V

    iget-object p1, v0, Lwe;->d:Lne;

    invoke-virtual {p1, p2, v1}, Lne;->g(Lq42;F)V

    int-to-float p1, p3

    iput p1, v0, Lwe;->b:F

    goto :goto_88

    :cond_51
    cmpl-float v2, p4, v1

    if-ltz v2, :cond_62

    invoke-virtual {v3, p6, v4}, Lne;->g(Lq42;F)V

    iget-object p1, v0, Lwe;->d:Lne;

    invoke-virtual {p1, p5, v1}, Lne;->g(Lq42;F)V

    neg-int p1, p7

    int-to-float p1, p1

    iput p1, v0, Lwe;->b:F

    goto :goto_88

    :cond_62
    sub-float v2, v1, p4

    mul-float v5, v2, v1

    invoke-virtual {v3, p1, v5}, Lne;->g(Lq42;F)V

    iget-object p1, v0, Lwe;->d:Lne;

    mul-float v3, v2, v4

    invoke-virtual {p1, p2, v3}, Lne;->g(Lq42;F)V

    iget-object p1, v0, Lwe;->d:Lne;

    mul-float/2addr v4, p4

    invoke-virtual {p1, p5, v4}, Lne;->g(Lq42;F)V

    iget-object p1, v0, Lwe;->d:Lne;

    mul-float/2addr v1, p4

    invoke-virtual {p1, p6, v1}, Lne;->g(Lq42;F)V

    if-gtz p3, :cond_80

    if-lez p7, :cond_88

    :cond_80
    neg-int p1, p3

    int-to-float p1, p1

    mul-float/2addr p1, v2

    int-to-float p2, p7

    mul-float/2addr p2, p4

    add-float/2addr p2, p1

    iput p2, v0, Lwe;->b:F

    :cond_88
    :goto_88
    const/16 p1, 0x8

    if-eq p8, p1, :cond_8f

    invoke-virtual {v0, p0, p8}, Lwe;->a(La21;I)V

    :cond_8f
    invoke-virtual {p0, v0}, La21;->c(Lwe;)V

    return-void
.end method

.method public final c(Lwe;)V
    .registers 19

    .prologue
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iget v2, v0, La21;->k:I

    const/4 v3, 0x1

    add-int/2addr v2, v3

    iget v4, v0, La21;->l:I

    if-ge v2, v4, :cond_13

    iget v2, v0, La21;->j:I

    add-int/2addr v2, v3

    iget v4, v0, La21;->f:I

    if-lt v2, v4, :cond_16

    :cond_13
    invoke-virtual {v0}, La21;->o()V

    :cond_16
    iget-boolean v2, v1, Lwe;->e:Z

    if-nez v2, :cond_1bb

    iget-object v2, v1, Lwe;->c:Ljava/util/ArrayList;

    iget-object v5, v0, La21;->g:[Lwe;

    array-length v5, v5

    const/4 v6, -0x1

    if-nez v5, :cond_23

    goto :goto_7d

    :cond_23
    const/4 v5, 0x0

    :goto_24
    if-nez v5, :cond_6d

    iget-object v7, v1, Lwe;->d:Lne;

    invoke-virtual {v7}, Lne;->d()I

    move-result v7

    const/4 v8, 0x0

    :goto_2d
    if-ge v8, v7, :cond_44

    iget-object v9, v1, Lwe;->d:Lne;

    invoke-virtual {v9, v8}, Lne;->e(I)Lq42;

    move-result-object v9

    iget v10, v9, Lq42;->c:I

    if-ne v10, v6, :cond_3e

    iget-boolean v10, v9, Lq42;->f:Z

    if-nez v10, :cond_3e

    goto :goto_41

    :cond_3e
    invoke-virtual {v2, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_41
    add-int/lit8 v8, v8, 0x1

    goto :goto_2d

    :cond_44
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v7

    if-lez v7, :cond_6b

    const/4 v8, 0x0

    :goto_4b
    if-ge v8, v7, :cond_67

    invoke-virtual {v2, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lq42;

    iget-boolean v10, v9, Lq42;->f:Z

    if-eqz v10, :cond_5b

    invoke-virtual {v1, v0, v9, v3}, Lwe;->h(La21;Lq42;Z)V

    goto :goto_64

    :cond_5b
    iget-object v10, v0, La21;->g:[Lwe;

    iget v9, v9, Lq42;->c:I

    aget-object v9, v10, v9

    invoke-virtual {v1, v0, v9, v3}, Lwe;->i(La21;Lwe;Z)V

    :goto_64
    add-int/lit8 v8, v8, 0x1

    goto :goto_4b

    :cond_67
    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    goto :goto_24

    :cond_6b
    move v5, v3

    goto :goto_24

    :cond_6d
    iget-object v2, v1, Lwe;->a:Lq42;

    if-eqz v2, :cond_7d

    iget-object v2, v1, Lwe;->d:Lne;

    invoke-virtual {v2}, Lne;->d()I

    move-result v2

    if-nez v2, :cond_7d

    iput-boolean v3, v1, Lwe;->e:Z

    iput-boolean v3, v0, La21;->b:Z

    :cond_7d
    :goto_7d
    invoke-virtual {v1}, Lwe;->e()Z

    move-result v2

    if-eqz v2, :cond_85

    goto/16 :goto_1c1

    :cond_85
    iget v2, v1, Lwe;->b:F

    const/4 v5, 0x0

    cmpg-float v7, v2, v5

    if-gez v7, :cond_aa

    const/high16 v7, -0x40800000  # -1.0f

    mul-float/2addr v2, v7

    iput v2, v1, Lwe;->b:F

    iget-object v2, v1, Lwe;->d:Lne;

    iget v8, v2, Lne;->h:I

    const/4 v9, 0x0

    :goto_96
    if-eq v8, v6, :cond_aa

    iget v10, v2, Lne;->a:I

    if-ge v9, v10, :cond_aa

    iget-object v10, v2, Lne;->g:[F

    aget v11, v10, v8

    mul-float/2addr v11, v7

    aput v11, v10, v8

    iget-object v10, v2, Lne;->f:[I

    aget v8, v10, v8

    add-int/lit8 v9, v9, 0x1

    goto :goto_96

    :cond_aa
    iget-object v2, v1, Lwe;->d:Lne;

    invoke-virtual {v2}, Lne;->d()I

    move-result v2

    const/4 v7, 0x0

    move v11, v5

    move v13, v11

    move-object v9, v7

    move-object v10, v9

    const/4 v8, 0x0

    const/4 v12, 0x0

    const/4 v14, 0x0

    :goto_b8
    if-ge v8, v2, :cond_10f

    iget-object v15, v1, Lwe;->d:Lne;

    invoke-virtual {v15, v8}, Lne;->f(I)F

    move-result v15

    iget-object v4, v1, Lwe;->d:Lne;

    invoke-virtual {v4, v8}, Lne;->e(I)Lq42;

    move-result-object v4

    move/from16 v16, v5

    iget v5, v4, Lq42;->l:I

    if-ne v5, v3, :cond_e8

    if-nez v9, :cond_d7

    iget v5, v4, Lq42;->k:I

    if-gt v5, v3, :cond_d3

    goto :goto_e6

    :cond_d3
    const/4 v12, 0x0

    :goto_d4
    move-object v9, v4

    move v11, v15

    goto :goto_10a

    :cond_d7
    cmpl-float v5, v11, v15

    if-lez v5, :cond_e0

    iget v5, v4, Lq42;->k:I

    if-gt v5, v3, :cond_d3

    goto :goto_e6

    :cond_e0
    if-nez v12, :cond_10a

    iget v5, v4, Lq42;->k:I

    if-gt v5, v3, :cond_10a

    :goto_e6
    move v12, v3

    goto :goto_d4

    :cond_e8
    if-nez v9, :cond_10a

    cmpg-float v5, v15, v16

    if-gez v5, :cond_10a

    if-nez v10, :cond_f9

    iget v5, v4, Lq42;->k:I

    if-gt v5, v3, :cond_f5

    goto :goto_108

    :cond_f5
    const/4 v14, 0x0

    :goto_f6
    move-object v10, v4

    move v13, v15

    goto :goto_10a

    :cond_f9
    cmpl-float v5, v13, v15

    if-lez v5, :cond_102

    iget v5, v4, Lq42;->k:I

    if-gt v5, v3, :cond_f5

    goto :goto_108

    :cond_102
    if-nez v14, :cond_10a

    iget v5, v4, Lq42;->k:I

    if-gt v5, v3, :cond_10a

    :goto_108
    move v14, v3

    goto :goto_f6

    :cond_10a
    :goto_10a
    add-int/lit8 v8, v8, 0x1

    move/from16 v5, v16

    goto :goto_b8

    :cond_10f
    move/from16 v16, v5

    if-eqz v9, :cond_114

    goto :goto_115

    :cond_114
    move-object v9, v10

    :goto_115
    if-nez v9, :cond_119

    move v2, v3

    goto :goto_11d

    :cond_119
    invoke-virtual {v1, v9}, Lwe;->g(Lq42;)V

    const/4 v2, 0x0

    :goto_11d
    iget-object v4, v1, Lwe;->d:Lne;

    invoke-virtual {v4}, Lne;->d()I

    move-result v4

    if-nez v4, :cond_127

    iput-boolean v3, v1, Lwe;->e:Z

    :cond_127
    if-eqz v2, :cond_1ab

    iget v2, v0, La21;->j:I

    add-int/2addr v2, v3

    iget v4, v0, La21;->f:I

    if-lt v2, v4, :cond_133

    invoke-virtual {v0}, La21;->o()V

    :cond_133
    const/4 v2, 0x3

    invoke-virtual {v0, v2}, La21;->a(I)Lq42;

    move-result-object v2

    iget v4, v0, La21;->c:I

    add-int/2addr v4, v3

    iput v4, v0, La21;->c:I

    iget v5, v0, La21;->j:I

    add-int/2addr v5, v3

    iput v5, v0, La21;->j:I

    iput v4, v2, Lq42;->b:I

    iget-object v5, v0, La21;->m:Ltd;

    iget-object v8, v5, Ltd;->d:Ljava/lang/Object;

    check-cast v8, [Lq42;

    aput-object v2, v8, v4

    iput-object v2, v1, Lwe;->a:Lq42;

    iget v4, v0, La21;->k:I

    invoke-virtual/range {p0 .. p1}, La21;->h(Lwe;)V

    iget v8, v0, La21;->k:I

    add-int/2addr v4, v3

    if-ne v8, v4, :cond_1ab

    iget-object v4, v0, La21;->p:Lwe;

    iput-object v7, v4, Lwe;->a:Lq42;

    iget-object v8, v4, Lwe;->d:Lne;

    invoke-virtual {v8}, Lne;->b()V

    const/4 v8, 0x0

    :goto_162
    iget-object v9, v1, Lwe;->d:Lne;

    invoke-virtual {v9}, Lne;->d()I

    move-result v9

    if-ge v8, v9, :cond_17e

    iget-object v9, v1, Lwe;->d:Lne;

    invoke-virtual {v9, v8}, Lne;->e(I)Lq42;

    move-result-object v9

    iget-object v10, v1, Lwe;->d:Lne;

    invoke-virtual {v10, v8}, Lne;->f(I)F

    move-result v10

    iget-object v11, v4, Lwe;->d:Lne;

    invoke-virtual {v11, v9, v10, v3}, Lne;->a(Lq42;FZ)V

    add-int/lit8 v8, v8, 0x1

    goto :goto_162

    :cond_17e
    iget-object v4, v0, La21;->p:Lwe;

    invoke-virtual {v0, v4}, La21;->r(Lwe;)V

    iget v4, v2, Lq42;->c:I

    if-ne v4, v6, :cond_1a9

    iget-object v4, v1, Lwe;->a:Lq42;

    if-ne v4, v2, :cond_194

    invoke-virtual {v1, v7, v2}, Lwe;->f([ZLq42;)Lq42;

    move-result-object v2

    if-eqz v2, :cond_194

    invoke-virtual {v1, v2}, Lwe;->g(Lq42;)V

    :cond_194
    iget-boolean v2, v1, Lwe;->e:Z

    if-nez v2, :cond_19d

    iget-object v2, v1, Lwe;->a:Lq42;

    invoke-virtual {v2, v0, v1}, Lq42;->e(La21;Lwe;)V

    :cond_19d
    iget-object v2, v5, Ltd;->b:Ljava/lang/Object;

    check-cast v2, Lyk1;

    invoke-virtual {v2, v1}, Lyk1;->b(Ljava/lang/Object;)V

    iget v2, v0, La21;->k:I

    sub-int/2addr v2, v3

    iput v2, v0, La21;->k:I

    :cond_1a9
    move v4, v3

    goto :goto_1ac

    :cond_1ab
    const/4 v4, 0x0

    :goto_1ac
    iget-object v2, v1, Lwe;->a:Lq42;

    if-eqz v2, :cond_1c1

    iget v2, v2, Lq42;->l:I

    if-eq v2, v3, :cond_1bc

    iget v2, v1, Lwe;->b:F

    cmpg-float v2, v2, v16

    if-ltz v2, :cond_1c1

    goto :goto_1bc

    :cond_1bb
    const/4 v4, 0x0

    :cond_1bc
    :goto_1bc
    if-nez v4, :cond_1c1

    invoke-virtual/range {p0 .. p1}, La21;->h(Lwe;)V

    :cond_1c1
    :goto_1c1
    return-void
.end method

.method public final d(Lq42;I)V
    .registers 7

    .prologue
    iget v0, p1, Lq42;->c:I

    const/4 v1, 0x1

    const/4 v2, -0x1

    if-ne v0, v2, :cond_1c

    int-to-float p2, p2

    invoke-virtual {p1, p0, p2}, Lq42;->d(La21;F)V

    const/4 p1, 0x0

    :goto_b
    iget p2, p0, La21;->c:I

    add-int/2addr p2, v1

    if-ge p1, p2, :cond_1b

    iget-object p2, p0, La21;->m:Ltd;

    iget-object p2, p2, Ltd;->d:Ljava/lang/Object;

    check-cast p2, [Lq42;

    aget-object p2, p2, p1

    add-int/lit8 p1, p1, 0x1

    goto :goto_b

    :cond_1b
    return-void

    :cond_1c
    if-eq v0, v2, :cond_58

    iget-object v3, p0, La21;->g:[Lwe;

    aget-object v0, v3, v0

    iget-boolean v3, v0, Lwe;->e:Z

    if-eqz v3, :cond_2a

    int-to-float p0, p2

    iput p0, v0, Lwe;->b:F

    return-void

    :cond_2a
    iget-object v3, v0, Lwe;->d:Lne;

    invoke-virtual {v3}, Lne;->d()I

    move-result v3

    if-nez v3, :cond_38

    iput-boolean v1, v0, Lwe;->e:Z

    int-to-float p0, p2

    iput p0, v0, Lwe;->b:F

    return-void

    :cond_38
    invoke-virtual {p0}, La21;->l()Lwe;

    move-result-object v0

    if-gez p2, :cond_4a

    mul-int/2addr p2, v2

    int-to-float p2, p2

    iput p2, v0, Lwe;->b:F

    iget-object p2, v0, Lwe;->d:Lne;

    const/high16 v1, 0x3f800000  # 1.0f

    invoke-virtual {p2, p1, v1}, Lne;->g(Lq42;F)V

    goto :goto_54

    :cond_4a
    int-to-float p2, p2

    iput p2, v0, Lwe;->b:F

    iget-object p2, v0, Lwe;->d:Lne;

    const/high16 v1, -0x40800000  # -1.0f

    invoke-virtual {p2, p1, v1}, Lne;->g(Lq42;F)V

    :goto_54
    invoke-virtual {p0, v0}, La21;->c(Lwe;)V

    return-void

    :cond_58
    invoke-virtual {p0}, La21;->l()Lwe;

    move-result-object v0

    iput-object p1, v0, Lwe;->a:Lq42;

    int-to-float p2, p2

    iput p2, p1, Lq42;->e:F

    iput p2, v0, Lwe;->b:F

    iput-boolean v1, v0, Lwe;->e:Z

    invoke-virtual {p0, v0}, La21;->c(Lwe;)V

    return-void
.end method

.method public final e(Lq42;Lq42;II)V
    .registers 10

    .prologue
    const/16 v0, 0x8

    if-ne p4, v0, :cond_15

    iget-boolean v1, p2, Lq42;->f:Z

    if-eqz v1, :cond_15

    iget v1, p1, Lq42;->c:I

    const/4 v2, -0x1

    if-ne v1, v2, :cond_15

    iget p2, p2, Lq42;->e:F

    int-to-float p3, p3

    add-float/2addr p2, p3

    invoke-virtual {p1, p0, p2}, Lq42;->d(La21;F)V

    return-void

    :cond_15
    invoke-virtual {p0}, La21;->l()Lwe;

    move-result-object v1

    const/4 v2, 0x0

    if-eqz p3, :cond_24

    if-gez p3, :cond_21

    mul-int/lit8 p3, p3, -0x1

    const/4 v2, 0x1

    :cond_21
    int-to-float p3, p3

    iput p3, v1, Lwe;->b:F

    :cond_24
    iget-object p3, v1, Lwe;->d:Lne;

    const/high16 v3, 0x3f800000  # 1.0f

    const/high16 v4, -0x40800000  # -1.0f

    if-nez v2, :cond_35

    invoke-virtual {p3, p1, v4}, Lne;->g(Lq42;F)V

    iget-object p1, v1, Lwe;->d:Lne;

    invoke-virtual {p1, p2, v3}, Lne;->g(Lq42;F)V

    goto :goto_3d

    :cond_35
    invoke-virtual {p3, p1, v3}, Lne;->g(Lq42;F)V

    iget-object p1, v1, Lwe;->d:Lne;

    invoke-virtual {p1, p2, v4}, Lne;->g(Lq42;F)V

    :goto_3d
    if-eq p4, v0, :cond_42

    invoke-virtual {v1, p0, p4}, Lwe;->a(La21;I)V

    :cond_42
    invoke-virtual {p0, v1}, La21;->c(Lwe;)V

    return-void
.end method

.method public final f(Lq42;Lq42;II)V
    .registers 8

    .prologue
    invoke-virtual {p0}, La21;->l()Lwe;

    move-result-object v0

    invoke-virtual {p0}, La21;->m()Lq42;

    move-result-object v1

    const/4 v2, 0x0

    iput v2, v1, Lq42;->d:I

    invoke-virtual {v0, p1, p2, v1, p3}, Lwe;->b(Lq42;Lq42;Lq42;I)V

    const/16 p1, 0x8

    if-eq p4, p1, :cond_26

    iget-object p1, v0, Lwe;->d:Lne;

    invoke-virtual {p1, v1}, Lne;->c(Lq42;)F

    move-result p1

    const/high16 p2, -0x40800000  # -1.0f

    mul-float/2addr p1, p2

    float-to-int p1, p1

    invoke-virtual {p0, p4}, La21;->j(I)Lq42;

    move-result-object p2

    iget-object p3, v0, Lwe;->d:Lne;

    int-to-float p1, p1

    invoke-virtual {p3, p2, p1}, Lne;->g(Lq42;F)V

    :cond_26
    invoke-virtual {p0, v0}, La21;->c(Lwe;)V

    return-void
.end method

.method public final g(Lq42;Lq42;II)V
    .registers 8

    .prologue
    invoke-virtual {p0}, La21;->l()Lwe;

    move-result-object v0

    invoke-virtual {p0}, La21;->m()Lq42;

    move-result-object v1

    const/4 v2, 0x0

    iput v2, v1, Lq42;->d:I

    invoke-virtual {v0, p1, p2, v1, p3}, Lwe;->c(Lq42;Lq42;Lq42;I)V

    const/16 p1, 0x8

    if-eq p4, p1, :cond_26

    iget-object p1, v0, Lwe;->d:Lne;

    invoke-virtual {p1, v1}, Lne;->c(Lq42;)F

    move-result p1

    const/high16 p2, -0x40800000  # -1.0f

    mul-float/2addr p1, p2

    float-to-int p1, p1

    invoke-virtual {p0, p4}, La21;->j(I)Lq42;

    move-result-object p2

    iget-object p3, v0, Lwe;->d:Lne;

    int-to-float p1, p1

    invoke-virtual {p3, p2, p1}, Lne;->g(Lq42;F)V

    :cond_26
    invoke-virtual {p0, v0}, La21;->c(Lwe;)V

    return-void
.end method

.method public final h(Lwe;)V
    .registers 9

    .prologue
    iget-boolean v0, p1, Lwe;->e:Z

    if-eqz v0, :cond_c

    iget-object v0, p1, Lwe;->a:Lq42;

    iget p1, p1, Lwe;->b:F

    invoke-virtual {v0, p0, p1}, Lq42;->d(La21;F)V

    goto :goto_1d

    :cond_c
    iget-object v0, p0, La21;->g:[Lwe;

    iget v1, p0, La21;->k:I

    aput-object p1, v0, v1

    iget-object v0, p1, Lwe;->a:Lq42;

    iput v1, v0, Lq42;->c:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, La21;->k:I

    invoke-virtual {v0, p0, p1}, Lq42;->e(La21;Lwe;)V

    :goto_1d
    iget-boolean p1, p0, La21;->b:Z

    if-eqz p1, :cond_81

    const/4 p1, 0x0

    move v0, p1

    :goto_23
    iget v1, p0, La21;->k:I

    if-ge v0, v1, :cond_7f

    iget-object v1, p0, La21;->g:[Lwe;

    aget-object v1, v1, v0

    if-nez v1, :cond_34

    sget-object v1, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const-string v2, "WTF"

    invoke-virtual {v1, v2}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    :cond_34
    iget-object v1, p0, La21;->g:[Lwe;

    aget-object v1, v1, v0

    if-eqz v1, :cond_7c

    iget-boolean v2, v1, Lwe;->e:Z

    if-eqz v2, :cond_7c

    iget-object v2, v1, Lwe;->a:Lq42;

    iget v3, v1, Lwe;->b:F

    invoke-virtual {v2, p0, v3}, Lq42;->d(La21;F)V

    iget-object v2, p0, La21;->m:Ltd;

    iget-object v2, v2, Ltd;->b:Ljava/lang/Object;

    check-cast v2, Lyk1;

    invoke-virtual {v2, v1}, Lyk1;->b(Ljava/lang/Object;)V

    iget-object v1, p0, La21;->g:[Lwe;

    const/4 v2, 0x0

    aput-object v2, v1, v0

    add-int/lit8 v1, v0, 0x1

    move v3, v1

    :goto_56
    iget v4, p0, La21;->k:I

    if-ge v1, v4, :cond_70

    iget-object v3, p0, La21;->g:[Lwe;

    add-int/lit8 v4, v1, -0x1

    aget-object v5, v3, v1

    aput-object v5, v3, v4

    iget-object v3, v5, Lwe;->a:Lq42;

    iget v5, v3, Lq42;->c:I

    if-ne v5, v1, :cond_6a

    iput v4, v3, Lq42;->c:I

    :cond_6a
    add-int/lit8 v3, v1, 0x1

    move v6, v3

    move v3, v1

    move v1, v6

    goto :goto_56

    :cond_70
    if-ge v3, v4, :cond_76

    iget-object v1, p0, La21;->g:[Lwe;

    aput-object v2, v1, v3

    :cond_76
    add-int/lit8 v4, v4, -0x1

    iput v4, p0, La21;->k:I

    add-int/lit8 v0, v0, -0x1

    :cond_7c
    add-int/lit8 v0, v0, 0x1

    goto :goto_23

    :cond_7f
    iput-boolean p1, p0, La21;->b:Z

    :cond_81
    return-void
.end method

.method public final i()V
    .registers 4

    .prologue
    const/4 v0, 0x0

    :goto_1
    iget v1, p0, La21;->k:I

    if-ge v0, v1, :cond_12

    iget-object v1, p0, La21;->g:[Lwe;

    aget-object v1, v1, v0

    iget-object v2, v1, Lwe;->a:Lq42;

    iget v1, v1, Lwe;->b:F

    iput v1, v2, Lq42;->e:F

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_12
    return-void
.end method

.method public final j(I)Lq42;
    .registers 6

    .prologue
    iget v0, p0, La21;->j:I

    add-int/lit8 v0, v0, 0x1

    iget v1, p0, La21;->f:I

    if-lt v0, v1, :cond_b

    invoke-virtual {p0}, La21;->o()V

    :cond_b
    const/4 v0, 0x4

    invoke-virtual {p0, v0}, La21;->a(I)Lq42;

    move-result-object v0

    iget-object v1, v0, Lq42;->h:[F

    iget v2, p0, La21;->c:I

    add-int/lit8 v2, v2, 0x1

    iput v2, p0, La21;->c:I

    iget v3, p0, La21;->j:I

    add-int/lit8 v3, v3, 0x1

    iput v3, p0, La21;->j:I

    iput v2, v0, Lq42;->b:I

    iput p1, v0, Lq42;->d:I

    iget-object p1, p0, La21;->m:Ltd;

    iget-object p1, p1, Ltd;->d:Ljava/lang/Object;

    check-cast p1, [Lq42;

    aput-object v0, p1, v2

    iget-object p0, p0, La21;->d:Lzm1;

    iget-object p1, p0, Lzm1;->i:Lfm0;

    iput-object v0, p1, Lfm0;->b:Ljava/lang/Object;

    const/4 p1, 0x0

    invoke-static {v1, p1}, Ljava/util/Arrays;->fill([FF)V

    iget p1, v0, Lq42;->d:I

    const/high16 v2, 0x3f800000  # 1.0f

    aput v2, v1, p1

    invoke-virtual {p0, v0}, Lzm1;->j(Lq42;)V

    return-object v0
.end method

.method public final k(Ljava/lang/Object;)Lq42;
    .registers 7

    .prologue
    if-nez p1, :cond_3

    goto :goto_4c

    :cond_3
    iget v0, p0, La21;->j:I

    const/4 v1, 0x1

    add-int/2addr v0, v1

    iget v2, p0, La21;->f:I

    if-lt v0, v2, :cond_e

    invoke-virtual {p0}, La21;->o()V

    :cond_e
    instance-of v0, p1, Ltv;

    if-eqz v0, :cond_4c

    check-cast p1, Ltv;

    iget-object v0, p1, Ltv;->i:Lq42;

    if-nez v0, :cond_1d

    invoke-virtual {p1}, Ltv;->k()V

    iget-object v0, p1, Ltv;->i:Lq42;

    :cond_1d
    iget p1, v0, Lq42;->b:I

    const/4 v2, -0x1

    iget-object v3, p0, La21;->m:Ltd;

    if-eq p1, v2, :cond_32

    iget v4, p0, La21;->c:I

    if-gt p1, v4, :cond_32

    iget-object v4, v3, Ltd;->d:Ljava/lang/Object;

    check-cast v4, [Lq42;

    aget-object v4, v4, p1

    if-nez v4, :cond_31

    goto :goto_32

    :cond_31
    return-object v0

    :cond_32
    :goto_32
    if-eq p1, v2, :cond_37

    invoke-virtual {v0}, Lq42;->c()V

    :cond_37
    iget p1, p0, La21;->c:I

    add-int/2addr p1, v1

    iput p1, p0, La21;->c:I

    iget v2, p0, La21;->j:I

    add-int/2addr v2, v1

    iput v2, p0, La21;->j:I

    iput p1, v0, Lq42;->b:I

    iput v1, v0, Lq42;->l:I

    iget-object p0, v3, Ltd;->d:Ljava/lang/Object;

    check-cast p0, [Lq42;

    aput-object v0, p0, p1

    return-object v0

    :cond_4c
    :goto_4c
    const/4 p0, 0x0

    return-object p0
.end method

.method public final l()Lwe;
    .registers 6

    .prologue
    iget-object p0, p0, La21;->m:Ltd;

    iget-object v0, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v0, Lyk1;

    iget v1, v0, Lyk1;->b:I

    const/4 v2, 0x0

    if-lez v1, :cond_16

    add-int/lit8 v1, v1, -0x1

    iget-object v3, v0, Lyk1;->a:[Ljava/lang/Object;

    aget-object v4, v3, v1

    aput-object v2, v3, v1

    iput v1, v0, Lyk1;->b:I

    goto :goto_17

    :cond_16
    move-object v4, v2

    :goto_17
    check-cast v4, Lwe;

    if-nez v4, :cond_21

    new-instance v4, Lwe;

    invoke-direct {v4, p0}, Lwe;-><init>(Ltd;)V

    goto :goto_2e

    :cond_21
    iput-object v2, v4, Lwe;->a:Lq42;

    iget-object p0, v4, Lwe;->d:Lne;

    invoke-virtual {p0}, Lne;->b()V

    const/4 p0, 0x0

    iput p0, v4, Lwe;->b:F

    const/4 p0, 0x0

    iput-boolean p0, v4, Lwe;->e:Z

    :goto_2e
    return-object v4
.end method

.method public final m()Lq42;
    .registers 4

    .prologue
    iget v0, p0, La21;->j:I

    add-int/lit8 v0, v0, 0x1

    iget v1, p0, La21;->f:I

    if-lt v0, v1, :cond_b

    invoke-virtual {p0}, La21;->o()V

    :cond_b
    const/4 v0, 0x3

    invoke-virtual {p0, v0}, La21;->a(I)Lq42;

    move-result-object v0

    iget v1, p0, La21;->c:I

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, La21;->c:I

    iget v2, p0, La21;->j:I

    add-int/lit8 v2, v2, 0x1

    iput v2, p0, La21;->j:I

    iput v1, v0, Lq42;->b:I

    iget-object p0, p0, La21;->m:Ltd;

    iget-object p0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast p0, [Lq42;

    aput-object v0, p0, v1

    return-object v0
.end method

.method public final o()V
    .registers 4

    iget v0, p0, La21;->e:I

    mul-int/lit8 v0, v0, 0x2

    iput v0, p0, La21;->e:I

    iget-object v1, p0, La21;->g:[Lwe;

    invoke-static {v1, v0}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lwe;

    iput-object v0, p0, La21;->g:[Lwe;

    iget-object v0, p0, La21;->m:Ltd;

    iget-object v1, v0, Ltd;->d:Ljava/lang/Object;

    check-cast v1, [Lq42;

    iget v2, p0, La21;->e:I

    invoke-static {v1, v2}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [Lq42;

    iput-object v1, v0, Ltd;->d:Ljava/lang/Object;

    iget v0, p0, La21;->e:I

    new-array v1, v0, [Z

    iput-object v1, p0, La21;->i:[Z

    iput v0, p0, La21;->f:I

    iput v0, p0, La21;->l:I

    return-void
.end method

.method public final p()V
    .registers 4

    .prologue
    iget-object v0, p0, La21;->d:Lzm1;

    invoke-virtual {v0}, Lzm1;->e()Z

    move-result v1

    if-eqz v1, :cond_c

    invoke-virtual {p0}, La21;->i()V

    return-void

    :cond_c
    iget-boolean v1, p0, La21;->h:Z

    if-eqz v1, :cond_28

    const/4 v1, 0x0

    :goto_11
    iget v2, p0, La21;->k:I

    if-ge v1, v2, :cond_24

    iget-object v2, p0, La21;->g:[Lwe;

    aget-object v2, v2, v1

    iget-boolean v2, v2, Lwe;->e:Z

    if-nez v2, :cond_21

    invoke-virtual {p0, v0}, La21;->q(Lzm1;)V

    return-void

    :cond_21
    add-int/lit8 v1, v1, 0x1

    goto :goto_11

    :cond_24
    invoke-virtual {p0}, La21;->i()V

    return-void

    :cond_28
    invoke-virtual {p0, v0}, La21;->q(Lzm1;)V

    return-void
.end method

.method public final q(Lzm1;)V
    .registers 20

    .prologue
    move-object/from16 v0, p0

    const/4 v2, 0x0

    :goto_3
    iget v3, v0, La21;->k:I

    if-ge v2, v3, :cond_ae

    iget-object v3, v0, La21;->g:[Lwe;

    aget-object v3, v3, v2

    iget-object v4, v3, Lwe;->a:Lq42;

    iget v4, v4, Lq42;->l:I

    const/4 v5, 0x1

    if-ne v4, v5, :cond_14

    goto/16 :goto_aa

    :cond_14
    iget v3, v3, Lwe;->b:F

    const/4 v4, 0x0

    cmpg-float v3, v3, v4

    if-gez v3, :cond_aa

    const/4 v2, 0x0

    const/4 v3, 0x0

    :goto_1d
    if-nez v2, :cond_ae

    add-int/2addr v3, v5

    const/4 v6, -0x1

    const v7, 0x7f7fffff  # Float.MAX_VALUE

    move v9, v6

    move v10, v9

    const/4 v8, 0x0

    const/4 v11, 0x0

    :goto_28
    iget v12, v0, La21;->k:I

    if-ge v8, v12, :cond_81

    iget-object v12, v0, La21;->g:[Lwe;

    aget-object v12, v12, v8

    iget-object v13, v12, Lwe;->a:Lq42;

    iget v13, v13, Lq42;->l:I

    if-ne v13, v5, :cond_37

    goto :goto_7c

    :cond_37
    iget-boolean v13, v12, Lwe;->e:Z

    if-eqz v13, :cond_3c

    goto :goto_7c

    :cond_3c
    iget v13, v12, Lwe;->b:F

    cmpg-float v13, v13, v4

    if-gez v13, :cond_7c

    iget-object v13, v12, Lwe;->d:Lne;

    invoke-virtual {v13}, Lne;->d()I

    move-result v13

    const/4 v14, 0x0

    :goto_49
    if-ge v14, v13, :cond_7c

    iget-object v15, v12, Lwe;->d:Lne;

    invoke-virtual {v15, v14}, Lne;->e(I)Lq42;

    move-result-object v15

    iget-object v1, v12, Lwe;->d:Lne;

    invoke-virtual {v1, v15}, Lne;->c(Lq42;)F

    move-result v1

    cmpg-float v16, v1, v4

    if-gtz v16, :cond_5c

    goto :goto_77

    :cond_5c
    const/4 v4, 0x0

    :goto_5d
    const/16 v5, 0x9

    if-ge v4, v5, :cond_77

    iget-object v5, v15, Lq42;->g:[F

    aget v5, v5, v4

    div-float/2addr v5, v1

    cmpg-float v17, v5, v7

    if-gez v17, :cond_6c

    if-eq v4, v11, :cond_6e

    :cond_6c
    if-le v4, v11, :cond_74

    :cond_6e
    iget v7, v15, Lq42;->b:I

    move v11, v4

    move v10, v7

    move v9, v8

    move v7, v5

    :cond_74
    add-int/lit8 v4, v4, 0x1

    goto :goto_5d

    :cond_77
    :goto_77
    add-int/lit8 v14, v14, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    goto :goto_49

    :cond_7c
    :goto_7c
    add-int/lit8 v8, v8, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    goto :goto_28

    :cond_81
    if-eq v9, v6, :cond_9e

    iget-object v1, v0, La21;->g:[Lwe;

    aget-object v1, v1, v9

    iget-object v4, v1, Lwe;->a:Lq42;

    iput v6, v4, Lq42;->c:I

    iget-object v4, v0, La21;->m:Ltd;

    iget-object v4, v4, Ltd;->d:Ljava/lang/Object;

    check-cast v4, [Lq42;

    aget-object v4, v4, v10

    invoke-virtual {v1, v4}, Lwe;->g(Lq42;)V

    iget-object v4, v1, Lwe;->a:Lq42;

    iput v9, v4, Lq42;->c:I

    invoke-virtual {v4, v0, v1}, Lq42;->e(La21;Lwe;)V

    goto :goto_9f

    :cond_9e
    const/4 v2, 0x1

    :goto_9f
    iget v1, v0, La21;->j:I

    div-int/lit8 v1, v1, 0x2

    if-le v3, v1, :cond_a6

    const/4 v2, 0x1

    :cond_a6
    const/4 v4, 0x0

    const/4 v5, 0x1

    goto/16 :goto_1d

    :cond_aa
    :goto_aa
    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_3

    :cond_ae
    invoke-virtual/range {p0 .. p1}, La21;->r(Lwe;)V

    invoke-virtual {v0}, La21;->i()V

    return-void
.end method

.method public final r(Lwe;)V
    .registers 18

    .prologue
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const/4 v2, 0x0

    move v3, v2

    :goto_6
    iget v4, v0, La21;->j:I

    if-ge v3, v4, :cond_11

    iget-object v4, v0, La21;->i:[Z

    aput-boolean v2, v4, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_6

    :cond_11
    move v3, v2

    move v4, v3

    :goto_13
    if-nez v3, :cond_ae

    const/4 v5, 0x1

    add-int/2addr v4, v5

    iget v6, v0, La21;->j:I

    mul-int/lit8 v6, v6, 0x2

    if-lt v4, v6, :cond_1f

    goto/16 :goto_ae

    :cond_1f
    iget-object v6, v1, Lwe;->a:Lq42;

    if-eqz v6, :cond_29

    iget-object v7, v0, La21;->i:[Z

    iget v6, v6, Lq42;->b:I

    aput-boolean v5, v7, v6

    :cond_29
    iget-object v6, v0, La21;->i:[Z

    invoke-virtual {v1, v6}, Lwe;->d([Z)Lq42;

    move-result-object v6

    if-eqz v6, :cond_3d

    iget-object v7, v0, La21;->i:[Z

    iget v8, v6, Lq42;->b:I

    aget-boolean v9, v7, v8

    if-eqz v9, :cond_3b

    goto/16 :goto_ae

    :cond_3b
    aput-boolean v5, v7, v8

    :cond_3d
    if-eqz v6, :cond_aa

    const/4 v7, -0x1

    const v8, 0x7f7fffff  # Float.MAX_VALUE

    move v9, v2

    move v10, v7

    :goto_45
    iget v11, v0, La21;->k:I

    if-ge v9, v11, :cond_95

    iget-object v11, v0, La21;->g:[Lwe;

    aget-object v11, v11, v9

    iget-object v12, v11, Lwe;->a:Lq42;

    iget v12, v12, Lq42;->l:I

    if-ne v12, v5, :cond_54

    goto :goto_91

    :cond_54
    iget-boolean v12, v11, Lwe;->e:Z

    if-eqz v12, :cond_59

    goto :goto_91

    :cond_59
    iget-object v12, v11, Lwe;->d:Lne;

    iget v13, v12, Lne;->h:I

    if-ne v13, v7, :cond_60

    goto :goto_79

    :cond_60
    move v14, v2

    :goto_61
    if-eq v13, v7, :cond_79

    iget v15, v12, Lne;->a:I

    if-ge v14, v15, :cond_79

    iget-object v15, v12, Lne;->e:[I

    aget v15, v15, v13

    iget v2, v6, Lq42;->b:I

    if-ne v15, v2, :cond_71

    move v2, v5

    goto :goto_7a

    :cond_71
    iget-object v2, v12, Lne;->f:[I

    aget v13, v2, v13

    add-int/lit8 v14, v14, 0x1

    const/4 v2, 0x0

    goto :goto_61

    :cond_79
    :goto_79
    const/4 v2, 0x0

    :goto_7a
    if-eqz v2, :cond_91

    iget-object v2, v11, Lwe;->d:Lne;

    invoke-virtual {v2, v6}, Lne;->c(Lq42;)F

    move-result v2

    const/4 v12, 0x0

    cmpg-float v12, v2, v12

    if-gez v12, :cond_91

    iget v11, v11, Lwe;->b:F

    neg-float v11, v11

    div-float/2addr v11, v2

    cmpg-float v2, v11, v8

    if-gez v2, :cond_91

    move v10, v9

    move v8, v11

    :cond_91
    :goto_91
    add-int/lit8 v9, v9, 0x1

    const/4 v2, 0x0

    goto :goto_45

    :cond_95
    if-le v10, v7, :cond_ab

    iget-object v2, v0, La21;->g:[Lwe;

    aget-object v2, v2, v10

    iget-object v5, v2, Lwe;->a:Lq42;

    iput v7, v5, Lq42;->c:I

    invoke-virtual {v2, v6}, Lwe;->g(Lq42;)V

    iget-object v5, v2, Lwe;->a:Lq42;

    iput v10, v5, Lq42;->c:I

    invoke-virtual {v5, v0, v2}, Lq42;->e(La21;Lwe;)V

    goto :goto_ab

    :cond_aa
    move v3, v5

    :cond_ab
    :goto_ab
    const/4 v2, 0x0

    goto/16 :goto_13

    :cond_ae
    :goto_ae
    return-void
.end method

.method public final s()V
    .registers 4

    .prologue
    const/4 v0, 0x0

    :goto_1
    iget v1, p0, La21;->k:I

    if-ge v0, v1, :cond_1c

    iget-object v1, p0, La21;->g:[Lwe;

    aget-object v1, v1, v0

    if-eqz v1, :cond_14

    iget-object v2, p0, La21;->m:Ltd;

    iget-object v2, v2, Ltd;->b:Ljava/lang/Object;

    check-cast v2, Lyk1;

    invoke-virtual {v2, v1}, Lyk1;->b(Ljava/lang/Object;)V

    :cond_14
    iget-object v1, p0, La21;->g:[Lwe;

    const/4 v2, 0x0

    aput-object v2, v1, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_1c
    return-void
.end method

.method public final t()V
    .registers 11

    .prologue
    const/4 v0, 0x0

    move v1, v0

    :goto_2
    iget-object v2, p0, La21;->m:Ltd;

    iget-object v3, v2, Ltd;->d:Ljava/lang/Object;

    check-cast v3, [Lq42;

    array-length v4, v3

    if-ge v1, v4, :cond_15

    aget-object v2, v3, v1

    if-eqz v2, :cond_12

    invoke-virtual {v2}, Lq42;->c()V

    :cond_12
    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    :cond_15
    iget-object v1, v2, Ltd;->c:Ljava/lang/Object;

    check-cast v1, Lyk1;

    iget-object v3, p0, La21;->n:[Lq42;

    iget v4, p0, La21;->o:I

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    array-length v5, v3

    if-le v4, v5, :cond_24

    array-length v4, v3

    :cond_24
    move v5, v0

    :goto_25
    if-ge v5, v4, :cond_39

    aget-object v6, v3, v5

    iget v7, v1, Lyk1;->b:I

    iget-object v8, v1, Lyk1;->a:[Ljava/lang/Object;

    array-length v9, v8

    if-ge v7, v9, :cond_36

    aput-object v6, v8, v7

    add-int/lit8 v7, v7, 0x1

    iput v7, v1, Lyk1;->b:I

    :cond_36
    add-int/lit8 v5, v5, 0x1

    goto :goto_25

    :cond_39
    iput v0, p0, La21;->o:I

    iget-object v1, v2, Ltd;->d:Ljava/lang/Object;

    check-cast v1, [Lq42;

    const/4 v3, 0x0

    invoke-static {v1, v3}, Ljava/util/Arrays;->fill([Ljava/lang/Object;Ljava/lang/Object;)V

    iput v0, p0, La21;->c:I

    iget-object v1, p0, La21;->d:Lzm1;

    iput v0, v1, Lzm1;->h:I

    const/4 v3, 0x0

    iput v3, v1, Lwe;->b:F

    const/4 v1, 0x1

    iput v1, p0, La21;->j:I

    move v1, v0

    :goto_50
    iget v3, p0, La21;->k:I

    if-ge v1, v3, :cond_5b

    iget-object v3, p0, La21;->g:[Lwe;

    aget-object v3, v3, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_50

    :cond_5b
    invoke-virtual {p0}, La21;->s()V

    iput v0, p0, La21;->k:I

    new-instance v0, Lwe;

    invoke-direct {v0, v2}, Lwe;-><init>(Ltd;)V

    iput-object v0, p0, La21;->p:Lwe;

    return-void
.end method
