.class public abstract La72;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final a:[Ljava/lang/String;

.field public static final b:[B


# direct methods
.method static constructor <clinit>()V
    .registers 12

    .prologue
    const/16 v0, 0x5d

    new-array v1, v0, [Ljava/lang/String;

    const/4 v2, 0x0

    move v3, v2

    :goto_6
    const/16 v4, 0x20

    if-ge v3, v4, :cond_3c

    shr-int/lit8 v4, v3, 0xc

    invoke-static {v4}, La72;->b(I)C

    move-result v4

    shr-int/lit8 v5, v3, 0x8

    invoke-static {v5}, La72;->b(I)C

    move-result v5

    shr-int/lit8 v6, v3, 0x4

    invoke-static {v6}, La72;->b(I)C

    move-result v6

    invoke-static {v3}, La72;->b(I)C

    move-result v7

    new-instance v8, Ljava/lang/StringBuilder;

    const-string v9, "\\u"

    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    aput-object v4, v1, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_6

    :cond_3c
    const-string v3, "\\\""

    const/16 v5, 0x22

    aput-object v3, v1, v5

    const-string v3, "\\\\"

    const/16 v6, 0x5c

    aput-object v3, v1, v6

    const-string v3, "\\t"

    const/16 v7, 0x9

    aput-object v3, v1, v7

    const-string v3, "\\b"

    const/16 v8, 0x8

    aput-object v3, v1, v8

    const-string v3, "\\n"

    const/16 v9, 0xa

    aput-object v3, v1, v9

    const-string v3, "\\r"

    const/16 v10, 0xd

    aput-object v3, v1, v10

    const-string v3, "\\f"

    const/16 v11, 0xc

    aput-object v3, v1, v11

    sput-object v1, La72;->a:[Ljava/lang/String;

    new-array v0, v0, [B

    :goto_6a
    if-ge v2, v4, :cond_72

    const/4 v1, 0x1

    aput-byte v1, v0, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_6a

    :cond_72
    aput-byte v5, v0, v5

    aput-byte v6, v0, v6

    const/16 v1, 0x74

    aput-byte v1, v0, v7

    const/16 v1, 0x62

    aput-byte v1, v0, v8

    const/16 v1, 0x6e

    aput-byte v1, v0, v9

    const/16 v1, 0x72

    aput-byte v1, v0, v10

    const/16 v1, 0x66

    aput-byte v1, v0, v11

    sput-object v0, La72;->b:[B

    return-void
.end method

.method public static final a(Ljava/lang/StringBuilder;Ljava/lang/String;)V
    .registers 9

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x22

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v2, 0x0

    move v3, v2

    :goto_e
    if-ge v2, v1, :cond_2a

    invoke-virtual {p1, v2}, Ljava/lang/String;->charAt(I)C

    move-result v4

    sget-object v5, La72;->a:[Ljava/lang/String;

    array-length v6, v5

    if-ge v4, v6, :cond_27

    aget-object v6, v5, v4

    if-eqz v6, :cond_27

    invoke-virtual {p0, p1, v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    aget-object v3, v5, v4

    invoke-virtual {p0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v3, v2, 0x1

    :cond_27
    add-int/lit8 v2, v2, 0x1

    goto :goto_e

    :cond_2a
    if-eqz v3, :cond_34

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    invoke-virtual {p0, p1, v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    goto :goto_37

    :cond_34
    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_37
    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    return-void
.end method

.method public static final b(I)C
    .registers 2

    .prologue
    and-int/lit8 p0, p0, 0xf

    const/16 v0, 0xa

    if-ge p0, v0, :cond_a

    add-int/lit8 p0, p0, 0x30

    :goto_8
    int-to-char p0, p0

    return p0

    :cond_a
    add-int/lit8 p0, p0, 0x57

    goto :goto_8
.end method
