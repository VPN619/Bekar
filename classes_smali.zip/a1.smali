.class public final La1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final d:La1;


# instance fields
.field public final a:Ljava/lang/Runnable;

.field public final b:Ljava/util/concurrent/Executor;

.field public c:La1;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, La1;

    const/4 v1, 0x0

    invoke-direct {v0, v1, v1}, La1;-><init>(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    sput-object v0, La1;->d:La1;

    return-void
.end method

.method public constructor <init>(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La1;->a:Ljava/lang/Runnable;

    iput-object p2, p0, La1;->b:Ljava/util/concurrent/Executor;

    return-void
.end method
