.class public final Lac0;
.super Landroidx/preference/Preference;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public N:J


# virtual methods
.method public final e()J
    .registers 3

    iget-wide v0, p0, Lac0;->N:J

    return-wide v0
.end method

.method public final m(Lzl1;)V
    .registers 2

    invoke-super {p0, p1}, Landroidx/preference/Preference;->m(Lzl1;)V

    const/4 p0, 0x0

    iput-boolean p0, p1, Lzl1;->x:Z

    return-void
.end method
