.class public final Lad1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final c:Ljava/lang/ThreadLocal;


# instance fields
.field public final a:Landroid/content/Context;

.field public final b:Lve1;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Ljava/lang/ThreadLocal;

    invoke-direct {v0}, Ljava/lang/ThreadLocal;-><init>()V

    sput-object v0, Lad1;->c:Ljava/lang/ThreadLocal;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Lve1;)V
    .registers 3

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lad1;->a:Landroid/content/Context;

    iput-object p2, p0, Lad1;->b:Lve1;

    return-void
.end method

.method public static c(Landroid/content/res/TypedArray;Landroid/content/res/Resources;I)Lac1;
    .registers 20

    .prologue
    move-object/from16 v1, p0

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v1, v2, v3}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v4

    sget-object v0, Lad1;->c:Ljava/lang/ThreadLocal;

    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/util/TypedValue;

    if-nez v5, :cond_1a

    new-instance v5, Landroid/util/TypedValue;

    invoke-direct {v5}, Landroid/util/TypedValue;-><init>()V

    invoke-virtual {v0, v5}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    :cond_1a
    const/4 v0, 0x2

    invoke-virtual {v1, v0}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x4

    if-eqz v6, :cond_4d

    invoke-virtual/range {p1 .. p2}, Landroid/content/res/Resources;->getResourcePackageName(I)Ljava/lang/String;

    move-result-object v9

    const-string v0, "j$"

    const-string v10, "java"

    invoke-virtual {v6, v10}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v10

    if-nez v10, :cond_35

    :goto_30
    invoke-static {v6, v9}, Lsz;->x(Ljava/lang/String;Ljava/lang/String;)Ljd1;

    move-result-object v0

    goto :goto_4e

    :cond_35
    :try_start_35
    invoke-virtual {v6, v7}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v0, v10}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, v9}, Lsz;->x(Ljava/lang/String;Ljava/lang/String;)Ljd1;

    move-result-object v0
    :try_end_41
    .catch Ljava/lang/RuntimeException; {:try_start_35 .. :try_end_41} :catch_42

    goto :goto_4e

    :catch_42
    move-exception v0

    invoke-virtual {v0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v10

    instance-of v10, v10, Ljava/lang/ClassNotFoundException;

    if-eqz v10, :cond_4c

    goto :goto_30

    :cond_4c
    throw v0

    :cond_4d
    const/4 v0, 0x0

    :goto_4e
    const/4 v9, 0x1

    invoke-virtual {v1, v9, v5}, Landroid/content/res/TypedArray;->getValue(ILandroid/util/TypedValue;)Z

    move-result v10

    sget-object v11, Ljd1;->f:Lpj;

    sget-object v12, Ljd1;->l:Lpj;

    sget-object v13, Ljd1;->o:Lpj;

    sget-object v14, Ljd1;->b:Lpj;

    sget-object v15, Ljd1;->i:Lpj;

    if-eqz v10, :cond_17f

    iget v10, v5, Landroid/util/TypedValue;->resourceId:I

    move/from16 v16, v3

    const-string v3, "\' for "

    const-string v8, "unsupported value \'"

    const/16 v7, 0x10

    sget-object v2, Ljd1;->c:Lpj;

    if-ne v0, v2, :cond_a6

    if-eqz v10, :cond_75

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    goto/16 :goto_182

    :cond_75
    iget v1, v5, Landroid/util/TypedValue;->type:I

    if-ne v1, v7, :cond_83

    iget v1, v5, Landroid/util/TypedValue;->data:I

    if-nez v1, :cond_83

    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    goto/16 :goto_182

    :cond_83
    new-instance v1, Lorg/xmlpull/v1/XmlPullParserException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v4, v5, Landroid/util/TypedValue;->string:Ljava/lang/CharSequence;

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljd1;->b()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ". Must be a reference to a resource."

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_a6
    if-eqz v10, :cond_d4

    if-nez v0, :cond_b1

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object v0, v2

    goto/16 :goto_182

    :cond_b1
    new-instance v1, Lorg/xmlpull/v1/XmlPullParserException;

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v4, v5, Landroid/util/TypedValue;->string:Ljava/lang/CharSequence;

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljd1;->b()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, ". You must use a \"reference\" type to reference other resources."

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v0}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    throw v1

    :cond_d4
    if-ne v0, v13, :cond_dc

    invoke-virtual {v1, v9}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v1

    goto/16 :goto_182

    :cond_dc
    iget v1, v5, Landroid/util/TypedValue;->type:I

    const/4 v2, 0x3

    if-eq v1, v2, :cond_15a

    const-string v2, "float"

    const/4 v3, 0x4

    if-eq v1, v3, :cond_14d

    const/4 v3, 0x5

    if-eq v1, v3, :cond_139

    const/16 v3, 0x12

    if-eq v1, v3, :cond_126

    if-lt v1, v7, :cond_110

    const/16 v3, 0x1f

    if-gt v1, v3, :cond_110

    if-ne v0, v15, :cond_102

    invoke-static {v5, v0, v15, v6, v2}, Lqk;->g(Landroid/util/TypedValue;Ljd1;Ljd1;Ljava/lang/String;Ljava/lang/String;)Ljd1;

    move-result-object v0

    iget v1, v5, Landroid/util/TypedValue;->data:I

    int-to-float v1, v1

    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v1

    goto/16 :goto_182

    :cond_102
    const-string v1, "integer"

    invoke-static {v5, v0, v14, v6, v1}, Lqk;->g(Landroid/util/TypedValue;Ljd1;Ljd1;Ljava/lang/String;Ljava/lang/String;)Ljd1;

    move-result-object v0

    iget v1, v5, Landroid/util/TypedValue;->data:I

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    goto/16 :goto_182

    :cond_110
    new-instance v0, Lorg/xmlpull/v1/XmlPullParserException;

    iget v1, v5, Landroid/util/TypedValue;->type:I

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "unsupported argument type "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_126
    const-string v1, "boolean"

    invoke-static {v5, v0, v12, v6, v1}, Lqk;->g(Landroid/util/TypedValue;Ljd1;Ljd1;Ljava/lang/String;Ljava/lang/String;)Ljd1;

    move-result-object v0

    iget v1, v5, Landroid/util/TypedValue;->data:I

    if-eqz v1, :cond_132

    move v1, v9

    goto :goto_134

    :cond_132
    move/from16 v1, v16

    :goto_134
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    goto :goto_182

    :cond_139
    const-string v1, "dimension"

    invoke-static {v5, v0, v14, v6, v1}, Lqk;->g(Landroid/util/TypedValue;Ljd1;Ljd1;Ljava/lang/String;Ljava/lang/String;)Ljd1;

    move-result-object v0

    invoke-virtual/range {p1 .. p1}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v1

    invoke-virtual {v5, v1}, Landroid/util/TypedValue;->getDimension(Landroid/util/DisplayMetrics;)F

    move-result v1

    float-to-int v1, v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    goto :goto_182

    :cond_14d
    invoke-static {v5, v0, v15, v6, v2}, Lqk;->g(Landroid/util/TypedValue;Ljd1;Ljd1;Ljava/lang/String;Ljava/lang/String;)Ljd1;

    move-result-object v0

    invoke-virtual {v5}, Landroid/util/TypedValue;->getFloat()F

    move-result v1

    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v1

    goto :goto_182

    :cond_15a
    iget-object v1, v5, Landroid/util/TypedValue;->string:Ljava/lang/CharSequence;

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    if-nez v0, :cond_17a

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_165
    invoke-virtual {v14, v1}, Lpj;->d(Ljava/lang/String;)Ljava/lang/Object;
    :try_end_168
    .catch Ljava/lang/IllegalArgumentException; {:try_start_165 .. :try_end_168} :catch_16a

    move-object v0, v14

    goto :goto_17a

    :catch_16a
    :try_start_16a
    invoke-virtual {v11, v1}, Lpj;->d(Ljava/lang/String;)Ljava/lang/Object;
    :try_end_16d
    .catch Ljava/lang/IllegalArgumentException; {:try_start_16a .. :try_end_16d} :catch_16f

    move-object v0, v11

    goto :goto_17a

    :catch_16f
    :try_start_16f
    invoke-virtual {v15, v1}, Lpj;->d(Ljava/lang/String;)Ljava/lang/Object;
    :try_end_172
    .catch Ljava/lang/IllegalArgumentException; {:try_start_16f .. :try_end_172} :catch_174

    move-object v0, v15

    goto :goto_17a

    :catch_174
    :try_start_174
    invoke-virtual {v12, v1}, Lpj;->d(Ljava/lang/String;)Ljava/lang/Object;
    :try_end_177
    .catch Ljava/lang/IllegalArgumentException; {:try_start_174 .. :try_end_177} :catch_179

    move-object v0, v12

    goto :goto_17a

    :catch_179
    move-object v0, v13

    :cond_17a
    :goto_17a
    invoke-virtual {v0, v1}, Ljd1;->d(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    goto :goto_182

    :cond_17f
    move/from16 v16, v3

    const/4 v1, 0x0

    :goto_182
    if-eqz v1, :cond_186

    move v3, v9

    goto :goto_189

    :cond_186
    move/from16 v3, v16

    const/4 v1, 0x0

    :goto_189
    if-eqz v0, :cond_18c

    goto :goto_18d

    :cond_18c
    const/4 v0, 0x0

    :goto_18d
    if-nez v0, :cond_28a

    instance-of v0, v1, Ljava/lang/Integer;

    if-eqz v0, :cond_195

    move-object v8, v14

    goto :goto_1cd

    :cond_195
    instance-of v0, v1, [I

    if-eqz v0, :cond_19c

    sget-object v8, Ljd1;->d:Loj;

    goto :goto_1cd

    :cond_19c
    instance-of v0, v1, Ljava/lang/Long;

    if-eqz v0, :cond_1a2

    move-object v8, v11

    goto :goto_1cd

    :cond_1a2
    instance-of v0, v1, [J

    if-eqz v0, :cond_1a9

    sget-object v8, Ljd1;->g:Loj;

    goto :goto_1cd

    :cond_1a9
    instance-of v0, v1, Ljava/lang/Float;

    if-eqz v0, :cond_1af

    move-object v8, v15

    goto :goto_1cd

    :cond_1af
    instance-of v0, v1, [F

    if-eqz v0, :cond_1b6

    sget-object v8, Ljd1;->j:Loj;

    goto :goto_1cd

    :cond_1b6
    instance-of v0, v1, Ljava/lang/Boolean;

    if-eqz v0, :cond_1bc

    move-object v8, v12

    goto :goto_1cd

    :cond_1bc
    instance-of v0, v1, [Z

    if-eqz v0, :cond_1c3

    sget-object v8, Ljd1;->m:Loj;

    goto :goto_1cd

    :cond_1c3
    instance-of v0, v1, Ljava/lang/String;

    if-nez v0, :cond_1cc

    if-nez v1, :cond_1ca

    goto :goto_1cc

    :cond_1ca
    const/4 v8, 0x0

    goto :goto_1cd

    :cond_1cc
    :goto_1cc
    move-object v8, v13

    :goto_1cd
    if-nez v8, :cond_289

    instance-of v0, v1, [Ljava/lang/Object;

    if-eqz v0, :cond_1de

    move-object v0, v1

    check-cast v0, [Ljava/lang/Object;

    instance-of v0, v0, [Ljava/lang/String;

    if-eqz v0, :cond_1de

    sget-object v0, Ljd1;->p:Loj;

    goto/16 :goto_28a

    :cond_1de
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->isArray()Z

    move-result v0

    if-eqz v0, :cond_210

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-class v2, Landroid/os/Parcelable;

    invoke-virtual {v2, v0}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    if-eqz v0, :cond_210

    new-instance v0, Lfd1;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {v0, v2}, Lfd1;-><init>(Ljava/lang/Class;)V

    goto/16 :goto_28a

    :cond_210
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->isArray()Z

    move-result v0

    if-eqz v0, :cond_23e

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-class v2, Ljava/io/Serializable;

    invoke-virtual {v2, v0}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    if-eqz v0, :cond_23e

    new-instance v0, Lhd1;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {v0, v2}, Lhd1;-><init>(Ljava/lang/Class;)V

    goto :goto_28a

    :cond_23e
    instance-of v0, v1, Landroid/os/Parcelable;

    if-eqz v0, :cond_24c

    new-instance v0, Lgd1;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-direct {v0, v2}, Lgd1;-><init>(Ljava/lang/Class;)V

    goto :goto_28a

    :cond_24c
    instance-of v0, v1, Ljava/lang/Enum;

    if-eqz v0, :cond_25a

    new-instance v0, Led1;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-direct {v0, v2}, Led1;-><init>(Ljava/lang/Class;)V

    goto :goto_28a

    :cond_25a
    instance-of v0, v1, Ljava/io/Serializable;

    if-eqz v0, :cond_268

    new-instance v0, Lid1;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    invoke-direct {v0, v2}, Lid1;-><init>(Ljava/lang/Class;)V

    goto :goto_28a

    :cond_268
    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Object of type "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " is not supported for navigation arguments."

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_289
    move-object v0, v8

    :cond_28a
    :goto_28a
    new-instance v2, Lac1;

    invoke-direct {v2, v0, v4, v1, v3}, Lac1;-><init>(Ljd1;ZLjava/lang/Object;Z)V

    return-object v2
.end method


# virtual methods
.method public final a(Landroid/content/res/Resources;Landroid/content/res/XmlResourceParser;Landroid/util/AttributeSet;I)Luc1;
    .registers 33

    .prologue
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p3

    move/from16 v3, p4

    invoke-interface/range {p2 .. p2}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v5, v0, Lad1;->b:Lve1;

    invoke-virtual {v5, v4}, Lve1;->b(Ljava/lang/String;)Lue1;

    move-result-object v4

    invoke-virtual {v4}, Lue1;->a()Luc1;

    move-result-object v4

    iget-object v5, v0, Lad1;->a:Landroid/content/Context;

    invoke-virtual {v4, v5, v2}, Luc1;->e(Landroid/content/Context;Landroid/util/AttributeSet;)V

    iget-object v6, v4, Luc1;->b:Lz4;

    invoke-interface/range {p2 .. p2}, Lorg/xmlpull/v1/XmlPullParser;->getDepth()I

    move-result v7

    const/4 v8, 0x1

    add-int/2addr v7, v8

    :goto_26
    invoke-interface/range {p2 .. p2}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result v9

    if-eq v9, v8, :cond_27e

    invoke-interface/range {p2 .. p2}, Lorg/xmlpull/v1/XmlPullParser;->getDepth()I

    move-result v10

    const/4 v11, 0x3

    if-ge v10, v7, :cond_35

    if-eq v9, v11, :cond_27e

    :cond_35
    const/4 v12, 0x2

    if-eq v9, v12, :cond_39

    goto :goto_26

    :cond_39
    if-le v10, v7, :cond_3c

    goto :goto_26

    :cond_3c
    invoke-interface/range {p2 .. p2}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v9

    const-string v10, "argument"

    invoke-virtual {v10, v9}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v13

    const-string v14, "Arguments must have a name"

    sget-object v15, Ljp1;->b:[I

    const/4 v12, 0x0

    if-eqz v13, :cond_72

    invoke-virtual {v1, v2, v15}, Landroid/content/res/Resources;->obtainAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v9, v12}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v10

    if-eqz v10, :cond_6c

    invoke-static {v9, v1, v3}, Lad1;->c(Landroid/content/res/TypedArray;Landroid/content/res/Resources;I)Lac1;

    move-result-object v11

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v12, v6, Lz4;->e:Ljava/lang/Object;

    check-cast v12, Ljava/util/LinkedHashMap;

    invoke-interface {v12, v10, v11}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v9}, Landroid/content/res/TypedArray;->recycle()V

    goto :goto_26

    :cond_6c
    new-instance v0, Lorg/xmlpull/v1/XmlPullParserException;

    invoke-direct {v0, v14}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_72
    const-string v13, "deepLink"

    invoke-virtual {v13, v9}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v13

    const/16 v16, 0x0

    if-eqz v13, :cond_130

    sget-object v9, Ljp1;->c:[I

    invoke-virtual {v1, v2, v9}, Landroid/content/res/Resources;->obtainAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v9, v11}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v8}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v11

    const/4 v13, 0x2

    invoke-virtual {v9, v13}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v13

    if-eqz v10, :cond_9a

    invoke-virtual {v10}, Ljava/lang/String;->length()I

    move-result v14

    if-nez v14, :cond_aa

    :cond_9a
    if-eqz v11, :cond_a2

    invoke-virtual {v11}, Ljava/lang/String;->length()I

    move-result v14

    if-nez v14, :cond_aa

    :cond_a2
    if-eqz v13, :cond_128

    invoke-virtual {v13}, Ljava/lang/String;->length()I

    move-result v14

    if-eqz v14, :cond_128

    :cond_aa
    const-string v14, "${applicationId}"

    if-eqz v10, :cond_ba

    invoke-virtual {v5}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v10, v14, v15, v12}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v10

    goto :goto_bc

    :cond_ba
    move-object/from16 v10, v16

    :goto_bc
    if-eqz v11, :cond_dd

    invoke-virtual {v11}, Ljava/lang/String;->length()I

    move-result v15

    if-nez v15, :cond_c5

    goto :goto_dd

    :cond_c5
    invoke-virtual {v5}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v11, v14, v15, v12}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/String;->length()I

    move-result v15

    if-lez v15, :cond_d7

    goto :goto_df

    :cond_d7
    const-string v0, "The NavDeepLink cannot have an empty action."

    invoke-static {v0}, Lz6;->s(Ljava/lang/String;)V

    return-object v16

    :cond_dd
    :goto_dd
    move-object/from16 v11, v16

    :goto_df
    if-eqz v13, :cond_ed

    invoke-virtual {v5}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v13, v14, v15, v12}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v13

    goto :goto_ef

    :cond_ed
    move-object/from16 v13, v16

    :goto_ef
    new-instance v14, Lsc1;

    invoke-direct {v14, v10, v11, v13}, Lsc1;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v11, v6, Lz4;->e:Ljava/lang/Object;

    check-cast v11, Ljava/util/LinkedHashMap;

    new-instance v13, Lvc1;

    invoke-direct {v13, v14, v12}, Lvc1;-><init>(Lsc1;I)V

    invoke-static {v11, v13}, Lmd3;->E(Ljava/util/Map;Lbk0;)Ljava/util/ArrayList;

    move-result-object v11

    invoke-virtual {v11}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v12

    if-eqz v12, :cond_116

    iget-object v10, v6, Lz4;->a:Ljava/lang/Object;

    check-cast v10, Ljava/util/ArrayList;

    invoke-virtual {v10, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v9}, Landroid/content/res/TypedArray;->recycle()V

    goto/16 :goto_26

    :cond_116
    const-string v0, "Deep link "

    const-string v1, " can\'t be used to open destination "

    invoke-static {v0, v10, v1}, Lrt2;->o(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    iget-object v1, v6, Lz4;->c:Ljava/lang/Object;

    check-cast v1, Luc1;

    const-string v2, ".\nFollowing required arguments are missing: "

    invoke-static {v0, v1, v2, v11}, Lf71;->m(Ljava/lang/StringBuilder;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    return-object v16

    :cond_128
    new-instance v0, Lorg/xmlpull/v1/XmlPullParserException;

    const-string v1, "Every <deepLink> must include at least one of app:uri, app:action, or app:mimeType"

    invoke-direct {v0, v1}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_130
    const-string v13, "action"

    invoke-virtual {v13, v9}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_241

    sget-object v9, Ljp1;->a:[I

    invoke-virtual {v5, v2, v9, v12, v12}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    move-result-object v9

    invoke-virtual {v9, v12, v12}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v13

    invoke-virtual {v9, v8, v12}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v11

    move/from16 v17, v8

    new-instance v8, Lzb1;

    invoke-direct {v8, v11}, Lzb1;-><init>(I)V

    const/4 v11, 0x4

    invoke-virtual {v9, v11, v12}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v19

    const/16 v11, 0xa

    invoke-virtual {v9, v11, v12}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v20

    const/4 v11, 0x7

    const/4 v12, -0x1

    invoke-virtual {v9, v11, v12}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v21

    const/16 v11, 0x8

    const/4 v12, 0x0

    invoke-virtual {v9, v11, v12}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v22

    const/16 v11, 0x9

    invoke-virtual {v9, v11, v12}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    move-result v23

    const/4 v11, 0x2

    const/4 v12, -0x1

    invoke-virtual {v9, v11, v12}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v24

    const/4 v11, 0x3

    invoke-virtual {v9, v11, v12}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v25

    const/4 v11, 0x5

    invoke-virtual {v9, v11, v12}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v26

    const/4 v11, 0x6

    invoke-virtual {v9, v11, v12}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v27

    new-instance v18, Lcd1;

    invoke-direct/range {v18 .. v27}, Lcd1;-><init>(ZZIZZIIII)V

    move-object/from16 v11, v18

    iput-object v11, v8, Lzb1;->b:Lcd1;

    const/4 v12, 0x0

    new-array v11, v12, [Ldj1;

    invoke-static {v11, v12}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v11

    check-cast v11, [Ldj1;

    invoke-static {v11}, Lnp3;->q([Ldj1;)Landroid/os/Bundle;

    move-result-object v11

    invoke-interface/range {p2 .. p2}, Lorg/xmlpull/v1/XmlPullParser;->getDepth()I

    move-result v12

    add-int/lit8 v12, v12, 0x1

    move-object/from16 v18, v5

    :goto_19e
    invoke-interface/range {p2 .. p2}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result v5

    move-object/from16 v19, v6

    move/from16 v6, v17

    if-eq v5, v6, :cond_1f7

    invoke-interface/range {p2 .. p2}, Lorg/xmlpull/v1/XmlPullParser;->getDepth()I

    move-result v6

    move/from16 v20, v7

    if-ge v6, v12, :cond_1b3

    const/4 v7, 0x3

    if-eq v5, v7, :cond_1f9

    :cond_1b3
    const/4 v7, 0x2

    if-eq v5, v7, :cond_1bd

    :goto_1b6
    move-object/from16 v6, v19

    move/from16 v7, v20

    const/16 v17, 0x1

    goto :goto_19e

    :cond_1bd
    if-le v6, v12, :cond_1c0

    goto :goto_1b6

    :cond_1c0
    invoke-interface/range {p2 .. p2}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v10, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_1ee

    invoke-virtual {v1, v2, v15}, Landroid/content/res/Resources;->obtainAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v6, 0x0

    invoke-virtual {v5, v6}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v7

    if-eqz v7, :cond_1f1

    invoke-static {v5, v1, v3}, Lad1;->c(Landroid/content/res/TypedArray;Landroid/content/res/Resources;I)Lac1;

    move-result-object v6

    iget-boolean v3, v6, Lac1;->c:Z

    if-eqz v3, :cond_1eb

    if-eqz v3, :cond_1eb

    iget-object v3, v6, Lac1;->d:Ljava/lang/Object;

    if-eqz v3, :cond_1eb

    iget-object v6, v6, Lac1;->a:Ljd1;

    invoke-virtual {v6, v11, v7, v3}, Ljd1;->e(Landroid/os/Bundle;Ljava/lang/String;Ljava/lang/Object;)V

    :cond_1eb
    invoke-virtual {v5}, Landroid/content/res/TypedArray;->recycle()V

    :cond_1ee
    move/from16 v3, p4

    goto :goto_1b6

    :cond_1f1
    new-instance v0, Lorg/xmlpull/v1/XmlPullParserException;

    invoke-direct {v0, v14}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1f7
    move/from16 v20, v7

    :cond_1f9
    invoke-virtual {v11}, Landroid/os/BaseBundle;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_201

    iput-object v11, v8, Lzb1;->c:Landroid/os/Bundle;

    :cond_201
    instance-of v3, v4, Lc3;

    if-nez v3, :cond_220

    if-eqz v13, :cond_21a

    iget-object v3, v4, Luc1;->e:Lv42;

    invoke-virtual {v3, v13, v8}, Lv42;->c(ILjava/lang/Object;)V

    invoke-virtual {v9}, Landroid/content/res/TypedArray;->recycle()V

    :cond_20f
    :goto_20f
    move/from16 v3, p4

    move-object/from16 v5, v18

    move-object/from16 v6, v19

    move/from16 v7, v20

    const/4 v8, 0x1

    goto/16 :goto_26

    :cond_21a
    const-string v0, "Cannot have an action with actionId 0"

    invoke-static {v0}, Lz6;->s(Ljava/lang/String;)V

    return-object v16

    :cond_220
    new-instance v0, Ljava/lang/UnsupportedOperationException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Cannot add action "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v13}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, " to "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v2, " as it does not support actions, indicating that it is a terminal destination in your navigation graph and will never trigger actions."

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_241
    move-object/from16 v18, v5

    move-object/from16 v19, v6

    move/from16 v20, v7

    const-string v3, "include"

    invoke-virtual {v3, v9}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_26f

    instance-of v3, v4, Lwc1;

    if-eqz v3, :cond_26f

    sget-object v3, Lip1;->c:[I

    invoke-virtual {v1, v2, v3}, Landroid/content/res/Resources;->obtainAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v12, 0x0

    invoke-virtual {v3, v12, v12}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v5

    move-object v6, v4

    check-cast v6, Lwc1;

    invoke-virtual {v0, v5}, Lad1;->b(I)Lwc1;

    move-result-object v5

    invoke-virtual {v6, v5}, Lwc1;->f(Luc1;)V

    invoke-virtual {v3}, Landroid/content/res/TypedArray;->recycle()V

    goto :goto_20f

    :cond_26f
    instance-of v3, v4, Lwc1;

    if-eqz v3, :cond_20f

    move-object v3, v4

    check-cast v3, Lwc1;

    invoke-virtual/range {p0 .. p4}, Lad1;->a(Landroid/content/res/Resources;Landroid/content/res/XmlResourceParser;Landroid/util/AttributeSet;I)Luc1;

    move-result-object v5

    invoke-virtual {v3, v5}, Lwc1;->f(Luc1;)V

    goto :goto_20f

    :cond_27e
    return-object v4
.end method

.method public final b(I)Lwc1;
    .registers 8

    .prologue
    iget-object v0, p0, Lad1;->a:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getXml(I)Landroid/content/res/XmlResourceParser;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v1}, Landroid/util/Xml;->asAttributeSet(Lorg/xmlpull/v1/XmlPullParser;)Landroid/util/AttributeSet;

    move-result-object v2

    :cond_11
    :try_start_11
    invoke-interface {v1}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result v3

    const/4 v4, 0x2

    if-eq v3, v4, :cond_1b

    const/4 v5, 0x1

    if-ne v3, v5, :cond_11

    :cond_1b
    if-ne v3, v4, :cond_56

    invoke-interface {v1}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0, v0, v1, v2, p1}, Lad1;->a(Landroid/content/res/Resources;Landroid/content/res/XmlResourceParser;Landroid/util/AttributeSet;I)Luc1;

    move-result-object p0

    instance-of v2, p0, Lwc1;

    if-eqz v2, :cond_36

    check-cast p0, Lwc1;
    :try_end_2e
    .catch Ljava/lang/Exception; {:try_start_11 .. :try_end_2e} :catch_34
    .catchall {:try_start_11 .. :try_end_2e} :catchall_32

    invoke-interface {v1}, Landroid/content/res/XmlResourceParser;->close()V

    return-object p0

    :catchall_32
    move-exception p0

    goto :goto_85

    :catch_34
    move-exception p0

    goto :goto_5e

    :cond_36
    :try_start_36
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Root element <"

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "> did not inflate into a NavGraph"

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    new-instance v2, Ljava/lang/IllegalArgumentException;

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v2, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v2

    :cond_56
    new-instance p0, Lorg/xmlpull/v1/XmlPullParserException;

    const-string v2, "No start tag found"

    invoke-direct {p0, v2}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    throw p0
    :try_end_5e
    .catch Ljava/lang/Exception; {:try_start_36 .. :try_end_5e} :catch_34
    .catchall {:try_start_36 .. :try_end_5e} :catchall_32

    :goto_5e
    :try_start_5e
    new-instance v2, Ljava/lang/RuntimeException;

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "Exception inflating "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Landroid/content/res/Resources;->getResourceName(I)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, " line "

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-interface {v1}, Lorg/xmlpull/v1/XmlPullParser;->getLineNumber()I

    move-result p1

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v2, p1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v2
    :try_end_85
    .catchall {:try_start_5e .. :try_end_85} :catchall_32

    :goto_85
    invoke-interface {v1}, Landroid/content/res/XmlResourceParser;->close()V

    throw p0
.end method
