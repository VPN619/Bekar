.class public final La10;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lbk0;


# instance fields
.field public t:I


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    check-cast p1, Lvx;

    new-instance p0, La10;

    const/4 v0, 0x1

    invoke-direct {p0, v0, p1}, Lm82;-><init>(ILvx;)V

    sget-object p1, Lrg2;->a:Lrg2;

    invoke-virtual {p0, p1}, La10;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .prologue
    iget v0, p0, La10;->t:I

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_14

    if-ne v0, v2, :cond_e

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0

    :cond_e
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v1

    :cond_14
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iput v2, p0, La10;->t:I

    throw v1
.end method
