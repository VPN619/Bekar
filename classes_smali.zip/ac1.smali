.class public final Lac1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Ljd1;

.field public final b:Z

.field public final c:Z

.field public final d:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Ljd1;ZLjava/lang/Object;Z)V
    .registers 7

    .prologue
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iget-boolean v0, p1, Ljd1;->a:Z

    const/4 v1, 0x0

    if-nez v0, :cond_19

    if-nez p2, :cond_b

    goto :goto_19

    :cond_b
    invoke-virtual {p1}, Ljd1;->b()Ljava/lang/String;

    move-result-object p0

    const-string p1, " does not allow nullable values"

    invoke-virtual {p0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->v(Ljava/lang/Object;)V

    throw v1

    :cond_19
    :goto_19
    if-nez p2, :cond_2c

    if-eqz p4, :cond_2c

    if-eqz p3, :cond_20

    goto :goto_2c

    :cond_20
    invoke-virtual {p1}, Ljd1;->b()Ljava/lang/String;

    move-result-object p0

    const-string p1, " has null value but is not nullable."

    const-string p2, "Argument with type "

    invoke-static {p0, p1, p2}, Lf71;->h(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    throw v1

    :cond_2c
    :goto_2c
    iput-object p1, p0, Lac1;->a:Ljd1;

    iput-boolean p2, p0, Lac1;->b:Z

    iput-object p3, p0, Lac1;->d:Ljava/lang/Object;

    iput-boolean p4, p0, Lac1;->c:Z

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    .prologue
    if-ne p0, p1, :cond_3

    goto :goto_36

    :cond_3
    if-eqz p1, :cond_38

    const-class v0, Lac1;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    if-eq v0, v1, :cond_e

    goto :goto_38

    :cond_e
    check-cast p1, Lac1;

    iget-boolean v0, p0, Lac1;->b:Z

    iget-boolean v1, p1, Lac1;->b:Z

    if-eq v0, v1, :cond_17

    goto :goto_38

    :cond_17
    iget-boolean v0, p0, Lac1;->c:Z

    iget-boolean v1, p1, Lac1;->c:Z

    if-eq v0, v1, :cond_1e

    goto :goto_38

    :cond_1e
    iget-object v0, p0, Lac1;->a:Ljd1;

    iget-object v1, p1, Lac1;->a:Ljd1;

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_29

    goto :goto_38

    :cond_29
    iget-object p1, p1, Lac1;->d:Ljava/lang/Object;

    iget-object p0, p0, Lac1;->d:Ljava/lang/Object;

    if-eqz p0, :cond_34

    invoke-virtual {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    return p0

    :cond_34
    if-nez p1, :cond_38

    :goto_36
    const/4 p0, 0x1

    return p0

    :cond_38
    :goto_38
    const/4 p0, 0x0

    return p0
.end method

.method public final hashCode()I
    .registers 3

    .prologue
    iget-object v0, p0, Lac1;->a:Ljd1;

    invoke-virtual {v0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    iget-boolean v1, p0, Lac1;->b:Z

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-boolean v1, p0, Lac1;->c:Z

    add-int/2addr v0, v1

    mul-int/lit8 v0, v0, 0x1f

    iget-object p0, p0, Lac1;->d:Ljava/lang/Object;

    if-eqz p0, :cond_1b

    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    move-result p0

    goto :goto_1c

    :cond_1b
    const/4 p0, 0x0

    :goto_1c
    add-int/2addr v0, p0

    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 4

    .prologue
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-class v1, Lac1;

    invoke-static {v1}, Lxr1;->a(Ljava/lang/Class;)Llq;

    move-result-object v1

    invoke-virtual {v1}, Llq;->c()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, " Type: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Lac1;->a:Ljd1;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, " Nullable: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-boolean v2, p0, Lac1;->b:Z

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-boolean v1, p0, Lac1;->c:Z

    if-eqz v1, :cond_4f

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, " DefaultValue: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object p0, p0, Lac1;->d:Ljava/lang/Object;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_4f
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
