.class public final La42;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public final synthetic t:I

.field public u:I

.field public synthetic v:Ljava/lang/Object;

.field public final synthetic w:Lpk0;


# direct methods
.method public constructor <init>(Lpk0;Ljava/lang/Object;Lvx;)V
    .registers 5

    const/4 v0, 0x0

    iput v0, p0, La42;->t:I

    iput-object p1, p0, La42;->w:Lpk0;

    iput-object p2, p0, La42;->v:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lm82;-><init>(ILvx;)V

    return-void
.end method

.method public constructor <init>(Lpk0;Lvx;)V
    .registers 4

    const/4 v0, 0x1

    iput v0, p0, La42;->t:I

    iput-object p1, p0, La42;->w:Lpk0;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 5

    .prologue
    iget v0, p0, La42;->t:I

    iget-object v1, p0, La42;->w:Lpk0;

    packed-switch v0, :pswitch_data_18

    new-instance p0, La42;

    invoke-direct {p0, v1, p1}, La42;-><init>(Lpk0;Lvx;)V

    iput-object p2, p0, La42;->v:Ljava/lang/Object;

    return-object p0

    :pswitch_f  #0x0
    new-instance p2, La42;

    iget-object p0, p0, La42;->v:Ljava/lang/Object;

    invoke-direct {p2, v1, p0, p1}, La42;-><init>(Lpk0;Ljava/lang/Object;Lvx;)V

    return-object p2

    nop

    :pswitch_data_18
    .packed-switch 0x0
        :pswitch_f  #00000000
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .prologue
    iget v0, p0, La42;->t:I

    sget-object v1, Lrg2;->a:Lrg2;

    packed-switch v0, :pswitch_data_28

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    new-instance v0, La42;

    iget-object p0, p0, La42;->w:Lpk0;

    invoke-direct {v0, p0, p2}, La42;-><init>(Lpk0;Lvx;)V

    iput-object p1, v0, La42;->v:Ljava/lang/Object;

    invoke-virtual {v0, v1}, La42;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_19  #0x0
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    invoke-virtual {p0, p2, p1}, La42;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, La42;

    invoke-virtual {p0, v1}, La42;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_data_28
    .packed-switch 0x0
        :pswitch_19  #00000000
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 8

    .prologue
    iget v0, p0, La42;->t:I

    iget-object v1, p0, La42;->w:Lpk0;

    const-string v2, "call to \'resume\' before \'invoke\' with coroutine"

    sget-object v3, Lwy;->a:Lwy;

    const/4 v4, 0x1

    const/4 v5, 0x0

    packed-switch v0, :pswitch_data_54

    iget v0, p0, La42;->u:I

    if-eqz v0, :cond_1c

    if-ne v0, v4, :cond_17

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_33

    :cond_17
    invoke-static {v2}, Lz6;->w(Ljava/lang/String;)V

    move-object v3, v5

    goto :goto_35

    :cond_1c
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, La42;->v:Ljava/lang/Object;

    check-cast p1, Lvy;

    invoke-static {}, Lads_mobile_sdk/hh3;->b()Lads_mobile_sdk/gh3;

    move-result-object v0

    invoke-static {v0, v5}, Lads_mobile_sdk/hh3;->a(Lads_mobile_sdk/gh3;Lads_mobile_sdk/rg3;)Lads_mobile_sdk/rg3;

    iput v4, p0, La42;->u:I

    invoke-interface {v1, p1, p0}, Lpk0;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v3, :cond_33

    goto :goto_35

    :cond_33
    :goto_33
    sget-object v3, Lrg2;->a:Lrg2;

    :goto_35
    return-object v3

    :pswitch_36  #0x0
    iget v0, p0, La42;->u:I

    if-eqz v0, :cond_45

    if-ne v0, v4, :cond_40

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_53

    :cond_40
    invoke-static {v2}, Lz6;->w(Ljava/lang/String;)V

    move-object p1, v5

    goto :goto_53

    :cond_45
    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    iget-object p1, p0, La42;->v:Ljava/lang/Object;

    iput v4, p0, La42;->u:I

    invoke-interface {v1, p1, p0}, Lpk0;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v3, :cond_53

    move-object p1, v3

    :cond_53
    :goto_53
    return-object p1

    :pswitch_data_54
    .packed-switch 0x0
        :pswitch_36  #00000000
    .end packed-switch
.end method
