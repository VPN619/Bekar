.class public final La92;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Ly82;

.field public final b:Ljava/util/ArrayList;

.field public c:Lxr0;

.field public d:Lxr0;

.field public e:I


# direct methods
.method public constructor <init>(Landroid/view/ViewGroup;)V
    .registers 6

    .prologue
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, La92;->b:Ljava/util/ArrayList;

    sget-object v0, Lxr0;->e:Lxr0;

    iput-object v0, p0, La92;->c:Lxr0;

    iput-object v0, p0, La92;->d:Lxr0;

    invoke-virtual {p1}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    instance-of v1, v0, Landroid/graphics/drawable/ColorDrawable;

    const/4 v2, 0x0

    if-eqz v1, :cond_20

    check-cast v0, Landroid/graphics/drawable/ColorDrawable;

    invoke-virtual {v0}, Landroid/graphics/drawable/ColorDrawable;->getColor()I

    move-result v0

    goto :goto_21

    :cond_20
    move v0, v2

    :goto_21
    iput v0, p0, La92;->e:I

    new-instance v0, Ly82;

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, p0, v1, p1}, Ly82;-><init>(La92;Landroid/content/Context;Landroid/view/ViewGroup;)V

    iput-object v0, p0, La92;->a:Ly82;

    const/4 v1, 0x1

    invoke-virtual {v0, v1}, Landroid/view/View;->setWillNotDraw(Z)V

    new-instance v1, Lah;

    const/16 v3, 0x15

    invoke-direct {v1, v3, p0}, Lah;-><init>(ILjava/lang/Object;)V

    sget-object v3, Lek2;->a:Ljava/util/WeakHashMap;

    invoke-static {v0, v1}, Lwj2;->k(Landroid/view/View;Lih1;)V

    new-instance v1, Lz82;

    invoke-direct {v1, p0}, Lz82;-><init>(La92;)V

    invoke-static {v0, v1}, Lap2;->a(Landroid/view/View;Lso2;)V

    invoke-virtual {p1, v0, v2}, Landroid/view/ViewGroup;->addView(Landroid/view/View;I)V

    return-void
.end method
