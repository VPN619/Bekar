.class public final Laa2;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Landroid/content/res/ColorStateList;

.field public final b:Ljava/lang/String;

.field public c:Ljava/lang/String;

.field public final d:I

.field public final e:I

.field public final f:F

.field public final g:F

.field public final h:F

.field public final i:Z

.field public final j:F

.field public final k:Landroid/content/res/ColorStateList;

.field public l:F

.field public final m:I

.field public n:Z

.field public o:Z

.field public p:Landroid/graphics/Typeface;


# direct methods
.method public constructor <init>(Landroid/content/Context;I)V
    .registers 10

    .prologue
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-boolean v0, p0, Laa2;->n:Z

    iput-boolean v0, p0, Laa2;->o:Z

    sget-object v1, Lmp1;->w:[I

    invoke-virtual {p1, p2, v1}, Landroid/content/Context;->obtainStyledAttributes(I[I)Landroid/content/res/TypedArray;

    move-result-object v1

    const/4 v2, 0x0

    invoke-virtual {v1, v0, v2}, Landroid/content/res/TypedArray;->getDimension(IF)F

    move-result v3

    iput v3, p0, Laa2;->l:F

    const/4 v3, 0x3

    invoke-static {p1, v1, v3}, Llk;->n(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object v4

    iput-object v4, p0, Laa2;->k:Landroid/content/res/ColorStateList;

    const/4 v4, 0x4

    invoke-static {p1, v1, v4}, Llk;->n(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    const/4 v4, 0x5

    invoke-static {p1, v1, v4}, Llk;->n(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    const/4 v4, 0x2

    invoke-virtual {v1, v4, v0}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v4

    iput v4, p0, Laa2;->d:I

    const/4 v4, 0x1

    invoke-virtual {v1, v4, v4}, Landroid/content/res/TypedArray;->getInt(II)I

    move-result v5

    iput v5, p0, Laa2;->e:I

    const/16 v5, 0xc

    invoke-virtual {v1, v5}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result v6

    if-eqz v6, :cond_3b

    goto :goto_3d

    :cond_3b
    const/16 v5, 0xa

    :goto_3d
    invoke-virtual {v1, v5, v0}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v6

    iput v6, p0, Laa2;->m:I

    invoke-virtual {v1, v5}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v5

    iput-object v5, p0, Laa2;->b:Ljava/lang/String;

    const/16 v5, 0xe

    invoke-virtual {v1, v5, v0}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    const/4 v5, 0x6

    invoke-static {p1, v1, v5}, Llk;->n(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object v5

    iput-object v5, p0, Laa2;->a:Landroid/content/res/ColorStateList;

    const/4 v5, 0x7

    invoke-virtual {v1, v5, v2}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v5

    iput v5, p0, Laa2;->f:F

    const/16 v5, 0x8

    invoke-virtual {v1, v5, v2}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v5

    iput v5, p0, Laa2;->g:F

    const/16 v5, 0x9

    invoke-virtual {v1, v5, v2}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result v5

    iput v5, p0, Laa2;->h:F

    invoke-virtual {v1}, Landroid/content/res/TypedArray;->recycle()V

    sget-object v1, Lcp1;->D:[I

    invoke-virtual {p1, p2, v1}, Landroid/content/Context;->obtainStyledAttributes(I[I)Landroid/content/res/TypedArray;

    move-result-object p1

    invoke-virtual {p1, v0}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result p2

    iput-boolean p2, p0, Laa2;->i:Z

    invoke-virtual {p1, v0, v2}, Landroid/content/res/TypedArray;->getFloat(IF)F

    move-result p2

    iput p2, p0, Laa2;->j:F

    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v0, 0x1a

    if-lt p2, v0, :cond_95

    invoke-virtual {p1, v3}, Landroid/content/res/TypedArray;->hasValue(I)Z

    move-result p2

    if-eqz p2, :cond_8e

    goto :goto_8f

    :cond_8e
    move v3, v4

    :goto_8f
    invoke-virtual {p1, v3}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object p2

    iput-object p2, p0, Laa2;->c:Ljava/lang/String;

    :cond_95
    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    return-void
.end method


# virtual methods
.method public final a()V
    .registers 4

    .prologue
    iget-object v0, p0, Laa2;->p:Landroid/graphics/Typeface;

    iget v1, p0, Laa2;->d:I

    if-nez v0, :cond_10

    iget-object v2, p0, Laa2;->b:Ljava/lang/String;

    if-eqz v2, :cond_10

    invoke-static {v2, v1}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object v0

    iput-object v0, p0, Laa2;->p:Landroid/graphics/Typeface;

    :cond_10
    if-nez v0, :cond_36

    const/4 v0, 0x1

    iget v2, p0, Laa2;->e:I

    if-eq v2, v0, :cond_2c

    const/4 v0, 0x2

    if-eq v2, v0, :cond_27

    const/4 v0, 0x3

    if-eq v2, v0, :cond_22

    sget-object v0, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    iput-object v0, p0, Laa2;->p:Landroid/graphics/Typeface;

    goto :goto_30

    :cond_22
    sget-object v0, Landroid/graphics/Typeface;->MONOSPACE:Landroid/graphics/Typeface;

    iput-object v0, p0, Laa2;->p:Landroid/graphics/Typeface;

    goto :goto_30

    :cond_27
    sget-object v0, Landroid/graphics/Typeface;->SERIF:Landroid/graphics/Typeface;

    iput-object v0, p0, Laa2;->p:Landroid/graphics/Typeface;

    goto :goto_30

    :cond_2c
    sget-object v0, Landroid/graphics/Typeface;->SANS_SERIF:Landroid/graphics/Typeface;

    iput-object v0, p0, Laa2;->p:Landroid/graphics/Typeface;

    :goto_30
    invoke-static {v0, v1}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    move-result-object v0

    iput-object v0, p0, Laa2;->p:Landroid/graphics/Typeface;

    :cond_36
    return-void
.end method

.method public final b(Landroid/content/Context;Llk;)V
    .registers 12

    .prologue
    invoke-virtual {p0, p1}, Laa2;->c(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_9

    invoke-virtual {p0}, Laa2;->a()V

    :cond_9
    const/4 v1, 0x1

    iget v3, p0, Laa2;->m:I

    if-nez v3, :cond_10

    iput-boolean v1, p0, Laa2;->n:Z

    :cond_10
    iget-boolean v0, p0, Laa2;->n:Z

    if-eqz v0, :cond_1a

    iget-object p0, p0, Laa2;->p:Landroid/graphics/Typeface;

    invoke-virtual {p2, p0, v1}, Llk;->z(Landroid/graphics/Typeface;Z)V

    return-void

    :cond_1a
    :try_start_1a
    new-instance v6, Ly92;

    invoke-direct {v6, p0, p2}, Ly92;-><init>(Laa2;Llk;)V

    sget-object v0, Leu1;->a:Ljava/lang/ThreadLocal;

    invoke-virtual {p1}, Landroid/content/Context;->isRestricted()Z

    move-result v0

    if-eqz v0, :cond_2c

    const/4 p1, -0x4

    invoke-virtual {v6, p1}, Lqk;->d(I)V

    return-void

    :cond_2c
    new-instance v4, Landroid/util/TypedValue;

    invoke-direct {v4}, Landroid/util/TypedValue;-><init>()V

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v5, 0x0

    move-object v2, p1

    invoke-static/range {v2 .. v8}, Leu1;->a(Landroid/content/Context;ILandroid/util/TypedValue;ILqk;ZZ)Landroid/graphics/Typeface;
    :try_end_38
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_1a .. :try_end_38} :catch_55
    .catch Ljava/lang/Exception; {:try_start_1a .. :try_end_38} :catch_39

    return-void

    :catch_39
    move-exception v0

    move-object p1, v0

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "Error loading font "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v2, p0, Laa2;->b:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v2, "TextAppearance"

    nop

    iput-boolean v1, p0, Laa2;->n:Z

    const/4 p0, -0x3

    invoke-virtual {p2, p0}, Llk;->y(I)V

    goto :goto_5a

    :catch_55
    iput-boolean v1, p0, Laa2;->n:Z

    invoke-virtual {p2, v1}, Llk;->y(I)V

    :goto_5a
    return-void
.end method

.method public final c(Landroid/content/Context;)Z
    .registers 12

    .prologue
    iget-boolean v0, p0, Laa2;->n:Z

    const/4 v1, 0x1

    if-eqz v0, :cond_6

    return v1

    :cond_6
    const/4 v0, 0x0

    iget v3, p0, Laa2;->m:I

    if-nez v3, :cond_d

    goto/16 :goto_98

    :cond_d
    sget-object v2, Leu1;->a:Ljava/lang/ThreadLocal;

    invoke-virtual {p1}, Landroid/content/Context;->isRestricted()Z

    move-result v2

    const/4 v9, 0x0

    if-eqz v2, :cond_19

    move-object v2, p1

    move-object p1, v9

    goto :goto_27

    :cond_19
    new-instance v4, Landroid/util/TypedValue;

    invoke-direct {v4}, Landroid/util/TypedValue;-><init>()V

    const/4 v7, 0x0

    const/4 v8, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    move-object v2, p1

    invoke-static/range {v2 .. v8}, Leu1;->a(Landroid/content/Context;ILandroid/util/TypedValue;ILqk;ZZ)Landroid/graphics/Typeface;

    move-result-object p1

    :goto_27
    if-eqz p1, :cond_2e

    iput-object p1, p0, Laa2;->p:Landroid/graphics/Typeface;

    iput-boolean v1, p0, Laa2;->n:Z

    return v1

    :cond_2e
    iget-boolean p1, p0, Laa2;->o:Z

    if-eqz p1, :cond_33

    goto :goto_91

    :cond_33
    iput-boolean v1, p0, Laa2;->o:Z

    invoke-virtual {v2}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    iget v2, p0, Laa2;->m:I

    if-eqz v2, :cond_7e

    invoke-virtual {p1, v2}, Landroid/content/res/Resources;->getResourceTypeName(I)Ljava/lang/String;

    move-result-object v3

    const-string v4, "font"

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4a

    goto :goto_7e

    :cond_4a
    :try_start_4a
    invoke-virtual {p1, v2}, Landroid/content/res/Resources;->getXml(I)Landroid/content/res/XmlResourceParser;

    move-result-object v2

    :goto_4e
    invoke-interface {v2}, Lorg/xmlpull/v1/XmlPullParser;->getEventType()I

    move-result v3

    if-eq v3, v1, :cond_7e

    invoke-interface {v2}, Lorg/xmlpull/v1/XmlPullParser;->getEventType()I

    move-result v3

    const/4 v4, 0x2

    if-ne v3, v4, :cond_7a

    invoke-interface {v2}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object v3

    const-string v4, "font-family"

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_7a

    invoke-static {v2}, Landroid/util/Xml;->asAttributeSet(Lorg/xmlpull/v1/XmlPullParser;)Landroid/util/AttributeSet;

    move-result-object v2

    sget-object v3, Lgp1;->b:[I

    invoke-virtual {p1, v2, v3}, Landroid/content/res/Resources;->obtainAttributes(Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;

    move-result-object p1

    const/4 v2, 0x7

    invoke-virtual {p1, v2}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {p1}, Landroid/content/res/TypedArray;->recycle()V

    goto :goto_7f

    :cond_7a
    invoke-interface {v2}, Lorg/xmlpull/v1/XmlPullParser;->next()I
    :try_end_7d
    .catchall {:try_start_4a .. :try_end_7d} :catchall_7e

    goto :goto_4e

    :catchall_7e
    :cond_7e
    :goto_7e
    move-object v2, v9

    :goto_7f
    if-nez v2, :cond_82

    goto :goto_91

    :cond_82
    invoke-static {v2, v0}, Landroid/graphics/Typeface;->create(Ljava/lang/String;I)Landroid/graphics/Typeface;

    move-result-object p1

    sget-object v2, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    if-ne p1, v2, :cond_8b

    goto :goto_91

    :cond_8b
    iget v2, p0, Laa2;->d:I

    invoke-static {p1, v2}, Landroid/graphics/Typeface;->create(Landroid/graphics/Typeface;I)Landroid/graphics/Typeface;

    move-result-object v9

    :goto_91
    if-eqz v9, :cond_98

    iput-object v9, p0, Laa2;->p:Landroid/graphics/Typeface;

    iput-boolean v1, p0, Laa2;->n:Z

    return v1

    :cond_98
    :goto_98
    return v0
.end method

.method public final d(Landroid/content/Context;Landroid/text/TextPaint;Llk;)V
    .registers 5

    .prologue
    invoke-virtual {p0, p1, p2, p3}, Laa2;->e(Landroid/content/Context;Landroid/text/TextPaint;Llk;)V

    iget-object p1, p0, Laa2;->k:Landroid/content/res/ColorStateList;

    if-eqz p1, :cond_12

    iget-object p3, p2, Landroid/text/TextPaint;->drawableState:[I

    invoke-virtual {p1}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    move-result v0

    invoke-virtual {p1, p3, v0}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    move-result p1

    goto :goto_14

    :cond_12
    const/high16 p1, -0x1000000

    :goto_14
    invoke-virtual {p2, p1}, Landroid/graphics/Paint;->setColor(I)V

    iget-object p1, p0, Laa2;->a:Landroid/content/res/ColorStateList;

    if-eqz p1, :cond_26

    iget-object p3, p2, Landroid/text/TextPaint;->drawableState:[I

    invoke-virtual {p1}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    move-result v0

    invoke-virtual {p1, p3, v0}, Landroid/content/res/ColorStateList;->getColorForState([II)I

    move-result p1

    goto :goto_27

    :cond_26
    const/4 p1, 0x0

    :goto_27
    iget p3, p0, Laa2;->h:F

    iget v0, p0, Laa2;->f:F

    iget p0, p0, Laa2;->g:F

    invoke-virtual {p2, p3, v0, p0, p1}, Landroid/graphics/Paint;->setShadowLayer(FFFI)V

    return-void
.end method

.method public final e(Landroid/content/Context;Landroid/text/TextPaint;Llk;)V
    .registers 5

    .prologue
    invoke-virtual {p0, p1}, Laa2;->c(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_12

    iget-boolean v0, p0, Laa2;->n:Z

    if-eqz v0, :cond_12

    iget-object v0, p0, Laa2;->p:Landroid/graphics/Typeface;

    if-eqz v0, :cond_12

    invoke-virtual {p0, p1, p2, v0}, Laa2;->f(Landroid/content/Context;Landroid/text/TextPaint;Landroid/graphics/Typeface;)V

    return-void

    :cond_12
    invoke-virtual {p0}, Laa2;->a()V

    iget-object v0, p0, Laa2;->p:Landroid/graphics/Typeface;

    invoke-virtual {p0, p1, p2, v0}, Laa2;->f(Landroid/content/Context;Landroid/text/TextPaint;Landroid/graphics/Typeface;)V

    new-instance v0, Lz92;

    invoke-direct {v0, p0, p1, p2, p3}, Lz92;-><init>(Laa2;Landroid/content/Context;Landroid/text/TextPaint;Llk;)V

    invoke-virtual {p0, p1, v0}, Laa2;->b(Landroid/content/Context;Llk;)V

    return-void
.end method

.method public final f(Landroid/content/Context;Landroid/text/TextPaint;Landroid/graphics/Typeface;)V
    .registers 4

    .prologue
    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    invoke-virtual {p1}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object p1

    invoke-static {p1, p3}, Ljf1;->d(Landroid/content/res/Configuration;Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    move-result-object p1

    if-eqz p1, :cond_f

    move-object p3, p1

    :cond_f
    invoke-virtual {p2, p3}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    invoke-virtual {p3}, Landroid/graphics/Typeface;->getStyle()I

    move-result p1

    not-int p1, p1

    iget p3, p0, Laa2;->d:I

    and-int/2addr p1, p3

    and-int/lit8 p3, p1, 0x1

    if-eqz p3, :cond_20

    const/4 p3, 0x1

    goto :goto_21

    :cond_20
    const/4 p3, 0x0

    :goto_21
    invoke-virtual {p2, p3}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    and-int/lit8 p1, p1, 0x2

    if-eqz p1, :cond_2b

    const/high16 p1, -0x41800000  # -0.25f

    goto :goto_2c

    :cond_2b
    const/4 p1, 0x0

    :goto_2c
    invoke-virtual {p2, p1}, Landroid/graphics/Paint;->setTextSkewX(F)V

    iget p1, p0, Laa2;->l:F

    invoke-virtual {p2, p1}, Landroid/graphics/Paint;->setTextSize(F)V

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 p3, 0x1a

    if-lt p1, p3, :cond_43

    const/4 p1, 0x0

    invoke-virtual {p2, p1}, Landroid/text/TextPaint;->setFontVariationSettings(Ljava/lang/String;)Z

    iget-object p1, p0, Laa2;->c:Ljava/lang/String;

    invoke-virtual {p2, p1}, Landroid/text/TextPaint;->setFontVariationSettings(Ljava/lang/String;)Z

    :cond_43
    iget-boolean p1, p0, Laa2;->i:Z

    if-eqz p1, :cond_4c

    iget p0, p0, Laa2;->j:F

    invoke-virtual {p2, p0}, Landroid/graphics/Paint;->setLetterSpacing(F)V

    :cond_4c
    return-void
.end method
