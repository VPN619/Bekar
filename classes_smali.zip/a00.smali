.class public final La00;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lc00;


# direct methods
.method public synthetic constructor <init>(ILc00;Landroid/os/Bundle;)V
    .registers 4

    iput p1, p0, La00;->a:I

    iput-object p2, p0, La00;->b:Lc00;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Lc00;IIIIILandroid/os/Bundle;)V
    .registers 8

    const/4 p2, 0x3

    iput p2, p0, La00;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La00;->b:Lc00;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 2

    .prologue
    iget v0, p0, La00;->a:I

    iget-object p0, p0, La00;->b:Lc00;

    packed-switch v0, :pswitch_data_26

    iget-object p0, p0, Lc00;->b:Lnp3;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void

    :pswitch_d  #0x3
    iget-object p0, p0, Lc00;->b:Lnp3;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void

    :pswitch_13  #0x2
    iget-object p0, p0, Lc00;->b:Lnp3;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void

    :pswitch_19  #0x1
    iget-object p0, p0, Lc00;->b:Lnp3;

    invoke-virtual {p0}, Lnp3;->onMessageChannelReady()V

    return-void

    :pswitch_1f  #0x0
    iget-object p0, p0, Lc00;->b:Lnp3;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void

    nop

    :pswitch_data_26
    .packed-switch 0x0
        :pswitch_1f  #00000000
        :pswitch_19  #00000001
        :pswitch_13  #00000002
        :pswitch_d  #00000003
    .end packed-switch
.end method
