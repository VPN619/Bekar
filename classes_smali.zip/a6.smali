.class public final La6;
.super Lkl0;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ll91;


# virtual methods
.method public final bridge synthetic clone()Ljava/lang/Object;
    .registers 1

    invoke-virtual {p0}, Lkl0;->c()Lkl0;

    move-result-object p0

    return-object p0
.end method

.method public final getDefaultInstanceForType()Lrl0;
    .registers 1

    iget-object p0, p0, Lkl0;->a:Lrl0;

    return-object p0
.end method
