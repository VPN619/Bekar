.class public final La63;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# direct methods
.method public static a(Ljava/util/LinkedHashMap;Ljava/lang/String;Lb5;Lads_mobile_sdk/va;J)V
    .registers 8

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lads_mobile_sdk/ma;

    sget-object v1, Lv60;->b:Lp80;

    sget-object v1, Ly60;->d:Ly60;

    invoke-static {p4, p5, v1}, Li10;->H0(JLy60;)J

    move-result-wide p4

    invoke-direct {v0, p3, p2, p4, p5}, Lads_mobile_sdk/ma;-><init>(Lads_mobile_sdk/va;Lb5;J)V

    invoke-interface {p0, p1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method
