.class public final La8;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/widget/AdapterView$OnItemClickListener;


# instance fields
.field public final synthetic a:Lf8;

.field public final synthetic b:Lc8;


# direct methods
.method public constructor <init>(Lc8;Lf8;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La8;->b:Lc8;

    iput-object p2, p0, La8;->a:Lf8;

    return-void
.end method


# virtual methods
.method public final onItemClick(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .registers 6

    .prologue
    iget-object p1, p0, La8;->b:Lc8;

    iget-object p2, p1, Lc8;->n:Landroid/content/DialogInterface$OnClickListener;

    iget-object p0, p0, La8;->a:Lf8;

    iget-object p4, p0, Lf8;->b:Lh8;

    invoke-interface {p2, p4, p3}, Landroid/content/DialogInterface$OnClickListener;->onClick(Landroid/content/DialogInterface;I)V

    iget-boolean p1, p1, Lc8;->r:Z

    if-nez p1, :cond_14

    iget-object p0, p0, Lf8;->b:Lh8;

    invoke-virtual {p0}, Lub;->dismiss()V

    :cond_14
    return-void
.end method
