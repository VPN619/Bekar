.class public final synthetic La40;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/animation/ValueAnimator$AnimatorUpdateListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    iput p1, p0, La40;->a:I

    iput-object p2, p0, La40;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lk62;Landroid/view/View;)V
    .registers 3

    const/4 p2, 0x3

    iput p2, p0, La40;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, La40;->b:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final onAnimationUpdate(Landroid/animation/ValueAnimator;)V
    .registers 4

    .prologue
    iget v0, p0, La40;->a:I

    iget-object p0, p0, La40;->b:Ljava/lang/Object;

    packed-switch v0, :pswitch_data_6e

    check-cast p0, Landroid/view/View;

    invoke-static {p0, p1}, Lcom/mbridge/msdk/config/component/animation/b;->c(Landroid/view/View;Landroid/animation/ValueAnimator;)V

    return-void

    :pswitch_d  #0x6
    check-cast p0, Landroid/widget/ImageView;

    invoke-static {p0, p1}, Lcom/mbridge/msdk/config/component/animation/b;->d(Landroid/widget/ImageView;Landroid/animation/ValueAnimator;)V

    return-void

    :pswitch_13  #0x5
    check-cast p0, Landroid/widget/TextView;

    invoke-static {p0, p1}, Lcom/mbridge/msdk/config/component/animation/b;->e(Landroid/widget/TextView;Landroid/animation/ValueAnimator;)V

    return-void

    :pswitch_19  #0x4
    check-cast p0, Landroid/graphics/drawable/GradientDrawable;

    invoke-static {p0, p1}, Lcom/mbridge/msdk/config/component/animation/b;->b(Landroid/graphics/drawable/GradientDrawable;Landroid/animation/ValueAnimator;)V

    return-void

    :pswitch_1f  #0x3
    check-cast p0, Lk62;

    iget-object p0, p0, Lk62;->b:Ljava/lang/Object;

    check-cast p0, Lro2;

    iget-object p0, p0, Lro2;->x:Landroidx/appcompat/widget/ActionBarContainer;

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p0

    check-cast p0, Landroid/view/View;

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    return-void

    :pswitch_31  #0x2
    check-cast p0, Le71;

    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->getAnimatedValue()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Float;

    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result p1

    const/high16 v0, 0x437f0000  # 255.0f

    mul-float/2addr v0, p1

    float-to-int v0, v0

    iget-object v1, p0, Le71;->k:Landroid/graphics/drawable/Drawable;

    invoke-virtual {v1, v0}, Landroid/graphics/drawable/Drawable;->setAlpha(I)V

    iput p1, p0, Le71;->y:F

    return-void

    :pswitch_49  #0x1
    check-cast p0, Lu60;

    invoke-virtual {p1}, Landroid/animation/ValueAnimator;->getAnimatedValue()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/lang/Float;

    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result p1

    iget-object p0, p0, Lra0;->d:Lcom/google/android/material/internal/CheckableImageButton;

    invoke-virtual {p0, p1}, Landroid/view/View;->setAlpha(F)V

    return-void

    :pswitch_5b  #0x0
    check-cast p0, Lc40;

    iget-object p1, p0, Lc40;->p:Lf60;

    iget-object v0, p0, Lc40;->u:Landroid/animation/TimeInterpolator;

    iget-object p0, p0, Lc40;->t:Landroid/animation/ValueAnimator;

    invoke-virtual {p0}, Landroid/animation/ValueAnimator;->getAnimatedFraction()F

    move-result p0

    invoke-interface {v0, p0}, Landroid/animation/TimeInterpolator;->getInterpolation(F)F

    move-result p0

    iput p0, p1, Lf60;->e:F

    return-void

    :pswitch_data_6e
    .packed-switch 0x0
        :pswitch_5b  #00000000
        :pswitch_49  #00000001
        :pswitch_31  #00000002
        :pswitch_1f  #00000003
        :pswitch_19  #00000004
        :pswitch_13  #00000005
        :pswitch_d  #00000006
    .end packed-switch
.end method
