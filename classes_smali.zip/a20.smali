.class public final La20;
.super Landroid/animation/AnimatorListenerAdapter;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final synthetic a:Lpr1;

.field public final synthetic b:I

.field public final synthetic c:Landroid/view/View;

.field public final synthetic d:I

.field public final synthetic e:Landroid/view/ViewPropertyAnimator;

.field public final synthetic f:Le20;


# direct methods
.method public constructor <init>(Le20;Lpr1;ILandroid/view/View;ILandroid/view/ViewPropertyAnimator;)V
    .registers 7

    iput-object p1, p0, La20;->f:Le20;

    iput-object p2, p0, La20;->a:Lpr1;

    iput p3, p0, La20;->b:I

    iput-object p4, p0, La20;->c:Landroid/view/View;

    iput p5, p0, La20;->d:I

    iput-object p6, p0, La20;->e:Landroid/view/ViewPropertyAnimator;

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    return-void
.end method


# virtual methods
.method public final onAnimationCancel(Landroid/animation/Animator;)V
    .registers 4

    .prologue
    iget p1, p0, La20;->b:I

    const/4 v0, 0x0

    iget-object v1, p0, La20;->c:Landroid/view/View;

    if-eqz p1, :cond_a

    invoke-virtual {v1, v0}, Landroid/view/View;->setTranslationX(F)V

    :cond_a
    iget p0, p0, La20;->d:I

    if-eqz p0, :cond_11

    invoke-virtual {v1, v0}, Landroid/view/View;->setTranslationY(F)V

    :cond_11
    return-void
.end method

.method public final onAnimationEnd(Landroid/animation/Animator;)V
    .registers 3

    iget-object p1, p0, La20;->e:Landroid/view/ViewPropertyAnimator;

    const/4 v0, 0x0

    invoke-virtual {p1, v0}, Landroid/view/ViewPropertyAnimator;->setListener(Landroid/animation/Animator$AnimatorListener;)Landroid/view/ViewPropertyAnimator;

    iget-object p1, p0, La20;->f:Le20;

    iget-object p0, p0, La20;->a:Lpr1;

    invoke-virtual {p1, p0}, Lvq1;->c(Lpr1;)V

    iget-object v0, p1, Le20;->p:Ljava/util/ArrayList;

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    invoke-virtual {p1}, Le20;->i()V

    return-void
.end method

.method public final onAnimationStart(Landroid/animation/Animator;)V
    .registers 2

    iget-object p0, p0, La20;->f:Le20;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void
.end method
