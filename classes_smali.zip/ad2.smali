.class public final Lad2;
.super Ljava/lang/Object;


# static fields
.field public static final f:Lad2;

.field public static final g:Landroid/os/Handler;

.field public static h:Landroid/os/Handler;

.field public static final i:Li90;

.field public static final j:Li90;


# instance fields
.field public final a:Ljava/util/ArrayList;

.field public final b:Ljava/util/ArrayList;

.field public final c:Lfm0;

.field public final d:Lvs2;

.field public final e:Lfm0;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lad2;

    invoke-direct {v0}, Lad2;-><init>()V

    sput-object v0, Lad2;->f:Lad2;

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    sput-object v0, Lad2;->g:Landroid/os/Handler;

    const/4 v0, 0x0

    sput-object v0, Lad2;->h:Landroid/os/Handler;

    new-instance v0, Li90;

    const/4 v1, 0x3

    invoke-direct {v0, v1}, Li90;-><init>(I)V

    sput-object v0, Lad2;->i:Li90;

    new-instance v0, Li90;

    const/4 v1, 0x4

    invoke-direct {v0, v1}, Li90;-><init>(I)V

    sput-object v0, Lad2;->j:Li90;

    return-void
.end method

.method public constructor <init>()V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lad2;->a:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lad2;->b:Ljava/util/ArrayList;

    new-instance v0, Lvs2;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lvs2;-><init>(I)V

    iput-object v0, p0, Lad2;->d:Lvs2;

    new-instance v0, Lfm0;

    const/16 v1, 0x16

    invoke-direct {v0, v1}, Lfm0;-><init>(I)V

    iput-object v0, p0, Lad2;->c:Lfm0;

    new-instance v0, Lfm0;

    new-instance v1, Lpy1;

    invoke-direct {v1}, Lpy1;-><init>()V

    const/16 v2, 0x17

    invoke-direct {v0, v2, v1}, Lfm0;-><init>(ILjava/lang/Object;)V

    iput-object v0, p0, Lad2;->e:Lfm0;

    return-void
.end method

.method public static b()V
    .registers 4

    .prologue
    sget-object v0, Lad2;->h:Landroid/os/Handler;

    if-nez v0, :cond_1d

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    sput-object v0, Lad2;->h:Landroid/os/Handler;

    sget-object v1, Lad2;->i:Li90;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    sget-object v0, Lad2;->h:Landroid/os/Handler;

    sget-object v1, Lad2;->j:Li90;

    const-wide/16 v2, 0xc8

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_1d
    return-void
.end method


# virtual methods
.method public final a(Landroid/view/View;Lk62;Lorg/json/JSONObject;Z)V
    .registers 16

    .prologue
    invoke-static {p1}, Lnp3;->l(Landroid/view/View;)Ljava/lang/String;

    move-result-object v0

    if-nez v0, :cond_e9

    iget-object v1, p0, Lad2;->d:Lvs2;

    iget-object v0, v1, Lvs2;->d:Ljava/util/HashSet;

    invoke-virtual {v0, p1}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz v0, :cond_14

    move v4, v3

    goto :goto_1c

    :cond_14
    iget-boolean v0, v1, Lvs2;->j:Z

    if-eqz v0, :cond_1b

    const/4 v0, 0x2

    move v4, v0

    goto :goto_1c

    :cond_1b
    move v4, v2

    :goto_1c
    if-ne v4, v2, :cond_20

    goto/16 :goto_e9

    :cond_20
    invoke-virtual {p2, p1}, Lk62;->b(Landroid/view/View;)Lorg/json/JSONObject;

    move-result-object v7

    invoke-static {p3, v7}, Lxu2;->c(Lorg/json/JSONObject;Lorg/json/JSONObject;)V

    iget-object p3, v1, Lvs2;->a:Ljava/util/HashMap;

    invoke-virtual {p3}, Ljava/util/HashMap;->size()I

    move-result v0

    const/4 v2, 0x0

    if-nez v0, :cond_32

    move-object p3, v2

    goto :goto_3e

    :cond_32
    invoke-virtual {p3, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/String;

    if-eqz v0, :cond_3d

    invoke-virtual {p3, p1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_3d
    move-object p3, v0

    :goto_3e
    const-string v5, "OMIDLIB"

    const/4 v6, 0x0

    if-eqz p3, :cond_87

    :try_start_43
    const-string p0, "adSessionId"

    invoke-virtual {v7, p0, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_48
    .catch Lorg/json/JSONException; {:try_start_43 .. :try_end_48} :catch_49

    goto :goto_4e

    :catch_49
    move-exception v0

    move-object p0, v0

    const-string p2, "Error with setting ad session id"

    nop

    :goto_4e
    iget-object p0, v1, Lvs2;->i:Ljava/util/WeakHashMap;

    invoke-virtual {p0, p1}, Ljava/util/WeakHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_5c

    sget-object p2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {p0, p1, p2}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_5d

    :cond_5c
    move v6, v3

    :goto_5d
    invoke-static {v6}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    :try_start_61
    const-string p1, "hasWindowFocus"

    invoke-virtual {v7, p1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_66
    .catch Lorg/json/JSONException; {:try_start_61 .. :try_end_66} :catch_67

    goto :goto_6c

    :catch_67
    move-exception v0

    move-object p0, v0

    const-string p1, "Error with setting has window focus"

    nop

    :goto_6c
    iget-object p0, v1, Lvs2;->h:Ljava/util/HashSet;

    invoke-virtual {p0, p3}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result p0

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    if-eqz p0, :cond_83

    :try_start_78
    const-string p0, "isPipActive"

    invoke-virtual {v7, p0, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_7d
    .catch Lorg/json/JSONException; {:try_start_78 .. :try_end_7d} :catch_7e

    goto :goto_83

    :catch_7e
    move-exception v0

    move-object p0, v0

    const-string p1, "Error with setting is picture-in-picture active"

    nop

    :cond_83
    :goto_83
    iput-boolean v3, v1, Lvs2;->j:Z

    goto/16 :goto_e9

    :cond_87
    iget-object p3, v1, Lvs2;->b:Ljava/util/HashMap;

    invoke-virtual {p3, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lts2;

    if-eqz v0, :cond_94

    invoke-virtual {p3, p1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_94
    if-eqz v0, :cond_d2

    iget-object p3, v0, Lts2;->a:Lbx2;

    new-instance v1, Lorg/json/JSONArray;

    invoke-direct {v1}, Lorg/json/JSONArray;-><init>()V

    iget-object v0, v0, Lts2;->b:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v8

    move v9, v6

    :goto_a4
    if-ge v9, v8, :cond_b2

    invoke-virtual {v0, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    add-int/lit8 v9, v9, 0x1

    check-cast v10, Ljava/lang/String;

    invoke-virtual {v1, v10}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    goto :goto_a4

    :cond_b2
    :try_start_b2
    const-string v0, "isFriendlyObstructionFor"

    invoke-virtual {v7, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v0, "friendlyObstructionClass"

    iget-object v1, p3, Lbx2;->b:Ljava/lang/String;

    invoke-virtual {v7, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string v0, "friendlyObstructionPurpose"

    iget-object p3, p3, Lbx2;->c:Lwj0;

    invoke-virtual {v7, v0, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const-string p3, "friendlyObstructionReason"

    invoke-virtual {v7, p3, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_ca
    .catch Lorg/json/JSONException; {:try_start_b2 .. :try_end_ca} :catch_cb

    goto :goto_d0

    :catch_cb
    move-exception v0

    move-object p3, v0

    const-string v0, "Error with setting friendly obstruction"

    nop

    :goto_d0
    move p3, v3

    goto :goto_d3

    :cond_d2
    move p3, v6

    :goto_d3
    if-nez p4, :cond_da

    if-eqz p3, :cond_d8

    goto :goto_da

    :cond_d8
    move v10, v6

    goto :goto_db

    :cond_da
    :goto_da
    move v10, v3

    :goto_db
    if-ne v4, v3, :cond_e2

    move v9, v3

    move-object v8, p0

    move-object v6, p1

    move-object v5, p2

    goto :goto_e6

    :cond_e2
    move v9, v6

    move-object v8, p0

    move-object v5, p2

    move-object v6, p1

    :goto_e6
    invoke-virtual/range {v5 .. v10}, Lk62;->c(Landroid/view/View;Lorg/json/JSONObject;Lad2;ZZ)V

    :cond_e9
    :goto_e9
    return-void
.end method
