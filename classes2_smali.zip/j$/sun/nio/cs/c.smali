.class public final Lj$/sun/nio/cs/c;
.super Ljava/nio/charset/Charset;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final a:Lj$/sun/nio/cs/c;


# direct methods
.method static constructor <clinit>()V
    .registers 16

    new-instance v0, Lj$/sun/nio/cs/c;

    sget v1, Lj$/sun/nio/cs/d;->a:I

    const-string v14, "8859_1"

    const-string v15, "ISO8859-1"

    const-string v2, "iso-ir-100"

    const-string v3, "ISO_8859-1"

    const-string v4, "latin1"

    const-string v5, "l1"

    const-string v6, "IBM819"

    const-string v7, "cp819"

    const-string v8, "csISOLatin1"

    const-string v9, "819"

    const-string v10, "IBM-819"

    const-string v11, "ISO8859_1"

    const-string v12, "ISO_8859-1:1987"

    const-string v13, "ISO_8859_1"

    filled-new-array/range {v2 .. v15}, [Ljava/lang/String;

    move-result-object v1

    const-string v2, "ISO-8859-1"

    invoke-direct {v0, v2, v1}, Ljava/nio/charset/Charset;-><init>(Ljava/lang/String;[Ljava/lang/String;)V

    sput-object v0, Lj$/sun/nio/cs/c;->a:Lj$/sun/nio/cs/c;

    return-void
.end method


# virtual methods
.method public final contains(Ljava/nio/charset/Charset;)Z
    .registers 2

    .prologue
    instance-of p0, p1, Lj$/sun/nio/cs/c;

    if-eqz p0, :cond_6

    const/4 p0, 0x1

    return p0

    :cond_6
    const/4 p0, 0x0

    return p0
.end method

.method public final newDecoder()Ljava/nio/charset/CharsetDecoder;
    .registers 2

    new-instance v0, Lj$/sun/nio/cs/a;

    invoke-direct {v0, p0}, Lj$/sun/nio/cs/a;-><init>(Lj$/sun/nio/cs/c;)V

    return-object v0
.end method

.method public final newEncoder()Ljava/nio/charset/CharsetEncoder;
    .registers 2

    new-instance v0, Lj$/sun/nio/cs/b;

    invoke-direct {v0, p0}, Lj$/sun/nio/cs/b;-><init>(Lj$/sun/nio/cs/c;)V

    return-object v0
.end method
