.class public final Lj$/sun/nio/cs/b;
.super Ljava/nio/charset/CharsetEncoder;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Lj$/sun/nio/cs/e;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, Lj$/sun/nio/cs/c;

    return-void
.end method

.method public constructor <init>(Lj$/sun/nio/cs/c;)V
    .registers 3

    const/high16 v0, 0x3f800000  # 1.0f

    invoke-direct {p0, p1, v0, v0}, Ljava/nio/charset/CharsetEncoder;-><init>(Ljava/nio/charset/Charset;FF)V

    new-instance p1, Lj$/sun/nio/cs/e;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    sget-object v0, Ljava/nio/charset/CoderResult;->UNDERFLOW:Ljava/nio/charset/CoderResult;

    iput-object v0, p1, Lj$/sun/nio/cs/e;->a:Ljava/nio/charset/CoderResult;

    iput-object p1, p0, Lj$/sun/nio/cs/b;->a:Lj$/sun/nio/cs/e;

    return-void
.end method

.method public static a([CI[BII)I
    .registers 8

    .prologue
    const/4 v0, 0x0

    if-gtz p4, :cond_4

    return v0

    :cond_4
    invoke-static {p0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {p2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    if-ltz p1, :cond_4e

    array-length v1, p0

    if-ge p1, v1, :cond_4e

    if-ltz p3, :cond_48

    array-length v1, p2

    if-ge p3, v1, :cond_48

    add-int v1, p1, p4

    add-int/lit8 v1, v1, -0x1

    if-ltz v1, :cond_42

    array-length v2, p0

    if-ge v1, v2, :cond_42

    add-int v1, p3, p4

    add-int/lit8 v1, v1, -0x1

    if-ltz v1, :cond_3c

    array-length v2, p2

    if-ge v1, v2, :cond_3c

    :goto_26
    if-ge v0, p4, :cond_3b

    add-int/lit8 v1, p1, 0x1

    aget-char p1, p0, p1

    const/16 v2, 0xff

    if-le p1, v2, :cond_31

    goto :goto_3b

    :cond_31
    add-int/lit8 v2, p3, 0x1

    int-to-byte p1, p1

    aput-byte p1, p2, p3

    add-int/lit8 v0, v0, 0x1

    move p1, v1

    move p3, v2

    goto :goto_26

    :cond_3b
    :goto_3b
    return v0

    :cond_3c
    new-instance p0, Ljava/lang/ArrayIndexOutOfBoundsException;

    invoke-direct {p0, v1}, Ljava/lang/ArrayIndexOutOfBoundsException;-><init>(I)V

    throw p0

    :cond_42
    new-instance p0, Ljava/lang/ArrayIndexOutOfBoundsException;

    invoke-direct {p0, v1}, Ljava/lang/ArrayIndexOutOfBoundsException;-><init>(I)V

    throw p0

    :cond_48
    new-instance p0, Ljava/lang/ArrayIndexOutOfBoundsException;

    invoke-direct {p0, p3}, Ljava/lang/ArrayIndexOutOfBoundsException;-><init>(I)V

    throw p0

    :cond_4e
    new-instance p0, Ljava/lang/ArrayIndexOutOfBoundsException;

    invoke-direct {p0, p1}, Ljava/lang/ArrayIndexOutOfBoundsException;-><init>(I)V

    throw p0
.end method


# virtual methods
.method public final canEncode(C)Z
    .registers 2

    .prologue
    const/16 p0, 0xff

    if-gt p1, p0, :cond_6

    const/4 p0, 0x1

    return p0

    :cond_6
    const/4 p0, 0x0

    return p0
.end method

.method public final encodeLoop(Ljava/nio/CharBuffer;Ljava/nio/ByteBuffer;)Ljava/nio/charset/CoderResult;
    .registers 14

    .prologue
    invoke-virtual {p1}, Ljava/nio/CharBuffer;->hasArray()Z

    move-result v0

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eqz v0, :cond_b4

    invoke-virtual {p2}, Ljava/nio/ByteBuffer;->hasArray()Z

    move-result v0

    if-eqz v0, :cond_b4

    invoke-virtual {p1}, Ljava/nio/CharBuffer;->array()[C

    move-result-object v0

    invoke-virtual {p1}, Ljava/nio/CharBuffer;->arrayOffset()I

    move-result v3

    invoke-virtual {p1}, Ljava/nio/CharBuffer;->position()I

    move-result v4

    add-int/2addr v4, v3

    invoke-virtual {p1}, Ljava/nio/CharBuffer;->limit()I

    move-result v5

    add-int/2addr v5, v3

    if-gt v4, v5, :cond_23

    goto :goto_24

    :cond_23
    move v4, v5

    :goto_24
    invoke-virtual {p2}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v6

    invoke-virtual {p2}, Ljava/nio/ByteBuffer;->arrayOffset()I

    move-result v7

    invoke-virtual {p2}, Ljava/nio/ByteBuffer;->position()I

    move-result v8

    add-int/2addr v8, v7

    invoke-virtual {p2}, Ljava/nio/ByteBuffer;->limit()I

    move-result v9

    add-int/2addr v9, v7

    if-gt v8, v9, :cond_39

    goto :goto_3a

    :cond_39
    move v8, v9

    :goto_3a
    sub-int/2addr v9, v8

    sub-int v10, v5, v4

    if-ge v9, v10, :cond_40

    goto :goto_41

    :cond_40
    move v9, v10

    :goto_41
    :try_start_41
    invoke-static {v0, v4, v6, v8, v9}, Lj$/sun/nio/cs/b;->a([CI[BII)I

    move-result v6

    add-int/2addr v4, v6

    add-int/2addr v8, v6

    if-eq v6, v9, :cond_81

    iget-object v6, p0, Lj$/sun/nio/cs/b;->a:Lj$/sun/nio/cs/e;

    aget-char v9, v0, v4

    invoke-virtual {v6, v9, v0, v4, v5}, Lj$/sun/nio/cs/e;->b(C[CII)I

    move-result v0
    :try_end_51
    .catchall {:try_start_41 .. :try_end_51} :catchall_66

    iget-object p0, p0, Lj$/sun/nio/cs/b;->a:Lj$/sun/nio/cs/e;

    if-gez v0, :cond_68

    :try_start_55
    iget-object p0, p0, Lj$/sun/nio/cs/e;->a:Ljava/nio/charset/CoderResult;
    :try_end_57
    .catchall {:try_start_55 .. :try_end_57} :catchall_66

    sub-int/2addr v4, v3

    invoke-virtual {p1, v4}, Ljava/nio/CharBuffer;->position(I)Ljava/nio/Buffer;

    move-result-object p1

    check-cast p1, Ljava/nio/CharBuffer;

    sub-int/2addr v8, v7

    invoke-virtual {p2, v8}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    move-result-object p1

    check-cast p1, Ljava/nio/ByteBuffer;

    return-object p0

    :catchall_66
    move-exception p0

    goto :goto_a5

    :cond_68
    :try_start_68
    iget-boolean p0, p0, Lj$/sun/nio/cs/e;->b:Z

    if-eqz p0, :cond_6d

    goto :goto_6e

    :cond_6d
    move v1, v2

    :goto_6e
    invoke-static {v1}, Ljava/nio/charset/CoderResult;->unmappableForLength(I)Ljava/nio/charset/CoderResult;

    move-result-object p0
    :try_end_72
    .catchall {:try_start_68 .. :try_end_72} :catchall_66

    sub-int/2addr v4, v3

    invoke-virtual {p1, v4}, Ljava/nio/CharBuffer;->position(I)Ljava/nio/Buffer;

    move-result-object p1

    check-cast p1, Ljava/nio/CharBuffer;

    sub-int/2addr v8, v7

    invoke-virtual {p2, v8}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    move-result-object p1

    check-cast p1, Ljava/nio/ByteBuffer;

    return-object p0

    :cond_81
    if-ge v9, v10, :cond_94

    :try_start_83
    sget-object p0, Ljava/nio/charset/CoderResult;->OVERFLOW:Ljava/nio/charset/CoderResult;
    :try_end_85
    .catchall {:try_start_83 .. :try_end_85} :catchall_66

    sub-int/2addr v4, v3

    invoke-virtual {p1, v4}, Ljava/nio/CharBuffer;->position(I)Ljava/nio/Buffer;

    move-result-object p1

    check-cast p1, Ljava/nio/CharBuffer;

    sub-int/2addr v8, v7

    invoke-virtual {p2, v8}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    move-result-object p1

    check-cast p1, Ljava/nio/ByteBuffer;

    return-object p0

    :cond_94
    :try_start_94
    sget-object p0, Ljava/nio/charset/CoderResult;->UNDERFLOW:Ljava/nio/charset/CoderResult;
    :try_end_96
    .catchall {:try_start_94 .. :try_end_96} :catchall_66

    sub-int/2addr v4, v3

    invoke-virtual {p1, v4}, Ljava/nio/CharBuffer;->position(I)Ljava/nio/Buffer;

    move-result-object p1

    check-cast p1, Ljava/nio/CharBuffer;

    sub-int/2addr v8, v7

    invoke-virtual {p2, v8}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    move-result-object p1

    check-cast p1, Ljava/nio/ByteBuffer;

    return-object p0

    :goto_a5
    sub-int/2addr v4, v3

    invoke-virtual {p1, v4}, Ljava/nio/CharBuffer;->position(I)Ljava/nio/Buffer;

    move-result-object p1

    check-cast p1, Ljava/nio/CharBuffer;

    sub-int/2addr v8, v7

    invoke-virtual {p2, v8}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    move-result-object p1

    check-cast p1, Ljava/nio/ByteBuffer;

    throw p0

    :cond_b4
    invoke-virtual {p1}, Ljava/nio/CharBuffer;->position()I

    move-result v0

    :goto_b8
    :try_start_b8
    invoke-virtual {p1}, Ljava/nio/CharBuffer;->hasRemaining()Z

    move-result v3

    if-eqz v3, :cond_102

    invoke-virtual {p1}, Ljava/nio/CharBuffer;->get()C

    move-result v3

    const/16 v4, 0xff

    if-gt v3, v4, :cond_de

    invoke-virtual {p2}, Ljava/nio/ByteBuffer;->hasRemaining()Z

    move-result v4

    if-nez v4, :cond_d7

    sget-object p0, Ljava/nio/charset/CoderResult;->OVERFLOW:Ljava/nio/charset/CoderResult;
    :try_end_ce
    .catchall {:try_start_b8 .. :try_end_ce} :catchall_d5

    invoke-virtual {p1, v0}, Ljava/nio/CharBuffer;->position(I)Ljava/nio/Buffer;

    move-result-object p1

    check-cast p1, Ljava/nio/CharBuffer;

    return-object p0

    :catchall_d5
    move-exception p0

    goto :goto_10b

    :cond_d7
    int-to-byte v3, v3

    :try_start_d8
    invoke-virtual {p2, v3}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    add-int/lit8 v0, v0, 0x1

    goto :goto_b8

    :cond_de
    iget-object p2, p0, Lj$/sun/nio/cs/b;->a:Lj$/sun/nio/cs/e;

    invoke-virtual {p2, v3, p1}, Lj$/sun/nio/cs/e;->a(CLjava/nio/CharBuffer;)I

    move-result p2
    :try_end_e4
    .catchall {:try_start_d8 .. :try_end_e4} :catchall_d5

    iget-object p0, p0, Lj$/sun/nio/cs/b;->a:Lj$/sun/nio/cs/e;

    if-gez p2, :cond_f1

    :try_start_e8
    iget-object p0, p0, Lj$/sun/nio/cs/e;->a:Ljava/nio/charset/CoderResult;
    :try_end_ea
    .catchall {:try_start_e8 .. :try_end_ea} :catchall_d5

    invoke-virtual {p1, v0}, Ljava/nio/CharBuffer;->position(I)Ljava/nio/Buffer;

    move-result-object p1

    check-cast p1, Ljava/nio/CharBuffer;

    return-object p0

    :cond_f1
    :try_start_f1
    iget-boolean p0, p0, Lj$/sun/nio/cs/e;->b:Z

    if-eqz p0, :cond_f6

    goto :goto_f7

    :cond_f6
    move v1, v2

    :goto_f7
    invoke-static {v1}, Ljava/nio/charset/CoderResult;->unmappableForLength(I)Ljava/nio/charset/CoderResult;

    move-result-object p0
    :try_end_fb
    .catchall {:try_start_f1 .. :try_end_fb} :catchall_d5

    invoke-virtual {p1, v0}, Ljava/nio/CharBuffer;->position(I)Ljava/nio/Buffer;

    move-result-object p1

    check-cast p1, Ljava/nio/CharBuffer;

    return-object p0

    :cond_102
    :try_start_102
    sget-object p0, Ljava/nio/charset/CoderResult;->UNDERFLOW:Ljava/nio/charset/CoderResult;
    :try_end_104
    .catchall {:try_start_102 .. :try_end_104} :catchall_d5

    invoke-virtual {p1, v0}, Ljava/nio/CharBuffer;->position(I)Ljava/nio/Buffer;

    move-result-object p1

    check-cast p1, Ljava/nio/CharBuffer;

    return-object p0

    :goto_10b
    invoke-virtual {p1, v0}, Ljava/nio/CharBuffer;->position(I)Ljava/nio/Buffer;

    move-result-object p1

    check-cast p1, Ljava/nio/CharBuffer;

    throw p0
.end method

.method public final isLegalReplacement([B)Z
    .registers 2

    const/4 p0, 0x1

    return p0
.end method
