.class public final Lj$/sun/nio/cs/a;
.super Ljava/nio/charset/CharsetDecoder;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-class v0, Lj$/sun/nio/cs/c;

    return-void
.end method

.method public constructor <init>(Lj$/sun/nio/cs/c;)V
    .registers 3

    const/high16 v0, 0x3f800000  # 1.0f

    invoke-direct {p0, p1, v0, v0}, Ljava/nio/charset/CharsetDecoder;-><init>(Ljava/nio/charset/Charset;FF)V

    return-void
.end method


# virtual methods
.method public final decodeLoop(Ljava/nio/ByteBuffer;Ljava/nio/CharBuffer;)Ljava/nio/charset/CoderResult;
    .registers 10

    .prologue
    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->hasArray()Z

    move-result p0

    if-eqz p0, :cond_89

    invoke-virtual {p2}, Ljava/nio/CharBuffer;->hasArray()Z

    move-result p0

    if-eqz p0, :cond_89

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object p0

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->arrayOffset()I

    move-result v0

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->position()I

    move-result v1

    add-int/2addr v1, v0

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->arrayOffset()I

    move-result v0

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->limit()I

    move-result v2

    add-int/2addr v2, v0

    if-gt v1, v2, :cond_25

    goto :goto_26

    :cond_25
    move v1, v2

    :goto_26
    invoke-virtual {p2}, Ljava/nio/CharBuffer;->array()[C

    move-result-object v0

    invoke-virtual {p2}, Ljava/nio/CharBuffer;->arrayOffset()I

    move-result v3

    invoke-virtual {p2}, Ljava/nio/CharBuffer;->position()I

    move-result v4

    add-int/2addr v4, v3

    invoke-virtual {p2}, Ljava/nio/CharBuffer;->arrayOffset()I

    move-result v3

    invoke-virtual {p2}, Ljava/nio/CharBuffer;->limit()I

    move-result v5

    add-int/2addr v5, v3

    if-gt v4, v5, :cond_3f

    goto :goto_40

    :cond_3f
    move v4, v5

    :goto_40
    if-ge v1, v2, :cond_6f

    :try_start_42
    aget-byte v3, p0, v1

    if-lt v4, v5, :cond_61

    sget-object p0, Ljava/nio/charset/CoderResult;->OVERFLOW:Ljava/nio/charset/CoderResult;
    :try_end_48
    .catchall {:try_start_42 .. :try_end_48} :catchall_5f

    :goto_48
    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->arrayOffset()I

    move-result v0

    sub-int/2addr v1, v0

    invoke-virtual {p1, v1}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    move-result-object p1

    check-cast p1, Ljava/nio/ByteBuffer;

    invoke-virtual {p2}, Ljava/nio/CharBuffer;->arrayOffset()I

    move-result p1

    sub-int/2addr v4, p1

    invoke-virtual {p2, v4}, Ljava/nio/CharBuffer;->position(I)Ljava/nio/Buffer;

    move-result-object p1

    check-cast p1, Ljava/nio/CharBuffer;

    return-object p0

    :catchall_5f
    move-exception p0

    goto :goto_72

    :cond_61
    add-int/lit8 v6, v4, 0x1

    and-int/lit16 v3, v3, 0xff

    int-to-char v3, v3

    :try_start_66
    aput-char v3, v0, v4
    :try_end_68
    .catchall {:try_start_66 .. :try_end_68} :catchall_6c

    add-int/lit8 v1, v1, 0x1

    move v4, v6

    goto :goto_40

    :catchall_6c
    move-exception p0

    move v4, v6

    goto :goto_72

    :cond_6f
    :try_start_6f
    sget-object p0, Ljava/nio/charset/CoderResult;->UNDERFLOW:Ljava/nio/charset/CoderResult;
    :try_end_71
    .catchall {:try_start_6f .. :try_end_71} :catchall_5f

    goto :goto_48

    :goto_72
    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->arrayOffset()I

    move-result v0

    sub-int/2addr v1, v0

    invoke-virtual {p1, v1}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    move-result-object p1

    check-cast p1, Ljava/nio/ByteBuffer;

    invoke-virtual {p2}, Ljava/nio/CharBuffer;->arrayOffset()I

    move-result p1

    sub-int/2addr v4, p1

    invoke-virtual {p2, v4}, Ljava/nio/CharBuffer;->position(I)Ljava/nio/Buffer;

    move-result-object p1

    check-cast p1, Ljava/nio/CharBuffer;

    throw p0

    :cond_89
    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->position()I

    move-result p0

    :goto_8d
    :try_start_8d
    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->hasRemaining()Z

    move-result v0

    if-eqz v0, :cond_b1

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->get()B

    move-result v0

    invoke-virtual {p2}, Ljava/nio/CharBuffer;->hasRemaining()Z

    move-result v1

    if-nez v1, :cond_a8

    sget-object p2, Ljava/nio/charset/CoderResult;->OVERFLOW:Ljava/nio/charset/CoderResult;
    :try_end_9f
    .catchall {:try_start_8d .. :try_end_9f} :catchall_a6

    :goto_9f
    invoke-virtual {p1, p0}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    move-result-object p0

    check-cast p0, Ljava/nio/ByteBuffer;

    return-object p2

    :catchall_a6
    move-exception p2

    goto :goto_b4

    :cond_a8
    and-int/lit16 v0, v0, 0xff

    int-to-char v0, v0

    :try_start_ab
    invoke-virtual {p2, v0}, Ljava/nio/CharBuffer;->put(C)Ljava/nio/CharBuffer;

    add-int/lit8 p0, p0, 0x1

    goto :goto_8d

    :cond_b1
    sget-object p2, Ljava/nio/charset/CoderResult;->UNDERFLOW:Ljava/nio/charset/CoderResult;
    :try_end_b3
    .catchall {:try_start_ab .. :try_end_b3} :catchall_a6

    goto :goto_9f

    :goto_b4
    invoke-virtual {p1, p0}, Ljava/nio/ByteBuffer;->position(I)Ljava/nio/Buffer;

    move-result-object p0

    check-cast p0, Ljava/nio/ByteBuffer;

    throw p2
.end method
