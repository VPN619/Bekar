.class public final enum Lj$/time/temporal/e;
.super Lj$/time/temporal/g;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# direct methods
.method public constructor <init>()V
    .registers 3

    const-string v0, "WEEK_OF_WEEK_BASED_YEAR"

    const/4 v1, 0x2

    invoke-direct {p0, v0, v1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method


# virtual methods
.method public final E(Lj$/time/temporal/l;)J
    .registers 2

    .prologue
    invoke-virtual {p0, p1}, Lj$/time/temporal/e;->n(Lj$/time/temporal/l;)Z

    move-result p0

    if-eqz p0, :cond_10

    invoke-static {p1}, Lj$/time/LocalDate;->E(Lj$/time/temporal/l;)Lj$/time/LocalDate;

    move-result-object p0

    invoke-static {p0}, Lj$/time/temporal/g;->I(Lj$/time/LocalDate;)I

    move-result p0

    int-to-long p0, p0

    return-wide p0

    :cond_10
    new-instance p0, Lj$/time/temporal/q;

    const-string p1, "Unsupported field: WeekOfWeekBasedYear"

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final H(Lj$/time/temporal/Temporal;J)Lj$/time/temporal/Temporal;
    .registers 6

    invoke-virtual {p0}, Lj$/time/temporal/e;->range()Lj$/time/temporal/r;

    move-result-object v0

    invoke-virtual {v0, p2, p3, p0}, Lj$/time/temporal/r;->b(JLj$/time/temporal/o;)V

    invoke-virtual {p0, p1}, Lj$/time/temporal/e;->E(Lj$/time/temporal/l;)J

    move-result-wide v0

    invoke-static {p2, p3, v0, v1}, Ljava/lang/Math;->subtractExact(JJ)J

    move-result-wide p2

    sget-object p0, Lj$/time/temporal/ChronoUnit;->WEEKS:Lj$/time/temporal/ChronoUnit;

    invoke-interface {p1, p2, p3, p0}, Lj$/time/temporal/Temporal;->j(JLj$/time/temporal/TemporalUnit;)Lj$/time/temporal/Temporal;

    move-result-object p0

    return-object p0
.end method

.method public final n(Lj$/time/temporal/l;)Z
    .registers 2

    .prologue
    sget-object p0, Lj$/time/temporal/a;->EPOCH_DAY:Lj$/time/temporal/a;

    invoke-interface {p1, p0}, Lj$/time/temporal/l;->e(Lj$/time/temporal/o;)Z

    move-result p0

    if-eqz p0, :cond_18

    sget-object p0, Lj$/time/temporal/i;->a:Lj$/time/temporal/g;

    invoke-static {p1}, Lj$/time/chrono/m;->m(Lj$/time/temporal/l;)Lj$/time/chrono/m;

    move-result-object p0

    sget-object p1, Lj$/time/chrono/t;->c:Lj$/time/chrono/t;

    invoke-interface {p0, p1}, Lj$/time/chrono/m;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_18

    const/4 p0, 0x1

    return p0

    :cond_18
    const/4 p0, 0x0

    return p0
.end method

.method public final range()Lj$/time/temporal/r;
    .registers 5

    const-wide/16 v0, 0x34

    const-wide/16 v2, 0x35

    invoke-static {v0, v1, v2, v3}, Lj$/time/temporal/r;->f(JJ)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 1

    const-string p0, "WeekOfWeekBasedYear"

    return-object p0
.end method

.method public final v(Lj$/time/temporal/l;)Lj$/time/temporal/r;
    .registers 4

    .prologue
    invoke-virtual {p0, p1}, Lj$/time/temporal/e;->n(Lj$/time/temporal/l;)Z

    move-result p0

    if-eqz p0, :cond_1a

    invoke-static {p1}, Lj$/time/LocalDate;->E(Lj$/time/temporal/l;)Lj$/time/LocalDate;

    move-result-object p0

    invoke-static {p0}, Lj$/time/temporal/g;->J(Lj$/time/LocalDate;)I

    move-result p0

    invoke-static {p0}, Lj$/time/temporal/g;->K(I)I

    move-result p0

    int-to-long p0, p0

    const-wide/16 v0, 0x1

    invoke-static {v0, v1, p0, p1}, Lj$/time/temporal/r;->e(JJ)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_1a
    new-instance p0, Lj$/time/temporal/q;

    const-string p1, "Unsupported field: WeekOfWeekBasedYear"

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method
