.class public interface abstract Lj$/time/temporal/o;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# virtual methods
.method public abstract E(Lj$/time/temporal/l;)J
.end method

.method public abstract H(Lj$/time/temporal/Temporal;J)Lj$/time/temporal/Temporal;
.end method

.method public abstract isDateBased()Z
.end method

.method public abstract n(Lj$/time/temporal/l;)Z
.end method

.method public abstract range()Lj$/time/temporal/r;
.end method

.method public abstract v(Lj$/time/temporal/l;)Lj$/time/temporal/r;
.end method
