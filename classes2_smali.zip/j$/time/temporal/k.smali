.class public abstract Lj$/time/temporal/k;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final a:Lj$/time/temporal/j;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    sget-object v0, Lj$/time/temporal/j;->MODIFIED_JULIAN_DAY:Lj$/time/temporal/j;

    sput-object v0, Lj$/time/temporal/k;->a:Lj$/time/temporal/j;

    return-void
.end method
