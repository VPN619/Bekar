.class public final enum Lj$/time/temporal/d;
.super Lj$/time/temporal/g;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# direct methods
.method public constructor <init>()V
    .registers 3

    const-string v0, "QUARTER_OF_YEAR"

    const/4 v1, 0x1

    invoke-direct {p0, v0, v1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method


# virtual methods
.method public final E(Lj$/time/temporal/l;)J
    .registers 4

    .prologue
    invoke-virtual {p0, p1}, Lj$/time/temporal/d;->n(Lj$/time/temporal/l;)Z

    move-result p0

    if-eqz p0, :cond_13

    sget-object p0, Lj$/time/temporal/a;->MONTH_OF_YEAR:Lj$/time/temporal/a;

    invoke-interface {p1, p0}, Lj$/time/temporal/l;->f(Lj$/time/temporal/o;)J

    move-result-wide p0

    const-wide/16 v0, 0x2

    add-long/2addr p0, v0

    const-wide/16 v0, 0x3

    div-long/2addr p0, v0

    return-wide p0

    :cond_13
    new-instance p0, Lj$/time/temporal/q;

    const-string p1, "Unsupported field: QuarterOfYear"

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final H(Lj$/time/temporal/Temporal;J)Lj$/time/temporal/Temporal;
    .registers 8

    invoke-virtual {p0, p1}, Lj$/time/temporal/d;->E(Lj$/time/temporal/l;)J

    move-result-wide v0

    invoke-virtual {p0}, Lj$/time/temporal/d;->range()Lj$/time/temporal/r;

    move-result-object v2

    invoke-virtual {v2, p2, p3, p0}, Lj$/time/temporal/r;->b(JLj$/time/temporal/o;)V

    sget-object p0, Lj$/time/temporal/a;->MONTH_OF_YEAR:Lj$/time/temporal/a;

    invoke-interface {p1, p0}, Lj$/time/temporal/l;->f(Lj$/time/temporal/o;)J

    move-result-wide v2

    sub-long/2addr p2, v0

    const-wide/16 v0, 0x3

    mul-long/2addr p2, v0

    add-long/2addr p2, v2

    invoke-interface {p1, p2, p3, p0}, Lj$/time/temporal/Temporal;->g(JLj$/time/temporal/o;)Lj$/time/temporal/Temporal;

    move-result-object p0

    return-object p0
.end method

.method public final n(Lj$/time/temporal/l;)Z
    .registers 2

    .prologue
    sget-object p0, Lj$/time/temporal/a;->MONTH_OF_YEAR:Lj$/time/temporal/a;

    invoke-interface {p1, p0}, Lj$/time/temporal/l;->e(Lj$/time/temporal/o;)Z

    move-result p0

    if-eqz p0, :cond_18

    sget-object p0, Lj$/time/temporal/i;->a:Lj$/time/temporal/g;

    invoke-static {p1}, Lj$/time/chrono/m;->m(Lj$/time/temporal/l;)Lj$/time/chrono/m;

    move-result-object p0

    sget-object p1, Lj$/time/chrono/t;->c:Lj$/time/chrono/t;

    invoke-interface {p0, p1}, Lj$/time/chrono/m;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_18

    const/4 p0, 0x1

    return p0

    :cond_18
    const/4 p0, 0x0

    return p0
.end method

.method public final range()Lj$/time/temporal/r;
    .registers 5

    const-wide/16 v0, 0x1

    const-wide/16 v2, 0x4

    invoke-static {v0, v1, v2, v3}, Lj$/time/temporal/r;->e(JJ)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 1

    const-string p0, "QuarterOfYear"

    return-object p0
.end method

.method public final v(Lj$/time/temporal/l;)Lj$/time/temporal/r;
    .registers 2

    .prologue
    invoke-virtual {p0, p1}, Lj$/time/temporal/d;->n(Lj$/time/temporal/l;)Z

    move-result p1

    if-eqz p1, :cond_b

    invoke-virtual {p0}, Lj$/time/temporal/d;->range()Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_b
    new-instance p0, Lj$/time/temporal/q;

    const-string p1, "Unsupported field: QuarterOfYear"

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method
