.class public interface abstract Lj$/time/temporal/Temporal;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lj$/time/temporal/l;


# virtual methods
.method public a(JLj$/time/temporal/TemporalUnit;)Lj$/time/temporal/Temporal;
    .registers 6

    .prologue
    const-wide/high16 v0, -0x8000000000000000L

    cmp-long v0, p1, v0

    if-nez v0, :cond_16

    const-wide p1, 0x7fffffffffffffffL

    invoke-interface {p0, p1, p2, p3}, Lj$/time/temporal/Temporal;->j(JLj$/time/temporal/TemporalUnit;)Lj$/time/temporal/Temporal;

    move-result-object p0

    const-wide/16 p1, 0x1

    :goto_11
    invoke-interface {p0, p1, p2, p3}, Lj$/time/temporal/Temporal;->j(JLj$/time/temporal/TemporalUnit;)Lj$/time/temporal/Temporal;

    move-result-object p0

    return-object p0

    :cond_16
    neg-long p1, p1

    goto :goto_11
.end method

.method public abstract g(JLj$/time/temporal/o;)Lj$/time/temporal/Temporal;
.end method

.method public h(Lj$/time/LocalDate;)Lj$/time/temporal/Temporal;
    .registers 2

    invoke-interface {p1, p0}, Lj$/time/chrono/b;->c(Lj$/time/temporal/Temporal;)Lj$/time/temporal/Temporal;

    move-result-object p0

    return-object p0
.end method

.method public abstract j(JLj$/time/temporal/TemporalUnit;)Lj$/time/temporal/Temporal;
.end method

.method public abstract k(Lj$/time/temporal/Temporal;Lj$/time/temporal/TemporalUnit;)J
.end method
