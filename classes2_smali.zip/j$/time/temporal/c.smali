.class public final enum Lj$/time/temporal/c;
.super Lj$/time/temporal/g;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# direct methods
.method public constructor <init>()V
    .registers 3

    const-string v0, "DAY_OF_QUARTER"

    const/4 v1, 0x0

    invoke-direct {p0, v0, v1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method


# virtual methods
.method public final E(Lj$/time/temporal/l;)J
    .registers 5

    .prologue
    invoke-virtual {p0, p1}, Lj$/time/temporal/c;->n(Lj$/time/temporal/l;)Z

    move-result p0

    if-eqz p0, :cond_32

    sget-object p0, Lj$/time/temporal/a;->DAY_OF_YEAR:Lj$/time/temporal/a;

    invoke-interface {p1, p0}, Lj$/time/temporal/l;->d(Lj$/time/temporal/o;)I

    move-result p0

    sget-object v0, Lj$/time/temporal/a;->MONTH_OF_YEAR:Lj$/time/temporal/a;

    invoke-interface {p1, v0}, Lj$/time/temporal/l;->d(Lj$/time/temporal/o;)I

    move-result v0

    sget-object v1, Lj$/time/temporal/a;->YEAR:Lj$/time/temporal/a;

    invoke-interface {p1, v1}, Lj$/time/temporal/l;->f(Lj$/time/temporal/o;)J

    move-result-wide v1

    add-int/lit8 v0, v0, -0x1

    div-int/lit8 v0, v0, 0x3

    sget-object p1, Lj$/time/chrono/t;->c:Lj$/time/chrono/t;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v1, v2}, Lj$/time/chrono/t;->E(J)Z

    move-result p1

    if-eqz p1, :cond_29

    const/4 p1, 0x4

    goto :goto_2a

    :cond_29
    const/4 p1, 0x0

    :goto_2a
    add-int/2addr v0, p1

    sget-object p1, Lj$/time/temporal/g;->a:[I

    aget p1, p1, v0

    sub-int/2addr p0, p1

    int-to-long p0, p0

    return-wide p0

    :cond_32
    new-instance p0, Lj$/time/temporal/q;

    const-string p1, "Unsupported field: DayOfQuarter"

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final H(Lj$/time/temporal/Temporal;J)Lj$/time/temporal/Temporal;
    .registers 8

    invoke-virtual {p0, p1}, Lj$/time/temporal/c;->E(Lj$/time/temporal/l;)J

    move-result-wide v0

    invoke-virtual {p0}, Lj$/time/temporal/c;->range()Lj$/time/temporal/r;

    move-result-object v2

    invoke-virtual {v2, p2, p3, p0}, Lj$/time/temporal/r;->b(JLj$/time/temporal/o;)V

    sget-object p0, Lj$/time/temporal/a;->DAY_OF_YEAR:Lj$/time/temporal/a;

    invoke-interface {p1, p0}, Lj$/time/temporal/l;->f(Lj$/time/temporal/o;)J

    move-result-wide v2

    sub-long/2addr p2, v0

    add-long/2addr p2, v2

    invoke-interface {p1, p2, p3, p0}, Lj$/time/temporal/Temporal;->g(JLj$/time/temporal/o;)Lj$/time/temporal/Temporal;

    move-result-object p0

    return-object p0
.end method

.method public final n(Lj$/time/temporal/l;)Z
    .registers 2

    .prologue
    sget-object p0, Lj$/time/temporal/a;->DAY_OF_YEAR:Lj$/time/temporal/a;

    invoke-interface {p1, p0}, Lj$/time/temporal/l;->e(Lj$/time/temporal/o;)Z

    move-result p0

    if-eqz p0, :cond_28

    sget-object p0, Lj$/time/temporal/a;->MONTH_OF_YEAR:Lj$/time/temporal/a;

    invoke-interface {p1, p0}, Lj$/time/temporal/l;->e(Lj$/time/temporal/o;)Z

    move-result p0

    if-eqz p0, :cond_28

    sget-object p0, Lj$/time/temporal/a;->YEAR:Lj$/time/temporal/a;

    invoke-interface {p1, p0}, Lj$/time/temporal/l;->e(Lj$/time/temporal/o;)Z

    move-result p0

    if-eqz p0, :cond_28

    sget-object p0, Lj$/time/temporal/i;->a:Lj$/time/temporal/g;

    invoke-static {p1}, Lj$/time/chrono/m;->m(Lj$/time/temporal/l;)Lj$/time/chrono/m;

    move-result-object p0

    sget-object p1, Lj$/time/chrono/t;->c:Lj$/time/chrono/t;

    invoke-interface {p0, p1}, Lj$/time/chrono/m;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_28

    const/4 p0, 0x1

    return p0

    :cond_28
    const/4 p0, 0x0

    return p0
.end method

.method public final range()Lj$/time/temporal/r;
    .registers 5

    const-wide/16 v0, 0x5a

    const-wide/16 v2, 0x5c

    invoke-static {v0, v1, v2, v3}, Lj$/time/temporal/r;->f(JJ)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 1

    const-string p0, "DayOfQuarter"

    return-object p0
.end method

.method public final v(Lj$/time/temporal/l;)Lj$/time/temporal/r;
    .registers 11

    .prologue
    invoke-virtual {p0, p1}, Lj$/time/temporal/c;->n(Lj$/time/temporal/l;)Z

    move-result v0

    if-eqz v0, :cond_55

    sget-object v0, Lj$/time/temporal/g;->QUARTER_OF_YEAR:Lj$/time/temporal/g;

    invoke-interface {p1, v0}, Lj$/time/temporal/l;->f(Lj$/time/temporal/o;)J

    move-result-wide v0

    const-wide/16 v2, 0x1

    cmp-long v4, v0, v2

    const-wide/16 v5, 0x5b

    if-nez v4, :cond_31

    sget-object p0, Lj$/time/temporal/a;->YEAR:Lj$/time/temporal/a;

    invoke-interface {p1, p0}, Lj$/time/temporal/l;->f(Lj$/time/temporal/o;)J

    move-result-wide p0

    sget-object v0, Lj$/time/chrono/t;->c:Lj$/time/chrono/t;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p0, p1}, Lj$/time/chrono/t;->E(J)Z

    move-result p0

    if-eqz p0, :cond_2a

    invoke-static {v2, v3, v5, v6}, Lj$/time/temporal/r;->e(JJ)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_2a
    const-wide/16 p0, 0x5a

    invoke-static {v2, v3, p0, p1}, Lj$/time/temporal/r;->e(JJ)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_31
    const-wide/16 v7, 0x2

    cmp-long p1, v0, v7

    if-nez p1, :cond_3c

    invoke-static {v2, v3, v5, v6}, Lj$/time/temporal/r;->e(JJ)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_3c
    const-wide/16 v4, 0x3

    cmp-long p1, v0, v4

    if-eqz p1, :cond_4e

    const-wide/16 v4, 0x4

    cmp-long p1, v0, v4

    if-nez p1, :cond_49

    goto :goto_4e

    :cond_49
    invoke-virtual {p0}, Lj$/time/temporal/c;->range()Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_4e
    :goto_4e
    const-wide/16 p0, 0x5c

    invoke-static {v2, v3, p0, p1}, Lj$/time/temporal/r;->e(JJ)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_55
    new-instance p0, Lj$/time/temporal/q;

    const-string p1, "Unsupported field: DayOfQuarter"

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method
