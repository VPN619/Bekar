.class public abstract Lj$/time/temporal/p;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final a:Lj$/time/format/a;

.field public static final b:Lj$/time/format/a;

.field public static final c:Lj$/time/format/a;

.field public static final d:Lj$/time/format/a;

.field public static final e:Lj$/time/format/a;

.field public static final f:Lj$/time/format/a;

.field public static final g:Lj$/time/format/a;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lj$/time/format/a;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lj$/time/format/a;-><init>(I)V

    sput-object v0, Lj$/time/temporal/p;->a:Lj$/time/format/a;

    new-instance v0, Lj$/time/format/a;

    const/4 v1, 0x2

    invoke-direct {v0, v1}, Lj$/time/format/a;-><init>(I)V

    sput-object v0, Lj$/time/temporal/p;->b:Lj$/time/format/a;

    new-instance v0, Lj$/time/format/a;

    const/4 v1, 0x3

    invoke-direct {v0, v1}, Lj$/time/format/a;-><init>(I)V

    sput-object v0, Lj$/time/temporal/p;->c:Lj$/time/format/a;

    new-instance v0, Lj$/time/format/a;

    const/4 v1, 0x4

    invoke-direct {v0, v1}, Lj$/time/format/a;-><init>(I)V

    sput-object v0, Lj$/time/temporal/p;->d:Lj$/time/format/a;

    new-instance v0, Lj$/time/format/a;

    const/4 v1, 0x5

    invoke-direct {v0, v1}, Lj$/time/format/a;-><init>(I)V

    sput-object v0, Lj$/time/temporal/p;->e:Lj$/time/format/a;

    new-instance v0, Lj$/time/format/a;

    const/4 v1, 0x6

    invoke-direct {v0, v1}, Lj$/time/format/a;-><init>(I)V

    sput-object v0, Lj$/time/temporal/p;->f:Lj$/time/format/a;

    new-instance v0, Lj$/time/format/a;

    const/4 v1, 0x7

    invoke-direct {v0, v1}, Lj$/time/format/a;-><init>(I)V

    sput-object v0, Lj$/time/temporal/p;->g:Lj$/time/format/a;

    return-void
.end method
