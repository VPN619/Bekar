.class public final synthetic Lj$/time/temporal/n;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lj$/time/temporal/m;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:I


# direct methods
.method public synthetic constructor <init>(II)V
    .registers 3

    iput p2, p0, Lj$/time/temporal/n;->a:I

    iput p1, p0, Lj$/time/temporal/n;->b:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final c(Lj$/time/temporal/Temporal;)Lj$/time/temporal/Temporal;
    .registers 4

    .prologue
    iget v0, p0, Lj$/time/temporal/n;->a:I

    iget p0, p0, Lj$/time/temporal/n;->b:I

    packed-switch v0, :pswitch_data_3a

    sget-object v0, Lj$/time/temporal/a;->DAY_OF_WEEK:Lj$/time/temporal/a;

    invoke-interface {p1, v0}, Lj$/time/temporal/l;->d(Lj$/time/temporal/o;)I

    move-result v0

    if-ne v0, p0, :cond_10

    goto :goto_1f

    :cond_10
    sub-int/2addr p0, v0

    if-ltz p0, :cond_17

    rsub-int/lit8 p0, p0, 0x7

    :goto_15
    int-to-long v0, p0

    goto :goto_19

    :cond_17
    neg-int p0, p0

    goto :goto_15

    :goto_19
    sget-object p0, Lj$/time/temporal/ChronoUnit;->DAYS:Lj$/time/temporal/ChronoUnit;

    invoke-interface {p1, v0, v1, p0}, Lj$/time/temporal/Temporal;->a(JLj$/time/temporal/TemporalUnit;)Lj$/time/temporal/Temporal;

    move-result-object p1

    :goto_1f
    return-object p1

    :pswitch_20  #0x0
    sget-object v0, Lj$/time/temporal/a;->DAY_OF_WEEK:Lj$/time/temporal/a;

    invoke-interface {p1, v0}, Lj$/time/temporal/l;->d(Lj$/time/temporal/o;)I

    move-result v0

    if-ne v0, p0, :cond_29

    goto :goto_38

    :cond_29
    sub-int/2addr v0, p0

    if-ltz v0, :cond_30

    rsub-int/lit8 p0, v0, 0x7

    :goto_2e
    int-to-long v0, p0

    goto :goto_32

    :cond_30
    neg-int p0, v0

    goto :goto_2e

    :goto_32
    sget-object p0, Lj$/time/temporal/ChronoUnit;->DAYS:Lj$/time/temporal/ChronoUnit;

    invoke-interface {p1, v0, v1, p0}, Lj$/time/temporal/Temporal;->j(JLj$/time/temporal/TemporalUnit;)Lj$/time/temporal/Temporal;

    move-result-object p1

    :goto_38
    return-object p1

    nop

    :pswitch_data_3a
    .packed-switch 0x0
        :pswitch_20  #00000000
    .end packed-switch
.end method
