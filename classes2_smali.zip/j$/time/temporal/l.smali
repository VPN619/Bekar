.class public interface abstract Lj$/time/temporal/l;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# virtual methods
.method public b(Lj$/time/format/a;)Ljava/lang/Object;
    .registers 3

    .prologue
    sget-object v0, Lj$/time/temporal/p;->a:Lj$/time/format/a;

    if-eq p1, v0, :cond_12

    sget-object v0, Lj$/time/temporal/p;->b:Lj$/time/format/a;

    if-eq p1, v0, :cond_12

    sget-object v0, Lj$/time/temporal/p;->c:Lj$/time/format/a;

    if-ne p1, v0, :cond_d

    goto :goto_12

    :cond_d
    invoke-virtual {p1, p0}, Lj$/time/format/a;->a(Lj$/time/temporal/l;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :cond_12
    :goto_12
    const/4 p0, 0x0

    return-object p0
.end method

.method public d(Lj$/time/temporal/o;)I
    .registers 7

    .prologue
    invoke-interface {p0, p1}, Lj$/time/temporal/l;->i(Lj$/time/temporal/o;)Lj$/time/temporal/r;

    move-result-object v0

    iget-wide v1, v0, Lj$/time/temporal/r;->a:J

    const-wide/32 v3, -0x80000000

    cmp-long v1, v1, v3

    if-ltz v1, :cond_46

    iget-wide v1, v0, Lj$/time/temporal/r;->d:J

    const-wide/32 v3, 0x7fffffff

    cmp-long v1, v1, v3

    if-gtz v1, :cond_46

    invoke-interface {p0, p1}, Lj$/time/temporal/l;->f(Lj$/time/temporal/o;)J

    move-result-wide v1

    invoke-virtual {v0, v1, v2}, Lj$/time/temporal/r;->d(J)Z

    move-result p0

    if-eqz p0, :cond_22

    long-to-int p0, v1

    return p0

    :cond_22
    new-instance p0, Lj$/time/c;

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "Invalid value for "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p1, " (valid values "

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p1, "): "

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_46
    new-instance p0, Lj$/time/temporal/q;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Invalid field "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p1, " for get() method, use getLong() instead"

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public abstract e(Lj$/time/temporal/o;)Z
.end method

.method public abstract f(Lj$/time/temporal/o;)J
.end method

.method public i(Lj$/time/temporal/o;)Lj$/time/temporal/r;
    .registers 3

    .prologue
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_1b

    invoke-interface {p0, p1}, Lj$/time/temporal/l;->e(Lj$/time/temporal/o;)Z

    move-result p0

    if-eqz p0, :cond_f

    check-cast p1, Lj$/time/temporal/a;

    iget-object p0, p1, Lj$/time/temporal/a;->b:Lj$/time/temporal/r;

    return-object p0

    :cond_f
    new-instance p0, Lj$/time/temporal/q;

    const-string v0, "Unsupported field: "

    invoke-static {v0, p1}, Lj$/time/d;->a(Ljava/lang/String;Lj$/time/temporal/o;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_1b
    const-string v0, "field"

    invoke-static {p1, v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    invoke-interface {p1, p0}, Lj$/time/temporal/o;->v(Lj$/time/temporal/l;)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0
.end method
