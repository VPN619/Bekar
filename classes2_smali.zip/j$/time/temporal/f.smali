.class public final enum Lj$/time/temporal/f;
.super Lj$/time/temporal/g;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# direct methods
.method public constructor <init>()V
    .registers 3

    const-string v0, "WEEK_BASED_YEAR"

    const/4 v1, 0x3

    invoke-direct {p0, v0, v1}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method


# virtual methods
.method public final E(Lj$/time/temporal/l;)J
    .registers 2

    .prologue
    invoke-virtual {p0, p1}, Lj$/time/temporal/f;->n(Lj$/time/temporal/l;)Z

    move-result p0

    if-eqz p0, :cond_10

    invoke-static {p1}, Lj$/time/LocalDate;->E(Lj$/time/temporal/l;)Lj$/time/LocalDate;

    move-result-object p0

    invoke-static {p0}, Lj$/time/temporal/g;->J(Lj$/time/LocalDate;)I

    move-result p0

    int-to-long p0, p0

    return-wide p0

    :cond_10
    new-instance p0, Lj$/time/temporal/q;

    const-string p1, "Unsupported field: WeekBasedYear"

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final H(Lj$/time/temporal/Temporal;J)Lj$/time/temporal/Temporal;
    .registers 7

    .prologue
    invoke-virtual {p0, p1}, Lj$/time/temporal/f;->n(Lj$/time/temporal/l;)Z

    move-result p0

    if-eqz p0, :cond_44

    sget-object p0, Lj$/time/temporal/a;->YEAR:Lj$/time/temporal/a;

    iget-object p0, p0, Lj$/time/temporal/a;->b:Lj$/time/temporal/r;

    sget-object v0, Lj$/time/temporal/g;->WEEK_BASED_YEAR:Lj$/time/temporal/g;

    invoke-virtual {p0, p2, p3, v0}, Lj$/time/temporal/r;->a(JLj$/time/temporal/o;)I

    move-result p0

    invoke-static {p1}, Lj$/time/LocalDate;->E(Lj$/time/temporal/l;)Lj$/time/LocalDate;

    move-result-object p2

    sget-object p3, Lj$/time/temporal/a;->DAY_OF_WEEK:Lj$/time/temporal/a;

    invoke-virtual {p2, p3}, Lj$/time/LocalDate;->d(Lj$/time/temporal/o;)I

    move-result v0

    invoke-static {p2}, Lj$/time/temporal/g;->I(Lj$/time/LocalDate;)I

    move-result p2

    const/16 v1, 0x35

    if-ne p2, v1, :cond_2b

    invoke-static {p0}, Lj$/time/temporal/g;->K(I)I

    move-result v1

    const/16 v2, 0x34

    if-ne v1, v2, :cond_2b

    move p2, v2

    :cond_2b
    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {p0, v2, v1}, Lj$/time/LocalDate;->of(III)Lj$/time/LocalDate;

    move-result-object p0

    invoke-virtual {p0, p3}, Lj$/time/LocalDate;->d(Lj$/time/temporal/o;)I

    move-result p3

    sub-int/2addr v0, p3

    sub-int/2addr p2, v2

    mul-int/lit8 p2, p2, 0x7

    add-int/2addr p2, v0

    int-to-long p2, p2

    invoke-virtual {p0, p2, p3}, Lj$/time/LocalDate;->R(J)Lj$/time/LocalDate;

    move-result-object p0

    invoke-interface {p1, p0}, Lj$/time/temporal/Temporal;->h(Lj$/time/LocalDate;)Lj$/time/temporal/Temporal;

    move-result-object p0

    return-object p0

    :cond_44
    new-instance p0, Lj$/time/temporal/q;

    const-string p1, "Unsupported field: WeekBasedYear"

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final n(Lj$/time/temporal/l;)Z
    .registers 2

    .prologue
    sget-object p0, Lj$/time/temporal/a;->EPOCH_DAY:Lj$/time/temporal/a;

    invoke-interface {p1, p0}, Lj$/time/temporal/l;->e(Lj$/time/temporal/o;)Z

    move-result p0

    if-eqz p0, :cond_18

    sget-object p0, Lj$/time/temporal/i;->a:Lj$/time/temporal/g;

    invoke-static {p1}, Lj$/time/chrono/m;->m(Lj$/time/temporal/l;)Lj$/time/chrono/m;

    move-result-object p0

    sget-object p1, Lj$/time/chrono/t;->c:Lj$/time/chrono/t;

    invoke-interface {p0, p1}, Lj$/time/chrono/m;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_18

    const/4 p0, 0x1

    return p0

    :cond_18
    const/4 p0, 0x0

    return p0
.end method

.method public final range()Lj$/time/temporal/r;
    .registers 1

    sget-object p0, Lj$/time/temporal/a;->YEAR:Lj$/time/temporal/a;

    iget-object p0, p0, Lj$/time/temporal/a;->b:Lj$/time/temporal/r;

    return-object p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 1

    const-string p0, "WeekBasedYear"

    return-object p0
.end method

.method public final v(Lj$/time/temporal/l;)Lj$/time/temporal/r;
    .registers 2

    .prologue
    invoke-virtual {p0, p1}, Lj$/time/temporal/f;->n(Lj$/time/temporal/l;)Z

    move-result p0

    if-eqz p0, :cond_b

    sget-object p0, Lj$/time/temporal/a;->YEAR:Lj$/time/temporal/a;

    iget-object p0, p0, Lj$/time/temporal/a;->b:Lj$/time/temporal/r;

    return-object p0

    :cond_b
    new-instance p0, Lj$/time/temporal/q;

    const-string p1, "Unsupported field: WeekBasedYear"

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method
