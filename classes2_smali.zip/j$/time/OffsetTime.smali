.class public final Lj$/time/OffsetTime;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lj$/time/temporal/Temporal;
.implements Lj$/time/temporal/m;
.implements Ljava/lang/Comparable;
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lj$/time/temporal/Temporal;",
        "Lj$/time/temporal/m;",
        "Ljava/lang/Comparable<",
        "Lj$/time/OffsetTime;",
        ">;",
        "Ljava/io/Serializable;"
    }
.end annotation


# static fields
.field public static final synthetic c:I = 0x0

.field private static final serialVersionUID:J = 0x64d0affdfec1386cL


# instance fields
.field public final a:Lj$/time/LocalTime;

.field public final b:Lj$/time/ZoneOffset;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    sget-object v0, Lj$/time/LocalTime;->e:Lj$/time/LocalTime;

    sget-object v1, Lj$/time/ZoneOffset;->g:Lj$/time/ZoneOffset;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v0, v1}, Lj$/time/OffsetTime;->of(Lj$/time/LocalTime;Lj$/time/ZoneOffset;)Lj$/time/OffsetTime;

    sget-object v0, Lj$/time/LocalTime;->f:Lj$/time/LocalTime;

    sget-object v1, Lj$/time/ZoneOffset;->f:Lj$/time/ZoneOffset;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v0, v1}, Lj$/time/OffsetTime;->of(Lj$/time/LocalTime;Lj$/time/ZoneOffset;)Lj$/time/OffsetTime;

    return-void
.end method

.method public constructor <init>(Lj$/time/LocalTime;Lj$/time/ZoneOffset;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v0, "time"

    invoke-static {p1, v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-object v0, p1

    check-cast v0, Lj$/time/LocalTime;

    iput-object p1, p0, Lj$/time/OffsetTime;->a:Lj$/time/LocalTime;

    const-string p1, "offset"

    invoke-static {p2, p1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    move-object p1, p2

    check-cast p1, Lj$/time/ZoneOffset;

    iput-object p2, p0, Lj$/time/OffsetTime;->b:Lj$/time/ZoneOffset;

    return-void
.end method

.method public static of(Lj$/time/LocalTime;Lj$/time/ZoneOffset;)Lj$/time/OffsetTime;
    .registers 3

    new-instance v0, Lj$/time/OffsetTime;

    invoke-direct {v0, p0, p1}, Lj$/time/OffsetTime;-><init>(Lj$/time/LocalTime;Lj$/time/ZoneOffset;)V

    return-object v0
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .registers 2

    new-instance p0, Ljava/io/InvalidObjectException;

    const-string p1, "Deserialization via serialization delegate"

    invoke-direct {p0, p1}, Ljava/io/InvalidObjectException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private writeReplace()Ljava/lang/Object;
    .registers 3

    new-instance v0, Lj$/time/p;

    const/16 v1, 0x9

    invoke-direct {v0, v1, p0}, Lj$/time/p;-><init>(BLjava/lang/Object;)V

    return-object v0
.end method


# virtual methods
.method public final E(Lj$/time/LocalTime;Lj$/time/ZoneOffset;)Lj$/time/OffsetTime;
    .registers 4

    .prologue
    iget-object v0, p0, Lj$/time/OffsetTime;->a:Lj$/time/LocalTime;

    if-ne v0, p1, :cond_d

    iget-object v0, p0, Lj$/time/OffsetTime;->b:Lj$/time/ZoneOffset;

    invoke-virtual {v0, p2}, Lj$/time/ZoneOffset;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_d

    return-object p0

    :cond_d
    new-instance p0, Lj$/time/OffsetTime;

    invoke-direct {p0, p1, p2}, Lj$/time/OffsetTime;-><init>(Lj$/time/LocalTime;Lj$/time/ZoneOffset;)V

    return-object p0
.end method

.method public final a(JLj$/time/temporal/TemporalUnit;)Lj$/time/temporal/Temporal;
    .registers 6

    .prologue
    const-wide/high16 v0, -0x8000000000000000L

    cmp-long v0, p1, v0

    if-nez v0, :cond_16

    const-wide p1, 0x7fffffffffffffffL

    invoke-virtual {p0, p1, p2, p3}, Lj$/time/OffsetTime;->n(JLj$/time/temporal/TemporalUnit;)Lj$/time/OffsetTime;

    move-result-object p0

    const-wide/16 p1, 0x1

    :goto_11
    invoke-virtual {p0, p1, p2, p3}, Lj$/time/OffsetTime;->n(JLj$/time/temporal/TemporalUnit;)Lj$/time/OffsetTime;

    move-result-object p0

    return-object p0

    :cond_16
    neg-long p1, p1

    goto :goto_11
.end method

.method public final b(Lj$/time/format/a;)Ljava/lang/Object;
    .registers 6

    .prologue
    sget-object v0, Lj$/time/temporal/p;->d:Lj$/time/format/a;

    if-eq p1, v0, :cond_34

    sget-object v0, Lj$/time/temporal/p;->e:Lj$/time/format/a;

    if-ne p1, v0, :cond_9

    goto :goto_34

    :cond_9
    sget-object v0, Lj$/time/temporal/p;->a:Lj$/time/format/a;

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-ne p1, v0, :cond_11

    move v0, v2

    goto :goto_12

    :cond_11
    move v0, v1

    :goto_12
    sget-object v3, Lj$/time/temporal/p;->b:Lj$/time/format/a;

    if-ne p1, v3, :cond_17

    move v1, v2

    :cond_17
    or-int/2addr v0, v1

    if-nez v0, :cond_32

    sget-object v0, Lj$/time/temporal/p;->f:Lj$/time/format/a;

    if-ne p1, v0, :cond_1f

    goto :goto_32

    :cond_1f
    sget-object v0, Lj$/time/temporal/p;->g:Lj$/time/format/a;

    if-ne p1, v0, :cond_26

    iget-object p0, p0, Lj$/time/OffsetTime;->a:Lj$/time/LocalTime;

    return-object p0

    :cond_26
    sget-object v0, Lj$/time/temporal/p;->c:Lj$/time/format/a;

    if-ne p1, v0, :cond_2d

    sget-object p0, Lj$/time/temporal/ChronoUnit;->NANOS:Lj$/time/temporal/ChronoUnit;

    return-object p0

    :cond_2d
    invoke-virtual {p1, p0}, Lj$/time/format/a;->a(Lj$/time/temporal/l;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :cond_32
    :goto_32
    const/4 p0, 0x0

    return-object p0

    :cond_34
    :goto_34
    iget-object p0, p0, Lj$/time/OffsetTime;->b:Lj$/time/ZoneOffset;

    return-object p0
.end method

.method public final c(Lj$/time/temporal/Temporal;)Lj$/time/temporal/Temporal;
    .registers 5

    sget-object v0, Lj$/time/temporal/a;->NANO_OF_DAY:Lj$/time/temporal/a;

    iget-object v1, p0, Lj$/time/OffsetTime;->a:Lj$/time/LocalTime;

    invoke-virtual {v1}, Lj$/time/LocalTime;->P()J

    move-result-wide v1

    invoke-interface {p1, v1, v2, v0}, Lj$/time/temporal/Temporal;->g(JLj$/time/temporal/o;)Lj$/time/temporal/Temporal;

    move-result-object p1

    sget-object v0, Lj$/time/temporal/a;->OFFSET_SECONDS:Lj$/time/temporal/a;

    iget-object p0, p0, Lj$/time/OffsetTime;->b:Lj$/time/ZoneOffset;

    invoke-virtual {p0}, Lj$/time/ZoneOffset;->getTotalSeconds()I

    move-result p0

    int-to-long v1, p0

    invoke-interface {p1, v1, v2, v0}, Lj$/time/temporal/Temporal;->g(JLj$/time/temporal/o;)Lj$/time/temporal/Temporal;

    move-result-object p0

    return-object p0
.end method

.method public final compareTo(Ljava/lang/Object;)I
    .registers 6

    .prologue
    check-cast p1, Lj$/time/OffsetTime;

    iget-object v0, p0, Lj$/time/OffsetTime;->b:Lj$/time/ZoneOffset;

    iget-object v1, p1, Lj$/time/OffsetTime;->b:Lj$/time/ZoneOffset;

    invoke-virtual {v0, v1}, Lj$/time/ZoneOffset;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_15

    iget-object p0, p0, Lj$/time/OffsetTime;->a:Lj$/time/LocalTime;

    iget-object p1, p1, Lj$/time/OffsetTime;->a:Lj$/time/LocalTime;

    invoke-virtual {p0, p1}, Lj$/time/LocalTime;->n(Lj$/time/LocalTime;)I

    move-result p0

    return p0

    :cond_15
    invoke-virtual {p0}, Lj$/time/OffsetTime;->v()J

    move-result-wide v0

    invoke-virtual {p1}, Lj$/time/OffsetTime;->v()J

    move-result-wide v2

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Long;->compare(JJ)I

    move-result v0

    if-nez v0, :cond_2c

    iget-object p0, p0, Lj$/time/OffsetTime;->a:Lj$/time/LocalTime;

    iget-object p1, p1, Lj$/time/OffsetTime;->a:Lj$/time/LocalTime;

    invoke-virtual {p0, p1}, Lj$/time/LocalTime;->n(Lj$/time/LocalTime;)I

    move-result p0

    return p0

    :cond_2c
    return v0
.end method

.method public final e(Lj$/time/temporal/o;)Z
    .registers 3

    .prologue
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_12

    move-object p0, p1

    check-cast p0, Lj$/time/temporal/a;

    invoke-virtual {p0}, Lj$/time/temporal/a;->J()Z

    move-result p0

    if-nez p0, :cond_1a

    sget-object p0, Lj$/time/temporal/a;->OFFSET_SECONDS:Lj$/time/temporal/a;

    if-ne p1, p0, :cond_1c

    goto :goto_1a

    :cond_12
    if-eqz p1, :cond_1c

    invoke-interface {p1, p0}, Lj$/time/temporal/o;->n(Lj$/time/temporal/l;)Z

    move-result p0

    if-eqz p0, :cond_1c

    :cond_1a
    :goto_1a
    const/4 p0, 0x1

    return p0

    :cond_1c
    const/4 p0, 0x0

    return p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .prologue
    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lj$/time/OffsetTime;

    const/4 v2, 0x0

    if-eqz v1, :cond_20

    check-cast p1, Lj$/time/OffsetTime;

    iget-object v1, p0, Lj$/time/OffsetTime;->a:Lj$/time/LocalTime;

    iget-object v3, p1, Lj$/time/OffsetTime;->a:Lj$/time/LocalTime;

    invoke-virtual {v1, v3}, Lj$/time/LocalTime;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_20

    iget-object p0, p0, Lj$/time/OffsetTime;->b:Lj$/time/ZoneOffset;

    iget-object p1, p1, Lj$/time/OffsetTime;->b:Lj$/time/ZoneOffset;

    invoke-virtual {p0, p1}, Lj$/time/ZoneOffset;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_20

    return v0

    :cond_20
    return v2
.end method

.method public final f(Lj$/time/temporal/o;)J
    .registers 3

    .prologue
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_17

    sget-object v0, Lj$/time/temporal/a;->OFFSET_SECONDS:Lj$/time/temporal/a;

    if-ne p1, v0, :cond_10

    iget-object p0, p0, Lj$/time/OffsetTime;->b:Lj$/time/ZoneOffset;

    invoke-virtual {p0}, Lj$/time/ZoneOffset;->getTotalSeconds()I

    move-result p0

    int-to-long p0, p0

    return-wide p0

    :cond_10
    iget-object p0, p0, Lj$/time/OffsetTime;->a:Lj$/time/LocalTime;

    invoke-virtual {p0, p1}, Lj$/time/LocalTime;->f(Lj$/time/temporal/o;)J

    move-result-wide p0

    return-wide p0

    :cond_17
    invoke-interface {p1, p0}, Lj$/time/temporal/o;->E(Lj$/time/temporal/l;)J

    move-result-wide p0

    return-wide p0
.end method

.method public final g(JLj$/time/temporal/o;)Lj$/time/temporal/Temporal;
    .registers 6

    .prologue
    instance-of v0, p3, Lj$/time/temporal/a;

    if-eqz v0, :cond_26

    sget-object v0, Lj$/time/temporal/a;->OFFSET_SECONDS:Lj$/time/temporal/a;

    iget-object v1, p0, Lj$/time/OffsetTime;->a:Lj$/time/LocalTime;

    if-ne p3, v0, :cond_1b

    check-cast p3, Lj$/time/temporal/a;

    iget-object v0, p3, Lj$/time/temporal/a;->b:Lj$/time/temporal/r;

    invoke-virtual {v0, p1, p2, p3}, Lj$/time/temporal/r;->a(JLj$/time/temporal/o;)I

    move-result p1

    invoke-static {p1}, Lj$/time/ZoneOffset;->ofTotalSeconds(I)Lj$/time/ZoneOffset;

    move-result-object p1

    invoke-virtual {p0, v1, p1}, Lj$/time/OffsetTime;->E(Lj$/time/LocalTime;Lj$/time/ZoneOffset;)Lj$/time/OffsetTime;

    move-result-object p0

    return-object p0

    :cond_1b
    invoke-virtual {v1, p1, p2, p3}, Lj$/time/LocalTime;->R(JLj$/time/temporal/o;)Lj$/time/LocalTime;

    move-result-object p1

    iget-object p2, p0, Lj$/time/OffsetTime;->b:Lj$/time/ZoneOffset;

    invoke-virtual {p0, p1, p2}, Lj$/time/OffsetTime;->E(Lj$/time/LocalTime;Lj$/time/ZoneOffset;)Lj$/time/OffsetTime;

    move-result-object p0

    return-object p0

    :cond_26
    invoke-interface {p3, p0, p1, p2}, Lj$/time/temporal/o;->H(Lj$/time/temporal/Temporal;J)Lj$/time/temporal/Temporal;

    move-result-object p0

    check-cast p0, Lj$/time/OffsetTime;

    return-object p0
.end method

.method public getOffset()Lj$/time/ZoneOffset;
    .registers 1

    iget-object p0, p0, Lj$/time/OffsetTime;->b:Lj$/time/ZoneOffset;

    return-object p0
.end method

.method public final h(Lj$/time/LocalDate;)Lj$/time/temporal/Temporal;
    .registers 2

    invoke-interface {p1, p0}, Lj$/time/chrono/b;->c(Lj$/time/temporal/Temporal;)Lj$/time/temporal/Temporal;

    move-result-object p0

    check-cast p0, Lj$/time/OffsetTime;

    return-object p0
.end method

.method public final hashCode()I
    .registers 2

    iget-object v0, p0, Lj$/time/OffsetTime;->a:Lj$/time/LocalTime;

    invoke-virtual {v0}, Lj$/time/LocalTime;->hashCode()I

    move-result v0

    iget-object p0, p0, Lj$/time/OffsetTime;->b:Lj$/time/ZoneOffset;

    iget p0, p0, Lj$/time/ZoneOffset;->b:I

    xor-int/2addr p0, v0

    return p0
.end method

.method public final i(Lj$/time/temporal/o;)Lj$/time/temporal/r;
    .registers 3

    .prologue
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_14

    sget-object v0, Lj$/time/temporal/a;->OFFSET_SECONDS:Lj$/time/temporal/a;

    if-ne p1, v0, :cond_d

    check-cast p1, Lj$/time/temporal/a;

    iget-object p0, p1, Lj$/time/temporal/a;->b:Lj$/time/temporal/r;

    return-object p0

    :cond_d
    iget-object p0, p0, Lj$/time/OffsetTime;->a:Lj$/time/LocalTime;

    invoke-interface {p0, p1}, Lj$/time/temporal/l;->i(Lj$/time/temporal/o;)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_14
    invoke-interface {p1, p0}, Lj$/time/temporal/o;->v(Lj$/time/temporal/l;)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0
.end method

.method public final bridge synthetic j(JLj$/time/temporal/TemporalUnit;)Lj$/time/temporal/Temporal;
    .registers 4

    invoke-virtual {p0, p1, p2, p3}, Lj$/time/OffsetTime;->n(JLj$/time/temporal/TemporalUnit;)Lj$/time/OffsetTime;

    move-result-object p0

    return-object p0
.end method

.method public final k(Lj$/time/temporal/Temporal;Lj$/time/temporal/TemporalUnit;)J
    .registers 8

    .prologue
    instance-of v0, p1, Lj$/time/OffsetTime;

    const-wide/16 v1, 0x0

    if-eqz v0, :cond_9

    check-cast p1, Lj$/time/OffsetTime;

    goto :goto_17

    :cond_9
    :try_start_9
    invoke-static {p1}, Lj$/time/LocalTime;->E(Lj$/time/temporal/l;)Lj$/time/LocalTime;

    move-result-object v0

    invoke-static {p1}, Lj$/time/ZoneOffset;->K(Lj$/time/temporal/Temporal;)Lj$/time/ZoneOffset;

    move-result-object v3

    new-instance v4, Lj$/time/OffsetTime;

    invoke-direct {v4, v0, v3}, Lj$/time/OffsetTime;-><init>(Lj$/time/LocalTime;Lj$/time/ZoneOffset;)V
    :try_end_16
    .catch Lj$/time/c; {:try_start_9 .. :try_end_16} :catch_60

    move-object p1, v4

    :goto_17
    instance-of v0, p2, Lj$/time/temporal/ChronoUnit;

    if-eqz v0, :cond_5b

    invoke-virtual {p1}, Lj$/time/OffsetTime;->v()J

    move-result-wide v3

    invoke-virtual {p0}, Lj$/time/OffsetTime;->v()J

    move-result-wide p0

    sub-long/2addr v3, p0

    sget-object p0, Lj$/time/o;->a:[I

    move-object p1, p2

    check-cast p1, Lj$/time/temporal/ChronoUnit;

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    aget p0, p0, p1

    packed-switch p0, :pswitch_data_70

    const-string p0, "Unsupported unit: "

    invoke-static {p0, p2}, Lj$/time/h;->c(Ljava/lang/String;Ljava/lang/Object;)V

    return-wide v1

    :pswitch_38  #0x7
    const-wide p0, 0x274a48a78000L

    div-long/2addr v3, p0

    return-wide v3

    :pswitch_3f  #0x6
    const-wide p0, 0x34630b8a000L

    div-long/2addr v3, p0

    return-wide v3

    :pswitch_46  #0x5
    const-wide p0, 0xdf8475800L

    div-long/2addr v3, p0

    return-wide v3

    :pswitch_4d  #0x4
    const-wide/32 p0, 0x3b9aca00

    div-long/2addr v3, p0

    return-wide v3

    :pswitch_52  #0x3
    const-wide/32 p0, 0xf4240

    div-long/2addr v3, p0

    return-wide v3

    :pswitch_57  #0x2
    const-wide/16 p0, 0x3e8

    div-long/2addr v3, p0

    :pswitch_5a  #0x1
    return-wide v3

    :cond_5b
    invoke-interface {p2, p0, p1}, Lj$/time/temporal/TemporalUnit;->n(Lj$/time/temporal/Temporal;Lj$/time/temporal/Temporal;)J

    move-result-wide p0

    return-wide p0

    :catch_60
    move-exception p0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p2

    const-string v0, "Unable to obtain OffsetTime from TemporalAccessor: "

    invoke-static {v0, p1, p2, p0}, Lj$/time/h;->e(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Throwable;)V

    return-wide v1

    nop

    :pswitch_data_70
    .packed-switch 0x1
        :pswitch_5a  #00000001
        :pswitch_57  #00000002
        :pswitch_52  #00000003
        :pswitch_4d  #00000004
        :pswitch_46  #00000005
        :pswitch_3f  #00000006
        :pswitch_38  #00000007
    .end packed-switch
.end method

.method public final n(JLj$/time/temporal/TemporalUnit;)Lj$/time/OffsetTime;
    .registers 5

    .prologue
    instance-of v0, p3, Lj$/time/temporal/ChronoUnit;

    if-eqz v0, :cond_11

    iget-object v0, p0, Lj$/time/OffsetTime;->a:Lj$/time/LocalTime;

    invoke-virtual {v0, p1, p2, p3}, Lj$/time/LocalTime;->J(JLj$/time/temporal/TemporalUnit;)Lj$/time/LocalTime;

    move-result-object p1

    iget-object p2, p0, Lj$/time/OffsetTime;->b:Lj$/time/ZoneOffset;

    invoke-virtual {p0, p1, p2}, Lj$/time/OffsetTime;->E(Lj$/time/LocalTime;Lj$/time/ZoneOffset;)Lj$/time/OffsetTime;

    move-result-object p0

    return-object p0

    :cond_11
    invoke-interface {p3, p0, p1, p2}, Lj$/time/temporal/TemporalUnit;->v(Lj$/time/temporal/Temporal;J)Lj$/time/temporal/Temporal;

    move-result-object p0

    check-cast p0, Lj$/time/OffsetTime;

    return-object p0
.end method

.method public toLocalTime()Lj$/time/LocalTime;
    .registers 1

    iget-object p0, p0, Lj$/time/OffsetTime;->a:Lj$/time/LocalTime;

    return-object p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    iget-object v0, p0, Lj$/time/OffsetTime;->a:Lj$/time/LocalTime;

    invoke-virtual {v0}, Lj$/time/LocalTime;->toString()Ljava/lang/String;

    move-result-object v0

    iget-object p0, p0, Lj$/time/OffsetTime;->b:Lj$/time/ZoneOffset;

    iget-object p0, p0, Lj$/time/ZoneOffset;->c:Ljava/lang/String;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public final v()J
    .registers 7

    iget-object v0, p0, Lj$/time/OffsetTime;->a:Lj$/time/LocalTime;

    invoke-virtual {v0}, Lj$/time/LocalTime;->P()J

    move-result-wide v0

    iget-object p0, p0, Lj$/time/OffsetTime;->b:Lj$/time/ZoneOffset;

    invoke-virtual {p0}, Lj$/time/ZoneOffset;->getTotalSeconds()I

    move-result p0

    int-to-long v2, p0

    const-wide/32 v4, 0x3b9aca00

    mul-long/2addr v2, v4

    sub-long/2addr v0, v2

    return-wide v0
.end method
