.class public final Lj$/time/format/e;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lj$/time/format/f;


# instance fields
.field public final a:[Lj$/time/format/f;

.field public final b:Z


# direct methods
.method public constructor <init>(Ljava/util/List;Z)V
    .registers 4

    check-cast p1, Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v0

    new-array v0, v0, [Lj$/time/format/f;

    invoke-interface {p1, v0}, Ljava/util/List;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p1

    check-cast p1, [Lj$/time/format/f;

    invoke-direct {p0, p1, p2}, Lj$/time/format/e;-><init>([Lj$/time/format/f;Z)V

    return-void
.end method

.method public constructor <init>([Lj$/time/format/f;Z)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lj$/time/format/e;->a:[Lj$/time/format/f;

    iput-boolean p2, p0, Lj$/time/format/e;->b:Z

    return-void
.end method


# virtual methods
.method public final n(Lj$/time/format/p;Ljava/lang/StringBuilder;)Z
    .registers 9

    .prologue
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->length()I

    move-result v0

    const/4 v1, 0x1

    iget-boolean v2, p0, Lj$/time/format/e;->b:Z

    if-eqz v2, :cond_e

    iget v3, p1, Lj$/time/format/p;->c:I

    add-int/2addr v3, v1

    iput v3, p1, Lj$/time/format/p;->c:I

    :cond_e
    :try_start_e
    iget-object p0, p0, Lj$/time/format/e;->a:[Lj$/time/format/f;

    array-length v3, p0

    const/4 v4, 0x0

    :goto_12
    if-ge v4, v3, :cond_2c

    aget-object v5, p0, v4

    invoke-interface {v5, p1, p2}, Lj$/time/format/f;->n(Lj$/time/format/p;Ljava/lang/StringBuilder;)Z

    move-result v5

    if-nez v5, :cond_29

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->setLength(I)V
    :try_end_1f
    .catchall {:try_start_e .. :try_end_1f} :catchall_27

    if-eqz v2, :cond_2f

    :goto_21
    iget p0, p1, Lj$/time/format/p;->c:I

    sub-int/2addr p0, v1

    iput p0, p1, Lj$/time/format/p;->c:I

    return v1

    :catchall_27
    move-exception p0

    goto :goto_30

    :cond_29
    add-int/lit8 v4, v4, 0x1

    goto :goto_12

    :cond_2c
    if-eqz v2, :cond_2f

    goto :goto_21

    :cond_2f
    return v1

    :goto_30
    if-eqz v2, :cond_37

    iget p2, p1, Lj$/time/format/p;->c:I

    sub-int/2addr p2, v1

    iput p2, p1, Lj$/time/format/p;->c:I

    :cond_37
    throw p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 6

    .prologue
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v1, p0, Lj$/time/format/e;->a:[Lj$/time/format/f;

    if-eqz v1, :cond_2b

    iget-boolean p0, p0, Lj$/time/format/e;->b:Z

    if-eqz p0, :cond_10

    const-string v2, "["

    goto :goto_12

    :cond_10
    const-string v2, "("

    :goto_12
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    array-length v2, v1

    const/4 v3, 0x0

    :goto_17
    if-ge v3, v2, :cond_21

    aget-object v4, v1, v3

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    add-int/lit8 v3, v3, 0x1

    goto :goto_17

    :cond_21
    if-eqz p0, :cond_26

    const-string p0, "]"

    goto :goto_28

    :cond_26
    const-string p0, ")"

    :goto_28
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_2b
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
