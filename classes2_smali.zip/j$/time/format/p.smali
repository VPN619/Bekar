.class public final Lj$/time/format/p;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Lj$/time/temporal/l;

.field public final b:Lj$/time/format/DateTimeFormatter;

.field public c:I


# direct methods
.method public constructor <init>(Lj$/time/temporal/l;Lj$/time/format/DateTimeFormatter;)V
    .registers 12

    .prologue
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iget-object v0, p2, Lj$/time/format/DateTimeFormatter;->c:Lj$/time/chrono/m;

    if-nez v0, :cond_9

    goto/16 :goto_7d

    :cond_9
    sget-object v1, Lj$/time/temporal/p;->b:Lj$/time/format/a;

    invoke-interface {p1, v1}, Lj$/time/temporal/l;->b(Lj$/time/format/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lj$/time/chrono/m;

    sget-object v2, Lj$/time/temporal/p;->a:Lj$/time/format/a;

    invoke-interface {p1, v2}, Lj$/time/temporal/l;->b(Lj$/time/format/a;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lj$/time/ZoneId;

    invoke-static {v0, v1}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    const/4 v4, 0x0

    if-eqz v3, :cond_21

    move-object v0, v4

    :cond_21
    if-nez v0, :cond_24

    goto :goto_7d

    :cond_24
    if-eqz v0, :cond_28

    move-object v3, v0

    goto :goto_29

    :cond_28
    move-object v3, v1

    :goto_29
    if-eqz v0, :cond_77

    sget-object v5, Lj$/time/temporal/a;->EPOCH_DAY:Lj$/time/temporal/a;

    invoke-interface {p1, v5}, Lj$/time/temporal/l;->e(Lj$/time/temporal/o;)Z

    move-result v5

    if-eqz v5, :cond_3b

    move-object v0, p1

    check-cast v0, Lj$/time/temporal/Temporal;

    invoke-interface {v3, v0}, Lj$/time/chrono/m;->t(Lj$/time/temporal/Temporal;)Lj$/time/chrono/b;

    move-result-object v4

    goto :goto_77

    :cond_3b
    sget-object v5, Lj$/time/chrono/t;->c:Lj$/time/chrono/t;

    if-ne v0, v5, :cond_41

    if-eqz v1, :cond_77

    :cond_41
    invoke-static {}, Lj$/time/temporal/a;->values()[Lj$/time/temporal/a;

    move-result-object v1

    array-length v5, v1

    const/4 v6, 0x0

    :goto_47
    if-ge v6, v5, :cond_77

    aget-object v7, v1, v6

    invoke-virtual {v7}, Lj$/time/temporal/a;->isDateBased()Z

    move-result v8

    if-eqz v8, :cond_74

    invoke-interface {p1, v7}, Lj$/time/temporal/l;->e(Lj$/time/temporal/o;)Z

    move-result v7

    if-nez v7, :cond_58

    goto :goto_74

    :cond_58
    new-instance p0, Lj$/time/c;

    new-instance p2, Ljava/lang/StringBuilder;

    const-string v1, "Unable to apply override chronology \'"

    invoke-direct {p2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v0, "\' because the temporal object being formatted contains date fields but does not represent a whole date: "

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_74
    :goto_74
    add-int/lit8 v6, v6, 0x1

    goto :goto_47

    :cond_77
    :goto_77
    new-instance v0, Lj$/time/format/o;

    invoke-direct {v0, v4, p1, v3, v2}, Lj$/time/format/o;-><init>(Lj$/time/chrono/b;Lj$/time/temporal/l;Lj$/time/chrono/m;Lj$/time/ZoneId;)V

    move-object p1, v0

    :goto_7d
    iput-object p1, p0, Lj$/time/format/p;->a:Lj$/time/temporal/l;

    iput-object p2, p0, Lj$/time/format/p;->b:Lj$/time/format/DateTimeFormatter;

    return-void
.end method


# virtual methods
.method public final a(Lj$/time/temporal/o;)Ljava/lang/Long;
    .registers 3

    .prologue
    iget v0, p0, Lj$/time/format/p;->c:I

    iget-object p0, p0, Lj$/time/format/p;->a:Lj$/time/temporal/l;

    if-lez v0, :cond_e

    invoke-interface {p0, p1}, Lj$/time/temporal/l;->e(Lj$/time/temporal/o;)Z

    move-result v0

    if-nez v0, :cond_e

    const/4 p0, 0x0

    return-object p0

    :cond_e
    invoke-interface {p0, p1}, Lj$/time/temporal/l;->f(Lj$/time/temporal/o;)J

    move-result-wide p0

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    return-object p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lj$/time/format/p;->a:Lj$/time/temporal/l;

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
