.class public final Lj$/time/format/n;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final f:Lj$/time/format/a;


# instance fields
.field public a:Lj$/time/format/n;

.field public final b:Lj$/time/format/n;

.field public final c:Ljava/util/List;

.field public final d:Z

.field public e:I


# direct methods
.method static constructor <clinit>()V
    .registers 4

    new-instance v0, Lj$/time/format/a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lj$/time/format/a;-><init>(I)V

    sput-object v0, Lj$/time/format/n;->f:Lj$/time/format/a;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/16 v1, 0x47

    invoke-static {v1}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v1

    sget-object v2, Lj$/time/temporal/a;->ERA:Lj$/time/temporal/a;

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v1, 0x79

    invoke-static {v1}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v1

    sget-object v2, Lj$/time/temporal/a;->YEAR_OF_ERA:Lj$/time/temporal/a;

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v1, 0x75

    invoke-static {v1}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v1

    sget-object v2, Lj$/time/temporal/a;->YEAR:Lj$/time/temporal/a;

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v1, 0x51

    invoke-static {v1}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v1

    sget-object v2, Lj$/time/temporal/i;->a:Lj$/time/temporal/g;

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v1, 0x71

    invoke-static {v1}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v1

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v1, 0x4d

    invoke-static {v1}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v1

    sget-object v2, Lj$/time/temporal/a;->MONTH_OF_YEAR:Lj$/time/temporal/a;

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v1, 0x4c

    invoke-static {v1}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v1

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v1, 0x44

    invoke-static {v1}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v1

    sget-object v2, Lj$/time/temporal/a;->DAY_OF_YEAR:Lj$/time/temporal/a;

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v1, 0x64

    invoke-static {v1}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v1

    sget-object v2, Lj$/time/temporal/a;->DAY_OF_MONTH:Lj$/time/temporal/a;

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v1, 0x46

    invoke-static {v1}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v1

    sget-object v2, Lj$/time/temporal/a;->ALIGNED_DAY_OF_WEEK_IN_MONTH:Lj$/time/temporal/a;

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v1, 0x45

    invoke-static {v1}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v1

    sget-object v2, Lj$/time/temporal/a;->DAY_OF_WEEK:Lj$/time/temporal/a;

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v1, 0x63

    invoke-static {v1}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v1

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v1, 0x65

    invoke-static {v1}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v1

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v1, 0x61

    invoke-static {v1}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v1

    sget-object v2, Lj$/time/temporal/a;->AMPM_OF_DAY:Lj$/time/temporal/a;

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v1, 0x48

    invoke-static {v1}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v1

    sget-object v2, Lj$/time/temporal/a;->HOUR_OF_DAY:Lj$/time/temporal/a;

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v1, 0x6b

    invoke-static {v1}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v1

    sget-object v2, Lj$/time/temporal/a;->CLOCK_HOUR_OF_DAY:Lj$/time/temporal/a;

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v1, 0x4b

    invoke-static {v1}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v1

    sget-object v2, Lj$/time/temporal/a;->HOUR_OF_AMPM:Lj$/time/temporal/a;

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v1, 0x68

    invoke-static {v1}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v1

    sget-object v2, Lj$/time/temporal/a;->CLOCK_HOUR_OF_AMPM:Lj$/time/temporal/a;

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v1, 0x6d

    invoke-static {v1}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v1

    sget-object v2, Lj$/time/temporal/a;->MINUTE_OF_HOUR:Lj$/time/temporal/a;

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v1, 0x73

    invoke-static {v1}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v1

    sget-object v2, Lj$/time/temporal/a;->SECOND_OF_MINUTE:Lj$/time/temporal/a;

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v1, 0x53

    invoke-static {v1}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v1

    sget-object v2, Lj$/time/temporal/a;->NANO_OF_SECOND:Lj$/time/temporal/a;

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v1, 0x41

    invoke-static {v1}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v1

    sget-object v3, Lj$/time/temporal/a;->MILLI_OF_DAY:Lj$/time/temporal/a;

    invoke-virtual {v0, v1, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v1, 0x6e

    invoke-static {v1}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v1

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v1, 0x4e

    invoke-static {v1}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v1

    sget-object v2, Lj$/time/temporal/a;->NANO_OF_DAY:Lj$/time/temporal/a;

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v1, 0x67

    invoke-static {v1}, Ljava/lang/Character;->valueOf(C)Ljava/lang/Character;

    move-result-object v1

    sget-object v2, Lj$/time/temporal/k;->a:Lj$/time/temporal/j;

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>()V
    .registers 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p0, p0, Lj$/time/format/n;->a:Lj$/time/format/n;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lj$/time/format/n;->c:Ljava/util/List;

    const/4 v0, -0x1

    iput v0, p0, Lj$/time/format/n;->e:I

    const/4 v0, 0x0

    iput-object v0, p0, Lj$/time/format/n;->b:Lj$/time/format/n;

    const/4 v0, 0x0

    iput-boolean v0, p0, Lj$/time/format/n;->d:Z

    return-void
.end method

.method public constructor <init>(Lj$/time/format/n;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p0, p0, Lj$/time/format/n;->a:Lj$/time/format/n;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Lj$/time/format/n;->c:Ljava/util/List;

    const/4 v0, -0x1

    iput v0, p0, Lj$/time/format/n;->e:I

    iput-object p1, p0, Lj$/time/format/n;->b:Lj$/time/format/n;

    const/4 p1, 0x1

    iput-boolean p1, p0, Lj$/time/format/n;->d:Z

    return-void
.end method


# virtual methods
.method public final a(Lj$/time/format/DateTimeFormatter;)V
    .registers 4

    .prologue
    iget-object p1, p1, Lj$/time/format/DateTimeFormatter;->a:Lj$/time/format/e;

    iget-boolean v0, p1, Lj$/time/format/e;->b:Z

    if-nez v0, :cond_7

    goto :goto_10

    :cond_7
    new-instance v0, Lj$/time/format/e;

    iget-object p1, p1, Lj$/time/format/e;->a:[Lj$/time/format/f;

    const/4 v1, 0x0

    invoke-direct {v0, p1, v1}, Lj$/time/format/e;-><init>([Lj$/time/format/f;Z)V

    move-object p1, v0

    :goto_10
    invoke-virtual {p0, p1}, Lj$/time/format/n;->b(Lj$/time/format/f;)I

    return-void
.end method

.method public final b(Lj$/time/format/f;)I
    .registers 3

    const-string v0, "pp"

    invoke-static {p1, v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    iget-object v0, p0, Lj$/time/format/n;->a:Lj$/time/format/n;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, v0, Lj$/time/format/n;->c:Ljava/util/List;

    check-cast v0, Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object p0, p0, Lj$/time/format/n;->a:Lj$/time/format/n;

    const/4 p1, -0x1

    iput p1, p0, Lj$/time/format/n;->e:I

    iget-object p0, p0, Lj$/time/format/n;->c:Ljava/util/List;

    check-cast p0, Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result p0

    add-int/lit8 p0, p0, -0x1

    return p0
.end method

.method public final c(C)V
    .registers 3

    new-instance v0, Lj$/time/format/d;

    invoke-direct {v0, p1}, Lj$/time/format/d;-><init>(C)V

    invoke-virtual {p0, v0}, Lj$/time/format/n;->b(Lj$/time/format/f;)I

    return-void
.end method

.method public final d(Ljava/lang/String;)V
    .registers 4

    .prologue
    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_23

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v1, 0x1

    if-ne v0, v1, :cond_1b

    new-instance v0, Lj$/time/format/d;

    const/4 v1, 0x0

    invoke-virtual {p1, v1}, Ljava/lang/String;->charAt(I)C

    move-result p1

    invoke-direct {v0, p1}, Lj$/time/format/d;-><init>(C)V

    invoke-virtual {p0, v0}, Lj$/time/format/n;->b(Lj$/time/format/f;)I

    return-void

    :cond_1b
    new-instance v0, Lj$/time/format/l;

    invoke-direct {v0, p1}, Lj$/time/format/l;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v0}, Lj$/time/format/n;->b(Lj$/time/format/f;)I

    :cond_23
    return-void
.end method

.method public final e(Lj$/time/temporal/a;Ljava/util/Map;)V
    .registers 5

    const-string v0, "field"

    invoke-static {p1, v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    new-instance v0, Ljava/util/LinkedHashMap;

    invoke-direct {v0, p2}, Ljava/util/LinkedHashMap;-><init>(Ljava/util/Map;)V

    sget-object p2, Lj$/time/format/v;->FULL:Lj$/time/format/v;

    invoke-static {p2, v0}, Ljava/util/Collections;->singletonMap(Ljava/lang/Object;Ljava/lang/Object;)Ljava/util/Map;

    move-result-object v0

    new-instance v1, Lj$/time/format/r;

    invoke-direct {v1, v0}, Lj$/time/format/r;-><init>(Ljava/util/Map;)V

    new-instance v0, Lj$/time/format/b;

    invoke-direct {v0, v1}, Lj$/time/format/b;-><init>(Lj$/time/format/r;)V

    new-instance v1, Lj$/time/format/m;

    invoke-direct {v1, p1, p2, v0}, Lj$/time/format/m;-><init>(Lj$/time/temporal/o;Lj$/time/format/v;Lj$/time/format/b;)V

    invoke-virtual {p0, v1}, Lj$/time/format/n;->b(Lj$/time/format/f;)I

    return-void
.end method

.method public final f(Lj$/time/format/i;)V
    .registers 7

    .prologue
    iget-object v0, p0, Lj$/time/format/n;->a:Lj$/time/format/n;

    iget v1, v0, Lj$/time/format/n;->e:I

    if-ltz v1, :cond_42

    iget-object v0, v0, Lj$/time/format/n;->c:Ljava/util/List;

    check-cast v0, Ljava/util/ArrayList;

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lj$/time/format/i;

    iget v2, p1, Lj$/time/format/i;->b:I

    iget v3, p1, Lj$/time/format/i;->c:I

    if-ne v2, v3, :cond_2c

    iget-object v2, p1, Lj$/time/format/i;->d:Lj$/time/format/u;

    sget-object v4, Lj$/time/format/u;->NOT_NEGATIVE:Lj$/time/format/u;

    if-ne v2, v4, :cond_2c

    invoke-virtual {v0, v3}, Lj$/time/format/i;->b(I)Lj$/time/format/i;

    move-result-object v0

    invoke-virtual {p1}, Lj$/time/format/i;->a()Lj$/time/format/i;

    move-result-object p1

    invoke-virtual {p0, p1}, Lj$/time/format/n;->b(Lj$/time/format/f;)I

    iget-object p1, p0, Lj$/time/format/n;->a:Lj$/time/format/n;

    iput v1, p1, Lj$/time/format/n;->e:I

    goto :goto_38

    :cond_2c
    invoke-virtual {v0}, Lj$/time/format/i;->a()Lj$/time/format/i;

    move-result-object v0

    iget-object v2, p0, Lj$/time/format/n;->a:Lj$/time/format/n;

    invoke-virtual {p0, p1}, Lj$/time/format/n;->b(Lj$/time/format/f;)I

    move-result p1

    iput p1, v2, Lj$/time/format/n;->e:I

    :goto_38
    iget-object p0, p0, Lj$/time/format/n;->a:Lj$/time/format/n;

    iget-object p0, p0, Lj$/time/format/n;->c:Ljava/util/List;

    check-cast p0, Ljava/util/ArrayList;

    invoke-virtual {p0, v1, v0}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    return-void

    :cond_42
    invoke-virtual {p0, p1}, Lj$/time/format/n;->b(Lj$/time/format/f;)I

    move-result p0

    iput p0, v0, Lj$/time/format/n;->e:I

    return-void
.end method

.method public final g(Lj$/time/temporal/o;I)V
    .registers 5

    .prologue
    const-string v0, "field"

    invoke-static {p1, v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    const/4 v0, 0x1

    if-lt p2, v0, :cond_17

    const/16 v0, 0x13

    if-gt p2, v0, :cond_17

    new-instance v0, Lj$/time/format/i;

    sget-object v1, Lj$/time/format/u;->NOT_NEGATIVE:Lj$/time/format/u;

    invoke-direct {v0, p1, p2, p2, v1}, Lj$/time/format/i;-><init>(Lj$/time/temporal/o;IILj$/time/format/u;)V

    invoke-virtual {p0, v0}, Lj$/time/format/n;->f(Lj$/time/format/i;)V

    return-void

    :cond_17
    const-string p0, "The width must be from 1 to 19 inclusive but was "

    invoke-static {p0, p2}, Lj$/time/h;->f(Ljava/lang/String;I)V

    return-void
.end method

.method public final h(Lj$/time/temporal/o;IILj$/time/format/u;)V
    .registers 7

    .prologue
    if-ne p2, p3, :cond_a

    sget-object v0, Lj$/time/format/u;->NOT_NEGATIVE:Lj$/time/format/u;

    if-ne p4, v0, :cond_a

    invoke-virtual {p0, p1, p3}, Lj$/time/format/n;->g(Lj$/time/temporal/o;I)V

    return-void

    :cond_a
    const-string v0, "field"

    invoke-static {p1, v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    const-string v0, "signStyle"

    invoke-static {p4, v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    const/4 v0, 0x1

    if-lt p2, v0, :cond_4c

    const/16 v1, 0x13

    if-gt p2, v1, :cond_4c

    if-lt p3, v0, :cond_46

    if-gt p3, v1, :cond_46

    if-lt p3, p2, :cond_2a

    new-instance v0, Lj$/time/format/i;

    invoke-direct {v0, p1, p2, p3, p4}, Lj$/time/format/i;-><init>(Lj$/time/temporal/o;IILj$/time/format/u;)V

    invoke-virtual {p0, v0}, Lj$/time/format/n;->f(Lj$/time/format/i;)V

    return-void

    :cond_2a
    new-instance p0, Ljava/lang/IllegalArgumentException;

    new-instance p1, Ljava/lang/StringBuilder;

    const-string p4, "The maximum width must exceed or equal the minimum width but "

    invoke-direct {p1, p4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p3, " < "

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_46
    const-string p0, "The maximum width must be from 1 to 19 inclusive but was "

    invoke-static {p0, p3}, Lj$/time/h;->f(Ljava/lang/String;I)V

    return-void

    :cond_4c
    const-string p0, "The minimum width must be from 1 to 19 inclusive but was "

    invoke-static {p0, p2}, Lj$/time/h;->f(Ljava/lang/String;I)V

    return-void
.end method

.method public final i()V
    .registers 4

    .prologue
    iget-object v0, p0, Lj$/time/format/n;->a:Lj$/time/format/n;

    iget-object v1, v0, Lj$/time/format/n;->b:Lj$/time/format/n;

    if-eqz v1, :cond_2a

    iget-object v0, v0, Lj$/time/format/n;->c:Ljava/util/List;

    check-cast v0, Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    iget-object v1, p0, Lj$/time/format/n;->a:Lj$/time/format/n;

    if-lez v0, :cond_25

    new-instance v0, Lj$/time/format/e;

    iget-object v2, v1, Lj$/time/format/n;->c:Ljava/util/List;

    iget-boolean v1, v1, Lj$/time/format/n;->d:Z

    invoke-direct {v0, v2, v1}, Lj$/time/format/e;-><init>(Ljava/util/List;Z)V

    iget-object v1, p0, Lj$/time/format/n;->a:Lj$/time/format/n;

    iget-object v1, v1, Lj$/time/format/n;->b:Lj$/time/format/n;

    iput-object v1, p0, Lj$/time/format/n;->a:Lj$/time/format/n;

    invoke-virtual {p0, v0}, Lj$/time/format/n;->b(Lj$/time/format/f;)I

    return-void

    :cond_25
    iget-object v0, v1, Lj$/time/format/n;->b:Lj$/time/format/n;

    iput-object v0, p0, Lj$/time/format/n;->a:Lj$/time/format/n;

    return-void

    :cond_2a
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string v0, "Cannot call optionalEnd() as there was no previous call to optionalStart()"

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final j()V
    .registers 3

    iget-object v0, p0, Lj$/time/format/n;->a:Lj$/time/format/n;

    const/4 v1, -0x1

    iput v1, v0, Lj$/time/format/n;->e:I

    new-instance v1, Lj$/time/format/n;

    invoke-direct {v1, v0}, Lj$/time/format/n;-><init>(Lj$/time/format/n;)V

    iput-object v1, p0, Lj$/time/format/n;->a:Lj$/time/format/n;

    return-void
.end method

.method public final k(Lj$/time/format/t;Lj$/time/chrono/m;)Lj$/time/format/DateTimeFormatter;
    .registers 4

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    invoke-virtual {p0, v0, p1, p2}, Lj$/time/format/n;->l(Ljava/util/Locale;Lj$/time/format/t;Lj$/time/chrono/m;)Lj$/time/format/DateTimeFormatter;

    move-result-object p0

    return-object p0
.end method

.method public final l(Ljava/util/Locale;Lj$/time/format/t;Lj$/time/chrono/m;)Lj$/time/format/DateTimeFormatter;
    .registers 6

    .prologue
    const-string v0, "locale"

    invoke-static {p1, v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    :goto_5
    iget-object v0, p0, Lj$/time/format/n;->a:Lj$/time/format/n;

    iget-object v0, v0, Lj$/time/format/n;->b:Lj$/time/format/n;

    if-eqz v0, :cond_f

    invoke-virtual {p0}, Lj$/time/format/n;->i()V

    goto :goto_5

    :cond_f
    new-instance v0, Lj$/time/format/e;

    iget-object p0, p0, Lj$/time/format/n;->c:Ljava/util/List;

    const/4 v1, 0x0

    invoke-direct {v0, p0, v1}, Lj$/time/format/e;-><init>(Ljava/util/List;Z)V

    new-instance p0, Lj$/time/format/DateTimeFormatter;

    sget v1, Lj$/time/format/s;->a:I

    invoke-direct {p0, v0, p1, p2, p3}, Lj$/time/format/DateTimeFormatter;-><init>(Lj$/time/format/e;Ljava/util/Locale;Lj$/time/format/t;Lj$/time/chrono/m;)V

    return-object p0
.end method
