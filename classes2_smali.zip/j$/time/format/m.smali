.class public final Lj$/time/format/m;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lj$/time/format/f;


# instance fields
.field public final a:Lj$/time/temporal/o;

.field public final b:Lj$/time/format/v;

.field public final c:Lj$/time/format/b;

.field public volatile d:Lj$/time/format/i;


# direct methods
.method public constructor <init>(Lj$/time/temporal/o;Lj$/time/format/v;Lj$/time/format/b;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lj$/time/format/m;->a:Lj$/time/temporal/o;

    iput-object p2, p0, Lj$/time/format/m;->b:Lj$/time/format/v;

    iput-object p3, p0, Lj$/time/format/m;->c:Lj$/time/format/b;

    return-void
.end method


# virtual methods
.method public final n(Lj$/time/format/p;Ljava/lang/StringBuilder;)Z
    .registers 8

    .prologue
    iget-object v0, p0, Lj$/time/format/m;->a:Lj$/time/temporal/o;

    invoke-virtual {p1, v0}, Lj$/time/format/p;->a(Lj$/time/temporal/o;)Ljava/lang/Long;

    move-result-object v0

    if-nez v0, :cond_a

    const/4 p0, 0x0

    return p0

    :cond_a
    iget-object v1, p1, Lj$/time/format/p;->a:Lj$/time/temporal/l;

    sget-object v2, Lj$/time/temporal/p;->b:Lj$/time/format/a;

    invoke-interface {v1, v2}, Lj$/time/temporal/l;->b(Lj$/time/format/a;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lj$/time/chrono/m;

    if-eqz v1, :cond_2e

    sget-object v2, Lj$/time/chrono/t;->c:Lj$/time/chrono/t;

    if-ne v1, v2, :cond_1b

    goto :goto_2e

    :cond_1b
    iget-object v1, p0, Lj$/time/format/m;->c:Lj$/time/format/b;

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    iget-object v0, p0, Lj$/time/format/m;->b:Lj$/time/format/v;

    iget-object v4, p1, Lj$/time/format/p;->b:Lj$/time/format/DateTimeFormatter;

    iget-object v4, v4, Lj$/time/format/DateTimeFormatter;->b:Ljava/util/Locale;

    iget-object v1, v1, Lj$/time/format/b;->a:Lj$/time/format/r;

    invoke-virtual {v1, v2, v3, v0}, Lj$/time/format/r;->a(JLj$/time/format/v;)Ljava/lang/String;

    move-result-object v0

    goto :goto_40

    :cond_2e
    :goto_2e
    iget-object v1, p0, Lj$/time/format/m;->c:Lj$/time/format/b;

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    iget-object v0, p0, Lj$/time/format/m;->b:Lj$/time/format/v;

    iget-object v4, p1, Lj$/time/format/p;->b:Lj$/time/format/DateTimeFormatter;

    iget-object v4, v4, Lj$/time/format/DateTimeFormatter;->b:Ljava/util/Locale;

    iget-object v1, v1, Lj$/time/format/b;->a:Lj$/time/format/r;

    invoke-virtual {v1, v2, v3, v0}, Lj$/time/format/r;->a(JLj$/time/format/v;)Ljava/lang/String;

    move-result-object v0

    :goto_40
    const/4 v1, 0x1

    if-nez v0, :cond_5b

    iget-object v0, p0, Lj$/time/format/m;->d:Lj$/time/format/i;

    if-nez v0, :cond_54

    new-instance v0, Lj$/time/format/i;

    iget-object v2, p0, Lj$/time/format/m;->a:Lj$/time/temporal/o;

    const/16 v3, 0x13

    sget-object v4, Lj$/time/format/u;->NORMAL:Lj$/time/format/u;

    invoke-direct {v0, v2, v1, v3, v4}, Lj$/time/format/i;-><init>(Lj$/time/temporal/o;IILj$/time/format/u;)V

    iput-object v0, p0, Lj$/time/format/m;->d:Lj$/time/format/i;

    :cond_54
    iget-object p0, p0, Lj$/time/format/m;->d:Lj$/time/format/i;

    invoke-virtual {p0, p1, p2}, Lj$/time/format/i;->n(Lj$/time/format/p;Ljava/lang/StringBuilder;)Z

    move-result p0

    return p0

    :cond_5b
    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    return v1
.end method

.method public final toString()Ljava/lang/String;
    .registers 5

    .prologue
    sget-object v0, Lj$/time/format/v;->FULL:Lj$/time/format/v;

    const-string v1, ")"

    const-string v2, "Text("

    iget-object v3, p0, Lj$/time/format/m;->b:Lj$/time/format/v;

    iget-object p0, p0, Lj$/time/format/m;->a:Lj$/time/temporal/o;

    if-ne v3, v0, :cond_1c

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_1c
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p0, ","

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
