.class public final Lj$/time/format/h;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lj$/time/format/f;


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    iput p1, p0, Lj$/time/format/h;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final n(Lj$/time/format/p;Ljava/lang/StringBuilder;)Z
    .registers 21

    .prologue
    move-object/from16 v0, p1

    move-object/from16 v1, p0

    move-object/from16 v2, p2

    iget v1, v1, Lj$/time/format/h;->a:I

    const/4 v3, 0x1

    const/4 v4, 0x0

    packed-switch v1, :pswitch_data_136

    sget-object v1, Lj$/time/format/n;->f:Lj$/time/format/a;

    iget-object v5, v0, Lj$/time/format/p;->a:Lj$/time/temporal/l;

    invoke-interface {v5, v1}, Lj$/time/temporal/l;->b(Lj$/time/format/a;)Ljava/lang/Object;

    move-result-object v6

    if-nez v6, :cond_38

    iget v0, v0, Lj$/time/format/p;->c:I

    if-eqz v0, :cond_1c

    goto :goto_38

    :cond_1c
    new-instance v0, Lj$/time/c;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, "Unable to extract "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, " from temporal "

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_38
    :goto_38
    check-cast v6, Lj$/time/ZoneId;

    if-nez v6, :cond_3e

    move v3, v4

    goto :goto_45

    :cond_3e
    invoke-virtual {v6}, Lj$/time/ZoneId;->getId()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_45
    return v3

    :pswitch_46  #0x0
    sget-object v1, Lj$/time/temporal/a;->INSTANT_SECONDS:Lj$/time/temporal/a;

    invoke-virtual {v0, v1}, Lj$/time/format/p;->a(Lj$/time/temporal/o;)Ljava/lang/Long;

    move-result-object v1

    iget-object v0, v0, Lj$/time/format/p;->a:Lj$/time/temporal/l;

    sget-object v5, Lj$/time/temporal/a;->NANO_OF_SECOND:Lj$/time/temporal/a;

    invoke-interface {v0, v5}, Lj$/time/temporal/l;->e(Lj$/time/temporal/o;)Z

    move-result v6

    if-eqz v6, :cond_5f

    invoke-interface {v0, v5}, Lj$/time/temporal/l;->f(Lj$/time/temporal/o;)J

    move-result-wide v6

    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    goto :goto_60

    :cond_5f
    const/4 v0, 0x0

    :goto_60
    if-nez v1, :cond_65

    move v3, v4

    goto/16 :goto_126

    :cond_65
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v6

    const-wide/16 v8, 0x0

    if-eqz v0, :cond_72

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    goto :goto_73

    :cond_72
    move-wide v0, v8

    :goto_73
    iget-object v10, v5, Lj$/time/temporal/a;->b:Lj$/time/temporal/r;

    invoke-virtual {v10, v0, v1, v5}, Lj$/time/temporal/r;->a(JLj$/time/temporal/o;)I

    move-result v0

    const-wide v10, -0xe79747c00L

    cmp-long v1, v6, v10

    const-string v5, ":00"

    const-wide/16 v10, 0x1

    const-wide v12, 0xe79747c00L

    const-wide v14, 0x497968bd80L

    if-ltz v1, :cond_c3

    const-wide v16, 0x3afff44180L

    sub-long v6, v6, v16

    invoke-static {v6, v7, v14, v15}, Ljava/lang/Math;->floorDiv(JJ)J

    move-result-wide v16

    add-long v10, v16, v10

    invoke-static {v6, v7, v14, v15}, Ljava/lang/Math;->floorMod(JJ)J

    move-result-wide v6

    sub-long/2addr v6, v12

    sget-object v1, Lj$/time/ZoneOffset;->UTC:Lj$/time/ZoneOffset;

    invoke-static {v6, v7, v4, v1}, Lj$/time/LocalDateTime;->H(JILj$/time/ZoneOffset;)Lj$/time/LocalDateTime;

    move-result-object v1

    cmp-long v6, v10, v8

    if-lez v6, :cond_b4

    const/16 v6, 0x2b

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v10, v11}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    :cond_b4
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    iget-object v1, v1, Lj$/time/LocalDateTime;->b:Lj$/time/LocalTime;

    invoke-virtual {v1}, Lj$/time/LocalTime;->getSecond()I

    move-result v1

    if-nez v1, :cond_10c

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_10c

    :cond_c3
    add-long/2addr v6, v12

    move-wide/from16 p0, v8

    div-long v8, v6, v14

    rem-long/2addr v6, v14

    sub-long v12, v6, v12

    sget-object v1, Lj$/time/ZoneOffset;->UTC:Lj$/time/ZoneOffset;

    invoke-static {v12, v13, v4, v1}, Lj$/time/LocalDateTime;->H(JILj$/time/ZoneOffset;)Lj$/time/LocalDateTime;

    move-result-object v1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->length()I

    move-result v12

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    iget-object v13, v1, Lj$/time/LocalDateTime;->b:Lj$/time/LocalTime;

    invoke-virtual {v13}, Lj$/time/LocalTime;->getSecond()I

    move-result v13

    if-nez v13, :cond_e3

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_e3
    cmp-long v5, v8, p0

    if-gez v5, :cond_10c

    iget-object v1, v1, Lj$/time/LocalDateTime;->a:Lj$/time/LocalDate;

    invoke-virtual {v1}, Lj$/time/LocalDate;->getYear()I

    move-result v1

    const/16 v5, -0x2710

    if-ne v1, v5, :cond_fc

    add-int/lit8 v1, v12, 0x2

    sub-long/2addr v8, v10

    invoke-static {v8, v9}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v12, v1, v5}, Ljava/lang/StringBuilder;->replace(IILjava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_10c

    :cond_fc
    cmp-long v1, v6, p0

    if-nez v1, :cond_104

    invoke-virtual {v2, v12, v8, v9}, Ljava/lang/StringBuilder;->insert(IJ)Ljava/lang/StringBuilder;

    goto :goto_10c

    :cond_104
    add-int/2addr v12, v3

    invoke-static {v8, v9}, Ljava/lang/Math;->abs(J)J

    move-result-wide v5

    invoke-virtual {v2, v12, v5, v6}, Ljava/lang/StringBuilder;->insert(IJ)Ljava/lang/StringBuilder;

    :cond_10c
    :goto_10c
    if-gtz v0, :cond_10f

    goto :goto_121

    :cond_10f
    const/16 v1, 0x2e

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const v1, 0x5f5e100

    :goto_117
    if-gtz v0, :cond_127

    rem-int/lit8 v5, v4, 0x3

    if-nez v5, :cond_127

    const/4 v5, -0x2

    if-ge v4, v5, :cond_121

    goto :goto_127

    :cond_121
    :goto_121
    const/16 v0, 0x5a

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :goto_126
    return v3

    :cond_127
    :goto_127
    div-int v5, v0, v1

    add-int/lit8 v6, v5, 0x30

    int-to-char v6, v6

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    mul-int/2addr v5, v1

    sub-int/2addr v0, v5

    div-int/lit8 v1, v1, 0xa

    add-int/lit8 v4, v4, 0x1

    goto :goto_117

    :pswitch_data_136
    .packed-switch 0x0
        :pswitch_46  #00000000
    .end packed-switch
.end method

.method public final toString()Ljava/lang/String;
    .registers 1

    .prologue
    iget p0, p0, Lj$/time/format/h;->a:I

    packed-switch p0, :pswitch_data_c

    const-string p0, "ZoneRegionId()"

    return-object p0

    :pswitch_8  #0x0
    const-string p0, "Instant()"

    return-object p0

    nop

    :pswitch_data_c
    .packed-switch 0x0
        :pswitch_8  #00000000
    .end packed-switch
.end method
