.class public final synthetic Lj$/time/format/a;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    iput p1, p0, Lj$/time/format/a;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a(Lj$/time/temporal/l;)Ljava/lang/Object;
    .registers 4

    .prologue
    iget p0, p0, Lj$/time/format/a;->a:I

    sget-object v0, Lj$/time/temporal/p;->a:Lj$/time/format/a;

    const/4 v1, 0x0

    packed-switch p0, :pswitch_data_74

    sget-object p0, Lj$/time/temporal/a;->NANO_OF_DAY:Lj$/time/temporal/a;

    invoke-interface {p1, p0}, Lj$/time/temporal/l;->e(Lj$/time/temporal/o;)Z

    move-result v0

    if-eqz v0, :cond_18

    invoke-interface {p1, p0}, Lj$/time/temporal/l;->f(Lj$/time/temporal/o;)J

    move-result-wide p0

    invoke-static {p0, p1}, Lj$/time/LocalTime;->I(J)Lj$/time/LocalTime;

    move-result-object v1

    :cond_18
    return-object v1

    :pswitch_19  #0x6
    sget-object p0, Lj$/time/temporal/a;->EPOCH_DAY:Lj$/time/temporal/a;

    invoke-interface {p1, p0}, Lj$/time/temporal/l;->e(Lj$/time/temporal/o;)Z

    move-result v0

    if-eqz v0, :cond_29

    invoke-interface {p1, p0}, Lj$/time/temporal/l;->f(Lj$/time/temporal/o;)J

    move-result-wide p0

    invoke-static {p0, p1}, Lj$/time/LocalDate;->P(J)Lj$/time/LocalDate;

    move-result-object v1

    :cond_29
    return-object v1

    :pswitch_2a  #0x5
    invoke-interface {p1, v0}, Lj$/time/temporal/l;->b(Lj$/time/format/a;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lj$/time/ZoneId;

    if-eqz p0, :cond_33

    goto :goto_3b

    :cond_33
    sget-object p0, Lj$/time/temporal/p;->d:Lj$/time/format/a;

    invoke-interface {p1, p0}, Lj$/time/temporal/l;->b(Lj$/time/format/a;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lj$/time/ZoneId;

    :goto_3b
    return-object p0

    :pswitch_3c  #0x4
    sget-object p0, Lj$/time/temporal/a;->OFFSET_SECONDS:Lj$/time/temporal/a;

    invoke-interface {p1, p0}, Lj$/time/temporal/l;->e(Lj$/time/temporal/o;)Z

    move-result v0

    if-eqz v0, :cond_4c

    invoke-interface {p1, p0}, Lj$/time/temporal/l;->d(Lj$/time/temporal/o;)I

    move-result p0

    invoke-static {p0}, Lj$/time/ZoneOffset;->ofTotalSeconds(I)Lj$/time/ZoneOffset;

    move-result-object v1

    :cond_4c
    return-object v1

    :pswitch_4d  #0x3
    sget-object p0, Lj$/time/temporal/p;->c:Lj$/time/format/a;

    invoke-interface {p1, p0}, Lj$/time/temporal/l;->b(Lj$/time/format/a;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lj$/time/temporal/TemporalUnit;

    return-object p0

    :pswitch_56  #0x2
    sget-object p0, Lj$/time/temporal/p;->b:Lj$/time/format/a;

    invoke-interface {p1, p0}, Lj$/time/temporal/l;->b(Lj$/time/format/a;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lj$/time/chrono/m;

    return-object p0

    :pswitch_5f  #0x1
    invoke-interface {p1, v0}, Lj$/time/temporal/l;->b(Lj$/time/format/a;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lj$/time/ZoneId;

    return-object p0

    :pswitch_66  #0x0
    invoke-interface {p1, v0}, Lj$/time/temporal/l;->b(Lj$/time/format/a;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lj$/time/ZoneId;

    if-eqz p0, :cond_73

    instance-of p1, p0, Lj$/time/ZoneOffset;

    if-nez p1, :cond_73

    move-object v1, p0

    :cond_73
    return-object v1

    :pswitch_data_74
    .packed-switch 0x0
        :pswitch_66  #00000000
        :pswitch_5f  #00000001
        :pswitch_56  #00000002
        :pswitch_4d  #00000003
        :pswitch_3c  #00000004
        :pswitch_2a  #00000005
        :pswitch_19  #00000006
    .end packed-switch
.end method

.method public toString()Ljava/lang/String;
    .registers 2

    .prologue
    iget v0, p0, Lj$/time/format/a;->a:I

    packed-switch v0, :pswitch_data_20

    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :pswitch_a  #0x7
    const-string p0, "LocalTime"

    return-object p0

    :pswitch_d  #0x6
    const-string p0, "LocalDate"

    return-object p0

    :pswitch_10  #0x5
    const-string p0, "Zone"

    return-object p0

    :pswitch_13  #0x4
    const-string p0, "ZoneOffset"

    return-object p0

    :pswitch_16  #0x3
    const-string p0, "Precision"

    return-object p0

    :pswitch_19  #0x2
    const-string p0, "Chronology"

    return-object p0

    :pswitch_1c  #0x1
    const-string p0, "ZoneId"

    return-object p0

    nop

    :pswitch_data_20
    .packed-switch 0x1
        :pswitch_1c  #00000001
        :pswitch_19  #00000002
        :pswitch_16  #00000003
        :pswitch_13  #00000004
        :pswitch_10  #00000005
        :pswitch_d  #00000006
        :pswitch_a  #00000007
    .end packed-switch
.end method
