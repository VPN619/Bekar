.class public final Lj$/time/format/o;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lj$/time/temporal/l;


# instance fields
.field public final synthetic a:Lj$/time/chrono/b;

.field public final synthetic b:Lj$/time/temporal/l;

.field public final synthetic c:Lj$/time/chrono/m;

.field public final synthetic d:Lj$/time/ZoneId;


# direct methods
.method public constructor <init>(Lj$/time/chrono/b;Lj$/time/temporal/l;Lj$/time/chrono/m;Lj$/time/ZoneId;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lj$/time/format/o;->a:Lj$/time/chrono/b;

    iput-object p2, p0, Lj$/time/format/o;->b:Lj$/time/temporal/l;

    iput-object p3, p0, Lj$/time/format/o;->c:Lj$/time/chrono/m;

    iput-object p4, p0, Lj$/time/format/o;->d:Lj$/time/ZoneId;

    return-void
.end method


# virtual methods
.method public final b(Lj$/time/format/a;)Ljava/lang/Object;
    .registers 3

    .prologue
    sget-object v0, Lj$/time/temporal/p;->b:Lj$/time/format/a;

    if-ne p1, v0, :cond_7

    iget-object p0, p0, Lj$/time/format/o;->c:Lj$/time/chrono/m;

    return-object p0

    :cond_7
    sget-object v0, Lj$/time/temporal/p;->a:Lj$/time/format/a;

    if-ne p1, v0, :cond_e

    iget-object p0, p0, Lj$/time/format/o;->d:Lj$/time/ZoneId;

    return-object p0

    :cond_e
    sget-object v0, Lj$/time/temporal/p;->c:Lj$/time/format/a;

    if-ne p1, v0, :cond_19

    iget-object p0, p0, Lj$/time/format/o;->b:Lj$/time/temporal/l;

    invoke-interface {p0, p1}, Lj$/time/temporal/l;->b(Lj$/time/format/a;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :cond_19
    invoke-virtual {p1, p0}, Lj$/time/format/a;->a(Lj$/time/temporal/l;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final e(Lj$/time/temporal/o;)Z
    .registers 4

    .prologue
    iget-object v0, p0, Lj$/time/format/o;->a:Lj$/time/chrono/b;

    if-eqz v0, :cond_f

    invoke-interface {p1}, Lj$/time/temporal/o;->isDateBased()Z

    move-result v1

    if-eqz v1, :cond_f

    invoke-interface {v0, p1}, Lj$/time/chrono/b;->e(Lj$/time/temporal/o;)Z

    move-result p0

    return p0

    :cond_f
    iget-object p0, p0, Lj$/time/format/o;->b:Lj$/time/temporal/l;

    invoke-interface {p0, p1}, Lj$/time/temporal/l;->e(Lj$/time/temporal/o;)Z

    move-result p0

    return p0
.end method

.method public final f(Lj$/time/temporal/o;)J
    .registers 4

    .prologue
    iget-object v0, p0, Lj$/time/format/o;->a:Lj$/time/chrono/b;

    if-eqz v0, :cond_f

    invoke-interface {p1}, Lj$/time/temporal/o;->isDateBased()Z

    move-result v1

    if-eqz v1, :cond_f

    invoke-interface {v0, p1}, Lj$/time/temporal/l;->f(Lj$/time/temporal/o;)J

    move-result-wide p0

    return-wide p0

    :cond_f
    iget-object p0, p0, Lj$/time/format/o;->b:Lj$/time/temporal/l;

    invoke-interface {p0, p1}, Lj$/time/temporal/l;->f(Lj$/time/temporal/o;)J

    move-result-wide p0

    return-wide p0
.end method

.method public final i(Lj$/time/temporal/o;)Lj$/time/temporal/r;
    .registers 4

    .prologue
    iget-object v0, p0, Lj$/time/format/o;->a:Lj$/time/chrono/b;

    if-eqz v0, :cond_f

    invoke-interface {p1}, Lj$/time/temporal/o;->isDateBased()Z

    move-result v1

    if-eqz v1, :cond_f

    invoke-interface {v0, p1}, Lj$/time/temporal/l;->i(Lj$/time/temporal/o;)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_f
    iget-object p0, p0, Lj$/time/format/o;->b:Lj$/time/temporal/l;

    invoke-interface {p0, p1}, Lj$/time/temporal/l;->i(Lj$/time/temporal/o;)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 5

    .prologue
    const-string v0, ""

    iget-object v1, p0, Lj$/time/format/o;->c:Lj$/time/chrono/m;

    if-eqz v1, :cond_15

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v3, " with chronology "

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    goto :goto_16

    :cond_15
    move-object v1, v0

    :goto_16
    iget-object v2, p0, Lj$/time/format/o;->d:Lj$/time/ZoneId;

    if-eqz v2, :cond_28

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v3, " with zone "

    invoke-direct {v0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    :cond_28
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    iget-object p0, p0, Lj$/time/format/o;->b:Lj$/time/temporal/l;

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
