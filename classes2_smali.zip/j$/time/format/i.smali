.class public Lj$/time/format/i;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lj$/time/format/f;


# static fields
.field public static final f:[J


# instance fields
.field public final a:Lj$/time/temporal/o;

.field public final b:I

.field public final c:I

.field public final d:Lj$/time/format/u;

.field public final e:I


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .prologue
    const/16 v0, 0xb

    new-array v0, v0, [J

    fill-array-data v0, :array_a

    sput-object v0, Lj$/time/format/i;->f:[J

    return-void

    :array_a
    .array-data 8
        0x0
        0xa
        0x64
        0x3e8
        0x2710
        0x186a0
        0xf4240
        0x989680
        0x5f5e100
        0x3b9aca00
        0x2540be400L
    .end array-data
.end method

.method public constructor <init>(Lj$/time/temporal/o;IILj$/time/format/u;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lj$/time/format/i;->a:Lj$/time/temporal/o;

    iput p2, p0, Lj$/time/format/i;->b:I

    iput p3, p0, Lj$/time/format/i;->c:I

    iput-object p4, p0, Lj$/time/format/i;->d:Lj$/time/format/u;

    const/4 p1, 0x0

    iput p1, p0, Lj$/time/format/i;->e:I

    return-void
.end method

.method public constructor <init>(Lj$/time/temporal/o;IILj$/time/format/u;I)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lj$/time/format/i;->a:Lj$/time/temporal/o;

    iput p2, p0, Lj$/time/format/i;->b:I

    iput p3, p0, Lj$/time/format/i;->c:I

    iput-object p4, p0, Lj$/time/format/i;->d:Lj$/time/format/u;

    iput p5, p0, Lj$/time/format/i;->e:I

    return-void
.end method


# virtual methods
.method public a()Lj$/time/format/i;
    .registers 9

    .prologue
    iget v0, p0, Lj$/time/format/i;->e:I

    const/4 v1, -0x1

    if-ne v0, v1, :cond_6

    return-object p0

    :cond_6
    new-instance v2, Lj$/time/format/i;

    iget-object v6, p0, Lj$/time/format/i;->d:Lj$/time/format/u;

    const/4 v7, -0x1

    iget-object v3, p0, Lj$/time/format/i;->a:Lj$/time/temporal/o;

    iget v4, p0, Lj$/time/format/i;->b:I

    iget v5, p0, Lj$/time/format/i;->c:I

    invoke-direct/range {v2 .. v7}, Lj$/time/format/i;-><init>(Lj$/time/temporal/o;IILj$/time/format/u;I)V

    return-object v2
.end method

.method public b(I)Lj$/time/format/i;
    .registers 8

    new-instance v0, Lj$/time/format/i;

    iget v1, p0, Lj$/time/format/i;->e:I

    add-int v5, v1, p1

    iget-object v1, p0, Lj$/time/format/i;->a:Lj$/time/temporal/o;

    iget v2, p0, Lj$/time/format/i;->b:I

    iget v3, p0, Lj$/time/format/i;->c:I

    iget-object v4, p0, Lj$/time/format/i;->d:Lj$/time/format/u;

    invoke-direct/range {v0 .. v5}, Lj$/time/format/i;-><init>(Lj$/time/temporal/o;IILj$/time/format/u;I)V

    return-object v0
.end method

.method public n(Lj$/time/format/p;Ljava/lang/StringBuilder;)Z
    .registers 13

    .prologue
    iget-object v0, p0, Lj$/time/format/i;->a:Lj$/time/temporal/o;

    invoke-virtual {p1, v0}, Lj$/time/format/p;->a(Lj$/time/temporal/o;)Ljava/lang/Long;

    move-result-object v1

    const/4 v2, 0x0

    if-nez v1, :cond_a

    return v2

    :cond_a
    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    iget-object p1, p1, Lj$/time/format/p;->b:Lj$/time/format/DateTimeFormatter;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget p1, Lj$/time/format/s;->a:I

    const-wide/high16 v5, -0x8000000000000000L

    cmp-long p1, v3, v5

    if-nez p1, :cond_1e

    const-string p1, "9223372036854775808"

    goto :goto_26

    :cond_1e
    invoke-static {v3, v4}, Ljava/lang/Math;->abs(J)J

    move-result-wide v5

    invoke-static {v5, v6}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object p1

    :goto_26
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    const-string v5, " cannot be printed as the value "

    const-string v6, "Field "

    iget v7, p0, Lj$/time/format/i;->c:I

    if-gt v1, v7, :cond_aa

    const-wide/16 v7, 0x0

    cmp-long v1, v3, v7

    iget v7, p0, Lj$/time/format/i;->b:I

    const/4 v8, 0x2

    iget-object p0, p0, Lj$/time/format/i;->d:Lj$/time/format/u;

    const/4 v9, 0x1

    if-ltz v1, :cond_61

    sget-object v0, Lj$/time/format/c;->a:[I

    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result p0

    aget p0, v0, p0

    const/16 v0, 0x2b

    if-eq p0, v9, :cond_51

    if-eq p0, v8, :cond_4d

    goto :goto_96

    :cond_4d
    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_96

    :cond_51
    const/16 p0, 0x13

    if-ge v7, p0, :cond_96

    sget-object p0, Lj$/time/format/i;->f:[J

    aget-wide v5, p0, v7

    cmp-long p0, v3, v5

    if-ltz p0, :cond_96

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_96

    :cond_61
    sget-object v1, Lj$/time/format/c;->a:[I

    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result p0

    aget p0, v1, p0

    if-eq p0, v9, :cond_91

    if-eq p0, v8, :cond_91

    const/4 v1, 0x3

    if-eq p0, v1, :cond_91

    const/4 v1, 0x4

    if-eq p0, v1, :cond_74

    goto :goto_96

    :cond_74
    new-instance p0, Lj$/time/c;

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string p2, " cannot be negative according to the SignStyle"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_91
    const/16 p0, 0x2d

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :cond_96
    :goto_96
    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result p0

    sub-int p0, v7, p0

    if-ge v2, p0, :cond_a6

    const/16 p0, 0x30

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    add-int/lit8 v2, v2, 0x1

    goto :goto_96

    :cond_a6
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    return v9

    :cond_aa
    new-instance p0, Lj$/time/c;

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string p2, " exceeds the maximum print width of "

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public toString()Ljava/lang/String;
    .registers 8

    .prologue
    const/4 v0, 0x1

    iget v1, p0, Lj$/time/format/i;->c:I

    const-string v2, ")"

    const-string v3, "Value("

    iget-object v4, p0, Lj$/time/format/i;->a:Lj$/time/temporal/o;

    iget-object v5, p0, Lj$/time/format/i;->d:Lj$/time/format/u;

    iget p0, p0, Lj$/time/format/i;->b:I

    if-ne p0, v0, :cond_27

    const/16 v0, 0x13

    if-ne v1, v0, :cond_27

    sget-object v0, Lj$/time/format/u;->NORMAL:Lj$/time/format/u;

    if-ne v5, v0, :cond_27

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_27
    const-string v0, ","

    if-ne p0, v1, :cond_45

    sget-object v6, Lj$/time/format/u;->NOT_NEGATIVE:Lj$/time/format/u;

    if-ne v5, v6, :cond_45

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_45
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
