.class public final Lj$/time/ZoneOffset;
.super Lj$/time/ZoneId;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lj$/time/temporal/l;
.implements Lj$/time/temporal/m;
.implements Ljava/lang/Comparable;
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lj$/time/ZoneId;",
        "Lj$/time/temporal/l;",
        "Lj$/time/temporal/m;",
        "Ljava/lang/Comparable<",
        "Lj$/time/ZoneOffset;",
        ">;",
        "Ljava/io/Serializable;"
    }
.end annotation


# static fields
.field public static final UTC:Lj$/time/ZoneOffset;

.field public static final d:Ljava/util/concurrent/ConcurrentMap;

.field public static final e:Ljava/util/concurrent/ConcurrentMap;

.field public static final f:Lj$/time/ZoneOffset;

.field public static final g:Lj$/time/ZoneOffset;

.field private static final serialVersionUID:J = 0x20b8141d7a029c21L


# instance fields
.field public final b:I

.field public final transient c:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    const/16 v1, 0x10

    const/high16 v2, 0x3f400000  # 0.75f

    const/4 v3, 0x4

    invoke-direct {v0, v1, v2, v3}, Ljava/util/concurrent/ConcurrentHashMap;-><init>(IFI)V

    sput-object v0, Lj$/time/ZoneOffset;->d:Ljava/util/concurrent/ConcurrentMap;

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {v0, v1, v2, v3}, Ljava/util/concurrent/ConcurrentHashMap;-><init>(IFI)V

    sput-object v0, Lj$/time/ZoneOffset;->e:Ljava/util/concurrent/ConcurrentMap;

    const/4 v0, 0x0

    invoke-static {v0}, Lj$/time/ZoneOffset;->ofTotalSeconds(I)Lj$/time/ZoneOffset;

    move-result-object v0

    sput-object v0, Lj$/time/ZoneOffset;->UTC:Lj$/time/ZoneOffset;

    const v0, -0xfd20

    invoke-static {v0}, Lj$/time/ZoneOffset;->ofTotalSeconds(I)Lj$/time/ZoneOffset;

    move-result-object v0

    sput-object v0, Lj$/time/ZoneOffset;->f:Lj$/time/ZoneOffset;

    const v0, 0xfd20

    invoke-static {v0}, Lj$/time/ZoneOffset;->ofTotalSeconds(I)Lj$/time/ZoneOffset;

    move-result-object v0

    sput-object v0, Lj$/time/ZoneOffset;->g:Lj$/time/ZoneOffset;

    return-void
.end method

.method public constructor <init>(I)V
    .registers 8

    .prologue
    invoke-direct {p0}, Lj$/time/ZoneId;-><init>()V

    iput p1, p0, Lj$/time/ZoneOffset;->b:I

    if-nez p1, :cond_a

    const-string p1, "Z"

    goto :goto_4f

    :cond_a
    invoke-static {p1}, Ljava/lang/Math;->abs(I)I

    move-result v0

    new-instance v1, Ljava/lang/StringBuilder;

    div-int/lit16 v2, v0, 0xe10

    div-int/lit8 v3, v0, 0x3c

    rem-int/lit8 v3, v3, 0x3c

    if-gez p1, :cond_1b

    const-string p1, "-"

    goto :goto_1d

    :cond_1b
    const-string p1, "+"

    :goto_1d
    invoke-direct {v1, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 p1, 0xa

    if-ge v2, p1, :cond_27

    const-string v4, "0"

    goto :goto_29

    :cond_27
    const-string v4, ""

    :goto_29
    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, ":"

    const-string v4, ":0"

    if-ge v3, p1, :cond_37

    move-object v5, v4

    goto :goto_38

    :cond_37
    move-object v5, v2

    :goto_38
    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    rem-int/lit8 v0, v0, 0x3c

    if-eqz v0, :cond_4b

    if-ge v0, p1, :cond_45

    move-object v2, v4

    :cond_45
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    :cond_4b
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    :goto_4f
    iput-object p1, p0, Lj$/time/ZoneOffset;->c:Ljava/lang/String;

    return-void
.end method

.method public static K(Lj$/time/temporal/Temporal;)Lj$/time/ZoneOffset;
    .registers 3

    .prologue
    const-string v0, "temporal"

    invoke-static {p0, v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    sget-object v0, Lj$/time/temporal/p;->d:Lj$/time/format/a;

    invoke-interface {p0, v0}, Lj$/time/temporal/l;->b(Lj$/time/format/a;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lj$/time/ZoneOffset;

    if-eqz v0, :cond_10

    return-object v0

    :cond_10
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const-string v1, "Unable to obtain ZoneOffset from TemporalAccessor: "

    invoke-static {v1, p0, v0}, Lj$/time/h;->d(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static L(Ljava/lang/String;)Lj$/time/ZoneOffset;
    .registers 8

    .prologue
    const-string v0, "offsetId"

    invoke-static {p0, v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    sget-object v0, Lj$/time/ZoneOffset;->e:Ljava/util/concurrent/ConcurrentMap;

    check-cast v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v0, p0}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lj$/time/ZoneOffset;

    if-eqz v0, :cond_12

    return-object v0

    :cond_12
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eq v0, v1, :cond_65

    const/4 v1, 0x3

    if-eq v0, v1, :cond_81

    const/4 v4, 0x5

    if-eq v0, v4, :cond_5c

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-eq v0, v5, :cond_52

    const/4 v5, 0x7

    if-eq v0, v5, :cond_45

    const/16 v1, 0x9

    if-ne v0, v1, :cond_39

    invoke-static {p0, v2, v3}, Lj$/time/ZoneOffset;->N(Ljava/lang/CharSequence;IZ)I

    move-result v0

    invoke-static {p0, v6, v2}, Lj$/time/ZoneOffset;->N(Ljava/lang/CharSequence;IZ)I

    move-result v1

    invoke-static {p0, v5, v2}, Lj$/time/ZoneOffset;->N(Ljava/lang/CharSequence;IZ)I

    move-result v2

    goto :goto_87

    :cond_39
    new-instance v0, Lj$/time/c;

    const-string v1, "Invalid ID for ZoneOffset, invalid format: "

    invoke-virtual {v1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_45
    invoke-static {p0, v2, v3}, Lj$/time/ZoneOffset;->N(Ljava/lang/CharSequence;IZ)I

    move-result v0

    invoke-static {p0, v1, v3}, Lj$/time/ZoneOffset;->N(Ljava/lang/CharSequence;IZ)I

    move-result v1

    invoke-static {p0, v4, v3}, Lj$/time/ZoneOffset;->N(Ljava/lang/CharSequence;IZ)I

    move-result v2

    goto :goto_87

    :cond_52
    invoke-static {p0, v2, v3}, Lj$/time/ZoneOffset;->N(Ljava/lang/CharSequence;IZ)I

    move-result v0

    invoke-static {p0, v6, v2}, Lj$/time/ZoneOffset;->N(Ljava/lang/CharSequence;IZ)I

    move-result v1

    :goto_5a
    move v2, v3

    goto :goto_87

    :cond_5c
    invoke-static {p0, v2, v3}, Lj$/time/ZoneOffset;->N(Ljava/lang/CharSequence;IZ)I

    move-result v0

    invoke-static {p0, v1, v3}, Lj$/time/ZoneOffset;->N(Ljava/lang/CharSequence;IZ)I

    move-result v1

    goto :goto_5a

    :cond_65
    invoke-virtual {p0, v3}, Ljava/lang/String;->charAt(I)C

    move-result v0

    invoke-virtual {p0, v2}, Ljava/lang/String;->charAt(I)C

    move-result p0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string v0, "0"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    :cond_81
    invoke-static {p0, v2, v3}, Lj$/time/ZoneOffset;->N(Ljava/lang/CharSequence;IZ)I

    move-result v0

    move v1, v3

    move v2, v1

    :goto_87
    invoke-virtual {p0, v3}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const/16 v4, 0x2b

    const/16 v5, 0x2d

    if-eq v3, v4, :cond_a0

    if-ne v3, v5, :cond_94

    goto :goto_a0

    :cond_94
    new-instance v0, Lj$/time/c;

    const-string v1, "Invalid ID for ZoneOffset, plus/minus not found when expected: "

    invoke-virtual {v1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_a0
    :goto_a0
    if-ne v3, v5, :cond_aa

    neg-int p0, v0

    neg-int v0, v1

    neg-int v1, v2

    invoke-static {p0, v0, v1}, Lj$/time/ZoneOffset;->M(III)Lj$/time/ZoneOffset;

    move-result-object p0

    return-object p0

    :cond_aa
    invoke-static {v0, v1, v2}, Lj$/time/ZoneOffset;->M(III)Lj$/time/ZoneOffset;

    move-result-object p0

    return-object p0
.end method

.method public static M(III)Lj$/time/ZoneOffset;
    .registers 7

    .prologue
    const/16 v0, -0x12

    if-lt p0, v0, :cond_71

    const/16 v0, 0x12

    if-gt p0, v0, :cond_71

    if-lez p0, :cond_17

    if-ltz p1, :cond_f

    if-ltz p2, :cond_f

    goto :goto_37

    :cond_f
    new-instance p0, Lj$/time/c;

    const-string p1, "Zone offset minutes and seconds must be positive because hours is positive"

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_17
    if-gez p0, :cond_26

    if-gtz p1, :cond_1e

    if-gtz p2, :cond_1e

    goto :goto_37

    :cond_1e
    new-instance p0, Lj$/time/c;

    const-string p1, "Zone offset minutes and seconds must be negative because hours is negative"

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_26
    if-lez p1, :cond_2a

    if-ltz p2, :cond_2f

    :cond_2a
    if-gez p1, :cond_37

    if-gtz p2, :cond_2f

    goto :goto_37

    :cond_2f
    new-instance p0, Lj$/time/c;

    const-string p1, "Zone offset minutes and seconds must have the same sign"

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_37
    :goto_37
    const-string v1, " is not in the range -59 to 59"

    const/16 v2, -0x3b

    if-lt p1, v2, :cond_6a

    const/16 v3, 0x3b

    if-gt p1, v3, :cond_6a

    if-lt p2, v2, :cond_63

    if-gt p2, v3, :cond_63

    invoke-static {p0}, Ljava/lang/Math;->abs(I)I

    move-result v1

    if-ne v1, v0, :cond_58

    or-int v0, p1, p2

    if-nez v0, :cond_50

    goto :goto_58

    :cond_50
    new-instance p0, Lj$/time/c;

    const-string p1, "Zone offset not in valid range: -18:00 to +18:00"

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_58
    :goto_58
    mul-int/lit16 p0, p0, 0xe10

    mul-int/lit8 p1, p1, 0x3c

    add-int/2addr p1, p0

    add-int/2addr p1, p2

    invoke-static {p1}, Lj$/time/ZoneOffset;->ofTotalSeconds(I)Lj$/time/ZoneOffset;

    move-result-object p0

    return-object p0

    :cond_63
    const-string p0, "Zone offset seconds not in valid range: value "

    invoke-static {p0, p2, v1}, Lj$/time/h;->b(Ljava/lang/String;ILjava/lang/Object;)V

    const/4 p0, 0x0

    return-object p0

    :cond_6a
    const-string p0, "Zone offset minutes not in valid range: value "

    invoke-static {p0, p1, v1}, Lj$/time/h;->b(Ljava/lang/String;ILjava/lang/Object;)V

    const/4 p0, 0x0

    return-object p0

    :cond_71
    const-string p1, "Zone offset hours not in valid range: value "

    const-string p2, " is not in the range -18 to 18"

    invoke-static {p1, p0, p2}, Lj$/time/h;->b(Ljava/lang/String;ILjava/lang/Object;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static N(Ljava/lang/CharSequence;IZ)I
    .registers 5

    .prologue
    if-eqz p2, :cond_21

    add-int/lit8 p2, p1, -0x1

    invoke-interface {p0, p2}, Ljava/lang/CharSequence;->charAt(I)C

    move-result p2

    const/16 v0, 0x3a

    if-ne p2, v0, :cond_d

    goto :goto_21

    :cond_d
    new-instance p1, Lj$/time/c;

    new-instance p2, Ljava/lang/StringBuilder;

    const-string v0, "Invalid ID for ZoneOffset, colon not found when expected: "

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_21
    :goto_21
    invoke-interface {p0, p1}, Ljava/lang/CharSequence;->charAt(I)C

    move-result p2

    add-int/lit8 p1, p1, 0x1

    invoke-interface {p0, p1}, Ljava/lang/CharSequence;->charAt(I)C

    move-result p1

    const/16 v0, 0x30

    if-lt p2, v0, :cond_3d

    const/16 v1, 0x39

    if-gt p2, v1, :cond_3d

    if-lt p1, v0, :cond_3d

    if-gt p1, v1, :cond_3d

    sub-int/2addr p2, v0

    mul-int/lit8 p2, p2, 0xa

    sub-int/2addr p1, v0

    add-int/2addr p1, p2

    return p1

    :cond_3d
    new-instance p1, Lj$/time/c;

    new-instance p2, Ljava/lang/StringBuilder;

    const-string v0, "Invalid ID for ZoneOffset, non numeric characters found: "

    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public static O(Ljava/io/DataInput;)Lj$/time/ZoneOffset;
    .registers 3

    .prologue
    invoke-interface {p0}, Ljava/io/DataInput;->readByte()B

    move-result v0

    const/16 v1, 0x7f

    if-ne v0, v1, :cond_11

    invoke-interface {p0}, Ljava/io/DataInput;->readInt()I

    move-result p0

    invoke-static {p0}, Lj$/time/ZoneOffset;->ofTotalSeconds(I)Lj$/time/ZoneOffset;

    move-result-object p0

    return-object p0

    :cond_11
    mul-int/lit16 v0, v0, 0x384

    invoke-static {v0}, Lj$/time/ZoneOffset;->ofTotalSeconds(I)Lj$/time/ZoneOffset;

    move-result-object p0

    return-object p0
.end method

.method public static ofTotalSeconds(I)Lj$/time/ZoneOffset;
    .registers 4

    .prologue
    const v0, -0xfd20

    if-lt p0, v0, :cond_43

    const v0, 0xfd20

    if-gt p0, v0, :cond_43

    rem-int/lit16 v0, p0, 0x384

    if-nez v0, :cond_3d

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    sget-object v1, Lj$/time/ZoneOffset;->d:Ljava/util/concurrent/ConcurrentMap;

    move-object v2, v1

    check-cast v2, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v2, v0}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lj$/time/ZoneOffset;

    if-nez v2, :cond_3c

    new-instance v2, Lj$/time/ZoneOffset;

    invoke-direct {v2, p0}, Lj$/time/ZoneOffset;-><init>(I)V

    move-object p0, v1

    check-cast p0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {p0, v0, v2}, Ljava/util/concurrent/ConcurrentHashMap;->putIfAbsent(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v1, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v1, v0}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lj$/time/ZoneOffset;

    sget-object v0, Lj$/time/ZoneOffset;->e:Ljava/util/concurrent/ConcurrentMap;

    iget-object v1, p0, Lj$/time/ZoneOffset;->c:Ljava/lang/String;

    check-cast v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v0, v1, p0}, Ljava/util/concurrent/ConcurrentHashMap;->putIfAbsent(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-object p0

    :cond_3c
    return-object v2

    :cond_3d
    new-instance v0, Lj$/time/ZoneOffset;

    invoke-direct {v0, p0}, Lj$/time/ZoneOffset;-><init>(I)V

    return-object v0

    :cond_43
    new-instance p0, Lj$/time/c;

    const-string v0, "Zone offset not in valid range: -18:00 to +18:00"

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .registers 2

    new-instance p0, Ljava/io/InvalidObjectException;

    const-string p1, "Deserialization via serialization delegate"

    invoke-direct {p0, p1}, Ljava/io/InvalidObjectException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private writeReplace()Ljava/lang/Object;
    .registers 3

    new-instance v0, Lj$/time/p;

    const/16 v1, 0x8

    invoke-direct {v0, v1, p0}, Lj$/time/p;-><init>(BLjava/lang/Object;)V

    return-object v0
.end method


# virtual methods
.method public final J(Ljava/io/DataOutput;)V
    .registers 3

    const/16 v0, 0x8

    invoke-interface {p1, v0}, Ljava/io/DataOutput;->writeByte(I)V

    invoke-virtual {p0, p1}, Lj$/time/ZoneOffset;->P(Ljava/io/DataOutput;)V

    return-void
.end method

.method public final P(Ljava/io/DataOutput;)V
    .registers 4

    .prologue
    iget p0, p0, Lj$/time/ZoneOffset;->b:I

    rem-int/lit16 v0, p0, 0x384

    const/16 v1, 0x7f

    if-nez v0, :cond_b

    div-int/lit16 v0, p0, 0x384

    goto :goto_c

    :cond_b
    move v0, v1

    :goto_c
    invoke-interface {p1, v0}, Ljava/io/DataOutput;->writeByte(I)V

    if-ne v0, v1, :cond_14

    invoke-interface {p1, p0}, Ljava/io/DataOutput;->writeInt(I)V

    :cond_14
    return-void
.end method

.method public final b(Lj$/time/format/a;)Ljava/lang/Object;
    .registers 3

    .prologue
    sget-object v0, Lj$/time/temporal/p;->d:Lj$/time/format/a;

    if-eq p1, v0, :cond_d

    sget-object v0, Lj$/time/temporal/p;->e:Lj$/time/format/a;

    if-ne p1, v0, :cond_9

    goto :goto_d

    :cond_9
    invoke-super {p0, p1}, Lj$/time/temporal/l;->b(Lj$/time/format/a;)Ljava/lang/Object;

    move-result-object p0

    :cond_d
    :goto_d
    return-object p0
.end method

.method public final c(Lj$/time/temporal/Temporal;)Lj$/time/temporal/Temporal;
    .registers 5

    sget-object v0, Lj$/time/temporal/a;->OFFSET_SECONDS:Lj$/time/temporal/a;

    iget p0, p0, Lj$/time/ZoneOffset;->b:I

    int-to-long v1, p0

    invoke-interface {p1, v1, v2, v0}, Lj$/time/temporal/Temporal;->g(JLj$/time/temporal/o;)Lj$/time/temporal/Temporal;

    move-result-object p0

    return-object p0
.end method

.method public final compareTo(Ljava/lang/Object;)I
    .registers 2

    check-cast p1, Lj$/time/ZoneOffset;

    iget p1, p1, Lj$/time/ZoneOffset;->b:I

    iget p0, p0, Lj$/time/ZoneOffset;->b:I

    sub-int/2addr p1, p0

    return p1
.end method

.method public final d(Lj$/time/temporal/o;)I
    .registers 5

    .prologue
    sget-object v0, Lj$/time/temporal/a;->OFFSET_SECONDS:Lj$/time/temporal/a;

    if-ne p1, v0, :cond_7

    iget p0, p0, Lj$/time/ZoneOffset;->b:I

    return p0

    :cond_7
    if-nez p1, :cond_16

    invoke-super {p0, p1}, Lj$/time/temporal/l;->i(Lj$/time/temporal/o;)Lj$/time/temporal/r;

    move-result-object v0

    invoke-virtual {p0, p1}, Lj$/time/ZoneOffset;->f(Lj$/time/temporal/o;)J

    move-result-wide v1

    invoke-virtual {v0, v1, v2, p1}, Lj$/time/temporal/r;->a(JLj$/time/temporal/o;)I

    move-result p0

    return p0

    :cond_16
    new-instance p0, Lj$/time/temporal/q;

    const-string v0, "Unsupported field: "

    invoke-static {v0, p1}, Lj$/time/d;->a(Ljava/lang/String;Lj$/time/temporal/o;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final e(Lj$/time/temporal/o;)Z
    .registers 3

    .prologue
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_9

    sget-object p0, Lj$/time/temporal/a;->OFFSET_SECONDS:Lj$/time/temporal/a;

    if-ne p1, p0, :cond_13

    goto :goto_11

    :cond_9
    if-eqz p1, :cond_13

    invoke-interface {p1, p0}, Lj$/time/temporal/o;->n(Lj$/time/temporal/l;)Z

    move-result p0

    if-eqz p0, :cond_13

    :goto_11
    const/4 p0, 0x1

    return p0

    :cond_13
    const/4 p0, 0x0

    return p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 5

    .prologue
    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lj$/time/ZoneOffset;

    const/4 v2, 0x0

    if-eqz v1, :cond_12

    iget p0, p0, Lj$/time/ZoneOffset;->b:I

    check-cast p1, Lj$/time/ZoneOffset;

    iget p1, p1, Lj$/time/ZoneOffset;->b:I

    if-ne p0, p1, :cond_12

    return v0

    :cond_12
    return v2
.end method

.method public final f(Lj$/time/temporal/o;)J
    .registers 3

    .prologue
    sget-object v0, Lj$/time/temporal/a;->OFFSET_SECONDS:Lj$/time/temporal/a;

    if-ne p1, v0, :cond_8

    iget p0, p0, Lj$/time/ZoneOffset;->b:I

    int-to-long p0, p0

    return-wide p0

    :cond_8
    instance-of v0, p1, Lj$/time/temporal/a;

    if-nez v0, :cond_11

    invoke-interface {p1, p0}, Lj$/time/temporal/o;->E(Lj$/time/temporal/l;)J

    move-result-wide p0

    return-wide p0

    :cond_11
    new-instance p0, Lj$/time/temporal/q;

    const-string v0, "Unsupported field: "

    invoke-static {v0, p1}, Lj$/time/d;->a(Ljava/lang/String;Lj$/time/temporal/o;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final getId()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lj$/time/ZoneOffset;->c:Ljava/lang/String;

    return-object p0
.end method

.method public getTotalSeconds()I
    .registers 1

    iget p0, p0, Lj$/time/ZoneOffset;->b:I

    return p0
.end method

.method public final hashCode()I
    .registers 1

    iget p0, p0, Lj$/time/ZoneOffset;->b:I

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lj$/time/ZoneOffset;->c:Ljava/lang/String;

    return-object p0
.end method

.method public final v()Lj$/time/zone/f;
    .registers 2

    new-instance v0, Lj$/time/zone/f;

    invoke-direct {v0, p0}, Lj$/time/zone/f;-><init>(Lj$/time/ZoneOffset;)V

    return-object v0
.end method
