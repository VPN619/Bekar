.class public final Lj$/time/LocalTime;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lj$/time/temporal/Temporal;
.implements Lj$/time/temporal/m;
.implements Ljava/lang/Comparable;
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lj$/time/temporal/Temporal;",
        "Lj$/time/temporal/m;",
        "Ljava/lang/Comparable<",
        "Lj$/time/LocalTime;",
        ">;",
        "Ljava/io/Serializable;"
    }
.end annotation


# static fields
.field public static final e:Lj$/time/LocalTime;

.field public static final f:Lj$/time/LocalTime;

.field public static final g:Lj$/time/LocalTime;

.field public static final h:[Lj$/time/LocalTime;

.field private static final serialVersionUID:J = 0x5904a8b626e1a4f1L


# instance fields
.field public final a:B

.field public final b:B

.field public final c:B

.field public final d:I


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .prologue
    const/16 v0, 0x18

    new-array v0, v0, [Lj$/time/LocalTime;

    sput-object v0, Lj$/time/LocalTime;->h:[Lj$/time/LocalTime;

    const/4 v0, 0x0

    move v1, v0

    :goto_8
    sget-object v2, Lj$/time/LocalTime;->h:[Lj$/time/LocalTime;

    array-length v3, v2

    if-ge v1, v3, :cond_17

    new-instance v3, Lj$/time/LocalTime;

    invoke-direct {v3, v1, v0, v0, v0}, Lj$/time/LocalTime;-><init>(IIII)V

    aput-object v3, v2, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_8

    :cond_17
    aget-object v0, v2, v0

    sput-object v0, Lj$/time/LocalTime;->g:Lj$/time/LocalTime;

    const/16 v1, 0xc

    aget-object v1, v2, v1

    sput-object v0, Lj$/time/LocalTime;->e:Lj$/time/LocalTime;

    new-instance v0, Lj$/time/LocalTime;

    const/16 v1, 0x17

    const v2, 0x3b9ac9ff

    const/16 v3, 0x3b

    invoke-direct {v0, v1, v3, v3, v2}, Lj$/time/LocalTime;-><init>(IIII)V

    sput-object v0, Lj$/time/LocalTime;->f:Lj$/time/LocalTime;

    return-void
.end method

.method public constructor <init>(IIII)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    int-to-byte p1, p1

    iput-byte p1, p0, Lj$/time/LocalTime;->a:B

    int-to-byte p1, p2

    iput-byte p1, p0, Lj$/time/LocalTime;->b:B

    int-to-byte p1, p3

    iput-byte p1, p0, Lj$/time/LocalTime;->c:B

    iput p4, p0, Lj$/time/LocalTime;->d:I

    return-void
.end method

.method public static E(Lj$/time/temporal/l;)Lj$/time/LocalTime;
    .registers 3

    .prologue
    const-string v0, "temporal"

    invoke-static {p0, v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    sget-object v0, Lj$/time/temporal/p;->g:Lj$/time/format/a;

    invoke-interface {p0, v0}, Lj$/time/temporal/l;->b(Lj$/time/format/a;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lj$/time/LocalTime;

    if-eqz v0, :cond_10

    return-object v0

    :cond_10
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const-string v1, "Unable to obtain LocalTime from TemporalAccessor: "

    invoke-static {v1, p0, v0}, Lj$/time/h;->d(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static I(J)Lj$/time/LocalTime;
    .registers 9

    sget-object v0, Lj$/time/temporal/a;->NANO_OF_DAY:Lj$/time/temporal/a;

    invoke-virtual {v0, p0, p1}, Lj$/time/temporal/a;->I(J)V

    const-wide v0, 0x34630b8a000L

    div-long v2, p0, v0

    long-to-int v2, v2

    int-to-long v3, v2

    mul-long/2addr v3, v0

    sub-long/2addr p0, v3

    const-wide v0, 0xdf8475800L

    div-long v3, p0, v0

    long-to-int v3, v3

    int-to-long v4, v3

    mul-long/2addr v4, v0

    sub-long/2addr p0, v4

    const-wide/32 v0, 0x3b9aca00

    div-long v4, p0, v0

    long-to-int v4, v4

    int-to-long v5, v4

    mul-long/2addr v5, v0

    sub-long/2addr p0, v5

    long-to-int p0, p0

    invoke-static {v2, v3, v4, p0}, Lj$/time/LocalTime;->v(IIII)Lj$/time/LocalTime;

    move-result-object p0

    return-object p0
.end method

.method public static O(Ljava/io/DataInput;)Lj$/time/LocalTime;
    .registers 6

    .prologue
    invoke-interface {p0}, Ljava/io/DataInput;->readByte()B

    move-result v0

    const/4 v1, 0x0

    if-gez v0, :cond_b

    not-int v0, v0

    move p0, v1

    move v2, p0

    goto :goto_29

    :cond_b
    invoke-interface {p0}, Ljava/io/DataInput;->readByte()B

    move-result v2

    if-gez v2, :cond_16

    not-int p0, v2

    move v2, v1

    move v1, p0

    move p0, v2

    goto :goto_29

    :cond_16
    invoke-interface {p0}, Ljava/io/DataInput;->readByte()B

    move-result v3

    if-gez v3, :cond_21

    not-int p0, v3

    move v4, v2

    move v2, v1

    move v1, v4

    goto :goto_29

    :cond_21
    invoke-interface {p0}, Ljava/io/DataInput;->readInt()I

    move-result v1

    move p0, v2

    move v2, v1

    move v1, p0

    move p0, v3

    :goto_29
    invoke-static {v0, v1, p0, v2}, Lj$/time/LocalTime;->of(IIII)Lj$/time/LocalTime;

    move-result-object p0

    return-object p0
.end method

.method public static of(IIII)Lj$/time/LocalTime;
    .registers 7

    sget-object v0, Lj$/time/temporal/a;->HOUR_OF_DAY:Lj$/time/temporal/a;

    int-to-long v1, p0

    invoke-virtual {v0, v1, v2}, Lj$/time/temporal/a;->I(J)V

    sget-object v0, Lj$/time/temporal/a;->MINUTE_OF_HOUR:Lj$/time/temporal/a;

    int-to-long v1, p1

    invoke-virtual {v0, v1, v2}, Lj$/time/temporal/a;->I(J)V

    sget-object v0, Lj$/time/temporal/a;->SECOND_OF_MINUTE:Lj$/time/temporal/a;

    int-to-long v1, p2

    invoke-virtual {v0, v1, v2}, Lj$/time/temporal/a;->I(J)V

    sget-object v0, Lj$/time/temporal/a;->NANO_OF_SECOND:Lj$/time/temporal/a;

    int-to-long v1, p3

    invoke-virtual {v0, v1, v2}, Lj$/time/temporal/a;->I(J)V

    invoke-static {p0, p1, p2, p3}, Lj$/time/LocalTime;->v(IIII)Lj$/time/LocalTime;

    move-result-object p0

    return-object p0
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .registers 2

    new-instance p0, Ljava/io/InvalidObjectException;

    const-string p1, "Deserialization via serialization delegate"

    invoke-direct {p0, p1}, Ljava/io/InvalidObjectException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static v(IIII)Lj$/time/LocalTime;
    .registers 5

    .prologue
    or-int v0, p1, p2

    or-int/2addr v0, p3

    if-nez v0, :cond_a

    sget-object p1, Lj$/time/LocalTime;->h:[Lj$/time/LocalTime;

    aget-object p0, p1, p0

    return-object p0

    :cond_a
    new-instance v0, Lj$/time/LocalTime;

    invoke-direct {v0, p0, p1, p2, p3}, Lj$/time/LocalTime;-><init>(IIII)V

    return-object v0
.end method

.method private writeReplace()Ljava/lang/Object;
    .registers 3

    new-instance v0, Lj$/time/p;

    const/4 v1, 0x4

    invoke-direct {v0, v1, p0}, Lj$/time/p;-><init>(BLjava/lang/Object;)V

    return-object v0
.end method


# virtual methods
.method public final H(Lj$/time/temporal/o;)I
    .registers 4

    .prologue
    sget-object v0, Lj$/time/j;->a:[I

    move-object v1, p1

    check-cast v1, Lj$/time/temporal/a;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget v0, v0, v1

    const/16 v1, 0xc

    packed-switch v0, :pswitch_data_74

    new-instance p0, Lj$/time/temporal/q;

    const-string v0, "Unsupported field: "

    invoke-static {v0, p1}, Lj$/time/d;->a(Ljava/lang/String;Lj$/time/temporal/o;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :pswitch_1c  #0xf
    iget-byte p0, p0, Lj$/time/LocalTime;->a:B

    div-int/2addr p0, v1

    return p0

    :pswitch_20  #0xe
    iget-byte p0, p0, Lj$/time/LocalTime;->a:B

    if-nez p0, :cond_26

    const/16 p0, 0x18

    :cond_26
    return p0

    :pswitch_27  #0xd
    iget-byte p0, p0, Lj$/time/LocalTime;->a:B

    return p0

    :pswitch_2a  #0xc
    iget-byte p0, p0, Lj$/time/LocalTime;->a:B

    rem-int/2addr p0, v1

    rem-int/lit8 p1, p0, 0xc

    if-nez p1, :cond_32

    return v1

    :cond_32
    return p0

    :pswitch_33  #0xb
    iget-byte p0, p0, Lj$/time/LocalTime;->a:B

    rem-int/2addr p0, v1

    return p0

    :pswitch_37  #0xa
    iget-byte p1, p0, Lj$/time/LocalTime;->a:B

    mul-int/lit8 p1, p1, 0x3c

    iget-byte p0, p0, Lj$/time/LocalTime;->b:B

    add-int/2addr p1, p0

    return p1

    :pswitch_3f  #0x9
    iget-byte p0, p0, Lj$/time/LocalTime;->b:B

    return p0

    :pswitch_42  #0x8
    invoke-virtual {p0}, Lj$/time/LocalTime;->Q()I

    move-result p0

    return p0

    :pswitch_47  #0x7
    iget-byte p0, p0, Lj$/time/LocalTime;->c:B

    return p0

    :pswitch_4a  #0x6
    invoke-virtual {p0}, Lj$/time/LocalTime;->P()J

    move-result-wide p0

    const-wide/32 v0, 0xf4240

    div-long/2addr p0, v0

    long-to-int p0, p0

    return p0

    :pswitch_54  #0x5
    iget p0, p0, Lj$/time/LocalTime;->d:I

    const p1, 0xf4240

    div-int/2addr p0, p1

    return p0

    :pswitch_5b  #0x4
    new-instance p0, Lj$/time/temporal/q;

    const-string p1, "Invalid field \'MicroOfDay\' for get() method, use getLong() instead"

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :pswitch_63  #0x3
    iget p0, p0, Lj$/time/LocalTime;->d:I

    div-int/lit16 p0, p0, 0x3e8

    return p0

    :pswitch_68  #0x2
    new-instance p0, Lj$/time/temporal/q;

    const-string p1, "Invalid field \'NanoOfDay\' for get() method, use getLong() instead"

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :pswitch_70  #0x1
    iget p0, p0, Lj$/time/LocalTime;->d:I

    return p0

    nop

    :pswitch_data_74
    .packed-switch 0x1
        :pswitch_70  #00000001
        :pswitch_68  #00000002
        :pswitch_63  #00000003
        :pswitch_5b  #00000004
        :pswitch_54  #00000005
        :pswitch_4a  #00000006
        :pswitch_47  #00000007
        :pswitch_42  #00000008
        :pswitch_3f  #00000009
        :pswitch_37  #0000000a
        :pswitch_33  #0000000b
        :pswitch_2a  #0000000c
        :pswitch_27  #0000000d
        :pswitch_20  #0000000e
        :pswitch_1c  #0000000f
    .end packed-switch
.end method

.method public final J(JLj$/time/temporal/TemporalUnit;)Lj$/time/LocalTime;
    .registers 6

    .prologue
    instance-of v0, p3, Lj$/time/temporal/ChronoUnit;

    if-eqz v0, :cond_53

    sget-object v0, Lj$/time/j;->b:[I

    move-object v1, p3

    check-cast v1, Lj$/time/temporal/ChronoUnit;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget v0, v0, v1

    packed-switch v0, :pswitch_data_5a

    const-string p0, "Unsupported unit: "

    invoke-static {p0, p3}, Lj$/time/h;->c(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 p0, 0x0

    return-object p0

    :pswitch_19  #0x7
    const-wide/16 v0, 0x2

    rem-long/2addr p1, v0

    const-wide/16 v0, 0xc

    mul-long/2addr p1, v0

    invoke-virtual {p0, p1, p2}, Lj$/time/LocalTime;->K(J)Lj$/time/LocalTime;

    move-result-object p0

    return-object p0

    :pswitch_24  #0x6
    invoke-virtual {p0, p1, p2}, Lj$/time/LocalTime;->K(J)Lj$/time/LocalTime;

    move-result-object p0

    return-object p0

    :pswitch_29  #0x5
    invoke-virtual {p0, p1, p2}, Lj$/time/LocalTime;->L(J)Lj$/time/LocalTime;

    move-result-object p0

    return-object p0

    :pswitch_2e  #0x4
    invoke-virtual {p0, p1, p2}, Lj$/time/LocalTime;->N(J)Lj$/time/LocalTime;

    move-result-object p0

    return-object p0

    :pswitch_33  #0x3
    const-wide/32 v0, 0x5265c00

    rem-long/2addr p1, v0

    const-wide/32 v0, 0xf4240

    mul-long/2addr p1, v0

    invoke-virtual {p0, p1, p2}, Lj$/time/LocalTime;->M(J)Lj$/time/LocalTime;

    move-result-object p0

    return-object p0

    :pswitch_40  #0x2
    const-wide v0, 0x141dd76000L

    rem-long/2addr p1, v0

    const-wide/16 v0, 0x3e8

    mul-long/2addr p1, v0

    invoke-virtual {p0, p1, p2}, Lj$/time/LocalTime;->M(J)Lj$/time/LocalTime;

    move-result-object p0

    return-object p0

    :pswitch_4e  #0x1
    invoke-virtual {p0, p1, p2}, Lj$/time/LocalTime;->M(J)Lj$/time/LocalTime;

    move-result-object p0

    return-object p0

    :cond_53
    invoke-interface {p3, p0, p1, p2}, Lj$/time/temporal/TemporalUnit;->v(Lj$/time/temporal/Temporal;J)Lj$/time/temporal/Temporal;

    move-result-object p0

    check-cast p0, Lj$/time/LocalTime;

    return-object p0

    :pswitch_data_5a
    .packed-switch 0x1
        :pswitch_4e  #00000001
        :pswitch_40  #00000002
        :pswitch_33  #00000003
        :pswitch_2e  #00000004
        :pswitch_29  #00000005
        :pswitch_24  #00000006
        :pswitch_19  #00000007
    .end packed-switch
.end method

.method public final K(J)Lj$/time/LocalTime;
    .registers 5

    .prologue
    const-wide/16 v0, 0x0

    cmp-long v0, p1, v0

    if-nez v0, :cond_7

    return-object p0

    :cond_7
    const-wide/16 v0, 0x18

    rem-long/2addr p1, v0

    long-to-int p1, p1

    iget-byte p2, p0, Lj$/time/LocalTime;->a:B

    add-int/2addr p1, p2

    add-int/lit8 p1, p1, 0x18

    rem-int/lit8 p1, p1, 0x18

    iget-byte p2, p0, Lj$/time/LocalTime;->b:B

    iget-byte v0, p0, Lj$/time/LocalTime;->c:B

    iget p0, p0, Lj$/time/LocalTime;->d:I

    invoke-static {p1, p2, v0, p0}, Lj$/time/LocalTime;->v(IIII)Lj$/time/LocalTime;

    move-result-object p0

    return-object p0
.end method

.method public final L(J)Lj$/time/LocalTime;
    .registers 6

    .prologue
    const-wide/16 v0, 0x0

    cmp-long v0, p1, v0

    if-nez v0, :cond_7

    goto :goto_19

    :cond_7
    iget-byte v0, p0, Lj$/time/LocalTime;->a:B

    mul-int/lit8 v0, v0, 0x3c

    iget-byte v1, p0, Lj$/time/LocalTime;->b:B

    add-int/2addr v0, v1

    const-wide/16 v1, 0x5a0

    rem-long/2addr p1, v1

    long-to-int p1, p1

    add-int/2addr p1, v0

    add-int/lit16 p1, p1, 0x5a0

    rem-int/lit16 p1, p1, 0x5a0

    if-ne v0, p1, :cond_1a

    :goto_19
    return-object p0

    :cond_1a
    div-int/lit8 p2, p1, 0x3c

    rem-int/lit8 p1, p1, 0x3c

    iget-byte v0, p0, Lj$/time/LocalTime;->c:B

    iget p0, p0, Lj$/time/LocalTime;->d:I

    invoke-static {p2, p1, v0, p0}, Lj$/time/LocalTime;->v(IIII)Lj$/time/LocalTime;

    move-result-object p0

    return-object p0
.end method

.method public final M(J)Lj$/time/LocalTime;
    .registers 11

    .prologue
    const-wide/16 v0, 0x0

    cmp-long v0, p1, v0

    if-nez v0, :cond_7

    goto :goto_18

    :cond_7
    invoke-virtual {p0}, Lj$/time/LocalTime;->P()J

    move-result-wide v0

    const-wide v2, 0x4e94914f0000L

    rem-long/2addr p1, v2

    add-long/2addr p1, v0

    add-long/2addr p1, v2

    rem-long/2addr p1, v2

    cmp-long v0, v0, p1

    if-nez v0, :cond_19

    :goto_18
    return-object p0

    :cond_19
    const-wide v0, 0x34630b8a000L

    div-long v0, p1, v0

    long-to-int p0, v0

    const-wide v0, 0xdf8475800L

    div-long v0, p1, v0

    const-wide/16 v2, 0x3c

    rem-long/2addr v0, v2

    long-to-int v0, v0

    const-wide/32 v4, 0x3b9aca00

    div-long v6, p1, v4

    rem-long/2addr v6, v2

    long-to-int v1, v6

    rem-long/2addr p1, v4

    long-to-int p1, p1

    invoke-static {p0, v0, v1, p1}, Lj$/time/LocalTime;->v(IIII)Lj$/time/LocalTime;

    move-result-object p0

    return-object p0
.end method

.method public final N(J)Lj$/time/LocalTime;
    .registers 7

    .prologue
    const-wide/16 v0, 0x0

    cmp-long v0, p1, v0

    if-nez v0, :cond_7

    goto :goto_20

    :cond_7
    iget-byte v0, p0, Lj$/time/LocalTime;->a:B

    mul-int/lit16 v0, v0, 0xe10

    iget-byte v1, p0, Lj$/time/LocalTime;->b:B

    mul-int/lit8 v1, v1, 0x3c

    add-int/2addr v1, v0

    iget-byte v0, p0, Lj$/time/LocalTime;->c:B

    add-int/2addr v1, v0

    const-wide/32 v2, 0x15180

    rem-long/2addr p1, v2

    long-to-int p1, p1

    add-int/2addr p1, v1

    const p2, 0x15180

    add-int/2addr p1, p2

    rem-int/2addr p1, p2

    if-ne v1, p1, :cond_21

    :goto_20
    return-object p0

    :cond_21
    div-int/lit16 p2, p1, 0xe10

    div-int/lit8 v0, p1, 0x3c

    rem-int/lit8 v0, v0, 0x3c

    rem-int/lit8 p1, p1, 0x3c

    iget p0, p0, Lj$/time/LocalTime;->d:I

    invoke-static {p2, v0, p1, p0}, Lj$/time/LocalTime;->v(IIII)Lj$/time/LocalTime;

    move-result-object p0

    return-object p0
.end method

.method public final P()J
    .registers 7

    iget-byte v0, p0, Lj$/time/LocalTime;->a:B

    int-to-long v0, v0

    const-wide v2, 0x34630b8a000L

    mul-long/2addr v0, v2

    iget-byte v2, p0, Lj$/time/LocalTime;->b:B

    int-to-long v2, v2

    const-wide v4, 0xdf8475800L

    mul-long/2addr v2, v4

    add-long/2addr v2, v0

    iget-byte v0, p0, Lj$/time/LocalTime;->c:B

    int-to-long v0, v0

    const-wide/32 v4, 0x3b9aca00

    mul-long/2addr v0, v4

    add-long/2addr v0, v2

    iget p0, p0, Lj$/time/LocalTime;->d:I

    int-to-long v2, p0

    add-long/2addr v0, v2

    return-wide v0
.end method

.method public final Q()I
    .registers 3

    iget-byte v0, p0, Lj$/time/LocalTime;->a:B

    mul-int/lit16 v0, v0, 0xe10

    iget-byte v1, p0, Lj$/time/LocalTime;->b:B

    mul-int/lit8 v1, v1, 0x3c

    add-int/2addr v1, v0

    iget-byte p0, p0, Lj$/time/LocalTime;->c:B

    add-int/2addr v1, p0

    return v1
.end method

.method public final R(JLj$/time/temporal/o;)Lj$/time/LocalTime;
    .registers 9

    .prologue
    instance-of v0, p3, Lj$/time/temporal/a;

    if-eqz v0, :cond_f7

    move-object v0, p3

    check-cast v0, Lj$/time/temporal/a;

    invoke-virtual {v0, p1, p2}, Lj$/time/temporal/a;->I(J)V

    sget-object v1, Lj$/time/j;->a:[I

    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    aget v0, v1, v0

    const-wide/16 v1, 0x0

    const-wide/16 v3, 0xc

    packed-switch v0, :pswitch_data_fe

    new-instance p0, Lj$/time/temporal/q;

    const-string p1, "Unsupported field: "

    invoke-static {p1, p3}, Lj$/time/d;->a(Ljava/lang/String;Lj$/time/temporal/o;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :pswitch_25  #0xf
    iget-byte p3, p0, Lj$/time/LocalTime;->a:B

    div-int/lit8 p3, p3, 0xc

    int-to-long v0, p3

    sub-long/2addr p1, v0

    mul-long/2addr p1, v3

    invoke-virtual {p0, p1, p2}, Lj$/time/LocalTime;->K(J)Lj$/time/LocalTime;

    move-result-object p0

    return-object p0

    :pswitch_31  #0xe
    const-wide/16 v3, 0x18

    cmp-long p3, p1, v3

    if-nez p3, :cond_38

    move-wide p1, v1

    :cond_38
    long-to-int p1, p1

    iget-byte p2, p0, Lj$/time/LocalTime;->a:B

    if-ne p2, p1, :cond_3f

    goto/16 :goto_b7

    :cond_3f
    sget-object p2, Lj$/time/temporal/a;->HOUR_OF_DAY:Lj$/time/temporal/a;

    int-to-long v0, p1

    invoke-virtual {p2, v0, v1}, Lj$/time/temporal/a;->I(J)V

    iget-byte p2, p0, Lj$/time/LocalTime;->b:B

    iget-byte p3, p0, Lj$/time/LocalTime;->c:B

    iget p0, p0, Lj$/time/LocalTime;->d:I

    invoke-static {p1, p2, p3, p0}, Lj$/time/LocalTime;->v(IIII)Lj$/time/LocalTime;

    move-result-object p0

    return-object p0

    :pswitch_50  #0xd
    long-to-int p1, p1

    iget-byte p2, p0, Lj$/time/LocalTime;->a:B

    if-ne p2, p1, :cond_56

    goto :goto_b7

    :cond_56
    sget-object p2, Lj$/time/temporal/a;->HOUR_OF_DAY:Lj$/time/temporal/a;

    int-to-long v0, p1

    invoke-virtual {p2, v0, v1}, Lj$/time/temporal/a;->I(J)V

    iget-byte p2, p0, Lj$/time/LocalTime;->b:B

    iget-byte p3, p0, Lj$/time/LocalTime;->c:B

    iget p0, p0, Lj$/time/LocalTime;->d:I

    invoke-static {p1, p2, p3, p0}, Lj$/time/LocalTime;->v(IIII)Lj$/time/LocalTime;

    move-result-object p0

    return-object p0

    :pswitch_67  #0xc
    cmp-long p3, p1, v3

    if-nez p3, :cond_6c

    move-wide p1, v1

    :cond_6c
    iget-byte p3, p0, Lj$/time/LocalTime;->a:B

    rem-int/lit8 p3, p3, 0xc

    int-to-long v0, p3

    sub-long/2addr p1, v0

    invoke-virtual {p0, p1, p2}, Lj$/time/LocalTime;->K(J)Lj$/time/LocalTime;

    move-result-object p0

    return-object p0

    :pswitch_77  #0xb
    iget-byte p3, p0, Lj$/time/LocalTime;->a:B

    rem-int/lit8 p3, p3, 0xc

    int-to-long v0, p3

    sub-long/2addr p1, v0

    invoke-virtual {p0, p1, p2}, Lj$/time/LocalTime;->K(J)Lj$/time/LocalTime;

    move-result-object p0

    return-object p0

    :pswitch_82  #0xa
    iget-byte p3, p0, Lj$/time/LocalTime;->a:B

    mul-int/lit8 p3, p3, 0x3c

    iget-byte v0, p0, Lj$/time/LocalTime;->b:B

    add-int/2addr p3, v0

    int-to-long v0, p3

    sub-long/2addr p1, v0

    invoke-virtual {p0, p1, p2}, Lj$/time/LocalTime;->L(J)Lj$/time/LocalTime;

    move-result-object p0

    return-object p0

    :pswitch_90  #0x9
    long-to-int p1, p1

    iget-byte p2, p0, Lj$/time/LocalTime;->b:B

    if-ne p2, p1, :cond_96

    goto :goto_b7

    :cond_96
    sget-object p2, Lj$/time/temporal/a;->MINUTE_OF_HOUR:Lj$/time/temporal/a;

    int-to-long v0, p1

    invoke-virtual {p2, v0, v1}, Lj$/time/temporal/a;->I(J)V

    iget-byte p2, p0, Lj$/time/LocalTime;->a:B

    iget-byte p3, p0, Lj$/time/LocalTime;->c:B

    iget p0, p0, Lj$/time/LocalTime;->d:I

    invoke-static {p2, p1, p3, p0}, Lj$/time/LocalTime;->v(IIII)Lj$/time/LocalTime;

    move-result-object p0

    return-object p0

    :pswitch_a7  #0x8
    invoke-virtual {p0}, Lj$/time/LocalTime;->Q()I

    move-result p3

    int-to-long v0, p3

    sub-long/2addr p1, v0

    invoke-virtual {p0, p1, p2}, Lj$/time/LocalTime;->N(J)Lj$/time/LocalTime;

    move-result-object p0

    return-object p0

    :pswitch_b2  #0x7
    long-to-int p1, p1

    iget-byte p2, p0, Lj$/time/LocalTime;->c:B

    if-ne p2, p1, :cond_b8

    :goto_b7
    return-object p0

    :cond_b8
    sget-object p2, Lj$/time/temporal/a;->SECOND_OF_MINUTE:Lj$/time/temporal/a;

    int-to-long v0, p1

    invoke-virtual {p2, v0, v1}, Lj$/time/temporal/a;->I(J)V

    iget-byte p2, p0, Lj$/time/LocalTime;->a:B

    iget-byte p3, p0, Lj$/time/LocalTime;->b:B

    iget p0, p0, Lj$/time/LocalTime;->d:I

    invoke-static {p2, p3, p1, p0}, Lj$/time/LocalTime;->v(IIII)Lj$/time/LocalTime;

    move-result-object p0

    return-object p0

    :pswitch_c9  #0x6
    const-wide/32 v0, 0xf4240

    mul-long/2addr p1, v0

    invoke-static {p1, p2}, Lj$/time/LocalTime;->I(J)Lj$/time/LocalTime;

    move-result-object p0

    return-object p0

    :pswitch_d2  #0x5
    long-to-int p1, p1

    const p2, 0xf4240

    mul-int/2addr p1, p2

    invoke-virtual {p0, p1}, Lj$/time/LocalTime;->S(I)Lj$/time/LocalTime;

    move-result-object p0

    return-object p0

    :pswitch_dc  #0x4
    const-wide/16 v0, 0x3e8

    mul-long/2addr p1, v0

    invoke-static {p1, p2}, Lj$/time/LocalTime;->I(J)Lj$/time/LocalTime;

    move-result-object p0

    return-object p0

    :pswitch_e4  #0x3
    long-to-int p1, p1

    mul-int/lit16 p1, p1, 0x3e8

    invoke-virtual {p0, p1}, Lj$/time/LocalTime;->S(I)Lj$/time/LocalTime;

    move-result-object p0

    return-object p0

    :pswitch_ec  #0x2
    invoke-static {p1, p2}, Lj$/time/LocalTime;->I(J)Lj$/time/LocalTime;

    move-result-object p0

    return-object p0

    :pswitch_f1  #0x1
    long-to-int p1, p1

    invoke-virtual {p0, p1}, Lj$/time/LocalTime;->S(I)Lj$/time/LocalTime;

    move-result-object p0

    return-object p0

    :cond_f7
    invoke-interface {p3, p0, p1, p2}, Lj$/time/temporal/o;->H(Lj$/time/temporal/Temporal;J)Lj$/time/temporal/Temporal;

    move-result-object p0

    check-cast p0, Lj$/time/LocalTime;

    return-object p0

    :pswitch_data_fe
    .packed-switch 0x1
        :pswitch_f1  #00000001
        :pswitch_ec  #00000002
        :pswitch_e4  #00000003
        :pswitch_dc  #00000004
        :pswitch_d2  #00000005
        :pswitch_c9  #00000006
        :pswitch_b2  #00000007
        :pswitch_a7  #00000008
        :pswitch_90  #00000009
        :pswitch_82  #0000000a
        :pswitch_77  #0000000b
        :pswitch_67  #0000000c
        :pswitch_50  #0000000d
        :pswitch_31  #0000000e
        :pswitch_25  #0000000f
    .end packed-switch
.end method

.method public final S(I)Lj$/time/LocalTime;
    .registers 5

    .prologue
    iget v0, p0, Lj$/time/LocalTime;->d:I

    if-ne v0, p1, :cond_5

    return-object p0

    :cond_5
    sget-object v0, Lj$/time/temporal/a;->NANO_OF_SECOND:Lj$/time/temporal/a;

    int-to-long v1, p1

    invoke-virtual {v0, v1, v2}, Lj$/time/temporal/a;->I(J)V

    iget-byte v0, p0, Lj$/time/LocalTime;->a:B

    iget-byte v1, p0, Lj$/time/LocalTime;->b:B

    iget-byte p0, p0, Lj$/time/LocalTime;->c:B

    invoke-static {v0, v1, p0, p1}, Lj$/time/LocalTime;->v(IIII)Lj$/time/LocalTime;

    move-result-object p0

    return-object p0
.end method

.method public final T(Ljava/io/DataOutput;)V
    .registers 4

    .prologue
    iget v0, p0, Lj$/time/LocalTime;->d:I

    if-nez v0, :cond_2e

    iget-byte v0, p0, Lj$/time/LocalTime;->c:B

    if-nez v0, :cond_1d

    iget-byte v0, p0, Lj$/time/LocalTime;->b:B

    iget-byte v1, p0, Lj$/time/LocalTime;->a:B

    if-nez v0, :cond_13

    not-int p0, v1

    invoke-interface {p1, p0}, Ljava/io/DataOutput;->writeByte(I)V

    return-void

    :cond_13
    invoke-interface {p1, v1}, Ljava/io/DataOutput;->writeByte(I)V

    iget-byte p0, p0, Lj$/time/LocalTime;->b:B

    not-int p0, p0

    invoke-interface {p1, p0}, Ljava/io/DataOutput;->writeByte(I)V

    return-void

    :cond_1d
    iget-byte v0, p0, Lj$/time/LocalTime;->a:B

    invoke-interface {p1, v0}, Ljava/io/DataOutput;->writeByte(I)V

    iget-byte v0, p0, Lj$/time/LocalTime;->b:B

    invoke-interface {p1, v0}, Ljava/io/DataOutput;->writeByte(I)V

    iget-byte p0, p0, Lj$/time/LocalTime;->c:B

    not-int p0, p0

    invoke-interface {p1, p0}, Ljava/io/DataOutput;->writeByte(I)V

    return-void

    :cond_2e
    iget-byte v0, p0, Lj$/time/LocalTime;->a:B

    invoke-interface {p1, v0}, Ljava/io/DataOutput;->writeByte(I)V

    iget-byte v0, p0, Lj$/time/LocalTime;->b:B

    invoke-interface {p1, v0}, Ljava/io/DataOutput;->writeByte(I)V

    iget-byte v0, p0, Lj$/time/LocalTime;->c:B

    invoke-interface {p1, v0}, Ljava/io/DataOutput;->writeByte(I)V

    iget p0, p0, Lj$/time/LocalTime;->d:I

    invoke-interface {p1, p0}, Ljava/io/DataOutput;->writeInt(I)V

    return-void
.end method

.method public final a(JLj$/time/temporal/TemporalUnit;)Lj$/time/temporal/Temporal;
    .registers 6

    .prologue
    const-wide/high16 v0, -0x8000000000000000L

    cmp-long v0, p1, v0

    if-nez v0, :cond_16

    const-wide p1, 0x7fffffffffffffffL

    invoke-virtual {p0, p1, p2, p3}, Lj$/time/LocalTime;->J(JLj$/time/temporal/TemporalUnit;)Lj$/time/LocalTime;

    move-result-object p0

    const-wide/16 p1, 0x1

    :goto_11
    invoke-virtual {p0, p1, p2, p3}, Lj$/time/LocalTime;->J(JLj$/time/temporal/TemporalUnit;)Lj$/time/LocalTime;

    move-result-object p0

    return-object p0

    :cond_16
    neg-long p1, p1

    goto :goto_11
.end method

.method public final b(Lj$/time/format/a;)Ljava/lang/Object;
    .registers 3

    .prologue
    sget-object v0, Lj$/time/temporal/p;->b:Lj$/time/format/a;

    if-eq p1, v0, :cond_27

    sget-object v0, Lj$/time/temporal/p;->a:Lj$/time/format/a;

    if-eq p1, v0, :cond_27

    sget-object v0, Lj$/time/temporal/p;->e:Lj$/time/format/a;

    if-eq p1, v0, :cond_27

    sget-object v0, Lj$/time/temporal/p;->d:Lj$/time/format/a;

    if-ne p1, v0, :cond_11

    goto :goto_27

    :cond_11
    sget-object v0, Lj$/time/temporal/p;->g:Lj$/time/format/a;

    if-ne p1, v0, :cond_16

    return-object p0

    :cond_16
    sget-object v0, Lj$/time/temporal/p;->f:Lj$/time/format/a;

    if-ne p1, v0, :cond_1b

    goto :goto_27

    :cond_1b
    sget-object v0, Lj$/time/temporal/p;->c:Lj$/time/format/a;

    if-ne p1, v0, :cond_22

    sget-object p0, Lj$/time/temporal/ChronoUnit;->NANOS:Lj$/time/temporal/ChronoUnit;

    return-object p0

    :cond_22
    invoke-virtual {p1, p0}, Lj$/time/format/a;->a(Lj$/time/temporal/l;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :cond_27
    :goto_27
    const/4 p0, 0x0

    return-object p0
.end method

.method public final c(Lj$/time/temporal/Temporal;)Lj$/time/temporal/Temporal;
    .registers 5

    sget-object v0, Lj$/time/temporal/a;->NANO_OF_DAY:Lj$/time/temporal/a;

    invoke-virtual {p0}, Lj$/time/LocalTime;->P()J

    move-result-wide v1

    invoke-interface {p1, v1, v2, v0}, Lj$/time/temporal/Temporal;->g(JLj$/time/temporal/o;)Lj$/time/temporal/Temporal;

    move-result-object p0

    return-object p0
.end method

.method public final bridge synthetic compareTo(Ljava/lang/Object;)I
    .registers 2

    check-cast p1, Lj$/time/LocalTime;

    invoke-virtual {p0, p1}, Lj$/time/LocalTime;->n(Lj$/time/LocalTime;)I

    move-result p0

    return p0
.end method

.method public final d(Lj$/time/temporal/o;)I
    .registers 3

    .prologue
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_9

    invoke-virtual {p0, p1}, Lj$/time/LocalTime;->H(Lj$/time/temporal/o;)I

    move-result p0

    return p0

    :cond_9
    invoke-super {p0, p1}, Lj$/time/temporal/l;->d(Lj$/time/temporal/o;)I

    move-result p0

    return p0
.end method

.method public final e(Lj$/time/temporal/o;)Z
    .registers 3

    .prologue
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_b

    check-cast p1, Lj$/time/temporal/a;

    invoke-virtual {p1}, Lj$/time/temporal/a;->J()Z

    move-result p0

    return p0

    :cond_b
    if-eqz p1, :cond_15

    invoke-interface {p1, p0}, Lj$/time/temporal/o;->n(Lj$/time/temporal/l;)Z

    move-result p0

    if-eqz p0, :cond_15

    const/4 p0, 0x1

    return p0

    :cond_15
    const/4 p0, 0x0

    return p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .prologue
    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lj$/time/LocalTime;

    const/4 v2, 0x0

    if-eqz v1, :cond_24

    check-cast p1, Lj$/time/LocalTime;

    iget-byte v1, p0, Lj$/time/LocalTime;->a:B

    iget-byte v3, p1, Lj$/time/LocalTime;->a:B

    if-ne v1, v3, :cond_24

    iget-byte v1, p0, Lj$/time/LocalTime;->b:B

    iget-byte v3, p1, Lj$/time/LocalTime;->b:B

    if-ne v1, v3, :cond_24

    iget-byte v1, p0, Lj$/time/LocalTime;->c:B

    iget-byte v3, p1, Lj$/time/LocalTime;->c:B

    if-ne v1, v3, :cond_24

    iget p0, p0, Lj$/time/LocalTime;->d:I

    iget p1, p1, Lj$/time/LocalTime;->d:I

    if-ne p0, p1, :cond_24

    return v0

    :cond_24
    return v2
.end method

.method public final f(Lj$/time/temporal/o;)J
    .registers 4

    .prologue
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_1f

    sget-object v0, Lj$/time/temporal/a;->NANO_OF_DAY:Lj$/time/temporal/a;

    if-ne p1, v0, :cond_d

    invoke-virtual {p0}, Lj$/time/LocalTime;->P()J

    move-result-wide p0

    return-wide p0

    :cond_d
    sget-object v0, Lj$/time/temporal/a;->MICRO_OF_DAY:Lj$/time/temporal/a;

    if-ne p1, v0, :cond_19

    invoke-virtual {p0}, Lj$/time/LocalTime;->P()J

    move-result-wide p0

    const-wide/16 v0, 0x3e8

    div-long/2addr p0, v0

    return-wide p0

    :cond_19
    invoke-virtual {p0, p1}, Lj$/time/LocalTime;->H(Lj$/time/temporal/o;)I

    move-result p0

    int-to-long p0, p0

    return-wide p0

    :cond_1f
    invoke-interface {p1, p0}, Lj$/time/temporal/o;->E(Lj$/time/temporal/l;)J

    move-result-wide p0

    return-wide p0
.end method

.method public final bridge synthetic g(JLj$/time/temporal/o;)Lj$/time/temporal/Temporal;
    .registers 4

    invoke-virtual {p0, p1, p2, p3}, Lj$/time/LocalTime;->R(JLj$/time/temporal/o;)Lj$/time/LocalTime;

    move-result-object p0

    return-object p0
.end method

.method public getHour()I
    .registers 1

    iget-byte p0, p0, Lj$/time/LocalTime;->a:B

    return p0
.end method

.method public getMinute()I
    .registers 1

    iget-byte p0, p0, Lj$/time/LocalTime;->b:B

    return p0
.end method

.method public getNano()I
    .registers 1

    iget p0, p0, Lj$/time/LocalTime;->d:I

    return p0
.end method

.method public getSecond()I
    .registers 1

    iget-byte p0, p0, Lj$/time/LocalTime;->c:B

    return p0
.end method

.method public final h(Lj$/time/LocalDate;)Lj$/time/temporal/Temporal;
    .registers 2

    invoke-interface {p1, p0}, Lj$/time/chrono/b;->c(Lj$/time/temporal/Temporal;)Lj$/time/temporal/Temporal;

    move-result-object p0

    check-cast p0, Lj$/time/LocalTime;

    return-object p0
.end method

.method public final hashCode()I
    .registers 5

    invoke-virtual {p0}, Lj$/time/LocalTime;->P()J

    move-result-wide v0

    const/16 p0, 0x20

    ushr-long v2, v0, p0

    xor-long/2addr v0, v2

    long-to-int p0, v0

    return p0
.end method

.method public final bridge synthetic j(JLj$/time/temporal/TemporalUnit;)Lj$/time/temporal/Temporal;
    .registers 4

    invoke-virtual {p0, p1, p2, p3}, Lj$/time/LocalTime;->J(JLj$/time/temporal/TemporalUnit;)Lj$/time/LocalTime;

    move-result-object p0

    return-object p0
.end method

.method public final k(Lj$/time/temporal/Temporal;Lj$/time/temporal/TemporalUnit;)J
    .registers 5

    .prologue
    invoke-static {p1}, Lj$/time/LocalTime;->E(Lj$/time/temporal/l;)Lj$/time/LocalTime;

    move-result-object p1

    instance-of v0, p2, Lj$/time/temporal/ChronoUnit;

    if-eqz v0, :cond_4a

    invoke-virtual {p1}, Lj$/time/LocalTime;->P()J

    move-result-wide v0

    invoke-virtual {p0}, Lj$/time/LocalTime;->P()J

    move-result-wide p0

    sub-long/2addr v0, p0

    sget-object p0, Lj$/time/j;->b:[I

    move-object p1, p2

    check-cast p1, Lj$/time/temporal/ChronoUnit;

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    aget p0, p0, p1

    packed-switch p0, :pswitch_data_50

    const-string p0, "Unsupported unit: "

    invoke-static {p0, p2}, Lj$/time/h;->c(Ljava/lang/String;Ljava/lang/Object;)V

    const-wide/16 p0, 0x0

    return-wide p0

    :pswitch_27  #0x7
    const-wide p0, 0x274a48a78000L

    div-long/2addr v0, p0

    return-wide v0

    :pswitch_2e  #0x6
    const-wide p0, 0x34630b8a000L

    div-long/2addr v0, p0

    return-wide v0

    :pswitch_35  #0x5
    const-wide p0, 0xdf8475800L

    div-long/2addr v0, p0

    return-wide v0

    :pswitch_3c  #0x4
    const-wide/32 p0, 0x3b9aca00

    div-long/2addr v0, p0

    return-wide v0

    :pswitch_41  #0x3
    const-wide/32 p0, 0xf4240

    div-long/2addr v0, p0

    return-wide v0

    :pswitch_46  #0x2
    const-wide/16 p0, 0x3e8

    div-long/2addr v0, p0

    :pswitch_49  #0x1
    return-wide v0

    :cond_4a
    invoke-interface {p2, p0, p1}, Lj$/time/temporal/TemporalUnit;->n(Lj$/time/temporal/Temporal;Lj$/time/temporal/Temporal;)J

    move-result-wide p0

    return-wide p0

    nop

    :pswitch_data_50
    .packed-switch 0x1
        :pswitch_49  #00000001
        :pswitch_46  #00000002
        :pswitch_41  #00000003
        :pswitch_3c  #00000004
        :pswitch_35  #00000005
        :pswitch_2e  #00000006
        :pswitch_27  #00000007
    .end packed-switch
.end method

.method public final n(Lj$/time/LocalTime;)I
    .registers 4

    .prologue
    iget-byte v0, p0, Lj$/time/LocalTime;->a:B

    iget-byte v1, p1, Lj$/time/LocalTime;->a:B

    invoke-static {v0, v1}, Ljava/lang/Integer;->compare(II)I

    move-result v0

    if-nez v0, :cond_27

    iget-byte v0, p0, Lj$/time/LocalTime;->b:B

    iget-byte v1, p1, Lj$/time/LocalTime;->b:B

    invoke-static {v0, v1}, Ljava/lang/Integer;->compare(II)I

    move-result v0

    if-nez v0, :cond_27

    iget-byte v0, p0, Lj$/time/LocalTime;->c:B

    iget-byte v1, p1, Lj$/time/LocalTime;->c:B

    invoke-static {v0, v1}, Ljava/lang/Integer;->compare(II)I

    move-result v0

    if-nez v0, :cond_27

    iget p0, p0, Lj$/time/LocalTime;->d:I

    iget p1, p1, Lj$/time/LocalTime;->d:I

    invoke-static {p0, p1}, Ljava/lang/Integer;->compare(II)I

    move-result p0

    return p0

    :cond_27
    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 8

    .prologue
    new-instance v0, Ljava/lang/StringBuilder;

    const/16 v1, 0x12

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    iget-byte v1, p0, Lj$/time/LocalTime;->a:B

    iget-byte v2, p0, Lj$/time/LocalTime;->b:B

    iget-byte v3, p0, Lj$/time/LocalTime;->c:B

    iget p0, p0, Lj$/time/LocalTime;->d:I

    const/16 v4, 0xa

    if-ge v1, v4, :cond_16

    const-string v5, "0"

    goto :goto_18

    :cond_16
    const-string v5, ""

    :goto_18
    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ":"

    const-string v5, ":0"

    if-ge v2, v4, :cond_26

    move-object v6, v5

    goto :goto_27

    :cond_26
    move-object v6, v1

    :goto_27
    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    if-gtz v3, :cond_31

    if-lez p0, :cond_7a

    :cond_31
    if-ge v3, v4, :cond_34

    move-object v1, v5

    :cond_34
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    if-lez p0, :cond_7a

    const/16 v1, 0x2e

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const v1, 0xf4240

    rem-int v2, p0, v1

    const/4 v3, 0x1

    if-nez v2, :cond_58

    div-int/2addr p0, v1

    add-int/lit16 p0, p0, 0x3e8

    invoke-static {p0}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0, v3}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_7a

    :cond_58
    rem-int/lit16 v2, p0, 0x3e8

    if-nez v2, :cond_6b

    div-int/lit16 p0, p0, 0x3e8

    add-int/2addr p0, v1

    invoke-static {p0}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0, v3}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_7a

    :cond_6b
    const v1, 0x3b9aca00

    add-int/2addr p0, v1

    invoke-static {p0}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0, v3}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_7a
    :goto_7a
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
