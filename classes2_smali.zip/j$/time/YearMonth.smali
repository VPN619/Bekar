.class public final Lj$/time/YearMonth;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lj$/time/temporal/Temporal;
.implements Lj$/time/temporal/m;
.implements Ljava/lang/Comparable;
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lj$/time/temporal/Temporal;",
        "Lj$/time/temporal/m;",
        "Ljava/lang/Comparable<",
        "Lj$/time/YearMonth;",
        ">;",
        "Ljava/io/Serializable;"
    }
.end annotation


# static fields
.field public static final synthetic c:I = 0x0

.field private static final serialVersionUID:J = 0x3a0e6ceaf57ebbc6L


# instance fields
.field public final a:I

.field public final b:I


# direct methods
.method static constructor <clinit>()V
    .registers 5

    new-instance v0, Lj$/time/format/n;

    invoke-direct {v0}, Lj$/time/format/n;-><init>()V

    sget-object v1, Lj$/time/temporal/a;->YEAR:Lj$/time/temporal/a;

    const/16 v2, 0xa

    sget-object v3, Lj$/time/format/u;->EXCEEDS_PAD:Lj$/time/format/u;

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v4, v2, v3}, Lj$/time/format/n;->h(Lj$/time/temporal/o;IILj$/time/format/u;)V

    const/16 v1, 0x2d

    invoke-virtual {v0, v1}, Lj$/time/format/n;->c(C)V

    sget-object v1, Lj$/time/temporal/a;->MONTH_OF_YEAR:Lj$/time/temporal/a;

    const/4 v2, 0x2

    invoke-virtual {v0, v1, v2}, Lj$/time/format/n;->g(Lj$/time/temporal/o;I)V

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v1

    sget-object v2, Lj$/time/format/t;->SMART:Lj$/time/format/t;

    const/4 v3, 0x0

    invoke-virtual {v0, v1, v2, v3}, Lj$/time/format/n;->l(Ljava/util/Locale;Lj$/time/format/t;Lj$/time/chrono/m;)Lj$/time/format/DateTimeFormatter;

    return-void
.end method

.method public constructor <init>(II)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lj$/time/YearMonth;->a:I

    iput p2, p0, Lj$/time/YearMonth;->b:I

    return-void
.end method

.method public static of(II)Lj$/time/YearMonth;
    .registers 5

    sget-object v0, Lj$/time/temporal/a;->YEAR:Lj$/time/temporal/a;

    int-to-long v1, p0

    invoke-virtual {v0, v1, v2}, Lj$/time/temporal/a;->I(J)V

    sget-object v0, Lj$/time/temporal/a;->MONTH_OF_YEAR:Lj$/time/temporal/a;

    int-to-long v1, p1

    invoke-virtual {v0, v1, v2}, Lj$/time/temporal/a;->I(J)V

    new-instance v0, Lj$/time/YearMonth;

    invoke-direct {v0, p0, p1}, Lj$/time/YearMonth;-><init>(II)V

    return-object v0
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .registers 2

    new-instance p0, Ljava/io/InvalidObjectException;

    const-string p1, "Deserialization via serialization delegate"

    invoke-direct {p0, p1}, Ljava/io/InvalidObjectException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private writeReplace()Ljava/lang/Object;
    .registers 3

    new-instance v0, Lj$/time/p;

    const/16 v1, 0xc

    invoke-direct {v0, v1, p0}, Lj$/time/p;-><init>(BLjava/lang/Object;)V

    return-object v0
.end method


# virtual methods
.method public final E(J)Lj$/time/YearMonth;
    .registers 9

    .prologue
    const-wide/16 v0, 0x0

    cmp-long v0, p1, v0

    if-nez v0, :cond_7

    return-object p0

    :cond_7
    iget v0, p0, Lj$/time/YearMonth;->a:I

    int-to-long v0, v0

    const-wide/16 v2, 0xc

    mul-long/2addr v0, v2

    iget v4, p0, Lj$/time/YearMonth;->b:I

    add-int/lit8 v4, v4, -0x1

    int-to-long v4, v4

    add-long/2addr v0, v4

    add-long/2addr v0, p1

    sget-object p1, Lj$/time/temporal/a;->YEAR:Lj$/time/temporal/a;

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->floorDiv(JJ)J

    move-result-wide v4

    iget-object p2, p1, Lj$/time/temporal/a;->b:Lj$/time/temporal/r;

    invoke-virtual {p2, v4, v5, p1}, Lj$/time/temporal/r;->a(JLj$/time/temporal/o;)I

    move-result p1

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->floorMod(JJ)J

    move-result-wide v0

    long-to-int p2, v0

    add-int/lit8 p2, p2, 0x1

    invoke-virtual {p0, p1, p2}, Lj$/time/YearMonth;->I(II)Lj$/time/YearMonth;

    move-result-object p0

    return-object p0
.end method

.method public final H(J)Lj$/time/YearMonth;
    .registers 6

    .prologue
    const-wide/16 v0, 0x0

    cmp-long v0, p1, v0

    if-nez v0, :cond_7

    return-object p0

    :cond_7
    sget-object v0, Lj$/time/temporal/a;->YEAR:Lj$/time/temporal/a;

    iget v1, p0, Lj$/time/YearMonth;->a:I

    int-to-long v1, v1

    add-long/2addr v1, p1

    iget-object p1, v0, Lj$/time/temporal/a;->b:Lj$/time/temporal/r;

    invoke-virtual {p1, v1, v2, v0}, Lj$/time/temporal/r;->a(JLj$/time/temporal/o;)I

    move-result p1

    iget p2, p0, Lj$/time/YearMonth;->b:I

    invoke-virtual {p0, p1, p2}, Lj$/time/YearMonth;->I(II)Lj$/time/YearMonth;

    move-result-object p0

    return-object p0
.end method

.method public final I(II)Lj$/time/YearMonth;
    .registers 4

    .prologue
    iget v0, p0, Lj$/time/YearMonth;->a:I

    if-ne v0, p1, :cond_9

    iget v0, p0, Lj$/time/YearMonth;->b:I

    if-ne v0, p2, :cond_9

    return-object p0

    :cond_9
    new-instance p0, Lj$/time/YearMonth;

    invoke-direct {p0, p1, p2}, Lj$/time/YearMonth;-><init>(II)V

    return-object p0
.end method

.method public final J(JLj$/time/temporal/o;)Lj$/time/YearMonth;
    .registers 8

    .prologue
    instance-of v0, p3, Lj$/time/temporal/a;

    if-eqz v0, :cond_84

    move-object v0, p3

    check-cast v0, Lj$/time/temporal/a;

    invoke-virtual {v0, p1, p2}, Lj$/time/temporal/a;->I(J)V

    sget-object v1, Lj$/time/r;->a:[I

    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    aget v0, v1, v0

    const/4 v1, 0x1

    if-eq v0, v1, :cond_76

    const/4 v2, 0x2

    if-eq v0, v2, :cond_6c

    const/4 v2, 0x3

    if-eq v0, v2, :cond_56

    const/4 v2, 0x4

    if-eq v0, v2, :cond_48

    const/4 v2, 0x5

    if-ne v0, v2, :cond_3c

    sget-object p3, Lj$/time/temporal/a;->ERA:Lj$/time/temporal/a;

    invoke-virtual {p0, p3}, Lj$/time/YearMonth;->f(Lj$/time/temporal/o;)J

    move-result-wide v2

    cmp-long p1, v2, p1

    if-nez p1, :cond_2c

    return-object p0

    :cond_2c
    iget p1, p0, Lj$/time/YearMonth;->a:I

    sub-int/2addr v1, p1

    sget-object p1, Lj$/time/temporal/a;->YEAR:Lj$/time/temporal/a;

    int-to-long p2, v1

    invoke-virtual {p1, p2, p3}, Lj$/time/temporal/a;->I(J)V

    iget p1, p0, Lj$/time/YearMonth;->b:I

    invoke-virtual {p0, v1, p1}, Lj$/time/YearMonth;->I(II)Lj$/time/YearMonth;

    move-result-object p0

    return-object p0

    :cond_3c
    new-instance p0, Lj$/time/temporal/q;

    const-string p1, "Unsupported field: "

    invoke-static {p1, p3}, Lj$/time/d;->a(Ljava/lang/String;Lj$/time/temporal/o;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_48
    long-to-int p1, p1

    sget-object p2, Lj$/time/temporal/a;->YEAR:Lj$/time/temporal/a;

    int-to-long v0, p1

    invoke-virtual {p2, v0, v1}, Lj$/time/temporal/a;->I(J)V

    iget p2, p0, Lj$/time/YearMonth;->b:I

    invoke-virtual {p0, p1, p2}, Lj$/time/YearMonth;->I(II)Lj$/time/YearMonth;

    move-result-object p0

    return-object p0

    :cond_56
    iget p3, p0, Lj$/time/YearMonth;->a:I

    if-ge p3, v1, :cond_5e

    const-wide/16 v0, 0x1

    sub-long p1, v0, p1

    :cond_5e
    long-to-int p1, p1

    sget-object p2, Lj$/time/temporal/a;->YEAR:Lj$/time/temporal/a;

    int-to-long v0, p1

    invoke-virtual {p2, v0, v1}, Lj$/time/temporal/a;->I(J)V

    iget p2, p0, Lj$/time/YearMonth;->b:I

    invoke-virtual {p0, p1, p2}, Lj$/time/YearMonth;->I(II)Lj$/time/YearMonth;

    move-result-object p0

    return-object p0

    :cond_6c
    invoke-virtual {p0}, Lj$/time/YearMonth;->n()J

    move-result-wide v0

    sub-long/2addr p1, v0

    invoke-virtual {p0, p1, p2}, Lj$/time/YearMonth;->E(J)Lj$/time/YearMonth;

    move-result-object p0

    return-object p0

    :cond_76
    long-to-int p1, p1

    sget-object p2, Lj$/time/temporal/a;->MONTH_OF_YEAR:Lj$/time/temporal/a;

    int-to-long v0, p1

    invoke-virtual {p2, v0, v1}, Lj$/time/temporal/a;->I(J)V

    iget p2, p0, Lj$/time/YearMonth;->a:I

    invoke-virtual {p0, p2, p1}, Lj$/time/YearMonth;->I(II)Lj$/time/YearMonth;

    move-result-object p0

    return-object p0

    :cond_84
    invoke-interface {p3, p0, p1, p2}, Lj$/time/temporal/o;->H(Lj$/time/temporal/Temporal;J)Lj$/time/temporal/Temporal;

    move-result-object p0

    check-cast p0, Lj$/time/YearMonth;

    return-object p0
.end method

.method public final a(JLj$/time/temporal/TemporalUnit;)Lj$/time/temporal/Temporal;
    .registers 6

    .prologue
    const-wide/high16 v0, -0x8000000000000000L

    cmp-long v0, p1, v0

    if-nez v0, :cond_16

    const-wide p1, 0x7fffffffffffffffL

    invoke-virtual {p0, p1, p2, p3}, Lj$/time/YearMonth;->v(JLj$/time/temporal/TemporalUnit;)Lj$/time/YearMonth;

    move-result-object p0

    const-wide/16 p1, 0x1

    :goto_11
    invoke-virtual {p0, p1, p2, p3}, Lj$/time/YearMonth;->v(JLj$/time/temporal/TemporalUnit;)Lj$/time/YearMonth;

    move-result-object p0

    return-object p0

    :cond_16
    neg-long p1, p1

    goto :goto_11
.end method

.method public final b(Lj$/time/format/a;)Ljava/lang/Object;
    .registers 3

    .prologue
    sget-object v0, Lj$/time/temporal/p;->b:Lj$/time/format/a;

    if-ne p1, v0, :cond_7

    sget-object p0, Lj$/time/chrono/t;->c:Lj$/time/chrono/t;

    return-object p0

    :cond_7
    sget-object v0, Lj$/time/temporal/p;->c:Lj$/time/format/a;

    if-ne p1, v0, :cond_e

    sget-object p0, Lj$/time/temporal/ChronoUnit;->MONTHS:Lj$/time/temporal/ChronoUnit;

    return-object p0

    :cond_e
    invoke-super {p0, p1}, Lj$/time/temporal/l;->b(Lj$/time/format/a;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final c(Lj$/time/temporal/Temporal;)Lj$/time/temporal/Temporal;
    .registers 5

    .prologue
    invoke-static {p1}, Lj$/time/chrono/m;->m(Lj$/time/temporal/l;)Lj$/time/chrono/m;

    move-result-object v0

    sget-object v1, Lj$/time/chrono/t;->c:Lj$/time/chrono/t;

    invoke-interface {v0, v1}, Lj$/time/chrono/m;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_17

    sget-object v0, Lj$/time/temporal/a;->PROLEPTIC_MONTH:Lj$/time/temporal/a;

    invoke-virtual {p0}, Lj$/time/YearMonth;->n()J

    move-result-wide v1

    invoke-interface {p1, v1, v2, v0}, Lj$/time/temporal/Temporal;->g(JLj$/time/temporal/o;)Lj$/time/temporal/Temporal;

    move-result-object p0

    return-object p0

    :cond_17
    new-instance p0, Lj$/time/c;

    const-string p1, "Adjustment only supported on ISO date-time"

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final compareTo(Ljava/lang/Object;)I
    .registers 4

    .prologue
    check-cast p1, Lj$/time/YearMonth;

    iget v0, p0, Lj$/time/YearMonth;->a:I

    iget v1, p1, Lj$/time/YearMonth;->a:I

    sub-int/2addr v0, v1

    if-nez v0, :cond_f

    iget p0, p0, Lj$/time/YearMonth;->b:I

    iget p1, p1, Lj$/time/YearMonth;->b:I

    sub-int/2addr p0, p1

    return p0

    :cond_f
    return v0
.end method

.method public final d(Lj$/time/temporal/o;)I
    .registers 5

    invoke-virtual {p0, p1}, Lj$/time/YearMonth;->i(Lj$/time/temporal/o;)Lj$/time/temporal/r;

    move-result-object v0

    invoke-virtual {p0, p1}, Lj$/time/YearMonth;->f(Lj$/time/temporal/o;)J

    move-result-wide v1

    invoke-virtual {v0, v1, v2, p1}, Lj$/time/temporal/r;->a(JLj$/time/temporal/o;)I

    move-result p0

    return p0
.end method

.method public final e(Lj$/time/temporal/o;)Z
    .registers 3

    .prologue
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_19

    sget-object p0, Lj$/time/temporal/a;->YEAR:Lj$/time/temporal/a;

    if-eq p1, p0, :cond_21

    sget-object p0, Lj$/time/temporal/a;->MONTH_OF_YEAR:Lj$/time/temporal/a;

    if-eq p1, p0, :cond_21

    sget-object p0, Lj$/time/temporal/a;->PROLEPTIC_MONTH:Lj$/time/temporal/a;

    if-eq p1, p0, :cond_21

    sget-object p0, Lj$/time/temporal/a;->YEAR_OF_ERA:Lj$/time/temporal/a;

    if-eq p1, p0, :cond_21

    sget-object p0, Lj$/time/temporal/a;->ERA:Lj$/time/temporal/a;

    if-ne p1, p0, :cond_23

    goto :goto_21

    :cond_19
    if-eqz p1, :cond_23

    invoke-interface {p1, p0}, Lj$/time/temporal/o;->n(Lj$/time/temporal/l;)Z

    move-result p0

    if-eqz p0, :cond_23

    :cond_21
    :goto_21
    const/4 p0, 0x1

    return p0

    :cond_23
    const/4 p0, 0x0

    return p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .prologue
    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lj$/time/YearMonth;

    const/4 v2, 0x0

    if-eqz v1, :cond_18

    check-cast p1, Lj$/time/YearMonth;

    iget v1, p0, Lj$/time/YearMonth;->a:I

    iget v3, p1, Lj$/time/YearMonth;->a:I

    if-ne v1, v3, :cond_18

    iget p0, p0, Lj$/time/YearMonth;->b:I

    iget p1, p1, Lj$/time/YearMonth;->b:I

    if-ne p0, p1, :cond_18

    return v0

    :cond_18
    return v2
.end method

.method public final f(Lj$/time/temporal/o;)J
    .registers 5

    .prologue
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_45

    sget-object v0, Lj$/time/r;->a:[I

    move-object v1, p1

    check-cast v1, Lj$/time/temporal/a;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget v0, v0, v1

    const/4 v1, 0x1

    if-eq v0, v1, :cond_42

    const/4 v2, 0x2

    if-eq v0, v2, :cond_3d

    const/4 v2, 0x3

    if-eq v0, v2, :cond_35

    const/4 v2, 0x4

    if-eq v0, v2, :cond_31

    const/4 v2, 0x5

    if-ne v0, v2, :cond_25

    iget p0, p0, Lj$/time/YearMonth;->a:I

    if-ge p0, v1, :cond_23

    const/4 v1, 0x0

    :cond_23
    int-to-long p0, v1

    return-wide p0

    :cond_25
    new-instance p0, Lj$/time/temporal/q;

    const-string v0, "Unsupported field: "

    invoke-static {v0, p1}, Lj$/time/d;->a(Ljava/lang/String;Lj$/time/temporal/o;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_31
    iget p0, p0, Lj$/time/YearMonth;->a:I

    :goto_33
    int-to-long p0, p0

    return-wide p0

    :cond_35
    iget p0, p0, Lj$/time/YearMonth;->a:I

    if-ge p0, v1, :cond_3b

    rsub-int/lit8 p0, p0, 0x1

    :cond_3b
    int-to-long p0, p0

    return-wide p0

    :cond_3d
    invoke-virtual {p0}, Lj$/time/YearMonth;->n()J

    move-result-wide p0

    return-wide p0

    :cond_42
    iget p0, p0, Lj$/time/YearMonth;->b:I

    goto :goto_33

    :cond_45
    invoke-interface {p1, p0}, Lj$/time/temporal/o;->E(Lj$/time/temporal/l;)J

    move-result-wide p0

    return-wide p0
.end method

.method public final bridge synthetic g(JLj$/time/temporal/o;)Lj$/time/temporal/Temporal;
    .registers 4

    invoke-virtual {p0, p1, p2, p3}, Lj$/time/YearMonth;->J(JLj$/time/temporal/o;)Lj$/time/YearMonth;

    move-result-object p0

    return-object p0
.end method

.method public getMonthValue()I
    .registers 1

    iget p0, p0, Lj$/time/YearMonth;->b:I

    return p0
.end method

.method public getYear()I
    .registers 1

    iget p0, p0, Lj$/time/YearMonth;->a:I

    return p0
.end method

.method public final h(Lj$/time/LocalDate;)Lj$/time/temporal/Temporal;
    .registers 2

    invoke-interface {p1, p0}, Lj$/time/chrono/b;->c(Lj$/time/temporal/Temporal;)Lj$/time/temporal/Temporal;

    move-result-object p0

    check-cast p0, Lj$/time/YearMonth;

    return-object p0
.end method

.method public final hashCode()I
    .registers 2

    iget v0, p0, Lj$/time/YearMonth;->a:I

    iget p0, p0, Lj$/time/YearMonth;->b:I

    shl-int/lit8 p0, p0, 0x1b

    xor-int/2addr p0, v0

    return p0
.end method

.method public final i(Lj$/time/temporal/o;)Lj$/time/temporal/r;
    .registers 4

    .prologue
    sget-object v0, Lj$/time/temporal/a;->YEAR_OF_ERA:Lj$/time/temporal/a;

    if-ne p1, v0, :cond_18

    invoke-virtual {p0}, Lj$/time/YearMonth;->getYear()I

    move-result p0

    const-wide/16 v0, 0x1

    if-gtz p0, :cond_14

    const-wide/32 p0, 0x3b9aca00

    :goto_f
    invoke-static {v0, v1, p0, p1}, Lj$/time/temporal/r;->e(JJ)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_14
    const-wide/32 p0, 0x3b9ac9ff

    goto :goto_f

    :cond_18
    invoke-super {p0, p1}, Lj$/time/temporal/l;->i(Lj$/time/temporal/o;)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0
.end method

.method public final bridge synthetic j(JLj$/time/temporal/TemporalUnit;)Lj$/time/temporal/Temporal;
    .registers 4

    invoke-virtual {p0, p1, p2, p3}, Lj$/time/YearMonth;->v(JLj$/time/temporal/TemporalUnit;)Lj$/time/YearMonth;

    move-result-object p0

    return-object p0
.end method

.method public final k(Lj$/time/temporal/Temporal;Lj$/time/temporal/TemporalUnit;)J
    .registers 10

    .prologue
    instance-of v0, p1, Lj$/time/YearMonth;

    const-wide/16 v1, 0x0

    if-eqz v0, :cond_9

    check-cast p1, Lj$/time/YearMonth;

    goto :goto_31

    :cond_9
    const-string v0, "temporal"

    invoke-static {p1, v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    :try_start_e
    sget-object v0, Lj$/time/chrono/t;->c:Lj$/time/chrono/t;

    invoke-static {p1}, Lj$/time/chrono/m;->m(Lj$/time/temporal/l;)Lj$/time/chrono/m;

    move-result-object v3

    invoke-virtual {v0, v3}, Lj$/time/chrono/a;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_21

    invoke-static {p1}, Lj$/time/LocalDate;->E(Lj$/time/temporal/l;)Lj$/time/LocalDate;

    move-result-object p1

    goto :goto_21

    :catch_1f
    move-exception p0

    goto :goto_73

    :cond_21
    :goto_21
    sget-object v0, Lj$/time/temporal/a;->YEAR:Lj$/time/temporal/a;

    invoke-interface {p1, v0}, Lj$/time/temporal/l;->d(Lj$/time/temporal/o;)I

    move-result v0

    sget-object v3, Lj$/time/temporal/a;->MONTH_OF_YEAR:Lj$/time/temporal/a;

    invoke-interface {p1, v3}, Lj$/time/temporal/l;->d(Lj$/time/temporal/o;)I

    move-result v3

    invoke-static {v0, v3}, Lj$/time/YearMonth;->of(II)Lj$/time/YearMonth;

    move-result-object p1
    :try_end_31
    .catch Lj$/time/c; {:try_start_e .. :try_end_31} :catch_1f

    :goto_31
    instance-of v0, p2, Lj$/time/temporal/ChronoUnit;

    if-eqz v0, :cond_6e

    invoke-virtual {p1}, Lj$/time/YearMonth;->n()J

    move-result-wide v3

    invoke-virtual {p0}, Lj$/time/YearMonth;->n()J

    move-result-wide v5

    sub-long/2addr v3, v5

    sget-object v0, Lj$/time/r;->b:[I

    move-object v5, p2

    check-cast v5, Lj$/time/temporal/ChronoUnit;

    invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I

    move-result v5

    aget v0, v0, v5

    packed-switch v0, :pswitch_data_82

    const-string p0, "Unsupported unit: "

    invoke-static {p0, p2}, Lj$/time/h;->c(Ljava/lang/String;Ljava/lang/Object;)V

    return-wide v1

    :pswitch_52  #0x6
    sget-object p2, Lj$/time/temporal/a;->ERA:Lj$/time/temporal/a;

    invoke-virtual {p1, p2}, Lj$/time/YearMonth;->f(Lj$/time/temporal/o;)J

    move-result-wide v0

    invoke-virtual {p0, p2}, Lj$/time/YearMonth;->f(Lj$/time/temporal/o;)J

    move-result-wide p0

    sub-long/2addr v0, p0

    return-wide v0

    :pswitch_5e  #0x5
    const-wide/16 p0, 0x2ee0

    div-long/2addr v3, p0

    return-wide v3

    :pswitch_62  #0x4
    const-wide/16 p0, 0x4b0

    div-long/2addr v3, p0

    return-wide v3

    :pswitch_66  #0x3
    const-wide/16 p0, 0x78

    div-long/2addr v3, p0

    return-wide v3

    :pswitch_6a  #0x2
    const-wide/16 p0, 0xc

    div-long/2addr v3, p0

    :pswitch_6d  #0x1
    return-wide v3

    :cond_6e
    invoke-interface {p2, p0, p1}, Lj$/time/temporal/TemporalUnit;->n(Lj$/time/temporal/Temporal;Lj$/time/temporal/Temporal;)J

    move-result-wide p0

    return-wide p0

    :goto_73
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p2

    const-string v0, "Unable to obtain YearMonth from TemporalAccessor: "

    invoke-static {v0, p1, p2, p0}, Lj$/time/h;->e(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Throwable;)V

    return-wide v1

    nop

    :pswitch_data_82
    .packed-switch 0x1
        :pswitch_6d  #00000001
        :pswitch_6a  #00000002
        :pswitch_66  #00000003
        :pswitch_62  #00000004
        :pswitch_5e  #00000005
        :pswitch_52  #00000006
    .end packed-switch
.end method

.method public final n()J
    .registers 5

    iget v0, p0, Lj$/time/YearMonth;->a:I

    int-to-long v0, v0

    const-wide/16 v2, 0xc

    mul-long/2addr v0, v2

    iget p0, p0, Lj$/time/YearMonth;->b:I

    int-to-long v2, p0

    add-long/2addr v0, v2

    const-wide/16 v2, 0x1

    sub-long/2addr v0, v2

    return-wide v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 5

    .prologue
    iget v0, p0, Lj$/time/YearMonth;->a:I

    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    move-result v0

    new-instance v1, Ljava/lang/StringBuilder;

    const/16 v2, 0x9

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(I)V

    iget v2, p0, Lj$/time/YearMonth;->a:I

    const/16 v3, 0x3e8

    if-ge v0, v3, :cond_29

    if-gez v2, :cond_1f

    add-int/lit16 v2, v2, -0x2710

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v0, 0x1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->deleteCharAt(I)Ljava/lang/StringBuilder;

    goto :goto_2c

    :cond_1f
    add-int/lit16 v2, v2, 0x2710

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->deleteCharAt(I)Ljava/lang/StringBuilder;

    goto :goto_2c

    :cond_29
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    :goto_2c
    iget v0, p0, Lj$/time/YearMonth;->b:I

    const/16 v2, 0xa

    if-ge v0, v2, :cond_35

    const-string v0, "-0"

    goto :goto_37

    :cond_35
    const-string v0, "-"

    :goto_37
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget p0, p0, Lj$/time/YearMonth;->b:I

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public final v(JLj$/time/temporal/TemporalUnit;)Lj$/time/YearMonth;
    .registers 6

    .prologue
    instance-of v0, p3, Lj$/time/temporal/ChronoUnit;

    if-eqz v0, :cond_53

    sget-object v0, Lj$/time/r;->b:[I

    move-object v1, p3

    check-cast v1, Lj$/time/temporal/ChronoUnit;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget v0, v0, v1

    packed-switch v0, :pswitch_data_5a

    const-string p0, "Unsupported unit: "

    invoke-static {p0, p3}, Lj$/time/h;->c(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 p0, 0x0

    return-object p0

    :pswitch_19  #0x6
    sget-object p3, Lj$/time/temporal/a;->ERA:Lj$/time/temporal/a;

    invoke-virtual {p0, p3}, Lj$/time/YearMonth;->f(Lj$/time/temporal/o;)J

    move-result-wide v0

    invoke-static {v0, v1, p1, p2}, Ljava/lang/Math;->addExact(JJ)J

    move-result-wide p1

    invoke-virtual {p0, p1, p2, p3}, Lj$/time/YearMonth;->J(JLj$/time/temporal/o;)Lj$/time/YearMonth;

    move-result-object p0

    return-object p0

    :pswitch_28  #0x5
    const-wide/16 v0, 0x3e8

    invoke-static {p1, p2, v0, v1}, Ljava/lang/Math;->multiplyExact(JJ)J

    move-result-wide p1

    invoke-virtual {p0, p1, p2}, Lj$/time/YearMonth;->H(J)Lj$/time/YearMonth;

    move-result-object p0

    return-object p0

    :pswitch_33  #0x4
    const-wide/16 v0, 0x64

    invoke-static {p1, p2, v0, v1}, Ljava/lang/Math;->multiplyExact(JJ)J

    move-result-wide p1

    invoke-virtual {p0, p1, p2}, Lj$/time/YearMonth;->H(J)Lj$/time/YearMonth;

    move-result-object p0

    return-object p0

    :pswitch_3e  #0x3
    const-wide/16 v0, 0xa

    invoke-static {p1, p2, v0, v1}, Ljava/lang/Math;->multiplyExact(JJ)J

    move-result-wide p1

    invoke-virtual {p0, p1, p2}, Lj$/time/YearMonth;->H(J)Lj$/time/YearMonth;

    move-result-object p0

    return-object p0

    :pswitch_49  #0x2
    invoke-virtual {p0, p1, p2}, Lj$/time/YearMonth;->H(J)Lj$/time/YearMonth;

    move-result-object p0

    return-object p0

    :pswitch_4e  #0x1
    invoke-virtual {p0, p1, p2}, Lj$/time/YearMonth;->E(J)Lj$/time/YearMonth;

    move-result-object p0

    return-object p0

    :cond_53
    invoke-interface {p3, p0, p1, p2}, Lj$/time/temporal/TemporalUnit;->v(Lj$/time/temporal/Temporal;J)Lj$/time/temporal/Temporal;

    move-result-object p0

    check-cast p0, Lj$/time/YearMonth;

    return-object p0

    :pswitch_data_5a
    .packed-switch 0x1
        :pswitch_4e  #00000001
        :pswitch_49  #00000002
        :pswitch_3e  #00000003
        :pswitch_33  #00000004
        :pswitch_28  #00000005
        :pswitch_19  #00000006
    .end packed-switch
.end method
