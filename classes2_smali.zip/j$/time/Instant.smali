.class public final Lj$/time/Instant;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lj$/time/temporal/Temporal;
.implements Lj$/time/temporal/m;
.implements Ljava/lang/Comparable;
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lj$/time/temporal/Temporal;",
        "Lj$/time/temporal/m;",
        "Ljava/lang/Comparable<",
        "Lj$/time/Instant;",
        ">;",
        "Ljava/io/Serializable;"
    }
.end annotation


# static fields
.field public static final c:Lj$/time/Instant;

.field private static final serialVersionUID:J = -0x93d170fdcc5dce4L


# instance fields
.field public final a:J

.field public final b:I


# direct methods
.method static constructor <clinit>()V
    .registers 4

    new-instance v0, Lj$/time/Instant;

    const/4 v1, 0x0

    const-wide/16 v2, 0x0

    invoke-direct {v0, v2, v3, v1}, Lj$/time/Instant;-><init>(JI)V

    sput-object v0, Lj$/time/Instant;->c:Lj$/time/Instant;

    const-wide v0, -0x701cefeb9bec00L

    invoke-static {v0, v1, v2, v3}, Lj$/time/Instant;->ofEpochSecond(JJ)Lj$/time/Instant;

    const-wide v0, 0x701cd2fa9578ffL

    const-wide/32 v2, 0x3b9ac9ff

    invoke-static {v0, v1, v2, v3}, Lj$/time/Instant;->ofEpochSecond(JJ)Lj$/time/Instant;

    return-void
.end method

.method public constructor <init>(JI)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, Lj$/time/Instant;->a:J

    iput p3, p0, Lj$/time/Instant;->b:I

    return-void
.end method

.method public static n(JI)Lj$/time/Instant;
    .registers 7

    .prologue
    int-to-long v0, p2

    or-long/2addr v0, p0

    const-wide/16 v2, 0x0

    cmp-long v0, v0, v2

    if-nez v0, :cond_b

    sget-object p0, Lj$/time/Instant;->c:Lj$/time/Instant;

    return-object p0

    :cond_b
    const-wide v0, -0x701cefeb9bec00L

    cmp-long v0, p0, v0

    if-ltz v0, :cond_23

    const-wide v0, 0x701cd2fa9578ffL

    cmp-long v0, p0, v0

    if-gtz v0, :cond_23

    new-instance v0, Lj$/time/Instant;

    invoke-direct {v0, p0, p1, p2}, Lj$/time/Instant;-><init>(JI)V

    return-object v0

    :cond_23
    new-instance p0, Lj$/time/c;

    const-string p1, "Instant exceeds minimum or maximum instant"

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static ofEpochSecond(JJ)Lj$/time/Instant;
    .registers 8

    const-wide/32 v0, 0x3b9aca00

    invoke-static {p2, p3, v0, v1}, Ljava/lang/Math;->floorDiv(JJ)J

    move-result-wide v2

    invoke-static {p0, p1, v2, v3}, Ljava/lang/Math;->addExact(JJ)J

    move-result-wide p0

    invoke-static {p2, p3, v0, v1}, Ljava/lang/Math;->floorMod(JJ)J

    move-result-wide p2

    long-to-int p2, p2

    invoke-static {p0, p1, p2}, Lj$/time/Instant;->n(JI)Lj$/time/Instant;

    move-result-object p0

    return-object p0
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .registers 2

    new-instance p0, Ljava/io/InvalidObjectException;

    const-string p1, "Deserialization via serialization delegate"

    invoke-direct {p0, p1}, Ljava/io/InvalidObjectException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static v(Lj$/time/temporal/Temporal;)Lj$/time/Instant;
    .registers 5

    .prologue
    instance-of v0, p0, Lj$/time/Instant;

    if-eqz v0, :cond_7

    check-cast p0, Lj$/time/Instant;

    return-object p0

    :cond_7
    const-string v0, "temporal"

    invoke-static {p0, v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    :try_start_c
    sget-object v0, Lj$/time/temporal/a;->INSTANT_SECONDS:Lj$/time/temporal/a;

    invoke-interface {p0, v0}, Lj$/time/temporal/l;->f(Lj$/time/temporal/o;)J

    move-result-wide v0

    sget-object v2, Lj$/time/temporal/a;->NANO_OF_SECOND:Lj$/time/temporal/a;

    invoke-interface {p0, v2}, Lj$/time/temporal/l;->d(Lj$/time/temporal/o;)I

    move-result v2

    int-to-long v2, v2

    invoke-static {v0, v1, v2, v3}, Lj$/time/Instant;->ofEpochSecond(JJ)Lj$/time/Instant;

    move-result-object p0
    :try_end_1d
    .catch Lj$/time/c; {:try_start_c .. :try_end_1d} :catch_1e

    return-object p0

    :catch_1e
    move-exception v0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    const-string v2, "Unable to obtain Instant from TemporalAccessor: "

    invoke-static {v2, p0, v1, v0}, Lj$/time/h;->e(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Throwable;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method private writeReplace()Ljava/lang/Object;
    .registers 3

    new-instance v0, Lj$/time/p;

    const/4 v1, 0x2

    invoke-direct {v0, v1, p0}, Lj$/time/p;-><init>(BLjava/lang/Object;)V

    return-object v0
.end method


# virtual methods
.method public final E(JJ)Lj$/time/Instant;
    .registers 9

    .prologue
    or-long v0, p1, p3

    const-wide/16 v2, 0x0

    cmp-long v0, v0, v2

    if-nez v0, :cond_9

    return-object p0

    :cond_9
    iget-wide v0, p0, Lj$/time/Instant;->a:J

    invoke-static {v0, v1, p1, p2}, Ljava/lang/Math;->addExact(JJ)J

    move-result-wide p1

    const-wide/32 v0, 0x3b9aca00

    div-long v2, p3, v0

    invoke-static {p1, p2, v2, v3}, Ljava/lang/Math;->addExact(JJ)J

    move-result-wide p1

    rem-long/2addr p3, v0

    iget p0, p0, Lj$/time/Instant;->b:I

    int-to-long v0, p0

    add-long/2addr v0, p3

    invoke-static {p1, p2, v0, v1}, Lj$/time/Instant;->ofEpochSecond(JJ)Lj$/time/Instant;

    move-result-object p0

    return-object p0
.end method

.method public final H(JLj$/time/temporal/TemporalUnit;)Lj$/time/Instant;
    .registers 11

    .prologue
    instance-of v0, p3, Lj$/time/temporal/ChronoUnit;

    if-eqz v0, :cond_6a

    sget-object v0, Lj$/time/f;->b:[I

    move-object v1, p3

    check-cast v1, Lj$/time/temporal/ChronoUnit;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget v0, v0, v1

    const-wide/16 v1, 0x3e8

    const-wide/32 v3, 0xf4240

    const-wide/16 v5, 0x0

    packed-switch v0, :pswitch_data_72

    const-string p0, "Unsupported unit: "

    invoke-static {p0, p3}, Lj$/time/h;->c(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 p0, 0x0

    return-object p0

    :pswitch_20  #0x8
    const-wide/32 v0, 0x15180

    invoke-static {p1, p2, v0, v1}, Ljava/lang/Math;->multiplyExact(JJ)J

    move-result-wide p1

    invoke-virtual {p0, p1, p2, v5, v6}, Lj$/time/Instant;->E(JJ)Lj$/time/Instant;

    move-result-object p0

    return-object p0

    :pswitch_2c  #0x7
    const-wide/32 v0, 0xa8c0

    invoke-static {p1, p2, v0, v1}, Ljava/lang/Math;->multiplyExact(JJ)J

    move-result-wide p1

    invoke-virtual {p0, p1, p2, v5, v6}, Lj$/time/Instant;->E(JJ)Lj$/time/Instant;

    move-result-object p0

    return-object p0

    :pswitch_38  #0x6
    const-wide/16 v0, 0xe10

    invoke-static {p1, p2, v0, v1}, Ljava/lang/Math;->multiplyExact(JJ)J

    move-result-wide p1

    invoke-virtual {p0, p1, p2, v5, v6}, Lj$/time/Instant;->E(JJ)Lj$/time/Instant;

    move-result-object p0

    return-object p0

    :pswitch_43  #0x5
    const-wide/16 v0, 0x3c

    invoke-static {p1, p2, v0, v1}, Ljava/lang/Math;->multiplyExact(JJ)J

    move-result-wide p1

    invoke-virtual {p0, p1, p2, v5, v6}, Lj$/time/Instant;->E(JJ)Lj$/time/Instant;

    move-result-object p0

    return-object p0

    :pswitch_4e  #0x4
    invoke-virtual {p0, p1, p2, v5, v6}, Lj$/time/Instant;->E(JJ)Lj$/time/Instant;

    move-result-object p0

    return-object p0

    :pswitch_53  #0x3
    div-long v5, p1, v1

    rem-long/2addr p1, v1

    mul-long/2addr p1, v3

    invoke-virtual {p0, v5, v6, p1, p2}, Lj$/time/Instant;->E(JJ)Lj$/time/Instant;

    move-result-object p0

    return-object p0

    :pswitch_5c  #0x2
    div-long v5, p1, v3

    rem-long/2addr p1, v3

    mul-long/2addr p1, v1

    invoke-virtual {p0, v5, v6, p1, p2}, Lj$/time/Instant;->E(JJ)Lj$/time/Instant;

    move-result-object p0

    return-object p0

    :pswitch_65  #0x1
    invoke-virtual {p0, v5, v6, p1, p2}, Lj$/time/Instant;->E(JJ)Lj$/time/Instant;

    move-result-object p0

    return-object p0

    :cond_6a
    invoke-interface {p3, p0, p1, p2}, Lj$/time/temporal/TemporalUnit;->v(Lj$/time/temporal/Temporal;J)Lj$/time/temporal/Temporal;

    move-result-object p0

    check-cast p0, Lj$/time/Instant;

    return-object p0

    nop

    :pswitch_data_72
    .packed-switch 0x1
        :pswitch_65  #00000001
        :pswitch_5c  #00000002
        :pswitch_53  #00000003
        :pswitch_4e  #00000004
        :pswitch_43  #00000005
        :pswitch_38  #00000006
        :pswitch_2c  #00000007
        :pswitch_20  #00000008
    .end packed-switch
.end method

.method public final I(Lj$/time/Instant;)J
    .registers 10

    .prologue
    iget-wide v0, p1, Lj$/time/Instant;->a:J

    iget-wide v2, p0, Lj$/time/Instant;->a:J

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->subtractExact(JJ)J

    move-result-wide v0

    iget p1, p1, Lj$/time/Instant;->b:I

    iget p0, p0, Lj$/time/Instant;->b:I

    sub-int/2addr p1, p0

    int-to-long p0, p1

    const-wide/16 v2, 0x0

    cmp-long v4, v0, v2

    const-wide/16 v5, 0x1

    if-lez v4, :cond_1c

    cmp-long v7, p0, v2

    if-gez v7, :cond_1c

    sub-long/2addr v0, v5

    return-wide v0

    :cond_1c
    if-gez v4, :cond_23

    cmp-long p0, p0, v2

    if-lez p0, :cond_23

    add-long/2addr v0, v5

    :cond_23
    return-wide v0
.end method

.method public final J()J
    .registers 9

    .prologue
    iget-wide v0, p0, Lj$/time/Instant;->a:J

    const-wide/16 v2, 0x0

    cmp-long v2, v0, v2

    const v3, 0xf4240

    const-wide/16 v4, 0x3e8

    if-gez v2, :cond_23

    iget v2, p0, Lj$/time/Instant;->b:I

    if-lez v2, :cond_23

    const-wide/16 v6, 0x1

    add-long/2addr v0, v6

    invoke-static {v0, v1, v4, v5}, Ljava/lang/Math;->multiplyExact(JJ)J

    move-result-wide v0

    iget p0, p0, Lj$/time/Instant;->b:I

    div-int/2addr p0, v3

    add-int/lit16 p0, p0, -0x3e8

    int-to-long v2, p0

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->addExact(JJ)J

    move-result-wide v0

    return-wide v0

    :cond_23
    invoke-static {v0, v1, v4, v5}, Ljava/lang/Math;->multiplyExact(JJ)J

    move-result-wide v0

    iget p0, p0, Lj$/time/Instant;->b:I

    div-int/2addr p0, v3

    int-to-long v2, p0

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->addExact(JJ)J

    move-result-wide v0

    return-wide v0
.end method

.method public final a(JLj$/time/temporal/TemporalUnit;)Lj$/time/temporal/Temporal;
    .registers 6

    .prologue
    const-wide/high16 v0, -0x8000000000000000L

    cmp-long v0, p1, v0

    if-nez v0, :cond_16

    const-wide p1, 0x7fffffffffffffffL

    invoke-virtual {p0, p1, p2, p3}, Lj$/time/Instant;->H(JLj$/time/temporal/TemporalUnit;)Lj$/time/Instant;

    move-result-object p0

    const-wide/16 p1, 0x1

    :goto_11
    invoke-virtual {p0, p1, p2, p3}, Lj$/time/Instant;->H(JLj$/time/temporal/TemporalUnit;)Lj$/time/Instant;

    move-result-object p0

    return-object p0

    :cond_16
    neg-long p1, p1

    goto :goto_11
.end method

.method public atOffset(Lj$/time/ZoneOffset;)Lj$/time/OffsetDateTime;
    .registers 2

    invoke-static {p0, p1}, Lj$/time/OffsetDateTime;->n(Lj$/time/Instant;Lj$/time/ZoneId;)Lj$/time/OffsetDateTime;

    move-result-object p0

    return-object p0
.end method

.method public final b(Lj$/time/format/a;)Ljava/lang/Object;
    .registers 3

    .prologue
    sget-object v0, Lj$/time/temporal/p;->c:Lj$/time/format/a;

    if-ne p1, v0, :cond_7

    sget-object p0, Lj$/time/temporal/ChronoUnit;->NANOS:Lj$/time/temporal/ChronoUnit;

    return-object p0

    :cond_7
    sget-object v0, Lj$/time/temporal/p;->b:Lj$/time/format/a;

    if-eq p1, v0, :cond_25

    sget-object v0, Lj$/time/temporal/p;->a:Lj$/time/format/a;

    if-eq p1, v0, :cond_25

    sget-object v0, Lj$/time/temporal/p;->e:Lj$/time/format/a;

    if-eq p1, v0, :cond_25

    sget-object v0, Lj$/time/temporal/p;->d:Lj$/time/format/a;

    if-eq p1, v0, :cond_25

    sget-object v0, Lj$/time/temporal/p;->f:Lj$/time/format/a;

    if-eq p1, v0, :cond_25

    sget-object v0, Lj$/time/temporal/p;->g:Lj$/time/format/a;

    if-ne p1, v0, :cond_20

    goto :goto_25

    :cond_20
    invoke-virtual {p1, p0}, Lj$/time/format/a;->a(Lj$/time/temporal/l;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :cond_25
    :goto_25
    const/4 p0, 0x0

    return-object p0
.end method

.method public final c(Lj$/time/temporal/Temporal;)Lj$/time/temporal/Temporal;
    .registers 5

    sget-object v0, Lj$/time/temporal/a;->INSTANT_SECONDS:Lj$/time/temporal/a;

    iget-wide v1, p0, Lj$/time/Instant;->a:J

    invoke-interface {p1, v1, v2, v0}, Lj$/time/temporal/Temporal;->g(JLj$/time/temporal/o;)Lj$/time/temporal/Temporal;

    move-result-object p1

    sget-object v0, Lj$/time/temporal/a;->NANO_OF_SECOND:Lj$/time/temporal/a;

    iget p0, p0, Lj$/time/Instant;->b:I

    int-to-long v1, p0

    invoke-interface {p1, v1, v2, v0}, Lj$/time/temporal/Temporal;->g(JLj$/time/temporal/o;)Lj$/time/temporal/Temporal;

    move-result-object p0

    return-object p0
.end method

.method public final compareTo(Ljava/lang/Object;)I
    .registers 6

    .prologue
    check-cast p1, Lj$/time/Instant;

    iget-wide v0, p0, Lj$/time/Instant;->a:J

    iget-wide v2, p1, Lj$/time/Instant;->a:J

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Long;->compare(JJ)I

    move-result v0

    if-eqz v0, :cond_d

    return v0

    :cond_d
    iget p0, p0, Lj$/time/Instant;->b:I

    iget p1, p1, Lj$/time/Instant;->b:I

    sub-int/2addr p0, p1

    return p0
.end method

.method public final d(Lj$/time/temporal/o;)I
    .registers 5

    .prologue
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_40

    sget-object v0, Lj$/time/f;->a:[I

    move-object v1, p1

    check-cast v1, Lj$/time/temporal/a;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget v0, v0, v1

    const/4 v1, 0x1

    if-eq v0, v1, :cond_3d

    const/4 v1, 0x2

    if-eq v0, v1, :cond_38

    const/4 v1, 0x3

    if-eq v0, v1, :cond_31

    const/4 v1, 0x4

    if-eq v0, v1, :cond_1c

    goto :goto_25

    :cond_1c
    sget-object v0, Lj$/time/temporal/a;->INSTANT_SECONDS:Lj$/time/temporal/a;

    iget-wide v1, p0, Lj$/time/Instant;->a:J

    iget-object p0, v0, Lj$/time/temporal/a;->b:Lj$/time/temporal/r;

    invoke-virtual {p0, v1, v2, v0}, Lj$/time/temporal/r;->a(JLj$/time/temporal/o;)I

    :goto_25
    new-instance p0, Lj$/time/temporal/q;

    const-string v0, "Unsupported field: "

    invoke-static {v0, p1}, Lj$/time/d;->a(Ljava/lang/String;Lj$/time/temporal/o;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_31
    iget p0, p0, Lj$/time/Instant;->b:I

    const p1, 0xf4240

    div-int/2addr p0, p1

    return p0

    :cond_38
    iget p0, p0, Lj$/time/Instant;->b:I

    div-int/lit16 p0, p0, 0x3e8

    return p0

    :cond_3d
    iget p0, p0, Lj$/time/Instant;->b:I

    return p0

    :cond_40
    invoke-super {p0, p1}, Lj$/time/temporal/l;->i(Lj$/time/temporal/o;)Lj$/time/temporal/r;

    move-result-object v0

    invoke-interface {p1, p0}, Lj$/time/temporal/o;->E(Lj$/time/temporal/l;)J

    move-result-wide v1

    invoke-virtual {v0, v1, v2, p1}, Lj$/time/temporal/r;->a(JLj$/time/temporal/o;)I

    move-result p0

    return p0
.end method

.method public final e(Lj$/time/temporal/o;)Z
    .registers 3

    .prologue
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_15

    sget-object p0, Lj$/time/temporal/a;->INSTANT_SECONDS:Lj$/time/temporal/a;

    if-eq p1, p0, :cond_1d

    sget-object p0, Lj$/time/temporal/a;->NANO_OF_SECOND:Lj$/time/temporal/a;

    if-eq p1, p0, :cond_1d

    sget-object p0, Lj$/time/temporal/a;->MICRO_OF_SECOND:Lj$/time/temporal/a;

    if-eq p1, p0, :cond_1d

    sget-object p0, Lj$/time/temporal/a;->MILLI_OF_SECOND:Lj$/time/temporal/a;

    if-ne p1, p0, :cond_1f

    goto :goto_1d

    :cond_15
    if-eqz p1, :cond_1f

    invoke-interface {p1, p0}, Lj$/time/temporal/o;->n(Lj$/time/temporal/l;)Z

    move-result p0

    if-eqz p0, :cond_1f

    :cond_1d
    :goto_1d
    const/4 p0, 0x1

    return p0

    :cond_1f
    const/4 p0, 0x0

    return p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 9

    .prologue
    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lj$/time/Instant;

    const/4 v2, 0x0

    if-eqz v1, :cond_1a

    check-cast p1, Lj$/time/Instant;

    iget-wide v3, p0, Lj$/time/Instant;->a:J

    iget-wide v5, p1, Lj$/time/Instant;->a:J

    cmp-long v1, v3, v5

    if-nez v1, :cond_1a

    iget p0, p0, Lj$/time/Instant;->b:I

    iget p1, p1, Lj$/time/Instant;->b:I

    if-ne p0, p1, :cond_1a

    return v0

    :cond_1a
    return v2
.end method

.method public final f(Lj$/time/temporal/o;)J
    .registers 4

    .prologue
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_3a

    sget-object v0, Lj$/time/f;->a:[I

    move-object v1, p1

    check-cast v1, Lj$/time/temporal/a;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget v0, v0, v1

    const/4 v1, 0x1

    if-eq v0, v1, :cond_37

    const/4 v1, 0x2

    if-eq v0, v1, :cond_32

    const/4 v1, 0x3

    if-eq v0, v1, :cond_2a

    const/4 v1, 0x4

    if-ne v0, v1, :cond_1e

    iget-wide p0, p0, Lj$/time/Instant;->a:J

    return-wide p0

    :cond_1e
    new-instance p0, Lj$/time/temporal/q;

    const-string v0, "Unsupported field: "

    invoke-static {v0, p1}, Lj$/time/d;->a(Ljava/lang/String;Lj$/time/temporal/o;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_2a
    iget p0, p0, Lj$/time/Instant;->b:I

    const p1, 0xf4240

    div-int/2addr p0, p1

    :goto_30
    int-to-long p0, p0

    return-wide p0

    :cond_32
    iget p0, p0, Lj$/time/Instant;->b:I

    div-int/lit16 p0, p0, 0x3e8

    goto :goto_30

    :cond_37
    iget p0, p0, Lj$/time/Instant;->b:I

    goto :goto_30

    :cond_3a
    invoke-interface {p1, p0}, Lj$/time/temporal/o;->E(Lj$/time/temporal/l;)J

    move-result-wide p0

    return-wide p0
.end method

.method public final g(JLj$/time/temporal/o;)Lj$/time/temporal/Temporal;
    .registers 6

    .prologue
    instance-of v0, p3, Lj$/time/temporal/a;

    if-eqz v0, :cond_64

    move-object v0, p3

    check-cast v0, Lj$/time/temporal/a;

    invoke-virtual {v0, p1, p2}, Lj$/time/temporal/a;->I(J)V

    sget-object v1, Lj$/time/f;->a:[I

    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    aget v0, v1, v0

    const/4 v1, 0x1

    if-eq v0, v1, :cond_55

    const/4 v1, 0x2

    if-eq v0, v1, :cond_47

    const/4 v1, 0x3

    if-eq v0, v1, :cond_37

    const/4 v1, 0x4

    if-ne v0, v1, :cond_2b

    iget-wide v0, p0, Lj$/time/Instant;->a:J

    cmp-long p3, p1, v0

    if-eqz p3, :cond_63

    iget p0, p0, Lj$/time/Instant;->b:I

    invoke-static {p1, p2, p0}, Lj$/time/Instant;->n(JI)Lj$/time/Instant;

    move-result-object p0

    return-object p0

    :cond_2b
    new-instance p0, Lj$/time/temporal/q;

    const-string p1, "Unsupported field: "

    invoke-static {p1, p3}, Lj$/time/d;->a(Ljava/lang/String;Lj$/time/temporal/o;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_37
    long-to-int p1, p1

    const p2, 0xf4240

    mul-int/2addr p1, p2

    iget p2, p0, Lj$/time/Instant;->b:I

    if-eq p1, p2, :cond_63

    iget-wide p2, p0, Lj$/time/Instant;->a:J

    invoke-static {p2, p3, p1}, Lj$/time/Instant;->n(JI)Lj$/time/Instant;

    move-result-object p0

    return-object p0

    :cond_47
    long-to-int p1, p1

    mul-int/lit16 p1, p1, 0x3e8

    iget p2, p0, Lj$/time/Instant;->b:I

    if-eq p1, p2, :cond_63

    iget-wide p2, p0, Lj$/time/Instant;->a:J

    invoke-static {p2, p3, p1}, Lj$/time/Instant;->n(JI)Lj$/time/Instant;

    move-result-object p0

    return-object p0

    :cond_55
    iget p3, p0, Lj$/time/Instant;->b:I

    int-to-long v0, p3

    cmp-long p3, p1, v0

    if-eqz p3, :cond_63

    iget-wide v0, p0, Lj$/time/Instant;->a:J

    long-to-int p0, p1

    invoke-static {v0, v1, p0}, Lj$/time/Instant;->n(JI)Lj$/time/Instant;

    move-result-object p0

    :cond_63
    return-object p0

    :cond_64
    invoke-interface {p3, p0, p1, p2}, Lj$/time/temporal/o;->H(Lj$/time/temporal/Temporal;J)Lj$/time/temporal/Temporal;

    move-result-object p0

    check-cast p0, Lj$/time/Instant;

    return-object p0
.end method

.method public getEpochSecond()J
    .registers 3

    iget-wide v0, p0, Lj$/time/Instant;->a:J

    return-wide v0
.end method

.method public getNano()I
    .registers 1

    iget p0, p0, Lj$/time/Instant;->b:I

    return p0
.end method

.method public final h(Lj$/time/LocalDate;)Lj$/time/temporal/Temporal;
    .registers 2

    invoke-interface {p1, p0}, Lj$/time/chrono/b;->c(Lj$/time/temporal/Temporal;)Lj$/time/temporal/Temporal;

    move-result-object p0

    check-cast p0, Lj$/time/Instant;

    return-object p0
.end method

.method public final hashCode()I
    .registers 5

    iget-wide v0, p0, Lj$/time/Instant;->a:J

    const/16 v2, 0x20

    ushr-long v2, v0, v2

    xor-long/2addr v0, v2

    long-to-int v0, v0

    iget p0, p0, Lj$/time/Instant;->b:I

    mul-int/lit8 p0, p0, 0x33

    add-int/2addr p0, v0

    return p0
.end method

.method public final bridge synthetic j(JLj$/time/temporal/TemporalUnit;)Lj$/time/temporal/Temporal;
    .registers 4

    invoke-virtual {p0, p1, p2, p3}, Lj$/time/Instant;->H(JLj$/time/temporal/TemporalUnit;)Lj$/time/Instant;

    move-result-object p0

    return-object p0
.end method

.method public final k(Lj$/time/temporal/Temporal;Lj$/time/temporal/TemporalUnit;)J
    .registers 10

    .prologue
    invoke-static {p1}, Lj$/time/Instant;->v(Lj$/time/temporal/Temporal;)Lj$/time/Instant;

    move-result-object p1

    instance-of v0, p2, Lj$/time/temporal/ChronoUnit;

    if-eqz v0, :cond_86

    move-object v0, p2

    check-cast v0, Lj$/time/temporal/ChronoUnit;

    sget-object v1, Lj$/time/f;->b:[I

    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    aget v0, v1, v0

    const-wide/32 v1, 0x3b9aca00

    packed-switch v0, :pswitch_data_8c

    const-string p0, "Unsupported unit: "

    invoke-static {p0, p2}, Lj$/time/h;->c(Ljava/lang/String;Ljava/lang/Object;)V

    const-wide/16 p0, 0x0

    return-wide p0

    :pswitch_21  #0x8
    invoke-virtual {p0, p1}, Lj$/time/Instant;->I(Lj$/time/Instant;)J

    move-result-wide p0

    const-wide/32 v0, 0x15180

    div-long/2addr p0, v0

    return-wide p0

    :pswitch_2a  #0x7
    invoke-virtual {p0, p1}, Lj$/time/Instant;->I(Lj$/time/Instant;)J

    move-result-wide p0

    const-wide/32 v0, 0xa8c0

    div-long/2addr p0, v0

    return-wide p0

    :pswitch_33  #0x6
    invoke-virtual {p0, p1}, Lj$/time/Instant;->I(Lj$/time/Instant;)J

    move-result-wide p0

    const-wide/16 v0, 0xe10

    div-long/2addr p0, v0

    return-wide p0

    :pswitch_3b  #0x5
    invoke-virtual {p0, p1}, Lj$/time/Instant;->I(Lj$/time/Instant;)J

    move-result-wide p0

    const-wide/16 v0, 0x3c

    div-long/2addr p0, v0

    return-wide p0

    :pswitch_43  #0x4
    invoke-virtual {p0, p1}, Lj$/time/Instant;->I(Lj$/time/Instant;)J

    move-result-wide p0

    return-wide p0

    :pswitch_48  #0x3
    invoke-virtual {p1}, Lj$/time/Instant;->J()J

    move-result-wide p1

    invoke-virtual {p0}, Lj$/time/Instant;->J()J

    move-result-wide v0

    invoke-static {p1, p2, v0, v1}, Ljava/lang/Math;->subtractExact(JJ)J

    move-result-wide p0

    return-wide p0

    :pswitch_55  #0x2
    iget-wide v3, p1, Lj$/time/Instant;->a:J

    iget-wide v5, p0, Lj$/time/Instant;->a:J

    invoke-static {v3, v4, v5, v6}, Ljava/lang/Math;->subtractExact(JJ)J

    move-result-wide v3

    invoke-static {v3, v4, v1, v2}, Ljava/lang/Math;->multiplyExact(JJ)J

    move-result-wide v0

    iget p1, p1, Lj$/time/Instant;->b:I

    iget p0, p0, Lj$/time/Instant;->b:I

    sub-int/2addr p1, p0

    int-to-long p0, p1

    invoke-static {v0, v1, p0, p1}, Ljava/lang/Math;->addExact(JJ)J

    move-result-wide p0

    const-wide/16 v0, 0x3e8

    div-long/2addr p0, v0

    return-wide p0

    :pswitch_6f  #0x1
    iget-wide v3, p1, Lj$/time/Instant;->a:J

    iget-wide v5, p0, Lj$/time/Instant;->a:J

    invoke-static {v3, v4, v5, v6}, Ljava/lang/Math;->subtractExact(JJ)J

    move-result-wide v3

    invoke-static {v3, v4, v1, v2}, Ljava/lang/Math;->multiplyExact(JJ)J

    move-result-wide v0

    iget p1, p1, Lj$/time/Instant;->b:I

    iget p0, p0, Lj$/time/Instant;->b:I

    sub-int/2addr p1, p0

    int-to-long p0, p1

    invoke-static {v0, v1, p0, p1}, Ljava/lang/Math;->addExact(JJ)J

    move-result-wide p0

    return-wide p0

    :cond_86
    invoke-interface {p2, p0, p1}, Lj$/time/temporal/TemporalUnit;->n(Lj$/time/temporal/Temporal;Lj$/time/temporal/Temporal;)J

    move-result-wide p0

    return-wide p0

    nop

    :pswitch_data_8c
    .packed-switch 0x1
        :pswitch_6f  #00000001
        :pswitch_55  #00000002
        :pswitch_48  #00000003
        :pswitch_43  #00000004
        :pswitch_3b  #00000005
        :pswitch_33  #00000006
        :pswitch_2a  #00000007
        :pswitch_21  #00000008
    .end packed-switch
.end method

.method public final toString()Ljava/lang/String;
    .registers 2

    sget-object v0, Lj$/time/format/DateTimeFormatter;->d:Lj$/time/format/DateTimeFormatter;

    invoke-virtual {v0, p0}, Lj$/time/format/DateTimeFormatter;->a(Lj$/time/temporal/l;)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
