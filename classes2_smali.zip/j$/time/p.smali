.class public final Lj$/time/p;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ljava/io/Externalizable;


# static fields
.field private static final serialVersionUID:J = -0x6aa27b45e4ddb74eL


# instance fields
.field public a:B

.field public b:Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(BLjava/lang/Object;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-byte p1, p0, Lj$/time/p;->a:B

    iput-object p2, p0, Lj$/time/p;->b:Ljava/lang/Object;

    return-void
.end method

.method public static a(BLjava/io/ObjectInput;)Ljava/lang/Object;
    .registers 4

    .prologue
    packed-switch p0, :pswitch_data_134

    new-instance p0, Ljava/io/StreamCorruptedException;

    const-string p1, "Unknown serialized type"

    invoke-direct {p0, p1}, Ljava/io/StreamCorruptedException;-><init>(Ljava/lang/String;)V

    throw p0

    :pswitch_b  #0xe
    sget-object p0, Lj$/time/Period;->d:Lj$/time/Period;

    invoke-interface {p1}, Ljava/io/DataInput;->readInt()I

    move-result p0

    invoke-interface {p1}, Ljava/io/DataInput;->readInt()I

    move-result v0

    invoke-interface {p1}, Ljava/io/DataInput;->readInt()I

    move-result p1

    invoke-static {p0, v0, p1}, Lj$/time/Period;->of(III)Lj$/time/Period;

    move-result-object p0

    return-object p0

    :pswitch_1e  #0xd
    sget p0, Lj$/time/MonthDay;->c:I

    invoke-interface {p1}, Ljava/io/DataInput;->readByte()B

    move-result p0

    invoke-interface {p1}, Ljava/io/DataInput;->readByte()B

    move-result p1

    invoke-static {p0, p1}, Lj$/time/MonthDay;->of(II)Lj$/time/MonthDay;

    move-result-object p0

    return-object p0

    :pswitch_2d  #0xc
    sget p0, Lj$/time/YearMonth;->c:I

    invoke-interface {p1}, Ljava/io/DataInput;->readInt()I

    move-result p0

    invoke-interface {p1}, Ljava/io/DataInput;->readByte()B

    move-result p1

    invoke-static {p0, p1}, Lj$/time/YearMonth;->of(II)Lj$/time/YearMonth;

    move-result-object p0

    return-object p0

    :pswitch_3c  #0xb
    sget p0, Lj$/time/Year;->b:I

    invoke-interface {p1}, Ljava/io/DataInput;->readInt()I

    move-result p0

    invoke-static {p0}, Lj$/time/Year;->of(I)Lj$/time/Year;

    move-result-object p0

    return-object p0

    :pswitch_47  #0xa
    sget p0, Lj$/time/OffsetDateTime;->c:I

    sget-object p0, Lj$/time/LocalDate;->d:Lj$/time/LocalDate;

    invoke-interface {p1}, Ljava/io/DataInput;->readInt()I

    move-result p0

    invoke-interface {p1}, Ljava/io/DataInput;->readByte()B

    move-result v0

    invoke-interface {p1}, Ljava/io/DataInput;->readByte()B

    move-result v1

    invoke-static {p0, v0, v1}, Lj$/time/LocalDate;->of(III)Lj$/time/LocalDate;

    move-result-object p0

    invoke-static {p1}, Lj$/time/LocalTime;->O(Ljava/io/DataInput;)Lj$/time/LocalTime;

    move-result-object v0

    invoke-static {p0, v0}, Lj$/time/LocalDateTime;->of(Lj$/time/LocalDate;Lj$/time/LocalTime;)Lj$/time/LocalDateTime;

    move-result-object p0

    invoke-static {p1}, Lj$/time/ZoneOffset;->O(Ljava/io/DataInput;)Lj$/time/ZoneOffset;

    move-result-object p1

    invoke-static {p0, p1}, Lj$/time/OffsetDateTime;->of(Lj$/time/LocalDateTime;Lj$/time/ZoneOffset;)Lj$/time/OffsetDateTime;

    move-result-object p0

    return-object p0

    :pswitch_6c  #0x9
    sget p0, Lj$/time/OffsetTime;->c:I

    invoke-static {p1}, Lj$/time/LocalTime;->O(Ljava/io/DataInput;)Lj$/time/LocalTime;

    move-result-object p0

    invoke-static {p1}, Lj$/time/ZoneOffset;->O(Ljava/io/DataInput;)Lj$/time/ZoneOffset;

    move-result-object p1

    invoke-static {p0, p1}, Lj$/time/OffsetTime;->of(Lj$/time/LocalTime;Lj$/time/ZoneOffset;)Lj$/time/OffsetTime;

    move-result-object p0

    return-object p0

    :pswitch_7b  #0x8
    invoke-static {p1}, Lj$/time/ZoneOffset;->O(Ljava/io/DataInput;)Lj$/time/ZoneOffset;

    move-result-object p0

    return-object p0

    :pswitch_80  #0x7
    sget p0, Lj$/time/s;->d:I

    invoke-interface {p1}, Ljava/io/DataInput;->readUTF()Ljava/lang/String;

    move-result-object p0

    const/4 p1, 0x0

    invoke-static {p0, p1}, Lj$/time/ZoneId;->E(Ljava/lang/String;Z)Lj$/time/ZoneId;

    move-result-object p0

    return-object p0

    :pswitch_8c  #0x6
    sget-object p0, Lj$/time/LocalDateTime;->c:Lj$/time/LocalDateTime;

    sget-object p0, Lj$/time/LocalDate;->d:Lj$/time/LocalDate;

    invoke-interface {p1}, Ljava/io/DataInput;->readInt()I

    move-result p0

    invoke-interface {p1}, Ljava/io/DataInput;->readByte()B

    move-result v0

    invoke-interface {p1}, Ljava/io/DataInput;->readByte()B

    move-result v1

    invoke-static {p0, v0, v1}, Lj$/time/LocalDate;->of(III)Lj$/time/LocalDate;

    move-result-object p0

    invoke-static {p1}, Lj$/time/LocalTime;->O(Ljava/io/DataInput;)Lj$/time/LocalTime;

    move-result-object v0

    invoke-static {p0, v0}, Lj$/time/LocalDateTime;->of(Lj$/time/LocalDate;Lj$/time/LocalTime;)Lj$/time/LocalDateTime;

    move-result-object p0

    invoke-static {p1}, Lj$/time/ZoneOffset;->O(Ljava/io/DataInput;)Lj$/time/ZoneOffset;

    move-result-object v0

    invoke-interface {p1}, Ljava/io/ObjectInput;->readByte()B

    move-result v1

    invoke-static {v1, p1}, Lj$/time/p;->a(BLjava/io/ObjectInput;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lj$/time/ZoneId;

    const-string v1, "localDateTime"

    invoke-static {p0, v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    const-string v1, "offset"

    invoke-static {v0, v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    const-string v1, "zone"

    invoke-static {p1, v1}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    instance-of v1, p1, Lj$/time/ZoneOffset;

    if-eqz v1, :cond_d8

    invoke-virtual {v0, p1}, Lj$/time/ZoneOffset;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_d0

    goto :goto_d8

    :cond_d0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "ZoneId must match ZoneOffset"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_d8
    :goto_d8
    new-instance v1, Lj$/time/ZonedDateTime;

    invoke-direct {v1, p0, v0, p1}, Lj$/time/ZonedDateTime;-><init>(Lj$/time/LocalDateTime;Lj$/time/ZoneOffset;Lj$/time/ZoneId;)V

    return-object v1

    :pswitch_de  #0x5
    sget-object p0, Lj$/time/LocalDateTime;->c:Lj$/time/LocalDateTime;

    sget-object p0, Lj$/time/LocalDate;->d:Lj$/time/LocalDate;

    invoke-interface {p1}, Ljava/io/DataInput;->readInt()I

    move-result p0

    invoke-interface {p1}, Ljava/io/DataInput;->readByte()B

    move-result v0

    invoke-interface {p1}, Ljava/io/DataInput;->readByte()B

    move-result v1

    invoke-static {p0, v0, v1}, Lj$/time/LocalDate;->of(III)Lj$/time/LocalDate;

    move-result-object p0

    invoke-static {p1}, Lj$/time/LocalTime;->O(Ljava/io/DataInput;)Lj$/time/LocalTime;

    move-result-object p1

    invoke-static {p0, p1}, Lj$/time/LocalDateTime;->of(Lj$/time/LocalDate;Lj$/time/LocalTime;)Lj$/time/LocalDateTime;

    move-result-object p0

    return-object p0

    :pswitch_fb  #0x4
    invoke-static {p1}, Lj$/time/LocalTime;->O(Ljava/io/DataInput;)Lj$/time/LocalTime;

    move-result-object p0

    return-object p0

    :pswitch_100  #0x3
    sget-object p0, Lj$/time/LocalDate;->d:Lj$/time/LocalDate;

    invoke-interface {p1}, Ljava/io/DataInput;->readInt()I

    move-result p0

    invoke-interface {p1}, Ljava/io/DataInput;->readByte()B

    move-result v0

    invoke-interface {p1}, Ljava/io/DataInput;->readByte()B

    move-result p1

    invoke-static {p0, v0, p1}, Lj$/time/LocalDate;->of(III)Lj$/time/LocalDate;

    move-result-object p0

    return-object p0

    :pswitch_113  #0x2
    sget-object p0, Lj$/time/Instant;->c:Lj$/time/Instant;

    invoke-interface {p1}, Ljava/io/DataInput;->readLong()J

    move-result-wide v0

    invoke-interface {p1}, Ljava/io/DataInput;->readInt()I

    move-result p0

    int-to-long p0, p0

    invoke-static {v0, v1, p0, p1}, Lj$/time/Instant;->ofEpochSecond(JJ)Lj$/time/Instant;

    move-result-object p0

    return-object p0

    :pswitch_123  #0x1
    sget-object p0, Lj$/time/Duration;->c:Lj$/time/Duration;

    invoke-interface {p1}, Ljava/io/DataInput;->readLong()J

    move-result-wide v0

    invoke-interface {p1}, Ljava/io/DataInput;->readInt()I

    move-result p0

    int-to-long p0, p0

    invoke-static {v0, v1, p0, p1}, Lj$/time/Duration;->ofSeconds(JJ)Lj$/time/Duration;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_134
    .packed-switch 0x1
        :pswitch_123  #00000001
        :pswitch_113  #00000002
        :pswitch_100  #00000003
        :pswitch_fb  #00000004
        :pswitch_de  #00000005
        :pswitch_8c  #00000006
        :pswitch_80  #00000007
        :pswitch_7b  #00000008
        :pswitch_6c  #00000009
        :pswitch_47  #0000000a
        :pswitch_3c  #0000000b
        :pswitch_2d  #0000000c
        :pswitch_1e  #0000000d
        :pswitch_b  #0000000e
    .end packed-switch
.end method

.method private readResolve()Ljava/lang/Object;
    .registers 1

    iget-object p0, p0, Lj$/time/p;->b:Ljava/lang/Object;

    return-object p0
.end method


# virtual methods
.method public final readExternal(Ljava/io/ObjectInput;)V
    .registers 3

    invoke-interface {p1}, Ljava/io/ObjectInput;->readByte()B

    move-result v0

    iput-byte v0, p0, Lj$/time/p;->a:B

    invoke-static {v0, p1}, Lj$/time/p;->a(BLjava/io/ObjectInput;)Ljava/lang/Object;

    move-result-object p1

    iput-object p1, p0, Lj$/time/p;->b:Ljava/lang/Object;

    return-void
.end method

.method public final writeExternal(Ljava/io/ObjectOutput;)V
    .registers 5

    .prologue
    iget-byte v0, p0, Lj$/time/p;->a:B

    iget-object p0, p0, Lj$/time/p;->b:Ljava/lang/Object;

    invoke-interface {p1, v0}, Ljava/io/ObjectOutput;->writeByte(I)V

    packed-switch v0, :pswitch_data_f2

    new-instance p0, Ljava/io/InvalidClassException;

    const-string p1, "Unknown serialized type"

    invoke-direct {p0, p1}, Ljava/io/InvalidClassException;-><init>(Ljava/lang/String;)V

    throw p0

    :pswitch_12  #0xe
    check-cast p0, Lj$/time/Period;

    iget v0, p0, Lj$/time/Period;->a:I

    invoke-interface {p1, v0}, Ljava/io/DataOutput;->writeInt(I)V

    iget v0, p0, Lj$/time/Period;->b:I

    invoke-interface {p1, v0}, Ljava/io/DataOutput;->writeInt(I)V

    iget p0, p0, Lj$/time/Period;->c:I

    invoke-interface {p1, p0}, Ljava/io/DataOutput;->writeInt(I)V

    return-void

    :pswitch_24  #0xd
    check-cast p0, Lj$/time/MonthDay;

    iget v0, p0, Lj$/time/MonthDay;->a:I

    invoke-interface {p1, v0}, Ljava/io/DataOutput;->writeByte(I)V

    iget p0, p0, Lj$/time/MonthDay;->b:I

    invoke-interface {p1, p0}, Ljava/io/DataOutput;->writeByte(I)V

    return-void

    :pswitch_31  #0xc
    check-cast p0, Lj$/time/YearMonth;

    iget v0, p0, Lj$/time/YearMonth;->a:I

    invoke-interface {p1, v0}, Ljava/io/DataOutput;->writeInt(I)V

    iget p0, p0, Lj$/time/YearMonth;->b:I

    invoke-interface {p1, p0}, Ljava/io/DataOutput;->writeByte(I)V

    return-void

    :pswitch_3e  #0xb
    check-cast p0, Lj$/time/Year;

    iget p0, p0, Lj$/time/Year;->a:I

    invoke-interface {p1, p0}, Ljava/io/DataOutput;->writeInt(I)V

    return-void

    :pswitch_46  #0xa
    check-cast p0, Lj$/time/OffsetDateTime;

    iget-object v0, p0, Lj$/time/OffsetDateTime;->a:Lj$/time/LocalDateTime;

    iget-object v1, v0, Lj$/time/LocalDateTime;->a:Lj$/time/LocalDate;

    iget v2, v1, Lj$/time/LocalDate;->a:I

    invoke-interface {p1, v2}, Ljava/io/DataOutput;->writeInt(I)V

    iget-short v2, v1, Lj$/time/LocalDate;->b:S

    invoke-interface {p1, v2}, Ljava/io/DataOutput;->writeByte(I)V

    iget-short v1, v1, Lj$/time/LocalDate;->c:S

    invoke-interface {p1, v1}, Ljava/io/DataOutput;->writeByte(I)V

    iget-object v0, v0, Lj$/time/LocalDateTime;->b:Lj$/time/LocalTime;

    invoke-virtual {v0, p1}, Lj$/time/LocalTime;->T(Ljava/io/DataOutput;)V

    iget-object p0, p0, Lj$/time/OffsetDateTime;->b:Lj$/time/ZoneOffset;

    invoke-virtual {p0, p1}, Lj$/time/ZoneOffset;->P(Ljava/io/DataOutput;)V

    return-void

    :pswitch_66  #0x9
    check-cast p0, Lj$/time/OffsetTime;

    iget-object v0, p0, Lj$/time/OffsetTime;->a:Lj$/time/LocalTime;

    invoke-virtual {v0, p1}, Lj$/time/LocalTime;->T(Ljava/io/DataOutput;)V

    iget-object p0, p0, Lj$/time/OffsetTime;->b:Lj$/time/ZoneOffset;

    invoke-virtual {p0, p1}, Lj$/time/ZoneOffset;->P(Ljava/io/DataOutput;)V

    return-void

    :pswitch_73  #0x8
    check-cast p0, Lj$/time/ZoneOffset;

    invoke-virtual {p0, p1}, Lj$/time/ZoneOffset;->P(Ljava/io/DataOutput;)V

    return-void

    :pswitch_79  #0x7
    check-cast p0, Lj$/time/s;

    iget-object p0, p0, Lj$/time/s;->b:Ljava/lang/String;

    invoke-interface {p1, p0}, Ljava/io/DataOutput;->writeUTF(Ljava/lang/String;)V

    return-void

    :pswitch_81  #0x6
    check-cast p0, Lj$/time/ZonedDateTime;

    iget-object v0, p0, Lj$/time/ZonedDateTime;->a:Lj$/time/LocalDateTime;

    iget-object v1, v0, Lj$/time/LocalDateTime;->a:Lj$/time/LocalDate;

    iget v2, v1, Lj$/time/LocalDate;->a:I

    invoke-interface {p1, v2}, Ljava/io/DataOutput;->writeInt(I)V

    iget-short v2, v1, Lj$/time/LocalDate;->b:S

    invoke-interface {p1, v2}, Ljava/io/DataOutput;->writeByte(I)V

    iget-short v1, v1, Lj$/time/LocalDate;->c:S

    invoke-interface {p1, v1}, Ljava/io/DataOutput;->writeByte(I)V

    iget-object v0, v0, Lj$/time/LocalDateTime;->b:Lj$/time/LocalTime;

    invoke-virtual {v0, p1}, Lj$/time/LocalTime;->T(Ljava/io/DataOutput;)V

    iget-object v0, p0, Lj$/time/ZonedDateTime;->b:Lj$/time/ZoneOffset;

    invoke-virtual {v0, p1}, Lj$/time/ZoneOffset;->P(Ljava/io/DataOutput;)V

    iget-object p0, p0, Lj$/time/ZonedDateTime;->c:Lj$/time/ZoneId;

    invoke-virtual {p0, p1}, Lj$/time/ZoneId;->J(Ljava/io/DataOutput;)V

    return-void

    :pswitch_a6  #0x5
    check-cast p0, Lj$/time/LocalDateTime;

    iget-object v0, p0, Lj$/time/LocalDateTime;->a:Lj$/time/LocalDate;

    iget v1, v0, Lj$/time/LocalDate;->a:I

    invoke-interface {p1, v1}, Ljava/io/DataOutput;->writeInt(I)V

    iget-short v1, v0, Lj$/time/LocalDate;->b:S

    invoke-interface {p1, v1}, Ljava/io/DataOutput;->writeByte(I)V

    iget-short v0, v0, Lj$/time/LocalDate;->c:S

    invoke-interface {p1, v0}, Ljava/io/DataOutput;->writeByte(I)V

    iget-object p0, p0, Lj$/time/LocalDateTime;->b:Lj$/time/LocalTime;

    invoke-virtual {p0, p1}, Lj$/time/LocalTime;->T(Ljava/io/DataOutput;)V

    return-void

    :pswitch_bf  #0x4
    check-cast p0, Lj$/time/LocalTime;

    invoke-virtual {p0, p1}, Lj$/time/LocalTime;->T(Ljava/io/DataOutput;)V

    return-void

    :pswitch_c5  #0x3
    check-cast p0, Lj$/time/LocalDate;

    iget v0, p0, Lj$/time/LocalDate;->a:I

    invoke-interface {p1, v0}, Ljava/io/DataOutput;->writeInt(I)V

    iget-short v0, p0, Lj$/time/LocalDate;->b:S

    invoke-interface {p1, v0}, Ljava/io/DataOutput;->writeByte(I)V

    iget-short p0, p0, Lj$/time/LocalDate;->c:S

    invoke-interface {p1, p0}, Ljava/io/DataOutput;->writeByte(I)V

    return-void

    :pswitch_d7  #0x2
    check-cast p0, Lj$/time/Instant;

    iget-wide v0, p0, Lj$/time/Instant;->a:J

    invoke-interface {p1, v0, v1}, Ljava/io/DataOutput;->writeLong(J)V

    iget p0, p0, Lj$/time/Instant;->b:I

    invoke-interface {p1, p0}, Ljava/io/DataOutput;->writeInt(I)V

    return-void

    :pswitch_e4  #0x1
    check-cast p0, Lj$/time/Duration;

    iget-wide v0, p0, Lj$/time/Duration;->a:J

    invoke-interface {p1, v0, v1}, Ljava/io/DataOutput;->writeLong(J)V

    iget p0, p0, Lj$/time/Duration;->b:I

    invoke-interface {p1, p0}, Ljava/io/DataOutput;->writeInt(I)V

    return-void

    nop

    :pswitch_data_f2
    .packed-switch 0x1
        :pswitch_e4  #00000001
        :pswitch_d7  #00000002
        :pswitch_c5  #00000003
        :pswitch_bf  #00000004
        :pswitch_a6  #00000005
        :pswitch_81  #00000006
        :pswitch_79  #00000007
        :pswitch_73  #00000008
        :pswitch_66  #00000009
        :pswitch_46  #0000000a
        :pswitch_3e  #0000000b
        :pswitch_31  #0000000c
        :pswitch_24  #0000000d
        :pswitch_12  #0000000e
    .end packed-switch
.end method
