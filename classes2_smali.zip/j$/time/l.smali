.class public final enum Lj$/time/l;
.super Ljava/lang/Enum;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lj$/time/temporal/l;
.implements Lj$/time/temporal/m;


# static fields
.field public static final enum APRIL:Lj$/time/l;

.field public static final enum AUGUST:Lj$/time/l;

.field public static final enum DECEMBER:Lj$/time/l;

.field public static final enum FEBRUARY:Lj$/time/l;

.field public static final enum JANUARY:Lj$/time/l;

.field public static final enum JULY:Lj$/time/l;

.field public static final enum JUNE:Lj$/time/l;

.field public static final enum MARCH:Lj$/time/l;

.field public static final enum MAY:Lj$/time/l;

.field public static final enum NOVEMBER:Lj$/time/l;

.field public static final enum OCTOBER:Lj$/time/l;

.field public static final enum SEPTEMBER:Lj$/time/l;

.field public static final a:[Lj$/time/l;

.field public static final synthetic b:[Lj$/time/l;


# direct methods
.method static constructor <clinit>()V
    .registers 14

    new-instance v0, Lj$/time/l;

    const-string v1, "JANUARY"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lj$/time/l;->JANUARY:Lj$/time/l;

    new-instance v1, Lj$/time/l;

    const-string v2, "FEBRUARY"

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v1, Lj$/time/l;->FEBRUARY:Lj$/time/l;

    new-instance v2, Lj$/time/l;

    const-string v3, "MARCH"

    const/4 v4, 0x2

    invoke-direct {v2, v3, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v2, Lj$/time/l;->MARCH:Lj$/time/l;

    new-instance v3, Lj$/time/l;

    const-string v4, "APRIL"

    const/4 v5, 0x3

    invoke-direct {v3, v4, v5}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v3, Lj$/time/l;->APRIL:Lj$/time/l;

    new-instance v4, Lj$/time/l;

    const-string v5, "MAY"

    const/4 v6, 0x4

    invoke-direct {v4, v5, v6}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v4, Lj$/time/l;->MAY:Lj$/time/l;

    new-instance v5, Lj$/time/l;

    const-string v6, "JUNE"

    const/4 v7, 0x5

    invoke-direct {v5, v6, v7}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v5, Lj$/time/l;->JUNE:Lj$/time/l;

    new-instance v6, Lj$/time/l;

    const-string v7, "JULY"

    const/4 v8, 0x6

    invoke-direct {v6, v7, v8}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v6, Lj$/time/l;->JULY:Lj$/time/l;

    new-instance v7, Lj$/time/l;

    const-string v8, "AUGUST"

    const/4 v9, 0x7

    invoke-direct {v7, v8, v9}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v7, Lj$/time/l;->AUGUST:Lj$/time/l;

    new-instance v8, Lj$/time/l;

    const-string v9, "SEPTEMBER"

    const/16 v10, 0x8

    invoke-direct {v8, v9, v10}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v8, Lj$/time/l;->SEPTEMBER:Lj$/time/l;

    new-instance v9, Lj$/time/l;

    const-string v10, "OCTOBER"

    const/16 v11, 0x9

    invoke-direct {v9, v10, v11}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v9, Lj$/time/l;->OCTOBER:Lj$/time/l;

    new-instance v10, Lj$/time/l;

    const-string v11, "NOVEMBER"

    const/16 v12, 0xa

    invoke-direct {v10, v11, v12}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v10, Lj$/time/l;->NOVEMBER:Lj$/time/l;

    new-instance v11, Lj$/time/l;

    const-string v12, "DECEMBER"

    const/16 v13, 0xb

    invoke-direct {v11, v12, v13}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v11, Lj$/time/l;->DECEMBER:Lj$/time/l;

    filled-new-array/range {v0 .. v11}, [Lj$/time/l;

    move-result-object v0

    sput-object v0, Lj$/time/l;->b:[Lj$/time/l;

    invoke-static {}, Lj$/time/l;->values()[Lj$/time/l;

    move-result-object v0

    sput-object v0, Lj$/time/l;->a:[Lj$/time/l;

    return-void
.end method

.method public static H(I)Lj$/time/l;
    .registers 3

    .prologue
    const/4 v0, 0x1

    if-lt p0, v0, :cond_d

    const/16 v1, 0xc

    if-gt p0, v1, :cond_d

    sget-object v1, Lj$/time/l;->a:[Lj$/time/l;

    sub-int/2addr p0, v0

    aget-object p0, v1, p0

    return-object p0

    :cond_d
    const-string v0, "Invalid value for MonthOfYear: "

    invoke-static {v0, p0}, Lj$/time/h;->a(Ljava/lang/String;I)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lj$/time/l;
    .registers 2

    const-class v0, Lj$/time/l;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lj$/time/l;

    return-object p0
.end method

.method public static values()[Lj$/time/l;
    .registers 1

    sget-object v0, Lj$/time/l;->b:[Lj$/time/l;

    invoke-virtual {v0}, [Lj$/time/l;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lj$/time/l;

    return-object v0
.end method


# virtual methods
.method public final E()I
    .registers 2

    .prologue
    sget-object v0, Lj$/time/k;->a:[I

    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result p0

    aget p0, v0, p0

    const/4 v0, 0x1

    if-eq p0, v0, :cond_1d

    const/4 v0, 0x2

    if-eq p0, v0, :cond_1a

    const/4 v0, 0x3

    if-eq p0, v0, :cond_1a

    const/4 v0, 0x4

    if-eq p0, v0, :cond_1a

    const/4 v0, 0x5

    if-eq p0, v0, :cond_1a

    const/16 p0, 0x1f

    return p0

    :cond_1a
    const/16 p0, 0x1e

    return p0

    :cond_1d
    const/16 p0, 0x1d

    return p0
.end method

.method public final b(Lj$/time/format/a;)Ljava/lang/Object;
    .registers 3

    .prologue
    sget-object v0, Lj$/time/temporal/p;->b:Lj$/time/format/a;

    if-ne p1, v0, :cond_7

    sget-object p0, Lj$/time/chrono/t;->c:Lj$/time/chrono/t;

    return-object p0

    :cond_7
    sget-object v0, Lj$/time/temporal/p;->c:Lj$/time/format/a;

    if-ne p1, v0, :cond_e

    sget-object p0, Lj$/time/temporal/ChronoUnit;->MONTHS:Lj$/time/temporal/ChronoUnit;

    return-object p0

    :cond_e
    invoke-super {p0, p1}, Lj$/time/temporal/l;->b(Lj$/time/format/a;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final c(Lj$/time/temporal/Temporal;)Lj$/time/temporal/Temporal;
    .registers 5

    .prologue
    invoke-static {p1}, Lj$/time/chrono/m;->m(Lj$/time/temporal/l;)Lj$/time/chrono/m;

    move-result-object v0

    sget-object v1, Lj$/time/chrono/t;->c:Lj$/time/chrono/t;

    invoke-interface {v0, v1}, Lj$/time/chrono/m;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_18

    sget-object v0, Lj$/time/temporal/a;->MONTH_OF_YEAR:Lj$/time/temporal/a;

    invoke-virtual {p0}, Lj$/time/l;->getValue()I

    move-result p0

    int-to-long v1, p0

    invoke-interface {p1, v1, v2, v0}, Lj$/time/temporal/Temporal;->g(JLj$/time/temporal/o;)Lj$/time/temporal/Temporal;

    move-result-object p0

    return-object p0

    :cond_18
    new-instance p0, Lj$/time/c;

    const-string p1, "Adjustment only supported on ISO date-time"

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final d(Lj$/time/temporal/o;)I
    .registers 3

    .prologue
    sget-object v0, Lj$/time/temporal/a;->MONTH_OF_YEAR:Lj$/time/temporal/a;

    if-ne p1, v0, :cond_9

    invoke-virtual {p0}, Lj$/time/l;->getValue()I

    move-result p0

    return p0

    :cond_9
    invoke-super {p0, p1}, Lj$/time/temporal/l;->d(Lj$/time/temporal/o;)I

    move-result p0

    return p0
.end method

.method public final e(Lj$/time/temporal/o;)Z
    .registers 3

    .prologue
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_9

    sget-object p0, Lj$/time/temporal/a;->MONTH_OF_YEAR:Lj$/time/temporal/a;

    if-ne p1, p0, :cond_13

    goto :goto_11

    :cond_9
    if-eqz p1, :cond_13

    invoke-interface {p1, p0}, Lj$/time/temporal/o;->n(Lj$/time/temporal/l;)Z

    move-result p0

    if-eqz p0, :cond_13

    :goto_11
    const/4 p0, 0x1

    return p0

    :cond_13
    const/4 p0, 0x0

    return p0
.end method

.method public final f(Lj$/time/temporal/o;)J
    .registers 3

    .prologue
    sget-object v0, Lj$/time/temporal/a;->MONTH_OF_YEAR:Lj$/time/temporal/a;

    if-ne p1, v0, :cond_a

    invoke-virtual {p0}, Lj$/time/l;->getValue()I

    move-result p0

    int-to-long p0, p0

    return-wide p0

    :cond_a
    instance-of v0, p1, Lj$/time/temporal/a;

    if-nez v0, :cond_13

    invoke-interface {p1, p0}, Lj$/time/temporal/o;->E(Lj$/time/temporal/l;)J

    move-result-wide p0

    return-wide p0

    :cond_13
    new-instance p0, Lj$/time/temporal/q;

    const-string v0, "Unsupported field: "

    invoke-static {v0, p1}, Lj$/time/d;->a(Ljava/lang/String;Lj$/time/temporal/o;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final getValue()I
    .registers 1

    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result p0

    add-int/lit8 p0, p0, 0x1

    return p0
.end method

.method public final i(Lj$/time/temporal/o;)Lj$/time/temporal/r;
    .registers 3

    .prologue
    sget-object v0, Lj$/time/temporal/a;->MONTH_OF_YEAR:Lj$/time/temporal/a;

    if-ne p1, v0, :cond_9

    invoke-interface {p1}, Lj$/time/temporal/o;->range()Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_9
    invoke-super {p0, p1}, Lj$/time/temporal/l;->i(Lj$/time/temporal/o;)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0
.end method

.method public final n(Z)I
    .registers 3

    .prologue
    sget-object v0, Lj$/time/k;->a:[I

    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result p0

    aget p0, v0, p0

    packed-switch p0, :pswitch_data_2e

    add-int/lit16 p1, p1, 0x14f

    return p1

    :pswitch_e  #0xb
    add-int/lit16 p1, p1, 0x112

    return p1

    :pswitch_11  #0xa
    add-int/lit16 p1, p1, 0xd5

    return p1

    :pswitch_14  #0x9
    add-int/lit16 p1, p1, 0xb6

    return p1

    :pswitch_17  #0x8
    add-int/lit8 p1, p1, 0x79

    return p1

    :pswitch_1a  #0x7
    add-int/lit8 p1, p1, 0x3c

    return p1

    :pswitch_1d  #0x6
    const/4 p0, 0x1

    return p0

    :pswitch_1f  #0x5
    add-int/lit16 p1, p1, 0x131

    return p1

    :pswitch_22  #0x4
    add-int/lit16 p1, p1, 0xf4

    return p1

    :pswitch_25  #0x3
    add-int/lit16 p1, p1, 0x98

    return p1

    :pswitch_28  #0x2
    add-int/lit8 p1, p1, 0x5b

    return p1

    :pswitch_2b  #0x1
    const/16 p0, 0x20

    return p0

    :pswitch_data_2e
    .packed-switch 0x1
        :pswitch_2b  #00000001
        :pswitch_28  #00000002
        :pswitch_25  #00000003
        :pswitch_22  #00000004
        :pswitch_1f  #00000005
        :pswitch_1d  #00000006
        :pswitch_1a  #00000007
        :pswitch_17  #00000008
        :pswitch_14  #00000009
        :pswitch_11  #0000000a
        :pswitch_e  #0000000b
    .end packed-switch
.end method

.method public final v(Z)I
    .registers 3

    .prologue
    sget-object v0, Lj$/time/k;->a:[I

    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result p0

    aget p0, v0, p0

    const/4 v0, 0x1

    if-eq p0, v0, :cond_1d

    const/4 p1, 0x2

    if-eq p0, p1, :cond_1a

    const/4 p1, 0x3

    if-eq p0, p1, :cond_1a

    const/4 p1, 0x4

    if-eq p0, p1, :cond_1a

    const/4 p1, 0x5

    if-eq p0, p1, :cond_1a

    const/16 p0, 0x1f

    return p0

    :cond_1a
    const/16 p0, 0x1e

    return p0

    :cond_1d
    if-eqz p1, :cond_22

    const/16 p0, 0x1d

    return p0

    :cond_22
    const/16 p0, 0x1c

    return p0
.end method
