.class public abstract Lj$/time/ZoneId;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field public static final a:Ljava/util/Map;

.field private static final serialVersionUID:J = 0x798cab446e6L


# direct methods
.method static constructor <clinit>()V
    .registers 6

    .prologue
    const/16 v0, 0x1c

    new-array v1, v0, [Ljava/util/Map$Entry;

    new-instance v2, Ljava/util/AbstractMap$SimpleImmutableEntry;

    const-string v3, "ACT"

    const-string v4, "Australia/Darwin"

    invoke-direct {v2, v3, v4}, Ljava/util/AbstractMap$SimpleImmutableEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v3, 0x0

    aput-object v2, v1, v3

    new-instance v2, Ljava/util/AbstractMap$SimpleImmutableEntry;

    const-string v4, "AET"

    const-string v5, "Australia/Sydney"

    invoke-direct {v2, v4, v5}, Ljava/util/AbstractMap$SimpleImmutableEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v4, 0x1

    aput-object v2, v1, v4

    new-instance v2, Ljava/util/AbstractMap$SimpleImmutableEntry;

    const-string v4, "AGT"

    const-string v5, "America/Argentina/Buenos_Aires"

    invoke-direct {v2, v4, v5}, Ljava/util/AbstractMap$SimpleImmutableEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v4, 0x2

    aput-object v2, v1, v4

    new-instance v2, Ljava/util/AbstractMap$SimpleImmutableEntry;

    const-string v4, "ART"

    const-string v5, "Africa/Cairo"

    invoke-direct {v2, v4, v5}, Ljava/util/AbstractMap$SimpleImmutableEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v4, 0x3

    aput-object v2, v1, v4

    new-instance v2, Ljava/util/AbstractMap$SimpleImmutableEntry;

    const-string v4, "AST"

    const-string v5, "America/Anchorage"

    invoke-direct {v2, v4, v5}, Ljava/util/AbstractMap$SimpleImmutableEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v4, 0x4

    aput-object v2, v1, v4

    new-instance v2, Ljava/util/AbstractMap$SimpleImmutableEntry;

    const-string v4, "BET"

    const-string v5, "America/Sao_Paulo"

    invoke-direct {v2, v4, v5}, Ljava/util/AbstractMap$SimpleImmutableEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v4, 0x5

    aput-object v2, v1, v4

    new-instance v2, Ljava/util/AbstractMap$SimpleImmutableEntry;

    const-string v4, "BST"

    const-string v5, "Asia/Dhaka"

    invoke-direct {v2, v4, v5}, Ljava/util/AbstractMap$SimpleImmutableEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v4, 0x6

    aput-object v2, v1, v4

    new-instance v2, Ljava/util/AbstractMap$SimpleImmutableEntry;

    const-string v4, "CAT"

    const-string v5, "Africa/Harare"

    invoke-direct {v2, v4, v5}, Ljava/util/AbstractMap$SimpleImmutableEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v4, 0x7

    aput-object v2, v1, v4

    new-instance v2, Ljava/util/AbstractMap$SimpleImmutableEntry;

    const-string v4, "CNT"

    const-string v5, "America/St_Johns"

    invoke-direct {v2, v4, v5}, Ljava/util/AbstractMap$SimpleImmutableEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 v4, 0x8

    aput-object v2, v1, v4

    new-instance v2, Ljava/util/AbstractMap$SimpleImmutableEntry;

    const-string v4, "CST"

    const-string v5, "America/Chicago"

    invoke-direct {v2, v4, v5}, Ljava/util/AbstractMap$SimpleImmutableEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 v4, 0x9

    aput-object v2, v1, v4

    new-instance v2, Ljava/util/AbstractMap$SimpleImmutableEntry;

    const-string v4, "CTT"

    const-string v5, "Asia/Shanghai"

    invoke-direct {v2, v4, v5}, Ljava/util/AbstractMap$SimpleImmutableEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 v4, 0xa

    aput-object v2, v1, v4

    new-instance v2, Ljava/util/AbstractMap$SimpleImmutableEntry;

    const-string v4, "EAT"

    const-string v5, "Africa/Addis_Ababa"

    invoke-direct {v2, v4, v5}, Ljava/util/AbstractMap$SimpleImmutableEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 v4, 0xb

    aput-object v2, v1, v4

    new-instance v2, Ljava/util/AbstractMap$SimpleImmutableEntry;

    const-string v4, "ECT"

    const-string v5, "Europe/Paris"

    invoke-direct {v2, v4, v5}, Ljava/util/AbstractMap$SimpleImmutableEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 v4, 0xc

    aput-object v2, v1, v4

    new-instance v2, Ljava/util/AbstractMap$SimpleImmutableEntry;

    const-string v4, "IET"

    const-string v5, "America/Indiana/Indianapolis"

    invoke-direct {v2, v4, v5}, Ljava/util/AbstractMap$SimpleImmutableEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 v4, 0xd

    aput-object v2, v1, v4

    new-instance v2, Ljava/util/AbstractMap$SimpleImmutableEntry;

    const-string v4, "IST"

    const-string v5, "Asia/Kolkata"

    invoke-direct {v2, v4, v5}, Ljava/util/AbstractMap$SimpleImmutableEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 v4, 0xe

    aput-object v2, v1, v4

    new-instance v2, Ljava/util/AbstractMap$SimpleImmutableEntry;

    const-string v4, "JST"

    const-string v5, "Asia/Tokyo"

    invoke-direct {v2, v4, v5}, Ljava/util/AbstractMap$SimpleImmutableEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 v4, 0xf

    aput-object v2, v1, v4

    new-instance v2, Ljava/util/AbstractMap$SimpleImmutableEntry;

    const-string v4, "MIT"

    const-string v5, "Pacific/Apia"

    invoke-direct {v2, v4, v5}, Ljava/util/AbstractMap$SimpleImmutableEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 v4, 0x10

    aput-object v2, v1, v4

    new-instance v2, Ljava/util/AbstractMap$SimpleImmutableEntry;

    const-string v4, "NET"

    const-string v5, "Asia/Yerevan"

    invoke-direct {v2, v4, v5}, Ljava/util/AbstractMap$SimpleImmutableEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 v4, 0x11

    aput-object v2, v1, v4

    new-instance v2, Ljava/util/AbstractMap$SimpleImmutableEntry;

    const-string v4, "NST"

    const-string v5, "Pacific/Auckland"

    invoke-direct {v2, v4, v5}, Ljava/util/AbstractMap$SimpleImmutableEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 v4, 0x12

    aput-object v2, v1, v4

    new-instance v2, Ljava/util/AbstractMap$SimpleImmutableEntry;

    const-string v4, "PLT"

    const-string v5, "Asia/Karachi"

    invoke-direct {v2, v4, v5}, Ljava/util/AbstractMap$SimpleImmutableEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 v4, 0x13

    aput-object v2, v1, v4

    new-instance v2, Ljava/util/AbstractMap$SimpleImmutableEntry;

    const-string v4, "PNT"

    const-string v5, "America/Phoenix"

    invoke-direct {v2, v4, v5}, Ljava/util/AbstractMap$SimpleImmutableEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 v4, 0x14

    aput-object v2, v1, v4

    new-instance v2, Ljava/util/AbstractMap$SimpleImmutableEntry;

    const-string v4, "PRT"

    const-string v5, "America/Puerto_Rico"

    invoke-direct {v2, v4, v5}, Ljava/util/AbstractMap$SimpleImmutableEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 v4, 0x15

    aput-object v2, v1, v4

    new-instance v2, Ljava/util/AbstractMap$SimpleImmutableEntry;

    const-string v4, "PST"

    const-string v5, "America/Los_Angeles"

    invoke-direct {v2, v4, v5}, Ljava/util/AbstractMap$SimpleImmutableEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 v4, 0x16

    aput-object v2, v1, v4

    new-instance v2, Ljava/util/AbstractMap$SimpleImmutableEntry;

    const-string v4, "SST"

    const-string v5, "Pacific/Guadalcanal"

    invoke-direct {v2, v4, v5}, Ljava/util/AbstractMap$SimpleImmutableEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 v4, 0x17

    aput-object v2, v1, v4

    new-instance v2, Ljava/util/AbstractMap$SimpleImmutableEntry;

    const-string v4, "VST"

    const-string v5, "Asia/Ho_Chi_Minh"

    invoke-direct {v2, v4, v5}, Ljava/util/AbstractMap$SimpleImmutableEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 v4, 0x18

    aput-object v2, v1, v4

    new-instance v2, Ljava/util/AbstractMap$SimpleImmutableEntry;

    const-string v4, "EST"

    const-string v5, "-05:00"

    invoke-direct {v2, v4, v5}, Ljava/util/AbstractMap$SimpleImmutableEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 v4, 0x19

    aput-object v2, v1, v4

    new-instance v2, Ljava/util/AbstractMap$SimpleImmutableEntry;

    const-string v4, "MST"

    const-string v5, "-07:00"

    invoke-direct {v2, v4, v5}, Ljava/util/AbstractMap$SimpleImmutableEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 v4, 0x1a

    aput-object v2, v1, v4

    new-instance v2, Ljava/util/AbstractMap$SimpleImmutableEntry;

    const-string v4, "HST"

    const-string v5, "-10:00"

    invoke-direct {v2, v4, v5}, Ljava/util/AbstractMap$SimpleImmutableEntry;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/16 v4, 0x1b

    aput-object v2, v1, v4

    new-instance v2, Ljava/util/HashMap;

    invoke-direct {v2, v0}, Ljava/util/HashMap;-><init>(I)V

    :goto_16d
    if-ge v3, v0, :cond_19c

    aget-object v4, v1, v3

    invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v5

    invoke-static {v5}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v4

    invoke-static {v4}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v2, v5, v4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    if-nez v4, :cond_188

    add-int/lit8 v3, v3, 0x1

    goto :goto_16d

    :cond_188
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "duplicate key: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_19c
    invoke-static {v2}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v0

    sput-object v0, Lj$/time/ZoneId;->a:Ljava/util/Map;

    return-void
.end method

.method public constructor <init>()V
    .registers 3

    .prologue
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const-class v1, Lj$/time/ZoneOffset;

    if-eq v0, v1, :cond_1c

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    const-class v0, Lj$/time/s;

    if-ne p0, v0, :cond_14

    goto :goto_1c

    :cond_14
    new-instance p0, Ljava/lang/AssertionError;

    const-string v0, "Invalid subclass"

    invoke-direct {p0, v0}, Ljava/lang/AssertionError;-><init>(Ljava/lang/Object;)V

    throw p0

    :cond_1c
    :goto_1c
    return-void
.end method

.method public static E(Ljava/lang/String;Z)Lj$/time/ZoneId;
    .registers 4

    .prologue
    const-string v0, "zoneId"

    invoke-static {p0, v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v1, 0x1

    if-le v0, v1, :cond_47

    const-string v0, "+"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_47

    const-string v0, "-"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_1d

    goto :goto_47

    :cond_1d
    const-string v0, "UTC"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_41

    const-string v0, "GMT"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_2e

    goto :goto_41

    :cond_2e
    const-string v0, "UT"

    invoke-virtual {p0, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_3c

    const/4 v0, 0x2

    invoke-static {p0, v0, p1}, Lj$/time/ZoneId;->I(Ljava/lang/String;IZ)Lj$/time/ZoneId;

    move-result-object p0

    return-object p0

    :cond_3c
    invoke-static {p0, p1}, Lj$/time/s;->K(Ljava/lang/String;Z)Lj$/time/s;

    move-result-object p0

    return-object p0

    :cond_41
    :goto_41
    const/4 v0, 0x3

    invoke-static {p0, v0, p1}, Lj$/time/ZoneId;->I(Ljava/lang/String;IZ)Lj$/time/ZoneId;

    move-result-object p0

    return-object p0

    :cond_47
    :goto_47
    invoke-static {p0}, Lj$/time/ZoneOffset;->L(Ljava/lang/String;)Lj$/time/ZoneOffset;

    move-result-object p0

    return-object p0
.end method

.method public static H(Ljava/lang/String;Lj$/time/ZoneOffset;)Lj$/time/ZoneId;
    .registers 4

    .prologue
    const-string v0, "offset"

    invoke-static {p1, v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    invoke-virtual {p0}, Ljava/lang/String;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_c

    return-object p1

    :cond_c
    const-string v0, "GMT"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_31

    const-string v0, "UTC"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_31

    const-string v0, "UT"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_25

    goto :goto_31

    :cond_25
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "prefix should be GMT, UTC or UT, is: "

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_31
    :goto_31
    invoke-virtual {p1}, Lj$/time/ZoneOffset;->getTotalSeconds()I

    move-result v0

    if-eqz v0, :cond_3d

    iget-object v0, p1, Lj$/time/ZoneOffset;->c:Ljava/lang/String;

    invoke-virtual {p0, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    :cond_3d
    new-instance v0, Lj$/time/s;

    new-instance v1, Lj$/time/zone/f;

    invoke-direct {v1, p1}, Lj$/time/zone/f;-><init>(Lj$/time/ZoneOffset;)V

    invoke-direct {v0, p0, v1}, Lj$/time/s;-><init>(Ljava/lang/String;Lj$/time/zone/f;)V

    return-object v0
.end method

.method public static I(Ljava/lang/String;IZ)Lj$/time/ZoneId;
    .registers 6

    .prologue
    const/4 v0, 0x0

    invoke-virtual {p0, v0, p1}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    if-ne v1, p1, :cond_12

    sget-object p0, Lj$/time/ZoneOffset;->UTC:Lj$/time/ZoneOffset;

    invoke-static {v0, p0}, Lj$/time/ZoneId;->H(Ljava/lang/String;Lj$/time/ZoneOffset;)Lj$/time/ZoneId;

    move-result-object p0

    return-object p0

    :cond_12
    invoke-virtual {p0, p1}, Ljava/lang/String;->charAt(I)C

    move-result v1

    const/16 v2, 0x2b

    if-eq v1, v2, :cond_27

    invoke-virtual {p0, p1}, Ljava/lang/String;->charAt(I)C

    move-result v1

    const/16 v2, 0x2d

    if-eq v1, v2, :cond_27

    invoke-static {p0, p2}, Lj$/time/s;->K(Ljava/lang/String;Z)Lj$/time/s;

    move-result-object p0

    return-object p0

    :cond_27
    :try_start_27
    invoke-virtual {p0, p1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lj$/time/ZoneOffset;->L(Ljava/lang/String;)Lj$/time/ZoneOffset;

    move-result-object p1

    sget-object p2, Lj$/time/ZoneOffset;->UTC:Lj$/time/ZoneOffset;

    if-ne p1, p2, :cond_3a

    invoke-static {v0, p1}, Lj$/time/ZoneId;->H(Ljava/lang/String;Lj$/time/ZoneOffset;)Lj$/time/ZoneId;

    move-result-object p0

    return-object p0

    :catch_38
    move-exception p1

    goto :goto_3f

    :cond_3a
    invoke-static {v0, p1}, Lj$/time/ZoneId;->H(Ljava/lang/String;Lj$/time/ZoneOffset;)Lj$/time/ZoneId;

    move-result-object p0
    :try_end_3e
    .catch Lj$/time/c; {:try_start_27 .. :try_end_3e} :catch_38

    return-object p0

    :goto_3f
    new-instance p2, Lj$/time/c;

    const-string v0, "Invalid ID for offset-based ZoneId: "

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {p2, p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw p2
.end method

.method public static n(Lj$/time/temporal/l;)Lj$/time/ZoneId;
    .registers 3

    .prologue
    sget-object v0, Lj$/time/temporal/p;->e:Lj$/time/format/a;

    invoke-interface {p0, v0}, Lj$/time/temporal/l;->b(Lj$/time/format/a;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lj$/time/ZoneId;

    if-eqz v0, :cond_b

    return-object v0

    :cond_b
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const-string v1, "Unable to obtain ZoneId from TemporalAccessor: "

    invoke-static {v1, p0, v0}, Lj$/time/h;->d(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static of(Ljava/lang/String;)Lj$/time/ZoneId;
    .registers 2

    const/4 v0, 0x1

    invoke-static {p0, v0}, Lj$/time/ZoneId;->E(Ljava/lang/String;Z)Lj$/time/ZoneId;

    move-result-object p0

    return-object p0
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .registers 2

    new-instance p0, Ljava/io/InvalidObjectException;

    const-string p1, "Deserialization via serialization delegate"

    invoke-direct {p0, p1}, Ljava/io/InvalidObjectException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private writeReplace()Ljava/lang/Object;
    .registers 3

    new-instance v0, Lj$/time/p;

    const/4 v1, 0x7

    invoke-direct {v0, v1, p0}, Lj$/time/p;-><init>(BLjava/lang/Object;)V

    return-object v0
.end method


# virtual methods
.method public abstract J(Ljava/io/DataOutput;)V
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 3

    .prologue
    if-ne p0, p1, :cond_4

    const/4 p0, 0x1

    return p0

    :cond_4
    instance-of v0, p1, Lj$/time/ZoneId;

    if-eqz v0, :cond_17

    check-cast p1, Lj$/time/ZoneId;

    invoke-virtual {p0}, Lj$/time/ZoneId;->getId()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p1}, Lj$/time/ZoneId;->getId()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    return p0

    :cond_17
    const/4 p0, 0x0

    return p0
.end method

.method public abstract getId()Ljava/lang/String;
.end method

.method public hashCode()I
    .registers 1

    invoke-virtual {p0}, Lj$/time/ZoneId;->getId()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result p0

    return p0
.end method

.method public toString()Ljava/lang/String;
    .registers 1

    invoke-virtual {p0}, Lj$/time/ZoneId;->getId()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public abstract v()Lj$/time/zone/f;
.end method
