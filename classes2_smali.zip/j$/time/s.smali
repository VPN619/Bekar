.class public final Lj$/time/s;
.super Lj$/time/ZoneId;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final synthetic d:I = 0x0

.field private static final serialVersionUID:J = 0x746262147bb70e18L


# instance fields
.field public final b:Ljava/lang/String;

.field public final transient c:Lj$/time/zone/f;


# direct methods
.method public constructor <init>(Ljava/lang/String;Lj$/time/zone/f;)V
    .registers 3

    invoke-direct {p0}, Lj$/time/ZoneId;-><init>()V

    iput-object p1, p0, Lj$/time/s;->b:Ljava/lang/String;

    iput-object p2, p0, Lj$/time/s;->c:Lj$/time/zone/f;

    return-void
.end method

.method public static K(Ljava/lang/String;Z)Lj$/time/s;
    .registers 7

    .prologue
    const-string v0, "zoneId"

    invoke-static {p0, v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v1, 0x2

    const-string v2, "Invalid ID for region-based ZoneId, invalid format: "

    if-lt v0, v1, :cond_78

    const/4 v1, 0x0

    :goto_f
    if-ge v1, v0, :cond_68

    invoke-virtual {p0, v1}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const/16 v4, 0x61

    if-lt v3, v4, :cond_1e

    const/16 v4, 0x7a

    if-gt v3, v4, :cond_1e

    goto :goto_5b

    :cond_1e
    const/16 v4, 0x41

    if-lt v3, v4, :cond_27

    const/16 v4, 0x5a

    if-gt v3, v4, :cond_27

    goto :goto_5b

    :cond_27
    const/16 v4, 0x2f

    if-ne v3, v4, :cond_2e

    if-eqz v1, :cond_2e

    goto :goto_5b

    :cond_2e
    const/16 v4, 0x30

    if-lt v3, v4, :cond_39

    const/16 v4, 0x39

    if-gt v3, v4, :cond_39

    if-eqz v1, :cond_39

    goto :goto_5b

    :cond_39
    const/16 v4, 0x7e

    if-ne v3, v4, :cond_40

    if-eqz v1, :cond_40

    goto :goto_5b

    :cond_40
    const/16 v4, 0x2e

    if-ne v3, v4, :cond_47

    if-eqz v1, :cond_47

    goto :goto_5b

    :cond_47
    const/16 v4, 0x5f

    if-ne v3, v4, :cond_4e

    if-eqz v1, :cond_4e

    goto :goto_5b

    :cond_4e
    const/16 v4, 0x2b

    if-ne v3, v4, :cond_55

    if-eqz v1, :cond_55

    goto :goto_5b

    :cond_55
    const/16 v4, 0x2d

    if-ne v3, v4, :cond_5e

    if-eqz v1, :cond_5e

    :goto_5b
    add-int/lit8 v1, v1, 0x1

    goto :goto_f

    :cond_5e
    new-instance p1, Lj$/time/c;

    invoke-virtual {v2, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_68
    :try_start_68
    invoke-static {p0}, Lj$/time/zone/i;->a(Ljava/lang/String;)Lj$/time/zone/f;

    move-result-object p1
    :try_end_6c
    .catch Lj$/time/zone/g; {:try_start_68 .. :try_end_6c} :catch_6d

    goto :goto_71

    :catch_6d
    move-exception v0

    if-nez p1, :cond_77

    const/4 p1, 0x0

    :goto_71
    new-instance v0, Lj$/time/s;

    invoke-direct {v0, p0, p1}, Lj$/time/s;-><init>(Ljava/lang/String;Lj$/time/zone/f;)V

    return-object v0

    :cond_77
    throw v0

    :cond_78
    new-instance p1, Lj$/time/c;

    invoke-virtual {v2, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .registers 2

    new-instance p0, Ljava/io/InvalidObjectException;

    const-string p1, "Deserialization via serialization delegate"

    invoke-direct {p0, p1}, Ljava/io/InvalidObjectException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private writeReplace()Ljava/lang/Object;
    .registers 3

    new-instance v0, Lj$/time/p;

    const/4 v1, 0x7

    invoke-direct {v0, v1, p0}, Lj$/time/p;-><init>(BLjava/lang/Object;)V

    return-object v0
.end method


# virtual methods
.method public final J(Ljava/io/DataOutput;)V
    .registers 3

    const/4 v0, 0x7

    invoke-interface {p1, v0}, Ljava/io/DataOutput;->writeByte(I)V

    iget-object p0, p0, Lj$/time/s;->b:Ljava/lang/String;

    invoke-interface {p1, p0}, Ljava/io/DataOutput;->writeUTF(Ljava/lang/String;)V

    return-void
.end method

.method public final getId()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lj$/time/s;->b:Ljava/lang/String;

    return-object p0
.end method

.method public final v()Lj$/time/zone/f;
    .registers 2

    .prologue
    iget-object v0, p0, Lj$/time/s;->c:Lj$/time/zone/f;

    if-eqz v0, :cond_5

    return-object v0

    :cond_5
    iget-object p0, p0, Lj$/time/s;->b:Ljava/lang/String;

    invoke-static {p0}, Lj$/time/zone/i;->a(Ljava/lang/String;)Lj$/time/zone/f;

    move-result-object p0

    return-object p0
.end method
