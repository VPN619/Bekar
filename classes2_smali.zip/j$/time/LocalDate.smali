.class public final Lj$/time/LocalDate;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lj$/time/temporal/Temporal;
.implements Lj$/time/temporal/m;
.implements Lj$/time/chrono/b;
.implements Ljava/io/Serializable;


# static fields
.field public static final d:Lj$/time/LocalDate;

.field public static final e:Lj$/time/LocalDate;

.field private static final serialVersionUID:J = 0x28d617b1d8f33f1eL


# instance fields
.field public final a:I

.field public final b:S

.field public final c:S


# direct methods
.method static constructor <clinit>()V
    .registers 4

    const v0, -0x3b9ac9ff

    const/4 v1, 0x1

    invoke-static {v0, v1, v1}, Lj$/time/LocalDate;->of(III)Lj$/time/LocalDate;

    move-result-object v0

    sput-object v0, Lj$/time/LocalDate;->d:Lj$/time/LocalDate;

    const/16 v0, 0xc

    const/16 v2, 0x1f

    const v3, 0x3b9ac9ff

    invoke-static {v3, v0, v2}, Lj$/time/LocalDate;->of(III)Lj$/time/LocalDate;

    move-result-object v0

    sput-object v0, Lj$/time/LocalDate;->e:Lj$/time/LocalDate;

    const/16 v0, 0x7b2

    invoke-static {v0, v1, v1}, Lj$/time/LocalDate;->of(III)Lj$/time/LocalDate;

    return-void
.end method

.method public constructor <init>(III)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lj$/time/LocalDate;->a:I

    int-to-short p1, p2

    iput-short p1, p0, Lj$/time/LocalDate;->b:S

    int-to-short p1, p3

    iput-short p1, p0, Lj$/time/LocalDate;->c:S

    return-void
.end method

.method public static E(Lj$/time/temporal/l;)Lj$/time/LocalDate;
    .registers 3

    .prologue
    const-string v0, "temporal"

    invoke-static {p0, v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    sget-object v0, Lj$/time/temporal/p;->f:Lj$/time/format/a;

    invoke-interface {p0, v0}, Lj$/time/temporal/l;->b(Lj$/time/format/a;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lj$/time/LocalDate;

    if-eqz v0, :cond_10

    return-object v0

    :cond_10
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const-string v1, "Unable to obtain LocalDate from TemporalAccessor: "

    invoke-static {v1, p0, v0}, Lj$/time/h;->d(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static P(J)Lj$/time/LocalDate;
    .registers 25

    .prologue
    move-wide/from16 v0, p0

    sget-object v2, Lj$/time/temporal/a;->EPOCH_DAY:Lj$/time/temporal/a;

    invoke-virtual {v2, v0, v1}, Lj$/time/temporal/a;->I(J)V

    const-wide/32 v2, 0xafa6c

    add-long/2addr v2, v0

    const-wide/16 v4, 0x0

    cmp-long v6, v2, v4

    const-wide/16 v7, 0x1

    const-wide/32 v9, 0x23ab1

    const-wide/16 v11, 0x190

    if-gez v6, :cond_24

    const-wide/32 v13, 0xafa6d

    add-long/2addr v0, v13

    div-long/2addr v0, v9

    sub-long/2addr v0, v7

    mul-long v13, v0, v11

    neg-long v0, v0

    mul-long/2addr v0, v9

    add-long/2addr v2, v0

    goto :goto_25

    :cond_24
    move-wide v13, v4

    :goto_25
    mul-long v0, v2, v11

    const-wide/16 v15, 0x24f

    add-long/2addr v0, v15

    div-long/2addr v0, v9

    const-wide/16 v9, 0x16d

    mul-long v15, v0, v9

    const-wide/16 v17, 0x4

    div-long v19, v0, v17

    add-long v19, v19, v15

    const-wide/16 v15, 0x64

    div-long v21, v0, v15

    sub-long v19, v19, v21

    div-long v21, v0, v11

    add-long v21, v21, v19

    sub-long v19, v2, v21

    cmp-long v4, v19, v4

    if-gez v4, :cond_52

    sub-long/2addr v0, v7

    mul-long/2addr v9, v0

    div-long v4, v0, v17

    add-long/2addr v4, v9

    div-long v6, v0, v15

    sub-long/2addr v4, v6

    div-long v6, v0, v11

    add-long/2addr v6, v4

    sub-long v19, v2, v6

    :cond_52
    move-wide/from16 v2, v19

    add-long/2addr v0, v13

    long-to-int v2, v2

    mul-int/lit8 v3, v2, 0x5

    add-int/lit8 v3, v3, 0x2

    div-int/lit16 v3, v3, 0x99

    add-int/lit8 v4, v3, 0x2

    rem-int/lit8 v4, v4, 0xc

    add-int/lit8 v4, v4, 0x1

    mul-int/lit16 v5, v3, 0x132

    add-int/lit8 v5, v5, 0x5

    div-int/lit8 v5, v5, 0xa

    sub-int/2addr v2, v5

    add-int/lit8 v2, v2, 0x1

    div-int/lit8 v3, v3, 0xa

    int-to-long v5, v3

    add-long/2addr v0, v5

    sget-object v3, Lj$/time/temporal/a;->YEAR:Lj$/time/temporal/a;

    iget-object v5, v3, Lj$/time/temporal/a;->b:Lj$/time/temporal/r;

    invoke-virtual {v5, v0, v1, v3}, Lj$/time/temporal/r;->a(JLj$/time/temporal/o;)I

    move-result v0

    new-instance v1, Lj$/time/LocalDate;

    invoke-direct {v1, v0, v4, v2}, Lj$/time/LocalDate;-><init>(III)V

    return-object v1
.end method

.method public static U(III)Lj$/time/LocalDate;
    .registers 6

    .prologue
    const/4 v0, 0x2

    if-eq p1, v0, :cond_19

    const/4 v0, 0x4

    if-eq p1, v0, :cond_12

    const/4 v0, 0x6

    if-eq p1, v0, :cond_12

    const/16 v0, 0x9

    if-eq p1, v0, :cond_12

    const/16 v0, 0xb

    if-eq p1, v0, :cond_12

    goto :goto_2e

    :cond_12
    const/16 v0, 0x1e

    invoke-static {p2, v0}, Ljava/lang/Math;->min(II)I

    move-result p2

    goto :goto_2e

    :cond_19
    sget-object v0, Lj$/time/chrono/t;->c:Lj$/time/chrono/t;

    int-to-long v1, p0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v1, v2}, Lj$/time/chrono/t;->E(J)Z

    move-result v0

    if-eqz v0, :cond_28

    const/16 v0, 0x1d

    goto :goto_2a

    :cond_28
    const/16 v0, 0x1c

    :goto_2a
    invoke-static {p2, v0}, Ljava/lang/Math;->min(II)I

    move-result p2

    :goto_2e
    new-instance v0, Lj$/time/LocalDate;

    invoke-direct {v0, p0, p1, p2}, Lj$/time/LocalDate;-><init>(III)V

    return-object v0
.end method

.method public static of(III)Lj$/time/LocalDate;
    .registers 6

    sget-object v0, Lj$/time/temporal/a;->YEAR:Lj$/time/temporal/a;

    int-to-long v1, p0

    invoke-virtual {v0, v1, v2}, Lj$/time/temporal/a;->I(J)V

    sget-object v0, Lj$/time/temporal/a;->MONTH_OF_YEAR:Lj$/time/temporal/a;

    int-to-long v1, p1

    invoke-virtual {v0, v1, v2}, Lj$/time/temporal/a;->I(J)V

    sget-object v0, Lj$/time/temporal/a;->DAY_OF_MONTH:Lj$/time/temporal/a;

    int-to-long v1, p2

    invoke-virtual {v0, v1, v2}, Lj$/time/temporal/a;->I(J)V

    invoke-static {p0, p1, p2}, Lj$/time/LocalDate;->v(III)Lj$/time/LocalDate;

    move-result-object p0

    return-object p0
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .registers 2

    new-instance p0, Ljava/io/InvalidObjectException;

    const-string p1, "Deserialization via serialization delegate"

    invoke-direct {p0, p1}, Ljava/io/InvalidObjectException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static v(III)Lj$/time/LocalDate;
    .registers 8

    .prologue
    const/16 v0, 0x1c

    if-le p2, v0, :cond_60

    const/4 v1, 0x2

    const/16 v2, 0x1d

    if-eq p1, v1, :cond_1d

    const/4 v0, 0x4

    if-eq p1, v0, :cond_1a

    const/4 v0, 0x6

    if-eq p1, v0, :cond_1a

    const/16 v0, 0x9

    if-eq p1, v0, :cond_1a

    const/16 v0, 0xb

    if-eq p1, v0, :cond_1a

    const/16 v0, 0x1f

    goto :goto_2a

    :cond_1a
    const/16 v0, 0x1e

    goto :goto_2a

    :cond_1d
    sget-object v1, Lj$/time/chrono/t;->c:Lj$/time/chrono/t;

    int-to-long v3, p0

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v3, v4}, Lj$/time/chrono/t;->E(J)Z

    move-result v1

    if-eqz v1, :cond_2a

    move v0, v2

    :cond_2a
    :goto_2a
    if-le p2, v0, :cond_60

    if-ne p2, v2, :cond_37

    const-string p1, "Invalid date \'February 29\' as \'"

    const-string p2, "\' is not a leap year"

    invoke-static {p1, p0, p2}, Lj$/time/h;->b(Ljava/lang/String;ILjava/lang/Object;)V

    const/4 p0, 0x0

    return-object p0

    :cond_37
    new-instance p0, Lj$/time/c;

    invoke-static {p1}, Lj$/time/l;->H(I)Lj$/time/l;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object p1

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Invalid date \'"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p1, " "

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, "\'"

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_60
    new-instance v0, Lj$/time/LocalDate;

    invoke-direct {v0, p0, p1, p2}, Lj$/time/LocalDate;-><init>(III)V

    return-object v0
.end method

.method private writeReplace()Ljava/lang/Object;
    .registers 3

    new-instance v0, Lj$/time/p;

    const/4 v1, 0x3

    invoke-direct {v0, v1, p0}, Lj$/time/p;-><init>(BLjava/lang/Object;)V

    return-object v0
.end method


# virtual methods
.method public final A(Lj$/time/LocalTime;)Lj$/time/chrono/e;
    .registers 2

    invoke-static {p0, p1}, Lj$/time/LocalDateTime;->of(Lj$/time/LocalDate;Lj$/time/LocalTime;)Lj$/time/LocalDateTime;

    move-result-object p0

    return-object p0
.end method

.method public final G(Lj$/time/chrono/b;)I
    .registers 3

    .prologue
    instance-of v0, p1, Lj$/time/LocalDate;

    if-eqz v0, :cond_b

    check-cast p1, Lj$/time/LocalDate;

    invoke-virtual {p0, p1}, Lj$/time/LocalDate;->n(Lj$/time/LocalDate;)I

    move-result p0

    return p0

    :cond_b
    invoke-super {p0, p1}, Lj$/time/chrono/b;->G(Lj$/time/chrono/b;)I

    move-result p0

    return p0
.end method

.method public final H(Lj$/time/temporal/o;)I
    .registers 4

    .prologue
    sget-object v0, Lj$/time/g;->a:[I

    move-object v1, p1

    check-cast v1, Lj$/time/temporal/a;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget v0, v0, v1

    const/4 v1, 0x1

    packed-switch v0, :pswitch_data_70

    new-instance p0, Lj$/time/temporal/q;

    const-string v0, "Unsupported field: "

    invoke-static {v0, p1}, Lj$/time/d;->a(Ljava/lang/String;Lj$/time/temporal/o;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :pswitch_1b  #0xd
    iget p0, p0, Lj$/time/LocalDate;->a:I

    if-lt p0, v1, :cond_20

    return v1

    :cond_20
    const/4 p0, 0x0

    return p0

    :pswitch_22  #0xc
    iget p0, p0, Lj$/time/LocalDate;->a:I

    return p0

    :pswitch_25  #0xb
    new-instance p0, Lj$/time/temporal/q;

    const-string p1, "Invalid field \'ProlepticMonth\' for get() method, use getLong() instead"

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :pswitch_2d  #0xa
    iget-short p0, p0, Lj$/time/LocalDate;->b:S

    return p0

    :pswitch_30  #0x9
    invoke-virtual {p0}, Lj$/time/LocalDate;->J()I

    move-result p0

    sub-int/2addr p0, v1

    div-int/lit8 p0, p0, 0x7

    add-int/2addr p0, v1

    return p0

    :pswitch_39  #0x8
    new-instance p0, Lj$/time/temporal/q;

    const-string p1, "Invalid field \'EpochDay\' for get() method, use getLong() instead"

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :pswitch_41  #0x7
    invoke-virtual {p0}, Lj$/time/LocalDate;->J()I

    move-result p0

    sub-int/2addr p0, v1

    rem-int/lit8 p0, p0, 0x7

    add-int/2addr p0, v1

    return p0

    :pswitch_4a  #0x6
    iget-short p0, p0, Lj$/time/LocalDate;->c:S

    sub-int/2addr p0, v1

    rem-int/lit8 p0, p0, 0x7

    add-int/2addr p0, v1

    return p0

    :pswitch_51  #0x5
    invoke-virtual {p0}, Lj$/time/LocalDate;->I()Lj$/time/e;

    move-result-object p0

    invoke-virtual {p0}, Lj$/time/e;->getValue()I

    move-result p0

    return p0

    :pswitch_5a  #0x4
    iget p0, p0, Lj$/time/LocalDate;->a:I

    if-lt p0, v1, :cond_5f

    return p0

    :cond_5f
    sub-int/2addr v1, p0

    return v1

    :pswitch_61  #0x3
    iget-short p0, p0, Lj$/time/LocalDate;->c:S

    sub-int/2addr p0, v1

    div-int/lit8 p0, p0, 0x7

    add-int/2addr p0, v1

    return p0

    :pswitch_68  #0x2
    invoke-virtual {p0}, Lj$/time/LocalDate;->J()I

    move-result p0

    return p0

    :pswitch_6d  #0x1
    iget-short p0, p0, Lj$/time/LocalDate;->c:S

    return p0

    :pswitch_data_70
    .packed-switch 0x1
        :pswitch_6d  #00000001
        :pswitch_68  #00000002
        :pswitch_61  #00000003
        :pswitch_5a  #00000004
        :pswitch_51  #00000005
        :pswitch_4a  #00000006
        :pswitch_41  #00000007
        :pswitch_39  #00000008
        :pswitch_30  #00000009
        :pswitch_2d  #0000000a
        :pswitch_25  #0000000b
        :pswitch_22  #0000000c
        :pswitch_1b  #0000000d
    .end packed-switch
.end method

.method public final I()Lj$/time/e;
    .registers 5

    invoke-virtual {p0}, Lj$/time/LocalDate;->z()J

    move-result-wide v0

    const-wide/16 v2, 0x3

    add-long/2addr v0, v2

    const-wide/16 v2, 0x7

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->floorMod(JJ)J

    move-result-wide v0

    long-to-int p0, v0

    add-int/lit8 p0, p0, 0x1

    invoke-static {p0}, Lj$/time/e;->n(I)Lj$/time/e;

    move-result-object p0

    return-object p0
.end method

.method public final J()I
    .registers 3

    iget-short v0, p0, Lj$/time/LocalDate;->b:S

    invoke-static {v0}, Lj$/time/l;->H(I)Lj$/time/l;

    move-result-object v0

    invoke-virtual {p0}, Lj$/time/LocalDate;->M()Z

    move-result v1

    invoke-virtual {v0, v1}, Lj$/time/l;->n(Z)I

    move-result v0

    iget-short p0, p0, Lj$/time/LocalDate;->c:S

    add-int/2addr v0, p0

    add-int/lit8 v0, v0, -0x1

    return v0
.end method

.method public final K()J
    .registers 5

    iget v0, p0, Lj$/time/LocalDate;->a:I

    int-to-long v0, v0

    const-wide/16 v2, 0xc

    mul-long/2addr v0, v2

    iget-short p0, p0, Lj$/time/LocalDate;->b:S

    int-to-long v2, p0

    add-long/2addr v0, v2

    const-wide/16 v2, 0x1

    sub-long/2addr v0, v2

    return-wide v0
.end method

.method public final L(Lj$/time/chrono/b;)Z
    .registers 7

    .prologue
    instance-of v0, p1, Lj$/time/LocalDate;

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz v0, :cond_10

    check-cast p1, Lj$/time/LocalDate;

    invoke-virtual {p0, p1}, Lj$/time/LocalDate;->n(Lj$/time/LocalDate;)I

    move-result p0

    if-gez p0, :cond_f

    return v2

    :cond_f
    return v1

    :cond_10
    invoke-virtual {p0}, Lj$/time/LocalDate;->z()J

    move-result-wide v3

    invoke-interface {p1}, Lj$/time/chrono/b;->z()J

    move-result-wide p0

    cmp-long p0, v3, p0

    if-gez p0, :cond_1d

    return v2

    :cond_1d
    return v1
.end method

.method public final M()Z
    .registers 4

    sget-object v0, Lj$/time/chrono/t;->c:Lj$/time/chrono/t;

    iget p0, p0, Lj$/time/LocalDate;->a:I

    int-to-long v1, p0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v1, v2}, Lj$/time/chrono/t;->E(J)Z

    move-result p0

    return p0
.end method

.method public final N()I
    .registers 3

    .prologue
    iget-short v0, p0, Lj$/time/LocalDate;->b:S

    const/4 v1, 0x2

    if-eq v0, v1, :cond_19

    const/4 p0, 0x4

    if-eq v0, p0, :cond_16

    const/4 p0, 0x6

    if-eq v0, p0, :cond_16

    const/16 p0, 0x9

    if-eq v0, p0, :cond_16

    const/16 p0, 0xb

    if-eq v0, p0, :cond_16

    const/16 p0, 0x1f

    return p0

    :cond_16
    const/16 p0, 0x1e

    return p0

    :cond_19
    invoke-virtual {p0}, Lj$/time/LocalDate;->M()Z

    move-result p0

    if-eqz p0, :cond_22

    const/16 p0, 0x1d

    return p0

    :cond_22
    const/16 p0, 0x1c

    return p0
.end method

.method public final O(Lj$/time/LocalDate;)J
    .registers 8

    invoke-virtual {p0}, Lj$/time/LocalDate;->K()J

    move-result-wide v0

    const-wide/16 v2, 0x20

    mul-long/2addr v0, v2

    invoke-virtual {p0}, Lj$/time/LocalDate;->getDayOfMonth()I

    move-result p0

    int-to-long v4, p0

    add-long/2addr v0, v4

    invoke-virtual {p1}, Lj$/time/LocalDate;->K()J

    move-result-wide v4

    mul-long/2addr v4, v2

    invoke-virtual {p1}, Lj$/time/LocalDate;->getDayOfMonth()I

    move-result p0

    int-to-long p0, p0

    add-long/2addr v4, p0

    sub-long/2addr v4, v0

    div-long/2addr v4, v2

    return-wide v4
.end method

.method public final Q(JLj$/time/temporal/TemporalUnit;)Lj$/time/LocalDate;
    .registers 6

    .prologue
    instance-of v0, p3, Lj$/time/temporal/ChronoUnit;

    if-eqz v0, :cond_63

    move-object v0, p3

    check-cast v0, Lj$/time/temporal/ChronoUnit;

    sget-object v1, Lj$/time/g;->b:[I

    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    aget v0, v1, v0

    packed-switch v0, :pswitch_data_6a

    const-string p0, "Unsupported unit: "

    invoke-static {p0, p3}, Lj$/time/h;->c(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 p0, 0x0

    return-object p0

    :pswitch_19  #0x8
    sget-object p3, Lj$/time/temporal/a;->ERA:Lj$/time/temporal/a;

    invoke-virtual {p0, p3}, Lj$/time/LocalDate;->f(Lj$/time/temporal/o;)J

    move-result-wide v0

    invoke-static {v0, v1, p1, p2}, Ljava/lang/Math;->addExact(JJ)J

    move-result-wide p1

    invoke-virtual {p0, p1, p2, p3}, Lj$/time/LocalDate;->V(JLj$/time/temporal/o;)Lj$/time/LocalDate;

    move-result-object p0

    return-object p0

    :pswitch_28  #0x7
    const-wide/16 v0, 0x3e8

    invoke-static {p1, p2, v0, v1}, Ljava/lang/Math;->multiplyExact(JJ)J

    move-result-wide p1

    invoke-virtual {p0, p1, p2}, Lj$/time/LocalDate;->T(J)Lj$/time/LocalDate;

    move-result-object p0

    return-object p0

    :pswitch_33  #0x6
    const-wide/16 v0, 0x64

    invoke-static {p1, p2, v0, v1}, Ljava/lang/Math;->multiplyExact(JJ)J

    move-result-wide p1

    invoke-virtual {p0, p1, p2}, Lj$/time/LocalDate;->T(J)Lj$/time/LocalDate;

    move-result-object p0

    return-object p0

    :pswitch_3e  #0x5
    const-wide/16 v0, 0xa

    invoke-static {p1, p2, v0, v1}, Ljava/lang/Math;->multiplyExact(JJ)J

    move-result-wide p1

    invoke-virtual {p0, p1, p2}, Lj$/time/LocalDate;->T(J)Lj$/time/LocalDate;

    move-result-object p0

    return-object p0

    :pswitch_49  #0x4
    invoke-virtual {p0, p1, p2}, Lj$/time/LocalDate;->T(J)Lj$/time/LocalDate;

    move-result-object p0

    return-object p0

    :pswitch_4e  #0x3
    invoke-virtual {p0, p1, p2}, Lj$/time/LocalDate;->S(J)Lj$/time/LocalDate;

    move-result-object p0

    return-object p0

    :pswitch_53  #0x2
    const-wide/16 v0, 0x7

    invoke-static {p1, p2, v0, v1}, Ljava/lang/Math;->multiplyExact(JJ)J

    move-result-wide p1

    invoke-virtual {p0, p1, p2}, Lj$/time/LocalDate;->R(J)Lj$/time/LocalDate;

    move-result-object p0

    return-object p0

    :pswitch_5e  #0x1
    invoke-virtual {p0, p1, p2}, Lj$/time/LocalDate;->R(J)Lj$/time/LocalDate;

    move-result-object p0

    return-object p0

    :cond_63
    invoke-interface {p3, p0, p1, p2}, Lj$/time/temporal/TemporalUnit;->v(Lj$/time/temporal/Temporal;J)Lj$/time/temporal/Temporal;

    move-result-object p0

    check-cast p0, Lj$/time/LocalDate;

    return-object p0

    :pswitch_data_6a
    .packed-switch 0x1
        :pswitch_5e  #00000001
        :pswitch_53  #00000002
        :pswitch_4e  #00000003
        :pswitch_49  #00000004
        :pswitch_3e  #00000005
        :pswitch_33  #00000006
        :pswitch_28  #00000007
        :pswitch_19  #00000008
    .end packed-switch
.end method

.method public final R(J)Lj$/time/LocalDate;
    .registers 10

    .prologue
    const-wide/16 v0, 0x0

    cmp-long v2, p1, v0

    if-nez v2, :cond_7

    return-object p0

    :cond_7
    iget-short v2, p0, Lj$/time/LocalDate;->c:S

    int-to-long v2, v2

    add-long/2addr v2, p1

    cmp-long v0, v2, v0

    if-lez v0, :cond_60

    const-wide/16 v0, 0x1c

    cmp-long v0, v2, v0

    if-gtz v0, :cond_20

    new-instance p1, Lj$/time/LocalDate;

    iget p2, p0, Lj$/time/LocalDate;->a:I

    iget-short p0, p0, Lj$/time/LocalDate;->b:S

    long-to-int v0, v2

    invoke-direct {p1, p2, p0, v0}, Lj$/time/LocalDate;-><init>(III)V

    return-object p1

    :cond_20
    const-wide/16 v0, 0x3b

    cmp-long v0, v2, v0

    if-gtz v0, :cond_60

    invoke-virtual {p0}, Lj$/time/LocalDate;->N()I

    move-result p1

    int-to-long p1, p1

    cmp-long v0, v2, p1

    if-gtz v0, :cond_3a

    new-instance p1, Lj$/time/LocalDate;

    iget p2, p0, Lj$/time/LocalDate;->a:I

    iget-short p0, p0, Lj$/time/LocalDate;->b:S

    long-to-int v0, v2

    invoke-direct {p1, p2, p0, v0}, Lj$/time/LocalDate;-><init>(III)V

    return-object p1

    :cond_3a
    iget-short v0, p0, Lj$/time/LocalDate;->b:S

    const/16 v1, 0xc

    const/4 v4, 0x1

    if-ge v0, v1, :cond_4c

    new-instance v1, Lj$/time/LocalDate;

    iget p0, p0, Lj$/time/LocalDate;->a:I

    add-int/2addr v0, v4

    sub-long/2addr v2, p1

    long-to-int p1, v2

    invoke-direct {v1, p0, v0, p1}, Lj$/time/LocalDate;-><init>(III)V

    return-object v1

    :cond_4c
    sget-object v0, Lj$/time/temporal/a;->YEAR:Lj$/time/temporal/a;

    iget v1, p0, Lj$/time/LocalDate;->a:I

    add-int/2addr v1, v4

    int-to-long v5, v1

    invoke-virtual {v0, v5, v6}, Lj$/time/temporal/a;->I(J)V

    new-instance v0, Lj$/time/LocalDate;

    iget p0, p0, Lj$/time/LocalDate;->a:I

    add-int/2addr p0, v4

    sub-long/2addr v2, p1

    long-to-int p1, v2

    invoke-direct {v0, p0, v4, p1}, Lj$/time/LocalDate;-><init>(III)V

    return-object v0

    :cond_60
    invoke-virtual {p0}, Lj$/time/LocalDate;->z()J

    move-result-wide v0

    invoke-static {v0, v1, p1, p2}, Ljava/lang/Math;->addExact(JJ)J

    move-result-wide p0

    invoke-static {p0, p1}, Lj$/time/LocalDate;->P(J)Lj$/time/LocalDate;

    move-result-object p0

    return-object p0
.end method

.method public final S(J)Lj$/time/LocalDate;
    .registers 9

    .prologue
    const-wide/16 v0, 0x0

    cmp-long v0, p1, v0

    if-nez v0, :cond_7

    return-object p0

    :cond_7
    iget v0, p0, Lj$/time/LocalDate;->a:I

    int-to-long v0, v0

    const-wide/16 v2, 0xc

    mul-long/2addr v0, v2

    iget-short v4, p0, Lj$/time/LocalDate;->b:S

    add-int/lit8 v4, v4, -0x1

    int-to-long v4, v4

    add-long/2addr v0, v4

    add-long/2addr v0, p1

    sget-object p1, Lj$/time/temporal/a;->YEAR:Lj$/time/temporal/a;

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->floorDiv(JJ)J

    move-result-wide v4

    iget-object p2, p1, Lj$/time/temporal/a;->b:Lj$/time/temporal/r;

    invoke-virtual {p2, v4, v5, p1}, Lj$/time/temporal/r;->a(JLj$/time/temporal/o;)I

    move-result p1

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->floorMod(JJ)J

    move-result-wide v0

    long-to-int p2, v0

    add-int/lit8 p2, p2, 0x1

    iget-short p0, p0, Lj$/time/LocalDate;->c:S

    invoke-static {p1, p2, p0}, Lj$/time/LocalDate;->U(III)Lj$/time/LocalDate;

    move-result-object p0

    return-object p0
.end method

.method public final T(J)Lj$/time/LocalDate;
    .registers 6

    .prologue
    const-wide/16 v0, 0x0

    cmp-long v0, p1, v0

    if-nez v0, :cond_7

    return-object p0

    :cond_7
    sget-object v0, Lj$/time/temporal/a;->YEAR:Lj$/time/temporal/a;

    iget v1, p0, Lj$/time/LocalDate;->a:I

    int-to-long v1, v1

    add-long/2addr v1, p1

    iget-object p1, v0, Lj$/time/temporal/a;->b:Lj$/time/temporal/r;

    invoke-virtual {p1, v1, v2, v0}, Lj$/time/temporal/r;->a(JLj$/time/temporal/o;)I

    move-result p1

    iget-short p2, p0, Lj$/time/LocalDate;->b:S

    iget-short p0, p0, Lj$/time/LocalDate;->c:S

    invoke-static {p1, p2, p0}, Lj$/time/LocalDate;->U(III)Lj$/time/LocalDate;

    move-result-object p0

    return-object p0
.end method

.method public final V(JLj$/time/temporal/o;)Lj$/time/LocalDate;
    .registers 9

    .prologue
    instance-of v0, p3, Lj$/time/temporal/a;

    if-eqz v0, :cond_cd

    move-object v0, p3

    check-cast v0, Lj$/time/temporal/a;

    invoke-virtual {v0, p1, p2}, Lj$/time/temporal/a;->I(J)V

    sget-object v1, Lj$/time/g;->a:[I

    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    aget v0, v1, v0

    const-wide/16 v1, 0x7

    const/4 v3, 0x1

    packed-switch v0, :pswitch_data_d4

    new-instance p0, Lj$/time/temporal/q;

    const-string p1, "Unsupported field: "

    invoke-static {p1, p3}, Lj$/time/d;->a(Ljava/lang/String;Lj$/time/temporal/o;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :pswitch_24  #0xd
    sget-object p3, Lj$/time/temporal/a;->ERA:Lj$/time/temporal/a;

    invoke-virtual {p0, p3}, Lj$/time/LocalDate;->f(Lj$/time/temporal/o;)J

    move-result-wide v0

    cmp-long p1, v0, p1

    if-nez p1, :cond_30

    goto/16 :goto_c3

    :cond_30
    iget p1, p0, Lj$/time/LocalDate;->a:I

    sub-int/2addr v3, p1

    invoke-virtual {p0, v3}, Lj$/time/LocalDate;->Y(I)Lj$/time/LocalDate;

    move-result-object p0

    return-object p0

    :pswitch_38  #0xc
    long-to-int p1, p1

    invoke-virtual {p0, p1}, Lj$/time/LocalDate;->Y(I)Lj$/time/LocalDate;

    move-result-object p0

    return-object p0

    :pswitch_3e  #0xb
    invoke-virtual {p0}, Lj$/time/LocalDate;->K()J

    move-result-wide v0

    sub-long/2addr p1, v0

    invoke-virtual {p0, p1, p2}, Lj$/time/LocalDate;->S(J)Lj$/time/LocalDate;

    move-result-object p0

    return-object p0

    :pswitch_48  #0xa
    long-to-int p1, p1

    iget-short p2, p0, Lj$/time/LocalDate;->b:S

    if-ne p2, p1, :cond_4e

    goto :goto_c3

    :cond_4e
    sget-object p2, Lj$/time/temporal/a;->MONTH_OF_YEAR:Lj$/time/temporal/a;

    int-to-long v0, p1

    invoke-virtual {p2, v0, v1}, Lj$/time/temporal/a;->I(J)V

    iget p2, p0, Lj$/time/LocalDate;->a:I

    iget-short p0, p0, Lj$/time/LocalDate;->c:S

    invoke-static {p2, p1, p0}, Lj$/time/LocalDate;->U(III)Lj$/time/LocalDate;

    move-result-object p0

    return-object p0

    :pswitch_5d  #0x9
    sget-object p3, Lj$/time/temporal/a;->ALIGNED_WEEK_OF_YEAR:Lj$/time/temporal/a;

    invoke-virtual {p0, p3}, Lj$/time/LocalDate;->f(Lj$/time/temporal/o;)J

    move-result-wide v3

    sub-long/2addr p1, v3

    invoke-static {p1, p2, v1, v2}, Ljava/lang/Math;->multiplyExact(JJ)J

    move-result-wide p1

    invoke-virtual {p0, p1, p2}, Lj$/time/LocalDate;->R(J)Lj$/time/LocalDate;

    move-result-object p0

    return-object p0

    :pswitch_6d  #0x8
    invoke-static {p1, p2}, Lj$/time/LocalDate;->P(J)Lj$/time/LocalDate;

    move-result-object p0

    return-object p0

    :pswitch_72  #0x7
    sget-object p3, Lj$/time/temporal/a;->ALIGNED_DAY_OF_WEEK_IN_YEAR:Lj$/time/temporal/a;

    invoke-virtual {p0, p3}, Lj$/time/LocalDate;->f(Lj$/time/temporal/o;)J

    move-result-wide v0

    sub-long/2addr p1, v0

    invoke-virtual {p0, p1, p2}, Lj$/time/LocalDate;->R(J)Lj$/time/LocalDate;

    move-result-object p0

    return-object p0

    :pswitch_7e  #0x6
    sget-object p3, Lj$/time/temporal/a;->ALIGNED_DAY_OF_WEEK_IN_MONTH:Lj$/time/temporal/a;

    invoke-virtual {p0, p3}, Lj$/time/LocalDate;->f(Lj$/time/temporal/o;)J

    move-result-wide v0

    sub-long/2addr p1, v0

    invoke-virtual {p0, p1, p2}, Lj$/time/LocalDate;->R(J)Lj$/time/LocalDate;

    move-result-object p0

    return-object p0

    :pswitch_8a  #0x5
    invoke-virtual {p0}, Lj$/time/LocalDate;->I()Lj$/time/e;

    move-result-object p3

    invoke-virtual {p3}, Lj$/time/e;->getValue()I

    move-result p3

    int-to-long v0, p3

    sub-long/2addr p1, v0

    invoke-virtual {p0, p1, p2}, Lj$/time/LocalDate;->R(J)Lj$/time/LocalDate;

    move-result-object p0

    return-object p0

    :pswitch_99  #0x4
    iget p3, p0, Lj$/time/LocalDate;->a:I

    if-lt p3, v3, :cond_9e

    goto :goto_a2

    :cond_9e
    const-wide/16 v0, 0x1

    sub-long p1, v0, p1

    :goto_a2
    long-to-int p1, p1

    invoke-virtual {p0, p1}, Lj$/time/LocalDate;->Y(I)Lj$/time/LocalDate;

    move-result-object p0

    return-object p0

    :pswitch_a8  #0x3
    sget-object p3, Lj$/time/temporal/a;->ALIGNED_WEEK_OF_MONTH:Lj$/time/temporal/a;

    invoke-virtual {p0, p3}, Lj$/time/LocalDate;->f(Lj$/time/temporal/o;)J

    move-result-wide v3

    sub-long/2addr p1, v3

    invoke-static {p1, p2, v1, v2}, Ljava/lang/Math;->multiplyExact(JJ)J

    move-result-wide p1

    invoke-virtual {p0, p1, p2}, Lj$/time/LocalDate;->R(J)Lj$/time/LocalDate;

    move-result-object p0

    return-object p0

    :pswitch_b8  #0x2
    long-to-int p1, p1

    invoke-virtual {p0, p1}, Lj$/time/LocalDate;->X(I)Lj$/time/LocalDate;

    move-result-object p0

    return-object p0

    :pswitch_be  #0x1
    long-to-int p1, p1

    iget-short p2, p0, Lj$/time/LocalDate;->c:S

    if-ne p2, p1, :cond_c4

    :goto_c3
    return-object p0

    :cond_c4
    iget p2, p0, Lj$/time/LocalDate;->a:I

    iget-short p0, p0, Lj$/time/LocalDate;->b:S

    invoke-static {p2, p0, p1}, Lj$/time/LocalDate;->of(III)Lj$/time/LocalDate;

    move-result-object p0

    return-object p0

    :cond_cd
    invoke-interface {p3, p0, p1, p2}, Lj$/time/temporal/o;->H(Lj$/time/temporal/Temporal;J)Lj$/time/temporal/Temporal;

    move-result-object p0

    check-cast p0, Lj$/time/LocalDate;

    return-object p0

    :pswitch_data_d4
    .packed-switch 0x1
        :pswitch_be  #00000001
        :pswitch_b8  #00000002
        :pswitch_a8  #00000003
        :pswitch_99  #00000004
        :pswitch_8a  #00000005
        :pswitch_7e  #00000006
        :pswitch_72  #00000007
        :pswitch_6d  #00000008
        :pswitch_5d  #00000009
        :pswitch_48  #0000000a
        :pswitch_3e  #0000000b
        :pswitch_38  #0000000c
        :pswitch_24  #0000000d
    .end packed-switch
.end method

.method public final W(Lj$/time/temporal/m;)Lj$/time/LocalDate;
    .registers 3

    .prologue
    instance-of v0, p1, Lj$/time/LocalDate;

    if-eqz v0, :cond_7

    check-cast p1, Lj$/time/LocalDate;

    return-object p1

    :cond_7
    invoke-interface {p1, p0}, Lj$/time/temporal/m;->c(Lj$/time/temporal/Temporal;)Lj$/time/temporal/Temporal;

    move-result-object p0

    check-cast p0, Lj$/time/LocalDate;

    return-object p0
.end method

.method public final X(I)Lj$/time/LocalDate;
    .registers 7

    .prologue
    invoke-virtual {p0}, Lj$/time/LocalDate;->J()I

    move-result v0

    if-ne v0, p1, :cond_7

    return-object p0

    :cond_7
    iget p0, p0, Lj$/time/LocalDate;->a:I

    sget-object v0, Lj$/time/temporal/a;->YEAR:Lj$/time/temporal/a;

    int-to-long v1, p0

    invoke-virtual {v0, v1, v2}, Lj$/time/temporal/a;->I(J)V

    sget-object v0, Lj$/time/temporal/a;->DAY_OF_YEAR:Lj$/time/temporal/a;

    int-to-long v3, p1

    invoke-virtual {v0, v3, v4}, Lj$/time/temporal/a;->I(J)V

    sget-object v0, Lj$/time/chrono/t;->c:Lj$/time/chrono/t;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v1, v2}, Lj$/time/chrono/t;->E(J)Z

    move-result v0

    const/16 v1, 0x16e

    if-ne p1, v1, :cond_2e

    if-eqz v0, :cond_25

    goto :goto_2e

    :cond_25
    const-string p1, "Invalid date \'DayOfYear 366\' as \'"

    const-string v0, "\' is not a leap year"

    invoke-static {p1, p0, v0}, Lj$/time/h;->b(Ljava/lang/String;ILjava/lang/Object;)V

    const/4 p0, 0x0

    return-object p0

    :cond_2e
    :goto_2e
    add-int/lit8 v1, p1, -0x1

    div-int/lit8 v1, v1, 0x1f

    add-int/lit8 v1, v1, 0x1

    invoke-static {v1}, Lj$/time/l;->H(I)Lj$/time/l;

    move-result-object v1

    invoke-virtual {v1, v0}, Lj$/time/l;->n(Z)I

    move-result v2

    invoke-virtual {v1, v0}, Lj$/time/l;->v(Z)I

    move-result v3

    add-int/2addr v3, v2

    add-int/lit8 v3, v3, -0x1

    if-le p1, v3, :cond_51

    sget-object v2, Lj$/time/l;->a:[Lj$/time/l;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    add-int/lit8 v1, v1, 0xd

    rem-int/lit8 v1, v1, 0xc

    aget-object v1, v2, v1

    :cond_51
    invoke-virtual {v1, v0}, Lj$/time/l;->n(Z)I

    move-result v0

    sub-int/2addr p1, v0

    add-int/lit8 p1, p1, 0x1

    new-instance v0, Lj$/time/LocalDate;

    invoke-virtual {v1}, Lj$/time/l;->getValue()I

    move-result v1

    invoke-direct {v0, p0, v1, p1}, Lj$/time/LocalDate;-><init>(III)V

    return-object v0
.end method

.method public final Y(I)Lj$/time/LocalDate;
    .registers 5

    .prologue
    iget v0, p0, Lj$/time/LocalDate;->a:I

    if-ne v0, p1, :cond_5

    return-object p0

    :cond_5
    sget-object v0, Lj$/time/temporal/a;->YEAR:Lj$/time/temporal/a;

    int-to-long v1, p1

    invoke-virtual {v0, v1, v2}, Lj$/time/temporal/a;->I(J)V

    iget-short v0, p0, Lj$/time/LocalDate;->b:S

    iget-short p0, p0, Lj$/time/LocalDate;->c:S

    invoke-static {p1, v0, p0}, Lj$/time/LocalDate;->U(III)Lj$/time/LocalDate;

    move-result-object p0

    return-object p0
.end method

.method public final a(JLj$/time/temporal/TemporalUnit;)Lj$/time/chrono/b;
    .registers 4

    const-wide/16 p1, -0x1

    invoke-virtual {p0, p1, p2, p3}, Lj$/time/LocalDate;->Q(JLj$/time/temporal/TemporalUnit;)Lj$/time/LocalDate;

    move-result-object p0

    return-object p0
.end method

.method public final a(JLj$/time/temporal/TemporalUnit;)Lj$/time/temporal/Temporal;
    .registers 6

    .prologue
    const-wide/high16 v0, -0x8000000000000000L

    cmp-long v0, p1, v0

    if-nez v0, :cond_16

    const-wide p1, 0x7fffffffffffffffL

    invoke-virtual {p0, p1, p2, p3}, Lj$/time/LocalDate;->Q(JLj$/time/temporal/TemporalUnit;)Lj$/time/LocalDate;

    move-result-object p0

    const-wide/16 p1, 0x1

    :goto_11
    invoke-virtual {p0, p1, p2, p3}, Lj$/time/LocalDate;->Q(JLj$/time/temporal/TemporalUnit;)Lj$/time/LocalDate;

    move-result-object p0

    return-object p0

    :cond_16
    neg-long p1, p1

    goto :goto_11
.end method

.method public final b(Lj$/time/format/a;)Ljava/lang/Object;
    .registers 3

    .prologue
    sget-object v0, Lj$/time/temporal/p;->f:Lj$/time/format/a;

    if-ne p1, v0, :cond_5

    return-object p0

    :cond_5
    invoke-super {p0, p1}, Lj$/time/chrono/b;->b(Lj$/time/format/a;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final bridge synthetic compareTo(Ljava/lang/Object;)I
    .registers 2

    check-cast p1, Lj$/time/chrono/b;

    invoke-virtual {p0, p1}, Lj$/time/LocalDate;->G(Lj$/time/chrono/b;)I

    move-result p0

    return p0
.end method

.method public final d(Lj$/time/temporal/o;)I
    .registers 3

    .prologue
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_9

    invoke-virtual {p0, p1}, Lj$/time/LocalDate;->H(Lj$/time/temporal/o;)I

    move-result p0

    return p0

    :cond_9
    invoke-super {p0, p1}, Lj$/time/temporal/l;->d(Lj$/time/temporal/o;)I

    move-result p0

    return p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 5

    .prologue
    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lj$/time/LocalDate;

    const/4 v2, 0x0

    if-eqz v1, :cond_12

    check-cast p1, Lj$/time/LocalDate;

    invoke-virtual {p0, p1}, Lj$/time/LocalDate;->n(Lj$/time/LocalDate;)I

    move-result p0

    if-nez p0, :cond_12

    return v0

    :cond_12
    return v2
.end method

.method public final f(Lj$/time/temporal/o;)J
    .registers 3

    .prologue
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_1c

    sget-object v0, Lj$/time/temporal/a;->EPOCH_DAY:Lj$/time/temporal/a;

    if-ne p1, v0, :cond_d

    invoke-virtual {p0}, Lj$/time/LocalDate;->z()J

    move-result-wide p0

    return-wide p0

    :cond_d
    sget-object v0, Lj$/time/temporal/a;->PROLEPTIC_MONTH:Lj$/time/temporal/a;

    if-ne p1, v0, :cond_16

    invoke-virtual {p0}, Lj$/time/LocalDate;->K()J

    move-result-wide p0

    return-wide p0

    :cond_16
    invoke-virtual {p0, p1}, Lj$/time/LocalDate;->H(Lj$/time/temporal/o;)I

    move-result p0

    int-to-long p0, p0

    return-wide p0

    :cond_1c
    invoke-interface {p1, p0}, Lj$/time/temporal/o;->E(Lj$/time/temporal/l;)J

    move-result-wide p0

    return-wide p0
.end method

.method public final bridge synthetic g(JLj$/time/temporal/o;)Lj$/time/chrono/b;
    .registers 4

    invoke-virtual {p0, p1, p2, p3}, Lj$/time/LocalDate;->V(JLj$/time/temporal/o;)Lj$/time/LocalDate;

    move-result-object p0

    return-object p0
.end method

.method public final bridge synthetic g(JLj$/time/temporal/o;)Lj$/time/temporal/Temporal;
    .registers 4

    invoke-virtual {p0, p1, p2, p3}, Lj$/time/LocalDate;->V(JLj$/time/temporal/o;)Lj$/time/LocalDate;

    move-result-object p0

    return-object p0
.end method

.method public final getChronology()Lj$/time/chrono/m;
    .registers 1

    sget-object p0, Lj$/time/chrono/t;->c:Lj$/time/chrono/t;

    return-object p0
.end method

.method public getDayOfMonth()I
    .registers 1

    iget-short p0, p0, Lj$/time/LocalDate;->c:S

    return p0
.end method

.method public getMonthValue()I
    .registers 1

    iget-short p0, p0, Lj$/time/LocalDate;->b:S

    return p0
.end method

.method public getYear()I
    .registers 1

    iget p0, p0, Lj$/time/LocalDate;->a:I

    return p0
.end method

.method public final bridge synthetic h(Lj$/time/LocalDate;)Lj$/time/temporal/Temporal;
    .registers 2

    invoke-virtual {p0, p1}, Lj$/time/LocalDate;->W(Lj$/time/temporal/m;)Lj$/time/LocalDate;

    move-result-object p0

    return-object p0
.end method

.method public final hashCode()I
    .registers 4

    iget v0, p0, Lj$/time/LocalDate;->a:I

    iget-short v1, p0, Lj$/time/LocalDate;->b:S

    iget-short p0, p0, Lj$/time/LocalDate;->c:S

    and-int/lit16 v2, v0, -0x800

    shl-int/lit8 v0, v0, 0xb

    shl-int/lit8 v1, v1, 0x6

    add-int/2addr v0, v1

    add-int/2addr v0, p0

    xor-int p0, v2, v0

    return p0
.end method

.method public final i(Lj$/time/temporal/o;)Lj$/time/temporal/r;
    .registers 6

    .prologue
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_7d

    move-object v0, p1

    check-cast v0, Lj$/time/temporal/a;

    invoke-virtual {v0}, Lj$/time/temporal/a;->isDateBased()Z

    move-result v1

    if-eqz v1, :cond_71

    sget-object p1, Lj$/time/g;->a:[I

    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget p1, p1, v1

    const/4 v1, 0x1

    const-wide/16 v2, 0x1

    if-eq p1, v1, :cond_67

    const/4 v1, 0x2

    if-eq p1, v1, :cond_56

    const/4 v1, 0x3

    if-eq p1, v1, :cond_3c

    const/4 v1, 0x4

    if-eq p1, v1, :cond_26

    iget-object p0, v0, Lj$/time/temporal/a;->b:Lj$/time/temporal/r;

    return-object p0

    :cond_26
    invoke-virtual {p0}, Lj$/time/LocalDate;->getYear()I

    move-result p0

    if-gtz p0, :cond_34

    const-wide/32 p0, 0x3b9aca00

    invoke-static {v2, v3, p0, p1}, Lj$/time/temporal/r;->e(JJ)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_34
    const-wide/32 p0, 0x3b9ac9ff

    invoke-static {v2, v3, p0, p1}, Lj$/time/temporal/r;->e(JJ)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_3c
    iget-short p1, p0, Lj$/time/LocalDate;->b:S

    invoke-static {p1}, Lj$/time/l;->H(I)Lj$/time/l;

    move-result-object p1

    sget-object v0, Lj$/time/l;->FEBRUARY:Lj$/time/l;

    if-ne p1, v0, :cond_4f

    invoke-virtual {p0}, Lj$/time/LocalDate;->M()Z

    move-result p0

    if-nez p0, :cond_4f

    const-wide/16 p0, 0x4

    goto :goto_51

    :cond_4f
    const-wide/16 p0, 0x5

    :goto_51
    invoke-static {v2, v3, p0, p1}, Lj$/time/temporal/r;->e(JJ)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_56
    invoke-virtual {p0}, Lj$/time/LocalDate;->M()Z

    move-result p0

    if-eqz p0, :cond_5f

    const/16 p0, 0x16e

    goto :goto_61

    :cond_5f
    const/16 p0, 0x16d

    :goto_61
    int-to-long p0, p0

    invoke-static {v2, v3, p0, p1}, Lj$/time/temporal/r;->e(JJ)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_67
    invoke-virtual {p0}, Lj$/time/LocalDate;->N()I

    move-result p0

    int-to-long p0, p0

    invoke-static {v2, v3, p0, p1}, Lj$/time/temporal/r;->e(JJ)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_71
    new-instance p0, Lj$/time/temporal/q;

    const-string v0, "Unsupported field: "

    invoke-static {v0, p1}, Lj$/time/d;->a(Ljava/lang/String;Lj$/time/temporal/o;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_7d
    invoke-interface {p1, p0}, Lj$/time/temporal/o;->v(Lj$/time/temporal/l;)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0
.end method

.method public final bridge synthetic j(JLj$/time/temporal/TemporalUnit;)Lj$/time/chrono/b;
    .registers 4

    invoke-virtual {p0, p1, p2, p3}, Lj$/time/LocalDate;->Q(JLj$/time/temporal/TemporalUnit;)Lj$/time/LocalDate;

    move-result-object p0

    return-object p0
.end method

.method public final bridge synthetic j(JLj$/time/temporal/TemporalUnit;)Lj$/time/temporal/Temporal;
    .registers 4

    invoke-virtual {p0, p1, p2, p3}, Lj$/time/LocalDate;->Q(JLj$/time/temporal/TemporalUnit;)Lj$/time/LocalDate;

    move-result-object p0

    return-object p0
.end method

.method public final k(Lj$/time/temporal/Temporal;Lj$/time/temporal/TemporalUnit;)J
    .registers 5

    .prologue
    invoke-static {p1}, Lj$/time/LocalDate;->E(Lj$/time/temporal/l;)Lj$/time/LocalDate;

    move-result-object p1

    instance-of v0, p2, Lj$/time/temporal/ChronoUnit;

    if-eqz v0, :cond_66

    sget-object v0, Lj$/time/g;->b:[I

    move-object v1, p2

    check-cast v1, Lj$/time/temporal/ChronoUnit;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget v0, v0, v1

    packed-switch v0, :pswitch_data_6c

    const-string p0, "Unsupported unit: "

    invoke-static {p0, p2}, Lj$/time/h;->c(Ljava/lang/String;Ljava/lang/Object;)V

    const-wide/16 p0, 0x0

    return-wide p0

    :pswitch_1e  #0x8
    sget-object p2, Lj$/time/temporal/a;->ERA:Lj$/time/temporal/a;

    invoke-virtual {p1, p2}, Lj$/time/LocalDate;->f(Lj$/time/temporal/o;)J

    move-result-wide v0

    invoke-virtual {p0, p2}, Lj$/time/LocalDate;->f(Lj$/time/temporal/o;)J

    move-result-wide p0

    sub-long/2addr v0, p0

    return-wide v0

    :pswitch_2a  #0x7
    invoke-virtual {p0, p1}, Lj$/time/LocalDate;->O(Lj$/time/LocalDate;)J

    move-result-wide p0

    const-wide/16 v0, 0x2ee0

    div-long/2addr p0, v0

    return-wide p0

    :pswitch_32  #0x6
    invoke-virtual {p0, p1}, Lj$/time/LocalDate;->O(Lj$/time/LocalDate;)J

    move-result-wide p0

    const-wide/16 v0, 0x4b0

    div-long/2addr p0, v0

    return-wide p0

    :pswitch_3a  #0x5
    invoke-virtual {p0, p1}, Lj$/time/LocalDate;->O(Lj$/time/LocalDate;)J

    move-result-wide p0

    const-wide/16 v0, 0x78

    div-long/2addr p0, v0

    return-wide p0

    :pswitch_42  #0x4
    invoke-virtual {p0, p1}, Lj$/time/LocalDate;->O(Lj$/time/LocalDate;)J

    move-result-wide p0

    const-wide/16 v0, 0xc

    div-long/2addr p0, v0

    return-wide p0

    :pswitch_4a  #0x3
    invoke-virtual {p0, p1}, Lj$/time/LocalDate;->O(Lj$/time/LocalDate;)J

    move-result-wide p0

    return-wide p0

    :pswitch_4f  #0x2
    invoke-virtual {p1}, Lj$/time/LocalDate;->z()J

    move-result-wide p1

    invoke-virtual {p0}, Lj$/time/LocalDate;->z()J

    move-result-wide v0

    sub-long/2addr p1, v0

    const-wide/16 v0, 0x7

    div-long/2addr p1, v0

    return-wide p1

    :pswitch_5c  #0x1
    invoke-virtual {p1}, Lj$/time/LocalDate;->z()J

    move-result-wide p1

    invoke-virtual {p0}, Lj$/time/LocalDate;->z()J

    move-result-wide v0

    sub-long/2addr p1, v0

    return-wide p1

    :cond_66
    invoke-interface {p2, p0, p1}, Lj$/time/temporal/TemporalUnit;->n(Lj$/time/temporal/Temporal;Lj$/time/temporal/Temporal;)J

    move-result-wide p0

    return-wide p0

    nop

    :pswitch_data_6c
    .packed-switch 0x1
        :pswitch_5c  #00000001
        :pswitch_4f  #00000002
        :pswitch_4a  #00000003
        :pswitch_42  #00000004
        :pswitch_3a  #00000005
        :pswitch_32  #00000006
        :pswitch_2a  #00000007
        :pswitch_1e  #00000008
    .end packed-switch
.end method

.method public final n(Lj$/time/LocalDate;)I
    .registers 4

    .prologue
    iget v0, p0, Lj$/time/LocalDate;->a:I

    iget v1, p1, Lj$/time/LocalDate;->a:I

    sub-int/2addr v0, v1

    if-nez v0, :cond_14

    iget-short v0, p0, Lj$/time/LocalDate;->b:S

    iget-short v1, p1, Lj$/time/LocalDate;->b:S

    sub-int/2addr v0, v1

    if-nez v0, :cond_14

    iget-short p0, p0, Lj$/time/LocalDate;->c:S

    iget-short p1, p1, Lj$/time/LocalDate;->c:S

    sub-int/2addr p0, p1

    return p0

    :cond_14
    return v0
.end method

.method public final toString()Ljava/lang/String;
    .registers 7

    .prologue
    iget v0, p0, Lj$/time/LocalDate;->a:I

    iget-short v1, p0, Lj$/time/LocalDate;->b:S

    iget-short p0, p0, Lj$/time/LocalDate;->c:S

    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    move-result v2

    new-instance v3, Ljava/lang/StringBuilder;

    const/16 v4, 0xa

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(I)V

    const/16 v5, 0x3e8

    if-ge v2, v5, :cond_2b

    if-gez v0, :cond_21

    add-int/lit16 v0, v0, -0x2710

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v0, 0x1

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->deleteCharAt(I)Ljava/lang/StringBuilder;

    goto :goto_37

    :cond_21
    add-int/lit16 v0, v0, 0x2710

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->deleteCharAt(I)Ljava/lang/StringBuilder;

    goto :goto_37

    :cond_2b
    const/16 v2, 0x270f

    if-le v0, v2, :cond_34

    const/16 v2, 0x2b

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :cond_34
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    :goto_37
    const-string v0, "-"

    const-string v2, "-0"

    if-ge v1, v4, :cond_3f

    move-object v5, v2

    goto :goto_40

    :cond_3f
    move-object v5, v0

    :goto_40
    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    if-ge p0, v4, :cond_49

    move-object v0, v2

    :cond_49
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public final z()J
    .registers 13

    .prologue
    iget v0, p0, Lj$/time/LocalDate;->a:I

    int-to-long v0, v0

    iget-short v2, p0, Lj$/time/LocalDate;->b:S

    int-to-long v2, v2

    const-wide/16 v4, 0x16d

    mul-long/2addr v4, v0

    const-wide/16 v6, 0x0

    cmp-long v6, v0, v6

    if-ltz v6, :cond_25

    const-wide/16 v6, 0x3

    add-long/2addr v6, v0

    const-wide/16 v8, 0x4

    div-long/2addr v6, v8

    const-wide/16 v8, 0x63

    add-long/2addr v8, v0

    const-wide/16 v10, 0x64

    div-long/2addr v8, v10

    sub-long/2addr v6, v8

    const-wide/16 v8, 0x18f

    add-long/2addr v0, v8

    const-wide/16 v8, 0x190

    div-long/2addr v0, v8

    add-long/2addr v0, v6

    add-long/2addr v0, v4

    goto :goto_34

    :cond_25
    const-wide/16 v6, -0x4

    div-long v6, v0, v6

    const-wide/16 v8, -0x64

    div-long v8, v0, v8

    sub-long/2addr v6, v8

    const-wide/16 v8, -0x190

    div-long/2addr v0, v8

    add-long/2addr v0, v6

    sub-long v0, v4, v0

    :goto_34
    const-wide/16 v4, 0x16f

    mul-long/2addr v4, v2

    const-wide/16 v6, 0x16a

    sub-long/2addr v4, v6

    const-wide/16 v6, 0xc

    div-long/2addr v4, v6

    add-long/2addr v4, v0

    iget-short v0, p0, Lj$/time/LocalDate;->c:S

    add-int/lit8 v0, v0, -0x1

    int-to-long v0, v0

    add-long/2addr v4, v0

    const-wide/16 v0, 0x2

    cmp-long v2, v2, v0

    if-lez v2, :cond_57

    const-wide/16 v2, 0x1

    sub-long v2, v4, v2

    invoke-virtual {p0}, Lj$/time/LocalDate;->M()Z

    move-result p0

    if-nez p0, :cond_56

    sub-long/2addr v4, v0

    goto :goto_57

    :cond_56
    move-wide v4, v2

    :cond_57
    :goto_57
    const-wide/32 v0, 0xafaa8

    sub-long/2addr v4, v0

    return-wide v4
.end method
