.class public final Lj$/time/chrono/d0;
.super Lj$/time/chrono/d;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field private static final serialVersionUID:J = 0x120bd9be64a3de1eL


# instance fields
.field public final transient a:Lj$/time/LocalDate;


# direct methods
.method public constructor <init>(Lj$/time/LocalDate;)V
    .registers 3

    invoke-direct {p0}, Lj$/time/chrono/d;-><init>()V

    const-string v0, "isoDate"

    invoke-static {p1, v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    iput-object p1, p0, Lj$/time/chrono/d0;->a:Lj$/time/LocalDate;

    return-void
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .registers 2

    new-instance p0, Ljava/io/InvalidObjectException;

    const-string p1, "Deserialization via serialization delegate"

    invoke-direct {p0, p1}, Ljava/io/InvalidObjectException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private writeReplace()Ljava/lang/Object;
    .registers 3

    new-instance v0, Lj$/time/chrono/f0;

    const/4 v1, 0x7

    invoke-direct {v0, v1, p0}, Lj$/time/chrono/f0;-><init>(BLjava/lang/Object;)V

    return-object v0
.end method


# virtual methods
.method public final A(Lj$/time/LocalTime;)Lj$/time/chrono/e;
    .registers 3

    new-instance v0, Lj$/time/chrono/g;

    invoke-direct {v0, p0, p1}, Lj$/time/chrono/g;-><init>(Lj$/time/chrono/b;Lj$/time/LocalTime;)V

    return-object v0
.end method

.method public final C()Lj$/time/chrono/n;
    .registers 2

    .prologue
    invoke-virtual {p0}, Lj$/time/chrono/d0;->K()I

    move-result p0

    const/4 v0, 0x1

    if-lt p0, v0, :cond_a

    sget-object p0, Lj$/time/chrono/e0;->ROC:Lj$/time/chrono/e0;

    return-object p0

    :cond_a
    sget-object p0, Lj$/time/chrono/e0;->BEFORE_ROC:Lj$/time/chrono/e0;

    return-object p0
.end method

.method public final E(J)Lj$/time/chrono/b;
    .registers 4

    iget-object v0, p0, Lj$/time/chrono/d0;->a:Lj$/time/LocalDate;

    invoke-virtual {v0, p1, p2}, Lj$/time/LocalDate;->R(J)Lj$/time/LocalDate;

    move-result-object p1

    invoke-virtual {p0, p1}, Lj$/time/chrono/d0;->M(Lj$/time/LocalDate;)Lj$/time/chrono/d0;

    move-result-object p0

    return-object p0
.end method

.method public final H(J)Lj$/time/chrono/b;
    .registers 4

    iget-object v0, p0, Lj$/time/chrono/d0;->a:Lj$/time/LocalDate;

    invoke-virtual {v0, p1, p2}, Lj$/time/LocalDate;->S(J)Lj$/time/LocalDate;

    move-result-object p1

    invoke-virtual {p0, p1}, Lj$/time/chrono/d0;->M(Lj$/time/LocalDate;)Lj$/time/chrono/d0;

    move-result-object p0

    return-object p0
.end method

.method public final I(J)Lj$/time/chrono/b;
    .registers 4

    iget-object v0, p0, Lj$/time/chrono/d0;->a:Lj$/time/LocalDate;

    invoke-virtual {v0, p1, p2}, Lj$/time/LocalDate;->T(J)Lj$/time/LocalDate;

    move-result-object p1

    invoke-virtual {p0, p1}, Lj$/time/chrono/d0;->M(Lj$/time/LocalDate;)Lj$/time/chrono/d0;

    move-result-object p0

    return-object p0
.end method

.method public final J(Lj$/time/temporal/m;)Lj$/time/chrono/b;
    .registers 2

    invoke-super {p0, p1}, Lj$/time/chrono/d;->J(Lj$/time/temporal/m;)Lj$/time/chrono/b;

    move-result-object p0

    check-cast p0, Lj$/time/chrono/d0;

    return-object p0
.end method

.method public final K()I
    .registers 1

    iget-object p0, p0, Lj$/time/chrono/d0;->a:Lj$/time/LocalDate;

    invoke-virtual {p0}, Lj$/time/LocalDate;->getYear()I

    move-result p0

    add-int/lit16 p0, p0, -0x777

    return p0
.end method

.method public final L(JLj$/time/temporal/o;)Lj$/time/chrono/d0;
    .registers 11

    .prologue
    instance-of v0, p3, Lj$/time/temporal/a;

    if-eqz v0, :cond_a3

    move-object v0, p3

    check-cast v0, Lj$/time/temporal/a;

    invoke-virtual {p0, v0}, Lj$/time/chrono/d0;->f(Lj$/time/temporal/o;)J

    move-result-wide v1

    cmp-long v1, v1, p1

    if-nez v1, :cond_10

    return-object p0

    :cond_10
    sget-object v1, Lj$/time/chrono/c0;->a:[I

    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v2

    aget v2, v1, v2

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-eq v2, v5, :cond_4d

    const/4 v6, 0x5

    if-eq v2, v6, :cond_25

    if-eq v2, v4, :cond_4d

    if-eq v2, v3, :cond_4d

    goto :goto_63

    :cond_25
    sget-object p3, Lj$/time/chrono/b0;->c:Lj$/time/chrono/b0;

    invoke-virtual {p3, v0}, Lj$/time/chrono/b0;->u(Lj$/time/temporal/a;)Lj$/time/temporal/r;

    move-result-object p3

    invoke-virtual {p3, p1, p2, v0}, Lj$/time/temporal/r;->b(JLj$/time/temporal/o;)V

    invoke-virtual {p0}, Lj$/time/chrono/d0;->K()I

    move-result p3

    int-to-long v0, p3

    const-wide/16 v2, 0xc

    mul-long/2addr v0, v2

    iget-object p3, p0, Lj$/time/chrono/d0;->a:Lj$/time/LocalDate;

    invoke-virtual {p3}, Lj$/time/LocalDate;->getMonthValue()I

    move-result p3

    int-to-long v2, p3

    add-long/2addr v0, v2

    const-wide/16 v2, 0x1

    sub-long/2addr v0, v2

    sub-long/2addr p1, v0

    iget-object p3, p0, Lj$/time/chrono/d0;->a:Lj$/time/LocalDate;

    invoke-virtual {p3, p1, p2}, Lj$/time/LocalDate;->S(J)Lj$/time/LocalDate;

    move-result-object p1

    invoke-virtual {p0, p1}, Lj$/time/chrono/d0;->M(Lj$/time/LocalDate;)Lj$/time/chrono/d0;

    move-result-object p0

    return-object p0

    :cond_4d
    sget-object v2, Lj$/time/chrono/b0;->c:Lj$/time/chrono/b0;

    invoke-virtual {v2, v0}, Lj$/time/chrono/b0;->u(Lj$/time/temporal/a;)Lj$/time/temporal/r;

    move-result-object v2

    invoke-virtual {v2, p1, p2, v0}, Lj$/time/temporal/r;->a(JLj$/time/temporal/o;)I

    move-result v2

    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    aget v0, v1, v0

    if-eq v0, v5, :cond_8c

    if-eq v0, v4, :cond_7f

    if-eq v0, v3, :cond_6e

    :goto_63
    iget-object v0, p0, Lj$/time/chrono/d0;->a:Lj$/time/LocalDate;

    invoke-virtual {v0, p1, p2, p3}, Lj$/time/LocalDate;->V(JLj$/time/temporal/o;)Lj$/time/LocalDate;

    move-result-object p1

    invoke-virtual {p0, p1}, Lj$/time/chrono/d0;->M(Lj$/time/LocalDate;)Lj$/time/chrono/d0;

    move-result-object p0

    return-object p0

    :cond_6e
    iget-object p1, p0, Lj$/time/chrono/d0;->a:Lj$/time/LocalDate;

    invoke-virtual {p0}, Lj$/time/chrono/d0;->K()I

    move-result p2

    rsub-int p2, p2, 0x778

    invoke-virtual {p1, p2}, Lj$/time/LocalDate;->Y(I)Lj$/time/LocalDate;

    move-result-object p1

    invoke-virtual {p0, p1}, Lj$/time/chrono/d0;->M(Lj$/time/LocalDate;)Lj$/time/chrono/d0;

    move-result-object p0

    return-object p0

    :cond_7f
    iget-object p1, p0, Lj$/time/chrono/d0;->a:Lj$/time/LocalDate;

    add-int/lit16 v2, v2, 0x777

    invoke-virtual {p1, v2}, Lj$/time/LocalDate;->Y(I)Lj$/time/LocalDate;

    move-result-object p1

    invoke-virtual {p0, p1}, Lj$/time/chrono/d0;->M(Lj$/time/LocalDate;)Lj$/time/chrono/d0;

    move-result-object p0

    return-object p0

    :cond_8c
    iget-object p1, p0, Lj$/time/chrono/d0;->a:Lj$/time/LocalDate;

    invoke-virtual {p0}, Lj$/time/chrono/d0;->K()I

    move-result p2

    const/4 p3, 0x1

    if-lt p2, p3, :cond_98

    add-int/lit16 v2, v2, 0x777

    goto :goto_9a

    :cond_98
    rsub-int v2, v2, 0x778

    :goto_9a
    invoke-virtual {p1, v2}, Lj$/time/LocalDate;->Y(I)Lj$/time/LocalDate;

    move-result-object p1

    invoke-virtual {p0, p1}, Lj$/time/chrono/d0;->M(Lj$/time/LocalDate;)Lj$/time/chrono/d0;

    move-result-object p0

    return-object p0

    :cond_a3
    invoke-super {p0, p1, p2, p3}, Lj$/time/chrono/d;->g(JLj$/time/temporal/o;)Lj$/time/chrono/b;

    move-result-object p0

    check-cast p0, Lj$/time/chrono/d0;

    return-object p0
.end method

.method public final M(Lj$/time/LocalDate;)Lj$/time/chrono/d0;
    .registers 3

    .prologue
    iget-object v0, p0, Lj$/time/chrono/d0;->a:Lj$/time/LocalDate;

    invoke-virtual {p1, v0}, Lj$/time/LocalDate;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_9

    return-object p0

    :cond_9
    new-instance p0, Lj$/time/chrono/d0;

    invoke-direct {p0, p1}, Lj$/time/chrono/d0;-><init>(Lj$/time/LocalDate;)V

    return-object p0
.end method

.method public final a(JLj$/time/temporal/TemporalUnit;)Lj$/time/chrono/b;
    .registers 4

    invoke-super {p0, p1, p2, p3}, Lj$/time/chrono/d;->a(JLj$/time/temporal/TemporalUnit;)Lj$/time/chrono/b;

    move-result-object p0

    check-cast p0, Lj$/time/chrono/d0;

    return-object p0
.end method

.method public final a(JLj$/time/temporal/TemporalUnit;)Lj$/time/temporal/Temporal;
    .registers 4

    invoke-super {p0, p1, p2, p3}, Lj$/time/chrono/d;->a(JLj$/time/temporal/TemporalUnit;)Lj$/time/chrono/b;

    move-result-object p0

    check-cast p0, Lj$/time/chrono/d0;

    return-object p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 3

    .prologue
    if-ne p0, p1, :cond_4

    const/4 p0, 0x1

    return p0

    :cond_4
    instance-of v0, p1, Lj$/time/chrono/d0;

    if-eqz v0, :cond_13

    check-cast p1, Lj$/time/chrono/d0;

    iget-object p0, p0, Lj$/time/chrono/d0;->a:Lj$/time/LocalDate;

    iget-object p1, p1, Lj$/time/chrono/d0;->a:Lj$/time/LocalDate;

    invoke-virtual {p0, p1}, Lj$/time/LocalDate;->equals(Ljava/lang/Object;)Z

    move-result p0

    return p0

    :cond_13
    const/4 p0, 0x0

    return p0
.end method

.method public final f(Lj$/time/temporal/o;)J
    .registers 6

    .prologue
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_52

    sget-object v0, Lj$/time/chrono/c0;->a:[I

    move-object v1, p1

    check-cast v1, Lj$/time/temporal/a;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget v0, v0, v1

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eq v0, v1, :cond_47

    const/4 v1, 0x5

    if-eq v0, v1, :cond_33

    const/4 v1, 0x6

    if-eq v0, v1, :cond_2d

    const/4 v1, 0x7

    if-eq v0, v1, :cond_23

    iget-object p0, p0, Lj$/time/chrono/d0;->a:Lj$/time/LocalDate;

    invoke-virtual {p0, p1}, Lj$/time/LocalDate;->f(Lj$/time/temporal/o;)J

    move-result-wide p0

    return-wide p0

    :cond_23
    invoke-virtual {p0}, Lj$/time/chrono/d0;->K()I

    move-result p0

    if-lt p0, v2, :cond_2a

    goto :goto_2b

    :cond_2a
    const/4 v2, 0x0

    :goto_2b
    int-to-long p0, v2

    return-wide p0

    :cond_2d
    invoke-virtual {p0}, Lj$/time/chrono/d0;->K()I

    move-result p0

    int-to-long p0, p0

    return-wide p0

    :cond_33
    invoke-virtual {p0}, Lj$/time/chrono/d0;->K()I

    move-result p1

    int-to-long v0, p1

    const-wide/16 v2, 0xc

    mul-long/2addr v0, v2

    iget-object p0, p0, Lj$/time/chrono/d0;->a:Lj$/time/LocalDate;

    invoke-virtual {p0}, Lj$/time/LocalDate;->getMonthValue()I

    move-result p0

    int-to-long p0, p0

    add-long/2addr v0, p0

    const-wide/16 p0, 0x1

    sub-long/2addr v0, p0

    return-wide v0

    :cond_47
    invoke-virtual {p0}, Lj$/time/chrono/d0;->K()I

    move-result p0

    if-lt p0, v2, :cond_4e

    goto :goto_50

    :cond_4e
    rsub-int/lit8 p0, p0, 0x1

    :goto_50
    int-to-long p0, p0

    return-wide p0

    :cond_52
    invoke-interface {p1, p0}, Lj$/time/temporal/o;->E(Lj$/time/temporal/l;)J

    move-result-wide p0

    return-wide p0
.end method

.method public final bridge synthetic g(JLj$/time/temporal/o;)Lj$/time/chrono/b;
    .registers 4

    invoke-virtual {p0, p1, p2, p3}, Lj$/time/chrono/d0;->L(JLj$/time/temporal/o;)Lj$/time/chrono/d0;

    move-result-object p0

    return-object p0
.end method

.method public final bridge synthetic g(JLj$/time/temporal/o;)Lj$/time/temporal/Temporal;
    .registers 4

    invoke-virtual {p0, p1, p2, p3}, Lj$/time/chrono/d0;->L(JLj$/time/temporal/o;)Lj$/time/chrono/d0;

    move-result-object p0

    return-object p0
.end method

.method public final getChronology()Lj$/time/chrono/m;
    .registers 1

    sget-object p0, Lj$/time/chrono/b0;->c:Lj$/time/chrono/b0;

    return-object p0
.end method

.method public final h(Lj$/time/LocalDate;)Lj$/time/temporal/Temporal;
    .registers 2

    invoke-super {p0, p1}, Lj$/time/chrono/d;->J(Lj$/time/temporal/m;)Lj$/time/chrono/b;

    move-result-object p0

    check-cast p0, Lj$/time/chrono/d0;

    return-object p0
.end method

.method public final hashCode()I
    .registers 2

    sget-object v0, Lj$/time/chrono/b0;->c:Lj$/time/chrono/b0;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p0, Lj$/time/chrono/d0;->a:Lj$/time/LocalDate;

    invoke-virtual {p0}, Lj$/time/LocalDate;->hashCode()I

    move-result p0

    const v0, -0x769fa231

    xor-int/2addr p0, v0

    return p0
.end method

.method public final i(Lj$/time/temporal/o;)Lj$/time/temporal/r;
    .registers 5

    .prologue
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_58

    invoke-interface {p0, p1}, Lj$/time/chrono/b;->e(Lj$/time/temporal/o;)Z

    move-result v0

    if-eqz v0, :cond_4c

    move-object v0, p1

    check-cast v0, Lj$/time/temporal/a;

    sget-object v1, Lj$/time/chrono/c0;->a:[I

    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v2

    aget v1, v1, v2

    const/4 v2, 0x1

    if-eq v1, v2, :cond_45

    const/4 v2, 0x2

    if-eq v1, v2, :cond_45

    const/4 v2, 0x3

    if-eq v1, v2, :cond_45

    const/4 p1, 0x4

    if-eq v1, p1, :cond_28

    sget-object p0, Lj$/time/chrono/b0;->c:Lj$/time/chrono/b0;

    invoke-virtual {p0, v0}, Lj$/time/chrono/b0;->u(Lj$/time/temporal/a;)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_28
    sget-object p1, Lj$/time/temporal/a;->YEAR:Lj$/time/temporal/a;

    iget-object p1, p1, Lj$/time/temporal/a;->b:Lj$/time/temporal/r;

    invoke-virtual {p0}, Lj$/time/chrono/d0;->K()I

    move-result p0

    if-gtz p0, :cond_39

    iget-wide p0, p1, Lj$/time/temporal/r;->a:J

    neg-long p0, p0

    const-wide/16 v0, 0x778

    add-long/2addr p0, v0

    goto :goto_3e

    :cond_39
    iget-wide p0, p1, Lj$/time/temporal/r;->d:J

    const-wide/16 v0, 0x777

    sub-long/2addr p0, v0

    :goto_3e
    const-wide/16 v0, 0x1

    invoke-static {v0, v1, p0, p1}, Lj$/time/temporal/r;->e(JJ)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_45
    iget-object p0, p0, Lj$/time/chrono/d0;->a:Lj$/time/LocalDate;

    invoke-virtual {p0, p1}, Lj$/time/LocalDate;->i(Lj$/time/temporal/o;)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_4c
    new-instance p0, Lj$/time/temporal/q;

    const-string v0, "Unsupported field: "

    invoke-static {v0, p1}, Lj$/time/d;->a(Ljava/lang/String;Lj$/time/temporal/o;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_58
    invoke-interface {p1, p0}, Lj$/time/temporal/o;->v(Lj$/time/temporal/l;)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0
.end method

.method public final j(JLj$/time/temporal/TemporalUnit;)Lj$/time/chrono/b;
    .registers 4

    invoke-super {p0, p1, p2, p3}, Lj$/time/chrono/d;->j(JLj$/time/temporal/TemporalUnit;)Lj$/time/chrono/b;

    move-result-object p0

    check-cast p0, Lj$/time/chrono/d0;

    return-object p0
.end method

.method public final j(JLj$/time/temporal/TemporalUnit;)Lj$/time/temporal/Temporal;
    .registers 4

    invoke-super {p0, p1, p2, p3}, Lj$/time/chrono/d;->j(JLj$/time/temporal/TemporalUnit;)Lj$/time/chrono/b;

    move-result-object p0

    check-cast p0, Lj$/time/chrono/d0;

    return-object p0
.end method

.method public final z()J
    .registers 3

    iget-object p0, p0, Lj$/time/chrono/d0;->a:Lj$/time/LocalDate;

    invoke-virtual {p0}, Lj$/time/LocalDate;->z()J

    move-result-wide v0

    return-wide v0
.end method
