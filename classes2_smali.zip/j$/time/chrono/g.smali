.class public final Lj$/time/chrono/g;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lj$/time/chrono/e;
.implements Lj$/time/temporal/Temporal;
.implements Lj$/time/temporal/m;
.implements Ljava/io/Serializable;


# static fields
.field private static final serialVersionUID:J = 0x3f3a2d24660eebe2L


# instance fields
.field public final transient a:Lj$/time/chrono/b;

.field public final transient b:Lj$/time/LocalTime;


# direct methods
.method public constructor <init>(Lj$/time/chrono/b;Lj$/time/LocalTime;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string v0, "time"

    invoke-static {p2, v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    iput-object p1, p0, Lj$/time/chrono/g;->a:Lj$/time/chrono/b;

    iput-object p2, p0, Lj$/time/chrono/g;->b:Lj$/time/LocalTime;

    return-void
.end method

.method public static n(Lj$/time/chrono/m;Lj$/time/temporal/Temporal;)Lj$/time/chrono/g;
    .registers 3

    .prologue
    check-cast p1, Lj$/time/chrono/g;

    invoke-interface {p1}, Lj$/time/chrono/e;->getChronology()Lj$/time/chrono/m;

    move-result-object v0

    invoke-interface {p0, v0}, Lj$/time/chrono/m;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_d

    return-object p1

    :cond_d
    invoke-interface {p0}, Lj$/time/chrono/m;->getId()Ljava/lang/String;

    move-result-object p0

    invoke-interface {p1}, Lj$/time/chrono/e;->getChronology()Lj$/time/chrono/m;

    move-result-object p1

    invoke-interface {p1}, Lj$/time/chrono/m;->getId()Ljava/lang/String;

    move-result-object p1

    const-string v0, "Chronology mismatch, required: "

    invoke-static {v0, p0, p1}, Lj$/time/h;->g(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .registers 2

    new-instance p0, Ljava/io/InvalidObjectException;

    const-string p1, "Deserialization via serialization delegate"

    invoke-direct {p0, p1}, Ljava/io/InvalidObjectException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private writeReplace()Ljava/lang/Object;
    .registers 3

    new-instance v0, Lj$/time/chrono/f0;

    const/4 v1, 0x2

    invoke-direct {v0, v1, p0}, Lj$/time/chrono/f0;-><init>(BLjava/lang/Object;)V

    return-object v0
.end method


# virtual methods
.method public final E(Lj$/time/chrono/b;JJJJ)Lj$/time/chrono/g;
    .registers 28

    .prologue
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    or-long v2, p2, p4

    or-long v2, v2, p6

    or-long v2, v2, p8

    const-wide/16 v4, 0x0

    cmp-long v2, v2, v4

    iget-object v3, v0, Lj$/time/chrono/g;->b:Lj$/time/LocalTime;

    if-nez v2, :cond_17

    invoke-virtual {v0, v1, v3}, Lj$/time/chrono/g;->I(Lj$/time/temporal/Temporal;Lj$/time/LocalTime;)Lj$/time/chrono/g;

    move-result-object v0

    return-object v0

    :cond_17
    const-wide v4, 0x4e94914f0000L

    div-long v6, p8, v4

    const-wide/32 v8, 0x15180

    div-long v10, p6, v8

    add-long/2addr v10, v6

    const-wide/16 v6, 0x5a0

    div-long v12, p4, v6

    add-long/2addr v12, v10

    const-wide/16 v10, 0x18

    div-long v14, p2, v10

    add-long/2addr v14, v12

    rem-long v12, p8, v4

    rem-long v8, p6, v8

    const-wide/32 v16, 0x3b9aca00

    mul-long v8, v8, v16

    add-long/2addr v8, v12

    rem-long v6, p4, v6

    const-wide v12, 0xdf8475800L

    mul-long/2addr v6, v12

    add-long/2addr v6, v8

    rem-long v8, p2, v10

    const-wide v10, 0x34630b8a000L

    mul-long/2addr v8, v10

    add-long/2addr v8, v6

    invoke-virtual {v3}, Lj$/time/LocalTime;->P()J

    move-result-wide v2

    add-long/2addr v8, v2

    invoke-static {v8, v9, v4, v5}, Ljava/lang/Math;->floorDiv(JJ)J

    move-result-wide v6

    add-long/2addr v6, v14

    invoke-static {v8, v9, v4, v5}, Ljava/lang/Math;->floorMod(JJ)J

    move-result-wide v4

    cmp-long v2, v4, v2

    if-nez v2, :cond_5f

    iget-object v2, v0, Lj$/time/chrono/g;->b:Lj$/time/LocalTime;

    goto :goto_63

    :cond_5f
    invoke-static {v4, v5}, Lj$/time/LocalTime;->I(J)Lj$/time/LocalTime;

    move-result-object v2

    :goto_63
    sget-object v3, Lj$/time/temporal/ChronoUnit;->DAYS:Lj$/time/temporal/ChronoUnit;

    invoke-interface {v1, v6, v7, v3}, Lj$/time/chrono/b;->j(JLj$/time/temporal/TemporalUnit;)Lj$/time/chrono/b;

    move-result-object v1

    invoke-virtual {v0, v1, v2}, Lj$/time/chrono/g;->I(Lj$/time/temporal/Temporal;Lj$/time/LocalTime;)Lj$/time/chrono/g;

    move-result-object v0

    return-object v0
.end method

.method public final H(JLj$/time/temporal/o;)Lj$/time/chrono/g;
    .registers 6

    .prologue
    instance-of v0, p3, Lj$/time/temporal/a;

    if-eqz v0, :cond_25

    move-object v0, p3

    check-cast v0, Lj$/time/temporal/a;

    invoke-virtual {v0}, Lj$/time/temporal/a;->J()Z

    move-result v0

    iget-object v1, p0, Lj$/time/chrono/g;->a:Lj$/time/chrono/b;

    if-eqz v0, :cond_1a

    iget-object v0, p0, Lj$/time/chrono/g;->b:Lj$/time/LocalTime;

    invoke-virtual {v0, p1, p2, p3}, Lj$/time/LocalTime;->R(JLj$/time/temporal/o;)Lj$/time/LocalTime;

    move-result-object p1

    invoke-virtual {p0, v1, p1}, Lj$/time/chrono/g;->I(Lj$/time/temporal/Temporal;Lj$/time/LocalTime;)Lj$/time/chrono/g;

    move-result-object p0

    return-object p0

    :cond_1a
    invoke-interface {v1, p1, p2, p3}, Lj$/time/chrono/b;->g(JLj$/time/temporal/o;)Lj$/time/chrono/b;

    move-result-object p1

    iget-object p2, p0, Lj$/time/chrono/g;->b:Lj$/time/LocalTime;

    invoke-virtual {p0, p1, p2}, Lj$/time/chrono/g;->I(Lj$/time/temporal/Temporal;Lj$/time/LocalTime;)Lj$/time/chrono/g;

    move-result-object p0

    return-object p0

    :cond_25
    iget-object v0, p0, Lj$/time/chrono/g;->a:Lj$/time/chrono/b;

    invoke-interface {v0}, Lj$/time/chrono/b;->getChronology()Lj$/time/chrono/m;

    move-result-object v0

    invoke-interface {p3, p0, p1, p2}, Lj$/time/temporal/o;->H(Lj$/time/temporal/Temporal;J)Lj$/time/temporal/Temporal;

    move-result-object p0

    invoke-static {v0, p0}, Lj$/time/chrono/g;->n(Lj$/time/chrono/m;Lj$/time/temporal/Temporal;)Lj$/time/chrono/g;

    move-result-object p0

    return-object p0
.end method

.method public final I(Lj$/time/temporal/Temporal;Lj$/time/LocalTime;)Lj$/time/chrono/g;
    .registers 5

    .prologue
    iget-object v0, p0, Lj$/time/chrono/g;->a:Lj$/time/chrono/b;

    if-ne v0, p1, :cond_9

    iget-object v1, p0, Lj$/time/chrono/g;->b:Lj$/time/LocalTime;

    if-ne v1, p2, :cond_9

    return-object p0

    :cond_9
    invoke-interface {v0}, Lj$/time/chrono/b;->getChronology()Lj$/time/chrono/m;

    move-result-object p0

    invoke-static {p0, p1}, Lj$/time/chrono/d;->n(Lj$/time/chrono/m;Lj$/time/temporal/Temporal;)Lj$/time/chrono/b;

    move-result-object p0

    new-instance p1, Lj$/time/chrono/g;

    invoke-direct {p1, p0, p2}, Lj$/time/chrono/g;-><init>(Lj$/time/chrono/b;Lj$/time/LocalTime;)V

    return-object p1
.end method

.method public final d(Lj$/time/temporal/o;)I
    .registers 5

    .prologue
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_1b

    move-object v0, p1

    check-cast v0, Lj$/time/temporal/a;

    invoke-virtual {v0}, Lj$/time/temporal/a;->J()Z

    move-result v0

    if-eqz v0, :cond_14

    iget-object p0, p0, Lj$/time/chrono/g;->b:Lj$/time/LocalTime;

    invoke-virtual {p0, p1}, Lj$/time/LocalTime;->d(Lj$/time/temporal/o;)I

    move-result p0

    return p0

    :cond_14
    iget-object p0, p0, Lj$/time/chrono/g;->a:Lj$/time/chrono/b;

    invoke-interface {p0, p1}, Lj$/time/temporal/l;->d(Lj$/time/temporal/o;)I

    move-result p0

    return p0

    :cond_1b
    invoke-virtual {p0, p1}, Lj$/time/chrono/g;->i(Lj$/time/temporal/o;)Lj$/time/temporal/r;

    move-result-object v0

    invoke-virtual {p0, p1}, Lj$/time/chrono/g;->f(Lj$/time/temporal/o;)J

    move-result-wide v1

    invoke-virtual {v0, v1, v2, p1}, Lj$/time/temporal/r;->a(JLj$/time/temporal/o;)I

    move-result p0

    return p0
.end method

.method public final e(Lj$/time/temporal/o;)Z
    .registers 3

    .prologue
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_13

    check-cast p1, Lj$/time/temporal/a;

    invoke-virtual {p1}, Lj$/time/temporal/a;->isDateBased()Z

    move-result p0

    if-nez p0, :cond_1b

    invoke-virtual {p1}, Lj$/time/temporal/a;->J()Z

    move-result p0

    if-eqz p0, :cond_1d

    goto :goto_1b

    :cond_13
    if-eqz p1, :cond_1d

    invoke-interface {p1, p0}, Lj$/time/temporal/o;->n(Lj$/time/temporal/l;)Z

    move-result p0

    if-eqz p0, :cond_1d

    :cond_1b
    :goto_1b
    const/4 p0, 0x1

    return p0

    :cond_1d
    const/4 p0, 0x0

    return p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 5

    .prologue
    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lj$/time/chrono/e;

    const/4 v2, 0x0

    if-eqz v1, :cond_12

    check-cast p1, Lj$/time/chrono/e;

    invoke-interface {p0, p1}, Lj$/time/chrono/e;->D(Lj$/time/chrono/e;)I

    move-result p0

    if-nez p0, :cond_12

    return v0

    :cond_12
    return v2
.end method

.method public final f(Lj$/time/temporal/o;)J
    .registers 3

    .prologue
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_1b

    move-object v0, p1

    check-cast v0, Lj$/time/temporal/a;

    invoke-virtual {v0}, Lj$/time/temporal/a;->J()Z

    move-result v0

    if-eqz v0, :cond_14

    iget-object p0, p0, Lj$/time/chrono/g;->b:Lj$/time/LocalTime;

    invoke-virtual {p0, p1}, Lj$/time/LocalTime;->f(Lj$/time/temporal/o;)J

    move-result-wide p0

    return-wide p0

    :cond_14
    iget-object p0, p0, Lj$/time/chrono/g;->a:Lj$/time/chrono/b;

    invoke-interface {p0, p1}, Lj$/time/temporal/l;->f(Lj$/time/temporal/o;)J

    move-result-wide p0

    return-wide p0

    :cond_1b
    invoke-interface {p1, p0}, Lj$/time/temporal/o;->E(Lj$/time/temporal/l;)J

    move-result-wide p0

    return-wide p0
.end method

.method public final bridge synthetic g(JLj$/time/temporal/o;)Lj$/time/temporal/Temporal;
    .registers 4

    invoke-virtual {p0, p1, p2, p3}, Lj$/time/chrono/g;->H(JLj$/time/temporal/o;)Lj$/time/chrono/g;

    move-result-object p0

    return-object p0
.end method

.method public final h(Lj$/time/LocalDate;)Lj$/time/temporal/Temporal;
    .registers 3

    iget-object v0, p0, Lj$/time/chrono/g;->b:Lj$/time/LocalTime;

    invoke-virtual {p0, p1, v0}, Lj$/time/chrono/g;->I(Lj$/time/temporal/Temporal;Lj$/time/LocalTime;)Lj$/time/chrono/g;

    move-result-object p0

    return-object p0
.end method

.method public final hashCode()I
    .registers 2

    iget-object v0, p0, Lj$/time/chrono/g;->a:Lj$/time/chrono/b;

    invoke-interface {v0}, Lj$/time/chrono/b;->hashCode()I

    move-result v0

    iget-object p0, p0, Lj$/time/chrono/g;->b:Lj$/time/LocalTime;

    invoke-virtual {p0}, Lj$/time/LocalTime;->hashCode()I

    move-result p0

    xor-int/2addr p0, v0

    return p0
.end method

.method public final i(Lj$/time/temporal/o;)Lj$/time/temporal/r;
    .registers 3

    .prologue
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_17

    move-object v0, p1

    check-cast v0, Lj$/time/temporal/a;

    invoke-virtual {v0}, Lj$/time/temporal/a;->J()Z

    move-result v0

    if-eqz v0, :cond_14

    iget-object p0, p0, Lj$/time/chrono/g;->b:Lj$/time/LocalTime;

    :goto_f
    invoke-interface {p0, p1}, Lj$/time/temporal/l;->i(Lj$/time/temporal/o;)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_14
    iget-object p0, p0, Lj$/time/chrono/g;->a:Lj$/time/chrono/b;

    goto :goto_f

    :cond_17
    invoke-interface {p1, p0}, Lj$/time/temporal/o;->v(Lj$/time/temporal/l;)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0
.end method

.method public final bridge synthetic j(JLj$/time/temporal/TemporalUnit;)Lj$/time/temporal/Temporal;
    .registers 4

    invoke-virtual {p0, p1, p2, p3}, Lj$/time/chrono/g;->v(JLj$/time/temporal/TemporalUnit;)Lj$/time/chrono/g;

    move-result-object p0

    return-object p0
.end method

.method public final k(Lj$/time/temporal/Temporal;Lj$/time/temporal/TemporalUnit;)J
    .registers 9

    .prologue
    const-string v0, "endExclusive"

    invoke-static {p1, v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    invoke-interface {p0}, Lj$/time/chrono/e;->getChronology()Lj$/time/chrono/m;

    move-result-object v0

    invoke-interface {v0, p1}, Lj$/time/chrono/m;->r(Lj$/time/temporal/Temporal;)Lj$/time/chrono/e;

    move-result-object p1

    instance-of v0, p2, Lj$/time/temporal/ChronoUnit;

    if-eqz v0, :cond_99

    move-object v0, p2

    check-cast v0, Lj$/time/temporal/ChronoUnit;

    sget-object v1, Lj$/time/temporal/ChronoUnit;->DAYS:Lj$/time/temporal/ChronoUnit;

    invoke-virtual {v0, v1}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    move-result v2

    if-gez v2, :cond_7c

    sget-object v1, Lj$/time/temporal/a;->EPOCH_DAY:Lj$/time/temporal/a;

    invoke-interface {p1, v1}, Lj$/time/temporal/l;->f(Lj$/time/temporal/o;)J

    move-result-wide v2

    iget-object v4, p0, Lj$/time/chrono/g;->a:Lj$/time/chrono/b;

    invoke-interface {v4, v1}, Lj$/time/temporal/l;->f(Lj$/time/temporal/o;)J

    move-result-wide v4

    sub-long/2addr v2, v4

    sget-object v1, Lj$/time/chrono/f;->a:[I

    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    aget v0, v1, v0

    packed-switch v0, :pswitch_data_a4

    goto :goto_6d

    :pswitch_35  #0x7
    const-wide/16 v0, 0x2

    invoke-static {v2, v3, v0, v1}, Ljava/lang/Math;->multiplyExact(JJ)J

    move-result-wide v2

    goto :goto_6d

    :pswitch_3c  #0x6
    const-wide/16 v0, 0x18

    invoke-static {v2, v3, v0, v1}, Ljava/lang/Math;->multiplyExact(JJ)J

    move-result-wide v2

    goto :goto_6d

    :pswitch_43  #0x5
    const-wide/16 v0, 0x5a0

    invoke-static {v2, v3, v0, v1}, Ljava/lang/Math;->multiplyExact(JJ)J

    move-result-wide v2

    goto :goto_6d

    :pswitch_4a  #0x4
    const-wide/32 v0, 0x15180

    invoke-static {v2, v3, v0, v1}, Ljava/lang/Math;->multiplyExact(JJ)J

    move-result-wide v2

    goto :goto_6d

    :pswitch_52  #0x3
    const-wide/32 v0, 0x5265c00

    invoke-static {v2, v3, v0, v1}, Ljava/lang/Math;->multiplyExact(JJ)J

    move-result-wide v2

    goto :goto_6d

    :pswitch_5a  #0x2
    const-wide v0, 0x141dd76000L

    invoke-static {v2, v3, v0, v1}, Ljava/lang/Math;->multiplyExact(JJ)J

    move-result-wide v2

    goto :goto_6d

    :pswitch_64  #0x1
    const-wide v0, 0x4e94914f0000L

    invoke-static {v2, v3, v0, v1}, Ljava/lang/Math;->multiplyExact(JJ)J

    move-result-wide v2

    :goto_6d
    iget-object p0, p0, Lj$/time/chrono/g;->b:Lj$/time/LocalTime;

    invoke-interface {p1}, Lj$/time/chrono/e;->toLocalTime()Lj$/time/LocalTime;

    move-result-object p1

    invoke-virtual {p0, p1, p2}, Lj$/time/LocalTime;->k(Lj$/time/temporal/Temporal;Lj$/time/temporal/TemporalUnit;)J

    move-result-wide p0

    invoke-static {v2, v3, p0, p1}, Ljava/lang/Math;->addExact(JJ)J

    move-result-wide p0

    return-wide p0

    :cond_7c
    invoke-interface {p1}, Lj$/time/chrono/e;->toLocalDate()Lj$/time/chrono/b;

    move-result-object v0

    invoke-interface {p1}, Lj$/time/chrono/e;->toLocalTime()Lj$/time/LocalTime;

    move-result-object p1

    iget-object v2, p0, Lj$/time/chrono/g;->b:Lj$/time/LocalTime;

    invoke-virtual {p1, v2}, Lj$/time/LocalTime;->n(Lj$/time/LocalTime;)I

    move-result p1

    if-gez p1, :cond_92

    const-wide/16 v2, 0x1

    invoke-interface {v0, v2, v3, v1}, Lj$/time/chrono/b;->a(JLj$/time/temporal/TemporalUnit;)Lj$/time/chrono/b;

    move-result-object v0

    :cond_92
    iget-object p0, p0, Lj$/time/chrono/g;->a:Lj$/time/chrono/b;

    invoke-interface {p0, v0, p2}, Lj$/time/chrono/b;->k(Lj$/time/temporal/Temporal;Lj$/time/temporal/TemporalUnit;)J

    move-result-wide p0

    return-wide p0

    :cond_99
    const-string v0, "unit"

    invoke-static {p2, v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    invoke-interface {p2, p0, p1}, Lj$/time/temporal/TemporalUnit;->n(Lj$/time/temporal/Temporal;Lj$/time/temporal/Temporal;)J

    move-result-wide p0

    return-wide p0

    nop

    :pswitch_data_a4
    .packed-switch 0x1
        :pswitch_64  #00000001
        :pswitch_5a  #00000002
        :pswitch_52  #00000003
        :pswitch_4a  #00000004
        :pswitch_43  #00000005
        :pswitch_3c  #00000006
        :pswitch_35  #00000007
    .end packed-switch
.end method

.method public final p(Lj$/time/ZoneOffset;)Lj$/time/chrono/j;
    .registers 3

    const/4 v0, 0x0

    invoke-static {p1, v0, p0}, Lj$/time/chrono/l;->v(Lj$/time/ZoneId;Lj$/time/ZoneOffset;Lj$/time/chrono/g;)Lj$/time/chrono/l;

    move-result-object p0

    return-object p0
.end method

.method public final toLocalDate()Lj$/time/chrono/b;
    .registers 1

    iget-object p0, p0, Lj$/time/chrono/g;->a:Lj$/time/chrono/b;

    return-object p0
.end method

.method public final toLocalTime()Lj$/time/LocalTime;
    .registers 1

    iget-object p0, p0, Lj$/time/chrono/g;->b:Lj$/time/LocalTime;

    return-object p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    iget-object v0, p0, Lj$/time/chrono/g;->a:Lj$/time/chrono/b;

    invoke-interface {v0}, Lj$/time/chrono/b;->toString()Ljava/lang/String;

    move-result-object v0

    iget-object p0, p0, Lj$/time/chrono/g;->b:Lj$/time/LocalTime;

    invoke-virtual {p0}, Lj$/time/LocalTime;->toString()Ljava/lang/String;

    move-result-object p0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string v0, "T"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public final v(JLj$/time/temporal/TemporalUnit;)Lj$/time/chrono/g;
    .registers 21

    .prologue
    move-object/from16 v0, p0

    move-wide/from16 v2, p1

    move-object/from16 v1, p3

    instance-of v4, v1, Lj$/time/temporal/ChronoUnit;

    if-eqz v4, :cond_d3

    move-object v4, v1

    check-cast v4, Lj$/time/temporal/ChronoUnit;

    sget-object v5, Lj$/time/chrono/f;->a:[I

    invoke-virtual {v4}, Ljava/lang/Enum;->ordinal()I

    move-result v4

    aget v4, v5, v4

    packed-switch v4, :pswitch_data_e2

    iget-object v4, v0, Lj$/time/chrono/g;->a:Lj$/time/chrono/b;

    invoke-interface {v4, v2, v3, v1}, Lj$/time/chrono/b;->j(JLj$/time/temporal/TemporalUnit;)Lj$/time/chrono/b;

    move-result-object v1

    iget-object v2, v0, Lj$/time/chrono/g;->b:Lj$/time/LocalTime;

    invoke-virtual {v0, v1, v2}, Lj$/time/chrono/g;->I(Lj$/time/temporal/Temporal;Lj$/time/LocalTime;)Lj$/time/chrono/g;

    move-result-object v0

    return-object v0

    :pswitch_25  #0x7
    const-wide/16 v4, 0x100

    div-long v6, v2, v4

    iget-object v1, v0, Lj$/time/chrono/g;->a:Lj$/time/chrono/b;

    sget-object v8, Lj$/time/temporal/ChronoUnit;->DAYS:Lj$/time/temporal/ChronoUnit;

    invoke-interface {v1, v6, v7, v8}, Lj$/time/chrono/b;->j(JLj$/time/temporal/TemporalUnit;)Lj$/time/chrono/b;

    move-result-object v1

    iget-object v6, v0, Lj$/time/chrono/g;->b:Lj$/time/LocalTime;

    invoke-virtual {v0, v1, v6}, Lj$/time/chrono/g;->I(Lj$/time/temporal/Temporal;Lj$/time/LocalTime;)Lj$/time/chrono/g;

    move-result-object v7

    rem-long v0, v2, v4

    const-wide/16 v2, 0xc

    mul-long v9, v0, v2

    iget-object v8, v7, Lj$/time/chrono/g;->a:Lj$/time/chrono/b;

    const-wide/16 v13, 0x0

    const-wide/16 v15, 0x0

    const-wide/16 v11, 0x0

    invoke-virtual/range {v7 .. v16}, Lj$/time/chrono/g;->E(Lj$/time/chrono/b;JJJJ)Lj$/time/chrono/g;

    move-result-object v0

    return-object v0

    :pswitch_4a  #0x6
    iget-object v1, v0, Lj$/time/chrono/g;->a:Lj$/time/chrono/b;

    const-wide/16 v6, 0x0

    const-wide/16 v8, 0x0

    const-wide/16 v4, 0x0

    invoke-virtual/range {v0 .. v9}, Lj$/time/chrono/g;->E(Lj$/time/chrono/b;JJJJ)Lj$/time/chrono/g;

    move-result-object v0

    return-object v0

    :pswitch_57  #0x5
    iget-object v1, v0, Lj$/time/chrono/g;->a:Lj$/time/chrono/b;

    const-wide/16 v6, 0x0

    const-wide/16 v8, 0x0

    const-wide/16 v2, 0x0

    move-wide/from16 v4, p1

    invoke-virtual/range {v0 .. v9}, Lj$/time/chrono/g;->E(Lj$/time/chrono/b;JJJJ)Lj$/time/chrono/g;

    move-result-object v0

    return-object v0

    :pswitch_66  #0x4
    iget-object v1, v0, Lj$/time/chrono/g;->a:Lj$/time/chrono/b;

    const-wide/16 v4, 0x0

    const-wide/16 v8, 0x0

    const-wide/16 v2, 0x0

    move-wide/from16 v6, p1

    invoke-virtual/range {v0 .. v9}, Lj$/time/chrono/g;->E(Lj$/time/chrono/b;JJJJ)Lj$/time/chrono/g;

    move-result-object v0

    return-object v0

    :pswitch_75  #0x3
    const-wide/32 v1, 0x5265c00

    div-long v3, p1, v1

    iget-object v5, v0, Lj$/time/chrono/g;->a:Lj$/time/chrono/b;

    sget-object v6, Lj$/time/temporal/ChronoUnit;->DAYS:Lj$/time/temporal/ChronoUnit;

    invoke-interface {v5, v3, v4, v6}, Lj$/time/chrono/b;->j(JLj$/time/temporal/TemporalUnit;)Lj$/time/chrono/b;

    move-result-object v3

    iget-object v4, v0, Lj$/time/chrono/g;->b:Lj$/time/LocalTime;

    invoke-virtual {v0, v3, v4}, Lj$/time/chrono/g;->I(Lj$/time/temporal/Temporal;Lj$/time/LocalTime;)Lj$/time/chrono/g;

    move-result-object v5

    rem-long v0, p1, v1

    const-wide/32 v2, 0xf4240

    mul-long v13, v0, v2

    iget-object v6, v5, Lj$/time/chrono/g;->a:Lj$/time/chrono/b;

    const-wide/16 v9, 0x0

    const-wide/16 v11, 0x0

    const-wide/16 v7, 0x0

    invoke-virtual/range {v5 .. v14}, Lj$/time/chrono/g;->E(Lj$/time/chrono/b;JJJJ)Lj$/time/chrono/g;

    move-result-object v0

    return-object v0

    :pswitch_9c  #0x2
    const-wide v1, 0x141dd76000L

    div-long v3, p1, v1

    iget-object v5, v0, Lj$/time/chrono/g;->a:Lj$/time/chrono/b;

    sget-object v6, Lj$/time/temporal/ChronoUnit;->DAYS:Lj$/time/temporal/ChronoUnit;

    invoke-interface {v5, v3, v4, v6}, Lj$/time/chrono/b;->j(JLj$/time/temporal/TemporalUnit;)Lj$/time/chrono/b;

    move-result-object v3

    iget-object v4, v0, Lj$/time/chrono/g;->b:Lj$/time/LocalTime;

    invoke-virtual {v0, v3, v4}, Lj$/time/chrono/g;->I(Lj$/time/temporal/Temporal;Lj$/time/LocalTime;)Lj$/time/chrono/g;

    move-result-object v5

    rem-long v0, p1, v1

    const-wide/16 v2, 0x3e8

    mul-long v13, v0, v2

    iget-object v6, v5, Lj$/time/chrono/g;->a:Lj$/time/chrono/b;

    const-wide/16 v9, 0x0

    const-wide/16 v11, 0x0

    const-wide/16 v7, 0x0

    invoke-virtual/range {v5 .. v14}, Lj$/time/chrono/g;->E(Lj$/time/chrono/b;JJJJ)Lj$/time/chrono/g;

    move-result-object v0

    return-object v0

    :pswitch_c4  #0x1
    iget-object v1, v0, Lj$/time/chrono/g;->a:Lj$/time/chrono/b;

    const-wide/16 v4, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v2, 0x0

    move-wide/from16 v8, p1

    invoke-virtual/range {v0 .. v9}, Lj$/time/chrono/g;->E(Lj$/time/chrono/b;JJJJ)Lj$/time/chrono/g;

    move-result-object v0

    return-object v0

    :cond_d3
    iget-object v4, v0, Lj$/time/chrono/g;->a:Lj$/time/chrono/b;

    invoke-interface {v4}, Lj$/time/chrono/b;->getChronology()Lj$/time/chrono/m;

    move-result-object v4

    invoke-interface {v1, v0, v2, v3}, Lj$/time/temporal/TemporalUnit;->v(Lj$/time/temporal/Temporal;J)Lj$/time/temporal/Temporal;

    move-result-object v0

    invoke-static {v4, v0}, Lj$/time/chrono/g;->n(Lj$/time/chrono/m;Lj$/time/temporal/Temporal;)Lj$/time/chrono/g;

    move-result-object v0

    return-object v0

    :pswitch_data_e2
    .packed-switch 0x1
        :pswitch_c4  #00000001
        :pswitch_9c  #00000002
        :pswitch_75  #00000003
        :pswitch_66  #00000004
        :pswitch_57  #00000005
        :pswitch_4a  #00000006
        :pswitch_25  #00000007
    .end packed-switch
.end method
