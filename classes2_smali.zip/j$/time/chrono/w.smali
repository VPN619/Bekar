.class public final Lj$/time/chrono/w;
.super Lj$/time/chrono/a;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field public static final c:Lj$/time/chrono/w;

.field private static final serialVersionUID:J = 0x6623c4799cb0ddcL


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lj$/time/chrono/w;

    invoke-direct {v0}, Lj$/time/chrono/w;-><init>()V

    sput-object v0, Lj$/time/chrono/w;->c:Lj$/time/chrono/w;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .registers 2

    new-instance p0, Ljava/io/InvalidObjectException;

    const-string p1, "Deserialization via serialization delegate"

    invoke-direct {p0, p1}, Ljava/io/InvalidObjectException;-><init>(Ljava/lang/String;)V

    throw p0
.end method


# virtual methods
.method public final F(Lj$/time/Instant;Lj$/time/ZoneId;)Lj$/time/chrono/j;
    .registers 3

    invoke-static {p0, p1, p2}, Lj$/time/chrono/l;->E(Lj$/time/chrono/m;Lj$/time/Instant;Lj$/time/ZoneId;)Lj$/time/chrono/l;

    move-result-object p0

    return-object p0
.end method

.method public final getId()Ljava/lang/String;
    .registers 1

    const-string p0, "Japanese"

    return-object p0
.end method

.method public final q()Ljava/lang/String;
    .registers 1

    const-string p0, "japanese"

    return-object p0
.end method

.method public final t(Lj$/time/temporal/Temporal;)Lj$/time/chrono/b;
    .registers 2

    .prologue
    instance-of p0, p1, Lj$/time/chrono/y;

    if-eqz p0, :cond_7

    check-cast p1, Lj$/time/chrono/y;

    return-object p1

    :cond_7
    new-instance p0, Lj$/time/chrono/y;

    invoke-static {p1}, Lj$/time/LocalDate;->E(Lj$/time/temporal/l;)Lj$/time/LocalDate;

    move-result-object p1

    invoke-direct {p0, p1}, Lj$/time/chrono/y;-><init>(Lj$/time/LocalDate;)V

    return-object p0
.end method

.method public final u(Lj$/time/temporal/a;)Lj$/time/temporal/r;
    .registers 9

    .prologue
    sget-object p0, Lj$/time/chrono/v;->a:[I

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    aget p0, p0, v0

    const/4 v0, 0x0

    const/4 v1, 0x1

    packed-switch p0, :pswitch_data_d0

    iget-object p0, p1, Lj$/time/temporal/a;->b:Lj$/time/temporal/r;

    return-object p0

    :pswitch_10  #0x8
    sget-object p0, Lj$/time/chrono/z;->d:Lj$/time/chrono/z;

    iget p0, p0, Lj$/time/chrono/z;->a:I

    int-to-long p0, p0

    sget-object v0, Lj$/time/chrono/z;->e:[Lj$/time/chrono/z;

    array-length v2, v0

    sub-int/2addr v2, v1

    aget-object v0, v0, v2

    iget v0, v0, Lj$/time/chrono/z;->a:I

    int-to-long v0, v0

    invoke-static {p0, p1, v0, v1}, Lj$/time/temporal/r;->e(JJ)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :pswitch_23  #0x7
    sget-object p0, Lj$/time/chrono/y;->d:Lj$/time/LocalDate;

    invoke-virtual {p0}, Lj$/time/LocalDate;->getYear()I

    move-result p0

    int-to-long p0, p0

    const-wide/32 v0, 0x3b9ac9ff

    invoke-static {p0, p1, v0, v1}, Lj$/time/temporal/r;->e(JJ)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :pswitch_32  #0x6
    sget-object p0, Lj$/time/chrono/z;->d:Lj$/time/chrono/z;

    sget-object p0, Lj$/time/temporal/a;->DAY_OF_YEAR:Lj$/time/temporal/a;

    iget-object p0, p0, Lj$/time/temporal/a;->b:Lj$/time/temporal/r;

    iget-wide p0, p0, Lj$/time/temporal/r;->c:J

    sget-object v2, Lj$/time/chrono/z;->e:[Lj$/time/chrono/z;

    array-length v3, v2

    :goto_3d
    if-ge v0, v3, :cond_74

    aget-object v4, v2, v0

    iget-object v5, v4, Lj$/time/chrono/z;->b:Lj$/time/LocalDate;

    invoke-virtual {v5}, Lj$/time/LocalDate;->M()Z

    move-result v5

    if-eqz v5, :cond_4c

    const/16 v5, 0x16e

    goto :goto_4e

    :cond_4c
    const/16 v5, 0x16d

    :goto_4e
    iget-object v6, v4, Lj$/time/chrono/z;->b:Lj$/time/LocalDate;

    invoke-virtual {v6}, Lj$/time/LocalDate;->J()I

    move-result v6

    sub-int/2addr v5, v6

    add-int/2addr v5, v1

    int-to-long v5, v5

    invoke-static {p0, p1, v5, v6}, Ljava/lang/Math;->min(JJ)J

    move-result-wide p0

    invoke-virtual {v4}, Lj$/time/chrono/z;->n()Lj$/time/chrono/z;

    move-result-object v5

    if-eqz v5, :cond_71

    invoke-virtual {v4}, Lj$/time/chrono/z;->n()Lj$/time/chrono/z;

    move-result-object v4

    iget-object v4, v4, Lj$/time/chrono/z;->b:Lj$/time/LocalDate;

    invoke-virtual {v4}, Lj$/time/LocalDate;->J()I

    move-result v4

    sub-int/2addr v4, v1

    int-to-long v4, v4

    invoke-static {p0, p1, v4, v5}, Ljava/lang/Math;->min(JJ)J

    move-result-wide p0

    :cond_71
    add-int/lit8 v0, v0, 0x1

    goto :goto_3d

    :cond_74
    sget-object v0, Lj$/time/temporal/a;->DAY_OF_YEAR:Lj$/time/temporal/a;

    iget-object v0, v0, Lj$/time/temporal/a;->b:Lj$/time/temporal/r;

    iget-wide v0, v0, Lj$/time/temporal/r;->d:J

    invoke-static {p0, p1, v0, v1}, Lj$/time/temporal/r;->f(JJ)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :pswitch_7f  #0x5
    sget-object p0, Lj$/time/chrono/z;->e:[Lj$/time/chrono/z;

    array-length p1, p0

    sub-int/2addr p1, v1

    aget-object p1, p0, p1

    iget-object p1, p1, Lj$/time/chrono/z;->b:Lj$/time/LocalDate;

    invoke-virtual {p1}, Lj$/time/LocalDate;->getYear()I

    move-result p1

    array-length v2, p0

    sub-int/2addr v2, v1

    aget-object v2, p0, v2

    iget-object v2, v2, Lj$/time/chrono/z;->b:Lj$/time/LocalDate;

    invoke-virtual {v2}, Lj$/time/LocalDate;->getYear()I

    move-result v2

    const v3, 0x3b9aca00

    sub-int/2addr v3, v2

    aget-object p0, p0, v0

    iget-object p0, p0, Lj$/time/chrono/z;->b:Lj$/time/LocalDate;

    invoke-virtual {p0}, Lj$/time/LocalDate;->getYear()I

    move-result p0

    move v0, v1

    :goto_a2
    sget-object v2, Lj$/time/chrono/z;->e:[Lj$/time/chrono/z;

    array-length v4, v2

    if-ge v0, v4, :cond_be

    aget-object v2, v2, v0

    iget-object v4, v2, Lj$/time/chrono/z;->b:Lj$/time/LocalDate;

    invoke-virtual {v4}, Lj$/time/LocalDate;->getYear()I

    move-result v4

    sub-int/2addr v4, p0

    add-int/2addr v4, v1

    invoke-static {v3, v4}, Ljava/lang/Math;->min(II)I

    move-result v3

    iget-object p0, v2, Lj$/time/chrono/z;->b:Lj$/time/LocalDate;

    invoke-virtual {p0}, Lj$/time/LocalDate;->getYear()I

    move-result p0

    add-int/lit8 v0, v0, 0x1

    goto :goto_a2

    :cond_be
    int-to-long v0, v3

    const p0, 0x3b9ac9ff

    sub-int/2addr p0, p1

    int-to-long p0, p0

    invoke-static {v0, v1, p0, p1}, Lj$/time/temporal/r;->f(JJ)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :pswitch_c9  #0x1, 0x2, 0x3, 0x4
    const-string p0, "Unsupported field: "

    invoke-static {p0, p1}, Lj$/time/h;->c(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 p0, 0x0

    return-object p0

    :pswitch_data_d0
    .packed-switch 0x1
        :pswitch_c9  #00000001
        :pswitch_c9  #00000002
        :pswitch_c9  #00000003
        :pswitch_c9  #00000004
        :pswitch_7f  #00000005
        :pswitch_32  #00000006
        :pswitch_23  #00000007
        :pswitch_10  #00000008
    .end packed-switch
.end method

.method public final w(I)Lj$/time/chrono/n;
    .registers 2

    invoke-static {p1}, Lj$/time/chrono/z;->q(I)Lj$/time/chrono/z;

    move-result-object p0

    return-object p0
.end method

.method public writeReplace()Ljava/lang/Object;
    .registers 3

    new-instance v0, Lj$/time/chrono/f0;

    const/4 v1, 0x1

    invoke-direct {v0, v1, p0}, Lj$/time/chrono/f0;-><init>(BLjava/lang/Object;)V

    return-object v0
.end method
