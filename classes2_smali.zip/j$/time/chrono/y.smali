.class public final Lj$/time/chrono/y;
.super Lj$/time/chrono/d;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final d:Lj$/time/LocalDate;

.field private static final serialVersionUID:J = -0x43cbddbf9310f03L


# instance fields
.field public final transient a:Lj$/time/LocalDate;

.field public final transient b:Lj$/time/chrono/z;

.field public final transient c:I


# direct methods
.method static constructor <clinit>()V
    .registers 2

    const/16 v0, 0x751

    const/4 v1, 0x1

    invoke-static {v0, v1, v1}, Lj$/time/LocalDate;->of(III)Lj$/time/LocalDate;

    move-result-object v0

    sput-object v0, Lj$/time/chrono/y;->d:Lj$/time/LocalDate;

    return-void
.end method

.method public constructor <init>(Lj$/time/LocalDate;)V
    .registers 4

    .prologue
    invoke-direct {p0}, Lj$/time/chrono/d;-><init>()V

    sget-object v0, Lj$/time/chrono/y;->d:Lj$/time/LocalDate;

    invoke-virtual {p1, v0}, Lj$/time/LocalDate;->L(Lj$/time/chrono/b;)Z

    move-result v0

    if-nez v0, :cond_23

    invoke-static {p1}, Lj$/time/chrono/z;->m(Lj$/time/LocalDate;)Lj$/time/chrono/z;

    move-result-object v0

    iput-object v0, p0, Lj$/time/chrono/y;->b:Lj$/time/chrono/z;

    invoke-virtual {p1}, Lj$/time/LocalDate;->getYear()I

    move-result v1

    iget-object v0, v0, Lj$/time/chrono/z;->b:Lj$/time/LocalDate;

    invoke-virtual {v0}, Lj$/time/LocalDate;->getYear()I

    move-result v0

    sub-int/2addr v1, v0

    add-int/lit8 v1, v1, 0x1

    iput v1, p0, Lj$/time/chrono/y;->c:I

    iput-object p1, p0, Lj$/time/chrono/y;->a:Lj$/time/LocalDate;

    return-void

    :cond_23
    new-instance p0, Lj$/time/c;

    const-string p1, "JapaneseDate before Meiji 6 is not supported"

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .registers 2

    new-instance p0, Ljava/io/InvalidObjectException;

    const-string p1, "Deserialization via serialization delegate"

    invoke-direct {p0, p1}, Ljava/io/InvalidObjectException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private writeReplace()Ljava/lang/Object;
    .registers 3

    new-instance v0, Lj$/time/chrono/f0;

    const/4 v1, 0x4

    invoke-direct {v0, v1, p0}, Lj$/time/chrono/f0;-><init>(BLjava/lang/Object;)V

    return-object v0
.end method


# virtual methods
.method public final A(Lj$/time/LocalTime;)Lj$/time/chrono/e;
    .registers 3

    new-instance v0, Lj$/time/chrono/g;

    invoke-direct {v0, p0, p1}, Lj$/time/chrono/g;-><init>(Lj$/time/chrono/b;Lj$/time/LocalTime;)V

    return-object v0
.end method

.method public final C()Lj$/time/chrono/n;
    .registers 1

    iget-object p0, p0, Lj$/time/chrono/y;->b:Lj$/time/chrono/z;

    return-object p0
.end method

.method public final E(J)Lj$/time/chrono/b;
    .registers 4

    iget-object v0, p0, Lj$/time/chrono/y;->a:Lj$/time/LocalDate;

    invoke-virtual {v0, p1, p2}, Lj$/time/LocalDate;->R(J)Lj$/time/LocalDate;

    move-result-object p1

    invoke-virtual {p0, p1}, Lj$/time/chrono/y;->L(Lj$/time/LocalDate;)Lj$/time/chrono/y;

    move-result-object p0

    return-object p0
.end method

.method public final H(J)Lj$/time/chrono/b;
    .registers 4

    iget-object v0, p0, Lj$/time/chrono/y;->a:Lj$/time/LocalDate;

    invoke-virtual {v0, p1, p2}, Lj$/time/LocalDate;->S(J)Lj$/time/LocalDate;

    move-result-object p1

    invoke-virtual {p0, p1}, Lj$/time/chrono/y;->L(Lj$/time/LocalDate;)Lj$/time/chrono/y;

    move-result-object p0

    return-object p0
.end method

.method public final I(J)Lj$/time/chrono/b;
    .registers 4

    iget-object v0, p0, Lj$/time/chrono/y;->a:Lj$/time/LocalDate;

    invoke-virtual {v0, p1, p2}, Lj$/time/LocalDate;->T(J)Lj$/time/LocalDate;

    move-result-object p1

    invoke-virtual {p0, p1}, Lj$/time/chrono/y;->L(Lj$/time/LocalDate;)Lj$/time/chrono/y;

    move-result-object p0

    return-object p0
.end method

.method public final J(Lj$/time/temporal/m;)Lj$/time/chrono/b;
    .registers 2

    invoke-super {p0, p1}, Lj$/time/chrono/d;->J(Lj$/time/temporal/m;)Lj$/time/chrono/b;

    move-result-object p0

    check-cast p0, Lj$/time/chrono/y;

    return-object p0
.end method

.method public final K(JLj$/time/temporal/o;)Lj$/time/chrono/y;
    .registers 10

    .prologue
    instance-of v0, p3, Lj$/time/temporal/a;

    if-eqz v0, :cond_62

    move-object v0, p3

    check-cast v0, Lj$/time/temporal/a;

    invoke-virtual {p0, v0}, Lj$/time/chrono/y;->f(Lj$/time/temporal/o;)J

    move-result-wide v1

    cmp-long v1, v1, p1

    if-nez v1, :cond_10

    return-object p0

    :cond_10
    sget-object v1, Lj$/time/chrono/x;->a:[I

    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v2

    aget v2, v1, v2

    const/16 v3, 0x9

    const/16 v4, 0x8

    const/4 v5, 0x3

    if-eq v2, v5, :cond_24

    if-eq v2, v4, :cond_24

    if-eq v2, v3, :cond_24

    goto :goto_3a

    :cond_24
    sget-object v2, Lj$/time/chrono/w;->c:Lj$/time/chrono/w;

    invoke-virtual {v2, v0}, Lj$/time/chrono/w;->u(Lj$/time/temporal/a;)Lj$/time/temporal/r;

    move-result-object v2

    invoke-virtual {v2, p1, p2, v0}, Lj$/time/temporal/r;->a(JLj$/time/temporal/o;)I

    move-result v2

    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    aget v0, v1, v0

    if-eq v0, v5, :cond_5b

    if-eq v0, v4, :cond_50

    if-eq v0, v3, :cond_45

    :goto_3a
    iget-object v0, p0, Lj$/time/chrono/y;->a:Lj$/time/LocalDate;

    invoke-virtual {v0, p1, p2, p3}, Lj$/time/LocalDate;->V(JLj$/time/temporal/o;)Lj$/time/LocalDate;

    move-result-object p1

    invoke-virtual {p0, p1}, Lj$/time/chrono/y;->L(Lj$/time/LocalDate;)Lj$/time/chrono/y;

    move-result-object p0

    return-object p0

    :cond_45
    iget-object p1, p0, Lj$/time/chrono/y;->a:Lj$/time/LocalDate;

    invoke-virtual {p1, v2}, Lj$/time/LocalDate;->Y(I)Lj$/time/LocalDate;

    move-result-object p1

    invoke-virtual {p0, p1}, Lj$/time/chrono/y;->L(Lj$/time/LocalDate;)Lj$/time/chrono/y;

    move-result-object p0

    return-object p0

    :cond_50
    invoke-static {v2}, Lj$/time/chrono/z;->q(I)Lj$/time/chrono/z;

    move-result-object p1

    iget p2, p0, Lj$/time/chrono/y;->c:I

    invoke-virtual {p0, p1, p2}, Lj$/time/chrono/y;->M(Lj$/time/chrono/z;I)Lj$/time/chrono/y;

    move-result-object p0

    return-object p0

    :cond_5b
    iget-object p1, p0, Lj$/time/chrono/y;->b:Lj$/time/chrono/z;

    invoke-virtual {p0, p1, v2}, Lj$/time/chrono/y;->M(Lj$/time/chrono/z;I)Lj$/time/chrono/y;

    move-result-object p0

    return-object p0

    :cond_62
    invoke-super {p0, p1, p2, p3}, Lj$/time/chrono/d;->g(JLj$/time/temporal/o;)Lj$/time/chrono/b;

    move-result-object p0

    check-cast p0, Lj$/time/chrono/y;

    return-object p0
.end method

.method public final L(Lj$/time/LocalDate;)Lj$/time/chrono/y;
    .registers 3

    .prologue
    iget-object v0, p0, Lj$/time/chrono/y;->a:Lj$/time/LocalDate;

    invoke-virtual {p1, v0}, Lj$/time/LocalDate;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_9

    return-object p0

    :cond_9
    new-instance p0, Lj$/time/chrono/y;

    invoke-direct {p0, p1}, Lj$/time/chrono/y;-><init>(Lj$/time/LocalDate;)V

    return-object p0
.end method

.method public final M(Lj$/time/chrono/z;I)Lj$/time/chrono/y;
    .registers 5

    .prologue
    sget-object v0, Lj$/time/chrono/w;->c:Lj$/time/chrono/w;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-eqz p1, :cond_42

    iget-object v0, p1, Lj$/time/chrono/z;->b:Lj$/time/LocalDate;

    invoke-virtual {v0}, Lj$/time/LocalDate;->getYear()I

    move-result v0

    add-int/2addr v0, p2

    const/4 v1, 0x1

    sub-int/2addr v0, v1

    if-ne p2, v1, :cond_13

    goto :goto_2f

    :cond_13
    const p2, -0x3b9ac9ff

    if-lt v0, p2, :cond_3a

    const p2, 0x3b9ac9ff

    if-gt v0, p2, :cond_3a

    iget-object p2, p1, Lj$/time/chrono/z;->b:Lj$/time/LocalDate;

    invoke-virtual {p2}, Lj$/time/LocalDate;->getYear()I

    move-result p2

    if-lt v0, p2, :cond_3a

    invoke-static {v0, v1, v1}, Lj$/time/LocalDate;->of(III)Lj$/time/LocalDate;

    move-result-object p2

    invoke-static {p2}, Lj$/time/chrono/z;->m(Lj$/time/LocalDate;)Lj$/time/chrono/z;

    move-result-object p2

    if-ne p1, p2, :cond_3a

    :goto_2f
    iget-object p1, p0, Lj$/time/chrono/y;->a:Lj$/time/LocalDate;

    invoke-virtual {p1, v0}, Lj$/time/LocalDate;->Y(I)Lj$/time/LocalDate;

    move-result-object p1

    invoke-virtual {p0, p1}, Lj$/time/chrono/y;->L(Lj$/time/LocalDate;)Lj$/time/chrono/y;

    move-result-object p0

    return-object p0

    :cond_3a
    new-instance p0, Lj$/time/c;

    const-string p1, "Invalid yearOfEra value"

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_42
    new-instance p0, Ljava/lang/ClassCastException;

    const-string p1, "Era must be JapaneseEra"

    invoke-direct {p0, p1}, Ljava/lang/ClassCastException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final a(JLj$/time/temporal/TemporalUnit;)Lj$/time/chrono/b;
    .registers 4

    invoke-super {p0, p1, p2, p3}, Lj$/time/chrono/d;->a(JLj$/time/temporal/TemporalUnit;)Lj$/time/chrono/b;

    move-result-object p0

    check-cast p0, Lj$/time/chrono/y;

    return-object p0
.end method

.method public final a(JLj$/time/temporal/TemporalUnit;)Lj$/time/temporal/Temporal;
    .registers 4

    invoke-super {p0, p1, p2, p3}, Lj$/time/chrono/d;->a(JLj$/time/temporal/TemporalUnit;)Lj$/time/chrono/b;

    move-result-object p0

    check-cast p0, Lj$/time/chrono/y;

    return-object p0
.end method

.method public final e(Lj$/time/temporal/o;)Z
    .registers 3

    .prologue
    sget-object v0, Lj$/time/temporal/a;->ALIGNED_DAY_OF_WEEK_IN_MONTH:Lj$/time/temporal/a;

    if-eq p1, v0, :cond_26

    sget-object v0, Lj$/time/temporal/a;->ALIGNED_DAY_OF_WEEK_IN_YEAR:Lj$/time/temporal/a;

    if-eq p1, v0, :cond_26

    sget-object v0, Lj$/time/temporal/a;->ALIGNED_WEEK_OF_MONTH:Lj$/time/temporal/a;

    if-eq p1, v0, :cond_26

    sget-object v0, Lj$/time/temporal/a;->ALIGNED_WEEK_OF_YEAR:Lj$/time/temporal/a;

    if-ne p1, v0, :cond_11

    goto :goto_26

    :cond_11
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_1c

    check-cast p1, Lj$/time/temporal/a;

    invoke-virtual {p1}, Lj$/time/temporal/a;->isDateBased()Z

    move-result p0

    return p0

    :cond_1c
    if-eqz p1, :cond_26

    invoke-interface {p1, p0}, Lj$/time/temporal/o;->n(Lj$/time/temporal/l;)Z

    move-result p0

    if-eqz p0, :cond_26

    const/4 p0, 0x1

    return p0

    :cond_26
    :goto_26
    const/4 p0, 0x0

    return p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 3

    .prologue
    if-ne p0, p1, :cond_4

    const/4 p0, 0x1

    return p0

    :cond_4
    instance-of v0, p1, Lj$/time/chrono/y;

    if-eqz v0, :cond_13

    check-cast p1, Lj$/time/chrono/y;

    iget-object p0, p0, Lj$/time/chrono/y;->a:Lj$/time/LocalDate;

    iget-object p1, p1, Lj$/time/chrono/y;->a:Lj$/time/LocalDate;

    invoke-virtual {p0, p1}, Lj$/time/LocalDate;->equals(Ljava/lang/Object;)Z

    move-result p0

    return p0

    :cond_13
    const/4 p0, 0x0

    return p0
.end method

.method public final f(Lj$/time/temporal/o;)J
    .registers 4

    .prologue
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_4c

    sget-object v0, Lj$/time/chrono/x;->a:[I

    move-object v1, p1

    check-cast v1, Lj$/time/temporal/a;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget v0, v0, v1

    packed-switch v0, :pswitch_data_52

    iget-object p0, p0, Lj$/time/chrono/y;->a:Lj$/time/LocalDate;

    invoke-virtual {p0, p1}, Lj$/time/LocalDate;->f(Lj$/time/temporal/o;)J

    move-result-wide p0

    return-wide p0

    :pswitch_19  #0x8
    iget-object p0, p0, Lj$/time/chrono/y;->b:Lj$/time/chrono/z;

    iget p0, p0, Lj$/time/chrono/z;->a:I

    int-to-long p0, p0

    return-wide p0

    :pswitch_1f  #0x4, 0x5, 0x6, 0x7
    new-instance p0, Lj$/time/temporal/q;

    const-string v0, "Unsupported field: "

    invoke-static {v0, p1}, Lj$/time/d;->a(Ljava/lang/String;Lj$/time/temporal/o;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :pswitch_2b  #0x3
    iget p0, p0, Lj$/time/chrono/y;->c:I

    int-to-long p0, p0

    return-wide p0

    :pswitch_2f  #0x2
    iget p1, p0, Lj$/time/chrono/y;->c:I

    iget-object v0, p0, Lj$/time/chrono/y;->a:Lj$/time/LocalDate;

    const/4 v1, 0x1

    if-ne p1, v1, :cond_46

    invoke-virtual {v0}, Lj$/time/LocalDate;->J()I

    move-result p1

    iget-object p0, p0, Lj$/time/chrono/y;->b:Lj$/time/chrono/z;

    iget-object p0, p0, Lj$/time/chrono/z;->b:Lj$/time/LocalDate;

    invoke-virtual {p0}, Lj$/time/LocalDate;->J()I

    move-result p0

    sub-int/2addr p1, p0

    add-int/2addr p1, v1

    int-to-long p0, p1

    return-wide p0

    :cond_46
    invoke-virtual {v0}, Lj$/time/LocalDate;->J()I

    move-result p0

    int-to-long p0, p0

    return-wide p0

    :cond_4c
    invoke-interface {p1, p0}, Lj$/time/temporal/o;->E(Lj$/time/temporal/l;)J

    move-result-wide p0

    return-wide p0

    nop

    :pswitch_data_52
    .packed-switch 0x2
        :pswitch_2f  #00000002
        :pswitch_2b  #00000003
        :pswitch_1f  #00000004
        :pswitch_1f  #00000005
        :pswitch_1f  #00000006
        :pswitch_1f  #00000007
        :pswitch_19  #00000008
    .end packed-switch
.end method

.method public final bridge synthetic g(JLj$/time/temporal/o;)Lj$/time/chrono/b;
    .registers 4

    invoke-virtual {p0, p1, p2, p3}, Lj$/time/chrono/y;->K(JLj$/time/temporal/o;)Lj$/time/chrono/y;

    move-result-object p0

    return-object p0
.end method

.method public final bridge synthetic g(JLj$/time/temporal/o;)Lj$/time/temporal/Temporal;
    .registers 4

    invoke-virtual {p0, p1, p2, p3}, Lj$/time/chrono/y;->K(JLj$/time/temporal/o;)Lj$/time/chrono/y;

    move-result-object p0

    return-object p0
.end method

.method public final getChronology()Lj$/time/chrono/m;
    .registers 1

    sget-object p0, Lj$/time/chrono/w;->c:Lj$/time/chrono/w;

    return-object p0
.end method

.method public final h(Lj$/time/LocalDate;)Lj$/time/temporal/Temporal;
    .registers 2

    invoke-super {p0, p1}, Lj$/time/chrono/d;->J(Lj$/time/temporal/m;)Lj$/time/chrono/b;

    move-result-object p0

    check-cast p0, Lj$/time/chrono/y;

    return-object p0
.end method

.method public final hashCode()I
    .registers 2

    sget-object v0, Lj$/time/chrono/w;->c:Lj$/time/chrono/w;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p0, Lj$/time/chrono/y;->a:Lj$/time/LocalDate;

    invoke-virtual {p0}, Lj$/time/LocalDate;->hashCode()I

    move-result p0

    const v0, -0x29035c2f

    xor-int/2addr p0, v0

    return p0
.end method

.method public final i(Lj$/time/temporal/o;)Lj$/time/temporal/r;
    .registers 7

    .prologue
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_a5

    invoke-virtual {p0, p1}, Lj$/time/chrono/y;->e(Lj$/time/temporal/o;)Z

    move-result v0

    if-eqz v0, :cond_99

    check-cast p1, Lj$/time/temporal/a;

    sget-object v0, Lj$/time/chrono/x;->a:[I

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget v0, v0, v1

    const/4 v1, 0x1

    const-wide/16 v2, 0x1

    if-eq v0, v1, :cond_8d

    const/4 v4, 0x2

    if-eq v0, v4, :cond_4e

    const/4 v4, 0x3

    if-eq v0, v4, :cond_26

    sget-object p0, Lj$/time/chrono/w;->c:Lj$/time/chrono/w;

    invoke-virtual {p0, p1}, Lj$/time/chrono/w;->u(Lj$/time/temporal/a;)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_26
    iget-object p1, p0, Lj$/time/chrono/y;->b:Lj$/time/chrono/z;

    iget-object p1, p1, Lj$/time/chrono/z;->b:Lj$/time/LocalDate;

    invoke-virtual {p1}, Lj$/time/LocalDate;->getYear()I

    move-result p1

    iget-object p0, p0, Lj$/time/chrono/y;->b:Lj$/time/chrono/z;

    invoke-virtual {p0}, Lj$/time/chrono/z;->n()Lj$/time/chrono/z;

    move-result-object p0

    if-eqz p0, :cond_44

    iget-object p0, p0, Lj$/time/chrono/z;->b:Lj$/time/LocalDate;

    invoke-virtual {p0}, Lj$/time/LocalDate;->getYear()I

    move-result p0

    sub-int/2addr p0, p1

    add-int/2addr p0, v1

    int-to-long p0, p0

    invoke-static {v2, v3, p0, p1}, Lj$/time/temporal/r;->e(JJ)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_44
    const p0, 0x3b9ac9ff

    sub-int/2addr p0, p1

    int-to-long p0, p0

    invoke-static {v2, v3, p0, p1}, Lj$/time/temporal/r;->e(JJ)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_4e
    iget-object p1, p0, Lj$/time/chrono/y;->b:Lj$/time/chrono/z;

    invoke-virtual {p1}, Lj$/time/chrono/z;->n()Lj$/time/chrono/z;

    move-result-object p1

    if-eqz p1, :cond_6c

    iget-object v0, p1, Lj$/time/chrono/z;->b:Lj$/time/LocalDate;

    invoke-virtual {v0}, Lj$/time/LocalDate;->getYear()I

    move-result v0

    iget-object v4, p0, Lj$/time/chrono/y;->a:Lj$/time/LocalDate;

    invoke-virtual {v4}, Lj$/time/LocalDate;->getYear()I

    move-result v4

    if-ne v0, v4, :cond_6c

    iget-object p1, p1, Lj$/time/chrono/z;->b:Lj$/time/LocalDate;

    invoke-virtual {p1}, Lj$/time/LocalDate;->J()I

    move-result p1

    sub-int/2addr p1, v1

    goto :goto_79

    :cond_6c
    iget-object p1, p0, Lj$/time/chrono/y;->a:Lj$/time/LocalDate;

    invoke-virtual {p1}, Lj$/time/LocalDate;->M()Z

    move-result p1

    if-eqz p1, :cond_77

    const/16 p1, 0x16e

    goto :goto_79

    :cond_77
    const/16 p1, 0x16d

    :goto_79
    iget v0, p0, Lj$/time/chrono/y;->c:I

    if-ne v0, v1, :cond_87

    iget-object p0, p0, Lj$/time/chrono/y;->b:Lj$/time/chrono/z;

    iget-object p0, p0, Lj$/time/chrono/z;->b:Lj$/time/LocalDate;

    invoke-virtual {p0}, Lj$/time/LocalDate;->J()I

    move-result p0

    sub-int/2addr p0, v1

    sub-int/2addr p1, p0

    :cond_87
    int-to-long p0, p1

    invoke-static {v2, v3, p0, p1}, Lj$/time/temporal/r;->e(JJ)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_8d
    iget-object p0, p0, Lj$/time/chrono/y;->a:Lj$/time/LocalDate;

    invoke-virtual {p0}, Lj$/time/LocalDate;->N()I

    move-result p0

    int-to-long p0, p0

    invoke-static {v2, v3, p0, p1}, Lj$/time/temporal/r;->e(JJ)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_99
    new-instance p0, Lj$/time/temporal/q;

    const-string v0, "Unsupported field: "

    invoke-static {v0, p1}, Lj$/time/d;->a(Ljava/lang/String;Lj$/time/temporal/o;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_a5
    invoke-interface {p1, p0}, Lj$/time/temporal/o;->v(Lj$/time/temporal/l;)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0
.end method

.method public final j(JLj$/time/temporal/TemporalUnit;)Lj$/time/chrono/b;
    .registers 4

    invoke-super {p0, p1, p2, p3}, Lj$/time/chrono/d;->j(JLj$/time/temporal/TemporalUnit;)Lj$/time/chrono/b;

    move-result-object p0

    check-cast p0, Lj$/time/chrono/y;

    return-object p0
.end method

.method public final j(JLj$/time/temporal/TemporalUnit;)Lj$/time/temporal/Temporal;
    .registers 4

    invoke-super {p0, p1, p2, p3}, Lj$/time/chrono/d;->j(JLj$/time/temporal/TemporalUnit;)Lj$/time/chrono/b;

    move-result-object p0

    check-cast p0, Lj$/time/chrono/y;

    return-object p0
.end method

.method public final z()J
    .registers 3

    iget-object p0, p0, Lj$/time/chrono/y;->a:Lj$/time/LocalDate;

    invoke-virtual {p0}, Lj$/time/LocalDate;->z()J

    move-result-wide v0

    return-wide v0
.end method
