.class public abstract Lj$/time/chrono/d;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lj$/time/chrono/b;
.implements Lj$/time/temporal/Temporal;
.implements Lj$/time/temporal/m;
.implements Ljava/io/Serializable;


# static fields
.field private static final serialVersionUID:J = 0x572fb054bf61a0b8L


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static n(Lj$/time/chrono/m;Lj$/time/temporal/Temporal;)Lj$/time/chrono/b;
    .registers 3

    .prologue
    check-cast p1, Lj$/time/chrono/b;

    invoke-interface {p1}, Lj$/time/chrono/b;->getChronology()Lj$/time/chrono/m;

    move-result-object v0

    invoke-interface {p0, v0}, Lj$/time/chrono/m;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_d

    return-object p1

    :cond_d
    invoke-interface {p0}, Lj$/time/chrono/m;->getId()Ljava/lang/String;

    move-result-object p0

    invoke-interface {p1}, Lj$/time/chrono/b;->getChronology()Lj$/time/chrono/m;

    move-result-object p1

    invoke-interface {p1}, Lj$/time/chrono/m;->getId()Ljava/lang/String;

    move-result-object p1

    const-string v0, "Chronology mismatch, expected: "

    invoke-static {v0, p0, p1}, Lj$/time/h;->g(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 p0, 0x0

    return-object p0
.end method


# virtual methods
.method public abstract E(J)Lj$/time/chrono/b;
.end method

.method public abstract H(J)Lj$/time/chrono/b;
.end method

.method public abstract I(J)Lj$/time/chrono/b;
.end method

.method public J(Lj$/time/temporal/m;)Lj$/time/chrono/b;
    .registers 3

    invoke-interface {p0}, Lj$/time/chrono/b;->getChronology()Lj$/time/chrono/m;

    move-result-object v0

    invoke-interface {p1, p0}, Lj$/time/temporal/m;->c(Lj$/time/temporal/Temporal;)Lj$/time/temporal/Temporal;

    move-result-object p0

    invoke-static {v0, p0}, Lj$/time/chrono/d;->n(Lj$/time/chrono/m;Lj$/time/temporal/Temporal;)Lj$/time/chrono/b;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic a(JLj$/time/temporal/TemporalUnit;)Lj$/time/temporal/Temporal;
    .registers 4

    invoke-interface {p0, p1, p2, p3}, Lj$/time/chrono/b;->a(JLj$/time/temporal/TemporalUnit;)Lj$/time/chrono/b;

    move-result-object p0

    return-object p0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 5

    .prologue
    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lj$/time/chrono/b;

    const/4 v2, 0x0

    if-eqz v1, :cond_12

    check-cast p1, Lj$/time/chrono/b;

    invoke-interface {p0, p1}, Lj$/time/chrono/b;->G(Lj$/time/chrono/b;)I

    move-result p0

    if-nez p0, :cond_12

    return v0

    :cond_12
    return v2
.end method

.method public g(JLj$/time/temporal/o;)Lj$/time/chrono/b;
    .registers 5

    .prologue
    instance-of v0, p3, Lj$/time/temporal/a;

    if-nez v0, :cond_11

    invoke-interface {p0}, Lj$/time/chrono/b;->getChronology()Lj$/time/chrono/m;

    move-result-object v0

    invoke-interface {p3, p0, p1, p2}, Lj$/time/temporal/o;->H(Lj$/time/temporal/Temporal;J)Lj$/time/temporal/Temporal;

    move-result-object p0

    invoke-static {v0, p0}, Lj$/time/chrono/d;->n(Lj$/time/chrono/m;Lj$/time/temporal/Temporal;)Lj$/time/chrono/b;

    move-result-object p0

    return-object p0

    :cond_11
    new-instance p0, Lj$/time/temporal/q;

    const-string p1, "Unsupported field: "

    invoke-static {p1, p3}, Lj$/time/d;->a(Ljava/lang/String;Lj$/time/temporal/o;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public bridge synthetic g(JLj$/time/temporal/o;)Lj$/time/temporal/Temporal;
    .registers 4

    invoke-virtual {p0, p1, p2, p3}, Lj$/time/chrono/d;->g(JLj$/time/temporal/o;)Lj$/time/chrono/b;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic h(Lj$/time/LocalDate;)Lj$/time/temporal/Temporal;
    .registers 2

    invoke-virtual {p0, p1}, Lj$/time/chrono/d;->J(Lj$/time/temporal/m;)Lj$/time/chrono/b;

    move-result-object p0

    return-object p0
.end method

.method public hashCode()I
    .registers 5

    invoke-interface {p0}, Lj$/time/chrono/b;->z()J

    move-result-wide v0

    invoke-interface {p0}, Lj$/time/chrono/b;->getChronology()Lj$/time/chrono/m;

    move-result-object p0

    invoke-interface {p0}, Lj$/time/chrono/m;->hashCode()I

    move-result p0

    const/16 v2, 0x20

    ushr-long v2, v0, v2

    xor-long/2addr v0, v2

    long-to-int v0, v0

    xor-int/2addr p0, v0

    return p0
.end method

.method public j(JLj$/time/temporal/TemporalUnit;)Lj$/time/chrono/b;
    .registers 8

    .prologue
    instance-of v0, p3, Lj$/time/temporal/ChronoUnit;

    const/4 v1, 0x0

    const-string v2, "Unsupported unit: "

    if-eqz v0, :cond_63

    move-object v0, p3

    check-cast v0, Lj$/time/temporal/ChronoUnit;

    sget-object v3, Lj$/time/chrono/c;->a:[I

    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    aget v0, v3, v0

    packed-switch v0, :pswitch_data_76

    invoke-static {v2, p3}, Lj$/time/h;->c(Ljava/lang/String;Ljava/lang/Object;)V

    return-object v1

    :pswitch_19  #0x8
    sget-object p3, Lj$/time/temporal/a;->ERA:Lj$/time/temporal/a;

    invoke-interface {p0, p3}, Lj$/time/temporal/l;->f(Lj$/time/temporal/o;)J

    move-result-wide v0

    invoke-static {v0, v1, p1, p2}, Ljava/lang/Math;->addExact(JJ)J

    move-result-wide p1

    invoke-virtual {p0, p1, p2, p3}, Lj$/time/chrono/d;->g(JLj$/time/temporal/o;)Lj$/time/chrono/b;

    move-result-object p0

    return-object p0

    :pswitch_28  #0x7
    const-wide/16 v0, 0x3e8

    invoke-static {p1, p2, v0, v1}, Ljava/lang/Math;->multiplyExact(JJ)J

    move-result-wide p1

    invoke-virtual {p0, p1, p2}, Lj$/time/chrono/d;->I(J)Lj$/time/chrono/b;

    move-result-object p0

    return-object p0

    :pswitch_33  #0x6
    const-wide/16 v0, 0x64

    invoke-static {p1, p2, v0, v1}, Ljava/lang/Math;->multiplyExact(JJ)J

    move-result-wide p1

    invoke-virtual {p0, p1, p2}, Lj$/time/chrono/d;->I(J)Lj$/time/chrono/b;

    move-result-object p0

    return-object p0

    :pswitch_3e  #0x5
    const-wide/16 v0, 0xa

    invoke-static {p1, p2, v0, v1}, Ljava/lang/Math;->multiplyExact(JJ)J

    move-result-wide p1

    invoke-virtual {p0, p1, p2}, Lj$/time/chrono/d;->I(J)Lj$/time/chrono/b;

    move-result-object p0

    return-object p0

    :pswitch_49  #0x4
    invoke-virtual {p0, p1, p2}, Lj$/time/chrono/d;->I(J)Lj$/time/chrono/b;

    move-result-object p0

    return-object p0

    :pswitch_4e  #0x3
    invoke-virtual {p0, p1, p2}, Lj$/time/chrono/d;->H(J)Lj$/time/chrono/b;

    move-result-object p0

    return-object p0

    :pswitch_53  #0x2
    const-wide/16 v0, 0x7

    invoke-static {p1, p2, v0, v1}, Ljava/lang/Math;->multiplyExact(JJ)J

    move-result-wide p1

    invoke-virtual {p0, p1, p2}, Lj$/time/chrono/d;->E(J)Lj$/time/chrono/b;

    move-result-object p0

    return-object p0

    :pswitch_5e  #0x1
    invoke-virtual {p0, p1, p2}, Lj$/time/chrono/d;->E(J)Lj$/time/chrono/b;

    move-result-object p0

    return-object p0

    :cond_63
    if-nez v0, :cond_72

    invoke-interface {p0}, Lj$/time/chrono/b;->getChronology()Lj$/time/chrono/m;

    move-result-object v0

    invoke-interface {p3, p0, p1, p2}, Lj$/time/temporal/TemporalUnit;->v(Lj$/time/temporal/Temporal;J)Lj$/time/temporal/Temporal;

    move-result-object p0

    invoke-static {v0, p0}, Lj$/time/chrono/d;->n(Lj$/time/chrono/m;Lj$/time/temporal/Temporal;)Lj$/time/chrono/b;

    move-result-object p0

    return-object p0

    :cond_72
    invoke-static {v2, p3}, Lj$/time/h;->c(Ljava/lang/String;Ljava/lang/Object;)V

    return-object v1

    :pswitch_data_76
    .packed-switch 0x1
        :pswitch_5e  #00000001
        :pswitch_53  #00000002
        :pswitch_4e  #00000003
        :pswitch_49  #00000004
        :pswitch_3e  #00000005
        :pswitch_33  #00000006
        :pswitch_28  #00000007
        :pswitch_19  #00000008
    .end packed-switch
.end method

.method public bridge synthetic j(JLj$/time/temporal/TemporalUnit;)Lj$/time/temporal/Temporal;
    .registers 4

    invoke-virtual {p0, p1, p2, p3}, Lj$/time/chrono/d;->j(JLj$/time/temporal/TemporalUnit;)Lj$/time/chrono/b;

    move-result-object p0

    return-object p0
.end method

.method public final k(Lj$/time/temporal/Temporal;Lj$/time/temporal/TemporalUnit;)J
    .registers 5

    .prologue
    const-string v0, "endExclusive"

    invoke-static {p1, v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    invoke-interface {p0}, Lj$/time/chrono/b;->getChronology()Lj$/time/chrono/m;

    move-result-object v0

    invoke-interface {v0, p1}, Lj$/time/chrono/m;->t(Lj$/time/temporal/Temporal;)Lj$/time/chrono/b;

    move-result-object p1

    instance-of v0, p2, Lj$/time/temporal/ChronoUnit;

    if-eqz v0, :cond_6f

    sget-object v0, Lj$/time/chrono/c;->a:[I

    move-object v1, p2

    check-cast v1, Lj$/time/temporal/ChronoUnit;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget v0, v0, v1

    packed-switch v0, :pswitch_data_7a

    const-string p0, "Unsupported unit: "

    invoke-static {p0, p2}, Lj$/time/h;->c(Ljava/lang/String;Ljava/lang/Object;)V

    const-wide/16 p0, 0x0

    return-wide p0

    :pswitch_27  #0x8
    sget-object p2, Lj$/time/temporal/a;->ERA:Lj$/time/temporal/a;

    invoke-interface {p1, p2}, Lj$/time/temporal/l;->f(Lj$/time/temporal/o;)J

    move-result-wide v0

    invoke-interface {p0, p2}, Lj$/time/temporal/l;->f(Lj$/time/temporal/o;)J

    move-result-wide p0

    sub-long/2addr v0, p0

    return-wide v0

    :pswitch_33  #0x7
    invoke-virtual {p0, p1}, Lj$/time/chrono/d;->v(Lj$/time/chrono/b;)J

    move-result-wide p0

    const-wide/16 v0, 0x2ee0

    div-long/2addr p0, v0

    return-wide p0

    :pswitch_3b  #0x6
    invoke-virtual {p0, p1}, Lj$/time/chrono/d;->v(Lj$/time/chrono/b;)J

    move-result-wide p0

    const-wide/16 v0, 0x4b0

    div-long/2addr p0, v0

    return-wide p0

    :pswitch_43  #0x5
    invoke-virtual {p0, p1}, Lj$/time/chrono/d;->v(Lj$/time/chrono/b;)J

    move-result-wide p0

    const-wide/16 v0, 0x78

    div-long/2addr p0, v0

    return-wide p0

    :pswitch_4b  #0x4
    invoke-virtual {p0, p1}, Lj$/time/chrono/d;->v(Lj$/time/chrono/b;)J

    move-result-wide p0

    const-wide/16 v0, 0xc

    div-long/2addr p0, v0

    return-wide p0

    :pswitch_53  #0x3
    invoke-virtual {p0, p1}, Lj$/time/chrono/d;->v(Lj$/time/chrono/b;)J

    move-result-wide p0

    return-wide p0

    :pswitch_58  #0x2
    invoke-interface {p1}, Lj$/time/chrono/b;->z()J

    move-result-wide p1

    invoke-interface {p0}, Lj$/time/chrono/b;->z()J

    move-result-wide v0

    sub-long/2addr p1, v0

    const-wide/16 v0, 0x7

    div-long/2addr p1, v0

    return-wide p1

    :pswitch_65  #0x1
    invoke-interface {p1}, Lj$/time/chrono/b;->z()J

    move-result-wide p1

    invoke-interface {p0}, Lj$/time/chrono/b;->z()J

    move-result-wide v0

    sub-long/2addr p1, v0

    return-wide p1

    :cond_6f
    const-string v0, "unit"

    invoke-static {p2, v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    invoke-interface {p2, p0, p1}, Lj$/time/temporal/TemporalUnit;->n(Lj$/time/temporal/Temporal;Lj$/time/temporal/Temporal;)J

    move-result-wide p0

    return-wide p0

    nop

    :pswitch_data_7a
    .packed-switch 0x1
        :pswitch_65  #00000001
        :pswitch_58  #00000002
        :pswitch_53  #00000003
        :pswitch_4b  #00000004
        :pswitch_43  #00000005
        :pswitch_3b  #00000006
        :pswitch_33  #00000007
        :pswitch_27  #00000008
    .end packed-switch
.end method

.method public final toString()Ljava/lang/String;
    .registers 10

    .prologue
    sget-object v0, Lj$/time/temporal/a;->YEAR_OF_ERA:Lj$/time/temporal/a;

    invoke-interface {p0, v0}, Lj$/time/temporal/l;->f(Lj$/time/temporal/o;)J

    move-result-wide v0

    sget-object v2, Lj$/time/temporal/a;->MONTH_OF_YEAR:Lj$/time/temporal/a;

    invoke-interface {p0, v2}, Lj$/time/temporal/l;->f(Lj$/time/temporal/o;)J

    move-result-wide v2

    sget-object v4, Lj$/time/temporal/a;->DAY_OF_MONTH:Lj$/time/temporal/a;

    invoke-interface {p0, v4}, Lj$/time/temporal/l;->f(Lj$/time/temporal/o;)J

    move-result-wide v4

    new-instance v6, Ljava/lang/StringBuilder;

    const/16 v7, 0x1e

    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(I)V

    invoke-interface {p0}, Lj$/time/chrono/b;->getChronology()Lj$/time/chrono/m;

    move-result-object v7

    invoke-interface {v7}, Lj$/time/chrono/m;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v7, " "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-interface {p0}, Lj$/time/chrono/b;->C()Lj$/time/chrono/n;

    move-result-object p0

    invoke-virtual {v6, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-wide/16 v0, 0xa

    cmp-long p0, v2, v0

    const-string v7, "-"

    const-string v8, "-0"

    if-gez p0, :cond_42

    move-object p0, v8

    goto :goto_43

    :cond_42
    move-object p0, v7

    :goto_43
    invoke-virtual {v6, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    cmp-long p0, v4, v0

    if-gez p0, :cond_4e

    move-object v7, v8

    :cond_4e
    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public final v(Lj$/time/chrono/b;)J
    .registers 10

    .prologue
    invoke-interface {p0}, Lj$/time/chrono/b;->getChronology()Lj$/time/chrono/m;

    move-result-object v0

    sget-object v1, Lj$/time/temporal/a;->MONTH_OF_YEAR:Lj$/time/temporal/a;

    invoke-interface {v0, v1}, Lj$/time/chrono/m;->u(Lj$/time/temporal/a;)Lj$/time/temporal/r;

    move-result-object v0

    iget-wide v0, v0, Lj$/time/temporal/r;->d:J

    const-wide/16 v2, 0xc

    cmp-long v0, v0, v2

    if-nez v0, :cond_31

    sget-object v0, Lj$/time/temporal/a;->PROLEPTIC_MONTH:Lj$/time/temporal/a;

    invoke-interface {p0, v0}, Lj$/time/temporal/l;->f(Lj$/time/temporal/o;)J

    move-result-wide v1

    const-wide/16 v3, 0x20

    mul-long/2addr v1, v3

    sget-object v5, Lj$/time/temporal/a;->DAY_OF_MONTH:Lj$/time/temporal/a;

    invoke-interface {p0, v5}, Lj$/time/temporal/l;->d(Lj$/time/temporal/o;)I

    move-result p0

    int-to-long v6, p0

    add-long/2addr v1, v6

    invoke-interface {p1, v0}, Lj$/time/temporal/l;->f(Lj$/time/temporal/o;)J

    move-result-wide v6

    mul-long/2addr v6, v3

    invoke-interface {p1, v5}, Lj$/time/temporal/l;->d(Lj$/time/temporal/o;)I

    move-result p0

    int-to-long p0, p0

    add-long/2addr v6, p0

    sub-long/2addr v6, v1

    div-long/2addr v6, v3

    return-wide v6

    :cond_31
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "ChronoLocalDateImpl only supports Chronologies with 12 months per year"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method
