.class public interface abstract Lj$/time/chrono/m;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ljava/lang/Comparable;


# direct methods
.method public static m(Lj$/time/temporal/l;)Lj$/time/chrono/m;
    .registers 2

    .prologue
    const-string v0, "temporal"

    invoke-static {p0, v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    sget-object v0, Lj$/time/temporal/p;->b:Lj$/time/format/a;

    invoke-interface {p0, v0}, Lj$/time/temporal/l;->b(Lj$/time/format/a;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lj$/time/chrono/m;

    sget-object v0, Lj$/time/chrono/t;->c:Lj$/time/chrono/t;

    if-eqz p0, :cond_12

    return-object p0

    :cond_12
    const-string p0, "defaultObj"

    invoke-static {v0, p0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    return-object v0
.end method


# virtual methods
.method public B(Lj$/time/temporal/Temporal;)Lj$/time/chrono/j;
    .registers 5

    .prologue
    :try_start_0
    invoke-static {p1}, Lj$/time/ZoneId;->n(Lj$/time/temporal/l;)Lj$/time/ZoneId;

    move-result-object v0
    :try_end_4
    .catch Lj$/time/c; {:try_start_0 .. :try_end_4} :catch_1b

    :try_start_4
    invoke-static {p1}, Lj$/time/Instant;->v(Lj$/time/temporal/Temporal;)Lj$/time/Instant;

    move-result-object v1

    invoke-interface {p0, v1, v0}, Lj$/time/chrono/m;->F(Lj$/time/Instant;Lj$/time/ZoneId;)Lj$/time/chrono/j;

    move-result-object p0
    :try_end_c
    .catch Lj$/time/c; {:try_start_4 .. :try_end_c} :catch_d

    return-object p0

    :catch_d
    :try_start_d
    invoke-interface {p0, p1}, Lj$/time/chrono/m;->r(Lj$/time/temporal/Temporal;)Lj$/time/chrono/e;

    move-result-object v1

    invoke-static {p0, v1}, Lj$/time/chrono/g;->n(Lj$/time/chrono/m;Lj$/time/temporal/Temporal;)Lj$/time/chrono/g;

    move-result-object p0

    const/4 v1, 0x0

    invoke-static {v0, v1, p0}, Lj$/time/chrono/l;->v(Lj$/time/ZoneId;Lj$/time/ZoneOffset;Lj$/time/chrono/g;)Lj$/time/chrono/l;

    move-result-object p0
    :try_end_1a
    .catch Lj$/time/c; {:try_start_d .. :try_end_1a} :catch_1b

    return-object p0

    :catch_1b
    move-exception p0

    new-instance v0, Lj$/time/c;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p1

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Unable to obtain ChronoZonedDateTime from TemporalAccessor: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0
.end method

.method public abstract F(Lj$/time/Instant;Lj$/time/ZoneId;)Lj$/time/chrono/j;
.end method

.method public abstract equals(Ljava/lang/Object;)Z
.end method

.method public abstract getId()Ljava/lang/String;
.end method

.method public abstract hashCode()I
.end method

.method public abstract q()Ljava/lang/String;
.end method

.method public r(Lj$/time/temporal/Temporal;)Lj$/time/chrono/e;
    .registers 5

    .prologue
    :try_start_0
    invoke-interface {p0, p1}, Lj$/time/chrono/m;->t(Lj$/time/temporal/Temporal;)Lj$/time/chrono/b;

    move-result-object p0

    invoke-static {p1}, Lj$/time/LocalTime;->E(Lj$/time/temporal/l;)Lj$/time/LocalTime;

    move-result-object v0

    invoke-interface {p0, v0}, Lj$/time/chrono/b;->A(Lj$/time/LocalTime;)Lj$/time/chrono/e;

    move-result-object p0
    :try_end_c
    .catch Lj$/time/c; {:try_start_0 .. :try_end_c} :catch_d

    return-object p0

    :catch_d
    move-exception p0

    new-instance v0, Lj$/time/c;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p1

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Unable to obtain ChronoLocalDateTime from TemporalAccessor: "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v0
.end method

.method public abstract t(Lj$/time/temporal/Temporal;)Lj$/time/chrono/b;
.end method

.method public abstract toString()Ljava/lang/String;
.end method

.method public abstract u(Lj$/time/temporal/a;)Lj$/time/temporal/r;
.end method

.method public abstract w(I)Lj$/time/chrono/n;
.end method
