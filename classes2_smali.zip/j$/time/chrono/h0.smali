.class public final Lj$/time/chrono/h0;
.super Lj$/time/chrono/a;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field public static final c:Lj$/time/chrono/h0;

.field private static final serialVersionUID:J = 0x26862bec417f21daL


# direct methods
.method static constructor <clinit>()V
    .registers 7

    new-instance v0, Lj$/time/chrono/h0;

    invoke-direct {v0}, Lj$/time/chrono/h0;-><init>()V

    sput-object v0, Lj$/time/chrono/h0;->c:Lj$/time/chrono/h0;

    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    new-instance v1, Ljava/util/HashMap;

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    new-instance v2, Ljava/util/HashMap;

    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    const-string v3, "BB"

    const-string v4, "BE"

    filled-new-array {v3, v4}, [Ljava/lang/String;

    move-result-object v5

    const-string v6, "en"

    invoke-virtual {v0, v6, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    filled-new-array {v3, v4}, [Ljava/lang/String;

    move-result-object v3

    const-string v4, "th"

    invoke-virtual {v0, v4, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, "B.B."

    const-string v3, "B.E."

    filled-new-array {v0, v3}, [Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v6, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, "พ.ศ."

    const-string v3, "ปีก่อนคริสต์กาลที่"

    filled-new-array {v0, v3}, [Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v4, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, "Before Buddhist"

    const-string v1, "Budhhist Era"

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v6, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v0, "พุทธศักราช"

    filled-new-array {v0, v3}, [Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v4, v0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .registers 2

    new-instance p0, Ljava/io/InvalidObjectException;

    const-string p1, "Deserialization via serialization delegate"

    invoke-direct {p0, p1}, Ljava/io/InvalidObjectException;-><init>(Ljava/lang/String;)V

    throw p0
.end method


# virtual methods
.method public final F(Lj$/time/Instant;Lj$/time/ZoneId;)Lj$/time/chrono/j;
    .registers 3

    invoke-static {p0, p1, p2}, Lj$/time/chrono/l;->E(Lj$/time/chrono/m;Lj$/time/Instant;Lj$/time/ZoneId;)Lj$/time/chrono/l;

    move-result-object p0

    return-object p0
.end method

.method public final getId()Ljava/lang/String;
    .registers 1

    const-string p0, "ThaiBuddhist"

    return-object p0
.end method

.method public final q()Ljava/lang/String;
    .registers 1

    const-string p0, "buddhist"

    return-object p0
.end method

.method public final t(Lj$/time/temporal/Temporal;)Lj$/time/chrono/b;
    .registers 2

    .prologue
    instance-of p0, p1, Lj$/time/chrono/j0;

    if-eqz p0, :cond_7

    check-cast p1, Lj$/time/chrono/j0;

    return-object p1

    :cond_7
    new-instance p0, Lj$/time/chrono/j0;

    invoke-static {p1}, Lj$/time/LocalDate;->E(Lj$/time/temporal/l;)Lj$/time/LocalDate;

    move-result-object p1

    invoke-direct {p0, p1}, Lj$/time/chrono/j0;-><init>(Lj$/time/LocalDate;)V

    return-object p0
.end method

.method public final u(Lj$/time/temporal/a;)Lj$/time/temporal/r;
    .registers 9

    .prologue
    sget-object p0, Lj$/time/chrono/g0;->a:[I

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    aget p0, p0, v0

    const/4 v0, 0x1

    if-eq p0, v0, :cond_38

    const/4 v0, 0x2

    const-wide/16 v1, 0x21f

    if-eq p0, v0, :cond_25

    const/4 v0, 0x3

    if-eq p0, v0, :cond_16

    iget-object p0, p1, Lj$/time/temporal/a;->b:Lj$/time/temporal/r;

    return-object p0

    :cond_16
    sget-object p0, Lj$/time/temporal/a;->YEAR:Lj$/time/temporal/a;

    iget-object p0, p0, Lj$/time/temporal/a;->b:Lj$/time/temporal/r;

    iget-wide v3, p0, Lj$/time/temporal/r;->a:J

    add-long/2addr v3, v1

    iget-wide p0, p0, Lj$/time/temporal/r;->d:J

    add-long/2addr p0, v1

    invoke-static {v3, v4, p0, p1}, Lj$/time/temporal/r;->e(JJ)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_25
    sget-object p0, Lj$/time/temporal/a;->YEAR:Lj$/time/temporal/a;

    iget-object p0, p0, Lj$/time/temporal/a;->b:Lj$/time/temporal/r;

    iget-wide v3, p0, Lj$/time/temporal/r;->a:J

    add-long/2addr v3, v1

    neg-long v3, v3

    const-wide/16 v5, 0x1

    add-long/2addr v3, v5

    iget-wide p0, p0, Lj$/time/temporal/r;->d:J

    add-long/2addr p0, v1

    invoke-static {v3, v4, p0, p1}, Lj$/time/temporal/r;->f(JJ)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_38
    sget-object p0, Lj$/time/temporal/a;->PROLEPTIC_MONTH:Lj$/time/temporal/a;

    iget-object p0, p0, Lj$/time/temporal/a;->b:Lj$/time/temporal/r;

    iget-wide v0, p0, Lj$/time/temporal/r;->a:J

    const-wide/16 v2, 0x1974

    add-long/2addr v0, v2

    iget-wide p0, p0, Lj$/time/temporal/r;->d:J

    add-long/2addr p0, v2

    invoke-static {v0, v1, p0, p1}, Lj$/time/temporal/r;->e(JJ)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0
.end method

.method public final w(I)Lj$/time/chrono/n;
    .registers 2

    .prologue
    if-eqz p1, :cond_f

    const/4 p0, 0x1

    if-ne p1, p0, :cond_8

    sget-object p0, Lj$/time/chrono/k0;->BE:Lj$/time/chrono/k0;

    return-object p0

    :cond_8
    const-string p0, "Invalid era: "

    invoke-static {p0, p1}, Lj$/time/h;->a(Ljava/lang/String;I)V

    const/4 p0, 0x0

    return-object p0

    :cond_f
    sget-object p0, Lj$/time/chrono/k0;->BEFORE_BE:Lj$/time/chrono/k0;

    return-object p0
.end method

.method public writeReplace()Ljava/lang/Object;
    .registers 3

    new-instance v0, Lj$/time/chrono/f0;

    const/4 v1, 0x1

    invoke-direct {v0, v1, p0}, Lj$/time/chrono/f0;-><init>(BLjava/lang/Object;)V

    return-object v0
.end method
