.class public final Lj$/time/chrono/z;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lj$/time/chrono/n;
.implements Ljava/io/Serializable;


# static fields
.field public static final d:Lj$/time/chrono/z;

.field public static final e:[Lj$/time/chrono/z;

.field private static final serialVersionUID:J = 0x145a0d680453ed8aL


# instance fields
.field public final transient a:I

.field public final transient b:Lj$/time/LocalDate;

.field public final transient c:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 12

    new-instance v0, Lj$/time/chrono/z;

    const/16 v1, 0x74c

    const/4 v2, 0x1

    invoke-static {v1, v2, v2}, Lj$/time/LocalDate;->of(III)Lj$/time/LocalDate;

    move-result-object v1

    const-string v3, "Meiji"

    const/4 v4, -0x1

    invoke-direct {v0, v4, v1, v3}, Lj$/time/chrono/z;-><init>(ILj$/time/LocalDate;Ljava/lang/String;)V

    sput-object v0, Lj$/time/chrono/z;->d:Lj$/time/chrono/z;

    new-instance v1, Lj$/time/chrono/z;

    const/4 v3, 0x7

    const/16 v4, 0x1e

    const/16 v5, 0x778

    invoke-static {v5, v3, v4}, Lj$/time/LocalDate;->of(III)Lj$/time/LocalDate;

    move-result-object v3

    const-string v4, "Taisho"

    const/4 v5, 0x0

    invoke-direct {v1, v5, v3, v4}, Lj$/time/chrono/z;-><init>(ILj$/time/LocalDate;Ljava/lang/String;)V

    new-instance v3, Lj$/time/chrono/z;

    const/16 v4, 0xc

    const/16 v6, 0x19

    const/16 v7, 0x786

    invoke-static {v7, v4, v6}, Lj$/time/LocalDate;->of(III)Lj$/time/LocalDate;

    move-result-object v4

    const-string v6, "Showa"

    invoke-direct {v3, v2, v4, v6}, Lj$/time/chrono/z;-><init>(ILj$/time/LocalDate;Ljava/lang/String;)V

    new-instance v4, Lj$/time/chrono/z;

    const/16 v6, 0x7c5

    const/16 v7, 0x8

    invoke-static {v6, v2, v7}, Lj$/time/LocalDate;->of(III)Lj$/time/LocalDate;

    move-result-object v6

    const-string v7, "Heisei"

    const/4 v8, 0x2

    invoke-direct {v4, v8, v6, v7}, Lj$/time/chrono/z;-><init>(ILj$/time/LocalDate;Ljava/lang/String;)V

    new-instance v6, Lj$/time/chrono/z;

    const/16 v7, 0x7e3

    const/4 v9, 0x5

    invoke-static {v7, v9, v2}, Lj$/time/LocalDate;->of(III)Lj$/time/LocalDate;

    move-result-object v7

    const-string v10, "Reiwa"

    const/4 v11, 0x3

    invoke-direct {v6, v11, v7, v10}, Lj$/time/chrono/z;-><init>(ILj$/time/LocalDate;Ljava/lang/String;)V

    new-array v7, v9, [Lj$/time/chrono/z;

    sput-object v7, Lj$/time/chrono/z;->e:[Lj$/time/chrono/z;

    aput-object v0, v7, v5

    aput-object v1, v7, v2

    aput-object v3, v7, v8

    aput-object v4, v7, v11

    const/4 v0, 0x4

    aput-object v6, v7, v0

    return-void
.end method

.method public constructor <init>(ILj$/time/LocalDate;Ljava/lang/String;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lj$/time/chrono/z;->a:I

    iput-object p2, p0, Lj$/time/chrono/z;->b:Lj$/time/LocalDate;

    iput-object p3, p0, Lj$/time/chrono/z;->c:Ljava/lang/String;

    return-void
.end method

.method public static m(Lj$/time/LocalDate;)Lj$/time/chrono/z;
    .registers 4

    .prologue
    sget-object v0, Lj$/time/chrono/y;->d:Lj$/time/LocalDate;

    invoke-virtual {p0, v0}, Lj$/time/LocalDate;->L(Lj$/time/chrono/b;)Z

    move-result v0

    if-nez v0, :cond_21

    sget-object v0, Lj$/time/chrono/z;->e:[Lj$/time/chrono/z;

    array-length v0, v0

    add-int/lit8 v0, v0, -0x1

    :goto_d
    if-ltz v0, :cond_1f

    sget-object v1, Lj$/time/chrono/z;->e:[Lj$/time/chrono/z;

    aget-object v1, v1, v0

    iget-object v2, v1, Lj$/time/chrono/z;->b:Lj$/time/LocalDate;

    invoke-virtual {p0, v2}, Lj$/time/LocalDate;->G(Lj$/time/chrono/b;)I

    move-result v2

    if-ltz v2, :cond_1c

    return-object v1

    :cond_1c
    add-int/lit8 v0, v0, -0x1

    goto :goto_d

    :cond_1f
    const/4 p0, 0x0

    return-object p0

    :cond_21
    new-instance p0, Lj$/time/c;

    const-string v0, "JapaneseDate before Meiji 6 are not supported"

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static q(I)Lj$/time/chrono/z;
    .registers 4

    .prologue
    add-int/lit8 v0, p0, 0x1

    if-ltz v0, :cond_c

    sget-object v1, Lj$/time/chrono/z;->e:[Lj$/time/chrono/z;

    array-length v2, v1

    if-ge v0, v2, :cond_c

    aget-object p0, v1, v0

    return-object p0

    :cond_c
    const-string v0, "Invalid era: "

    invoke-static {v0, p0}, Lj$/time/h;->a(Ljava/lang/String;I)V

    const/4 p0, 0x0

    return-object p0
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .registers 2

    new-instance p0, Ljava/io/InvalidObjectException;

    const-string p1, "Deserialization via serialization delegate"

    invoke-direct {p0, p1}, Ljava/io/InvalidObjectException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private writeReplace()Ljava/lang/Object;
    .registers 3

    new-instance v0, Lj$/time/chrono/f0;

    const/4 v1, 0x5

    invoke-direct {v0, v1, p0}, Lj$/time/chrono/f0;-><init>(BLjava/lang/Object;)V

    return-object v0
.end method


# virtual methods
.method public final getValue()I
    .registers 1

    iget p0, p0, Lj$/time/chrono/z;->a:I

    return p0
.end method

.method public final i(Lj$/time/temporal/o;)Lj$/time/temporal/r;
    .registers 3

    .prologue
    sget-object v0, Lj$/time/temporal/a;->ERA:Lj$/time/temporal/a;

    if-ne p1, v0, :cond_b

    sget-object p0, Lj$/time/chrono/w;->c:Lj$/time/chrono/w;

    invoke-virtual {p0, v0}, Lj$/time/chrono/w;->u(Lj$/time/temporal/a;)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_b
    invoke-super {p0, p1}, Lj$/time/chrono/n;->i(Lj$/time/temporal/o;)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0
.end method

.method public final n()Lj$/time/chrono/z;
    .registers 3

    .prologue
    sget-object v0, Lj$/time/chrono/z;->e:[Lj$/time/chrono/z;

    array-length v1, v0

    add-int/lit8 v1, v1, -0x1

    aget-object v0, v0, v1

    if-ne p0, v0, :cond_b

    const/4 p0, 0x0

    return-object p0

    :cond_b
    iget p0, p0, Lj$/time/chrono/z;->a:I

    add-int/lit8 p0, p0, 0x1

    invoke-static {p0}, Lj$/time/chrono/z;->q(I)Lj$/time/chrono/z;

    move-result-object p0

    return-object p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 1

    iget-object p0, p0, Lj$/time/chrono/z;->c:Ljava/lang/String;

    return-object p0
.end method
