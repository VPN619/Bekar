.class public final enum Lj$/time/chrono/s;
.super Ljava/lang/Enum;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lj$/time/chrono/n;


# static fields
.field public static final enum AH:Lj$/time/chrono/s;

.field public static final synthetic a:[Lj$/time/chrono/s;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    new-instance v0, Lj$/time/chrono/s;

    const-string v1, "AH"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lj$/time/chrono/s;->AH:Lj$/time/chrono/s;

    filled-new-array {v0}, [Lj$/time/chrono/s;

    move-result-object v0

    sput-object v0, Lj$/time/chrono/s;->a:[Lj$/time/chrono/s;

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lj$/time/chrono/s;
    .registers 2

    const-class v0, Lj$/time/chrono/s;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lj$/time/chrono/s;

    return-object p0
.end method

.method public static values()[Lj$/time/chrono/s;
    .registers 1

    sget-object v0, Lj$/time/chrono/s;->a:[Lj$/time/chrono/s;

    invoke-virtual {v0}, [Lj$/time/chrono/s;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lj$/time/chrono/s;

    return-object v0
.end method


# virtual methods
.method public final getValue()I
    .registers 1

    const/4 p0, 0x1

    return p0
.end method

.method public final i(Lj$/time/temporal/o;)Lj$/time/temporal/r;
    .registers 3

    .prologue
    sget-object v0, Lj$/time/temporal/a;->ERA:Lj$/time/temporal/a;

    if-ne p1, v0, :cond_b

    const-wide/16 p0, 0x1

    invoke-static {p0, p1, p0, p1}, Lj$/time/temporal/r;->e(JJ)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_b
    invoke-super {p0, p1}, Lj$/time/chrono/n;->i(Lj$/time/temporal/o;)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0
.end method
