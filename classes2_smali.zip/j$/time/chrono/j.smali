.class public interface abstract Lj$/time/chrono/j;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lj$/time/temporal/Temporal;
.implements Ljava/lang/Comparable;


# virtual methods
.method public a(JLj$/time/temporal/TemporalUnit;)Lj$/time/chrono/j;
    .registers 5

    invoke-interface {p0}, Lj$/time/chrono/j;->getChronology()Lj$/time/chrono/m;

    move-result-object v0

    invoke-super {p0, p1, p2, p3}, Lj$/time/temporal/Temporal;->a(JLj$/time/temporal/TemporalUnit;)Lj$/time/temporal/Temporal;

    move-result-object p0

    invoke-static {v0, p0}, Lj$/time/chrono/l;->n(Lj$/time/chrono/m;Lj$/time/temporal/Temporal;)Lj$/time/chrono/l;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic a(JLj$/time/temporal/TemporalUnit;)Lj$/time/temporal/Temporal;
    .registers 4

    invoke-interface {p0, p1, p2, p3}, Lj$/time/chrono/j;->a(JLj$/time/temporal/TemporalUnit;)Lj$/time/chrono/j;

    move-result-object p0

    return-object p0
.end method

.method public b(Lj$/time/format/a;)Ljava/lang/Object;
    .registers 3

    .prologue
    sget-object v0, Lj$/time/temporal/p;->e:Lj$/time/format/a;

    if-eq p1, v0, :cond_30

    sget-object v0, Lj$/time/temporal/p;->a:Lj$/time/format/a;

    if-ne p1, v0, :cond_9

    goto :goto_30

    :cond_9
    sget-object v0, Lj$/time/temporal/p;->d:Lj$/time/format/a;

    if-ne p1, v0, :cond_12

    invoke-interface {p0}, Lj$/time/chrono/j;->getOffset()Lj$/time/ZoneOffset;

    move-result-object p0

    return-object p0

    :cond_12
    sget-object v0, Lj$/time/temporal/p;->g:Lj$/time/format/a;

    if-ne p1, v0, :cond_1b

    invoke-interface {p0}, Lj$/time/chrono/j;->toLocalTime()Lj$/time/LocalTime;

    move-result-object p0

    return-object p0

    :cond_1b
    sget-object v0, Lj$/time/temporal/p;->b:Lj$/time/format/a;

    if-ne p1, v0, :cond_24

    invoke-interface {p0}, Lj$/time/chrono/j;->getChronology()Lj$/time/chrono/m;

    move-result-object p0

    return-object p0

    :cond_24
    sget-object v0, Lj$/time/temporal/p;->c:Lj$/time/format/a;

    if-ne p1, v0, :cond_2b

    sget-object p0, Lj$/time/temporal/ChronoUnit;->NANOS:Lj$/time/temporal/ChronoUnit;

    return-object p0

    :cond_2b
    invoke-virtual {p1, p0}, Lj$/time/format/a;->a(Lj$/time/temporal/l;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :cond_30
    :goto_30
    invoke-interface {p0}, Lj$/time/chrono/j;->getZone()Lj$/time/ZoneId;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic compareTo(Ljava/lang/Object;)I
    .registers 2

    check-cast p1, Lj$/time/chrono/j;

    invoke-interface {p0, p1}, Lj$/time/chrono/j;->o(Lj$/time/chrono/j;)I

    move-result p0

    return p0
.end method

.method public d(Lj$/time/temporal/o;)I
    .registers 4

    .prologue
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_2f

    sget-object v0, Lj$/time/chrono/i;->a:[I

    move-object v1, p1

    check-cast v1, Lj$/time/temporal/a;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget v0, v0, v1

    const/4 v1, 0x1

    if-eq v0, v1, :cond_27

    const/4 v1, 0x2

    if-eq v0, v1, :cond_1e

    invoke-interface {p0}, Lj$/time/chrono/j;->toLocalDateTime()Lj$/time/chrono/e;

    move-result-object p0

    invoke-interface {p0, p1}, Lj$/time/temporal/l;->d(Lj$/time/temporal/o;)I

    move-result p0

    return p0

    :cond_1e
    invoke-interface {p0}, Lj$/time/chrono/j;->getOffset()Lj$/time/ZoneOffset;

    move-result-object p0

    invoke-virtual {p0}, Lj$/time/ZoneOffset;->getTotalSeconds()I

    move-result p0

    return p0

    :cond_27
    new-instance p0, Lj$/time/temporal/q;

    const-string p1, "Invalid field \'InstantSeconds\' for get() method, use getLong() instead"

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_2f
    invoke-super {p0, p1}, Lj$/time/temporal/l;->d(Lj$/time/temporal/o;)I

    move-result p0

    return p0
.end method

.method public f(Lj$/time/temporal/o;)J
    .registers 4

    .prologue
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_2d

    sget-object v0, Lj$/time/chrono/i;->a:[I

    move-object v1, p1

    check-cast v1, Lj$/time/temporal/a;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget v0, v0, v1

    const/4 v1, 0x1

    if-eq v0, v1, :cond_28

    const/4 v1, 0x2

    if-eq v0, v1, :cond_1e

    invoke-interface {p0}, Lj$/time/chrono/j;->toLocalDateTime()Lj$/time/chrono/e;

    move-result-object p0

    invoke-interface {p0, p1}, Lj$/time/temporal/l;->f(Lj$/time/temporal/o;)J

    move-result-wide p0

    return-wide p0

    :cond_1e
    invoke-interface {p0}, Lj$/time/chrono/j;->getOffset()Lj$/time/ZoneOffset;

    move-result-object p0

    invoke-virtual {p0}, Lj$/time/ZoneOffset;->getTotalSeconds()I

    move-result p0

    int-to-long p0, p0

    return-wide p0

    :cond_28
    invoke-interface {p0}, Lj$/time/chrono/j;->toEpochSecond()J

    move-result-wide p0

    return-wide p0

    :cond_2d
    invoke-interface {p1, p0}, Lj$/time/temporal/o;->E(Lj$/time/temporal/l;)J

    move-result-wide p0

    return-wide p0
.end method

.method public getChronology()Lj$/time/chrono/m;
    .registers 1

    invoke-interface {p0}, Lj$/time/chrono/j;->toLocalDate()Lj$/time/chrono/b;

    move-result-object p0

    invoke-interface {p0}, Lj$/time/chrono/b;->getChronology()Lj$/time/chrono/m;

    move-result-object p0

    return-object p0
.end method

.method public abstract getOffset()Lj$/time/ZoneOffset;
.end method

.method public abstract getZone()Lj$/time/ZoneId;
.end method

.method public bridge synthetic h(Lj$/time/LocalDate;)Lj$/time/temporal/Temporal;
    .registers 2

    invoke-interface {p0, p1}, Lj$/time/chrono/j;->y(Lj$/time/temporal/m;)Lj$/time/chrono/j;

    move-result-object p0

    return-object p0
.end method

.method public i(Lj$/time/temporal/o;)Lj$/time/temporal/r;
    .registers 3

    .prologue
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_1b

    sget-object v0, Lj$/time/temporal/a;->INSTANT_SECONDS:Lj$/time/temporal/a;

    if-eq p1, v0, :cond_16

    sget-object v0, Lj$/time/temporal/a;->OFFSET_SECONDS:Lj$/time/temporal/a;

    if-ne p1, v0, :cond_d

    goto :goto_16

    :cond_d
    invoke-interface {p0}, Lj$/time/chrono/j;->toLocalDateTime()Lj$/time/chrono/e;

    move-result-object p0

    invoke-interface {p0, p1}, Lj$/time/temporal/l;->i(Lj$/time/temporal/o;)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_16
    :goto_16
    check-cast p1, Lj$/time/temporal/a;

    iget-object p0, p1, Lj$/time/temporal/a;->b:Lj$/time/temporal/r;

    return-object p0

    :cond_1b
    invoke-interface {p1, p0}, Lj$/time/temporal/o;->v(Lj$/time/temporal/l;)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0
.end method

.method public abstract l(Lj$/time/ZoneId;)Lj$/time/chrono/j;
.end method

.method public o(Lj$/time/chrono/j;)I
    .registers 6

    .prologue
    invoke-interface {p0}, Lj$/time/chrono/j;->toEpochSecond()J

    move-result-wide v0

    invoke-interface {p1}, Lj$/time/chrono/j;->toEpochSecond()J

    move-result-wide v2

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Long;->compare(JJ)I

    move-result v0

    if-nez v0, :cond_5c

    invoke-interface {p0}, Lj$/time/chrono/j;->toLocalTime()Lj$/time/LocalTime;

    move-result-object v0

    invoke-virtual {v0}, Lj$/time/LocalTime;->getNano()I

    move-result v0

    invoke-interface {p1}, Lj$/time/chrono/j;->toLocalTime()Lj$/time/LocalTime;

    move-result-object v1

    invoke-virtual {v1}, Lj$/time/LocalTime;->getNano()I

    move-result v1

    sub-int/2addr v0, v1

    if-nez v0, :cond_5c

    invoke-interface {p0}, Lj$/time/chrono/j;->toLocalDateTime()Lj$/time/chrono/e;

    move-result-object v0

    invoke-interface {p1}, Lj$/time/chrono/j;->toLocalDateTime()Lj$/time/chrono/e;

    move-result-object v1

    invoke-interface {v0, v1}, Lj$/time/chrono/e;->D(Lj$/time/chrono/e;)I

    move-result v0

    if-nez v0, :cond_5c

    invoke-interface {p0}, Lj$/time/chrono/j;->getZone()Lj$/time/ZoneId;

    move-result-object v0

    invoke-virtual {v0}, Lj$/time/ZoneId;->getId()Ljava/lang/String;

    move-result-object v0

    invoke-interface {p1}, Lj$/time/chrono/j;->getZone()Lj$/time/ZoneId;

    move-result-object v1

    invoke-virtual {v1}, Lj$/time/ZoneId;->getId()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result v0

    if-nez v0, :cond_5c

    invoke-interface {p0}, Lj$/time/chrono/j;->getChronology()Lj$/time/chrono/m;

    move-result-object p0

    invoke-interface {p1}, Lj$/time/chrono/j;->getChronology()Lj$/time/chrono/m;

    move-result-object p1

    check-cast p0, Lj$/time/chrono/a;

    invoke-interface {p0}, Lj$/time/chrono/m;->getId()Ljava/lang/String;

    move-result-object p0

    invoke-interface {p1}, Lj$/time/chrono/m;->getId()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result p0

    return p0

    :cond_5c
    return v0
.end method

.method public toEpochSecond()J
    .registers 5

    invoke-interface {p0}, Lj$/time/chrono/j;->toLocalDate()Lj$/time/chrono/b;

    move-result-object v0

    invoke-interface {v0}, Lj$/time/chrono/b;->z()J

    move-result-wide v0

    const-wide/32 v2, 0x15180

    mul-long/2addr v0, v2

    invoke-interface {p0}, Lj$/time/chrono/j;->toLocalTime()Lj$/time/LocalTime;

    move-result-object v2

    invoke-virtual {v2}, Lj$/time/LocalTime;->Q()I

    move-result v2

    int-to-long v2, v2

    add-long/2addr v0, v2

    invoke-interface {p0}, Lj$/time/chrono/j;->getOffset()Lj$/time/ZoneOffset;

    move-result-object p0

    invoke-virtual {p0}, Lj$/time/ZoneOffset;->getTotalSeconds()I

    move-result p0

    int-to-long v2, p0

    sub-long/2addr v0, v2

    return-wide v0
.end method

.method public toLocalDate()Lj$/time/chrono/b;
    .registers 1

    invoke-interface {p0}, Lj$/time/chrono/j;->toLocalDateTime()Lj$/time/chrono/e;

    move-result-object p0

    invoke-interface {p0}, Lj$/time/chrono/e;->toLocalDate()Lj$/time/chrono/b;

    move-result-object p0

    return-object p0
.end method

.method public abstract toLocalDateTime()Lj$/time/chrono/e;
.end method

.method public toLocalTime()Lj$/time/LocalTime;
    .registers 1

    invoke-interface {p0}, Lj$/time/chrono/j;->toLocalDateTime()Lj$/time/chrono/e;

    move-result-object p0

    invoke-interface {p0}, Lj$/time/chrono/e;->toLocalTime()Lj$/time/LocalTime;

    move-result-object p0

    return-object p0
.end method

.method public abstract x(Lj$/time/ZoneId;)Lj$/time/chrono/j;
.end method

.method public y(Lj$/time/temporal/m;)Lj$/time/chrono/j;
    .registers 3

    invoke-interface {p0}, Lj$/time/chrono/j;->getChronology()Lj$/time/chrono/m;

    move-result-object v0

    invoke-interface {p1, p0}, Lj$/time/temporal/m;->c(Lj$/time/temporal/Temporal;)Lj$/time/temporal/Temporal;

    move-result-object p0

    invoke-static {v0, p0}, Lj$/time/chrono/l;->n(Lj$/time/chrono/m;Lj$/time/temporal/Temporal;)Lj$/time/chrono/l;

    move-result-object p0

    return-object p0
.end method
