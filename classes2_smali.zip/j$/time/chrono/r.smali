.class public final Lj$/time/chrono/r;
.super Lj$/time/chrono/d;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field private static final serialVersionUID:J = -0x4846033461a5e4e4L


# instance fields
.field public final transient a:Lj$/time/chrono/p;

.field public final transient b:I

.field public final transient c:I

.field public final transient d:I


# direct methods
.method public constructor <init>(Lj$/time/chrono/p;III)V
    .registers 5

    invoke-direct {p0}, Lj$/time/chrono/d;-><init>()V

    invoke-virtual {p1, p2, p3, p4}, Lj$/time/chrono/p;->I(III)J

    iput-object p1, p0, Lj$/time/chrono/r;->a:Lj$/time/chrono/p;

    iput p2, p0, Lj$/time/chrono/r;->b:I

    iput p3, p0, Lj$/time/chrono/r;->c:I

    iput p4, p0, Lj$/time/chrono/r;->d:I

    return-void
.end method

.method public constructor <init>(Lj$/time/chrono/p;J)V
    .registers 8

    .prologue
    invoke-direct {p0}, Lj$/time/chrono/d;-><init>()V

    long-to-int p2, p2

    invoke-virtual {p1}, Lj$/time/chrono/p;->E()V

    iget p3, p1, Lj$/time/chrono/p;->e:I

    if-lt p2, p3, :cond_3f

    iget p3, p1, Lj$/time/chrono/p;->f:I

    if-ge p2, p3, :cond_3f

    iget-object p3, p1, Lj$/time/chrono/p;->d:[I

    invoke-static {p3, p2}, Ljava/util/Arrays;->binarySearch([II)I

    move-result p3

    const/4 v0, 0x2

    if-gez p3, :cond_1a

    neg-int p3, p3

    sub-int/2addr p3, v0

    :cond_1a
    iget v1, p1, Lj$/time/chrono/p;->g:I

    add-int v2, p3, v1

    div-int/lit8 v2, v2, 0xc

    add-int/2addr v1, p3

    rem-int/lit8 v1, v1, 0xc

    iget-object v3, p1, Lj$/time/chrono/p;->d:[I

    aget p3, v3, p3

    sub-int/2addr p2, p3

    const/4 p3, 0x1

    add-int/2addr v1, p3

    add-int/2addr p2, p3

    filled-new-array {v2, v1, p2}, [I

    move-result-object p2

    iput-object p1, p0, Lj$/time/chrono/r;->a:Lj$/time/chrono/p;

    const/4 p1, 0x0

    aget p1, p2, p1

    iput p1, p0, Lj$/time/chrono/r;->b:I

    aget p1, p2, p3

    iput p1, p0, Lj$/time/chrono/r;->c:I

    aget p1, p2, v0

    iput p1, p0, Lj$/time/chrono/r;->d:I

    return-void

    :cond_3f
    new-instance p0, Lj$/time/c;

    const-string p1, "Hijrah date out of range"

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .registers 2

    new-instance p0, Ljava/io/InvalidObjectException;

    const-string p1, "Deserialization via serialization delegate"

    invoke-direct {p0, p1}, Ljava/io/InvalidObjectException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private writeReplace()Ljava/lang/Object;
    .registers 3

    new-instance v0, Lj$/time/chrono/f0;

    const/4 v1, 0x6

    invoke-direct {v0, v1, p0}, Lj$/time/chrono/f0;-><init>(BLjava/lang/Object;)V

    return-object v0
.end method


# virtual methods
.method public final A(Lj$/time/LocalTime;)Lj$/time/chrono/e;
    .registers 3

    new-instance v0, Lj$/time/chrono/g;

    invoke-direct {v0, p0, p1}, Lj$/time/chrono/g;-><init>(Lj$/time/chrono/b;Lj$/time/LocalTime;)V

    return-object v0
.end method

.method public final C()Lj$/time/chrono/n;
    .registers 1

    sget-object p0, Lj$/time/chrono/s;->AH:Lj$/time/chrono/s;

    return-object p0
.end method

.method public final bridge synthetic E(J)Lj$/time/chrono/b;
    .registers 3

    invoke-virtual {p0, p1, p2}, Lj$/time/chrono/r;->L(J)Lj$/time/chrono/r;

    move-result-object p0

    return-object p0
.end method

.method public final bridge synthetic H(J)Lj$/time/chrono/b;
    .registers 3

    invoke-virtual {p0, p1, p2}, Lj$/time/chrono/r;->M(J)Lj$/time/chrono/r;

    move-result-object p0

    return-object p0
.end method

.method public final I(J)Lj$/time/chrono/b;
    .registers 5

    .prologue
    const-wide/16 v0, 0x0

    cmp-long v0, p1, v0

    if-nez v0, :cond_7

    return-object p0

    :cond_7
    iget v0, p0, Lj$/time/chrono/r;->b:I

    long-to-int p1, p1

    invoke-static {v0, p1}, Ljava/lang/Math;->addExact(II)I

    move-result p1

    iget p2, p0, Lj$/time/chrono/r;->c:I

    iget v0, p0, Lj$/time/chrono/r;->d:I

    invoke-virtual {p0, p1, p2, v0}, Lj$/time/chrono/r;->N(III)Lj$/time/chrono/r;

    move-result-object p0

    return-object p0
.end method

.method public final J(Lj$/time/temporal/m;)Lj$/time/chrono/b;
    .registers 2

    invoke-super {p0, p1}, Lj$/time/chrono/d;->J(Lj$/time/temporal/m;)Lj$/time/chrono/b;

    move-result-object p0

    check-cast p0, Lj$/time/chrono/r;

    return-object p0
.end method

.method public final K()I
    .registers 4

    iget-object v0, p0, Lj$/time/chrono/r;->a:Lj$/time/chrono/p;

    iget v1, p0, Lj$/time/chrono/r;->b:I

    iget v2, p0, Lj$/time/chrono/r;->c:I

    add-int/lit8 v2, v2, -0x1

    invoke-virtual {v0, v1, v2}, Lj$/time/chrono/p;->L(II)I

    move-result v0

    iget p0, p0, Lj$/time/chrono/r;->d:I

    add-int/2addr v0, p0

    return v0
.end method

.method public final L(J)Lj$/time/chrono/r;
    .registers 7

    new-instance v0, Lj$/time/chrono/r;

    iget-object v1, p0, Lj$/time/chrono/r;->a:Lj$/time/chrono/p;

    invoke-virtual {p0}, Lj$/time/chrono/r;->z()J

    move-result-wide v2

    add-long/2addr v2, p1

    invoke-direct {v0, v1, v2, v3}, Lj$/time/chrono/r;-><init>(Lj$/time/chrono/p;J)V

    return-object v0
.end method

.method public final M(J)Lj$/time/chrono/r;
    .registers 11

    .prologue
    const-wide/16 v0, 0x0

    cmp-long v0, p1, v0

    if-nez v0, :cond_7

    return-object p0

    :cond_7
    iget v0, p0, Lj$/time/chrono/r;->b:I

    int-to-long v0, v0

    const-wide/16 v2, 0xc

    mul-long/2addr v0, v2

    iget v4, p0, Lj$/time/chrono/r;->c:I

    add-int/lit8 v4, v4, -0x1

    int-to-long v4, v4

    add-long/2addr v0, v4

    add-long/2addr v0, p1

    iget-object p1, p0, Lj$/time/chrono/r;->a:Lj$/time/chrono/p;

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->floorDiv(JJ)J

    move-result-wide v4

    iget p2, p1, Lj$/time/chrono/p;->g:I

    div-int/lit8 v6, p2, 0xc

    int-to-long v6, v6

    cmp-long v6, v4, v6

    if-ltz v6, :cond_41

    iget-object p1, p1, Lj$/time/chrono/p;->d:[I

    array-length p1, p1

    add-int/lit8 p1, p1, -0x1

    add-int/2addr p1, p2

    div-int/lit8 p1, p1, 0xc

    add-int/lit8 p1, p1, -0x1

    int-to-long p1, p1

    cmp-long p1, v4, p1

    if-gtz p1, :cond_41

    long-to-int p1, v4

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->floorMod(JJ)J

    move-result-wide v0

    long-to-int p2, v0

    add-int/lit8 p2, p2, 0x1

    iget v0, p0, Lj$/time/chrono/r;->d:I

    invoke-virtual {p0, p1, p2, v0}, Lj$/time/chrono/r;->N(III)Lj$/time/chrono/r;

    move-result-object p0

    return-object p0

    :cond_41
    new-instance p0, Lj$/time/c;

    new-instance p1, Ljava/lang/StringBuilder;

    const-string p2, "Invalid Hijrah year: "

    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final N(III)Lj$/time/chrono/r;
    .registers 5

    .prologue
    iget-object v0, p0, Lj$/time/chrono/r;->a:Lj$/time/chrono/p;

    invoke-virtual {v0, p1, p2}, Lj$/time/chrono/p;->J(II)I

    move-result v0

    if-le p3, v0, :cond_9

    move p3, v0

    :cond_9
    iget-object p0, p0, Lj$/time/chrono/r;->a:Lj$/time/chrono/p;

    new-instance v0, Lj$/time/chrono/r;

    invoke-direct {v0, p0, p1, p2, p3}, Lj$/time/chrono/r;-><init>(Lj$/time/chrono/p;III)V

    return-object v0
.end method

.method public final O(JLj$/time/temporal/o;)Lj$/time/chrono/r;
    .registers 11

    .prologue
    instance-of v0, p3, Lj$/time/temporal/a;

    if-eqz v0, :cond_dc

    move-object v0, p3

    check-cast v0, Lj$/time/temporal/a;

    iget-object v1, p0, Lj$/time/chrono/r;->a:Lj$/time/chrono/p;

    invoke-virtual {v1, v0}, Lj$/time/chrono/p;->u(Lj$/time/temporal/a;)Lj$/time/temporal/r;

    move-result-object v1

    invoke-virtual {v1, p1, p2, v0}, Lj$/time/temporal/r;->b(JLj$/time/temporal/o;)V

    long-to-int v1, p1

    sget-object v2, Lj$/time/chrono/q;->a:[I

    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    aget v0, v2, v0

    const-wide/16 v2, 0x7

    const/4 v4, 0x1

    packed-switch v0, :pswitch_data_e4

    new-instance p0, Lj$/time/temporal/q;

    const-string p1, "Unsupported field: "

    invoke-static {p1, p3}, Lj$/time/d;->a(Ljava/lang/String;Lj$/time/temporal/o;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :pswitch_2b  #0xd
    iget p1, p0, Lj$/time/chrono/r;->b:I

    sub-int/2addr v4, p1

    iget p1, p0, Lj$/time/chrono/r;->c:I

    iget p2, p0, Lj$/time/chrono/r;->d:I

    invoke-virtual {p0, v4, p1, p2}, Lj$/time/chrono/r;->N(III)Lj$/time/chrono/r;

    move-result-object p0

    return-object p0

    :pswitch_37  #0xc
    iget p1, p0, Lj$/time/chrono/r;->c:I

    iget p2, p0, Lj$/time/chrono/r;->d:I

    invoke-virtual {p0, v1, p1, p2}, Lj$/time/chrono/r;->N(III)Lj$/time/chrono/r;

    move-result-object p0

    return-object p0

    :pswitch_40  #0xb
    iget p1, p0, Lj$/time/chrono/r;->b:I

    if-lt p1, v4, :cond_45

    goto :goto_47

    :cond_45
    rsub-int/lit8 v1, v1, 0x1

    :goto_47
    iget p1, p0, Lj$/time/chrono/r;->c:I

    iget p2, p0, Lj$/time/chrono/r;->d:I

    invoke-virtual {p0, v1, p1, p2}, Lj$/time/chrono/r;->N(III)Lj$/time/chrono/r;

    move-result-object p0

    return-object p0

    :pswitch_50  #0xa
    iget p3, p0, Lj$/time/chrono/r;->b:I

    int-to-long v0, p3

    const-wide/16 v2, 0xc

    mul-long/2addr v0, v2

    iget p3, p0, Lj$/time/chrono/r;->c:I

    int-to-long v2, p3

    add-long/2addr v0, v2

    const-wide/16 v2, 0x1

    sub-long/2addr v0, v2

    sub-long/2addr p1, v0

    invoke-virtual {p0, p1, p2}, Lj$/time/chrono/r;->M(J)Lj$/time/chrono/r;

    move-result-object p0

    return-object p0

    :pswitch_63  #0x9
    iget p1, p0, Lj$/time/chrono/r;->b:I

    iget p2, p0, Lj$/time/chrono/r;->d:I

    invoke-virtual {p0, p1, v1, p2}, Lj$/time/chrono/r;->N(III)Lj$/time/chrono/r;

    move-result-object p0

    return-object p0

    :pswitch_6c  #0x8
    sget-object p3, Lj$/time/temporal/a;->ALIGNED_WEEK_OF_YEAR:Lj$/time/temporal/a;

    invoke-virtual {p0, p3}, Lj$/time/chrono/r;->f(Lj$/time/temporal/o;)J

    move-result-wide v0

    sub-long/2addr p1, v0

    mul-long/2addr p1, v2

    invoke-virtual {p0, p1, p2}, Lj$/time/chrono/r;->L(J)Lj$/time/chrono/r;

    move-result-object p0

    return-object p0

    :pswitch_79  #0x7
    new-instance p3, Lj$/time/chrono/r;

    iget-object p0, p0, Lj$/time/chrono/r;->a:Lj$/time/chrono/p;

    invoke-direct {p3, p0, p1, p2}, Lj$/time/chrono/r;-><init>(Lj$/time/chrono/p;J)V

    return-object p3

    :pswitch_81  #0x6
    sget-object p3, Lj$/time/temporal/a;->ALIGNED_DAY_OF_WEEK_IN_YEAR:Lj$/time/temporal/a;

    invoke-virtual {p0, p3}, Lj$/time/chrono/r;->f(Lj$/time/temporal/o;)J

    move-result-wide v0

    sub-long/2addr p1, v0

    invoke-virtual {p0, p1, p2}, Lj$/time/chrono/r;->L(J)Lj$/time/chrono/r;

    move-result-object p0

    return-object p0

    :pswitch_8d  #0x5
    sget-object p3, Lj$/time/temporal/a;->ALIGNED_DAY_OF_WEEK_IN_MONTH:Lj$/time/temporal/a;

    invoke-virtual {p0, p3}, Lj$/time/chrono/r;->f(Lj$/time/temporal/o;)J

    move-result-wide v0

    sub-long/2addr p1, v0

    invoke-virtual {p0, p1, p2}, Lj$/time/chrono/r;->L(J)Lj$/time/chrono/r;

    move-result-object p0

    return-object p0

    :pswitch_99  #0x4
    invoke-virtual {p0}, Lj$/time/chrono/r;->z()J

    move-result-wide v0

    const-wide/16 v5, 0x3

    add-long/2addr v0, v5

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->floorMod(JJ)J

    move-result-wide v0

    long-to-int p3, v0

    add-int/2addr p3, v4

    int-to-long v0, p3

    sub-long/2addr p1, v0

    invoke-virtual {p0, p1, p2}, Lj$/time/chrono/r;->L(J)Lj$/time/chrono/r;

    move-result-object p0

    return-object p0

    :pswitch_ad  #0x3
    sget-object p3, Lj$/time/temporal/a;->ALIGNED_WEEK_OF_MONTH:Lj$/time/temporal/a;

    invoke-virtual {p0, p3}, Lj$/time/chrono/r;->f(Lj$/time/temporal/o;)J

    move-result-wide v0

    sub-long/2addr p1, v0

    mul-long/2addr p1, v2

    invoke-virtual {p0, p1, p2}, Lj$/time/chrono/r;->L(J)Lj$/time/chrono/r;

    move-result-object p0

    return-object p0

    :pswitch_ba  #0x2
    iget-object p1, p0, Lj$/time/chrono/r;->a:Lj$/time/chrono/p;

    iget p2, p0, Lj$/time/chrono/r;->b:I

    const/16 p3, 0xc

    invoke-virtual {p1, p2, p3}, Lj$/time/chrono/p;->L(II)I

    move-result p1

    invoke-static {v1, p1}, Ljava/lang/Math;->min(II)I

    move-result p1

    invoke-virtual {p0}, Lj$/time/chrono/r;->K()I

    move-result p2

    sub-int/2addr p1, p2

    int-to-long p1, p1

    invoke-virtual {p0, p1, p2}, Lj$/time/chrono/r;->L(J)Lj$/time/chrono/r;

    move-result-object p0

    return-object p0

    :pswitch_d3  #0x1
    iget p1, p0, Lj$/time/chrono/r;->b:I

    iget p2, p0, Lj$/time/chrono/r;->c:I

    invoke-virtual {p0, p1, p2, v1}, Lj$/time/chrono/r;->N(III)Lj$/time/chrono/r;

    move-result-object p0

    return-object p0

    :cond_dc
    invoke-super {p0, p1, p2, p3}, Lj$/time/chrono/d;->g(JLj$/time/temporal/o;)Lj$/time/chrono/b;

    move-result-object p0

    check-cast p0, Lj$/time/chrono/r;

    return-object p0

    nop

    :pswitch_data_e4
    .packed-switch 0x1
        :pswitch_d3  #00000001
        :pswitch_ba  #00000002
        :pswitch_ad  #00000003
        :pswitch_99  #00000004
        :pswitch_8d  #00000005
        :pswitch_81  #00000006
        :pswitch_79  #00000007
        :pswitch_6c  #00000008
        :pswitch_63  #00000009
        :pswitch_50  #0000000a
        :pswitch_40  #0000000b
        :pswitch_37  #0000000c
        :pswitch_2b  #0000000d
    .end packed-switch
.end method

.method public final a(JLj$/time/temporal/TemporalUnit;)Lj$/time/chrono/b;
    .registers 4

    invoke-super {p0, p1, p2, p3}, Lj$/time/chrono/d;->a(JLj$/time/temporal/TemporalUnit;)Lj$/time/chrono/b;

    move-result-object p0

    check-cast p0, Lj$/time/chrono/r;

    return-object p0
.end method

.method public final a(JLj$/time/temporal/TemporalUnit;)Lj$/time/temporal/Temporal;
    .registers 4

    invoke-super {p0, p1, p2, p3}, Lj$/time/chrono/d;->a(JLj$/time/temporal/TemporalUnit;)Lj$/time/chrono/b;

    move-result-object p0

    check-cast p0, Lj$/time/chrono/r;

    return-object p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .prologue
    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lj$/time/chrono/r;

    const/4 v2, 0x0

    if-eqz v1, :cond_28

    check-cast p1, Lj$/time/chrono/r;

    iget v1, p0, Lj$/time/chrono/r;->b:I

    iget v3, p1, Lj$/time/chrono/r;->b:I

    if-ne v1, v3, :cond_28

    iget v1, p0, Lj$/time/chrono/r;->c:I

    iget v3, p1, Lj$/time/chrono/r;->c:I

    if-ne v1, v3, :cond_28

    iget v1, p0, Lj$/time/chrono/r;->d:I

    iget v3, p1, Lj$/time/chrono/r;->d:I

    if-ne v1, v3, :cond_28

    iget-object p0, p0, Lj$/time/chrono/r;->a:Lj$/time/chrono/p;

    iget-object p1, p1, Lj$/time/chrono/r;->a:Lj$/time/chrono/p;

    invoke-virtual {p0, p1}, Lj$/time/chrono/a;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_28

    return v0

    :cond_28
    return v2
.end method

.method public final f(Lj$/time/temporal/o;)J
    .registers 6

    .prologue
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_78

    sget-object v0, Lj$/time/chrono/q;->a:[I

    move-object v1, p1

    check-cast v1, Lj$/time/temporal/a;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget v0, v0, v1

    const/4 v1, 0x1

    packed-switch v0, :pswitch_data_7e

    new-instance p0, Lj$/time/temporal/q;

    const-string v0, "Unsupported field: "

    invoke-static {v0, p1}, Lj$/time/d;->a(Ljava/lang/String;Lj$/time/temporal/o;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :pswitch_1f  #0xd
    iget p0, p0, Lj$/time/chrono/r;->b:I

    if-le p0, v1, :cond_24

    goto :goto_25

    :cond_24
    const/4 v1, 0x0

    :goto_25
    int-to-long p0, v1

    return-wide p0

    :pswitch_27  #0xc
    iget p0, p0, Lj$/time/chrono/r;->b:I

    :goto_29
    int-to-long p0, p0

    return-wide p0

    :pswitch_2b  #0xb
    iget p0, p0, Lj$/time/chrono/r;->b:I

    goto :goto_29

    :pswitch_2e  #0xa
    iget p1, p0, Lj$/time/chrono/r;->b:I

    int-to-long v0, p1

    const-wide/16 v2, 0xc

    mul-long/2addr v0, v2

    iget p0, p0, Lj$/time/chrono/r;->c:I

    int-to-long p0, p0

    add-long/2addr v0, p0

    const-wide/16 p0, 0x1

    sub-long/2addr v0, p0

    return-wide v0

    :pswitch_3c  #0x9
    iget p0, p0, Lj$/time/chrono/r;->c:I

    goto :goto_29

    :pswitch_3f  #0x8
    invoke-virtual {p0}, Lj$/time/chrono/r;->K()I

    move-result p0

    sub-int/2addr p0, v1

    div-int/lit8 p0, p0, 0x7

    :goto_46
    add-int/2addr p0, v1

    goto :goto_29

    :pswitch_48  #0x7
    invoke-virtual {p0}, Lj$/time/chrono/r;->z()J

    move-result-wide p0

    return-wide p0

    :pswitch_4d  #0x6
    invoke-virtual {p0}, Lj$/time/chrono/r;->K()I

    move-result p0

    sub-int/2addr p0, v1

    rem-int/lit8 p0, p0, 0x7

    goto :goto_46

    :pswitch_55  #0x5
    iget p0, p0, Lj$/time/chrono/r;->d:I

    sub-int/2addr p0, v1

    rem-int/lit8 p0, p0, 0x7

    goto :goto_46

    :pswitch_5b  #0x4
    invoke-virtual {p0}, Lj$/time/chrono/r;->z()J

    move-result-wide p0

    const-wide/16 v2, 0x3

    add-long/2addr p0, v2

    const-wide/16 v2, 0x7

    invoke-static {p0, p1, v2, v3}, Ljava/lang/Math;->floorMod(JJ)J

    move-result-wide p0

    long-to-int p0, p0

    goto :goto_46

    :pswitch_6a  #0x3
    iget p0, p0, Lj$/time/chrono/r;->d:I

    sub-int/2addr p0, v1

    div-int/lit8 p0, p0, 0x7

    goto :goto_46

    :pswitch_70  #0x2
    invoke-virtual {p0}, Lj$/time/chrono/r;->K()I

    move-result p0

    goto :goto_29

    :pswitch_75  #0x1
    iget p0, p0, Lj$/time/chrono/r;->d:I

    goto :goto_29

    :cond_78
    invoke-interface {p1, p0}, Lj$/time/temporal/o;->E(Lj$/time/temporal/l;)J

    move-result-wide p0

    return-wide p0

    nop

    :pswitch_data_7e
    .packed-switch 0x1
        :pswitch_75  #00000001
        :pswitch_70  #00000002
        :pswitch_6a  #00000003
        :pswitch_5b  #00000004
        :pswitch_55  #00000005
        :pswitch_4d  #00000006
        :pswitch_48  #00000007
        :pswitch_3f  #00000008
        :pswitch_3c  #00000009
        :pswitch_2e  #0000000a
        :pswitch_2b  #0000000b
        :pswitch_27  #0000000c
        :pswitch_1f  #0000000d
    .end packed-switch
.end method

.method public final bridge synthetic g(JLj$/time/temporal/o;)Lj$/time/chrono/b;
    .registers 4

    invoke-virtual {p0, p1, p2, p3}, Lj$/time/chrono/r;->O(JLj$/time/temporal/o;)Lj$/time/chrono/r;

    move-result-object p0

    return-object p0
.end method

.method public final bridge synthetic g(JLj$/time/temporal/o;)Lj$/time/temporal/Temporal;
    .registers 4

    invoke-virtual {p0, p1, p2, p3}, Lj$/time/chrono/r;->O(JLj$/time/temporal/o;)Lj$/time/chrono/r;

    move-result-object p0

    return-object p0
.end method

.method public final getChronology()Lj$/time/chrono/m;
    .registers 1

    iget-object p0, p0, Lj$/time/chrono/r;->a:Lj$/time/chrono/p;

    return-object p0
.end method

.method public final h(Lj$/time/LocalDate;)Lj$/time/temporal/Temporal;
    .registers 2

    invoke-super {p0, p1}, Lj$/time/chrono/d;->J(Lj$/time/temporal/m;)Lj$/time/chrono/b;

    move-result-object p0

    check-cast p0, Lj$/time/chrono/r;

    return-object p0
.end method

.method public final hashCode()I
    .registers 5

    iget v0, p0, Lj$/time/chrono/r;->b:I

    iget v1, p0, Lj$/time/chrono/r;->c:I

    iget v2, p0, Lj$/time/chrono/r;->d:I

    iget-object p0, p0, Lj$/time/chrono/r;->a:Lj$/time/chrono/p;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    and-int/lit16 p0, v0, -0x800

    const v3, 0x7d2cfbb3

    xor-int/2addr p0, v3

    shl-int/lit8 v0, v0, 0xb

    shl-int/lit8 v1, v1, 0x6

    add-int/2addr v0, v1

    add-int/2addr v0, v2

    xor-int/2addr p0, v0

    return p0
.end method

.method public final i(Lj$/time/temporal/o;)Lj$/time/temporal/r;
    .registers 6

    .prologue
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_59

    invoke-interface {p0, p1}, Lj$/time/chrono/b;->e(Lj$/time/temporal/o;)Z

    move-result v0

    if-eqz v0, :cond_4d

    check-cast p1, Lj$/time/temporal/a;

    sget-object v0, Lj$/time/chrono/q;->a:[I

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget v0, v0, v1

    const/4 v1, 0x1

    const-wide/16 v2, 0x1

    if-eq v0, v1, :cond_3d

    const/4 v1, 0x2

    if-eq v0, v1, :cond_2d

    const/4 v1, 0x3

    if-eq v0, v1, :cond_26

    iget-object p0, p0, Lj$/time/chrono/r;->a:Lj$/time/chrono/p;

    invoke-virtual {p0, p1}, Lj$/time/chrono/p;->u(Lj$/time/temporal/a;)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_26
    const-wide/16 p0, 0x5

    invoke-static {v2, v3, p0, p1}, Lj$/time/temporal/r;->e(JJ)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_2d
    iget-object p1, p0, Lj$/time/chrono/r;->a:Lj$/time/chrono/p;

    iget p0, p0, Lj$/time/chrono/r;->b:I

    const/16 v0, 0xc

    invoke-virtual {p1, p0, v0}, Lj$/time/chrono/p;->L(II)I

    move-result p0

    int-to-long p0, p0

    invoke-static {v2, v3, p0, p1}, Lj$/time/temporal/r;->e(JJ)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_3d
    iget-object p1, p0, Lj$/time/chrono/r;->a:Lj$/time/chrono/p;

    iget v0, p0, Lj$/time/chrono/r;->b:I

    iget p0, p0, Lj$/time/chrono/r;->c:I

    invoke-virtual {p1, v0, p0}, Lj$/time/chrono/p;->J(II)I

    move-result p0

    int-to-long p0, p0

    invoke-static {v2, v3, p0, p1}, Lj$/time/temporal/r;->e(JJ)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_4d
    new-instance p0, Lj$/time/temporal/q;

    const-string v0, "Unsupported field: "

    invoke-static {v0, p1}, Lj$/time/d;->a(Ljava/lang/String;Lj$/time/temporal/o;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_59
    invoke-interface {p1, p0}, Lj$/time/temporal/o;->v(Lj$/time/temporal/l;)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0
.end method

.method public final j(JLj$/time/temporal/TemporalUnit;)Lj$/time/chrono/b;
    .registers 4

    invoke-super {p0, p1, p2, p3}, Lj$/time/chrono/d;->j(JLj$/time/temporal/TemporalUnit;)Lj$/time/chrono/b;

    move-result-object p0

    check-cast p0, Lj$/time/chrono/r;

    return-object p0
.end method

.method public final j(JLj$/time/temporal/TemporalUnit;)Lj$/time/temporal/Temporal;
    .registers 4

    invoke-super {p0, p1, p2, p3}, Lj$/time/chrono/d;->j(JLj$/time/temporal/TemporalUnit;)Lj$/time/chrono/b;

    move-result-object p0

    check-cast p0, Lj$/time/chrono/r;

    return-object p0
.end method

.method public final z()J
    .registers 4

    iget-object v0, p0, Lj$/time/chrono/r;->a:Lj$/time/chrono/p;

    iget v1, p0, Lj$/time/chrono/r;->b:I

    iget v2, p0, Lj$/time/chrono/r;->c:I

    iget p0, p0, Lj$/time/chrono/r;->d:I

    invoke-virtual {v0, v1, v2, p0}, Lj$/time/chrono/p;->I(III)J

    move-result-wide v0

    return-wide v0
.end method
