.class public interface abstract Lj$/time/chrono/b;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lj$/time/temporal/Temporal;
.implements Lj$/time/temporal/m;
.implements Ljava/lang/Comparable;


# virtual methods
.method public A(Lj$/time/LocalTime;)Lj$/time/chrono/e;
    .registers 3

    new-instance v0, Lj$/time/chrono/g;

    invoke-direct {v0, p0, p1}, Lj$/time/chrono/g;-><init>(Lj$/time/chrono/b;Lj$/time/LocalTime;)V

    return-object v0
.end method

.method public C()Lj$/time/chrono/n;
    .registers 3

    invoke-interface {p0}, Lj$/time/chrono/b;->getChronology()Lj$/time/chrono/m;

    move-result-object v0

    sget-object v1, Lj$/time/temporal/a;->ERA:Lj$/time/temporal/a;

    invoke-interface {p0, v1}, Lj$/time/temporal/l;->d(Lj$/time/temporal/o;)I

    move-result p0

    invoke-interface {v0, p0}, Lj$/time/chrono/m;->w(I)Lj$/time/chrono/n;

    move-result-object p0

    return-object p0
.end method

.method public G(Lj$/time/chrono/b;)I
    .registers 6

    .prologue
    invoke-interface {p0}, Lj$/time/chrono/b;->z()J

    move-result-wide v0

    invoke-interface {p1}, Lj$/time/chrono/b;->z()J

    move-result-wide v2

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Long;->compare(JJ)I

    move-result v0

    if-nez v0, :cond_25

    invoke-interface {p0}, Lj$/time/chrono/b;->getChronology()Lj$/time/chrono/m;

    move-result-object p0

    invoke-interface {p1}, Lj$/time/chrono/b;->getChronology()Lj$/time/chrono/m;

    move-result-object p1

    check-cast p0, Lj$/time/chrono/a;

    invoke-interface {p0}, Lj$/time/chrono/m;->getId()Ljava/lang/String;

    move-result-object p0

    invoke-interface {p1}, Lj$/time/chrono/m;->getId()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result p0

    return p0

    :cond_25
    return v0
.end method

.method public a(JLj$/time/temporal/TemporalUnit;)Lj$/time/chrono/b;
    .registers 5

    invoke-interface {p0}, Lj$/time/chrono/b;->getChronology()Lj$/time/chrono/m;

    move-result-object v0

    invoke-super {p0, p1, p2, p3}, Lj$/time/temporal/Temporal;->a(JLj$/time/temporal/TemporalUnit;)Lj$/time/temporal/Temporal;

    move-result-object p0

    invoke-static {v0, p0}, Lj$/time/chrono/d;->n(Lj$/time/chrono/m;Lj$/time/temporal/Temporal;)Lj$/time/chrono/b;

    move-result-object p0

    return-object p0
.end method

.method public b(Lj$/time/format/a;)Ljava/lang/Object;
    .registers 3

    .prologue
    sget-object v0, Lj$/time/temporal/p;->a:Lj$/time/format/a;

    if-eq p1, v0, :cond_27

    sget-object v0, Lj$/time/temporal/p;->e:Lj$/time/format/a;

    if-eq p1, v0, :cond_27

    sget-object v0, Lj$/time/temporal/p;->d:Lj$/time/format/a;

    if-ne p1, v0, :cond_d

    goto :goto_27

    :cond_d
    sget-object v0, Lj$/time/temporal/p;->g:Lj$/time/format/a;

    if-ne p1, v0, :cond_12

    goto :goto_27

    :cond_12
    sget-object v0, Lj$/time/temporal/p;->b:Lj$/time/format/a;

    if-ne p1, v0, :cond_1b

    invoke-interface {p0}, Lj$/time/chrono/b;->getChronology()Lj$/time/chrono/m;

    move-result-object p0

    return-object p0

    :cond_1b
    sget-object v0, Lj$/time/temporal/p;->c:Lj$/time/format/a;

    if-ne p1, v0, :cond_22

    sget-object p0, Lj$/time/temporal/ChronoUnit;->DAYS:Lj$/time/temporal/ChronoUnit;

    return-object p0

    :cond_22
    invoke-virtual {p1, p0}, Lj$/time/format/a;->a(Lj$/time/temporal/l;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :cond_27
    :goto_27
    const/4 p0, 0x0

    return-object p0
.end method

.method public c(Lj$/time/temporal/Temporal;)Lj$/time/temporal/Temporal;
    .registers 5

    sget-object v0, Lj$/time/temporal/a;->EPOCH_DAY:Lj$/time/temporal/a;

    invoke-interface {p0}, Lj$/time/chrono/b;->z()J

    move-result-wide v1

    invoke-interface {p1, v1, v2, v0}, Lj$/time/temporal/Temporal;->g(JLj$/time/temporal/o;)Lj$/time/temporal/Temporal;

    move-result-object p0

    return-object p0
.end method

.method public bridge synthetic compareTo(Ljava/lang/Object;)I
    .registers 2

    check-cast p1, Lj$/time/chrono/b;

    invoke-interface {p0, p1}, Lj$/time/chrono/b;->G(Lj$/time/chrono/b;)I

    move-result p0

    return p0
.end method

.method public e(Lj$/time/temporal/o;)Z
    .registers 3

    .prologue
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_b

    check-cast p1, Lj$/time/temporal/a;

    invoke-virtual {p1}, Lj$/time/temporal/a;->isDateBased()Z

    move-result p0

    return p0

    :cond_b
    if-eqz p1, :cond_15

    invoke-interface {p1, p0}, Lj$/time/temporal/o;->n(Lj$/time/temporal/l;)Z

    move-result p0

    if-eqz p0, :cond_15

    const/4 p0, 0x1

    return p0

    :cond_15
    const/4 p0, 0x0

    return p0
.end method

.method public abstract g(JLj$/time/temporal/o;)Lj$/time/chrono/b;
.end method

.method public abstract getChronology()Lj$/time/chrono/m;
.end method

.method public abstract hashCode()I
.end method

.method public abstract j(JLj$/time/temporal/TemporalUnit;)Lj$/time/chrono/b;
.end method

.method public abstract k(Lj$/time/temporal/Temporal;Lj$/time/temporal/TemporalUnit;)J
.end method

.method public abstract toString()Ljava/lang/String;
.end method

.method public z()J
    .registers 3

    sget-object v0, Lj$/time/temporal/a;->EPOCH_DAY:Lj$/time/temporal/a;

    invoke-interface {p0, v0}, Lj$/time/temporal/l;->f(Lj$/time/temporal/o;)J

    move-result-wide v0

    return-wide v0
.end method
