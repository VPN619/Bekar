.class public final Lj$/time/MonthDay;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lj$/time/temporal/l;
.implements Lj$/time/temporal/m;
.implements Ljava/lang/Comparable;
.implements Ljava/io/Serializable;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lj$/time/temporal/l;",
        "Lj$/time/temporal/m;",
        "Ljava/lang/Comparable<",
        "Lj$/time/MonthDay;",
        ">;",
        "Ljava/io/Serializable;"
    }
.end annotation


# static fields
.field public static final synthetic c:I = 0x0

.field private static final serialVersionUID:J = -0xd0888991b3ac078L


# instance fields
.field public final a:I

.field public final b:I


# direct methods
.method static constructor <clinit>()V
    .registers 4

    new-instance v0, Lj$/time/format/n;

    invoke-direct {v0}, Lj$/time/format/n;-><init>()V

    const-string v1, "--"

    invoke-virtual {v0, v1}, Lj$/time/format/n;->d(Ljava/lang/String;)V

    sget-object v1, Lj$/time/temporal/a;->MONTH_OF_YEAR:Lj$/time/temporal/a;

    const/4 v2, 0x2

    invoke-virtual {v0, v1, v2}, Lj$/time/format/n;->g(Lj$/time/temporal/o;I)V

    const/16 v1, 0x2d

    invoke-virtual {v0, v1}, Lj$/time/format/n;->c(C)V

    sget-object v1, Lj$/time/temporal/a;->DAY_OF_MONTH:Lj$/time/temporal/a;

    invoke-virtual {v0, v1, v2}, Lj$/time/format/n;->g(Lj$/time/temporal/o;I)V

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v1

    sget-object v2, Lj$/time/format/t;->SMART:Lj$/time/format/t;

    const/4 v3, 0x0

    invoke-virtual {v0, v1, v2, v3}, Lj$/time/format/n;->l(Ljava/util/Locale;Lj$/time/format/t;Lj$/time/chrono/m;)Lj$/time/format/DateTimeFormatter;

    return-void
.end method

.method public constructor <init>(II)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lj$/time/MonthDay;->a:I

    iput p2, p0, Lj$/time/MonthDay;->b:I

    return-void
.end method

.method public static of(II)Lj$/time/MonthDay;
    .registers 5

    .prologue
    invoke-static {p0}, Lj$/time/l;->H(I)Lj$/time/l;

    move-result-object p0

    const-string v0, "month"

    invoke-static {p0, v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/Object;

    sget-object v0, Lj$/time/temporal/a;->DAY_OF_MONTH:Lj$/time/temporal/a;

    int-to-long v1, p1

    invoke-virtual {v0, v1, v2}, Lj$/time/temporal/a;->I(J)V

    invoke-virtual {p0}, Lj$/time/l;->E()I

    move-result v0

    if-gt p1, v0, :cond_1f

    new-instance v0, Lj$/time/MonthDay;

    invoke-virtual {p0}, Lj$/time/l;->getValue()I

    move-result p0

    invoke-direct {v0, p0, p1}, Lj$/time/MonthDay;-><init>(II)V

    return-object v0

    :cond_1f
    new-instance v0, Lj$/time/c;

    invoke-virtual {p0}, Ljava/lang/Enum;->name()Ljava/lang/String;

    move-result-object p0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Illegal value for DayOfMonth field, value "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, " is not valid for month "

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .registers 2

    new-instance p0, Ljava/io/InvalidObjectException;

    const-string p1, "Deserialization via serialization delegate"

    invoke-direct {p0, p1}, Ljava/io/InvalidObjectException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private writeReplace()Ljava/lang/Object;
    .registers 3

    new-instance v0, Lj$/time/p;

    const/16 v1, 0xd

    invoke-direct {v0, v1, p0}, Lj$/time/p;-><init>(BLjava/lang/Object;)V

    return-object v0
.end method


# virtual methods
.method public final b(Lj$/time/format/a;)Ljava/lang/Object;
    .registers 3

    .prologue
    sget-object v0, Lj$/time/temporal/p;->b:Lj$/time/format/a;

    if-ne p1, v0, :cond_7

    sget-object p0, Lj$/time/chrono/t;->c:Lj$/time/chrono/t;

    return-object p0

    :cond_7
    invoke-super {p0, p1}, Lj$/time/temporal/l;->b(Lj$/time/format/a;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public final c(Lj$/time/temporal/Temporal;)Lj$/time/temporal/Temporal;
    .registers 7

    .prologue
    invoke-static {p1}, Lj$/time/chrono/m;->m(Lj$/time/temporal/l;)Lj$/time/chrono/m;

    move-result-object v0

    sget-object v1, Lj$/time/chrono/t;->c:Lj$/time/chrono/t;

    invoke-interface {v0, v1}, Lj$/time/chrono/m;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_29

    sget-object v0, Lj$/time/temporal/a;->MONTH_OF_YEAR:Lj$/time/temporal/a;

    iget v1, p0, Lj$/time/MonthDay;->a:I

    int-to-long v1, v1

    invoke-interface {p1, v1, v2, v0}, Lj$/time/temporal/Temporal;->g(JLj$/time/temporal/o;)Lj$/time/temporal/Temporal;

    move-result-object p1

    sget-object v0, Lj$/time/temporal/a;->DAY_OF_MONTH:Lj$/time/temporal/a;

    invoke-interface {p1, v0}, Lj$/time/temporal/l;->i(Lj$/time/temporal/o;)Lj$/time/temporal/r;

    move-result-object v1

    iget-wide v1, v1, Lj$/time/temporal/r;->d:J

    iget p0, p0, Lj$/time/MonthDay;->b:I

    int-to-long v3, p0

    invoke-static {v1, v2, v3, v4}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v1

    invoke-interface {p1, v1, v2, v0}, Lj$/time/temporal/Temporal;->g(JLj$/time/temporal/o;)Lj$/time/temporal/Temporal;

    move-result-object p0

    return-object p0

    :cond_29
    new-instance p0, Lj$/time/c;

    const-string p1, "Adjustment only supported on ISO date-time"

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public final compareTo(Ljava/lang/Object;)I
    .registers 4

    .prologue
    check-cast p1, Lj$/time/MonthDay;

    iget v0, p0, Lj$/time/MonthDay;->a:I

    iget v1, p1, Lj$/time/MonthDay;->a:I

    sub-int/2addr v0, v1

    if-nez v0, :cond_f

    iget p0, p0, Lj$/time/MonthDay;->b:I

    iget p1, p1, Lj$/time/MonthDay;->b:I

    sub-int/2addr p0, p1

    return p0

    :cond_f
    return v0
.end method

.method public final d(Lj$/time/temporal/o;)I
    .registers 5

    invoke-virtual {p0, p1}, Lj$/time/MonthDay;->i(Lj$/time/temporal/o;)Lj$/time/temporal/r;

    move-result-object v0

    invoke-virtual {p0, p1}, Lj$/time/MonthDay;->f(Lj$/time/temporal/o;)J

    move-result-wide v1

    invoke-virtual {v0, v1, v2, p1}, Lj$/time/temporal/r;->a(JLj$/time/temporal/o;)I

    move-result p0

    return p0
.end method

.method public final e(Lj$/time/temporal/o;)Z
    .registers 3

    .prologue
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_d

    sget-object p0, Lj$/time/temporal/a;->MONTH_OF_YEAR:Lj$/time/temporal/a;

    if-eq p1, p0, :cond_15

    sget-object p0, Lj$/time/temporal/a;->DAY_OF_MONTH:Lj$/time/temporal/a;

    if-ne p1, p0, :cond_17

    goto :goto_15

    :cond_d
    if-eqz p1, :cond_17

    invoke-interface {p1, p0}, Lj$/time/temporal/o;->n(Lj$/time/temporal/l;)Z

    move-result p0

    if-eqz p0, :cond_17

    :cond_15
    :goto_15
    const/4 p0, 0x1

    return p0

    :cond_17
    const/4 p0, 0x0

    return p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .prologue
    const/4 v0, 0x1

    if-ne p0, p1, :cond_4

    return v0

    :cond_4
    instance-of v1, p1, Lj$/time/MonthDay;

    const/4 v2, 0x0

    if-eqz v1, :cond_18

    check-cast p1, Lj$/time/MonthDay;

    iget v1, p0, Lj$/time/MonthDay;->a:I

    iget v3, p1, Lj$/time/MonthDay;->a:I

    if-ne v1, v3, :cond_18

    iget p0, p0, Lj$/time/MonthDay;->b:I

    iget p1, p1, Lj$/time/MonthDay;->b:I

    if-ne p0, p1, :cond_18

    return v0

    :cond_18
    return v2
.end method

.method public final f(Lj$/time/temporal/o;)J
    .registers 4

    .prologue
    instance-of v0, p1, Lj$/time/temporal/a;

    if-eqz v0, :cond_28

    sget-object v0, Lj$/time/m;->a:[I

    move-object v1, p1

    check-cast v1, Lj$/time/temporal/a;

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    aget v0, v0, v1

    const/4 v1, 0x1

    if-eq v0, v1, :cond_25

    const/4 v1, 0x2

    if-ne v0, v1, :cond_19

    iget p0, p0, Lj$/time/MonthDay;->a:I

    :goto_17
    int-to-long p0, p0

    return-wide p0

    :cond_19
    new-instance p0, Lj$/time/temporal/q;

    const-string v0, "Unsupported field: "

    invoke-static {v0, p1}, Lj$/time/d;->a(Ljava/lang/String;Lj$/time/temporal/o;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_25
    iget p0, p0, Lj$/time/MonthDay;->b:I

    goto :goto_17

    :cond_28
    invoke-interface {p1, p0}, Lj$/time/temporal/o;->E(Lj$/time/temporal/l;)J

    move-result-wide p0

    return-wide p0
.end method

.method public getDayOfMonth()I
    .registers 1

    iget p0, p0, Lj$/time/MonthDay;->b:I

    return p0
.end method

.method public getMonthValue()I
    .registers 1

    iget p0, p0, Lj$/time/MonthDay;->a:I

    return p0
.end method

.method public final hashCode()I
    .registers 2

    iget v0, p0, Lj$/time/MonthDay;->a:I

    shl-int/lit8 v0, v0, 0x6

    iget p0, p0, Lj$/time/MonthDay;->b:I

    add-int/2addr v0, p0

    return v0
.end method

.method public final i(Lj$/time/temporal/o;)Lj$/time/temporal/r;
    .registers 4

    .prologue
    sget-object v0, Lj$/time/temporal/a;->MONTH_OF_YEAR:Lj$/time/temporal/a;

    if-ne p1, v0, :cond_9

    invoke-interface {p1}, Lj$/time/temporal/o;->range()Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_9
    sget-object v0, Lj$/time/temporal/a;->DAY_OF_MONTH:Lj$/time/temporal/a;

    if-ne p1, v0, :cond_46

    iget p1, p0, Lj$/time/MonthDay;->a:I

    invoke-static {p1}, Lj$/time/l;->H(I)Lj$/time/l;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lj$/time/k;->a:[I

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    aget p1, v0, p1

    const/4 v0, 0x1

    if-eq p1, v0, :cond_33

    const/4 v0, 0x2

    if-eq p1, v0, :cond_30

    const/4 v0, 0x3

    if-eq p1, v0, :cond_30

    const/4 v0, 0x4

    if-eq p1, v0, :cond_30

    const/4 v0, 0x5

    if-eq p1, v0, :cond_30

    const/16 p1, 0x1f

    goto :goto_35

    :cond_30
    const/16 p1, 0x1e

    goto :goto_35

    :cond_33
    const/16 p1, 0x1c

    :goto_35
    int-to-long v0, p1

    iget p0, p0, Lj$/time/MonthDay;->a:I

    invoke-static {p0}, Lj$/time/l;->H(I)Lj$/time/l;

    move-result-object p0

    invoke-virtual {p0}, Lj$/time/l;->E()I

    move-result p0

    int-to-long p0, p0

    invoke-static {v0, v1, p0, p1}, Lj$/time/temporal/r;->f(JJ)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0

    :cond_46
    invoke-super {p0, p1}, Lj$/time/temporal/l;->i(Lj$/time/temporal/o;)Lj$/time/temporal/r;

    move-result-object p0

    return-object p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 4

    .prologue
    new-instance v0, Ljava/lang/StringBuilder;

    const/16 v1, 0xa

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    const-string v2, "--"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, Lj$/time/MonthDay;->a:I

    if-ge v2, v1, :cond_13

    const-string v2, "0"

    goto :goto_15

    :cond_13
    const-string v2, ""

    :goto_15
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v2, p0, Lj$/time/MonthDay;->a:I

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    iget v2, p0, Lj$/time/MonthDay;->b:I

    if-ge v2, v1, :cond_24

    const-string v1, "-0"

    goto :goto_26

    :cond_24
    const-string v1, "-"

    :goto_26
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget p0, p0, Lj$/time/MonthDay;->b:I

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
