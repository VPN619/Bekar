.class public final Lj$/time/zone/a;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ljava/io/Externalizable;


# static fields
.field private static final serialVersionUID:J = -0x7b4f011483e5ac42L


# instance fields
.field public a:B

.field public b:Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(BLjava/lang/Object;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-byte p1, p0, Lj$/time/zone/a;->a:B

    iput-object p2, p0, Lj$/time/zone/a;->b:Ljava/lang/Object;

    return-void
.end method

.method public static a(Ljava/io/DataInput;)J
    .registers 5

    .prologue
    invoke-interface {p0}, Ljava/io/DataInput;->readByte()B

    move-result v0

    const/16 v1, 0xff

    and-int/2addr v0, v1

    if-ne v0, v1, :cond_e

    invoke-interface {p0}, Ljava/io/DataInput;->readLong()J

    move-result-wide v0

    return-wide v0

    :cond_e
    invoke-interface {p0}, Ljava/io/DataInput;->readByte()B

    move-result v2

    and-int/2addr v2, v1

    invoke-interface {p0}, Ljava/io/DataInput;->readByte()B

    move-result p0

    and-int/2addr p0, v1

    shl-int/lit8 v0, v0, 0x10

    shl-int/lit8 v1, v2, 0x8

    add-int/2addr v0, v1

    add-int/2addr v0, p0

    int-to-long v0, v0

    const-wide/16 v2, 0x384

    mul-long/2addr v0, v2

    const-wide v2, 0x110bc5000L

    sub-long/2addr v0, v2

    return-wide v0
.end method

.method public static b(Ljava/io/DataInput;)Lj$/time/ZoneOffset;
    .registers 3

    .prologue
    invoke-interface {p0}, Ljava/io/DataInput;->readByte()B

    move-result v0

    const/16 v1, 0x7f

    if-ne v0, v1, :cond_11

    invoke-interface {p0}, Ljava/io/DataInput;->readInt()I

    move-result p0

    invoke-static {p0}, Lj$/time/ZoneOffset;->ofTotalSeconds(I)Lj$/time/ZoneOffset;

    move-result-object p0

    return-object p0

    :cond_11
    mul-int/lit16 v0, v0, 0x384

    invoke-static {v0}, Lj$/time/ZoneOffset;->ofTotalSeconds(I)Lj$/time/ZoneOffset;

    move-result-object p0

    return-object p0
.end method

.method public static c(JLjava/io/DataOutput;)V
    .registers 11

    .prologue
    const-wide v0, -0x110bc5000L

    cmp-long v0, p0, v0

    const/16 v1, 0xff

    if-ltz v0, :cond_37

    const-wide v2, 0x26cb5db00L

    cmp-long v0, p0, v2

    if-gez v0, :cond_37

    const-wide/16 v2, 0x384

    rem-long v4, p0, v2

    const-wide/16 v6, 0x0

    cmp-long v0, v4, v6

    if-nez v0, :cond_37

    const-wide v4, 0x110bc5000L

    add-long/2addr p0, v4

    div-long/2addr p0, v2

    long-to-int p0, p0

    ushr-int/lit8 p1, p0, 0x10

    and-int/2addr p1, v1

    invoke-interface {p2, p1}, Ljava/io/DataOutput;->writeByte(I)V

    ushr-int/lit8 p1, p0, 0x8

    and-int/2addr p1, v1

    invoke-interface {p2, p1}, Ljava/io/DataOutput;->writeByte(I)V

    and-int/2addr p0, v1

    invoke-interface {p2, p0}, Ljava/io/DataOutput;->writeByte(I)V

    return-void

    :cond_37
    invoke-interface {p2, v1}, Ljava/io/DataOutput;->writeByte(I)V

    invoke-interface {p2, p0, p1}, Ljava/io/DataOutput;->writeLong(J)V

    return-void
.end method

.method public static d(Lj$/time/ZoneOffset;Ljava/io/DataOutput;)V
    .registers 4

    .prologue
    invoke-virtual {p0}, Lj$/time/ZoneOffset;->getTotalSeconds()I

    move-result p0

    rem-int/lit16 v0, p0, 0x384

    const/16 v1, 0x7f

    if-nez v0, :cond_d

    div-int/lit16 v0, p0, 0x384

    goto :goto_e

    :cond_d
    move v0, v1

    :goto_e
    invoke-interface {p1, v0}, Ljava/io/DataOutput;->writeByte(I)V

    if-ne v0, v1, :cond_16

    invoke-interface {p1, p0}, Ljava/io/DataOutput;->writeInt(I)V

    :cond_16
    return-void
.end method

.method private readResolve()Ljava/lang/Object;
    .registers 1

    iget-object p0, p0, Lj$/time/zone/a;->b:Ljava/lang/Object;

    return-object p0
.end method


# virtual methods
.method public final readExternal(Ljava/io/ObjectInput;)V
    .registers 12

    .prologue
    invoke-interface {p1}, Ljava/io/ObjectInput;->readByte()B

    move-result v0

    iput-byte v0, p0, Lj$/time/zone/a;->a:B

    const/4 v1, 0x1

    if-eq v0, v1, :cond_52

    const/4 v1, 0x2

    if-eq v0, v1, :cond_30

    const/4 v1, 0x3

    if-eq v0, v1, :cond_2a

    const/16 v1, 0x64

    if-ne v0, v1, :cond_22

    invoke-interface {p1}, Ljava/io/DataInput;->readUTF()Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Ljava/util/TimeZone;->getTimeZone(Ljava/lang/String;)Ljava/util/TimeZone;

    move-result-object p1

    new-instance v0, Lj$/time/zone/f;

    invoke-direct {v0, p1}, Lj$/time/zone/f;-><init>(Ljava/util/TimeZone;)V

    goto/16 :goto_bf

    :cond_22
    new-instance p0, Ljava/io/StreamCorruptedException;

    const-string p1, "Unknown serialized type"

    invoke-direct {p0, p1}, Ljava/io/StreamCorruptedException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_2a
    invoke-static {p1}, Lj$/time/zone/e;->a(Ljava/io/DataInput;)Lj$/time/zone/e;

    move-result-object v0

    goto/16 :goto_bf

    :cond_30
    invoke-static {p1}, Lj$/time/zone/a;->a(Ljava/io/DataInput;)J

    move-result-wide v0

    invoke-static {p1}, Lj$/time/zone/a;->b(Ljava/io/DataInput;)Lj$/time/ZoneOffset;

    move-result-object v2

    invoke-static {p1}, Lj$/time/zone/a;->b(Ljava/io/DataInput;)Lj$/time/ZoneOffset;

    move-result-object p1

    invoke-virtual {v2, p1}, Lj$/time/ZoneOffset;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_4a

    new-instance v3, Lj$/time/zone/b;

    invoke-direct {v3, v0, v1, v2, p1}, Lj$/time/zone/b;-><init>(JLj$/time/ZoneOffset;Lj$/time/ZoneOffset;)V

    move-object v0, v3

    goto/16 :goto_bf

    :cond_4a
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string p1, "Offsets must not be equal"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_52
    sget-object v0, Lj$/time/zone/f;->i:[J

    invoke-interface {p1}, Ljava/io/DataInput;->readInt()I

    move-result v2

    if-nez v2, :cond_5c

    move-object v5, v0

    goto :goto_5f

    :cond_5c
    new-array v3, v2, [J

    move-object v5, v3

    :goto_5f
    const/4 v3, 0x0

    move v4, v3

    :goto_61
    if-ge v4, v2, :cond_6c

    invoke-static {p1}, Lj$/time/zone/a;->a(Ljava/io/DataInput;)J

    move-result-wide v6

    aput-wide v6, v5, v4

    add-int/lit8 v4, v4, 0x1

    goto :goto_61

    :cond_6c
    add-int/2addr v2, v1

    new-array v6, v2, [Lj$/time/ZoneOffset;

    move v4, v3

    :goto_70
    if-ge v4, v2, :cond_7b

    invoke-static {p1}, Lj$/time/zone/a;->b(Ljava/io/DataInput;)Lj$/time/ZoneOffset;

    move-result-object v7

    aput-object v7, v6, v4

    add-int/lit8 v4, v4, 0x1

    goto :goto_70

    :cond_7b
    invoke-interface {p1}, Ljava/io/DataInput;->readInt()I

    move-result v2

    if-nez v2, :cond_83

    :goto_81
    move-object v7, v0

    goto :goto_86

    :cond_83
    new-array v0, v2, [J

    goto :goto_81

    :goto_86
    move v0, v3

    :goto_87
    if-ge v0, v2, :cond_92

    invoke-static {p1}, Lj$/time/zone/a;->a(Ljava/io/DataInput;)J

    move-result-wide v8

    aput-wide v8, v7, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_87

    :cond_92
    add-int/2addr v2, v1

    new-array v8, v2, [Lj$/time/ZoneOffset;

    move v0, v3

    :goto_96
    if-ge v0, v2, :cond_a1

    invoke-static {p1}, Lj$/time/zone/a;->b(Ljava/io/DataInput;)Lj$/time/ZoneOffset;

    move-result-object v1

    aput-object v1, v8, v0

    add-int/lit8 v0, v0, 0x1

    goto :goto_96

    :cond_a1
    invoke-interface {p1}, Ljava/io/DataInput;->readByte()B

    move-result v0

    if-nez v0, :cond_ab

    sget-object v1, Lj$/time/zone/f;->j:[Lj$/time/zone/e;

    :goto_a9
    move-object v9, v1

    goto :goto_ae

    :cond_ab
    new-array v1, v0, [Lj$/time/zone/e;

    goto :goto_a9

    :goto_ae
    if-ge v3, v0, :cond_b9

    invoke-static {p1}, Lj$/time/zone/e;->a(Ljava/io/DataInput;)Lj$/time/zone/e;

    move-result-object v1

    aput-object v1, v9, v3

    add-int/lit8 v3, v3, 0x1

    goto :goto_ae

    :cond_b9
    new-instance v4, Lj$/time/zone/f;

    invoke-direct/range {v4 .. v9}, Lj$/time/zone/f;-><init>([J[Lj$/time/ZoneOffset;[J[Lj$/time/ZoneOffset;[Lj$/time/zone/e;)V

    move-object v0, v4

    :goto_bf
    iput-object v0, p0, Lj$/time/zone/a;->b:Ljava/lang/Object;

    return-void
.end method

.method public final writeExternal(Ljava/io/ObjectOutput;)V
    .registers 8

    .prologue
    iget-byte v0, p0, Lj$/time/zone/a;->a:B

    iget-object p0, p0, Lj$/time/zone/a;->b:Ljava/lang/Object;

    invoke-interface {p1, v0}, Ljava/io/DataOutput;->writeByte(I)V

    const/4 v1, 0x1

    if-eq v0, v1, :cond_40

    const/4 v1, 0x2

    if-eq v0, v1, :cond_2e

    const/4 v1, 0x3

    if-eq v0, v1, :cond_28

    const/16 v1, 0x64

    if-ne v0, v1, :cond_20

    check-cast p0, Lj$/time/zone/f;

    iget-object p0, p0, Lj$/time/zone/f;->g:Ljava/util/TimeZone;

    invoke-virtual {p0}, Ljava/util/TimeZone;->getID()Ljava/lang/String;

    move-result-object p0

    invoke-interface {p1, p0}, Ljava/io/DataOutput;->writeUTF(Ljava/lang/String;)V

    return-void

    :cond_20
    new-instance p0, Ljava/io/InvalidClassException;

    const-string p1, "Unknown serialized type"

    invoke-direct {p0, p1}, Ljava/io/InvalidClassException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_28
    check-cast p0, Lj$/time/zone/e;

    invoke-virtual {p0, p1}, Lj$/time/zone/e;->b(Ljava/io/DataOutput;)V

    return-void

    :cond_2e
    check-cast p0, Lj$/time/zone/b;

    iget-wide v0, p0, Lj$/time/zone/b;->a:J

    invoke-static {v0, v1, p1}, Lj$/time/zone/a;->c(JLjava/io/DataOutput;)V

    iget-object v0, p0, Lj$/time/zone/b;->c:Lj$/time/ZoneOffset;

    invoke-static {v0, p1}, Lj$/time/zone/a;->d(Lj$/time/ZoneOffset;Ljava/io/DataOutput;)V

    iget-object p0, p0, Lj$/time/zone/b;->d:Lj$/time/ZoneOffset;

    invoke-static {p0, p1}, Lj$/time/zone/a;->d(Lj$/time/ZoneOffset;Ljava/io/DataOutput;)V

    return-void

    :cond_40
    check-cast p0, Lj$/time/zone/f;

    iget-object v0, p0, Lj$/time/zone/f;->a:[J

    array-length v0, v0

    invoke-interface {p1, v0}, Ljava/io/DataOutput;->writeInt(I)V

    iget-object v0, p0, Lj$/time/zone/f;->a:[J

    array-length v1, v0

    const/4 v2, 0x0

    move v3, v2

    :goto_4d
    if-ge v3, v1, :cond_57

    aget-wide v4, v0, v3

    invoke-static {v4, v5, p1}, Lj$/time/zone/a;->c(JLjava/io/DataOutput;)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_4d

    :cond_57
    iget-object v0, p0, Lj$/time/zone/f;->b:[Lj$/time/ZoneOffset;

    array-length v1, v0

    move v3, v2

    :goto_5b
    if-ge v3, v1, :cond_65

    aget-object v4, v0, v3

    invoke-static {v4, p1}, Lj$/time/zone/a;->d(Lj$/time/ZoneOffset;Ljava/io/DataOutput;)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_5b

    :cond_65
    iget-object v0, p0, Lj$/time/zone/f;->c:[J

    array-length v0, v0

    invoke-interface {p1, v0}, Ljava/io/DataOutput;->writeInt(I)V

    iget-object v0, p0, Lj$/time/zone/f;->c:[J

    array-length v1, v0

    move v3, v2

    :goto_6f
    if-ge v3, v1, :cond_79

    aget-wide v4, v0, v3

    invoke-static {v4, v5, p1}, Lj$/time/zone/a;->c(JLjava/io/DataOutput;)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_6f

    :cond_79
    iget-object v0, p0, Lj$/time/zone/f;->e:[Lj$/time/ZoneOffset;

    array-length v1, v0

    move v3, v2

    :goto_7d
    if-ge v3, v1, :cond_87

    aget-object v4, v0, v3

    invoke-static {v4, p1}, Lj$/time/zone/a;->d(Lj$/time/ZoneOffset;Ljava/io/DataOutput;)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_7d

    :cond_87
    iget-object v0, p0, Lj$/time/zone/f;->f:[Lj$/time/zone/e;

    array-length v0, v0

    invoke-interface {p1, v0}, Ljava/io/DataOutput;->writeByte(I)V

    iget-object p0, p0, Lj$/time/zone/f;->f:[Lj$/time/zone/e;

    array-length v0, p0

    :goto_90
    if-ge v2, v0, :cond_9a

    aget-object v1, p0, v2

    invoke-virtual {v1, p1}, Lj$/time/zone/e;->b(Ljava/io/DataOutput;)V

    add-int/lit8 v2, v2, 0x1

    goto :goto_90

    :cond_9a
    return-void
.end method
