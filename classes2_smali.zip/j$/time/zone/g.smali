.class public final Lj$/time/zone/g;
.super Lj$/time/c;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field private static final serialVersionUID:J = -0x16a7842e31574fcfL
