.class public final enum Lj$/time/zone/d;
.super Ljava/lang/Enum;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final enum STANDARD:Lj$/time/zone/d;

.field public static final enum UTC:Lj$/time/zone/d;

.field public static final enum WALL:Lj$/time/zone/d;

.field public static final synthetic a:[Lj$/time/zone/d;


# direct methods
.method static constructor <clinit>()V
    .registers 5

    new-instance v0, Lj$/time/zone/d;

    const-string v1, "UTC"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lj$/time/zone/d;->UTC:Lj$/time/zone/d;

    new-instance v1, Lj$/time/zone/d;

    const-string v2, "WALL"

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v1, Lj$/time/zone/d;->WALL:Lj$/time/zone/d;

    new-instance v2, Lj$/time/zone/d;

    const-string v3, "STANDARD"

    const/4 v4, 0x2

    invoke-direct {v2, v3, v4}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    sput-object v2, Lj$/time/zone/d;->STANDARD:Lj$/time/zone/d;

    filled-new-array {v0, v1, v2}, [Lj$/time/zone/d;

    move-result-object v0

    sput-object v0, Lj$/time/zone/d;->a:[Lj$/time/zone/d;

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lj$/time/zone/d;
    .registers 2

    const-class v0, Lj$/time/zone/d;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    check-cast p0, Lj$/time/zone/d;

    return-object p0
.end method

.method public static values()[Lj$/time/zone/d;
    .registers 1

    sget-object v0, Lj$/time/zone/d;->a:[Lj$/time/zone/d;

    invoke-virtual {v0}, [Lj$/time/zone/d;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lj$/time/zone/d;

    return-object v0
.end method
