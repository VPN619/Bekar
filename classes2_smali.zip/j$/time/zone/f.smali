.class public final Lj$/time/zone/f;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field public static final i:[J

.field public static final j:[Lj$/time/zone/e;

.field public static final k:[Lj$/time/LocalDateTime;

.field public static final l:[Lj$/time/zone/b;

.field private static final serialVersionUID:J = 0x2a3f985312278703L


# instance fields
.field public final a:[J

.field public final b:[Lj$/time/ZoneOffset;

.field public final c:[J

.field public final d:[Lj$/time/LocalDateTime;

.field public final e:[Lj$/time/ZoneOffset;

.field public final f:[Lj$/time/zone/e;

.field public final g:Ljava/util/TimeZone;

.field public final transient h:Ljava/util/concurrent/ConcurrentMap;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    const/4 v0, 0x0

    new-array v1, v0, [J

    sput-object v1, Lj$/time/zone/f;->i:[J

    new-array v1, v0, [Lj$/time/zone/e;

    sput-object v1, Lj$/time/zone/f;->j:[Lj$/time/zone/e;

    new-array v1, v0, [Lj$/time/LocalDateTime;

    sput-object v1, Lj$/time/zone/f;->k:[Lj$/time/LocalDateTime;

    new-array v0, v0, [Lj$/time/zone/b;

    sput-object v0, Lj$/time/zone/f;->l:[Lj$/time/zone/b;

    return-void
.end method

.method public constructor <init>(Lj$/time/ZoneOffset;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    iput-object v0, p0, Lj$/time/zone/f;->h:Ljava/util/concurrent/ConcurrentMap;

    const/4 v0, 0x1

    new-array v0, v0, [Lj$/time/ZoneOffset;

    iput-object v0, p0, Lj$/time/zone/f;->b:[Lj$/time/ZoneOffset;

    const/4 v1, 0x0

    aput-object p1, v0, v1

    sget-object p1, Lj$/time/zone/f;->i:[J

    iput-object p1, p0, Lj$/time/zone/f;->a:[J

    iput-object p1, p0, Lj$/time/zone/f;->c:[J

    sget-object p1, Lj$/time/zone/f;->k:[Lj$/time/LocalDateTime;

    iput-object p1, p0, Lj$/time/zone/f;->d:[Lj$/time/LocalDateTime;

    iput-object v0, p0, Lj$/time/zone/f;->e:[Lj$/time/ZoneOffset;

    sget-object p1, Lj$/time/zone/f;->j:[Lj$/time/zone/e;

    iput-object p1, p0, Lj$/time/zone/f;->f:[Lj$/time/zone/e;

    const/4 p1, 0x0

    iput-object p1, p0, Lj$/time/zone/f;->g:Ljava/util/TimeZone;

    return-void
.end method

.method public constructor <init>(Ljava/util/TimeZone;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    iput-object v0, p0, Lj$/time/zone/f;->h:Ljava/util/concurrent/ConcurrentMap;

    const/4 v0, 0x1

    new-array v0, v0, [Lj$/time/ZoneOffset;

    iput-object v0, p0, Lj$/time/zone/f;->b:[Lj$/time/ZoneOffset;

    invoke-virtual {p1}, Ljava/util/TimeZone;->getRawOffset()I

    move-result v1

    invoke-static {v1}, Lj$/time/zone/f;->g(I)Lj$/time/ZoneOffset;

    move-result-object v1

    const/4 v2, 0x0

    aput-object v1, v0, v2

    sget-object v1, Lj$/time/zone/f;->i:[J

    iput-object v1, p0, Lj$/time/zone/f;->a:[J

    iput-object v1, p0, Lj$/time/zone/f;->c:[J

    sget-object v1, Lj$/time/zone/f;->k:[Lj$/time/LocalDateTime;

    iput-object v1, p0, Lj$/time/zone/f;->d:[Lj$/time/LocalDateTime;

    iput-object v0, p0, Lj$/time/zone/f;->e:[Lj$/time/ZoneOffset;

    sget-object v0, Lj$/time/zone/f;->j:[Lj$/time/zone/e;

    iput-object v0, p0, Lj$/time/zone/f;->f:[Lj$/time/zone/e;

    iput-object p1, p0, Lj$/time/zone/f;->g:Ljava/util/TimeZone;

    return-void
.end method

.method public constructor <init>([J[Lj$/time/ZoneOffset;[J[Lj$/time/ZoneOffset;[Lj$/time/zone/e;)V
    .registers 11

    .prologue
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    iput-object v0, p0, Lj$/time/zone/f;->h:Ljava/util/concurrent/ConcurrentMap;

    iput-object p1, p0, Lj$/time/zone/f;->a:[J

    iput-object p2, p0, Lj$/time/zone/f;->b:[Lj$/time/ZoneOffset;

    iput-object p3, p0, Lj$/time/zone/f;->c:[J

    iput-object p4, p0, Lj$/time/zone/f;->e:[Lj$/time/ZoneOffset;

    iput-object p5, p0, Lj$/time/zone/f;->f:[Lj$/time/zone/e;

    array-length p1, p3

    if-nez p1, :cond_1c

    sget-object p1, Lj$/time/zone/f;->k:[Lj$/time/LocalDateTime;

    iput-object p1, p0, Lj$/time/zone/f;->d:[Lj$/time/LocalDateTime;

    goto :goto_75

    :cond_1c
    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    const/4 p2, 0x0

    move p5, p2

    :goto_23
    array-length v0, p3

    if-ge p5, v0, :cond_67

    aget-object v0, p4, p5

    add-int/lit8 v1, p5, 0x1

    aget-object v2, p4, v1

    aget-wide v3, p3, p5

    invoke-static {v3, v4, p2, v0}, Lj$/time/LocalDateTime;->H(JILj$/time/ZoneOffset;)Lj$/time/LocalDateTime;

    move-result-object p5

    invoke-virtual {v2}, Lj$/time/ZoneOffset;->getTotalSeconds()I

    move-result v3

    invoke-virtual {v0}, Lj$/time/ZoneOffset;->getTotalSeconds()I

    move-result v4

    if-le v3, v4, :cond_51

    invoke-virtual {p1, p5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {v2}, Lj$/time/ZoneOffset;->getTotalSeconds()I

    move-result v2

    invoke-virtual {v0}, Lj$/time/ZoneOffset;->getTotalSeconds()I

    move-result v0

    sub-int/2addr v2, v0

    int-to-long v2, v2

    invoke-virtual {p5, v2, v3}, Lj$/time/LocalDateTime;->J(J)Lj$/time/LocalDateTime;

    move-result-object p5

    invoke-virtual {p1, p5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_65

    :cond_51
    invoke-virtual {v2}, Lj$/time/ZoneOffset;->getTotalSeconds()I

    move-result v2

    invoke-virtual {v0}, Lj$/time/ZoneOffset;->getTotalSeconds()I

    move-result v0

    sub-int/2addr v2, v0

    int-to-long v2, v2

    invoke-virtual {p5, v2, v3}, Lj$/time/LocalDateTime;->J(J)Lj$/time/LocalDateTime;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    invoke-virtual {p1, p5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_65
    move p5, v1

    goto :goto_23

    :cond_67
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p2

    new-array p2, p2, [Lj$/time/LocalDateTime;

    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p1

    check-cast p1, [Lj$/time/LocalDateTime;

    iput-object p1, p0, Lj$/time/zone/f;->d:[Lj$/time/LocalDateTime;

    :goto_75
    const/4 p1, 0x0

    iput-object p1, p0, Lj$/time/zone/f;->g:Ljava/util/TimeZone;

    return-void
.end method

.method public static a(Lj$/time/LocalDateTime;Lj$/time/zone/b;)Ljava/lang/Object;
    .registers 5

    .prologue
    iget-object v0, p1, Lj$/time/zone/b;->b:Lj$/time/LocalDateTime;

    iget-object v1, p1, Lj$/time/zone/b;->d:Lj$/time/ZoneOffset;

    invoke-virtual {v1}, Lj$/time/ZoneOffset;->getTotalSeconds()I

    move-result v1

    iget-object v2, p1, Lj$/time/zone/b;->c:Lj$/time/ZoneOffset;

    invoke-virtual {v2}, Lj$/time/ZoneOffset;->getTotalSeconds()I

    move-result v2

    if-le v1, v2, :cond_37

    invoke-virtual {p0, v0}, Lj$/time/LocalDateTime;->E(Lj$/time/chrono/e;)Z

    move-result v0

    if-eqz v0, :cond_19

    iget-object p0, p1, Lj$/time/zone/b;->c:Lj$/time/ZoneOffset;

    return-object p0

    :cond_19
    iget-object v0, p1, Lj$/time/zone/b;->b:Lj$/time/LocalDateTime;

    iget-object v1, p1, Lj$/time/zone/b;->d:Lj$/time/ZoneOffset;

    invoke-virtual {v1}, Lj$/time/ZoneOffset;->getTotalSeconds()I

    move-result v1

    iget-object v2, p1, Lj$/time/zone/b;->c:Lj$/time/ZoneOffset;

    invoke-virtual {v2}, Lj$/time/ZoneOffset;->getTotalSeconds()I

    move-result v2

    sub-int/2addr v1, v2

    int-to-long v1, v1

    invoke-virtual {v0, v1, v2}, Lj$/time/LocalDateTime;->J(J)Lj$/time/LocalDateTime;

    move-result-object v0

    invoke-virtual {p0, v0}, Lj$/time/LocalDateTime;->E(Lj$/time/chrono/e;)Z

    move-result p0

    if-eqz p0, :cond_34

    goto :goto_5d

    :cond_34
    iget-object p0, p1, Lj$/time/zone/b;->d:Lj$/time/ZoneOffset;

    return-object p0

    :cond_37
    invoke-virtual {p0, v0}, Lj$/time/LocalDateTime;->E(Lj$/time/chrono/e;)Z

    move-result v0

    if-nez v0, :cond_40

    iget-object p0, p1, Lj$/time/zone/b;->d:Lj$/time/ZoneOffset;

    return-object p0

    :cond_40
    iget-object v0, p1, Lj$/time/zone/b;->b:Lj$/time/LocalDateTime;

    iget-object v1, p1, Lj$/time/zone/b;->d:Lj$/time/ZoneOffset;

    invoke-virtual {v1}, Lj$/time/ZoneOffset;->getTotalSeconds()I

    move-result v1

    iget-object v2, p1, Lj$/time/zone/b;->c:Lj$/time/ZoneOffset;

    invoke-virtual {v2}, Lj$/time/ZoneOffset;->getTotalSeconds()I

    move-result v2

    sub-int/2addr v1, v2

    int-to-long v1, v1

    invoke-virtual {v0, v1, v2}, Lj$/time/LocalDateTime;->J(J)Lj$/time/LocalDateTime;

    move-result-object v0

    invoke-virtual {p0, v0}, Lj$/time/LocalDateTime;->E(Lj$/time/chrono/e;)Z

    move-result p0

    if-eqz p0, :cond_5d

    iget-object p0, p1, Lj$/time/zone/b;->c:Lj$/time/ZoneOffset;

    return-object p0

    :cond_5d
    :goto_5d
    return-object p1
.end method

.method public static c(JLj$/time/ZoneOffset;)I
    .registers 5

    invoke-virtual {p2}, Lj$/time/ZoneOffset;->getTotalSeconds()I

    move-result p2

    int-to-long v0, p2

    add-long/2addr p0, v0

    const-wide/32 v0, 0x15180

    invoke-static {p0, p1, v0, v1}, Ljava/lang/Math;->floorDiv(JJ)J

    move-result-wide p0

    invoke-static {p0, p1}, Lj$/time/LocalDate;->P(J)Lj$/time/LocalDate;

    move-result-object p0

    invoke-virtual {p0}, Lj$/time/LocalDate;->getYear()I

    move-result p0

    return p0
.end method

.method public static g(I)Lj$/time/ZoneOffset;
    .registers 1

    div-int/lit16 p0, p0, 0x3e8

    invoke-static {p0}, Lj$/time/ZoneOffset;->ofTotalSeconds(I)Lj$/time/ZoneOffset;

    move-result-object p0

    return-object p0
.end method

.method private readObject(Ljava/io/ObjectInputStream;)V
    .registers 2

    new-instance p0, Ljava/io/InvalidObjectException;

    const-string p1, "Deserialization via serialization delegate"

    invoke-direct {p0, p1}, Ljava/io/InvalidObjectException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method private writeReplace()Ljava/lang/Object;
    .registers 3

    .prologue
    new-instance v0, Lj$/time/zone/a;

    iget-object v1, p0, Lj$/time/zone/f;->g:Ljava/util/TimeZone;

    if-eqz v1, :cond_9

    const/16 v1, 0x64

    goto :goto_a

    :cond_9
    const/4 v1, 0x1

    :goto_a
    invoke-direct {v0, v1, p0}, Lj$/time/zone/a;-><init>(BLjava/lang/Object;)V

    return-object v0
.end method


# virtual methods
.method public final b(I)[Lj$/time/zone/b;
    .registers 22

    .prologue
    move-object/from16 v0, p0

    move/from16 v1, p1

    sget-object v2, Lj$/time/zone/f;->l:[Lj$/time/zone/b;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    iget-object v4, v0, Lj$/time/zone/f;->h:Ljava/util/concurrent/ConcurrentMap;

    check-cast v4, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v4, v3}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, [Lj$/time/zone/b;

    if-eqz v4, :cond_17

    return-object v4

    :cond_17
    iget-object v4, v0, Lj$/time/zone/f;->g:Ljava/util/TimeZone;

    const/16 v5, 0x834

    const-wide/16 v6, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-eqz v4, :cond_d7

    const/16 v4, 0x708

    if-ge v1, v4, :cond_26

    return-object v2

    :cond_26
    add-int/lit8 v4, v1, -0x1

    sget-object v10, Lj$/time/LocalDateTime;->c:Lj$/time/LocalDateTime;

    const/16 v10, 0xc

    const/16 v11, 0x1f

    invoke-static {v4, v10, v11}, Lj$/time/LocalDate;->of(III)Lj$/time/LocalDate;

    move-result-object v4

    sget-object v10, Lj$/time/temporal/a;->HOUR_OF_DAY:Lj$/time/temporal/a;

    const-wide/16 v11, 0x0

    invoke-virtual {v10, v11, v12}, Lj$/time/temporal/a;->I(J)V

    sget-object v10, Lj$/time/LocalTime;->h:[Lj$/time/LocalTime;

    aget-object v10, v10, v8

    new-instance v11, Lj$/time/LocalDateTime;

    invoke-direct {v11, v4, v10}, Lj$/time/LocalDateTime;-><init>(Lj$/time/LocalDate;Lj$/time/LocalTime;)V

    iget-object v4, v0, Lj$/time/zone/f;->b:[Lj$/time/ZoneOffset;

    aget-object v4, v4, v8

    invoke-interface {v11, v4}, Lj$/time/chrono/e;->s(Lj$/time/ZoneOffset;)J

    move-result-wide v10

    iget-object v4, v0, Lj$/time/zone/f;->g:Ljava/util/TimeZone;

    const-wide/16 v12, 0x3e8

    mul-long v14, v10, v12

    invoke-virtual {v4, v14, v15}, Ljava/util/TimeZone;->getOffset(J)I

    move-result v4

    const-wide/32 v14, 0x1e7cb00

    add-long/2addr v14, v10

    :goto_58
    cmp-long v8, v10, v14

    if-gez v8, :cond_c9

    const-wide/32 v16, 0x76a700

    add-long v16, v10, v16

    iget-object v8, v0, Lj$/time/zone/f;->g:Ljava/util/TimeZone;

    move-wide/from16 v18, v12

    mul-long v12, v16, v18

    invoke-virtual {v8, v12, v13}, Ljava/util/TimeZone;->getOffset(J)I

    move-result v8

    if-eq v4, v8, :cond_c2

    :goto_6d
    sub-long v12, v16, v10

    cmp-long v8, v12, v6

    if-lez v8, :cond_8c

    add-long v12, v16, v10

    const-wide/16 v6, 0x2

    invoke-static {v12, v13, v6, v7}, Ljava/lang/Math;->floorDiv(JJ)J

    move-result-wide v6

    iget-object v8, v0, Lj$/time/zone/f;->g:Ljava/util/TimeZone;

    mul-long v12, v6, v18

    invoke-virtual {v8, v12, v13}, Ljava/util/TimeZone;->getOffset(J)I

    move-result v8

    if-ne v8, v4, :cond_87

    move-wide v10, v6

    goto :goto_89

    :cond_87
    move-wide/from16 v16, v6

    :goto_89
    const-wide/16 v6, 0x1

    goto :goto_6d

    :cond_8c
    iget-object v6, v0, Lj$/time/zone/f;->g:Ljava/util/TimeZone;

    mul-long v12, v10, v18

    invoke-virtual {v6, v12, v13}, Ljava/util/TimeZone;->getOffset(J)I

    move-result v6

    if-eq v6, v4, :cond_97

    goto :goto_99

    :cond_97
    move-wide/from16 v10, v16

    :goto_99
    invoke-static {v4}, Lj$/time/zone/f;->g(I)Lj$/time/ZoneOffset;

    move-result-object v4

    iget-object v6, v0, Lj$/time/zone/f;->g:Ljava/util/TimeZone;

    mul-long v12, v10, v18

    invoke-virtual {v6, v12, v13}, Ljava/util/TimeZone;->getOffset(J)I

    move-result v6

    invoke-static {v6}, Lj$/time/zone/f;->g(I)Lj$/time/ZoneOffset;

    move-result-object v7

    invoke-static {v10, v11, v7}, Lj$/time/zone/f;->c(JLj$/time/ZoneOffset;)I

    move-result v8

    if-ne v8, v1, :cond_c0

    array-length v8, v2

    add-int/2addr v8, v9

    invoke-static {v2, v8}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v2

    check-cast v2, [Lj$/time/zone/b;

    array-length v8, v2

    sub-int/2addr v8, v9

    new-instance v12, Lj$/time/zone/b;

    invoke-direct {v12, v10, v11, v4, v7}, Lj$/time/zone/b;-><init>(JLj$/time/ZoneOffset;Lj$/time/ZoneOffset;)V

    aput-object v12, v2, v8

    :cond_c0
    move v4, v6

    goto :goto_c4

    :cond_c2
    move-wide/from16 v10, v16

    :goto_c4
    move-wide/from16 v12, v18

    const-wide/16 v6, 0x1

    goto :goto_58

    :cond_c9
    const/16 v4, 0x77c

    if-gt v4, v1, :cond_d6

    if-ge v1, v5, :cond_d6

    iget-object v0, v0, Lj$/time/zone/f;->h:Ljava/util/concurrent/ConcurrentMap;

    check-cast v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v0, v3, v2}, Ljava/util/concurrent/ConcurrentHashMap;->putIfAbsent(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_d6
    return-object v2

    :cond_d7
    iget-object v2, v0, Lj$/time/zone/f;->f:[Lj$/time/zone/e;

    array-length v4, v2

    new-array v4, v4, [Lj$/time/zone/b;

    move v6, v8

    :goto_dd
    array-length v7, v2

    if-ge v6, v7, :cond_19e

    aget-object v7, v2, v6

    iget-byte v10, v7, Lj$/time/zone/e;->b:B

    iget-object v11, v7, Lj$/time/zone/e;->a:Lj$/time/l;

    if-gez v10, :cond_121

    sget-object v10, Lj$/time/chrono/t;->c:Lj$/time/chrono/t;

    int-to-long v12, v1

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v12, v13}, Lj$/time/chrono/t;->E(J)Z

    move-result v10

    invoke-virtual {v11, v10}, Lj$/time/l;->v(Z)I

    move-result v10

    add-int/2addr v10, v9

    iget-byte v14, v7, Lj$/time/zone/e;->b:B

    add-int/2addr v10, v14

    sget-object v14, Lj$/time/LocalDate;->d:Lj$/time/LocalDate;

    sget-object v14, Lj$/time/temporal/a;->YEAR:Lj$/time/temporal/a;

    invoke-virtual {v14, v12, v13}, Lj$/time/temporal/a;->I(J)V

    sget-object v12, Lj$/time/temporal/a;->DAY_OF_MONTH:Lj$/time/temporal/a;

    int-to-long v13, v10

    invoke-virtual {v12, v13, v14}, Lj$/time/temporal/a;->I(J)V

    invoke-virtual {v11}, Lj$/time/l;->getValue()I

    move-result v11

    invoke-static {v1, v11, v10}, Lj$/time/LocalDate;->v(III)Lj$/time/LocalDate;

    move-result-object v10

    iget-object v11, v7, Lj$/time/zone/e;->c:Lj$/time/e;

    if-eqz v11, :cond_148

    invoke-virtual {v11}, Lj$/time/e;->getValue()I

    move-result v11

    new-instance v12, Lj$/time/temporal/n;

    invoke-direct {v12, v11, v9}, Lj$/time/temporal/n;-><init>(II)V

    invoke-virtual {v10, v12}, Lj$/time/LocalDate;->W(Lj$/time/temporal/m;)Lj$/time/LocalDate;

    move-result-object v10

    goto :goto_148

    :cond_121
    sget-object v12, Lj$/time/LocalDate;->d:Lj$/time/LocalDate;

    sget-object v12, Lj$/time/temporal/a;->YEAR:Lj$/time/temporal/a;

    int-to-long v13, v1

    invoke-virtual {v12, v13, v14}, Lj$/time/temporal/a;->I(J)V

    sget-object v12, Lj$/time/temporal/a;->DAY_OF_MONTH:Lj$/time/temporal/a;

    int-to-long v13, v10

    invoke-virtual {v12, v13, v14}, Lj$/time/temporal/a;->I(J)V

    invoke-virtual {v11}, Lj$/time/l;->getValue()I

    move-result v11

    invoke-static {v1, v11, v10}, Lj$/time/LocalDate;->v(III)Lj$/time/LocalDate;

    move-result-object v10

    iget-object v11, v7, Lj$/time/zone/e;->c:Lj$/time/e;

    if-eqz v11, :cond_148

    invoke-virtual {v11}, Lj$/time/e;->getValue()I

    move-result v11

    new-instance v12, Lj$/time/temporal/n;

    invoke-direct {v12, v11, v8}, Lj$/time/temporal/n;-><init>(II)V

    invoke-virtual {v10, v12}, Lj$/time/LocalDate;->W(Lj$/time/temporal/m;)Lj$/time/LocalDate;

    move-result-object v10

    :cond_148
    :goto_148
    iget-boolean v11, v7, Lj$/time/zone/e;->e:Z

    if-eqz v11, :cond_153

    const-wide/16 v11, 0x1

    invoke-virtual {v10, v11, v12}, Lj$/time/LocalDate;->R(J)Lj$/time/LocalDate;

    move-result-object v10

    goto :goto_155

    :cond_153
    const-wide/16 v11, 0x1

    :goto_155
    iget-object v13, v7, Lj$/time/zone/e;->d:Lj$/time/LocalTime;

    invoke-static {v10, v13}, Lj$/time/LocalDateTime;->of(Lj$/time/LocalDate;Lj$/time/LocalTime;)Lj$/time/LocalDateTime;

    move-result-object v10

    iget-object v13, v7, Lj$/time/zone/e;->f:Lj$/time/zone/d;

    iget-object v14, v7, Lj$/time/zone/e;->g:Lj$/time/ZoneOffset;

    iget-object v15, v7, Lj$/time/zone/e;->h:Lj$/time/ZoneOffset;

    sget-object v16, Lj$/time/zone/c;->a:[I

    invoke-virtual {v13}, Ljava/lang/Enum;->ordinal()I

    move-result v13

    aget v13, v16, v13

    if-eq v13, v9, :cond_17e

    const/4 v8, 0x2

    if-eq v13, v8, :cond_16f

    goto :goto_18e

    :cond_16f
    invoke-virtual {v15}, Lj$/time/ZoneOffset;->getTotalSeconds()I

    move-result v8

    invoke-virtual {v14}, Lj$/time/ZoneOffset;->getTotalSeconds()I

    move-result v13

    sub-int/2addr v8, v13

    int-to-long v13, v8

    invoke-virtual {v10, v13, v14}, Lj$/time/LocalDateTime;->J(J)Lj$/time/LocalDateTime;

    move-result-object v10

    goto :goto_18e

    :cond_17e
    invoke-virtual {v15}, Lj$/time/ZoneOffset;->getTotalSeconds()I

    move-result v8

    sget-object v13, Lj$/time/ZoneOffset;->UTC:Lj$/time/ZoneOffset;

    invoke-virtual {v13}, Lj$/time/ZoneOffset;->getTotalSeconds()I

    move-result v13

    sub-int/2addr v8, v13

    int-to-long v13, v8

    invoke-virtual {v10, v13, v14}, Lj$/time/LocalDateTime;->J(J)Lj$/time/LocalDateTime;

    move-result-object v10

    :goto_18e
    new-instance v8, Lj$/time/zone/b;

    iget-object v13, v7, Lj$/time/zone/e;->h:Lj$/time/ZoneOffset;

    iget-object v7, v7, Lj$/time/zone/e;->i:Lj$/time/ZoneOffset;

    invoke-direct {v8, v10, v13, v7}, Lj$/time/zone/b;-><init>(Lj$/time/LocalDateTime;Lj$/time/ZoneOffset;Lj$/time/ZoneOffset;)V

    aput-object v8, v4, v6

    add-int/lit8 v6, v6, 0x1

    const/4 v8, 0x0

    goto/16 :goto_dd

    :cond_19e
    if-ge v1, v5, :cond_1a7

    iget-object v0, v0, Lj$/time/zone/f;->h:Ljava/util/concurrent/ConcurrentMap;

    check-cast v0, Ljava/util/concurrent/ConcurrentHashMap;

    invoke-virtual {v0, v3, v4}, Ljava/util/concurrent/ConcurrentHashMap;->putIfAbsent(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1a7
    return-object v4
.end method

.method public final d(Lj$/time/Instant;)Lj$/time/ZoneOffset;
    .registers 8

    .prologue
    iget-object v0, p0, Lj$/time/zone/f;->g:Ljava/util/TimeZone;

    if-eqz v0, :cond_11

    invoke-virtual {p1}, Lj$/time/Instant;->J()J

    move-result-wide p0

    invoke-virtual {v0, p0, p1}, Ljava/util/TimeZone;->getOffset(J)I

    move-result p0

    invoke-static {p0}, Lj$/time/zone/f;->g(I)Lj$/time/ZoneOffset;

    move-result-object p0

    return-object p0

    :cond_11
    iget-object v0, p0, Lj$/time/zone/f;->c:[J

    array-length v0, v0

    const/4 v1, 0x0

    if-nez v0, :cond_1c

    iget-object p0, p0, Lj$/time/zone/f;->b:[Lj$/time/ZoneOffset;

    aget-object p0, p0, v1

    return-object p0

    :cond_1c
    invoke-virtual {p1}, Lj$/time/Instant;->getEpochSecond()J

    move-result-wide v2

    iget-object p1, p0, Lj$/time/zone/f;->f:[Lj$/time/zone/e;

    array-length p1, p1

    if-lez p1, :cond_54

    iget-object p1, p0, Lj$/time/zone/f;->c:[J

    array-length v0, p1

    add-int/lit8 v0, v0, -0x1

    aget-wide v4, p1, v0

    cmp-long p1, v2, v4

    if-lez p1, :cond_54

    iget-object p1, p0, Lj$/time/zone/f;->e:[Lj$/time/ZoneOffset;

    array-length v0, p1

    add-int/lit8 v0, v0, -0x1

    aget-object p1, p1, v0

    invoke-static {v2, v3, p1}, Lj$/time/zone/f;->c(JLj$/time/ZoneOffset;)I

    move-result p1

    invoke-virtual {p0, p1}, Lj$/time/zone/f;->b(I)[Lj$/time/zone/b;

    move-result-object p0

    const/4 p1, 0x0

    :goto_40
    array-length v0, p0

    if-ge v1, v0, :cond_51

    aget-object p1, p0, v1

    iget-wide v4, p1, Lj$/time/zone/b;->a:J

    cmp-long v0, v2, v4

    if-gez v0, :cond_4e

    iget-object p0, p1, Lj$/time/zone/b;->c:Lj$/time/ZoneOffset;

    return-object p0

    :cond_4e
    add-int/lit8 v1, v1, 0x1

    goto :goto_40

    :cond_51
    iget-object p0, p1, Lj$/time/zone/b;->d:Lj$/time/ZoneOffset;

    return-object p0

    :cond_54
    iget-object p1, p0, Lj$/time/zone/f;->c:[J

    invoke-static {p1, v2, v3}, Ljava/util/Arrays;->binarySearch([JJ)I

    move-result p1

    if-gez p1, :cond_5f

    neg-int p1, p1

    add-int/lit8 p1, p1, -0x2

    :cond_5f
    iget-object p0, p0, Lj$/time/zone/f;->e:[Lj$/time/ZoneOffset;

    add-int/lit8 p1, p1, 0x1

    aget-object p0, p0, p1

    return-object p0
.end method

.method public final e(Lj$/time/LocalDateTime;)Ljava/lang/Object;
    .registers 10

    .prologue
    iget-object v0, p0, Lj$/time/zone/f;->g:Ljava/util/TimeZone;

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz v0, :cond_45

    iget-object v0, p1, Lj$/time/LocalDateTime;->a:Lj$/time/LocalDate;

    invoke-virtual {v0}, Lj$/time/LocalDate;->getYear()I

    move-result v0

    invoke-virtual {p0, v0}, Lj$/time/zone/f;->b(I)[Lj$/time/zone/b;

    move-result-object v0

    array-length v3, v0

    if-nez v3, :cond_29

    iget-object v0, p0, Lj$/time/zone/f;->g:Ljava/util/TimeZone;

    iget-object p0, p0, Lj$/time/zone/f;->b:[Lj$/time/ZoneOffset;

    aget-object p0, p0, v2

    invoke-interface {p1, p0}, Lj$/time/chrono/e;->s(Lj$/time/ZoneOffset;)J

    move-result-wide p0

    const-wide/16 v1, 0x3e8

    mul-long/2addr p0, v1

    invoke-virtual {v0, p0, p1}, Ljava/util/TimeZone;->getOffset(J)I

    move-result p0

    invoke-static {p0}, Lj$/time/zone/f;->g(I)Lj$/time/ZoneOffset;

    move-result-object p0

    return-object p0

    :cond_29
    array-length p0, v0

    :goto_2a
    if-ge v2, p0, :cond_44

    aget-object v1, v0, v2

    invoke-static {p1, v1}, Lj$/time/zone/f;->a(Lj$/time/LocalDateTime;Lj$/time/zone/b;)Ljava/lang/Object;

    move-result-object v3

    instance-of v4, v3, Lj$/time/zone/b;

    if-nez v4, :cond_43

    iget-object v1, v1, Lj$/time/zone/b;->c:Lj$/time/ZoneOffset;

    invoke-virtual {v3, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_3f

    goto :goto_43

    :cond_3f
    add-int/lit8 v2, v2, 0x1

    move-object v1, v3

    goto :goto_2a

    :cond_43
    :goto_43
    return-object v3

    :cond_44
    return-object v1

    :cond_45
    iget-object v0, p0, Lj$/time/zone/f;->c:[J

    array-length v0, v0

    if-nez v0, :cond_4f

    iget-object p0, p0, Lj$/time/zone/f;->b:[Lj$/time/ZoneOffset;

    aget-object p0, p0, v2

    return-object p0

    :cond_4f
    iget-object v0, p0, Lj$/time/zone/f;->f:[Lj$/time/zone/e;

    array-length v0, v0

    const/4 v3, 0x1

    if-lez v0, :cond_bd

    iget-object v0, p0, Lj$/time/zone/f;->d:[Lj$/time/LocalDateTime;

    array-length v4, v0

    sub-int/2addr v4, v3

    aget-object v0, v0, v4

    if-eqz v0, :cond_6a

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1, v0}, Lj$/time/LocalDateTime;->n(Lj$/time/LocalDateTime;)I

    move-result v0

    if-lez v0, :cond_68

    :cond_66
    :goto_66
    move v0, v3

    goto :goto_95

    :cond_68
    move v0, v2

    goto :goto_95

    :cond_6a
    invoke-virtual {p1}, Lj$/time/LocalDateTime;->toLocalDate()Lj$/time/LocalDate;

    move-result-object v4

    invoke-virtual {v4}, Lj$/time/LocalDate;->z()J

    move-result-wide v4

    invoke-virtual {v0}, Lj$/time/LocalDateTime;->toLocalDate()Lj$/time/LocalDate;

    move-result-object v6

    invoke-virtual {v6}, Lj$/time/LocalDate;->z()J

    move-result-wide v6

    cmp-long v4, v4, v6

    if-gtz v4, :cond_66

    if-nez v4, :cond_68

    invoke-interface {p1}, Lj$/time/chrono/e;->toLocalTime()Lj$/time/LocalTime;

    move-result-object v4

    invoke-virtual {v4}, Lj$/time/LocalTime;->P()J

    move-result-wide v4

    invoke-interface {v0}, Lj$/time/chrono/e;->toLocalTime()Lj$/time/LocalTime;

    move-result-object v0

    invoke-virtual {v0}, Lj$/time/LocalTime;->P()J

    move-result-wide v6

    cmp-long v0, v4, v6

    if-lez v0, :cond_68

    goto :goto_66

    :goto_95
    if-eqz v0, :cond_bd

    iget-object v0, p1, Lj$/time/LocalDateTime;->a:Lj$/time/LocalDate;

    invoke-virtual {v0}, Lj$/time/LocalDate;->getYear()I

    move-result v0

    invoke-virtual {p0, v0}, Lj$/time/zone/f;->b(I)[Lj$/time/zone/b;

    move-result-object p0

    array-length v0, p0

    :goto_a2
    if-ge v2, v0, :cond_bc

    aget-object v1, p0, v2

    invoke-static {p1, v1}, Lj$/time/zone/f;->a(Lj$/time/LocalDateTime;Lj$/time/zone/b;)Ljava/lang/Object;

    move-result-object v3

    instance-of v4, v3, Lj$/time/zone/b;

    if-nez v4, :cond_bb

    iget-object v1, v1, Lj$/time/zone/b;->c:Lj$/time/ZoneOffset;

    invoke-virtual {v3, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_b7

    goto :goto_bb

    :cond_b7
    add-int/lit8 v2, v2, 0x1

    move-object v1, v3

    goto :goto_a2

    :cond_bb
    :goto_bb
    return-object v3

    :cond_bc
    return-object v1

    :cond_bd
    iget-object v0, p0, Lj$/time/zone/f;->d:[Lj$/time/LocalDateTime;

    invoke-static {v0, p1}, Ljava/util/Arrays;->binarySearch([Ljava/lang/Object;Ljava/lang/Object;)I

    move-result p1

    const/4 v0, -0x1

    if-ne p1, v0, :cond_cb

    iget-object p0, p0, Lj$/time/zone/f;->e:[Lj$/time/ZoneOffset;

    aget-object p0, p0, v2

    return-object p0

    :cond_cb
    if-gez p1, :cond_d1

    neg-int p1, p1

    add-int/lit8 p1, p1, -0x2

    goto :goto_e4

    :cond_d1
    iget-object v0, p0, Lj$/time/zone/f;->d:[Lj$/time/LocalDateTime;

    array-length v1, v0

    sub-int/2addr v1, v3

    if-ge p1, v1, :cond_e4

    aget-object v1, v0, p1

    add-int/lit8 v2, p1, 0x1

    aget-object v0, v0, v2

    invoke-virtual {v1, v0}, Lj$/time/LocalDateTime;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_e4

    move p1, v2

    :cond_e4
    :goto_e4
    and-int/lit8 v0, p1, 0x1

    if-nez v0, :cond_10f

    iget-object v0, p0, Lj$/time/zone/f;->d:[Lj$/time/LocalDateTime;

    aget-object v1, v0, p1

    add-int/lit8 v2, p1, 0x1

    aget-object v0, v0, v2

    iget-object p0, p0, Lj$/time/zone/f;->e:[Lj$/time/ZoneOffset;

    div-int/lit8 p1, p1, 0x2

    aget-object v2, p0, p1

    add-int/2addr p1, v3

    aget-object p0, p0, p1

    invoke-virtual {p0}, Lj$/time/ZoneOffset;->getTotalSeconds()I

    move-result p1

    invoke-virtual {v2}, Lj$/time/ZoneOffset;->getTotalSeconds()I

    move-result v3

    if-le p1, v3, :cond_109

    new-instance p1, Lj$/time/zone/b;

    invoke-direct {p1, v1, v2, p0}, Lj$/time/zone/b;-><init>(Lj$/time/LocalDateTime;Lj$/time/ZoneOffset;Lj$/time/ZoneOffset;)V

    return-object p1

    :cond_109
    new-instance p1, Lj$/time/zone/b;

    invoke-direct {p1, v0, v2, p0}, Lj$/time/zone/b;-><init>(Lj$/time/LocalDateTime;Lj$/time/ZoneOffset;Lj$/time/ZoneOffset;)V

    return-object p1

    :cond_10f
    iget-object p0, p0, Lj$/time/zone/f;->e:[Lj$/time/ZoneOffset;

    div-int/lit8 p1, p1, 0x2

    add-int/2addr p1, v3

    aget-object p0, p0, p1

    return-object p0
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    .prologue
    if-ne p0, p1, :cond_3

    goto :goto_45

    :cond_3
    instance-of v0, p1, Lj$/time/zone/f;

    if-eqz v0, :cond_47

    check-cast p1, Lj$/time/zone/f;

    iget-object v0, p0, Lj$/time/zone/f;->g:Ljava/util/TimeZone;

    iget-object v1, p1, Lj$/time/zone/f;->g:Ljava/util/TimeZone;

    invoke-static {v0, v1}, Ljava/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_47

    iget-object v0, p0, Lj$/time/zone/f;->a:[J

    iget-object v1, p1, Lj$/time/zone/f;->a:[J

    invoke-static {v0, v1}, Ljava/util/Arrays;->equals([J[J)Z

    move-result v0

    if-eqz v0, :cond_47

    iget-object v0, p0, Lj$/time/zone/f;->b:[Lj$/time/ZoneOffset;

    iget-object v1, p1, Lj$/time/zone/f;->b:[Lj$/time/ZoneOffset;

    invoke-static {v0, v1}, Ljava/util/Arrays;->equals([Ljava/lang/Object;[Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_47

    iget-object v0, p0, Lj$/time/zone/f;->c:[J

    iget-object v1, p1, Lj$/time/zone/f;->c:[J

    invoke-static {v0, v1}, Ljava/util/Arrays;->equals([J[J)Z

    move-result v0

    if-eqz v0, :cond_47

    iget-object v0, p0, Lj$/time/zone/f;->e:[Lj$/time/ZoneOffset;

    iget-object v1, p1, Lj$/time/zone/f;->e:[Lj$/time/ZoneOffset;

    invoke-static {v0, v1}, Ljava/util/Arrays;->equals([Ljava/lang/Object;[Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_47

    iget-object p0, p0, Lj$/time/zone/f;->f:[Lj$/time/zone/e;

    iget-object p1, p1, Lj$/time/zone/f;->f:[Lj$/time/zone/e;

    invoke-static {p0, p1}, Ljava/util/Arrays;->equals([Ljava/lang/Object;[Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_47

    :goto_45
    const/4 p0, 0x1

    return p0

    :cond_47
    const/4 p0, 0x0

    return p0
.end method

.method public final f(Lj$/time/LocalDateTime;)Ljava/util/List;
    .registers 5

    .prologue
    invoke-virtual {p0, p1}, Lj$/time/zone/f;->e(Lj$/time/LocalDateTime;)Ljava/lang/Object;

    move-result-object p0

    instance-of p1, p0, Lj$/time/zone/b;

    if-eqz p1, :cond_3c

    check-cast p0, Lj$/time/zone/b;

    iget-object p1, p0, Lj$/time/zone/b;->d:Lj$/time/ZoneOffset;

    invoke-virtual {p1}, Lj$/time/ZoneOffset;->getTotalSeconds()I

    move-result p1

    iget-object v0, p0, Lj$/time/zone/b;->c:Lj$/time/ZoneOffset;

    invoke-virtual {v0}, Lj$/time/ZoneOffset;->getTotalSeconds()I

    move-result v0

    if-le p1, v0, :cond_1b

    sget-object p0, Ljava/util/Collections;->EMPTY_LIST:Ljava/util/List;

    return-object p0

    :cond_1b
    iget-object p1, p0, Lj$/time/zone/b;->c:Lj$/time/ZoneOffset;

    iget-object p0, p0, Lj$/time/zone/b;->d:Lj$/time/ZoneOffset;

    filled-new-array {p1, p0}, [Ljava/lang/Object;

    move-result-object p0

    new-instance p1, Ljava/util/ArrayList;

    const/4 v0, 0x2

    invoke-direct {p1, v0}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v1, 0x0

    :goto_2a
    if-ge v1, v0, :cond_37

    aget-object v2, p0, v1

    invoke-static {v2}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v1, v1, 0x1

    goto :goto_2a

    :cond_37
    invoke-static {p1}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object p0

    return-object p0

    :cond_3c
    check-cast p0, Lj$/time/ZoneOffset;

    invoke-static {p0}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    return-object p0
.end method

.method public final hashCode()I
    .registers 3

    iget-object v0, p0, Lj$/time/zone/f;->g:Ljava/util/TimeZone;

    invoke-static {v0}, Ljava/util/Objects;->hashCode(Ljava/lang/Object;)I

    move-result v0

    iget-object v1, p0, Lj$/time/zone/f;->a:[J

    invoke-static {v1}, Ljava/util/Arrays;->hashCode([J)I

    move-result v1

    xor-int/2addr v0, v1

    iget-object v1, p0, Lj$/time/zone/f;->b:[Lj$/time/ZoneOffset;

    invoke-static {v1}, Ljava/util/Arrays;->hashCode([Ljava/lang/Object;)I

    move-result v1

    xor-int/2addr v0, v1

    iget-object v1, p0, Lj$/time/zone/f;->c:[J

    invoke-static {v1}, Ljava/util/Arrays;->hashCode([J)I

    move-result v1

    xor-int/2addr v0, v1

    iget-object v1, p0, Lj$/time/zone/f;->e:[Lj$/time/ZoneOffset;

    invoke-static {v1}, Ljava/util/Arrays;->hashCode([Ljava/lang/Object;)I

    move-result v1

    xor-int/2addr v0, v1

    iget-object p0, p0, Lj$/time/zone/f;->f:[Lj$/time/zone/e;

    invoke-static {p0}, Ljava/util/Arrays;->hashCode([Ljava/lang/Object;)I

    move-result p0

    xor-int/2addr p0, v0

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 4

    .prologue
    iget-object v0, p0, Lj$/time/zone/f;->g:Ljava/util/TimeZone;

    const-string v1, "]"

    if-eqz v0, :cond_1c

    invoke-virtual {v0}, Ljava/util/TimeZone;->getID()Ljava/lang/String;

    move-result-object p0

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "ZoneRules[timeZone="

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_1c
    iget-object p0, p0, Lj$/time/zone/f;->b:[Lj$/time/ZoneOffset;

    array-length v0, p0

    add-int/lit8 v0, v0, -0x1

    aget-object p0, p0, v0

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "ZoneRules[currentStandardOffset="

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method
