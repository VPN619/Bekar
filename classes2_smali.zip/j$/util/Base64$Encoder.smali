.class public Lj$/util/Base64$Encoder;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lj$/util/Base64;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Encoder"
.end annotation


# static fields
.field public static final a:[C

.field public static final b:[C

.field public static final c:Lj$/util/Base64$Encoder;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .prologue
    const/16 v0, 0x40

    new-array v0, v0, [C

    fill-array-data v0, :array_1a

    sput-object v0, Lj$/util/Base64$Encoder;->a:[C

    const/16 v0, 0x40

    new-array v0, v0, [C

    fill-array-data v0, :array_5e

    sput-object v0, Lj$/util/Base64$Encoder;->b:[C

    new-instance v0, Lj$/util/Base64$Encoder;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lj$/util/Base64$Encoder;->c:Lj$/util/Base64$Encoder;

    return-void

    :array_1a
    .array-data 2
        0x41s
        0x42s
        0x43s
        0x44s
        0x45s
        0x46s
        0x47s
        0x48s
        0x49s
        0x4as
        0x4bs
        0x4cs
        0x4ds
        0x4es
        0x4fs
        0x50s
        0x51s
        0x52s
        0x53s
        0x54s
        0x55s
        0x56s
        0x57s
        0x58s
        0x59s
        0x5as
        0x61s
        0x62s
        0x63s
        0x64s
        0x65s
        0x66s
        0x67s
        0x68s
        0x69s
        0x6as
        0x6bs
        0x6cs
        0x6ds
        0x6es
        0x6fs
        0x70s
        0x71s
        0x72s
        0x73s
        0x74s
        0x75s
        0x76s
        0x77s
        0x78s
        0x79s
        0x7as
        0x30s
        0x31s
        0x32s
        0x33s
        0x34s
        0x35s
        0x36s
        0x37s
        0x38s
        0x39s
        0x2bs
        0x2fs
    .end array-data

    :array_5e
    .array-data 2
        0x41s
        0x42s
        0x43s
        0x44s
        0x45s
        0x46s
        0x47s
        0x48s
        0x49s
        0x4as
        0x4bs
        0x4cs
        0x4ds
        0x4es
        0x4fs
        0x50s
        0x51s
        0x52s
        0x53s
        0x54s
        0x55s
        0x56s
        0x57s
        0x58s
        0x59s
        0x5as
        0x61s
        0x62s
        0x63s
        0x64s
        0x65s
        0x66s
        0x67s
        0x68s
        0x69s
        0x6as
        0x6bs
        0x6cs
        0x6ds
        0x6es
        0x6fs
        0x70s
        0x71s
        0x72s
        0x73s
        0x74s
        0x75s
        0x76s
        0x77s
        0x78s
        0x79s
        0x7as
        0x30s
        0x31s
        0x32s
        0x33s
        0x34s
        0x35s
        0x36s
        0x37s
        0x38s
        0x39s
        0x2ds
        0x5fs
    .end array-data
.end method


# virtual methods
.method public encodeToString([B)Ljava/lang/String;
    .registers 16

    .prologue
    array-length p0, p1

    add-int/lit8 p0, p0, 0x2

    div-int/lit8 p0, p0, 0x3

    mul-int/lit8 p0, p0, 0x4

    new-array v0, p0, [B

    array-length v1, p1

    div-int/lit8 v2, v1, 0x3

    mul-int/lit8 v2, v2, 0x3

    const/4 v3, 0x0

    move v4, v3

    move v5, v4

    :goto_11
    sget-object v6, Lj$/util/Base64$Encoder;->a:[C

    if-ge v4, v2, :cond_73

    add-int v7, v4, v2

    invoke-static {v7, v2}, Ljava/lang/Math;->min(II)I

    move-result v7

    move v8, v4

    move v9, v5

    :goto_1d
    if-ge v8, v7, :cond_62

    add-int/lit8 v10, v8, 0x1

    aget-byte v11, p1, v8

    and-int/lit16 v11, v11, 0xff

    shl-int/lit8 v11, v11, 0x10

    add-int/lit8 v12, v8, 0x2

    aget-byte v10, p1, v10

    and-int/lit16 v10, v10, 0xff

    shl-int/lit8 v10, v10, 0x8

    or-int/2addr v10, v11

    add-int/lit8 v8, v8, 0x3

    aget-byte v11, p1, v12

    and-int/lit16 v11, v11, 0xff

    or-int/2addr v10, v11

    add-int/lit8 v11, v9, 0x1

    ushr-int/lit8 v12, v10, 0x12

    and-int/lit8 v12, v12, 0x3f

    aget-char v12, v6, v12

    int-to-byte v12, v12

    aput-byte v12, v0, v9

    add-int/lit8 v12, v9, 0x2

    ushr-int/lit8 v13, v10, 0xc

    and-int/lit8 v13, v13, 0x3f

    aget-char v13, v6, v13

    int-to-byte v13, v13

    aput-byte v13, v0, v11

    add-int/lit8 v11, v9, 0x3

    ushr-int/lit8 v13, v10, 0x6

    and-int/lit8 v13, v13, 0x3f

    aget-char v13, v6, v13

    int-to-byte v13, v13

    aput-byte v13, v0, v12

    add-int/lit8 v9, v9, 0x4

    and-int/lit8 v10, v10, 0x3f

    aget-char v10, v6, v10

    int-to-byte v10, v10

    aput-byte v10, v0, v11

    goto :goto_1d

    :cond_62
    sub-int v4, v7, v4

    div-int/lit8 v4, v4, 0x3

    mul-int/lit8 v4, v4, 0x4

    add-int/2addr v5, v4

    const/4 v6, -0x1

    if-ne v4, v6, :cond_71

    if-lt v7, v1, :cond_6f

    goto :goto_71

    :cond_6f
    const/4 p0, 0x0

    throw p0

    :cond_71
    :goto_71
    move v4, v7

    goto :goto_11

    :cond_73
    if-ge v4, v1, :cond_bd

    add-int/lit8 v2, v4, 0x1

    aget-byte v4, p1, v4

    and-int/lit16 v4, v4, 0xff

    add-int/lit8 v7, v5, 0x1

    shr-int/lit8 v8, v4, 0x2

    aget-char v8, v6, v8

    int-to-byte v8, v8

    aput-byte v8, v0, v5

    const/16 v8, 0x3d

    if-ne v2, v1, :cond_9c

    add-int/lit8 p1, v5, 0x2

    shl-int/lit8 v1, v4, 0x4

    and-int/lit8 v1, v1, 0x3f

    aget-char v1, v6, v1

    int-to-byte v1, v1

    aput-byte v1, v0, v7

    add-int/lit8 v1, v5, 0x3

    aput-byte v8, v0, p1

    add-int/lit8 v5, v5, 0x4

    aput-byte v8, v0, v1

    goto :goto_bd

    :cond_9c
    aget-byte p1, p1, v2

    and-int/lit16 p1, p1, 0xff

    add-int/lit8 v1, v5, 0x2

    shl-int/lit8 v2, v4, 0x4

    and-int/lit8 v2, v2, 0x3f

    shr-int/lit8 v4, p1, 0x4

    or-int/2addr v2, v4

    aget-char v2, v6, v2

    int-to-byte v2, v2

    aput-byte v2, v0, v7

    add-int/lit8 v2, v5, 0x3

    shl-int/lit8 p1, p1, 0x2

    and-int/lit8 p1, p1, 0x3f

    aget-char p1, v6, p1

    int-to-byte p1, p1

    aput-byte p1, v0, v1

    add-int/lit8 v5, v5, 0x4

    aput-byte v8, v0, v2

    :cond_bd
    :goto_bd
    if-eq v5, p0, :cond_c3

    invoke-static {v0, v5}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object v0

    :cond_c3
    new-instance p0, Ljava/lang/String;

    array-length p1, v0

    invoke-direct {p0, v0, v3, v3, p1}, Ljava/lang/String;-><init>([BIII)V

    return-object p0
.end method
