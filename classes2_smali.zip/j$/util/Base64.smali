.class public Lj$/util/Base64;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lj$/util/Base64$Decoder;,
        Lj$/util/Base64$Encoder;
    }
.end annotation


# direct methods
.method public static getDecoder()Lj$/util/Base64$Decoder;
    .registers 1

    sget-object v0, Lj$/util/Base64$Decoder;->c:Lj$/util/Base64$Decoder;

    return-object v0
.end method

.method public static getEncoder()Lj$/util/Base64$Encoder;
    .registers 1

    sget-object v0, Lj$/util/Base64$Encoder;->c:Lj$/util/Base64$Encoder;

    return-object v0
.end method
