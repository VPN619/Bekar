.class public final synthetic Lj$/util/DateRetargetClass;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# direct methods
.method public static toInstant(Ljava/util/Date;)Lj$/time/Instant;
    .registers 7

    invoke-virtual {p0}, Ljava/util/Date;->getTime()J

    move-result-wide v0

    sget-object p0, Lj$/time/Instant;->c:Lj$/time/Instant;

    const-wide/16 v2, 0x3e8

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->floorDiv(JJ)J

    move-result-wide v4

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->floorMod(JJ)J

    move-result-wide v0

    long-to-int p0, v0

    const v0, 0xf4240

    mul-int/2addr p0, v0

    invoke-static {v4, v5, p0}, Lj$/time/Instant;->n(JI)Lj$/time/Instant;

    move-result-object p0

    return-object p0
.end method
