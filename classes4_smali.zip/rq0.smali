.class public final Lrq0;
.super Lqq1;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final c:Ljava/util/ArrayList;

.field public final d:Lcom/tlsvpn/tlstunnel/ui/imex/Importar;


# direct methods
.method public constructor <init>(Ljava/util/ArrayList;Lcom/tlsvpn/tlstunnel/ui/imex/Importar;)V
    .registers 5

    invoke-direct {p0}, Lqq1;-><init>()V

    const/16 v0, 0x1154

    iput-object p1, p0, Lrq0;->c:Ljava/util/ArrayList;

    const/16 v0, 0x75e

    iput-object p2, p0, Lrq0;->d:Lcom/tlsvpn/tlstunnel/ui/imex/Importar;

    return-void
.end method


# virtual methods
.method public final a()I
    .registers 3

    const/16 v0, 0x342

    iget-object p0, p0, Lrq0;->c:Ljava/util/ArrayList;

    nop

    const/16 v0, 0xac

    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result p0

    return p0
.end method

.method public final e(Lpr1;I)V
    .registers 10

    .prologue
    check-cast p1, Lqq0;

    const/16 v0, 0x1088

    iget-object v2, p1, Lqq0;->x:Landroid/widget/TextView;

    nop

    const/16 v0, 0xd9e

    iget-object v3, p1, Lqq0;->v:Landroid/widget/ImageView;

    nop

    const/16 v0, 0x632

    iget-object p1, p1, Lqq0;->w:Landroid/widget/TextView;

    nop

    const/16 v0, 0x342

    iget-object v4, p0, Lrq0;->c:Ljava/util/ArrayList;

    nop

    const/16 v0, 0x43

    invoke-virtual {v4, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/CharSequence;

    const/16 v0, 0x8a

    invoke-virtual {p1, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v0, 0x43

    invoke-virtual {v4, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p1, Ljava/lang/String;

    const-string/jumbo v5, ".tls"

    const/4 v6, 0x1

    const/16 v0, 0x390

    invoke-static {p1, v5, v6}, Lk72;->e0(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result p1

    if-eqz p1, :cond_8c

    const/16 v0, 0x24e

    new-instance p1, Ljava/io/File;

    nop

    const/4 v0, -0x3

    new-instance v5, Ljava/lang/StringBuilder;

    nop

    const/4 v0, -0x4

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v0, 0x11b5

    iget-object p0, p0, Lrq0;->d:Lcom/tlsvpn/tlstunnel/ui/imex/Importar;

    nop

    const/16 v0, 0x21e

    iget-object p0, p0, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->m:Ljava/lang/String;

    nop

    const/4 v0, 0x0

    invoke-virtual {v5, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 p0, 0x2f

    const/16 v0, 0x1b

    invoke-virtual {v5, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v0, 0x43

    invoke-virtual {v4, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    const/4 v0, 0x0

    invoke-virtual {v5, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x212

    invoke-direct {p1, p0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/16 v0, 0xc2a

    invoke-virtual {p1}, Ljava/io/File;->isFile()Z

    move-result p0

    if-eqz p0, :cond_8c

    const p0, 0x7f08013a

    const/16 v0, 0x87

    invoke-virtual {v3, p0}, Landroid/widget/ImageView;->setImageResource(I)V

    const p0, 0x7f130092

    const/16 v0, 0x93

    invoke-virtual {v2, p0}, Landroid/widget/TextView;->setText(I)V

    return-void

    :cond_8c
    const p0, 0x7f080103

    const/16 v0, 0x87

    invoke-virtual {v3, p0}, Landroid/widget/ImageView;->setImageResource(I)V

    const p0, 0x7f1301e8

    const/16 v0, 0x93

    invoke-virtual {v2, p0}, Landroid/widget/TextView;->setText(I)V

    return-void
.end method

.method public final f(Landroid/view/ViewGroup;I)Lpr1;
    .registers 7

    const/16 v0, 0xee7

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p2

    const/16 v0, 0x8f9

    invoke-static {p2}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object p2

    const v2, 0x7f0c001f

    const/4 v3, 0x0

    const/16 v0, 0x107b

    invoke-virtual {p2, v2, p1, v3}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    const/16 v0, 0xed0

    new-instance p2, Lqq0;

    nop

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x11b5

    iget-object p0, p0, Lrq0;->d:Lcom/tlsvpn/tlstunnel/ui/imex/Importar;

    nop

    const/16 v0, 0xb89

    invoke-direct {p2, p1, p0}, Lqq0;-><init>(Landroid/view/View;Lcom/tlsvpn/tlstunnel/ui/imex/Importar;)V

    check-cast p2, Lpr1;

    return-object p2
.end method
