.class public Lms1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lyt;
.implements Lky;
.implements Lcom/google/android/gms/internal/consent_sdk/zzqp;
.implements Lfp3;
.implements Lk4;
.implements Lnl2;
.implements Ltl;
.implements Lua0;
.implements Loo1;
.implements Lml1;


# static fields
.field public static final b:Lms1;

.field public static final c:Lms1;

.field public static final d:Lms1;

.field public static final synthetic e:Lms1;

.field public static final f:Lms1;

.field public static final g:Lms1;

.field public static final h:Lms1;

.field public static final i:Lms1;

.field public static final j:Lms1;

.field public static final k:Lms1;

.field public static final l:Lms1;

.field public static final m:Lms1;

.field public static final n:Lms1;

.field public static final o:Lms1;

.field public static final p:Lms1;

.field public static final q:Lms1;

.field public static r:Lms1;


# instance fields
.field public final synthetic a:I


# direct methods
.method static synthetic constructor <clinit>()V
    .registers 2

    new-instance v0, Lms1;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lms1;-><init>(I)V

    sput-object v0, Lms1;->b:Lms1;

    new-instance v0, Lms1;

    const/4 v1, 0x2

    invoke-direct {v0, v1}, Lms1;-><init>(I)V

    sput-object v0, Lms1;->c:Lms1;

    new-instance v0, Lms1;

    const/4 v1, 0x3

    invoke-direct {v0, v1}, Lms1;-><init>(I)V

    sput-object v0, Lms1;->d:Lms1;

    new-instance v0, Lms1;

    const/4 v1, 0x4

    invoke-direct {v0, v1}, Lms1;-><init>(I)V

    sput-object v0, Lms1;->e:Lms1;

    new-instance v0, Lms1;

    const/4 v1, 0x5

    invoke-direct {v0, v1}, Lms1;-><init>(I)V

    sput-object v0, Lms1;->f:Lms1;

    new-instance v0, Lms1;

    const/4 v1, 0x6

    invoke-direct {v0, v1}, Lms1;-><init>(I)V

    sput-object v0, Lms1;->g:Lms1;

    new-instance v0, Lms1;

    const/4 v1, 0x7

    invoke-direct {v0, v1}, Lms1;-><init>(I)V

    sput-object v0, Lms1;->h:Lms1;

    new-instance v0, Lms1;

    const/16 v1, 0x8

    invoke-direct {v0, v1}, Lms1;-><init>(I)V

    sput-object v0, Lms1;->i:Lms1;

    new-instance v0, Lms1;

    const/16 v1, 0x9

    invoke-direct {v0, v1}, Lms1;-><init>(I)V

    sput-object v0, Lms1;->j:Lms1;

    new-instance v0, Lms1;

    const/16 v1, 0xa

    invoke-direct {v0, v1}, Lms1;-><init>(I)V

    sput-object v0, Lms1;->k:Lms1;

    new-instance v0, Lms1;

    const/16 v1, 0xb

    invoke-direct {v0, v1}, Lms1;-><init>(I)V

    sput-object v0, Lms1;->l:Lms1;

    new-instance v0, Lms1;

    const/16 v1, 0xc

    invoke-direct {v0, v1}, Lms1;-><init>(I)V

    sput-object v0, Lms1;->m:Lms1;

    new-instance v0, Lms1;

    const/16 v1, 0xd

    invoke-direct {v0, v1}, Lms1;-><init>(I)V

    sput-object v0, Lms1;->n:Lms1;

    new-instance v0, Lms1;

    const/16 v1, 0xe

    invoke-direct {v0, v1}, Lms1;-><init>(I)V

    sput-object v0, Lms1;->o:Lms1;

    new-instance v0, Lms1;

    const/16 v1, 0xf

    invoke-direct {v0, v1}, Lms1;-><init>(I)V

    sput-object v0, Lms1;->p:Lms1;

    new-instance v0, Lms1;

    const/16 v1, 0x10

    invoke-direct {v0, v1}, Lms1;-><init>(I)V

    sput-object v0, Lms1;->q:Lms1;

    return-void
.end method

.method public synthetic constructor <init>(I)V
    .registers 2

    iput p1, p0, Lms1;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a([BII)[B
    .registers 5

    new-array p0, p3, [B

    const/4 v0, 0x0

    invoke-static {p1, p2, p0, v0, p3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-object p0
.end method

.method public b(F)F
    .registers 2

    const/high16 p0, 0x3f800000  # 1.0f

    return p0
.end method

.method public c(Ljava/lang/Class;)Ljp3;
    .registers 4

    .prologue
    const-class p0, Lcom/google/android/gms/internal/consent_sdk/zzqm;

    invoke-virtual {p0, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_29

    :try_start_9
    invoke-virtual {p1, p0}, Ljava/lang/Class;->asSubclass(Ljava/lang/Class;)Ljava/lang/Class;

    move-result-object p0

    invoke-static {p0}, Lcom/google/android/gms/internal/consent_sdk/zzqm;->e(Ljava/lang/Class;)Lcom/google/android/gms/internal/consent_sdk/zzqm;

    move-result-object p0

    const/4 v0, 0x3

    invoke-virtual {p0, v0, v1, v1}, Lcom/google/android/gms/internal/consent_sdk/zzqm;->zzb(ILjava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljp3;
    :try_end_18
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_18} :catch_19

    return-object p0

    :catch_19
    move-exception p0

    invoke-virtual {p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p1

    const-string/jumbo v0, "Unable to get message info for "

    invoke-virtual {v0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1, p0}, Lvx2;->k(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-object v1

    :cond_29
    invoke-virtual {p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    const-string/jumbo p1, "Unsupported message type: "

    invoke-virtual {p1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->s(Ljava/lang/String;)V

    return-object v1
.end method

.method public d(Landroid/view/View;Lpp2;Lrz;)Lpp2;
    .registers 8

    .prologue
    iget p0, p3, Lrz;->e:I

    invoke-virtual {p2}, Lpp2;->a()I

    move-result v0

    add-int/2addr v0, p0

    iput v0, p3, Lrz;->e:I

    invoke-virtual {p1}, Landroid/view/View;->getLayoutDirection()I

    move-result p0

    const/4 v0, 0x1

    if-ne p0, v0, :cond_11

    goto :goto_12

    :cond_11
    const/4 v0, 0x0

    :goto_12
    invoke-virtual {p2}, Lpp2;->b()I

    move-result p0

    invoke-virtual {p2}, Lpp2;->c()I

    move-result v1

    iget v2, p3, Lrz;->b:I

    if-eqz v0, :cond_20

    move v3, v1

    goto :goto_21

    :cond_20
    move v3, p0

    :goto_21
    add-int/2addr v2, v3

    iput v2, p3, Lrz;->b:I

    iget v3, p3, Lrz;->d:I

    if-eqz v0, :cond_29

    goto :goto_2a

    :cond_29
    move p0, v1

    :goto_2a
    add-int/2addr v3, p0

    iput v3, p3, Lrz;->d:I

    iget p0, p3, Lrz;->c:I

    iget p3, p3, Lrz;->e:I

    invoke-virtual {p1, v2, p0, v3, p3}, Landroid/view/View;->setPaddingRelative(IIII)V

    return-object p2
.end method

.method public e(Ljava/lang/Class;)Z
    .registers 2

    const-class p0, Lcom/google/android/gms/internal/consent_sdk/zzqm;

    invoke-virtual {p0, p1}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result p0

    return p0
.end method

.method public f(Ljava/lang/String;Ljava/security/Provider;)Ljava/lang/Object;
    .registers 3

    .prologue
    if-nez p2, :cond_7

    invoke-static {p1}, Ljava/security/KeyPairGenerator;->getInstance(Ljava/lang/String;)Ljava/security/KeyPairGenerator;

    move-result-object p0

    return-object p0

    :cond_7
    invoke-static {p1, p2}, Ljava/security/KeyPairGenerator;->getInstance(Ljava/lang/String;Ljava/security/Provider;)Ljava/security/KeyPairGenerator;

    move-result-object p0

    return-object p0
.end method

.method public g(Landroidx/preference/Preference;)Ljava/lang/CharSequence;
    .registers 4

    .prologue
    check-cast p1, Landroidx/preference/ListPreference;

    iget-object p0, p1, Landroidx/preference/ListPreference;->T:[Ljava/lang/CharSequence;

    iget-object v0, p1, Landroidx/preference/ListPreference;->V:Ljava/lang/String;

    invoke-virtual {p1, v0}, Landroidx/preference/ListPreference;->z(Ljava/lang/String;)I

    move-result v0

    const/4 v1, 0x0

    if-ltz v0, :cond_12

    if-eqz p0, :cond_12

    aget-object v0, p0, v0

    goto :goto_13

    :cond_12
    move-object v0, v1

    :goto_13
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-eqz v0, :cond_23

    iget-object p0, p1, Landroidx/preference/Preference;->a:Landroid/content/Context;

    const p1, 0x7f1301df

    invoke-virtual {p0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_23
    iget-object v0, p1, Landroidx/preference/ListPreference;->V:Ljava/lang/String;

    invoke-virtual {p1, v0}, Landroidx/preference/ListPreference;->z(Ljava/lang/String;)I

    move-result p1

    if-ltz p1, :cond_30

    if-eqz p0, :cond_30

    aget-object p0, p0, p1

    return-object p0

    :cond_30
    return-object v1
.end method

.method public get()Ljava/lang/Object;
    .registers 3

    new-instance p0, Lav0;

    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    const/4 v1, 0x1

    invoke-direct {p0, v0, v1}, Lav0;-><init>(Ljava/util/concurrent/Executor;I)V

    return-object p0
.end method

.method public h(Lk20;)Ljava/lang/Object;
    .registers 4

    new-instance p0, Lyo1;

    const-class v0, Llj;

    const-class v1, Ljava/util/concurrent/Executor;

    invoke-direct {p0, v0, v1}, Lyo1;-><init>(Ljava/lang/Class;Ljava/lang/Class;)V

    invoke-virtual {p1, p0}, Lk20;->f(Lyo1;)Ljava/lang/Object;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p0, Ljava/util/concurrent/Executor;

    invoke-static {p0}, Lnp3;->I(Ljava/util/concurrent/Executor;)Loy;

    move-result-object p0

    return-object p0
.end method

.method public i(Ljava/io/File;)V
    .registers 2

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/io/File;->delete()Z

    move-result p0

    if-nez p0, :cond_1a

    invoke-virtual {p1}, Ljava/io/File;->exists()Z

    move-result p0

    if-nez p0, :cond_10

    goto :goto_1a

    :cond_10
    const-string/jumbo p0, "failed to delete "

    invoke-static {p1, p0}, Lgt0;->C0(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lvh0;->k(Ljava/lang/String;)V

    :cond_1a
    :goto_1a
    return-void
.end method

.method public j(Ljava/io/File;)V
    .registers 6

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v0

    if-eqz v0, :cond_2c

    array-length p1, v0

    const/4 v1, 0x0

    :goto_b
    if-ge v1, p1, :cond_2b

    aget-object v2, v0, v1

    add-int/lit8 v1, v1, 0x1

    invoke-virtual {v2}, Ljava/io/File;->isDirectory()Z

    move-result v3

    if-eqz v3, :cond_1a

    invoke-virtual {p0, v2}, Lms1;->j(Ljava/io/File;)V

    :cond_1a
    invoke-virtual {v2}, Ljava/io/File;->delete()Z

    move-result v3

    if-eqz v3, :cond_21

    goto :goto_b

    :cond_21
    const-string/jumbo p0, "failed to delete "

    invoke-static {v2, p0}, Lgt0;->C0(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lvh0;->k(Ljava/lang/String;)V

    :cond_2b
    return-void

    :cond_2c
    const-string/jumbo p0, "not a readable directory: "

    invoke-static {p1, p0}, Lgt0;->C0(Ljava/lang/Object;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lvh0;->k(Ljava/lang/String;)V

    return-void
.end method

.method public k(Ljava/io/File;)Z
    .registers 2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/io/File;->exists()Z

    move-result p0

    return p0
.end method

.method public l(Landroid/content/pm/PackageManager;Ljava/lang/String;)[Landroid/content/pm/Signature;
    .registers 3

    const/16 p0, 0x40

    invoke-virtual {p1, p2, p0}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p0

    iget-object p0, p0, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    return-object p0
.end method

.method public m(Ljava/io/File;Ljava/io/File;)V
    .registers 5

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0, p2}, Lms1;->i(Ljava/io/File;)V

    invoke-virtual {p1, p2}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    move-result p0

    if-eqz p0, :cond_10

    return-void

    :cond_10
    new-instance p0, Ljava/io/IOException;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "failed to rename "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string/jumbo p1, " to "

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public onAdFailedToLoad(Lq31;)V
    .registers 6

    .prologue
    const/4 v0, -0x3

    new-instance p0, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v2, "Falha ao carregar Intersticial ("

    const/16 v0, 0x97

    invoke-direct {p0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0xf55

    invoke-virtual {p1}, Lq31;->V()Lp31;

    move-result-object v2

    const/16 v0, 0x190

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string/jumbo v2, ": "

    const/4 v0, 0x0

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0xaf5

    invoke-virtual {p1}, Lq31;->W()Ljava/lang/String;

    move-result-object p1

    const/4 v0, 0x0

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 p1, 0x29

    const/16 v0, 0x1b

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string/jumbo p1, "Ads-Load"

    nop

    const/4 p0, 0x0

    const/16 v0, 0x992

    sput-boolean p0, Lg4;->x:Z

    const/4 p0, 0x0

    const/16 v0, 0x6fe

    sput-object p0, Lg4;->w:Let0;

    const/16 v0, 0x101

    sget-boolean p0, Lmi2;->n:Z

    nop

    if-eqz p0, :cond_4a

    goto :goto_75

    :cond_4a
    const/16 v0, 0xbfc

    sget-object p0, Lmi2;->q:Lcom/tlsvpn/tlstunnel/MainActivity;

    nop

    if-eqz p0, :cond_75

    const/16 v0, 0x140

    sget-boolean p1, Lg4;->a:Z

    nop

    const/16 v0, 0x901

    sget p1, Lg4;->y:I

    nop

    add-int/lit8 v2, p1, 0x1

    const/16 v0, 0x1257

    sput v2, Lg4;->y:I

    const/4 v2, 0x4

    if-ge p1, v2, :cond_75

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-wide/16 v2, 0x3a98

    const/16 v0, 0x2ce

    invoke-static {v2, v3, p0}, Lg4;->k(JLandroid/content/Context;)V

    :cond_75
    :goto_75
    return-void
.end method

.method public onAdLoaded(Ljava/lang/Object;)V
    .registers 5

    .prologue
    check-cast p1, Let0;

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string/jumbo p0, "Ads-Load"

    const-string/jumbo v2, "Intersticial Carregado!"

    nop

    const/4 p0, 0x0

    const/16 v0, 0x992

    sput-boolean p0, Lg4;->x:Z

    const/16 v0, 0x1257

    sput p0, Lg4;->y:I

    const/16 v0, 0x101

    sget-boolean p0, Lmi2;->n:Z

    nop

    if-eqz p0, :cond_1e

    goto :goto_2c

    :cond_1e
    const/16 v0, 0x195

    sget-boolean p0, Lmi2;->d:Z

    nop

    if-nez p0, :cond_2d

    const/16 v0, 0xf11

    sget-boolean p0, Lmi2;->e:Z

    nop

    if-nez p0, :cond_2d

    :goto_2c
    return-void

    :cond_2d
    const/16 v0, 0x6fe

    sput-object p1, Lg4;->w:Let0;

    check-cast p1, Lads_mobile_sdk/ai1;

    const/16 v0, 0xb92

    iget-object p0, p1, Lads_mobile_sdk/ai1;->b:Lxx2;

    nop

    const/4 p1, 0x1

    const/16 v0, 0xb06

    iput-boolean p1, p0, Lads_mobile_sdk/xo;->n:Z

    const/16 v0, 0xcb4

    iput-boolean p1, p0, Lads_mobile_sdk/xo;->o:Z

    const/16 v0, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    return-void
.end method

.method public toString()Ljava/lang/String;
    .registers 2

    .prologue
    iget v0, p0, Lms1;->a:I

    packed-switch v0, :pswitch_data_e

    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :pswitch_a  #0x2
    const-string/jumbo p0, "FileSystem.SYSTEM"

    return-object p0

    :pswitch_data_e
    .packed-switch 0x2
        :pswitch_a  #00000002
    .end packed-switch
.end method
