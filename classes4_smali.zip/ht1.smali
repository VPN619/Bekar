.class public final Lht1;
.super Lwx;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public synthetic t:Ljava/lang/Object;

.field public final synthetic u:Llt1;

.field public v:I


# direct methods
.method public constructor <init>(Llt1;Lwx;)V
    .registers 5

    iput-object p1, p0, Lht1;->u:Llt1;

    invoke-direct {p0, p2}, Lwx;-><init>(Lvx;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    const/16 v0, 0x85c

    iput-object p1, p0, Lht1;->t:Ljava/lang/Object;

    const/16 v0, 0x3e9

    iget p1, p0, Lht1;->v:I

    nop

    const/high16 v2, -0x80000000

    or-int/2addr p1, v2

    const/16 v0, 0x96

    iput p1, p0, Lht1;->v:I

    const/16 v0, 0xd91

    iget-object p1, p0, Lht1;->u:Llt1;

    nop

    const/16 v0, 0x231

    invoke-virtual {p1, p0}, Llt1;->a(Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
