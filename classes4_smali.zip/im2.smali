.class public final Lim2;
.super Lwx;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public t:I

.field public synthetic u:Ljava/lang/Object;

.field public final synthetic v:Lcom/tlsvpn/tlstunnel/services/VpnConnection;

.field public w:I


# direct methods
.method public constructor <init>(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Lwx;)V
    .registers 5

    iput-object p1, p0, Lim2;->v:Lcom/tlsvpn/tlstunnel/services/VpnConnection;

    invoke-direct {p0, p2}, Lwx;-><init>(Lvx;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    const/16 v0, 0x537

    iput-object p1, p0, Lim2;->u:Ljava/lang/Object;

    const/16 v0, 0x3aa

    iget p1, p0, Lim2;->w:I

    nop

    const/high16 v2, -0x80000000

    or-int/2addr p1, v2

    const/16 v0, 0x455

    iput p1, p0, Lim2;->w:I

    const/16 v0, 0xe2

    sget p1, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->O:I

    nop

    const/16 v0, 0x716

    iget-object p1, p0, Lim2;->v:Lcom/tlsvpn/tlstunnel/services/VpnConnection;

    nop

    const/16 v0, 0x957

    invoke-virtual {p1, p0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->i(Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
