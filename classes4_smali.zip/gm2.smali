.class public final synthetic Lgm2;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:Lcom/tlsvpn/tlstunnel/services/VpnConnection;

.field public final synthetic b:J


# direct methods
.method public synthetic constructor <init>(Lcom/tlsvpn/tlstunnel/services/VpnConnection;J)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0xc2c

    iput-object p1, p0, Lgm2;->a:Lcom/tlsvpn/tlstunnel/services/VpnConnection;

    const/16 v0, 0xe1c

    iput-wide p2, p0, Lgm2;->b:J

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 7

    const/16 v0, 0xe2

    sget v2, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->O:I

    nop

    const/4 v2, 0x1

    const/16 v0, 0xb1d

    iget-object v3, p0, Lgm2;->a:Lcom/tlsvpn/tlstunnel/services/VpnConnection;

    nop

    const/16 v0, 0x1248

    iget-wide v4, p0, Lgm2;->b:J

    nop

    const/16 v0, 0xccd

    invoke-virtual {v3, v4, v5, v2}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->l(JZ)V

    return-void
.end method
