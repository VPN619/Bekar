.class public final Lkc0;
.super Lvb;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final synthetic Y:I


# instance fields
.field public A:Landroid/widget/TableLayout;

.field public B:Landroid/widget/EditText;

.field public C:Lcom/google/android/material/textfield/TextInputLayout;

.field public D:Landroid/widget/EditText;

.field public E:Lcom/google/android/material/textfield/TextInputLayout;

.field public F:Landroid/widget/CheckBox;

.field public G:Landroid/widget/LinearLayout;

.field public H:Landroid/widget/EditText;

.field public I:Lcom/google/android/material/textfield/TextInputLayout;

.field public J:Landroid/widget/EditText;

.field public K:Lcom/google/android/material/textfield/TextInputLayout;

.field public L:Landroid/widget/CheckBox;

.field public M:Landroid/widget/CheckBox;

.field public N:Landroid/widget/CheckBox;

.field public O:Landroid/widget/TextView;

.field public P:Lcom/google/android/material/card/MaterialCardView;

.field public Q:Landroid/widget/TextView;

.field public R:Landroid/widget/TextView;

.field public S:Z

.field public T:Ljava/io/File;

.field public U:Landroid/net/Uri;

.field public V:Ljava/io/OutputStream;

.field public W:Z

.field public final X:Lm3;

.field public final q:Lw82;

.field public r:Landroid/widget/ImageView;

.field public s:Landroid/widget/ImageView;

.field public t:Landroid/widget/EditText;

.field public u:Lcom/google/android/material/textfield/TextInputLayout;

.field public v:Landroid/widget/LinearLayout;

.field public w:Lcom/google/android/material/textfield/TextInputEditText;

.field public x:Lcom/google/android/material/textfield/TextInputLayout;

.field public y:Landroid/widget/CheckBox;

.field public z:Landroid/widget/CheckBox;


# direct methods
.method public constructor <init>()V
    .registers 6

    invoke-direct {p0}, Lvb;-><init>()V

    const/16 v0, 0xa84

    new-instance v2, Ld;

    nop

    const/16 v3, 0x8

    const/16 v0, 0x6cb

    invoke-direct {v2, v3, p0}, Ld;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x27a

    new-instance v3, Lw82;

    nop

    const/16 v0, 0x215

    invoke-direct {v3, v2}, Lw82;-><init>(Lzj0;)V

    const/16 v0, 0x818

    iput-object v3, p0, Lkc0;->q:Lw82;

    const/16 v0, 0xa2

    new-instance v2, Ll3;

    nop

    const/4 v3, 0x2

    const/16 v0, 0x9e

    invoke-direct {v2, v3}, Ll3;-><init>(I)V

    const/16 v0, 0x50f

    new-instance v3, Lah;

    nop

    const/4 v4, 0x5

    const/16 v0, 0x3bf

    invoke-direct {v3, v4, p0}, Lah;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0xbe4

    invoke-virtual {p0, v2, v3}, Landroidx/fragment/app/Fragment;->registerForActivityResult(Lk3;Lj3;)Lm3;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xe2f

    iput-object v2, p0, Lkc0;->X:Lm3;

    return-void
.end method


# virtual methods
.method public final c(ZZ)V
    .registers 32

    .prologue
    move-object/from16 v8, p0

    move/from16 v9, p1

    const/16 v6, 0x291

    iget-boolean v10, v8, Lkc0;->W:Z

    nop

    const-string/jumbo v11, "sshpass"

    const-string/jumbo v12, "sshuser"

    const-string/jumbo v13, "sshlogin"

    const-string/jumbo v14, "sshport"

    const-string/jumbo v15, "sshhost"

    const-string/jumbo v16, "sshserver"

    const v17, 0x7f1300c8

    const/16 v18, 0x0

    if-nez v10, :cond_148

    const/16 v6, 0x90

    iget-object v10, v8, Lkc0;->z:Landroid/widget/CheckBox;

    nop

    if-eqz v10, :cond_141

    const/16 v6, 0x36

    invoke-virtual {v10}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v10

    if-eqz v10, :cond_a4

    const/16 v6, 0x130

    iget-object v10, v8, Lkc0;->B:Landroid/widget/EditText;

    nop

    if-eqz v10, :cond_9f

    const/16 v6, 0x2d

    invoke-virtual {v10}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v10

    if-eqz v10, :cond_82

    const/16 v6, 0x7c

    invoke-static {v10}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v10

    if-eqz v10, :cond_49

    goto :goto_82

    :cond_49
    const/16 v6, 0x24f

    iget-object v10, v8, Lkc0;->D:Landroid/widget/EditText;

    nop

    if-eqz v10, :cond_7d

    const/16 v6, 0x2d

    invoke-virtual {v10}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v10

    if-eqz v10, :cond_60

    const/16 v6, 0x7c

    invoke-static {v10}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v10

    if-eqz v10, :cond_a4

    :cond_60
    const/16 v6, 0x4c4

    iget-object v9, v8, Lkc0;->E:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz v9, :cond_75

    const/16 v6, 0x4c

    move/from16 v0, v17

    invoke-virtual {v8, v0}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v8

    const/16 v6, 0x6e

    invoke-virtual {v9, v8}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    return-void

    :cond_75
    const-string/jumbo v8, "sshport_l"

    const/4 v6, 0x5

    invoke-static {v8}, Lgt0;->F0(Ljava/lang/String;)V

    throw v18

    :cond_7d
    const/4 v6, 0x5

    invoke-static {v14}, Lgt0;->F0(Ljava/lang/String;)V

    throw v18

    :cond_82
    :goto_82
    const/16 v6, 0x3e5

    iget-object v9, v8, Lkc0;->C:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz v9, :cond_97

    const/16 v6, 0x4c

    move/from16 v0, v17

    invoke-virtual {v8, v0}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v8

    const/16 v6, 0x6e

    invoke-virtual {v9, v8}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    return-void

    :cond_97
    const-string/jumbo v8, "sshhost_l"

    const/4 v6, 0x5

    invoke-static {v8}, Lgt0;->F0(Ljava/lang/String;)V

    throw v18

    :cond_9f
    const/4 v6, 0x5

    invoke-static {v15}, Lgt0;->F0(Ljava/lang/String;)V

    throw v18

    :cond_a4
    const/16 v6, 0x90

    iget-object v10, v8, Lkc0;->z:Landroid/widget/CheckBox;

    nop

    if-eqz v10, :cond_13a

    const/16 v6, 0x36

    invoke-virtual {v10}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v10

    if-eqz v10, :cond_148

    const/16 v6, 0xa1

    iget-object v10, v8, Lkc0;->F:Landroid/widget/CheckBox;

    nop

    if-eqz v10, :cond_135

    const/16 v6, 0x36

    invoke-virtual {v10}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v10

    if-eqz v10, :cond_148

    const/16 v6, 0x11e

    iget-object v10, v8, Lkc0;->H:Landroid/widget/EditText;

    nop

    if-eqz v10, :cond_130

    const/16 v6, 0x2d

    invoke-virtual {v10}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v10

    if-eqz v10, :cond_113

    const/16 v6, 0x7c

    invoke-static {v10}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v10

    if-eqz v10, :cond_da

    goto :goto_113

    :cond_da
    const/16 v6, 0x230

    iget-object v10, v8, Lkc0;->J:Landroid/widget/EditText;

    nop

    if-eqz v10, :cond_10e

    const/16 v6, 0x2d

    invoke-virtual {v10}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v10

    if-eqz v10, :cond_f1

    const/16 v6, 0x7c

    invoke-static {v10}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v10

    if-eqz v10, :cond_148

    :cond_f1
    const/16 v6, 0x39a

    iget-object v9, v8, Lkc0;->K:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz v9, :cond_106

    const/16 v6, 0x4c

    move/from16 v0, v17

    invoke-virtual {v8, v0}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v8

    const/16 v6, 0x6e

    invoke-virtual {v9, v8}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    return-void

    :cond_106
    const-string/jumbo v8, "sshpass_l"

    const/4 v6, 0x5

    invoke-static {v8}, Lgt0;->F0(Ljava/lang/String;)V

    throw v18

    :cond_10e
    const/4 v6, 0x5

    invoke-static {v11}, Lgt0;->F0(Ljava/lang/String;)V

    throw v18

    :cond_113
    :goto_113
    const/16 v6, 0x2d8

    iget-object v9, v8, Lkc0;->I:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz v9, :cond_128

    const/16 v6, 0x4c

    move/from16 v0, v17

    invoke-virtual {v8, v0}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v8

    const/16 v6, 0x6e

    invoke-virtual {v9, v8}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    return-void

    :cond_128
    const-string/jumbo v8, "sshuser_l"

    const/4 v6, 0x5

    invoke-static {v8}, Lgt0;->F0(Ljava/lang/String;)V

    throw v18

    :cond_130
    const/4 v6, 0x5

    invoke-static {v12}, Lgt0;->F0(Ljava/lang/String;)V

    throw v18

    :cond_135
    const/4 v6, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    throw v18

    :cond_13a
    const/4 v6, 0x5

    move-object/from16 v0, v16

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v18

    :cond_141
    const/4 v6, 0x5

    move-object/from16 v0, v16

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v18

    :cond_148
    const/16 v6, 0xc1

    iget-object v10, v8, Lkc0;->t:Landroid/widget/EditText;

    nop

    const-string/jumbo v19, "cfgname"

    if-eqz v10, :cond_e3b

    const/16 v6, 0x2d

    invoke-virtual {v10}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v10

    const/4 v6, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xff

    invoke-interface {v10}, Ljava/lang/CharSequence;->length()I

    move-result v10

    const-string/jumbo v20, "cfgname_l"

    if-nez v10, :cond_196

    const/16 v6, 0x124

    iget-object v9, v8, Lkc0;->u:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz v9, :cond_18f

    const/16 v6, 0x4c

    move/from16 v0, v17

    invoke-virtual {v8, v0}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v10

    const/16 v6, 0x6e

    invoke-virtual {v9, v10}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    const/16 v6, 0xc1

    iget-object v8, v8, Lkc0;->t:Landroid/widget/EditText;

    nop

    if-eqz v8, :cond_188

    const/16 v6, 0xc4

    invoke-virtual {v8}, Landroid/view/View;->requestFocus()Z

    return-void

    :cond_188
    const/4 v6, 0x5

    move-object/from16 v0, v19

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v18

    :cond_18f
    const/4 v6, 0x5

    move-object/from16 v0, v20

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v18

    :cond_196
    const/16 v6, 0xc1

    iget-object v10, v8, Lkc0;->t:Landroid/widget/EditText;

    nop

    if-eqz v10, :cond_e32

    const/16 v6, 0x2d

    invoke-virtual {v10}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v17

    const/16 v6, 0xcb

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v17

    const-string/jumbo v21, "/"

    const-string/jumbo v22, ""

    const/16 v23, 0x0

    const/16 v6, 0x1a

    move-object/from16 v0, v17

    move-object/from16 v1, v21

    move-object/from16 v2, v22

    move/from16 v3, v23

    invoke-static {v0, v1, v2, v3}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v17

    const/16 v6, 0x8a

    move-object/from16 v0, v17

    invoke-virtual {v10, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v6, 0x1fc

    sget v10, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const-string/jumbo v17, ".tls"

    move-object/from16 v24, v18

    const/16 v18, 0x1e

    const-string/jumbo v25, "cfgfile"

    move/from16 v0, v18

    if-ge v10, v0, :cond_416

    const/16 v6, 0x24e

    new-instance v18, Ljava/io/File;

    nop

    const/4 v6, -0x3

    new-instance v23, Ljava/lang/StringBuilder;

    nop

    const/4 v6, -0x4

    move-object/from16 v0, v23

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v6, 0x2ea

    move-object/from16 v0, v22

    invoke-static {v0}, Landroid/os/Environment;->getExternalStoragePublicDirectory(Ljava/lang/String;)Ljava/io/File;

    move-result-object v27

    const/4 v6, -0x6

    move-object/from16 v0, v27

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x125

    move-object/from16 v0, v27

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v21

    const/4 v6, 0x0

    move-object/from16 v0, v23

    move-object/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v21, "/TLS Tunnel/"

    const/4 v6, 0x0

    move-object/from16 v0, v23

    move-object/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, -0x2

    move-object/from16 v0, v23

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v21

    const/16 v6, 0x212

    move-object/from16 v0, v18

    move-object/from16 v1, v21

    invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/16 v6, 0xca

    move-object/from16 v0, v18

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v21

    if-nez v21, :cond_234

    const/16 v6, 0x521

    move-object/from16 v0, v18

    invoke-virtual {v0}, Ljava/io/File;->mkdir()Z

    :cond_234
    const/16 v6, 0x24e

    new-instance v21, Ljava/io/File;

    nop

    const/4 v6, -0x3

    new-instance v23, Ljava/lang/StringBuilder;

    nop

    const/4 v6, -0x4

    move-object/from16 v0, v23

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v6, 0x125

    move-object/from16 v0, v18

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v18

    const/4 v6, 0x0

    move-object/from16 v0, v23

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v18, 0x2f

    const/16 v6, 0x1b

    move-object/from16 v0, v23

    move/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v6, 0xc1

    iget-object v6, v8, Lkc0;->t:Landroid/widget/EditText;

    move-object/16 v18, v6

    if-eqz v18, :cond_40f

    const/16 v6, 0x2d

    move-object/from16 v0, v18

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v18

    const/16 v6, 0x190

    move-object/from16 v0, v23

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    move-object/from16 v0, v23

    move-object/from16 v1, v17

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, -0x2

    move-object/from16 v0, v23

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v18

    const/16 v6, 0x212

    move-object/from16 v0, v21

    move-object/from16 v1, v18

    invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/16 v6, 0x3a8

    move-object/from16 v0, v21

    iput-object v0, v8, Lkc0;->T:Ljava/io/File;

    const/16 v6, 0xca

    move-object/from16 v0, v21

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v18

    if-eqz v18, :cond_366

    if-nez p2, :cond_366

    const/16 v6, 0xbb1

    new-instance v10, Lg8;

    nop

    const/16 v6, 0x2b

    invoke-virtual {v8}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v11

    const/16 v6, 0x100b

    invoke-direct {v10, v11}, Lg8;-><init>(Landroid/content/Context;)V

    const/16 v6, 0x11e6

    iget-object v11, v10, Lg8;->c:Ljava/lang/Object;

    nop

    check-cast v11, Lc8;

    const/16 v6, 0x505

    iget-object v12, v11, Lc8;->a:Landroid/view/ContextThemeWrapper;

    nop

    const v13, 0x7f13002e

    const/16 v6, 0x492

    invoke-virtual {v12, v13}, Landroid/content/Context;->getText(I)Ljava/lang/CharSequence;

    move-result-object v12

    const/16 v6, 0x7c3

    iput-object v12, v11, Lc8;->f:Ljava/lang/CharSequence;

    const/16 v6, 0xe54

    new-instance v12, Lhc0;

    nop

    const/16 v6, 0x643

    invoke-direct {v12, v8, v9}, Lhc0;-><init>(Lkc0;Z)V

    const v9, 0x7f130247

    const/16 v6, 0xf53

    invoke-virtual {v10, v9, v12}, Lg8;->j(ILandroid/content/DialogInterface$OnClickListener;)V

    const/16 v6, 0x120f

    new-instance v9, Lic0;

    nop

    const/4 v12, 0x0

    const/16 v6, 0x1192

    invoke-direct {v9, v12}, Lic0;-><init>(I)V

    const v12, 0x7f130064

    const/16 v6, 0x505

    iget-object v14, v11, Lc8;->a:Landroid/view/ContextThemeWrapper;

    nop

    const/16 v6, 0x492

    invoke-virtual {v14, v12}, Landroid/content/Context;->getText(I)Ljava/lang/CharSequence;

    move-result-object v12

    const/16 v6, 0xe5d

    iput-object v12, v11, Lc8;->i:Ljava/lang/CharSequence;

    const/16 v6, 0xe2e

    iput-object v9, v11, Lc8;->j:Landroid/content/DialogInterface$OnClickListener;

    const/16 v6, 0x670

    invoke-virtual {v10}, Lg8;->b()Lh8;

    move-result-object v9

    const/16 v6, 0x9a5

    invoke-virtual {v9}, Landroid/app/Dialog;->show()V

    const/16 v6, 0x124

    iget-object v9, v8, Lkc0;->u:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz v9, :cond_35f

    const/4 v6, -0x3

    new-instance v10, Ljava/lang/StringBuilder;

    nop

    const/4 v6, -0x4

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v6, 0x4c

    invoke-virtual {v8, v13}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v11

    const/4 v6, 0x0

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v11, 0xa

    const/16 v6, 0x1b

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v6, 0x3d

    iget-object v11, v8, Lkc0;->T:Ljava/io/File;

    nop

    if-eqz v11, :cond_358

    const/16 v6, 0x25d

    invoke-virtual {v11}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v11

    const/4 v6, 0x0

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, -0x2

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    const/16 v6, 0x6e

    invoke-virtual {v9, v10}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    const/16 v6, 0xc1

    iget-object v8, v8, Lkc0;->t:Landroid/widget/EditText;

    nop

    if-eqz v8, :cond_351

    const/16 v6, 0xc4

    invoke-virtual {v8}, Landroid/view/View;->requestFocus()Z

    return-void

    :cond_351
    const/4 v6, 0x5

    move-object/from16 v0, v19

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_358
    const/4 v6, 0x5

    move-object/from16 v0, v25

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_35f
    const/4 v6, 0x5

    move-object/from16 v0, v20

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_366
    const/16 v6, 0x3d

    iget-object v6, v8, Lkc0;->T:Ljava/io/File;

    move-object/16 v18, v6

    if-eqz v18, :cond_408

    const/16 v6, 0xca

    move-object/from16 v0, v18

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v18

    if-eqz v18, :cond_393

    if-eqz p2, :cond_393

    const/16 v6, 0x3d

    iget-object v6, v8, Lkc0;->T:Ljava/io/File;

    move-object/16 v18, v6

    if-eqz v18, :cond_38c

    const/16 v6, 0x460

    move-object/from16 v0, v18

    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    goto :goto_393

    :cond_38c
    const/4 v6, 0x5

    move-object/from16 v0, v25

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_393
    :goto_393
    const v18, 0x7f1300ce

    :try_start_396
    const/16 v6, 0x3d

    iget-object v6, v8, Lkc0;->T:Ljava/io/File;

    move-object/16 v19, v6

    if-eqz v19, :cond_3e5

    const/16 v6, 0x288

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/io/File;->createNewFile()Z

    move-result v19

    if-nez v19, :cond_3c5

    const/16 v6, 0x124

    iget-object v9, v8, Lkc0;->u:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz v9, :cond_3be

    const/16 v6, 0x4c

    move/from16 v0, v18

    invoke-virtual {v8, v0}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v10

    const/16 v6, 0x6e

    invoke-virtual {v9, v10}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    return-void

    :cond_3be
    const/4 v6, 0x5

    move-object/from16 v0, v20

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24
    :try_end_3c5
    .catch Ljava/lang/Exception; {:try_start_396 .. :try_end_3c5} :catch_3ec

    :cond_3c5
    const/16 v6, 0x3d

    iget-object v6, v8, Lkc0;->T:Ljava/io/File;

    move-object/16 v18, v6

    if-eqz v18, :cond_3de

    const/16 v6, 0xa2e

    move-object/from16 v0, v18

    invoke-static {v0}, Landroid/net/Uri;->fromFile(Ljava/io/File;)Landroid/net/Uri;

    move-result-object v18

    const/16 v6, 0xd8a

    move-object/from16 v0, v18

    iput-object v0, v8, Lkc0;->U:Landroid/net/Uri;

    goto/16 :goto_483

    :cond_3de
    const/4 v6, 0x5

    move-object/from16 v0, v25

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_3e5
    :try_start_3e5
    const/4 v6, 0x5

    move-object/from16 v0, v25

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24
    :try_end_3ec
    .catch Ljava/lang/Exception; {:try_start_3e5 .. :try_end_3ec} :catch_3ec

    :catch_3ec
    const/16 v6, 0x124

    iget-object v9, v8, Lkc0;->u:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz v9, :cond_401

    const/16 v6, 0x4c

    move/from16 v0, v18

    invoke-virtual {v8, v0}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v8

    const/16 v6, 0x6e

    invoke-virtual {v9, v8}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    return-void

    :cond_401
    const/4 v6, 0x5

    move-object/from16 v0, v20

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_408
    const/4 v6, 0x5

    move-object/from16 v0, v25

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_40f
    const/4 v6, 0x5

    move-object/from16 v0, v19

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_416
    const/16 v6, 0x188

    iget-object v6, v8, Lkc0;->V:Ljava/io/OutputStream;

    move-object/16 v18, v6

    if-nez v18, :cond_483

    const/16 v6, 0xe2d

    iput-boolean v9, v8, Lkc0;->S:Z

    const/16 v6, 0x5b

    new-instance v9, Landroid/content/Intent;

    nop

    const-string/jumbo v10, "android.intent.action.CREATE_DOCUMENT"

    const/16 v6, 0x62

    invoke-direct {v9, v10}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string/jumbo v10, "android.intent.category.OPENABLE"

    const/16 v6, 0xcce

    invoke-virtual {v9, v10}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    const-string/jumbo v10, "application/octet-stream"

    const/16 v6, 0x3dd

    invoke-virtual {v9, v10}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v6, -0x3

    new-instance v10, Ljava/lang/StringBuilder;

    nop

    const/4 v6, -0x4

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v6, 0xc1

    iget-object v11, v8, Lkc0;->t:Landroid/widget/EditText;

    nop

    if-eqz v11, :cond_47a

    const/16 v6, 0x2d

    invoke-virtual {v11}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v11

    const/16 v6, 0x190

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    move-object/from16 v0, v17

    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, -0x2

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    const-string/jumbo v11, "android.intent.extra.TITLE"

    const/16 v6, 0x4b

    invoke-virtual {v9, v11, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/16 v6, 0xeed

    iget-object v8, v8, Lkc0;->X:Lm3;

    nop

    move-object/from16 v10, v24

    const/16 v6, 0xad

    invoke-virtual {v8, v9, v10}, Lm3;->a(Ljava/lang/Object;Lf3;)V

    return-void

    :cond_47a
    move-object/from16 v10, v24

    const/4 v6, 0x5

    move-object/from16 v0, v19

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_483
    :goto_483
    const/16 v6, 0xf5a

    invoke-virtual {v8}, Lkc0;->e()V

    const/16 v6, 0x291

    iget-boolean v6, v8, Lkc0;->W:Z

    move/16 v18, v6

    const/16 v20, 0x1

    if-nez v18, :cond_b99

    const/16 v6, 0x8ea

    new-instance v18, Lou;

    nop

    const/16 v6, 0x30

    invoke-virtual {v8}, Lkc0;->d()Landroid/content/SharedPreferences;

    move-result-object v21

    const/4 v6, -0x6

    move-object/from16 v0, v21

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x1c6

    invoke-virtual {v8}, Landroidx/fragment/app/Fragment;->getResources()Landroid/content/res/Resources;

    move-result-object v23

    const/4 v6, -0x6

    move-object/from16 v0, v23

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v19, 0x0

    const/16 v6, 0x83d

    move v0, v6

    move-object/from16 v1, v18

    move-object/from16 v2, v21

    move-object/from16 v3, v23

    move/from16 v4, v19

    move/from16 v5, v19

    invoke-direct/range {v1 .. v5}, Lou;-><init>(Landroid/content/SharedPreferences;Landroid/content/res/Resources;ZZ)V

    const/16 v6, 0x90

    iget-object v6, v8, Lkc0;->z:Landroid/widget/CheckBox;

    move-object/16 v19, v6

    if-eqz v19, :cond_b90

    const/16 v6, 0x36

    move-object/from16 v0, v19

    invoke-virtual {v0}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v19

    if-eqz v19, :cond_58f

    const/16 v6, 0x130

    iget-object v6, v8, Lkc0;->B:Landroid/widget/EditText;

    move-object/16 v19, v6

    if-eqz v19, :cond_588

    const/16 v6, 0x2d

    move-object/from16 v0, v19

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v19

    const/4 v6, -0x6

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xff

    move-object/from16 v0, v19

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v19

    if-lez v19, :cond_57e

    const/16 v6, 0x24f

    iget-object v6, v8, Lkc0;->D:Landroid/widget/EditText;

    move-object/16 v19, v6

    if-eqz v19, :cond_581

    const/16 v6, 0x2d

    move-object/from16 v0, v19

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v19

    const/4 v6, -0x6

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xff

    move-object/from16 v0, v19

    invoke-interface {v0}, Ljava/lang/CharSequence;->length()I

    move-result v19

    if-lez v19, :cond_57e

    const/16 v6, 0x3c8

    move-object/from16 v0, v18

    move/from16 v1, v20

    iput-boolean v1, v0, Lou;->h:Z

    const/16 v6, 0x130

    iget-object v6, v8, Lkc0;->B:Landroid/widget/EditText;

    move-object/16 v19, v6

    if-eqz v19, :cond_577

    const/16 v6, 0x2d

    move-object/from16 v0, v19

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v15

    const/16 v6, 0xcb

    invoke-virtual {v15}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v15

    const/4 v6, -0x6

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x244

    move-object/from16 v0, v18

    iput-object v15, v0, Lou;->i:Ljava/lang/String;

    const/4 v6, -0x3

    new-instance v15, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v19, "T "

    const/16 v6, 0x97

    move-object/from16 v0, v19

    invoke-direct {v15, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v6, 0x24f

    iget-object v6, v8, Lkc0;->D:Landroid/widget/EditText;

    move-object/16 v19, v6

    if-eqz v19, :cond_570

    const/16 v6, 0x2d

    move-object/from16 v0, v19

    invoke-virtual {v0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v14

    const/16 v6, 0x190

    invoke-virtual {v15, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, -0x2

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v14

    const/16 v6, 0xdb

    move-object/from16 v0, v18

    iput-object v14, v0, Lou;->g:Ljava/lang/String;

    goto :goto_59f

    :cond_570
    const/4 v6, 0x5

    invoke-static {v14}, Lgt0;->F0(Ljava/lang/String;)V

    const/16 v24, 0x0

    throw v24

    :cond_577
    const/16 v24, 0x0

    const/4 v6, 0x5

    invoke-static {v15}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_57e
    const/16 v24, 0x0

    goto :goto_58f

    :cond_581
    const/16 v24, 0x0

    const/4 v6, 0x5

    invoke-static {v14}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_588
    const/16 v24, 0x0

    const/4 v6, 0x5

    invoke-static {v15}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_58f
    :goto_58f
    const/16 v6, 0x244

    move-object/from16 v0, v18

    move-object/from16 v1, v22

    iput-object v1, v0, Lou;->i:Ljava/lang/String;

    const/16 v6, 0xdb

    move-object/from16 v0, v18

    move-object/from16 v1, v22

    iput-object v1, v0, Lou;->g:Ljava/lang/String;

    :goto_59f
    const/16 v6, 0x90

    iget-object v14, v8, Lkc0;->z:Landroid/widget/CheckBox;

    nop

    if-eqz v14, :cond_b87

    const/16 v6, 0x36

    invoke-virtual {v14}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v14

    if-eqz v14, :cond_650

    const/16 v6, 0xa1

    iget-object v14, v8, Lkc0;->F:Landroid/widget/CheckBox;

    nop

    if-eqz v14, :cond_649

    const/16 v6, 0x36

    invoke-virtual {v14}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v14

    if-eqz v14, :cond_638

    const/16 v6, 0x11e

    iget-object v14, v8, Lkc0;->H:Landroid/widget/EditText;

    nop

    if-eqz v14, :cond_642

    const/16 v6, 0x2d

    invoke-virtual {v14}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v14

    const/4 v6, -0x6

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xff

    invoke-interface {v14}, Ljava/lang/CharSequence;->length()I

    move-result v14

    if-lez v14, :cond_638

    const/16 v6, 0x230

    iget-object v14, v8, Lkc0;->J:Landroid/widget/EditText;

    nop

    if-eqz v14, :cond_63b

    const/16 v6, 0x2d

    invoke-virtual {v14}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v14

    const/4 v6, -0x6

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xff

    invoke-interface {v14}, Ljava/lang/CharSequence;->length()I

    move-result v14

    if-lez v14, :cond_638

    const/16 v6, 0x11e

    iget-object v13, v8, Lkc0;->H:Landroid/widget/EditText;

    nop

    if-eqz v13, :cond_631

    const/16 v6, 0x2d

    invoke-virtual {v13}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v12

    const/16 v6, 0xcb

    invoke-virtual {v12}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v12

    const/4 v6, -0x6

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x261

    move-object/from16 v0, v18

    iput-object v12, v0, Lou;->k:Ljava/lang/String;

    const/16 v6, 0x230

    iget-object v12, v8, Lkc0;->J:Landroid/widget/EditText;

    nop

    if-eqz v12, :cond_62a

    const/16 v6, 0x2d

    invoke-virtual {v12}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v11

    const/16 v6, 0xcb

    invoke-virtual {v11}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v11

    const/4 v6, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x266

    move-object/from16 v0, v18

    iput-object v11, v0, Lou;->l:Ljava/lang/String;

    goto :goto_66f

    :cond_62a
    const/4 v6, 0x5

    invoke-static {v11}, Lgt0;->F0(Ljava/lang/String;)V

    const/16 v24, 0x0

    throw v24

    :cond_631
    const/16 v24, 0x0

    const/4 v6, 0x5

    invoke-static {v12}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_638
    const/16 v24, 0x0

    goto :goto_650

    :cond_63b
    const/16 v24, 0x0

    const/4 v6, 0x5

    invoke-static {v11}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_642
    const/16 v24, 0x0

    const/4 v6, 0x5

    invoke-static {v12}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_649
    const/16 v24, 0x0

    const/4 v6, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_650
    :goto_650
    const/16 v6, 0xa1

    iget-object v11, v8, Lkc0;->F:Landroid/widget/CheckBox;

    nop

    if-eqz v11, :cond_b80

    const/16 v6, 0x36

    invoke-virtual {v11}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v11

    if-nez v11, :cond_66f

    const/16 v6, 0x261

    move-object/from16 v0, v18

    move-object/from16 v1, v22

    iput-object v1, v0, Lou;->k:Ljava/lang/String;

    const/16 v6, 0x266

    move-object/from16 v0, v18

    move-object/from16 v1, v22

    iput-object v1, v0, Lou;->l:Ljava/lang/String;

    :cond_66f
    :goto_66f
    const/16 v6, 0xf4

    iget-object v11, v8, Lkc0;->y:Landroid/widget/CheckBox;

    nop

    const-string/jumbo v12, "bloqmc"

    if-eqz v11, :cond_b79

    const/16 v6, 0x36

    invoke-virtual {v11}, Landroid/widget/CompoundButton;->isChecked()Z

    const/4 v11, 0x0

    const/16 v6, 0x7c4

    move-object/from16 v0, v18

    iput-boolean v11, v0, Lou;->w:Z

    const/16 v6, 0xf4

    iget-object v11, v8, Lkc0;->y:Landroid/widget/CheckBox;

    nop

    if-eqz v11, :cond_b72

    const/16 v6, 0x36

    invoke-virtual {v11}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v11

    if-eqz v11, :cond_6b0

    const/16 v6, 0x23f

    iget-object v11, v8, Lkc0;->M:Landroid/widget/CheckBox;

    nop

    if-eqz v11, :cond_6a6

    const/16 v6, 0x36

    invoke-virtual {v11}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v11

    if-eqz v11, :cond_6b0

    move/from16 v11, v20

    goto :goto_6b1

    :cond_6a6
    const-string/jumbo v8, "blockTorrent"

    const/4 v6, 0x5

    invoke-static {v8}, Lgt0;->F0(Ljava/lang/String;)V

    const/16 v24, 0x0

    throw v24

    :cond_6b0
    const/4 v11, 0x0

    :goto_6b1
    const/16 v6, 0xa25

    move-object/from16 v0, v18

    iput-boolean v11, v0, Lou;->x:Z

    const/16 v6, 0xf4

    iget-object v11, v8, Lkc0;->y:Landroid/widget/CheckBox;

    nop

    if-eqz v11, :cond_b6b

    const/16 v6, 0x36

    invoke-virtual {v11}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v11

    if-eqz v11, :cond_6e2

    const/16 v6, 0x1b5

    iget-object v11, v8, Lkc0;->N:Landroid/widget/CheckBox;

    nop

    if-eqz v11, :cond_6d8

    const/16 v6, 0x36

    invoke-virtual {v11}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v11

    if-eqz v11, :cond_6e2

    move/from16 v11, v20

    goto :goto_6e3

    :cond_6d8
    const-string/jumbo v8, "blockRootDev"

    const/4 v6, 0x5

    invoke-static {v8}, Lgt0;->F0(Ljava/lang/String;)V

    const/16 v24, 0x0

    throw v24

    :cond_6e2
    const/4 v11, 0x0

    :goto_6e3
    const/16 v6, 0xba7

    move-object/from16 v0, v18

    iput-boolean v11, v0, Lou;->y:Z

    const/16 v6, 0x75

    move-object/from16 v0, v18

    iget-boolean v11, v0, Lou;->w:Z

    nop

    if-eqz v11, :cond_732

    const/16 v6, 0xe6

    iget-object v11, v8, Lkc0;->L:Landroid/widget/CheckBox;

    nop

    if-eqz v11, :cond_728

    const/16 v6, 0x36

    invoke-virtual {v11}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v11

    if-eqz v11, :cond_725

    const/16 v6, 0x4c7

    iget-object v11, v8, Lkc0;->w:Lcom/google/android/material/textfield/TextInputEditText;

    nop

    if-eqz v11, :cond_71b

    const/16 v6, 0x20b

    invoke-virtual {v11}, Lyb;->getText()Landroid/text/Editable;

    move-result-object v11

    const/16 v6, 0x1a8

    invoke-static {v11}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v11

    const/16 v6, 0x962

    move-object/from16 v0, v18

    iput-object v11, v0, Lou;->B:Ljava/lang/String;

    goto :goto_732

    :cond_71b
    const-string/jumbo v8, "mensagem"

    const/4 v6, 0x5

    invoke-static {v8}, Lgt0;->F0(Ljava/lang/String;)V

    const/16 v24, 0x0

    throw v24

    :cond_725
    const/16 v24, 0x0

    goto :goto_732

    :cond_728
    const/16 v24, 0x0

    const-string/jumbo v8, "addmsg"

    const/4 v6, 0x5

    invoke-static {v8}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_732
    :goto_732
    new-instance v11, Ljava/lang/String;

    const/16 v6, 0x3eb

    new-instance v12, Ltd;

    nop

    const/16 v13, 0xc

    const/16 v6, 0x484

    invoke-direct {v12, v13}, Ltd;-><init>(I)V

    const/4 v6, -0x3

    new-instance v13, Ljava/lang/StringBuilder;

    nop

    const/4 v6, -0x4

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v6, 0xaf1

    move-object/from16 v0, v18

    iget v14, v0, Lou;->b:I

    nop

    const/16 v6, 0x33

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 v14, 0x3a

    const/16 v6, 0x1b

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v6, 0x11f

    move-object/from16 v0, v18

    iget v15, v0, Lou;->d:I

    nop

    const/16 v6, 0x33

    invoke-virtual {v13, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 v6, 0x1b

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v6, 0x32

    move-object/from16 v0, v18

    iget v15, v0, Lou;->e:I

    nop

    const/16 v6, 0x33

    invoke-virtual {v13, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 v6, 0x1b

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v6, 0x9d

    move-object/from16 v0, v18

    iget-boolean v15, v0, Lou;->h:Z

    nop

    const/16 v6, 0x6a

    invoke-virtual {v13, v15}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/16 v6, 0x1b

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v6, 0x905

    sget-boolean v14, Lmi2;->a:Z

    nop

    const/16 v6, 0x2e2

    move-object/from16 v0, v18

    iget-object v14, v0, Lou;->k:Ljava/lang/String;

    nop

    const/16 v6, 0x2e4

    sget-object v15, Lip;->a:Ljava/nio/charset/Charset;

    nop

    const/16 v6, 0x2c

    invoke-virtual {v14, v15}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v14

    const/4 v6, -0x6

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v16, 0x2

    const/16 v6, 0x3e

    move/from16 v0, v16

    invoke-static {v14, v0}, Landroid/util/Base64;->encode([BI)[B

    move-result-object v14

    const/4 v6, -0x6

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v19, Ljava/lang/String;

    check-cast v15, Ljava/nio/charset/Charset;

    move-object/from16 v0, v19

    invoke-direct {v0, v14, v15}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const/4 v6, 0x0

    move-object/from16 v0, v19

    invoke-virtual {v13, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v14, 0x3a

    const/16 v6, 0x1b

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v6, 0xef9

    move-object/from16 v0, v18

    iget-object v6, v0, Lou;->l:Ljava/lang/String;

    move-object/16 v19, v6

    const/16 v6, 0x2c

    move-object/from16 v0, v19

    invoke-virtual {v0, v15}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v19

    const/4 v6, -0x6

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x3e

    move-object/from16 v0, v19

    move/from16 v1, v16

    invoke-static {v0, v1}, Landroid/util/Base64;->encode([BI)[B

    move-result-object v19

    const/4 v6, -0x6

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v21, Ljava/lang/String;

    check-cast v15, Ljava/nio/charset/Charset;

    move-object/from16 v0, v21

    move-object/from16 v1, v19

    invoke-direct {v0, v1, v15}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const/4 v6, 0x0

    move-object/from16 v0, v21

    invoke-virtual {v13, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v6, 0x1b

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v6, 0x3b

    move-object/from16 v0, v18

    iget-object v6, v0, Lou;->i:Ljava/lang/String;

    move-object/16 v19, v6

    const/16 v6, 0x2c

    move-object/from16 v0, v19

    invoke-virtual {v0, v15}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v19

    const/4 v6, -0x6

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x3e

    move-object/from16 v0, v19

    move/from16 v1, v16

    invoke-static {v0, v1}, Landroid/util/Base64;->encode([BI)[B

    move-result-object v19

    const/4 v6, -0x6

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v21, Ljava/lang/String;

    check-cast v15, Ljava/nio/charset/Charset;

    move-object/from16 v0, v21

    move-object/from16 v1, v19

    invoke-direct {v0, v1, v15}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const/4 v6, 0x0

    move-object/from16 v0, v21

    invoke-virtual {v13, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v6, 0x1b

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v6, 0x34a

    move-object/from16 v0, v18

    iget-object v6, v0, Lou;->g:Ljava/lang/String;

    move-object/16 v19, v6

    const/16 v6, 0x2c

    move-object/from16 v0, v19

    invoke-virtual {v0, v15}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v19

    const/4 v6, -0x6

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x3e

    move-object/from16 v0, v19

    move/from16 v1, v16

    invoke-static {v0, v1}, Landroid/util/Base64;->encode([BI)[B

    move-result-object v19

    const/4 v6, -0x6

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v21, Ljava/lang/String;

    check-cast v15, Ljava/nio/charset/Charset;

    move-object/from16 v0, v21

    move-object/from16 v1, v19

    invoke-direct {v0, v1, v15}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const/4 v6, 0x0

    move-object/from16 v0, v21

    invoke-virtual {v13, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v6, 0x1b

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v6, 0xe1

    move-object/from16 v0, v18

    iget-object v6, v0, Lou;->f:Ljava/lang/String;

    move-object/16 v19, v6

    const/16 v6, 0x2c

    move-object/from16 v0, v19

    invoke-virtual {v0, v15}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v19

    const/4 v6, -0x6

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x3e

    move-object/from16 v0, v19

    move/from16 v1, v16

    invoke-static {v0, v1}, Landroid/util/Base64;->encode([BI)[B

    move-result-object v19

    const/4 v6, -0x6

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v21, Ljava/lang/String;

    check-cast v15, Ljava/nio/charset/Charset;

    move-object/from16 v0, v21

    move-object/from16 v1, v19

    invoke-direct {v0, v1, v15}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const/4 v6, 0x0

    move-object/from16 v0, v21

    invoke-virtual {v13, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v6, 0x1b

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v6, 0x34b

    move-object/from16 v0, v18

    iget-object v6, v0, Lou;->j:Ljava/lang/String;

    move-object/16 v19, v6

    const/16 v6, 0x2c

    move-object/from16 v0, v19

    invoke-virtual {v0, v15}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v19

    const/4 v6, -0x6

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x3e

    move-object/from16 v0, v19

    move/from16 v1, v16

    invoke-static {v0, v1}, Landroid/util/Base64;->encode([BI)[B

    move-result-object v19

    const/4 v6, -0x6

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v21, Ljava/lang/String;

    check-cast v15, Ljava/nio/charset/Charset;

    move-object/from16 v0, v21

    move-object/from16 v1, v19

    invoke-direct {v0, v1, v15}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const/4 v6, 0x0

    move-object/from16 v0, v21

    invoke-virtual {v13, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v6, 0x1b

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v6, 0x1b8

    move-object/from16 v0, v18

    iget v6, v0, Lou;->m:I

    move/16 v19, v6

    const/16 v6, 0x33

    move/from16 v0, v19

    invoke-virtual {v13, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 v6, 0x1b

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v6, 0x8eb

    move-object/from16 v0, v18

    iget-boolean v6, v0, Lou;->n:Z

    move/16 v19, v6

    const/16 v6, 0x6a

    move/from16 v0, v19

    invoke-virtual {v13, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/16 v6, 0x1b

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v6, 0x285

    move-object/from16 v0, v18

    iget-object v6, v0, Lou;->o:Ljava/lang/String;

    move-object/16 v19, v6

    const/16 v6, 0x2c

    move-object/from16 v0, v19

    invoke-virtual {v0, v15}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v19

    const/4 v6, -0x6

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x3e

    move-object/from16 v0, v19

    move/from16 v1, v16

    invoke-static {v0, v1}, Landroid/util/Base64;->encode([BI)[B

    move-result-object v19

    const/4 v6, -0x6

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v21, Ljava/lang/String;

    check-cast v15, Ljava/nio/charset/Charset;

    move-object/from16 v0, v21

    move-object/from16 v1, v19

    invoke-direct {v0, v1, v15}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const/4 v6, 0x0

    move-object/from16 v0, v21

    invoke-virtual {v13, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v6, 0x1b

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v6, 0x7f

    move-object/from16 v0, v18

    iget-boolean v6, v0, Lou;->p:Z

    move/16 v19, v6

    const/16 v6, 0x6a

    move/from16 v0, v19

    invoke-virtual {v13, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/16 v6, 0x1b

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v6, 0x26e

    move-object/from16 v0, v18

    iget-object v6, v0, Lou;->q:Ljava/lang/String;

    move-object/16 v19, v6

    const/16 v6, 0x2c

    move-object/from16 v0, v19

    invoke-virtual {v0, v15}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v19

    const/4 v6, -0x6

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x3e

    move-object/from16 v0, v19

    move/from16 v1, v16

    invoke-static {v0, v1}, Landroid/util/Base64;->encode([BI)[B

    move-result-object v19

    const/4 v6, -0x6

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v21, Ljava/lang/String;

    check-cast v15, Ljava/nio/charset/Charset;

    move-object/from16 v0, v21

    move-object/from16 v1, v19

    invoke-direct {v0, v1, v15}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const/4 v6, 0x0

    move-object/from16 v0, v21

    invoke-virtual {v13, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v6, 0x1b

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v6, 0xfdd

    move-object/from16 v0, v18

    iget-boolean v6, v0, Lou;->r:Z

    move/16 v19, v6

    const/16 v6, 0x6a

    move/from16 v0, v19

    invoke-virtual {v13, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/16 v6, 0x1b

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v6, 0x2e3

    move-object/from16 v0, v18

    iget-object v6, v0, Lou;->s:Ljava/lang/String;

    move-object/16 v19, v6

    const/16 v6, 0x2c

    move-object/from16 v0, v19

    invoke-virtual {v0, v15}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v19

    const/4 v6, -0x6

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x3e

    move-object/from16 v0, v19

    move/from16 v1, v16

    invoke-static {v0, v1}, Landroid/util/Base64;->encode([BI)[B

    move-result-object v19

    const/4 v6, -0x6

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v21, Ljava/lang/String;

    check-cast v15, Ljava/nio/charset/Charset;

    move-object/from16 v0, v21

    move-object/from16 v1, v19

    invoke-direct {v0, v1, v15}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const/4 v6, 0x0

    move-object/from16 v0, v21

    invoke-virtual {v13, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v6, 0x1b

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v6, 0x3f5

    move-object/from16 v0, v18

    iget-boolean v6, v0, Lou;->t:Z

    move/16 v19, v6

    const/16 v6, 0x6a

    move/from16 v0, v19

    invoke-virtual {v13, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/16 v6, 0x1b

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v6, 0x1e1

    move-object/from16 v0, v18

    iget-object v6, v0, Lou;->u:Ljava/lang/String;

    move-object/16 v19, v6

    const/16 v6, 0x2c

    move-object/from16 v0, v19

    invoke-virtual {v0, v15}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v19

    const/4 v6, -0x6

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x3e

    move-object/from16 v0, v19

    move/from16 v1, v16

    invoke-static {v0, v1}, Landroid/util/Base64;->encode([BI)[B

    move-result-object v19

    const/4 v6, -0x6

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v21, Ljava/lang/String;

    check-cast v15, Ljava/nio/charset/Charset;

    move-object/from16 v0, v21

    move-object/from16 v1, v19

    invoke-direct {v0, v1, v15}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const/4 v6, 0x0

    move-object/from16 v0, v21

    invoke-virtual {v13, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v6, 0x1b

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v6, 0x1f4

    move-object/from16 v0, v18

    iget-object v14, v0, Lou;->v:Ljava/lang/String;

    nop

    const/16 v6, 0x2c

    invoke-virtual {v14, v15}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v14

    const/4 v6, -0x6

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x3e

    move/from16 v0, v16

    invoke-static {v14, v0}, Landroid/util/Base64;->encode([BI)[B

    move-result-object v14

    const/4 v6, -0x6

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v19, Ljava/lang/String;

    check-cast v15, Ljava/nio/charset/Charset;

    move-object/from16 v0, v19

    invoke-direct {v0, v14, v15}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const/4 v6, 0x0

    move-object/from16 v0, v19

    invoke-virtual {v13, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v14, "::::::"

    const/4 v6, 0x0

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v6, 0x75

    move-object/from16 v0, v18

    iget-boolean v14, v0, Lou;->w:Z

    nop

    const/16 v6, 0x6a

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/16 v14, 0x3a

    const/16 v6, 0x1b

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v6, 0x1b9

    move-object/from16 v0, v18

    iget-boolean v6, v0, Lou;->x:Z

    move/16 v19, v6

    const/16 v6, 0x6a

    move/from16 v0, v19

    invoke-virtual {v13, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/16 v6, 0x1b

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v6, 0x4d6

    move-object/from16 v0, v18

    iget-object v14, v0, Lou;->B:Ljava/lang/String;

    nop

    const-string/jumbo v19, "\\n"

    const-string/jumbo v21, "\n"

    const/16 v23, 0x0

    const/16 v6, 0x1a

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    move/from16 v2, v23

    invoke-static {v14, v0, v1, v2}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v14

    const-string/jumbo v19, "\\r"

    const-string/jumbo v21, "\r"

    const/16 v6, 0x1a

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    move/from16 v2, v23

    invoke-static {v14, v0, v1, v2}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v14

    const/16 v6, 0x2c

    invoke-virtual {v14, v15}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v14

    const/4 v6, -0x6

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x3e

    move/from16 v0, v16

    invoke-static {v14, v0}, Landroid/util/Base64;->encode([BI)[B

    move-result-object v14

    const/4 v6, -0x6

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v16, Ljava/lang/String;

    check-cast v15, Ljava/nio/charset/Charset;

    move-object/from16 v0, v16

    invoke-direct {v0, v14, v15}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const/4 v6, 0x0

    move-object/from16 v0, v16

    invoke-virtual {v13, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v14, 0x3a

    const/16 v6, 0x1b

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v6, 0x7ec

    move-object/from16 v0, v18

    iget-boolean v14, v0, Lou;->y:Z

    nop

    const/16 v6, 0x6a

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string/jumbo v14, ":::::::::::::::::::::::::::::"

    const/4 v6, 0x0

    invoke-virtual {v13, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, -0x2

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v13

    const-string/jumbo v14, "="

    const/16 v23, 0x0

    const/16 v6, 0x1a

    move-object/from16 v0, v22

    move/from16 v1, v23

    invoke-static {v13, v14, v0, v1}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v13

    const/16 v6, 0x2c

    invoke-virtual {v13, v15}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v13

    const/4 v6, -0x6

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x56f

    invoke-virtual {v12, v13}, Ltd;->v([B)[B

    move-result-object v12

    const-string/jumbo v13, ":::::"

    const/16 v6, 0x2c

    invoke-virtual {v13, v15}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v13

    const/4 v6, -0x6

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xe5

    invoke-static {v12, v13}, Laf;->o0([B[B)[B

    move-result-object v12

    check-cast v15, Ljava/nio/charset/Charset;

    invoke-direct {v11, v12, v15}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const/16 v6, 0x2c

    invoke-virtual {v11, v15}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v11

    const/4 v6, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :goto_b68
    const/16 v12, 0x1e

    goto :goto_bbe

    :cond_b6b
    const/4 v6, 0x5

    invoke-static {v12}, Lgt0;->F0(Ljava/lang/String;)V

    const/16 v24, 0x0

    throw v24

    :cond_b72
    const/16 v24, 0x0

    const/4 v6, 0x5

    invoke-static {v12}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_b79
    const/16 v24, 0x0

    const/4 v6, 0x5

    invoke-static {v12}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_b80
    const/16 v24, 0x0

    const/4 v6, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_b87
    const/16 v24, 0x0

    const/4 v6, 0x5

    move-object/from16 v0, v16

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_b90
    const/16 v24, 0x0

    const/4 v6, 0x5

    move-object/from16 v0, v16

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_b99
    const/16 v6, 0x30

    invoke-virtual {v8}, Lkc0;->d()Landroid/content/SharedPreferences;

    move-result-object v11

    const-string/jumbo v12, "cryptoconfig"

    const/16 v6, 0x2e

    move-object/from16 v0, v22

    invoke-interface {v11, v12, v0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const/4 v6, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x2e4

    sget-object v12, Lip;->a:Ljava/nio/charset/Charset;

    nop

    const/16 v6, 0x2c

    invoke-virtual {v11, v12}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v11

    const/4 v6, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    goto :goto_b68

    :goto_bbe
    if-ge v10, v12, :cond_c06

    const/16 v6, 0x3d

    iget-object v12, v8, Lkc0;->T:Ljava/io/File;

    nop

    if-eqz v12, :cond_bfd

    const/16 v6, 0x448

    new-instance v13, Ljava/io/FileOutputStream;

    nop

    const/16 v6, 0x442

    move/from16 v0, v20

    invoke-direct {v13, v12, v0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;Z)V

    :try_start_bd3
    const/16 v6, 0x3e8

    invoke-virtual {v13, v11}, Ljava/io/FileOutputStream;->write([B)V
    :try_end_bd8
    .catchall {:try_start_bd3 .. :try_end_bd8} :catchall_bf3

    const/16 v6, 0x3c5

    invoke-virtual {v13}, Ljava/io/FileOutputStream;->close()V

    const/16 v6, 0x3d

    iget-object v12, v8, Lkc0;->T:Ljava/io/File;

    nop

    if-eqz v12, :cond_bea

    const/16 v6, 0x509

    invoke-virtual {v12}, Ljava/io/File;->setReadOnly()Z

    goto :goto_c32

    :cond_bea
    const/4 v6, 0x5

    move-object/from16 v0, v25

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    const/16 v24, 0x0

    throw v24

    :catchall_bf3
    move-exception v8

    move-object v9, v8

    :try_start_bf5
    throw v9
    :try_end_bf6
    .catchall {:try_start_bf5 .. :try_end_bf6} :catchall_bf6

    :catchall_bf6
    move-exception v8

    const/16 v6, 0x343

    invoke-static {v13, v9}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v8

    :cond_bfd
    const/16 v24, 0x0

    const/4 v6, 0x5

    move-object/from16 v0, v25

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_c06
    const/16 v6, 0x188

    iget-object v12, v8, Lkc0;->V:Ljava/io/OutputStream;

    nop

    const-string/jumbo v13, "cfgfileOS"

    if-eqz v12, :cond_e2b

    array-length v14, v11

    const/16 v23, 0x0

    const/16 v6, 0x672

    move/from16 v0, v23

    invoke-virtual {v12, v11, v0, v14}, Ljava/io/OutputStream;->write([BII)V

    const/16 v6, 0x188

    iget-object v12, v8, Lkc0;->V:Ljava/io/OutputStream;

    nop

    if-eqz v12, :cond_e24

    const/16 v6, 0xbd8

    invoke-virtual {v12}, Ljava/io/OutputStream;->flush()V

    const/16 v6, 0x188

    iget-object v12, v8, Lkc0;->V:Ljava/io/OutputStream;

    nop

    if-eqz v12, :cond_e1d

    const/16 v6, 0x148

    invoke-virtual {v12}, Ljava/io/OutputStream;->close()V

    :goto_c32
    const-string/jumbo v12, "cfgfileUri"

    if-eqz v9, :cond_dbb

    const/16 v9, 0x1e

    if-lt v10, v9, :cond_d63

    const/16 v6, 0x2b

    invoke-virtual {v8}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v9

    const/16 v6, 0xb64

    move-object/from16 v0, v22

    invoke-virtual {v9, v0}, Landroid/content/Context;->getExternalFilesDir(Ljava/lang/String;)Ljava/io/File;

    move-result-object v9

    const/4 v6, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xca

    invoke-virtual {v9}, Ljava/io/File;->exists()Z

    move-result v10

    if-nez v10, :cond_c5a

    const/16 v6, 0x521

    invoke-virtual {v9}, Ljava/io/File;->mkdir()Z

    :cond_c5a
    const/16 v6, 0x24e

    new-instance v10, Ljava/io/File;

    nop

    const/4 v6, -0x3

    new-instance v13, Ljava/lang/StringBuilder;

    nop

    const/4 v6, -0x4

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v6, 0x125

    invoke-virtual {v9}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v9

    const/4 v6, 0x0

    invoke-virtual {v13, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v18, 0x2f

    const/16 v6, 0x1b

    move/from16 v0, v18

    invoke-virtual {v13, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v6, 0x4f0

    iget-object v9, v8, Lkc0;->U:Landroid/net/Uri;

    nop

    if-eqz v9, :cond_d5c

    const/16 v6, 0x441

    invoke-virtual {v9}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object v9

    const/4 v6, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move/from16 v0, v20

    new-array v14, v0, [C

    const/16 v15, 0x2e

    const/16 v26, 0x0

    aput-char v15, v14, v26

    const/16 v6, 0x31

    invoke-static {v9, v14}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v9

    const/16 v6, 0x535

    invoke-static {v9}, Lbs;->k0(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/CharSequence;

    move/from16 v0, v20

    new-array v14, v0, [C

    const/16 v28, 0x2f

    aput-char v28, v14, v26

    const/16 v6, 0x31

    invoke-static {v9, v14}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v9

    const/16 v6, 0x306

    invoke-static {v9}, Lbs;->q0(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    const/4 v6, 0x0

    invoke-virtual {v13, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v9, 0x20

    const/16 v6, 0x1b

    invoke-virtual {v13, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v6, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v14

    const/16 v6, 0x83

    invoke-virtual {v13, v14, v15}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    move-object/from16 v0, v17

    invoke-virtual {v13, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, -0x2

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    const/16 v6, 0x212

    invoke-direct {v10, v9}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/16 v6, 0x3a8

    iput-object v10, v8, Lkc0;->T:Ljava/io/File;

    const/16 v6, 0xca

    invoke-virtual {v10}, Ljava/io/File;->exists()Z

    move-result v9

    if-eqz v9, :cond_d01

    const/16 v6, 0x3d

    iget-object v9, v8, Lkc0;->T:Ljava/io/File;

    nop

    if-eqz v9, :cond_cf8

    const/16 v6, 0x460

    invoke-virtual {v9}, Ljava/io/File;->delete()Z

    goto :goto_d01

    :cond_cf8
    const/4 v6, 0x5

    move-object/from16 v0, v25

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    const/16 v24, 0x0

    throw v24

    :cond_d01
    :goto_d01
    const/16 v6, 0x3d

    iget-object v9, v8, Lkc0;->T:Ljava/io/File;

    nop

    if-eqz v9, :cond_d53

    const/16 v6, 0x288

    invoke-virtual {v9}, Ljava/io/File;->createNewFile()Z

    const/16 v6, 0x3d

    iget-object v9, v8, Lkc0;->T:Ljava/io/File;

    nop

    if-eqz v9, :cond_d4a

    const/16 v6, 0x448

    new-instance v10, Ljava/io/FileOutputStream;

    nop

    const/16 v6, 0x442

    move/from16 v0, v20

    invoke-direct {v10, v9, v0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;Z)V

    :try_start_d20
    const/16 v6, 0x3e8

    invoke-virtual {v10, v11}, Ljava/io/FileOutputStream;->write([B)V
    :try_end_d25
    .catchall {:try_start_d20 .. :try_end_d25} :catchall_d40

    const/16 v6, 0x3c5

    invoke-virtual {v10}, Ljava/io/FileOutputStream;->close()V

    const/16 v6, 0x3d

    iget-object v9, v8, Lkc0;->T:Ljava/io/File;

    nop

    if-eqz v9, :cond_d37

    const/16 v6, 0x509

    invoke-virtual {v9}, Ljava/io/File;->setReadOnly()Z

    goto :goto_d63

    :cond_d37
    const/4 v6, 0x5

    move-object/from16 v0, v25

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    const/16 v24, 0x0

    throw v24

    :catchall_d40
    move-exception v8

    move-object v9, v8

    :try_start_d42
    throw v9
    :try_end_d43
    .catchall {:try_start_d42 .. :try_end_d43} :catchall_d43

    :catchall_d43
    move-exception v8

    const/16 v6, 0x343

    invoke-static {v10, v9}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v8

    :cond_d4a
    const/16 v24, 0x0

    const/4 v6, 0x5

    move-object/from16 v0, v25

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_d53
    const/16 v24, 0x0

    const/4 v6, 0x5

    move-object/from16 v0, v25

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_d5c
    const/16 v24, 0x0

    const/4 v6, 0x5

    invoke-static {v12}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_d63
    :goto_d63
    const/16 v6, 0x5b

    new-instance v9, Landroid/content/Intent;

    nop

    const-string/jumbo v10, "android.intent.action.SEND"

    const/16 v6, 0x62

    invoke-direct {v9, v10}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v6, 0x2b

    invoke-virtual {v8}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v10

    const/16 v6, 0x3d

    iget-object v11, v8, Lkc0;->T:Ljava/io/File;

    nop

    if-eqz v11, :cond_db2

    const-string/jumbo v13, "com.tlsvpn.tlstunnel.configs"

    const/16 v6, 0xa90

    invoke-static {v10, v13, v11}, Landroidx/core/content/FileProvider;->getUriForFile(Landroid/content/Context;Ljava/lang/String;Ljava/io/File;)Landroid/net/Uri;

    move-result-object v10

    const-string/jumbo v11, "android.intent.extra.STREAM"

    const/16 v6, 0x436

    invoke-virtual {v9, v11, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    const-string/jumbo v10, "*/*"

    const/16 v6, 0x3dd

    invoke-virtual {v9, v10}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    const/16 v6, 0x59

    move/from16 v0, v20

    invoke-virtual {v9, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const v10, 0x7f1300cc

    const/16 v6, 0x4c

    invoke-virtual {v8, v10}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v10

    const/16 v6, 0x7c8

    invoke-static {v9, v10}, Landroid/content/Intent;->createChooser(Landroid/content/Intent;Ljava/lang/CharSequence;)Landroid/content/Intent;

    move-result-object v9

    const/16 v6, 0x634

    invoke-virtual {v8, v9}, Landroidx/fragment/app/Fragment;->startActivity(Landroid/content/Intent;)V

    goto :goto_dbb

    :cond_db2
    const/4 v6, 0x5

    move-object/from16 v0, v25

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    const/16 v24, 0x0

    throw v24

    :cond_dbb
    :goto_dbb
    const/4 v6, -0x3

    new-instance v9, Ljava/lang/StringBuilder;

    nop

    const/4 v6, -0x4

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const v10, 0x7f130231

    const/16 v6, 0x4c

    invoke-virtual {v8, v10}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v10

    const/4 v6, 0x0

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v10, ": "

    const/4 v6, 0x0

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v6, 0x4f0

    iget-object v10, v8, Lkc0;->U:Landroid/net/Uri;

    nop

    if-eqz v10, :cond_e16

    const/16 v6, 0x441

    invoke-virtual {v10}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object v10

    const/4 v6, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move/from16 v0, v20

    new-array v11, v0, [C

    const/16 v14, 0x3a

    const/16 v26, 0x0

    aput-char v14, v11, v26

    const/16 v6, 0x31

    invoke-static {v10, v11}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v10

    const/16 v6, 0x306

    invoke-static {v10}, Lbs;->q0(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    const/4 v6, 0x0

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, -0x2

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    const/16 v6, 0x303

    move-object/from16 v0, v22

    invoke-virtual {v8, v9, v0}, Lkc0;->f(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v6, 0x181

    invoke-virtual {v8}, Landroidx/fragment/app/g;->dismiss()V

    return-void

    :cond_e16
    const/4 v6, 0x5

    invoke-static {v12}, Lgt0;->F0(Ljava/lang/String;)V

    const/16 v24, 0x0

    throw v24

    :cond_e1d
    const/16 v24, 0x0

    const/4 v6, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_e24
    const/16 v24, 0x0

    const/4 v6, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_e2b
    const/16 v24, 0x0

    const/4 v6, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_e32
    move-object/from16 v24, v18

    const/4 v6, 0x5

    move-object/from16 v0, v19

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_e3b
    move-object/from16 v24, v18

    const/4 v6, 0x5

    move-object/from16 v0, v19

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24
.end method

.method public final d()Landroid/content/SharedPreferences;
    .registers 3

    const/16 v0, 0x980

    iget-object p0, p0, Lkc0;->q:Lw82;

    nop

    const/16 v0, 0x177

    invoke-virtual {p0}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/content/SharedPreferences;

    return-object p0
.end method

.method public final e()V
    .registers 10

    .prologue
    const/16 v0, 0x30

    invoke-virtual {p0}, Lkc0;->d()Landroid/content/SharedPreferences;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x7a

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const/16 v0, 0xc1

    iget-object v3, p0, Lkc0;->t:Landroid/widget/EditText;

    nop

    const/4 v4, 0x0

    const-string/jumbo v5, "cfgname"

    if-eqz v3, :cond_1cd

    const/16 v0, 0x2d

    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v3

    const/16 v0, 0xcb

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    const/16 v0, 0x2e4

    sget-object v6, Lip;->a:Ljava/nio/charset/Charset;

    nop

    const/16 v0, 0x2c

    invoke-virtual {v3, v6}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v3

    const/4 v0, -0x6

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v7, 0x2

    const/16 v0, 0x3e

    invoke-static {v3, v7}, Landroid/util/Base64;->encode([BI)[B

    move-result-object v3

    const/4 v0, -0x6

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v8, Ljava/lang/String;

    check-cast v6, Ljava/nio/charset/Charset;

    invoke-direct {v8, v3, v6}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const/16 v0, 0x3c

    invoke-interface {v2, v5, v8}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x6f

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/16 v0, 0x291

    iget-boolean v2, p0, Lkc0;->W:Z

    nop

    if-nez v2, :cond_1cc

    const/16 v0, 0x30

    invoke-virtual {p0}, Lkc0;->d()Landroid/content/SharedPreferences;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x7a

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const/16 v0, 0x4c7

    iget-object v3, p0, Lkc0;->w:Lcom/google/android/material/textfield/TextInputEditText;

    nop

    const-string/jumbo v5, "mensagem"

    if-eqz v3, :cond_1c7

    const/16 v0, 0x20b

    invoke-virtual {v3}, Lyb;->getText()Landroid/text/Editable;

    move-result-object v3

    const/16 v0, 0x1a8

    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    const/16 v0, 0x2c

    invoke-virtual {v3, v6}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v3

    const/4 v0, -0x6

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x3e

    invoke-static {v3, v7}, Landroid/util/Base64;->encode([BI)[B

    move-result-object v3

    const/4 v0, -0x6

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v7, Ljava/lang/String;

    check-cast v6, Ljava/nio/charset/Charset;

    invoke-direct {v7, v3, v6}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const/16 v0, 0x3c

    invoke-interface {v2, v5, v7}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0xf4

    iget-object v3, p0, Lkc0;->y:Landroid/widget/CheckBox;

    nop

    const-string/jumbo v5, "bloqmc"

    if-eqz v3, :cond_1c2

    const/16 v0, 0x36

    invoke-virtual {v3}, Landroid/widget/CompoundButton;->isChecked()Z

    const/4 v3, 0x0

    const/16 v0, 0x48

    invoke-interface {v2, v5, v3}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x90

    iget-object v3, p0, Lkc0;->z:Landroid/widget/CheckBox;

    nop

    if-eqz v3, :cond_1ba

    const/16 v0, 0x36

    invoke-virtual {v3}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v3

    const-string/jumbo v5, "exsshserver"

    const/16 v0, 0x48

    invoke-interface {v2, v5, v3}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x130

    iget-object v3, p0, Lkc0;->B:Landroid/widget/EditText;

    nop

    const-string/jumbo v5, "sshhost"

    if-eqz v3, :cond_1b5

    const/16 v0, 0x2d

    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v3

    const/16 v0, 0xcb

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    const/16 v0, 0x3c

    invoke-interface {v2, v5, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x24f

    iget-object v3, p0, Lkc0;->D:Landroid/widget/EditText;

    nop

    const-string/jumbo v5, "sshport"

    if-eqz v3, :cond_1b0

    const/16 v0, 0x2d

    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v3

    const/16 v0, 0xcb

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    const/16 v0, 0x3c

    invoke-interface {v2, v5, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0xa1

    iget-object v3, p0, Lkc0;->F:Landroid/widget/CheckBox;

    nop

    if-eqz v3, :cond_1a8

    const/16 v0, 0x36

    invoke-virtual {v3}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v3

    const-string/jumbo v5, "exsshlogin"

    const/16 v0, 0x48

    invoke-interface {v2, v5, v3}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x11e

    iget-object v3, p0, Lkc0;->H:Landroid/widget/EditText;

    nop

    const-string/jumbo v5, "sshuser"

    if-eqz v3, :cond_1a3

    const/16 v0, 0x2d

    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v3

    const/16 v0, 0xcb

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    const/16 v0, 0x3c

    invoke-interface {v2, v5, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x230

    iget-object v3, p0, Lkc0;->J:Landroid/widget/EditText;

    nop

    const-string/jumbo v5, "sshpass"

    if-eqz v3, :cond_19e

    const/16 v0, 0x2d

    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v3

    const/16 v0, 0xcb

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    const/16 v0, 0x3c

    invoke-interface {v2, v5, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0xe6

    iget-object v3, p0, Lkc0;->L:Landroid/widget/CheckBox;

    nop

    const-string/jumbo v5, "addmsg"

    if-eqz v3, :cond_199

    const/16 v0, 0x36

    invoke-virtual {v3}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v3

    const/16 v0, 0x48

    invoke-interface {v2, v5, v3}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x23f

    iget-object v3, p0, Lkc0;->M:Landroid/widget/CheckBox;

    nop

    const-string/jumbo v5, "blockTorrent"

    if-eqz v3, :cond_194

    const/16 v0, 0x36

    invoke-virtual {v3}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v3

    const/16 v0, 0x48

    invoke-interface {v2, v5, v3}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x1b5

    iget-object p0, p0, Lkc0;->N:Landroid/widget/CheckBox;

    nop

    const-string/jumbo v3, "blockRootDev"

    if-eqz p0, :cond_18f

    const/16 v0, 0x36

    invoke-virtual {p0}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result p0

    const/16 v0, 0x48

    invoke-interface {v2, v3, p0}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x6f

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void

    :cond_18f
    const/4 v0, 0x5

    invoke-static {v3}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_194
    const/4 v0, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_199
    const/4 v0, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_19e
    const/4 v0, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_1a3
    const/4 v0, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_1a8
    const-string/jumbo p0, "sshlogin"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_1b0
    const/4 v0, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_1b5
    const/4 v0, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_1ba
    const-string/jumbo p0, "sshserver"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_1c2
    const/4 v0, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_1c7
    const/4 v0, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_1cc
    return-void

    :cond_1cd
    const/4 v0, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4
.end method

.method public final f(Ljava/lang/String;Ljava/lang/String;)V
    .registers 7

    const/16 v0, 0x5b

    new-instance v2, Landroid/content/Intent;

    nop

    const-string/jumbo v3, "ssb"

    const/16 v0, 0x62

    invoke-direct {v2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string/jumbo v3, "msg"

    const/16 v0, 0x4b

    invoke-virtual {v2, v3, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string/jumbo p1, "dur"

    const/16 v3, 0xbb8

    const/16 v0, 0x29

    invoke-virtual {v2, p1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string/jumbo p1, "act"

    const/16 v0, 0x4b

    invoke-virtual {v2, p1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p1

    const/16 v0, 0x53

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const/16 v0, 0x4a

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0x64

    invoke-virtual {v2, p1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p0

    const/16 v0, 0x63

    invoke-virtual {p0, v2}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    return-void
.end method

.method public final onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .registers 24

    .prologue
    move-object/from16 v4, p0

    const/4 v2, -0x6

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const v5, 0x7f0c0037

    const/4 v6, 0x0

    move-object/from16 v7, p1

    move-object/from16 v8, p2

    const/16 v2, 0x107b

    invoke-virtual {v7, v5, v8, v6}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v5

    const v7, 0x7f090392

    const/16 v2, 0x11

    invoke-virtual {v5, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v7, Landroid/widget/ImageView;

    const/16 v2, 0x10c0

    iput-object v7, v4, Lkc0;->r:Landroid/widget/ImageView;

    const v7, 0x7f09013b

    const/16 v2, 0x11

    invoke-virtual {v5, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v7, Landroid/widget/ImageView;

    const/16 v2, 0xa1d

    iput-object v7, v4, Lkc0;->s:Landroid/widget/ImageView;

    const v7, 0x7f090107

    const/16 v2, 0x11

    invoke-virtual {v5, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v7, Landroid/widget/LinearLayout;

    const/16 v2, 0xca6

    iput-object v7, v4, Lkc0;->v:Landroid/widget/LinearLayout;

    const v7, 0x7f09009d

    const/16 v2, 0x11

    invoke-virtual {v5, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v7, Landroid/widget/EditText;

    const/16 v2, 0x782

    iput-object v7, v4, Lkc0;->t:Landroid/widget/EditText;

    const v7, 0x7f09009e

    const/16 v2, 0x11

    invoke-virtual {v5, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v7, Lcom/google/android/material/textfield/TextInputLayout;

    const/16 v2, 0x866

    iput-object v7, v4, Lkc0;->u:Lcom/google/android/material/textfield/TextInputLayout;

    const v7, 0x7f09007d

    const/16 v2, 0x11

    invoke-virtual {v5, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v7, Landroid/widget/CheckBox;

    const/16 v2, 0x9e0

    iput-object v7, v4, Lkc0;->y:Landroid/widget/CheckBox;

    const v7, 0x7f090351

    const/16 v2, 0x11

    invoke-virtual {v5, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v7, Landroid/widget/CheckBox;

    const/16 v2, 0x80a

    iput-object v7, v4, Lkc0;->z:Landroid/widget/CheckBox;

    const v7, 0x7f09034b

    const/16 v2, 0x11

    invoke-virtual {v5, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v7, Landroid/widget/TableLayout;

    const/16 v2, 0xacd

    iput-object v7, v4, Lkc0;->A:Landroid/widget/TableLayout;

    const v7, 0x7f090349

    const/16 v2, 0x11

    invoke-virtual {v5, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v7, Landroid/widget/EditText;

    const/16 v2, 0xd03

    iput-object v7, v4, Lkc0;->B:Landroid/widget/EditText;

    const v7, 0x7f09034a

    const/16 v2, 0x11

    invoke-virtual {v5, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v7, Lcom/google/android/material/textfield/TextInputLayout;

    const/16 v2, 0x11b8

    iput-object v7, v4, Lkc0;->C:Lcom/google/android/material/textfield/TextInputLayout;

    const v7, 0x7f09034f

    const/16 v2, 0x11

    invoke-virtual {v5, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v7, Landroid/widget/EditText;

    const/16 v2, 0x59b

    iput-object v7, v4, Lkc0;->D:Landroid/widget/EditText;

    const v7, 0x7f090350

    const/16 v2, 0x11

    invoke-virtual {v5, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v7, Lcom/google/android/material/textfield/TextInputLayout;

    const/16 v2, 0x1066

    iput-object v7, v4, Lkc0;->E:Lcom/google/android/material/textfield/TextInputLayout;

    const v7, 0x7f09034c

    const/16 v2, 0x11

    invoke-virtual {v5, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v7, Landroid/widget/CheckBox;

    const/16 v2, 0x5a5

    iput-object v7, v4, Lkc0;->F:Landroid/widget/CheckBox;

    const v7, 0x7f090354

    const/16 v2, 0x11

    invoke-virtual {v5, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v7, Landroid/widget/LinearLayout;

    const/16 v2, 0x1230

    iput-object v7, v4, Lkc0;->G:Landroid/widget/LinearLayout;

    const v7, 0x7f090352

    const/16 v2, 0x11

    invoke-virtual {v5, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v7, Landroid/widget/EditText;

    const/16 v2, 0x11ab

    iput-object v7, v4, Lkc0;->H:Landroid/widget/EditText;

    const v7, 0x7f090353

    const/16 v2, 0x11

    invoke-virtual {v5, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v7, Lcom/google/android/material/textfield/TextInputLayout;

    const/16 v2, 0x79a

    iput-object v7, v4, Lkc0;->I:Lcom/google/android/material/textfield/TextInputLayout;

    const v7, 0x7f09034d

    const/16 v2, 0x11

    invoke-virtual {v5, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v7, Landroid/widget/EditText;

    const/16 v2, 0xd09

    iput-object v7, v4, Lkc0;->J:Landroid/widget/EditText;

    const v7, 0x7f09034e

    const/16 v2, 0x11

    invoke-virtual {v5, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v7, Lcom/google/android/material/textfield/TextInputLayout;

    const/16 v2, 0x9ad

    iput-object v7, v4, Lkc0;->K:Lcom/google/android/material/textfield/TextInputLayout;

    const v7, 0x7f09007c

    const/16 v2, 0x11

    invoke-virtual {v5, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v7, Landroid/widget/CheckBox;

    const/16 v2, 0xa60

    iput-object v7, v4, Lkc0;->M:Landroid/widget/CheckBox;

    const v7, 0x7f09007b

    const/16 v2, 0x11

    invoke-virtual {v5, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v7, Landroid/widget/CheckBox;

    const/16 v2, 0x1085

    iput-object v7, v4, Lkc0;->N:Landroid/widget/CheckBox;

    const v7, 0x7f09004a

    const/16 v2, 0x11

    invoke-virtual {v5, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v7, Landroid/widget/CheckBox;

    const/16 v2, 0xdad

    iput-object v7, v4, Lkc0;->L:Landroid/widget/CheckBox;

    const v7, 0x7f090247

    const/16 v2, 0x11

    invoke-virtual {v5, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v7, Lcom/google/android/material/textfield/TextInputEditText;

    const/16 v2, 0xe93

    iput-object v7, v4, Lkc0;->w:Lcom/google/android/material/textfield/TextInputEditText;

    const v7, 0x7f090248

    const/16 v2, 0x11

    invoke-virtual {v5, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v7, Lcom/google/android/material/textfield/TextInputLayout;

    const/16 v2, 0x1101

    iput-object v7, v4, Lkc0;->x:Lcom/google/android/material/textfield/TextInputLayout;

    const v7, 0x7f090137

    const/16 v2, 0x11

    invoke-virtual {v5, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v7, Landroid/widget/TextView;

    const/16 v2, 0x966

    iput-object v7, v4, Lkc0;->R:Landroid/widget/TextView;

    const v7, 0x7f090259

    const/16 v2, 0x11

    invoke-virtual {v5, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v7, Landroid/widget/TextView;

    const/16 v2, 0xebd

    iput-object v7, v4, Lkc0;->O:Landroid/widget/TextView;

    const v7, 0x7f0903a4

    const/16 v2, 0x11

    invoke-virtual {v5, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v7, Lcom/google/android/material/card/MaterialCardView;

    const/16 v2, 0x7d2

    iput-object v7, v4, Lkc0;->P:Lcom/google/android/material/card/MaterialCardView;

    const v7, 0x7f0903a3

    const/16 v2, 0x11

    invoke-virtual {v5, v7}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v7, Landroid/widget/TextView;

    const/16 v2, 0x6dc

    iput-object v7, v4, Lkc0;->Q:Landroid/widget/TextView;

    const/16 v2, 0x30

    invoke-virtual {v4}, Lkc0;->d()Landroid/content/SharedPreferences;

    move-result-object v7

    const-string/jumbo v8, "cryptoconfig"

    const-string/jumbo v9, ""

    const/16 v2, 0x2e

    invoke-interface {v7, v8, v9}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v2, 0x47

    invoke-virtual {v7}, Ljava/lang/String;->length()I

    move-result v7

    const/4 v8, 0x1

    if-lez v7, :cond_238

    move v7, v8

    goto :goto_239

    :cond_238
    move v7, v6

    :goto_239
    const/16 v2, 0x721

    iput-boolean v7, v4, Lkc0;->W:Z

    const/16 v2, 0x5b2

    iget-object v10, v4, Lkc0;->v:Landroid/widget/LinearLayout;

    nop

    if-eqz v10, :cond_9a5

    if-eqz v7, :cond_249

    const/16 v7, 0x8

    goto :goto_24a

    :cond_249
    move v7, v6

    :goto_24a
    const/4 v2, -0x5

    invoke-virtual {v10, v7}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0x897

    iget-object v7, v4, Lkc0;->s:Landroid/widget/ImageView;

    nop

    if-eqz v7, :cond_99b

    const/16 v2, 0x37e

    new-instance v10, Lfc0;

    nop

    const/16 v2, 0x36c

    invoke-direct {v10, v4, v6}, Lfc0;-><init>(Lkc0;I)V

    const/16 v2, 0x5f

    invoke-virtual {v7, v10}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v2, 0xcf3

    iget-object v7, v4, Lkc0;->r:Landroid/widget/ImageView;

    nop

    if-eqz v7, :cond_991

    const/16 v2, 0x37e

    new-instance v10, Lfc0;

    nop

    const/16 v2, 0x36c

    invoke-direct {v10, v4, v8}, Lfc0;-><init>(Lkc0;I)V

    const/16 v2, 0x5f

    invoke-virtual {v7, v10}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v2, 0xc1

    iget-object v7, v4, Lkc0;->t:Landroid/widget/EditText;

    nop

    const-string/jumbo v10, "cfgname"

    if-eqz v7, :cond_98a

    const/16 v2, 0xbc

    new-instance v13, Ljc0;

    nop

    const/16 v2, 0xa3

    invoke-direct {v13, v4, v6}, Ljc0;-><init>(Lkc0;I)V

    const/16 v2, 0xb8

    invoke-virtual {v7, v13}, Landroid/widget/TextView;->addTextChangedListener(Landroid/text/TextWatcher;)V

    const/16 v2, 0x130

    iget-object v7, v4, Lkc0;->B:Landroid/widget/EditText;

    nop

    const-string/jumbo v13, "sshhost"

    if-eqz v7, :cond_983

    const/16 v2, 0xbc

    new-instance v14, Ljc0;

    nop

    const/16 v2, 0xa3

    invoke-direct {v14, v4, v8}, Ljc0;-><init>(Lkc0;I)V

    const/16 v2, 0xb8

    invoke-virtual {v7, v14}, Landroid/widget/TextView;->addTextChangedListener(Landroid/text/TextWatcher;)V

    const/16 v2, 0x24f

    iget-object v7, v4, Lkc0;->D:Landroid/widget/EditText;

    nop

    const-string/jumbo v14, "sshport"

    if-eqz v7, :cond_97c

    const/16 v2, 0xbc

    new-instance v15, Ljc0;

    nop

    const/16 v16, 0x2

    const/16 v2, 0xa3

    move/from16 v0, v16

    invoke-direct {v15, v4, v0}, Ljc0;-><init>(Lkc0;I)V

    const/16 v2, 0xb8

    invoke-virtual {v7, v15}, Landroid/widget/TextView;->addTextChangedListener(Landroid/text/TextWatcher;)V

    const/16 v2, 0x11e

    iget-object v7, v4, Lkc0;->H:Landroid/widget/EditText;

    nop

    const-string/jumbo v15, "sshuser"

    if-eqz v7, :cond_975

    const/16 v2, 0xbc

    new-instance v17, Ljc0;

    nop

    const/16 v18, 0x3

    const/16 v2, 0xa3

    move-object/from16 v0, v17

    move/from16 v1, v18

    invoke-direct {v0, v4, v1}, Ljc0;-><init>(Lkc0;I)V

    const/16 v2, 0xb8

    move-object/from16 v0, v17

    invoke-virtual {v7, v0}, Landroid/widget/TextView;->addTextChangedListener(Landroid/text/TextWatcher;)V

    const/16 v2, 0x230

    iget-object v7, v4, Lkc0;->J:Landroid/widget/EditText;

    nop

    const-string/jumbo v17, "sshpass"

    if-eqz v7, :cond_96c

    const/16 v2, 0xbc

    new-instance v19, Ljc0;

    nop

    const/16 p1, 0x0

    const/4 v11, 0x4

    const/16 v2, 0xa3

    move-object/from16 v0, v19

    invoke-direct {v0, v4, v11}, Ljc0;-><init>(Lkc0;I)V

    const/16 v2, 0xb8

    move-object/from16 v0, v19

    invoke-virtual {v7, v0}, Landroid/widget/TextView;->addTextChangedListener(Landroid/text/TextWatcher;)V

    const/16 v2, 0xf4

    iget-object v7, v4, Lkc0;->y:Landroid/widget/CheckBox;

    nop

    const-string/jumbo v11, "bloqmc"

    if-eqz v7, :cond_967

    const/16 v2, 0x165

    new-instance v19, Lgc0;

    nop

    const/16 v2, 0x164

    move-object/from16 v0, v19

    invoke-direct {v0, v4, v6}, Lgc0;-><init>(Lkc0;I)V

    const/16 v2, 0x14a

    move-object/from16 v0, v19

    invoke-virtual {v7, v0}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    const/16 v2, 0x90

    iget-object v7, v4, Lkc0;->z:Landroid/widget/CheckBox;

    nop

    const-string/jumbo v19, "sshserver"

    if-eqz v7, :cond_960

    const/16 v2, 0x165

    new-instance v12, Lgc0;

    nop

    const/16 v2, 0x164

    invoke-direct {v12, v4, v8}, Lgc0;-><init>(Lkc0;I)V

    const/16 v2, 0x14a

    invoke-virtual {v7, v12}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    const/16 v2, 0xa1

    iget-object v7, v4, Lkc0;->F:Landroid/widget/CheckBox;

    nop

    const-string/jumbo v12, "sshlogin"

    if-eqz v7, :cond_95b

    move/from16 p3, v8

    const/16 v2, 0x165

    new-instance v8, Lgc0;

    nop

    const/16 v2, 0x164

    move/from16 v0, v16

    invoke-direct {v8, v4, v0}, Lgc0;-><init>(Lkc0;I)V

    const/16 v2, 0x14a

    invoke-virtual {v7, v8}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    const/16 v2, 0xe6

    iget-object v7, v4, Lkc0;->L:Landroid/widget/CheckBox;

    nop

    const-string/jumbo v8, "addmsg"

    if-eqz v7, :cond_956

    const/16 v2, 0x165

    new-instance v16, Lgc0;

    nop

    const/16 v2, 0x164

    move-object/from16 v0, v16

    move/from16 v1, v18

    invoke-direct {v0, v4, v1}, Lgc0;-><init>(Lkc0;I)V

    const/16 v2, 0x14a

    move-object/from16 v0, v16

    invoke-virtual {v7, v0}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    const/16 v2, 0x4c7

    iget-object v7, v4, Lkc0;->w:Lcom/google/android/material/textfield/TextInputEditText;

    nop

    const-string/jumbo v16, "mensagem"

    if-eqz v7, :cond_94f

    const/16 v2, 0xbc

    new-instance v18, Ljc0;

    nop

    const/4 v6, 0x5

    const/16 v2, 0xa3

    move-object/from16 v0, v18

    invoke-direct {v0, v4, v6}, Ljc0;-><init>(Lkc0;I)V

    const/16 v2, 0xb8

    move-object/from16 v0, v18

    invoke-virtual {v7, v0}, Landroid/widget/TextView;->addTextChangedListener(Landroid/text/TextWatcher;)V

    const/16 v2, 0x9d1

    iget-object v6, v4, Lkc0;->Q:Landroid/widget/TextView;

    nop

    if-eqz v6, :cond_947

    const/16 v2, 0xb9c

    invoke-static {}, Landroid/text/method/LinkMovementMethod;->getInstance()Landroid/text/method/MovementMethod;

    move-result-object v7

    const/16 v2, 0xfc1

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setMovementMethod(Landroid/text/method/MovementMethod;)V

    const/16 v2, 0x1fc

    sget v6, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 v7, 0x1e

    if-ge v6, v7, :cond_42d

    const/16 v2, 0x2b

    invoke-virtual {v4}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v6

    const-string/jumbo v7, "android.permission.READ_EXTERNAL_STORAGE"

    const/16 v2, 0x2b7

    invoke-static {v6, v7}, Lqx;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result v6

    const-string/jumbo v18, "android.permission.WRITE_EXTERNAL_STORAGE"

    if-nez v6, :cond_3d9

    const/16 v2, 0x2b

    invoke-virtual {v4}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v6

    const/16 v2, 0x2b7

    move-object/from16 v0, v18

    invoke-static {v6, v0}, Lqx;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result v6

    if-eqz v6, :cond_42d

    :cond_3d9
    const/16 v2, 0xfb

    invoke-virtual {v4}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object v6

    const/16 v2, 0x282

    invoke-static {v6, v7}, La3;->c(Landroidx/fragment/app/l;Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_413

    const/16 v2, 0xfb

    invoke-virtual {v4}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object v6

    const/16 v2, 0x282

    move-object/from16 v0, v18

    invoke-static {v6, v0}, La3;->c(Landroidx/fragment/app/l;Ljava/lang/String;)Z

    move-result v6

    if-nez v6, :cond_3f8

    goto :goto_413

    :cond_3f8
    const v6, 0x7f1301f3

    const/16 v2, 0x4c

    invoke-virtual {v4, v6}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v6

    const/4 v2, -0x6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string/jumbo v7, "pdn"

    const/16 v2, 0x303

    invoke-virtual {v4, v6, v7}, Lkc0;->f(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v2, 0x181

    invoke-virtual {v4}, Landroidx/fragment/app/g;->dismiss()V

    goto :goto_42d

    :cond_413
    :goto_413
    const/16 v2, 0xfb

    invoke-virtual {v4}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object v6

    check-cast v7, Ljava/lang/String;

    check-cast v18, Ljava/lang/String;

    move-object v0, v7

    move-object/from16 v1, v18

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v7

    const/16 v18, 0x1cd0

    const/16 v2, 0xf38

    move/from16 v0, v18

    invoke-static {v6, v7, v0}, La3;->b(Landroid/app/Activity;[Ljava/lang/String;I)V

    :cond_42d
    :goto_42d
    const/16 v2, 0x90

    iget-object v6, v4, Lkc0;->z:Landroid/widget/CheckBox;

    nop

    if-eqz v6, :cond_940

    const/16 v2, 0x130

    iget-object v7, v4, Lkc0;->B:Landroid/widget/EditText;

    nop

    if-eqz v7, :cond_93b

    const/16 v2, 0x2d

    invoke-virtual {v7}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v2, 0x7c

    invoke-static {v7}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v7

    xor-int/lit8 v7, v7, 0x1

    const/16 v2, 0x7e

    invoke-virtual {v6, v7}, Landroid/widget/CompoundButton;->setChecked(Z)V

    const/16 v2, 0x90

    iget-object v6, v4, Lkc0;->z:Landroid/widget/CheckBox;

    nop

    if-eqz v6, :cond_934

    const/16 v2, 0x36

    invoke-virtual {v6}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v6

    if-eqz v6, :cond_491

    const/16 v2, 0xa1

    iget-object v6, v4, Lkc0;->F:Landroid/widget/CheckBox;

    nop

    if-eqz v6, :cond_48c

    const/16 v2, 0x11e

    iget-object v7, v4, Lkc0;->H:Landroid/widget/EditText;

    nop

    if-eqz v7, :cond_487

    const/16 v2, 0x2d

    invoke-virtual {v7}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v2, 0x7c

    invoke-static {v7}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v7

    xor-int/lit8 v7, v7, 0x1

    const/16 v2, 0x7e

    invoke-virtual {v6, v7}, Landroid/widget/CompoundButton;->setChecked(Z)V

    goto :goto_491

    :cond_487
    const/4 v2, 0x5

    invoke-static {v15}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_48c
    const/4 v2, 0x5

    invoke-static {v12}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_491
    :goto_491
    const/16 v2, 0xc1

    iget-object v6, v4, Lkc0;->t:Landroid/widget/EditText;

    nop

    if-eqz v6, :cond_92f

    :try_start_498
    const/16 v2, 0x30

    invoke-virtual {v4}, Lkc0;->d()Landroid/content/SharedPreferences;

    move-result-object v7

    const/16 v2, 0x2e

    invoke-interface {v7, v10, v9}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const/4 v10, 0x0

    const/16 v2, 0x3ce

    invoke-static {v7, v10}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v10, Ljava/lang/String;

    const/16 v2, 0x2e4

    sget-object v18, Lip;->a:Ljava/nio/charset/Charset;

    nop

    check-cast v18, Ljava/nio/charset/Charset;

    move-object/from16 v0, v18

    invoke-direct {v10, v7, v0}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V
    :try_end_4bd
    .catch Ljava/lang/Exception; {:try_start_498 .. :try_end_4bd} :catch_4be

    goto :goto_4bf

    :catch_4be
    move-object v10, v9

    :goto_4bf
    const/16 v2, 0x8a

    invoke-virtual {v6, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v2, 0x291

    iget-boolean v6, v4, Lkc0;->W:Z

    nop

    if-eqz v6, :cond_4cd

    goto/16 :goto_878

    :cond_4cd
    const/16 v2, 0x4c7

    iget-object v6, v4, Lkc0;->w:Lcom/google/android/material/textfield/TextInputEditText;

    nop

    if-eqz v6, :cond_928

    :try_start_4d4
    const/16 v2, 0x30

    invoke-virtual {v4}, Lkc0;->d()Landroid/content/SharedPreferences;

    move-result-object v7

    const/16 v2, 0x2e

    move-object/from16 v0, v16

    invoke-interface {v7, v0, v9}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const/4 v10, 0x0

    const/16 v2, 0x3ce

    invoke-static {v7, v10}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v10, Ljava/lang/String;

    const/16 v2, 0x2e4

    sget-object v16, Lip;->a:Ljava/nio/charset/Charset;

    nop

    check-cast v16, Ljava/nio/charset/Charset;

    move-object/from16 v0, v16

    invoke-direct {v10, v7, v0}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V
    :try_end_4fb
    .catch Ljava/lang/Exception; {:try_start_4d4 .. :try_end_4fb} :catch_4fc

    goto :goto_4fd

    :catch_4fc
    move-object v10, v9

    :goto_4fd
    const/16 v2, 0x8a

    invoke-virtual {v6, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v2, 0x130

    iget-object v6, v4, Lkc0;->B:Landroid/widget/EditText;

    nop

    if-eqz v6, :cond_923

    const/16 v2, 0x30

    invoke-virtual {v4}, Lkc0;->d()Landroid/content/SharedPreferences;

    move-result-object v7

    const/16 v2, 0x2e

    invoke-interface {v7, v13, v9}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const/16 v2, 0x8a

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v2, 0x24f

    iget-object v6, v4, Lkc0;->D:Landroid/widget/EditText;

    nop

    if-eqz v6, :cond_91e

    const/16 v2, 0x30

    invoke-virtual {v4}, Lkc0;->d()Landroid/content/SharedPreferences;

    move-result-object v7

    const/16 v2, 0x2e

    invoke-interface {v7, v14, v9}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const/16 v2, 0x8a

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v2, 0x11e

    iget-object v6, v4, Lkc0;->H:Landroid/widget/EditText;

    nop

    if-eqz v6, :cond_919

    const/16 v2, 0x30

    invoke-virtual {v4}, Lkc0;->d()Landroid/content/SharedPreferences;

    move-result-object v7

    const/16 v2, 0x2e

    invoke-interface {v7, v15, v9}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const/16 v2, 0x8a

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v2, 0x230

    iget-object v6, v4, Lkc0;->J:Landroid/widget/EditText;

    nop

    if-eqz v6, :cond_912

    const/16 v2, 0x30

    invoke-virtual {v4}, Lkc0;->d()Landroid/content/SharedPreferences;

    move-result-object v7

    const/16 v2, 0x2e

    move-object/from16 v0, v17

    invoke-interface {v7, v0, v9}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const/16 v2, 0x8a

    invoke-virtual {v6, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v2, 0xf4

    iget-object v6, v4, Lkc0;->y:Landroid/widget/CheckBox;

    nop

    if-eqz v6, :cond_90d

    const/16 v2, 0x30

    invoke-virtual {v4}, Lkc0;->d()Landroid/content/SharedPreferences;

    move-result-object v7

    const/4 v10, 0x0

    const/16 v2, 0x77

    invoke-interface {v7, v11, v10}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v7

    const/16 v2, 0x7e

    invoke-virtual {v6, v7}, Landroid/widget/CompoundButton;->setChecked(Z)V

    const/16 v2, 0x90

    iget-object v6, v4, Lkc0;->z:Landroid/widget/CheckBox;

    nop

    if-eqz v6, :cond_906

    const/16 v2, 0x30

    invoke-virtual {v4}, Lkc0;->d()Landroid/content/SharedPreferences;

    move-result-object v7

    const-string/jumbo v9, "exsshserver"

    const/16 v2, 0x77

    invoke-interface {v7, v9, v10}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v7

    if-nez v7, :cond_5d4

    const/16 v2, 0x130

    iget-object v7, v4, Lkc0;->B:Landroid/widget/EditText;

    nop

    if-eqz v7, :cond_5cf

    const/16 v2, 0x2d

    invoke-virtual {v7}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v2, 0xff

    invoke-interface {v7}, Ljava/lang/CharSequence;->length()I

    move-result v7

    if-lez v7, :cond_5cd

    const/16 v2, 0x24f

    iget-object v7, v4, Lkc0;->D:Landroid/widget/EditText;

    nop

    if-eqz v7, :cond_5c8

    const/16 v2, 0x2d

    invoke-virtual {v7}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v2, 0xff

    invoke-interface {v7}, Ljava/lang/CharSequence;->length()I

    move-result v7

    if-lez v7, :cond_5cd

    goto :goto_5d4

    :cond_5c8
    const/4 v2, 0x5

    invoke-static {v14}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_5cd
    const/4 v7, 0x0

    goto :goto_5d6

    :cond_5cf
    const/4 v2, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_5d4
    :goto_5d4
    move/from16 v7, p3

    :goto_5d6
    const/16 v2, 0x7e

    invoke-virtual {v6, v7}, Landroid/widget/CompoundButton;->setChecked(Z)V

    const/16 v2, 0xa1

    iget-object v6, v4, Lkc0;->F:Landroid/widget/CheckBox;

    nop

    if-eqz v6, :cond_901

    const/16 v2, 0x30

    invoke-virtual {v4}, Lkc0;->d()Landroid/content/SharedPreferences;

    move-result-object v7

    const-string/jumbo v9, "exsshlogin"

    const/4 v10, 0x0

    const/16 v2, 0x77

    invoke-interface {v7, v9, v10}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v7

    if-nez v7, :cond_635

    const/16 v2, 0x11e

    iget-object v7, v4, Lkc0;->H:Landroid/widget/EditText;

    nop

    if-eqz v7, :cond_630

    const/16 v2, 0x2d

    invoke-virtual {v7}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v2, 0xff

    invoke-interface {v7}, Ljava/lang/CharSequence;->length()I

    move-result v7

    if-lez v7, :cond_62e

    const/16 v2, 0x230

    iget-object v7, v4, Lkc0;->J:Landroid/widget/EditText;

    nop

    if-eqz v7, :cond_627

    const/16 v2, 0x2d

    invoke-virtual {v7}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v7

    const/4 v2, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v2, 0xff

    invoke-interface {v7}, Ljava/lang/CharSequence;->length()I

    move-result v7

    if-lez v7, :cond_62e

    goto :goto_635

    :cond_627
    const/4 v2, 0x5

    move-object/from16 v0, v17

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_62e
    const/4 v7, 0x0

    goto :goto_637

    :cond_630
    const/4 v2, 0x5

    invoke-static {v15}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_635
    :goto_635
    move/from16 v7, p3

    :goto_637
    const/16 v2, 0x7e

    invoke-virtual {v6, v7}, Landroid/widget/CompoundButton;->setChecked(Z)V

    const/16 v2, 0xe6

    iget-object v6, v4, Lkc0;->L:Landroid/widget/CheckBox;

    nop

    if-eqz v6, :cond_8fc

    const/16 v2, 0x30

    invoke-virtual {v4}, Lkc0;->d()Landroid/content/SharedPreferences;

    move-result-object v7

    const/4 v10, 0x0

    const/16 v2, 0x77

    invoke-interface {v7, v8, v10}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v7

    const/16 v2, 0x7e

    invoke-virtual {v6, v7}, Landroid/widget/CompoundButton;->setChecked(Z)V

    const/16 v2, 0x23f

    iget-object v6, v4, Lkc0;->M:Landroid/widget/CheckBox;

    nop

    const-string/jumbo v7, "blockTorrent"

    if-eqz v6, :cond_8f7

    const/16 v2, 0x30

    invoke-virtual {v4}, Lkc0;->d()Landroid/content/SharedPreferences;

    move-result-object v9

    const/16 v2, 0x77

    invoke-interface {v9, v7, v10}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v9

    const/16 v2, 0x7e

    invoke-virtual {v6, v9}, Landroid/widget/CompoundButton;->setChecked(Z)V

    const/16 v2, 0x1b5

    iget-object v6, v4, Lkc0;->N:Landroid/widget/CheckBox;

    nop

    const-string/jumbo v9, "blockRootDev"

    if-eqz v6, :cond_8f2

    const/16 v2, 0x30

    invoke-virtual {v4}, Lkc0;->d()Landroid/content/SharedPreferences;

    move-result-object v13

    const/16 v2, 0x77

    invoke-interface {v13, v9, v10}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v13

    const/16 v2, 0x7e

    invoke-virtual {v6, v13}, Landroid/widget/CompoundButton;->setChecked(Z)V

    const/16 v2, 0xf4

    iget-object v6, v4, Lkc0;->y:Landroid/widget/CheckBox;

    nop

    if-eqz v6, :cond_8ed

    const/16 v2, 0x36

    invoke-virtual {v6}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v6

    const/16 v2, 0x23f

    iget-object v10, v4, Lkc0;->M:Landroid/widget/CheckBox;

    nop

    const-string/jumbo v13, "htmlspp"

    const-string/jumbo v14, "mensagem_l"

    if-eqz v6, :cond_6ec

    if-eqz v10, :cond_6e7

    const/16 v2, 0x90

    iget-object v6, v4, Lkc0;->z:Landroid/widget/CheckBox;

    nop

    if-eqz v6, :cond_6e0

    const/16 v2, 0x36

    invoke-virtual {v6}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v6

    if-eqz v6, :cond_6b8

    const/4 v6, 0x0

    goto :goto_6ba

    :cond_6b8
    const/16 v6, 0x8

    :goto_6ba
    const/4 v2, -0x5

    invoke-virtual {v10, v6}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0x1b5

    iget-object v6, v4, Lkc0;->N:Landroid/widget/CheckBox;

    nop

    if-eqz v6, :cond_6db

    const/4 v10, 0x0

    const/4 v2, -0x5

    invoke-virtual {v6, v10}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0xe6

    iget-object v6, v4, Lkc0;->L:Landroid/widget/CheckBox;

    nop

    if-eqz v6, :cond_6d6

    const/4 v2, -0x5

    invoke-virtual {v6, v10}, Landroid/view/View;->setVisibility(I)V

    goto :goto_720

    :cond_6d6
    const/4 v2, 0x5

    invoke-static {v8}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_6db
    const/4 v2, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_6e0
    const/4 v2, 0x5

    move-object/from16 v0, v19

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_6e7
    const/4 v2, 0x5

    invoke-static {v7}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_6ec
    if-eqz v10, :cond_8e8

    const/16 v6, 0x8

    const/4 v2, -0x5

    invoke-virtual {v10, v6}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0x1b5

    iget-object v10, v4, Lkc0;->N:Landroid/widget/CheckBox;

    nop

    if-eqz v10, :cond_8e3

    const/4 v2, -0x5

    invoke-virtual {v10, v6}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0xe6

    iget-object v9, v4, Lkc0;->L:Landroid/widget/CheckBox;

    nop

    if-eqz v9, :cond_8de

    const/4 v2, -0x5

    invoke-virtual {v9, v6}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0x268

    iget-object v9, v4, Lkc0;->x:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz v9, :cond_8d9

    const/4 v2, -0x5

    invoke-virtual {v9, v6}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0xce

    iget-object v9, v4, Lkc0;->R:Landroid/widget/TextView;

    nop

    if-eqz v9, :cond_8d4

    const/4 v2, -0x5

    invoke-virtual {v9, v6}, Landroid/view/View;->setVisibility(I)V

    :goto_720
    const/16 v2, 0x90

    iget-object v6, v4, Lkc0;->z:Landroid/widget/CheckBox;

    nop

    if-eqz v6, :cond_8cd

    const/16 v2, 0x36

    invoke-virtual {v6}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v6

    const/16 v2, 0x23f

    iget-object v9, v4, Lkc0;->M:Landroid/widget/CheckBox;

    nop

    const-string/jumbo v10, "sshuserpass"

    if-eqz v6, :cond_77f

    if-eqz v9, :cond_77a

    const/16 v2, 0xf4

    iget-object v6, v4, Lkc0;->y:Landroid/widget/CheckBox;

    nop

    if-eqz v6, :cond_775

    const/16 v2, 0x36

    invoke-virtual {v6}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v6

    if-eqz v6, :cond_74a

    const/4 v6, 0x0

    goto :goto_74c

    :cond_74a
    const/16 v6, 0x8

    :goto_74c
    const/4 v2, -0x5

    invoke-virtual {v9, v6}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0x494

    iget-object v6, v4, Lkc0;->A:Landroid/widget/TableLayout;

    nop

    if-eqz v6, :cond_76d

    const/4 v7, 0x0

    const/4 v2, -0x5

    invoke-virtual {v6, v7}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0xa1

    iget-object v6, v4, Lkc0;->F:Landroid/widget/CheckBox;

    nop

    if-eqz v6, :cond_768

    const/4 v2, -0x5

    invoke-virtual {v6, v7}, Landroid/view/View;->setVisibility(I)V

    goto :goto_79d

    :cond_768
    const/4 v2, 0x5

    invoke-static {v12}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_76d
    const-string/jumbo v4, "sshhostport"

    const/4 v2, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_775
    const/4 v2, 0x5

    invoke-static {v11}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_77a
    const/4 v2, 0x5

    invoke-static {v7}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_77f
    if-eqz v9, :cond_8c8

    const/16 v6, 0x8

    const/4 v2, -0x5

    invoke-virtual {v9, v6}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0x23b

    iget-object v7, v4, Lkc0;->G:Landroid/widget/LinearLayout;

    nop

    if-eqz v7, :cond_8c3

    const/4 v2, -0x5

    invoke-virtual {v7, v6}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0xa1

    iget-object v7, v4, Lkc0;->F:Landroid/widget/CheckBox;

    nop

    if-eqz v7, :cond_8be

    const/4 v2, -0x5

    invoke-virtual {v7, v6}, Landroid/view/View;->setVisibility(I)V

    :goto_79d
    const/16 v2, 0x90

    iget-object v6, v4, Lkc0;->z:Landroid/widget/CheckBox;

    nop

    if-eqz v6, :cond_8b7

    const/16 v2, 0x36

    invoke-virtual {v6}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v6

    if-eqz v6, :cond_7d2

    const/16 v2, 0xa1

    iget-object v6, v4, Lkc0;->F:Landroid/widget/CheckBox;

    nop

    if-eqz v6, :cond_7cd

    const/16 v2, 0x36

    invoke-virtual {v6}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v6

    if-eqz v6, :cond_7d2

    const/16 v2, 0x23b

    iget-object v6, v4, Lkc0;->G:Landroid/widget/LinearLayout;

    nop

    if-eqz v6, :cond_7c8

    const/4 v7, 0x0

    const/4 v2, -0x5

    invoke-virtual {v6, v7}, Landroid/view/View;->setVisibility(I)V

    goto :goto_7df

    :cond_7c8
    const/4 v2, 0x5

    invoke-static {v10}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_7cd
    const/4 v2, 0x5

    invoke-static {v12}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_7d2
    const/16 v2, 0x23b

    iget-object v6, v4, Lkc0;->G:Landroid/widget/LinearLayout;

    nop

    if-eqz v6, :cond_8b2

    const/16 v7, 0x8

    const/4 v2, -0x5

    invoke-virtual {v6, v7}, Landroid/view/View;->setVisibility(I)V

    :goto_7df
    const/16 v2, 0xf4

    iget-object v6, v4, Lkc0;->y:Landroid/widget/CheckBox;

    nop

    if-eqz v6, :cond_8ad

    const/16 v2, 0x36

    invoke-virtual {v6}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v6

    const-string/jumbo v7, "txtMsgPreviewCard"

    const-string/jumbo v9, "msgpreviewhint"

    if-eqz v6, :cond_84a

    const/16 v2, 0xe6

    iget-object v6, v4, Lkc0;->L:Landroid/widget/CheckBox;

    nop

    if-eqz v6, :cond_845

    const/16 v2, 0x36

    invoke-virtual {v6}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v6

    if-eqz v6, :cond_84a

    const/16 v2, 0x268

    iget-object v6, v4, Lkc0;->x:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz v6, :cond_840

    const/4 v10, 0x0

    const/4 v2, -0x5

    invoke-virtual {v6, v10}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0xce

    iget-object v6, v4, Lkc0;->R:Landroid/widget/TextView;

    nop

    if-eqz v6, :cond_83b

    const/4 v2, -0x5

    invoke-virtual {v6, v10}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0xfc

    iget-object v6, v4, Lkc0;->O:Landroid/widget/TextView;

    nop

    if-eqz v6, :cond_836

    const/4 v2, -0x5

    invoke-virtual {v6, v10}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0xda

    iget-object v6, v4, Lkc0;->P:Lcom/google/android/material/card/MaterialCardView;

    nop

    if-eqz v6, :cond_831

    const/4 v2, -0x5

    invoke-virtual {v6, v10}, Landroid/view/View;->setVisibility(I)V

    goto :goto_878

    :cond_831
    const/4 v2, 0x5

    invoke-static {v7}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_836
    const/4 v2, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_83b
    const/4 v2, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_840
    const/4 v2, 0x5

    invoke-static {v14}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_845
    const/4 v2, 0x5

    invoke-static {v8}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_84a
    const/16 v2, 0x268

    iget-object v6, v4, Lkc0;->x:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz v6, :cond_8a8

    const/16 v8, 0x8

    const/4 v2, -0x5

    invoke-virtual {v6, v8}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0xce

    iget-object v6, v4, Lkc0;->R:Landroid/widget/TextView;

    nop

    if-eqz v6, :cond_8a3

    const/4 v2, -0x5

    invoke-virtual {v6, v8}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0xfc

    iget-object v6, v4, Lkc0;->O:Landroid/widget/TextView;

    nop

    if-eqz v6, :cond_89e

    const/4 v2, -0x5

    invoke-virtual {v6, v8}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0xda

    iget-object v6, v4, Lkc0;->P:Lcom/google/android/material/card/MaterialCardView;

    nop

    if-eqz v6, :cond_899

    const/4 v2, -0x5

    invoke-virtual {v6, v8}, Landroid/view/View;->setVisibility(I)V

    :goto_878
    const/16 v2, 0x140

    sget-boolean v6, Lg4;->a:Z

    nop

    const/16 v2, 0xfb

    invoke-virtual {v4}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object v6

    const/4 v2, -0x6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v2, 0x30

    invoke-virtual {v4}, Lkc0;->d()Landroid/content/SharedPreferences;

    move-result-object v4

    const/4 v2, -0x6

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v2, 0x394

    invoke-static {v4, v6}, Lg4;->n(Landroid/content/SharedPreferences;Landroidx/fragment/app/l;)V

    check-cast v5, Landroid/view/View;

    return-object v5

    :cond_899
    const/4 v2, 0x5

    invoke-static {v7}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_89e
    const/4 v2, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_8a3
    const/4 v2, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_8a8
    const/4 v2, 0x5

    invoke-static {v14}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_8ad
    const/4 v2, 0x5

    invoke-static {v11}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_8b2
    const/4 v2, 0x5

    invoke-static {v10}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_8b7
    const/4 v2, 0x5

    move-object/from16 v0, v19

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_8be
    const/4 v2, 0x5

    invoke-static {v12}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_8c3
    const/4 v2, 0x5

    invoke-static {v10}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_8c8
    const/4 v2, 0x5

    invoke-static {v7}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_8cd
    const/4 v2, 0x5

    move-object/from16 v0, v19

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_8d4
    const/4 v2, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_8d9
    const/4 v2, 0x5

    invoke-static {v14}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_8de
    const/4 v2, 0x5

    invoke-static {v8}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_8e3
    const/4 v2, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_8e8
    const/4 v2, 0x5

    invoke-static {v7}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_8ed
    const/4 v2, 0x5

    invoke-static {v11}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_8f2
    const/4 v2, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_8f7
    const/4 v2, 0x5

    invoke-static {v7}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_8fc
    const/4 v2, 0x5

    invoke-static {v8}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_901
    const/4 v2, 0x5

    invoke-static {v12}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_906
    const/4 v2, 0x5

    move-object/from16 v0, v19

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_90d
    const/4 v2, 0x5

    invoke-static {v11}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_912
    const/4 v2, 0x5

    move-object/from16 v0, v17

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_919
    const/4 v2, 0x5

    invoke-static {v15}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_91e
    const/4 v2, 0x5

    invoke-static {v14}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_923
    const/4 v2, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_928
    const/4 v2, 0x5

    move-object/from16 v0, v16

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_92f
    const/4 v2, 0x5

    invoke-static {v10}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_934
    const/4 v2, 0x5

    move-object/from16 v0, v19

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_93b
    const/4 v2, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_940
    const/4 v2, 0x5

    move-object/from16 v0, v19

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_947
    const-string/jumbo v4, "txtMsgPreview"

    const/4 v2, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_94f
    const/4 v2, 0x5

    move-object/from16 v0, v16

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_956
    const/4 v2, 0x5

    invoke-static {v8}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_95b
    const/4 v2, 0x5

    invoke-static {v12}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_960
    const/4 v2, 0x5

    move-object/from16 v0, v19

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_967
    const/4 v2, 0x5

    invoke-static {v11}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_96c
    const/16 p1, 0x0

    const/4 v2, 0x5

    move-object/from16 v0, v17

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_975
    const/16 p1, 0x0

    const/4 v2, 0x5

    invoke-static {v15}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_97c
    const/16 p1, 0x0

    const/4 v2, 0x5

    invoke-static {v14}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_983
    const/16 p1, 0x0

    const/4 v2, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_98a
    const/16 p1, 0x0

    const/4 v2, 0x5

    invoke-static {v10}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_991
    const/16 p1, 0x0

    const-string/jumbo v4, "tbBtnShare"

    const/4 v2, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_99b
    const/16 p1, 0x0

    const-string/jumbo v4, "exportar"

    const/4 v2, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_9a5
    const/16 p1, 0x0

    const-string/jumbo v4, "exportdata"

    const/4 v2, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1
.end method

.method public final onDestroyView()V
    .registers 3

    const/16 v0, 0x53a

    invoke-super {p0}, Landroidx/fragment/app/g;->onDestroyView()V

    const/16 v0, 0xf5a

    invoke-virtual {p0}, Lkc0;->e()V

    return-void
.end method

.method public final onPause()V
    .registers 3

    const/16 v0, 0xbf8

    invoke-super {p0}, Landroidx/fragment/app/Fragment;->onPause()V

    const/16 v0, 0xf5a

    invoke-virtual {p0}, Lkc0;->e()V

    return-void
.end method

.method public final onRequestPermissionsResult(I[Ljava/lang/String;[I)V
    .registers 10

    .prologue
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, -0x6

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x90d

    invoke-super {p0, p1, p2, p3}, Landroidx/fragment/app/Fragment;->onRequestPermissionsResult(I[Ljava/lang/String;[I)V

    const/16 p2, 0x1cd0

    if-ne p1, p2, :cond_54

    array-length p1, p3

    const/4 p2, 0x0

    if-nez p1, :cond_17

    const/4 p1, 0x1

    goto :goto_18

    :cond_17
    move p1, p2

    :goto_18
    const-string/jumbo v2, "pdn"

    const v3, 0x7f1301f3

    if-nez p1, :cond_40

    array-length p1, p3

    :goto_21
    if-ge p2, p1, :cond_54

    aget v4, p3, p2

    const/4 v5, -0x1

    if-ne v4, v5, :cond_3d

    const/16 v0, 0x4c

    invoke-virtual {p0, v3}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x303

    invoke-virtual {p0, p1, v2}, Lkc0;->f(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v0, 0x181

    invoke-virtual {p0}, Landroidx/fragment/app/g;->dismiss()V

    return-void

    :cond_3d
    add-int/lit8 p2, p2, 0x1

    goto :goto_21

    :cond_40
    const/16 v0, 0x4c

    invoke-virtual {p0, v3}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x303

    invoke-virtual {p0, p1, v2}, Lkc0;->f(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v0, 0x181

    invoke-virtual {p0}, Landroidx/fragment/app/g;->dismiss()V

    :cond_54
    return-void
.end method

.method public final onStart()V
    .registers 6

    .prologue
    const/16 v0, 0x55f

    invoke-super {p0}, Landroidx/fragment/app/g;->onStart()V

    const/16 v0, 0xaeb

    invoke-virtual {p0}, Landroidx/fragment/app/g;->getDialog()Landroid/app/Dialog;

    move-result-object p0

    const/4 v2, 0x0

    if-eqz p0, :cond_13

    const/16 v0, 0xaa0

    invoke-virtual {p0, v2}, Landroid/app/Dialog;->setCanceledOnTouchOutside(Z)V

    :cond_13
    if-eqz p0, :cond_3b

    const/16 v0, 0xc8b

    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object p0

    if-eqz p0, :cond_3b

    const/4 v3, -0x1

    const/4 v4, -0x2

    const/16 v0, 0x1132

    invoke-virtual {p0, v3, v4}, Landroid/view/Window;->setLayout(II)V

    const/16 v0, 0x10ad

    new-instance v3, Landroid/graphics/drawable/ColorDrawable;

    nop

    const/16 v0, 0xc14

    invoke-direct {v3, v2}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    const/16 v0, 0xba3

    invoke-virtual {p0, v3}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    const v2, 0x7f140137

    const/16 v0, 0xa0d

    invoke-virtual {p0, v2}, Landroid/view/Window;->setWindowAnimations(I)V

    :cond_3b
    return-void
.end method
