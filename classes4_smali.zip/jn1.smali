.class public final synthetic Ljn1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/widget/RadioGroup$OnCheckedChangeListener;


# instance fields
.field public final synthetic a:Lnn1;

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:Ljava/lang/String;


# direct methods
.method public synthetic constructor <init>(Lnn1;Ljava/lang/String;Ljava/lang/String;)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x79b

    iput-object p1, p0, Ljn1;->a:Lnn1;

    const/16 v0, 0x5d2

    iput-object p2, p0, Ljn1;->b:Ljava/lang/String;

    const/16 v0, 0xca5

    iput-object p3, p0, Ljn1;->c:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final onCheckedChanged(Landroid/widget/RadioGroup;I)V
    .registers 7

    .prologue
    const/16 v1, 0x8b4

    const/16 v2, 0xfc5

    const/16 v3, 0xc18

    const p1, 0x7f0902dc

    if-ne p2, p1, :cond_f

    iget-object p1, p0, Ljn1;->b:Ljava/lang/String;

    nop

    goto :goto_12

    :cond_f
    iget-object p1, p0, Ljn1;->c:Ljava/lang/String;

    nop

    :goto_12
    iget-object p0, p0, Ljn1;->a:Lnn1;

    nop

    const/16 v0, 0x707

    iput-object p1, p0, Lnn1;->A:Ljava/lang/String;

    return-void
.end method
