.class public final synthetic Lk41;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/view/View$OnLongClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:I

.field public final synthetic c:Lqq1;


# direct methods
.method public synthetic constructor <init>(Lqq1;II)V
    .registers 6

    iput p3, p0, Lk41;->a:I

    iput-object p1, p0, Lk41;->c:Lqq1;

    iput p2, p0, Lk41;->b:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onLongClick(Landroid/view/View;)Z
    .registers 9

    .prologue
    const/16 v0, 0xa15

    iget p1, p0, Lk41;->a:I

    nop

    const/4 v2, 0x1

    const/16 v0, 0x882

    iget v3, p0, Lk41;->b:I

    nop

    const/16 v0, 0x62b

    iget-object p0, p0, Lk41;->c:Lqq1;

    nop

    packed-switch p1, :pswitch_data_e6

    check-cast p0, Ll12;

    const/16 v0, 0xa85

    iget-object p1, p0, Ll12;->c:Lg12;

    nop

    const/16 v0, 0x82f

    iget-object v4, p1, Lg12;->B:Ljava/util/ArrayList;

    nop

    const/16 v0, 0x44

    iget-object v5, p0, Ll12;->f:Ljava/util/ArrayList;

    nop

    const/16 v0, 0x43

    invoke-virtual {v5, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, La12;

    const/16 v0, 0x4ba

    iget-object v5, v5, La12;->a:Ljava/lang/String;

    nop

    const/16 v0, 0xef7

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    const/16 v0, 0x5b

    new-instance v4, Landroid/content/Intent;

    nop

    const/16 v0, 0xfc6

    iget-object v5, p0, Ll12;->d:Landroid/content/Context;

    nop

    const-class v6, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;

    const/16 v0, 0xd0

    invoke-direct {v4, v5, v6}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/16 v0, 0x44

    iget-object p0, p0, Ll12;->f:Ljava/util/ArrayList;

    nop

    const/16 v0, 0x43

    invoke-virtual {p0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, La12;

    const/16 v0, 0x4ba

    iget-object p0, p0, La12;->a:Ljava/lang/String;

    nop

    const-string/jumbo v3, "serverh"

    const/16 v0, 0x4b

    invoke-virtual {v4, v3, p0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    const/16 v0, 0x634

    invoke-virtual {p1, p0}, Landroidx/fragment/app/Fragment;->startActivity(Landroid/content/Intent;)V

    return v2

    :pswitch_68  #0x0
    check-cast p0, Lm41;

    const/16 v0, 0xa8d

    iget-object p0, p0, Lm41;->c:Lcom/tlsvpn/tlstunnel/ui/Logs;

    nop

    const/16 v0, 0xb7a

    sget-object p1, Lmi2;->b:Ljava/util/concurrent/CopyOnWriteArrayList;

    nop

    const/16 v0, 0xd25

    invoke-virtual {p1, v3}, Ljava/util/concurrent/CopyOnWriteArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p1, Landroid/text/Spanned;

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v3

    const-string/jumbo v4, "clipboard"

    const/16 v0, 0x31d

    invoke-virtual {v3, v4}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    const/4 v0, -0x6

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v3, Landroid/content/ClipboardManager;

    const-string/jumbo v4, "Tls Tunnel Log"

    const/16 v0, 0x703

    invoke-static {v4, p1}, Landroid/content/ClipData;->newPlainText(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;

    move-result-object p1

    const/16 v0, 0xba6

    invoke-virtual {v3, p1}, Landroid/content/ClipboardManager;->setPrimaryClip(Landroid/content/ClipData;)V

    const/16 v0, 0xfb

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object p1

    const/16 v0, 0x5b

    new-instance v3, Landroid/content/Intent;

    nop

    const-string/jumbo v4, "ssb"

    const/16 v0, 0x62

    invoke-direct {v3, v4}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const v4, 0x7f130097

    const/16 v0, 0x4c

    invoke-virtual {p0, v4}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v4

    const-string/jumbo v5, "msg"

    const/16 v0, 0x4b

    invoke-virtual {v3, v5, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v3

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p0

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/16 v0, 0x4a

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x64

    invoke-virtual {v3, p0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    const/16 v0, 0x63

    invoke-virtual {p1, p0}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    return v2

    :pswitch_data_e6
    .packed-switch 0x0
        :pswitch_68  #00000000
    .end packed-switch
.end method
