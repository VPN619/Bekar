.class public final Ll12;
.super Lqq1;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final c:Lg12;

.field public final d:Landroid/content/Context;

.field public final e:Landroid/content/res/Resources$Theme;

.field public f:Ljava/util/ArrayList;

.field public final g:Z

.field public final h:I


# direct methods
.method public constructor <init>(Lg12;Landroid/content/Context;Landroid/content/res/Resources$Theme;Ljava/util/ArrayList;ZI)V
    .registers 9

    invoke-direct {p0}, Lqq1;-><init>()V

    const/16 v0, 0x1250

    iput-object p1, p0, Ll12;->c:Lg12;

    const/16 v0, 0xebe

    iput-object p2, p0, Ll12;->d:Landroid/content/Context;

    const/16 v0, 0x6a2

    iput-object p3, p0, Ll12;->e:Landroid/content/res/Resources$Theme;

    const/16 v0, 0xcd6

    iput-object p4, p0, Ll12;->f:Ljava/util/ArrayList;

    const/16 v0, 0xe70

    iput-boolean p5, p0, Ll12;->g:Z

    const/16 v0, 0x1131

    iput p6, p0, Ll12;->h:I

    return-void
.end method


# virtual methods
.method public final a()I
    .registers 3

    const/16 v0, 0x44

    iget-object p0, p0, Ll12;->f:Ljava/util/ArrayList;

    nop

    const/16 v0, 0xac

    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result p0

    return p0
.end method

.method public final e(Lpr1;I)V
    .registers 23

    .prologue
    move-object/from16 v4, p0

    move/from16 v5, p2

    move-object/from16 v6, p1

    check-cast v6, Lk12;

    const/16 v2, 0x1090

    iget-object v7, v6, Lk12;->v:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    const/16 v2, 0x814

    iget-object v8, v6, Lk12;->B:Landroid/widget/ImageView;

    nop

    const/16 v2, 0xd0b

    iget-object v9, v6, Lk12;->C:Landroid/widget/TextView;

    nop

    const/16 v2, 0xde6

    iget-object v10, v6, Lk12;->z:Landroid/widget/ProgressBar;

    nop

    const/16 v2, 0x72f

    iget-object v11, v6, Lk12;->u:Landroid/widget/ImageView;

    nop

    const/16 v2, 0x11c7

    iget-object v12, v6, Lk12;->A:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    const/16 v2, 0xf66

    iget-object v13, v6, Lk12;->w:Landroid/widget/ImageView;

    nop

    const/16 v2, 0x44

    iget-object v14, v4, Ll12;->f:Ljava/util/ArrayList;

    nop

    const/16 v2, 0x43

    invoke-virtual {v14, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, La12;

    const/16 v2, 0x3fc

    iget v14, v14, La12;->b:I

    nop

    const/16 v2, 0x87

    invoke-virtual {v13, v14}, Landroid/widget/ImageView;->setImageResource(I)V

    const/16 v2, 0xf8b

    iget-object v13, v6, Lk12;->x:Landroid/widget/TextView;

    nop

    const/16 v2, 0x44

    iget-object v14, v4, Ll12;->f:Ljava/util/ArrayList;

    nop

    const/16 v2, 0x43

    invoke-virtual {v14, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, La12;

    const/16 v2, 0x479

    iget-object v14, v14, La12;->c:Ljava/lang/String;

    nop

    const/16 v2, 0x8a

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v2, 0x6d4

    iget-object v13, v6, Lk12;->y:Landroid/widget/TextView;

    nop

    const/16 v2, 0x44

    iget-object v14, v4, Ll12;->f:Ljava/util/ArrayList;

    nop

    const/16 v2, 0x43

    invoke-virtual {v14, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, La12;

    const/16 v2, 0x350

    iget-object v14, v14, La12;->d:Ljava/lang/String;

    nop

    const/16 v2, 0x8a

    invoke-virtual {v13, v14}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v2, 0x11ca

    iget-boolean v14, v4, Ll12;->g:Z

    nop

    const/16 v15, 0x8

    const/16 v16, 0x0

    if-eqz v14, :cond_88

    move/from16 v14, v16

    goto :goto_89

    :cond_88
    move v14, v15

    :goto_89
    const/4 v2, -0x5

    invoke-virtual {v13, v14}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0xc04

    new-instance v13, Lc12;

    nop

    add-int/lit8 v14, v5, 0x1

    const/16 v2, 0x21a

    invoke-direct {v13}, Ljava/lang/Object;-><init>()V

    const/16 v2, 0xa85

    iget-object v2, v4, Ll12;->c:Lg12;

    move-object/16 v17, v2

    const/16 v2, 0x959

    move-object/from16 v0, v17

    iput-object v0, v13, Lc12;->a:Lg12;

    const/16 v2, 0x91b

    iput v14, v13, Lc12;->b:I

    const/16 v2, 0x5f

    invoke-virtual {v7, v13}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v2, 0xa93

    new-instance v13, Ld12;

    nop

    const/16 v2, 0x44

    iget-object v2, v4, Ll12;->f:Ljava/util/ArrayList;

    move-object/16 v18, v2

    const/16 v2, 0x43

    move-object/from16 v0, v18

    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v18

    check-cast v18, La12;

    const/16 v2, 0x4ba

    move-object/from16 v0, v18

    iget-object v2, v0, La12;->a:Ljava/lang/String;

    move-object/16 v18, v2

    const/16 v2, 0x7ef

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-direct {v13, v0, v1, v14}, Ld12;-><init>(Lg12;Ljava/lang/String;I)V

    const/16 v2, 0x8f

    invoke-virtual {v7, v13}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    const/16 v2, 0x44

    iget-object v7, v4, Ll12;->f:Ljava/util/ArrayList;

    nop

    const/16 v2, 0x43

    invoke-virtual {v7, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La12;

    const/16 v2, 0x3b6

    iget-boolean v7, v7, La12;->l:Z

    nop

    const v13, 0x7f0402ae

    const v14, 0x7f0402af

    const/16 v2, 0x9dc

    iget-object v2, v4, Ll12;->e:Landroid/content/res/Resources$Theme;

    move-object/16 v18, v2

    const/16 v19, 0x1

    if-eqz v7, :cond_12a

    const/16 v2, 0xd5

    new-instance v7, Landroid/util/TypedValue;

    nop

    const/16 v2, 0xe7

    invoke-direct {v7}, Landroid/util/TypedValue;-><init>()V

    const/16 v2, 0x68

    move-object/from16 v0, v18

    move/from16 v1, v19

    invoke-virtual {v0, v14, v7, v1}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    const/16 v2, 0x9b

    iget v7, v7, Landroid/util/TypedValue;->data:I

    nop

    const/16 v2, 0x171

    invoke-static {v7}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v7

    const/16 v2, 0x172

    invoke-virtual {v11, v7}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    const/16 v2, 0x23d

    move/from16 v0, v16

    invoke-virtual {v11, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    goto :goto_16e

    :cond_12a
    const/16 v2, 0x44

    iget-object v7, v4, Ll12;->f:Ljava/util/ArrayList;

    nop

    const/16 v2, 0x43

    invoke-virtual {v7, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La12;

    const/16 v2, 0x355

    iget-boolean v7, v7, La12;->k:Z

    nop

    if-eqz v7, :cond_169

    const/16 v2, 0xd5

    new-instance v7, Landroid/util/TypedValue;

    nop

    const/16 v2, 0xe7

    invoke-direct {v7}, Landroid/util/TypedValue;-><init>()V

    const/16 v2, 0x68

    move-object/from16 v0, v18

    move/from16 v1, v19

    invoke-virtual {v0, v13, v7, v1}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    const/16 v2, 0x9b

    iget v7, v7, Landroid/util/TypedValue;->data:I

    nop

    const/16 v2, 0x171

    invoke-static {v7}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v7

    const/16 v2, 0x172

    invoke-virtual {v11, v7}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    const/16 v2, 0x23d

    move/from16 v0, v16

    invoke-virtual {v11, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    goto :goto_16e

    :cond_169
    const/16 v2, 0x23d

    invoke-virtual {v11, v15}, Landroid/widget/ImageView;->setVisibility(I)V

    :goto_16e
    const/16 v2, 0x44

    iget-object v7, v4, Ll12;->f:Ljava/util/ArrayList;

    nop

    const/16 v2, 0x43

    invoke-virtual {v7, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, La12;

    const/16 v2, 0x530

    iget-boolean v7, v7, La12;->h:Z

    nop

    if-eqz v7, :cond_194

    const/16 v2, 0x483

    move/from16 v0, v19

    invoke-virtual {v10, v0}, Landroid/widget/ProgressBar;->setIndeterminate(Z)V

    const/4 v2, -0x5

    move/from16 v0, v16

    invoke-virtual {v10, v0}, Landroid/view/View;->setVisibility(I)V

    const/4 v2, -0x5

    invoke-virtual {v12, v15}, Landroid/view/View;->setVisibility(I)V

    return-void

    :cond_194
    const/16 v2, 0xd5

    new-instance v7, Landroid/util/TypedValue;

    nop

    const/16 v2, 0xe7

    invoke-direct {v7}, Landroid/util/TypedValue;-><init>()V

    const/16 v2, 0xd5

    new-instance v11, Landroid/util/TypedValue;

    nop

    const/16 v2, 0xe7

    invoke-direct {v11}, Landroid/util/TypedValue;-><init>()V

    const/16 v2, 0xd5

    new-instance v13, Landroid/util/TypedValue;

    nop

    const/16 v2, 0xe7

    invoke-direct {v13}, Landroid/util/TypedValue;-><init>()V

    const/16 v2, 0x483

    move/from16 v0, v16

    invoke-virtual {v10, v0}, Landroid/widget/ProgressBar;->setIndeterminate(Z)V

    const/4 v2, -0x5

    invoke-virtual {v10, v15}, Landroid/view/View;->setVisibility(I)V

    const/4 v2, -0x5

    move/from16 v0, v16

    invoke-virtual {v12, v0}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0x44

    iget-object v10, v4, Ll12;->f:Ljava/util/ArrayList;

    nop

    const/16 v2, 0x43

    invoke-virtual {v10, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, La12;

    const/16 v2, 0x2af

    iget-boolean v10, v10, La12;->i:Z

    nop

    const v15, 0x7f040117

    if-eqz v10, :cond_23d

    const/16 v2, 0x68

    move-object/from16 v0, v18

    move/from16 v1, v19

    invoke-virtual {v0, v15, v7, v1}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    const/16 v2, 0x68

    move-object/from16 v0, v18

    move/from16 v1, v19

    invoke-virtual {v0, v15, v13, v1}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    const/16 v2, 0xefe

    invoke-virtual {v11, v7}, Landroid/util/TypedValue;->setTo(Landroid/util/TypedValue;)V

    const v10, 0x7f1300cd

    const/16 v2, 0x93

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setText(I)V

    const v10, 0x7f080115

    const/16 v2, 0x87

    invoke-virtual {v8, v10}, Landroid/widget/ImageView;->setImageResource(I)V

    const/16 v2, 0xf7

    move/from16 v0, v19

    invoke-virtual {v12, v0}, Landroid/view/View;->setEnabled(Z)V

    const/16 v2, 0xed

    move/from16 v0, v19

    invoke-virtual {v12, v0}, Landroid/view/View;->setClickable(Z)V

    const/16 v2, 0xcc

    move/from16 v0, v19

    invoke-virtual {v12, v0}, Landroid/view/View;->setLongClickable(Z)V

    const/16 v2, 0xd8

    move/from16 v0, v19

    invoke-virtual {v12, v0}, Landroid/view/View;->setFocusable(Z)V

    const/16 v2, 0x664

    new-instance v10, Lh12;

    nop

    const/16 v2, 0x104a

    invoke-direct {v10, v4, v5, v6}, Lh12;-><init>(Ll12;ILk12;)V

    const/16 v2, 0x5f

    invoke-virtual {v12, v10}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v2, 0x656

    new-instance v10, Li12;

    nop

    const/16 v2, 0xfea

    invoke-direct {v10, v4, v5, v6}, Li12;-><init>(Ll12;ILk12;)V

    const/16 v2, 0x8f

    invoke-virtual {v12, v10}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    goto/16 :goto_38b

    :cond_23d
    const/16 v2, 0x44

    iget-object v10, v4, Ll12;->f:Ljava/util/ArrayList;

    nop

    const/16 v2, 0x43

    invoke-virtual {v10, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, La12;

    const/16 v2, 0x36b

    iget-object v10, v10, La12;->e:Ljava/lang/String;

    nop

    const/16 v2, 0x8a

    invoke-virtual {v9, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const v10, 0x7f04029c

    const/16 v2, 0x68

    move-object/from16 v0, v18

    move/from16 v1, v19

    invoke-virtual {v0, v10, v7, v1}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    const/16 v2, 0x44

    iget-object v10, v4, Ll12;->f:Ljava/util/ArrayList;

    nop

    const/16 v2, 0x43

    invoke-virtual {v10, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, La12;

    const/16 v2, 0x4fd

    iget v10, v10, La12;->f:I

    nop

    const/4 v15, 0x2

    move/from16 v0, v19

    if-eq v10, v0, :cond_288

    if-eq v10, v15, :cond_284

    const/4 v14, 0x3

    if-eq v10, v14, :cond_280

    const v10, 0x7f040117

    goto :goto_28b

    :cond_280
    const v10, 0x7f0402b2

    goto :goto_28b

    :cond_284
    const v10, 0x7f0402b3

    goto :goto_28b

    :cond_288
    const v10, 0x7f0402af

    :goto_28b
    const/16 v2, 0x68

    move-object/from16 v0, v18

    move/from16 v1, v19

    invoke-virtual {v0, v10, v13, v1}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    const/16 v2, 0x101

    sget-boolean v10, Lmi2;->n:Z

    nop

    if-nez v10, :cond_353

    const/16 v2, 0x1b1

    move-object/from16 v0, v17

    iget-boolean v10, v0, Lg12;->r:Z

    nop

    if-eqz v10, :cond_2a6

    goto/16 :goto_353

    :cond_2a6
    const/16 v2, 0xa59

    new-instance v10, Lj12;

    nop

    const/16 v2, 0x111b

    invoke-direct {v10, v4, v5}, Lj12;-><init>(Ll12;I)V

    const/16 v2, 0x5f

    invoke-virtual {v12, v10}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v2, 0x1187

    new-instance v10, Lk41;

    nop

    const/16 v2, 0xe10

    move/from16 v0, v19

    invoke-direct {v10, v4, v5, v0}, Lk41;-><init>(Lqq1;II)V

    const/16 v2, 0x8f

    invoke-virtual {v12, v10}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    const v10, 0x7f08010f

    const/16 v2, 0x87

    invoke-virtual {v8, v10}, Landroid/widget/ImageView;->setImageResource(I)V

    const/16 v2, 0x44

    iget-object v4, v4, Ll12;->f:Ljava/util/ArrayList;

    nop

    const/16 v2, 0x43

    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La12;

    const/16 v2, 0x29b

    iget v4, v4, La12;->g:I

    nop

    if-eqz v4, :cond_32c

    move/from16 v0, v19

    if-eq v4, v0, :cond_30c

    if-eq v4, v15, :cond_2ec

    :goto_2e8
    const v4, 0x7f0402af

    goto :goto_349

    :cond_2ec
    const/16 v2, 0xf7

    move/from16 v0, v16

    invoke-virtual {v12, v0}, Landroid/view/View;->setEnabled(Z)V

    const/16 v2, 0xed

    move/from16 v0, v16

    invoke-virtual {v12, v0}, Landroid/view/View;->setClickable(Z)V

    const/16 v2, 0xcc

    move/from16 v0, v16

    invoke-virtual {v12, v0}, Landroid/view/View;->setLongClickable(Z)V

    const/16 v2, 0xd8

    move/from16 v0, v16

    invoke-virtual {v12, v0}, Landroid/view/View;->setFocusable(Z)V

    const v4, 0x7f040116

    goto :goto_349

    :cond_30c
    const/16 v2, 0xf7

    move/from16 v0, v19

    invoke-virtual {v12, v0}, Landroid/view/View;->setEnabled(Z)V

    const/16 v2, 0xed

    move/from16 v0, v19

    invoke-virtual {v12, v0}, Landroid/view/View;->setClickable(Z)V

    const/16 v2, 0xcc

    move/from16 v0, v19

    invoke-virtual {v12, v0}, Landroid/view/View;->setLongClickable(Z)V

    const/16 v2, 0xd8

    move/from16 v0, v19

    invoke-virtual {v12, v0}, Landroid/view/View;->setFocusable(Z)V

    const v4, 0x7f0402ae

    goto :goto_349

    :cond_32c
    const/16 v2, 0xf7

    move/from16 v0, v19

    invoke-virtual {v12, v0}, Landroid/view/View;->setEnabled(Z)V

    const/16 v2, 0xed

    move/from16 v0, v19

    invoke-virtual {v12, v0}, Landroid/view/View;->setClickable(Z)V

    const/16 v2, 0xcc

    move/from16 v0, v19

    invoke-virtual {v12, v0}, Landroid/view/View;->setLongClickable(Z)V

    const/16 v2, 0xd8

    move/from16 v0, v19

    invoke-virtual {v12, v0}, Landroid/view/View;->setFocusable(Z)V

    goto :goto_2e8

    :goto_349
    const/16 v2, 0x68

    move-object/from16 v0, v18

    move/from16 v1, v19

    invoke-virtual {v0, v4, v11, v1}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    goto :goto_38b

    :cond_353
    :goto_353
    const/16 v2, 0xf7

    move/from16 v0, v16

    invoke-virtual {v12, v0}, Landroid/view/View;->setEnabled(Z)V

    const/16 v2, 0xed

    move/from16 v0, v16

    invoke-virtual {v12, v0}, Landroid/view/View;->setClickable(Z)V

    const/16 v2, 0xcc

    move/from16 v0, v16

    invoke-virtual {v12, v0}, Landroid/view/View;->setLongClickable(Z)V

    const/16 v2, 0xd8

    move/from16 v0, v16

    invoke-virtual {v12, v0}, Landroid/view/View;->setFocusable(Z)V

    const v4, 0x7f0800fe

    const/16 v2, 0x87

    invoke-virtual {v8, v4}, Landroid/widget/ImageView;->setImageResource(I)V

    const v4, 0x7f130265

    const/16 v2, 0x93

    invoke-virtual {v9, v4}, Landroid/widget/TextView;->setText(I)V

    const v4, 0x7f0402af

    const/16 v2, 0x68

    move-object/from16 v0, v18

    move/from16 v1, v19

    invoke-virtual {v0, v4, v11, v1}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    :goto_38b
    const/16 v2, 0x9b

    iget v4, v7, Landroid/util/TypedValue;->data:I

    nop

    const/16 v2, 0xfb8

    invoke-virtual {v9, v4}, Landroid/widget/TextView;->setTextColor(I)V

    const/16 v2, 0x6e8

    iget-object v4, v6, Lk12;->D:Lcom/google/android/material/card/MaterialCardView;

    nop

    const/16 v2, 0x9b

    iget v5, v7, Landroid/util/TypedValue;->data:I

    nop

    const/16 v2, 0x7e2

    invoke-virtual {v4, v5}, Lcom/google/android/material/card/MaterialCardView;->setStrokeColor(I)V

    const/16 v2, 0x9b

    iget v4, v11, Landroid/util/TypedValue;->data:I

    nop

    const/16 v2, 0x171

    invoke-static {v4}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v4

    const/16 v2, 0x172

    invoke-virtual {v8, v4}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    const/16 v2, 0x5b0

    iget-object v4, v6, Lk12;->E:Landroid/widget/ImageView;

    nop

    const/16 v2, 0x9b

    iget v5, v13, Landroid/util/TypedValue;->data:I

    nop

    const/16 v2, 0x171

    invoke-static {v5}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v5

    const/16 v2, 0x172

    invoke-virtual {v4, v5}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    return-void
.end method

.method public final f(Landroid/view/ViewGroup;I)Lpr1;
    .registers 6

    const/16 v0, 0xee7

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p0

    const/16 v0, 0x8f9

    invoke-static {p0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object p0

    const p2, 0x7f0c00d0

    const/4 v2, 0x0

    const/16 v0, 0x107b

    invoke-virtual {p0, p2, p1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p0

    const/16 v0, 0x968

    new-instance p1, Lk12;

    nop

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xf1b

    invoke-direct {p1, p0}, Lk12;-><init>(Landroid/view/View;)V

    check-cast p1, Lpr1;

    return-object p1
.end method
