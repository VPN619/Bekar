.class public final Lc4;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public final synthetic t:I

.field public final synthetic u:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Lvx;I)V
    .registers 6

    iput p3, p0, Lc4;->t:I

    iput-object p1, p0, Lc4;->u:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 6

    .prologue
    const/16 v0, 0x1078

    iget p2, p0, Lc4;->t:I

    nop

    const/16 v0, 0x20

    iget-object p0, p0, Lc4;->u:Ljava/lang/Object;

    nop

    packed-switch p2, :pswitch_data_19e

    const/16 v0, 0x23

    new-instance p2, Lc4;

    nop

    check-cast p0, Lads_mobile_sdk/xi;

    const/16 v2, 0x17

    const/16 v0, 0x22

    invoke-direct {p2, p0, p1, v2}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_1e  #0x16
    const/16 v0, 0x23

    new-instance p2, Lc4;

    nop

    check-cast p0, Lads_mobile_sdk/b90;

    const/16 v2, 0x16

    const/16 v0, 0x22

    invoke-direct {p2, p0, p1, v2}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_2f  #0x15
    const/16 v0, 0x23

    new-instance p2, Lc4;

    nop

    check-cast p0, Lads_mobile_sdk/t70;

    const/16 v2, 0x15

    const/16 v0, 0x22

    invoke-direct {p2, p0, p1, v2}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_40  #0x14
    const/16 v0, 0x23

    new-instance p2, Lc4;

    nop

    check-cast p0, Lads_mobile_sdk/xa2;

    const/16 v2, 0x14

    const/16 v0, 0x22

    invoke-direct {p2, p0, p1, v2}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_51  #0x13
    const/16 v0, 0x23

    new-instance p2, Lc4;

    nop

    check-cast p0, Lads_mobile_sdk/ur0;

    const/16 v2, 0x13

    const/16 v0, 0x22

    invoke-direct {p2, p0, p1, v2}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_62  #0x12
    const/16 v0, 0x23

    new-instance p2, Lc4;

    nop

    check-cast p0, Lads_mobile_sdk/u30;

    const/16 v2, 0x12

    const/16 v0, 0x22

    invoke-direct {p2, p0, p1, v2}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_73  #0x11
    const/16 v0, 0x23

    new-instance p2, Lc4;

    nop

    check-cast p0, Lads_mobile_sdk/v82;

    const/16 v2, 0x11

    const/16 v0, 0x22

    invoke-direct {p2, p0, p1, v2}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_84  #0x10
    const/16 v0, 0x23

    new-instance p2, Lc4;

    nop

    check-cast p0, Lut;

    const/16 v2, 0x10

    const/16 v0, 0x22

    invoke-direct {p2, p0, p1, v2}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_95  #0xf
    const/16 v0, 0x23

    new-instance p2, Lc4;

    nop

    check-cast p0, Landroid/app/Application;

    const/16 v2, 0xf

    const/16 v0, 0x22

    invoke-direct {p2, p0, p1, v2}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_a6  #0xe
    const/16 v0, 0x23

    new-instance p2, Lc4;

    nop

    check-cast p0, Lads_mobile_sdk/eo;

    const/16 v2, 0xe

    const/16 v0, 0x22

    invoke-direct {p2, p0, p1, v2}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_b7  #0xd
    const/16 v0, 0x23

    new-instance p2, Lc4;

    nop

    check-cast p0, Lads_mobile_sdk/qf2;

    const/16 v2, 0xd

    const/16 v0, 0x22

    invoke-direct {p2, p0, p1, v2}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_c8  #0xc
    const/16 v0, 0x23

    new-instance p2, Lc4;

    nop

    check-cast p0, Lads_mobile_sdk/vz;

    const/16 v2, 0xc

    const/16 v0, 0x22

    invoke-direct {p2, p0, p1, v2}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_d9  #0xb
    const/16 v0, 0x23

    new-instance p2, Lc4;

    nop

    check-cast p0, Lads_mobile_sdk/rf1;

    const/16 v2, 0xb

    const/16 v0, 0x22

    invoke-direct {p2, p0, p1, v2}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_ea  #0xa
    const/16 v0, 0x23

    new-instance p2, Lc4;

    nop

    check-cast p0, Lads_mobile_sdk/s52;

    const/16 v2, 0xa

    const/16 v0, 0x22

    invoke-direct {p2, p0, p1, v2}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_fb  #0x9
    const/16 v0, 0x23

    new-instance p2, Lc4;

    nop

    check-cast p0, Lads_mobile_sdk/l23;

    const/16 v2, 0x9

    const/16 v0, 0x22

    invoke-direct {p2, p0, p1, v2}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_10c  #0x8
    const/16 v0, 0x23

    new-instance p2, Lc4;

    nop

    check-cast p0, Lads_mobile_sdk/ia1;

    const/16 v2, 0x8

    const/16 v0, 0x22

    invoke-direct {p2, p0, p1, v2}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_11d  #0x7
    const/16 v0, 0x23

    new-instance p2, Lc4;

    nop

    check-cast p0, Lads_mobile_sdk/h01;

    const/4 v2, 0x7

    const/16 v0, 0x22

    invoke-direct {p2, p0, p1, v2}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_12d  #0x6
    const/16 v0, 0x23

    new-instance p2, Lc4;

    nop

    check-cast p0, Lads_mobile_sdk/fe3;

    const/4 v2, 0x6

    const/16 v0, 0x22

    invoke-direct {p2, p0, p1, v2}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_13d  #0x5
    const/16 v0, 0x23

    new-instance p2, Lc4;

    nop

    check-cast p0, Lads_mobile_sdk/d90;

    const/4 v2, 0x5

    const/16 v0, 0x22

    invoke-direct {p2, p0, p1, v2}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_14d  #0x4
    const/16 v0, 0x23

    new-instance p2, Lc4;

    nop

    check-cast p0, Ll13;

    const/4 v2, 0x4

    const/16 v0, 0x22

    invoke-direct {p2, p0, p1, v2}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_15d  #0x3
    const/16 v0, 0x23

    new-instance p2, Lc4;

    nop

    check-cast p0, Lads_mobile_sdk/bz0;

    const/4 v2, 0x3

    const/16 v0, 0x22

    invoke-direct {p2, p0, p1, v2}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_16d  #0x2
    const/16 v0, 0x23

    new-instance p2, Lc4;

    nop

    check-cast p0, Lvq2;

    const/4 v2, 0x2

    const/16 v0, 0x22

    invoke-direct {p2, p0, p1, v2}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_17d  #0x1
    const/16 v0, 0x23

    new-instance p2, Lc4;

    nop

    check-cast p0, Lrd;

    const/4 v2, 0x1

    const/16 v0, 0x22

    invoke-direct {p2, p0, p1, v2}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_18d  #0x0
    const/16 v0, 0x23

    new-instance p2, Lc4;

    nop

    check-cast p0, Landroid/content/Context;

    const/4 v2, 0x0

    const/16 v0, 0x22

    invoke-direct {p2, p0, p1, v2}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    nop

    :pswitch_data_19e
    .packed-switch 0x0
        :pswitch_18d  #00000000
        :pswitch_17d  #00000001
        :pswitch_16d  #00000002
        :pswitch_15d  #00000003
        :pswitch_14d  #00000004
        :pswitch_13d  #00000005
        :pswitch_12d  #00000006
        :pswitch_11d  #00000007
        :pswitch_10c  #00000008
        :pswitch_fb  #00000009
        :pswitch_ea  #0000000a
        :pswitch_d9  #0000000b
        :pswitch_c8  #0000000c
        :pswitch_b7  #0000000d
        :pswitch_a6  #0000000e
        :pswitch_95  #0000000f
        :pswitch_84  #00000010
        :pswitch_73  #00000011
        :pswitch_62  #00000012
        :pswitch_51  #00000013
        :pswitch_40  #00000014
        :pswitch_2f  #00000015
        :pswitch_1e  #00000016
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 8

    .prologue
    const/16 v0, 0x1078

    iget v2, p0, Lc4;->t:I

    nop

    const/16 v0, 0x20

    iget-object v3, p0, Lc4;->u:Ljava/lang/Object;

    nop

    const/16 v0, 0x21

    sget-object v4, Lrg2;->a:Lrg2;

    nop

    packed-switch v2, :pswitch_data_260

    check-cast p1, Lads_mobile_sdk/xi;

    check-cast p2, Lvx;

    const/16 v0, 0x23

    new-instance p0, Lc4;

    nop

    check-cast v3, Lads_mobile_sdk/xi;

    const/16 p1, 0x17

    const/16 v0, 0x22

    invoke-direct {p0, v3, p2, p1}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    const/4 v0, 0x6

    invoke-static {v4}, Lt12;->W(Ljava/lang/Object;)V

    return-object v3

    :pswitch_29  #0x16
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    const/16 v0, 0x23

    new-instance p0, Lc4;

    nop

    check-cast v3, Lads_mobile_sdk/b90;

    const/16 p1, 0x16

    const/16 v0, 0x22

    invoke-direct {p0, v3, p2, p1}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    const/16 v0, 0x26

    invoke-virtual {p0, v4}, Lc4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v4, Ljava/lang/Object;

    return-object v4

    :pswitch_43  #0x15
    check-cast p1, Lads_mobile_sdk/t70;

    check-cast p2, Lvx;

    const/16 v0, 0x23

    new-instance p0, Lc4;

    nop

    check-cast v3, Lads_mobile_sdk/t70;

    const/16 p1, 0x15

    const/16 v0, 0x22

    invoke-direct {p0, v3, p2, p1}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    const/4 v0, 0x6

    invoke-static {v4}, Lt12;->W(Ljava/lang/Object;)V

    return-object v3

    :pswitch_5a  #0x14
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    const/16 v0, 0x23

    new-instance p0, Lc4;

    nop

    check-cast v3, Lads_mobile_sdk/xa2;

    const/16 p1, 0x14

    const/16 v0, 0x22

    invoke-direct {p0, v3, p2, p1}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    const/16 v0, 0x26

    invoke-virtual {p0, v4}, Lc4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v4, Ljava/lang/Object;

    return-object v4

    :pswitch_74  #0x13
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    const/16 v0, 0x23

    new-instance p0, Lc4;

    nop

    check-cast v3, Lads_mobile_sdk/ur0;

    const/16 p1, 0x13

    const/16 v0, 0x22

    invoke-direct {p0, v3, p2, p1}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    const/16 v0, 0x26

    invoke-virtual {p0, v4}, Lc4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v4, Ljava/lang/Object;

    return-object v4

    :pswitch_8e  #0x12
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    const/16 v0, 0x23

    new-instance p0, Lc4;

    nop

    check-cast v3, Lads_mobile_sdk/u30;

    const/16 p1, 0x12

    const/16 v0, 0x22

    invoke-direct {p0, v3, p2, p1}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    const/16 v0, 0x26

    invoke-virtual {p0, v4}, Lc4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v4, Ljava/lang/Object;

    return-object v4

    :pswitch_a8  #0x11
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    const/16 v0, 0x23

    new-instance p0, Lc4;

    nop

    check-cast v3, Lads_mobile_sdk/v82;

    const/16 p1, 0x11

    const/16 v0, 0x22

    invoke-direct {p0, v3, p2, p1}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    const/16 v0, 0x26

    invoke-virtual {p0, v4}, Lc4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_c1  #0x10
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    const/16 v0, 0x23

    new-instance p0, Lc4;

    nop

    check-cast v3, Lut;

    const/16 p1, 0x10

    const/16 v0, 0x22

    invoke-direct {p0, v3, p2, p1}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    const/16 v0, 0x26

    invoke-virtual {p0, v4}, Lc4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v4, Ljava/lang/Object;

    return-object v4

    :pswitch_db  #0xf
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    const/16 v0, 0x23

    new-instance p0, Lc4;

    nop

    check-cast v3, Landroid/app/Application;

    const/16 p1, 0xf

    const/16 v0, 0x22

    invoke-direct {p0, v3, p2, p1}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    const/16 v0, 0x26

    invoke-virtual {p0, v4}, Lc4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v4, Ljava/lang/Object;

    return-object v4

    :pswitch_f5  #0xe
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    const/16 v0, 0x23

    new-instance p0, Lc4;

    nop

    check-cast v3, Lads_mobile_sdk/eo;

    const/16 p1, 0xe

    const/16 v0, 0x22

    invoke-direct {p0, v3, p2, p1}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    const/16 v0, 0x26

    invoke-virtual {p0, v4}, Lc4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v4, Ljava/lang/Object;

    return-object v4

    :pswitch_10f  #0xd
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    const/16 v0, 0x23

    new-instance p0, Lc4;

    nop

    check-cast v3, Lads_mobile_sdk/qf2;

    const/16 p1, 0xd

    const/16 v0, 0x22

    invoke-direct {p0, v3, p2, p1}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    const/16 v0, 0x26

    invoke-virtual {p0, v4}, Lc4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v4, Ljava/lang/Object;

    return-object v4

    :pswitch_129  #0xc
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    const/16 v0, 0x23

    new-instance p0, Lc4;

    nop

    check-cast v3, Lads_mobile_sdk/vz;

    const/16 p1, 0xc

    const/16 v0, 0x22

    invoke-direct {p0, v3, p2, p1}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    const/16 v0, 0x26

    invoke-virtual {p0, v4}, Lc4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v4, Ljava/lang/Object;

    return-object v4

    :pswitch_143  #0xb
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    const/16 v0, 0x23

    new-instance p0, Lc4;

    nop

    check-cast v3, Lads_mobile_sdk/rf1;

    const/16 p1, 0xb

    const/16 v0, 0x22

    invoke-direct {p0, v3, p2, p1}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    const/16 v0, 0x26

    invoke-virtual {p0, v4}, Lc4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v4, Ljava/lang/Object;

    return-object v4

    :pswitch_15d  #0xa
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    const/16 v0, 0x23

    new-instance p0, Lc4;

    nop

    check-cast v3, Lads_mobile_sdk/s52;

    const/16 p1, 0xa

    const/16 v0, 0x22

    invoke-direct {p0, v3, p2, p1}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    const/16 v0, 0x26

    invoke-virtual {p0, v4}, Lc4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v4, Ljava/lang/Object;

    return-object v4

    :pswitch_177  #0x9
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    const/16 v0, 0x23

    new-instance p0, Lc4;

    nop

    check-cast v3, Lads_mobile_sdk/l23;

    const/16 p1, 0x9

    const/16 v0, 0x22

    invoke-direct {p0, v3, p2, p1}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    const/16 v0, 0x26

    invoke-virtual {p0, v4}, Lc4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v4, Ljava/lang/Object;

    return-object v4

    :pswitch_191  #0x8
    check-cast p1, Lads_mobile_sdk/ia1;

    check-cast p2, Lvx;

    const/16 v0, 0x23

    new-instance p0, Lc4;

    nop

    check-cast v3, Lads_mobile_sdk/ia1;

    const/16 p1, 0x8

    const/16 v0, 0x22

    invoke-direct {p0, v3, p2, p1}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    const/4 v0, 0x6

    invoke-static {v4}, Lt12;->W(Ljava/lang/Object;)V

    return-object v3

    :pswitch_1a8  #0x7
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    const/16 v0, 0x23

    new-instance p0, Lc4;

    nop

    check-cast v3, Lads_mobile_sdk/h01;

    const/4 p1, 0x7

    const/16 v0, 0x22

    invoke-direct {p0, v3, p2, p1}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    const/16 v0, 0x26

    invoke-virtual {p0, v4}, Lc4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v4, Ljava/lang/Object;

    return-object v4

    :pswitch_1c1  #0x6
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    const/16 v0, 0x23

    new-instance p0, Lc4;

    nop

    check-cast v3, Lads_mobile_sdk/fe3;

    const/4 p1, 0x6

    const/16 v0, 0x22

    invoke-direct {p0, v3, p2, p1}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    const/16 v0, 0x26

    invoke-virtual {p0, v4}, Lc4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v4, Ljava/lang/Object;

    return-object v4

    :pswitch_1da  #0x5
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    const/16 v0, 0x23

    new-instance p0, Lc4;

    nop

    check-cast v3, Lads_mobile_sdk/d90;

    const/4 p1, 0x5

    const/16 v0, 0x22

    invoke-direct {p0, v3, p2, p1}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    const/16 v0, 0x26

    invoke-virtual {p0, v4}, Lc4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v4, Ljava/lang/Object;

    return-object v4

    :pswitch_1f3  #0x4
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    const/16 v0, 0x23

    new-instance p0, Lc4;

    nop

    check-cast v3, Ll13;

    const/4 p1, 0x4

    const/16 v0, 0x22

    invoke-direct {p0, v3, p2, p1}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    const/16 v0, 0x26

    invoke-virtual {p0, v4}, Lc4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v4, Ljava/lang/Object;

    return-object v4

    :pswitch_20c  #0x3
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    const/16 v0, 0x23

    new-instance p0, Lc4;

    nop

    check-cast v3, Lads_mobile_sdk/bz0;

    const/4 p1, 0x3

    const/16 v0, 0x22

    invoke-direct {p0, v3, p2, p1}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    const/16 v0, 0x26

    invoke-virtual {p0, v4}, Lc4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v4, Ljava/lang/Object;

    return-object v4

    :pswitch_225  #0x2
    check-cast p1, Lcx;

    check-cast p2, Lvx;

    const/16 v0, 0x1de

    invoke-virtual {p0, p2, p1}, Lc4;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lc4;

    const/16 v0, 0x26

    invoke-virtual {p0, v4}, Lc4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v4, Ljava/lang/Object;

    return-object v4

    :pswitch_239  #0x1
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    const/16 v0, 0x1de

    invoke-virtual {p0, p2, p1}, Lc4;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lc4;

    const/16 v0, 0x26

    invoke-virtual {p0, v4}, Lc4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_24c  #0x0
    check-cast p1, Lvy;

    check-cast p2, Lvx;

    const/16 v0, 0x1de

    invoke-virtual {p0, p2, p1}, Lc4;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lc4;

    const/16 v0, 0x26

    invoke-virtual {p0, v4}, Lc4;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v4, Ljava/lang/Object;

    return-object v4

    :pswitch_data_260
    .packed-switch 0x0
        :pswitch_24c  #00000000
        :pswitch_239  #00000001
        :pswitch_225  #00000002
        :pswitch_20c  #00000003
        :pswitch_1f3  #00000004
        :pswitch_1da  #00000005
        :pswitch_1c1  #00000006
        :pswitch_1a8  #00000007
        :pswitch_191  #00000008
        :pswitch_177  #00000009
        :pswitch_15d  #0000000a
        :pswitch_143  #0000000b
        :pswitch_129  #0000000c
        :pswitch_10f  #0000000d
        :pswitch_f5  #0000000e
        :pswitch_db  #0000000f
        :pswitch_c1  #00000010
        :pswitch_a8  #00000011
        :pswitch_8e  #00000012
        :pswitch_74  #00000013
        :pswitch_5a  #00000014
        :pswitch_43  #00000015
        :pswitch_29  #00000016
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 31

    .prologue
    move-object/from16 v11, p0

    const/16 v9, 0x1078

    iget v12, v11, Lc4;->t:I

    nop

    const/4 v13, 0x6

    const/4 v14, 0x2

    const/4 v15, 0x3

    const/16 v16, 0x0

    const/16 v17, 0x1

    const/16 v18, 0x0

    packed-switch v12, :pswitch_data_b32

    const/4 v9, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v9, 0x20

    iget-object v11, v11, Lc4;->u:Ljava/lang/Object;

    nop

    check-cast v11, Lads_mobile_sdk/xi;

    return-object v11

    :pswitch_21  #0x16
    const/4 v9, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v9, 0x20

    iget-object v11, v11, Lc4;->u:Ljava/lang/Object;

    nop

    check-cast v11, Lads_mobile_sdk/b90;

    const/16 v9, 0x485

    iget-object v12, v11, Lads_mobile_sdk/b90;->a:Landroid/content/Context;

    nop

    const/16 v9, 0x4d3

    iget-object v13, v11, Lads_mobile_sdk/b90;->e:Lec;

    nop

    if-eqz v13, :cond_3b

    goto :goto_58

    :cond_3b
    const/16 v9, 0x420

    invoke-static {v12}, Lec;->D(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v13

    if-nez v13, :cond_44

    goto :goto_58

    :cond_44
    const/16 v9, 0x4a

    invoke-virtual {v12}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v14

    const/16 v9, 0x128

    invoke-virtual {v13, v14}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v14

    if-eqz v14, :cond_53

    goto :goto_58

    :cond_53
    const/16 v9, 0x47b

    invoke-static {v12, v13, v11}, Lec;->f(Landroid/content/Context;Ljava/lang/String;Lg00;)V

    :goto_58
    const/16 v9, 0x21

    sget-object v11, Lrg2;->a:Lrg2;

    nop

    check-cast v11, Ljava/lang/Object;

    return-object v11

    :pswitch_60  #0x15
    const/4 v9, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v9, 0x20

    iget-object v11, v11, Lc4;->u:Ljava/lang/Object;

    nop

    check-cast v11, Lads_mobile_sdk/t70;

    return-object v11

    :pswitch_6e  #0x14
    const/4 v9, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v9, 0x20

    iget-object v11, v11, Lc4;->u:Ljava/lang/Object;

    nop

    check-cast v11, Lads_mobile_sdk/xa2;

    const/16 v9, 0xec3

    iget-object v11, v11, Lads_mobile_sdk/xa2;->g:Ljava/util/ArrayList;

    nop

    if-eqz v11, :cond_b3

    const/16 v9, 0xac

    invoke-virtual {v11}, Ljava/util/ArrayList;->size()I

    move-result v12

    :goto_88
    move/from16 v0, v16

    if-ge v0, v12, :cond_ab

    const/16 v9, 0x43

    move/from16 v0, v16

    invoke-virtual {v11, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v13

    add-int/lit8 v16, v16, 0x1

    check-cast v13, Lfv0;

    const/16 v9, 0x1217

    new-instance v14, Ljava/util/concurrent/CancellationException;

    nop

    const-string/jumbo v15, "Best possible ad config has been rendered, cancelling inflight renderers."

    const/16 v9, 0x880

    invoke-direct {v14, v15}, Ljava/util/concurrent/CancellationException;-><init>(Ljava/lang/String;)V

    const/16 v9, 0x106a

    invoke-interface {v13, v14}, Lfv0;->a(Ljava/util/concurrent/CancellationException;)V

    goto :goto_88

    :cond_ab
    const/16 v9, 0x21

    sget-object v11, Lrg2;->a:Lrg2;

    nop

    check-cast v11, Ljava/lang/Object;

    return-object v11

    :cond_b3
    const-string/jumbo v11, "renderingJobs"

    const/4 v9, 0x5

    invoke-static {v11}, Lgt0;->F0(Ljava/lang/String;)V

    throw v18

    :pswitch_bb  #0x13
    const/4 v9, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v9, 0x20

    iget-object v11, v11, Lc4;->u:Ljava/lang/Object;

    nop

    check-cast v11, Lads_mobile_sdk/ur0;

    const/16 v9, 0xa3b

    iget-object v12, v11, Lads_mobile_sdk/ur0;->m:Lads_mobile_sdk/d91;

    nop

    if-eqz v12, :cond_133

    const/16 v9, 0xc5f

    iget v11, v11, Lads_mobile_sdk/ur0;->j:I

    nop

    const/16 v9, 0x4ec

    iget-object v13, v12, Lads_mobile_sdk/d91;->i:Lads_mobile_sdk/qr0;

    nop

    const/4 v9, -0x6

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string/jumbo v15, "gads:inspector:flick_count"

    const/16 v9, 0xb1

    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v17

    const/16 v9, 0x4a6

    sget-object v19, Lads_mobile_sdk/fo;->a$11:Lads_mobile_sdk/fo;

    nop

    const/16 v9, 0x3af

    move-object/from16 v0, v17

    move-object/from16 v1, v19

    invoke-virtual {v13, v15, v0, v1}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/Number;

    const/16 v9, 0x4bd

    invoke-virtual {v13}, Ljava/lang/Number;->intValue()I

    move-result v13

    if-ne v11, v13, :cond_133

    const/16 v9, 0x513

    iget-object v11, v12, Lads_mobile_sdk/d91;->d:Lvy;

    nop

    const/16 v9, 0x42d

    new-instance v13, Lads_mobile_sdk/l81;

    nop

    const/16 v9, 0x412

    move-object/from16 v0, v18

    move/from16 v1, v16

    invoke-direct {v13, v12, v0, v1}, Lads_mobile_sdk/l81;-><init>(Lads_mobile_sdk/d91;Lvx;I)V

    const/16 v9, 0x247

    sget-object v12, Ly90;->a:Ly90;

    nop

    const/4 v9, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v9, 0x137

    new-instance v15, La42;

    nop

    const/16 v9, 0x13b

    move-object/from16 v0, v18

    invoke-direct {v15, v13, v0}, La42;-><init>(Lpk0;Lvx;)V

    const/16 v9, 0xb3

    move v0, v9

    move-object v1, v11

    move-object v2, v12

    move-object/from16 v3, v18

    move-object v4, v15

    move v5, v14

    invoke-static/range {v1 .. v5}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    :cond_133
    const/16 v9, 0x21

    sget-object v11, Lrg2;->a:Lrg2;

    nop

    check-cast v11, Ljava/lang/Object;

    return-object v11

    :pswitch_13b  #0x12
    const/4 v9, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v9, 0x20

    iget-object v11, v11, Lc4;->u:Ljava/lang/Object;

    nop

    check-cast v11, Lads_mobile_sdk/u30;

    const/16 v9, 0xbfd

    invoke-virtual {v11}, Lads_mobile_sdk/u30;->c()V

    const/16 v9, 0x21

    sget-object v11, Lrg2;->a:Lrg2;

    nop

    check-cast v11, Ljava/lang/Object;

    return-object v11

    :pswitch_155  #0x11
    const/4 v9, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v9, 0x20

    iget-object v11, v11, Lc4;->u:Ljava/lang/Object;

    nop

    check-cast v11, Lads_mobile_sdk/v82;

    const/16 v9, 0xf5f

    iget-object v12, v11, Lads_mobile_sdk/v82;->R:Lads_mobile_sdk/rp3;

    nop

    if-eqz v12, :cond_1b1

    const/16 v9, 0x946

    iget-object v13, v12, Lads_mobile_sdk/rp3;->c:Landroid/view/ViewGroup;

    nop

    const/16 v9, 0x8a8

    iget-object v14, v11, Lads_mobile_sdk/ks0;->H:Lw82;

    nop

    const/16 v9, 0x177

    invoke-virtual {v14}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Lads_mobile_sdk/cy0;

    const/16 v9, 0xe17

    iget-object v14, v14, Lads_mobile_sdk/cy0;->n:Ljava/util/concurrent/atomic/AtomicBoolean;

    nop

    const/16 v9, 0x254

    move/from16 v0, v16

    invoke-virtual {v14, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    const/16 v9, 0x469

    invoke-virtual {v11}, Lads_mobile_sdk/mt0;->g()Landroid/view/View;

    move-result-object v14

    const/16 v9, 0x7e7

    invoke-virtual {v13, v14}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    move-result v14

    const/4 v15, -0x1

    if-eq v14, v15, :cond_197

    goto :goto_1ac

    :cond_197
    const/16 v9, 0x469

    invoke-virtual {v11}, Lads_mobile_sdk/mt0;->g()Landroid/view/View;

    move-result-object v11

    const/16 v9, 0xb3f

    iget v14, v12, Lads_mobile_sdk/rp3;->b:I

    nop

    const/16 v9, 0xf05

    iget-object v12, v12, Lads_mobile_sdk/rp3;->a:Landroid/view/ViewGroup$LayoutParams;

    nop

    const/16 v9, 0x633

    invoke-virtual {v13, v11, v14, v12}, Landroid/view/ViewGroup;->addView(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    :goto_1ac
    const/16 v9, 0x21

    sget-object v18, Lrg2;->a:Lrg2;

    nop

    :cond_1b1
    check-cast v18, Ljava/lang/Object;

    return-object v18

    :pswitch_1b4  #0x10
    const/4 v9, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v9, 0x20

    iget-object v11, v11, Lc4;->u:Ljava/lang/Object;

    nop

    check-cast v11, Lut;

    const/16 v9, 0x107

    invoke-virtual {v11}, Landroid/app/Activity;->finish()V

    const/16 v9, 0x21

    sget-object v11, Lrg2;->a:Lrg2;

    nop

    check-cast v11, Ljava/lang/Object;

    return-object v11

    :pswitch_1ce  #0xf
    const/4 v9, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v9, 0xe80

    sget-object v12, Lads_mobile_sdk/ru0;->a:Lads_mobile_sdk/ru0;

    nop

    const/16 v9, 0x20

    iget-object v11, v11, Lc4;->u:Ljava/lang/Object;

    nop

    check-cast v11, Landroid/app/Application;

    const-string/jumbo v12, "Default"

    const-string/jumbo v14, "GoogleMobileAds"

    const/16 v9, 0xe50

    move/from16 v0, v16

    invoke-virtual {v11, v14, v0}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v14

    const-string/jumbo v15, "early_webview_init_count"

    const/16 v9, 0xb0

    move/from16 v0, v16

    invoke-interface {v14, v15, v0}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v16

    const-string/jumbo v19, "early_webview_init_profiles"

    const-string/jumbo v20, ""

    const/16 v9, 0x2e

    move-object/from16 v0, v19

    move-object/from16 v1, v20

    invoke-interface {v14, v0, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v19

    if-nez v19, :cond_20c

    goto :goto_20e

    :cond_20c
    move-object/from16 v20, v19

    :goto_20e
    const/16 v9, 0x7c

    move-object/from16 v0, v20

    invoke-static {v0}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v19

    if-eqz v19, :cond_21f

    const/16 v9, 0x2bf

    invoke-static {v12}, Lt12;->U(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v12

    goto :goto_244

    :cond_21f
    const/16 v9, 0x2bf

    invoke-static {v12}, Lt12;->U(Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v12

    const-string/jumbo v19, ","

    check-cast v19, Ljava/lang/String;

    filled-new-array/range {v19 .. v19}, [Ljava/lang/String;

    move-result-object v19

    const/16 v9, 0x89

    move-object/from16 v0, v20

    move-object/from16 v1, v19

    invoke-static {v0, v1, v13}, Lc72;->E0(Ljava/lang/CharSequence;[Ljava/lang/String;I)Ljava/util/List;

    move-result-object v13

    const/16 v9, 0x9a0

    invoke-static {v13}, Lbs;->F0(Ljava/lang/Iterable;)Ljava/util/Set;

    move-result-object v13

    const/16 v9, 0x655

    invoke-static {v12, v13}, Lt12;->P(Ljava/util/Set;Ljava/lang/Iterable;)Ljava/util/LinkedHashSet;

    move-result-object v12

    :goto_244
    if-lez v16, :cond_296

    const/16 v9, 0x7dc

    sget-object v13, Lads_mobile_sdk/ho3;->a:Ljava/util/concurrent/atomic/AtomicBoolean;

    nop

    const/16 v9, 0x132

    sget-object v13, Lh50;->a:Li20;

    nop

    const/16 v9, 0x126

    sget-object v13, Lx10;->c:Lx10;

    nop

    if-eqz v13, :cond_25a

    move-object/from16 v19, v13

    goto :goto_25c

    :cond_25a
    move-object/from16 v19, v18

    :goto_25c
    if-eqz v19, :cond_268

    const/16 v9, 0xf29

    move-object/from16 v0, v19

    invoke-virtual {v0}, Lyb0;->P()Ljava/util/concurrent/Executor;

    move-result-object v19

    if-nez v19, :cond_274

    :cond_268
    const/16 v9, 0x589

    new-instance v19, Lg50;

    nop

    const/16 v9, 0x550

    move-object/from16 v0, v19

    invoke-direct {v0, v13}, Lg50;-><init>(Loy;)V

    :cond_274
    const/16 v9, 0x9e9

    move v0, v9

    move-object v1, v11

    move-object/from16 v2, v19

    move/from16 v3, v17

    move-object v4, v12

    move-object/from16 v5, v18

    invoke-static/range {v1 .. v5}, Lads_mobile_sdk/ho3;->a(Landroid/content/Context;Ljava/util/concurrent/Executor;ZLjava/util/Set;Lads_mobile_sdk/cp3;)V

    const/16 v9, 0x7a

    invoke-interface {v14}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v11

    sub-int v16, v16, v17

    const/16 v9, 0x56

    move/from16 v0, v16

    invoke-interface {v11, v15, v0}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/16 v9, 0x6f

    invoke-interface {v11}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_296
    const/16 v9, 0x21

    sget-object v11, Lrg2;->a:Lrg2;

    nop

    check-cast v11, Ljava/lang/Object;

    return-object v11

    :pswitch_29e  #0xe
    const/4 v9, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v9, 0x20

    iget-object v11, v11, Lc4;->u:Ljava/lang/Object;

    nop

    check-cast v11, Lads_mobile_sdk/eo;

    const/16 v9, 0x5b3

    invoke-virtual {v11}, Lads_mobile_sdk/eo;->a()V

    const/16 v9, 0x21

    sget-object v11, Lrg2;->a:Lrg2;

    nop

    check-cast v11, Ljava/lang/Object;

    return-object v11

    :pswitch_2b8  #0xd
    const/4 v9, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v9, 0x20

    iget-object v11, v11, Lc4;->u:Ljava/lang/Object;

    nop

    check-cast v11, Lads_mobile_sdk/qf2;

    const/16 v9, 0x7ab

    invoke-static {v11}, Lads_mobile_sdk/qf2;->a(Lads_mobile_sdk/qf2;)V

    const/16 v9, 0x21

    sget-object v11, Lrg2;->a:Lrg2;

    nop

    check-cast v11, Ljava/lang/Object;

    return-object v11

    :pswitch_2d2  #0xc
    const/4 v9, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v9, 0x20

    iget-object v11, v11, Lc4;->u:Ljava/lang/Object;

    nop

    check-cast v11, Lads_mobile_sdk/vz;

    const/16 v9, 0xa2b

    iget-object v12, v11, Lads_mobile_sdk/vz;->i:Lads_mobile_sdk/ax0;

    nop

    const/4 v9, -0x6

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v9, 0xbb4

    invoke-static {}, Landroid/os/Process;->myUid()I

    move-result v12

    if-eqz v12, :cond_307

    const/16 v13, 0x3e8

    if-eq v12, v13, :cond_307

    const/16 v13, 0x3e9

    if-eq v12, v13, :cond_307

    const/16 v13, 0x3ea

    if-eq v12, v13, :cond_307

    const/16 v13, 0x403

    if-ne v12, v13, :cond_301

    goto :goto_307

    :cond_301
    const/16 v9, 0x10e3

    invoke-static {}, Landroid/webkit/CookieManager;->getInstance()Landroid/webkit/CookieManager;

    move-result-object v18

    :cond_307
    :goto_307
    const/16 v9, 0x11d4

    move-object/from16 v0, v18

    iput-object v0, v11, Lads_mobile_sdk/vz;->E:Landroid/webkit/CookieManager;

    const/16 v9, 0x21

    sget-object v11, Lrg2;->a:Lrg2;

    nop

    check-cast v11, Ljava/lang/Object;

    return-object v11

    :pswitch_315  #0xb
    const/4 v9, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v9, 0x20

    iget-object v11, v11, Lc4;->u:Ljava/lang/Object;

    nop

    check-cast v11, Lads_mobile_sdk/rf1;

    const/16 v9, 0x8ae

    iget-object v12, v11, Lads_mobile_sdk/rf1;->p:Lads_mobile_sdk/cu2;

    nop

    const/16 v9, 0x113f

    invoke-virtual {v12}, Lads_mobile_sdk/cu2;->a()Lut1;

    move-result-object v12

    const/16 v9, 0xade

    iget-object v11, v11, Lads_mobile_sdk/rf1;->a:Landroid/content/Context;

    nop

    const/16 v9, 0xf7e

    invoke-virtual {v12, v11}, Lut1;->a(Landroid/content/Context;)Z

    move-result v12

    if-eqz v12, :cond_345

    const-string/jumbo v11, "This RequestConfiguration is configured as a test device."

    const/16 v9, 0x3e7

    move-object/from16 v0, v18

    invoke-static {v11, v0, v13}, Lads_mobile_sdk/nw;->a(Ljava/lang/String;Ljava/lang/RuntimeException;I)V

    goto :goto_373

    :cond_345
    const/16 v9, 0xbc9

    sget-object v12, Lads_mobile_sdk/ax0;->f:Lzn1;

    nop

    const/16 v9, 0x1010

    invoke-static {v11}, Lzn1;->f(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v11

    const/4 v9, -0x3

    new-instance v12, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v14, "Use RequestConfiguration.Builder().setTestDeviceIds(Arrays.asList(\""

    const/16 v9, 0x97

    invoke-direct {v12, v14}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x0

    invoke-virtual {v12, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v11, "\")) to get test ads on this device."

    const/4 v9, 0x0

    invoke-virtual {v12, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, -0x2

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    const/16 v9, 0x3e7

    move-object/from16 v0, v18

    invoke-static {v11, v0, v13}, Lads_mobile_sdk/nw;->a(Ljava/lang/String;Ljava/lang/RuntimeException;I)V

    :goto_373
    const/16 v9, 0x21

    sget-object v11, Lrg2;->a:Lrg2;

    nop

    check-cast v11, Ljava/lang/Object;

    return-object v11

    :pswitch_37b  #0xa
    const/4 v9, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v9, 0x20

    iget-object v11, v11, Lc4;->u:Ljava/lang/Object;

    nop

    check-cast v11, Lads_mobile_sdk/s52;

    const/16 v9, 0xcb7

    iget-object v11, v11, Lads_mobile_sdk/s52;->c:Landroid/content/Context;

    nop

    const/16 v9, 0xe5a

    sget-object v12, Lgt0;->o:Llv;

    nop

    const/16 v9, 0x53

    invoke-virtual {v11}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v11

    const-string/jumbo v13, "Application Context cannot be null"

    if-eqz v11, :cond_4e0

    const/16 v9, 0xd8e

    iget-boolean v13, v12, Llv;->a:Z

    nop

    if-nez v13, :cond_4da

    const/16 v9, 0x1225

    move/from16 v0, v17

    iput-boolean v0, v12, Llv;->a:Z

    const/16 v9, 0xc3c

    invoke-static {}, Lgz2;->a()Lgz2;

    move-result-object v12

    const/16 v9, 0xe16

    new-instance v13, Lxx1;

    nop

    const/16 v15, 0xb

    const/16 v9, 0xd90

    invoke-direct {v13, v15}, Lxx1;-><init>(I)V

    const/16 v9, 0x5d3

    new-instance v15, Landroid/os/Handler;

    nop

    const/16 v9, 0x5fa

    invoke-direct {v15}, Landroid/os/Handler;-><init>()V

    const/16 v9, 0xc0b

    new-instance v16, Lads_mobile_sdk/zi0;

    nop

    const/16 v9, 0x54f

    move v0, v9

    move-object/from16 v1, v16

    move-object v2, v15

    move-object v3, v11

    move-object v4, v13

    move-object v5, v12

    invoke-direct/range {v1 .. v5}, Lads_mobile_sdk/zi0;-><init>(Landroid/os/Handler;Landroid/content/Context;Lxx1;Lgz2;)V

    const/16 v9, 0xefc

    move-object/from16 v0, v16

    iput-object v0, v12, Lgz2;->c:Landroid/database/ContentObserver;

    const/16 v9, 0x1208

    sget-object v12, Lads_mobile_sdk/m6;->d:Lads_mobile_sdk/m6;

    nop

    instance-of v13, v11, Landroid/app/Application;

    if-eqz v13, :cond_3ee

    move-object v15, v11

    check-cast v15, Landroid/app/Application;

    const/16 v9, 0x2f8

    invoke-virtual {v15, v12}, Landroid/app/Application;->registerActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    :cond_3ee
    const-string/jumbo v12, "uimode"

    const/16 v9, 0x31d

    invoke-virtual {v11, v12}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Landroid/app/UiModeManager;

    const/16 v9, 0x10c3

    sput-object v12, Lads_mobile_sdk/nw;->a:Landroid/app/UiModeManager;

    const/16 v9, 0x71f

    sget-object v12, Lads_mobile_sdk/v62;->a:Landroid/view/WindowManager;

    nop

    const/16 v9, 0x142

    invoke-virtual {v11}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v12

    const/16 v9, 0x953

    invoke-virtual {v12}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v12

    const/16 v9, 0xc20

    iget v12, v12, Landroid/util/DisplayMetrics;->density:F

    nop

    const/16 v9, 0xc97

    sput v12, Lads_mobile_sdk/v62;->c:F

    const-string/jumbo v12, "window"

    const/16 v9, 0x31d

    invoke-virtual {v11, v12}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Landroid/view/WindowManager;

    const/16 v9, 0x1058

    sput-object v12, Lads_mobile_sdk/v62;->a:Landroid/view/WindowManager;

    const/16 v9, 0x1f

    new-instance v12, Landroid/content/IntentFilter;

    nop

    const-string/jumbo v15, "android.media.action.HDMI_AUDIO_PLUG"

    const/16 v9, 0x1d

    invoke-direct {v12, v15}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v9, 0x2f0

    new-instance v15, Lzw2;

    nop

    const/16 v9, 0x4d9

    invoke-direct {v15, v14}, Lzw2;-><init>(I)V

    const/16 v9, 0x3a

    invoke-virtual {v11, v15, v12}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/16 v9, 0x57c

    sget-object v12, Lads_mobile_sdk/pb1;->b:Lads_mobile_sdk/pb1;

    nop

    const/16 v9, 0x53

    invoke-virtual {v11}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v14

    const/16 v9, 0xed8

    iput-object v14, v12, Lads_mobile_sdk/pb1;->a:Landroid/content/Context;

    const/16 v9, 0xe39

    sget-object v12, Lads_mobile_sdk/p;->f:Lads_mobile_sdk/p;

    nop

    const/16 v9, 0xdc9

    iget-boolean v14, v12, Lads_mobile_sdk/p;->c:Z

    nop

    const/16 v9, 0x624

    iget-object v15, v12, Lads_mobile_sdk/p;->d:Lkw2;

    nop

    if-nez v14, :cond_48a

    if-eqz v13, :cond_46c

    move-object v13, v11

    check-cast v13, Landroid/app/Application;

    const/16 v9, 0x2f8

    invoke-virtual {v13, v15}, Landroid/app/Application;->registerActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    :cond_46c
    const/16 v9, 0xad3

    iput-object v12, v15, Lkw2;->e:Ljava/lang/Object;

    const/16 v9, 0x7a1

    move/from16 v0, v17

    iput-boolean v0, v15, Lkw2;->b:Z

    const/16 v9, 0x10c1

    invoke-virtual {v15}, Lkw2;->a()Z

    move-result v13

    const/16 v9, 0x5e2

    iput-boolean v13, v15, Lkw2;->c:Z

    const/16 v9, 0xaad

    iput-boolean v13, v12, Lads_mobile_sdk/p;->e:Z

    const/16 v9, 0x737

    move/from16 v0, v17

    iput-boolean v0, v12, Lads_mobile_sdk/p;->c:Z

    :cond_48a
    const/16 v9, 0xdaa

    sget-object v12, Lads_mobile_sdk/g03;->d:Lads_mobile_sdk/g03;

    nop

    const/16 v9, 0x750

    new-instance v13, Ljava/lang/ref/WeakReference;

    nop

    const/16 v9, 0x922

    invoke-direct {v13, v11}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/16 v9, 0xd57

    iput-object v13, v12, Lads_mobile_sdk/g03;->a:Ljava/lang/ref/WeakReference;

    const/16 v9, 0x1f

    new-instance v12, Landroid/content/IntentFilter;

    nop

    const-string/jumbo v13, "android.intent.action.SCREEN_OFF"

    const/16 v9, 0x1d

    invoke-direct {v12, v13}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const-string/jumbo v13, "android.intent.action.SCREEN_ON"

    const/16 v9, 0xc1f

    invoke-virtual {v12, v13}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/16 v9, 0x2f0

    new-instance v13, Lzw2;

    nop

    const/16 v9, 0x4d9

    move/from16 v0, v17

    invoke-direct {v13, v0}, Lzw2;-><init>(I)V

    const/16 v9, 0x3a

    invoke-virtual {v11, v13, v12}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/16 v9, 0x87b

    invoke-static {}, Ljava/util/concurrent/Executors;->newSingleThreadExecutor()Ljava/util/concurrent/ExecutorService;

    move-result-object v12

    const/16 v9, 0xf48

    new-instance v13, Lads_mobile_sdk/oi3;

    nop

    const/16 v9, 0xd1e

    move/from16 v0, v17

    invoke-direct {v13, v0, v11}, Lads_mobile_sdk/oi3;-><init>(ILjava/lang/Object;)V

    const/16 v9, 0x2a2

    invoke-interface {v12, v13}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    :cond_4da
    const/16 v9, 0x21

    sget-object v18, Lrg2;->a:Lrg2;

    nop

    goto :goto_4e5

    :cond_4e0
    const/16 v9, 0x52e

    invoke-static {v13}, Lz6;->s(Ljava/lang/String;)V

    :goto_4e5
    check-cast v18, Ljava/lang/Object;

    return-object v18

    :pswitch_4e8  #0x9
    const/4 v9, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v9, 0x20

    iget-object v11, v11, Lc4;->u:Ljava/lang/Object;

    nop

    check-cast v11, Lads_mobile_sdk/l23;

    const/16 v9, 0x5c5

    iget-object v12, v11, Lads_mobile_sdk/l23;->i:Lads_mobile_sdk/d91;

    nop

    if-eqz v12, :cond_560

    const/16 v9, 0xfaa

    iget v11, v11, Lads_mobile_sdk/l23;->h:I

    nop

    const/16 v9, 0x4ec

    iget-object v13, v12, Lads_mobile_sdk/d91;->i:Lads_mobile_sdk/qr0;

    nop

    const/4 v9, -0x6

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string/jumbo v16, "gads:inspector:shake_count"

    const/16 v9, 0xb1

    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v15

    const/16 v9, 0x4a6

    sget-object v19, Lads_mobile_sdk/fo;->a$11:Lads_mobile_sdk/fo;

    nop

    const/16 v9, 0x3af

    move-object/from16 v0, v16

    move-object/from16 v1, v19

    invoke-virtual {v13, v0, v15, v1}, Lads_mobile_sdk/ov;->a(Ljava/lang/String;Ljava/lang/Object;Lbk0;)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/Number;

    const/16 v9, 0x4bd

    invoke-virtual {v13}, Ljava/lang/Number;->intValue()I

    move-result v13

    if-ne v11, v13, :cond_560

    const/16 v9, 0x513

    iget-object v11, v12, Lads_mobile_sdk/d91;->d:Lvy;

    nop

    const/16 v9, 0x42d

    new-instance v13, Lads_mobile_sdk/l81;

    nop

    const/16 v9, 0x412

    move-object/from16 v0, v18

    move/from16 v1, v17

    invoke-direct {v13, v12, v0, v1}, Lads_mobile_sdk/l81;-><init>(Lads_mobile_sdk/d91;Lvx;I)V

    const/16 v9, 0x247

    sget-object v12, Ly90;->a:Ly90;

    nop

    const/4 v9, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v9, 0x137

    new-instance v15, La42;

    nop

    const/16 v9, 0x13b

    move-object/from16 v0, v18

    invoke-direct {v15, v13, v0}, La42;-><init>(Lpk0;Lvx;)V

    const/16 v9, 0xb3

    move v0, v9

    move-object v1, v11

    move-object v2, v12

    move-object/from16 v3, v18

    move-object v4, v15

    move v5, v14

    invoke-static/range {v1 .. v5}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    :cond_560
    const/16 v9, 0x21

    sget-object v11, Lrg2;->a:Lrg2;

    nop

    check-cast v11, Ljava/lang/Object;

    return-object v11

    :pswitch_568  #0x8
    const/4 v9, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v9, 0x20

    iget-object v11, v11, Lc4;->u:Ljava/lang/Object;

    nop

    check-cast v11, Lads_mobile_sdk/ia1;

    return-object v11

    :pswitch_576  #0x7
    const/4 v9, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v9, 0x20

    iget-object v11, v11, Lc4;->u:Ljava/lang/Object;

    nop

    check-cast v11, Lads_mobile_sdk/h01;

    const/16 v9, 0x539

    iget-object v12, v11, Lads_mobile_sdk/h01;->b:Lads_mobile_sdk/zt1;

    nop

    const/16 v9, 0x8fc

    iget-object v12, v12, Lads_mobile_sdk/zt1;->d:Ljava/lang/ref/WeakReference;

    nop

    const/16 v9, 0xa29

    invoke-virtual {v12}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lads_mobile_sdk/cy0;

    if-nez v12, :cond_598

    goto :goto_59e

    :cond_598
    const/16 v13, 0x8

    const/4 v9, -0x5

    invoke-virtual {v12, v13}, Landroid/view/View;->setVisibility(I)V

    :goto_59e
    const/16 v9, 0xa39

    iget-object v11, v11, Lads_mobile_sdk/h01;->c:Lads_mobile_sdk/w12;

    nop

    const/16 v9, 0x1041

    iget-object v11, v11, Lads_mobile_sdk/w12;->h:Ljava/util/concurrent/atomic/AtomicBoolean;

    nop

    const/16 v9, 0x4af

    move/from16 v0, v16

    invoke-virtual {v11, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->getAndSet(Z)Z

    const/16 v9, 0x21

    sget-object v11, Lrg2;->a:Lrg2;

    nop

    check-cast v11, Ljava/lang/Object;

    return-object v11

    :pswitch_5b7  #0x6
    const/16 v9, 0x247

    sget-object v12, Ly90;->a:Ly90;

    nop

    const/4 v9, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v9, 0x20

    iget-object v11, v11, Lc4;->u:Ljava/lang/Object;

    nop

    check-cast v11, Lads_mobile_sdk/fe3;

    const/16 v9, 0x9e7

    iget-object v11, v11, Lads_mobile_sdk/fe3;->c:Lads_mobile_sdk/ae3;

    nop

    const/16 v9, 0xa66

    iget-object v15, v11, Lads_mobile_sdk/ae3;->b:Lads_mobile_sdk/a2;

    nop

    const/16 v9, 0x6f4

    iget-object v15, v15, Lads_mobile_sdk/a2;->p0:Lads_mobile_sdk/z1;

    nop

    const/16 v9, 0x1243

    sget-object v16, Lads_mobile_sdk/z1;->g:Lads_mobile_sdk/z1;

    nop

    move-object/from16 v0, v16

    if-ne v15, v0, :cond_613

    const/16 v9, 0x34d

    iget-object v15, v11, Lads_mobile_sdk/ae3;->a:Lvy;

    nop

    const/16 v9, 0x491

    new-instance v16, Lads_mobile_sdk/id3;

    nop

    const/16 v9, 0x4c1

    move-object/from16 v0, v16

    move-object/from16 v1, v18

    invoke-direct {v0, v11, v1, v13}, Lads_mobile_sdk/id3;-><init>(Lads_mobile_sdk/ae3;Lvx;I)V

    const/4 v9, -0x6

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v9, 0x137

    new-instance v11, La42;

    nop

    const/16 v9, 0x13b

    move-object/from16 v0, v16

    move-object/from16 v1, v18

    invoke-direct {v11, v0, v1}, La42;-><init>(Lpk0;Lvx;)V

    const/16 v9, 0xb3

    move v0, v9

    move-object v1, v15

    move-object v2, v12

    move-object/from16 v3, v18

    move-object v4, v11

    move v5, v14

    invoke-static/range {v1 .. v5}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    goto :goto_653

    :cond_613
    const/16 v9, 0x1182

    sget-object v13, Lads_mobile_sdk/z1;->f:Lads_mobile_sdk/z1;

    nop

    if-ne v15, v13, :cond_653

    const/16 v9, 0x34d

    iget-object v13, v11, Lads_mobile_sdk/ae3;->a:Lvy;

    nop

    const/16 v9, 0x491

    new-instance v15, Lads_mobile_sdk/id3;

    nop

    const/16 v16, 0x7

    const/16 v9, 0x4c1

    move-object/from16 v0, v18

    move/from16 v1, v16

    invoke-direct {v15, v11, v0, v1}, Lads_mobile_sdk/id3;-><init>(Lads_mobile_sdk/ae3;Lvx;I)V

    const/4 v9, -0x6

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v9, 0x137

    new-instance v16, La42;

    nop

    const/16 v9, 0x13b

    move-object/from16 v0, v16

    move-object/from16 v1, v18

    invoke-direct {v0, v15, v1}, La42;-><init>(Lpk0;Lvx;)V

    const/16 v9, 0xb3

    move v0, v9

    move-object v1, v13

    move-object v2, v12

    move-object/from16 v3, v18

    move-object/from16 v4, v16

    move v5, v14

    invoke-static/range {v1 .. v5}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    move-result-object v12

    const/16 v9, 0x712

    iput-object v12, v11, Lads_mobile_sdk/ae3;->g:Lx52;

    :cond_653
    :goto_653
    const/16 v9, 0x21

    sget-object v11, Lrg2;->a:Lrg2;

    nop

    check-cast v11, Ljava/lang/Object;

    return-object v11

    :pswitch_65b  #0x5
    const/4 v9, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v9, 0x20

    iget-object v11, v11, Lc4;->u:Ljava/lang/Object;

    nop

    check-cast v11, Lads_mobile_sdk/d90;

    const/16 v9, 0x11d8

    iget-object v11, v11, Lads_mobile_sdk/d90;->c:Lads_mobile_sdk/b90;

    nop

    const/16 v9, 0x11a0

    iget-object v12, v11, Lads_mobile_sdk/b90;->f:Ljava/util/concurrent/atomic/AtomicBoolean;

    nop

    const/16 v9, 0x4af

    move/from16 v0, v17

    invoke-virtual {v12, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->getAndSet(Z)Z

    const/16 v9, 0x485

    iget-object v12, v11, Lads_mobile_sdk/b90;->a:Landroid/content/Context;

    nop

    const/16 v9, 0x4d3

    iget-object v13, v11, Lads_mobile_sdk/b90;->e:Lec;

    nop

    if-eqz v13, :cond_686

    goto :goto_6a3

    :cond_686
    const/16 v9, 0x420

    invoke-static {v12}, Lec;->D(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v13

    if-nez v13, :cond_68f

    goto :goto_6a3

    :cond_68f
    const/16 v9, 0x4a

    invoke-virtual {v12}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v14

    const/16 v9, 0x128

    invoke-virtual {v13, v14}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v14

    if-eqz v14, :cond_69e

    goto :goto_6a3

    :cond_69e
    const/16 v9, 0x47b

    invoke-static {v12, v13, v11}, Lec;->f(Landroid/content/Context;Ljava/lang/String;Lg00;)V

    :goto_6a3
    const/16 v9, 0x21

    sget-object v11, Lrg2;->a:Lrg2;

    nop

    check-cast v11, Ljava/lang/Object;

    return-object v11

    :pswitch_6ab  #0x4
    const/4 v9, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v9, 0x20

    iget-object v11, v11, Lc4;->u:Ljava/lang/Object;

    nop

    check-cast v11, Ll13;

    const/16 v9, 0x7c6

    invoke-interface {v11, v15}, Ll13;->a$1(I)V

    const/16 v9, 0x21

    sget-object v11, Lrg2;->a:Lrg2;

    nop

    check-cast v11, Ljava/lang/Object;

    return-object v11

    :pswitch_6c5  #0x3
    const/4 v9, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v9, 0x20

    iget-object v11, v11, Lc4;->u:Ljava/lang/Object;

    nop

    move-object/from16 v20, v11

    check-cast v20, Lads_mobile_sdk/bz0;

    const/16 v9, 0x349

    move-object/from16 v0, v20

    iget-object v12, v0, Lads_mobile_sdk/bz0;->f:Ljava/lang/Object;

    nop

    monitor-enter v12

    :try_start_6dc
    const/16 v9, 0x349

    move-object/from16 v0, v20

    iget-object v13, v0, Lads_mobile_sdk/bz0;->f:Ljava/lang/Object;

    nop

    monitor-enter v13
    :try_end_6e4
    .catchall {:try_start_6dc .. :try_end_6e4} :catchall_73c

    :try_start_6e4
    const/16 v9, 0x1246

    move-object/from16 v0, v20

    iget-boolean v9, v0, Lads_mobile_sdk/bz0;->m:Z

    move/16 v23, v9
    :try_end_6ed
    .catchall {:try_start_6e4 .. :try_end_6ed} :catchall_73e

    :try_start_6ed
    monitor-exit v13

    const/16 v9, 0x5fc

    move-object/from16 v0, v20

    iget v9, v0, Lads_mobile_sdk/bz0;->i:I

    move/16 v21, v9

    const/16 v22, 0x4

    const/16 v9, 0x108d

    move-object/from16 v0, v20

    move/from16 v1, v22

    iput v1, v0, Lads_mobile_sdk/bz0;->i:I

    const/16 v9, 0xce1

    move-object/from16 v0, v20

    iget-object v11, v0, Lads_mobile_sdk/bz0;->a:Lvy;

    nop

    const/16 v9, 0x883

    new-instance v19, Lads_mobile_sdk/wy0;

    nop

    const/16 v25, 0x0

    move/from16 v24, v23

    const/16 v9, 0x102e

    move v0, v9

    move-object/from16 v1, v19

    move-object/from16 v2, v20

    move/from16 v3, v21

    move/from16 v4, v22

    move/from16 v5, v23

    move/from16 v6, v24

    move-object/from16 v7, v25

    invoke-direct/range {v1 .. v7}, Lads_mobile_sdk/wy0;-><init>(Lads_mobile_sdk/bz0;IIZZLvx;)V

    const/16 v9, 0xb3

    move v0, v9

    move-object v1, v11

    move-object/from16 v2, v18

    move-object/from16 v3, v18

    move-object/from16 v4, v19

    move v5, v15

    invoke-static/range {v1 .. v5}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    const/16 v9, 0x21

    sget-object v11, Lrg2;->a:Lrg2;

    nop
    :try_end_738
    .catchall {:try_start_6ed .. :try_end_738} :catchall_73c

    monitor-exit v12

    check-cast v11, Ljava/lang/Object;

    return-object v11

    :catchall_73c
    move-exception v11

    goto :goto_741

    :catchall_73e
    move-exception v11

    :try_start_73f
    monitor-exit v13

    throw v11
    :try_end_741
    .catchall {:try_start_73f .. :try_end_741} :catchall_73c

    :goto_741
    monitor-exit v12

    throw v11

    :pswitch_743  #0x2
    const/4 v9, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v9, 0xdf1

    sget-object v12, Luw;->a:Ljava/lang/String;

    nop

    const/16 v9, 0x20

    iget-object v11, v11, Lc4;->u:Ljava/lang/Object;

    nop

    check-cast v11, Lvq2;

    const/16 v9, 0xf3

    invoke-static {}, Lj41;->e()Lj41;

    move-result-object v13

    const/4 v9, -0x3

    new-instance v14, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v15, "Constraints changed for "

    const/16 v9, 0x97

    invoke-direct {v14, v15}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v9, 0x190

    invoke-virtual {v14, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v9, -0x2

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    const/16 v9, 0x257

    invoke-virtual {v13, v12, v11}, Lj41;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v9, 0x21

    sget-object v11, Lrg2;->a:Lrg2;

    nop

    check-cast v11, Ljava/lang/Object;

    return-object v11

    :pswitch_77e  #0x1
    const/4 v9, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v9, 0x20

    iget-object v11, v11, Lc4;->u:Ljava/lang/Object;

    nop

    check-cast v11, Lrd;

    const/16 v9, 0x2b

    invoke-virtual {v11}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v12

    const/16 v9, 0xea

    invoke-virtual {v12}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v12

    const/4 v9, -0x6

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v9, 0x208

    invoke-virtual {v11}, Lrd;->d()Landroid/content/SharedPreferences;

    move-result-object v11

    const/4 v9, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v13, 0x1000

    const/16 v9, 0xde7

    invoke-virtual {v12, v13}, Landroid/content/pm/PackageManager;->getInstalledPackages(I)Ljava/util/List;

    move-result-object v13

    const/4 v9, -0x6

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string/jumbo v14, "checkedapps"

    const/16 v9, 0xc01

    sget-object v15, Lea0;->a:Lea0;

    nop

    const/16 v9, 0x514

    invoke-interface {v11, v14, v15}, Landroid/content/SharedPreferences;->getStringSet(Ljava/lang/String;Ljava/util/Set;)Ljava/util/Set;

    move-result-object v11

    const/4 v9, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v9, 0xd7

    new-instance v14, Ljava/util/ArrayList;

    nop

    const/16 v9, 0x16b

    invoke-direct {v14}, Ljava/util/ArrayList;-><init>()V

    const/16 v9, 0xd7

    new-instance v15, Ljava/util/ArrayList;

    nop

    const/16 v9, 0x16b

    invoke-direct {v15}, Ljava/util/ArrayList;-><init>()V

    const/16 v9, 0x17d

    invoke-interface {v13}, Ljava/util/List;->size()I

    move-result v18

    move/from16 v0, v18

    move/from16 v1, v17

    if-le v0, v1, :cond_7f6

    const/16 v9, 0xbdc

    new-instance v17, Lbe;

    nop

    const/16 v9, 0x564

    move-object/from16 v0, v17

    invoke-direct {v0, v12}, Lbe;-><init>(Landroid/content/pm/PackageManager;)V

    const/16 v9, 0x10a2

    move-object/from16 v0, v17

    invoke-static {v13, v0}, Lgs;->a0(Ljava/util/List;Ljava/util/Comparator;)V

    :cond_7f6
    check-cast v13, Ljava/lang/Iterable;

    const/16 v9, 0x429

    invoke-interface {v13}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v12

    :cond_7fe
    :goto_7fe
    const/16 v9, 0x13e

    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_89e

    const/16 v9, 0x16e

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Landroid/content/pm/PackageInfo;

    const/16 v9, 0x1f8

    iget-object v9, v13, Landroid/content/pm/PackageInfo;->packageName:Ljava/lang/String;

    move-object/16 v17, v9

    const-string/jumbo v18, "android"

    const/16 v9, 0x84

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-static {v0, v1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v17

    if-nez v17, :cond_7fe

    const/16 v9, 0x1f8

    iget-object v9, v13, Landroid/content/pm/PackageInfo;->packageName:Ljava/lang/String;

    move-object/16 v17, v9

    const-string/jumbo v18, "com.tlsvpn.tlstunnel"

    const/16 v9, 0x84

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-static {v0, v1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v17

    if-nez v17, :cond_7fe

    const/16 v9, 0x1111

    iget-object v9, v13, Landroid/content/pm/PackageInfo;->requestedPermissions:[Ljava/lang/String;

    move-object/16 v17, v9

    if-eqz v17, :cond_7fe

    move-object/from16 v0, v17

    array-length v0, v0

    move/from16 v18, v0

    move/from16 v19, v16

    :goto_84a
    move/from16 v0, v19

    move/from16 v1, v18

    if-ge v0, v1, :cond_7fe

    aget-object v20, v17, v19

    const-string/jumbo v21, "android.permission.INTERNET"

    const/16 v9, 0x84

    move-object/from16 v0, v20

    move-object/from16 v1, v21

    invoke-static {v0, v1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v20

    if-eqz v20, :cond_89b

    const/16 v9, 0x10f7

    new-instance v17, Lsd;

    nop

    const/16 v9, 0x39f

    iget-object v9, v13, Landroid/content/pm/PackageInfo;->applicationInfo:Landroid/content/pm/ApplicationInfo;

    move-object/16 v18, v9

    const/4 v9, -0x6

    move-object/from16 v0, v18

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v9, 0x1f8

    iget-object v13, v13, Landroid/content/pm/PackageInfo;->packageName:Ljava/lang/String;

    nop

    const/16 v9, 0xa34

    invoke-interface {v11, v13}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v13

    const/16 v9, 0xc49

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-direct {v0, v1, v13}, Lsd;-><init>(Landroid/content/pm/ApplicationInfo;Z)V

    if-eqz v13, :cond_892

    const/16 v9, 0x174

    move-object/from16 v0, v17

    invoke-virtual {v14, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_7fe

    :cond_892
    const/16 v9, 0x174

    move-object/from16 v0, v17

    invoke-virtual {v15, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto/16 :goto_7fe

    :cond_89b
    add-int/lit8 v19, v19, 0x1

    goto :goto_84a

    :cond_89e
    const/16 v9, 0x1199

    new-instance v11, Lae;

    nop

    const/16 v9, 0xc69

    invoke-direct {v11, v14, v15}, Lae;-><init>(Ljava/util/ArrayList;Ljava/util/ArrayList;)V

    check-cast v11, Ljava/lang/Object;

    return-object v11

    :pswitch_8ab  #0x0
    const/4 v9, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v9, 0xbfa

    sget-object v12, Lg4;->c:Ljava/util/List;

    nop

    check-cast v12, Ljava/lang/Iterable;

    const/16 v9, 0xd7

    new-instance v13, Ljava/util/ArrayList;

    nop

    const/16 v9, 0x16b

    invoke-direct {v13}, Ljava/util/ArrayList;-><init>()V

    const/16 v9, 0x429

    invoke-interface {v12}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v12

    :cond_8c8
    :goto_8c8
    const/16 v9, 0x13e

    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_8ea

    const/16 v9, 0x16e

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    move-object/from16 v19, v14

    check-cast v19, Ljava/lang/String;

    const/16 v9, 0x7c

    move-object/from16 v0, v19

    invoke-static {v0}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v19

    if-nez v19, :cond_8c8

    const/16 v9, 0x174

    invoke-virtual {v13, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_8c8

    :cond_8ea
    const/16 v9, 0x48a

    new-instance v12, Ljava/util/LinkedHashSet;

    nop

    const/16 v9, 0xf5b

    invoke-direct {v12, v13}, Ljava/util/LinkedHashSet;-><init>(Ljava/util/Collection;)V

    const/16 v9, 0x10eb

    invoke-static {v12}, Lbs;->C0(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v12

    const/16 v9, 0xf35

    sget-object v13, Lg4;->d:Ljava/lang/String;

    nop

    const/4 v9, -0x6

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v9, 0x108

    new-instance v14, Landroid/os/Bundle;

    nop

    const/16 v9, 0x198

    invoke-direct {v14}, Landroid/os/Bundle;-><init>()V

    const-string/jumbo v19, "B3EEABB8EE11C2BE770B684D95219ECB"

    check-cast v19, Ljava/lang/String;

    filled-new-array/range {v19 .. v19}, [Ljava/lang/String;

    move-result-object v19

    const/16 v9, 0xd7

    new-instance v20, Ljava/util/ArrayList;

    nop

    const/16 v9, 0x434

    new-instance v21, Lie;

    nop

    const/16 v9, 0x324

    move-object/from16 v0, v21

    move-object/from16 v1, v19

    move/from16 v2, v17

    invoke-direct {v0, v1, v2}, Lie;-><init>([Ljava/lang/Object;Z)V

    const/16 v9, 0x489

    move-object/from16 v0, v20

    move-object/from16 v1, v21

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/16 v9, 0xb0a

    sget-object v19, Lqt1;->b:Lqt1;

    nop

    const-string/jumbo v20, "B3EEABB8EE11C2BE770B684D95219ECB"

    check-cast v20, Ljava/lang/String;

    filled-new-array/range {v20 .. v20}, [Ljava/lang/String;

    move-result-object v20

    const/16 v9, 0xd7

    new-instance v21, Ljava/util/ArrayList;

    nop

    const/16 v9, 0x434

    new-instance v22, Lie;

    nop

    const/16 v9, 0x324

    move-object/from16 v0, v22

    move-object/from16 v1, v20

    move/from16 v2, v17

    invoke-direct {v0, v1, v2}, Lie;-><init>([Ljava/lang/Object;Z)V

    const/16 v9, 0x489

    move-object/from16 v0, v21

    move-object/from16 v1, v22

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/16 v9, 0xa43

    sget-object v20, Lrt1;->b:Lrt1;

    nop

    const/16 v9, 0x15b

    move-object/from16 v0, v21

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/16 v9, 0x12a

    move-object/from16 v0, v21

    invoke-virtual {v0, v12}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    const-string/jumbo v12, "B3EEABB8EE11C2BE770B684D95219ECB"

    const/16 v9, 0x174

    move-object/from16 v0, v21

    invoke-virtual {v0, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/16 v9, 0xf77

    new-instance v12, Lut1;

    nop

    const/16 v9, 0xfcb

    move-object/from16 v0, v19

    move-object/from16 v1, v21

    move-object/from16 v2, v20

    invoke-direct {v12, v0, v1, v2}, Lut1;-><init>(Lqt1;Ljava/util/ArrayList;Lrt1;)V

    const/16 v9, 0x11ed

    new-instance v19, Lfm0;

    nop

    const/16 v9, 0x973

    move-object/from16 v0, v19

    invoke-direct {v0, v13, v12, v14}, Lfm0;-><init>(Ljava/lang/String;Lut1;Landroid/os/Bundle;)V

    const/16 v9, 0x20

    iget-object v13, v11, Lc4;->u:Ljava/lang/Object;

    nop

    check-cast v13, Landroid/content/Context;

    const/16 v9, 0x53

    invoke-virtual {v13}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v13

    const/4 v9, -0x6

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v9, 0x20

    iget-object v11, v11, Lc4;->u:Ljava/lang/Object;

    nop

    check-cast v11, Landroid/content/Context;

    const/16 v9, 0xe90

    new-instance v14, Lb4;

    nop

    const/16 v9, 0xafd

    invoke-direct {v14, v11}, Lb4;-><init>(Landroid/content/Context;)V

    const/16 v9, 0x3d3

    sget-object v11, Lo43;->a:Lads_mobile_sdk/ru0;

    nop

    const/4 v9, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v9, 0x53

    invoke-virtual {v13}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v11

    instance-of v0, v11, Landroid/app/Application;

    move/from16 v20, v0

    if-eqz v20, :cond_b27

    const/16 v9, 0x105a

    sget-object v20, Lads_mobile_sdk/ru0;->d:Ljava/util/concurrent/atomic/AtomicBoolean;

    nop

    const/16 v9, 0xbd5

    move-object/from16 v0, v20

    move/from16 v1, v16

    move/from16 v2, v17

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result v20

    if-eqz v20, :cond_a8a

    const/16 v9, 0xa86

    sget v20, Lads_mobile_sdk/qw;->k:I

    nop

    const/16 v9, 0x424

    sget-object v20, Lv60;->b:Lp80;

    nop

    const-string/jumbo v20, "WebView"

    const/16 v9, 0xf21

    new-instance v21, Lads_mobile_sdk/tf3;

    nop

    const/16 v9, 0xfff

    move-object/from16 v0, v21

    move-object/from16 v1, v20

    invoke-direct {v0, v1}, Lads_mobile_sdk/tf3;-><init>(Ljava/lang/String;)V

    move-object/from16 v28, v21

    const/16 v9, 0x113e

    new-instance v21, Ljava/util/concurrent/ThreadPoolExecutor;

    nop

    const/16 v9, 0xd58

    sget-object v20, Ly60;->e:Ly60;

    nop

    const-wide/16 v22, 0x0

    const/16 v9, 0x10a3

    move-wide/from16 v0, v22

    move-object/from16 v2, v20

    invoke-static {v0, v1, v2}, Lv60;->l(JLy60;)J

    move-result-wide v24

    const/16 v9, 0x887

    sget-object v26, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    nop

    const/16 v9, 0x11cb

    new-instance v27, Ljava/util/concurrent/LinkedBlockingQueue;

    nop

    const/16 v9, 0x53c

    move-object/from16 v0, v27

    invoke-direct {v0}, Ljava/util/concurrent/LinkedBlockingQueue;-><init>()V

    const/16 v22, 0x1

    move/from16 v23, v22

    const/16 v9, 0x933

    move v0, v9

    move-object/from16 v1, v21

    move/from16 v2, v22

    move/from16 v3, v23

    move-wide/from16 v4, v24

    move-object/from16 v6, v26

    move-object/from16 v7, v27

    move-object/from16 v8, v28

    invoke-direct/range {v1 .. v8}, Ljava/util/concurrent/ThreadPoolExecutor;-><init>(IIJLjava/util/concurrent/TimeUnit;Ljava/util/concurrent/BlockingQueue;Ljava/util/concurrent/ThreadFactory;)V

    const/16 v9, 0x743

    new-instance v20, Loa1;

    nop

    const/16 v9, 0x780

    move-object/from16 v0, v20

    move-object/from16 v1, v21

    invoke-direct {v0, v1}, Loa1;-><init>(Ljava/util/concurrent/ThreadPoolExecutor;)V

    const/16 v9, 0xa77

    new-instance v21, Lzb0;

    nop

    const/16 v9, 0x604

    move-object/from16 v0, v21

    move-object/from16 v1, v20

    invoke-direct {v0, v1}, Lzb0;-><init>(Ljava/util/concurrent/Executor;)V

    const/16 v9, 0xf43

    move-object/from16 v0, v21

    invoke-static {v0}, Lw53;->a(Lly;)Lsx;

    move-result-object v20

    const/16 v9, 0x23

    new-instance v21, Lc4;

    nop

    move-object/from16 v22, v11

    check-cast v22, Landroid/app/Application;

    const/16 v23, 0xf

    const/16 v9, 0x22

    move-object/from16 v0, v21

    move-object/from16 v1, v22

    move-object/from16 v2, v18

    move/from16 v3, v23

    invoke-direct {v0, v1, v2, v3}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    const/16 v9, 0xb3

    move v0, v9

    move-object/from16 v1, v20

    move-object/from16 v2, v18

    move-object/from16 v3, v18

    move-object/from16 v4, v21

    move v5, v15

    invoke-static/range {v1 .. v5}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    :cond_a8a
    const/16 v9, 0xc37

    sget-object v20, Lads_mobile_sdk/ru0;->b:Lads_mobile_sdk/e7;

    nop

    const/16 v9, 0x6d3

    new-instance v21, Lads_mobile_sdk/i13;

    nop

    check-cast v11, Landroid/app/Application;

    const/16 v9, 0xdca

    move-object/from16 v0, v21

    invoke-direct {v0, v15, v13, v11}, Lads_mobile_sdk/i13;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    monitor-enter v20

    :try_start_a9e
    const/16 v9, 0xc30

    move-object/from16 v0, v20

    iget-object v11, v0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    nop

    if-nez v11, :cond_ab8

    const/16 v9, 0x609

    move-object/from16 v0, v21

    invoke-virtual {v0}, Lads_mobile_sdk/i13;->invoke()Ljava/lang/Object;

    move-result-object v11

    const/16 v9, 0xcfa

    move-object/from16 v0, v20

    iput-object v11, v0, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;
    :try_end_ab5
    .catchall {:try_start_a9e .. :try_end_ab5} :catchall_ab6

    goto :goto_ab8

    :catchall_ab6
    move-exception v11

    goto :goto_b25

    :cond_ab8
    :goto_ab8
    monitor-exit v20

    check-cast v11, Lo43;

    check-cast v11, Lads_mobile_sdk/sb0;

    const/16 v9, 0x870

    iget-object v13, v11, Lads_mobile_sdk/sb0;->d:Ltv2;

    nop

    const/16 v9, 0x1e8

    invoke-interface {v13}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lads_mobile_sdk/i41;

    const/16 v9, 0x61d

    move-object/from16 v0, v19

    iput-object v0, v13, Lads_mobile_sdk/i41;->a:Lfm0;

    const/16 v9, 0xf2e

    iget-object v13, v11, Lads_mobile_sdk/sb0;->a1:Ltv2;

    nop

    const/16 v9, 0x1e8

    invoke-interface {v13}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lads_mobile_sdk/cu2;

    const/16 v9, 0x617

    iget-object v15, v13, Lads_mobile_sdk/cu2;->a:Lads_mobile_sdk/ji;

    nop

    const/16 v9, 0x1022

    sget-object v19, Lads_mobile_sdk/cu2;->b:[Liy0;

    nop

    aget-object v16, v19, v16

    const/16 v9, 0x1037

    move-object/from16 v0, v16

    invoke-virtual {v15, v13, v0, v12}, Lads_mobile_sdk/ji;->setValue(Ljava/lang/Object;Liy0;Ljava/lang/Object;)V

    const/16 v9, 0xcf8

    iget-object v11, v11, Lads_mobile_sdk/sb0;->T2:Ltv2;

    nop

    const/16 v9, 0x1e8

    invoke-interface {v11}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lads_mobile_sdk/rf1;

    const/4 v9, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v9, 0xc4d

    new-instance v12, Lads_mobile_sdk/cf1;

    nop

    const/16 v9, 0x878

    move v0, v9

    move-object v1, v12

    move-object v2, v11

    move-object v3, v14

    move-object/from16 v4, v18

    move/from16 v5, v17

    invoke-direct/range {v1 .. v5}, Lads_mobile_sdk/cf1;-><init>(Lads_mobile_sdk/rf1;Lb4;Lvx;I)V

    const/16 v9, 0x839

    invoke-static {v12}, Lw53;->R(Lpk0;)Ljava/lang/Object;

    const/16 v9, 0xd50

    sget-object v11, Lqk;->l:Ljava/lang/Object;

    nop

    monitor-enter v11

    monitor-exit v11

    const/16 v9, 0x21

    sget-object v18, Lrg2;->a:Lrg2;

    nop

    goto :goto_b2f

    :goto_b25
    monitor-exit v20

    throw v11

    :cond_b27
    const-string/jumbo v11, "The provided application context is not an instance of Application. The Google Mobile Ads SDK should not be used from contexts like BroadcastReceivers, only Services and Activities."

    const/16 v9, 0x52e

    invoke-static {v11}, Lz6;->s(Ljava/lang/String;)V

    :goto_b2f
    check-cast v18, Ljava/lang/Object;

    return-object v18

    :pswitch_data_b32
    .packed-switch 0x0
        :pswitch_8ab  #00000000
        :pswitch_77e  #00000001
        :pswitch_743  #00000002
        :pswitch_6c5  #00000003
        :pswitch_6ab  #00000004
        :pswitch_65b  #00000005
        :pswitch_5b7  #00000006
        :pswitch_576  #00000007
        :pswitch_568  #00000008
        :pswitch_4e8  #00000009
        :pswitch_37b  #0000000a
        :pswitch_315  #0000000b
        :pswitch_2d2  #0000000c
        :pswitch_2b8  #0000000d
        :pswitch_29e  #0000000e
        :pswitch_1ce  #0000000f
        :pswitch_1b4  #00000010
        :pswitch_155  #00000011
        :pswitch_13b  #00000012
        :pswitch_bb  #00000013
        :pswitch_6e  #00000014
        :pswitch_60  #00000015
        :pswitch_21  #00000016
    .end packed-switch
.end method
