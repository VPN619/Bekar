.class public final synthetic Lzg;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;


# direct methods
.method public synthetic constructor <init>(Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;I)V
    .registers 5

    iput p2, p0, Lzg;->a:I

    iput-object p1, p0, Lzg;->b:Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 7

    .prologue
    const/16 v0, 0xb3e

    iget p1, p0, Lzg;->a:I

    nop

    const/16 v0, 0xce0

    iget-object p0, p0, Lzg;->b:Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;

    nop

    packed-switch p1, :pswitch_data_58

    const/16 v0, 0x3ad

    sget p1, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;->o:I

    nop

    const/16 v0, 0x337

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;->finish()V

    return-void

    :pswitch_18  #0x1
    const/16 v0, 0x2c7

    iget-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;->k:Landroid/widget/TextView;

    nop

    const-string/jumbo v2, "msginfo"

    const/4 v3, 0x0

    if-eqz p1, :cond_48

    const/16 v4, 0x8

    const/4 v0, -0x5

    invoke-virtual {p1, v4}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0x2c7

    iget-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;->k:Landroid/widget/TextView;

    nop

    if-eqz p1, :cond_43

    const/4 v2, 0x0

    const/4 v0, -0x5

    invoke-virtual {p1, v2}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0xe22

    iget-object p0, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;->n:Lm3;

    nop

    const-string/jumbo p1, "android.permission.POST_NOTIFICATIONS"

    const/16 v0, 0xad

    invoke-virtual {p0, p1, v3}, Lm3;->a(Ljava/lang/Object;Lf3;)V

    return-void

    :cond_43
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_48
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :pswitch_4d  #0x0
    const/16 v0, 0x3ad

    sget p1, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;->o:I

    nop

    const/16 v0, 0x337

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;->finish()V

    return-void

    :pswitch_data_58
    .packed-switch 0x0
        :pswitch_4d  #00000000
        :pswitch_18  #00000001
    .end packed-switch
.end method
