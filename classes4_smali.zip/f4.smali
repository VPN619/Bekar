.class public final Lf4;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lyu1;


# instance fields
.field public final synthetic a:Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;

.field public final synthetic b:Lsr1;

.field public final synthetic c:Landroid/content/SharedPreferences;


# direct methods
.method public constructor <init>(Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;Lsr1;Landroid/content/SharedPreferences;)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x10f3

    iput-object p1, p0, Lf4;->a:Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;

    const/16 v0, 0x574

    iput-object p2, p0, Lf4;->b:Lsr1;

    const/16 v0, 0x5ea

    iput-object p3, p0, Lf4;->c:Landroid/content/SharedPreferences;

    return-void
.end method


# virtual methods
.method public final onAdDismissedFullScreenContent()V
    .registers 13

    .prologue
    const/16 v1, 0x140

    sget-boolean v3, Lg4;->a:Z

    nop

    const/4 v3, 0x0

    const/16 v1, 0x881

    sput-boolean v3, Lg4;->j:Z

    const/4 v4, 0x0

    const/16 v1, 0xd9f

    sput-object v4, Lg4;->A:Lxu1;

    const/16 v1, 0xfb2

    iget-object v4, p0, Lf4;->b:Lsr1;

    nop

    const/16 v1, 0x701

    iget-boolean v4, v4, Lsr1;->a:Z

    nop

    const/16 v1, 0xca1

    iget-object v5, p0, Lf4;->a:Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;

    nop

    if-nez v4, :cond_32

    const/16 v1, 0x22e

    new-instance p0, Lzs1;

    nop

    const/4 v4, 0x2

    const/16 v1, 0x1d4

    invoke-direct {p0, v5, v4}, Lzs1;-><init>(Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;I)V

    const/16 v1, 0x147

    invoke-virtual {v5, p0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    goto/16 :goto_e1

    :cond_32
    const/16 v1, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v6

    const/16 v1, 0x713

    sput-wide v6, Lg4;->i:J

    const/16 v1, 0xc0e

    sput-wide v6, Lg4;->l:J

    const/16 v1, 0x123

    sget-object v4, Lpp1;->a:Lv0;

    nop

    const/16 v1, 0x1196

    invoke-virtual {v4}, Lpp1;->j()J

    move-result-wide v6

    const/16 v1, 0x979

    iget-object p0, p0, Lf4;->c:Landroid/content/SharedPreferences;

    nop

    const/16 v1, 0x622

    invoke-static {p0}, Lg4;->i(Landroid/content/SharedPreferences;)Z

    move-result v4

    const/4 v8, 0x1

    if-eqz v4, :cond_a3

    const-string/jumbo v4, "adXs5SFd"

    const/16 v1, 0xb0

    invoke-interface {p0, v4, v3}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v4

    const/16 v9, 0x18

    if-lt v4, v9, :cond_68

    move v4, v8

    goto :goto_69

    :cond_68
    move v4, v3

    :goto_69
    const/16 v1, 0x1179

    invoke-static {}, Lj$/time/LocalDateTime;->now()Lj$/time/LocalDateTime;

    move-result-object v9

    const-wide/16 v10, 0x1

    if-eqz v4, :cond_85

    const/16 v1, 0xc21

    invoke-virtual {v9, v10, v11}, Lj$/time/LocalDateTime;->plusDays(J)Lj$/time/LocalDateTime;

    move-result-object v4

    const/16 v1, 0x1055

    sget-object v10, Lj$/time/temporal/ChronoUnit;->DAYS:Lj$/time/temporal/ChronoUnit;

    nop

    const/16 v1, 0x42b

    invoke-virtual {v4, v10}, Lj$/time/LocalDateTime;->truncatedTo(Lj$/time/temporal/TemporalUnit;)Lj$/time/LocalDateTime;

    move-result-object v4

    goto :goto_96

    :cond_85
    const/16 v1, 0xf06

    invoke-virtual {v9, v10, v11}, Lj$/time/LocalDateTime;->plusHours(J)Lj$/time/LocalDateTime;

    move-result-object v4

    const/16 v1, 0xef1

    sget-object v10, Lj$/time/temporal/ChronoUnit;->HOURS:Lj$/time/temporal/ChronoUnit;

    nop

    const/16 v1, 0x42b

    invoke-virtual {v4, v10}, Lj$/time/LocalDateTime;->truncatedTo(Lj$/time/temporal/TemporalUnit;)Lj$/time/LocalDateTime;

    move-result-object v4

    :goto_96
    const/16 v1, 0x658

    invoke-static {v9, v4}, Lj$/time/Duration;->between(Lj$/time/temporal/Temporal;Lj$/time/temporal/Temporal;)Lj$/time/Duration;

    move-result-object v4

    const/16 v1, 0x857

    invoke-virtual {v4}, Lj$/time/Duration;->toMillis()J

    move-result-wide v9

    add-long/2addr v6, v9

    :cond_a3
    const/16 v1, 0x2e6

    sget-wide v9, Lg4;->l:J

    nop

    add-long/2addr v9, v6

    const/16 v1, 0xa95

    sput-wide v9, Lg4;->k:J

    const/16 v1, 0x7a

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo v4, "lrtms"

    const/16 v1, 0x2e6

    sget-wide v9, Lg4;->l:J

    nop

    const/16 v1, 0x37a

    invoke-interface {p0, v4, v9, v10}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    const-string/jumbo v4, "nrtms"

    const/16 v1, 0x5f5

    sget-wide v9, Lg4;->k:J

    nop

    const/16 v1, 0x37a

    invoke-interface {p0, v4, v9, v10}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    const/16 v1, 0x6f

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/16 v1, 0x53

    invoke-virtual {v5}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v1, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v1, 0x9a8

    invoke-static {p0, v6, v7, v8}, Lg4;->l(Landroid/content/Context;JZ)V

    :goto_e1
    const/16 v1, 0x154

    sget-object p0, Lg4;->m:Ljava/util/ArrayList;

    nop

    const/16 v1, 0xac

    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v4

    :goto_ec
    if-ge v3, v4, :cond_fe

    const/16 v1, 0x43

    invoke-virtual {p0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    add-int/lit8 v3, v3, 0x1

    check-cast v5, Lzj0;

    const/16 v1, 0xfe9

    invoke-interface {v5}, Lzj0;->invoke()Ljava/lang/Object;

    goto :goto_ec

    :cond_fe
    const/16 v1, 0x154

    sget-object p0, Lg4;->m:Ljava/util/ArrayList;

    nop

    const/16 v1, 0x15b

    invoke-virtual {p0}, Ljava/util/ArrayList;->clear()V

    return-void
.end method

.method public final onAdFailedToShowFullScreenContent(Lxj0;)V
    .registers 6

    .prologue
    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, -0x3

    new-instance v2, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v3, "Erro ao exibir Rewarded ("

    const/16 v0, 0x97

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0xad8

    iget v3, p1, Lxj0;->j:I

    nop

    const/16 v0, 0xbbf

    invoke-static {v3}, Lc33;->y(I)Ljava/lang/String;

    move-result-object v3

    const/4 v0, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v3, ": "

    const/4 v0, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0xf00

    iget-object p1, p1, Lxj0;->k:Ljava/lang/String;

    nop

    const/4 v0, 0x0

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 p1, 0x29

    const/16 v0, 0x1b

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string/jumbo v2, "Ads-Show"

    nop

    const/4 p1, 0x0

    const/16 v0, 0x881

    sput-boolean p1, Lg4;->j:Z

    const/4 v2, 0x0

    const/16 v0, 0xd9f

    sput-object v2, Lg4;->A:Lxu1;

    const/16 v0, 0x22e

    new-instance v2, Lzs1;

    nop

    const/4 v3, 0x1

    const/16 v0, 0xca1

    iget-object p0, p0, Lf4;->a:Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;

    nop

    const/16 v0, 0x1d4

    invoke-direct {v2, p0, v3}, Lzs1;-><init>(Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;I)V

    const/16 v0, 0x147

    invoke-virtual {p0, v2}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    const/16 v0, 0x154

    sget-object p0, Lg4;->m:Ljava/util/ArrayList;

    nop

    const/16 v0, 0xac

    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v2

    :goto_69
    if-ge p1, v2, :cond_7b

    const/16 v0, 0x43

    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    add-int/lit8 p1, p1, 0x1

    check-cast v3, Lzj0;

    const/16 v0, 0xfe9

    invoke-interface {v3}, Lzj0;->invoke()Ljava/lang/Object;

    goto :goto_69

    :cond_7b
    const/16 v0, 0x154

    sget-object p0, Lg4;->m:Ljava/util/ArrayList;

    nop

    const/16 v0, 0x15b

    invoke-virtual {p0}, Ljava/util/ArrayList;->clear()V

    return-void
.end method

.method public final onAdShowedFullScreenContent()V
    .registers 4

    const/16 v0, 0x140

    sget-boolean p0, Lg4;->a:Z

    nop

    const/4 p0, 0x1

    const/16 v0, 0x881

    sput-boolean p0, Lg4;->j:Z

    const-string/jumbo p0, "Ads-Show"

    const-string/jumbo v2, "O Rewarded foi exibido!"

    nop

    return-void
.end method
