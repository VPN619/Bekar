.class public final synthetic Lfo0;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/tlsvpn/tlstunnel/ui/Home;


# direct methods
.method public synthetic constructor <init>(Lcom/tlsvpn/tlstunnel/ui/Home;I)V
    .registers 5

    iput p2, p0, Lfo0;->a:I

    iput-object p1, p0, Lfo0;->b:Lcom/tlsvpn/tlstunnel/ui/Home;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 8

    .prologue
    const/16 v0, 0x583

    iget p1, p0, Lfo0;->a:I

    nop

    const/16 v0, 0xcc3

    iget-object p0, p0, Lfo0;->b:Lcom/tlsvpn/tlstunnel/ui/Home;

    nop

    packed-switch p1, :pswitch_data_238

    const/16 v0, 0x726

    new-instance p1, Lbq0;

    nop

    const/16 v0, 0x7ed

    invoke-direct {p1}, Lbq0;-><init>()V

    const/16 v0, 0x8b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getParentFragmentManager()Landroidx/fragment/app/p;

    move-result-object v2

    const v3, 0x7f1300fd

    const/16 v0, 0x4c

    invoke-virtual {p0, v3}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x8c

    invoke-virtual {p1, v2, p0}, Landroidx/fragment/app/g;->show(Landroidx/fragment/app/p;Ljava/lang/String;)V

    return-void

    :pswitch_2c  #0x7
    const/16 v0, 0xb50

    iget-boolean p1, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->B:Z

    nop

    if-eqz p1, :cond_34

    goto :goto_52

    :cond_34
    const/16 v0, 0xb8d

    new-instance p1, Lwu;

    nop

    const/16 v0, 0x833

    invoke-direct {p1}, Lwu;-><init>()V

    const/16 v0, 0x8b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getParentFragmentManager()Landroidx/fragment/app/p;

    move-result-object v2

    const v3, 0x7f13017f

    const/16 v0, 0x4c

    invoke-virtual {p0, v3}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x8c

    invoke-virtual {p1, v2, p0}, Landroidx/fragment/app/g;->show(Landroidx/fragment/app/p;Ljava/lang/String;)V

    :goto_52
    return-void

    :pswitch_53  #0x6
    const/16 v0, 0x140

    sget-boolean p1, Lg4;->a:Z

    nop

    const/16 v0, 0xfb

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xc6

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/Home;->b()Landroid/content/SharedPreferences;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x394

    invoke-static {v2, p1}, Lg4;->n(Landroid/content/SharedPreferences;Landroidx/fragment/app/l;)V

    const/16 v0, 0x356

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/Home;->k()V

    const/16 v0, 0xa9

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/Home;->j()V

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p1

    const/16 v0, 0x5b

    new-instance v2, Landroid/content/Intent;

    nop

    const-string/jumbo v3, "reconnect"

    const/16 v0, 0x62

    invoke-direct {v2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p0

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/16 v0, 0x4a

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x64

    invoke-virtual {v2, p0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    const/16 v0, 0x63

    invoke-virtual {p1, p0}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    return-void

    :pswitch_ac  #0x5
    const/16 v0, 0x1200

    new-instance p1, Lnn1;

    nop

    const/16 v0, 0x6df

    invoke-direct {p1}, Lnn1;-><init>()V

    const/16 v0, 0x108

    new-instance v2, Landroid/os/Bundle;

    nop

    const/16 v0, 0x198

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    const-string/jumbo v3, "strnew"

    const-string/jumbo v4, ""

    const/16 v0, 0x76

    invoke-virtual {v2, v3, v4}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v0, 0x19a

    invoke-virtual {p1, v2}, Landroidx/fragment/app/Fragment;->setArguments(Landroid/os/Bundle;)V

    const/16 v0, 0x8b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getParentFragmentManager()Landroidx/fragment/app/p;

    move-result-object v2

    const v3, 0x7f130209

    const/16 v0, 0x4c

    invoke-virtual {p0, v3}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x8c

    invoke-virtual {p1, v2, p0}, Landroidx/fragment/app/g;->show(Landroidx/fragment/app/p;Ljava/lang/String;)V

    return-void

    :pswitch_e5  #0x4
    const/16 v0, 0x2aa

    iget-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->F:Ljava/lang/String;

    nop

    const/16 v0, 0x272

    sget-object v2, Lmi2;->m:Ljava/lang/String;

    nop

    const/16 v0, 0x84

    invoke-static {p1, v2}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_14e

    const/16 v0, 0x10d5

    iget p1, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->G:I

    nop

    if-eqz p1, :cond_14e

    const/16 v0, 0x272

    sget-object p1, Lmi2;->m:Ljava/lang/String;

    nop

    const/16 v0, 0x2aa

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->F:Ljava/lang/String;

    nop

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xa0a

    new-instance v3, Lyz1;

    nop

    const/16 v0, 0xeff

    invoke-direct {v3}, Lyz1;-><init>()V

    const/16 v0, 0x108

    new-instance v4, Landroid/os/Bundle;

    nop

    const/16 v0, 0x198

    invoke-direct {v4}, Landroid/os/Bundle;-><init>()V

    const-string/jumbo v5, "chost"

    const/16 v0, 0x76

    invoke-virtual {v4, v5, p1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const-string/jumbo p1, "shost"

    const/16 v0, 0x76

    invoke-virtual {v4, p1, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v0, 0x19a

    invoke-virtual {v3, v4}, Landroidx/fragment/app/Fragment;->setArguments(Landroid/os/Bundle;)V

    const/16 v0, 0x8b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getParentFragmentManager()Landroidx/fragment/app/p;

    move-result-object p1

    const v2, 0x7f130226

    const/16 v0, 0x4c

    invoke-virtual {p0, v2}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x8c

    invoke-virtual {v3, p1, p0}, Landroidx/fragment/app/g;->show(Landroidx/fragment/app/p;Ljava/lang/String;)V

    goto :goto_179

    :cond_14e
    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p1

    const/16 v0, 0x5b

    new-instance v2, Landroid/content/Intent;

    nop

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p0

    const-class v3, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;

    const/16 v0, 0xd0

    invoke-direct {v2, p0, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string/jumbo p0, "serverh"

    const/16 v0, 0x272

    sget-object v3, Lmi2;->m:Ljava/lang/String;

    nop

    const/16 v0, 0x4b

    invoke-virtual {v2, p0, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    const/16 v0, 0xc9

    invoke-virtual {p1, p0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    :goto_179
    return-void

    :pswitch_17a  #0x3
    const/16 v0, 0x140

    sget-boolean p1, Lg4;->a:Z

    nop

    const/16 v0, 0xfb

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xc6

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/Home;->b()Landroid/content/SharedPreferences;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x394

    invoke-static {v2, p1}, Lg4;->n(Landroid/content/SharedPreferences;Landroidx/fragment/app/l;)V

    const/16 v0, 0x356

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/Home;->k()V

    const/16 v0, 0xca3

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/Home;->i()V

    return-void

    :pswitch_1a3  #0x2
    const/16 v0, 0x35f

    iget-boolean p1, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->C:Z

    nop

    const v2, 0x7f1301fa

    if-eqz p1, :cond_1e1

    const/16 v0, 0x310

    new-instance p1, Ldn1;

    nop

    const/16 v0, 0x3f8

    invoke-direct {p1}, Ldn1;-><init>()V

    const/16 v0, 0x108

    new-instance v3, Landroid/os/Bundle;

    nop

    const/16 v0, 0x198

    invoke-direct {v3}, Landroid/os/Bundle;-><init>()V

    const-string/jumbo v4, "eptalert"

    const/4 v5, 0x0

    const/16 v0, 0x27b

    invoke-virtual {v3, v4, v5}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/16 v0, 0x19a

    invoke-virtual {p1, v3}, Landroidx/fragment/app/Fragment;->setArguments(Landroid/os/Bundle;)V

    const/16 v0, 0x8b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getParentFragmentManager()Landroidx/fragment/app/p;

    move-result-object v3

    const/16 v0, 0x4c

    invoke-virtual {p0, v2}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x8c

    invoke-virtual {p1, v3, p0}, Landroidx/fragment/app/g;->show(Landroidx/fragment/app/p;Ljava/lang/String;)V

    goto :goto_1fc

    :cond_1e1
    const/16 v0, 0xd47

    new-instance p1, Lsu;

    nop

    const/16 v0, 0x102b

    invoke-direct {p1}, Lsu;-><init>()V

    const/16 v0, 0x8b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getParentFragmentManager()Landroidx/fragment/app/p;

    move-result-object v3

    const/16 v0, 0x4c

    invoke-virtual {p0, v2}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x8c

    invoke-virtual {p1, v3, p0}, Landroidx/fragment/app/g;->show(Landroidx/fragment/app/p;Ljava/lang/String;)V

    :goto_1fc
    return-void

    :pswitch_1fd  #0x1
    const/16 v0, 0x629

    new-instance p1, Lvz1;

    nop

    const/16 v0, 0x81a

    invoke-direct {p1}, Lvz1;-><init>()V

    const/16 v0, 0x8b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getParentFragmentManager()Landroidx/fragment/app/p;

    move-result-object v2

    const v3, 0x7f13023e

    const/16 v0, 0x4c

    invoke-virtual {p0, v3}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x8c

    invoke-virtual {p1, v2, p0}, Landroidx/fragment/app/g;->show(Landroidx/fragment/app/p;Ljava/lang/String;)V

    return-void

    :pswitch_21c  #0x0
    const/16 v0, 0xfb

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object p0

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p0, Lcom/tlsvpn/tlstunnel/MainActivity;

    const/16 v0, 0x1f9

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/MainActivity;->h()Lcom/google/android/material/bottomnavigation/BottomNavigationView;

    move-result-object p0

    const p1, 0x7f090319

    const/16 v0, 0x29c

    invoke-virtual {p0, p1}, Lyd1;->setSelectedItemId(I)V

    return-void

    nop

    :pswitch_data_238
    .packed-switch 0x0
        :pswitch_21c  #00000000
        :pswitch_1fd  #00000001
        :pswitch_1a3  #00000002
        :pswitch_17a  #00000003
        :pswitch_e5  #00000004
        :pswitch_ac  #00000005
        :pswitch_53  #00000006
        :pswitch_2c  #00000007
    .end packed-switch
.end method
