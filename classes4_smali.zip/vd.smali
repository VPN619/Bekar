.class public final synthetic Lvd;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 5

    iput p1, p0, Lvd;->a:I

    iput-object p2, p0, Lvd;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 9

    .prologue
    const/16 v0, 0xf37

    iget v2, p0, Lvd;->a:I

    nop

    const v3, 0x7f090130

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    const/16 v0, 0xfc3

    iget-object p0, p0, Lvd;->b:Ljava/lang/Object;

    nop

    packed-switch v2, :pswitch_data_20a

    check-cast p0, Lads_mobile_sdk/rr1;

    const/16 v0, 0x8e3

    invoke-virtual {p0, v6}, Lads_mobile_sdk/rr1;->a(Z)V

    return-void

    :pswitch_1b  #0x19
    check-cast p0, Lcom/vungle/ads/internal/ui/view/n;

    const/16 v0, 0x5ed

    invoke-static {p0, p1}, Lcom/vungle/ads/internal/ui/view/n;->a(Lcom/vungle/ads/internal/ui/view/n;Landroid/view/View;)V

    return-void

    :pswitch_23  #0x18
    check-cast p0, Lads_mobile_sdk/mt0;

    const/4 p1, 0x2

    const/16 v0, 0xf32

    invoke-virtual {p0, p1}, Lads_mobile_sdk/mt0;->a$1(I)V

    return-void

    :pswitch_2c  #0x17
    check-cast p0, Lads_mobile_sdk/jz2;

    const/16 v0, 0xbf6

    iget-object p0, p0, Lads_mobile_sdk/jz2;->g:Ljava/util/concurrent/atomic/AtomicBoolean;

    nop

    const/16 v0, 0x254

    invoke-virtual {p0, v6}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    return-void

    :pswitch_39  #0x16
    check-cast p0, Lx92;

    :try_start_3b
    const/16 v0, 0x5b

    new-instance p1, Landroid/content/Intent;

    nop

    const-string/jumbo v2, "android.intent.action.VIEW"

    const/16 v0, 0x62

    invoke-direct {p1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string/jumbo v2, "https://t.me/tlstunnelinfo"

    const/16 v0, 0x985

    invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    const/16 v0, 0x11c6

    invoke-virtual {p1, v2}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    const/16 v0, 0x634

    invoke-virtual {p0, p1}, Landroidx/fragment/app/Fragment;->startActivity(Landroid/content/Intent;)V
    :try_end_5b
    .catch Ljava/lang/Exception; {:try_start_3b .. :try_end_5b} :catch_5b

    :catch_5b
    const/16 v0, 0x181

    invoke-virtual {p0}, Landroidx/fragment/app/g;->dismiss()V

    return-void

    :pswitch_61  #0x15
    check-cast p0, Lcom/mbridge/msdk/config/dynamic/baseview/cusview/SoundImageView;

    const/16 v0, 0xb04

    invoke-static {p0, p1}, Lcom/mbridge/msdk/config/dynamic/baseview/cusview/SoundImageView;->b(Lcom/mbridge/msdk/config/dynamic/baseview/cusview/SoundImageView;Landroid/view/View;)V

    return-void

    :pswitch_69  #0x14
    check-cast p0, Lrj1;

    const/16 v0, 0x11a

    iget-object p1, p0, Lrj1;->f:Landroid/widget/EditText;

    nop

    if-nez p1, :cond_73

    goto :goto_b4

    :cond_73
    const/16 v0, 0x9c9

    invoke-virtual {p1}, Landroid/widget/TextView;->getSelectionEnd()I

    move-result p1

    const/16 v0, 0x11a

    iget-object v2, p0, Lrj1;->f:Landroid/widget/EditText;

    nop

    if-eqz v2, :cond_8b

    const/16 v0, 0xf0e

    invoke-virtual {v2}, Landroid/widget/TextView;->getTransformationMethod()Landroid/text/method/TransformationMethod;

    move-result-object v2

    instance-of v2, v2, Landroid/text/method/PasswordTransformationMethod;

    if-eqz v2, :cond_8b

    move v5, v6

    :cond_8b
    const/16 v0, 0x11a

    iget-object v2, p0, Lrj1;->f:Landroid/widget/EditText;

    nop

    if-eqz v5, :cond_98

    const/16 v0, 0x4ff

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setTransformationMethod(Landroid/text/method/TransformationMethod;)V

    goto :goto_a3

    :cond_98
    const/16 v0, 0x5e1

    invoke-static {}, Landroid/text/method/PasswordTransformationMethod;->getInstance()Landroid/text/method/PasswordTransformationMethod;

    move-result-object v3

    const/16 v0, 0x4ff

    invoke-virtual {v2, v3}, Landroid/widget/TextView;->setTransformationMethod(Landroid/text/method/TransformationMethod;)V

    :goto_a3
    if-ltz p1, :cond_af

    const/16 v0, 0x11a

    iget-object v2, p0, Lrj1;->f:Landroid/widget/EditText;

    nop

    const/16 v0, 0x10b6

    invoke-virtual {v2, p1}, Landroid/widget/EditText;->setSelection(I)V

    :cond_af
    const/16 v0, 0x33b

    invoke-virtual {p0}, Lra0;->p()V

    :goto_b4
    return-void

    :pswitch_b5  #0x13
    check-cast p0, Lcom/tlsvpn/tlstunnel/ui/Others;

    const/16 v0, 0xfb

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object p0

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p0, Lcom/tlsvpn/tlstunnel/MainActivity;

    const/16 v0, 0x1f9

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/MainActivity;->h()Lcom/google/android/material/bottomnavigation/BottomNavigationView;

    move-result-object p0

    const/16 v0, 0x29c

    invoke-virtual {p0, v3}, Lyd1;->setSelectedItemId(I)V

    return-void

    :pswitch_cf  #0x12
    check-cast p0, Lcom/mbridge/msdk/config/dynamic/baseview/cusview/MoreOfferContainerView;

    const/16 v0, 0x6a5

    invoke-static {p0, p1}, Lcom/mbridge/msdk/config/dynamic/baseview/cusview/MoreOfferContainerView;->c(Lcom/mbridge/msdk/config/dynamic/baseview/cusview/MoreOfferContainerView;Landroid/view/View;)V

    return-void

    :pswitch_d7  #0x11
    check-cast p0, Lk71;

    const/16 v0, 0x841

    invoke-virtual {p0}, Lk71;->c()V

    throw v4

    :pswitch_df  #0x10
    check-cast p0, Lcom/tlsvpn/tlstunnel/ui/Logs;

    const/16 v0, 0xfb

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object p0

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p0, Lcom/tlsvpn/tlstunnel/MainActivity;

    const/16 v0, 0x1f9

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/MainActivity;->h()Lcom/google/android/material/bottomnavigation/BottomNavigationView;

    move-result-object p0

    const/16 v0, 0x29c

    invoke-virtual {p0, v3}, Lyd1;->setSelectedItemId(I)V

    return-void

    :pswitch_f9  #0xf
    check-cast p0, Lqq0;

    const/16 v0, 0x632

    iget-object p1, p0, Lqq0;->w:Landroid/widget/TextView;

    nop

    const/16 v0, 0x275

    invoke-virtual {p1}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string/jumbo v3, ".tls"

    const/16 v0, 0xf39

    invoke-static {v2, v3, v6}, Lc72;->n0(Ljava/lang/CharSequence;Ljava/lang/String;Z)Z

    move-result v2

    const/16 v0, 0xe60

    iget-object p0, p0, Lqq0;->u:Lcom/tlsvpn/tlstunnel/ui/imex/Importar;

    nop

    if-eqz v2, :cond_148

    const/4 v0, -0x3

    new-instance v2, Ljava/lang/StringBuilder;

    nop

    const/4 v0, -0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v0, 0x21e

    iget-object v3, p0, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->m:Ljava/lang/String;

    nop

    const/4 v0, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v3, 0x2f

    const/16 v0, 0x1b

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v0, 0x275

    invoke-virtual {p1}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object p1

    const/16 v0, 0x190

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0x64f

    invoke-virtual {p0, p1, v5}, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->j(Ljava/lang/String;Z)V

    goto :goto_15e

    :cond_148
    const/16 v0, 0x275

    invoke-virtual {p1}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object p1

    const/16 v0, 0xcb

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0xfe2

    sget v2, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->o:I

    nop

    const/16 v0, 0x54b

    invoke-virtual {p0, p1}, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->g(Ljava/lang/String;)V

    :goto_15e
    return-void

    :pswitch_15f  #0xe
    check-cast p0, Lu60;

    const/16 v0, 0xd64

    invoke-virtual {p0}, Lu60;->t()V

    return-void

    :pswitch_167  #0xd
    check-cast p0, Lcom/mbridge/msdk/config/dynamic/baseview/webview/ComponentWebView;

    const/16 v0, 0xb73

    invoke-static {p0, p1}, Lcom/mbridge/msdk/config/dynamic/baseview/webview/ComponentWebView;->a(Lcom/mbridge/msdk/config/dynamic/baseview/webview/ComponentWebView;Landroid/view/View;)V

    return-void

    :pswitch_16f  #0xc
    check-cast p0, Lcom/mbridge/msdk/config/dynamic/baseview/ComponentTextView;

    const/16 v0, 0x94c

    invoke-static {p0, p1}, Lcom/mbridge/msdk/config/dynamic/baseview/ComponentTextView;->a(Lcom/mbridge/msdk/config/dynamic/baseview/ComponentTextView;Landroid/view/View;)V

    return-void

    :pswitch_177  #0xb
    check-cast p0, Lcom/mbridge/msdk/config/dynamic/baseview/ComponentScrollView;

    const/16 v0, 0x57f

    invoke-static {p0, p1}, Lcom/mbridge/msdk/config/dynamic/baseview/ComponentScrollView;->a(Lcom/mbridge/msdk/config/dynamic/baseview/ComponentScrollView;Landroid/view/View;)V

    return-void

    :pswitch_17f  #0xa
    check-cast p0, Lcom/mbridge/msdk/config/dynamic/baseview/ComponentRelativeLayout;

    const/16 v0, 0x602

    invoke-static {p0, p1}, Lcom/mbridge/msdk/config/dynamic/baseview/ComponentRelativeLayout;->a(Lcom/mbridge/msdk/config/dynamic/baseview/ComponentRelativeLayout;Landroid/view/View;)V

    return-void

    :pswitch_187  #0x9
    check-cast p0, Lcom/mbridge/msdk/config/dynamic/baseview/ComponentListView;

    const/16 v0, 0xbc8

    invoke-static {p0, p1}, Lcom/mbridge/msdk/config/dynamic/baseview/ComponentListView;->a(Lcom/mbridge/msdk/config/dynamic/baseview/ComponentListView;Landroid/view/View;)V

    return-void

    :pswitch_18f  #0x8
    check-cast p0, Lcom/mbridge/msdk/config/dynamic/baseview/ComponentLinearLayout;

    const/16 v0, 0x1044

    invoke-static {p0, p1}, Lcom/mbridge/msdk/config/dynamic/baseview/ComponentLinearLayout;->a(Lcom/mbridge/msdk/config/dynamic/baseview/ComponentLinearLayout;Landroid/view/View;)V

    return-void

    :pswitch_197  #0x7
    check-cast p0, Lcom/mbridge/msdk/config/dynamic/baseview/ComponentInduceClickView;

    const/16 v0, 0xba1

    invoke-static {p0, p1}, Lcom/mbridge/msdk/config/dynamic/baseview/ComponentInduceClickView;->a(Lcom/mbridge/msdk/config/dynamic/baseview/ComponentInduceClickView;Landroid/view/View;)V

    return-void

    :pswitch_19f  #0x6
    check-cast p0, Lcom/mbridge/msdk/config/dynamic/baseview/ComponentImageView;

    const/16 v0, 0x1051

    invoke-static {p0, p1}, Lcom/mbridge/msdk/config/dynamic/baseview/ComponentImageView;->a(Lcom/mbridge/msdk/config/dynamic/baseview/ComponentImageView;Landroid/view/View;)V

    return-void

    :pswitch_1a7  #0x5
    check-cast p0, Lcom/mbridge/msdk/config/dynamic/baseview/ComponentHorizontalScrollView;

    const/16 v0, 0x543

    invoke-static {p0, p1}, Lcom/mbridge/msdk/config/dynamic/baseview/ComponentHorizontalScrollView;->a(Lcom/mbridge/msdk/config/dynamic/baseview/ComponentHorizontalScrollView;Landroid/view/View;)V

    return-void

    :pswitch_1af  #0x4
    check-cast p0, Lcom/mbridge/msdk/config/dynamic/baseview/ComponentGridView;

    const/16 v0, 0x639

    invoke-static {p0, p1}, Lcom/mbridge/msdk/config/dynamic/baseview/ComponentGridView;->a(Lcom/mbridge/msdk/config/dynamic/baseview/ComponentGridView;Landroid/view/View;)V

    return-void

    :pswitch_1b7  #0x3
    check-cast p0, Lcom/mbridge/msdk/config/dynamic/baseview/ComponentFrameLayout;

    const/16 v0, 0xb80

    invoke-static {p0, p1}, Lcom/mbridge/msdk/config/dynamic/baseview/ComponentFrameLayout;->a(Lcom/mbridge/msdk/config/dynamic/baseview/ComponentFrameLayout;Landroid/view/View;)V

    return-void

    :pswitch_1bf  #0x2
    check-cast p0, Lcom/mbridge/msdk/config/dynamic/baseview/ComponentButton;

    const/16 v0, 0xf07

    invoke-static {p0, p1}, Lcom/mbridge/msdk/config/dynamic/baseview/ComponentButton;->a(Lcom/mbridge/msdk/config/dynamic/baseview/ComponentButton;Landroid/view/View;)V

    return-void

    :pswitch_1c7  #0x1
    check-cast p0, Lwq;

    const/16 v0, 0x431

    iget-object v2, p0, Lwq;->i:Landroid/widget/EditText;

    nop

    if-nez v2, :cond_1d1

    goto :goto_1f5

    :cond_1d1
    const/16 v0, 0x2d

    invoke-virtual {v2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v2

    const/16 v0, 0x71d

    invoke-virtual {p1}, Landroid/view/View;->hasFocus()Z

    move-result p1

    if-eqz p1, :cond_1e9

    const/16 v0, 0x431

    iget-object p1, p0, Lwq;->i:Landroid/widget/EditText;

    nop

    const/16 v0, 0xc4

    invoke-virtual {p1}, Landroid/view/View;->requestFocus()Z

    :cond_1e9
    if-eqz v2, :cond_1f0

    const/16 v0, 0x93b

    invoke-interface {v2}, Landroid/text/Editable;->clear()V

    :cond_1f0
    const/16 v0, 0x33b

    invoke-virtual {p0}, Lra0;->p()V

    :goto_1f5
    return-void

    :pswitch_1f6  #0x0
    check-cast p0, Lwd;

    const/16 v0, 0xb0c

    iget-object p0, p0, Lwd;->x:Landroid/widget/CheckBox;

    nop

    const/16 v0, 0x36

    invoke-virtual {p0}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result p1

    xor-int/2addr p1, v6

    const/16 v0, 0x7e

    invoke-virtual {p0, p1}, Landroid/widget/CompoundButton;->setChecked(Z)V

    return-void

    :pswitch_data_20a
    .packed-switch 0x0
        :pswitch_1f6  #00000000
        :pswitch_1c7  #00000001
        :pswitch_1bf  #00000002
        :pswitch_1b7  #00000003
        :pswitch_1af  #00000004
        :pswitch_1a7  #00000005
        :pswitch_19f  #00000006
        :pswitch_197  #00000007
        :pswitch_18f  #00000008
        :pswitch_187  #00000009
        :pswitch_17f  #0000000a
        :pswitch_177  #0000000b
        :pswitch_16f  #0000000c
        :pswitch_167  #0000000d
        :pswitch_15f  #0000000e
        :pswitch_f9  #0000000f
        :pswitch_df  #00000010
        :pswitch_d7  #00000011
        :pswitch_cf  #00000012
        :pswitch_b5  #00000013
        :pswitch_69  #00000014
        :pswitch_61  #00000015
        :pswitch_39  #00000016
        :pswitch_2c  #00000017
        :pswitch_23  #00000018
        :pswitch_1b  #00000019
    .end packed-switch
.end method
