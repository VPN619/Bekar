.class public final synthetic Lvh0;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lrm1;
.implements Ljj1;
.implements Lhj1;
.implements Lxy0;
.implements Lvy0;
.implements Lcom/mbridge/msdk/tracker/f;
.implements Lih1;


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    iput p1, p0, Lvh0;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static synthetic g(ILjava/lang/String;)V
    .registers 3

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public static synthetic h(ILjava/lang/StringBuilder;)V
    .registers 2

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    new-instance p1, Ljava/lang/IndexOutOfBoundsException;

    invoke-direct {p1, p0}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public static bridge synthetic i(Landroid/view/WindowManager$LayoutParams;I)V
    .registers 2

    iput p1, p0, Landroid/view/WindowManager$LayoutParams;->layoutInDisplayCutoutMode:I

    return-void
.end method

.method public static synthetic j(Ljava/lang/Object;Ljava/lang/String;)V
    .registers 4

    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static synthetic k(Ljava/lang/String;)V
    .registers 2

    new-instance v0, Ljava/io/IOException;

    invoke-direct {v0, p0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static synthetic l(Ljava/lang/Throwable;)V
    .registers 2

    new-instance v0, Ljava/lang/RuntimeException;

    invoke-direct {v0, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    throw v0
.end method

.method public static synthetic m(Ljava/lang/Object;Ljava/lang/String;)V
    .registers 4

    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static synthetic n(Ljava/lang/String;)V
    .registers 2

    new-instance v0, Ljava/lang/UnsupportedOperationException;

    invoke-direct {v0, p0}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    throw v0
.end method


# virtual methods
.method public a(Li10;)Lk20;
    .registers 6

    .prologue
    iget p0, p0, Lvh0;->a:I

    sparse-switch p0, :sswitch_data_10e

    check-cast p1, Lp01;

    invoke-static {}, Ltz0;->x()Lsz0;

    move-result-object p0

    iget-object v0, p1, Lp01;->o:Lq01;

    invoke-static {v0}, Lnp3;->e0(Lq01;)Lvz0;

    move-result-object v0

    invoke-virtual {p0}, Lkl0;->e()V

    iget-object v1, p0, Lkl0;->b:Lrl0;

    check-cast v1, Ltz0;

    invoke-virtual {v1, v0}, Ltz0;->A(Lvz0;)V

    invoke-virtual {p0}, Lkl0;->a()Lrl0;

    move-result-object p0

    check-cast p0, Ltz0;

    invoke-virtual {p0}, Ls0;->e()Lvl;

    move-result-object p0

    sget-object v0, Lq5;->i0:Lq5;

    iget-object v1, p1, Lp01;->o:Lq01;

    iget-object v1, v1, Lq01;->a:Lq5;

    sget-object v2, Lq5;->c0:Lq5;

    if-eq v2, v1, :cond_47

    sget-object v2, Lq5;->d0:Lq5;

    if-ne v2, v1, :cond_36

    sget-object v1, Lq5;->m0:Lq5;

    goto :goto_49

    :cond_36
    new-instance p0, Ljava/security/GeneralSecurityException;

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const-string/jumbo v0, "Unable to serialize variant: "

    invoke-virtual {v0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_47
    sget-object v1, Lq5;->k0:Lq5;

    :goto_49
    iget-object p1, p1, Lp01;->q:Ljava/lang/Integer;

    const-string/jumbo v2, "type.googleapis.com/google.crypto.tink.KmsEnvelopeAeadKey"

    invoke-static {v2, p0, v0, v1, p1}, Lk20;->g(Ljava/lang/String;Lyl;Lq5;Lq5;Ljava/lang/Integer;)Lk20;

    move-result-object p0

    return-object p0

    :sswitch_53
    check-cast p1, Ln01;

    invoke-static {}, Lnz0;->x()Lmz0;

    move-result-object p0

    invoke-static {}, Lpz0;->x()Loz0;

    move-result-object v0

    iget-object v1, p1, Ln01;->o:Lo01;

    iget-object v1, v1, Lo01;->a:Ljava/lang/String;

    invoke-virtual {v0}, Lkl0;->e()V

    iget-object v2, v0, Lkl0;->b:Lrl0;

    check-cast v2, Lpz0;

    invoke-virtual {v2, v1}, Lpz0;->z(Ljava/lang/String;)V

    invoke-virtual {v0}, Lkl0;->a()Lrl0;

    move-result-object v0

    check-cast v0, Lpz0;

    invoke-virtual {p0}, Lkl0;->e()V

    iget-object v1, p0, Lkl0;->b:Lrl0;

    check-cast v1, Lnz0;

    invoke-virtual {v1, v0}, Lnz0;->A(Lpz0;)V

    invoke-virtual {p0}, Lkl0;->a()Lrl0;

    move-result-object p0

    check-cast p0, Lnz0;

    invoke-virtual {p0}, Ls0;->e()Lvl;

    move-result-object p0

    sget-object v0, Lq5;->i0:Lq5;

    iget-object v1, p1, Ln01;->o:Lo01;

    iget-object v1, v1, Lo01;->b:Lq5;

    invoke-static {v1}, Lmd3;->K(Lq5;)Lq5;

    move-result-object v1

    iget-object p1, p1, Ln01;->q:Ljava/lang/Integer;

    const-string/jumbo v2, "type.googleapis.com/google.crypto.tink.KmsAeadKey"

    invoke-static {v2, p0, v0, v1, p1}, Lk20;->g(Ljava/lang/String;Lyl;Lq5;Lq5;Ljava/lang/Integer;)Lk20;

    move-result-object p0

    return-object p0

    :sswitch_99
    check-cast p1, Lwn0;

    invoke-static {}, Lvn0;->z()Lun0;

    move-result-object p0

    iget-object v0, p1, Lwn0;->o:Lbo0;

    invoke-static {}, Ldo0;->y()Lco0;

    move-result-object v1

    iget v2, v0, Lbo0;->b:I

    invoke-virtual {v1}, Lkl0;->e()V

    iget-object v3, v1, Lkl0;->b:Lrl0;

    check-cast v3, Ldo0;

    invoke-virtual {v3, v2}, Ldo0;->A(I)V

    sget-object v2, Leo0;->a:Lec;

    iget-object v0, v0, Lbo0;->d:Lao0;

    invoke-virtual {v2, v0}, Lec;->T(Ljava/lang/Object;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, Ldn0;

    invoke-virtual {v1}, Lkl0;->e()V

    iget-object v2, v1, Lkl0;->b:Lrl0;

    check-cast v2, Ldo0;

    invoke-virtual {v2, v0}, Ldo0;->z(Ldn0;)V

    invoke-virtual {v1}, Lkl0;->a()Lrl0;

    move-result-object v0

    check-cast v0, Ldo0;

    invoke-virtual {p0}, Lkl0;->e()V

    iget-object v1, p0, Lkl0;->b:Lrl0;

    check-cast v1, Lvn0;

    invoke-virtual {v1, v0}, Lvn0;->D(Ldo0;)V

    iget-object v0, p1, Lwn0;->p:Loj0;

    iget-object v0, v0, Loj0;->a:Ljava/lang/Object;

    check-cast v0, Lzl;

    invoke-virtual {v0}, Lzl;->b()[B

    move-result-object v0

    const/4 v1, 0x0

    array-length v2, v0

    invoke-static {v0, v1, v2}, Lyl;->d([BII)Lvl;

    move-result-object v0

    invoke-virtual {p0}, Lkl0;->e()V

    iget-object v1, p0, Lkl0;->b:Lrl0;

    check-cast v1, Lvn0;

    invoke-virtual {v1, v0}, Lvn0;->C(Lvl;)V

    invoke-virtual {p0}, Lkl0;->a()Lrl0;

    move-result-object p0

    check-cast p0, Lvn0;

    invoke-virtual {p0}, Ls0;->e()Lvl;

    move-result-object p0

    sget-object v0, Lq5;->f0:Lq5;

    iget-object v1, p1, Lwn0;->o:Lbo0;

    iget-object v1, v1, Lbo0;->c:Lq5;

    invoke-static {v1}, Leo0;->a(Lq5;)Lq5;

    move-result-object v1

    iget-object p1, p1, Lwn0;->r:Ljava/lang/Integer;

    const-string/jumbo v2, "type.googleapis.com/google.crypto.tink.HmacKey"

    invoke-static {v2, p0, v0, v1, p1}, Lk20;->g(Ljava/lang/String;Lyl;Lq5;Lq5;Ljava/lang/Integer;)Lk20;

    move-result-object p0

    return-object p0

    nop

    :sswitch_data_10e
    .sparse-switch
        0x9 -> :sswitch_99
        0x14 -> :sswitch_53
    .end sparse-switch
.end method

.method public a(Lcom/mbridge/msdk/tracker/e;)Z
    .registers 2

    invoke-static {p1}, Lcom/mbridge/msdk/config/component/log/LogCpt;->g(Lcom/mbridge/msdk/tracker/e;)Z

    move-result p0

    return p0
.end method

.method public b(Lk20;)Li10;
    .registers 7

    .prologue
    iget p0, p0, Lvh0;->a:I

    const-string/jumbo v0, "Unable to parse OutputPrefixType: "

    const/4 v1, 0x0

    sparse-switch p0, :sswitch_data_18e

    const-string/jumbo p0, "KmsEnvelopeAeadKeys are only accepted with version 0, got "

    iget-object v2, p1, Lk20;->a:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    const-string/jumbo v3, "type.googleapis.com/google.crypto.tink.KmsEnvelopeAeadKey"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_6f

    :try_start_19
    iget-object v1, p1, Lk20;->b:Ljava/lang/Object;

    check-cast v1, Lyl;

    invoke-static {}, Lrc0;->a()Lrc0;

    move-result-object v2

    invoke-static {v1, v2}, Ltz0;->y(Lyl;Lrc0;)Ltz0;

    move-result-object v1

    invoke-virtual {v1}, Ltz0;->w()I

    move-result v2

    if-nez v2, :cond_57

    invoke-virtual {v1}, Ltz0;->v()Lvz0;

    move-result-object p0

    iget-object v1, p1, Lk20;->d:Ljava/lang/Object;

    check-cast v1, Lq5;

    sget-object v2, Lq5;->k0:Lq5;

    if-ne v1, v2, :cond_38

    goto :goto_3c

    :cond_38
    sget-object v2, Lq5;->m0:Lq5;

    if-ne v1, v2, :cond_49

    :goto_3c
    invoke-static {p0, v2}, Lnp3;->W(Lvz0;Lq5;)Lq01;

    move-result-object p0

    iget-object p1, p1, Lk20;->e:Ljava/lang/Object;

    check-cast p1, Ljava/lang/Integer;

    invoke-static {p0, p1}, Lp01;->U0(Lq01;Ljava/lang/Integer;)Lp01;

    move-result-object v1

    goto :goto_75

    :cond_49
    new-instance p0, Ljava/security/GeneralSecurityException;

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_57
    new-instance p1, Ljava/security/GeneralSecurityException;

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_65
    .catch Lmt0; {:try_start_19 .. :try_end_65} :catch_65

    :catch_65
    move-exception p0

    new-instance p1, Ljava/security/GeneralSecurityException;

    const-string/jumbo v0, "Parsing KmsEnvelopeAeadKey failed: "

    invoke-direct {p1, v0, p0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw p1

    :cond_6f
    const-string/jumbo p0, "Wrong type URL in call to LegacyKmsEnvelopeAeadProtoSerialization.parseKey"

    invoke-static {p0}, Lz6;->s(Ljava/lang/String;)V

    :goto_75
    return-object v1

    :sswitch_76
    const-string/jumbo p0, "KmsAeadKey are only accepted with version 0, got "

    iget-object v2, p1, Lk20;->a:Ljava/lang/Object;

    check-cast v2, Ljava/lang/String;

    const-string/jumbo v3, "type.googleapis.com/google.crypto.tink.KmsAeadKey"

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_e5

    :try_start_86
    iget-object v1, p1, Lk20;->b:Ljava/lang/Object;

    check-cast v1, Lyl;

    invoke-static {}, Lrc0;->a()Lrc0;

    move-result-object v2

    invoke-static {v1, v2}, Lnz0;->y(Lyl;Lrc0;)Lnz0;

    move-result-object v1

    invoke-virtual {v1}, Lnz0;->w()I

    move-result v2

    if-nez v2, :cond_cd

    invoke-virtual {v1}, Lnz0;->v()Lpz0;

    move-result-object p0

    invoke-virtual {p0}, Lpz0;->w()Ljava/lang/String;

    move-result-object p0

    iget-object v1, p1, Lk20;->d:Ljava/lang/Object;

    check-cast v1, Lq5;

    sget-object v2, Lq5;->k0:Lq5;

    if-ne v1, v2, :cond_ab

    sget-object v0, Lq5;->U:Lq5;

    goto :goto_b1

    :cond_ab
    sget-object v2, Lq5;->m0:Lq5;

    if-ne v1, v2, :cond_bf

    sget-object v0, Lq5;->V:Lq5;

    :goto_b1
    new-instance v1, Lo01;

    invoke-direct {v1, p0, v0}, Lo01;-><init>(Ljava/lang/String;Lq5;)V

    iget-object p0, p1, Lk20;->e:Ljava/lang/Object;

    check-cast p0, Ljava/lang/Integer;

    invoke-static {v1, p0}, Ln01;->U0(Lo01;Ljava/lang/Integer;)Ln01;

    move-result-object v1

    goto :goto_eb

    :cond_bf
    new-instance p0, Ljava/security/GeneralSecurityException;

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_cd
    new-instance p1, Ljava/security/GeneralSecurityException;

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_db
    .catch Lmt0; {:try_start_86 .. :try_end_db} :catch_db

    :catch_db
    move-exception p0

    new-instance p1, Ljava/security/GeneralSecurityException;

    const-string/jumbo v0, "Parsing KmsAeadKey failed: "

    invoke-direct {p1, v0, p0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw p1

    :cond_e5
    const-string/jumbo p0, "Wrong type URL in call to LegacyKmsAeadProtoSerialization.parseKey"

    invoke-static {p0}, Lz6;->s(Ljava/lang/String;)V

    :goto_eb
    return-object v1

    :sswitch_ec
    iget-object p0, p1, Lk20;->a:Ljava/lang/Object;

    check-cast p0, Ljava/lang/String;

    const-string/jumbo v0, "type.googleapis.com/google.crypto.tink.HmacKey"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_187

    :try_start_f9
    iget-object p0, p1, Lk20;->b:Ljava/lang/Object;

    check-cast p0, Lyl;

    invoke-static {}, Lrc0;->a()Lrc0;

    move-result-object v0

    invoke-static {p0, v0}, Lvn0;->A(Lyl;Lrc0;)Lvn0;

    move-result-object p0

    invoke-virtual {p0}, Lvn0;->y()I

    move-result v0

    if-nez v0, :cond_177

    invoke-static {}, Lbo0;->b()Lx5;

    move-result-object v0

    invoke-virtual {p0}, Lvn0;->w()Lyl;

    move-result-object v2

    invoke-virtual {v2}, Lyl;->size()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    iput-object v2, v0, Lx5;->b:Ljava/lang/Object;

    invoke-virtual {p0}, Lvn0;->x()Ldo0;

    move-result-object v2

    invoke-virtual {v2}, Ldo0;->x()I

    move-result v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    iput-object v2, v0, Lx5;->c:Ljava/lang/Object;

    sget-object v2, Leo0;->a:Lec;

    invoke-virtual {p0}, Lvn0;->x()Ldo0;

    move-result-object v3

    invoke-virtual {v3}, Ldo0;->w()Ldn0;

    move-result-object v3

    invoke-virtual {v2, v3}, Lec;->B(Ldn0;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lao0;

    iput-object v2, v0, Lx5;->d:Ljava/lang/Object;

    iget-object v2, p1, Lk20;->d:Ljava/lang/Object;

    check-cast v2, Lq5;

    invoke-static {v2}, Leo0;->b(Lq5;)Lq5;

    move-result-object v2

    iput-object v2, v0, Lx5;->e:Ljava/lang/Object;

    invoke-virtual {v0}, Lx5;->e()Lbo0;

    move-result-object v0

    new-instance v2, Ltd;

    const/16 v3, 0x12

    const/4 v4, 0x0

    invoke-direct {v2, v3, v4}, Ltd;-><init>(IZ)V

    iput-object v1, v2, Ltd;->c:Ljava/lang/Object;

    iput-object v1, v2, Ltd;->d:Ljava/lang/Object;

    iput-object v0, v2, Ltd;->b:Ljava/lang/Object;

    invoke-virtual {p0}, Lvn0;->w()Lyl;

    move-result-object p0

    invoke-virtual {p0}, Lyl;->h()[B

    move-result-object p0

    new-instance v0, Loj0;

    invoke-static {p0}, Lzl;->a([B)Lzl;

    move-result-object p0

    invoke-direct {v0, p0}, Loj0;-><init>(Ljava/lang/Object;)V

    iput-object v0, v2, Ltd;->c:Ljava/lang/Object;

    iget-object p0, p1, Lk20;->e:Ljava/lang/Object;

    check-cast p0, Ljava/lang/Integer;

    iput-object p0, v2, Ltd;->d:Ljava/lang/Object;

    invoke-virtual {v2}, Ltd;->l()Lwn0;

    move-result-object v1

    goto :goto_18d

    :cond_177
    new-instance p0, Ljava/security/GeneralSecurityException;

    const-string/jumbo p1, "Only version 0 keys are accepted"

    invoke-direct {p0, p1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p0
    :try_end_180
    .catch Lmt0; {:try_start_f9 .. :try_end_180} :catch_180
    .catch Ljava/lang/IllegalArgumentException; {:try_start_f9 .. :try_end_180} :catch_180

    :catch_180
    const-string/jumbo p0, "Parsing HmacKey failed"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    goto :goto_18d

    :cond_187
    const-string/jumbo p0, "Wrong type URL in call to HmacProtoSerialization.parseKey"

    invoke-static {p0}, Lz6;->s(Ljava/lang/String;)V

    :goto_18d
    return-object v1

    :sswitch_data_18e
    .sparse-switch
        0xa -> :sswitch_ec
        0x15 -> :sswitch_76
    .end sparse-switch
.end method

.method public c(Li10;)Ljava/lang/Object;
    .registers 7

    .prologue
    iget p0, p0, Lvh0;->a:I

    const/4 v0, 0x0

    sparse-switch p0, :sswitch_data_aa

    check-cast p1, Ls01;

    iget-object p0, p1, Ls01;->o:Lk20;

    sget-object v0, Lty0;->d:Lty0;

    iget-object v1, p0, Lk20;->a:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    const-class v2, Lmm1;

    invoke-virtual {v0, v2, v1}, Lty0;->a(Ljava/lang/Class;Ljava/lang/String;)Lm01;

    move-result-object v0

    iget-object v1, p0, Lk20;->b:Ljava/lang/Object;

    check-cast v1, Lyl;

    invoke-virtual {v0, v1}, Lm01;->a(Lyl;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lmm1;

    iget-object p0, p0, Lk20;->d:Ljava/lang/Object;

    check-cast p0, Lq5;

    invoke-static {p0}, Lq23;->a0(Lq5;)Lti1;

    iget-object p1, p1, Ls01;->o:Lk20;

    iget-object p1, p1, Lk20;->e:Ljava/lang/Object;

    check-cast p1, Ljava/lang/Integer;

    invoke-static {p0, p1}, Lq23;->w(Lq5;Ljava/lang/Integer;)Lzl;

    move-result-object p0

    invoke-virtual {p0}, Lzl;->b()[B

    new-instance p0, Lmm1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-object p0

    :sswitch_3a
    check-cast p1, Lp01;

    iget-object p0, p1, Lp01;->o:Lq01;

    iget-object p0, p0, Lq01;->b:Ljava/lang/String;

    invoke-static {p0}, Lrz0;->a(Ljava/lang/String;)V

    throw v0

    :sswitch_44
    check-cast p1, Ln01;

    iget-object p0, p1, Ln01;->o:Lo01;

    iget-object p0, p0, Lo01;->a:Ljava/lang/String;

    invoke-static {p0}, Lrz0;->a(Ljava/lang/String;)V

    throw v0

    :sswitch_4e
    check-cast p1, Lwn0;

    new-instance p0, Lmm1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lfc1;

    iget-object v1, p1, Lwn0;->o:Lbo0;

    iget-object v1, v1, Lbo0;->d:Lao0;

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const-string/jumbo v2, "HMAC"

    invoke-virtual {v2, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    new-instance v3, Ljavax/crypto/spec/SecretKeySpec;

    iget-object v4, p1, Lwn0;->p:Loj0;

    iget-object v4, v4, Loj0;->a:Ljava/lang/Object;

    check-cast v4, Lzl;

    invoke-virtual {v4}, Lzl;->b()[B

    move-result-object v4

    invoke-direct {v3, v4, v2}, Ljavax/crypto/spec/SecretKeySpec;-><init>([BLjava/lang/String;)V

    invoke-direct {v0, v1, v3}, Lfc1;-><init>(Ljava/lang/String;Ljavax/crypto/spec/SecretKeySpec;)V

    iget-object v0, p1, Lwn0;->o:Lbo0;

    iget v1, v0, Lbo0;->b:I

    iget-object p1, p1, Lwn0;->q:Lzl;

    invoke-virtual {p1}, Lzl;->b()[B

    iget-object p1, v0, Lbo0;->c:Lq5;

    sget-object v0, Lq5;->P:Lq5;

    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_91

    sget-object p1, Lmm1;->a:[B

    const/4 v0, 0x1

    invoke-static {p1, v0}, Ljava/util/Arrays;->copyOf([BI)[B

    :cond_91
    return-object p0

    :sswitch_92
    new-instance p0, Lzp;

    check-cast p1, Lwn0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 p1, 0x2

    invoke-static {p1}, Ly41;->f(I)Z

    move-result p1

    if-eqz p1, :cond_a2

    move-object v0, p0

    goto :goto_a8

    :cond_a2
    const-string/jumbo p0, "Can not use HMAC in FIPS-mode, as BoringCrypto module is not available."

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    :goto_a8
    return-object v0

    nop

    :sswitch_data_aa
    .sparse-switch
        0x5 -> :sswitch_92
        0x6 -> :sswitch_4e
        0x10 -> :sswitch_44
        0x11 -> :sswitch_3a
    .end sparse-switch
.end method

.method public d(Ltd;)Lfj1;
    .registers 4

    .prologue
    iget p0, p0, Lvh0;->a:I

    const/4 v0, 0x0

    sparse-switch p0, :sswitch_data_11a

    iget-object p0, p1, Ltd;->c:Ljava/lang/Object;

    check-cast p0, Ljava/lang/String;

    const-string/jumbo v1, "type.googleapis.com/google.crypto.tink.KmsEnvelopeAeadKey"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_32

    :try_start_13
    iget-object p0, p1, Ltd;->b:Ljava/lang/Object;

    check-cast p0, Lyl;

    invoke-static {}, Lrc0;->a()Lrc0;

    move-result-object v0

    invoke-static {p0, v0}, Lvz0;->z(Lyl;Lrc0;)Lvz0;

    move-result-object p0
    :try_end_1f
    .catch Lmt0; {:try_start_13 .. :try_end_1f} :catch_28

    iget-object p1, p1, Ltd;->d:Ljava/lang/Object;

    check-cast p1, Lq5;

    invoke-static {p0, p1}, Lnp3;->W(Lvz0;Lq5;)Lq01;

    move-result-object v0

    goto :goto_3c

    :catch_28
    move-exception p0

    new-instance p1, Ljava/security/GeneralSecurityException;

    const-string/jumbo v0, "Parsing KmsEnvelopeAeadKeyFormat failed: "

    invoke-direct {p1, v0, p0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw p1

    :cond_32
    const-string/jumbo p1, "Wrong type URL in call to LegacyKmsEnvelopeAeadProtoSerialization.parseParameters: "

    invoke-static {p1, p0}, Lrt2;->h(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->s(Ljava/lang/String;)V

    :goto_3c
    return-object v0

    :sswitch_3d
    iget-object p0, p1, Ltd;->c:Ljava/lang/Object;

    check-cast p0, Ljava/lang/String;

    const-string/jumbo v1, "type.googleapis.com/google.crypto.tink.KmsAeadKey"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_8c

    :try_start_4a
    iget-object p0, p1, Ltd;->b:Ljava/lang/Object;

    check-cast p0, Lyl;

    invoke-static {}, Lrc0;->a()Lrc0;

    move-result-object v0

    invoke-static {p0, v0}, Lpz0;->y(Lyl;Lrc0;)Lpz0;

    move-result-object p0
    :try_end_56
    .catch Lmt0; {:try_start_4a .. :try_end_56} :catch_82

    invoke-virtual {p0}, Lpz0;->w()Ljava/lang/String;

    move-result-object p0

    iget-object p1, p1, Ltd;->d:Ljava/lang/Object;

    check-cast p1, Lq5;

    sget-object v0, Lq5;->k0:Lq5;

    if-ne p1, v0, :cond_65

    sget-object p1, Lq5;->U:Lq5;

    goto :goto_6b

    :cond_65
    sget-object v0, Lq5;->m0:Lq5;

    if-ne p1, v0, :cond_71

    sget-object p1, Lq5;->V:Lq5;

    :goto_6b
    new-instance v0, Lo01;

    invoke-direct {v0, p0, p1}, Lo01;-><init>(Ljava/lang/String;Lq5;)V

    goto :goto_96

    :cond_71
    new-instance p0, Ljava/security/GeneralSecurityException;

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const-string/jumbo v0, "Unable to parse OutputPrefixType: "

    invoke-virtual {v0, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p0

    :catch_82
    move-exception p0

    new-instance p1, Ljava/security/GeneralSecurityException;

    const-string/jumbo v0, "Parsing KmsAeadKeyFormat failed: "

    invoke-direct {p1, v0, p0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw p1

    :cond_8c
    const-string/jumbo p1, "Wrong type URL in call to LegacyKmsAeadProtoSerialization.parseParameters: "

    invoke-static {p1, p0}, Lrt2;->h(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->s(Ljava/lang/String;)V

    :goto_96
    return-object v0

    :sswitch_97
    iget-object p0, p1, Ltd;->c:Ljava/lang/Object;

    check-cast p0, Ljava/lang/String;

    const-string/jumbo v1, "type.googleapis.com/google.crypto.tink.HmacKey"

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_10e

    :try_start_a4
    iget-object p0, p1, Ltd;->b:Ljava/lang/Object;

    check-cast p0, Lyl;

    invoke-static {}, Lrc0;->a()Lrc0;

    move-result-object v0

    invoke-static {p0, v0}, Lyn0;->A(Lyl;Lrc0;)Lyn0;

    move-result-object p0
    :try_end_b0
    .catch Lmt0; {:try_start_a4 .. :try_end_b0} :catch_104

    invoke-virtual {p0}, Lyn0;->y()I

    move-result v0

    if-nez v0, :cond_f3

    invoke-static {}, Lbo0;->b()Lx5;

    move-result-object v0

    invoke-virtual {p0}, Lyn0;->w()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    iput-object v1, v0, Lx5;->b:Ljava/lang/Object;

    invoke-virtual {p0}, Lyn0;->x()Ldo0;

    move-result-object v1

    invoke-virtual {v1}, Ldo0;->x()I

    move-result v1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    iput-object v1, v0, Lx5;->c:Ljava/lang/Object;

    sget-object v1, Leo0;->a:Lec;

    invoke-virtual {p0}, Lyn0;->x()Ldo0;

    move-result-object p0

    invoke-virtual {p0}, Ldo0;->w()Ldn0;

    move-result-object p0

    invoke-virtual {v1, p0}, Lec;->B(Ldn0;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lao0;

    iput-object p0, v0, Lx5;->d:Ljava/lang/Object;

    iget-object p0, p1, Ltd;->d:Ljava/lang/Object;

    check-cast p0, Lq5;

    invoke-static {p0}, Leo0;->b(Lq5;)Lq5;

    move-result-object p0

    iput-object p0, v0, Lx5;->e:Ljava/lang/Object;

    invoke-virtual {v0}, Lx5;->e()Lbo0;

    move-result-object v0

    goto :goto_118

    :cond_f3
    new-instance p1, Ljava/security/GeneralSecurityException;

    invoke-virtual {p0}, Lyn0;->y()I

    move-result p0

    const-string/jumbo v0, "Parsing HmacParameters failed: unknown Version "

    invoke-static {p0, v0}, Lrt2;->f(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p1

    :catch_104
    move-exception p0

    new-instance p1, Ljava/security/GeneralSecurityException;

    const-string/jumbo v0, "Parsing HmacParameters failed: "

    invoke-direct {p1, v0, p0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw p1

    :cond_10e
    const-string/jumbo p1, "Wrong type URL in call to HmacProtoSerialization.parseParameters: "

    invoke-static {p1, p0}, Lrt2;->h(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->s(Ljava/lang/String;)V

    :goto_118
    return-object v0

    nop

    :sswitch_data_11a
    .sparse-switch
        0x8 -> :sswitch_97
        0x13 -> :sswitch_3d
    .end sparse-switch
.end method

.method public e(Lfj1;)Ltd;
    .registers 6

    .prologue
    iget p0, p0, Lvh0;->a:I

    sparse-switch p0, :sswitch_data_c0

    check-cast p1, Lq01;

    iget-object p0, p1, Lq01;->a:Lq5;

    sget-object v0, Lq5;->c0:Lq5;

    if-eq v0, p0, :cond_25

    sget-object v0, Lq5;->d0:Lq5;

    if-ne v0, p0, :cond_14

    sget-object p0, Lq5;->m0:Lq5;

    goto :goto_27

    :cond_14
    new-instance p1, Ljava/security/GeneralSecurityException;

    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const-string/jumbo v0, "Unable to serialize variant: "

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_25
    sget-object p0, Lq5;->k0:Lq5;

    :goto_27
    invoke-static {p1}, Lnp3;->e0(Lq01;)Lvz0;

    move-result-object p1

    invoke-virtual {p1}, Ls0;->e()Lvl;

    move-result-object p1

    const-string/jumbo v0, "type.googleapis.com/google.crypto.tink.KmsEnvelopeAeadKey"

    invoke-static {v0, p0, p1}, Ltd;->p(Ljava/lang/String;Lq5;Lyl;)Ltd;

    move-result-object p0

    return-object p0

    :sswitch_37
    check-cast p1, Lo01;

    iget-object p0, p1, Lo01;->b:Lq5;

    invoke-static {p0}, Lmd3;->K(Lq5;)Lq5;

    move-result-object p0

    invoke-static {}, Lpz0;->x()Loz0;

    move-result-object v0

    iget-object p1, p1, Lo01;->a:Ljava/lang/String;

    invoke-virtual {v0}, Lkl0;->e()V

    iget-object v1, v0, Lkl0;->b:Lrl0;

    check-cast v1, Lpz0;

    invoke-virtual {v1, p1}, Lpz0;->z(Ljava/lang/String;)V

    invoke-virtual {v0}, Lkl0;->a()Lrl0;

    move-result-object p1

    check-cast p1, Lpz0;

    invoke-virtual {p1}, Ls0;->e()Lvl;

    move-result-object p1

    const-string/jumbo v0, "type.googleapis.com/google.crypto.tink.KmsAeadKey"

    invoke-static {v0, p0, p1}, Ltd;->p(Ljava/lang/String;Lq5;Lyl;)Ltd;

    move-result-object p0

    return-object p0

    :sswitch_61
    check-cast p1, Lbo0;

    iget-object p0, p1, Lbo0;->c:Lq5;

    invoke-static {p0}, Leo0;->a(Lq5;)Lq5;

    move-result-object p0

    invoke-static {}, Lyn0;->z()Lxn0;

    move-result-object v0

    invoke-static {}, Ldo0;->y()Lco0;

    move-result-object v1

    iget v2, p1, Lbo0;->b:I

    invoke-virtual {v1}, Lkl0;->e()V

    iget-object v3, v1, Lkl0;->b:Lrl0;

    check-cast v3, Ldo0;

    invoke-virtual {v3, v2}, Ldo0;->A(I)V

    sget-object v2, Leo0;->a:Lec;

    iget-object v3, p1, Lbo0;->d:Lao0;

    invoke-virtual {v2, v3}, Lec;->T(Ljava/lang/Object;)Ljava/lang/Enum;

    move-result-object v2

    check-cast v2, Ldn0;

    invoke-virtual {v1}, Lkl0;->e()V

    iget-object v3, v1, Lkl0;->b:Lrl0;

    check-cast v3, Ldo0;

    invoke-virtual {v3, v2}, Ldo0;->z(Ldn0;)V

    invoke-virtual {v1}, Lkl0;->a()Lrl0;

    move-result-object v1

    check-cast v1, Ldo0;

    invoke-virtual {v0}, Lkl0;->e()V

    iget-object v2, v0, Lkl0;->b:Lrl0;

    check-cast v2, Lyn0;

    invoke-virtual {v2, v1}, Lyn0;->C(Ldo0;)V

    iget p1, p1, Lbo0;->a:I

    invoke-virtual {v0}, Lkl0;->e()V

    iget-object v1, v0, Lkl0;->b:Lrl0;

    check-cast v1, Lyn0;

    invoke-virtual {v1, p1}, Lyn0;->B(I)V

    invoke-virtual {v0}, Lkl0;->a()Lrl0;

    move-result-object p1

    check-cast p1, Lyn0;

    invoke-virtual {p1}, Ls0;->e()Lvl;

    move-result-object p1

    const-string/jumbo v0, "type.googleapis.com/google.crypto.tink.HmacKey"

    invoke-static {v0, p0, p1}, Ltd;->p(Ljava/lang/String;Lq5;Lyl;)Ltd;

    move-result-object p0

    return-object p0

    nop

    :sswitch_data_c0
    .sparse-switch
        0x7 -> :sswitch_61
        0x12 -> :sswitch_37
    .end sparse-switch
.end method

.method public f(Landroid/view/View;Lpp2;)Lpp2;
    .registers 13

    const/16 v6, 0x44d

    sget p0, Lcom/tlsvpn/tlstunnel/MainActivity;->m:I

    nop

    const/4 v6, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 p0, 0x207

    const/16 v6, 0xe13

    iget-object p2, p2, Lpp2;->a:Lmp2;

    nop

    const/16 v6, 0x2f6

    invoke-virtual {p2, p0}, Lmp2;->f(I)Lxr0;

    move-result-object p0

    const/4 v6, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xa69

    iget p2, p0, Lxr0;->a:I

    nop

    const/16 v6, 0xc29

    iget v8, p0, Lxr0;->b:I

    nop

    const/16 v6, 0xd8f

    iget v9, p0, Lxr0;->c:I

    nop

    const/16 v6, 0xf45

    iget p0, p0, Lxr0;->d:I

    nop

    const/16 v6, 0xd1d

    move v0, v6

    move-object v1, p1

    move v2, p2

    move v3, v8

    move v4, v9

    move v5, p0

    invoke-virtual/range {v1 .. v5}, Landroid/view/View;->setPadding(IIII)V

    const/16 v6, 0xe7f

    sget-object p0, Lpp2;->b:Lpp2;

    nop

    check-cast p0, Lpp2;

    return-object p0
.end method
