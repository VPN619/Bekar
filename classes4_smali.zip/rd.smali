.class public final Lrd;
.super Lkk;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final q:Lw82;

.field public r:Landroidx/appcompat/widget/SwitchCompat;

.field public s:Landroidx/appcompat/widget/SwitchCompat;

.field public t:Landroidx/recyclerview/widget/RecyclerView;

.field public u:Lcom/google/android/material/progressindicator/LinearProgressIndicator;


# direct methods
.method public constructor <init>()V
    .registers 5

    invoke-direct {p0}, Lkk;-><init>()V

    const/16 v0, 0xa84

    new-instance v2, Ld;

    nop

    const/4 v3, 0x2

    const/16 v0, 0x6cb

    invoke-direct {v2, v3, p0}, Ld;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x27a

    new-instance v3, Lw82;

    nop

    const/16 v0, 0x215

    invoke-direct {v3, v2}, Lw82;-><init>(Lzj0;)V

    const/16 v0, 0x97c

    iput-object v3, p0, Lrd;->q:Lw82;

    return-void
.end method


# virtual methods
.method public final c(Lwx;)Ljava/lang/Object;
    .registers 10

    .prologue
    instance-of v2, p1, Lpd;

    if-eqz v2, :cond_18

    move-object v2, p1

    check-cast v2, Lpd;

    const/16 v0, 0x2a8

    iget v3, v2, Lpd;->v:I

    nop

    const/high16 v4, -0x80000000

    and-int v5, v3, v4

    if-eqz v5, :cond_18

    sub-int/2addr v3, v4

    const/16 v0, 0x364

    iput v3, v2, Lpd;->v:I

    goto :goto_22

    :cond_18
    const/16 v0, 0x738

    new-instance v2, Lpd;

    nop

    const/16 v0, 0x6e3

    invoke-direct {v2, p0, p1}, Lpd;-><init>(Lrd;Lwx;)V

    :goto_22
    const/16 v0, 0xe6f

    iget-object p1, v2, Lpd;->t:Ljava/lang/Object;

    nop

    const/16 v0, 0x2a8

    iget v3, v2, Lpd;->v:I

    nop

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v3, :cond_40

    if-ne v3, v4, :cond_37

    const/4 v0, 0x6

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_67

    :cond_37
    const-string/jumbo p0, "call to \'resume\' before \'invoke\' with coroutine"

    const/16 v0, 0x13

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v5

    :cond_40
    const/4 v0, 0x6

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v0, 0x132

    sget-object p1, Lh50;->a:Li20;

    nop

    const/16 v0, 0x23

    new-instance v3, Lc4;

    nop

    const/16 v0, 0x22

    invoke-direct {v3, p0, v5, v4}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    const/16 v0, 0x364

    iput v4, v2, Lpd;->v:I

    const/16 v0, 0x121

    invoke-static {p1, v3, v2}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object p1

    const/16 v0, 0x15

    sget-object v2, Lwy;->a:Lwy;

    nop

    if-ne p1, v2, :cond_67

    check-cast v2, Ljava/lang/Object;

    return-object v2

    :cond_67
    :goto_67
    check-cast p1, Lae;

    const/16 v0, 0xd9

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->isAdded()Z

    move-result v2

    const/16 v0, 0x21

    sget-object v3, Lrg2;->a:Lrg2;

    nop

    if-nez v2, :cond_79

    check-cast v3, Ljava/lang/Object;

    return-object v3

    :cond_79
    const/16 v0, 0x42a

    iget-object v2, p0, Lrd;->t:Landroidx/recyclerview/widget/RecyclerView;

    nop

    if-eqz v2, :cond_e3

    const/16 v0, 0xff8

    new-instance v4, Lxd;

    nop

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v6

    const/16 v0, 0xea

    invoke-virtual {v6}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v6

    const/4 v0, -0x6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x2b9

    iget-object v7, p1, Lae;->a:Ljava/util/ArrayList;

    nop

    const/16 v0, 0x44a

    iget-object p1, p1, Lae;->b:Ljava/util/ArrayList;

    nop

    const/16 v0, 0x653

    invoke-static {p1, v7}, Lbs;->t0(Ljava/lang/Iterable;Ljava/util/Collection;)Ljava/util/ArrayList;

    move-result-object p1

    const/16 v0, 0x208

    invoke-virtual {p0}, Lrd;->d()Landroid/content/SharedPreferences;

    move-result-object v7

    const/4 v0, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x9d6

    invoke-direct {v4, v6, p1, v7}, Lxd;-><init>(Landroid/content/pm/PackageManager;Ljava/util/ArrayList;Landroid/content/SharedPreferences;)V

    const/16 v0, 0xc87

    invoke-virtual {v2, v4}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Lqq1;)V

    const/16 v0, 0x2a9

    iget-object p1, p0, Lrd;->u:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    nop

    const-string/jumbo v2, "progressBar"

    if-eqz p1, :cond_de

    const/4 v4, 0x0

    const/16 v0, 0xd3

    invoke-virtual {p1, v4}, Lki;->setIndeterminate(Z)V

    const/16 v0, 0x2a9

    iget-object p0, p0, Lrd;->u:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    nop

    if-eqz p0, :cond_d9

    const/16 p1, 0x8

    const/4 v0, -0x5

    invoke-virtual {p0, p1}, Landroid/view/View;->setVisibility(I)V

    check-cast v3, Ljava/lang/Object;

    return-object v3

    :cond_d9
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw v5

    :cond_de
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw v5

    :cond_e3
    const-string/jumbo p0, "appfilter_applist"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v5
.end method

.method public final d()Landroid/content/SharedPreferences;
    .registers 3

    const/16 v0, 0xdec

    iget-object p0, p0, Lrd;->q:Lw82;

    nop

    const/16 v0, 0x177

    invoke-virtual {p0}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/content/SharedPreferences;

    return-object p0
.end method

.method public final getTheme()I
    .registers 3

    const p0, 0x7f140424

    return p0
.end method

.method public final onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .registers 18

    .prologue
    const/4 v6, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const p3, 0x7f0c001d

    const/4 v8, 0x0

    const/16 v6, 0x107b

    move/from16 v0, p3

    move-object/from16 v1, p2

    invoke-virtual {p1, v0, v1, v8}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    const p2, 0x7f09005c

    const/16 v6, 0x11

    move/from16 v0, p2

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v6, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroidx/appcompat/widget/SwitchCompat;

    const/16 v6, 0x7d1

    move-object/from16 v0, p2

    iput-object v0, p0, Lrd;->r:Landroidx/appcompat/widget/SwitchCompat;

    const p2, 0x7f09005d

    const/16 v6, 0x11

    move/from16 v0, p2

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v6, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroidx/appcompat/widget/SwitchCompat;

    const/16 v6, 0xa01

    move-object/from16 v0, p2

    iput-object v0, p0, Lrd;->s:Landroidx/appcompat/widget/SwitchCompat;

    const p2, 0x7f09005b

    const/16 v6, 0x11

    move/from16 v0, p2

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v6, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroidx/recyclerview/widget/RecyclerView;

    const/16 v6, 0x117d

    move-object/from16 v0, p2

    iput-object v0, p0, Lrd;->t:Landroidx/recyclerview/widget/RecyclerView;

    const p2, 0x7f0902cf

    const/16 v6, 0x11

    move/from16 v0, p2

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v6, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    const/16 v6, 0x73b

    move-object/from16 v0, p2

    iput-object v0, p0, Lrd;->u:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    const/16 v6, 0x372

    iget-object v6, p0, Lrd;->r:Landroidx/appcompat/widget/SwitchCompat;

    move-object/16 p2, v6

    const-string/jumbo p3, "appfilter_enabled"

    const/4 v9, 0x0

    if-eqz p2, :cond_1e0

    const/16 v6, 0x3ee

    new-instance v10, Lod;

    nop

    const/16 v6, 0x321

    invoke-direct {v10, v8, p0}, Lod;-><init>(ILjava/lang/Object;)V

    const/16 v6, 0x14a

    move-object/from16 v0, p2

    invoke-virtual {v0, v10}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    const/16 v6, 0x1d7

    iget-object v6, p0, Lrd;->s:Landroidx/appcompat/widget/SwitchCompat;

    move-object/16 p2, v6

    const-string/jumbo v10, "appfilter_mode"

    if-eqz p2, :cond_1db

    const/16 v6, 0x3ee

    new-instance v11, Lod;

    nop

    const/4 v12, 0x1

    const/16 v6, 0x321

    invoke-direct {v11, v12, p0}, Lod;-><init>(ILjava/lang/Object;)V

    const/16 v6, 0x14a

    move-object/from16 v0, p2

    invoke-virtual {v0, v11}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    const/16 v6, 0xf80

    new-instance p2, Lp50;

    nop

    const/16 v6, 0xfb

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object v11

    const/16 v6, 0x1133

    move-object/from16 v0, p2

    invoke-direct {v0, v11}, Lp50;-><init>(Landroid/content/Context;)V

    const/16 v6, 0xfb

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object v11

    const v13, 0x7f0800a6

    const/16 v6, 0x52f

    invoke-static {v11, v13}, Lqx;->getDrawable(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v11

    const/4 v6, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x8fa

    move-object/from16 v0, p2

    iput-object v11, v0, Lp50;->b:Ljava/lang/Object;

    const/16 v6, 0x42a

    iget-object v11, p0, Lrd;->t:Landroidx/recyclerview/widget/RecyclerView;

    nop

    const-string/jumbo v13, "appfilter_applist"

    if-eqz v11, :cond_1d6

    const/16 v6, 0x892

    move-object/from16 v0, p2

    invoke-virtual {v11, v0}, Landroidx/recyclerview/widget/RecyclerView;->i(Lwq1;)V

    const/16 v6, 0x42a

    iget-object v6, p0, Lrd;->t:Landroidx/recyclerview/widget/RecyclerView;

    move-object/16 p2, v6

    if-eqz p2, :cond_1d1

    const/16 v6, 0x7ba

    move-object/from16 v0, p2

    invoke-virtual {v0, v9}, Landroidx/recyclerview/widget/RecyclerView;->setItemAnimator(Lvq1;)V

    const/16 v6, 0x372

    iget-object v6, p0, Lrd;->r:Landroidx/appcompat/widget/SwitchCompat;

    move-object/16 p2, v6

    if-eqz p2, :cond_1ca

    const/16 v6, 0x208

    invoke-virtual {p0}, Lrd;->d()Landroid/content/SharedPreferences;

    move-result-object p3

    const-string/jumbo v11, "appfilter"

    const/16 v6, 0x77

    move-object/from16 v0, p3

    invoke-interface {v0, v11, v8}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p3

    const/16 v6, 0x4a8

    move-object/from16 v0, p2

    move/from16 v1, p3

    invoke-virtual {v0, v1}, Landroidx/appcompat/widget/SwitchCompat;->setChecked(Z)V

    const/16 v6, 0x1d7

    iget-object v6, p0, Lrd;->s:Landroidx/appcompat/widget/SwitchCompat;

    move-object/16 p2, v6

    if-eqz p2, :cond_1c5

    const/16 v6, 0x208

    invoke-virtual {p0}, Lrd;->d()Landroid/content/SharedPreferences;

    move-result-object p3

    const/16 v6, 0x77

    move-object/from16 v0, p3

    invoke-interface {v0, v10, v12}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p3

    const/16 v6, 0x4a8

    move-object/from16 v0, p2

    move/from16 v1, p3

    invoke-virtual {v0, v1}, Landroidx/appcompat/widget/SwitchCompat;->setChecked(Z)V

    const/16 v6, 0x1d7

    iget-object v6, p0, Lrd;->s:Landroidx/appcompat/widget/SwitchCompat;

    move-object/16 p2, v6

    if-eqz p2, :cond_1c0

    const/16 v6, 0x36

    move-object/from16 v0, p2

    invoke-virtual {v0}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result p3

    if-eqz p3, :cond_160

    const p3, 0x7f13002b

    :goto_157
    const/16 v6, 0x4c

    move/from16 v0, p3

    invoke-virtual {p0, v0}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object p3

    goto :goto_164

    :cond_160
    const p3, 0x7f13002c

    goto :goto_157

    :goto_164
    const/16 v6, 0x8a

    move-object/from16 v0, p2

    move-object/from16 v1, p3

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v6, 0x325

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getViewLifecycleOwner()Lh11;

    move-result-object p2

    const/4 v6, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x341

    move-object/from16 v0, p2

    invoke-static {v0}, Lns2;->m(Lh11;)Lc11;

    move-result-object p2

    const/16 v6, 0x16

    new-instance p3, Lqd;

    nop

    const/16 v6, 0x17

    move-object/from16 v0, p3

    invoke-direct {v0, p0, v9, v8}, Lqd;-><init>(Ljava/lang/Object;Lvx;I)V

    const/4 v8, 0x3

    const/16 v6, 0xb3

    move v0, v6

    move-object/from16 v1, p2

    move-object v2, v9

    move-object v3, v9

    move-object/from16 v4, p3

    move v5, v8

    invoke-static/range {v1 .. v5}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    const/16 v6, 0x140

    sget-boolean p2, Lg4;->a:Z

    nop

    const/16 v6, 0xfb

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object p2

    const/4 v6, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x208

    invoke-virtual {p0}, Lrd;->d()Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v6, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x394

    move-object/from16 v0, p2

    invoke-static {p0, v0}, Lg4;->n(Landroid/content/SharedPreferences;Landroidx/fragment/app/l;)V

    check-cast p1, Landroid/view/View;

    return-object p1

    :cond_1c0
    const/4 v6, 0x5

    invoke-static {v10}, Lgt0;->F0(Ljava/lang/String;)V

    throw v9

    :cond_1c5
    const/4 v6, 0x5

    invoke-static {v10}, Lgt0;->F0(Ljava/lang/String;)V

    throw v9

    :cond_1ca
    const/4 v6, 0x5

    move-object/from16 v0, p3

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v9

    :cond_1d1
    const/4 v6, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    throw v9

    :cond_1d6
    const/4 v6, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    throw v9

    :cond_1db
    const/4 v6, 0x5

    invoke-static {v10}, Lgt0;->F0(Ljava/lang/String;)V

    throw v9

    :cond_1e0
    const/4 v6, 0x5

    move-object/from16 v0, p3

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v9
.end method

.method public final onStart()V
    .registers 6

    .prologue
    const/16 v0, 0x55f

    invoke-super {p0}, Landroidx/fragment/app/g;->onStart()V

    const/16 v0, 0xaeb

    invoke-virtual {p0}, Landroidx/fragment/app/g;->getDialog()Landroid/app/Dialog;

    move-result-object v2

    instance-of v3, v2, Ljk;

    const/4 v4, 0x0

    if-eqz v3, :cond_13

    check-cast v2, Ljk;

    goto :goto_14

    :cond_13
    move-object v2, v4

    :goto_14
    if-eqz v2, :cond_1c

    const/16 v0, 0xff7

    invoke-virtual {v2}, Ljk;->f()Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    move-result-object v4

    :cond_1c
    const/16 v0, 0x1c6

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/16 v0, 0x84a

    invoke-virtual {p0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object p0

    const/16 v0, 0x8b5

    iget p0, p0, Landroid/content/res/Configuration;->orientation:I

    nop

    const/4 v2, 0x2

    if-ne p0, v2, :cond_3d

    if-eqz v4, :cond_3d

    const/4 p0, 0x3

    const/16 v0, 0x8a6

    invoke-virtual {v4, p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->L(I)V

    const/4 p0, 0x1

    const/16 v0, 0x1099

    iput-boolean p0, v4, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->K:Z

    :cond_3d
    return-void
.end method
