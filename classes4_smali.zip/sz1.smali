.class public final synthetic Lsz1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lzj0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 5

    iput p1, p0, Lsz1;->a:I

    iput-object p2, p0, Lsz1;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 10

    .prologue
    const/16 v0, 0x683

    iget v2, p0, Lsz1;->a:I

    nop

    const/4 v3, 0x0

    const/16 v0, 0xc56

    iget-object p0, p0, Lsz1;->b:Ljava/lang/Object;

    nop

    packed-switch v2, :pswitch_data_134

    check-cast p0, Landroidx/work/Worker;

    const/16 v0, 0x124e

    invoke-virtual {p0}, Landroidx/work/Worker;->c()Li31;

    move-result-object p0

    check-cast p0, Ljava/lang/Object;

    return-object p0

    :pswitch_19  #0x8
    check-cast p0, Ldq2;

    const/16 v0, 0xd86

    sget-object v2, Lva0;->a:Ljava/lang/String;

    nop

    const/16 v0, 0x6b4

    iget-object v2, p0, Ldq2;->a:Lnq2;

    nop

    const/16 v0, 0xe24

    iget-object v4, v2, Lnq2;->c:Landroidx/work/impl/WorkDatabase;

    nop

    const/16 v0, 0x167

    new-instance v5, Ljava/util/HashSet;

    nop

    const/16 v0, 0x13f

    invoke-direct {v5}, Ljava/util/HashSet;-><init>()V

    const/16 v0, 0x400

    iget-object v6, p0, Ldq2;->c:Ljava/util/ArrayList;

    nop

    const/16 v0, 0x649

    invoke-interface {v5, v6}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    const/16 v0, 0x9b9

    invoke-static {p0}, Ldq2;->a(Ldq2;)Ljava/util/HashSet;

    move-result-object v6

    const/16 v0, 0xe63

    invoke-virtual {v5}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :cond_4a
    const/16 v0, 0x13e

    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_64

    const/16 v0, 0x16e

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    const/16 v0, 0x1241

    invoke-virtual {v6, v8}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_4a

    const/4 v3, 0x1

    goto :goto_6e

    :cond_64
    const/16 v0, 0x400

    iget-object v6, p0, Ldq2;->c:Ljava/util/ArrayList;

    nop

    const/16 v0, 0x94f

    invoke-interface {v5, v6}, Ljava/util/Set;->removeAll(Ljava/util/Collection;)Z

    :goto_6e
    if-nez v3, :cond_a8

    const/16 v0, 0x921

    iget-object v3, v2, Lnq2;->b:Lsg;

    nop

    const/16 v0, 0x8a7

    invoke-virtual {v4}, Lgv1;->b()V

    :try_start_7a
    const/16 v0, 0x6fa

    invoke-static {v4, v3, p0}, Lw53;->x(Landroidx/work/impl/WorkDatabase;Lsg;Ldq2;)V

    const/16 v0, 0xc5a

    invoke-static {p0}, Lva0;->a(Ldq2;)Z

    move-result p0

    const/16 v0, 0xf61

    invoke-virtual {v4}, Lgv1;->o()V
    :try_end_8a
    .catchall {:try_start_7a .. :try_end_8a} :catchall_a1

    const/16 v0, 0x3c0

    invoke-virtual {v4}, Lgv1;->l()V

    if-eqz p0, :cond_9b

    const/16 v0, 0xe34

    iget-object p0, v2, Lnq2;->e:Ljava/util/List;

    nop

    const/16 v0, 0xcb0

    invoke-static {v3, v4, p0}, Loy1;->b(Lsg;Landroidx/work/impl/WorkDatabase;Ljava/util/List;)V

    :cond_9b
    const/16 v0, 0x21

    sget-object p0, Lrg2;->a:Lrg2;

    nop

    goto :goto_b4

    :catchall_a1
    move-exception p0

    const/16 v0, 0x3c0

    invoke-virtual {v4}, Lgv1;->l()V

    throw p0

    :cond_a8
    const-string/jumbo v2, "WorkContinuation has cycles ("

    const-string/jumbo v3, ")"

    const/16 v0, 0xda0

    invoke-static {p0, v3, v2}, Lho;->c(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;)V

    const/4 p0, 0x0

    :goto_b4
    check-cast p0, Ljava/lang/Object;

    return-object p0

    :pswitch_b7  #0x7
    check-cast p0, Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings;

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p0

    const/16 v0, 0x2a

    invoke-static {p0}, Lxl1;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    check-cast p0, Ljava/lang/Object;

    return-object p0

    :pswitch_c8  #0x6
    check-cast p0, Lg12;

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p0

    const/16 v0, 0x2a

    invoke-static {p0}, Lxl1;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    check-cast p0, Ljava/lang/Object;

    return-object p0

    :pswitch_d9  #0x5
    check-cast p0, Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;

    const/16 v0, 0xb57

    sget v2, Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;->j:I

    nop

    const/16 v0, 0x2a

    invoke-static {p0}, Lxl1;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    check-cast p0, Ljava/lang/Object;

    return-object p0

    :pswitch_e9  #0x4
    check-cast p0, Ljava/util/ArrayList;

    const/16 v0, 0x43

    invoke-virtual {p0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lky0;

    const/16 v0, 0x9f1

    invoke-interface {p0}, Lky0;->c()Llq;

    move-result-object p0

    check-cast p0, Ljava/lang/Object;

    return-object p0

    :pswitch_fc  #0x3
    check-cast p0, Lo02;

    const/16 v0, 0xea1

    iget-object v2, p0, Lo02;->k:[Lm02;

    nop

    const/16 v0, 0xed2

    invoke-static {p0, v2}, Lqk;->r(Lm02;[Lm02;)I

    move-result p0

    const/16 v0, 0xb1

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    :pswitch_10f  #0x2
    check-cast p0, Ljava/lang/Object;

    return-object p0

    :pswitch_112  #0x1
    check-cast p0, Lyz1;

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p0

    const/16 v0, 0x2a

    invoke-static {p0}, Lxl1;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    check-cast p0, Ljava/lang/Object;

    return-object p0

    :pswitch_123  #0x0
    check-cast p0, Lvz1;

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p0

    const/16 v0, 0x2a

    invoke-static {p0}, Lxl1;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    check-cast p0, Ljava/lang/Object;

    return-object p0

    :pswitch_data_134
    .packed-switch 0x0
        :pswitch_123  #00000000
        :pswitch_112  #00000001
        :pswitch_10f  #00000002
        :pswitch_fc  #00000003
        :pswitch_e9  #00000004
        :pswitch_d9  #00000005
        :pswitch_c8  #00000006
        :pswitch_b7  #00000007
        :pswitch_19  #00000008
    .end packed-switch
.end method
