.class public abstract Ldz;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final a:Lcz;

.field public static final b:Ljava/util/Map;


# direct methods
.method static constructor <clinit>()V
    .registers 85

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v4, 0x7f130264

    const-string/jumbo v5, "\ud83c\udf0e"

    const v6, 0x7f0800be

    const/4 v1, 0x1

    invoke-direct {v3, v6, v4, v5}, Lcz;-><init>(IILjava/lang/String;)V

    check-cast v3, Lcz;

    sput-object v3, Ldz;->a:Lcz;

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v4, 0x7f13001e

    const-string/jumbo v5, "\ud83c\udde6\ud83c\uddea"

    const v6, 0x7f0800a7

    const/4 v1, 0x1

    invoke-direct {v3, v6, v4, v5}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v7, Ldj1;

    nop

    const-string/jumbo v4, "ae"

    const/4 v1, 0x4

    invoke-direct {v7, v4, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v4, 0x7f130020

    const-string/jumbo v5, "\ud83c\udde6\ud83c\uddf1"

    const v6, 0x7f0800a8

    const/4 v1, 0x1

    invoke-direct {v3, v6, v4, v5}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v8, Ldj1;

    nop

    const-string/jumbo v4, "al"

    const/4 v1, 0x4

    invoke-direct {v8, v4, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v4, 0x7f13002d

    const-string/jumbo v5, "\ud83c\udde6\ud83c\uddf7"

    const v6, 0x7f0800a9

    const/4 v1, 0x1

    invoke-direct {v3, v6, v4, v5}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v9, Ldj1;

    nop

    const-string/jumbo v4, "ar"

    const/4 v1, 0x4

    invoke-direct {v9, v4, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v4, 0x7f130030

    const-string/jumbo v5, "\ud83c\udde6\ud83c\uddf9"

    const v6, 0x7f0800aa

    const/4 v1, 0x1

    invoke-direct {v3, v6, v4, v5}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v10, Ldj1;

    nop

    const-string/jumbo v4, "at"

    const/4 v1, 0x4

    invoke-direct {v10, v4, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v4, 0x7f130034

    const-string/jumbo v5, "\ud83c\udde6\ud83c\uddfa"

    const v6, 0x7f0800ab

    const/4 v1, 0x1

    invoke-direct {v3, v6, v4, v5}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v11, Ldj1;

    nop

    const-string/jumbo v4, "au"

    const/4 v1, 0x4

    invoke-direct {v11, v4, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v4, 0x7f13003d

    const-string/jumbo v5, "\ud83c\udde6\ud83c\uddff"

    const v6, 0x7f0800ac

    const/4 v1, 0x1

    invoke-direct {v3, v6, v4, v5}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v12, Ldj1;

    nop

    const-string/jumbo v4, "az"

    const/4 v1, 0x4

    invoke-direct {v12, v4, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v4, 0x7f13003e

    const-string/jumbo v5, "\ud83c\udde7\ud83c\udde6"

    const v6, 0x7f0800ad

    const/4 v1, 0x1

    invoke-direct {v3, v6, v4, v5}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v13, Ldj1;

    nop

    const-string/jumbo v4, "ba"

    const/4 v1, 0x4

    invoke-direct {v13, v4, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v4, 0x7f130041

    const-string/jumbo v5, "\ud83c\udde7\ud83c\udde9"

    const v6, 0x7f0800ae

    const/4 v1, 0x1

    invoke-direct {v3, v6, v4, v5}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v14, Ldj1;

    nop

    const-string/jumbo v4, "bd"

    const/4 v1, 0x4

    invoke-direct {v14, v4, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v4, 0x7f130042

    const-string/jumbo v5, "\ud83c\udde7\ud83c\uddea"

    const v6, 0x7f0800af

    const/4 v1, 0x1

    invoke-direct {v3, v6, v4, v5}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v15, Ldj1;

    nop

    const-string/jumbo v4, "be"

    const/4 v1, 0x4

    invoke-direct {v15, v4, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v4, 0x7f130043

    const-string/jumbo v5, "\ud83c\udde7\ud83c\uddec"

    const v6, 0x7f0800b0

    const/4 v1, 0x1

    invoke-direct {v3, v6, v4, v5}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v16, Ldj1;

    nop

    const-string/jumbo v4, "bg"

    const/4 v1, 0x4

    move-object/from16 v0, v16

    invoke-direct {v0, v4, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v4, 0x7f130048

    const-string/jumbo v5, "\ud83c\udde7\ud83c\uddf4"

    const v6, 0x7f0800b1

    const/4 v1, 0x1

    invoke-direct {v3, v6, v4, v5}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v17, Ldj1;

    nop

    const-string/jumbo v4, "bo"

    const/4 v1, 0x4

    move-object/from16 v0, v17

    invoke-direct {v0, v4, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v4, 0x7f130054

    const-string/jumbo v5, "\ud83c\udde7\ud83c\uddf7"

    const v6, 0x7f0800b2

    const/4 v1, 0x1

    invoke-direct {v3, v6, v4, v5}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v18, Ldj1;

    nop

    const-string/jumbo v4, "br"

    const/4 v1, 0x4

    move-object/from16 v0, v18

    invoke-direct {v0, v4, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v4, 0x7f130057

    const-string/jumbo v5, "\ud83c\udde8\ud83c\udde6"

    const v6, 0x7f0800b3

    const/4 v1, 0x1

    invoke-direct {v3, v6, v4, v5}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "ca"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f13006b

    const-string/jumbo v6, "\ud83c\udde8\ud83c\udded"

    move-object/from16 v19, v4

    const v4, 0x7f0800b4

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "ch"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f13006f

    const-string/jumbo v6, "\ud83c\udde8\ud83c\uddf1"

    move-object/from16 v20, v4

    const v4, 0x7f0800b5

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "cl"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f130073

    const-string/jumbo v6, "\ud83c\udde8\ud83c\uddf3"

    move-object/from16 v21, v4

    const v4, 0x7f0800b6

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "cn"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f130076

    const-string/jumbo v6, "\ud83c\udde8\ud83c\uddf4"

    move-object/from16 v22, v4

    const v4, 0x7f0800b7

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "co"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f1300a0

    const-string/jumbo v6, "\ud83c\udde8\ud83c\uddf7"

    move-object/from16 v23, v4

    const v4, 0x7f0800b8

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "cr"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f1300a1

    const-string/jumbo v6, "\ud83c\udde8\ud83c\uddfe"

    move-object/from16 v24, v4

    const v4, 0x7f0800b9

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "cy"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f1300a2

    const-string/jumbo v6, "\ud83c\udde8\ud83c\uddff"

    move-object/from16 v25, v4

    const v4, 0x7f0800ba

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "cz"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f1300a3

    const-string/jumbo v6, "\ud83c\udde9\ud83c\uddea"

    move-object/from16 v26, v4

    const v4, 0x7f0800bb

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "de"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f1300a9

    const-string/jumbo v6, "\ud83c\udde9\ud83c\uddf0"

    move-object/from16 v27, v4

    const v4, 0x7f0800bc

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "dk"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f1300c4

    const-string/jumbo v6, "\ud83c\udde9\ud83c\uddff"

    move-object/from16 v28, v4

    const v4, 0x7f0800bd

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "dz"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f1300c5

    const-string/jumbo v6, "\ud83c\uddea\ud83c\udde8"

    move-object/from16 v29, v4

    const v4, 0x7f0800bf

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "ec"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f1300c6

    const-string/jumbo v6, "\ud83c\uddea\ud83c\uddea"

    move-object/from16 v30, v4

    const v4, 0x7f0800c0

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "ee"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f1300c7

    const-string/jumbo v6, "\ud83c\uddea\ud83c\uddec"

    move-object/from16 v31, v4

    const v4, 0x7f0800c1

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "eg"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f1300d1

    const-string/jumbo v6, "\ud83c\uddea\ud83c\uddf8"

    move-object/from16 v32, v4

    const v4, 0x7f0800c2

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "es"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f1300e3

    const-string/jumbo v6, "\ud83c\uddeb\ud83c\uddee"

    move-object/from16 v33, v4

    const v4, 0x7f0800c3

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "fi"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f1300e5

    const-string/jumbo v6, "\ud83c\uddeb\ud83c\uddf7"

    move-object/from16 v34, v4

    const v4, 0x7f0800c4

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "fr"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f1300e7

    const-string/jumbo v6, "\ud83c\uddec\ud83c\uddea"

    move-object/from16 v35, v4

    const v4, 0x7f0800c5

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "ge"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f1300ee

    const-string/jumbo v6, "\ud83c\uddec\ud83c\uddf7"

    move-object/from16 v36, v4

    const v4, 0x7f0800c6

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "gr"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f1300ef

    const-string/jumbo v6, "\ud83c\uddec\ud83c\uddf9"

    move-object/from16 v37, v4

    const v4, 0x7f0800c7

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "gt"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f1300f3

    const-string/jumbo v6, "\ud83c\udded\ud83c\uddf0"

    move-object/from16 v38, v4

    const v4, 0x7f0800c8

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "hk"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f1300f7

    const-string/jumbo v6, "\ud83c\udded\ud83c\uddfa"

    move-object/from16 v39, v4

    const v4, 0x7f0800c9

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "hu"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f1300fa

    const-string/jumbo v6, "\ud83c\uddee\ud83c\udde9"

    move-object/from16 v40, v4

    const v4, 0x7f0800ca

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "id"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f1300fb

    const-string/jumbo v6, "\ud83c\uddee\ud83c\uddea"

    move-object/from16 v41, v4

    const v4, 0x7f0800cb

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "ie"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f1300fc

    const-string/jumbo v6, "\ud83c\uddee\ud83c\uddf1"

    move-object/from16 v42, v4

    const v4, 0x7f0800cc

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "il"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f130101

    const-string/jumbo v6, "\ud83c\uddee\ud83c\uddf3"

    move-object/from16 v43, v4

    const v4, 0x7f0800cd

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "in"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f130109

    const-string/jumbo v6, "\ud83c\uddee\ud83c\uddf7"

    move-object/from16 v44, v4

    const v4, 0x7f0800ce

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "ir"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f13010a

    const-string/jumbo v6, "\ud83c\uddee\ud83c\uddf9"

    move-object/from16 v45, v4

    const v4, 0x7f0800cf

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "it"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f13010d

    const-string/jumbo v6, "\ud83c\uddef\ud83c\uddf5"

    move-object/from16 v46, v4

    const v4, 0x7f0800d0

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "jp"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f13010e

    const-string/jumbo v6, "\ud83c\uddf0\ud83c\uddf7"

    move-object/from16 v47, v4

    const v4, 0x7f0800d1

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "kr"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f13010f

    const-string/jumbo v6, "\ud83c\uddf0\ud83c\uddff"

    move-object/from16 v48, v4

    const v4, 0x7f0800d2

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "kz"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f130113

    const-string/jumbo v6, "\ud83c\uddf1\ud83c\uddf0"

    move-object/from16 v49, v4

    const v4, 0x7f0800d3

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "lk"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f130116

    const-string/jumbo v6, "\ud83c\uddf1\ud83c\uddf9"

    move-object/from16 v50, v4

    const v4, 0x7f0800d4

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "lt"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f130117

    const-string/jumbo v6, "\ud83c\uddf1\ud83c\uddfa"

    move-object/from16 v51, v4

    const v4, 0x7f0800d5

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "lu"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f130118

    const-string/jumbo v6, "\ud83c\uddf1\ud83c\uddfb"

    move-object/from16 v52, v4

    const v4, 0x7f0800d6

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "lv"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f130132

    const-string/jumbo v6, "\ud83c\uddf2\ud83c\udde6"

    move-object/from16 v53, v4

    const v4, 0x7f0800d7

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "ma"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f13017d

    const-string/jumbo v6, "\ud83c\uddf2\ud83c\udde9"

    move-object/from16 v54, v4

    const v4, 0x7f0800d8

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "md"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f130180

    const-string/jumbo v6, "\ud83c\uddf2\ud83c\uddf2"

    move-object/from16 v55, v4

    const v4, 0x7f0800d9

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "mm"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f1301d1

    const-string/jumbo v6, "\ud83c\uddf2\ud83c\uddfb"

    move-object/from16 v56, v4

    const v4, 0x7f0800da

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "mv"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f1301d2

    const-string/jumbo v6, "\ud83c\uddf2\ud83c\uddfd"

    move-object/from16 v57, v4

    const v4, 0x7f0800db

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "mx"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f1301d3

    const-string/jumbo v6, "\ud83c\uddf2\ud83c\uddfe"

    move-object/from16 v58, v4

    const v4, 0x7f0800dc

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "my"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f1301dc

    const-string/jumbo v6, "\ud83c\uddf3\ud83c\uddec"

    move-object/from16 v59, v4

    const v4, 0x7f0800dd

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "ng"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f1301dd

    const-string/jumbo v6, "\ud83c\uddf3\ud83c\uddf1"

    move-object/from16 v60, v4

    const v4, 0x7f0800de

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "nl"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f1301de

    const-string/jumbo v6, "\ud83c\uddf3\ud83c\uddf4"

    move-object/from16 v61, v4

    const v4, 0x7f0800df

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "no"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f1301e5

    const-string/jumbo v6, "\ud83c\uddf5\ud83c\udde6"

    move-object/from16 v62, v4

    const v4, 0x7f0800e0

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "pa"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f1301f1

    const-string/jumbo v6, "\ud83c\uddf5\ud83c\uddea"

    move-object/from16 v63, v4

    const v4, 0x7f0800e1

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "pe"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f1301f7

    const-string/jumbo v6, "\ud83c\uddf5\ud83c\uddf0"

    move-object/from16 v64, v4

    const v4, 0x7f0800e2

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "pk"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f1301f9

    const-string/jumbo v6, "\ud83c\uddf5\ud83c\uddf1"

    move-object/from16 v65, v4

    const v4, 0x7f0800e3

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "pl"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f1301fd

    const-string/jumbo v6, "\ud83c\uddf5\ud83c\uddf7"

    move-object/from16 v66, v4

    const v4, 0x7f0800e4

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "pr"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f130216

    const-string/jumbo v6, "\ud83c\uddf5\ud83c\uddf9"

    move-object/from16 v67, v4

    const v4, 0x7f0800e5

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "pt"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f130217

    const-string/jumbo v6, "\ud83c\uddf5\ud83c\uddfe"

    move-object/from16 v68, v4

    const v4, 0x7f0800e6

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "py"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f13022d

    const-string/jumbo v6, "\ud83c\uddf7\ud83c\uddf4"

    move-object/from16 v69, v4

    const v4, 0x7f0800e7

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "ro"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f13022e

    const-string/jumbo v6, "\ud83c\uddf7\ud83c\uddf8"

    move-object/from16 v70, v4

    const v4, 0x7f0800e8

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "rs"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f13022f

    const-string/jumbo v6, "\ud83c\uddf7\ud83c\uddfa"

    move-object/from16 v71, v4

    const v4, 0x7f0800e9

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "ru"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f130230

    const-string/jumbo v6, "\ud83c\uddf8\ud83c\udde6"

    move-object/from16 v72, v4

    const v4, 0x7f0800ea

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "sa"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f130232

    const-string/jumbo v6, "\ud83c\uddf8\ud83c\uddea"

    move-object/from16 v73, v4

    const v4, 0x7f0800eb

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "se"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f130242

    const-string/jumbo v6, "\ud83c\uddf8\ud83c\uddec"

    move-object/from16 v74, v4

    const v4, 0x7f0800ec

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "sg"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f130245

    const-string/jumbo v6, "\ud83c\uddf8\ud83c\uddf0"

    move-object/from16 v75, v4

    const v4, 0x7f0800ed

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "sk"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f130257

    const-string/jumbo v6, "\ud83c\uddf9\ud83c\udded"

    move-object/from16 v76, v4

    const v4, 0x7f0800ee

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "th"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f13025c

    const-string/jumbo v6, "\ud83c\uddf9\ud83c\uddf3"

    move-object/from16 v77, v4

    const v4, 0x7f0800ef

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "tn"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f13025f

    const-string/jumbo v6, "\ud83c\uddf9\ud83c\uddf7"

    move-object/from16 v78, v4

    const v4, 0x7f0800f0

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "tr"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f130260

    const-string/jumbo v6, "\ud83c\uddf9\ud83c\uddfc"

    move-object/from16 v79, v4

    const v4, 0x7f0800f1

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "tw"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f130261

    const-string/jumbo v6, "\ud83c\uddfa\ud83c\udde6"

    move-object/from16 v80, v4

    const v4, 0x7f0800f2

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "ua"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f130262

    const-string/jumbo v6, "\ud83c\uddec\ud83c\udde7"

    move-object/from16 v81, v4

    const v4, 0x7f0800f3

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "uk"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f130266

    const-string/jumbo v6, "\ud83c\uddfa\ud83c\uddf8"

    move-object/from16 v82, v4

    const v4, 0x7f0800f4

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "us"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v1, 0x2

    new-instance v3, Lcz;

    nop

    const v5, 0x7f130273

    const-string/jumbo v6, "\ud83c\uddff\ud83c\udde6"

    move-object/from16 v83, v4

    const v4, 0x7f0800f5

    const/4 v1, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcz;-><init>(IILjava/lang/String;)V

    const/4 v1, 0x3

    new-instance v4, Ldj1;

    nop

    const-string/jumbo v5, "za"

    const/4 v1, 0x4

    invoke-direct {v4, v5, v3}, Ldj1;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    move-object/from16 v84, v4

    check-cast v7, Ldj1;

    check-cast v8, Ldj1;

    check-cast v9, Ldj1;

    check-cast v10, Ldj1;

    check-cast v11, Ldj1;

    check-cast v12, Ldj1;

    check-cast v13, Ldj1;

    check-cast v14, Ldj1;

    check-cast v15, Ldj1;

    check-cast v16, Ldj1;

    check-cast v17, Ldj1;

    check-cast v18, Ldj1;

    check-cast v19, Ldj1;

    check-cast v20, Ldj1;

    check-cast v21, Ldj1;

    check-cast v22, Ldj1;

    check-cast v23, Ldj1;

    check-cast v24, Ldj1;

    check-cast v25, Ldj1;

    check-cast v26, Ldj1;

    check-cast v27, Ldj1;

    check-cast v28, Ldj1;

    check-cast v29, Ldj1;

    check-cast v30, Ldj1;

    check-cast v31, Ldj1;

    check-cast v32, Ldj1;

    check-cast v33, Ldj1;

    check-cast v34, Ldj1;

    check-cast v35, Ldj1;

    check-cast v36, Ldj1;

    check-cast v37, Ldj1;

    check-cast v38, Ldj1;

    check-cast v39, Ldj1;

    check-cast v40, Ldj1;

    check-cast v41, Ldj1;

    check-cast v42, Ldj1;

    check-cast v43, Ldj1;

    check-cast v44, Ldj1;

    check-cast v45, Ldj1;

    check-cast v46, Ldj1;

    check-cast v47, Ldj1;

    check-cast v48, Ldj1;

    check-cast v49, Ldj1;

    check-cast v50, Ldj1;

    check-cast v51, Ldj1;

    check-cast v52, Ldj1;

    check-cast v53, Ldj1;

    check-cast v54, Ldj1;

    check-cast v55, Ldj1;

    check-cast v56, Ldj1;

    check-cast v57, Ldj1;

    check-cast v58, Ldj1;

    check-cast v59, Ldj1;

    check-cast v60, Ldj1;

    check-cast v61, Ldj1;

    check-cast v62, Ldj1;

    check-cast v63, Ldj1;

    check-cast v64, Ldj1;

    check-cast v65, Ldj1;

    check-cast v66, Ldj1;

    check-cast v67, Ldj1;

    check-cast v68, Ldj1;

    check-cast v69, Ldj1;

    check-cast v70, Ldj1;

    check-cast v71, Ldj1;

    check-cast v72, Ldj1;

    check-cast v73, Ldj1;

    check-cast v74, Ldj1;

    check-cast v75, Ldj1;

    check-cast v76, Ldj1;

    check-cast v77, Ldj1;

    check-cast v78, Ldj1;

    check-cast v79, Ldj1;

    check-cast v80, Ldj1;

    check-cast v81, Ldj1;

    check-cast v82, Ldj1;

    check-cast v83, Ldj1;

    check-cast v84, Ldj1;

    filled-new-array/range {v7 .. v84}, [Ldj1;

    move-result-object v3

    const/16 v1, 0xce4

    invoke-static {v3}, Lb61;->R([Ldj1;)Ljava/util/Map;

    move-result-object v3

    check-cast v3, Ljava/util/Map;

    sput-object v3, Ldz;->b:Ljava/util/Map;

    return-void
.end method

.method public static a(Ljava/lang/String;)Lcz;
    .registers 4

    .prologue
    const/16 v0, 0x88f

    sget-object v2, Ldz;->b:Ljava/util/Map;

    nop

    const/16 v0, 0xb0b

    invoke-interface {v2, p0}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcz;

    if-nez p0, :cond_14

    const/16 v0, 0x52b

    sget-object p0, Ldz;->a:Lcz;

    nop

    :cond_14
    check-cast p0, Lcz;

    return-object p0
.end method
