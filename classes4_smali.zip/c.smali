.class public final synthetic Lc;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 5

    iput p1, p0, Lc;->a:I

    iput-object p2, p0, Lc;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final a()V
    .registers 8

    .prologue
    const/16 v0, 0x19

    iget-object p0, p0, Lc;->b:Ljava/lang/Object;

    nop

    check-cast p0, Lxu0;

    const/16 v0, 0xf2

    iget-object v2, p0, Lxu0;->c:Ljava/util/ArrayDeque;

    nop

    monitor-enter v2

    :try_start_d
    const/16 v0, 0x109d

    iget-boolean v3, p0, Lxu0;->d:Z

    nop

    if-eqz v3, :cond_18

    monitor-exit v2

    return-void

    :catchall_16
    move-exception p0

    goto :goto_7b

    :cond_18
    const/16 v0, 0xf2

    iget-object v3, p0, Lxu0;->c:Ljava/util/ArrayDeque;

    nop

    const/16 v0, 0x2d3

    invoke-virtual {v3}, Ljava/util/ArrayDeque;->pollFirst()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Runnable;

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v3, :cond_2b

    move v6, v4

    goto :goto_2c

    :cond_2b
    move v6, v5

    :goto_2c
    const/16 v0, 0x255

    iput-boolean v6, p0, Lxu0;->d:Z

    monitor-exit v2
    :try_end_31
    .catchall {:try_start_d .. :try_end_31} :catchall_16

    :goto_31
    if-eqz v3, :cond_7a

    :try_start_33
    const/16 v0, 0x2d0

    invoke-interface {v3}, Ljava/lang/Runnable;->run()V
    :try_end_38
    .catchall {:try_start_33 .. :try_end_38} :catchall_59

    const/16 v0, 0xf2

    iget-object v2, p0, Lxu0;->c:Ljava/util/ArrayDeque;

    nop

    monitor-enter v2

    :try_start_3e
    const/16 v0, 0xf2

    iget-object v3, p0, Lxu0;->c:Ljava/util/ArrayDeque;

    nop

    const/16 v0, 0x2d3

    invoke-virtual {v3}, Ljava/util/ArrayDeque;->pollFirst()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Runnable;

    if-eqz v3, :cond_4f

    move v6, v4

    goto :goto_50

    :cond_4f
    move v6, v5

    :goto_50
    const/16 v0, 0x255

    iput-boolean v6, p0, Lxu0;->d:Z

    monitor-exit v2

    goto :goto_31

    :catchall_56
    move-exception p0

    monitor-exit v2
    :try_end_58
    .catchall {:try_start_3e .. :try_end_58} :catchall_56

    throw p0

    :catchall_59
    move-exception v2

    const/16 v0, 0xf2

    iget-object v3, p0, Lxu0;->c:Ljava/util/ArrayDeque;

    nop

    monitor-enter v3

    :try_start_60
    const/16 v0, 0x255

    iput-boolean v5, p0, Lxu0;->d:Z
    :try_end_64
    .catchall {:try_start_60 .. :try_end_64} :catchall_74

    :try_start_64
    const/16 v0, 0xb1f

    iget-object v4, p0, Lxu0;->a:Lqu0;

    nop

    const/16 v0, 0x95f

    iget-object p0, p0, Lxu0;->b:Lc;

    nop

    const/16 v0, 0x804

    invoke-virtual {v4, p0}, Lqu0;->execute(Ljava/lang/Runnable;)V
    :try_end_73
    .catch Ljava/util/concurrent/RejectedExecutionException; {:try_start_64 .. :try_end_73} :catch_76
    .catchall {:try_start_64 .. :try_end_73} :catchall_74

    goto :goto_76

    :catchall_74
    move-exception p0

    goto :goto_78

    :catch_76
    :goto_76
    :try_start_76
    monitor-exit v3
    :try_end_77
    .catchall {:try_start_76 .. :try_end_77} :catchall_74

    throw v2

    :goto_78
    :try_start_78
    monitor-exit v3
    :try_end_79
    .catchall {:try_start_78 .. :try_end_79} :catchall_74

    throw p0

    :cond_7a
    return-void

    :goto_7b
    :try_start_7b
    monitor-exit v2
    :try_end_7c
    .catchall {:try_start_7b .. :try_end_7c} :catchall_16

    throw p0
.end method


# virtual methods
.method public final run()V
    .registers 52

    .prologue
    move-object/from16 v17, p0

    const/16 v15, 0xc6b

    move-object/from16 v0, v17

    iget v15, v0, Lc;->a:I

    move/16 v18, v15

    const/16 v19, 0x2

    const/16 v20, 0x1

    const/16 v21, 0x0

    const/16 v22, 0x0

    packed-switch v18, :pswitch_data_d1a

    const/16 v15, 0x19

    move-object/from16 v0, v17

    iget-object v15, v0, Lc;->b:Ljava/lang/Object;

    move-object/16 v17, v15

    check-cast v17, Landroidx/swiperefreshlayout/widget/SwipeRefreshLayout;

    const/16 v15, 0xe06

    sget-object v18, Landroidx/swiperefreshlayout/widget/SwipeRefreshLayout;->K:[I

    nop

    const/16 v15, 0x11b2

    move-object/from16 v0, v17

    invoke-virtual {v0}, Landroidx/swiperefreshlayout/widget/SwipeRefreshLayout;->l()V

    return-void

    :pswitch_2e  #0x1c
    const/16 v15, 0x19

    move-object/from16 v0, v17

    iget-object v15, v0, Lc;->b:Ljava/lang/Object;

    move-object/16 v17, v15

    check-cast v17, Lcom/mbridge/msdk/config/component/style/StyleCpt;

    const/16 v15, 0xf2f

    move-object/from16 v0, v17

    invoke-static {v0}, Lcom/mbridge/msdk/config/component/style/StyleCpt;->g(Lcom/mbridge/msdk/config/component/style/StyleCpt;)V

    return-void

    :pswitch_41  #0x1b
    const/16 v15, 0x19

    move-object/from16 v0, v17

    iget-object v15, v0, Lc;->b:Ljava/lang/Object;

    move-object/16 v17, v15

    check-cast v17, Lgk;

    const/16 v15, 0x690

    move-object/from16 v0, v17

    move/from16 v1, v21

    iput-boolean v1, v0, Lgk;->c:Z

    const/16 v15, 0xfae

    move-object/from16 v0, v17

    iget-object v15, v0, Lgk;->e:Lay;

    move-object/16 v18, v15

    check-cast v18, Lcom/google/android/material/sidesheet/SideSheetBehavior;

    const/16 v15, 0x6bc

    move-object/from16 v0, v18

    iget-object v15, v0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->i:Lhk2;

    move-object/16 v20, v15

    if-eqz v20, :cond_87

    const/16 v15, 0x754

    move-object/from16 v0, v20

    invoke-virtual {v0}, Lhk2;->f()Z

    move-result v20

    if-eqz v20, :cond_87

    const/16 v15, 0x2e5

    move-object/from16 v0, v17

    iget v15, v0, Lgk;->b:I

    move/16 v18, v15

    const/16 v15, 0x792

    move-object/from16 v0, v17

    move/from16 v1, v18

    invoke-virtual {v0, v1}, Lgk;->a(I)V

    goto :goto_a8

    :cond_87
    const/16 v15, 0x1117

    move-object/from16 v0, v18

    iget v15, v0, Lcom/google/android/material/sidesheet/SideSheetBehavior;->h:I

    move/16 v20, v15

    move/from16 v0, v20

    move/from16 v1, v19

    if-ne v0, v1, :cond_a8

    const/16 v15, 0x2e5

    move-object/from16 v0, v17

    iget v15, v0, Lgk;->b:I

    move/16 v17, v15

    const/16 v15, 0xacf

    move-object/from16 v0, v18

    move/from16 v1, v17

    invoke-virtual {v0, v1}, Lcom/google/android/material/sidesheet/SideSheetBehavior;->x(I)V

    :cond_a8
    :goto_a8
    return-void

    :pswitch_a9  #0x1a
    const/16 v15, 0x19

    move-object/from16 v0, v17

    iget-object v15, v0, Lc;->b:Ljava/lang/Object;

    move-object/16 v17, v15

    check-cast v17, Lg12;

    const/16 v15, 0xcfe

    move-object/from16 v0, v17

    move/from16 v1, v21

    invoke-virtual {v0, v1}, Lg12;->e(Z)V

    return-void

    :pswitch_be  #0x19
    const/16 v15, 0x19

    move-object/from16 v0, v17

    iget-object v15, v0, Lc;->b:Ljava/lang/Object;

    move-object/16 v17, v15

    check-cast v17, Lnp1;

    const/16 v15, 0x628

    move-object/from16 v0, v17

    invoke-virtual {v0}, Lnp1;->m()V

    return-void

    :pswitch_d1  #0x18
    const/16 v15, 0x19

    move-object/from16 v0, v17

    iget-object v15, v0, Lc;->b:Ljava/lang/Object;

    move-object/16 v17, v15

    check-cast v17, Lso1;

    const-string/jumbo v18, "prxhost"

    const/16 v15, 0x1c1

    move-object/from16 v0, v17

    iget-object v15, v0, Lso1;->t:Landroid/widget/EditText;

    move-object/16 v17, v15

    if-eqz v17, :cond_fc

    const/16 v15, 0x1fd

    move-object/from16 v0, v17

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v18

    const/16 v15, 0x22a

    move-object/from16 v0, v17

    move/from16 v1, v18

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setMaxWidth(I)V

    return-void

    :cond_fc
    const/4 v15, 0x5

    move-object/from16 v0, v18

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v22

    :pswitch_103  #0x17
    const/16 v15, 0x19

    move-object/from16 v0, v17

    iget-object v15, v0, Lc;->b:Ljava/lang/Object;

    move-object/16 v17, v15

    check-cast v17, Lpn1;

    const/16 v15, 0xb6e

    move-object/from16 v0, v17

    iget-object v15, v0, Lpn1;->f:Lk11;

    move-object/16 v18, v15

    const/16 v15, 0x7c9

    move-object/from16 v0, v17

    iget v15, v0, Lpn1;->b:I

    move/16 v19, v15

    if-nez v19, :cond_138

    const/16 v15, 0xf9a

    move-object/from16 v0, v17

    move/from16 v1, v20

    iput-boolean v1, v0, Lpn1;->c:Z

    const/16 v15, 0x5f3

    sget-object v19, Ly01;->ON_PAUSE:Ly01;

    nop

    const/16 v15, 0x3cf

    move-object/from16 v0, v18

    move-object/from16 v1, v19

    invoke-virtual {v0, v1}, Lk11;->e(Ly01;)V

    :cond_138
    const/16 v15, 0x67d

    move-object/from16 v0, v17

    iget v15, v0, Lpn1;->a:I

    move/16 v19, v15

    if-nez v19, :cond_164

    const/16 v15, 0x69a

    move-object/from16 v0, v17

    iget-boolean v15, v0, Lpn1;->c:Z

    move/16 v19, v15

    if-eqz v19, :cond_164

    const/16 v15, 0xf7c

    sget-object v19, Ly01;->ON_STOP:Ly01;

    nop

    const/16 v15, 0x3cf

    move-object/from16 v0, v18

    move-object/from16 v1, v19

    invoke-virtual {v0, v1}, Lk11;->e(Ly01;)V

    const/16 v15, 0x1149

    move-object/from16 v0, v17

    move/from16 v1, v20

    iput-boolean v1, v0, Lpn1;->d:Z

    :cond_164
    return-void

    :pswitch_165  #0x16
    const/16 v15, 0x19

    move-object/from16 v0, v17

    iget-object v15, v0, Lc;->b:Ljava/lang/Object;

    move-object/16 v17, v15

    check-cast v17, Ldn1;

    const-string/jumbo v18, "sshhost"

    const/16 v15, 0xf8

    move-object/from16 v0, v17

    iget-object v15, v0, Ldn1;->w:Landroid/widget/EditText;

    move-object/16 v17, v15

    if-eqz v17, :cond_190

    const/16 v15, 0x1fd

    move-object/from16 v0, v17

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v18

    const/16 v15, 0x22a

    move-object/from16 v0, v17

    move/from16 v1, v18

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setMaxWidth(I)V

    return-void

    :cond_190
    const/4 v15, 0x5

    move-object/from16 v0, v18

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v22

    :pswitch_197  #0x15
    const/16 v15, 0x19

    move-object/from16 v0, v17

    iget-object v15, v0, Lc;->b:Ljava/lang/Object;

    move-object/16 v17, v15

    check-cast v17, Lcom/mbridge/msdk/config/dynamic/baseview/cusview/MoreOfferContainerView;

    const/16 v15, 0x10fb

    move-object/from16 v0, v17

    invoke-static {v0}, Lcom/mbridge/msdk/config/dynamic/baseview/cusview/MoreOfferContainerView;->b(Lcom/mbridge/msdk/config/dynamic/baseview/cusview/MoreOfferContainerView;)V

    return-void

    :pswitch_1aa  #0x14
    const/16 v15, 0x19

    move-object/from16 v0, v17

    iget-object v15, v0, Lc;->b:Ljava/lang/Object;

    move-object/16 v17, v15

    check-cast v17, Lcom/google/android/material/button/MaterialButton;

    const/16 v15, 0x903

    sget-object v18, Lcom/google/android/material/button/MaterialButton;->N:[I

    nop

    const/16 v15, 0xba5

    move-object/from16 v0, v17

    invoke-virtual {v0}, Lcom/google/android/material/button/MaterialButton;->q()V

    return-void

    :pswitch_1c2  #0x13
    const/16 v15, 0x19

    move-object/from16 v0, v17

    iget-object v15, v0, Lc;->b:Ljava/lang/Object;

    move-object/16 v17, v15

    check-cast v17, Lcom/tlsvpn/tlstunnel/MainActivity;

    const/16 v15, 0x44d

    sget v18, Lcom/tlsvpn/tlstunnel/MainActivity;->m:I

    nop

    const/16 v15, 0x27c

    move-object/from16 v0, v17

    invoke-virtual {v0}, Lcom/tlsvpn/tlstunnel/MainActivity;->k()V

    const/16 v15, 0x5b

    new-instance v18, Landroid/content/Intent;

    nop

    const-string/jumbo v19, "setProgress"

    const/16 v15, 0x62

    move-object/from16 v0, v18

    move-object/from16 v1, v19

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v15, 0x53

    move-object/from16 v0, v17

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v19

    const/16 v15, 0x4a

    move-object/from16 v0, v19

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v19

    const/16 v15, 0x64

    move-object/from16 v0, v18

    move-object/from16 v1, v19

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v18

    const/16 v15, 0x63

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    return-void

    :pswitch_20e  #0x12
    const/16 v15, 0x19

    move-object/from16 v0, v17

    iget-object v15, v0, Lc;->b:Ljava/lang/Object;

    move-object/16 v17, v15

    check-cast v17, Lfv0;

    if-eqz v17, :cond_224

    const/16 v15, 0x106a

    move-object/from16 v0, v17

    move-object/from16 v1, v22

    invoke-interface {v0, v1}, Lfv0;->a(Ljava/util/concurrent/CancellationException;)V

    :cond_224
    return-void

    :pswitch_225  #0x11
    const/16 v15, 0x650

    move-object/from16 v0, v17

    invoke-direct {v0}, Lc;->a()V

    return-void

    :pswitch_22d  #0x10
    const/16 v15, 0x19

    move-object/from16 v0, v17

    iget-object v15, v0, Lc;->b:Ljava/lang/Object;

    move-object/16 v17, v15

    check-cast v17, Lvu0;

    :try_start_238
    const/16 v15, 0x445

    move-object/from16 v0, v17

    iget-object v15, v0, Lvu0;->d:Lyu0;

    move-object/16 v18, v15

    const/16 v15, 0xace

    move-object/from16 v0, v18

    iget-object v15, v0, Lyu0;->u:Lg73;

    move-object/16 v19, v15

    const/16 v15, 0x10dd

    move-object/from16 v0, v18

    iget v15, v0, Lyu0;->t:I

    move/16 v18, v15

    move/from16 v0, v18

    int-to-long v0, v0

    move-wide/from16 v20, v0

    const/16 v15, 0x695

    move-object/from16 v0, v17

    invoke-virtual {v0}, Lvu0;->a()Lqz;

    move-result-object v17

    const/16 v15, 0x113d

    move-object/from16 v0, v19

    move-wide/from16 v1, v20

    move-object/from16 v3, v17

    invoke-virtual {v0, v1, v2, v3}, Lg73;->F(JLqz;)V
    :try_end_26b
    .catch Ljava/lang/RuntimeException; {:try_start_238 .. :try_end_26b} :catch_26c

    goto :goto_274

    :catch_26c
    move-exception v17

    const-string/jumbo v18, "yu0"

    const-string/jumbo v19, "Error while trying to log CronetTrafficInfo: "

    nop

    :goto_274
    return-void

    :pswitch_275  #0xf
    const/16 v15, 0x19

    move-object/from16 v0, v17

    iget-object v15, v0, Lc;->b:Ljava/lang/Object;

    move-object/16 v17, v15

    check-cast v17, Lj8;

    const-string/jumbo v18, "Cronet JavaUrlRequest.AsyncUrlRequestCallback#executeOnFallbackExecutor  onFailed running callback"

    const/16 v15, 0x9b8

    move-object/from16 v0, v18

    invoke-static {v0}, Lxy1;->b(Ljava/lang/String;)V

    :try_start_28a
    const/16 v15, 0xa8b

    move-object/from16 v0, v17

    invoke-virtual {v0}, Lj8;->run()V
    :try_end_291
    .catchall {:try_start_28a .. :try_end_291} :catchall_297

    const/16 v15, 0x73

    invoke-static {}, Landroid/os/Trace;->endSection()V

    return-void

    :catchall_297
    move-exception v17

    move-object/from16 v18, v17

    :try_start_29a
    const/16 v15, 0x73

    invoke-static {}, Landroid/os/Trace;->endSection()V
    :try_end_29f
    .catchall {:try_start_29a .. :try_end_29f} :catchall_2a0

    goto :goto_2aa

    :catchall_2a0
    move-exception v17

    const/16 v15, 0x135

    move-object/from16 v0, v18

    move-object/from16 v1, v17

    invoke-virtual {v0, v1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_2aa
    throw v18

    :pswitch_2ab  #0xe
    const/16 v15, 0x19

    move-object/from16 v0, v17

    iget-object v15, v0, Lc;->b:Ljava/lang/Object;

    move-object/16 v17, v15

    check-cast v17, Lmu0;

    const/16 v15, 0x837

    move-object/from16 v0, v17

    iget v15, v0, Lmu0;->h:I

    move/16 v18, v15

    add-int v18, v18, v20

    const/16 v15, 0xa50

    move-object/from16 v0, v17

    move/from16 v1, v18

    iput v1, v0, Lmu0;->h:I

    return-void

    :pswitch_2ca  #0xd
    const/16 v15, 0x19

    move-object/from16 v0, v17

    iget-object v15, v0, Lc;->b:Ljava/lang/Object;

    move-object/16 v17, v15

    check-cast v17, Landroidx/fragment/app/Fragment;

    const/16 v15, 0xf26

    move-object/from16 v0, v17

    invoke-static {v0}, Landroidx/fragment/app/Fragment;->a(Landroidx/fragment/app/Fragment;)V

    return-void

    :pswitch_2dd  #0xc
    const/16 v15, 0x19

    move-object/from16 v0, v17

    iget-object v15, v0, Lc;->b:Ljava/lang/Object;

    move-object/16 v17, v15

    move-object/from16 v18, v17

    check-cast v18, Lng0;

    const-string/jumbo v17, "fetchFonts result is not OK. ("

    const/16 v15, 0x116

    move-object/from16 v0, v18

    iget-object v15, v0, Lng0;->c:Ljava/lang/Object;

    move-object/16 v20, v15

    monitor-enter v20

    :try_start_2f7
    const/16 v15, 0x27f

    move-object/from16 v0, v18

    iget-object v15, v0, Lng0;->g:Lns2;

    move-object/16 v22, v15

    if-nez v22, :cond_308

    monitor-exit v20

    goto/16 :goto_490

    :catchall_305
    move-exception v17

    goto/16 :goto_493

    :cond_308
    monitor-exit v20
    :try_end_309
    .catchall {:try_start_2f7 .. :try_end_309} :catchall_305

    :try_start_309
    const/16 v15, 0x10e0

    move-object/from16 v0, v18

    invoke-virtual {v0}, Lng0;->c()Lxg0;

    move-result-object v20

    const/16 v15, 0xb2d

    move-object/from16 v0, v20

    iget v15, v0, Lxg0;->e:I

    move/16 v22, v15

    move/from16 v0, v22

    move/from16 v1, v19

    if-ne v0, v1, :cond_332

    const/16 v15, 0x116

    move-object/from16 v0, v18

    iget-object v15, v0, Lng0;->c:Ljava/lang/Object;

    move-object/16 v19, v15

    monitor-enter v19
    :try_end_32a
    .catchall {:try_start_309 .. :try_end_32a} :catchall_32f

    :try_start_32a
    monitor-exit v19

    goto :goto_332

    :catchall_32c
    move-exception v17

    monitor-exit v19
    :try_end_32e
    .catchall {:try_start_32a .. :try_end_32e} :catchall_32c

    :try_start_32e
    throw v17
    :try_end_32f
    .catchall {:try_start_32e .. :try_end_32f} :catchall_32f

    :catchall_32f
    move-exception v17

    goto/16 :goto_467

    :cond_332
    :goto_332
    if-nez v22, :cond_42e

    :try_start_334
    const-string/jumbo v17, "EmojiCompat.FontRequestEmojiCompatConfig.buildTypeface"

    const/16 v15, 0x27d

    sget-object v19, Ldc2;->b:Ljava/lang/reflect/Method;

    nop

    const/16 v15, 0x1ef

    move-object/from16 v0, v17

    invoke-static {v0}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    const/16 v15, 0x2a6

    move-object/from16 v0, v18

    iget-object v15, v0, Lng0;->a:Landroid/content/Context;

    move-object/16 v17, v15

    check-cast v20, Lxg0;

    filled-new-array/range {v20 .. v20}, [Lxg0;

    move-result-object v19

    const/16 v15, 0x3ef

    sget-object v22, Lef2;->a:Lnp3;

    nop

    const-string/jumbo v22, "TypefaceCompat.createFromFontInfo"

    const/16 v15, 0xbf2

    move-object/from16 v0, v22

    invoke-static {v0}, Lq23;->b0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v22

    const/16 v15, 0x1ef

    move-object/from16 v0, v22

    invoke-static {v0}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V
    :try_end_369
    .catchall {:try_start_334 .. :try_end_369} :catchall_41a

    :try_start_369
    const/16 v15, 0x3ef

    sget-object v22, Lef2;->a:Lnp3;

    nop

    const/16 v15, 0x5d0

    move-object/from16 v0, v22

    move-object/from16 v1, v17

    move-object/from16 v2, v19

    move/from16 v3, v21

    invoke-virtual {v0, v1, v2, v3}, Lnp3;->y(Landroid/content/Context;[Lxg0;I)Landroid/graphics/Typeface;

    move-result-object v17
    :try_end_37c
    .catchall {:try_start_369 .. :try_end_37c} :catchall_41c

    :try_start_37c
    const/16 v15, 0x73

    invoke-static {}, Landroid/os/Trace;->endSection()V

    const/16 v15, 0x2a6

    move-object/from16 v0, v18

    iget-object v15, v0, Lng0;->a:Landroid/content/Context;

    move-object/16 v19, v15

    const/16 v15, 0xb1c

    move-object/from16 v0, v20

    iget-object v15, v0, Lxg0;->a:Landroid/net/Uri;

    move-object/16 v20, v15

    const/16 v15, 0x679

    move-object/from16 v0, v19

    move-object/from16 v1, v20

    invoke-static {v0, v1}, Luz;->I(Landroid/content/Context;Landroid/net/Uri;)Ljava/nio/MappedByteBuffer;

    move-result-object v19
    :try_end_39d
    .catchall {:try_start_37c .. :try_end_39d} :catchall_41a

    if-eqz v19, :cond_406

    if-eqz v17, :cond_406

    :try_start_3a1
    const-string/jumbo v20, "EmojiCompat.MetadataRepo.create"

    const/16 v15, 0x1ef

    move-object/from16 v0, v20

    invoke-static {v0}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    const/16 v15, 0x727

    new-instance v20, Lx5;

    nop

    const/16 v15, 0x8aa

    move-object/from16 v0, v19

    invoke-static {v0}, Lvr0;->D(Ljava/nio/MappedByteBuffer;)Lu91;

    move-result-object v19

    const/16 v15, 0x551

    move-object/from16 v0, v20

    move-object/from16 v1, v17

    move-object/from16 v2, v19

    invoke-direct {v0, v1, v2}, Lx5;-><init>(Landroid/graphics/Typeface;Lu91;)V
    :try_end_3c3
    .catchall {:try_start_3a1 .. :try_end_3c3} :catchall_3fa

    :try_start_3c3
    const/16 v15, 0x73

    invoke-static {}, Landroid/os/Trace;->endSection()V
    :try_end_3c8
    .catchall {:try_start_3c3 .. :try_end_3c8} :catchall_41a

    :try_start_3c8
    const/16 v15, 0x73

    invoke-static {}, Landroid/os/Trace;->endSection()V

    const/16 v15, 0x116

    move-object/from16 v0, v18

    iget-object v15, v0, Lng0;->c:Ljava/lang/Object;

    move-object/16 v19, v15

    monitor-enter v19
    :try_end_3d7
    .catchall {:try_start_3c8 .. :try_end_3d7} :catchall_32f

    :try_start_3d7
    const/16 v15, 0x27f

    move-object/from16 v0, v18

    iget-object v15, v0, Lng0;->g:Lns2;

    move-object/16 v17, v15

    if-eqz v17, :cond_3ee

    const/16 v15, 0x99a

    move-object/from16 v0, v17

    move-object/from16 v1, v20

    invoke-virtual {v0, v1}, Lns2;->w(Lx5;)V

    goto :goto_3ee

    :catchall_3ec
    move-exception v17

    goto :goto_3f8

    :cond_3ee
    :goto_3ee
    monitor-exit v19
    :try_end_3ef
    .catchall {:try_start_3d7 .. :try_end_3ef} :catchall_3ec

    :try_start_3ef
    const/16 v15, 0x38a

    move-object/from16 v0, v18

    invoke-virtual {v0}, Lng0;->b()V
    :try_end_3f6
    .catchall {:try_start_3ef .. :try_end_3f6} :catchall_32f

    goto/16 :goto_490

    :goto_3f8
    :try_start_3f8
    monitor-exit v19
    :try_end_3f9
    .catchall {:try_start_3f8 .. :try_end_3f9} :catchall_3ec

    :try_start_3f9
    throw v17
    :try_end_3fa
    .catchall {:try_start_3f9 .. :try_end_3fa} :catchall_32f

    :catchall_3fa
    move-exception v17

    :try_start_3fb
    const/16 v15, 0x27d

    sget-object v19, Ldc2;->b:Ljava/lang/reflect/Method;

    nop

    const/16 v15, 0x73

    invoke-static {}, Landroid/os/Trace;->endSection()V

    throw v17

    :cond_406
    const/16 v15, 0x379

    new-instance v17, Ljava/lang/RuntimeException;

    nop

    const-string/jumbo v19, "Unable to open file."

    const/16 v15, 0x2b0

    move-object/from16 v0, v17

    move-object/from16 v1, v19

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    check-cast v17, Ljava/lang/Throwable;

    throw v17

    :catchall_41a
    move-exception v17

    goto :goto_423

    :catchall_41c
    move-exception v17

    const/16 v15, 0x73

    invoke-static {}, Landroid/os/Trace;->endSection()V

    throw v17
    :try_end_423
    .catchall {:try_start_3fb .. :try_end_423} :catchall_41a

    :goto_423
    :try_start_423
    const/16 v15, 0x27d

    sget-object v19, Ldc2;->b:Ljava/lang/reflect/Method;

    nop

    const/16 v15, 0x73

    invoke-static {}, Landroid/os/Trace;->endSection()V

    throw v17

    :cond_42e
    const/16 v15, 0x379

    new-instance v19, Ljava/lang/RuntimeException;

    nop

    const/4 v15, -0x3

    new-instance v20, Ljava/lang/StringBuilder;

    nop

    const/16 v15, 0x97

    move-object/from16 v0, v20

    move-object/from16 v1, v17

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v15, 0x33

    move-object/from16 v0, v20

    move/from16 v1, v22

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v17, ")"

    const/4 v15, 0x0

    move-object/from16 v0, v20

    move-object/from16 v1, v17

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v15, -0x2

    move-object/from16 v0, v20

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v17

    const/16 v15, 0x2b0

    move-object/from16 v0, v19

    move-object/from16 v1, v17

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    check-cast v19, Ljava/lang/Throwable;

    throw v19
    :try_end_467
    .catchall {:try_start_423 .. :try_end_467} :catchall_32f

    :goto_467
    const/16 v15, 0x116

    move-object/from16 v0, v18

    iget-object v15, v0, Lng0;->c:Ljava/lang/Object;

    move-object/16 v19, v15

    monitor-enter v19

    :try_start_471
    const/16 v15, 0x27f

    move-object/from16 v0, v18

    iget-object v15, v0, Lng0;->g:Lns2;

    move-object/16 v20, v15

    if-eqz v20, :cond_488

    const/16 v15, 0xd43

    move-object/from16 v0, v20

    move-object/from16 v1, v17

    invoke-virtual {v0, v1}, Lns2;->v(Ljava/lang/Throwable;)V

    goto :goto_488

    :catchall_486
    move-exception v17

    goto :goto_491

    :cond_488
    :goto_488
    monitor-exit v19
    :try_end_489
    .catchall {:try_start_471 .. :try_end_489} :catchall_486

    const/16 v15, 0x38a

    move-object/from16 v0, v18

    invoke-virtual {v0}, Lng0;->b()V

    :goto_490
    return-void

    :goto_491
    :try_start_491
    monitor-exit v19
    :try_end_492
    .catchall {:try_start_491 .. :try_end_492} :catchall_486

    throw v17

    :goto_493
    :try_start_493
    monitor-exit v20
    :try_end_494
    .catchall {:try_start_493 .. :try_end_494} :catchall_305

    throw v17

    :pswitch_495  #0xb
    const/16 v15, 0x19

    move-object/from16 v0, v17

    iget-object v15, v0, Lc;->b:Ljava/lang/Object;

    move-object/16 v17, v15

    check-cast v17, Lu60;

    const/16 v15, 0x5ad

    move-object/from16 v0, v17

    iget-object v15, v0, Lu60;->h:Landroid/widget/AutoCompleteTextView;

    move-object/16 v18, v15

    const/16 v15, 0x9a2

    move-object/from16 v0, v18

    invoke-virtual {v0}, Landroid/widget/AutoCompleteTextView;->isPopupShowing()Z

    move-result v18

    const/16 v15, 0xc58

    move-object/from16 v0, v17

    move/from16 v1, v18

    invoke-virtual {v0, v1}, Lu60;->s(Z)V

    const/16 v15, 0x10c4

    move-object/from16 v0, v17

    move/from16 v1, v18

    iput-boolean v1, v0, Lu60;->m:Z

    return-void

    :pswitch_4c3  #0xa
    const/16 v15, 0x19

    move-object/from16 v0, v17

    iget-object v15, v0, Lc;->b:Ljava/lang/Object;

    move-object/16 v17, v15

    check-cast v17, Ljava/util/ArrayList;

    const/16 v18, 0x4

    const/16 v15, 0x11c9

    move/from16 v0, v18

    move-object/from16 v1, v17

    invoke-static {v0, v1}, Lwi0;->a(ILjava/util/ArrayList;)V

    return-void

    :pswitch_4da  #0x9
    const/16 v15, 0x19

    move-object/from16 v0, v17

    iget-object v15, v0, Lc;->b:Ljava/lang/Object;

    move-object/16 v17, v15

    check-cast v17, Lwu;

    const-string/jumbo v18, "prxhost"

    const/16 v15, 0x78f

    move-object/from16 v0, v17

    iget-object v15, v0, Lwu;->F:Landroid/widget/TextView;

    move-object/16 v17, v15

    if-eqz v17, :cond_505

    const/16 v15, 0x1fd

    move-object/from16 v0, v17

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v18

    const/16 v15, 0x22a

    move-object/from16 v0, v17

    move/from16 v1, v18

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setMaxWidth(I)V

    return-void

    :cond_505
    const/4 v15, 0x5

    move-object/from16 v0, v18

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v22

    :pswitch_50c  #0x8
    const/16 v15, 0x19

    move-object/from16 v0, v17

    iget-object v15, v0, Lc;->b:Ljava/lang/Object;

    move-object/16 v17, v15

    check-cast v17, Lwt;

    const/16 v15, 0xe1f

    move-object/from16 v0, v17

    invoke-static {v0}, Lwt;->b(Lwt;)V

    return-void

    :pswitch_51f  #0x7
    const/16 v15, 0x19

    move-object/from16 v0, v17

    iget-object v15, v0, Lc;->b:Ljava/lang/Object;

    move-object/16 v17, v15

    check-cast v17, Lst;

    const/16 v15, 0x5d7

    move-object/from16 v0, v17

    iget-object v15, v0, Lst;->b:Ljava/lang/Runnable;

    move-object/16 v18, v15

    if-eqz v18, :cond_544

    const/16 v15, 0x2d0

    move-object/from16 v0, v18

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    const/16 v15, 0x1079

    move-object/from16 v0, v17

    move-object/from16 v1, v22

    iput-object v1, v0, Lst;->b:Ljava/lang/Runnable;

    :cond_544
    return-void

    :pswitch_545  #0x6
    const/16 v15, 0x19

    move-object/from16 v0, v17

    iget-object v15, v0, Lc;->b:Ljava/lang/Object;

    move-object/16 v17, v15

    check-cast v17, Lut;

    const/16 v15, 0xc82

    move-object/from16 v0, v17

    invoke-virtual {v0}, Lut;->invalidateMenu()V

    return-void

    :pswitch_558  #0x5
    const/16 v15, 0x19

    move-object/from16 v0, v17

    iget-object v15, v0, Lc;->b:Ljava/lang/Object;

    move-object/16 v17, v15

    check-cast v17, Lwq;

    const/16 v15, 0xfaf

    move-object/from16 v0, v17

    move/from16 v1, v20

    invoke-virtual {v0, v1}, Lwq;->s(Z)V

    return-void

    :pswitch_56d  #0x4
    const/16 v15, 0x19

    move-object/from16 v0, v17

    iget-object v15, v0, Lc;->b:Ljava/lang/Object;

    move-object/16 v17, v15

    check-cast v17, Lcom/google/android/material/carousel/CarouselLayoutManager;

    const/16 v15, 0xa02

    move-object/from16 v0, v17

    invoke-virtual {v0}, Lzq1;->o0()V

    return-void

    :pswitch_580  #0x3
    const/16 v15, 0x19

    move-object/from16 v0, v17

    iget-object v15, v0, Lc;->b:Ljava/lang/Object;

    move-object/16 v17, v15

    check-cast v17, Lba;

    const/16 v15, 0x1048

    move-object/from16 v0, v17

    iget-object v15, v0, Lba;->c:Lam0;

    move-object/16 v17, v15

    const/16 v15, 0xa96

    move-object/from16 v0, v17

    iget-object v15, v0, Lam0;->b:Ljava/lang/Object;

    move-object/16 v17, v15

    check-cast v17, Lba;

    const/16 v15, 0x223

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v18

    const/16 v15, 0x2c1

    move-object/from16 v0, v17

    iget-object v15, v0, Lba;->b:Ljava/util/ArrayList;

    move-object/16 v23, v15

    const/16 v15, 0x223

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v24

    move/from16 v26, v21

    :goto_5b6
    const/16 v15, 0xac

    move-object/from16 v0, v23

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v27

    move/from16 v0, v26

    move/from16 v1, v27

    if-ge v0, v1, :cond_a18

    const/16 v15, 0x43

    move-object/from16 v0, v23

    move/from16 v1, v26

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v27

    check-cast v27, Lh52;

    if-nez v27, :cond_5d6

    :cond_5d2
    :goto_5d2
    move-object/from16 p0, v23

    goto/16 :goto_a0c

    :cond_5d6
    const/16 v15, 0x43b

    move-object/from16 v0, v17

    iget-object v15, v0, Lba;->a:Lk32;

    move-object/16 v28, v15

    const/16 v15, 0x698

    move-object/from16 v0, v28

    move-object/from16 v1, v27

    invoke-virtual {v0, v1}, Lk32;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v29

    check-cast v29, Ljava/lang/Long;

    if-nez v29, :cond_5ee

    goto :goto_603

    :cond_5ee
    const/16 v15, 0x417

    move-object/from16 v0, v29

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v29

    cmp-long v29, v29, v24

    if-gez v29, :cond_5d2

    const/16 v15, 0x33f

    move-object/from16 v0, v28

    move-object/from16 v1, v27

    invoke-virtual {v0, v1}, Lk32;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :goto_603
    const/16 v15, 0x1160

    move-object/from16 v0, v27

    iget-wide v15, v0, Lh52;->g:J

    move-wide/16 v28, v15

    const-wide/16 v30, 0x0

    cmp-long v32, v28, v30

    if-nez v32, :cond_62d

    const/16 v15, 0x1a4

    move-object/from16 v0, v27

    move-wide/from16 v1, v18

    iput-wide v1, v0, Lh52;->g:J

    const/16 v15, 0x264

    move-object/from16 v0, v27

    iget v15, v0, Lh52;->b:F

    move/16 v28, v15

    const/16 v15, 0x48b

    move-object/from16 v0, v27

    move/from16 v1, v28

    invoke-virtual {v0, v1}, Lh52;->c(F)V

    goto :goto_5d2

    :cond_62d
    sub-long v28, v18, v28

    const/16 v15, 0x1a4

    move-object/from16 v0, v27

    move-wide/from16 v1, v18

    iput-wide v1, v0, Lh52;->g:J

    const/16 v15, 0x4f4

    invoke-static {}, Lh52;->b()Lba;

    move-result-object v32

    const/16 v15, 0x1063

    move-object/from16 v0, v32

    iget v15, v0, Lba;->g:F

    move/16 v32, v15

    const/16 v30, 0x0

    cmpl-float v31, v32, v30

    if-nez v31, :cond_652

    const-wide/32 v28, 0x7fffffff

    :goto_64f
    move-wide/from16 v40, v28

    goto :goto_65f

    :cond_652
    move-wide/from16 v0, v28

    long-to-float v0, v0

    move/from16 v28, v0

    div-float v28, v28, v32

    move/from16 v0, v28

    float-to-long v0, v0

    move-wide/from16 v28, v0

    goto :goto_64f

    :goto_65f
    const/16 v15, 0xcdf

    move-object/from16 v0, v27

    iget-boolean v15, v0, Lh52;->m:Z

    move/16 v28, v15

    const/16 v15, 0x3d0

    move-object/from16 v0, v27

    iget v15, v0, Lh52;->l:F

    move/16 v29, v15

    const v31, -0x800001

    const v32, 0x7f7fffff  # Float.MAX_VALUE

    if-eqz v28, :cond_6d3

    cmpl-float v28, v29, v32

    if-eqz v28, :cond_69e

    const/16 v15, 0xae

    move-object/from16 v0, v27

    iget-object v15, v0, Lh52;->k:Li52;

    move-object/16 v28, v15

    move-object/from16 p0, v23

    move/from16 v0, v29

    float-to-double v0, v0

    move-wide/from16 v22, v0

    const/16 v15, 0x389

    move-object/from16 v0, v28

    move-wide/from16 v1, v22

    iput-wide v1, v0, Li52;->i:D

    const/16 v15, 0x520

    move-object/from16 v0, v27

    move/from16 v1, v32

    iput v1, v0, Lh52;->l:F

    goto :goto_6a0

    :cond_69e
    move-object/from16 p0, v23

    :goto_6a0
    const/16 v15, 0xae

    move-object/from16 v0, v27

    iget-object v15, v0, Lh52;->k:Li52;

    move-object/16 v22, v15

    const/16 v15, 0x24b

    move-object/from16 v0, v22

    iget-wide v15, v0, Li52;->i:D

    move-wide/16 v22, v15

    move-wide/from16 v0, v22

    double-to-float v0, v0

    move/from16 v22, v0

    const/16 v15, 0x6b

    move-object/from16 v0, v27

    move/from16 v1, v22

    iput v1, v0, Lh52;->b:F

    const/16 v15, 0x13a

    move-object/from16 v0, v27

    move/from16 v1, v30

    iput v1, v0, Lh52;->a:F

    const/16 v15, 0xce5

    move-object/from16 v0, v27

    move/from16 v1, v21

    iput-boolean v1, v0, Lh52;->m:Z

    move/from16 v22, v20

    goto/16 :goto_87f

    :cond_6d3
    move-object/from16 p0, v23

    cmpl-float v22, v29, v32

    const/16 v15, 0xae

    move-object/from16 v0, v27

    iget-object v15, v0, Lh52;->k:Li52;

    move-object/16 v23, v15

    const/16 v15, 0x264

    move-object/from16 v0, v27

    iget v15, v0, Lh52;->b:F

    move/16 v28, v15

    const/16 v15, 0x528

    move-object/from16 v0, v27

    iget v15, v0, Lh52;->a:F

    move/16 v29, v15

    if-eqz v22, :cond_792

    move/from16 v0, v28

    float-to-double v0, v0

    move-wide/from16 v20, v0

    move/from16 v0, v29

    float-to-double v0, v0

    move-wide/from16 v28, v0

    const-wide/16 v35, 0x2

    div-long v48, v40, v35

    move-wide/from16 v44, v20

    move-object/from16 v43, v23

    move-wide/from16 v46, v28

    const/16 v15, 0x1aa

    move v0, v15

    move-object/from16 v1, v43

    move-wide/from16 v2, v44

    move-wide/from16 v4, v46

    move-wide/from16 v6, v48

    invoke-virtual/range {v1 .. v7}, Li52;->c(DDJ)La70;

    move-result-object v20

    const/16 v15, 0xae

    move-object/from16 v0, v27

    iget-object v15, v0, Lh52;->k:Li52;

    move-object/16 v21, v15

    const/16 v15, 0x3d0

    move-object/from16 v0, v27

    iget v15, v0, Lh52;->l:F

    move/16 v23, v15

    move/from16 v0, v23

    float-to-double v0, v0

    move-wide/from16 v28, v0

    const/16 v15, 0x389

    move-object/from16 v0, v21

    move-wide/from16 v1, v28

    iput-wide v1, v0, Li52;->i:D

    const/16 v15, 0x520

    move-object/from16 v0, v27

    move/from16 v1, v32

    iput v1, v0, Lh52;->l:F

    const/16 v15, 0x1ba

    move-object/from16 v0, v20

    iget v15, v0, La70;->a:F

    move/16 v23, v15

    move/from16 v0, v23

    float-to-double v0, v0

    move-wide/from16 v28, v0

    const/16 v15, 0x279

    move-object/from16 v0, v20

    iget v15, v0, La70;->b:F

    move/16 v20, v15

    move/from16 v0, v20

    float-to-double v0, v0

    move-wide/from16 v22, v0

    move-object/from16 v43, v21

    move-wide/from16 v46, v22

    move-wide/from16 v44, v28

    const/16 v15, 0x1aa

    move v0, v15

    move-object/from16 v1, v43

    move-wide/from16 v2, v44

    move-wide/from16 v4, v46

    move-wide/from16 v6, v48

    invoke-virtual/range {v1 .. v7}, Li52;->c(DDJ)La70;

    move-result-object v20

    const/16 v15, 0x1ba

    move-object/from16 v0, v20

    iget v15, v0, La70;->a:F

    move/16 v21, v15

    const/16 v15, 0x6b

    move-object/from16 v0, v27

    move/from16 v1, v21

    iput v1, v0, Lh52;->b:F

    const/16 v15, 0x279

    move-object/from16 v0, v20

    iget v15, v0, La70;->b:F

    move/16 v20, v15

    const/16 v15, 0x13a

    move-object/from16 v0, v27

    move/from16 v1, v20

    iput v1, v0, Lh52;->a:F

    goto :goto_7d3

    :cond_792
    move-object/from16 v35, v23

    move/from16 v0, v28

    float-to-double v0, v0

    move-wide/from16 v20, v0

    move/from16 v0, v29

    float-to-double v0, v0

    move-wide/from16 v22, v0

    move-wide/from16 v36, v20

    move-wide/from16 v38, v22

    const/16 v15, 0x1aa

    move v0, v15

    move-object/from16 v1, v35

    move-wide/from16 v2, v36

    move-wide/from16 v4, v38

    move-wide/from16 v6, v40

    invoke-virtual/range {v1 .. v7}, Li52;->c(DDJ)La70;

    move-result-object v20

    const/16 v15, 0x1ba

    move-object/from16 v0, v20

    iget v15, v0, La70;->a:F

    move/16 v21, v15

    const/16 v15, 0x6b

    move-object/from16 v0, v27

    move/from16 v1, v21

    iput v1, v0, Lh52;->b:F

    const/16 v15, 0x279

    move-object/from16 v0, v20

    iget v15, v0, La70;->b:F

    move/16 v20, v15

    const/16 v15, 0x13a

    move-object/from16 v0, v27

    move/from16 v1, v20

    iput v1, v0, Lh52;->a:F

    :goto_7d3
    const/16 v15, 0x467

    move/from16 v0, v21

    move/from16 v1, v31

    invoke-static {v0, v1}, Ljava/lang/Math;->max(FF)F

    move-result v20

    const/16 v15, 0x6b

    move-object/from16 v0, v27

    move/from16 v1, v20

    iput v1, v0, Lh52;->b:F

    const/16 v15, 0x529

    move/from16 v0, v20

    move/from16 v1, v32

    invoke-static {v0, v1}, Ljava/lang/Math;->min(FF)F

    move-result v20

    const/16 v15, 0x6b

    move-object/from16 v0, v27

    move/from16 v1, v20

    iput v1, v0, Lh52;->b:F

    const/16 v15, 0x528

    move-object/from16 v0, v27

    iget v15, v0, Lh52;->a:F

    move/16 v21, v15

    const/16 v15, 0xae

    move-object/from16 v0, v27

    iget-object v15, v0, Lh52;->k:Li52;

    move-object/16 v22, v15

    const/4 v15, -0x6

    move-object/from16 v0, v22

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v15, 0x3bb

    move/from16 v0, v21

    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v21

    move/from16 v0, v21

    float-to-double v0, v0

    move-wide/from16 v28, v0

    const/16 v15, 0xa28

    move-object/from16 v0, v22

    iget-wide v15, v0, Li52;->e:D

    move-wide/16 v31, v15

    cmpg-double v28, v28, v31

    if-gez v28, :cond_87d

    const/16 v15, 0x24b

    move-object/from16 v0, v22

    iget-wide v15, v0, Li52;->i:D

    move-wide/16 v28, v15

    move-wide/from16 v0, v28

    double-to-float v0, v0

    move/from16 v28, v0

    sub-float v20, v20, v28

    const/16 v15, 0x3bb

    move/from16 v0, v20

    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v20

    move/from16 v0, v20

    float-to-double v0, v0

    move-wide/from16 v28, v0

    const/16 v15, 0xeb8

    move-object/from16 v0, v22

    iget-wide v15, v0, Li52;->d:D

    move-wide/16 v31, v15

    cmpg-double v20, v28, v31

    if-gez v20, :cond_87d

    const/16 v15, 0xae

    move-object/from16 v0, v27

    iget-object v15, v0, Lh52;->k:Li52;

    move-object/16 v20, v15

    const/16 v15, 0x24b

    move-object/from16 v0, v20

    iget-wide v15, v0, Li52;->i:D

    move-wide/16 v28, v15

    move-wide/from16 v0, v28

    double-to-float v0, v0

    move/from16 v20, v0

    const/16 v15, 0x6b

    move-object/from16 v0, v27

    move/from16 v1, v20

    iput v1, v0, Lh52;->b:F

    const/16 v15, 0x13a

    move-object/from16 v0, v27

    move/from16 v1, v30

    iput v1, v0, Lh52;->a:F

    const/16 v22, 0x1

    goto :goto_87f

    :cond_87d
    const/16 v22, 0x0

    :goto_87f
    const/16 v15, 0x264

    move-object/from16 v0, v27

    iget v15, v0, Lh52;->b:F

    move/16 v20, v15

    const v23, 0x7f7fffff  # Float.MAX_VALUE

    const/16 v15, 0x529

    move/from16 v0, v20

    move/from16 v1, v23

    invoke-static {v0, v1}, Ljava/lang/Math;->min(FF)F

    move-result v20

    const/16 v15, 0x6b

    move-object/from16 v0, v27

    move/from16 v1, v20

    iput v1, v0, Lh52;->b:F

    const v21, -0x800001

    const/16 v15, 0x467

    move/from16 v0, v20

    move/from16 v1, v21

    invoke-static {v0, v1}, Ljava/lang/Math;->max(FF)F

    move-result v20

    const/16 v15, 0x6b

    move-object/from16 v0, v27

    move/from16 v1, v20

    iput v1, v0, Lh52;->b:F

    const/16 v15, 0x48b

    move-object/from16 v0, v27

    move/from16 v1, v20

    invoke-virtual {v0, v1}, Lh52;->c(F)V

    if-eqz v22, :cond_a0c

    const/16 v15, 0x112f

    move-object/from16 v0, v27

    iget-object v15, v0, Lh52;->i:Ljava/util/ArrayList;

    move-object/16 v20, v15

    const/16 v22, 0x0

    const/16 v15, 0x122c

    move-object/from16 v0, v27

    move/from16 v1, v22

    iput-boolean v1, v0, Lh52;->f:Z

    const/16 v15, 0x4f4

    invoke-static {}, Lh52;->b()Lba;

    move-result-object v21

    const/16 v15, 0x43b

    move-object/from16 v0, v21

    iget-object v15, v0, Lba;->a:Lk32;

    move-object/16 v23, v15

    const/16 v15, 0x33f

    move-object/from16 v0, v23

    move-object/from16 v1, v27

    invoke-virtual {v0, v1}, Lk32;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v15, 0x2c1

    move-object/from16 v0, v21

    iget-object v15, v0, Lba;->b:Ljava/util/ArrayList;

    move-object/16 v23, v15

    const/16 v15, 0x1152

    move-object/from16 v0, v23

    move-object/from16 v1, v27

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->indexOf(Ljava/lang/Object;)I

    move-result v28

    if-ltz v28, :cond_914

    const/16 v29, 0x0

    const/16 v15, 0x58a

    move-object/from16 v0, v23

    move/from16 v1, v28

    move-object/from16 v2, v29

    invoke-virtual {v0, v1, v2}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    const/16 v23, 0x1

    const/16 v15, 0x314

    move-object/from16 v0, v21

    move/from16 v1, v23

    iput-boolean v1, v0, Lba;->f:Z

    :cond_914
    const-wide/16 v28, 0x0

    const/16 v15, 0x1a4

    move-object/from16 v0, v27

    move-wide/from16 v1, v28

    iput-wide v1, v0, Lh52;->g:J

    const/16 v22, 0x0

    const/16 v15, 0xd87

    move-object/from16 v0, v27

    move/from16 v1, v22

    iput-boolean v1, v0, Lh52;->c:Z

    const/16 v21, 0x0

    :goto_92a
    const/16 v15, 0xac

    move-object/from16 v0, v20

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v23

    move/from16 v0, v21

    move/from16 v1, v23

    if-ge v0, v1, :cond_9e6

    const/16 v15, 0x43

    move-object/from16 v0, v20

    move/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v23

    if-eqz v23, :cond_9e2

    const/16 v15, 0x43

    move-object/from16 v0, v20

    move/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v23

    check-cast v23, Lhi;

    const/16 v15, 0xf93

    move-object/from16 v0, v23

    iget-object v15, v0, Lhi;->a:Lki;

    move-object/16 v23, v15

    const/16 v15, 0x2df

    move-object/from16 v0, v23

    invoke-virtual {v0}, Lki;->getProgressDrawable()Lc40;

    move-result-object v27

    if-eqz v27, :cond_9e2

    const/16 v15, 0x2df

    move-object/from16 v0, v23

    invoke-virtual {v0}, Lki;->getProgressDrawable()Lc40;

    move-result-object v27

    const/16 v15, 0xc32

    move-object/from16 v0, v27

    invoke-virtual {v0}, Landroid/graphics/drawable/Drawable;->getLevel()I

    move-result v27

    const/16 v28, 0x2710

    move/from16 v0, v27

    move/from16 v1, v28

    if-ne v0, v1, :cond_9e2

    const/16 v15, 0xd01

    move-object/from16 v0, v23

    iget-object v15, v0, Lki;->l:Lii;

    move-object/16 v27, v15

    const/16 v15, 0x631

    move-object/from16 v0, v23

    invoke-virtual {v0}, Landroid/view/View;->getVisibility()I

    move-result v28

    if-eqz v28, :cond_9a1

    const/16 v15, 0x763

    move-object/from16 v0, v23

    iget-object v15, v0, Lki;->k:Lii;

    move-object/16 v27, v15

    const/16 v15, 0x2f7

    move-object/from16 v0, v23

    move-object/from16 v1, v27

    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    goto :goto_9e2

    :cond_9a1
    const/16 v15, 0x2f7

    move-object/from16 v0, v23

    move-object/from16 v1, v27

    invoke-virtual {v0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    const/16 v15, 0x223

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v28

    const/16 v15, 0xc93

    move-object/from16 v0, v23

    iget-wide v15, v0, Lki;->e:J

    move-wide/16 v30, v15

    sub-long v28, v28, v30

    const/16 v15, 0xc19

    move-object/from16 v0, v23

    iget v15, v0, Lki;->d:I

    move/16 v30, v15

    move/from16 v0, v30

    int-to-long v0, v0

    move-wide/from16 v30, v0

    cmp-long v32, v28, v30

    if-ltz v32, :cond_9d5

    const/16 v15, 0xe6a

    move-object/from16 v0, v27

    invoke-virtual {v0}, Lii;->run()V

    goto :goto_9e2

    :cond_9d5
    sub-long v30, v30, v28

    const/16 v15, 0x60d

    move-object/from16 v0, v23

    move-object/from16 v1, v27

    move-wide/from16 v2, v30

    invoke-virtual {v0, v1, v2, v3}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_9e2
    :goto_9e2
    add-int/lit8 v21, v21, 0x1

    goto/16 :goto_92a

    :cond_9e6
    const/16 v15, 0xac

    move-object/from16 v0, v20

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v21

    const/16 v50, 0x1

    add-int/lit8 v21, v21, -0x1

    :goto_9f2
    if-ltz v21, :cond_a0c

    const/16 v15, 0x43

    move-object/from16 v0, v20

    move/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v23

    if-nez v23, :cond_a09

    const/16 v15, 0x363

    move-object/from16 v0, v20

    move/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    :cond_a09
    add-int/lit8 v21, v21, -0x1

    goto :goto_9f2

    :cond_a0c
    :goto_a0c
    add-int/lit8 v26, v26, 0x1

    const/16 v20, 0x1

    const/16 v21, 0x0

    const/16 v22, 0x0

    move-object/from16 v23, p0

    goto/16 :goto_5b6

    :cond_a18
    move-object/from16 p0, v23

    const/16 v15, 0xb29

    move-object/from16 v0, v17

    iget-boolean v15, v0, Lba;->f:Z

    move/16 v18, v15

    if-eqz v18, :cond_a83

    const/16 v15, 0xac

    move-object/from16 v0, p0

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v18

    const/16 v50, 0x1

    add-int/lit8 v18, v18, -0x1

    :goto_a31
    if-ltz v18, :cond_a4f

    move-object/from16 v19, p0

    const/16 v15, 0x43

    move-object/from16 v0, v19

    move/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v20

    if-nez v20, :cond_a4a

    const/16 v15, 0x363

    move-object/from16 v0, v19

    move/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    :cond_a4a
    add-int/lit8 v18, v18, -0x1

    move-object/from16 p0, v19

    goto :goto_a31

    :cond_a4f
    move-object/from16 v19, p0

    const/16 v15, 0xac

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v18

    if-nez v18, :cond_a78

    const/16 v15, 0x1fc

    sget v18, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 v20, 0x21

    move/from16 v0, v18

    move/from16 v1, v20

    if-lt v0, v1, :cond_a78

    const/16 v15, 0x9bb

    move-object/from16 v0, v17

    iget-object v15, v0, Lba;->h:Lz9;

    move-object/16 v18, v15

    const/16 v15, 0x6f5

    move-object/from16 v0, v18

    invoke-virtual {v0}, Lz9;->a()Z

    :cond_a78
    const/16 v22, 0x0

    const/16 v15, 0x314

    move-object/from16 v0, v17

    move/from16 v1, v22

    iput-boolean v1, v0, Lba;->f:Z

    goto :goto_a85

    :cond_a83
    move-object/from16 v19, p0

    :goto_a85
    const/16 v15, 0xac

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v18

    if-lez v18, :cond_ac3

    const/16 v15, 0x95c

    move-object/from16 v0, v17

    iget-object v15, v0, Lba;->e:Lec;

    move-object/16 v18, v15

    const/16 v15, 0x828

    move-object/from16 v0, v17

    iget-object v15, v0, Lba;->d:Lc;

    move-object/16 v17, v15

    const/16 v15, 0x11ec

    move-object/from16 v0, v18

    iget-object v15, v0, Lec;->b:Ljava/lang/Object;

    move-object/16 v18, v15

    check-cast v18, Landroid/view/Choreographer;

    const/16 v15, 0xdb5

    new-instance v19, Laa;

    nop

    const/16 v15, 0x78c

    move-object/from16 v0, v19

    move-object/from16 v1, v17

    invoke-direct {v0, v1}, Laa;-><init>(Lc;)V

    const/16 v15, 0xe02

    move-object/from16 v0, v18

    move-object/from16 v1, v19

    invoke-virtual {v0, v1}, Landroid/view/Choreographer;->postFrameCallback(Landroid/view/Choreographer$FrameCallback;)V

    :cond_ac3
    return-void

    :pswitch_ac4  #0x2
    const/16 v15, 0x19

    move-object/from16 v0, v17

    iget-object v15, v0, Lc;->b:Ljava/lang/Object;

    move-object/16 v17, v15

    check-cast v17, Lvp1;

    const/16 v15, 0x101

    sget-boolean v18, Lmi2;->n:Z

    nop

    if-nez v18, :cond_b85

    const/16 v15, 0x195

    sget-boolean v18, Lmi2;->d:Z

    nop

    if-eqz v18, :cond_b85

    const/16 v15, 0x12f

    sget-object v18, Lg4;->n:Lx4;

    nop

    if-eqz v18, :cond_b8d

    const/16 v15, 0x1013

    sget-object v20, Lg4;->f:Ljava/lang/String;

    nop

    const/16 v15, 0xb6b

    sget-object v29, Lg4;->o:Ls4;

    nop

    const/4 v15, -0x6

    move-object/from16 v0, v20

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v15, -0x6

    move-object/from16 v0, v29

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v15, 0x11b1

    move-object/from16 v0, v29

    invoke-static {v0}, Luz;->G(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v30

    const/16 v15, 0x48a

    new-instance v21, Ljava/util/LinkedHashSet;

    nop

    const/16 v15, 0x3f9

    move-object/from16 v0, v21

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    const/16 v15, 0x160

    new-instance v23, Ljava/util/LinkedHashMap;

    nop

    const/16 v15, 0x158

    move-object/from16 v0, v23

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    const/16 v15, 0x108

    new-instance v24, Landroid/os/Bundle;

    nop

    const/16 v15, 0x198

    move-object/from16 v0, v24

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/16 v15, 0x167

    new-instance v25, Ljava/util/HashSet;

    nop

    const/16 v15, 0x13f

    move-object/from16 v0, v25

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    const/16 v15, 0x167

    new-instance v26, Ljava/util/HashSet;

    nop

    const/16 v15, 0x13f

    move-object/from16 v0, v26

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    const/16 v15, 0x160

    new-instance v27, Ljava/util/LinkedHashMap;

    nop

    const/16 v15, 0x158

    move-object/from16 v0, v27

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    const/16 v15, 0xaed

    new-instance v19, Lph;

    nop

    const/16 v22, 0x0

    const/16 v28, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/16 v15, 0x93c

    move v0, v15

    move-object/from16 v1, v19

    move-object/from16 v2, v20

    move-object/from16 v3, v21

    move-object/from16 v4, v22

    move-object/from16 v5, v23

    move-object/from16 v6, v24

    move-object/from16 v7, v25

    move-object/from16 v8, v26

    move-object/from16 v9, v27

    move-object/from16 v10, v28

    move-object/from16 v11, v29

    move-object/from16 v12, v30

    move-object/from16 v13, v31

    move/from16 v14, v32

    invoke-direct/range {v1 .. v14}, Lph;-><init>(Ljava/lang/String;Ljava/util/LinkedHashSet;Ljava/lang/String;Ljava/util/LinkedHashMap;Landroid/os/Bundle;Ljava/util/HashSet;Ljava/util/HashSet;Ljava/util/LinkedHashMap;Ljava/lang/String;Ls4;Ljava/util/List;Lpj2;Z)V

    const/16 v15, 0xaa9

    move-object/from16 v0, v18

    move-object/from16 v1, v19

    move-object/from16 v2, v17

    invoke-virtual {v0, v1, v2}, Lx4;->d(Lph;Lk4;)V

    goto :goto_b8d

    :cond_b85
    const/16 v22, 0x0

    const/16 v15, 0x8ba

    move/from16 v0, v22

    sput-boolean v0, Lg4;->p:Z

    :cond_b8d
    :goto_b8d
    return-void

    :pswitch_b8e  #0x1
    const/16 v15, 0x19

    move-object/from16 v0, v17

    iget-object v15, v0, Lc;->b:Ljava/lang/Object;

    move-object/16 v17, v15

    move-object/from16 v18, v17

    check-cast v18, Landroid/app/Activity;

    const/16 v15, 0x415

    move-object/from16 v0, v18

    invoke-virtual {v0}, Landroid/app/Activity;->isFinishing()Z

    move-result v17

    if-nez v17, :cond_ce0

    const/16 v15, 0xc91

    sget-object v20, Lh3;->g:Landroid/os/Handler;

    nop

    const/16 v15, 0x96f

    sget-object v17, Lh3;->f:Ljava/lang/reflect/Method;

    nop

    const/16 v15, 0x1fc

    sget v21, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 v23, 0x1c

    move/from16 v0, v21

    move/from16 v1, v23

    if-lt v0, v1, :cond_bc5

    const/16 v15, 0x1a3

    move-object/from16 v0, v18

    invoke-virtual {v0}, Landroid/app/Activity;->recreate()V

    goto/16 :goto_ce0

    :cond_bc5
    const/16 v23, 0x1b

    const/16 v24, 0x1a

    move/from16 v0, v21

    move/from16 v1, v24

    if-eq v0, v1, :cond_bd5

    move/from16 v0, v21

    move/from16 v1, v23

    if-ne v0, v1, :cond_bd9

    :cond_bd5
    if-nez v17, :cond_bd9

    goto/16 :goto_cd9

    :cond_bd9
    const/16 v15, 0xc79

    sget-object v25, Lh3;->e:Ljava/lang/reflect/Method;

    nop

    if-nez v25, :cond_be9

    const/16 v15, 0xf82

    sget-object v25, Lh3;->d:Ljava/lang/reflect/Method;

    nop

    if-nez v25, :cond_be9

    goto/16 :goto_cd9

    :cond_be9
    :try_start_be9
    const/16 v15, 0xc98

    sget-object v25, Lh3;->c:Ljava/lang/reflect/Field;

    nop

    check-cast v25, Ljava/lang/reflect/Field;

    move-object/from16 v0, v25

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v26

    if-nez v26, :cond_bfc

    goto/16 :goto_cd9

    :cond_bfc
    const/16 v15, 0xf03

    sget-object v25, Lh3;->b:Ljava/lang/reflect/Field;

    nop

    check-cast v25, Ljava/lang/reflect/Field;

    move-object/from16 v0, v25

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v25

    if-nez v25, :cond_c0f

    goto/16 :goto_cd9

    :cond_c0f
    const/16 v15, 0x587

    move-object/from16 v0, v18

    invoke-virtual {v0}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object v27

    const/16 v15, 0x79f

    new-instance v28, Lg3;

    nop

    const/16 v15, 0x73d

    move-object/from16 v0, v28

    move-object/from16 v1, v18

    invoke-direct {v0, v1}, Lg3;-><init>(Landroid/app/Activity;)V

    const/16 v15, 0x2f8

    move-object/from16 v0, v27

    move-object/from16 v1, v28

    invoke-virtual {v0, v1}, Landroid/app/Application;->registerActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    const/16 v15, 0x248

    new-instance v29, Lcl0;

    nop

    const/16 v15, 0x1d5

    move-object/from16 v0, v29

    move/from16 v1, v19

    move-object/from16 v2, v28

    move-object/from16 v3, v26

    invoke-direct {v0, v1, v2, v3}, Lcl0;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    const/16 v15, 0x216

    move-object/from16 v0, v20

    move-object/from16 v1, v29

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_c49
    .catchall {:try_start_be9 .. :try_end_c49} :catchall_cd9

    move/from16 v0, v21

    move/from16 v1, v24

    if-eq v0, v1, :cond_c59

    move/from16 v0, v21

    move/from16 v1, v23

    if-ne v0, v1, :cond_c56

    goto :goto_c59

    :cond_c56
    const/16 v50, 0x0

    goto :goto_c5b

    :cond_c59
    :goto_c59
    const/16 v50, 0x1

    :goto_c5b
    const/16 v19, 0x3

    if-eqz v50, :cond_c96

    const/16 v22, 0x0

    :try_start_c61
    const/16 v15, 0xb1

    move/from16 v0, v22

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v29

    const/16 v15, 0x10d

    sget-object v30, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    nop
    :try_end_c6e
    .catchall {:try_start_c61 .. :try_end_c6e} :catchall_c90

    const/16 v31, 0x0

    const/16 v32, 0x0

    move-object/from16 v21, v27

    const/16 v27, 0x0

    move-object/from16 v22, v28

    const/16 v28, 0x0

    move-object/from16 v33, v30

    move-object/from16 v34, v30

    :try_start_c7e
    filled-new-array/range {v26 .. v34}, [Ljava/lang/Object;

    move-result-object v23

    check-cast v17, Ljava/lang/reflect/Method;

    move-object/from16 v0, v17

    move-object/from16 v1, v25

    move-object/from16 v2, v23

    invoke-virtual {v0, v1, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_ca1

    :catchall_c8e
    move-exception v17

    goto :goto_cbd

    :catchall_c90
    move-exception v17

    move-object/from16 v21, v27

    move-object/from16 v22, v28

    goto :goto_cbd

    :cond_c96
    move-object/from16 v21, v27

    move-object/from16 v22, v28

    const/16 v15, 0x1a3

    move-object/from16 v0, v18

    invoke-virtual {v0}, Landroid/app/Activity;->recreate()V
    :try_end_ca1
    .catchall {:try_start_c7e .. :try_end_ca1} :catchall_c8e

    :goto_ca1
    :try_start_ca1
    const/16 v15, 0x248

    new-instance v17, Lcl0;

    nop

    const/16 v15, 0x1d5

    move-object/from16 v0, v17

    move/from16 v1, v19

    move-object/from16 v2, v21

    move-object/from16 v3, v22

    invoke-direct {v0, v1, v2, v3}, Lcl0;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    const/16 v15, 0x216

    move-object/from16 v0, v20

    move-object/from16 v1, v17

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_ce0

    :goto_cbd
    const/16 v15, 0x248

    new-instance v23, Lcl0;

    nop

    const/16 v15, 0x1d5

    move-object/from16 v0, v23

    move/from16 v1, v19

    move-object/from16 v2, v21

    move-object/from16 v3, v22

    invoke-direct {v0, v1, v2, v3}, Lcl0;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    const/16 v15, 0x216

    move-object/from16 v0, v20

    move-object/from16 v1, v23

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    throw v17
    :try_end_cd9
    .catchall {:try_start_ca1 .. :try_end_cd9} :catchall_cd9

    :catchall_cd9
    :goto_cd9
    const/16 v15, 0x1a3

    move-object/from16 v0, v18

    invoke-virtual {v0}, Landroid/app/Activity;->recreate()V

    :cond_ce0
    :goto_ce0
    return-void

    :pswitch_ce1  #0x0
    const/16 v15, 0x19

    move-object/from16 v0, v17

    iget-object v15, v0, Lc;->b:Ljava/lang/Object;

    move-object/16 v17, v15

    check-cast v17, Lcom/tlsvpn/tlstunnel/ui/About;

    const/16 v15, 0xd9

    move-object/from16 v0, v17

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->isAdded()Z

    move-result v18

    if-eqz v18, :cond_d19

    const/16 v15, 0x108f

    move-object/from16 v0, v17

    iget-object v15, v0, Lcom/tlsvpn/tlstunnel/ui/About;->e:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    move-object/16 v17, v15

    if-eqz v17, :cond_d0d

    const/16 v23, 0x1

    const/16 v15, 0x10d8

    move-object/from16 v0, v17

    move/from16 v1, v23

    invoke-virtual {v0, v1}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->f(Z)V

    goto :goto_d19

    :cond_d0d
    const-string/jumbo v17, "check"

    const/4 v15, 0x5

    move-object/from16 v0, v17

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    const/16 v42, 0x0

    throw v42

    :cond_d19
    :goto_d19
    return-void

    :pswitch_data_d1a
    .packed-switch 0x0
        :pswitch_ce1  #00000000
        :pswitch_b8e  #00000001
        :pswitch_ac4  #00000002
        :pswitch_580  #00000003
        :pswitch_56d  #00000004
        :pswitch_558  #00000005
        :pswitch_545  #00000006
        :pswitch_51f  #00000007
        :pswitch_50c  #00000008
        :pswitch_4da  #00000009
        :pswitch_4c3  #0000000a
        :pswitch_495  #0000000b
        :pswitch_2dd  #0000000c
        :pswitch_2ca  #0000000d
        :pswitch_2ab  #0000000e
        :pswitch_275  #0000000f
        :pswitch_22d  #00000010
        :pswitch_225  #00000011
        :pswitch_20e  #00000012
        :pswitch_1c2  #00000013
        :pswitch_1aa  #00000014
        :pswitch_197  #00000015
        :pswitch_165  #00000016
        :pswitch_103  #00000017
        :pswitch_d1  #00000018
        :pswitch_be  #00000019
        :pswitch_a9  #0000001a
        :pswitch_41  #0000001b
        :pswitch_2e  #0000001c
    .end packed-switch
.end method
