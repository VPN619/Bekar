.class public final synthetic Lc51;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/tlsvpn/tlstunnel/MainActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/tlsvpn/tlstunnel/MainActivity;I)V
    .registers 5

    iput p2, p0, Lc51;->a:I

    iput-object p1, p0, Lc51;->b:Lcom/tlsvpn/tlstunnel/MainActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 8

    .prologue
    const/16 v0, 0xf7b

    iget p1, p0, Lc51;->a:I

    nop

    const v2, 0x7f13023e

    const-string/jumbo v3, "is_premium"

    const/16 v0, 0xc77

    iget-object p0, p0, Lc51;->b:Lcom/tlsvpn/tlstunnel/MainActivity;

    nop

    packed-switch p1, :pswitch_data_80

    const/16 v0, 0x44d

    sget p1, Lcom/tlsvpn/tlstunnel/MainActivity;->m:I

    nop

    const/16 v0, 0x4e5

    new-instance p1, Lg12;

    nop

    const/16 v0, 0x2b3

    invoke-direct {p1}, Lg12;-><init>()V

    const/16 v0, 0x108

    new-instance v4, Landroid/os/Bundle;

    nop

    const/16 v0, 0x198

    invoke-direct {v4}, Landroid/os/Bundle;-><init>()V

    const/4 v5, 0x1

    const/16 v0, 0x27b

    invoke-virtual {v4, v3, v5}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/16 v0, 0x19a

    invoke-virtual {p1, v4}, Landroidx/fragment/app/Fragment;->setArguments(Landroid/os/Bundle;)V

    const/16 v0, 0x2ff

    invoke-virtual {p0}, Landroidx/fragment/app/l;->c()Lfi0;

    move-result-object v3

    const/16 v0, 0xb4

    invoke-virtual {p0, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x8c

    invoke-virtual {p1, v3, p0}, Landroidx/fragment/app/g;->show(Landroidx/fragment/app/p;Ljava/lang/String;)V

    return-void

    :pswitch_49  #0x0
    const/16 v0, 0x44d

    sget p1, Lcom/tlsvpn/tlstunnel/MainActivity;->m:I

    nop

    const/16 v0, 0x4e5

    new-instance p1, Lg12;

    nop

    const/16 v0, 0x2b3

    invoke-direct {p1}, Lg12;-><init>()V

    const/16 v0, 0x108

    new-instance v4, Landroid/os/Bundle;

    nop

    const/16 v0, 0x198

    invoke-direct {v4}, Landroid/os/Bundle;-><init>()V

    const/4 v5, 0x0

    const/16 v0, 0x27b

    invoke-virtual {v4, v3, v5}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/16 v0, 0x19a

    invoke-virtual {p1, v4}, Landroidx/fragment/app/Fragment;->setArguments(Landroid/os/Bundle;)V

    const/16 v0, 0x2ff

    invoke-virtual {p0}, Landroidx/fragment/app/l;->c()Lfi0;

    move-result-object v3

    const/16 v0, 0xb4

    invoke-virtual {p0, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x8c

    invoke-virtual {p1, v3, p0}, Landroidx/fragment/app/g;->show(Landroidx/fragment/app/p;Ljava/lang/String;)V

    return-void

    nop

    :pswitch_data_80
    .packed-switch 0x0
        :pswitch_49  #00000000
    .end packed-switch
.end method
