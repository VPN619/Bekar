.class public final synthetic Lbn1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ldn1;


# direct methods
.method public synthetic constructor <init>(Ldn1;I)V
    .registers 5

    iput p2, p0, Lbn1;->a:I

    iput-object p1, p0, Lbn1;->b:Ldn1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 6

    .prologue
    const/16 v0, 0x10f5

    iget p1, p0, Lbn1;->a:I

    nop

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/16 v0, 0xa6d

    iget-object p0, p0, Lbn1;->b:Ldn1;

    nop

    packed-switch p1, :pswitch_data_40

    const/16 v0, 0xbb

    invoke-virtual {p0, v3, v2}, Ldn1;->c(ZZ)V

    return-void

    :pswitch_15  #0x6
    const/16 v0, 0xbb

    invoke-virtual {p0, v3, v2}, Ldn1;->c(ZZ)V

    return-void

    :pswitch_1b  #0x5
    const/16 v0, 0xbb

    invoke-virtual {p0, v3, v3}, Ldn1;->c(ZZ)V

    return-void

    :pswitch_21  #0x4
    const/16 v0, 0xbb

    invoke-virtual {p0, v3, v3}, Ldn1;->c(ZZ)V

    return-void

    :pswitch_27  #0x3
    const/16 v0, 0x39e

    invoke-virtual {p0}, Ldn1;->d()V

    return-void

    :pswitch_2d  #0x2
    const/16 v0, 0x39e

    invoke-virtual {p0}, Ldn1;->d()V

    return-void

    :pswitch_33  #0x1
    const/16 v0, 0xbb

    invoke-virtual {p0, v2, v3}, Ldn1;->c(ZZ)V

    return-void

    :pswitch_39  #0x0
    const/16 v0, 0xbb

    invoke-virtual {p0, v2, v3}, Ldn1;->c(ZZ)V

    return-void

    nop

    :pswitch_data_40
    .packed-switch 0x0
        :pswitch_39  #00000000
        :pswitch_33  #00000001
        :pswitch_2d  #00000002
        :pswitch_27  #00000003
        :pswitch_21  #00000004
        :pswitch_1b  #00000005
        :pswitch_15  #00000006
    .end packed-switch
.end method
