.class public final synthetic Lwz1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lyz1;


# direct methods
.method public synthetic constructor <init>(Lyz1;I)V
    .registers 5

    iput p2, p0, Lwz1;->a:I

    iput-object p1, p0, Lwz1;->b:Lyz1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 5

    .prologue
    const/16 v0, 0xefb

    iget p1, p0, Lwz1;->a:I

    nop

    const/4 v2, 0x0

    const/16 v0, 0xe38

    iget-object p0, p0, Lwz1;->b:Lyz1;

    nop

    packed-switch p1, :pswitch_data_38

    const/16 v0, 0x1f1

    iget-object p1, p0, Lyz1;->C:Ljava/lang/String;

    nop

    if-eqz p1, :cond_1b

    const/16 v0, 0x374

    invoke-virtual {p0, p1}, Lyz1;->c(Ljava/lang/String;)V

    return-void

    :cond_1b
    const-string/jumbo p0, "selectedServerHost"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v2

    :pswitch_23  #0x0
    const/16 v0, 0x4cb

    iget-object p1, p0, Lyz1;->v:Ljava/lang/String;

    nop

    if-eqz p1, :cond_30

    const/16 v0, 0x374

    invoke-virtual {p0, p1}, Lyz1;->c(Ljava/lang/String;)V

    return-void

    :cond_30
    const-string/jumbo p0, "connectedServerHost"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v2

    :pswitch_data_38
    .packed-switch 0x0
        :pswitch_23  #00000000
    .end packed-switch
.end method
