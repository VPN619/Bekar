.class public final Lou;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final A:Z

.field public B:Ljava/lang/String;

.field public final a:Z

.field public b:I

.field public c:Z

.field public d:I

.field public e:I

.field public f:Ljava/lang/String;

.field public g:Ljava/lang/String;

.field public h:Z

.field public i:Ljava/lang/String;

.field public j:Ljava/lang/String;

.field public k:Ljava/lang/String;

.field public l:Ljava/lang/String;

.field public m:I

.field public n:Z

.field public o:Ljava/lang/String;

.field public p:Z

.field public q:Ljava/lang/String;

.field public r:Z

.field public s:Ljava/lang/String;

.field public t:Z

.field public u:Ljava/lang/String;

.field public v:Ljava/lang/String;

.field public w:Z

.field public x:Z

.field public y:Z

.field public final z:Z


# direct methods
.method public constructor <init>(Landroid/content/SharedPreferences;Landroid/content/res/Resources;ZZ)V
    .registers 25

    .prologue
    move-object/from16 v4, p0

    move-object/from16 v5, p1

    move-object/from16 v6, p2

    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    move/from16 v7, p4

    const/16 v2, 0xc78

    iput-boolean v7, v4, Lou;->a:Z

    const/16 v7, 0x1f2

    const/16 v2, 0x825

    iput v7, v4, Lou;->b:I

    const-string/jumbo v7, ""

    const/16 v2, 0x39c

    iput-object v7, v4, Lou;->f:Ljava/lang/String;

    const/16 v2, 0xdb

    iput-object v7, v4, Lou;->g:Ljava/lang/String;

    const/16 v2, 0x244

    iput-object v7, v4, Lou;->i:Ljava/lang/String;

    const/16 v2, 0x4aa

    iput-object v7, v4, Lou;->j:Ljava/lang/String;

    const/16 v2, 0x261

    iput-object v7, v4, Lou;->k:Ljava/lang/String;

    const/16 v2, 0x266

    iput-object v7, v4, Lou;->l:Ljava/lang/String;

    const/16 v2, 0x3d4

    iput-object v7, v4, Lou;->o:Ljava/lang/String;

    const/16 v2, 0x47f

    iput-object v7, v4, Lou;->q:Ljava/lang/String;

    const/16 v2, 0x360

    iput-object v7, v4, Lou;->s:Ljava/lang/String;

    const/16 v2, 0x3c3

    iput-object v7, v4, Lou;->u:Ljava/lang/String;

    const/16 v2, 0x335

    iput-object v7, v4, Lou;->v:Ljava/lang/String;

    const/16 v2, 0x962

    iput-object v7, v4, Lou;->B:Ljava/lang/String;

    const-string/jumbo v8, "cryptoconfig"

    const/16 v2, 0x2e

    invoke-interface {v5, v8, v7}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    if-nez v8, :cond_54

    move-object v8, v7

    :cond_54
    const/16 v2, 0x47

    invoke-virtual {v8}, Ljava/lang/String;->length()I

    move-result v9

    const v10, 0x7f030005

    const/4 v11, 0x3

    const-string/jumbo v12, "psrvslctd"

    const-string/jumbo v13, "sshpass"

    const-string/jumbo v14, "sshuser"

    const-string/jumbo v15, "pserver"

    const-string/jumbo v16, "server"

    const-string/jumbo v17, "port"

    const/16 v18, 0x1

    const/16 v19, 0x0

    if-lez v9, :cond_254

    const/16 v2, 0x2e4

    sget-object v9, Lip;->a:Ljava/nio/charset/Charset;

    nop

    const/16 v2, 0x2c

    invoke-virtual {v8, v9}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v8

    const/4 v2, -0x6

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v2, 0x11e1

    invoke-virtual {v4, v8}, Lou;->b([B)Z

    const/16 v2, 0x9d

    iget-boolean v8, v4, Lou;->h:Z

    nop

    if-eqz v8, :cond_ae

    const/16 v2, 0x3b

    iget-object v8, v4, Lou;->i:Ljava/lang/String;

    nop

    const/16 v2, 0x47

    invoke-virtual {v8}, Ljava/lang/String;->length()I

    move-result v8

    if-lez v8, :cond_ae

    const/16 v2, 0x34b

    iget-object v8, v4, Lou;->j:Ljava/lang/String;

    nop

    const/16 v2, 0x47

    invoke-virtual {v8}, Ljava/lang/String;->length()I

    move-result v8

    if-lez v8, :cond_ae

    move/from16 v8, v18

    goto :goto_b0

    :cond_ae
    move/from16 v8, v19

    :goto_b0
    const/16 v2, 0xd24

    iput-boolean v8, v4, Lou;->z:Z

    const/16 v2, 0x77

    move/from16 v0, v19

    invoke-interface {v5, v15, v0}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v9

    if-eqz v9, :cond_c5

    if-eqz v8, :cond_c5

    if-nez p3, :cond_c5

    move/from16 v9, v18

    goto :goto_c7

    :cond_c5
    move/from16 v9, v19

    :goto_c7
    const/16 v2, 0x3c8

    iput-boolean v9, v4, Lou;->h:Z

    if-eqz v8, :cond_110

    const/16 v2, 0x2e2

    iget-object v8, v4, Lou;->k:Ljava/lang/String;

    nop

    const/16 v2, 0x47

    invoke-virtual {v8}, Ljava/lang/String;->length()I

    move-result v8

    if-nez v8, :cond_db

    goto :goto_e8

    :cond_db
    const/16 v2, 0xef9

    iget-object v8, v4, Lou;->l:Ljava/lang/String;

    nop

    const/16 v2, 0x47

    invoke-virtual {v8}, Ljava/lang/String;->length()I

    move-result v8

    if-nez v8, :cond_10a

    :goto_e8
    const/16 v2, 0x4a0

    move/from16 v0, v19

    iput-boolean v0, v4, Lou;->A:Z

    const/16 v2, 0x2e

    invoke-interface {v5, v14, v7}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    if-nez v8, :cond_f7

    move-object v8, v7

    :cond_f7
    const/16 v2, 0x261

    iput-object v8, v4, Lou;->k:Ljava/lang/String;

    const/16 v2, 0x2e

    invoke-interface {v5, v13, v7}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    if-nez v8, :cond_104

    goto :goto_105

    :cond_104
    move-object v7, v8

    :goto_105
    const/16 v2, 0x266

    iput-object v7, v4, Lou;->l:Ljava/lang/String;

    goto :goto_110

    :cond_10a
    const/16 v2, 0x4a0

    move/from16 v0, v18

    iput-boolean v0, v4, Lou;->A:Z

    :cond_110
    :goto_110
    const/16 v2, 0x9d

    iget-boolean v7, v4, Lou;->h:Z

    nop

    if-eqz v7, :cond_14f

    const/16 v2, 0x103

    move/from16 v0, v19

    iput v0, v4, Lou;->d:I

    const/16 v2, 0x7a

    invoke-interface {v5}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v6

    const/16 v2, 0x56

    move-object/from16 v0, v16

    move/from16 v1, v19

    invoke-interface {v6, v0, v1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/16 v2, 0x6f

    invoke-interface {v6}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/16 v2, 0x91

    move/from16 v0, v19

    iput v0, v4, Lou;->e:I

    const/16 v2, 0x7a

    invoke-interface {v5}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v5

    const/16 v2, 0x32

    iget v4, v4, Lou;->e:I

    nop

    const/16 v2, 0x56

    move-object/from16 v0, v17

    invoke-interface {v5, v0, v4}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/16 v2, 0x6f

    invoke-interface {v5}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void

    :cond_14f
    const/16 v2, 0x77

    move/from16 v0, v19

    invoke-interface {v5, v12, v0}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v7

    const/16 v2, 0x49b

    iput-boolean v7, v4, Lou;->c:Z

    const/16 v2, 0xb0

    move-object/from16 v0, v16

    move/from16 v1, v19

    invoke-interface {v5, v0, v1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v7

    const/16 v2, 0x103

    iput v7, v4, Lou;->d:I

    const/16 v2, 0xb0

    move-object/from16 v0, v17

    move/from16 v1, v19

    invoke-interface {v5, v0, v1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v7

    const/16 v2, 0x91

    iput v7, v4, Lou;->e:I

    const/16 v2, 0xf1

    iget-boolean v7, v4, Lou;->c:Z

    nop

    if-eqz v7, :cond_17f

    goto :goto_181

    :cond_17f
    move/from16 v11, v19

    :goto_181
    const/16 v2, 0x4fe

    invoke-static {v5, v6, v11}, Lqk;->p(Landroid/content/SharedPreferences;Landroid/content/res/Resources;I)[Ljava/lang/String;

    move-result-object v7

    const/16 v2, 0x11f

    iget v8, v4, Lou;->d:I

    nop

    array-length v9, v7

    if-lt v8, v9, :cond_1a9

    const/16 v2, 0x103

    move/from16 v0, v19

    iput v0, v4, Lou;->d:I

    const/16 v2, 0x7a

    invoke-interface {v5}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v8

    const/16 v2, 0x56

    move-object/from16 v0, v16

    move/from16 v1, v19

    invoke-interface {v8, v0, v1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/16 v2, 0x6f

    invoke-interface {v8}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_1a9
    const/16 v2, 0x11f

    iget v8, v4, Lou;->d:I

    nop

    aget-object v7, v7, v8

    const/16 v2, 0x244

    iput-object v7, v4, Lou;->i:Ljava/lang/String;

    const/16 v2, 0x3e2

    invoke-virtual {v6, v10}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v6

    const/4 v2, -0x6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v2, 0x32

    iget v7, v4, Lou;->e:I

    nop

    array-length v8, v6

    if-lt v7, v8, :cond_1e3

    const/16 v2, 0x91

    move/from16 v0, v19

    iput v0, v4, Lou;->e:I

    const/16 v2, 0x7a

    invoke-interface {v5}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v7

    const/16 v2, 0x32

    iget v8, v4, Lou;->e:I

    nop

    const/16 v2, 0x56

    move-object/from16 v0, v17

    invoke-interface {v7, v0, v8}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/16 v2, 0x6f

    invoke-interface {v7}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_1e3
    const/16 v2, 0x32

    iget v7, v4, Lou;->e:I

    nop

    array-length v8, v6

    sub-int v8, v8, v18

    if-ne v7, v8, :cond_20d

    const/16 v2, 0xe1

    iget-object v7, v4, Lou;->f:Ljava/lang/String;

    nop

    const/16 v2, 0x47

    invoke-virtual {v7}, Ljava/lang/String;->length()I

    move-result v7

    if-lez v7, :cond_20d

    array-length v5, v6

    if-eqz v5, :cond_203

    array-length v5, v6

    sub-int v5, v5, v18

    aget-object v5, v6, v5

    goto :goto_24b

    :cond_203
    const-string/jumbo v4, "Array is empty."

    const/16 v2, 0x4f9

    invoke-static {v4}, Lpw1;->m(Ljava/lang/String;)V

    const/4 v4, 0x0

    throw v4

    :cond_20d
    const/16 v2, 0x32

    iget v7, v4, Lou;->e:I

    nop

    array-length v8, v6

    sub-int v8, v8, v18

    if-ne v7, v8, :cond_244

    const/16 v2, 0xe1

    iget-object v7, v4, Lou;->f:Ljava/lang/String;

    nop

    const/16 v2, 0x47

    invoke-virtual {v7}, Ljava/lang/String;->length()I

    move-result v7

    if-nez v7, :cond_244

    const/16 v2, 0x91

    move/from16 v0, v19

    iput v0, v4, Lou;->e:I

    const/16 v2, 0x7a

    invoke-interface {v5}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v5

    const/16 v2, 0x32

    iget v7, v4, Lou;->e:I

    nop

    const/16 v2, 0x56

    move-object/from16 v0, v17

    invoke-interface {v5, v0, v7}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/16 v2, 0x6f

    invoke-interface {v5}, Landroid/content/SharedPreferences$Editor;->apply()V

    aget-object v5, v6, v19

    goto :goto_24b

    :cond_244
    const/16 v2, 0x32

    iget v5, v4, Lou;->e:I

    nop

    aget-object v5, v6, v5

    :goto_24b
    const/4 v2, -0x6

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v2, 0xdb

    iput-object v5, v4, Lou;->g:Ljava/lang/String;

    return-void

    :cond_254
    const-string/jumbo v8, "metodo"

    const/16 v2, 0xb0

    move/from16 v0, v19

    invoke-interface {v5, v8, v0}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v8

    const/16 v2, 0x495

    iput v8, v4, Lou;->m:I

    move/from16 v0, v18

    if-le v8, v0, :cond_26d

    const/16 v2, 0x495

    move/from16 v0, v19

    iput v0, v4, Lou;->m:I

    :cond_26d
    const-string/jumbo v8, "upayload"

    const/16 v2, 0x77

    move/from16 v0, v19

    invoke-interface {v5, v8, v0}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v8

    const/16 v2, 0x55e

    iput-boolean v8, v4, Lou;->n:Z

    const-string/jumbo v8, "payload"

    const/16 v2, 0x2e

    invoke-interface {v5, v8, v7}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    if-nez v8, :cond_288

    move-object v8, v7

    :cond_288
    const/16 v2, 0x3d4

    iput-object v8, v4, Lou;->o:Ljava/lang/String;

    const-string/jumbo v8, "usnihost"

    const/16 v2, 0x77

    move/from16 v0, v19

    invoke-interface {v5, v8, v0}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v8

    const/16 v2, 0x963

    iput-boolean v8, v4, Lou;->p:Z

    const-string/jumbo v8, "snihost"

    const/16 v2, 0x2e

    invoke-interface {v5, v8, v7}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    if-nez v8, :cond_2a7

    move-object v8, v7

    :cond_2a7
    const/16 v2, 0x47f

    iput-object v8, v4, Lou;->q:Ljava/lang/String;

    const-string/jumbo v8, "upayloadat"

    const/16 v2, 0x77

    move/from16 v0, v19

    invoke-interface {v5, v8, v0}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v8

    const/16 v2, 0xc55

    iput-boolean v8, v4, Lou;->r:Z

    const-string/jumbo v8, "payloadat"

    const/16 v2, 0x2e

    invoke-interface {v5, v8, v7}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    if-nez v8, :cond_2c6

    move-object v8, v7

    :cond_2c6
    const/16 v2, 0x360

    iput-object v8, v4, Lou;->s:Ljava/lang/String;

    const-string/jumbo v8, "uprx"

    const/16 v2, 0x77

    move/from16 v0, v19

    invoke-interface {v5, v8, v0}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v8

    const/16 v2, 0x104d

    iput-boolean v8, v4, Lou;->t:Z

    const-string/jumbo v8, "prxhost"

    const/16 v2, 0x2e

    invoke-interface {v5, v8, v7}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    if-nez v8, :cond_2e5

    move-object v8, v7

    :cond_2e5
    const/16 v2, 0x3c3

    iput-object v8, v4, Lou;->u:Ljava/lang/String;

    const-string/jumbo v8, "prxport"

    const/16 v2, 0x2e

    invoke-interface {v5, v8, v7}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    if-nez v8, :cond_2f5

    move-object v8, v7

    :cond_2f5
    const/16 v2, 0x335

    iput-object v8, v4, Lou;->v:Ljava/lang/String;

    const/16 v2, 0x2e

    invoke-interface {v5, v14, v7}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    if-nez v8, :cond_302

    move-object v8, v7

    :cond_302
    const/16 v2, 0x261

    iput-object v8, v4, Lou;->k:Ljava/lang/String;

    const/16 v2, 0x2e

    invoke-interface {v5, v13, v7}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    if-nez v8, :cond_30f

    move-object v8, v7

    :cond_30f
    const/16 v2, 0x266

    iput-object v8, v4, Lou;->l:Ljava/lang/String;

    const/16 v2, 0x77

    move/from16 v0, v19

    invoke-interface {v5, v15, v0}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v8

    const-string/jumbo v9, "sshport"

    const-string/jumbo v13, "sshhost"

    if-eqz v8, :cond_34a

    const/16 v2, 0x2e

    invoke-interface {v5, v13, v7}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    if-nez v8, :cond_32c

    move-object v8, v7

    :cond_32c
    const/16 v2, 0x47

    invoke-virtual {v8}, Ljava/lang/String;->length()I

    move-result v8

    if-lez v8, :cond_34a

    const/16 v2, 0x2e

    invoke-interface {v5, v9, v7}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    if-nez v8, :cond_33d

    move-object v8, v7

    :cond_33d
    const/16 v2, 0x47

    invoke-virtual {v8}, Ljava/lang/String;->length()I

    move-result v8

    if-lez v8, :cond_34a

    if-nez p3, :cond_34a

    move/from16 v8, v18

    goto :goto_34c

    :cond_34a
    move/from16 v8, v19

    :goto_34c
    const/16 v2, 0x3c8

    iput-boolean v8, v4, Lou;->h:Z

    const/16 v2, 0x77

    move/from16 v0, v19

    invoke-interface {v5, v12, v0}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v8

    const/16 v2, 0x49b

    iput-boolean v8, v4, Lou;->c:Z

    const/16 v2, 0xb0

    move-object/from16 v0, v16

    move/from16 v1, v19

    invoke-interface {v5, v0, v1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v8

    const/16 v2, 0x103

    iput v8, v4, Lou;->d:I

    const/16 v2, 0xb0

    move-object/from16 v0, v17

    move/from16 v1, v19

    invoke-interface {v5, v0, v1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v8

    const/16 v2, 0x91

    iput v8, v4, Lou;->e:I

    const/16 v2, 0xf1

    iget-boolean v8, v4, Lou;->c:Z

    nop

    if-eqz v8, :cond_380

    goto :goto_382

    :cond_380
    move/from16 v11, v19

    :goto_382
    const/16 v2, 0x4fe

    invoke-static {v5, v6, v11}, Lqk;->p(Landroid/content/SharedPreferences;Landroid/content/res/Resources;I)[Ljava/lang/String;

    move-result-object v8

    const/16 v2, 0x11f

    iget v11, v4, Lou;->d:I

    nop

    array-length v12, v8

    if-ge v11, v12, :cond_397

    const/16 v2, 0x9d

    iget-boolean v11, v4, Lou;->h:Z

    nop

    if-eqz v11, :cond_3b1

    :cond_397
    const/16 v2, 0x103

    move/from16 v0, v19

    iput v0, v4, Lou;->d:I

    const/16 v2, 0x7a

    invoke-interface {v5}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v11

    const/16 v2, 0x56

    move-object/from16 v0, v16

    move/from16 v1, v19

    invoke-interface {v11, v0, v1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/16 v2, 0x6f

    invoke-interface {v11}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_3b1
    const/16 v2, 0x9d

    iget-boolean v11, v4, Lou;->h:Z

    nop

    if-eqz v11, :cond_3c2

    const/16 v2, 0x2e

    invoke-interface {v5, v13, v7}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    if-nez v8, :cond_3c9

    move-object v8, v7

    goto :goto_3c9

    :cond_3c2
    const/16 v2, 0x11f

    iget v11, v4, Lou;->d:I

    nop

    aget-object v8, v8, v11

    :cond_3c9
    :goto_3c9
    const/16 v2, 0x244

    iput-object v8, v4, Lou;->i:Ljava/lang/String;

    const-string/jumbo v8, "cport"

    const/16 v2, 0x2e

    invoke-interface {v5, v8, v7}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    if-nez v8, :cond_3d9

    move-object v8, v7

    :cond_3d9
    const/16 v2, 0x39c

    iput-object v8, v4, Lou;->f:Ljava/lang/String;

    const/16 v2, 0x2e

    invoke-interface {v5, v9, v7}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    if-nez v8, :cond_3e6

    goto :goto_3e7

    :cond_3e6
    move-object v7, v8

    :goto_3e7
    const/16 v2, 0x4aa

    iput-object v7, v4, Lou;->j:Ljava/lang/String;

    const/16 v2, 0x3e2

    invoke-virtual {v6, v10}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v6

    const/4 v2, -0x6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v2, 0x32

    iget v7, v4, Lou;->e:I

    nop

    array-length v8, v6

    if-ge v7, v8, :cond_404

    const/16 v2, 0x9d

    iget-boolean v7, v4, Lou;->h:Z

    nop

    if-eqz v7, :cond_421

    :cond_404
    const/16 v2, 0x91

    move/from16 v0, v19

    iput v0, v4, Lou;->e:I

    const/16 v2, 0x7a

    invoke-interface {v5}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v7

    const/16 v2, 0x32

    iget v8, v4, Lou;->e:I

    nop

    const/16 v2, 0x56

    move-object/from16 v0, v17

    invoke-interface {v7, v0, v8}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/16 v2, 0x6f

    invoke-interface {v7}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_421
    const/16 v2, 0x9d

    iget-boolean v7, v4, Lou;->h:Z

    nop

    const-string/jumbo v8, "T "

    if-eqz v7, :cond_443

    const/4 v2, -0x3

    new-instance v5, Ljava/lang/StringBuilder;

    nop

    const/16 v2, 0x97

    invoke-direct {v5, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v2, 0x34b

    iget-object v6, v4, Lou;->j:Ljava/lang/String;

    nop

    const/4 v2, 0x0

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, -0x2

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    goto :goto_4b8

    :cond_443
    const/16 v2, 0x32

    iget v7, v4, Lou;->e:I

    nop

    array-length v9, v6

    sub-int v9, v9, v18

    if-ne v7, v9, :cond_472

    const/16 v2, 0xe1

    iget-object v7, v4, Lou;->f:Ljava/lang/String;

    nop

    const/16 v2, 0x47

    invoke-virtual {v7}, Ljava/lang/String;->length()I

    move-result v7

    if-lez v7, :cond_472

    const/4 v2, -0x3

    new-instance v5, Ljava/lang/StringBuilder;

    nop

    const/16 v2, 0x97

    invoke-direct {v5, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v2, 0xe1

    iget-object v6, v4, Lou;->f:Ljava/lang/String;

    nop

    const/4 v2, 0x0

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, -0x2

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    goto :goto_4b8

    :cond_472
    const/16 v2, 0x32

    iget v7, v4, Lou;->e:I

    nop

    array-length v8, v6

    sub-int v8, v8, v18

    if-ne v7, v8, :cond_4ad

    const/16 v2, 0xe1

    iget-object v7, v4, Lou;->f:Ljava/lang/String;

    nop

    const/16 v2, 0x47

    invoke-virtual {v7}, Ljava/lang/String;->length()I

    move-result v7

    if-nez v7, :cond_4ad

    const/16 v2, 0x91

    move/from16 v0, v19

    iput v0, v4, Lou;->e:I

    const/16 v2, 0x7a

    invoke-interface {v5}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v5

    const/16 v2, 0x32

    iget v7, v4, Lou;->e:I

    nop

    const/16 v2, 0x56

    move-object/from16 v0, v17

    invoke-interface {v5, v0, v7}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/16 v2, 0x6f

    invoke-interface {v5}, Landroid/content/SharedPreferences$Editor;->apply()V

    aget-object v5, v6, v19

    const/4 v2, -0x6

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    goto :goto_4b8

    :cond_4ad
    const/16 v2, 0x32

    iget v5, v4, Lou;->e:I

    nop

    aget-object v5, v6, v5

    const/4 v2, -0x6

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :goto_4b8
    const/16 v2, 0xdb

    iput-object v5, v4, Lou;->g:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final a()V
    .registers 14

    .prologue
    const/4 v9, 0x0

    const/4 v10, 0x0

    const/16 v0, 0x7c4

    iput-boolean v10, p0, Lou;->w:Z

    const/16 v0, 0x103

    iput v10, p0, Lou;->d:I

    const/16 v0, 0x91

    iput v10, p0, Lou;->e:I

    const/16 v0, 0x9d

    iget-boolean v11, p0, Lou;->h:Z

    nop

    const-string/jumbo v12, ""

    if-eqz v11, :cond_1c

    const/16 v0, 0x244

    iput-object v12, p0, Lou;->i:Ljava/lang/String;

    :cond_1c
    const/16 v0, 0x3c8

    iput-boolean v10, p0, Lou;->h:Z

    const/16 v0, 0x261

    iput-object v12, p0, Lou;->k:Ljava/lang/String;

    const/16 v0, 0x266

    iput-object v12, p0, Lou;->l:Ljava/lang/String;

    const/16 v0, 0xdb

    iput-object v12, p0, Lou;->g:Ljava/lang/String;

    const/16 v0, 0x55e

    iput-boolean v10, p0, Lou;->n:Z

    const/16 v0, 0x3d4

    iput-object v12, p0, Lou;->o:Ljava/lang/String;

    const/16 v0, 0x963

    iput-boolean v10, p0, Lou;->p:Z

    const/16 v0, 0x47f

    iput-object v12, p0, Lou;->q:Ljava/lang/String;

    const/16 v0, 0xc55

    iput-boolean v10, p0, Lou;->r:Z

    const/16 v0, 0x360

    iput-object v12, p0, Lou;->s:Ljava/lang/String;

    const/16 v0, 0x104d

    iput-boolean v10, p0, Lou;->t:Z

    const/16 v0, 0x3c3

    iput-object v12, p0, Lou;->u:Ljava/lang/String;

    const/16 v0, 0x335

    iput-object v12, p0, Lou;->v:Ljava/lang/String;

    return-void
.end method

.method public final b([B)Z
    .registers 13

    .prologue
    const-string/jumbo v2, "\n"

    const/4 v3, 0x0

    :try_start_4
    new-instance v4, Ljava/lang/String;

    const/16 v0, 0x3eb

    new-instance v5, Ltd;

    nop

    const/16 v6, 0xc

    const/16 v0, 0x484

    invoke-direct {v5, v6}, Ltd;-><init>(I)V

    const/16 v0, 0xd2d

    invoke-virtual {v5, p1}, Ltd;->q([B)[B

    move-result-object p1

    const/16 v0, 0x2e4

    sget-object v5, Lip;->a:Ljava/nio/charset/Charset;

    nop

    check-cast v5, Ljava/nio/charset/Charset;

    invoke-direct {v4, p1, v5}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const/4 p1, 0x1

    new-array v7, p1, [C

    const/16 v8, 0x3a

    aput-char v8, v7, v3

    const/16 v0, 0x31

    invoke-static {v4, v7}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v4

    const/16 v0, 0x17d

    invoke-interface {v4}, Ljava/util/List;->size()I

    move-result v7

    const/16 v8, 0x1c

    if-ge v7, v8, :cond_3b

    goto/16 :goto_371

    :cond_3b
    const/16 v0, 0x24

    invoke-interface {v4, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    const/16 v0, 0x8e

    invoke-static {v7}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v7

    const/16 v0, 0x825

    iput v7, p0, Lou;->b:I

    const/16 v0, 0x24

    invoke-interface {v4, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    const/16 v0, 0x8e

    invoke-static {v7}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v7

    const/16 v0, 0x103

    iput v7, p0, Lou;->d:I

    const/4 v7, 0x2

    const/16 v0, 0x24

    invoke-interface {v4, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    const/16 v0, 0x8e

    invoke-static {v9}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v9

    const/16 v0, 0x91

    iput v9, p0, Lou;->e:I

    const/4 v9, 0x3

    const/16 v0, 0x24

    invoke-interface {v4, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    const/16 v0, 0x74

    invoke-static {v9}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result v9

    const/16 v0, 0x3c8

    iput-boolean v9, p0, Lou;->h:Z

    const/16 v0, 0x905

    sget-boolean v9, Lmi2;->a:Z

    nop

    const/4 v9, 0x4

    const/16 v0, 0x24

    invoke-interface {v4, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    const/16 v0, 0x2c

    invoke-virtual {v9, v5}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v9

    const/4 v0, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x40

    invoke-static {v9, v7}, Landroid/util/Base64;->decode([BI)[B

    move-result-object v9

    const/4 v0, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v10, Ljava/lang/String;

    check-cast v5, Ljava/nio/charset/Charset;

    invoke-direct {v10, v9, v5}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const/16 v0, 0x261

    iput-object v10, p0, Lou;->k:Ljava/lang/String;

    const/4 v9, 0x5

    const/16 v0, 0x24

    invoke-interface {v4, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    const/16 v0, 0x2c

    invoke-virtual {v9, v5}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v9

    const/4 v0, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x40

    invoke-static {v9, v7}, Landroid/util/Base64;->decode([BI)[B

    move-result-object v9

    const/4 v0, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v10, Ljava/lang/String;

    check-cast v5, Ljava/nio/charset/Charset;

    invoke-direct {v10, v9, v5}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const/16 v0, 0x266

    iput-object v10, p0, Lou;->l:Ljava/lang/String;

    const/4 v9, 0x6

    const/16 v0, 0x24

    invoke-interface {v4, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    const/16 v0, 0x2c

    invoke-virtual {v9, v5}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v9

    const/4 v0, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x40

    invoke-static {v9, v7}, Landroid/util/Base64;->decode([BI)[B

    move-result-object v9

    const/4 v0, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v10, Ljava/lang/String;

    check-cast v5, Ljava/nio/charset/Charset;

    invoke-direct {v10, v9, v5}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const/16 v0, 0x244

    iput-object v10, p0, Lou;->i:Ljava/lang/String;

    const/4 v9, 0x7

    const/16 v0, 0x24

    invoke-interface {v4, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    const/16 v0, 0x2c

    invoke-virtual {v9, v5}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v9

    const/4 v0, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x40

    invoke-static {v9, v7}, Landroid/util/Base64;->decode([BI)[B

    move-result-object v9

    const/4 v0, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v10, Ljava/lang/String;

    check-cast v5, Ljava/nio/charset/Charset;

    invoke-direct {v10, v9, v5}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const/16 v0, 0xdb

    iput-object v10, p0, Lou;->g:Ljava/lang/String;

    const/16 v9, 0x8

    const/16 v0, 0x24

    invoke-interface {v4, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    const/16 v0, 0x2c

    invoke-virtual {v9, v5}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v9

    const/4 v0, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x40

    invoke-static {v9, v7}, Landroid/util/Base64;->decode([BI)[B

    move-result-object v9

    const/4 v0, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v10, Ljava/lang/String;

    check-cast v5, Ljava/nio/charset/Charset;

    invoke-direct {v10, v9, v5}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const/16 v0, 0x39c

    iput-object v10, p0, Lou;->f:Ljava/lang/String;

    const/16 v9, 0x9

    const/16 v0, 0x24

    invoke-interface {v4, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    const/16 v0, 0x2c

    invoke-virtual {v9, v5}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v9

    const/4 v0, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x40

    invoke-static {v9, v7}, Landroid/util/Base64;->decode([BI)[B

    move-result-object v9

    const/4 v0, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v10, Ljava/lang/String;

    check-cast v5, Ljava/nio/charset/Charset;

    invoke-direct {v10, v9, v5}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const/16 v0, 0x4aa

    iput-object v10, p0, Lou;->j:Ljava/lang/String;

    const/16 v9, 0xa

    const/16 v0, 0x24

    invoke-interface {v4, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    const/16 v0, 0x8e

    invoke-static {v9}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v9

    const/16 v0, 0x495

    iput v9, p0, Lou;->m:I

    if-gt v9, p1, :cond_361

    const/16 v9, 0xb

    const/16 v0, 0x24

    invoke-interface {v4, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    const/16 v0, 0x74

    invoke-static {v9}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result v9

    const/16 v0, 0x55e

    iput-boolean v9, p0, Lou;->n:Z

    const/16 v0, 0x24

    invoke-interface {v4, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const/16 v0, 0x2c

    invoke-virtual {v6, v5}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v6

    const/4 v0, -0x6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x40

    invoke-static {v6, v7}, Landroid/util/Base64;->decode([BI)[B

    move-result-object v6

    const/4 v0, -0x6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v9, Ljava/lang/String;

    check-cast v5, Ljava/nio/charset/Charset;

    invoke-direct {v9, v6, v5}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const/16 v0, 0x3d4

    iput-object v9, p0, Lou;->o:Ljava/lang/String;

    const/16 v6, 0xd

    const/16 v0, 0x24

    invoke-interface {v4, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const/16 v0, 0x74

    invoke-static {v6}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result v6

    const/16 v0, 0x963

    iput-boolean v6, p0, Lou;->p:Z

    const/16 v6, 0xe

    const/16 v0, 0x24

    invoke-interface {v4, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const/16 v0, 0x2c

    invoke-virtual {v6, v5}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v6

    const/4 v0, -0x6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x40

    invoke-static {v6, v7}, Landroid/util/Base64;->decode([BI)[B

    move-result-object v6

    const/4 v0, -0x6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v9, Ljava/lang/String;

    check-cast v5, Ljava/nio/charset/Charset;

    invoke-direct {v9, v6, v5}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const/16 v0, 0x47f

    iput-object v9, p0, Lou;->q:Ljava/lang/String;

    const/16 v6, 0xf

    const/16 v0, 0x24

    invoke-interface {v4, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const/16 v0, 0x74

    invoke-static {v6}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result v6

    const/16 v0, 0xc55

    iput-boolean v6, p0, Lou;->r:Z

    const/16 v6, 0x10

    const/16 v0, 0x24

    invoke-interface {v4, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const/16 v0, 0x2c

    invoke-virtual {v6, v5}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v6

    const/4 v0, -0x6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x40

    invoke-static {v6, v7}, Landroid/util/Base64;->decode([BI)[B

    move-result-object v6

    const/4 v0, -0x6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v9, Ljava/lang/String;

    check-cast v5, Ljava/nio/charset/Charset;

    invoke-direct {v9, v6, v5}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const/16 v0, 0x360

    iput-object v9, p0, Lou;->s:Ljava/lang/String;

    const/16 v6, 0x11

    const/16 v0, 0x24

    invoke-interface {v4, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const/16 v0, 0x74

    invoke-static {v6}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result v6

    const/16 v0, 0x104d

    iput-boolean v6, p0, Lou;->t:Z

    const/16 v6, 0x12

    const/16 v0, 0x24

    invoke-interface {v4, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const/16 v0, 0x2c

    invoke-virtual {v6, v5}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v6

    const/4 v0, -0x6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x40

    invoke-static {v6, v7}, Landroid/util/Base64;->decode([BI)[B

    move-result-object v6

    const/4 v0, -0x6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v9, Ljava/lang/String;

    check-cast v5, Ljava/nio/charset/Charset;

    invoke-direct {v9, v6, v5}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const/16 v0, 0x3c3

    iput-object v9, p0, Lou;->u:Ljava/lang/String;

    const/16 v6, 0x13

    const/16 v0, 0x24

    invoke-interface {v4, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const/16 v0, 0x2c

    invoke-virtual {v6, v5}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v6

    const/4 v0, -0x6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x40

    invoke-static {v6, v7}, Landroid/util/Base64;->decode([BI)[B

    move-result-object v6

    const/4 v0, -0x6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v9, Ljava/lang/String;

    check-cast v5, Ljava/nio/charset/Charset;

    invoke-direct {v9, v6, v5}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const/16 v0, 0x335

    iput-object v9, p0, Lou;->v:Ljava/lang/String;

    const/16 v6, 0x19

    const/16 v0, 0x24

    invoke-interface {v4, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const/16 v0, 0x74

    invoke-static {v6}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    const/4 v6, 0x0

    const/16 v0, 0x7c4

    iput-boolean v6, p0, Lou;->w:Z

    const/16 v6, 0x1a

    const/16 v0, 0x24

    invoke-interface {v4, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const/16 v0, 0x74

    invoke-static {v6}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result v6

    const/16 v0, 0xa25

    iput-boolean v6, p0, Lou;->x:Z

    const/16 v0, 0xf1c

    iget-boolean v6, p0, Lou;->a:Z

    nop

    if-nez v6, :cond_323

    const/16 v6, 0x1b

    const/16 v0, 0x24

    invoke-interface {v4, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const/16 v0, 0x2c

    invoke-virtual {v6, v5}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v6

    const/4 v0, -0x6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x40

    invoke-static {v6, v7}, Landroid/util/Base64;->decode([BI)[B

    move-result-object v6

    const/4 v0, -0x6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v7, Ljava/lang/String;

    check-cast v5, Ljava/nio/charset/Charset;

    invoke-direct {v7, v6, v5}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const-string/jumbo v5, "\\n"

    const/16 v0, 0x1a

    invoke-static {v7, v5, v2, v3}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v5

    const-string/jumbo v6, "\\r"

    const-string/jumbo v7, "\r"

    const/16 v0, 0x1a

    invoke-static {v5, v6, v7, v3}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v5

    const-string/jumbo v6, "<br/>"

    const/16 v0, 0x1a

    invoke-static {v5, v2, v6, v3}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v2

    const/16 v0, 0x962

    iput-object v2, p0, Lou;->B:Ljava/lang/String;
    :try_end_323
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_323} :catch_371

    :cond_323
    :try_start_323
    const/16 v0, 0x24

    invoke-interface {v4, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    const/16 v0, 0x74

    invoke-static {v2}, Ljava/lang/Boolean;->parseBoolean(Ljava/lang/String;)Z

    move-result v2
    :try_end_331
    .catch Ljava/lang/Exception; {:try_start_323 .. :try_end_331} :catch_332

    goto :goto_333

    :catch_332
    move v2, v3

    :goto_333
    :try_start_333
    const/4 v2, 0x0

    const/16 v0, 0xba7

    iput-boolean v2, p0, Lou;->y:Z

    const/16 v0, 0x9d

    iget-boolean v2, p0, Lou;->h:Z

    nop

    if-eqz v2, :cond_35b

    const/16 v0, 0x3b

    iget-object v2, p0, Lou;->i:Ljava/lang/String;

    nop

    const/16 v0, 0x47

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    if-lez v2, :cond_35b

    const/16 v0, 0x34a

    iget-object v2, p0, Lou;->g:Ljava/lang/String;

    nop

    const/16 v0, 0x47

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    if-lez v2, :cond_35b

    move v2, p1

    goto :goto_35c

    :cond_35b
    move v2, v3

    :goto_35c
    const/16 v0, 0x3c8

    iput-boolean v2, p0, Lou;->h:Z

    return p1

    :cond_361
    const/16 v0, 0x36a

    new-instance p0, Ljava/lang/Exception;

    nop

    const-string/jumbo p1, "DNSTT Discontinued"

    const/16 v0, 0x46d

    invoke-direct {p0, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    check-cast p0, Ljava/lang/Throwable;

    throw p0
    :try_end_371
    .catch Ljava/lang/Exception; {:try_start_333 .. :try_end_371} :catch_371

    :catch_371
    :goto_371
    return v3
.end method
