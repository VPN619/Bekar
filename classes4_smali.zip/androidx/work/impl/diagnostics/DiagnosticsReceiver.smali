.class public Landroidx/work/impl/diagnostics/DiagnosticsReceiver;
.super Landroid/content/BroadcastReceiver;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final a:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    const-string/jumbo v2, "DiagnosticsRcvr"

    nop

    nop

    const/16 v0, 0x5fb

    invoke-static {v2}, Lj41;->g(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    sput-object v2, Landroidx/work/impl/diagnostics/DiagnosticsReceiver;->a:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .registers 6

    .prologue
    if-nez p2, :cond_3

    return-void

    :cond_3
    const/16 v0, 0xf3

    invoke-static {}, Lj41;->e()Lj41;

    move-result-object p0

    const-string/jumbo p2, "Requesting diagnostics"

    nop

    nop

    const/16 v0, 0x112a

    sget-object v2, Landroidx/work/impl/diagnostics/DiagnosticsReceiver;->a:Ljava/lang/String;

    nop

    const/16 v0, 0x257

    invoke-virtual {p0, v2, p2}, Lj41;->a(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_18
    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x81b

    invoke-static {p1}, Lnq2;->b(Landroid/content/Context;)Lnq2;

    move-result-object p0

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-class p1, Landroidx/work/impl/workers/DiagnosticsWorker;

    const/16 v0, 0x3eb

    new-instance p2, Ltd;

    nop

    const/16 v0, 0x7f7

    invoke-direct {p2, p1}, Ltd;-><init>(Ljava/lang/Class;)V

    const/16 v0, 0xff4

    invoke-virtual {p2}, Ltd;->m()Lgi1;

    move-result-object p1

    const/16 v0, 0x1143

    invoke-virtual {p0, p1}, Lnq2;->a(Lgi1;)V
    :try_end_3d
    .catch Ljava/lang/IllegalStateException; {:try_start_18 .. :try_end_3d} :catch_3e

    return-void

    :catch_3e
    move-exception p0

    const/16 v0, 0xf3

    invoke-static {}, Lj41;->e()Lj41;

    move-result-object p1

    const-string/jumbo p2, "WorkManager is not initialized"

    nop

    nop

    const/16 v0, 0x585

    invoke-virtual {p1, v2, p2, p0}, Lj41;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
