.class public Landroidx/work/impl/background/systemjob/SystemJobService;
.super Landroid/app/job/JobService;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lwb0;


# static fields
.field public static final e:Ljava/lang/String;


# instance fields
.field public a:Lnq2;

.field public final b:Ljava/util/HashMap;

.field public final c:Lv00;

.field public d:Lfm0;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    const-string/jumbo v2, "SystemJobService"

    nop

    nop

    const/16 v0, 0x5fb

    invoke-static {v2}, Lj41;->g(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    sput-object v2, Landroidx/work/impl/background/systemjob/SystemJobService;->e:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .registers 5

    invoke-direct {p0}, Landroid/app/job/JobService;-><init>()V

    const/16 v0, 0x8b3

    new-instance v2, Ljava/util/HashMap;

    nop

    const/16 v0, 0xf9f

    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    const/16 v0, 0xe7a

    iput-object v2, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->b:Ljava/util/HashMap;

    const/16 v0, 0x114a

    new-instance v2, Lv00;

    nop

    const/4 v3, 0x5

    const/16 v0, 0x85d

    invoke-direct {v2, v3}, Lv00;-><init>(I)V

    const/16 v0, 0x760

    iput-object v2, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->c:Lv00;

    return-void
.end method

.method public static a(Ljava/lang/String;)V
    .registers 5

    .prologue
    const/16 v0, 0x1210

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    const/16 v0, 0xc7a

    invoke-virtual {v2}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    move-result-object v2

    const/16 v0, 0x10d3

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v3

    if-ne v2, v3, :cond_15

    return-void

    :cond_15
    const-string/jumbo v2, "Cannot invoke "

    nop

    nop

    const-string/jumbo v3, " on a background thread"

    nop

    nop

    const/16 v0, 0x6ac

    invoke-static {v2, p0, v3}, Lrt2;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x13

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-void
.end method

.method public static c(Landroid/app/job/JobParameters;)Llq2;
    .registers 6

    .prologue
    const-string/jumbo v2, "EXTRA_WORK_SPEC_ID"

    nop

    nop

    :try_start_5
    const/16 v0, 0x176

    invoke-virtual {p0}, Landroid/app/job/JobParameters;->getExtras()Landroid/os/PersistableBundle;

    move-result-object p0

    if-eqz p0, :cond_33

    const/16 v0, 0x9c

    invoke-virtual {p0, v2}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_33

    const/16 v0, 0x6e0

    new-instance v3, Llq2;

    nop

    const/16 v0, 0x183

    invoke-virtual {p0, v2}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string/jumbo v4, "EXTRA_WORK_SPEC_GENERATION"

    nop

    nop

    const/16 v0, 0x233

    invoke-virtual {p0, v4}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result p0

    const/16 v0, 0x8b2

    invoke-direct {v3, v2, p0}, Llq2;-><init>(Ljava/lang/String;I)V
    :try_end_30
    .catch Ljava/lang/NullPointerException; {:try_start_5 .. :try_end_30} :catch_33

    check-cast v3, Llq2;

    return-object v3

    :catch_33
    :cond_33
    const/4 p0, 0x0

    return-object p0
.end method


# virtual methods
.method public final b(Llq2;Z)V
    .registers 8

    .prologue
    const-string/jumbo v2, "onExecuted"

    nop

    nop

    const/16 v0, 0xb9d

    invoke-static {v2}, Landroidx/work/impl/background/systemjob/SystemJobService;->a(Ljava/lang/String;)V

    const/16 v0, 0xf3

    invoke-static {}, Lj41;->e()Lj41;

    move-result-object v2

    const/4 v0, -0x3

    new-instance v3, Ljava/lang/StringBuilder;

    nop

    const/4 v0, -0x4

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v0, 0xb4e

    iget-object v4, p1, Llq2;->a:Ljava/lang/String;

    nop

    const/4 v0, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v4, " executed on JobScheduler"

    nop

    nop

    const/4 v0, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/16 v0, 0x23c

    sget-object v4, Landroidx/work/impl/background/systemjob/SystemJobService;->e:Ljava/lang/String;

    nop

    const/16 v0, 0x257

    invoke-virtual {v2, v4, v3}, Lj41;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v0, 0x11b4

    iget-object v2, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->b:Ljava/util/HashMap;

    nop

    const/16 v0, 0x1072

    invoke-virtual {v2, p1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/app/job/JobParameters;

    const/16 v0, 0x10b7

    iget-object v3, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->c:Lv00;

    nop

    const/16 v0, 0x1001

    invoke-virtual {v3, p1}, Lv00;->f(Llq2;)Lb62;

    if-eqz v2, :cond_57

    const/16 v0, 0xc5e

    invoke-virtual {p0, v2, p2}, Landroid/app/job/JobService;->jobFinished(Landroid/app/job/JobParameters;Z)V

    :cond_57
    return-void
.end method

.method public final onCreate()V
    .registers 6

    .prologue
    const/16 v0, 0x1095

    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    :try_start_5
    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const/16 v0, 0x81b

    invoke-static {v2}, Lnq2;->b(Landroid/content/Context;)Lnq2;

    move-result-object v2

    const/16 v0, 0x8b0

    iput-object v2, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->a:Lnq2;

    const/16 v0, 0x625

    iget-object v3, v2, Lnq2;->f:Lsn1;

    nop

    const/16 v0, 0x11ed

    new-instance v4, Lfm0;

    nop

    const/16 v0, 0xdda

    iget-object v2, v2, Lnq2;->d:Lx5;

    nop

    const/16 v0, 0x7c1

    invoke-direct {v4, v3, v2}, Lfm0;-><init>(Lsn1;Lx5;)V

    const/16 v0, 0x938

    iput-object v4, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->d:Lfm0;

    const/16 v0, 0x5af

    invoke-virtual {v3, p0}, Lsn1;->a(Lwb0;)V
    :try_end_32
    .catch Ljava/lang/IllegalStateException; {:try_start_5 .. :try_end_32} :catch_33

    return-void

    :catch_33
    move-exception v2

    const/16 v0, 0x762

    invoke-virtual {p0}, Landroid/app/Service;->getApplication()Landroid/app/Application;

    move-result-object p0

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    const-class v3, Landroid/app/Application;

    const/16 v0, 0x128

    invoke-virtual {v3, p0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_5f

    const/16 v0, 0xf3

    invoke-static {}, Lj41;->e()Lj41;

    move-result-object p0

    const/16 v0, 0x23c

    sget-object v2, Landroidx/work/impl/background/systemjob/SystemJobService;->e:Ljava/lang/String;

    nop

    const-string/jumbo v3, "Could not find WorkManager instance; this may be because an auto-backup is in progress. Ignoring JobScheduler commands for now. Please make sure that you are initializing WorkManager if you have manually disabled WorkManagerInitializer."

    nop

    nop

    const/16 v0, 0x10a6

    invoke-virtual {p0, v2, v3}, Lj41;->h(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_5f
    const-string/jumbo p0, "WorkManager needs to be initialized via a ContentProvider#onCreate() or an Application#onCreate()."

    nop

    nop

    const/16 v0, 0x11c8

    invoke-static {p0, v2}, Lvx2;->u(Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method

.method public final onDestroy()V
    .registers 5

    .prologue
    const/16 v0, 0xc0a

    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    const/16 v0, 0x354

    iget-object v2, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->a:Lnq2;

    nop

    if-eqz v2, :cond_26

    const/16 v0, 0x625

    iget-object v2, v2, Lnq2;->f:Lsn1;

    nop

    const/16 v0, 0x1206

    iget-object v3, v2, Lsn1;->k:Ljava/lang/Object;

    nop

    monitor-enter v3

    :try_start_17
    const/16 v0, 0xce8

    iget-object v2, v2, Lsn1;->j:Ljava/util/ArrayList;

    nop

    const/16 v0, 0xef7

    invoke-virtual {v2, p0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    monitor-exit v3

    return-void

    :catchall_23
    move-exception p0

    monitor-exit v3
    :try_end_25
    .catchall {:try_start_17 .. :try_end_25} :catchall_23

    throw p0

    :cond_26
    return-void
.end method

.method public final onStartJob(Landroid/app/job/JobParameters;)Z
    .registers 11

    .prologue
    const-string/jumbo v2, "onStartJob"

    nop

    nop

    const/16 v0, 0xb9d

    invoke-static {v2}, Landroidx/work/impl/background/systemjob/SystemJobService;->a(Ljava/lang/String;)V

    const/16 v0, 0x354

    iget-object v2, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->a:Lnq2;

    nop

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/16 v0, 0x23c

    sget-object v5, Landroidx/work/impl/background/systemjob/SystemJobService;->e:Ljava/lang/String;

    nop

    if-nez v2, :cond_2e

    const/16 v0, 0xf3

    invoke-static {}, Lj41;->e()Lj41;

    move-result-object v2

    const-string/jumbo v6, "WorkManager is not initialized; requesting retry."

    nop

    nop

    const/16 v0, 0x257

    invoke-virtual {v2, v5, v6}, Lj41;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v0, 0xc5e

    invoke-virtual {p0, p1, v3}, Landroid/app/job/JobService;->jobFinished(Landroid/app/job/JobParameters;Z)V

    return v4

    :cond_2e
    const/16 v0, 0xb85

    invoke-static {p1}, Landroidx/work/impl/background/systemjob/SystemJobService;->c(Landroid/app/job/JobParameters;)Llq2;

    move-result-object v2

    if-nez v2, :cond_47

    const/16 v0, 0xf3

    invoke-static {}, Lj41;->e()Lj41;

    move-result-object p0

    const-string/jumbo p1, "WorkSpec id not found!"

    nop

    nop

    const/16 v0, 0x77b

    invoke-virtual {p0, v5, p1}, Lj41;->c(Ljava/lang/String;Ljava/lang/String;)V

    return v4

    :cond_47
    const/16 v0, 0x11b4

    iget-object v6, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->b:Ljava/util/HashMap;

    nop

    const/16 v0, 0x1127

    invoke-virtual {v6, v2}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_78

    const/16 v0, 0xf3

    invoke-static {}, Lj41;->e()Lj41;

    move-result-object p0

    const/4 v0, -0x3

    new-instance p1, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v3, "Job is already being executed by SystemJobService: "

    nop

    nop

    const/16 v0, 0x97

    invoke-direct {p1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x190

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0x257

    invoke-virtual {p0, v5, p1}, Lj41;->a(Ljava/lang/String;Ljava/lang/String;)V

    return v4

    :cond_78
    const/16 v0, 0xf3

    invoke-static {}, Lj41;->e()Lj41;

    move-result-object v4

    const/4 v0, -0x3

    new-instance v7, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v8, "onStartJob for "

    nop

    nop

    const/16 v0, 0x97

    invoke-direct {v7, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x190

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const/16 v0, 0x257

    invoke-virtual {v4, v5, v7}, Lj41;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v0, 0x9c7

    invoke-virtual {v6, v2, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v0, 0x11ed

    new-instance v4, Lfm0;

    nop

    const/16 v5, 0x15

    const/16 v0, 0xaa5

    invoke-direct {v4, v5}, Lfm0;-><init>(I)V

    const/16 v0, 0x3ba

    invoke-virtual {p1}, Landroid/app/job/JobParameters;->getTriggeredContentUris()[Landroid/net/Uri;

    move-result-object v5

    if-eqz v5, :cond_c4

    const/16 v0, 0x3ba

    invoke-virtual {p1}, Landroid/app/job/JobParameters;->getTriggeredContentUris()[Landroid/net/Uri;

    move-result-object v5

    const/16 v0, 0x473

    invoke-static {v5}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    const/16 v0, 0x7ce

    iput-object v5, v4, Lfm0;->c:Ljava/lang/Object;

    :cond_c4
    const/16 v0, 0x411

    invoke-virtual {p1}, Landroid/app/job/JobParameters;->getTriggeredContentAuthorities()[Ljava/lang/String;

    move-result-object v5

    if-eqz v5, :cond_dc

    const/16 v0, 0x411

    invoke-virtual {p1}, Landroid/app/job/JobParameters;->getTriggeredContentAuthorities()[Ljava/lang/String;

    move-result-object v5

    const/16 v0, 0x473

    invoke-static {v5}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v5

    const/16 v0, 0xc7c

    iput-object v5, v4, Lfm0;->b:Ljava/lang/Object;

    :cond_dc
    const/16 v0, 0x1fc

    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 v6, 0x1c

    if-lt v5, v6, :cond_ea

    const/16 v0, 0xd84

    invoke-static {p1}, Lea;->i(Landroid/app/job/JobParameters;)V

    :cond_ea
    const/16 v0, 0x9bc

    iget-object p1, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->d:Lfm0;

    nop

    const/16 v0, 0x10b7

    iget-object p0, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->c:Lv00;

    nop

    const/16 v0, 0x120c

    invoke-virtual {p0, v2}, Lv00;->h(Llq2;)Lb62;

    move-result-object p0

    const/16 v0, 0xd82

    invoke-virtual {p1, p0, v4}, Lfm0;->v(Lb62;Lfm0;)V

    return v3
.end method

.method public final onStopJob(Landroid/app/job/JobParameters;)Z
    .registers 10

    .prologue
    const-string/jumbo v2, "onStopJob"

    nop

    nop

    const/16 v0, 0xb9d

    invoke-static {v2}, Landroidx/work/impl/background/systemjob/SystemJobService;->a(Ljava/lang/String;)V

    const/16 v0, 0x354

    iget-object v2, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->a:Lnq2;

    nop

    const/4 v3, 0x1

    if-nez v2, :cond_28

    const/16 v0, 0xf3

    invoke-static {}, Lj41;->e()Lj41;

    move-result-object p0

    const/16 v0, 0x23c

    sget-object p1, Landroidx/work/impl/background/systemjob/SystemJobService;->e:Ljava/lang/String;

    nop

    const-string/jumbo v2, "WorkManager is not initialized; requesting retry."

    nop

    nop

    const/16 v0, 0x257

    invoke-virtual {p0, p1, v2}, Lj41;->a(Ljava/lang/String;Ljava/lang/String;)V

    return v3

    :cond_28
    const/16 v0, 0xb85

    invoke-static {p1}, Landroidx/work/impl/background/systemjob/SystemJobService;->c(Landroid/app/job/JobParameters;)Llq2;

    move-result-object v2

    if-nez v2, :cond_47

    const/16 v0, 0xf3

    invoke-static {}, Lj41;->e()Lj41;

    move-result-object p0

    const/16 v0, 0x23c

    sget-object p1, Landroidx/work/impl/background/systemjob/SystemJobService;->e:Ljava/lang/String;

    nop

    const-string/jumbo v2, "WorkSpec id not found!"

    nop

    nop

    const/16 v0, 0x77b

    invoke-virtual {p0, p1, v2}, Lj41;->c(Ljava/lang/String;Ljava/lang/String;)V

    const/4 p0, 0x0

    return p0

    :cond_47
    const/16 v0, 0xf3

    invoke-static {}, Lj41;->e()Lj41;

    move-result-object v4

    const/16 v0, 0x23c

    sget-object v5, Landroidx/work/impl/background/systemjob/SystemJobService;->e:Ljava/lang/String;

    nop

    const/4 v0, -0x3

    new-instance v6, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v7, "onStopJob for "

    nop

    nop

    const/16 v0, 0x97

    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x190

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const/16 v0, 0x257

    invoke-virtual {v4, v5, v6}, Lj41;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v0, 0x11b4

    iget-object v4, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->b:Ljava/util/HashMap;

    nop

    const/16 v0, 0x1072

    invoke-virtual {v4, v2}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v0, 0x10b7

    iget-object v4, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->c:Lv00;

    nop

    const/16 v0, 0x1001

    invoke-virtual {v4, v2}, Lv00;->f(Llq2;)Lb62;

    move-result-object v4

    if-eqz v4, :cond_a6

    const/16 v0, 0x1fc

    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 v6, 0x1f

    if-lt v5, v6, :cond_96

    const/16 v0, 0x9ef

    invoke-static {p1}, Ljf1;->b(Landroid/app/job/JobParameters;)I

    move-result p1

    goto :goto_98

    :cond_96
    const/16 p1, -0x200

    :goto_98
    const/16 v0, 0x9bc

    iget-object v5, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->d:Lfm0;

    nop

    const/4 v0, -0x6

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xd97

    invoke-virtual {v5, v4, p1}, Lfm0;->w(Lb62;I)V

    :cond_a6
    const/16 v0, 0x354

    iget-object p0, p0, Landroidx/work/impl/background/systemjob/SystemJobService;->a:Lnq2;

    nop

    const/16 v0, 0x625

    iget-object p0, p0, Lnq2;->f:Lsn1;

    nop

    const/16 v0, 0xb4e

    iget-object p1, v2, Llq2;->a:Ljava/lang/String;

    nop

    const/16 v0, 0x1206

    iget-object v2, p0, Lsn1;->k:Ljava/lang/Object;

    nop

    monitor-enter v2

    :try_start_bb
    const/16 v0, 0x100d

    iget-object p0, p0, Lsn1;->i:Ljava/util/HashSet;

    nop

    const/16 v0, 0x1241

    invoke-virtual {p0, p1}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result p0

    monitor-exit v2

    xor-int/2addr p0, v3

    return p0

    :catchall_c9
    move-exception p0

    monitor-exit v2
    :try_end_cb
    .catchall {:try_start_bb .. :try_end_cb} :catchall_c9

    throw p0
.end method
