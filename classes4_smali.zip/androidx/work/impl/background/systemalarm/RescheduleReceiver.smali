.class public Landroidx/work/impl/background/systemalarm/RescheduleReceiver;
.super Landroid/content/BroadcastReceiver;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final a:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    const-string/jumbo v2, "RescheduleReceiver"

    nop

    nop

    const/16 v0, 0x5fb

    invoke-static {v2}, Lj41;->g(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    sput-object v2, Landroidx/work/impl/background/systemalarm/RescheduleReceiver;->a:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .registers 9

    .prologue
    const/16 v0, 0xf3

    invoke-static {}, Lj41;->e()Lj41;

    move-result-object v2

    const/16 v0, 0x443

    sget-object v3, Landroidx/work/impl/background/systemalarm/RescheduleReceiver;->a:Ljava/lang/String;

    nop

    const/4 v0, -0x3

    new-instance v4, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v5, "Received intent "

    nop

    nop

    const/16 v0, 0x97

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x190

    invoke-virtual {v4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/16 v0, 0x257

    invoke-virtual {v2, v3, p2}, Lj41;->a(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_28
    const/16 v0, 0x81b

    invoke-static {p1}, Lnq2;->b(Landroid/content/Context;)Lnq2;

    move-result-object p1

    const/16 v0, 0x576

    invoke-virtual {p0}, Landroid/content/BroadcastReceiver;->goAsync()Landroid/content/BroadcastReceiver$PendingResult;

    move-result-object p0

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x5e7

    sget-object p2, Lnq2;->m:Ljava/lang/Object;

    nop

    monitor-enter p2
    :try_end_3e
    .catch Ljava/lang/IllegalStateException; {:try_start_28 .. :try_end_3e} :catch_66

    :try_start_3e
    const/16 v0, 0x92c

    iget-object v2, p1, Lnq2;->i:Landroid/content/BroadcastReceiver$PendingResult;

    nop

    if-eqz v2, :cond_4d

    const/16 v0, 0x507

    invoke-virtual {v2}, Landroid/content/BroadcastReceiver$PendingResult;->finish()V

    goto :goto_4d

    :catchall_4b
    move-exception p0

    goto :goto_64

    :cond_4d
    :goto_4d
    const/16 v0, 0x478

    iput-object p0, p1, Lnq2;->i:Landroid/content/BroadcastReceiver$PendingResult;

    const/16 v0, 0xe4c

    iget-boolean v2, p1, Lnq2;->h:Z

    nop

    if-eqz v2, :cond_62

    const/16 v0, 0x507

    invoke-virtual {p0}, Landroid/content/BroadcastReceiver$PendingResult;->finish()V

    const/4 p0, 0x0

    const/16 v0, 0x478

    iput-object p0, p1, Lnq2;->i:Landroid/content/BroadcastReceiver$PendingResult;

    :cond_62
    monitor-exit p2

    return-void

    :goto_64
    monitor-exit p2
    :try_end_65
    .catchall {:try_start_3e .. :try_end_65} :catchall_4b

    :try_start_65
    throw p0
    :try_end_66
    .catch Ljava/lang/IllegalStateException; {:try_start_65 .. :try_end_66} :catch_66

    :catch_66
    move-exception p0

    const/16 v0, 0xf3

    invoke-static {}, Lj41;->e()Lj41;

    move-result-object p1

    const/16 v0, 0x443

    sget-object p2, Landroidx/work/impl/background/systemalarm/RescheduleReceiver;->a:Ljava/lang/String;

    nop

    const-string/jumbo v2, "Cannot reschedule jobs. WorkManager needs to be initialized via a ContentProvider#onCreate() or an Application#onCreate()."

    nop

    nop

    const/16 v0, 0x585

    invoke-virtual {p1, p2, v2, p0}, Lj41;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method
