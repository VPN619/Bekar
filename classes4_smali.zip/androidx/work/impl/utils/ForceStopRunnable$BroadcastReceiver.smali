.class public Landroidx/work/impl/utils/ForceStopRunnable$BroadcastReceiver;
.super Landroid/content/BroadcastReceiver;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final a:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    const-string/jumbo v2, "ForceStopRunnable$Rcvr"

    nop

    nop

    const/16 v0, 0x5fb

    invoke-static {v2}, Lj41;->g(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    sput-object v2, Landroidx/work/impl/utils/ForceStopRunnable$BroadcastReceiver;->a:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .registers 5

    .prologue
    if-eqz p2, :cond_32

    const/16 v0, 0x2f

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p0

    const-string/jumbo p2, "ACTION_FORCE_STOP_RESCHEDULE"

    nop

    nop

    const/4 v0, -0x7

    invoke-virtual {p2, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_32

    const/16 v0, 0xf3

    invoke-static {}, Lj41;->e()Lj41;

    move-result-object p0

    const/16 v0, 0x1110

    iget p0, p0, Lj41;->a:I

    nop

    const/4 p2, 0x2

    if-gt p0, p2, :cond_2d

    const/16 v0, 0xce6

    sget-object p0, Landroidx/work/impl/utils/ForceStopRunnable$BroadcastReceiver;->a:Ljava/lang/String;

    nop

    const-string/jumbo p2, "Rescheduling alarm that keeps track of force-stops."

    nop

    nop

    nop

    :cond_2d
    const/16 v0, 0xc83

    invoke-static {p1}, Lyg0;->c(Landroid/content/Context;)V

    :cond_32
    return-void
.end method
