.class public Landroidx/work/impl/foreground/SystemForegroundService;
.super Landroid/app/Service;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lh11;


# static fields
.field public static final e:Ljava/lang/String;


# instance fields
.field public final a:Lpy1;

.field public b:Z

.field public c:Ld92;

.field public d:Landroid/app/NotificationManager;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    const-string/jumbo v2, "SystemFgService"

    nop

    nop

    const/16 v0, 0x5fb

    invoke-static {v2}, Lj41;->g(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    sput-object v2, Landroidx/work/impl/foreground/SystemForegroundService;->e:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .registers 4

    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    const/16 v0, 0x8b6

    new-instance v2, Lpy1;

    nop

    const/16 v0, 0xe3b

    invoke-direct {v2, p0}, Lpy1;-><init>(Landroidx/work/impl/foreground/SystemForegroundService;)V

    const/16 v0, 0xf3c

    iput-object v2, p0, Landroidx/work/impl/foreground/SystemForegroundService;->a:Lpy1;

    return-void
.end method


# virtual methods
.method public final a()V
    .registers 5

    .prologue
    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const-string/jumbo v3, "notification"

    nop

    nop

    const/16 v0, 0x31d

    invoke-virtual {v2, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/app/NotificationManager;

    const/16 v0, 0x1125

    iput-object v2, p0, Landroidx/work/impl/foreground/SystemForegroundService;->d:Landroid/app/NotificationManager;

    const/16 v0, 0x6f0

    new-instance v2, Ld92;

    nop

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    const/16 v0, 0xad7

    invoke-direct {v2, v3}, Ld92;-><init>(Landroid/content/Context;)V

    const/16 v0, 0x548

    iput-object v2, p0, Landroidx/work/impl/foreground/SystemForegroundService;->c:Ld92;

    const/16 v0, 0x928

    iget-object v3, v2, Ld92;->i:Landroidx/work/impl/foreground/SystemForegroundService;

    nop

    if-eqz v3, :cond_48

    const/16 v0, 0xf3

    invoke-static {}, Lj41;->e()Lj41;

    move-result-object p0

    const/16 v0, 0x1038

    sget-object v2, Ld92;->j:Ljava/lang/String;

    nop

    const-string/jumbo v3, "A callback already exists."

    nop

    nop

    const/16 v0, 0x77b

    invoke-virtual {p0, v2, v3}, Lj41;->c(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_48
    const/16 v0, 0x7bb

    iput-object p0, v2, Ld92;->i:Landroidx/work/impl/foreground/SystemForegroundService;

    return-void
.end method

.method public final b()V
    .registers 5

    const/16 v0, 0xf44

    iget-object v2, p0, Landroidx/work/impl/foreground/SystemForegroundService;->a:Lpy1;

    nop

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x561

    sget-object v3, Ly01;->ON_CREATE:Ly01;

    nop

    const/16 v0, 0x515

    invoke-virtual {v2, v3}, Lpy1;->g(Ly01;)V

    const/16 v0, 0x1095

    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    return-void
.end method

.method public final c()V
    .registers 5

    const/16 v0, 0xf44

    iget-object v2, p0, Landroidx/work/impl/foreground/SystemForegroundService;->a:Lpy1;

    nop

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xf7c

    sget-object v3, Ly01;->ON_STOP:Ly01;

    nop

    const/16 v0, 0x515

    invoke-virtual {v2, v3}, Lpy1;->g(Ly01;)V

    const/16 v0, 0x122f

    sget-object v3, Ly01;->ON_DESTROY:Ly01;

    nop

    const/16 v0, 0x515

    invoke-virtual {v2, v3}, Lpy1;->g(Ly01;)V

    const/16 v0, 0xc0a

    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    return-void
.end method

.method public final getLifecycle()La11;
    .registers 3

    const/4 v1, 0x0

    const/16 v0, 0xf44

    iget-object p0, p0, Landroidx/work/impl/foreground/SystemForegroundService;->a:Lpy1;

    nop

    const/16 v0, 0x7f2

    iget-object p0, p0, Lpy1;->b:Ljava/lang/Object;

    nop

    check-cast p0, Lk11;

    return-object p0
.end method

.method public final onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .registers 4

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xf44

    iget-object p0, p0, Landroidx/work/impl/foreground/SystemForegroundService;->a:Lpy1;

    nop

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x877

    sget-object p1, Ly01;->ON_START:Ly01;

    nop

    const/16 v0, 0x515

    invoke-virtual {p0, p1}, Lpy1;->g(Ly01;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public final onCreate()V
    .registers 3

    const/16 v0, 0x8e5

    invoke-virtual {p0}, Landroidx/work/impl/foreground/SystemForegroundService;->b()V

    const/16 v0, 0x9d5

    invoke-virtual {p0}, Landroidx/work/impl/foreground/SystemForegroundService;->a()V

    return-void
.end method

.method public final onDestroy()V
    .registers 3

    const/16 v0, 0xdb9

    invoke-virtual {p0}, Landroidx/work/impl/foreground/SystemForegroundService;->c()V

    const/16 v0, 0x294

    iget-object p0, p0, Landroidx/work/impl/foreground/SystemForegroundService;->c:Ld92;

    nop

    const/16 v0, 0x859

    invoke-virtual {p0}, Ld92;->e()V

    return-void
.end method

.method public final onStart(Landroid/content/Intent;I)V
    .registers 7

    const/16 v0, 0xf44

    iget-object v2, p0, Landroidx/work/impl/foreground/SystemForegroundService;->a:Lpy1;

    nop

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x877

    sget-object v3, Ly01;->ON_START:Ly01;

    nop

    const/16 v0, 0x515

    invoke-virtual {v2, v3}, Lpy1;->g(Ly01;)V

    const/16 v0, 0xc99

    invoke-super {p0, p1, p2}, Landroid/app/Service;->onStart(Landroid/content/Intent;I)V

    return-void
.end method

.method public final onStartCommand(Landroid/content/Intent;II)I
    .registers 17

    .prologue
    const/16 v6, 0xc80

    move/from16 v0, p3

    invoke-super {p0, p1, p2, v0}, Landroid/app/Service;->onStartCommand(Landroid/content/Intent;II)I

    const/16 v6, 0xe3c

    iget-boolean p2, p0, Landroidx/work/impl/foreground/SystemForegroundService;->b:Z

    nop

    const/4 v8, 0x0

    const/16 v6, 0xb8f

    sget-object v9, Landroidx/work/impl/foreground/SystemForegroundService;->e:Ljava/lang/String;

    nop

    if-eqz p2, :cond_37

    const/16 v6, 0xf3

    invoke-static {}, Lj41;->e()Lj41;

    move-result-object p2

    const-string/jumbo v10, "Re-initializing SystemForegroundService after a request to shut-down."

    nop

    nop

    const/16 v6, 0x15d

    invoke-virtual {p2, v9, v10}, Lj41;->f(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v6, 0x294

    iget-object p2, p0, Landroidx/work/impl/foreground/SystemForegroundService;->c:Ld92;

    nop

    const/16 v6, 0x859

    invoke-virtual {p2}, Ld92;->e()V

    const/16 v6, 0x9d5

    invoke-virtual {p0}, Landroidx/work/impl/foreground/SystemForegroundService;->a()V

    const/16 v6, 0x2be

    iput-boolean v8, p0, Landroidx/work/impl/foreground/SystemForegroundService;->b:Z

    :cond_37
    if-eqz p1, :cond_1a6

    const/16 v6, 0x294

    iget-object p0, p0, Landroidx/work/impl/foreground/SystemForegroundService;->c:Ld92;

    nop

    const/4 v6, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x1038

    sget-object p2, Ld92;->j:Ljava/lang/String;

    nop

    const/16 v6, 0x2f

    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v10

    const-string/jumbo v11, "ACTION_START_FOREGROUND"

    nop

    nop

    const/4 v6, -0x7

    invoke-virtual {v11, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    const-string/jumbo v12, "KEY_WORKSPEC_ID"

    nop

    nop

    if-eqz v11, :cond_b7

    const/16 v6, 0xf3

    invoke-static {}, Lj41;->e()Lj41;

    move-result-object p3

    const/4 v6, -0x3

    new-instance v9, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v10, "Started foreground service "

    nop

    nop

    const/16 v6, 0x97

    invoke-direct {v9, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v6, 0x190

    invoke-virtual {v9, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, -0x2

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    const/16 v6, 0x15d

    move-object/from16 v0, p3

    invoke-virtual {v0, p2, v9}, Lj41;->f(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v6, 0x8d

    invoke-virtual {p1, v12}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/16 v6, 0xddc

    iget-object v6, p0, Ld92;->b:Lx5;

    move-object/16 p3, v6

    const/16 v6, 0x248

    new-instance v9, Lcl0;

    nop

    const/16 v10, 0xf

    const/16 v6, 0x6f6

    move v0, v6

    move-object v1, v9

    move-object v2, p0

    move-object v3, p2

    move v4, v10

    move v5, v8

    invoke-direct/range {v1 .. v5}, Lcl0;-><init>(Ljava/lang/Object;Ljava/lang/Object;IZ)V

    const/16 v6, 0x3a9

    move-object/from16 v0, p3

    iget-object p2, v0, Lx5;->c:Ljava/lang/Object;

    nop

    check-cast p2, Lcb;

    const/16 v6, 0x7fd

    invoke-virtual {p2, v9}, Lcb;->execute(Ljava/lang/Runnable;)V

    const/16 v6, 0x3da

    invoke-virtual {p0, p1}, Ld92;->d(Landroid/content/Intent;)V

    goto/16 :goto_1a6

    :cond_b7
    const-string/jumbo v8, "ACTION_NOTIFY"

    nop

    nop

    const/4 v6, -0x7

    invoke-virtual {v8, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_ca

    const/16 v6, 0x3da

    invoke-virtual {p0, p1}, Ld92;->d(Landroid/content/Intent;)V

    goto/16 :goto_1a6

    :cond_ca
    const-string/jumbo v8, "ACTION_CANCEL_WORK"

    nop

    nop

    const/4 v6, -0x7

    invoke-virtual {v8, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8

    const/4 v11, 0x1

    if-eqz v8, :cond_15a

    const/16 v6, 0xf3

    invoke-static {}, Lj41;->e()Lj41;

    move-result-object p3

    const/4 v6, -0x3

    new-instance v8, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v9, "Stopping foreground work for "

    nop

    nop

    const/16 v6, 0x97

    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v6, 0x190

    invoke-virtual {v8, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, -0x2

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    const/16 v6, 0x15d

    move-object/from16 v0, p3

    invoke-virtual {v0, p2, v8}, Lj41;->f(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v6, 0x8d

    invoke-virtual {p1, v12}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_1a6

    const/16 v6, 0x3ca

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    if-nez p2, :cond_1a6

    const/16 v6, 0x1218

    iget-object p0, p0, Ld92;->a:Lnq2;

    nop

    const/16 v6, 0x678

    invoke-static {p1}, Ljava/util/UUID;->fromString(Ljava/lang/String;)Ljava/util/UUID;

    move-result-object p1

    const/4 v6, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v6, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x921

    iget-object p2, p0, Lnq2;->b:Lsg;

    nop

    const/16 v6, 0xf23

    iget-object p2, p2, Lsg;->g:Ljava/lang/Object;

    nop

    check-cast p2, Lvp1;

    const/16 v6, 0xdda

    iget-object v6, p0, Lnq2;->d:Lx5;

    move-object/16 p3, v6

    const/16 v6, 0x3a9

    move-object/from16 v0, p3

    iget-object v6, v0, Lx5;->c:Ljava/lang/Object;

    move-object/16 p3, v6

    check-cast p3, Lcb;

    const/4 v6, -0x6

    move-object/from16 v0, p3

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xf27

    new-instance v8, Lwh;

    nop

    const/16 v6, 0x104e

    invoke-direct {v8, v11, p0, p1}, Lwh;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    const-string/jumbo p0, "CancelWorkById"

    nop

    nop

    const/16 v6, 0x11a5

    move-object/from16 v0, p3

    invoke-static {p2, p0, v0, v8}, Lq23;->E(Lvp1;Ljava/lang/String;Ljava/util/concurrent/Executor;Lzj0;)Lli1;

    goto :goto_1a6

    :cond_15a
    const-string/jumbo p1, "ACTION_STOP_FOREGROUND"

    nop

    nop

    const/4 v6, -0x7

    invoke-virtual {p1, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_1a6

    const/16 v6, 0xf3

    invoke-static {}, Lj41;->e()Lj41;

    move-result-object p1

    const-string/jumbo v8, "Stopping foreground service"

    nop

    nop

    const/16 v6, 0x15d

    invoke-virtual {p1, p2, v8}, Lj41;->f(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v6, 0x928

    iget-object p0, p0, Ld92;->i:Landroidx/work/impl/foreground/SystemForegroundService;

    nop

    if-eqz p0, :cond_1a6

    const/16 v6, 0x2be

    iput-boolean v11, p0, Landroidx/work/impl/foreground/SystemForegroundService;->b:Z

    const/16 v6, 0xf3

    invoke-static {}, Lj41;->e()Lj41;

    move-result-object p1

    const-string/jumbo p2, "Shutting down."

    nop

    nop

    const/16 v6, 0x257

    invoke-virtual {p1, v9, p2}, Lj41;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v6, 0x1fc

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 p2, 0x1a

    if-lt p1, p2, :cond_19f

    const/16 v6, 0xe7b

    invoke-virtual {p0, v11}, Landroid/app/Service;->stopForeground(Z)V

    :cond_19f
    const/16 v6, 0x556

    move/from16 v0, p3

    invoke-virtual {p0, v0}, Landroid/app/Service;->stopSelf(I)V

    :cond_1a6
    :goto_1a6
    const/4 p0, 0x3

    return p0
.end method

.method public final onTimeout(I)V
    .registers 6

    .prologue
    const/16 v0, 0x1fc

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 v3, 0x23

    if-lt v2, v3, :cond_a

    return-void

    :cond_a
    const/16 v0, 0x294

    iget-object p0, p0, Landroidx/work/impl/foreground/SystemForegroundService;->c:Ld92;

    nop

    const/16 v2, 0x800

    const/16 v0, 0x8e6

    invoke-virtual {p0, p1, v2}, Ld92;->f(II)V

    return-void
.end method

.method public final onTimeout(II)V
    .registers 5

    const/16 v0, 0x294

    iget-object p0, p0, Landroidx/work/impl/foreground/SystemForegroundService;->c:Ld92;

    nop

    const/16 v0, 0x8e6

    invoke-virtual {p0, p1, p2}, Ld92;->f(II)V

    return-void
.end method
