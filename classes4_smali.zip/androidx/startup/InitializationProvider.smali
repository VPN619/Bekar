.class public Landroidx/startup/InitializationProvider;
.super Landroid/content/ContentProvider;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# direct methods
.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Landroid/content/ContentProvider;-><init>()V

    return-void
.end method


# virtual methods
.method public final delete(Landroid/net/Uri;Ljava/lang/String;[Ljava/lang/String;)I
    .registers 6

    const/16 v0, 0x4bb

    new-instance p0, Ljava/lang/IllegalStateException;

    nop

    const-string/jumbo p1, "Not allowed."

    nop

    nop

    const/16 v0, 0x49e

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    check-cast p0, Ljava/lang/Throwable;

    throw p0
.end method

.method public final getType(Landroid/net/Uri;)Ljava/lang/String;
    .registers 4

    const/16 v0, 0x4bb

    new-instance p0, Ljava/lang/IllegalStateException;

    nop

    const-string/jumbo p1, "Not allowed."

    nop

    nop

    const/16 v0, 0x49e

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    check-cast p0, Ljava/lang/Throwable;

    throw p0
.end method

.method public final insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;
    .registers 5

    const/16 v0, 0x4bb

    new-instance p0, Ljava/lang/IllegalStateException;

    nop

    const-string/jumbo p1, "Not allowed."

    nop

    nop

    const/16 v0, 0x49e

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    check-cast p0, Ljava/lang/Throwable;

    throw p0
.end method

.method public final onCreate()Z
    .registers 7

    .prologue
    const/16 v0, 0x6c7

    invoke-virtual {p0}, Landroid/content/ContentProvider;->getContext()Landroid/content/Context;

    move-result-object p0

    if-eqz p0, :cond_7a

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    if-eqz v2, :cond_78

    const/16 v0, 0xd5a

    invoke-static {p0}, Ltd;->x(Landroid/content/Context;)Ltd;

    move-result-object p0

    const/16 v0, 0xd63

    iget-object v2, p0, Ltd;->d:Ljava/lang/Object;

    nop

    check-cast v2, Landroid/content/Context;

    :try_start_1d
    const-string/jumbo v3, "Startup"

    nop

    nop

    const/16 v0, 0xbf2

    invoke-static {v3}, Lq23;->b0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/16 v0, 0x1ef

    invoke-static {v3}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    const/16 v0, 0x9cd

    new-instance v3, Landroid/content/ComponentName;

    nop

    const/16 v0, 0x4a

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    const-class v5, Landroidx/startup/InitializationProvider;

    const/16 v0, 0x9db

    invoke-virtual {v5}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v5

    const/16 v0, 0x1151

    invoke-direct {v3, v4, v5}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v0, 0xea

    invoke-virtual {v2}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    const/16 v4, 0x80

    const/16 v0, 0xcf2

    invoke-virtual {v2, v3, v4}, Landroid/content/pm/PackageManager;->getProviderInfo(Landroid/content/ComponentName;I)Landroid/content/pm/ProviderInfo;

    move-result-object v2

    const/16 v0, 0xbf4

    iget-object v2, v2, Landroid/content/pm/ProviderInfo;->metaData:Landroid/os/Bundle;

    nop

    const/16 v0, 0x9c1

    invoke-virtual {p0, v2}, Ltd;->t(Landroid/os/Bundle;)V
    :try_end_5d
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_1d .. :try_end_5d} :catch_63
    .catchall {:try_start_1d .. :try_end_5d} :catchall_71

    const/16 v0, 0x73

    invoke-static {}, Landroid/os/Trace;->endSection()V

    goto :goto_78

    :catch_63
    move-exception p0

    :try_start_64
    const/16 v0, 0x359

    new-instance v2, Lft;

    nop

    const/16 v0, 0xeea

    invoke-direct {v2, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    check-cast v2, Ljava/lang/Throwable;

    throw v2
    :try_end_71
    .catchall {:try_start_64 .. :try_end_71} :catchall_71

    :catchall_71
    move-exception p0

    const/16 v0, 0x73

    invoke-static {}, Landroid/os/Trace;->endSection()V

    throw p0

    :cond_78
    :goto_78
    const/4 p0, 0x1

    return p0

    :cond_7a
    const/16 v0, 0x359

    new-instance p0, Lft;

    nop

    const-string/jumbo v2, "Context cannot be null"

    nop

    nop

    const/16 v0, 0x2b0

    invoke-direct {p0, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    check-cast p0, Ljava/lang/Throwable;

    throw p0
.end method

.method public final query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    .registers 8

    const/16 v0, 0x4bb

    new-instance p0, Ljava/lang/IllegalStateException;

    nop

    const-string/jumbo p1, "Not allowed."

    nop

    nop

    const/16 v0, 0x49e

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    check-cast p0, Ljava/lang/Throwable;

    throw p0
.end method

.method public final update(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I
    .registers 7

    const/16 v0, 0x4bb

    new-instance p0, Ljava/lang/IllegalStateException;

    nop

    const-string/jumbo p1, "Not allowed."

    nop

    nop

    const/16 v0, 0x49e

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    check-cast p0, Ljava/lang/Throwable;

    throw p0
.end method
