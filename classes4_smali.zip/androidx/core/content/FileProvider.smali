.class public Landroidx/core/content/FileProvider;
.super Landroid/content/ContentProvider;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field private static final ATTR_NAME:Ljava/lang/String;

.field private static final ATTR_PATH:Ljava/lang/String;

.field private static final COLUMNS:[Ljava/lang/String;

.field private static final DEVICE_ROOT:Ljava/io/File;

.field private static final DISPLAYNAME_FIELD:Ljava/lang/String;

.field private static final META_DATA_FILE_PROVIDER_PATHS:Ljava/lang/String;

.field private static final TAG_CACHE_PATH:Ljava/lang/String;

.field private static final TAG_EXTERNAL:Ljava/lang/String;

.field private static final TAG_EXTERNAL_CACHE:Ljava/lang/String;

.field private static final TAG_EXTERNAL_FILES:Ljava/lang/String;

.field private static final TAG_EXTERNAL_MEDIA:Ljava/lang/String;

.field private static final TAG_FILES_PATH:Ljava/lang/String;

.field private static final TAG_ROOT_PATH:Ljava/lang/String;

.field private static final sCache:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Lld0;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field private mAuthority:Ljava/lang/String;

.field private mLocalPathStrategy:Lld0;

.field private final mLock:Ljava/lang/Object;

.field private final mResourceId:I


# direct methods
.method static constructor <clinit>()V
    .registers 4

    const-string/jumbo v0, "external-cache-path"

    nop

    nop

    sput-object v0, Landroidx/core/content/FileProvider;->TAG_EXTERNAL_CACHE:Ljava/lang/String;

    const-string/jumbo v0, "files-path"

    nop

    nop

    sput-object v0, Landroidx/core/content/FileProvider;->TAG_FILES_PATH:Ljava/lang/String;

    const-string/jumbo v0, "name"

    nop

    nop

    sput-object v0, Landroidx/core/content/FileProvider;->ATTR_NAME:Ljava/lang/String;

    const-string/jumbo v0, "cache-path"

    nop

    nop

    sput-object v0, Landroidx/core/content/FileProvider;->TAG_CACHE_PATH:Ljava/lang/String;

    const-string/jumbo v0, "external-media-path"

    nop

    nop

    sput-object v0, Landroidx/core/content/FileProvider;->TAG_EXTERNAL_MEDIA:Ljava/lang/String;

    const-string/jumbo v0, "displayName"

    nop

    nop

    sput-object v0, Landroidx/core/content/FileProvider;->DISPLAYNAME_FIELD:Ljava/lang/String;

    const-string/jumbo v0, "external-files-path"

    nop

    nop

    sput-object v0, Landroidx/core/content/FileProvider;->TAG_EXTERNAL_FILES:Ljava/lang/String;

    const-string/jumbo v0, "path"

    nop

    nop

    sput-object v0, Landroidx/core/content/FileProvider;->ATTR_PATH:Ljava/lang/String;

    const-string/jumbo v0, "android.support.FILE_PROVIDER_PATHS"

    nop

    nop

    sput-object v0, Landroidx/core/content/FileProvider;->META_DATA_FILE_PROVIDER_PATHS:Ljava/lang/String;

    const-string/jumbo v0, "external-path"

    nop

    nop

    sput-object v0, Landroidx/core/content/FileProvider;->TAG_EXTERNAL:Ljava/lang/String;

    const-string/jumbo v0, "root-path"

    nop

    nop

    sput-object v0, Landroidx/core/content/FileProvider;->TAG_ROOT_PATH:Ljava/lang/String;

    const-string/jumbo v2, "_display_name"

    nop

    nop

    const-string/jumbo v3, "_size"

    nop

    nop

    check-cast v2, Ljava/lang/String;

    check-cast v3, Ljava/lang/String;

    filled-new-array {v2, v3}, [Ljava/lang/String;

    move-result-object v2

    sput-object v2, Landroidx/core/content/FileProvider;->COLUMNS:[Ljava/lang/String;

    const/16 v0, 0x24e

    new-instance v2, Ljava/io/File;

    nop

    const-string/jumbo v3, "/"

    nop

    nop

    const/16 v0, 0x212

    invoke-direct {v2, v3}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    check-cast v2, Ljava/io/File;

    sput-object v2, Landroidx/core/content/FileProvider;->DEVICE_ROOT:Ljava/io/File;

    const/16 v0, 0x8b3

    new-instance v2, Ljava/util/HashMap;

    nop

    const/16 v0, 0xf9f

    invoke-direct {v2}, Ljava/util/HashMap;-><init>()V

    check-cast v2, Ljava/util/HashMap;

    sput-object v2, Landroidx/core/content/FileProvider;->sCache:Ljava/util/HashMap;

    return-void
.end method

.method public constructor <init>()V
    .registers 4

    const/4 v2, 0x0

    invoke-direct {p0, v2}, Landroidx/core/content/FileProvider;-><init>(I)V

    return-void
.end method

.method public constructor <init>(I)V
    .registers 5

    invoke-direct {p0}, Landroid/content/ContentProvider;-><init>()V

    const/16 v0, 0xbd7

    new-instance v2, Ljava/lang/Object;

    nop

    const/16 v0, 0x21a

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x87d

    iput-object v2, p0, Landroidx/core/content/FileProvider;->mLock:Ljava/lang/Object;

    const/16 v0, 0xf09

    iput p1, p0, Landroidx/core/content/FileProvider;->mResourceId:I

    return-void
.end method

.method public static synthetic access$000(Ljava/lang/String;)Ljava/lang/String;
    .registers 3

    const/16 v0, 0xb53

    invoke-static {p0}, Landroidx/core/content/FileProvider;->removeTrailingSlash(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    return-object p0
.end method

.method private static varargs buildPath(Ljava/io/File;[Ljava/lang/String;)Ljava/io/File;
    .registers 8

    .prologue
    array-length v2, p1

    const/4 v3, 0x0

    :goto_2
    if-ge v3, v2, :cond_16

    aget-object v4, p1, v3

    if-eqz v4, :cond_13

    const/16 v0, 0x24e

    new-instance v5, Ljava/io/File;

    nop

    const/16 v0, 0xc0f

    invoke-direct {v5, p0, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    move-object p0, v5

    :cond_13
    add-int/lit8 v3, v3, 0x1

    goto :goto_2

    :cond_16
    check-cast p0, Ljava/io/File;

    return-object p0
.end method

.method private static copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;
    .registers 12

    new-array v8, p1, [Ljava/lang/Object;

    const/4 v9, 0x0

    const/16 v6, 0x1252

    move v0, v6

    move-object v1, p0

    move v2, v9

    move-object v3, v8

    move v4, v9

    move v5, p1

    invoke-static/range {v1 .. v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-object v8
.end method

.method private static copyOf([Ljava/lang/String;I)[Ljava/lang/String;
    .registers 12

    new-array v8, p1, [Ljava/lang/String;

    const/4 v9, 0x0

    const/16 v6, 0x1252

    move v0, v6

    move-object v1, p0

    move v2, v9

    move-object v3, v8

    move v4, v9

    move v5, p1

    invoke-static/range {v1 .. v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-object v8
.end method

.method public static getFileProviderPathsMetaData(Landroid/content/Context;Ljava/lang/String;Landroid/content/pm/ProviderInfo;I)Landroid/content/res/XmlResourceParser;
    .registers 9

    .prologue
    const/4 v2, 0x0

    if-eqz p2, :cond_41

    const/16 v0, 0xbf4

    iget-object p1, p2, Landroid/content/pm/ProviderInfo;->metaData:Landroid/os/Bundle;

    nop

    const-string/jumbo v3, "android.support.FILE_PROVIDER_PATHS"

    nop

    nop

    if-nez p1, :cond_25

    if-eqz p3, :cond_25

    const/16 v0, 0x108

    new-instance p1, Landroid/os/Bundle;

    nop

    const/4 v4, 0x1

    const/16 v0, 0x1073

    invoke-direct {p1, v4}, Landroid/os/Bundle;-><init>(I)V

    const/16 v0, 0x1021

    iput-object p1, p2, Landroid/content/pm/ProviderInfo;->metaData:Landroid/os/Bundle;

    const/16 v0, 0x23e

    invoke-virtual {p1, v3, p3}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    :cond_25
    const/16 v0, 0xea

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/16 v0, 0xb77

    invoke-virtual {p2, p0, v3}, Landroid/content/pm/PackageItemInfo;->loadXmlMetaData(Landroid/content/pm/PackageManager;Ljava/lang/String;)Landroid/content/res/XmlResourceParser;

    move-result-object p0

    if-eqz p0, :cond_36

    check-cast p0, Landroid/content/res/XmlResourceParser;

    return-object p0

    :cond_36
    const-string/jumbo p0, "Missing android.support.FILE_PROVIDER_PATHS meta-data"

    nop

    nop

    const/16 v0, 0x52e

    invoke-static {p0}, Lz6;->s(Ljava/lang/String;)V

    return-object v2

    :cond_41
    const-string/jumbo p0, "Couldn\'t find meta-data for provider with authority "

    nop

    nop

    const/16 v0, 0xebf

    invoke-static {p0, p1}, Lrt2;->h(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x52e

    invoke-static {p0}, Lz6;->s(Ljava/lang/String;)V

    return-object v2
.end method

.method private getLocalPathStrategy()Lld0;
    .registers 7

    .prologue
    const/16 v0, 0xcd7

    iget-object v2, p0, Landroidx/core/content/FileProvider;->mLock:Ljava/lang/Object;

    nop

    monitor-enter v2

    :try_start_6
    const/16 v0, 0x527

    iget-object v3, p0, Landroidx/core/content/FileProvider;->mAuthority:Ljava/lang/String;

    nop

    const-string/jumbo v4, "mAuthority is null. Did you override attachInfo and did not call super.attachInfo()?"

    nop

    nop

    if-eqz v3, :cond_38

    const/16 v0, 0x9be

    iget-object v3, p0, Landroidx/core/content/FileProvider;->mLocalPathStrategy:Lld0;

    nop

    if-nez v3, :cond_36

    const/16 v0, 0x6c7

    invoke-virtual {p0}, Landroid/content/ContentProvider;->getContext()Landroid/content/Context;

    move-result-object v3

    const/16 v0, 0x527

    iget-object v4, p0, Landroidx/core/content/FileProvider;->mAuthority:Ljava/lang/String;

    nop

    const/16 v0, 0xa5f

    iget v5, p0, Landroidx/core/content/FileProvider;->mResourceId:I

    nop

    const/16 v0, 0xccc

    invoke-static {v3, v4, v5}, Landroidx/core/content/FileProvider;->getPathStrategy(Landroid/content/Context;Ljava/lang/String;I)Lld0;

    move-result-object v3

    const/16 v0, 0xaef

    iput-object v3, p0, Landroidx/core/content/FileProvider;->mLocalPathStrategy:Lld0;

    goto :goto_36

    :catchall_34
    move-exception p0

    goto :goto_45

    :cond_36
    :goto_36
    monitor-exit v2

    goto :goto_47

    :cond_38
    const/16 v0, 0x621

    new-instance p0, Ljava/lang/NullPointerException;

    nop

    const/16 v0, 0x109b

    invoke-direct {p0, v4}, Ljava/lang/NullPointerException;-><init>(Ljava/lang/String;)V

    check-cast p0, Ljava/lang/Throwable;

    throw p0

    :goto_45
    monitor-exit v2
    :try_end_46
    .catchall {:try_start_6 .. :try_end_46} :catchall_34

    throw p0

    :goto_47
    check-cast v3, Lld0;

    return-object v3
.end method

.method private static getPathStrategy(Landroid/content/Context;Ljava/lang/String;I)Lld0;
    .registers 7

    .prologue
    const/16 v0, 0x627

    sget-object v2, Landroidx/core/content/FileProvider;->sCache:Ljava/util/HashMap;

    nop

    monitor-enter v2

    :try_start_6
    const/16 v0, 0x416

    invoke-virtual {v2, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lld0;
    :try_end_e
    .catchall {:try_start_6 .. :try_end_e} :catchall_1c

    if-nez v3, :cond_44

    :try_start_10
    const/16 v0, 0x822

    invoke-static {p0, p1, p2}, Landroidx/core/content/FileProvider;->parsePathStrategy(Landroid/content/Context;Ljava/lang/String;I)Lld0;

    move-result-object v3
    :try_end_16
    .catch Ljava/io/IOException; {:try_start_10 .. :try_end_16} :catch_31
    .catch Lorg/xmlpull/v1/XmlPullParserException; {:try_start_10 .. :try_end_16} :catch_1e
    .catchall {:try_start_10 .. :try_end_16} :catchall_1c

    :try_start_16
    const/16 v0, 0x9c7

    invoke-virtual {v2, p1, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_44

    :catchall_1c
    move-exception p0

    goto :goto_46

    :catch_1e
    move-exception p0

    const/16 v0, 0x4d8

    new-instance p1, Ljava/lang/IllegalArgumentException;

    nop

    const-string/jumbo p2, "Failed to parse android.support.FILE_PROVIDER_PATHS meta-data"

    nop

    nop

    const/16 v0, 0x3b3

    invoke-direct {p1, p2, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    check-cast p1, Ljava/lang/Throwable;

    throw p1

    :catch_31
    move-exception p0

    const/16 v0, 0x4d8

    new-instance p1, Ljava/lang/IllegalArgumentException;

    nop

    const-string/jumbo p2, "Failed to parse android.support.FILE_PROVIDER_PATHS meta-data"

    nop

    nop

    const/16 v0, 0x3b3

    invoke-direct {p1, p2, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    check-cast p1, Ljava/lang/Throwable;

    throw p1

    :cond_44
    :goto_44
    monitor-exit v2

    goto :goto_48

    :goto_46
    monitor-exit v2
    :try_end_47
    .catchall {:try_start_16 .. :try_end_47} :catchall_1c

    throw p0

    :goto_48
    check-cast v3, Lld0;

    return-object v3
.end method

.method public static getUriForFile(Landroid/content/Context;Ljava/lang/String;Ljava/io/File;)Landroid/net/Uri;
    .registers 13

    .prologue
    const/4 v2, 0x0

    const/16 v0, 0xccc

    invoke-static {p0, p1, v2}, Landroidx/core/content/FileProvider;->getPathStrategy(Landroid/content/Context;Ljava/lang/String;I)Lld0;

    move-result-object p0

    check-cast p0, Lmd0;

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 p1, 0x0

    :try_start_e
    const/16 v0, 0x1034

    invoke-virtual {p2}, Ljava/io/File;->getCanonicalPath()Ljava/lang/String;

    move-result-object p2
    :try_end_14
    .catch Ljava/io/IOException; {:try_start_e .. :try_end_14} :catch_136

    const/16 v0, 0x581

    iget-object v2, p0, Lmd0;->b:Ljava/util/HashMap;

    nop

    const/16 v0, 0x9d3

    invoke-virtual {v2}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    move-result-object v2

    const/16 v0, 0x14c

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    move-object v3, p1

    :cond_26
    :goto_26
    const/16 v0, 0x13e

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/16 v5, 0x2f

    if-eqz v4, :cond_90

    const/16 v0, 0x16e

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/util/Map$Entry;

    const/16 v0, 0x1c2

    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/io/File;

    const/16 v0, 0x25d

    invoke-virtual {v6}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v6

    const/16 v0, 0x3db

    invoke-static {p2}, Landroidx/core/content/FileProvider;->access$000(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const/16 v0, 0x3db

    invoke-static {v6}, Landroidx/core/content/FileProvider;->access$000(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const/4 v0, -0x3

    new-instance v9, Ljava/lang/StringBuilder;

    nop

    const/4 v0, -0x4

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v0, 0x0

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x1b

    invoke-virtual {v9, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/16 v0, 0xded

    invoke-virtual {v7, v5}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v5

    if-eqz v5, :cond_26

    if-eqz v3, :cond_8e

    const/16 v0, 0x47

    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v5

    const/16 v0, 0x1c2

    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/io/File;

    const/16 v0, 0x25d

    invoke-virtual {v6}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object v6

    const/16 v0, 0x47

    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v6

    if-le v5, v6, :cond_26

    :cond_8e
    move-object v3, v4

    goto :goto_26

    :cond_90
    if-eqz v3, :cond_125

    const/16 v0, 0x1c2

    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Ljava/io/File;

    const/16 v0, 0x25d

    invoke-virtual {p1}, Ljava/io/File;->getPath()Ljava/lang/String;

    move-result-object p1

    const-string/jumbo v2, "/"

    nop

    nop

    const/16 v0, 0xb14

    invoke-virtual {p1, v2}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_ba

    const/16 v0, 0x47

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result p1

    const/16 v0, 0x3bc

    invoke-virtual {p2, p1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p1

    goto :goto_c8

    :cond_ba
    const/16 v0, 0x47

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result p1

    add-int/lit8 p1, p1, 0x1

    const/16 v0, 0x3bc

    invoke-virtual {p2, p1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p1

    :goto_c8
    const/4 v0, -0x3

    new-instance p2, Ljava/lang/StringBuilder;

    nop

    const/4 v0, -0x4

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v0, 0x28f

    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    const/16 v0, 0x793

    invoke-static {v3}, Landroid/net/Uri;->encode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v0, 0x0

    invoke-virtual {p2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x1b

    invoke-virtual {p2, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v0, 0xdd3

    invoke-static {p1, v2}, Landroid/net/Uri;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v0, 0x0

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0x8fb

    new-instance p2, Landroid/net/Uri$Builder;

    nop

    const/16 v0, 0x1047

    invoke-direct {p2}, Landroid/net/Uri$Builder;-><init>()V

    const-string/jumbo v2, "content"

    nop

    nop

    const/16 v0, 0x988

    invoke-virtual {p2, v2}, Landroid/net/Uri$Builder;->scheme(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object p2

    const/16 v0, 0x8af

    iget-object p0, p0, Lmd0;->a:Ljava/lang/String;

    nop

    const/16 v0, 0x6e9

    invoke-virtual {p2, p0}, Landroid/net/Uri$Builder;->authority(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object p0

    const/16 v0, 0x10a7

    invoke-virtual {p0, p1}, Landroid/net/Uri$Builder;->encodedPath(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object p0

    const/16 v0, 0xab2

    invoke-virtual {p0}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object p0

    check-cast p0, Landroid/net/Uri;

    return-object p0

    :cond_125
    const-string/jumbo p0, "Failed to find configured root that contains "

    nop

    nop

    const/16 v0, 0xebf

    invoke-static {p0, p2}, Lrt2;->h(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x52e

    invoke-static {p0}, Lz6;->s(Ljava/lang/String;)V

    return-object p1

    :catch_136
    const-string/jumbo p0, "Failed to resolve canonical path for "

    nop

    nop

    const/16 v0, 0x113b

    invoke-static {p2, p0}, Lvh0;->j(Ljava/lang/Object;Ljava/lang/String;)V

    return-object p1
.end method

.method public static getUriForFile(Landroid/content/Context;Ljava/lang/String;Ljava/io/File;Ljava/lang/String;)Landroid/net/Uri;
    .registers 6
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "StreamFiles"
        }
    .end annotation

    const/16 v0, 0xa90

    invoke-static {p0, p1, p2}, Landroidx/core/content/FileProvider;->getUriForFile(Landroid/content/Context;Ljava/lang/String;Ljava/io/File;)Landroid/net/Uri;

    move-result-object p0

    const/16 v0, 0xe9d

    invoke-virtual {p0}, Landroid/net/Uri;->buildUpon()Landroid/net/Uri$Builder;

    move-result-object p0

    const-string/jumbo p1, "displayName"

    nop

    nop

    const/16 v0, 0x78e

    invoke-virtual {p0, p1, p3}, Landroid/net/Uri$Builder;->appendQueryParameter(Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object p0

    const/16 v0, 0xab2

    invoke-virtual {p0}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object p0

    check-cast p0, Landroid/net/Uri;

    return-object p0
.end method

.method private static modeToMode(Ljava/lang/String;)I
    .registers 4

    .prologue
    const-string/jumbo v2, "r"

    nop

    nop

    const/4 v0, -0x7

    invoke-virtual {v2, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_f

    const/high16 p0, 0x10000000

    return p0

    :cond_f
    const-string/jumbo v2, "w"

    nop

    nop

    const/4 v0, -0x7

    invoke-virtual {v2, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_67

    const-string/jumbo v2, "wt"

    nop

    nop

    const/4 v0, -0x7

    invoke-virtual {v2, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_28

    goto :goto_67

    :cond_28
    const-string/jumbo v2, "wa"

    nop

    nop

    const/4 v0, -0x7

    invoke-virtual {v2, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_37

    const/high16 p0, 0x2a000000

    return p0

    :cond_37
    const-string/jumbo v2, "rw"

    nop

    nop

    const/4 v0, -0x7

    invoke-virtual {v2, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_46

    const/high16 p0, 0x38000000

    return p0

    :cond_46
    const-string/jumbo v2, "rwt"

    nop

    nop

    const/4 v0, -0x7

    invoke-virtual {v2, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_55

    const/high16 p0, 0x3c000000  # 0.0078125f

    return p0

    :cond_55
    const-string/jumbo v2, "Invalid mode: "

    nop

    nop

    const/16 v0, 0xebf

    invoke-static {v2, p0}, Lrt2;->h(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x52e

    invoke-static {p0}, Lz6;->s(Ljava/lang/String;)V

    const/4 p0, 0x0

    return p0

    :cond_67
    :goto_67
    const/high16 p0, 0x2c000000

    return p0
.end method

.method private static parsePathStrategy(Landroid/content/Context;Ljava/lang/String;I)Lld0;
    .registers 11

    .prologue
    const/16 v0, 0x10a0

    new-instance v2, Lmd0;

    nop

    const/16 v0, 0x98b

    invoke-direct {v2, p1}, Lmd0;-><init>(Ljava/lang/String;)V

    const/16 v0, 0xea

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v3

    const/16 v4, 0x80

    const/16 v0, 0x1014

    invoke-virtual {v3, p1, v4}, Landroid/content/pm/PackageManager;->resolveContentProvider(Ljava/lang/String;I)Landroid/content/pm/ProviderInfo;

    move-result-object v3

    const/16 v0, 0xcc8

    invoke-static {p0, p1, v3, p2}, Landroidx/core/content/FileProvider;->getFileProviderPathsMetaData(Landroid/content/Context;Ljava/lang/String;Landroid/content/pm/ProviderInfo;I)Landroid/content/res/XmlResourceParser;

    move-result-object p1

    :cond_1e
    :goto_1e
    const/16 v0, 0xdaf

    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->next()I

    move-result p2

    const/4 v3, 0x1

    if-eq p2, v3, :cond_136

    const/4 v3, 0x2

    if-ne p2, v3, :cond_1e

    const/16 v0, 0xd2e

    invoke-interface {p1}, Lorg/xmlpull/v1/XmlPullParser;->getName()Ljava/lang/String;

    move-result-object p2

    const-string/jumbo v3, "name"

    nop

    nop

    const/4 v4, 0x0

    const/16 v0, 0x2dc

    invoke-interface {p1, v4, v3}, Landroid/util/AttributeSet;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string/jumbo v5, "path"

    nop

    nop

    const/16 v0, 0x2dc

    invoke-interface {p1, v4, v5}, Landroid/util/AttributeSet;->getAttributeValue(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string/jumbo v6, "root-path"

    nop

    nop

    const/4 v0, -0x7

    invoke-virtual {v6, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_5a

    const/16 v0, 0xc3b

    sget-object p2, Landroidx/core/content/FileProvider;->DEVICE_ROOT:Ljava/io/File;

    nop

    goto/16 :goto_dd

    :cond_5a
    const-string/jumbo v6, "files-path"

    nop

    nop

    const/4 v0, -0x7

    invoke-virtual {v6, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_6d

    const/16 v0, 0x1c3

    invoke-virtual {p0}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object p2

    goto :goto_dd

    :cond_6d
    const-string/jumbo v6, "cache-path"

    nop

    nop

    const/4 v0, -0x7

    invoke-virtual {v6, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_80

    const/16 v0, 0xfa0

    invoke-virtual {p0}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    move-result-object p2

    goto :goto_dd

    :cond_80
    const-string/jumbo v6, "external-path"

    nop

    nop

    const/4 v0, -0x7

    invoke-virtual {v6, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_93

    const/16 v0, 0x74e

    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object p2

    goto :goto_dd

    :cond_93
    const-string/jumbo v6, "external-files-path"

    nop

    nop

    const/4 v0, -0x7

    invoke-virtual {v6, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    const/4 v7, 0x0

    if-eqz v6, :cond_ac

    const/16 v0, 0xbc6

    invoke-static {p0, v4}, Lqx;->getExternalFilesDirs(Landroid/content/Context;Ljava/lang/String;)[Ljava/io/File;

    move-result-object p2

    array-length v6, p2

    if-lez v6, :cond_dc

    aget-object p2, p2, v7

    goto :goto_dd

    :cond_ac
    const-string/jumbo v6, "external-cache-path"

    nop

    nop

    const/4 v0, -0x7

    invoke-virtual {v6, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_c4

    const/16 v0, 0xd99

    invoke-static {p0}, Lqx;->getExternalCacheDirs(Landroid/content/Context;)[Ljava/io/File;

    move-result-object p2

    array-length v6, p2

    if-lez v6, :cond_dc

    aget-object p2, p2, v7

    goto :goto_dd

    :cond_c4
    const-string/jumbo v6, "external-media-path"

    nop

    nop

    const/4 v0, -0x7

    invoke-virtual {v6, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_dc

    const/16 v0, 0x114d

    invoke-virtual {p0}, Landroid/content/Context;->getExternalMediaDirs()[Ljava/io/File;

    move-result-object p2

    array-length v6, p2

    if-lez v6, :cond_dc

    aget-object p2, p2, v7

    goto :goto_dd

    :cond_dc
    move-object p2, v4

    :goto_dd
    if-eqz p2, :cond_1e

    check-cast v5, Ljava/lang/String;

    filled-new-array {v5}, [Ljava/lang/String;

    move-result-object v5

    const/16 v0, 0xb07

    invoke-static {p2, v5}, Landroidx/core/content/FileProvider;->buildPath(Ljava/io/File;[Ljava/lang/String;)Ljava/io/File;

    move-result-object p2

    const/16 v0, 0x3ca

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v5

    if-nez v5, :cond_12b

    :try_start_f3
    const/16 v0, 0xc43

    invoke-virtual {p2}, Ljava/io/File;->getCanonicalFile()Ljava/io/File;

    move-result-object p2
    :try_end_f9
    .catch Ljava/io/IOException; {:try_start_f3 .. :try_end_f9} :catch_105

    const/16 v0, 0x581

    iget-object v4, v2, Lmd0;->b:Ljava/util/HashMap;

    nop

    const/16 v0, 0x9c7

    invoke-virtual {v4, v3, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_1e

    :catch_105
    move-exception p0

    const/16 v0, 0x4d8

    new-instance p1, Ljava/lang/IllegalArgumentException;

    nop

    const/4 v0, -0x3

    new-instance v2, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v3, "Failed to resolve canonical path for "

    nop

    nop

    const/16 v0, 0x97

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x190

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/16 v0, 0x3b3

    invoke-direct {p1, p2, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    check-cast p1, Ljava/lang/Throwable;

    throw p1

    :cond_12b
    const-string/jumbo p0, "Name must not be empty"

    nop

    nop

    const/16 v0, 0x52e

    invoke-static {p0}, Lz6;->s(Ljava/lang/String;)V

    return-object v4

    :cond_136
    check-cast v2, Lld0;

    return-object v2
.end method

.method private static removeTrailingSlash(Ljava/lang/String;)Ljava/lang/String;
    .registers 5

    .prologue
    const/16 v0, 0x47

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v2

    if-lez v2, :cond_29

    const/16 v0, 0x47

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v2

    add-int/lit8 v2, v2, -0x1

    const/16 v0, 0x8a2

    invoke-virtual {p0, v2}, Ljava/lang/String;->charAt(I)C

    move-result v2

    const/16 v3, 0x2f

    if-ne v2, v3, :cond_29

    const/16 v0, 0x47

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v2

    add-int/lit8 v2, v2, -0x1

    const/4 v3, 0x0

    const/16 v0, 0x50b

    invoke-virtual {p0, v3, v2}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object p0

    :cond_29
    check-cast p0, Ljava/lang/String;

    return-object p0
.end method


# virtual methods
.method public attachInfo(Landroid/content/Context;Landroid/content/pm/ProviderInfo;)V
    .registers 5

    .prologue
    const/16 v0, 0x725

    invoke-super {p0, p1, p2}, Landroid/content/ContentProvider;->attachInfo(Landroid/content/Context;Landroid/content/pm/ProviderInfo;)V

    const/16 v0, 0x106f

    iget-boolean p1, p2, Landroid/content/pm/ProviderInfo;->exported:Z

    nop

    if-nez p1, :cond_7d

    const/16 v0, 0xfc8

    iget-boolean p1, p2, Landroid/content/pm/ProviderInfo;->grantUriPermissions:Z

    nop

    if-eqz p1, :cond_6b

    const/16 v0, 0x323

    iget-object p1, p2, Landroid/content/pm/ProviderInfo;->authority:Ljava/lang/String;

    nop

    if-eqz p1, :cond_59

    const/16 v0, 0x5cc

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0x125b

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result p1

    if-nez p1, :cond_59

    const/16 v0, 0x323

    iget-object p1, p2, Landroid/content/pm/ProviderInfo;->authority:Ljava/lang/String;

    nop

    const-string/jumbo p2, ";"

    nop

    nop

    const/16 v0, 0xe49

    invoke-virtual {p1, p2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    const/4 p2, 0x0

    aget-object p1, p1, p2

    const/16 v0, 0xcd7

    iget-object p2, p0, Landroidx/core/content/FileProvider;->mLock:Ljava/lang/Object;

    nop

    monitor-enter p2

    :try_start_41
    const/16 v0, 0x813

    iput-object p1, p0, Landroidx/core/content/FileProvider;->mAuthority:Ljava/lang/String;

    monitor-exit p2
    :try_end_46
    .catchall {:try_start_41 .. :try_end_46} :catchall_56

    const/16 v0, 0x627

    sget-object p0, Landroidx/core/content/FileProvider;->sCache:Ljava/util/HashMap;

    nop

    monitor-enter p0

    :try_start_4c
    const/16 v0, 0x1072

    invoke-virtual {p0, p1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    monitor-exit p0

    return-void

    :catchall_53
    move-exception p1

    monitor-exit p0
    :try_end_55
    .catchall {:try_start_4c .. :try_end_55} :catchall_53

    throw p1

    :catchall_56
    move-exception p0

    :try_start_57
    monitor-exit p2
    :try_end_58
    .catchall {:try_start_57 .. :try_end_58} :catchall_56

    throw p0

    :cond_59
    const/16 v0, 0x204

    new-instance p0, Ljava/lang/SecurityException;

    nop

    const-string/jumbo p1, "Provider must have a non-empty authority"

    nop

    nop

    const/16 v0, 0x19d

    invoke-direct {p0, p1}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    check-cast p0, Ljava/lang/Throwable;

    throw p0

    :cond_6b
    const/16 v0, 0x204

    new-instance p0, Ljava/lang/SecurityException;

    nop

    const-string/jumbo p1, "Provider must grant uri permissions"

    nop

    nop

    const/16 v0, 0x19d

    invoke-direct {p0, p1}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    check-cast p0, Ljava/lang/Throwable;

    throw p0

    :cond_7d
    const/16 v0, 0x204

    new-instance p0, Ljava/lang/SecurityException;

    nop

    const-string/jumbo p1, "Provider must not be exported"

    nop

    nop

    const/16 v0, 0x19d

    invoke-direct {p0, p1}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    check-cast p0, Ljava/lang/Throwable;

    throw p0
.end method

.method public delete(Landroid/net/Uri;Ljava/lang/String;[Ljava/lang/String;)I
    .registers 6

    const/16 v0, 0x1035

    invoke-direct {p0}, Landroidx/core/content/FileProvider;->getLocalPathStrategy()Lld0;

    move-result-object p0

    check-cast p0, Lmd0;

    const/16 v0, 0x56c

    invoke-virtual {p0, p1}, Lmd0;->a(Landroid/net/Uri;)Ljava/io/File;

    move-result-object p0

    const/16 v0, 0x460

    invoke-virtual {p0}, Ljava/io/File;->delete()Z

    move-result p0

    return p0
.end method

.method public getType(Landroid/net/Uri;)Ljava/lang/String;
    .registers 5

    .prologue
    const/16 v0, 0x1035

    invoke-direct {p0}, Landroidx/core/content/FileProvider;->getLocalPathStrategy()Lld0;

    move-result-object p0

    check-cast p0, Lmd0;

    const/16 v0, 0x56c

    invoke-virtual {p0, p1}, Lmd0;->a(Landroid/net/Uri;)Ljava/io/File;

    move-result-object p0

    const/16 v0, 0x1b7

    invoke-virtual {p0}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object p1

    const/16 v2, 0x2e

    const/16 v0, 0xafc

    invoke-virtual {p1, v2}, Ljava/lang/String;->lastIndexOf(I)I

    move-result p1

    if-ltz p1, :cond_3d

    const/16 v0, 0x1b7

    invoke-virtual {p0}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object p0

    add-int/lit8 p1, p1, 0x1

    const/16 v0, 0x3bc

    invoke-virtual {p0, p1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x91d

    invoke-static {}, Landroid/webkit/MimeTypeMap;->getSingleton()Landroid/webkit/MimeTypeMap;

    move-result-object p1

    const/16 v0, 0xf8c

    invoke-virtual {p1, p0}, Landroid/webkit/MimeTypeMap;->getMimeTypeFromExtension(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    if-eqz p0, :cond_3d

    check-cast p0, Ljava/lang/String;

    return-object p0

    :cond_3d
    const-string/jumbo p0, "application/octet-stream"

    nop

    nop

    return-object p0
.end method

.method public getTypeAnonymous(Landroid/net/Uri;)Ljava/lang/String;
    .registers 4

    const-string/jumbo p0, "application/octet-stream"

    nop

    nop

    return-object p0
.end method

.method public insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;
    .registers 5

    const/16 v0, 0x1097

    new-instance p0, Ljava/lang/UnsupportedOperationException;

    nop

    const-string/jumbo p1, "No external inserts"

    nop

    nop

    const/16 v0, 0x9e6

    invoke-direct {p0, p1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    check-cast p0, Ljava/lang/Throwable;

    throw p0
.end method

.method public onCreate()Z
    .registers 3

    const/4 p0, 0x1

    return p0
.end method

.method public openFile(Landroid/net/Uri;Ljava/lang/String;)Landroid/os/ParcelFileDescriptor;
    .registers 5
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "UnknownNullness"
        }
    .end annotation

    const/16 v0, 0x1035

    invoke-direct {p0}, Landroidx/core/content/FileProvider;->getLocalPathStrategy()Lld0;

    move-result-object p0

    check-cast p0, Lmd0;

    const/16 v0, 0x56c

    invoke-virtual {p0, p1}, Lmd0;->a(Landroid/net/Uri;)Ljava/io/File;

    move-result-object p0

    const/16 v0, 0xdd8

    invoke-static {p2}, Landroidx/core/content/FileProvider;->modeToMode(Ljava/lang/String;)I

    move-result p1

    const/16 v0, 0xedc

    invoke-static {p0, p1}, Landroid/os/ParcelFileDescriptor;->open(Ljava/io/File;I)Landroid/os/ParcelFileDescriptor;

    move-result-object p0

    check-cast p0, Landroid/os/ParcelFileDescriptor;

    return-object p0
.end method

.method public query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    .registers 14

    .prologue
    const/16 v1, 0x1035

    invoke-direct {p0}, Landroidx/core/content/FileProvider;->getLocalPathStrategy()Lld0;

    move-result-object p0

    check-cast p0, Lmd0;

    const/16 v1, 0x56c

    invoke-virtual {p0, p1}, Lmd0;->a(Landroid/net/Uri;)Ljava/io/File;

    move-result-object p0

    const-string/jumbo p3, "displayName"

    nop

    nop

    const/16 v1, 0x219

    invoke-virtual {p1, p3}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    if-nez p2, :cond_20

    const/16 v1, 0xb7f

    sget-object p2, Landroidx/core/content/FileProvider;->COLUMNS:[Ljava/lang/String;

    nop

    :cond_20
    array-length p3, p2

    new-array p3, p3, [Ljava/lang/String;

    array-length p4, p2

    new-array p4, p4, [Ljava/lang/Object;

    array-length p5, p2

    const/4 v3, 0x0

    move v4, v3

    :goto_29
    if-ge v3, p5, :cond_6d

    aget-object v5, p2, v3

    const-string/jumbo v6, "_display_name"

    nop

    nop

    const/4 v1, -0x7

    invoke-virtual {v6, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_4b

    aput-object v6, p3, v4

    add-int/lit8 v5, v4, 0x1

    if-nez p1, :cond_46

    const/16 v1, 0x1b7

    invoke-virtual {p0}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v6

    goto :goto_47

    :cond_46
    move-object v6, p1

    :goto_47
    aput-object v6, p4, v4

    :goto_49
    move v4, v5

    goto :goto_6a

    :cond_4b
    const-string/jumbo v6, "_size"

    nop

    nop

    const/4 v1, -0x7

    invoke-virtual {v6, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_6a

    aput-object v6, p3, v4

    add-int/lit8 v5, v4, 0x1

    const/16 v1, 0x9b7

    invoke-virtual {p0}, Ljava/io/File;->length()J

    move-result-wide v6

    const/16 v1, 0x61

    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v6

    aput-object v6, p4, v4

    goto :goto_49

    :cond_6a
    :goto_6a
    add-int/lit8 v3, v3, 0x1

    goto :goto_29

    :cond_6d
    const/16 v1, 0xf3f

    invoke-static {p3, v4}, Landroidx/core/content/FileProvider;->copyOf([Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object p0

    const/16 v1, 0x103a

    invoke-static {p4, v4}, Landroidx/core/content/FileProvider;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p1

    const/16 v1, 0xcff

    new-instance p2, Landroid/database/MatrixCursor;

    nop

    const/4 p3, 0x1

    const/16 v1, 0xaa1

    invoke-direct {p2, p0, p3}, Landroid/database/MatrixCursor;-><init>([Ljava/lang/String;I)V

    const/16 v1, 0x64c

    invoke-virtual {p2, p1}, Landroid/database/MatrixCursor;->addRow([Ljava/lang/Object;)V

    check-cast p2, Landroid/database/Cursor;

    return-object p2
.end method

.method public update(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I
    .registers 7

    const/16 v0, 0x1097

    new-instance p0, Ljava/lang/UnsupportedOperationException;

    nop

    const-string/jumbo p1, "No external updates"

    nop

    nop

    const/16 v0, 0x9e6

    invoke-direct {p0, p1}, Ljava/lang/UnsupportedOperationException;-><init>(Ljava/lang/String;)V

    check-cast p0, Ljava/lang/Throwable;

    throw p0
.end method
