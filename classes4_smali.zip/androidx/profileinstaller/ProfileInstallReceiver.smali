.class public Landroidx/profileinstaller/ProfileInstallReceiver;
.super Landroid/content/BroadcastReceiver;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# direct methods
.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .registers 10

    .prologue
    if-nez p2, :cond_4

    goto/16 :goto_16f

    :cond_4
    const/16 v0, 0x2f

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v2

    const-string/jumbo v3, "androidx.profileinstaller.action.INSTALL_PROFILE"

    nop

    nop

    const/4 v0, -0x7

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_31

    const/16 v0, 0xe9a

    new-instance p2, Lge;

    nop

    const/4 v2, 0x1

    const/16 v0, 0xcc0

    invoke-direct {p2, v2}, Lge;-><init>(I)V

    const/16 v0, 0x24c

    new-instance v3, Loj0;

    nop

    const/16 v0, 0x246

    invoke-direct {v3, p0}, Loj0;-><init>(Ljava/lang/Object;)V

    const/16 v0, 0x888

    invoke-static {p1, p2, v3, v2}, Lpy2;->T(Landroid/content/Context;Ljava/util/concurrent/Executor;Lxn1;Z)V

    return-void

    :cond_31
    const-string/jumbo v3, "androidx.profileinstaller.action.SKIP_FILE"

    nop

    nop

    const/4 v0, -0x7

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const-string/jumbo v4, "ProfileInstaller"

    nop

    nop

    const/16 v5, 0xa

    const/4 v6, 0x0

    if-eqz v3, :cond_d6

    const/16 v0, 0xdf

    invoke-virtual {p2}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object p2

    if-eqz p2, :cond_16f

    const-string/jumbo v2, "EXTRA_SKIP_FILE_OPERATION"

    nop

    nop

    const/16 v0, 0x183

    invoke-virtual {p2, v2}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const-string/jumbo v2, "WRITE_SKIP_FILE"

    nop

    nop

    const/4 v0, -0x7

    invoke-virtual {v2, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_a2

    const/16 v0, 0x24c

    new-instance p2, Loj0;

    nop

    const/16 v0, 0x246

    invoke-direct {p2, p0}, Loj0;-><init>(Ljava/lang/Object;)V

    const/16 v0, 0x53

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/16 v0, 0x4a

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0xea

    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v2

    const/4 v3, 0x0

    :try_start_81
    const/16 v0, 0xf17

    invoke-virtual {v2, p0, v3}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p0
    :try_end_87
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_81 .. :try_end_87} :catch_99

    const/16 v0, 0x1c3

    invoke-virtual {p1}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object p1

    const/16 v0, 0x836

    invoke-static {p0, p1}, Lpy2;->D(Landroid/content/pm/PackageInfo;Ljava/io/File;)V

    const/16 v0, 0xec

    invoke-virtual {p2, v5, v6}, Loj0;->d(ILjava/lang/Object;)V

    goto/16 :goto_16f

    :catch_99
    move-exception p0

    const/4 p1, 0x7

    const/16 v0, 0xec

    invoke-virtual {p2, p1, p0}, Loj0;->d(ILjava/lang/Object;)V

    goto/16 :goto_16f

    :cond_a2
    const-string/jumbo v2, "DELETE_SKIP_FILE"

    nop

    nop

    const/4 v0, -0x7

    invoke-virtual {v2, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_16f

    const/16 v0, 0x1c3

    invoke-virtual {p1}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object p1

    const/16 v0, 0x24e

    new-instance p2, Ljava/io/File;

    nop

    const-string/jumbo v2, "profileinstaller_profileWrittenFor_lastUpdateTime.dat"

    nop

    nop

    const/16 v0, 0xc0f

    invoke-direct {p2, p1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/16 v0, 0x460

    invoke-virtual {p2}, Ljava/io/File;->delete()Z

    const-string/jumbo p1, "RESULT_DELETE_SKIP_FILE_SUCCESS"

    nop

    nop

    nop

    const/16 p1, 0xb

    const/16 v0, 0x289

    invoke-virtual {p0, p1}, Landroid/content/BroadcastReceiver;->setResultCode(I)V

    return-void

    :cond_d6
    const-string/jumbo v3, "androidx.profileinstaller.action.SAVE_PROFILE"

    nop

    nop

    const/4 v0, -0x7

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_f9

    const/16 v0, 0xe44

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result p1

    const/16 v0, 0x845

    invoke-static {p1, v5}, Landroid/os/Process;->sendSignal(II)V

    const-string/jumbo p1, ""

    nop

    const/16 p1, 0xc

    const/16 v0, 0x289

    invoke-virtual {p0, p1}, Landroid/content/BroadcastReceiver;->setResultCode(I)V

    return-void

    :cond_f9
    const-string/jumbo v3, "androidx.profileinstaller.action.BENCHMARK_OPERATION"

    nop

    nop

    const/4 v0, -0x7

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_16f

    const/16 v0, 0xdf

    invoke-virtual {p2}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object p2

    if-eqz p2, :cond_16f

    const-string/jumbo v2, "EXTRA_BENCHMARK_OPERATION"

    nop

    nop

    const/16 v0, 0x183

    invoke-virtual {p2, v2}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/16 v0, 0x24c

    new-instance v2, Loj0;

    nop

    const/16 v0, 0x246

    invoke-direct {v2, p0}, Loj0;-><init>(Ljava/lang/Object;)V

    const-string/jumbo p0, "DROP_SHADER_CACHE"

    nop

    nop

    const/4 v0, -0x7

    invoke-virtual {p0, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_168

    const/16 v0, 0x1fc

    sget p0, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 p2, 0x22

    if-lt p0, p2, :cond_144

    const/16 v0, 0x46a

    invoke-virtual {p1}, Landroid/content/Context;->createDeviceProtectedStorageContext()Landroid/content/Context;

    move-result-object p0

    const/16 v0, 0xfa0

    invoke-virtual {p0}, Landroid/content/Context;->getCacheDir()Ljava/io/File;

    move-result-object p0

    goto :goto_150

    :cond_144
    const/16 v0, 0x46a

    invoke-virtual {p1}, Landroid/content/Context;->createDeviceProtectedStorageContext()Landroid/content/Context;

    move-result-object p0

    const/16 v0, 0xfac

    invoke-virtual {p0}, Landroid/content/Context;->getCodeCacheDir()Ljava/io/File;

    move-result-object p0

    :goto_150
    const/16 v0, 0x913

    invoke-static {p0}, Lv13;->m(Ljava/io/File;)Z

    move-result p0

    if-eqz p0, :cond_160

    const/16 p0, 0xe

    const/16 v0, 0xec

    invoke-virtual {v2, p0, v6}, Loj0;->d(ILjava/lang/Object;)V

    return-void

    :cond_160
    const/16 p0, 0xf

    const/16 v0, 0xec

    invoke-virtual {v2, p0, v6}, Loj0;->d(ILjava/lang/Object;)V

    return-void

    :cond_168
    const/16 p0, 0x10

    const/16 v0, 0xec

    invoke-virtual {v2, p0, v6}, Loj0;->d(ILjava/lang/Object;)V

    :cond_16f
    :goto_16f
    return-void
.end method
