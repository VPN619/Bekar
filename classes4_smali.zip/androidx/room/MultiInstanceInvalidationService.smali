.class public final Landroidx/room/MultiInstanceInvalidationService;
.super Landroid/app/Service;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public a:I

.field public final b:Ljava/util/LinkedHashMap;

.field public final c:Lwa1;

.field public final d:Lva1;


# direct methods
.method public constructor <init>()V
    .registers 4

    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    const/16 v0, 0x160

    new-instance v2, Ljava/util/LinkedHashMap;

    nop

    const/16 v0, 0x158

    invoke-direct {v2}, Ljava/util/LinkedHashMap;-><init>()V

    const/16 v0, 0x967

    iput-object v2, p0, Landroidx/room/MultiInstanceInvalidationService;->b:Ljava/util/LinkedHashMap;

    const/16 v0, 0x999

    new-instance v2, Lwa1;

    nop

    const/16 v0, 0x1109

    invoke-direct {v2, p0}, Lwa1;-><init>(Landroidx/room/MultiInstanceInvalidationService;)V

    const/16 v0, 0x908

    iput-object v2, p0, Landroidx/room/MultiInstanceInvalidationService;->c:Lwa1;

    const/16 v0, 0x94b

    new-instance v2, Lva1;

    nop

    const/16 v0, 0xcda

    invoke-direct {v2, p0}, Lva1;-><init>(Landroidx/room/MultiInstanceInvalidationService;)V

    const/16 v0, 0xa9d

    iput-object v2, p0, Landroidx/room/MultiInstanceInvalidationService;->d:Lva1;

    return-void
.end method


# virtual methods
.method public final onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .registers 4

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x11d0

    iget-object p0, p0, Landroidx/room/MultiInstanceInvalidationService;->d:Lva1;

    nop

    check-cast p0, Landroid/os/IBinder;

    return-object p0
.end method
