.class public final synthetic Lfm2;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lzj0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/tlsvpn/tlstunnel/services/VpnConnection;


# direct methods
.method public synthetic constructor <init>(Lcom/tlsvpn/tlstunnel/services/VpnConnection;I)V
    .registers 5

    iput p2, p0, Lfm2;->a:I

    iput-object p1, p0, Lfm2;->b:Lcom/tlsvpn/tlstunnel/services/VpnConnection;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 13

    .prologue
    const/16 v0, 0x1228

    iget v2, p0, Lfm2;->a:I

    nop

    const-string/jumbo v3, "torrentblk"

    const v4, 0x7f13003c

    const-string/jumbo v5, "atype"

    const-string/jumbo v6, "msg"

    const-class v7, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;

    const/16 v0, 0x21

    sget-object v8, Lrg2;->a:Lrg2;

    nop

    const/high16 v9, 0x10000000

    const/16 v0, 0xfb6

    iget-object p0, p0, Lfm2;->b:Lcom/tlsvpn/tlstunnel/services/VpnConnection;

    nop

    packed-switch v2, :pswitch_data_160

    const/16 v0, 0xfa

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->a:Lcom/tlsvpn/tlstunnel/services/ServicoVpn;

    nop

    const/16 v0, 0xe2

    sget v3, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->O:I

    nop

    :try_start_2c
    const/16 v0, 0x5b

    new-instance v3, Landroid/content/Intent;

    nop

    const/16 v0, 0x53

    invoke-virtual {v2}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v4

    const/16 v0, 0xd0

    invoke-direct {v3, v4, v7}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const v4, 0x7f130045

    const/4 v0, 0x7

    invoke-virtual {p0, v4}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x4b

    invoke-virtual {v3, v6, p0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    const-string/jumbo v3, "atmsgonly"

    const/16 v0, 0x4b

    invoke-virtual {p0, v5, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    const/16 v0, 0x59

    invoke-virtual {p0, v9}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object p0

    const/16 v0, 0xc9

    invoke-virtual {v2, p0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_5e
    .catch Ljava/lang/Exception; {:try_start_2c .. :try_end_5e} :catch_5e

    :catch_5e
    check-cast v8, Ljava/lang/Object;

    return-object v8

    :pswitch_61  #0x3
    const/16 v0, 0xfa

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->a:Lcom/tlsvpn/tlstunnel/services/ServicoVpn;

    nop

    const/16 v0, 0xe2

    sget v3, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->O:I

    nop

    :try_start_6b
    const/16 v0, 0x5b

    new-instance v3, Landroid/content/Intent;

    nop

    const/16 v0, 0x53

    invoke-virtual {v2}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v4

    const-class v5, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;

    const/16 v0, 0xd0

    invoke-direct {v3, v4, v5}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string/jumbo v4, "serverh"

    const/16 v0, 0xb91

    iget-object p0, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h:Lou;

    nop

    const/16 v0, 0x3b

    iget-object p0, p0, Lou;->i:Ljava/lang/String;

    nop

    const/16 v0, 0x4b

    invoke-virtual {v3, v4, p0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    const/16 v0, 0x59

    invoke-virtual {p0, v9}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object p0

    const/16 v0, 0xc9

    invoke-virtual {v2, p0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_9b
    .catch Ljava/lang/Exception; {:try_start_6b .. :try_end_9b} :catch_9b

    :catch_9b
    check-cast v8, Ljava/lang/Object;

    return-object v8

    :pswitch_9e  #0x2
    const/16 v0, 0xfa

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->a:Lcom/tlsvpn/tlstunnel/services/ServicoVpn;

    nop

    const/16 v0, 0xe2

    sget v10, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->O:I

    nop

    :try_start_a8
    const/16 v0, 0x5b

    new-instance v10, Landroid/content/Intent;

    nop

    const/16 v0, 0x53

    invoke-virtual {v2}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v11

    const/16 v0, 0xd0

    invoke-direct {v10, v11, v7}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v0, 0x7

    invoke-virtual {p0, v4}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x4b

    invoke-virtual {v10, v6, p0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    const/16 v0, 0x4b

    invoke-virtual {p0, v5, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    const/16 v0, 0x59

    invoke-virtual {p0, v9}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object p0

    const/16 v0, 0xc9

    invoke-virtual {v2, p0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_d4
    .catch Ljava/lang/Exception; {:try_start_a8 .. :try_end_d4} :catch_d4

    :catch_d4
    check-cast v8, Ljava/lang/Object;

    return-object v8

    :pswitch_d7  #0x1
    const/16 v0, 0xfa

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->a:Lcom/tlsvpn/tlstunnel/services/ServicoVpn;

    nop

    const/16 v0, 0xe2

    sget v3, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->O:I

    nop

    :try_start_e1
    const/16 v0, 0x5b

    new-instance v3, Landroid/content/Intent;

    nop

    const/16 v0, 0x53

    invoke-virtual {v2}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v4

    const/16 v0, 0xd0

    invoke-direct {v3, v4, v7}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string/jumbo v4, "sshaf"

    const/16 v0, 0x4b

    invoke-virtual {v3, v5, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v3

    const-string/jumbo v4, "title"

    const v5, 0x7f130037

    const/4 v0, 0x7

    invoke-virtual {p0, v5}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v5

    const/16 v0, 0x4b

    invoke-virtual {v3, v4, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v3

    const v4, 0x7f130038

    const/4 v0, 0x7

    invoke-virtual {p0, v4}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x4b

    invoke-virtual {v3, v6, p0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    const/16 v0, 0x59

    invoke-virtual {p0, v9}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object p0

    const/16 v0, 0xc9

    invoke-virtual {v2, p0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_124
    .catch Ljava/lang/Exception; {:try_start_e1 .. :try_end_124} :catch_124

    :catch_124
    check-cast v8, Ljava/lang/Object;

    return-object v8

    :pswitch_127  #0x0
    const/16 v0, 0xfa

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->a:Lcom/tlsvpn/tlstunnel/services/ServicoVpn;

    nop

    const/16 v0, 0xe2

    sget v10, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->O:I

    nop

    :try_start_131
    const/16 v0, 0x5b

    new-instance v10, Landroid/content/Intent;

    nop

    const/16 v0, 0x53

    invoke-virtual {v2}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v11

    const/16 v0, 0xd0

    invoke-direct {v10, v11, v7}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v0, 0x7

    invoke-virtual {p0, v4}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x4b

    invoke-virtual {v10, v6, p0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    const/16 v0, 0x4b

    invoke-virtual {p0, v5, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    const/16 v0, 0x59

    invoke-virtual {p0, v9}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object p0

    const/16 v0, 0xc9

    invoke-virtual {v2, p0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_15d
    .catch Ljava/lang/Exception; {:try_start_131 .. :try_end_15d} :catch_15d

    :catch_15d
    check-cast v8, Ljava/lang/Object;

    return-object v8

    :pswitch_data_160
    .packed-switch 0x0
        :pswitch_127  #00000000
        :pswitch_d7  #00000001
        :pswitch_9e  #00000002
        :pswitch_61  #00000003
    .end packed-switch
.end method
