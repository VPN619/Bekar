.class public final synthetic Lx3;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpv;
.implements Lmz;
.implements Lkn;
.implements Lzu0;
.implements Lyt;
.implements Lxm;
.implements Lwd1;
.implements Lcom/android/billingclient/api/AcknowledgePurchaseResponseListener;
.implements Lgx1;
.implements Lv82;
.implements Lcom/mbridge/msdk/config/component/load/downloader/database/c$a;
.implements Lcom/google/android/gms/tasks/OnCompleteListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .registers 6

    iput p1, p0, Lx3;->a:I

    iput-object p2, p0, Lx3;->b:Ljava/lang/Object;

    iput-object p3, p0, Lx3;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public H()Ljava/lang/Object;
    .registers 16

    .prologue
    const/16 v6, 0x7a3

    iget v8, p0, Lx3;->a:I

    nop

    const/4 v9, 0x0

    const/16 v6, 0xd7f

    iget-object v10, p0, Lx3;->c:Ljava/lang/Object;

    nop

    const/16 v6, 0x778

    iget-object p0, p0, Lx3;->b:Ljava/lang/Object;

    nop

    check-cast p0, Lvh2;

    packed-switch v8, :pswitch_data_a0

    check-cast v10, Ljava/util/HashMap;

    const/16 v6, 0x9d3

    invoke-virtual {v10}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    move-result-object v8

    const/16 v6, 0x14c

    invoke-interface {v8}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :goto_23
    const/16 v6, 0x13e

    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_61

    const/16 v6, 0x16e

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/Map$Entry;

    const/16 v6, 0xc36

    iget-object v11, p0, Lvh2;->e:Ljava/lang/Object;

    nop

    check-cast v11, Lix1;

    const/16 v6, 0x1c2

    invoke-interface {v10}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/Integer;

    const/16 v6, 0x451

    invoke-virtual {v12}, Ljava/lang/Integer;->intValue()I

    move-result v12

    int-to-long v12, v12

    const/16 v6, 0x28f

    invoke-interface {v10}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    const/16 v6, 0x972

    sget-object v14, Le41;->g:Le41;

    nop

    const/16 v6, 0xc9a

    move v0, v6

    move-object v1, v11

    move-wide v2, v12

    move-object v4, v14

    move-object v5, v10

    invoke-virtual/range {v1 .. v5}, Lix1;->C(JLe41;Ljava/lang/String;)V

    goto :goto_23

    :cond_61
    return-object v9

    :pswitch_62  #0xd
    check-cast v10, Ljava/lang/Iterable;

    const/16 v6, 0xdc2

    iget-object p0, p0, Lvh2;->c:Ljava/lang/Object;

    nop

    check-cast p0, Lix1;

    const/4 v6, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x429

    invoke-interface {v10}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v8

    const/16 v6, 0x13e

    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-nez v8, :cond_7e

    goto :goto_9e

    :cond_7e
    const/16 v6, 0xe69

    invoke-static {v10}, Lix1;->I(Ljava/lang/Iterable;)Ljava/lang/String;

    move-result-object v8

    const-string/jumbo v10, "DELETE FROM events WHERE _id in "

    const/16 v6, 0xee

    invoke-virtual {v10, v8}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const/16 v6, 0xcd

    invoke-virtual {p0}, Lix1;->k()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object p0

    const/16 v6, 0x112

    invoke-virtual {p0, v8}, Landroid/database/sqlite/SQLiteDatabase;->compileStatement(Ljava/lang/String;)Landroid/database/sqlite/SQLiteStatement;

    move-result-object p0

    const/16 v6, 0x34c

    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteStatement;->execute()V

    :goto_9e
    return-object v9

    nop

    :pswitch_data_a0
    .packed-switch 0xd
        :pswitch_62  #0000000d
    .end packed-switch
.end method

.method public a(Lcom/mbridge/msdk/config/component/load/downloader/database/b;)V
    .registers 5

    const/16 v0, 0x778

    iget-object v2, p0, Lx3;->b:Ljava/lang/Object;

    nop

    check-cast v2, Lcom/mbridge/msdk/config/component/load/downloader/core/g;

    const/16 v0, 0xd7f

    iget-object p0, p0, Lx3;->c:Ljava/lang/Object;

    nop

    check-cast p0, Ljava/util/concurrent/CountDownLatch;

    const/16 v0, 0x954

    invoke-static {v2, p0, p1}, Lcom/mbridge/msdk/config/component/load/downloader/core/g;->a(Lcom/mbridge/msdk/config/component/load/downloader/core/g;Ljava/util/concurrent/CountDownLatch;Lcom/mbridge/msdk/config/component/load/downloader/database/b;)V

    return-void
.end method

.method public a(Landroid/view/MenuItem;)Z
    .registers 31

    .prologue
    move-object/from16 v13, p0

    const/16 v11, 0x778

    iget-object v14, v13, Lx3;->b:Ljava/lang/Object;

    nop

    check-cast v14, Landroidx/navigation/fragment/NavHostFragment;

    const/16 v11, 0xd7f

    iget-object v13, v13, Lx3;->c:Ljava/lang/Object;

    nop

    check-cast v13, Lcom/tlsvpn/tlstunnel/MainActivity;

    const/16 v11, 0x44d

    sget v15, Lcom/tlsvpn/tlstunnel/MainActivity;->m:I

    nop

    const/4 v11, -0x6

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v11, 0x25c

    invoke-virtual {v14}, Landroidx/navigation/fragment/NavHostFragment;->b()Lzc1;

    move-result-object v14

    const/16 v11, 0x4b9

    iget-object v15, v14, Lzc1;->b:Lmc1;

    nop

    const/16 v11, 0x271

    invoke-virtual {v15}, Lmc1;->f()Luc1;

    move-result-object v15

    const/16 v16, 0x1

    if-eqz v15, :cond_47

    const/16 v11, 0x17e

    move-object/from16 v0, p1

    invoke-interface {v0}, Landroid/view/MenuItem;->getItemId()I

    move-result v17

    const/16 v11, 0xbcf

    iget-object v15, v15, Luc1;->b:Lz4;

    nop

    const/16 v11, 0xa10

    iget v15, v15, Lz4;->b:I

    nop

    move/from16 v0, v17

    if-ne v0, v15, :cond_47

    return v16

    :cond_47
    const/16 v11, 0x17e

    move-object/from16 v0, p1

    invoke-interface {v0}, Landroid/view/MenuItem;->getItemId()I

    move-result v15

    const v17, 0x7f09016c

    const/16 v18, 0x0

    move/from16 v0, v17

    if-ne v15, v0, :cond_7d

    const/16 v11, 0x1f9

    invoke-virtual {v13}, Lcom/tlsvpn/tlstunnel/MainActivity;->h()Lcom/google/android/material/bottomnavigation/BottomNavigationView;

    move-result-object v13

    const/16 v11, 0x5b9

    move/from16 v0, v17

    invoke-virtual {v13, v0}, Lyd1;->a(I)Ljh;

    move-result-object v13

    const/16 v11, 0x100f

    move/from16 v0, v18

    sput v0, Lmi2;->c:I

    const/16 v11, 0xb65

    move/from16 v0, v18

    invoke-virtual {v13, v0}, Ljh;->j(Z)V

    const/16 v11, 0x4d0

    sget v15, Lmi2;->c:I

    nop

    const/16 v11, 0x5cb

    invoke-virtual {v13, v15}, Ljh;->i(I)V

    :cond_7d
    const/16 v11, 0x4b9

    iget-object v13, v14, Lzc1;->b:Lmc1;

    nop

    const/16 v11, 0x7c0

    invoke-virtual {v13}, Lmc1;->g()Lwc1;

    move-result-object v13

    const/16 v11, 0x1175

    iget-object v13, v13, Lwc1;->g:Lfc1;

    nop

    const/16 v11, 0x10ae

    iget v11, v13, Lfc1;->a:I

    move/16 v22, v11

    const/16 v11, 0xbcd

    new-instance v19, Lcd1;

    nop

    const/16 v20, 0x1

    const/16 v21, 0x1

    const/16 v23, 0x0

    const/16 v24, 0x1

    const v25, 0x7f01002e

    const v26, 0x7f01002f

    const v27, 0x7f01002e

    const v28, 0x7f01002f

    const/16 v11, 0xe4b

    move v0, v11

    move-object/from16 v1, v19

    move/from16 v2, v20

    move/from16 v3, v21

    move/from16 v4, v22

    move/from16 v5, v23

    move/from16 v6, v24

    move/from16 v7, v25

    move/from16 v8, v26

    move/from16 v9, v27

    move/from16 v10, v28

    invoke-direct/range {v1 .. v10}, Lcd1;-><init>(ZZIZZIIII)V

    :try_start_c7
    const/16 v11, 0x17e

    move-object/from16 v0, p1

    invoke-interface {v0}, Landroid/view/MenuItem;->getItemId()I

    move-result v13

    const/16 v11, 0xcf7

    move-object/from16 v0, v19

    invoke-virtual {v14, v13, v0}, Lzc1;->a(ILcd1;)V
    :try_end_d6
    .catch Ljava/lang/Exception; {:try_start_c7 .. :try_end_d6} :catch_d7

    return v16

    :catch_d7
    return v18
.end method

.method public apply(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 25

    .prologue
    const/16 v9, 0x778

    move-object/from16 v0, p0

    iget-object v11, v0, Lx3;->b:Ljava/lang/Object;

    nop

    check-cast v11, Lix1;

    const/16 v9, 0xd7f

    move-object/from16 v0, p0

    iget-object v9, v0, Lx3;->c:Ljava/lang/Object;

    move-object/16 p0, v9

    check-cast p0, Lyg;

    move-object/from16 v12, p1

    check-cast v12, Landroid/database/sqlite/SQLiteDatabase;

    const/16 v9, 0x5a0

    iget-object v9, v11, Lix1;->d:Ljg;

    move-object/16 p1, v9

    const/16 v9, 0x3bd

    move-object/from16 v0, p1

    iget v13, v0, Ljg;->b:I

    nop

    const/16 v9, 0x330

    move-object/from16 v0, p0

    invoke-virtual {v11, v12, v0, v13}, Lix1;->y(Landroid/database/sqlite/SQLiteDatabase;Lyg;I)Ljava/util/ArrayList;

    move-result-object v20

    const/16 v9, 0x765

    invoke-static {}, Lym1;->values()[Lym1;

    move-result-object v13

    array-length v14, v13

    const/16 v21, 0x0

    move/from16 v15, v21

    :goto_39
    if-ge v15, v14, :cond_c1

    aget-object v16, v13, v15

    const/16 v9, 0x1147

    move-object/from16 v0, p0

    iget-object v9, v0, Lyg;->c:Lym1;

    move-object/16 v17, v9

    move-object/from16 v0, v16

    move-object/from16 v1, v17

    if-ne v0, v1, :cond_4d

    goto :goto_b1

    :cond_4d
    const/16 v9, 0x3bd

    move-object/from16 v0, p1

    iget v9, v0, Ljg;->b:I

    move/16 v17, v9

    const/16 v9, 0xac

    move-object/from16 v0, v20

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v18

    sub-int v17, v17, v18

    if-gtz v17, :cond_63

    goto :goto_c1

    :cond_63
    const/16 v9, 0xcaf

    invoke-static {}, Lyg;->a()Ltd;

    move-result-object v18

    const/16 v9, 0x76d

    move-object/from16 v0, p0

    iget-object v9, v0, Lyg;->a:Ljava/lang/String;

    move-object/16 v19, v9

    const/16 v9, 0x1195

    move-object/from16 v0, v18

    move-object/from16 v1, v19

    invoke-virtual {v0, v1}, Ltd;->D(Ljava/lang/String;)V

    if-eqz v16, :cond_b4

    const/16 v9, 0x5e5

    move-object/from16 v0, v18

    move-object/from16 v1, v16

    iput-object v1, v0, Ltd;->d:Ljava/lang/Object;

    const/16 v9, 0x879

    move-object/from16 v0, p0

    iget-object v9, v0, Lyg;->b:[B

    move-object/16 v16, v9

    const/16 v9, 0x1211

    move-object/from16 v0, v18

    move-object/from16 v1, v16

    iput-object v1, v0, Ltd;->c:Ljava/lang/Object;

    const/16 v9, 0xacb

    move-object/from16 v0, v18

    invoke-virtual {v0}, Ltd;->j()Lyg;

    move-result-object v16

    const/16 v9, 0x330

    move-object/from16 v0, v16

    move/from16 v1, v17

    invoke-virtual {v11, v12, v0, v1}, Lix1;->y(Landroid/database/sqlite/SQLiteDatabase;Lyg;I)Ljava/util/ArrayList;

    move-result-object v16

    const/16 v9, 0x12a

    move-object/from16 v0, v20

    move-object/from16 v1, v16

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    :goto_b1
    add-int/lit8 v15, v15, 0x1

    goto :goto_39

    :cond_b4
    const-string/jumbo p0, "Null priority"

    const/16 v9, 0x83f

    move-object/from16 v0, p0

    invoke-static {v0}, Ldm2;->n(Ljava/lang/String;)V

    const/16 p0, 0x0

    return-object p0

    :cond_c1
    :goto_c1
    const/16 v9, 0x8b3

    new-instance p0, Ljava/util/HashMap;

    nop

    const/16 v9, 0xf9f

    move-object/from16 v0, p0

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v9, -0x3

    new-instance p1, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v11, "event_id IN ("

    const/16 v9, 0x97

    move-object/from16 v0, p1

    invoke-direct {v0, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    move/from16 v11, v21

    :goto_dd
    const/16 v9, 0xac

    move-object/from16 v0, v20

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v13

    const/16 v22, 0x1

    if-ge v11, v13, :cond_119

    const/16 v9, 0x43

    move-object/from16 v0, v20

    invoke-virtual {v0, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lrg;

    const/16 v9, 0x292

    iget-wide v9, v13, Lrg;->a:J

    move-wide/16 v13, v9

    const/16 v9, 0x83

    move-object/from16 v0, p1

    invoke-virtual {v0, v13, v14}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/16 v9, 0xac

    move-object/from16 v0, v20

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v13

    sub-int v13, v13, v22

    if-ge v11, v13, :cond_116

    const/16 v13, 0x2c

    const/16 v9, 0x1b

    move-object/from16 v0, p1

    invoke-virtual {v0, v13}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    :cond_116
    add-int/lit8 v11, v11, 0x1

    goto :goto_dd

    :cond_119
    const/16 v11, 0x29

    const/16 v9, 0x1b

    move-object/from16 v0, p1

    invoke-virtual {v0, v11}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string/jumbo v11, "name"

    const-string/jumbo v13, "value"

    const-string/jumbo v14, "event_id"

    check-cast v14, Ljava/lang/String;

    check-cast v11, Ljava/lang/String;

    check-cast v13, Ljava/lang/String;

    filled-new-array {v14, v11, v13}, [Ljava/lang/String;

    move-result-object v14

    const/4 v9, -0x2

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v15

    const/16 v18, 0x0

    const/16 v19, 0x0

    const-string/jumbo v13, "event_metadata"

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v9, 0xf4c

    move v0, v9

    move-object v1, v12

    move-object v2, v13

    move-object v3, v14

    move-object v4, v15

    move-object/from16 v5, v16

    move-object/from16 v6, v17

    move-object/from16 v7, v18

    move-object/from16 v8, v19

    invoke-virtual/range {v1 .. v8}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object p1

    :try_start_15a
    move-object/from16 v11, p1

    check-cast v11, Landroid/database/Cursor;

    :goto_15e
    const/16 v9, 0x1a7

    invoke-interface {v11}, Landroid/database/Cursor;->moveToNext()Z

    move-result v12

    if-eqz v12, :cond_1b6

    const/16 v9, 0x11c

    move/from16 v0, v21

    invoke-interface {v11, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v12

    const/16 v9, 0x61

    invoke-static {v12, v13}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v14

    const/16 v9, 0x416

    move-object/from16 v0, p0

    invoke-virtual {v0, v14}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/util/Set;

    if-nez v14, :cond_197

    const/16 v9, 0x167

    new-instance v14, Ljava/util/HashSet;

    nop

    const/16 v9, 0x13f

    invoke-direct {v14}, Ljava/util/HashSet;-><init>()V

    const/16 v9, 0x61

    invoke-static {v12, v13}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v12

    const/16 v9, 0x9c7

    move-object/from16 v0, p0

    invoke-virtual {v0, v12, v14}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_197
    const/16 v9, 0x8c0

    new-instance v12, Lhx1;

    nop

    const/16 v9, 0x153

    move/from16 v0, v22

    invoke-interface {v11, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v13

    const/4 v15, 0x2

    const/16 v9, 0x153

    invoke-interface {v11, v15}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v15

    const/16 v9, 0xa32

    invoke-direct {v12, v13, v15}, Lhx1;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v9, 0x10c6

    invoke-interface {v14, v12}, Ljava/util/Set;->add(Ljava/lang/Object;)Z
    :try_end_1b5
    .catchall {:try_start_15a .. :try_end_1b5} :catchall_262

    goto :goto_15e

    :cond_1b6
    const/16 v9, 0x30d

    move-object/from16 v0, p1

    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    const/16 v9, 0x11ad

    move-object/from16 v0, v20

    invoke-virtual {v0}, Ljava/util/ArrayList;->listIterator()Ljava/util/ListIterator;

    move-result-object p1

    :goto_1c5
    const/16 v9, 0xad2

    move-object/from16 v0, p1

    invoke-interface {v0}, Ljava/util/ListIterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_25f

    const/16 v9, 0x5c9

    move-object/from16 v0, p1

    invoke-interface {v0}, Ljava/util/ListIterator;->next()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lrg;

    const/16 v9, 0x292

    iget-wide v12, v11, Lrg;->a:J

    nop

    const/16 v9, 0x61

    invoke-static {v12, v13}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v14

    const/16 v9, 0x1127

    move-object/from16 v0, p0

    invoke-virtual {v0, v14}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v14

    if-nez v14, :cond_1ef

    goto :goto_1c5

    :cond_1ef
    const/16 v9, 0x8f1

    iget-object v14, v11, Lrg;->c:Lig;

    nop

    const/16 v9, 0xbdd

    invoke-virtual {v14}, Lig;->c()Lf6;

    move-result-object v14

    const/16 v9, 0x61

    invoke-static {v12, v13}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v15

    const/16 v9, 0x416

    move-object/from16 v0, p0

    invoke-virtual {v0, v15}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Ljava/util/Set;

    const/16 v9, 0x14c

    invoke-interface {v15}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v15

    :goto_210
    const/16 v9, 0x13e

    invoke-interface {v15}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-eqz v16, :cond_23c

    const/16 v9, 0x16e

    invoke-interface {v15}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v16

    check-cast v16, Lhx1;

    const/16 v9, 0x6f7

    move-object/from16 v0, v16

    iget-object v9, v0, Lhx1;->a:Ljava/lang/String;

    move-object/16 v17, v9

    const/16 v9, 0xaba

    move-object/from16 v0, v16

    iget-object v9, v0, Lhx1;->b:Ljava/lang/String;

    move-object/16 v16, v9

    const/16 v9, 0x6a0

    move-object/from16 v0, v17

    move-object/from16 v1, v16

    invoke-virtual {v14, v0, v1}, Lf6;->a(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_210

    :cond_23c
    const/16 v9, 0x73f

    iget-object v11, v11, Lrg;->b:Lyg;

    nop

    const/16 v9, 0xdd6

    invoke-virtual {v14}, Lf6;->c()Lig;

    move-result-object v14

    const/16 v9, 0x1053

    new-instance v15, Lrg;

    nop

    const/16 v9, 0x7e6

    move v0, v9

    move-object v1, v15

    move-wide v2, v12

    move-object v4, v11

    move-object v5, v14

    invoke-direct/range {v1 .. v5}, Lrg;-><init>(JLyg;Lig;)V

    const/16 v9, 0x10ea

    move-object/from16 v0, p1

    invoke-interface {v0, v15}, Ljava/util/ListIterator;->set(Ljava/lang/Object;)V

    goto/16 :goto_1c5

    :cond_25f
    check-cast v20, Ljava/lang/Object;

    return-object v20

    :catchall_262
    move-exception v11

    move-object/from16 p0, v11

    const/16 v9, 0x30d

    move-object/from16 v0, p1

    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    throw p0
.end method

.method public b(Lhz0;)Ljava/lang/Object;
    .registers 5

    .prologue
    const/16 v0, 0x778

    iget-object v2, p0, Lx3;->b:Ljava/lang/Object;

    nop

    check-cast v2, Lvm1;

    const/16 v0, 0xd7f

    iget-object p0, p0, Lx3;->c:Ljava/lang/Object;

    nop

    check-cast p0, Lj5;

    const/16 v0, 0xd48

    iget-object p1, p1, Lhz0;->a:Li10;

    nop

    const/16 v0, 0xec5

    iget p0, p0, Lj5;->a:I

    nop

    packed-switch p0, :pswitch_data_30

    const-class p0, Luo1;

    goto :goto_29

    :pswitch_1e  #0x3
    const-class p0, Lto1;

    goto :goto_29

    :pswitch_21  #0x2
    const-class p0, Lmm1;

    goto :goto_29

    :pswitch_24  #0x1
    const-class p0, Lzp;

    goto :goto_29

    :pswitch_27  #0x0
    const-class p0, Lf5;

    :goto_29
    const/16 v0, 0xfd2

    invoke-virtual {v2, p1, p0}, Lvm1;->a(Li10;Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_data_30
    .packed-switch 0x0
        :pswitch_27  #00000000
        :pswitch_24  #00000001
        :pswitch_21  #00000002
        :pswitch_1e  #00000003
    .end packed-switch
.end method

.method public c(Lwm;)Ljava/lang/Object;
    .registers 15

    .prologue
    const/16 v6, 0x7a3

    iget v8, p0, Lx3;->a:I

    nop

    const/16 v6, 0xf3a

    sget-object v9, Lu40;->a:Lu40;

    nop

    const/16 v6, 0xd7f

    iget-object v10, p0, Lx3;->c:Ljava/lang/Object;

    nop

    const/16 v6, 0x778

    iget-object p0, p0, Lx3;->b:Ljava/lang/Object;

    nop

    const/4 v11, 0x0

    check-cast p0, Ljava/util/concurrent/Executor;

    packed-switch v8, :pswitch_data_98

    check-cast v10, Lzj0;

    const/16 v6, 0x43d

    new-instance v8, Ljava/util/concurrent/atomic/AtomicBoolean;

    nop

    const/16 v6, 0x309

    invoke-direct {v8, v11}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    const/16 v6, 0x317

    new-instance v11, Le31;

    nop

    const/4 v12, 0x1

    const/16 v6, 0x30e

    invoke-direct {v11, v8, v12}, Le31;-><init>(Ljava/util/concurrent/atomic/AtomicBoolean;I)V

    const/16 v6, 0x50d

    iget-object v12, p1, Lwm;->c:Lzt1;

    nop

    if-eqz v12, :cond_3d

    const/16 v6, 0x42e

    invoke-virtual {v12, v11, v9}, Lf1;->a(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    :cond_3d
    const/16 v6, 0x4ae

    new-instance v9, Lj8;

    nop

    const/16 v11, 0xc

    const/16 v6, 0x4b3

    move v0, v6

    move-object v1, v9

    move-object v2, v8

    move-object v3, p1

    move-object v4, v10

    move v5, v11

    invoke-direct/range {v1 .. v5}, Lj8;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    const/16 v6, 0x2a2

    invoke-interface {p0, v9}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    const/16 v6, 0x21

    sget-object p0, Lrg2;->a:Lrg2;

    nop

    check-cast p0, Ljava/lang/Object;

    return-object p0

    :pswitch_5c  #0x7
    check-cast v10, Ljq2;

    const/16 v6, 0x43d

    new-instance v8, Ljava/util/concurrent/atomic/AtomicBoolean;

    nop

    const/16 v6, 0x309

    invoke-direct {v8, v11}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    const/16 v6, 0x317

    new-instance v12, Le31;

    nop

    const/16 v6, 0x30e

    invoke-direct {v12, v8, v11}, Le31;-><init>(Ljava/util/concurrent/atomic/AtomicBoolean;I)V

    const/16 v6, 0x50d

    iget-object v11, p1, Lwm;->c:Lzt1;

    nop

    if-eqz v11, :cond_7e

    const/16 v6, 0x42e

    invoke-virtual {v11, v12, v9}, Lf1;->a(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    :cond_7e
    const/16 v6, 0x4ae

    new-instance v9, Lj8;

    nop

    const/4 v11, 0x7

    const/16 v6, 0x4b3

    move v0, v6

    move-object v1, v9

    move-object v2, v8

    move-object v3, p1

    move-object v4, v10

    move v5, v11

    invoke-direct/range {v1 .. v5}, Lj8;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    const/16 v6, 0x2a2

    invoke-interface {p0, v9}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    const-string/jumbo p0, "setForegroundAsync"

    return-object p0

    :pswitch_data_98
    .packed-switch 0x7
        :pswitch_5c  #00000007
    .end packed-switch
.end method

.method public h(Lk20;)Ljava/lang/Object;
    .registers 7

    .prologue
    const/16 v0, 0x778

    iget-object v2, p0, Lx3;->b:Ljava/lang/Object;

    nop

    check-cast v2, Ljava/lang/String;

    const/16 v0, 0xd7f

    iget-object p0, p0, Lx3;->c:Ljava/lang/Object;

    nop

    check-cast p0, Ll70;

    const-class v3, Landroid/content/Context;

    const/16 v0, 0x4e3

    invoke-virtual {p1, v3}, Lk20;->a(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/content/Context;

    const/16 v0, 0x11ee

    iget p0, p0, Ll70;->a:I

    nop

    const-string/jumbo v3, ""

    packed-switch p0, :pswitch_data_d0

    const/16 v0, 0xea

    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/16 v0, 0x4a

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0xbc4

    invoke-virtual {p0, p1}, Landroid/content/pm/PackageManager;->getInstallerPackageName(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    if-eqz p0, :cond_c3

    const/16 v0, 0xa7a

    invoke-static {p0}, Lcom/google/firebase/FirebaseCommonRegistrar;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    goto/16 :goto_c3

    :pswitch_3f  #0x1a
    const/16 v0, 0xea

    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const-string/jumbo v4, "android.hardware.type.television"

    const/16 v0, 0x184

    invoke-virtual {p0, v4}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    move-result p0

    if-eqz p0, :cond_54

    const-string/jumbo v3, "tv"

    goto :goto_c3

    :cond_54
    const/16 v0, 0xea

    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const-string/jumbo v4, "android.hardware.type.watch"

    const/16 v0, 0x184

    invoke-virtual {p0, v4}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    move-result p0

    if-eqz p0, :cond_69

    const-string/jumbo v3, "watch"

    goto :goto_c3

    :cond_69
    const/16 v0, 0xea

    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const-string/jumbo v4, "android.hardware.type.automotive"

    const/16 v0, 0x184

    invoke-virtual {p0, v4}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    move-result p0

    if-eqz p0, :cond_7e

    const-string/jumbo v3, "auto"

    goto :goto_c3

    :cond_7e
    const/16 v0, 0x1fc

    sget p0, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 v4, 0x1a

    if-lt p0, v4, :cond_c3

    const/16 v0, 0xea

    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const-string/jumbo p1, "android.hardware.type.embedded"

    const/16 v0, 0x184

    invoke-virtual {p0, p1}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    move-result p0

    if-eqz p0, :cond_c3

    const-string/jumbo v3, "embedded"

    goto :goto_c3

    :pswitch_9c  #0x19
    const/16 v0, 0x435

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object p0

    if-eqz p0, :cond_c3

    const/16 v0, 0x11d6

    iget p0, p0, Landroid/content/pm/ApplicationInfo;->minSdkVersion:I

    nop

    const/16 v0, 0x262

    invoke-static {p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    goto :goto_c3

    :pswitch_b0  #0x18
    const/16 v0, 0x435

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object p0

    if-eqz p0, :cond_c3

    const/16 v0, 0xcc1

    iget p0, p0, Landroid/content/pm/ApplicationInfo;->targetSdkVersion:I

    nop

    const/16 v0, 0x262

    invoke-static {p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v3

    :cond_c3
    :goto_c3
    const/16 v0, 0x8ff

    new-instance p0, Lmg;

    nop

    const/16 v0, 0xc47

    invoke-direct {p0, v2, v3}, Lmg;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    check-cast p0, Ljava/lang/Object;

    return-object p0

    :pswitch_data_d0
    .packed-switch 0x18
        :pswitch_b0  #00000018
        :pswitch_9c  #00000019
        :pswitch_3f  #0000001a
    .end packed-switch
.end method

.method public onAcknowledgePurchaseResponse(Lcom/android/billingclient/api/BillingResult;)V
    .registers 6

    .prologue
    const/16 v0, 0x7a3

    iget v2, p0, Lx3;->a:I

    nop

    const/16 v0, 0xd7f

    iget-object v3, p0, Lx3;->c:Ljava/lang/Object;

    nop

    const/16 v0, 0x778

    iget-object p0, p0, Lx3;->b:Ljava/lang/Object;

    nop

    check-cast p0, Lwh;

    packed-switch v2, :pswitch_data_44

    check-cast v3, Lnn1;

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x450

    invoke-virtual {p1}, Lcom/android/billingclient/api/BillingResult;->getResponseCode()I

    move-result p1

    if-nez p1, :cond_28

    const/16 v0, 0x4e0

    invoke-virtual {p0}, Lwh;->invoke()Ljava/lang/Object;

    goto :goto_2d

    :cond_28
    const/16 v0, 0x3f4

    invoke-virtual {v3}, Lnn1;->d()V

    :goto_2d
    return-void

    :pswitch_2e  #0xa
    check-cast v3, Lcom/tlsvpn/tlstunnel/services/ProMonitor;

    const/16 v0, 0x2d1

    sget v2, Lcom/tlsvpn/tlstunnel/services/ProMonitor;->e:I

    nop

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x4e0

    invoke-virtual {p0}, Lwh;->invoke()Ljava/lang/Object;

    const/16 v0, 0x4f7

    invoke-virtual {v3}, Landroid/app/Service;->stopSelf()V

    return-void

    :pswitch_data_44
    .packed-switch 0xa
        :pswitch_2e  #0000000a
    .end packed-switch
.end method

.method public onCancel()V
    .registers 5

    .prologue
    const/16 v0, 0x7a3

    iget v2, p0, Lx3;->a:I

    nop

    const/16 v0, 0xd7f

    iget-object v3, p0, Lx3;->c:Ljava/lang/Object;

    nop

    const/16 v0, 0x778

    iget-object p0, p0, Lx3;->b:Ljava/lang/Object;

    nop

    packed-switch v2, :pswitch_data_56

    check-cast p0, Lkc2;

    check-cast v3, Lu7;

    const/16 v0, 0xd5c

    invoke-virtual {p0}, Lkc2;->cancel()V

    const/16 v0, 0x1238

    invoke-virtual {v3}, Lu7;->run()V

    return-void

    :pswitch_21  #0x3
    check-cast p0, Landroid/animation/Animator;

    check-cast v3, Landroidx/fragment/app/u;

    const/16 v0, 0x798

    invoke-virtual {p0}, Landroid/animation/Animator;->end()V

    const/4 p0, 0x2

    const/16 v0, 0x1142

    invoke-static {p0}, Landroidx/fragment/app/p;->H(I)Z

    move-result p0

    if-eqz p0, :cond_54

    const/4 v0, -0x3

    new-instance p0, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v2, "Animator from operation "

    const/16 v0, 0x97

    invoke-direct {p0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x190

    invoke-virtual {p0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string/jumbo v2, " has been canceled."

    const/4 v0, 0x0

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string/jumbo v2, "FragmentManager"

    nop

    :cond_54
    return-void

    nop

    :pswitch_data_56
    .packed-switch 0x3
        :pswitch_21  #00000003
    .end packed-switch
.end method

.method public onComplete(Lcom/google/android/gms/tasks/Task;)V
    .registers 5

    .prologue
    const/16 v0, 0x778

    iget-object p1, p0, Lx3;->b:Ljava/lang/Object;

    nop

    check-cast p1, Lads_mobile_sdk/u13;

    const/16 v0, 0xd7f

    iget-object p0, p0, Lx3;->c:Ljava/lang/Object;

    nop

    check-cast p0, Lcom/google/android/gms/tasks/TaskCompletionSource;

    const/16 v0, 0x6c8

    iget-object v2, p1, Lads_mobile_sdk/u13;->f:Ljava/lang/Object;

    nop

    monitor-enter v2

    :try_start_14
    const/16 v0, 0x81f

    iget-object p1, p1, Lads_mobile_sdk/u13;->e:Ljava/util/HashSet;

    nop

    const/16 v0, 0xe62

    invoke-virtual {p1, p0}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    monitor-exit v2

    return-void

    :catchall_20
    move-exception p0

    monitor-exit v2
    :try_end_22
    .catchall {:try_start_14 .. :try_end_22} :catchall_20

    throw p0
.end method

.method public onConsentInfoUpdateSuccess()V
    .registers 6

    .prologue
    const/16 v0, 0x778

    iget-object v2, p0, Lx3;->b:Ljava/lang/Object;

    nop

    check-cast v2, Landroid/app/Activity;

    const/16 v0, 0xd7f

    iget-object p0, p0, Lx3;->c:Ljava/lang/Object;

    nop

    check-cast p0, Lcom/google/android/gms/internal/consent_sdk/zzj;

    const/16 v0, 0xca8

    new-instance v3, Ly3;

    nop

    const/16 v0, 0xd95

    invoke-direct {v3, p0, v2}, Ly3;-><init>(Lcom/google/android/gms/internal/consent_sdk/zzj;Landroid/app/Activity;)V

    const/16 v0, 0xa80

    invoke-static {v2}, Lcom/google/android/gms/internal/consent_sdk/zza;->zza(Landroid/content/Context;)Lcom/google/android/gms/internal/consent_sdk/zza;

    move-result-object p0

    const/16 v0, 0x8dd

    invoke-virtual {p0}, Lcom/google/android/gms/internal/consent_sdk/zza;->zzb()Lcom/google/android/gms/internal/consent_sdk/zzj;

    move-result-object v4

    const/16 v0, 0xfd0

    invoke-virtual {v4}, Lcom/google/android/gms/internal/consent_sdk/zzj;->canRequestAds()Z

    move-result v4

    if-eqz v4, :cond_33

    const/4 p0, 0x0

    const/16 v0, 0x829

    invoke-virtual {v3, p0}, Ly3;->a(Lch0;)V

    return-void

    :cond_33
    const/16 v0, 0xf87

    invoke-virtual {p0}, Lcom/google/android/gms/internal/consent_sdk/zza;->zzd()Lcom/google/android/gms/internal/consent_sdk/zzcr;

    move-result-object v4

    const/16 v0, 0xfc9

    invoke-virtual {v4}, Lcom/google/android/gms/internal/consent_sdk/zzcr;->zzc()V

    const/16 v0, 0x952

    invoke-virtual {p0}, Lcom/google/android/gms/internal/consent_sdk/zza;->zzc()Lcom/google/android/gms/internal/consent_sdk/zzbq;

    move-result-object p0

    const/16 v0, 0x8cb

    invoke-static {}, Lcom/google/android/gms/internal/consent_sdk/zzcz;->zza()V

    const/16 v0, 0xc90

    new-instance v4, Lcom/google/android/gms/internal/consent_sdk/zzbo;

    nop

    const/16 v0, 0x1223

    invoke-direct {v4, v2, v3}, Lcom/google/android/gms/internal/consent_sdk/zzbo;-><init>(Landroid/app/Activity;Lmv;)V

    const/16 v0, 0xbe0

    new-instance v2, Lcom/google/android/gms/internal/consent_sdk/zzbp;

    nop

    const/16 v0, 0x11c4

    invoke-direct {v2, v3}, Lcom/google/android/gms/internal/consent_sdk/zzbp;-><init>(Lmv;)V

    const/4 v3, 0x1

    const/16 v0, 0x7da

    invoke-virtual {p0, v4, v2, v3}, Lcom/google/android/gms/internal/consent_sdk/zzbq;->zzb(Lai2;Lzh2;Z)V

    return-void
.end method

.method public run()Ljava/lang/Object;
    .registers 5

    .prologue
    const/16 v0, 0x7a3

    iget v2, p0, Lx3;->a:I

    nop

    const/16 v0, 0xd7f

    iget-object v3, p0, Lx3;->c:Ljava/lang/Object;

    nop

    const/16 v0, 0x778

    iget-object p0, p0, Lx3;->b:Ljava/lang/Object;

    nop

    packed-switch v2, :pswitch_data_3a

    check-cast p0, Lo9;

    check-cast v3, Landroid/net/http/UrlResponseInfo;

    const/16 v0, 0x458

    invoke-static {v3}, Lr9;->b(Landroid/net/http/UrlResponseInfo;)Lr9;

    move-result-object v2

    const/16 v0, 0x295

    iget-object v3, p0, Lo9;->a:Lorg/chromium/net/UrlRequest$Callback;

    nop

    const/16 v0, 0x397

    iget-object p0, p0, Lo9;->b:Lq9;

    nop

    const/16 v0, 0xd7a

    invoke-virtual {v3, p0, v2}, Lorg/chromium/net/UrlRequest$Callback;->onResponseStarted(Lorg/chromium/net/UrlRequest;Lorg/chromium/net/UrlResponseInfo;)V

    const/4 p0, 0x0

    return-object p0

    :pswitch_2d  #0x1
    check-cast p0, Lc9;

    check-cast v3, Ljava/net/URL;

    const/16 v0, 0xf51

    invoke-virtual {p0, v3}, Lc9;->c(Ljava/net/URL;)Ljava/net/URLConnection;

    move-result-object p0

    check-cast p0, Ljava/lang/Object;

    return-object p0

    :pswitch_data_3a
    .packed-switch 0x1
        :pswitch_2d  #00000001
    .end packed-switch
.end method

.method public run()V
    .registers 14

    .prologue
    const/16 v6, 0x778

    iget-object v8, p0, Lx3;->b:Ljava/lang/Object;

    nop

    check-cast v8, Lyu0;

    const/16 v6, 0xd7f

    iget-object p0, p0, Lx3;->c:Ljava/lang/Object;

    nop

    check-cast p0, Ljava/nio/ByteBuffer;

    const/16 v6, 0x4ac

    iget-object v9, v8, Lyu0;->n:Ljava/nio/channels/ReadableByteChannel;

    nop

    const/4 v10, 0x1

    const/4 v11, -0x1

    if-eqz v9, :cond_28

    const/16 v6, 0x8fe

    iget v12, v8, Lyu0;->w:I

    nop

    add-int/2addr v12, v10

    const/16 v6, 0xf3d

    iput v12, v8, Lyu0;->w:I

    const/16 v6, 0x115f

    invoke-interface {v9, p0}, Ljava/nio/channels/ReadableByteChannel;->read(Ljava/nio/ByteBuffer;)I

    move-result v9

    goto :goto_29

    :cond_28
    move v9, v11

    :goto_29
    const/16 v6, 0x63c

    iget-object v12, v8, Lyu0;->a:Lvu0;

    nop

    if-eq v9, v11, :cond_53

    const/16 v6, 0x386

    iget-object v8, v8, Lyu0;->o:Lyh2;

    nop

    const/4 v6, -0x6

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x592

    new-instance v9, Lz3;

    nop

    const/4 v10, 0x4

    const/16 v6, 0x72a

    move v0, v6

    move-object v1, v9

    move-object v2, v12

    move-object v3, v8

    move-object v4, p0

    move v5, v10

    invoke-direct/range {v1 .. v5}, Lz3;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    const-string/jumbo p0, "onReadCompleted"

    const/16 v6, 0xcd1

    invoke-virtual {v12, v9, p0}, Lvu0;->b(Lzu0;Ljava/lang/String;)V

    return-void

    :cond_53
    const/16 v6, 0x4ac

    iget-object p0, v8, Lyu0;->n:Ljava/nio/channels/ReadableByteChannel;

    nop

    if-eqz p0, :cond_5f

    const/16 v6, 0xbe8

    invoke-interface {p0}, Ljava/nio/channels/Channel;->close()V

    :cond_5f
    const/16 v6, 0x110d

    iget-object p0, v8, Lyu0;->f:Ljava/util/concurrent/atomic/AtomicInteger;

    nop

    const/4 v9, 0x5

    const/4 v11, 0x7

    const/16 v6, 0x10b4

    invoke-virtual {p0, v9, v11}, Ljava/util/concurrent/atomic/AtomicInteger;->compareAndSet(II)Z

    move-result p0

    if-eqz p0, :cond_9c

    const/16 v6, 0xc63

    new-instance p0, Lpu0;

    nop

    const/4 v9, 0x2

    const/16 v6, 0xed9

    invoke-direct {p0, v8, v9}, Lpu0;-><init>(Lyu0;I)V

    const-string/jumbo v9, "fireDisconnect"

    const/16 v6, 0xc13

    invoke-virtual {v8, p0, v9}, Lyu0;->c(Ljava/lang/Runnable;Ljava/lang/String;)V

    const/16 v6, 0x386

    iget-object p0, v8, Lyu0;->o:Lyh2;

    nop

    const/4 v6, -0x6

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x571

    new-instance v8, Luu0;

    nop

    const/16 v6, 0x565

    invoke-direct {v8, v12, p0, v10}, Luu0;-><init>(Lvu0;Lorg/chromium/net/UrlResponseInfo;I)V

    const-string/jumbo p0, "onSucceeded"

    const/16 v6, 0xe14

    invoke-virtual {v12, v8, p0}, Lvu0;->c(Ljava/lang/Runnable;Ljava/lang/String;)V

    :cond_9c
    return-void
.end method
