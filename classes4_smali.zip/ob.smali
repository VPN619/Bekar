.class public final Lob;
.super Landroid/content/BroadcastReceiver;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    iput p1, p0, Lob;->a:I

    iput-object p2, p0, Lob;->b:Ljava/lang/Object;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .registers 46

    .prologue
    move-object/from16 v9, p0

    move-object/from16 v10, p2

    const/16 v7, 0x7be

    iget v11, v9, Lob;->a:I

    nop

    const-string/jumbo v12, "cId"

    const-string/jumbo v13, "SERVERLURPL"

    const-string/jumbo v14, ""

    const-string/jumbo v15, "cTp"

    const-string/jumbo v16, "server"

    const-string/jumbo v17, "psrvslctd"

    const-string/jumbo v19, "admobIniciado"

    const-string/jumbo v22, "STATUS:"

    const-string/jumbo v23, "RPL"

    const-string/jumbo v24, "SERVERRPL"

    const-string/jumbo v20, "dipro"

    const/16 v27, 0x3a

    const/16 v29, 0x0

    const-string/jumbo v21, "pVacTd"

    const/16 v7, 0x930

    iget-object v9, v9, Lob;->b:Ljava/lang/Object;

    nop

    packed-switch v11, :pswitch_data_1262

    check-cast v9, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;

    const/16 v7, 0x105e

    iget-object v11, v9, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->e:Lw82;

    nop

    if-eqz v10, :cond_516

    const/16 v7, 0x2f

    invoke-virtual {v10}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v12

    if-eqz v12, :cond_516

    const/16 v7, 0x51

    invoke-virtual {v12}, Ljava/lang/String;->hashCode()I

    move-result v13

    const-string/jumbo v19, "m] ["

    const-string/jumbo v18, "m | max:"

    move-object/from16 v31, v11

    const-string/jumbo v11, "s) [left:"

    move/from16 v32, v13

    const-string/jumbo v13, "m) ou ("

    move-object/from16 v33, v14

    const-string/jumbo v14, "Renew"

    const-wide/16 v34, 0x3c

    const-wide/16 v36, 0x3e8

    move-object/from16 v38, v14

    const-string/jumbo v14, "VPN"

    const-wide/32 v39, 0x493e0

    const-string/jumbo v41, "renewTimer"

    const-string/jumbo v42, "notificacao"

    sparse-switch v32, :sswitch_data_1276

    goto/16 :goto_516

    :sswitch_7c
    const-string/jumbo v10, "reconnect"

    const/4 v7, -0x7

    invoke-virtual {v12, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_88

    goto/16 :goto_516

    :cond_88
    const-string/jumbo v10, "(ServicoVpn) cmdReceiver: RECONNECT"

    nop

    const/16 v7, 0x1c9

    sget v10, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->q:I

    nop

    const/16 v7, 0x496

    invoke-virtual {v9}, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->d()V

    goto/16 :goto_516

    :sswitch_98
    const/4 v7, -0x7

    move-object/from16 v0, v20

    invoke-virtual {v12, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_a3

    goto/16 :goto_516

    :cond_a3
    const/16 v7, 0x1ff

    sget v10, Lmi2;->o:I

    nop

    const/4 v11, 0x3

    if-ne v10, v11, :cond_516

    const/16 v7, 0x6cc

    sget-boolean v10, Lmi2;->l:Z

    nop

    if-eqz v10, :cond_e6

    const/16 v7, 0x1c9

    sget v10, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->q:I

    nop

    const/16 v7, 0x177

    move-object/from16 v0, v31

    invoke-virtual {v0}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Landroid/content/SharedPreferences;

    const/4 v7, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x7a

    invoke-interface {v10}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v10

    const/4 v11, 0x0

    const/16 v7, 0x48

    move-object/from16 v0, v17

    invoke-interface {v10, v0, v11}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/16 v7, 0x56

    move-object/from16 v0, v16

    invoke-interface {v10, v0, v11}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/16 v7, 0x6f

    invoke-interface {v10}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/16 v7, 0x496

    invoke-virtual {v9}, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->d()V

    goto/16 :goto_516

    :cond_e6
    const/16 v7, 0x4f

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->f:Lkg1;

    nop

    if-eqz v10, :cond_134

    const/16 v7, 0x26f

    sget-wide v11, Lmi2;->i:J

    nop

    const/16 v7, 0x1bd

    iget-object v13, v10, Lkg1;->u:Landroid/app/Notification;

    nop

    const/16 v7, 0x210

    iput-wide v11, v13, Landroid/app/Notification;->when:J

    const/4 v11, 0x1

    const/16 v7, 0x226

    invoke-virtual {v10, v11}, Lkg1;->d(Z)V

    const/16 v7, 0x4f

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->f:Lkg1;

    nop

    if-eqz v10, :cond_12d

    const/16 v7, 0x2db

    iput-boolean v11, v10, Lkg1;->j:Z

    :try_start_10c
    const/16 v7, 0xe9

    invoke-virtual {v9}, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->a()Landroid/app/NotificationManager;

    move-result-object v10

    const/16 v7, 0x4f

    iget-object v9, v9, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->f:Lkg1;

    nop

    if-eqz v9, :cond_126

    const/16 v7, 0x1df

    invoke-virtual {v9}, Lkg1;->b()Landroid/app/Notification;

    move-result-object v9

    const/16 v7, 0x1be

    invoke-virtual {v10, v11, v9}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    goto/16 :goto_516

    :cond_126
    const/4 v7, 0x5

    move-object/from16 v0, v42

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v29
    :try_end_12d
    .catch Ljava/lang/Exception; {:try_start_10c .. :try_end_12d} :catch_516

    :cond_12d
    const/4 v7, 0x5

    move-object/from16 v0, v42

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v29

    :cond_134
    const/4 v7, 0x5

    move-object/from16 v0, v42

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v29

    :sswitch_13b
    const/4 v7, -0x7

    move-object/from16 v0, v21

    invoke-virtual {v12, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_146

    goto/16 :goto_516

    :cond_146
    const/16 v7, 0x1ff

    sget v10, Lmi2;->o:I

    nop

    const/4 v11, 0x3

    if-ne v10, v11, :cond_516

    const/16 v7, 0x4f

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->f:Lkg1;

    nop

    if-eqz v10, :cond_1ac

    const/16 v7, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v11

    const/16 v7, 0x1bd

    iget-object v10, v10, Lkg1;->u:Landroid/app/Notification;

    nop

    const/16 v7, 0x210

    iput-wide v11, v10, Landroid/app/Notification;->when:J

    const/16 v7, 0x4f

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->f:Lkg1;

    nop

    if-eqz v10, :cond_1a5

    const/4 v11, 0x0

    const/16 v7, 0x226

    invoke-virtual {v10, v11}, Lkg1;->d(Z)V

    const/16 v7, 0x4f

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->f:Lkg1;

    nop

    if-eqz v10, :cond_19e

    const/4 v11, 0x1

    const/16 v7, 0x2db

    iput-boolean v11, v10, Lkg1;->j:Z

    :try_start_17d
    const/16 v7, 0xe9

    invoke-virtual {v9}, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->a()Landroid/app/NotificationManager;

    move-result-object v10

    const/16 v7, 0x4f

    iget-object v9, v9, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->f:Lkg1;

    nop

    if-eqz v9, :cond_197

    const/16 v7, 0x1df

    invoke-virtual {v9}, Lkg1;->b()Landroid/app/Notification;

    move-result-object v9

    const/16 v7, 0x1be

    invoke-virtual {v10, v11, v9}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    goto/16 :goto_516

    :cond_197
    const/4 v7, 0x5

    move-object/from16 v0, v42

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v29
    :try_end_19e
    .catch Ljava/lang/Exception; {:try_start_17d .. :try_end_19e} :catch_516

    :cond_19e
    const/4 v7, 0x5

    move-object/from16 v0, v42

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v29

    :cond_1a5
    const/4 v7, 0x5

    move-object/from16 v0, v42

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v29

    :cond_1ac
    const/4 v7, 0x5

    move-object/from16 v0, v42

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v29

    :sswitch_1b3
    const/4 v7, -0x7

    move-object/from16 v0, v24

    invoke-virtual {v12, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_1be

    goto/16 :goto_516

    :cond_1be
    const/16 v7, 0x329

    iget-object v12, v9, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->a:Lcom/tlsvpn/tlstunnel/services/VpnConnection;

    nop

    if-eqz v12, :cond_516

    const/16 v7, 0x1ff

    sget v12, Lmi2;->o:I

    nop

    const/4 v14, 0x3

    if-eq v12, v14, :cond_1cf

    goto/16 :goto_516

    :cond_1cf
    const/16 v7, 0x8d

    move-object/from16 v0, v23

    invoke-virtual {v10, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    if-eqz v12, :cond_516

    const/16 v7, 0x7c

    invoke-static {v12}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v14

    if-eqz v14, :cond_1e3

    goto/16 :goto_516

    :cond_1e3
    const/4 v14, 0x1

    new-array v0, v14, [C

    move-object/from16 v16, v0

    const/16 v17, 0x0

    aput-char v27, v16, v17

    const/16 v7, 0x31

    move-object/from16 v0, v16

    invoke-static {v12, v0}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v16

    const/16 v7, 0x24

    move-object/from16 v0, v16

    move/from16 v1, v17

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v16

    check-cast v16, Ljava/lang/String;

    const/16 v7, 0xa8

    move/from16 v0, v17

    invoke-virtual {v10, v15, v0}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v10

    const/16 v7, 0x272

    sget-object v15, Lmi2;->m:Ljava/lang/String;

    nop

    const/16 v7, 0x84

    move-object/from16 v0, v16

    invoke-static {v0, v15}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v15

    if-eqz v15, :cond_516

    const/4 v15, 0x2

    if-ne v10, v15, :cond_516

    :try_start_21a
    new-array v10, v14, [C

    aput-char v27, v10, v17

    const/16 v7, 0x31

    invoke-static {v12, v10}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v10

    const/16 v7, 0x24

    move/from16 v0, v17

    invoke-interface {v10, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    const/16 v7, 0x47

    invoke-virtual {v10}, Ljava/lang/String;->length()I

    move-result v10

    const/4 v14, 0x1

    new-array v15, v14, [C

    aput-char v27, v15, v17

    const/16 v7, 0x31

    invoke-static {v12, v15}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v15

    const/16 v7, 0x24

    invoke-interface {v15, v14}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Ljava/lang/String;

    const/16 v7, 0x47

    invoke-virtual {v15}, Ljava/lang/String;->length()I

    move-result v14

    add-int/2addr v10, v14

    const/16 v28, 0x2

    add-int/lit8 v10, v10, 0x2

    const/16 v17, 0x0

    const/16 v7, 0x21c

    move/from16 v0, v17

    invoke-static {v12, v0, v10}, Lc72;->z0(Ljava/lang/CharSequence;II)Ljava/lang/CharSequence;

    move-result-object v10

    const/16 v7, 0xcb

    invoke-virtual {v10}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v14
    :try_end_262
    .catch Ljava/lang/Exception; {:try_start_21a .. :try_end_262} :catch_265

    :goto_262
    const/16 v17, 0x0

    goto :goto_268

    :catch_265
    move-object/from16 v14, v33

    goto :goto_262

    :goto_268
    const/16 v7, 0x92

    move-object/from16 v0, v22

    move/from16 v1, v17

    invoke-static {v14, v0, v1}, Lk72;->k0(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v10

    if-eqz v10, :cond_516

    const/4 v10, 0x1

    :try_start_275
    new-array v12, v10, [C

    aput-char v27, v12, v17

    const/16 v7, 0x31

    invoke-static {v14, v12}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v12

    const/16 v7, 0x24

    invoke-interface {v12, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/String;

    const/16 v7, 0xd35

    invoke-static {v12}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v20
    :try_end_28d
    .catch Ljava/lang/Exception; {:try_start_275 .. :try_end_28d} :catch_28e

    goto :goto_290

    :catch_28e
    const-wide/16 v20, 0x0

    :goto_290
    const-wide/32 v14, 0xea60

    mul-long v14, v14, v20

    const/16 v7, 0x29a

    sget-wide v22, Lmi2;->j:J

    nop

    cmp-long v10, v14, v22

    if-lez v10, :cond_2a2

    sub-long v24, v14, v22

    add-long v39, v24, v39

    :cond_2a2
    move-wide/from16 v24, v14

    move-wide/from16 v14, v39

    const/4 v7, -0x3

    new-instance v10, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v12, "[REPLY] Exibir notificação em ("

    const/16 v7, 0x97

    invoke-direct {v10, v12}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    move-wide/from16 v26, v22

    div-long v22, v14, v36

    move-wide/from16 v32, v14

    div-long v14, v22, v34

    const/16 v7, 0x83

    invoke-virtual {v10, v14, v15}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    invoke-virtual {v10, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v7, 0x83

    move-wide/from16 v0, v22

    invoke-virtual {v10, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v7, 0x83

    move-wide/from16 v0, v20

    invoke-virtual {v10, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    move-object/from16 v0, v18

    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    div-long v22, v26, v36

    div-long v22, v22, v34

    const/16 v7, 0x83

    move-wide/from16 v0, v22

    invoke-virtual {v10, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    move-object/from16 v0, v19

    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    move-object/from16 v0, v16

    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v11, 0x5d

    const/16 v7, 0x1b

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v7, -0x2

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    move-object/from16 v14, v38

    nop

    const/16 v17, 0x0

    const/16 v7, 0xd20

    move/from16 v0, v17

    iput-boolean v0, v9, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->c:Z

    const/16 v7, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v10

    add-long v10, v10, v24

    const/16 v7, 0x40a

    sput-wide v10, Lmi2;->i:J

    const/16 v7, 0x101

    sget-boolean v10, Lmi2;->n:Z

    nop

    if-nez v10, :cond_36f

    const/16 v7, 0x4f

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->f:Lkg1;

    nop

    if-eqz v10, :cond_368

    const/16 v7, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v11

    add-long v11, v11, v24

    const/16 v7, 0x1bd

    iget-object v10, v10, Lkg1;->u:Landroid/app/Notification;

    nop

    const/16 v7, 0x210

    iput-wide v11, v10, Landroid/app/Notification;->when:J

    const/16 v7, 0x4f

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->f:Lkg1;

    nop

    if-eqz v10, :cond_361

    const/4 v11, 0x1

    const/16 v7, 0x226

    invoke-virtual {v10, v11}, Lkg1;->d(Z)V

    :try_start_341
    const/16 v7, 0xe9

    invoke-virtual {v9}, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->a()Landroid/app/NotificationManager;

    move-result-object v10

    const/16 v7, 0x4f

    iget-object v12, v9, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->f:Lkg1;

    nop

    if-eqz v12, :cond_35a

    const/16 v7, 0x1df

    invoke-virtual {v12}, Lkg1;->b()Landroid/app/Notification;

    move-result-object v12

    const/16 v7, 0x1be

    invoke-virtual {v10, v11, v12}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    goto :goto_36f

    :cond_35a
    const/4 v7, 0x5

    move-object/from16 v0, v42

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v29
    :try_end_361
    .catch Ljava/lang/Exception; {:try_start_341 .. :try_end_361} :catch_36f

    :cond_361
    const/4 v7, 0x5

    move-object/from16 v0, v42

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v29

    :cond_368
    const/4 v7, 0x5

    move-object/from16 v0, v42

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v29

    :catch_36f
    :cond_36f
    :goto_36f
    const/16 v7, 0x3e1

    iget-boolean v10, v9, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->d:Z

    nop

    if-nez v10, :cond_37d

    const/16 v7, 0x101

    sget-boolean v10, Lmi2;->n:Z

    nop

    if-eqz v10, :cond_516

    :cond_37d
    const/16 v7, 0xe9

    invoke-virtual {v9}, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->a()Landroid/app/NotificationManager;

    move-result-object v10

    const/4 v15, 0x2

    const/16 v7, 0x2f4

    invoke-virtual {v10, v15}, Landroid/app/NotificationManager;->cancel(I)V

    const/16 v7, 0x133

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->b:Ljava/util/Timer;

    nop

    if-eqz v10, :cond_3a9

    :try_start_390
    const/16 v7, 0x4b1

    invoke-virtual {v10}, Ljava/util/Timer;->cancel()V

    const/16 v7, 0x133

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->b:Ljava/util/Timer;

    nop

    if-eqz v10, :cond_3a2

    const/16 v7, 0x31c

    invoke-virtual {v10}, Ljava/util/Timer;->purge()I

    goto :goto_3a9

    :cond_3a2
    const/4 v7, 0x5

    move-object/from16 v0, v41

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v29
    :try_end_3a9
    .catch Ljava/lang/Exception; {:try_start_390 .. :try_end_3a9} :catch_3a9

    :catch_3a9
    :cond_3a9
    :goto_3a9
    const/16 v7, 0x351

    new-instance v10, Ljava/util/Timer;

    nop

    const/16 v7, 0x477

    invoke-direct {v10}, Ljava/util/Timer;-><init>()V

    const/16 v7, 0x2fa

    iput-object v10, v9, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->b:Ljava/util/Timer;

    :try_start_3b7
    const/16 v7, 0x393

    new-instance v11, Lp12;

    nop

    const/16 v7, 0x177

    move-object/from16 v0, v31

    invoke-virtual {v0}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Landroid/content/SharedPreferences;

    const/4 v7, -0x6

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x46b

    move-object/from16 v0, v16

    invoke-direct {v11, v9, v0, v12}, Lp12;-><init>(Lcom/tlsvpn/tlstunnel/services/ServicoVpn;Ljava/lang/String;Landroid/content/SharedPreferences;)V

    move-wide/from16 v12, v32

    const/16 v7, 0x4e8

    invoke-virtual {v10, v11, v12, v13}, Ljava/util/Timer;->schedule(Ljava/util/TimerTask;J)V
    :try_end_3d8
    .catch Ljava/lang/Exception; {:try_start_3b7 .. :try_end_3d8} :catch_516

    goto/16 :goto_516

    :sswitch_3da
    const-string/jumbo v10, "stopVpn"

    const/4 v7, -0x7

    invoke-virtual {v12, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_3e6

    goto/16 :goto_516

    :cond_3e6
    const-string/jumbo v10, "(ServicoVpn) cmdReceiver: STOP_VPN"

    nop

    const/16 v7, 0x1c9

    sget v10, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->q:I

    nop

    const/16 v7, 0x1163

    invoke-virtual {v9}, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->c()V

    goto/16 :goto_516

    :sswitch_3f6
    move-object/from16 v14, v38

    const-string/jumbo v15, "timeLeft"

    const/4 v7, -0x7

    invoke-virtual {v12, v15}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-nez v12, :cond_404

    goto/16 :goto_516

    :cond_404
    const-string/jumbo v12, "serverhost"

    const/16 v7, 0x8d

    invoke-virtual {v10, v12}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    const/4 v7, -0x6

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string/jumbo v15, "mLeft"

    const/16 v17, 0x0

    const/16 v7, 0xa8

    move/from16 v0, v17

    invoke-virtual {v10, v15, v0}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v10

    const v15, 0xea60

    mul-int/2addr v15, v10

    int-to-long v15, v15

    const/16 v7, 0x29a

    sget-wide v20, Lmi2;->j:J

    nop

    cmp-long v17, v15, v20

    if-lez v17, :cond_433

    sub-long v15, v15, v20

    add-long v39, v15, v39

    :cond_430
    :goto_430
    move-wide/from16 v15, v39

    goto :goto_441

    :cond_433
    const/16 v7, 0x380

    iget-boolean v15, v9, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->c:Z

    nop

    if-nez v15, :cond_43e

    const/16 v15, 0xf

    if-ge v10, v15, :cond_430

    :cond_43e
    const-wide/16 v39, 0x3a98

    goto :goto_430

    :goto_441
    const/4 v7, -0x3

    new-instance v17, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v22, "[TIMELEFT] Exibir notificação em ("

    const/16 v7, 0x97

    move-object/from16 v0, v17

    move-object/from16 v1, v22

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    div-long v22, v15, v36

    move-wide/from16 v24, v20

    div-long v20, v22, v34

    const/16 v7, 0x83

    move-object/from16 v0, v17

    move-wide/from16 v1, v20

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    move-object/from16 v0, v17

    invoke-virtual {v0, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v7, 0x83

    move-object/from16 v0, v17

    move-wide/from16 v1, v22

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    move-object/from16 v0, v17

    invoke-virtual {v0, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v7, 0x33

    move-object/from16 v0, v17

    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    div-long v20, v24, v36

    div-long v20, v20, v34

    const/16 v7, 0x83

    move-object/from16 v0, v17

    move-wide/from16 v1, v20

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v19

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    move-object/from16 v0, v17

    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v11, 0x5d

    const/16 v7, 0x1b

    move-object/from16 v0, v17

    invoke-virtual {v0, v11}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v7, -0x2

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    nop

    const/16 v7, 0x3e1

    iget-boolean v10, v9, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->d:Z

    nop

    if-nez v10, :cond_4be

    const/16 v7, 0x101

    sget-boolean v10, Lmi2;->n:Z

    nop

    if-eqz v10, :cond_516

    :cond_4be
    const/16 v7, 0xe9

    invoke-virtual {v9}, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->a()Landroid/app/NotificationManager;

    move-result-object v10

    const/4 v11, 0x2

    const/16 v7, 0x2f4

    invoke-virtual {v10, v11}, Landroid/app/NotificationManager;->cancel(I)V

    const/16 v7, 0x133

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->b:Ljava/util/Timer;

    nop

    if-eqz v10, :cond_4ea

    :try_start_4d1
    const/16 v7, 0x4b1

    invoke-virtual {v10}, Ljava/util/Timer;->cancel()V

    const/16 v7, 0x133

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->b:Ljava/util/Timer;

    nop

    if-eqz v10, :cond_4e3

    const/16 v7, 0x31c

    invoke-virtual {v10}, Ljava/util/Timer;->purge()I

    goto :goto_4ea

    :cond_4e3
    const/4 v7, 0x5

    move-object/from16 v0, v41

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v29
    :try_end_4ea
    .catch Ljava/lang/Exception; {:try_start_4d1 .. :try_end_4ea} :catch_4ea

    :catch_4ea
    :cond_4ea
    :goto_4ea
    const/16 v7, 0x351

    new-instance v10, Ljava/util/Timer;

    nop

    const/16 v7, 0x477

    invoke-direct {v10}, Ljava/util/Timer;-><init>()V

    const/16 v7, 0x2fa

    iput-object v10, v9, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->b:Ljava/util/Timer;

    :try_start_4f8
    const/16 v7, 0x393

    new-instance v11, Lp12;

    nop

    const/16 v7, 0x177

    move-object/from16 v0, v31

    invoke-virtual {v0}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Landroid/content/SharedPreferences;

    const/4 v7, -0x6

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x46b

    invoke-direct {v11, v9, v12, v13}, Lp12;-><init>(Lcom/tlsvpn/tlstunnel/services/ServicoVpn;Ljava/lang/String;Landroid/content/SharedPreferences;)V

    const/16 v7, 0x4e8

    move-wide v0, v15

    invoke-virtual {v10, v11, v0, v1}, Ljava/util/Timer;->schedule(Ljava/util/TimerTask;J)V
    :try_end_516
    .catch Ljava/lang/Exception; {:try_start_4f8 .. :try_end_516} :catch_516

    :catch_516
    :cond_516
    :goto_516
    return-void

    :pswitch_517  #0x7
    check-cast v9, Lg12;

    if-eqz v10, :cond_97e

    const/16 v7, 0x2f

    invoke-virtual {v10}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v11

    if-eqz v11, :cond_97e

    const/16 v7, 0x51

    invoke-virtual {v11}, Ljava/lang/String;->hashCode()I

    move-result v14

    const v16, -0x65ac5055

    move/from16 v0, v16

    if-eq v14, v0, :cond_5b3

    const v10, -0x3bf7bee8

    if-eq v14, v10, :cond_573

    const v10, 0x53d44a42

    if-eq v14, v10, :cond_53c

    goto/16 :goto_97e

    :cond_53c
    const/4 v7, -0x7

    invoke-virtual {v11, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_545

    goto/16 :goto_97e

    :cond_545
    const/16 v7, 0x325

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->getViewLifecycleOwner()Lh11;

    move-result-object v10

    const/4 v7, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x341

    invoke-static {v10}, Lns2;->m(Lh11;)Lc11;

    move-result-object v10

    const/16 v7, 0x1f0

    new-instance v11, Le12;

    nop

    move-object/from16 v12, v29

    const/16 v17, 0x0

    const/16 v7, 0x21b

    move/from16 v0, v17

    invoke-direct {v11, v9, v12, v0}, Le12;-><init>(Lg12;Lvx;I)V

    const/4 v14, 0x3

    const/16 v7, 0xb3

    move v0, v7

    move-object v1, v10

    move-object v2, v12

    move-object v3, v12

    move-object v4, v11

    move v5, v14

    invoke-static/range {v1 .. v5}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    goto/16 :goto_97e

    :cond_573
    move-object/from16 v12, v29

    const/4 v7, -0x7

    move-object/from16 v0, v21

    invoke-virtual {v11, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_580

    goto/16 :goto_97e

    :cond_580
    const/16 v7, 0x101

    sget-boolean v10, Lmi2;->n:Z

    nop

    if-eqz v10, :cond_97e

    const/16 v7, 0x325

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->getViewLifecycleOwner()Lh11;

    move-result-object v10

    const/4 v7, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x341

    invoke-static {v10}, Lns2;->m(Lh11;)Lc11;

    move-result-object v10

    const/16 v7, 0x24d

    new-instance v11, Lf12;

    nop

    const/16 v17, 0x0

    const/16 v7, 0x1ad

    move/from16 v0, v17

    invoke-direct {v11, v9, v12, v0}, Lf12;-><init>(Lg12;Lvx;I)V

    const/4 v14, 0x3

    const/16 v7, 0xb3

    move v0, v7

    move-object v1, v10

    move-object v2, v12

    move-object v3, v12

    move-object v4, v11

    move v5, v14

    invoke-static/range {v1 .. v5}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    goto/16 :goto_97e

    :cond_5b3
    const/16 v17, 0x0

    const/4 v7, -0x7

    move-object/from16 v0, v24

    invoke-virtual {v11, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_97e

    const/16 v7, 0xa8

    move/from16 v0, v17

    invoke-virtual {v10, v12, v0}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v11

    const/16 v7, 0xa8

    move/from16 v0, v17

    invoke-virtual {v10, v15, v0}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v12

    const/4 v15, 0x2

    if-eq v12, v15, :cond_5e2

    const/4 v14, 0x1

    if-ne v12, v14, :cond_97e

    const/16 v7, 0x81c

    iget v12, v9, Lg12;->z:I

    nop

    if-eq v11, v12, :cond_5e2

    const/16 v7, 0xc26

    iget v12, v9, Lg12;->A:I

    nop

    if-ne v11, v12, :cond_97e

    :cond_5e2
    const/16 v7, 0x8d

    move-object/from16 v0, v23

    invoke-virtual {v10, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const/4 v7, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v11, 0x1

    new-array v12, v11, [C

    const/16 v17, 0x0

    aput-char v27, v12, v17

    const/16 v7, 0x31

    invoke-static {v10, v12}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v12

    const/16 v7, 0x17d

    invoke-interface {v12}, Ljava/util/List;->size()I

    move-result v12

    if-le v12, v11, :cond_97e

    new-array v12, v11, [C

    aput-char v27, v12, v17

    const/16 v7, 0x31

    invoke-static {v10, v12}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v12

    const/16 v7, 0x24

    move/from16 v0, v17

    invoke-interface {v12, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/String;

    new-array v13, v11, [C

    aput-char v27, v13, v17

    const/16 v7, 0x31

    invoke-static {v10, v13}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v13

    const/16 v7, 0x24

    invoke-interface {v13, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/String;

    const/16 v7, 0x8e

    invoke-static {v13}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v13

    const/16 v7, 0x47

    invoke-virtual {v12}, Ljava/lang/String;->length()I

    move-result v14

    const/16 v28, 0x2

    add-int/lit8 v14, v14, 0x2

    const/16 v7, 0x262

    invoke-static {v13}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v15

    const/16 v7, 0x47

    invoke-virtual {v15}, Ljava/lang/String;->length()I

    move-result v15

    add-int/2addr v15, v14

    const/16 v7, 0x21c

    move/from16 v0, v17

    invoke-static {v10, v0, v15}, Lc72;->z0(Ljava/lang/CharSequence;II)Ljava/lang/CharSequence;

    move-result-object v10

    const/16 v7, 0xcb

    invoke-virtual {v10}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v10

    sub-int/2addr v13, v11

    const/16 v7, 0x82f

    iget-object v11, v9, Lg12;->B:Ljava/util/ArrayList;

    nop

    const/16 v7, 0x1089

    invoke-virtual {v11, v12}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v14

    if-eqz v14, :cond_664

    goto/16 :goto_97e

    :cond_664
    if-ltz v13, :cond_97e

    const/16 v7, 0x42

    iget-object v14, v9, Lg12;->y:Ll12;

    nop

    const-string/jumbo v15, "serverListAdapter"

    if-eqz v14, :cond_977

    const/16 v7, 0x44

    iget-object v14, v14, Ll12;->f:Ljava/util/ArrayList;

    nop

    const/16 v7, 0x5d5

    invoke-interface {v14}, Ljava/util/Collection;->size()I

    move-result v14

    if-ge v13, v14, :cond_97e

    const/16 v17, 0x0

    const/16 v7, 0x92

    move-object/from16 v0, v22

    move/from16 v1, v17

    invoke-static {v10, v0, v1}, Lk72;->k0(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v14

    const-string/jumbo v16, "-status"

    if-eqz v14, :cond_8c1

    const/16 v7, 0x174

    invoke-virtual {v11, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v11, 0x1

    new-array v14, v11, [C

    aput-char v27, v14, v17

    const/16 v7, 0x31

    invoke-static {v10, v14}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v14

    const/16 v7, 0x24

    invoke-interface {v14, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/lang/String;

    const/16 v7, 0x8e

    invoke-static {v14}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v14

    new-array v0, v11, [C

    move-object/from16 v18, v0

    aput-char v27, v18, v17

    const/16 v7, 0x31

    move-object/from16 v0, v18

    invoke-static {v10, v0}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v18

    const/16 v19, 0x2

    const/16 v7, 0x24

    move-object/from16 v0, v18

    move/from16 v1, v19

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v18

    check-cast v18, Ljava/lang/String;

    const/16 v7, 0x8e

    move-object/from16 v0, v18

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v18

    new-array v0, v11, [C

    move-object/from16 v19, v0

    aput-char v27, v19, v17

    const/16 v7, 0x31

    move-object/from16 v0, v19

    invoke-static {v10, v0}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v19

    const/16 v20, 0x3

    const/16 v7, 0x24

    move-object/from16 v0, v19

    move/from16 v1, v20

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v19

    check-cast v19, Ljava/lang/String;

    const/16 v7, 0x8e

    move-object/from16 v0, v19

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v19

    const/16 v21, 0x4

    :try_start_6f6
    new-array v0, v11, [C

    move-object/from16 v22, v0

    aput-char v27, v22, v17

    const/16 v7, 0x31

    move-object/from16 v0, v22

    invoke-static {v10, v0}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v11

    const/16 v7, 0x24

    move/from16 v0, v21

    invoke-interface {v11, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    const/16 v7, 0x8e

    invoke-static {v11}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v11
    :try_end_714
    .catch Ljava/lang/Exception; {:try_start_6f6 .. :try_end_714} :catch_717

    :goto_714
    const/16 v17, 0x1

    goto :goto_71a

    :catch_717
    const/16 v11, 0x3e8

    goto :goto_714

    :goto_71a
    :try_start_71a
    move/from16 v0, v17

    new-array v0, v0, [C

    move-object/from16 v22, v0

    const/16 v30, 0x0

    aput-char v27, v22, v30

    const/16 v7, 0x31

    move-object/from16 v0, v22

    invoke-static {v10, v0}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v10

    const/16 v17, 0x5

    const/16 v7, 0x24

    move/from16 v0, v17

    invoke-interface {v10, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    const/16 v7, 0x8e

    invoke-static {v10}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v10
    :try_end_73e
    .catch Ljava/lang/Exception; {:try_start_71a .. :try_end_73e} :catch_73f

    goto :goto_760

    :catch_73f
    const/16 v10, 0x64

    mul-int v19, v19, v10

    div-int v19, v19, v11

    move/from16 v0, v19

    if-gt v0, v10, :cond_74c

    const/16 v20, 0x1

    goto :goto_75e

    :cond_74c
    const/16 v10, 0x96

    move/from16 v0, v19

    if-gt v0, v10, :cond_755

    const/16 v20, 0x2

    goto :goto_75e

    :cond_755
    const/16 v10, 0xc8

    move/from16 v0, v19

    if-gt v0, v10, :cond_75c

    goto :goto_75e

    :cond_75c
    move/from16 v20, v21

    :goto_75e
    move/from16 v10, v20

    :goto_760
    const/16 v7, 0xaae

    sget-object v11, Ljava/util/Locale;->US:Ljava/util/Locale;

    nop

    div-int/lit8 v17, v14, 0x3c

    const/16 v7, 0xb1

    move/from16 v0, v17

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v17

    rem-int/lit8 v19, v14, 0x3c

    const/16 v7, 0xb1

    move/from16 v0, v19

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v19

    move-object/from16 v0, v17

    move-object/from16 v1, v19

    filled-new-array {v0, v1}, [Ljava/lang/Object;

    move-result-object v17

    const/16 v19, 0x2

    const/16 v7, 0x120e

    move-object/from16 v0, v17

    move/from16 v1, v19

    invoke-static {v0, v1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v17

    const-string/jumbo v19, "%02d:%02d:00"

    const/16 v7, 0xb81

    move-object/from16 v0, v19

    move-object/from16 v1, v17

    invoke-static {v11, v0, v1}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v11

    const/16 v7, 0x42

    iget-object v7, v9, Lg12;->y:Ll12;

    move-object/16 v17, v7

    if-eqz v17, :cond_8ba

    const/16 v7, 0x44

    move-object/from16 v0, v17

    iget-object v7, v0, Ll12;->f:Ljava/util/ArrayList;

    move-object/16 v17, v7

    const/16 v7, 0x43

    move-object/from16 v0, v17

    invoke-virtual {v0, v13}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v17

    check-cast v17, La12;

    const/16 v19, 0x0

    const/16 v7, 0x4ad

    move-object/from16 v0, v17

    move/from16 v1, v19

    iput-boolean v1, v0, La12;->i:Z

    const/16 v7, 0x42

    iget-object v7, v9, Lg12;->y:Ll12;

    move-object/16 v17, v7

    if-eqz v17, :cond_8b3

    const/16 v7, 0x44

    move-object/from16 v0, v17

    iget-object v7, v0, Ll12;->f:Ljava/util/ArrayList;

    move-object/16 v17, v7

    const/16 v7, 0x43

    move-object/from16 v0, v17

    invoke-virtual {v0, v13}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v17

    check-cast v17, La12;

    const/4 v7, -0x6

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0xdcf

    move-object/from16 v0, v17

    iput-object v11, v0, La12;->e:Ljava/lang/String;

    const/16 v7, 0x42

    iget-object v11, v9, Lg12;->y:Ll12;

    nop

    if-eqz v11, :cond_8ac

    const/16 v7, 0x44

    iget-object v11, v11, Ll12;->f:Ljava/util/ArrayList;

    nop

    const/16 v7, 0x43

    invoke-virtual {v11, v13}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, La12;

    const/16 v17, 0x10

    move/from16 v0, v17

    if-ge v14, v0, :cond_805

    const/16 v21, 0x0

    goto :goto_80e

    :cond_805
    move/from16 v0, v18

    if-ge v14, v0, :cond_80c

    const/16 v21, 0x1

    goto :goto_80e

    :cond_80c
    const/16 v21, 0x2

    :goto_80e
    const/16 v7, 0xcb1

    move/from16 v0, v21

    iput v0, v11, La12;->g:I

    const/16 v7, 0x42

    iget-object v11, v9, Lg12;->y:Ll12;

    nop

    if-eqz v11, :cond_8a5

    const/16 v7, 0x44

    iget-object v11, v11, Ll12;->f:Ljava/util/ArrayList;

    nop

    const/16 v7, 0x43

    invoke-virtual {v11, v13}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, La12;

    const/16 v7, 0xe9c

    iput v10, v11, La12;->f:I

    const/16 v7, 0x42

    iget-object v11, v9, Lg12;->y:Ll12;

    nop

    if-eqz v11, :cond_89e

    const/16 v7, 0x44

    iget-object v11, v11, Ll12;->f:Ljava/util/ArrayList;

    nop

    const/16 v7, 0x43

    invoke-virtual {v11, v13}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, La12;

    const/16 v17, 0x0

    const/16 v7, 0x2e7

    move/from16 v0, v17

    iput-boolean v0, v11, La12;->h:Z

    const/16 v7, 0x42

    iget-object v11, v9, Lg12;->y:Ll12;

    nop

    if-eqz v11, :cond_897

    const/16 v7, 0x44

    iget-object v11, v11, Ll12;->f:Ljava/util/ArrayList;

    nop

    const/16 v7, 0x43

    invoke-virtual {v11, v13}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, La12;

    const/16 v7, 0x2ee

    move/from16 v0, v17

    iput v0, v11, La12;->j:I

    const/16 v7, 0x131

    invoke-virtual {v9}, Lg12;->d()Landroid/content/SharedPreferences;

    move-result-object v11

    const/4 v7, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x7a

    invoke-interface {v11}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v11

    const/16 v7, 0x1f7

    sget-object v14, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    nop

    const/16 v7, 0x3b0

    invoke-virtual {v12, v14}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v12

    const/4 v7, -0x6

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0xee

    move-object/from16 v0, v16

    invoke-virtual {v12, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    const/16 v7, 0x56

    invoke-interface {v11, v12, v10}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/16 v7, 0x6f

    invoke-interface {v11}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_893
    :goto_893
    const/16 v29, 0x0

    goto/16 :goto_95e

    :cond_897
    const/4 v7, 0x5

    invoke-static {v15}, Lgt0;->F0(Ljava/lang/String;)V

    const/16 v29, 0x0

    throw v29

    :cond_89e
    const/16 v29, 0x0

    const/4 v7, 0x5

    invoke-static {v15}, Lgt0;->F0(Ljava/lang/String;)V

    throw v29

    :cond_8a5
    const/16 v29, 0x0

    const/4 v7, 0x5

    invoke-static {v15}, Lgt0;->F0(Ljava/lang/String;)V

    throw v29

    :cond_8ac
    const/16 v29, 0x0

    const/4 v7, 0x5

    invoke-static {v15}, Lgt0;->F0(Ljava/lang/String;)V

    throw v29

    :cond_8b3
    const/16 v29, 0x0

    const/4 v7, 0x5

    invoke-static {v15}, Lgt0;->F0(Ljava/lang/String;)V

    throw v29

    :cond_8ba
    const/16 v29, 0x0

    const/4 v7, 0x5

    invoke-static {v15}, Lgt0;->F0(Ljava/lang/String;)V

    throw v29

    :cond_8c1
    const/16 v7, 0x42

    iget-object v10, v9, Lg12;->y:Ll12;

    nop

    if-eqz v10, :cond_970

    const/16 v7, 0x44

    iget-object v10, v10, Ll12;->f:Ljava/util/ArrayList;

    nop

    const/16 v7, 0x43

    invoke-virtual {v10, v13}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, La12;

    const/16 v7, 0x37b

    iget v11, v10, La12;->j:I

    nop

    const/4 v14, 0x1

    add-int/2addr v11, v14

    const/16 v7, 0x2ee

    iput v11, v10, La12;->j:I

    const/16 v7, 0xf40

    iget v10, v9, Lg12;->C:I

    nop

    if-lt v11, v10, :cond_893

    const/16 v7, 0x42

    iget-object v10, v9, Lg12;->y:Ll12;

    nop

    if-eqz v10, :cond_957

    const/16 v7, 0x44

    iget-object v10, v10, Ll12;->f:Ljava/util/ArrayList;

    nop

    const/16 v7, 0x43

    invoke-virtual {v10, v13}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, La12;

    const/16 v7, 0x4ad

    iput-boolean v14, v10, La12;->i:Z

    const/16 v7, 0x42

    iget-object v10, v9, Lg12;->y:Ll12;

    nop

    if-eqz v10, :cond_950

    const/16 v7, 0x44

    iget-object v10, v10, Ll12;->f:Ljava/util/ArrayList;

    nop

    const/16 v7, 0x43

    invoke-virtual {v10, v13}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, La12;

    const/16 v17, 0x0

    const/16 v7, 0x2e7

    move/from16 v0, v17

    iput-boolean v0, v10, La12;->h:Z

    const/16 v7, 0x131

    invoke-virtual {v9}, Lg12;->d()Landroid/content/SharedPreferences;

    move-result-object v10

    const/4 v7, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x7a

    invoke-interface {v10}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v10

    const/16 v7, 0x1f7

    sget-object v11, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    nop

    const/16 v7, 0x3b0

    invoke-virtual {v12, v11}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v11

    const/4 v7, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0xee

    move-object/from16 v0, v16

    invoke-virtual {v11, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const/16 v7, 0x56

    move/from16 v0, v17

    invoke-interface {v10, v11, v0}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/16 v7, 0x6f

    invoke-interface {v10}, Landroid/content/SharedPreferences$Editor;->apply()V

    goto/16 :goto_893

    :cond_950
    const/4 v7, 0x5

    invoke-static {v15}, Lgt0;->F0(Ljava/lang/String;)V

    const/16 v29, 0x0

    throw v29

    :cond_957
    const/16 v29, 0x0

    const/4 v7, 0x5

    invoke-static {v15}, Lgt0;->F0(Ljava/lang/String;)V

    throw v29

    :goto_95e
    const/16 v7, 0x42

    iget-object v9, v9, Lg12;->y:Ll12;

    nop

    if-eqz v9, :cond_96b

    const/16 v7, 0x11e5

    invoke-virtual {v9, v13}, Lqq1;->d(I)V

    goto :goto_97e

    :cond_96b
    const/4 v7, 0x5

    invoke-static {v15}, Lgt0;->F0(Ljava/lang/String;)V

    throw v29

    :cond_970
    const/16 v29, 0x0

    const/4 v7, 0x5

    invoke-static {v15}, Lgt0;->F0(Ljava/lang/String;)V

    throw v29

    :cond_977
    const/16 v29, 0x0

    const/4 v7, 0x5

    invoke-static {v15}, Lgt0;->F0(Ljava/lang/String;)V

    throw v29

    :cond_97e
    :goto_97e
    return-void

    :pswitch_97f  #0x6
    check-cast v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;

    if-eqz v10, :cond_b27

    const/16 v7, 0x2f

    invoke-virtual {v10}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v11

    if-eqz v11, :cond_b27

    const/16 v7, 0x51

    invoke-virtual {v11}, Ljava/lang/String;->hashCode()I

    move-result v14

    const/4 v15, 0x6

    sparse-switch v14, :sswitch_data_1290

    goto/16 :goto_b27

    :sswitch_997
    const/4 v7, -0x7

    invoke-virtual {v11, v13}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_9a0

    goto/16 :goto_b27

    :cond_9a0
    const-string/jumbo v11, "cspl"

    const/16 v17, 0x0

    const/16 v7, 0x151

    move/from16 v0, v17

    invoke-virtual {v10, v11, v0}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v10

    if-nez v10, :cond_b27

    const/16 v7, 0x143

    sget v10, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->F:I

    nop

    const/16 v7, 0x242

    invoke-virtual {v9}, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->h()Landroid/content/SharedPreferences;

    move-result-object v10

    const/4 v7, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0xa82

    invoke-virtual {v9}, Lra;->getResources()Landroid/content/res/Resources;

    move-result-object v11

    const/4 v7, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x4fe

    move/from16 v0, v17

    invoke-static {v10, v11, v0}, Lqk;->p(Landroid/content/SharedPreferences;Landroid/content/res/Resources;I)[Ljava/lang/String;

    move-result-object v10

    const/16 v7, 0x88

    iget-object v11, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->t:Ljava/lang/String;

    nop

    const/16 v7, 0x48e

    invoke-static {v10, v11}, Laf;->a0([Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_b27

    const/16 v7, 0x224

    invoke-virtual {v9}, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->finish()V

    goto/16 :goto_b27

    :sswitch_9e4
    const/4 v7, -0x7

    move-object/from16 v0, v21

    invoke-virtual {v11, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_9ef

    goto/16 :goto_b27

    :cond_9ef
    const/16 v7, 0x224

    invoke-virtual {v9}, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->finish()V

    goto/16 :goto_b27

    :sswitch_9f6
    const/4 v7, -0x7

    move-object/from16 v0, v24

    invoke-virtual {v11, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_b27

    const/16 v17, 0x0

    const/16 v7, 0xa8

    move/from16 v0, v17

    invoke-virtual {v10, v12, v0}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v11

    const/16 v7, 0xa48

    iget v12, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->v:I

    nop

    if-ne v11, v12, :cond_b27

    const/16 v7, 0x8d

    move-object/from16 v0, v23

    invoke-virtual {v10, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const/4 v7, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v11, 0x1

    new-array v12, v11, [C

    aput-char v27, v12, v17

    const/16 v7, 0x31

    invoke-static {v10, v12}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v12

    const/16 v7, 0x24

    move/from16 v0, v17

    invoke-interface {v12, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/String;

    new-array v13, v11, [C

    aput-char v27, v13, v17

    const/16 v7, 0x31

    invoke-static {v10, v13}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v13

    const/16 v7, 0x24

    invoke-interface {v13, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/String;

    const/16 v7, 0x47

    invoke-virtual {v12}, Ljava/lang/String;->length()I

    move-result v11

    const/16 v7, 0x47

    invoke-virtual {v13}, Ljava/lang/String;->length()I

    move-result v12

    add-int/2addr v12, v11

    const/16 v28, 0x2

    add-int/lit8 v12, v12, 0x2

    const/16 v7, 0x21c

    move/from16 v0, v17

    invoke-static {v10, v0, v12}, Lc72;->z0(Ljava/lang/CharSequence;II)Ljava/lang/CharSequence;

    move-result-object v10

    const/16 v7, 0xcb

    invoke-virtual {v10}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v10

    const/16 v7, 0x92

    move-object/from16 v0, v22

    move/from16 v1, v17

    invoke-static {v10, v0, v1}, Lk72;->k0(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v11

    if-eqz v11, :cond_af6

    const-string/jumbo v11, ":"

    check-cast v11, Ljava/lang/String;

    filled-new-array {v11}, [Ljava/lang/String;

    move-result-object v11

    const/16 v7, 0x89

    invoke-static {v10, v11, v15}, Lc72;->E0(Ljava/lang/CharSequence;[Ljava/lang/String;I)Ljava/util/List;

    move-result-object v10

    const/4 v11, 0x1

    const/16 v7, 0x24

    invoke-interface {v10, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    const/16 v7, 0x8e

    invoke-static {v10}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v10

    rem-int/lit8 v12, v10, 0x3c

    const/16 v13, 0x6d

    if-gt v11, v12, :cond_ab6

    const/16 v11, 0xa

    if-ge v12, v11, :cond_ab6

    div-int/lit8 v11, v10, 0x3c

    if-lez v11, :cond_ab6

    const/4 v7, -0x3

    new-instance v11, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v14, "0"

    const/16 v7, 0x97

    invoke-direct {v11, v14}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    :goto_aa6
    const/16 v7, 0x33

    invoke-virtual {v11, v12}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 v7, 0x1b

    invoke-virtual {v11, v13}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v7, -0x2

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    goto :goto_abf

    :cond_ab6
    const/4 v7, -0x3

    new-instance v11, Ljava/lang/StringBuilder;

    nop

    const/4 v7, -0x4

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    goto :goto_aa6

    :goto_abf
    div-int/lit8 v10, v10, 0x3c

    if-lez v10, :cond_ae0

    const/4 v7, -0x3

    new-instance v12, Ljava/lang/StringBuilder;

    nop

    const/4 v7, -0x4

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v7, 0x33

    invoke-virtual {v12, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v10, "h "

    const/4 v7, 0x0

    invoke-virtual {v12, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    invoke-virtual {v12, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, -0x2

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    :cond_ae0
    const/16 v7, 0x1191

    iput-object v11, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->B:Ljava/lang/String;

    const/16 v7, 0xd45

    new-instance v10, Lu7;

    nop

    const/16 v12, 0x12

    const/16 v7, 0x1080

    invoke-direct {v10, v12, v9, v11}, Lu7;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    const/16 v7, 0x147

    invoke-virtual {v9, v10}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    goto :goto_b27

    :cond_af6
    const/16 v7, 0x22e

    new-instance v10, Lzs1;

    nop

    const/4 v11, 0x5

    const/16 v7, 0x1d4

    invoke-direct {v10, v9, v11}, Lzs1;-><init>(Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;I)V

    const/16 v7, 0x147

    invoke-virtual {v9, v10}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    goto :goto_b27

    :sswitch_b07
    const/4 v7, -0x7

    move-object/from16 v0, v19

    invoke-virtual {v11, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_b11

    goto :goto_b27

    :cond_b11
    const/16 v7, 0x140

    sget-boolean v10, Lg4;->a:Z

    nop

    const/16 v7, 0x53

    invoke-virtual {v9}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v9

    const/4 v7, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-wide/16 v10, 0x0

    const/16 v7, 0x3d5

    invoke-static {v9, v15, v10, v11}, Lg4;->m(Landroid/content/Context;IJ)V

    :cond_b27
    :goto_b27
    return-void

    :pswitch_b28  #0x5
    move-object/from16 v33, v14

    check-cast v9, Lcom/tlsvpn/tlstunnel/MainActivity;

    const/16 v7, 0x232

    invoke-virtual {v9}, Landroid/app/Activity;->isDestroyed()Z

    move-result v11

    if-eqz v11, :cond_b36

    goto/16 :goto_e30

    :cond_b36
    if-eqz v10, :cond_e30

    :try_start_b38
    const/16 v7, 0x2f

    invoke-virtual {v10}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v11

    if-eqz v11, :cond_e30

    const/16 v7, 0x51

    invoke-virtual {v11}, Ljava/lang/String;->hashCode()I

    move-result v12

    const v13, 0x7f090170

    sparse-switch v12, :sswitch_data_12a2

    goto/16 :goto_e30

    :sswitch_b4e
    const-string/jumbo v10, "recreateMain"

    const/4 v7, -0x7

    invoke-virtual {v11, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_b5a

    goto/16 :goto_e30

    :cond_b5a
    const/16 v7, 0x1a3

    invoke-virtual {v9}, Landroid/app/Activity;->recreate()V

    goto/16 :goto_e30

    :sswitch_b61
    const-string/jumbo v10, "stelegrambs"

    const/4 v7, -0x7

    invoke-virtual {v11, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_b6d

    goto/16 :goto_e30

    :cond_b6d
    const/16 v7, 0x9ec

    new-instance v10, Lx92;

    nop

    const/16 v7, 0xf42

    invoke-direct {v10}, Lx92;-><init>()V

    const/16 v7, 0x2ff

    invoke-virtual {v9}, Landroidx/fragment/app/l;->c()Lfi0;

    move-result-object v11

    const v12, 0x7f130253

    const/16 v7, 0xb4

    invoke-virtual {v9, v12}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v9

    const/16 v7, 0x8c

    invoke-virtual {v10, v11, v9}, Landroidx/fragment/app/g;->show(Landroidx/fragment/app/p;Ljava/lang/String;)V

    goto/16 :goto_e30

    :sswitch_b8d
    const-string/jumbo v10, "dialogRestaurar"

    const/4 v7, -0x7

    invoke-virtual {v11, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_b99

    goto/16 :goto_e30

    :cond_b99
    const/16 v7, 0xbb1

    new-instance v10, Lg8;

    nop

    const/16 v7, 0x100b

    invoke-direct {v10, v9}, Lg8;-><init>(Landroid/content/Context;)V

    const/16 v7, 0x11e6

    iget-object v11, v10, Lg8;->c:Ljava/lang/Object;

    nop

    check-cast v11, Lc8;

    const/16 v7, 0x505

    iget-object v12, v11, Lc8;->a:Landroid/view/ContextThemeWrapper;

    nop

    const v13, 0x7f13022a

    const/16 v7, 0x492

    invoke-virtual {v12, v13}, Landroid/content/Context;->getText(I)Ljava/lang/CharSequence;

    move-result-object v12

    const/16 v7, 0x7c3

    iput-object v12, v11, Lc8;->f:Ljava/lang/CharSequence;

    const/16 v7, 0xfe3

    new-instance v12, Ld51;

    nop

    const/16 v17, 0x0

    const/16 v7, 0xb08

    move/from16 v0, v17

    invoke-direct {v12, v0, v9}, Ld51;-><init>(ILjava/lang/Object;)V

    const v9, 0x7f130228

    const/16 v7, 0xf53

    invoke-virtual {v10, v9, v12}, Lg8;->j(ILandroid/content/DialogInterface$OnClickListener;)V

    const/16 v7, 0x120f

    new-instance v9, Lic0;

    nop

    const/4 v14, 0x1

    const/16 v7, 0x1192

    invoke-direct {v9, v14}, Lic0;-><init>(I)V

    const/16 v7, 0x505

    iget-object v12, v11, Lc8;->a:Landroid/view/ContextThemeWrapper;

    nop

    const v13, 0x7f130064

    const/16 v7, 0x492

    invoke-virtual {v12, v13}, Landroid/content/Context;->getText(I)Ljava/lang/CharSequence;

    move-result-object v12

    const/16 v7, 0xe5d

    iput-object v12, v11, Lc8;->i:Ljava/lang/CharSequence;

    const/16 v7, 0xe2e

    iput-object v9, v11, Lc8;->j:Landroid/content/DialogInterface$OnClickListener;

    const/16 v7, 0x670

    invoke-virtual {v10}, Lg8;->b()Lh8;

    move-result-object v9

    const/16 v7, 0x9a5

    invoke-virtual {v9}, Landroid/app/Dialog;->show()V

    goto/16 :goto_e30

    :sswitch_c00
    const-string/jumbo v10, "restoreHome"

    const/4 v7, -0x7

    invoke-virtual {v11, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_c0c

    goto/16 :goto_e30

    :cond_c0c
    const/16 v7, 0x27c

    invoke-virtual {v9}, Lcom/tlsvpn/tlstunnel/MainActivity;->k()V

    goto/16 :goto_e30

    :sswitch_c13
    const-string/jumbo v10, "evaluate"

    const/4 v7, -0x7

    invoke-virtual {v11, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_c1f

    goto/16 :goto_e30

    :cond_c1f
    const/16 v7, 0xf11

    sget-boolean v10, Lmi2;->e:Z

    nop

    if-eqz v10, :cond_c28

    goto/16 :goto_e30

    :cond_c28
    const/16 v7, 0x53

    invoke-virtual {v9}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v10

    const/16 v7, 0x53

    invoke-virtual {v10}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v11

    if-eqz v11, :cond_c37

    move-object v10, v11

    :cond_c37
    const/16 v7, 0x11ed

    new-instance v11, Lfm0;

    nop

    const/16 v7, 0x9df

    new-instance v12, Lnj3;

    nop

    const/16 v7, 0xec4

    invoke-direct {v12, v10}, Lnj3;-><init>(Landroid/content/Context;)V

    const/16 v7, 0xa27

    invoke-direct {v11, v12}, Lfm0;-><init>(Lnj3;)V

    const/16 v7, 0x744

    invoke-virtual {v11}, Lfm0;->u()Lcom/google/android/gms/tasks/Task;

    move-result-object v10

    const/4 v7, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x592

    new-instance v12, Lz3;

    nop

    const/4 v13, 0x7

    const/16 v7, 0x72a

    move v0, v7

    move-object v1, v12

    move-object v2, v10

    move-object v3, v11

    move-object v4, v9

    move v5, v13

    invoke-direct/range {v1 .. v5}, Lz3;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    const/16 v7, 0xe42

    invoke-virtual {v10, v12}, Lcom/google/android/gms/tasks/Task;->addOnCompleteListener(Lcom/google/android/gms/tasks/OnCompleteListener;)Lcom/google/android/gms/tasks/Task;

    goto/16 :goto_e30

    :sswitch_c6d
    const-string/jumbo v12, "vpnOn"

    const/4 v7, -0x7

    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_c79

    goto/16 :goto_e30

    :cond_c79
    const-string/jumbo v11, "csuscgaE"

    const/16 v17, 0x0

    const/16 v7, 0x151

    move/from16 v0, v17

    invoke-virtual {v10, v11, v0}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v10

    if-eqz v10, :cond_cdb

    const/16 v7, 0x140

    sget-boolean v10, Lg4;->a:Z

    nop

    const/16 v7, 0x2cc

    invoke-static {v9}, Lg4;->d(Landroid/app/Activity;)V

    const/16 v7, 0x53

    invoke-virtual {v9}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v10

    const/4 v7, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-wide/16 v11, 0x0

    const/16 v7, 0x3a0

    invoke-static {v11, v12, v10}, Lg4;->j(JLandroid/content/Context;)V

    const/16 v7, 0x53

    invoke-virtual {v9}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v10

    const/4 v7, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x2ce

    invoke-static {v11, v12, v10}, Lg4;->k(JLandroid/content/Context;)V

    const/16 v7, 0x95

    invoke-virtual {v9}, Lcom/tlsvpn/tlstunnel/MainActivity;->j()Landroid/content/SharedPreferences;

    move-result-object v10

    const/4 v7, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0xfa8

    invoke-static {v10}, Lg4;->g(Landroid/content/SharedPreferences;)Z

    move-result v10

    if-eqz v10, :cond_cd6

    const/16 v7, 0x53

    invoke-virtual {v9}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v10

    const/4 v7, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v11, 0x6

    const-wide/16 v12, 0x0

    const/16 v7, 0x3d5

    invoke-static {v10, v11, v12, v13}, Lg4;->m(Landroid/content/Context;IJ)V

    :cond_cd6
    const/16 v7, 0xaf4

    invoke-virtual {v9}, Lcom/tlsvpn/tlstunnel/MainActivity;->g()V

    :cond_cdb
    const/16 v7, 0x27c

    invoke-virtual {v9}, Lcom/tlsvpn/tlstunnel/MainActivity;->k()V

    goto/16 :goto_e30

    :sswitch_ce2
    const/4 v7, -0x7

    move-object/from16 v0, v20

    invoke-virtual {v11, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_ced

    goto/16 :goto_e30

    :cond_ced
    const/16 v7, 0x41

    invoke-virtual {v9, v13}, Lra;->findViewById(I)Landroid/view/View;

    move-result-object v10

    const/4 v7, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const v11, 0x7f13020b

    const/16 v7, 0xb4

    invoke-virtual {v9, v11}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v11

    const/4 v7, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-object/from16 v12, v33

    const/16 v17, 0x0

    const/16 v7, 0x1ae

    move v0, v7

    move-object v1, v9

    move-object v2, v11

    move-object v3, v12

    move-object v4, v10

    move/from16 v5, v17

    invoke-virtual/range {v1 .. v5}, Lcom/tlsvpn/tlstunnel/MainActivity;->n(Ljava/lang/String;Ljava/lang/String;Landroid/view/View;I)V

    const/16 v7, 0x140

    sget-boolean v10, Lg4;->a:Z

    nop

    const/16 v7, 0x2cc

    invoke-static {v9}, Lg4;->d(Landroid/app/Activity;)V

    goto/16 :goto_e30

    :sswitch_d20
    move-object/from16 v12, v33

    const-string/jumbo v14, "ssb"

    const/4 v7, -0x7

    invoke-virtual {v11, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_d2e

    goto/16 :goto_e30

    :cond_d2e
    const-string/jumbo v11, "msg"

    const/16 v7, 0x8d

    invoke-virtual {v10, v11}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const/4 v7, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string/jumbo v14, "dur"

    const/4 v15, -0x1

    const/16 v7, 0xa8

    invoke-virtual {v10, v14, v15}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v14

    const-string/jumbo v15, "act"

    const/16 v7, 0x8d

    invoke-virtual {v10, v15}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    if-nez v10, :cond_d51

    move-object v10, v12

    :cond_d51
    const/16 v7, 0x41

    invoke-virtual {v9, v13}, Lra;->findViewById(I)Landroid/view/View;

    move-result-object v12

    const/4 v7, -0x6

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x1ae

    move v0, v7

    move-object v1, v9

    move-object v2, v11

    move-object v3, v10

    move-object v4, v12

    move v5, v14

    invoke-virtual/range {v1 .. v5}, Lcom/tlsvpn/tlstunnel/MainActivity;->n(Ljava/lang/String;Ljava/lang/String;Landroid/view/View;I)V

    goto/16 :goto_e30

    :sswitch_d68
    const-string/jumbo v10, "vpnOff"

    const/4 v7, -0x7

    invoke-virtual {v11, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_d74

    goto/16 :goto_e30

    :cond_d74
    const/16 v7, 0x27c

    invoke-virtual {v9}, Lcom/tlsvpn/tlstunnel/MainActivity;->k()V

    goto/16 :goto_e30

    :sswitch_d7b
    move-object/from16 v12, v33

    const/4 v7, -0x7

    move-object/from16 v0, v21

    invoke-virtual {v11, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_d88

    goto/16 :goto_e30

    :cond_d88
    const/16 v7, 0x101

    sget-boolean v10, Lmi2;->n:Z

    nop

    if-nez v10, :cond_d91

    goto/16 :goto_e30

    :cond_d91
    const/16 v7, 0x41

    invoke-virtual {v9, v13}, Lra;->findViewById(I)Landroid/view/View;

    move-result-object v10

    const/4 v7, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const v11, 0x7f13020c

    const/16 v7, 0xb4

    invoke-virtual {v9, v11}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v11

    const/4 v7, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    nop

    nop

    nop

    nop

    nop

    nop

    nop

    nop

    nop

    goto/16 :goto_e30

    :sswitch_db3
    const-string/jumbo v10, "addLog"

    const/4 v7, -0x7

    invoke-virtual {v11, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_dbe

    goto :goto_e30

    :cond_dbe
    const/16 v7, 0x905

    sget-boolean v10, Lmi2;->a:Z

    nop

    if-nez v10, :cond_e30

    const/16 v7, 0x1f9

    invoke-virtual {v9}, Lcom/tlsvpn/tlstunnel/MainActivity;->h()Lcom/google/android/material/bottomnavigation/BottomNavigationView;

    move-result-object v9

    const v10, 0x7f09016c

    const/16 v7, 0x5b9

    invoke-virtual {v9, v10}, Lyd1;->a(I)Ljh;

    move-result-object v9

    const/4 v11, 0x1

    const/16 v7, 0xb65

    invoke-virtual {v9, v11}, Ljh;->j(Z)V

    const/16 v7, 0x4d0

    sget v10, Lmi2;->c:I

    nop

    const/16 v12, 0x3e7

    if-lt v10, v12, :cond_de4

    goto :goto_dea

    :cond_de4
    add-int/lit8 v12, v10, 0x1

    const/16 v7, 0x100f

    sput v12, Lmi2;->c:I

    :goto_dea
    const/16 v7, 0x5cb

    invoke-virtual {v9, v12}, Ljh;->i(I)V

    goto :goto_e30

    :sswitch_df0
    const-string/jumbo v10, "resetCfgFromMain"

    const/4 v7, -0x7

    invoke-virtual {v11, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_dfb

    goto :goto_e30

    :cond_dfb
    const/16 v7, 0x7e9

    invoke-virtual {v9}, Lcom/tlsvpn/tlstunnel/MainActivity;->m()V

    goto :goto_e30

    :sswitch_e01
    const/4 v7, -0x7

    move-object/from16 v0, v19

    invoke-virtual {v11, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_e0b

    goto :goto_e30

    :cond_e0b
    const/16 v7, 0x140

    sget-boolean v10, Lg4;->a:Z

    nop

    const/16 v7, 0x53

    invoke-virtual {v9}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v10

    const/4 v7, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-wide/16 v11, 0x0

    const/16 v7, 0x3a0

    invoke-static {v11, v12, v10}, Lg4;->j(JLandroid/content/Context;)V

    const/16 v7, 0x53

    invoke-virtual {v9}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v9

    const/4 v7, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x2ce

    invoke-static {v11, v12, v9}, Lg4;->k(JLandroid/content/Context;)V
    :try_end_e30
    .catch Ljava/lang/IllegalStateException; {:try_start_b38 .. :try_end_e30} :catch_e30

    :catch_e30
    :cond_e30
    :goto_e30
    return-void

    :pswitch_e31  #0x4
    check-cast v9, Lcom/tlsvpn/tlstunnel/ui/Logs;

    if-eqz v10, :cond_e7a

    const/16 v7, 0x2f

    invoke-virtual {v10}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v11

    if-eqz v11, :cond_e7a

    const/16 v7, 0x51

    invoke-virtual {v11}, Ljava/lang/String;->hashCode()I

    move-result v12

    const v13, -0x54ca1d1d

    if-eq v12, v13, :cond_e5f

    const v10, 0x2f1ab5b7

    if-eq v12, v10, :cond_e4e

    goto :goto_e7a

    :cond_e4e
    const-string/jumbo v10, "clearLog"

    const/4 v7, -0x7

    invoke-virtual {v11, v10}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_e59

    goto :goto_e7a

    :cond_e59
    const/16 v7, 0x6ea

    invoke-virtual {v9}, Lcom/tlsvpn/tlstunnel/ui/Logs;->c()V

    goto :goto_e7a

    :cond_e5f
    const-string/jumbo v12, "addLog"

    const/4 v7, -0x7

    invoke-virtual {v11, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_e6a

    goto :goto_e7a

    :cond_e6a
    const-string/jumbo v11, "lmsg"

    const/16 v7, 0x8d

    invoke-virtual {v10, v11}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    if-eqz v10, :cond_e7a

    const/16 v7, 0x194

    invoke-virtual {v9, v10}, Lcom/tlsvpn/tlstunnel/ui/Logs;->b(Ljava/lang/String;)V

    :cond_e7a
    :goto_e7a
    return-void

    :pswitch_e7b  #0x3
    check-cast v9, Lcom/tlsvpn/tlstunnel/ui/Home;

    const/16 v7, 0xd9

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->isAdded()Z

    move-result v11

    if-eqz v11, :cond_10a0

    const/16 v7, 0x69

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->getView()Landroid/view/View;

    move-result-object v11

    if-eqz v11, :cond_10a0

    if-nez p1, :cond_e91

    goto/16 :goto_10a0

    :cond_e91
    if-eqz v10, :cond_10a0

    const/16 v7, 0x2f

    invoke-virtual {v10}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v10

    if-eqz v10, :cond_10a0

    const/16 v7, 0x51

    invoke-virtual {v10}, Ljava/lang/String;->hashCode()I

    move-result v11

    const-string/jumbo v12, "bannerContainerBCFG"

    const-string/jumbo v13, "bannerContainerDft"

    sparse-switch v11, :sswitch_data_12d8

    goto/16 :goto_10a0

    :sswitch_eac
    const-string/jumbo v11, "renewed"

    const/4 v7, -0x7

    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_eb8

    goto/16 :goto_10a0

    :cond_eb8
    const/16 v7, 0x182

    invoke-virtual {v9}, Lcom/tlsvpn/tlstunnel/ui/Home;->g()V

    goto/16 :goto_10a0

    :sswitch_ebf
    const-string/jumbo v11, "setProgress"

    const/4 v7, -0x7

    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_ecb

    goto/16 :goto_10a0

    :cond_ecb
    const/16 v7, 0x182

    invoke-virtual {v9}, Lcom/tlsvpn/tlstunnel/ui/Home;->g()V

    goto/16 :goto_10a0

    :sswitch_ed2
    const-string/jumbo v11, "restoreHome"

    const/4 v7, -0x7

    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_ede

    goto/16 :goto_10a0

    :cond_ede
    const/16 v7, 0x11b

    invoke-virtual {v9}, Lcom/tlsvpn/tlstunnel/ui/Home;->d()V

    const/16 v7, 0x322

    invoke-virtual {v9}, Lcom/tlsvpn/tlstunnel/ui/Home;->c()V

    goto/16 :goto_10a0

    :sswitch_eea
    const-string/jumbo v11, "vpnOn"

    const/4 v7, -0x7

    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_ef6

    goto/16 :goto_10a0

    :cond_ef6
    const/16 v7, 0x69

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->getView()Landroid/view/View;

    move-result-object v10

    if-eqz v10, :cond_10a0

    const/16 v7, 0xd9

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->isAdded()Z

    move-result v10

    if-nez v10, :cond_f08

    goto/16 :goto_10a0

    :cond_f08
    const/16 v7, 0x11b

    invoke-virtual {v9}, Lcom/tlsvpn/tlstunnel/ui/Home;->d()V

    const/16 v7, 0x2c2

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/Home;->m:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz v10, :cond_f32

    const/4 v11, 0x1

    const/16 v7, 0xf7

    invoke-virtual {v10, v11}, Landroid/view/View;->setEnabled(Z)V

    const/16 v7, 0x102

    iget-object v9, v9, Lcom/tlsvpn/tlstunnel/ui/Home;->r:Landroid/widget/ImageButton;

    nop

    if-eqz v9, :cond_f28

    const/16 v7, 0xf7

    invoke-virtual {v9, v11}, Landroid/view/View;->setEnabled(Z)V

    goto/16 :goto_10a0

    :cond_f28
    const-string/jumbo v9, "btnReconnect"

    const/4 v7, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    const/16 v29, 0x0

    throw v29

    :cond_f32
    const/16 v29, 0x0

    const-string/jumbo v9, "btnStartStop"

    const/4 v7, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw v29

    :sswitch_f3c
    const/4 v7, -0x7

    move-object/from16 v0, v20

    invoke-virtual {v10, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_f47

    goto/16 :goto_10a0

    :cond_f47
    const/16 v7, 0x69

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->getView()Landroid/view/View;

    move-result-object v10

    if-eqz v10, :cond_10a0

    const/16 v7, 0xd9

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->isAdded()Z

    move-result v10

    if-nez v10, :cond_f59

    goto/16 :goto_10a0

    :cond_f59
    const/16 v7, 0x69

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->getView()Landroid/view/View;

    move-result-object v10

    const/4 v7, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const v11, 0x7f090392

    const/16 v7, 0x11

    invoke-virtual {v10, v11}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/ImageView;

    const v11, 0x7f080135

    const/16 v7, 0x87

    invoke-virtual {v10, v11}, Landroid/widget/ImageView;->setImageResource(I)V

    const/16 v7, 0x69

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->getView()Landroid/view/View;

    move-result-object v10

    const/4 v7, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const v11, 0x7f090393

    const/16 v7, 0x11

    invoke-virtual {v10, v11}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v10

    check-cast v10, Landroid/widget/TextView;

    const v11, 0x7f130024

    const/16 v7, 0x93

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(I)V

    const/16 v7, 0xc6

    invoke-virtual {v9}, Lcom/tlsvpn/tlstunnel/ui/Home;->b()Landroid/content/SharedPreferences;

    move-result-object v10

    const/4 v11, 0x0

    const/16 v7, 0x77

    move-object/from16 v0, v17

    invoke-interface {v10, v0, v11}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v10

    if-eqz v10, :cond_fc7

    const/16 v7, 0xc6

    invoke-virtual {v9}, Lcom/tlsvpn/tlstunnel/ui/Home;->b()Landroid/content/SharedPreferences;

    move-result-object v10

    const/4 v7, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x7a

    invoke-interface {v10}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v10

    const/16 v7, 0x48

    move-object/from16 v0, v17

    invoke-interface {v10, v0, v11}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/16 v7, 0x56

    move-object/from16 v0, v16

    invoke-interface {v10, v0, v11}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/16 v7, 0x6f

    invoke-interface {v10}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_fc7
    const/16 v7, 0x508

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/Home;->E:Landroid/widget/FrameLayout;

    nop

    if-eqz v10, :cond_ff0

    const/4 v7, -0x5

    invoke-virtual {v10, v11}, Landroid/view/View;->setVisibility(I)V

    const/16 v7, 0x395

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/Home;->D:Landroid/widget/FrameLayout;

    nop

    if-eqz v10, :cond_fe9

    const/4 v7, -0x5

    invoke-virtual {v10, v11}, Landroid/view/View;->setVisibility(I)V

    const/16 v7, 0x11b

    invoke-virtual {v9}, Lcom/tlsvpn/tlstunnel/ui/Home;->d()V

    const/16 v7, 0x182

    invoke-virtual {v9}, Lcom/tlsvpn/tlstunnel/ui/Home;->g()V

    goto/16 :goto_10a0

    :cond_fe9
    const/4 v7, 0x5

    invoke-static {v12}, Lgt0;->F0(Ljava/lang/String;)V

    const/16 v29, 0x0

    throw v29

    :cond_ff0
    const/16 v29, 0x0

    const/4 v7, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    throw v29

    :sswitch_ff7
    const-string/jumbo v11, "vpnOff"

    const/4 v7, -0x7

    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_1003

    goto/16 :goto_10a0

    :cond_1003
    const/16 v7, 0x69

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->getView()Landroid/view/View;

    move-result-object v10

    if-eqz v10, :cond_10a0

    const/16 v7, 0xd9

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->isAdded()Z

    move-result v10

    if-nez v10, :cond_1015

    goto/16 :goto_10a0

    :cond_1015
    const/16 v7, 0x11b

    invoke-virtual {v9}, Lcom/tlsvpn/tlstunnel/ui/Home;->d()V

    const/16 v7, 0xa9

    invoke-virtual {v9}, Lcom/tlsvpn/tlstunnel/ui/Home;->j()V

    goto/16 :goto_10a0

    :sswitch_1021
    const/4 v7, -0x7

    move-object/from16 v0, v21

    invoke-virtual {v10, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_102b

    goto :goto_10a0

    :cond_102b
    const/16 v7, 0x69

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->getView()Landroid/view/View;

    move-result-object v10

    if-eqz v10, :cond_10a0

    const/16 v7, 0xd9

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->isAdded()Z

    move-result v10

    if-nez v10, :cond_103c

    goto :goto_10a0

    :cond_103c
    const/16 v7, 0x69

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->getView()Landroid/view/View;

    move-result-object v10

    const/4 v7, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x64a

    invoke-virtual {v9, v10}, Lcom/tlsvpn/tlstunnel/ui/Home;->f(Landroid/view/View;)V

    const/16 v7, 0x182

    invoke-virtual {v9}, Lcom/tlsvpn/tlstunnel/ui/Home;->g()V

    const/16 v7, 0x12f

    sget-object v10, Lg4;->n:Lx4;

    nop

    if-eqz v10, :cond_10a0

    const/16 v29, 0x0

    const/16 v7, 0xce3

    move-object/from16 v0, v29

    sput-object v0, Lg4;->n:Lx4;

    const/16 v11, 0x8

    const/4 v7, -0x5

    invoke-virtual {v10, v11}, Landroid/view/View;->setVisibility(I)V

    :try_start_1065
    const/16 v7, 0x70c

    invoke-virtual {v10}, Lx4;->c()V
    :try_end_106a
    .catch Ljava/lang/Exception; {:try_start_1065 .. :try_end_106a} :catch_106a

    :catch_106a
    const/16 v7, 0x395

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/Home;->D:Landroid/widget/FrameLayout;

    nop

    if-eqz v10, :cond_108a

    const/16 v7, 0x42c

    invoke-virtual {v10}, Landroid/view/ViewGroup;->removeAllViews()V

    const/16 v7, 0x508

    iget-object v9, v9, Lcom/tlsvpn/tlstunnel/ui/Home;->E:Landroid/widget/FrameLayout;

    nop

    if-eqz v9, :cond_1083

    const/16 v7, 0x42c

    invoke-virtual {v9}, Landroid/view/ViewGroup;->removeAllViews()V

    goto :goto_10a0

    :cond_1083
    const/4 v7, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    const/16 v29, 0x0

    throw v29

    :cond_108a
    const/16 v29, 0x0

    const/4 v7, 0x5

    invoke-static {v12}, Lgt0;->F0(Ljava/lang/String;)V

    throw v29

    :sswitch_1091
    const/4 v7, -0x7

    move-object/from16 v0, v19

    invoke-virtual {v10, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_109b

    goto :goto_10a0

    :cond_109b
    const/16 v7, 0x322

    invoke-virtual {v9}, Lcom/tlsvpn/tlstunnel/ui/Home;->c()V

    :cond_10a0
    :goto_10a0
    return-void

    :pswitch_10a1  #0x2
    if-eqz v10, :cond_10c8

    const/16 v7, 0x2f

    invoke-virtual {v10}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v10

    if-eqz v10, :cond_10c8

    const/16 v7, 0x51

    invoke-virtual {v10}, Ljava/lang/String;->hashCode()I

    move-result v11

    const v12, -0x133f84b

    if-eq v11, v12, :cond_10b7

    goto :goto_10c8

    :cond_10b7
    const-string/jumbo v11, "restoremtdcfg"

    const/4 v7, -0x7

    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_10c8

    check-cast v9, Lwu;

    const/16 v7, 0xe11

    invoke-virtual {v9}, Lwu;->d()V

    :cond_10c8
    :goto_10c8
    return-void

    :pswitch_10c9  #0x1
    const/4 v7, -0x6

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v7, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v9, Ldj;

    const/16 v7, 0xb09

    iget v11, v9, Ldj;->g:I

    nop

    const-string/jumbo v12, "Received "

    packed-switch v11, :pswitch_data_12fa

    const/16 v7, 0x2f

    invoke-virtual {v10}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v11

    if-nez v11, :cond_10ea

    goto/16 :goto_1258

    :cond_10ea
    const/16 v7, 0xf3

    invoke-static {}, Lj41;->e()Lj41;

    move-result-object v11

    const/16 v7, 0xe3d

    sget-object v13, Ls62;->a:Ljava/lang/String;

    nop

    const/4 v7, -0x3

    new-instance v14, Ljava/lang/StringBuilder;

    nop

    const/16 v7, 0x97

    invoke-direct {v14, v12}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v7, 0x2f

    invoke-virtual {v10}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v12

    const/4 v7, 0x0

    invoke-virtual {v14, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, -0x2

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    const/16 v7, 0x257

    invoke-virtual {v11, v13, v12}, Lj41;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v7, 0x2f

    invoke-virtual {v10}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v10

    if-eqz v10, :cond_1258

    const/16 v7, 0x51

    invoke-virtual {v10}, Ljava/lang/String;->hashCode()I

    move-result v11

    const v12, -0x46671f94

    if-eq v11, v12, :cond_1144

    const v12, -0x2b8fb65c

    if-eq v11, v12, :cond_112c

    goto/16 :goto_1258

    :cond_112c
    const-string/jumbo v11, "android.intent.action.DEVICE_STORAGE_OK"

    const/4 v7, -0x7

    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_1138

    goto/16 :goto_1258

    :cond_1138
    const/16 v7, 0x159

    sget-object v10, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    nop

    const/16 v7, 0x71

    invoke-virtual {v9, v10}, Ljw;->b(Ljava/lang/Object;)V

    goto/16 :goto_1258

    :cond_1144
    const-string/jumbo v11, "android.intent.action.DEVICE_STORAGE_LOW"

    const/4 v7, -0x7

    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_1150

    goto/16 :goto_1258

    :cond_1150
    const/16 v7, 0x10d

    sget-object v10, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    nop

    const/16 v7, 0x71

    invoke-virtual {v9, v10}, Ljw;->b(Ljava/lang/Object;)V

    goto/16 :goto_1258

    :pswitch_115c  #0x1
    const/16 v7, 0x2f

    invoke-virtual {v10}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v11

    if-nez v11, :cond_1166

    goto/16 :goto_1258

    :cond_1166
    const/16 v7, 0xf3

    invoke-static {}, Lj41;->e()Lj41;

    move-result-object v11

    const/16 v7, 0xea5

    sget-object v13, Lfj;->a:Ljava/lang/String;

    nop

    const/4 v7, -0x3

    new-instance v14, Ljava/lang/StringBuilder;

    nop

    const/16 v7, 0x97

    invoke-direct {v14, v12}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v7, 0x2f

    invoke-virtual {v10}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v12

    const/4 v7, 0x0

    invoke-virtual {v14, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, -0x2

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    const/16 v7, 0x257

    invoke-virtual {v11, v13, v12}, Lj41;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v7, 0x2f

    invoke-virtual {v10}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v10

    if-eqz v10, :cond_1258

    const/16 v7, 0x51

    invoke-virtual {v10}, Ljava/lang/String;->hashCode()I

    move-result v11

    const v12, -0x7606c095  # -6.0004207E-33f

    if-eq v11, v12, :cond_11c0

    const v12, 0x1d398bfd

    if-eq v11, v12, :cond_11a8

    goto/16 :goto_1258

    :cond_11a8
    const-string/jumbo v11, "android.intent.action.BATTERY_LOW"

    const/4 v7, -0x7

    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_11b4

    goto/16 :goto_1258

    :cond_11b4
    const/16 v7, 0x10d

    sget-object v10, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    nop

    const/16 v7, 0x71

    invoke-virtual {v9, v10}, Ljw;->b(Ljava/lang/Object;)V

    goto/16 :goto_1258

    :cond_11c0
    const-string/jumbo v11, "android.intent.action.BATTERY_OKAY"

    const/4 v7, -0x7

    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_11cc

    goto/16 :goto_1258

    :cond_11cc
    const/16 v7, 0x159

    sget-object v10, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    nop

    const/16 v7, 0x71

    invoke-virtual {v9, v10}, Ljw;->b(Ljava/lang/Object;)V

    goto/16 :goto_1258

    :pswitch_11d8  #0x0
    const/16 v7, 0x2f

    invoke-virtual {v10}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v10

    if-nez v10, :cond_11e1

    goto :goto_1258

    :cond_11e1
    const/16 v7, 0xf3

    invoke-static {}, Lj41;->e()Lj41;

    move-result-object v11

    const/16 v7, 0x6f2

    sget-object v13, Lej;->a:Ljava/lang/String;

    nop

    const/16 v7, 0xee

    invoke-virtual {v12, v10}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    const/16 v7, 0x257

    invoke-virtual {v11, v13, v12}, Lj41;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v7, 0x51

    invoke-virtual {v10}, Ljava/lang/String;->hashCode()I

    move-result v11

    sparse-switch v11, :sswitch_data_1302

    goto :goto_1258

    :sswitch_1201
    const-string/jumbo v11, "android.intent.action.ACTION_POWER_CONNECTED"

    const/4 v7, -0x7

    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_120c

    goto :goto_1258

    :cond_120c
    const/16 v7, 0x159

    sget-object v10, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    nop

    const/16 v7, 0x71

    invoke-virtual {v9, v10}, Ljw;->b(Ljava/lang/Object;)V

    goto :goto_1258

    :sswitch_1217
    const-string/jumbo v11, "android.os.action.CHARGING"

    const/4 v7, -0x7

    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_1222

    goto :goto_1258

    :cond_1222
    const/16 v7, 0x159

    sget-object v10, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    nop

    const/16 v7, 0x71

    invoke-virtual {v9, v10}, Ljw;->b(Ljava/lang/Object;)V

    goto :goto_1258

    :sswitch_122d
    const-string/jumbo v11, "android.os.action.DISCHARGING"

    const/4 v7, -0x7

    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_1238

    goto :goto_1258

    :cond_1238
    const/16 v7, 0x10d

    sget-object v10, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    nop

    const/16 v7, 0x71

    invoke-virtual {v9, v10}, Ljw;->b(Ljava/lang/Object;)V

    goto :goto_1258

    :sswitch_1243
    const-string/jumbo v11, "android.intent.action.ACTION_POWER_DISCONNECTED"

    const/4 v7, -0x7

    invoke-virtual {v10, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_124e

    goto :goto_1258

    :cond_124e
    const/16 v7, 0x10d

    sget-object v10, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    nop

    const/16 v7, 0x71

    invoke-virtual {v9, v10}, Ljw;->b(Ljava/lang/Object;)V

    :cond_1258
    :goto_1258
    return-void

    :pswitch_1259  #0x0
    check-cast v9, Lpb;

    const/16 v7, 0xf97

    invoke-virtual {v9}, Lpb;->n()V

    return-void

    nop

    :pswitch_data_1262
    .packed-switch 0x0
        :pswitch_1259  #00000000
        :pswitch_10c9  #00000001
        :pswitch_10a1  #00000002
        :pswitch_e7b  #00000003
        :pswitch_e31  #00000004
        :pswitch_b28  #00000005
        :pswitch_97f  #00000006
        :pswitch_517  #00000007
    .end packed-switch

    :sswitch_data_1276
    .sparse-switch
        -0x7bd5c78c -> :sswitch_3f6
        -0x7050ce6e -> :sswitch_3da
        -0x65ac5055 -> :sswitch_1b3
        -0x3bf7bee8 -> :sswitch_13b
        0x5b29c08 -> :sswitch_98
        0x3b049b57 -> :sswitch_7c
    .end sparse-switch

    :sswitch_data_1290
    .sparse-switch
        -0x7896e3c1 -> :sswitch_b07
        -0x65ac5055 -> :sswitch_9f6
        -0x3bf7bee8 -> :sswitch_9e4
        0x53d44a42 -> :sswitch_997
    .end sparse-switch

    :sswitch_data_12a2
    .sparse-switch
        -0x7896e3c1 -> :sswitch_e01
        -0x5e5a9fc8 -> :sswitch_df0
        -0x54ca1d1d -> :sswitch_db3
        -0x3bf7bee8 -> :sswitch_d7b
        -0x3046a825 -> :sswitch_d68
        0x1be02 -> :sswitch_d20
        0x5b29c08 -> :sswitch_ce2
        0x6b365f3 -> :sswitch_c6d
        0x9a4ac99 -> :sswitch_c13
        0x13a5448d -> :sswitch_c00
        0x3da94bb3 -> :sswitch_b8d
        0x7b0f05c5 -> :sswitch_b61
        0x7cef6748 -> :sswitch_b4e
    .end sparse-switch

    :sswitch_data_12d8
    .sparse-switch
        -0x7896e3c1 -> :sswitch_1091
        -0x3bf7bee8 -> :sswitch_1021
        -0x3046a825 -> :sswitch_ff7
        0x5b29c08 -> :sswitch_f3c
        0x6b365f3 -> :sswitch_eea
        0x13a5448d -> :sswitch_ed2
        0x3ae760af -> :sswitch_ebf
        0x411da7ec -> :sswitch_eac
    .end sparse-switch

    :pswitch_data_12fa
    .packed-switch 0x0
        :pswitch_11d8  #00000000
        :pswitch_115c  #00000001
    .end packed-switch

    :sswitch_data_1302
    .sparse-switch
        -0x7073f927 -> :sswitch_1243
        -0x3465cce -> :sswitch_122d
        0x388694fe -> :sswitch_1217
        0x3cbf870b -> :sswitch_1201
    .end sparse-switch
.end method
