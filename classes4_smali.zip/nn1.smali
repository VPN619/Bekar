.class public final Lnn1;
.super Lvb;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lcom/android/billingclient/api/PurchasesUpdatedListener;
.implements Lcom/android/billingclient/api/BillingClientStateListener;
.implements Lcom/android/billingclient/api/PurchasesResponseListener;


# instance fields
.field public A:Ljava/lang/String;

.field public B:Lcom/android/billingclient/api/BillingClient;

.field public C:Landroid/widget/TextView;

.field public final q:Lw82;

.field public r:Ljava/lang/String;

.field public s:Landroid/widget/ProgressBar;

.field public t:Landroid/widget/LinearLayout;

.field public u:Landroid/widget/TextView;

.field public v:Landroid/widget/LinearLayout;

.field public w:Landroid/widget/TextView;

.field public x:Landroid/widget/RadioGroup;

.field public y:Landroid/widget/RadioButton;

.field public z:Landroid/widget/RadioButton;


# direct methods
.method public constructor <init>()V
    .registers 5

    invoke-direct {p0}, Lvb;-><init>()V

    const/16 v0, 0xa84

    new-instance v2, Ld;

    nop

    const/16 v3, 0x19

    const/16 v0, 0x6cb

    invoke-direct {v2, v3, p0}, Ld;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x27a

    new-instance v3, Lw82;

    nop

    const/16 v0, 0x215

    invoke-direct {v3, v2}, Lw82;-><init>(Lzj0;)V

    const/16 v0, 0x784

    iput-object v3, p0, Lnn1;->q:Lw82;

    const-string/jumbo v2, ""

    const/16 v0, 0xcc2

    iput-object v2, p0, Lnn1;->r:Ljava/lang/String;

    const/16 v0, 0x707

    iput-object v2, p0, Lnn1;->A:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final c()V
    .registers 5

    const/4 v0, 0x1

    sput-boolean v0, Lmi2;->n:Z

    iget-object v0, p0, Lnn1;->q:Lw82;

    invoke-virtual {v0}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v2, "pvdata"

    const-string v3, "dummy:dummy"

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    invoke-virtual {p0}, Lnn1;->dismiss()V

    return-void
.end method

.method public final d()V
    .registers 13

    const/16 v6, 0x325

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getViewLifecycleOwner()Lh11;

    move-result-object v8

    const/4 v6, -0x6

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x341

    invoke-static {v8}, Lns2;->m(Lh11;)Lc11;

    move-result-object v8

    const/16 v6, 0x161

    new-instance v9, Lin1;

    nop

    const/4 v10, 0x0

    const/4 v11, 0x3

    const/16 v6, 0x16a

    invoke-direct {v9, p0, v10, v11}, Lin1;-><init>(Lnn1;Lvx;I)V

    const/16 v6, 0xb3

    move v0, v6

    move-object v1, v8

    move-object v2, v10

    move-object v3, v10

    move-object v4, v9

    move v5, v11

    invoke-static/range {v1 .. v5}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    return-void
.end method

.method public final e(Lcom/android/billingclient/api/BillingResult;Ljava/util/List;)V
    .registers 4

    const/4 v0, 0x1

    sput-boolean v0, Lmi2;->n:Z

    iget-object v0, p0, Lnn1;->q:Lw82;

    invoke-virtual {v0}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string p1, "pvdata"

    const-string p2, "dummy:dummy"

    invoke-interface {p0, p1, p2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method public final onBillingServiceDisconnected()V
    .registers 3

    const/16 v0, 0x3f4

    invoke-virtual {p0}, Lnn1;->d()V

    return-void
.end method

.method public final onBillingSetupFinished(Lcom/android/billingclient/api/BillingResult;)V
    .registers 12

    .prologue
    const/4 v6, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x450

    invoke-virtual {p1}, Lcom/android/billingclient/api/BillingResult;->getResponseCode()I

    move-result p1

    if-nez p1, :cond_34

    const/16 v6, 0x325

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getViewLifecycleOwner()Lh11;

    move-result-object p1

    const/4 v6, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x341

    invoke-static {p1}, Lns2;->m(Lh11;)Lc11;

    move-result-object p1

    const/16 v6, 0x9f4

    new-instance v8, Lln1;

    nop

    const/4 v9, 0x0

    const/16 v6, 0x7ca

    invoke-direct {v8, p0, v9}, Lln1;-><init>(Lnn1;Lvx;)V

    const/4 p0, 0x3

    const/16 v6, 0xb3

    move v0, v6

    move-object v1, p1

    move-object v2, v9

    move-object v3, v9

    move-object v4, v8

    move v5, p0

    invoke-static/range {v1 .. v5}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    return-void

    :cond_34
    const/16 v6, 0x3f4

    invoke-virtual {p0}, Lnn1;->d()V

    return-void
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .registers 6

    .prologue
    const/16 v0, 0x11c5

    invoke-super {p0, p1}, Landroidx/fragment/app/g;->onCreate(Landroid/os/Bundle;)V

    const/16 v0, 0xc2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getArguments()Landroid/os/Bundle;

    move-result-object p1

    if-eqz p1, :cond_21

    const-string/jumbo v2, "strnew"

    const-string/jumbo v3, ""

    const/16 v0, 0x54e

    invoke-virtual {p1, v2, v3}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xcc2

    iput-object p1, p0, Lnn1;->r:Ljava/lang/String;

    :cond_21
    return-void
.end method

.method public final onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .registers 14

    .prologue
    const/4 v6, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const p3, 0x7f0c00c5

    const/4 v8, 0x0

    const/16 v6, 0x107b

    invoke-virtual {p1, p3, p2, v8}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    const p2, 0x7f0902cf

    const/16 v6, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v6, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/ProgressBar;

    const/16 v6, 0x1119

    iput-object p2, p0, Lnn1;->s:Landroid/widget/ProgressBar;

    const p2, 0x7f0900c2

    const/16 v6, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v6, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/LinearLayout;

    const/16 v6, 0xb99

    iput-object p2, p0, Lnn1;->t:Landroid/widget/LinearLayout;

    const p2, 0x7f090258

    const/16 v6, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v6, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/TextView;

    const/16 v6, 0xcbb

    iput-object p2, p0, Lnn1;->u:Landroid/widget/TextView;

    const p2, 0x7f0902a8

    const/16 v6, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v6, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/TextView;

    const/16 v6, 0x6ba

    iput-object p2, p0, Lnn1;->C:Landroid/widget/TextView;

    const p2, 0x7f090062

    const/16 v6, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v6, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/LinearLayout;

    const/16 v6, 0xe36

    iput-object p2, p0, Lnn1;->v:Landroid/widget/LinearLayout;

    const p2, 0x7f090063

    const/16 v6, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v6, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/TextView;

    const/16 v6, 0xb87

    iput-object p2, p0, Lnn1;->w:Landroid/widget/TextView;

    const p2, 0x7f0902eb

    const/16 v6, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v6, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/RadioGroup;

    const/16 v6, 0xac1

    iput-object p2, p0, Lnn1;->x:Landroid/widget/RadioGroup;

    const p2, 0x7f0902dd

    const/16 v6, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v6, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/RadioButton;

    const/16 v6, 0xda4

    iput-object p2, p0, Lnn1;->y:Landroid/widget/RadioButton;

    const p2, 0x7f0902dc

    const/16 v6, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v6, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/RadioButton;

    const/16 v6, 0x5ec

    iput-object p2, p0, Lnn1;->z:Landroid/widget/RadioButton;

    const/16 v6, 0x5c3

    invoke-static {}, Lmi2;->e()Z

    move-result p2

    if-eqz p2, :cond_ea

    const/16 v6, 0x325

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getViewLifecycleOwner()Lh11;

    move-result-object p2

    const/4 v6, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x341

    invoke-static {p2}, Lns2;->m(Lh11;)Lc11;

    move-result-object p2

    const/16 v6, 0x161

    new-instance p3, Lin1;

    nop

    const/4 v8, 0x2

    const/4 v9, 0x0

    const/16 v6, 0x16a

    invoke-direct {p3, p0, v9, v8}, Lin1;-><init>(Lnn1;Lvx;I)V

    const/4 p0, 0x3

    const/16 v6, 0xb3

    move v0, v6

    move-object v1, p2

    move-object v2, v9

    move-object v3, v9

    move-object v4, p3

    move v5, p0

    invoke-static/range {v1 .. v5}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    goto :goto_127

    :cond_ea
    const/16 v6, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p2

    const/16 v6, 0x1155

    invoke-static {p2}, Lcom/android/billingclient/api/BillingClient;->newBuilder(Landroid/content/Context;)Lcom/android/billingclient/api/BillingClient$Builder;

    move-result-object p2

    const/16 v6, 0xcd8

    invoke-virtual {p2, p0}, Lcom/android/billingclient/api/BillingClient$Builder;->setListener(Lcom/android/billingclient/api/PurchasesUpdatedListener;)Lcom/android/billingclient/api/BillingClient$Builder;

    move-result-object p2

    const/16 v6, 0xc54

    invoke-static {}, Lcom/android/billingclient/api/PendingPurchasesParams;->newBuilder()Lcom/android/billingclient/api/PendingPurchasesParams$Builder;

    move-result-object p3

    const/16 v6, 0x66e

    invoke-virtual {p3}, Lcom/android/billingclient/api/PendingPurchasesParams$Builder;->enableOneTimeProducts()Lcom/android/billingclient/api/PendingPurchasesParams$Builder;

    move-result-object p3

    const/16 v6, 0x1025

    invoke-virtual {p3}, Lcom/android/billingclient/api/PendingPurchasesParams$Builder;->build()Lcom/android/billingclient/api/PendingPurchasesParams;

    move-result-object p3

    const/16 v6, 0xe8d

    invoke-virtual {p2, p3}, Lcom/android/billingclient/api/BillingClient$Builder;->enablePendingPurchases(Lcom/android/billingclient/api/PendingPurchasesParams;)Lcom/android/billingclient/api/BillingClient$Builder;

    move-result-object p2

    const/16 v6, 0xbe6

    invoke-virtual {p2}, Lcom/android/billingclient/api/BillingClient$Builder;->build()Lcom/android/billingclient/api/BillingClient;

    move-result-object p2

    const/4 v6, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x90c

    iput-object p2, p0, Lnn1;->B:Lcom/android/billingclient/api/BillingClient;

    const/16 v6, 0x10d6

    invoke-virtual {p2, p0}, Lcom/android/billingclient/api/BillingClient;->startConnection(Lcom/android/billingclient/api/BillingClientStateListener;)V

    :goto_127
    const/4 p0, 0x1

    const/16 v6, 0x11eb

    sput-boolean p0, Lmi2;->f:Z

    check-cast p1, Landroid/view/View;

    return-object p1
.end method

.method public final onDestroyView()V
    .registers 4

    .prologue
    const/16 v0, 0x53a

    invoke-super {p0}, Landroidx/fragment/app/g;->onDestroyView()V

    const/16 v0, 0x905

    sget-boolean v2, Lmi2;->a:Z

    nop

    const/4 v2, 0x0

    const/16 v0, 0x11eb

    sput-boolean v2, Lmi2;->f:Z

    :try_start_f
    const/16 v0, 0xafe

    iget-object p0, p0, Lnn1;->B:Lcom/android/billingclient/api/BillingClient;

    nop

    if-eqz p0, :cond_1c

    const/16 v0, 0xe5e

    invoke-virtual {p0}, Lcom/android/billingclient/api/BillingClient;->endConnection()V

    return-void

    :cond_1c
    const-string/jumbo p0, "billingClient"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0
    :try_end_25
    .catch Ljava/lang/Exception; {:try_start_f .. :try_end_25} :catch_25

    :catch_25
    return-void
.end method

.method public final onPurchasesUpdated(Lcom/android/billingclient/api/BillingResult;Ljava/util/List;)V
    .registers 19

    const/4 v7, -0x6

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x325

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getViewLifecycleOwner()Lh11;

    move-result-object v9

    const/4 v7, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x341

    invoke-static {v9}, Lns2;->m(Lh11;)Lc11;

    move-result-object v9

    const/16 v7, 0x4b0

    new-instance v10, Lmn1;

    nop

    const/4 v15, 0x0

    const/4 v14, 0x0

    move-object/from16 v11, p0

    move-object/from16 v12, p1

    move-object/from16 v13, p2

    const/16 v7, 0x2b1

    move v0, v7

    move-object v1, v10

    move-object v2, v11

    move-object v3, v12

    move-object v4, v13

    move-object v5, v14

    move v6, v15

    invoke-direct/range {v1 .. v6}, Lmn1;-><init>(Lnn1;Lcom/android/billingclient/api/BillingResult;Ljava/util/List;Lvx;I)V

    const/16 p0, 0x3

    const/16 v7, 0xb3

    move v0, v7

    move-object v1, v9

    move-object v2, v14

    move-object v3, v14

    move-object v4, v10

    move/from16 v5, p0

    invoke-static/range {v1 .. v5}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    return-void
.end method

.method public final onQueryPurchasesResponse(Lcom/android/billingclient/api/BillingResult;Ljava/util/List;)V
    .registers 19

    const/4 v7, -0x6

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v7, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x325

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getViewLifecycleOwner()Lh11;

    move-result-object v9

    const/4 v7, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x341

    invoke-static {v9}, Lns2;->m(Lh11;)Lc11;

    move-result-object v9

    const/16 v7, 0x4b0

    new-instance v10, Lmn1;

    nop

    const/4 v15, 0x1

    const/4 v14, 0x0

    move-object/from16 v11, p0

    move-object/from16 v12, p1

    move-object/from16 v13, p2

    const/16 v7, 0x2b1

    move v0, v7

    move-object v1, v10

    move-object v2, v11

    move-object v3, v12

    move-object v4, v13

    move-object v5, v14

    move v6, v15

    invoke-direct/range {v1 .. v6}, Lmn1;-><init>(Lnn1;Lcom/android/billingclient/api/BillingResult;Ljava/util/List;Lvx;I)V

    const/16 p0, 0x3

    const/16 v7, 0xb3

    move v0, v7

    move-object v1, v9

    move-object v2, v14

    move-object v3, v14

    move-object v4, v10

    move/from16 v5, p0

    invoke-static/range {v1 .. v5}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    return-void
.end method

.method public final onStart()V
    .registers 5

    .prologue
    const/16 v0, 0x55f

    invoke-super {p0}, Landroidx/fragment/app/g;->onStart()V

    const/16 v0, 0xaeb

    invoke-virtual {p0}, Landroidx/fragment/app/g;->getDialog()Landroid/app/Dialog;

    move-result-object p0

    if-eqz p0, :cond_34

    const/16 v0, 0xc8b

    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object p0

    if-eqz p0, :cond_34

    const/4 v2, -0x1

    const/4 v3, -0x2

    const/16 v0, 0x1132

    invoke-virtual {p0, v2, v3}, Landroid/view/Window;->setLayout(II)V

    const/16 v0, 0x10ad

    new-instance v2, Landroid/graphics/drawable/ColorDrawable;

    nop

    const/4 v3, 0x0

    const/16 v0, 0xc14

    invoke-direct {v2, v3}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    const/16 v0, 0xba3

    invoke-virtual {p0, v2}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    const v2, 0x7f140137

    const/16 v0, 0xa0d

    invoke-virtual {p0, v2}, Landroid/view/Window;->setWindowAnimations(I)V

    :cond_34
    return-void
.end method
