.class public final synthetic Lb;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/tlsvpn/tlstunnel/ui/About;


# direct methods
.method public synthetic constructor <init>(Lcom/tlsvpn/tlstunnel/ui/About;I)V
    .registers 5

    iput p2, p0, Lb;->a:I

    iput-object p1, p0, Lb;->b:Lcom/tlsvpn/tlstunnel/ui/About;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 5

    .prologue
    const/16 v0, 0x80d

    iget p1, p0, Lb;->a:I

    nop

    const v2, 0x7f090130

    const/16 v0, 0xb11

    iget-object p0, p0, Lb;->b:Lcom/tlsvpn/tlstunnel/ui/About;

    nop

    packed-switch p1, :pswitch_data_56

    const/16 v0, 0xfb

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p1, Lcom/tlsvpn/tlstunnel/MainActivity;

    const/16 v0, 0x1f9

    invoke-virtual {p1}, Lcom/tlsvpn/tlstunnel/MainActivity;->h()Lcom/google/android/material/bottomnavigation/BottomNavigationView;

    move-result-object p1

    const/16 v0, 0x29c

    invoke-virtual {p1, v2}, Lyd1;->setSelectedItemId(I)V

    const/16 v0, 0x108f

    iget-object p0, p0, Lcom/tlsvpn/tlstunnel/ui/About;->e:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    nop

    if-eqz p0, :cond_35

    const/4 p1, 0x1

    const/16 v0, 0xe37

    invoke-virtual {p0, p1}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->d(Z)V

    return-void

    :cond_35
    const-string/jumbo p0, "check"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0

    :pswitch_3e  #0x0
    const/16 v0, 0xfb

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object p0

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p0, Lcom/tlsvpn/tlstunnel/MainActivity;

    const/16 v0, 0x1f9

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/MainActivity;->h()Lcom/google/android/material/bottomnavigation/BottomNavigationView;

    move-result-object p0

    const/16 v0, 0x29c

    invoke-virtual {p0, v2}, Lyd1;->setSelectedItemId(I)V

    return-void

    :pswitch_data_56
    .packed-switch 0x0
        :pswitch_3e  #00000000
    .end packed-switch
.end method
