.class public final Lkn1;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public final synthetic t:Lnn1;

.field public final synthetic u:Ljava/lang/String;

.field public final synthetic v:Ljava/lang/String;

.field public final synthetic w:Ljava/lang/String;

.field public final synthetic x:Ljava/lang/String;

.field public final synthetic y:Lcom/android/billingclient/api/ProductDetails;


# direct methods
.method public constructor <init>(Lnn1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/android/billingclient/api/ProductDetails;Lvx;)V
    .registers 10

    iput-object p1, p0, Lkn1;->t:Lnn1;

    iput-object p2, p0, Lkn1;->u:Ljava/lang/String;

    iput-object p3, p0, Lkn1;->v:Ljava/lang/String;

    iput-object p4, p0, Lkn1;->w:Ljava/lang/String;

    iput-object p5, p0, Lkn1;->x:Ljava/lang/String;

    iput-object p6, p0, Lkn1;->y:Lcom/android/billingclient/api/ProductDetails;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p7}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 22

    const/16 v9, 0xb40

    new-instance v11, Lkn1;

    nop

    const/16 v9, 0xac9

    move-object/from16 v0, p0

    iget-object v9, v0, Lkn1;->x:Ljava/lang/String;

    move-object/16 v16, v9

    const/16 v9, 0xb8e

    move-object/from16 v0, p0

    iget-object v9, v0, Lkn1;->y:Lcom/android/billingclient/api/ProductDetails;

    move-object/16 v17, v9

    const/16 v9, 0x9c2

    move-object/from16 v0, p0

    iget-object v12, v0, Lkn1;->t:Lnn1;

    nop

    const/16 v9, 0x9f6

    move-object/from16 v0, p0

    iget-object v13, v0, Lkn1;->u:Ljava/lang/String;

    nop

    const/16 v9, 0x931

    move-object/from16 v0, p0

    iget-object v14, v0, Lkn1;->v:Ljava/lang/String;

    nop

    const/16 v9, 0xb2b

    move-object/from16 v0, p0

    iget-object v15, v0, Lkn1;->w:Ljava/lang/String;

    nop

    move-object/from16 v18, p1

    const/16 v9, 0x9af

    move v0, v9

    move-object v1, v11

    move-object v2, v12

    move-object v3, v13

    move-object v4, v14

    move-object v5, v15

    move-object/from16 v6, v16

    move-object/from16 v7, v17

    move-object/from16 v8, v18

    invoke-direct/range {v1 .. v8}, Lkn1;-><init>(Lnn1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/android/billingclient/api/ProductDetails;Lvx;)V

    check-cast v11, Lvx;

    return-object v11
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    const/16 v0, 0xe27

    invoke-virtual {p0, p2, p1}, Lkn1;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lkn1;

    const/16 v0, 0x21

    sget-object p1, Lrg2;->a:Lrg2;

    nop

    const/16 v0, 0xf85

    invoke-virtual {p0, p1}, Lkn1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast p1, Ljava/lang/Object;

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 14

    .prologue
    const/4 v0, 0x6

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v0, 0x9c2

    iget-object p1, p0, Lkn1;->t:Lnn1;

    nop

    const/16 v0, 0x8d7

    iget-object v2, p1, Lnn1;->q:Lw82;

    nop

    const/16 v0, 0x177

    invoke-virtual {v2}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/content/SharedPreferences;

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x7a

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string/jumbo v3, "pvdata"

    const-string/jumbo v4, ""

    const/16 v0, 0x3c

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x6f

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/16 v0, 0x12c

    iget-object v2, p1, Lnn1;->t:Landroid/widget/LinearLayout;

    nop

    const/4 v3, 0x0

    if-eqz v2, :cond_1a1

    const/4 v4, 0x0

    const/4 v0, -0x5

    invoke-virtual {v2, v4}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0x25e

    iget-object v2, p1, Lnn1;->x:Landroid/widget/RadioGroup;

    nop

    const-string/jumbo v5, "rgplanos"

    if-eqz v2, :cond_19c

    const/4 v0, -0x5

    invoke-virtual {v2, v4}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0x17a

    iget-object v2, p1, Lnn1;->s:Landroid/widget/ProgressBar;

    nop

    if-eqz v2, :cond_194

    const/16 v6, 0x8

    const/4 v0, -0x5

    invoke-virtual {v2, v6}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0x8e8

    iget-object v2, p1, Lnn1;->y:Landroid/widget/RadioButton;

    nop

    if-eqz v2, :cond_18c

    const/4 v0, -0x3

    new-instance v7, Ljava/lang/StringBuilder;

    nop

    const/4 v0, -0x4

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const v8, 0x7f130263

    const/16 v0, 0x4c

    invoke-virtual {p1, v8}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v8

    const/4 v0, 0x0

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v8, " ("

    const/4 v0, 0x0

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x9f6

    iget-object v9, p0, Lkn1;->u:Ljava/lang/String;

    nop

    const/4 v0, 0x0

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v9, 0x29

    const/16 v0, 0x1b

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const/16 v0, 0x8a

    invoke-virtual {v2, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v0, 0x931

    iget-object v2, p0, Lkn1;->v:Ljava/lang/String;

    nop

    const/16 v0, 0x47

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v7

    const-string/jumbo v10, "rbanual"

    if-lez v7, :cond_ee

    const/16 v0, 0x1b6

    iget-object v6, p1, Lnn1;->z:Landroid/widget/RadioButton;

    nop

    if-eqz v6, :cond_e9

    const/4 v0, -0x3

    new-instance v7, Ljava/lang/StringBuilder;

    nop

    const/4 v0, -0x4

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const v11, 0x7f1300b0

    const/16 v0, 0x4c

    invoke-virtual {p1, v11}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v11

    const/4 v0, 0x0

    invoke-virtual {v7, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x1b

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/16 v0, 0x8a

    invoke-virtual {v6, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v0, 0x1b6

    iget-object v2, p1, Lnn1;->z:Landroid/widget/RadioButton;

    nop

    if-eqz v2, :cond_e4

    const/4 v0, -0x5

    invoke-virtual {v2, v4}, Landroid/view/View;->setVisibility(I)V

    goto :goto_108

    :cond_e4
    const/4 v0, 0x5

    invoke-static {v10}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_e9
    const/4 v0, 0x5

    invoke-static {v10}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_ee
    const/16 v0, 0x25e

    iget-object v2, p1, Lnn1;->x:Landroid/widget/RadioGroup;

    nop

    if-eqz v2, :cond_187

    const v4, 0x7f0902dd

    const/16 v0, 0xdfa

    invoke-virtual {v2, v4}, Landroid/widget/RadioGroup;->check(I)V

    const/16 v0, 0x1b6

    iget-object v2, p1, Lnn1;->z:Landroid/widget/RadioButton;

    nop

    if-eqz v2, :cond_182

    const/4 v0, -0x5

    invoke-virtual {v2, v6}, Landroid/view/View;->setVisibility(I)V

    :goto_108
    const/16 v0, 0x25e

    iget-object v2, p1, Lnn1;->x:Landroid/widget/RadioGroup;

    nop

    if-eqz v2, :cond_17d

    const/16 v0, 0xbe7

    new-instance v4, Ljn1;

    nop

    const/16 v0, 0xb2b

    iget-object v5, p0, Lkn1;->w:Ljava/lang/String;

    nop

    const/16 v0, 0xac9

    iget-object v6, p0, Lkn1;->x:Ljava/lang/String;

    nop

    const/16 v0, 0xb42

    invoke-direct {v4, p1, v5, v6}, Ljn1;-><init>(Lnn1;Ljava/lang/String;Ljava/lang/String;)V

    const/16 v0, 0x94d

    invoke-virtual {v2, v4}, Landroid/widget/RadioGroup;->setOnCheckedChangeListener(Landroid/widget/RadioGroup$OnCheckedChangeListener;)V

    const/16 v0, 0xc2

    iget-object v2, p1, Lnn1;->v:Landroid/widget/LinearLayout;

    nop

    const-string/jumbo v4, "assinar"

    if-eqz v2, :cond_178

    const/4 v5, 0x1

    const/16 v0, 0xf7

    invoke-virtual {v2, v5}, Landroid/view/View;->setEnabled(Z)V

    const/16 v0, 0x1e4

    iget-object v2, p1, Lnn1;->w:Landroid/widget/TextView;

    nop

    if-eqz v2, :cond_170

    const v5, 0x7f130218

    const/16 v0, 0x93

    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setText(I)V

    const/16 v0, 0xc2

    iget-object v2, p1, Lnn1;->v:Landroid/widget/LinearLayout;

    nop

    if-eqz v2, :cond_16b

    const/16 v0, 0xf56

    new-instance v3, Lgd0;

    nop

    const/4 v4, 0x2

    const/16 v0, 0xb8e

    iget-object p0, p0, Lkn1;->y:Lcom/android/billingclient/api/ProductDetails;

    nop

    const/16 v0, 0x708

    invoke-direct {v3, v4, p1, p0}, Lgd0;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    const/16 v0, 0x5f

    invoke-virtual {v2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0x21

    sget-object p0, Lrg2;->a:Lrg2;

    nop

    check-cast p0, Ljava/lang/Object;

    return-object p0

    :cond_16b
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_170
    const-string/jumbo p0, "assinartxt"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_178
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_17d
    const/4 v0, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_182
    const/4 v0, 0x5

    invoke-static {v10}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_187
    const/4 v0, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_18c
    const-string/jumbo p0, "rbmensal"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_194
    const-string/jumbo p0, "progress"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_19c
    const/4 v0, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_1a1
    const-string/jumbo p0, "conteudo"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3
.end method
