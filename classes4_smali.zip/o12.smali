.class public final synthetic Lo12;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lzj0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/tlsvpn/tlstunnel/services/ServicoVpn;


# direct methods
.method public synthetic constructor <init>(Lcom/tlsvpn/tlstunnel/services/ServicoVpn;I)V
    .registers 5

    iput p2, p0, Lo12;->a:I

    iput-object p1, p0, Lo12;->b:Lcom/tlsvpn/tlstunnel/services/ServicoVpn;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 4

    .prologue
    const/16 v0, 0xc09

    iget v2, p0, Lo12;->a:I

    nop

    const/16 v0, 0x572

    iget-object p0, p0, Lo12;->b:Lcom/tlsvpn/tlstunnel/services/ServicoVpn;

    nop

    packed-switch v2, :pswitch_data_46

    const/16 v0, 0x1c9

    sget v2, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->q:I

    nop

    const-string/jumbo v2, "connectivity"

    const/16 v0, 0x31d

    invoke-virtual {p0, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p0, Landroid/net/ConnectivityManager;

    return-object p0

    :pswitch_22  #0x1
    const/16 v0, 0x1c9

    sget v2, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->q:I

    nop

    const-string/jumbo v2, "notification"

    const/16 v0, 0x31d

    invoke-virtual {p0, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p0, Landroid/app/NotificationManager;

    return-object p0

    :pswitch_37  #0x0
    const/16 v0, 0x1c9

    sget v2, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->q:I

    nop

    const/16 v0, 0x2a

    invoke-static {p0}, Lxl1;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    check-cast p0, Ljava/lang/Object;

    return-object p0

    nop

    :pswitch_data_46
    .packed-switch 0x0
        :pswitch_37  #00000000
        :pswitch_22  #00000001
    .end packed-switch
.end method
