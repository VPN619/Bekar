.class public abstract Lil1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final a:Ljava/util/Set;


# direct methods
.method static constructor <clinit>()V
    .registers 5

    const/16 v2, 0x10d

    new-array v2, v2, [Ljava/lang/String;

    const-string/jumbo v3, "app.com.torrentdownload"

    const/4 v4, 0x0

    aput-object v3, v2, v4

    const-string/jumbo v3, "app.com.torrentdownloadpremium"

    const/4 v4, 0x1

    aput-object v3, v2, v4

    const-string/jumbo v3, "app.movietorrent.torrentdownload"

    const/4 v4, 0x2

    aput-object v3, v2, v4

    const-string/jumbo v3, "app.no.ytsnoads"

    const/4 v4, 0x3

    aput-object v3, v2, v4

    const-string/jumbo v3, "apps.degsware.torrent_info_hash_to_magnet"

    const/4 v4, 0x4

    aput-object v3, v2, v4

    const-string/jumbo v3, "bitking.torrent.downloader"

    const/4 v4, 0x5

    aput-object v3, v2, v4

    const-string/jumbo v3, "cili.niao.search.bt.ci.li"

    const/4 v4, 0x6

    aput-object v3, v2, v4

    const-string/jumbo v3, "co.bitwire.torrent"

    const/4 v4, 0x7

    aput-object v3, v2, v4

    const-string/jumbo v3, "co.gapsoft.torrent"

    const/16 v4, 0x8

    aput-object v3, v2, v4

    const-string/jumbo v3, "co.turbotorrentapp.downloader"

    const/16 v4, 0x9

    aput-object v3, v2, v4

    const-string/jumbo v3, "co.we.torrent"

    const/16 v4, 0xa

    aput-object v3, v2, v4

    const-string/jumbo v3, "codexial.movies.torrent"

    const/16 v4, 0xb

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.AndroidA.DroiDownloader"

    const/16 v4, 0xc

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.DroiDownloader"

    const/16 v4, 0xd

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.Kumargoura.torrent"

    const/16 v4, 0xe

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.TorrMonk"

    const/16 v4, 0xf

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.advice.drone"

    const/16 v4, 0x10

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.akingi.torrent"

    const/16 v4, 0x11

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.akingi.torrent2"

    const/16 v4, 0x12

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.amnis"

    const/16 v4, 0x13

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.anantadwi13.playtorrent"

    const/16 v4, 0x14

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.androfysolutions.torrentlite"

    const/16 v4, 0x15

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.ap.transmission.btc"

    const/16 v4, 0x16

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.apoorvasingh.streamer"

    const/16 v4, 0x17

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.apoot.bt2magnet"

    const/16 v4, 0x18

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.appwin.torrent.moviedownloader"

    const/16 v4, 0x19

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.appybuilder.ideaberry0.tolink"

    const/16 v4, 0x1a

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.arjuntsgowda.test"

    const/16 v4, 0x1b

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.asterisklab.tornado"

    const/16 v4, 0x1c

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.atorrent.vreng"

    const/16 v4, 0x1d

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.azmra.aztorrent"

    const/16 v4, 0x1e

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.baliyaan.android.imdbtor"

    const/16 v4, 0x1f

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.betorrent.client"

    const/16 v4, 0x20

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.better.app.torrentsearch"

    const/16 v4, 0x21

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.biglybt.android.client"

    const/16 v4, 0x22

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.bitcomet.android"

    const/16 v4, 0x23

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.bitnet.betorrentadvancetorrentdownloaderpro"

    const/16 v4, 0x24

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.bittorrent.client"

    const/16 v4, 0x25

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.bittorrent.client.pro"

    const/16 v4, 0x26

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.bittorrent.download.torrent.go"

    const/16 v4, 0x27

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.brute.torrentolite"

    const/16 v4, 0x28

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.captaindroid.torrentclient"

    const/16 v4, 0x29

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.cmtiger.download"

    const/16 v4, 0x2a

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.content.magnetsearch"

    const/16 v4, 0x2b

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.davidhodges.torrentsearch"

    const/16 v4, 0x2c

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.delphicoder.flud"

    const/16 v4, 0x2d

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.delphicoder.flud.paid"

    const/16 v4, 0x2e

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.dev.florian.yggcompagnon"

    const/16 v4, 0x2f

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.devmeca.simpletorrent"

    const/16 v4, 0x30

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.dextersbrain.mobmovie"

    const/16 v4, 0x31

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.digitalmedia.moviedownloader"

    const/16 v4, 0x32

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.dokenedgar.movieapp"

    const/16 v4, 0x33

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.down.move.films"

    const/16 v4, 0x34

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.down.torrent"

    const/16 v4, 0x35

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.download.fluidtorrent"

    const/16 v4, 0x36

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.download.torrent.magnet"

    const/16 v4, 0x37

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.downloadmanager.moviedownloader"

    const/16 v4, 0x38

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.downloadmovies.hdmovies4u"

    const/16 v4, 0x39

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.dv.adm"

    const/16 v4, 0x3a

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.dv.adm.pay"

    const/16 v4, 0x3b

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.dvillegas.torrents"

    const/16 v4, 0x3c

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.easelifeapps.torrz"

    const/16 v4, 0x3d

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.efs.movietime"

    const/16 v4, 0x3e

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.emilcodes.yts_browser"

    const/16 v4, 0x3f

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.epic.app.iTorrent"

    const/16 v4, 0x40

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.evancejaye.torrenttime"

    const/16 v4, 0x41

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.fahad.ali.movies"

    const/16 v4, 0x42

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.fgrouptech.kickasstorrents"

    const/16 v4, 0x43

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.filmdownloader.tecpiranha.malludroid"

    const/16 v4, 0x44

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.flowapp.tvmagnet2"

    const/16 v4, 0x45

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.foossi.bitcloud"

    const/16 v4, 0x46

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.free.movie.tube"

    const/16 v4, 0x47

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.free.torrent.client.torrentdownloader"

    const/16 v4, 0x48

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.free.yts.moviedownloader.torrent"

    const/16 v4, 0x49

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.free.yts.torrentmovie"

    const/16 v4, 0x4a

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.freemoviedownloader.freetorrentmoviedownloader.freehollywoodytstmdbpopcornvdf"

    const/16 v4, 0x4b

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.freetorrentmovies.freemoviedownloader.freeytspopcornmoviesvdt"

    const/16 v4, 0x4c

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.freeyts.torrent.moviedownloder"

    const/16 v4, 0x4d

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.frostwire.android"

    const/16 v4, 0x4e

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.gabordemko.torrnado"

    const/16 v4, 0x4f

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.gamemalt.streamtorrentvideos"

    const/16 v4, 0x50

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.gamemalt.torrentwiz"

    const/16 v4, 0x51

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.gianlu.aria2app"

    const/16 v4, 0x52

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.halle.torrentdownloader"

    const/16 v4, 0x53

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.haris.ali.moviedownloader"

    const/16 v4, 0x54

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.hfz.ali.moviedownloader"

    const/16 v4, 0x55

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.houseoflife.bitlord"

    const/16 v4, 0x56

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.hrsali.moviebrowser"

    const/16 v4, 0x57

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.hwkrbbt.downloadall"

    const/16 v4, 0x58

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.icodelife.itorrentsearch"

    const/16 v4, 0x59

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.inceptionapps.torrentstream"

    const/16 v4, 0x5a

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.indris.yifytorrents"

    const/16 v4, 0x5b

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.inetric.orxy"

    const/16 v4, 0x5c

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.isautomation.torrent2magnet"

    const/16 v4, 0x5d

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.jeetproductions.itorrent"

    const/16 v4, 0x5e

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.kelmatech.youtorrent"

    const/16 v4, 0x5f

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.keno.torrent.movie.downloader"

    const/16 v4, 0x60

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.kevinforeman.nzb360"

    const/16 v4, 0x61

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.kexmon.theMovieApp"

    const/16 v4, 0x62

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.leaftorrent_magneticlinks.torrent_search_engine"

    const/16 v4, 0x63

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.librastudiosinc.moviedownloaderhd"

    const/16 v4, 0x64

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.lightswitch.torrently"

    const/16 v4, 0x65

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.lntrend.lntorrent"

    const/16 v4, 0x66

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.logiclooper.idm"

    const/16 v4, 0x67

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.magdalm.downloadmanager"

    const/16 v4, 0x68

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.maghribpress.torrebook"

    const/16 v4, 0x69

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.magnetmotordebuscas"

    const/16 v4, 0x6a

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.marutigroup.downtor"

    const/16 v4, 0x6b

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.masterwok.shrimplesearch"

    const/16 v4, 0x6c

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.mediaget.android"

    const/16 v4, 0x6d

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.mediastream.torrentdownloader"

    const/16 v4, 0x6e

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.mobilityflow.torrent"

    const/16 v4, 0x6f

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.mobilityflow.torrent.prof"

    const/16 v4, 0x70

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.mobilityflow.tvp"

    const/16 v4, 0x71

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.movie.show.moviedownloader"

    const/16 v4, 0x72

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.movie.skd.downloader"

    const/16 v4, 0x73

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.movie.torrent.downloader"

    const/16 v4, 0x74

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.movie.torrentmovie.freedownloader"

    const/16 v4, 0x75

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.movie.tvshow.details"

    const/16 v4, 0x76

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.movie.tvshow.details.one"

    const/16 v4, 0x77

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.moviedownload.torrent"

    const/16 v4, 0x78

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.moviedownloader.torrentdownload.freemovie"

    const/16 v4, 0x79

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.moviedownloader.torrentsearch.freemovie"

    const/16 v4, 0x7a

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.movies.torrentmovies"

    const/16 v4, 0x7b

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.mtorrent.client"

    const/16 v4, 0x7c

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.nebula.swift"

    const/16 v4, 0x7d

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.nest.logix.metorrent.hd.movies.torrent"

    const/16 v4, 0x7e

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.nestloigix.supertorrent.downloaderapp"

    const/16 v4, 0x7f

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.newtechn.torrentdwnloader"

    const/16 v4, 0x80

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.nitroxenon.terrarium"

    const/16 v4, 0x81

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.oidapps.bittorrent"

    const/16 v4, 0x82

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.oubrDB.torrentHunt"

    const/16 v4, 0x83

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.outlook.intorrent.app"

    const/16 v4, 0x84

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.paolod.torrentsearch2"

    const/16 v4, 0x85

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.pitorrent.client.torrent"

    const/16 v4, 0x86

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.pixeltech.ptorrent"

    const/16 v4, 0x87

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.pixeltech.ptorrent.pro"

    const/16 v4, 0x88

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.pk.torrbot"

    const/16 v4, 0x89

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.pklbox.translatorspro"

    const/16 v4, 0x8a

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.portcase.player.android"

    const/16 v4, 0x8b

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.prostudio.inc.ztorrent"

    const/16 v4, 0x8c

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.rb.rbtorrent"

    const/16 v4, 0x8d

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.revolgenx.lemillion"

    const/16 v4, 0x8e

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.rsa.transgui"

    const/16 v4, 0x8f

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.rubycell.apps.internet.download.manager"

    const/16 v4, 0x90

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.saxtorrents.app"

    const/16 v4, 0x91

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.sdownloader.iq.downloader"

    const/16 v4, 0x92

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.search.torso"

    const/16 v4, 0x93

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.sheikh.ali.moviedownloader"

    const/16 v4, 0x94

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.shivam.torrent_search"

    const/16 v4, 0x95

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.shivam.torrent_search.pro"

    const/16 v4, 0x96

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.siberianwildapps.tapeer"

    const/16 v4, 0x97

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.sitbit.torrent"

    const/16 v4, 0x98

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.sptorrent.torrentdownloader"

    const/16 v4, 0x99

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.ss.video"

    const/16 v4, 0x9a

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.storrent"

    const/16 v4, 0x9b

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.stream.torrentmovies"

    const/16 v4, 0x9c

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.stremio"

    const/16 v4, 0x9d

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.stremio.one"

    const/16 v4, 0x9e

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.tdo.showbox"

    const/16 v4, 0x9f

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.technoxyz.android"

    const/16 v4, 0xa0

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.teeonsoft.ztorrent"

    const/16 v4, 0xa1

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.teeonsoft.ztorrentpro"

    const/16 v4, 0xa2

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.teleaus.talenttorrentandroid"

    const/16 v4, 0xa3

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.tordown.torrentsave"

    const/16 v4, 0xa4

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.torrent"

    const/16 v4, 0xa5

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.torrent.appfor.movies.downloader.free.utorrent.bittorrent.downloader"

    const/16 v4, 0xa6

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.torrent.downloader.manager"

    const/16 v4, 0xa7

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.torrent.safe.watch"

    const/16 v4, 0xa8

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.torrent.search.revolution"

    const/16 v4, 0xa9

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.torrent.searchengine.moviedownloader"

    const/16 v4, 0xaa

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.torrent_downloader.torrentify"

    const/16 v4, 0xab

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.torrentdownloader.appstar.torrentclient"

    const/16 v4, 0xac

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.torrentdownloader.form.bittorrent"

    const/16 v4, 0xad

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.torrentdownloader.masterclient"

    const/16 v4, 0xae

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.torrently.downloader"

    const/16 v4, 0xaf

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.torrentor.iam"

    const/16 v4, 0xb0

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.torrentseeker_torrentsearch.engine_dev"

    const/16 v4, 0xb1

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.torrentspro.safetorrentapp"

    const/16 v4, 0xb2

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.torrentstreamer.app"

    const/16 v4, 0xb3

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.torrentvilla.romreviwer.com"

    const/16 v4, 0xb4

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.torrentvillalite.romreviewer.com"

    const/16 v4, 0xb5

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.torrget.app"

    const/16 v4, 0xb6

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.torro.kali"

    const/16 v4, 0xb7

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.utorrent.client"

    const/16 v4, 0xb8

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.utorrent.client.pro"

    const/16 v4, 0xb9

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.utorrent.web"

    const/16 v4, 0xba

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.vbanimt.freemoviedownloader"

    const/16 v4, 0xbb

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.vetornorte.torrent"

    const/16 v4, 0xbc

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.victoriya.tortube"

    const/16 v4, 0xbd

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.vihatsoft.cloudtab"

    const/16 v4, 0xbe

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.vit.torrentplayer"

    const/16 v4, 0xbf

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.vuze.android.remote"

    const/16 v4, 0xc0

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.vuze.torrent.downloader"

    const/16 v4, 0xc1

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.wMediaTorrentCatalog_4259736"

    const/16 v4, 0xc2

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.webtorrent.app"

    const/16 v4, 0xc3

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.worldcodes.lorie"

    const/16 v4, 0xc4

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.wssolutions.wstorrent"

    const/16 v4, 0xc5

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.xDgit.galaxyTorrentVPN"

    const/16 v4, 0xc6

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.xunlei.downloadprovider"

    const/16 v4, 0xc7

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.yablio.torrentium"

    const/16 v4, 0xc8

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.yts.latest_movies"

    const/16 v4, 0xc9

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.ytsmoviedownload.moviedownloader"

    const/16 v4, 0xca

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.ytv.ytv"

    const/16 v4, 0xcb

    aput-object v3, v2, v4

    const-string/jumbo v3, "com.zamdevinc.ztorrent"

    const/16 v4, 0xcc

    aput-object v3, v2, v4

    const-string/jumbo v3, "connect.torrentpower"

    const/16 v4, 0xcd

    aput-object v3, v2, v4

    const-string/jumbo v3, "downloader.torrent.moviedownloader"

    const/16 v4, 0xce

    aput-object v3, v2, v4

    const-string/jumbo v3, "downloader.ytsmovie.torrent"

    const/16 v4, 0xcf

    aput-object v3, v2, v4

    const-string/jumbo v3, "dwleee.torrentsearch"

    const/16 v4, 0xd0

    aput-object v3, v2, v4

    const-string/jumbo v3, "fast.downloader.ytorrent.lite"

    const/16 v4, 0xd1

    aput-object v3, v2, v4

    const-string/jumbo v3, "finca.estorrent2"

    const/16 v4, 0xd2

    aput-object v3, v2, v4

    const-string/jumbo v3, "free.full.torrent.moviedownloader"

    const/16 v4, 0xd3

    aput-object v3, v2, v4

    const-string/jumbo v3, "freehdtorrentmoviesvt.freehdmoviedownloadervt.freepopcornbucketmoviesdownloadervt"

    const/16 v4, 0xd4

    aput-object v3, v2, v4

    const-string/jumbo v3, "hu.bute.daai.amorg.drtorrent"

    const/16 v4, 0xd5

    aput-object v3, v2, v4

    const-string/jumbo v3, "hu.tagsoft.ttorrent.lite"

    const/16 v4, 0xd6

    aput-object v3, v2, v4

    const-string/jumbo v3, "hu.tagsoft.ttorrent.noads"

    const/16 v4, 0xd7

    aput-object v3, v2, v4

    const-string/jumbo v3, "idm.full.downloader.download.manager"

    const/16 v4, 0xd8

    aput-object v3, v2, v4

    const-string/jumbo v3, "idm.internet.download.manager"

    const/16 v4, 0xd9

    aput-object v3, v2, v4

    const-string/jumbo v3, "idm.internet.download.manager.adm.lite"

    const/16 v4, 0xda

    aput-object v3, v2, v4

    const-string/jumbo v3, "idm.internet.download.manager.plus"

    const/16 v4, 0xdb

    aput-object v3, v2, v4

    const-string/jumbo v3, "in.gopalakrishnareddy.torrent"

    const/16 v4, 0xdc

    aput-object v3, v2, v4

    const-string/jumbo v3, "info.popcorntime.app"

    const/16 v4, 0xdd

    aput-object v3, v2, v4

    const-string/jumbo v3, "intelligems.torrdroid"

    const/16 v4, 0xde

    aput-object v3, v2, v4

    const-string/jumbo v3, "io.bitport.bitportflutterapp"

    const/16 v4, 0xdf

    aput-object v3, v2, v4

    const-string/jumbo v3, "io.torrentdrive.app"

    const/16 v4, 0xe0

    aput-object v3, v2, v4

    const-string/jumbo v3, "lt.yts"

    const/16 v4, 0xe1

    aput-object v3, v2, v4

    const-string/jumbo v3, "me.fengmlo.qbRemote"

    const/16 v4, 0xe2

    aput-object v3, v2, v4

    const-string/jumbo v3, "megabyte.dm"

    const/16 v4, 0xe3

    aput-object v3, v2, v4

    const-string/jumbo v3, "megabyte.tdm"

    const/16 v4, 0xe4

    aput-object v3, v2, v4

    const-string/jumbo v3, "microtech.movie.torrentdownloader"

    const/16 v4, 0xe5

    aput-object v3, v2, v4

    const-string/jumbo v3, "mobidev.apps.torrent"

    const/16 v4, 0xe6

    aput-object v3, v2, v4

    const-string/jumbo v3, "mobidevcodexial.movies.torrent"

    const/16 v4, 0xe7

    aput-object v3, v2, v4

    const-string/jumbo v3, "net.pryvate.onionbrowser"

    const/16 v4, 0xe8

    aput-object v3, v2, v4

    const-string/jumbo v3, "net.yupol.transmissionremote.app"

    const/16 v4, 0xe9

    aput-object v3, v2, v4

    const-string/jumbo v3, "nextera.torrent.moviedownloader"

    const/16 v4, 0xea

    aput-object v3, v2, v4

    const-string/jumbo v3, "nl.timkatgert.mediasplash"

    const/16 v4, 0xeb

    aput-object v3, v2, v4

    const-string/jumbo v3, "nl.timkatgert.nzbmanager"

    const/16 v4, 0xec

    aput-object v3, v2, v4

    const-string/jumbo v3, "org.anacletus.geted2k"

    const/16 v4, 0xed

    aput-object v3, v2, v4

    const-string/jumbo v3, "org.artechis.btorrent"

    const/16 v4, 0xee

    aput-object v3, v2, v4

    const-string/jumbo v3, "org.btorrent.hgcor"

    const/16 v4, 0xef

    aput-object v3, v2, v4

    const-string/jumbo v3, "org.camquilt.torrentdownloader"

    const/16 v4, 0xf0

    aput-object v3, v2, v4

    const-string/jumbo v3, "org.equeim.tremotesf"

    const/16 v4, 0xf1

    aput-object v3, v2, v4

    const-string/jumbo v3, "org.fiveg.torrent"

    const/16 v4, 0xf2

    aput-object v3, v2, v4

    const-string/jumbo v3, "org.freedownloadmanager.fdm"

    const/16 v4, 0xf3

    aput-object v3, v2, v4

    const-string/jumbo v3, "org.itsasoftware.dast"

    const/16 v4, 0xf4

    aput-object v3, v2, v4

    const-string/jumbo v3, "org.jsp.wide"

    const/16 v4, 0xf5

    aput-object v3, v2, v4

    const-string/jumbo v3, "org.postinitdev.bitraytorrent"

    const/16 v4, 0xf6

    aput-object v3, v2, v4

    const-string/jumbo v3, "org.proninyaroslav.libretorrent"

    const/16 v4, 0xf7

    aput-object v3, v2, v4

    const-string/jumbo v3, "org.proninyaroslav.speedtorrent"

    const/16 v4, 0xf8

    aput-object v3, v2, v4

    const-string/jumbo v3, "org.razint.ritorrent"

    const/16 v4, 0xf9

    aput-object v3, v2, v4

    const-string/jumbo v3, "org.torproject.android"

    const/16 v4, 0xfa

    aput-object v3, v2, v4

    const-string/jumbo v3, "org.torproject.torbrowser"

    const/16 v4, 0xfb

    aput-object v3, v2, v4

    const-string/jumbo v3, "org.torproject.torbrowser_alpha"

    const/16 v4, 0xfc

    aput-object v3, v2, v4

    const-string/jumbo v3, "org.tr.torrent"

    const/16 v4, 0xfd

    aput-object v3, v2, v4

    const-string/jumbo v3, "org.transdroid.lite"

    const/16 v4, 0xfe

    aput-object v3, v2, v4

    const-string/jumbo v3, "org.viento.breeze"

    const/16 v4, 0xff

    aput-object v3, v2, v4

    const-string/jumbo v3, "org.xbmc.kodi"

    const/16 v4, 0x100

    aput-object v3, v2, v4

    const-string/jumbo v3, "ru.jsql.android.torrent"

    const/16 v4, 0x101

    aput-object v3, v2, v4

    const-string/jumbo v3, "ru.taptm.qbitremote"

    const/16 v4, 0x102

    aput-object v3, v2, v4

    const-string/jumbo v3, "se.popcorn_time.android"

    const/16 v4, 0x103

    aput-object v3, v2, v4

    const-string/jumbo v3, "smartsolutions.torrent.bittorrent.torrents.torrentclient"

    const/16 v4, 0x104

    aput-object v3, v2, v4

    const-string/jumbo v3, "tech.devm.movies_torrent"

    const/16 v4, 0x105

    aput-object v3, v2, v4

    const-string/jumbo v3, "tmkapps.torrentmagnet.converter"

    const/16 v4, 0x106

    aput-object v3, v2, v4

    const-string/jumbo v3, "torrent"

    const/16 v4, 0x107

    aput-object v3, v2, v4

    const-string/jumbo v3, "tv.bitx.media"

    const/16 v4, 0x108

    aput-object v3, v2, v4

    const-string/jumbo v3, "tv.strem.app"

    const/16 v4, 0x109

    aput-object v3, v2, v4

    const-string/jumbo v3, "yts.appinvents.torrent"

    const/16 v4, 0x10a

    aput-object v3, v2, v4

    const-string/jumbo v3, "zbr.natamvora.torrentdownloadertwentytwenty"

    const/16 v4, 0x10b

    aput-object v3, v2, v4

    const-string/jumbo v3, "zig.zak.media.tor"

    const/16 v4, 0x10c

    aput-object v3, v2, v4

    const/16 v0, 0xbbd

    invoke-static {v2}, Laf;->x0([Ljava/lang/Object;)Ljava/util/Set;

    move-result-object v2

    check-cast v2, Ljava/util/Set;

    sput-object v2, Lil1;->a:Ljava/util/Set;

    return-void
.end method
