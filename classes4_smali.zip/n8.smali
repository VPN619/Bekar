.class public final Ln8;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lm8;
.implements Lky;
.implements Lyt;
.implements Lcom/google/android/gms/internal/consent_sdk/zzqp;
.implements Lcom/google/android/gms/common/api/internal/RemoteCall;
.implements Lk4;
.implements Lsl;
.implements Lua0;
.implements Le82;
.implements Ljm1;


# static fields
.field public static volatile b:Ln8;

.field public static final synthetic c:Ln8;

.field public static final d:Ln8;

.field public static final e:Ln8;

.field public static final f:Ln8;

.field public static final g:Ln8;

.field public static final h:Ln8;

.field public static final i:Ln8;

.field public static final j:Ln8;

.field public static final k:Ln8;

.field public static final l:Ln8;

.field public static final m:Ln8;

.field public static final n:Ln8;

.field public static final o:Ln8;

.field public static final p:Ln8;

.field public static final q:Ln8;

.field public static final r:Ln8;


# instance fields
.field public final synthetic a:I


# direct methods
.method static synthetic constructor <clinit>()V
    .registers 2

    new-instance v0, Ln8;

    const/4 v1, 0x2

    invoke-direct {v0, v1}, Ln8;-><init>(I)V

    sput-object v0, Ln8;->c:Ln8;

    new-instance v0, Ln8;

    const/4 v1, 0x3

    invoke-direct {v0, v1}, Ln8;-><init>(I)V

    sput-object v0, Ln8;->d:Ln8;

    new-instance v0, Ln8;

    const/4 v1, 0x4

    invoke-direct {v0, v1}, Ln8;-><init>(I)V

    sput-object v0, Ln8;->e:Ln8;

    new-instance v0, Ln8;

    const/4 v1, 0x5

    invoke-direct {v0, v1}, Ln8;-><init>(I)V

    sput-object v0, Ln8;->f:Ln8;

    new-instance v0, Ln8;

    const/4 v1, 0x6

    invoke-direct {v0, v1}, Ln8;-><init>(I)V

    sput-object v0, Ln8;->g:Ln8;

    new-instance v0, Ln8;

    const/4 v1, 0x7

    invoke-direct {v0, v1}, Ln8;-><init>(I)V

    sput-object v0, Ln8;->h:Ln8;

    new-instance v0, Ln8;

    const/16 v1, 0x8

    invoke-direct {v0, v1}, Ln8;-><init>(I)V

    sput-object v0, Ln8;->i:Ln8;

    new-instance v0, Ln8;

    const/16 v1, 0x9

    invoke-direct {v0, v1}, Ln8;-><init>(I)V

    sput-object v0, Ln8;->j:Ln8;

    new-instance v0, Ln8;

    const/16 v1, 0xa

    invoke-direct {v0, v1}, Ln8;-><init>(I)V

    sput-object v0, Ln8;->k:Ln8;

    new-instance v0, Ln8;

    const/16 v1, 0xb

    invoke-direct {v0, v1}, Ln8;-><init>(I)V

    sput-object v0, Ln8;->l:Ln8;

    new-instance v0, Ln8;

    const/16 v1, 0xc

    invoke-direct {v0, v1}, Ln8;-><init>(I)V

    sput-object v0, Ln8;->m:Ln8;

    new-instance v0, Ln8;

    const/16 v1, 0xd

    invoke-direct {v0, v1}, Ln8;-><init>(I)V

    sput-object v0, Ln8;->n:Ln8;

    new-instance v0, Ln8;

    const/16 v1, 0xe

    invoke-direct {v0, v1}, Ln8;-><init>(I)V

    sput-object v0, Ln8;->o:Ln8;

    new-instance v0, Ln8;

    const/16 v1, 0xf

    invoke-direct {v0, v1}, Ln8;-><init>(I)V

    sput-object v0, Ln8;->p:Ln8;

    new-instance v0, Ln8;

    const/16 v1, 0x10

    invoke-direct {v0, v1}, Ln8;-><init>(I)V

    sput-object v0, Ln8;->q:Ln8;

    new-instance v0, Ln8;

    const/16 v1, 0x11

    invoke-direct {v0, v1}, Ln8;-><init>(I)V

    sput-object v0, Ln8;->r:Ln8;

    return-void
.end method

.method public synthetic constructor <init>(I)V
    .registers 2

    iput p1, p0, Ln8;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Lkm1;Lp80;)V
    .registers 3

    const/16 p1, 0x1d

    iput p1, p0, Ln8;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static b(Lm4;Lk4;)V
    .registers 23

    invoke-virtual/range {p1 .. p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lads_mobile_sdk/bh;->d:Lzx1;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lo43;->a:Lads_mobile_sdk/ru0;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Lads_mobile_sdk/ru0;->a()Lo43;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/sb0;

    iget-object v0, v0, Lads_mobile_sdk/sb0;->T2:Ltv2;

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/rf1;

    invoke-static {}, Lads_mobile_sdk/ru0;->a()Lo43;

    move-result-object v1

    check-cast v1, Lads_mobile_sdk/sb0;

    iget-object v1, v1, Lads_mobile_sdk/sb0;->c:Lads_mobile_sdk/sb0;

    sget-object v2, Lads_mobile_sdk/av2;->e:Lads_mobile_sdk/av2;

    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sget-object v4, Lgv2;->a:Lads_mobile_sdk/ob1;

    new-instance v5, Lads_mobile_sdk/a3;

    invoke-direct {v5, v4, v4, v4}, Lads_mobile_sdk/a3;-><init>(Lads_mobile_sdk/ob1;Lads_mobile_sdk/ob1;Lads_mobile_sdk/ob1;)V

    new-instance v9, Lads_mobile_sdk/nj0;

    invoke-direct {v9, v5}, Lads_mobile_sdk/nj0;-><init>(Ltv2;)V

    iget-object v4, v1, Lads_mobile_sdk/sb0;->v0:Ltv2;

    new-instance v5, Lads_mobile_sdk/b;

    const/16 v6, 0x1c

    invoke-direct {v5, v4, v6}, Lads_mobile_sdk/b;-><init>(Ltv2;I)V

    new-instance v14, Lads_mobile_sdk/nj0;

    invoke-direct {v14, v5}, Lads_mobile_sdk/nj0;-><init>(Ltv2;)V

    invoke-static {v2}, Lads_mobile_sdk/ob1;->a(Ljava/lang/Object;)Lads_mobile_sdk/ob1;

    move-result-object v12

    invoke-static {v3}, Lads_mobile_sdk/ob1;->a(Ljava/lang/Object;)Lads_mobile_sdk/ob1;

    move-result-object v2

    invoke-static/range {p0 .. p0}, Lads_mobile_sdk/ob1;->a(Ljava/lang/Object;)Lads_mobile_sdk/ob1;

    move-result-object v4

    new-instance v13, Lads_mobile_sdk/n90;

    invoke-direct {v13, v4}, Lads_mobile_sdk/n90;-><init>(Ltv2;)V

    invoke-static {v3}, Lads_mobile_sdk/ob1;->a(Ljava/lang/Object;)Lads_mobile_sdk/ob1;

    move-result-object v15

    iget-object v11, v1, Lads_mobile_sdk/sb0;->g1:Lads_mobile_sdk/ah0;

    iget-object v3, v1, Lads_mobile_sdk/sb0;->h:Ltv2;

    new-instance v10, Lads_mobile_sdk/np;

    move-object/from16 v16, v3

    invoke-direct/range {v10 .. v16}, Lads_mobile_sdk/np;-><init>(Lads_mobile_sdk/ah0;Ltv2;Ltv2;Ltv2;Lads_mobile_sdk/ob1;Ltv2;)V

    new-instance v3, Lads_mobile_sdk/nj0;

    invoke-direct {v3, v10}, Lads_mobile_sdk/nj0;-><init>(Ltv2;)V

    invoke-static/range {p0 .. p0}, Lads_mobile_sdk/ob1;->a(Ljava/lang/Object;)Lads_mobile_sdk/ob1;

    move-result-object v17

    sget-object v4, Lsz;->m:Lct2;

    new-instance v5, Lads_mobile_sdk/nj0;

    invoke-direct {v5, v4}, Lads_mobile_sdk/nj0;-><init>(Ltv2;)V

    iget-object v8, v1, Lads_mobile_sdk/sb0;->u:Lads_mobile_sdk/ah0;

    new-instance v4, Lads_mobile_sdk/dw;

    const/4 v6, 0x1

    invoke-direct {v4, v8, v5, v6}, Lads_mobile_sdk/dw;-><init>(Lads_mobile_sdk/ah0;Ltv2;I)V

    new-instance v5, Lads_mobile_sdk/nj0;

    invoke-direct {v5, v4}, Lads_mobile_sdk/nj0;-><init>(Ltv2;)V

    iget-object v7, v1, Lads_mobile_sdk/sb0;->a3:Ltv2;

    iget-object v10, v1, Lads_mobile_sdk/sb0;->t:Ltv2;

    iget-object v11, v1, Lads_mobile_sdk/sb0;->G:Ltv2;

    move-object v13, v12

    move-object v12, v14

    iget-object v14, v1, Lads_mobile_sdk/sb0;->d:Ltv2;

    iget-object v1, v1, Lads_mobile_sdk/sb0;->b3:Lads_mobile_sdk/ab0;

    new-instance v6, Lads_mobile_sdk/gq2;

    const/16 v20, 0x4

    move-object/from16 v18, v1

    move-object v15, v2

    move-object/from16 v16, v3

    move-object/from16 v19, v5

    invoke-direct/range {v6 .. v20}, Lads_mobile_sdk/gq2;-><init>(Ltv2;Lads_mobile_sdk/ah0;Ltv2;Ltv2;Ltv2;Ltv2;Ltv2;Ltv2;Ltv2;Ltv2;Lads_mobile_sdk/ob1;Ltv2;Ltv2;I)V

    new-instance v1, Lads_mobile_sdk/nj0;

    invoke-direct {v1, v6}, Lads_mobile_sdk/nj0;-><init>(Ltv2;)V

    invoke-interface {v1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lads_mobile_sdk/xn2;

    new-instance v2, Lads_mobile_sdk/wg;

    const/4 v3, 0x0

    const/4 v4, 0x0

    move-object/from16 v5, p1

    invoke-direct {v2, v1, v5, v3, v4}, Lads_mobile_sdk/wg;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lvx;I)V

    invoke-virtual {v0, v2}, Lads_mobile_sdk/rf1;->a(Lbk0;)V

    return-void
.end method


# virtual methods
.method public a([BII)[B
    .registers 4

    add-int/2addr p3, p2

    invoke-static {p1, p2, p3}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object p0

    return-object p0
.end method

.method public accept(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 4

    check-cast p1, Lcom/google/android/gms/internal/location/zzaz;

    check-cast p2, Lcom/google/android/gms/tasks/TaskCompletionSource;

    new-instance p0, Lgc3;

    const/4 v0, 0x1

    invoke-direct {p0, v0, p2}, Lgc3;-><init>(ILcom/google/android/gms/tasks/TaskCompletionSource;)V

    invoke-virtual {p1, p0}, Lcom/google/android/gms/internal/location/zzaz;->zzK(Lcom/google/android/gms/internal/location/zzai;)V

    return-void
.end method

.method public c(Ld82;)Lf82;
    .registers 8

    new-instance v0, Ltj0;

    iget-object v1, p1, Ld82;->a:Landroid/content/Context;

    iget-object v2, p1, Ld82;->b:Ljava/lang/String;

    iget-object v3, p1, Ld82;->c:Lg8;

    iget-boolean v4, p1, Ld82;->d:Z

    iget-boolean v5, p1, Ld82;->e:Z

    invoke-direct/range {v0 .. v5}, Ltj0;-><init>(Landroid/content/Context;Ljava/lang/String;Lg8;ZZ)V

    return-object v0
.end method

.method public f(Ljava/lang/String;Ljava/security/Provider;)Ljava/lang/Object;
    .registers 3

    .prologue
    if-nez p2, :cond_7

    invoke-static {p1}, Ljavax/crypto/Mac;->getInstance(Ljava/lang/String;)Ljavax/crypto/Mac;

    move-result-object p0

    return-object p0

    :cond_7
    invoke-static {p1, p2}, Ljavax/crypto/Mac;->getInstance(Ljava/lang/String;Ljava/security/Provider;)Ljavax/crypto/Mac;

    move-result-object p0

    return-object p0
.end method

.method public h(Lk20;)Ljava/lang/Object;
    .registers 4

    .prologue
    iget p0, p0, Ln8;->a:I

    const-class v0, Ljava/util/concurrent/Executor;

    packed-switch p0, :pswitch_data_32

    new-instance p0, Lyo1;

    const-class v1, Llj;

    invoke-direct {p0, v1, v0}, Lyo1;-><init>(Ljava/lang/Class;Ljava/lang/Class;)V

    invoke-virtual {p1, p0}, Lk20;->f(Lyo1;)Ljava/lang/Object;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p0, Ljava/util/concurrent/Executor;

    invoke-static {p0}, Lnp3;->I(Ljava/util/concurrent/Executor;)Loy;

    move-result-object p0

    return-object p0

    :pswitch_1c  #0x3
    new-instance p0, Lyo1;

    const-class v1, Lhh;

    invoke-direct {p0, v1, v0}, Lyo1;-><init>(Ljava/lang/Class;Ljava/lang/Class;)V

    invoke-virtual {p1, p0}, Lk20;->f(Lyo1;)Ljava/lang/Object;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p0, Ljava/util/concurrent/Executor;

    invoke-static {p0}, Lnp3;->I(Ljava/util/concurrent/Executor;)Loy;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_32
    .packed-switch 0x3
        :pswitch_1c  #00000003
    .end packed-switch
.end method

.method public onAdFailedToLoad(Lq31;)V
    .registers 8

    .prologue
    const/4 v1, -0x3

    new-instance p0, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v3, "Falha ao carregar Rewarded ("

    const/16 v1, 0x97

    invoke-direct {p0, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v1, 0xf55

    invoke-virtual {p1}, Lq31;->V()Lp31;

    move-result-object v3

    const/16 v1, 0x190

    invoke-virtual {p0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string/jumbo v3, ": "

    const/4 v1, 0x0

    invoke-virtual {p0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v1, 0xaf5

    invoke-virtual {p1}, Lq31;->W()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 p1, 0x29

    const/16 v1, 0x1b

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v1, -0x2

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string/jumbo p1, "Ads-Load"

    nop

    const/16 v1, 0x140

    sget-boolean p0, Lg4;->a:Z

    nop

    const/4 p0, 0x0

    const/16 v1, 0x1178

    sput-boolean p0, Lg4;->B:Z

    const/4 p0, 0x0

    const/16 v1, 0xd9f

    sput-object p0, Lg4;->A:Lxu1;

    const/16 v1, 0x101

    sget-boolean p0, Lmi2;->n:Z

    nop

    if-eqz p0, :cond_4f

    goto :goto_8d

    :cond_4f
    const/16 v1, 0xada

    sget-object p0, Lmi2;->p:Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;

    nop

    if-eqz p0, :cond_67

    const/16 v1, 0x22e

    new-instance p1, Lzs1;

    nop

    const/4 v3, 0x1

    const/16 v1, 0x1d4

    invoke-direct {p1, p0, v3}, Lzs1;-><init>(Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;I)V

    const/16 v1, 0x147

    invoke-virtual {p0, p1}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    goto :goto_8d

    :cond_67
    const/16 v1, 0xbfc

    sget-object p0, Lmi2;->q:Lcom/tlsvpn/tlstunnel/MainActivity;

    nop

    if-eqz p0, :cond_8d

    const/16 v1, 0xe26

    sget p1, Lg4;->C:I

    nop

    add-int/lit8 v3, p1, 0x1

    const/16 v1, 0x929

    sput v3, Lg4;->C:I

    const/4 v3, 0x4

    if-ge p1, v3, :cond_8d

    const/16 v1, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v1, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-wide/16 v4, 0x3a98

    const/16 v1, 0x3d5

    invoke-static {p0, v3, v4, v5}, Lg4;->m(Landroid/content/Context;IJ)V

    :cond_8d
    :goto_8d
    return-void
.end method

.method public onAdLoaded(Ljava/lang/Object;)V
    .registers 5

    .prologue
    check-cast p1, Lxu1;

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string/jumbo p0, "Ads-Load"

    const-string/jumbo v2, "Rewarded Carregado!"

    nop

    const/4 p0, 0x0

    const/16 v0, 0x1178

    sput-boolean p0, Lg4;->B:Z

    const/16 v0, 0x929

    sput p0, Lg4;->C:I

    const/16 v0, 0x101

    sget-boolean v2, Lmi2;->n:Z

    nop

    if-eqz v2, :cond_1e

    goto :goto_74

    :cond_1e
    const/16 v0, 0x195

    sget-boolean v2, Lmi2;->d:Z

    nop

    if-nez v2, :cond_2d

    const/16 v0, 0xf11

    sget-boolean v2, Lmi2;->e:Z

    nop

    if-nez v2, :cond_2d

    goto :goto_74

    :cond_2d
    const/16 v0, 0xd9f

    sput-object p1, Lg4;->A:Lxu1;

    check-cast p1, Lads_mobile_sdk/lw2;

    const/16 v0, 0x62a

    iget-object p1, p1, Lads_mobile_sdk/lw2;->b:Lads_mobile_sdk/jh1;

    nop

    const/4 v2, 0x1

    const/16 v0, 0xb06

    iput-boolean v2, p1, Lads_mobile_sdk/xo;->n:Z

    const/16 v0, 0xcb4

    iput-boolean v2, p1, Lads_mobile_sdk/xo;->o:Z

    const/16 v0, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    const/16 v0, 0xada

    sget-object p1, Lmi2;->p:Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;

    nop

    if-eqz p1, :cond_5c

    const/16 v0, 0x22e

    new-instance v2, Lzs1;

    nop

    const/16 v0, 0x1d4

    invoke-direct {v2, p1, p0}, Lzs1;-><init>(Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;I)V

    const/16 v0, 0x147

    invoke-virtual {p1, v2}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    :cond_5c
    const/16 v0, 0xbfc

    sget-object p0, Lmi2;->q:Lcom/tlsvpn/tlstunnel/MainActivity;

    nop

    if-eqz p0, :cond_74

    const/16 v0, 0xb36

    new-instance p1, Lc;

    nop

    const/16 v2, 0x13

    const/16 v0, 0x87c

    invoke-direct {p1, v2, p0}, Lc;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x147

    invoke-virtual {p0, p1}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    :cond_74
    :goto_74
    return-void
.end method

.method public toString()Ljava/lang/String;
    .registers 8

    .prologue
    iget v0, p0, Ln8;->a:I

    packed-switch v0, :pswitch_data_54

    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :pswitch_a  #0x14
    new-instance p0, Ljava/lang/StringBuilder;

    const-string/jumbo v0, "CharMatcher.is(\'"

    invoke-direct {p0, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v0, 0x6

    new-array v0, v0, [C

    const/16 v1, 0x5c

    const/4 v2, 0x0

    aput-char v1, v0, v2

    const/4 v1, 0x1

    const/16 v3, 0x75

    aput-char v3, v0, v1

    const/4 v1, 0x2

    aput-char v2, v0, v1

    const/4 v1, 0x3

    aput-char v2, v0, v1

    const/4 v1, 0x4

    aput-char v2, v0, v1

    const/4 v3, 0x5

    aput-char v2, v0, v3

    const/16 v3, 0xa

    move v4, v2

    :goto_2e
    if-ge v4, v1, :cond_41

    rsub-int/lit8 v5, v4, 0x5

    and-int/lit8 v3, v3, 0xf

    const-string/jumbo v6, "0123456789ABCDEF"

    invoke-virtual {v6, v3}, Ljava/lang/String;->charAt(I)C

    move-result v3

    aput-char v3, v0, v5

    add-int/lit8 v4, v4, 0x1

    move v3, v2

    goto :goto_2e

    :cond_41
    invoke-static {v0}, Ljava/lang/String;->copyValueOf([C)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v0, "\')"

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_54
    .packed-switch 0x14
        :pswitch_a  #00000014
    .end packed-switch
.end method
