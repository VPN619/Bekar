.class public final synthetic Lz3;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lei1;
.implements Lmz;
.implements Lv82;
.implements Lzu0;
.implements Lxm;
.implements Lcom/google/android/gms/tasks/OnCompleteListener;
.implements Lgx1;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;

.field public final synthetic c:Ljava/lang/Object;

.field public final synthetic d:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .registers 7

    iput p4, p0, Lz3;->a:I

    iput-object p1, p0, Lz3;->b:Ljava/lang/Object;

    iput-object p2, p0, Lz3;->c:Ljava/lang/Object;

    iput-object p3, p0, Lz3;->d:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public H()Ljava/lang/Object;
    .registers 18

    .prologue
    const/16 v6, 0x1204

    move-object/from16 v0, p0

    iget-object v8, v0, Lz3;->b:Ljava/lang/Object;

    nop

    check-cast v8, Lj20;

    const/16 v6, 0xc8c

    move-object/from16 v0, p0

    iget-object v9, v0, Lz3;->c:Ljava/lang/Object;

    nop

    check-cast v9, Lyg;

    const/16 v6, 0x6c1

    move-object/from16 v0, p0

    iget-object v6, v0, Lz3;->d:Ljava/lang/Object;

    move-object/16 p0, v6

    check-cast p0, Lig;

    const/16 v6, 0x9cc

    iget-object v10, v8, Lj20;->d:Lix1;

    nop

    const/4 v6, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x1147

    iget-object v11, v9, Lyg;->c:Lym1;

    nop

    const/16 v6, 0xcec

    move-object/from16 v0, p0

    iget-object v12, v0, Lig;->a:Ljava/lang/String;

    nop

    const/16 v6, 0x76d

    iget-object v13, v9, Lyg;->a:Ljava/lang/String;

    nop

    const-string/jumbo v14, "SQLiteEventStore"

    const/16 v6, 0x312

    invoke-static {v14}, Lg73;->x(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    const/4 v15, 0x3

    const/16 v6, 0x481

    invoke-static {v14, v15}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v15

    if-eqz v15, :cond_78

    const/4 v6, -0x3

    new-instance v15, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v16, "Storing event with priority="

    const/16 v6, 0x97

    move-object/from16 v0, v16

    invoke-direct {v15, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v6, 0x190

    invoke-virtual {v15, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string/jumbo v11, ", name="

    const/4 v6, 0x0

    invoke-virtual {v15, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    invoke-virtual {v15, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v11, " for destination "

    const/4 v6, 0x0

    invoke-virtual {v15, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    invoke-virtual {v15, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, -0x2

    invoke-virtual {v15}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    nop

    :cond_78
    const/16 v6, 0x592

    new-instance v11, Lz3;

    nop

    const/16 v12, 0x8

    const/16 v6, 0x72a

    move v0, v6

    move-object v1, v11

    move-object v2, v10

    move-object/from16 v3, p0

    move-object v4, v9

    move v5, v12

    invoke-direct/range {v1 .. v5}, Lz3;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    const/16 v6, 0x7e5

    invoke-virtual {v10, v11}, Lix1;->p(Lgx1;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Long;

    const/4 v6, -0x6

    move-object/from16 v0, p0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x58e

    iget-object v6, v8, Lj20;->a:Ltd;

    move-object/16 p0, v6

    const/4 v8, 0x1

    const/4 v10, 0x0

    const/16 v6, 0xe8a

    move-object/from16 v0, p0

    invoke-virtual {v0, v9, v8, v10}, Ltd;->C(Lyg;IZ)V

    const/16 p0, 0x0

    return-object p0
.end method

.method public apply(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 40

    .prologue
    move-object/from16 v12, p0

    const/16 v10, 0xc34

    iget v13, v12, Lz3;->a:I

    nop

    const-string/jumbo v14, "bytes"

    const-string/jumbo v15, "PRAGMA page_size"

    const-string/jumbo v16, "PRAGMA page_count"

    const/16 v17, 0x6

    const/16 v18, 0x5

    const/16 v19, 0x4

    const/16 v20, 0x3

    const/16 v10, 0xfa4

    sget-object v21, Le41;->d:Le41;

    nop

    const/16 v22, 0x2

    const/16 v24, 0x0

    const/16 v25, 0x1

    const/16 v10, 0x6c1

    iget-object v10, v12, Lz3;->d:Ljava/lang/Object;

    move-object/16 v26, v10

    const/16 v10, 0xc8c

    iget-object v10, v12, Lz3;->c:Ljava/lang/Object;

    move-object/16 v27, v10

    const/16 v10, 0x1204

    iget-object v12, v12, Lz3;->b:Ljava/lang/Object;

    nop

    packed-switch v13, :pswitch_data_78e

    check-cast v12, Lix1;

    check-cast v27, Ljava/util/HashMap;

    check-cast v26, Lx5;

    const/16 v10, 0x916

    move-object/from16 v0, v26

    iget-object v13, v0, Lx5;->d:Ljava/lang/Object;

    nop

    check-cast v13, Ljava/util/ArrayList;

    move-object/from16 v14, p1

    check-cast v14, Landroid/database/Cursor;

    const/4 v10, -0x6

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :goto_50
    const/16 v10, 0x1a7

    invoke-interface {v14}, Landroid/database/Cursor;->moveToNext()Z

    move-result v23

    if-eqz v23, :cond_12d

    const/16 v10, 0x153

    move/from16 v0, v24

    invoke-interface {v14, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v23

    const/16 v10, 0x252

    move/from16 v0, v25

    invoke-interface {v14, v0}, Landroid/database/Cursor;->getInt(I)I

    move-result v24

    const/16 v10, 0x1007

    sget-object v29, Le41;->b:Le41;

    nop

    if-nez v24, :cond_72

    :goto_6f
    move-object/from16 v17, v29

    goto :goto_d1

    :cond_72
    move/from16 v0, v24

    move/from16 v1, v25

    if-ne v0, v1, :cond_7e

    const/16 v10, 0xc00

    sget-object v29, Le41;->c:Le41;

    nop

    goto :goto_6f

    :cond_7e
    move/from16 v0, v24

    move/from16 v1, v22

    if-ne v0, v1, :cond_87

    move-object/from16 v17, v21

    goto :goto_d1

    :cond_87
    move/from16 v0, v24

    move/from16 v1, v20

    if-ne v0, v1, :cond_93

    const/16 v10, 0x76e

    sget-object v29, Le41;->e:Le41;

    nop

    goto :goto_6f

    :cond_93
    move/from16 v0, v24

    move/from16 v1, v19

    if-ne v0, v1, :cond_9f

    const/16 v10, 0x78b

    sget-object v29, Le41;->f:Le41;

    nop

    goto :goto_6f

    :cond_9f
    move/from16 v0, v24

    move/from16 v1, v18

    if-ne v0, v1, :cond_ab

    const/16 v10, 0x972

    sget-object v29, Le41;->g:Le41;

    nop

    goto :goto_6f

    :cond_ab
    move/from16 v0, v24

    move/from16 v1, v17

    if-ne v0, v1, :cond_b7

    const/16 v10, 0xc8e

    sget-object v29, Le41;->h:Le41;

    nop

    goto :goto_6f

    :cond_b7
    const-string/jumbo v17, "%n is not valid. No matched LogEventDropped-Reason found. Treated it as REASON_UNKNOWN"

    const/16 v10, 0xb1

    move/from16 v0, v24

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v24

    const-string/jumbo v18, "SQLiteEventStore"

    const/16 v10, 0x4eb

    move-object/from16 v0, v18

    move-object/from16 v1, v17

    move-object/from16 v2, v24

    invoke-static {v0, v1, v2}, Lg73;->q(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    goto :goto_6f

    :goto_d1
    const/16 v10, 0x11c

    move/from16 v0, v22

    invoke-interface {v14, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v19

    const/16 v10, 0x1127

    move-object/from16 v0, v27

    move-object/from16 v1, v23

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v29

    if-nez v29, :cond_fc

    const/16 v10, 0xd7

    new-instance v18, Ljava/util/ArrayList;

    nop

    const/16 v10, 0x16b

    move-object/from16 v0, v18

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/16 v10, 0x9c7

    move-object/from16 v0, v27

    move-object/from16 v1, v23

    move-object/from16 v2, v18

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_fc
    const/16 v10, 0x416

    move-object/from16 v0, v27

    move-object/from16 v1, v23

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v18

    check-cast v18, Ljava/util/List;

    const/16 v10, 0x1106

    new-instance v23, Lf41;

    nop

    const/16 v10, 0xf02

    move-object/from16 v0, v23

    move-wide/from16 v1, v19

    move-object/from16 v3, v17

    invoke-direct {v0, v1, v2, v3}, Lf41;-><init>(JLe41;)V

    const/16 v10, 0x8d8

    move-object/from16 v0, v18

    move-object/from16 v1, v23

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/16 v17, 0x6

    const/16 v18, 0x5

    const/16 v19, 0x4

    const/16 v20, 0x3

    const/16 v24, 0x0

    goto/16 :goto_50

    :cond_12d
    const/16 v10, 0x9d3

    move-object/from16 v0, v27

    invoke-virtual {v0}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    move-result-object v14

    const/16 v10, 0x14c

    invoke-interface {v14}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v14

    :goto_13b
    const/16 v10, 0x13e

    invoke-interface {v14}, Ljava/util/Iterator;->hasNext()Z

    move-result v17

    if-eqz v17, :cond_190

    const/16 v10, 0x16e

    invoke-interface {v14}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v17

    check-cast v17, Ljava/util/Map$Entry;

    const/16 v10, 0x7cd

    sget v18, Lh41;->c:I

    nop

    const/16 v10, 0xd7

    new-instance v18, Ljava/util/ArrayList;

    nop

    const/16 v10, 0x16b

    move-object/from16 v0, v18

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/16 v10, 0x28f

    move-object/from16 v0, v17

    invoke-interface {v0}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v18

    check-cast v18, Ljava/lang/String;

    const/16 v10, 0x1c2

    move-object/from16 v0, v17

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v17

    check-cast v17, Ljava/util/List;

    const/16 v10, 0x977

    new-instance v19, Lh41;

    nop

    const/16 v10, 0x41a

    move-object/from16 v0, v17

    invoke-static {v0}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v17

    const/16 v10, 0xb39

    move-object/from16 v0, v19

    move-object/from16 v1, v18

    move-object/from16 v2, v17

    invoke-direct {v0, v1, v2}, Lh41;-><init>(Ljava/lang/String;Ljava/util/List;)V

    const/16 v10, 0x174

    move-object/from16 v0, v19

    invoke-virtual {v13, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_13b

    :cond_190
    const/16 v10, 0xe15

    iget-object v14, v12, Lix1;->b:Lns1;

    nop

    const/16 v10, 0xa83

    invoke-virtual {v14}, Lns1;->c()J

    move-result-wide v17

    const/16 v10, 0x63e

    new-instance v14, Lfx1;

    nop

    const/16 v10, 0xfeb

    move-wide/from16 v0, v17

    invoke-direct {v14, v0, v1}, Lfx1;-><init>(J)V

    const/16 v10, 0x7e5

    invoke-virtual {v12, v14}, Lix1;->p(Lgx1;)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Lwa2;

    const/16 v10, 0x807

    move-object/from16 v0, v26

    iput-object v14, v0, Lx5;->c:Ljava/lang/Object;

    const/16 v10, 0xcd

    invoke-virtual {v12}, Lix1;->k()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v14

    const/16 v10, 0x112

    move-object/from16 v0, v16

    invoke-virtual {v14, v0}, Landroid/database/sqlite/SQLiteDatabase;->compileStatement(Ljava/lang/String;)Landroid/database/sqlite/SQLiteStatement;

    move-result-object v14

    const/16 v10, 0x149

    invoke-virtual {v14}, Landroid/database/sqlite/SQLiteStatement;->simpleQueryForLong()J

    move-result-wide v16

    const/16 v10, 0xcd

    invoke-virtual {v12}, Lix1;->k()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v14

    const/16 v10, 0x112

    invoke-virtual {v14, v15}, Landroid/database/sqlite/SQLiteDatabase;->compileStatement(Ljava/lang/String;)Landroid/database/sqlite/SQLiteStatement;

    move-result-object v14

    const/16 v10, 0x149

    invoke-virtual {v14}, Landroid/database/sqlite/SQLiteStatement;->simpleQueryForLong()J

    move-result-wide v14

    mul-long v14, v14, v16

    const/16 v10, 0x5ff

    sget-object v16, Ljg;->f:Ljg;

    nop

    const/16 v10, 0x3a2

    move-object/from16 v0, v16

    iget-wide v10, v0, Ljg;->a:J

    move-wide/16 v16, v10

    const/16 v10, 0xfed

    new-instance v18, Lr62;

    nop

    const/16 v10, 0x700

    move v0, v10

    move-object/from16 v1, v18

    move-wide v2, v14

    move-wide/from16 v4, v16

    invoke-direct/range {v1 .. v5}, Lr62;-><init>(JJ)V

    const/16 v10, 0x5b1

    new-instance v14, Lbm0;

    nop

    const/16 v10, 0xece

    move-object/from16 v0, v18

    invoke-direct {v14, v0}, Lbm0;-><init>(Lr62;)V

    const/16 v10, 0xf2a

    move-object/from16 v0, v26

    iput-object v14, v0, Lx5;->e:Ljava/lang/Object;

    const/16 v10, 0xcb3

    iget-object v12, v12, Lix1;->e:Loo1;

    nop

    const/16 v10, 0xe9b

    invoke-interface {v12}, Loo1;->get()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/String;

    const/16 v10, 0xdd0

    move-object/from16 v0, v26

    iput-object v12, v0, Lx5;->b:Ljava/lang/Object;

    const/16 v10, 0x11e0

    new-instance v12, Lzq;

    nop

    const/16 v10, 0x3a9

    move-object/from16 v0, v26

    iget-object v14, v0, Lx5;->c:Ljava/lang/Object;

    nop

    check-cast v14, Lwa2;

    const/16 v10, 0x41a

    invoke-static {v13}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object v13

    const/16 v10, 0x1e3

    move-object/from16 v0, v26

    iget-object v15, v0, Lx5;->e:Ljava/lang/Object;

    nop

    check-cast v15, Lbm0;

    const/16 v10, 0x385

    move-object/from16 v0, v26

    iget-object v10, v0, Lx5;->b:Ljava/lang/Object;

    move-object/16 v16, v10

    check-cast v16, Ljava/lang/String;

    const/16 v10, 0xe5f

    move v0, v10

    move-object v1, v12

    move-object v2, v14

    move-object v3, v13

    move-object v4, v15

    move-object/from16 v5, v16

    invoke-direct/range {v1 .. v5}, Lzq;-><init>(Lwa2;Ljava/util/List;Lbm0;Ljava/lang/String;)V

    check-cast v12, Ljava/lang/Object;

    return-object v12

    :pswitch_257  #0x9
    check-cast v12, Lix1;

    check-cast v27, Ljava/util/ArrayList;

    check-cast v26, Lyg;

    move-object/from16 v13, p1

    check-cast v13, Landroid/database/Cursor;

    :goto_261
    const/16 v10, 0x1a7

    invoke-interface {v13}, Landroid/database/Cursor;->moveToNext()Z

    move-result v15

    if-eqz v15, :cond_492

    const/4 v15, 0x0

    const/16 v10, 0x11c

    invoke-interface {v13, v15}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v16

    const/4 v15, 0x7

    const/16 v10, 0x252

    invoke-interface {v13, v15}, Landroid/database/Cursor;->getInt(I)I

    move-result v15

    if-eqz v15, :cond_27c

    move/from16 v15, v25

    goto :goto_27d

    :cond_27c
    const/4 v15, 0x0

    :goto_27d
    const/16 v10, 0x77e

    new-instance v19, Lf6;

    nop

    const/16 v10, 0x21a

    move-object/from16 v0, v19

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/16 v10, 0x8b3

    new-instance v18, Ljava/util/HashMap;

    nop

    const/16 v10, 0xf9f

    move-object/from16 v0, v18

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/16 v10, 0x67e

    move-object/from16 v0, v19

    move-object/from16 v1, v18

    iput-object v1, v0, Lf6;->f:Ljava/lang/Object;

    const/16 v10, 0x153

    move/from16 v0, v25

    invoke-interface {v13, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v18

    if-eqz v18, :cond_487

    const/16 v10, 0x8f0

    move-object/from16 v0, v19

    move-object/from16 v1, v18

    iput-object v1, v0, Lf6;->b:Ljava/lang/Object;

    const/16 v10, 0x11c

    move/from16 v0, v22

    invoke-interface {v13, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v20

    const/16 v10, 0x61

    move-wide/from16 v0, v20

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v18

    const/16 v10, 0x749

    move-object/from16 v0, v19

    move-object/from16 v1, v18

    iput-object v1, v0, Lf6;->d:Ljava/lang/Object;

    const/16 v24, 0x3

    const/16 v10, 0x11c

    move/from16 v0, v24

    invoke-interface {v13, v0}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v20

    const/16 v10, 0x61

    move-wide/from16 v0, v20

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v18

    const/16 v10, 0xde5

    move-object/from16 v0, v19

    move-object/from16 v1, v18

    iput-object v1, v0, Lf6;->e:Ljava/lang/Object;

    if-eqz v15, :cond_32b

    const/16 v10, 0x3b1

    new-instance v15, Lfa0;

    nop

    const/16 v18, 0x4

    const/16 v10, 0x153

    move/from16 v0, v18

    invoke-interface {v13, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v20

    if-nez v20, :cond_2fc

    const/16 v10, 0x320

    sget-object v20, Lix1;->f:Lja0;

    nop

    :goto_2f9
    const/16 v21, 0x5

    goto :goto_30d

    :cond_2fc
    const/16 v10, 0x308

    new-instance v21, Lja0;

    nop

    const/16 v10, 0x3de

    move-object/from16 v0, v21

    move-object/from16 v1, v20

    invoke-direct {v0, v1}, Lja0;-><init>(Ljava/lang/String;)V

    move-object/from16 v20, v21

    goto :goto_2f9

    :goto_30d
    const/16 v10, 0x4d5

    move/from16 v0, v21

    invoke-interface {v13, v0}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v18

    const/16 v10, 0x4e1

    move-object/from16 v0, v20

    move-object/from16 v1, v18

    invoke-direct {v15, v0, v1}, Lfa0;-><init>(Lja0;[B)V

    const/16 v10, 0x459

    move-object/from16 v0, v19

    iput-object v15, v0, Lf6;->c:Ljava/lang/Object;

    move-object/from16 v34, v12

    const/16 v33, 0x0

    :goto_328
    const/4 v12, 0x6

    goto/16 :goto_437

    :cond_32b
    const/16 v21, 0x5

    const/16 v10, 0x3b1

    new-instance v15, Lfa0;

    nop

    const/16 v18, 0x4

    const/16 v10, 0x153

    move/from16 v0, v18

    invoke-interface {v13, v0}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v20

    if-nez v20, :cond_344

    const/16 v10, 0x320

    sget-object v20, Lix1;->f:Lja0;

    nop

    goto :goto_354

    :cond_344
    const/16 v10, 0x308

    new-instance v18, Lja0;

    nop

    const/16 v10, 0x3de

    move-object/from16 v0, v18

    move-object/from16 v1, v20

    invoke-direct {v0, v1}, Lja0;-><init>(Ljava/lang/String;)V

    move-object/from16 v20, v18

    :goto_354
    const/16 v10, 0xcd

    invoke-virtual {v12}, Lix1;->k()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v30

    check-cast v14, Ljava/lang/String;

    filled-new-array {v14}, [Ljava/lang/String;

    move-result-object v32

    const/16 v10, 0x107c

    move-wide/from16 v0, v16

    invoke-static {v0, v1}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v18

    check-cast v18, Ljava/lang/String;

    filled-new-array/range {v18 .. v18}, [Ljava/lang/String;

    move-result-object v34

    const/16 v36, 0x0

    const-string/jumbo v37, "sequence_num"

    const-string/jumbo v31, "event_payloads"

    const-string/jumbo v33, "event_id = ?"

    const/16 v35, 0x0

    const/16 v10, 0xf4c

    move v0, v10

    move-object/from16 v1, v30

    move-object/from16 v2, v31

    move-object/from16 v3, v32

    move-object/from16 v4, v33

    move-object/from16 v5, v34

    move-object/from16 v6, v35

    move-object/from16 v7, v36

    move-object/from16 v8, v37

    invoke-virtual/range {v1 .. v8}, Landroid/database/sqlite/SQLiteDatabase;->query(Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v18

    :try_start_392
    move-object/from16 v21, v18

    check-cast v21, Landroid/database/Cursor;

    const/16 v10, 0xd7

    new-instance v22, Ljava/util/ArrayList;

    nop

    const/16 v10, 0x16b

    move-object/from16 v0, v22

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/16 v24, 0x0

    :goto_3a4
    const/16 v10, 0x1a7

    move-object/from16 v0, v21

    invoke-interface {v0}, Landroid/database/Cursor;->moveToNext()Z

    move-result v32

    if-eqz v32, :cond_3cf

    const/16 v25, 0x0

    const/16 v33, 0x0

    const/16 v10, 0x4d5

    move-object/from16 v0, v21

    move/from16 v1, v25

    invoke-interface {v0, v1}, Landroid/database/Cursor;->getBlob(I)[B

    move-result-object v23

    const/16 v10, 0x174

    move-object/from16 v0, v22

    move-object/from16 v1, v23

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move-object/from16 v0, v23

    array-length v0, v0

    move/from16 v23, v0

    add-int v24, v24, v23

    const/16 v25, 0x1

    goto :goto_3a4

    :cond_3cf
    const/16 v33, 0x0

    move/from16 v0, v24

    new-array v0, v0, [B

    move-object/from16 v21, v0

    const/16 v23, 0x0

    const/16 v24, 0x0

    :goto_3db
    const/16 v10, 0xac

    move-object/from16 v0, v22

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v25

    move/from16 v0, v23

    move/from16 v1, v25

    if-ge v0, v1, :cond_41b

    const/16 v10, 0x43

    move-object/from16 v0, v22

    move/from16 v1, v23

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v25

    check-cast v25, [B

    move-object/from16 v34, v12

    move-object/from16 v0, v25

    array-length v12, v0
    :try_end_3fa
    .catchall {:try_start_392 .. :try_end_3fa} :catchall_47c

    move-object/from16 p1, v18

    const/16 v18, 0x0

    :try_start_3fe
    const/16 v10, 0x1252

    move v0, v10

    move-object/from16 v1, v25

    move/from16 v2, v18

    move-object/from16 v3, v21

    move/from16 v4, v24

    move v5, v12

    invoke-static/range {v1 .. v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    move-object/from16 v0, v25

    array-length v12, v0
    :try_end_410
    .catchall {:try_start_3fe .. :try_end_410} :catchall_419

    add-int v24, v24, v12

    add-int/lit8 v23, v23, 0x1

    move-object/from16 v18, p1

    move-object/from16 v12, v34

    goto :goto_3db

    :catchall_419
    move-exception v12

    goto :goto_47f

    :cond_41b
    move-object/from16 v34, v12

    move-object/from16 p1, v18

    const/16 v10, 0x30d

    move-object/from16 v0, p1

    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    const/16 v10, 0x4e1

    move-object/from16 v0, v20

    move-object/from16 v1, v21

    invoke-direct {v15, v0, v1}, Lfa0;-><init>(Lja0;[B)V

    const/16 v10, 0x459

    move-object/from16 v0, v19

    iput-object v15, v0, Lf6;->c:Ljava/lang/Object;

    goto/16 :goto_328

    :goto_437
    const/16 v10, 0xf0a

    invoke-interface {v13, v12}, Landroid/database/Cursor;->isNull(I)Z

    move-result v15

    if-nez v15, :cond_451

    const/16 v10, 0x252

    invoke-interface {v13, v12}, Landroid/database/Cursor;->getInt(I)I

    move-result v15

    const/16 v10, 0xb1

    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v15

    const/16 v10, 0x8d2

    move-object/from16 v0, v19

    iput-object v15, v0, Lf6;->a:Ljava/lang/Object;

    :cond_451
    const/16 v10, 0xdd6

    move-object/from16 v0, v19

    invoke-virtual {v0}, Lf6;->c()Lig;

    move-result-object v15

    const/16 v10, 0x1053

    new-instance v18, Lrg;

    nop

    const/16 v10, 0x7e6

    move v0, v10

    move-object/from16 v1, v18

    move-wide/from16 v2, v16

    move-object/from16 v4, v26

    move-object v5, v15

    invoke-direct/range {v1 .. v5}, Lrg;-><init>(JLyg;Lig;)V

    const/16 v10, 0x174

    move-object/from16 v0, v27

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    move-object/from16 v12, v34

    const/16 v22, 0x2

    const/16 v25, 0x1

    goto/16 :goto_261

    :catchall_47c
    move-exception v12

    move-object/from16 p1, v18

    :goto_47f
    const/16 v10, 0x30d

    move-object/from16 v0, p1

    invoke-interface {v0}, Landroid/database/Cursor;->close()V

    throw v12

    :cond_487
    const/16 v33, 0x0

    const-string/jumbo v12, "Null transportName"

    const/16 v10, 0x83f

    invoke-static {v12}, Ldm2;->n(Ljava/lang/String;)V

    goto :goto_494

    :cond_492
    const/16 v33, 0x0

    :goto_494
    return-object v33

    :pswitch_495  #0x8
    const/16 v33, 0x0

    check-cast v12, Lix1;

    check-cast v27, Lig;

    const/16 v10, 0x68e

    move-object/from16 v0, v27

    iget-object v13, v0, Lig;->c:Lfa0;

    nop

    const/16 v10, 0xcec

    move-object/from16 v0, v27

    iget-object v10, v0, Lig;->a:Ljava/lang/String;

    move-object/16 v17, v10

    check-cast v26, Lyg;

    move-object/from16 v18, p1

    check-cast v18, Landroid/database/sqlite/SQLiteDatabase;

    const/16 v28, 0x0

    const/16 v10, 0xb1

    move/from16 v0, v28

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v19

    const/16 v10, 0xcd

    invoke-virtual {v12}, Lix1;->k()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v20

    const/16 v10, 0x112

    move-object/from16 v0, v20

    move-object/from16 v1, v16

    invoke-virtual {v0, v1}, Landroid/database/sqlite/SQLiteDatabase;->compileStatement(Ljava/lang/String;)Landroid/database/sqlite/SQLiteStatement;

    move-result-object v16

    const/16 v10, 0x149

    move-object/from16 v0, v16

    invoke-virtual {v0}, Landroid/database/sqlite/SQLiteStatement;->simpleQueryForLong()J

    move-result-wide v22

    const/16 v10, 0xcd

    invoke-virtual {v12}, Lix1;->k()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v16

    const/16 v10, 0x112

    move-object/from16 v0, v16

    invoke-virtual {v0, v15}, Landroid/database/sqlite/SQLiteDatabase;->compileStatement(Ljava/lang/String;)Landroid/database/sqlite/SQLiteStatement;

    move-result-object v15

    const/16 v10, 0x149

    invoke-virtual {v15}, Landroid/database/sqlite/SQLiteStatement;->simpleQueryForLong()J

    move-result-wide v15

    mul-long v15, v15, v22

    const/16 v10, 0x5a0

    iget-object v10, v12, Lix1;->d:Ljg;

    move-object/16 v20, v10

    const/16 v10, 0x3a2

    move-object/from16 v0, v20

    iget-wide v10, v0, Ljg;->a:J

    move-wide/16 v22, v10

    cmp-long v15, v15, v22

    if-ltz v15, :cond_515

    const-wide/16 v13, 0x1

    const/16 v10, 0xc9a

    move v0, v10

    move-object v1, v12

    move-wide v2, v13

    move-object/from16 v4, v21

    move-object/from16 v5, v17

    invoke-virtual/range {v1 .. v5}, Lix1;->C(JLe41;Ljava/lang/String;)V

    const-wide/16 v12, -0x1

    const/16 v10, 0x61

    invoke-static {v12, v13}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v12

    goto/16 :goto_78b

    :cond_515
    const/16 v10, 0x1028

    move-object/from16 v0, v18

    move-object/from16 v1, v26

    invoke-static {v0, v1}, Lix1;->n(Landroid/database/sqlite/SQLiteDatabase;Lyg;)Ljava/lang/Long;

    move-result-object v12

    if-eqz v12, :cond_528

    const/16 v10, 0x417

    invoke-virtual {v12}, Ljava/lang/Long;->longValue()J

    move-result-wide v15

    goto :goto_59a

    :cond_528
    const/16 v10, 0x18f

    new-instance v12, Landroid/content/ContentValues;

    nop

    const/16 v10, 0x15e

    invoke-direct {v12}, Landroid/content/ContentValues;-><init>()V

    const-string/jumbo v15, "backend_name"

    const/16 v10, 0x76d

    move-object/from16 v0, v26

    iget-object v10, v0, Lyg;->a:Ljava/lang/String;

    move-object/16 v16, v10

    const/16 v10, 0xc5

    move-object/from16 v0, v16

    invoke-virtual {v12, v15, v0}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v10, 0x1147

    move-object/from16 v0, v26

    iget-object v15, v0, Lyg;->c:Lym1;

    nop

    const/16 v10, 0xe8e

    invoke-static {v15}, Lan1;->a(Lym1;)I

    move-result v15

    const/16 v10, 0xb1

    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v15

    const-string/jumbo v16, "priority"

    const/16 v10, 0xf5

    move-object/from16 v0, v16

    invoke-virtual {v12, v0, v15}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    const-string/jumbo v15, "next_request_ms"

    const/16 v10, 0xf5

    move-object/from16 v0, v19

    invoke-virtual {v12, v15, v0}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    const/16 v10, 0x879

    move-object/from16 v0, v26

    iget-object v15, v0, Lyg;->b:[B

    nop

    if-eqz v15, :cond_589

    const-string/jumbo v16, "extras"

    const/16 v25, 0x0

    const/16 v10, 0xcfd

    move/from16 v0, v25

    invoke-static {v15, v0}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object v15

    const/16 v10, 0xc5

    move-object/from16 v0, v16

    invoke-virtual {v12, v0, v15}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    :cond_589
    const-string/jumbo v15, "transport_contexts"

    move-object/from16 v16, v33

    const/16 v10, 0x144

    move-object/from16 v0, v18

    move-object/from16 v1, v16

    invoke-virtual {v0, v15, v1, v12}, Landroid/database/sqlite/SQLiteDatabase;->insert(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)J

    move-result-wide v21

    move-wide/from16 v15, v21

    :goto_59a
    const/16 v10, 0x54d

    move-object/from16 v0, v20

    iget v12, v0, Ljg;->e:I

    nop

    const/16 v10, 0x55c

    iget-object v10, v13, Lfa0;->b:[B

    move-object/16 v20, v10

    move-object/from16 v0, v20

    array-length v0, v0

    move/from16 v21, v0

    move/from16 v0, v21

    if-gt v0, v12, :cond_5b4

    const/16 v21, 0x1

    goto :goto_5b6

    :cond_5b4
    const/16 v21, 0x0

    :goto_5b6
    const/16 v10, 0x18f

    new-instance v22, Landroid/content/ContentValues;

    nop

    const/16 v10, 0x15e

    move-object/from16 v0, v22

    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    const-string/jumbo v23, "context_id"

    const/16 v10, 0x61

    move-wide v0, v15

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v15

    const/16 v10, 0x100

    move-object/from16 v0, v22

    move-object/from16 v1, v23

    invoke-virtual {v0, v1, v15}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const-string/jumbo v15, "transport_name"

    const/16 v10, 0xc5

    move-object/from16 v0, v22

    move-object/from16 v1, v17

    invoke-virtual {v0, v15, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v10, 0xcf5

    move-object/from16 v0, v27

    iget-wide v15, v0, Lig;->d:J

    nop

    const/16 v10, 0x61

    move-wide v0, v15

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v15

    const-string/jumbo v16, "timestamp_ms"

    const/16 v10, 0x100

    move-object/from16 v0, v22

    move-object/from16 v1, v16

    invoke-virtual {v0, v1, v15}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/16 v10, 0xb69

    move-object/from16 v0, v27

    iget-wide v15, v0, Lig;->e:J

    nop

    const/16 v10, 0x61

    move-wide v0, v15

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v15

    const-string/jumbo v16, "uptime_ms"

    const/16 v10, 0x100

    move-object/from16 v0, v22

    move-object/from16 v1, v16

    invoke-virtual {v0, v1, v15}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/16 v10, 0x9e2

    iget-object v13, v13, Lfa0;->a:Lja0;

    nop

    const/16 v10, 0xe08

    iget-object v13, v13, Lja0;->a:Ljava/lang/String;

    nop

    const-string/jumbo v15, "payload_encoding"

    const/16 v10, 0xc5

    move-object/from16 v0, v22

    invoke-virtual {v0, v15, v13}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const-string/jumbo v13, "code"

    const/16 v10, 0xc6f

    move-object/from16 v0, v27

    iget-object v15, v0, Lig;->b:Ljava/lang/Integer;

    nop

    const/16 v10, 0xf5

    move-object/from16 v0, v22

    invoke-virtual {v0, v13, v15}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    const-string/jumbo v13, "num_attempts"

    const/16 v10, 0xf5

    move-object/from16 v0, v22

    move-object/from16 v1, v19

    invoke-virtual {v0, v13, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    const-string/jumbo v13, "inline"

    const/16 v10, 0x2cb

    move/from16 v0, v21

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v15

    const/16 v10, 0x95a

    move-object/from16 v0, v22

    invoke-virtual {v0, v13, v15}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Boolean;)V

    if-eqz v21, :cond_65d

    move-object/from16 v13, v20

    goto :goto_663

    :cond_65d
    const/16 v25, 0x0

    move/from16 v0, v25

    new-array v13, v0, [B

    :goto_663
    const-string/jumbo v15, "payload"

    const/16 v10, 0x522

    move-object/from16 v0, v22

    invoke-virtual {v0, v15, v13}, Landroid/content/ContentValues;->put(Ljava/lang/String;[B)V

    const-string/jumbo v13, "events"

    const/16 v16, 0x0

    const/16 v10, 0x144

    move-object/from16 v0, v18

    move-object/from16 v1, v16

    move-object/from16 v2, v22

    invoke-virtual {v0, v13, v1, v2}, Landroid/database/sqlite/SQLiteDatabase;->insert(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)J

    move-result-wide v22

    const-string/jumbo v13, "event_id"

    if-nez v21, :cond_70c

    move-object/from16 v0, v20

    array-length v15, v0

    int-to-double v15, v15

    int-to-double v0, v12

    move-wide/from16 v24, v0

    div-double v15, v15, v24

    const/16 v10, 0x8ac

    move-wide v0, v15

    invoke-static {v0, v1}, Ljava/lang/Math;->ceil(D)D

    move-result-wide v15

    double-to-int v15, v15

    const/16 v25, 0x1

    :goto_696
    move/from16 v0, v25

    if-gt v0, v15, :cond_70c

    add-int/lit8 v16, v25, -0x1

    mul-int v16, v16, v12

    mul-int v17, v25, v12

    move-object/from16 v0, v20

    array-length v0, v0

    move/from16 v19, v0

    const/16 v10, 0x9e1

    move/from16 v0, v17

    move/from16 v1, v19

    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    move-result v17

    const/16 v10, 0x776

    move-object/from16 v0, v20

    move/from16 v1, v16

    move/from16 v2, v17

    invoke-static {v0, v1, v2}, Ljava/util/Arrays;->copyOfRange([BII)[B

    move-result-object v16

    const/16 v10, 0x18f

    new-instance v17, Landroid/content/ContentValues;

    nop

    const/16 v10, 0x15e

    move-object/from16 v0, v17

    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    const/16 v10, 0x61

    move-wide/from16 v0, v22

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v19

    const/16 v10, 0x100

    move-object/from16 v0, v17

    move-object/from16 v1, v19

    invoke-virtual {v0, v13, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const-string/jumbo v19, "sequence_num"

    const/16 v10, 0xb1

    move/from16 v0, v25

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v21

    const/16 v10, 0xf5

    move-object/from16 v0, v17

    move-object/from16 v1, v19

    move-object/from16 v2, v21

    invoke-virtual {v0, v1, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    const/16 v10, 0x522

    move-object/from16 v0, v17

    move-object/from16 v1, v16

    invoke-virtual {v0, v14, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;[B)V

    const-string/jumbo v16, "event_payloads"

    const/16 v19, 0x0

    const/16 v10, 0x144

    move-object/from16 v0, v18

    move-object/from16 v1, v16

    move-object/from16 v2, v19

    move-object/from16 v3, v17

    invoke-virtual {v0, v1, v2, v3}, Landroid/database/sqlite/SQLiteDatabase;->insert(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)J

    add-int/lit8 v25, v25, 0x1

    goto :goto_696

    :cond_70c
    const/16 v10, 0x11cf

    move-object/from16 v0, v27

    iget-object v12, v0, Lig;->f:Ljava/util/Map;

    nop

    const/16 v10, 0xb9

    invoke-static {v12}, Ljava/util/Collections;->unmodifiableMap(Ljava/util/Map;)Ljava/util/Map;

    move-result-object v12

    const/16 v10, 0xfa2

    invoke-interface {v12}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v12

    const/16 v10, 0x14c

    invoke-interface {v12}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v12

    :goto_725
    const/16 v10, 0x13e

    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_783

    const/16 v10, 0x16e

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/util/Map$Entry;

    const/16 v10, 0x18f

    new-instance v15, Landroid/content/ContentValues;

    nop

    const/16 v10, 0x15e

    invoke-direct {v15}, Landroid/content/ContentValues;-><init>()V

    const/16 v10, 0x61

    move-wide/from16 v0, v22

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v16

    const/16 v10, 0x100

    move-object/from16 v0, v16

    invoke-virtual {v15, v13, v0}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/16 v10, 0x28f

    invoke-interface {v14}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v16

    check-cast v16, Ljava/lang/String;

    const-string/jumbo v17, "name"

    const/16 v10, 0xc5

    move-object/from16 v0, v17

    move-object/from16 v1, v16

    invoke-virtual {v15, v0, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v10, 0x1c2

    invoke-interface {v14}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/lang/String;

    const-string/jumbo v16, "value"

    const/16 v10, 0xc5

    move-object/from16 v0, v16

    invoke-virtual {v15, v0, v14}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const-string/jumbo v14, "event_metadata"

    const/16 v16, 0x0

    const/16 v10, 0x144

    move-object/from16 v0, v18

    move-object/from16 v1, v16

    invoke-virtual {v0, v14, v1, v15}, Landroid/database/sqlite/SQLiteDatabase;->insert(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)J

    goto :goto_725

    :cond_783
    const/16 v10, 0x61

    move-wide/from16 v0, v22

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v12

    :goto_78b
    check-cast v12, Ljava/lang/Object;

    return-object v12

    :pswitch_data_78e
    .packed-switch 0x8
        :pswitch_495  #00000008
        :pswitch_257  #00000009
    .end packed-switch
.end method

.method public b(Lwu1;)V
    .registers 14

    .prologue
    const/16 v0, 0x1204

    iget-object v2, p0, Lz3;->b:Ljava/lang/Object;

    nop

    check-cast v2, Lsr1;

    const/16 v0, 0xc8c

    iget-object v3, p0, Lz3;->c:Ljava/lang/Object;

    nop

    check-cast v3, Landroid/content/SharedPreferences;

    const/16 v0, 0x6c1

    iget-object p0, p0, Lz3;->d:Ljava/lang/Object;

    nop

    check-cast p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 p1, 0x1

    const/16 v0, 0x8ed

    iput-boolean p1, v2, Lsr1;->a:Z

    const/4 v2, 0x0

    const/16 v0, 0x98

    invoke-static {v2}, Lmi2;->c(Z)Ljava/lang/String;

    move-result-object v4

    const-string/jumbo v5, "gd4Lrfa"

    const-string/jumbo v6, ""

    const/16 v0, 0x2e

    invoke-interface {v3, v5, v6}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const/16 v0, 0x98

    invoke-static {p1}, Lmi2;->c(Z)Ljava/lang/String;

    move-result-object v8

    const-string/jumbo v9, "Ss5fGn2"

    const/16 v0, 0x2e

    invoke-interface {v3, v9, v6}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const/16 v0, 0x7a

    invoke-interface {v3}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v10

    const/16 v0, 0x128

    invoke-virtual {v4, v7}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v7

    const-string/jumbo v11, "adXs5SFd"

    if-nez v7, :cond_5c

    const/16 v0, 0x3c

    invoke-interface {v10, v5, v4}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x56

    invoke-interface {v10, v11, p1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    goto :goto_68

    :cond_5c
    const/16 v0, 0xb0

    invoke-interface {v3, v11, v2}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v4

    add-int/2addr v4, p1

    const/16 v0, 0x56

    invoke-interface {v10, v11, v4}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    :goto_68
    const/16 v0, 0x128

    invoke-virtual {v8, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v4

    const-string/jumbo v5, "drVw5ad"

    if-nez v4, :cond_7e

    const/16 v0, 0x3c

    invoke-interface {v10, v9, v8}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x56

    invoke-interface {v10, v5, p1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    goto :goto_8a

    :cond_7e
    const/16 v0, 0xb0

    invoke-interface {v3, v5, v2}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v3

    add-int/2addr v3, p1

    const/16 v0, 0x56

    invoke-interface {v10, v5, v3}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    :goto_8a
    const/16 v0, 0x6f

    invoke-interface {v10}, Landroid/content/SharedPreferences$Editor;->apply()V

    const-string/jumbo p1, "video"

    const/16 v0, 0x399

    invoke-virtual {p0, p1, v2}, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->i(Ljava/lang/String;Z)V

    return-void
.end method

.method public c(Lwm;)Ljava/lang/Object;
    .registers 15

    .prologue
    const/16 v6, 0x1204

    iget-object v8, p0, Lz3;->b:Ljava/lang/Object;

    nop

    check-cast v8, Lly;

    const/16 v6, 0xc8c

    iget-object v9, p0, Lz3;->c:Ljava/lang/Object;

    nop

    check-cast v9, Lyy;

    const/16 v6, 0x6c1

    iget-object p0, p0, Lz3;->d:Ljava/lang/Object;

    nop

    check-cast p0, Lpk0;

    const/16 v6, 0xb9b

    sget-object v10, Lms1;->e:Lms1;

    nop

    const/16 v6, 0x890

    invoke-interface {v8, v10}, Lly;->get(Lky;)Ljy;

    move-result-object v10

    check-cast v10, Lfv0;

    const/16 v6, 0xb36

    new-instance v11, Lc;

    nop

    const/16 v12, 0x12

    const/16 v6, 0x87c

    invoke-direct {v11, v12, v10}, Lc;-><init>(ILjava/lang/Object;)V

    const/16 v6, 0x50d

    iget-object v10, p1, Lwm;->c:Lzt1;

    nop

    if-eqz v10, :cond_3f

    const/16 v6, 0xf3a

    sget-object v12, Lu40;->a:Lu40;

    nop

    const/16 v6, 0x42e

    invoke-virtual {v10, v11, v12}, Lf1;->a(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    :cond_3f
    const/16 v6, 0xf43

    invoke-static {v8}, Lw53;->a(Lly;)Lsx;

    move-result-object v8

    const/16 v6, 0xd39

    new-instance v10, Lto;

    nop

    const/4 v11, 0x2

    const/4 v12, 0x0

    const/16 v6, 0xce7

    move v0, v6

    move-object v1, v10

    move-object v2, p0

    move-object v3, p1

    move-object v4, v12

    move v5, v11

    invoke-direct/range {v1 .. v5}, Lto;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lvx;I)V

    const/4 p0, 0x1

    const/16 v6, 0xb3

    move v0, v6

    move-object v1, v8

    move-object v2, v12

    move-object v3, v9

    move-object v4, v10

    move v5, p0

    invoke-static/range {v1 .. v5}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    move-result-object p0

    check-cast p0, Ljava/lang/Object;

    return-object p0
.end method

.method public onComplete(Lcom/google/android/gms/tasks/Task;)V
    .registers 7

    .prologue
    const/16 v0, 0x1204

    iget-object v2, p0, Lz3;->b:Ljava/lang/Object;

    nop

    check-cast v2, Lcom/google/android/gms/tasks/Task;

    const/16 v0, 0xc8c

    iget-object v3, p0, Lz3;->c:Ljava/lang/Object;

    nop

    check-cast v3, Lfm0;

    const/16 v0, 0x6c1

    iget-object p0, p0, Lz3;->d:Ljava/lang/Object;

    nop

    check-cast p0, Lcom/tlsvpn/tlstunnel/MainActivity;

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xe1a

    invoke-virtual {v2}, Lcom/google/android/gms/tasks/Task;->isSuccessful()Z

    move-result p1

    if-eqz p1, :cond_b3

    const/16 v0, 0xea8

    invoke-virtual {v2}, Lcom/google/android/gms/tasks/Task;->getResult()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lvu1;

    move-object v2, p1

    check-cast v2, Lta3;

    const/16 v0, 0xc57

    iget-boolean v2, v2, Lta3;->b:Z

    nop

    if-eqz v2, :cond_3b

    const/4 p1, 0x0

    const/16 v0, 0x93a

    invoke-static {p1}, Lcom/google/android/gms/tasks/Tasks;->forResult(Ljava/lang/Object;)Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    goto :goto_9e

    :cond_3b
    const/16 v0, 0x5b

    new-instance v2, Landroid/content/Intent;

    nop

    const-class v4, Lcom/google/android/play/core/common/PlayCoreDialogWrapperActivity;

    const/16 v0, 0xd0

    invoke-direct {v2, p0, v4}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    check-cast p1, Lta3;

    const/16 v0, 0xa3f

    iget-object p1, p1, Lta3;->a:Landroid/app/PendingIntent;

    nop

    const-string/jumbo v4, "confirmation_intent"

    const/16 v0, 0x436

    invoke-virtual {v2, v4, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    const/16 v0, 0x86

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p1

    const/16 v0, 0x213

    invoke-virtual {p1}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object p1

    const/16 v0, 0xb0d

    invoke-virtual {p1}, Landroid/view/View;->getWindowSystemUiVisibility()I

    move-result p1

    const-string/jumbo v4, "window_flags"

    const/16 v0, 0x29

    invoke-virtual {v2, v4, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/16 v0, 0x898

    new-instance p1, Lcom/google/android/gms/tasks/TaskCompletionSource;

    nop

    const/16 v0, 0xd1b

    invoke-direct {p1}, Lcom/google/android/gms/tasks/TaskCompletionSource;-><init>()V

    const/16 v0, 0x1052

    iget-object v3, v3, Lfm0;->c:Ljava/lang/Object;

    nop

    check-cast v3, Landroid/os/Handler;

    const/16 v0, 0xf72

    new-instance v4, Lne3;

    nop

    const/16 v0, 0xd5b

    invoke-direct {v4, v3, p1}, Lne3;-><init>(Landroid/os/Handler;Lcom/google/android/gms/tasks/TaskCompletionSource;)V

    const-string/jumbo v3, "result_receiver"

    const/16 v0, 0x436

    invoke-virtual {v2, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    const/16 v0, 0xcf0

    invoke-virtual {p0, v2}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    const/16 v0, 0xeaf

    invoke-virtual {p1}, Lcom/google/android/gms/tasks/TaskCompletionSource;->getTask()Lcom/google/android/gms/tasks/Task;

    move-result-object p1

    :goto_9e
    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x50f

    new-instance v2, Lah;

    nop

    const/16 v3, 0xf

    const/16 v0, 0x3bf

    invoke-direct {v2, v3, p0}, Lah;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0xe42

    invoke-virtual {p1, v2}, Lcom/google/android/gms/tasks/Task;->addOnCompleteListener(Lcom/google/android/gms/tasks/OnCompleteListener;)Lcom/google/android/gms/tasks/Task;

    :cond_b3
    return-void
.end method

.method public run()Ljava/lang/Object;
    .registers 7

    .prologue
    const/16 v0, 0xc34

    iget v2, p0, Lz3;->a:I

    nop

    const/4 v3, 0x0

    const/16 v0, 0x6c1

    iget-object v4, p0, Lz3;->d:Ljava/lang/Object;

    nop

    const/16 v0, 0xc8c

    iget-object v5, p0, Lz3;->c:Ljava/lang/Object;

    nop

    const/16 v0, 0x1204

    iget-object p0, p0, Lz3;->b:Ljava/lang/Object;

    nop

    check-cast p0, Lo9;

    check-cast v5, Landroid/net/http/UrlResponseInfo;

    packed-switch v2, :pswitch_data_4c

    check-cast v4, Ljava/lang/String;

    const/16 v0, 0x458

    invoke-static {v5}, Lr9;->b(Landroid/net/http/UrlResponseInfo;)Lr9;

    move-result-object v2

    const/16 v0, 0x295

    iget-object v5, p0, Lo9;->a:Lorg/chromium/net/UrlRequest$Callback;

    nop

    const/16 v0, 0x397

    iget-object p0, p0, Lo9;->b:Lq9;

    nop

    const/16 v0, 0x11ac

    invoke-virtual {v5, p0, v2, v4}, Lorg/chromium/net/UrlRequest$Callback;->onRedirectReceived(Lorg/chromium/net/UrlRequest;Lorg/chromium/net/UrlResponseInfo;Ljava/lang/String;)V

    return-object v3

    :pswitch_34  #0x1
    check-cast v4, Ljava/nio/ByteBuffer;

    const/16 v0, 0x458

    invoke-static {v5}, Lr9;->b(Landroid/net/http/UrlResponseInfo;)Lr9;

    move-result-object v2

    const/16 v0, 0x295

    iget-object v5, p0, Lo9;->a:Lorg/chromium/net/UrlRequest$Callback;

    nop

    const/16 v0, 0x397

    iget-object p0, p0, Lo9;->b:Lq9;

    nop

    const/16 v0, 0xf68

    invoke-virtual {v5, p0, v2, v4}, Lorg/chromium/net/UrlRequest$Callback;->onReadCompleted(Lorg/chromium/net/UrlRequest;Lorg/chromium/net/UrlResponseInfo;Ljava/nio/ByteBuffer;)V

    return-object v3

    :pswitch_data_4c
    .packed-switch 0x1
        :pswitch_34  #00000001
    .end packed-switch
.end method

.method public run()V
    .registers 9

    .prologue
    const/16 v0, 0xc34

    iget v2, p0, Lz3;->a:I

    nop

    const/16 v0, 0x6c1

    iget-object v3, p0, Lz3;->d:Ljava/lang/Object;

    nop

    const/16 v0, 0xc8c

    iget-object v4, p0, Lz3;->c:Ljava/lang/Object;

    nop

    const/16 v0, 0x1204

    iget-object p0, p0, Lz3;->b:Ljava/lang/Object;

    nop

    check-cast p0, Lvu0;

    packed-switch v2, :pswitch_data_50

    check-cast v4, Lyh2;

    check-cast v3, Ljava/lang/String;

    const/16 v0, 0x414

    iget-object v2, p0, Lvu0;->a:Lij2;

    nop

    const/16 v0, 0x445

    iget-object p0, p0, Lvu0;->d:Lyu0;

    nop

    const/16 v0, 0x719

    invoke-virtual {v2, p0, v4, v3}, Lij2;->onRedirectReceived(Lorg/chromium/net/UrlRequest;Lorg/chromium/net/UrlResponseInfo;Ljava/lang/String;)V

    return-void

    :pswitch_2d  #0x4
    check-cast v4, Lorg/chromium/net/UrlResponseInfo;

    check-cast v3, Ljava/nio/ByteBuffer;

    const/16 v0, 0x445

    iget-object v2, p0, Lvu0;->d:Lyu0;

    nop

    const/16 v0, 0x110d

    iget-object v5, v2, Lyu0;->f:Ljava/util/concurrent/atomic/AtomicInteger;

    nop

    const/4 v6, 0x5

    const/4 v7, 0x4

    const/16 v0, 0x10b4

    invoke-virtual {v5, v6, v7}, Ljava/util/concurrent/atomic/AtomicInteger;->compareAndSet(II)Z

    move-result v5

    if-eqz v5, :cond_4f

    const/16 v0, 0x414

    iget-object p0, p0, Lvu0;->a:Lij2;

    nop

    const/16 v0, 0xe99

    invoke-virtual {p0, v2, v4, v3}, Lij2;->onReadCompleted(Lorg/chromium/net/UrlRequest;Lorg/chromium/net/UrlResponseInfo;Ljava/nio/ByteBuffer;)V

    :cond_4f
    return-void

    :pswitch_data_50
    .packed-switch 0x4
        :pswitch_2d  #00000004
    .end packed-switch
.end method
