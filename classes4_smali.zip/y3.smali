.class public final synthetic Ly3;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lmv;


# instance fields
.field public final synthetic a:Lcom/google/android/gms/internal/consent_sdk/zzj;

.field public final synthetic b:Landroid/app/Activity;


# direct methods
.method public synthetic constructor <init>(Lcom/google/android/gms/internal/consent_sdk/zzj;Landroid/app/Activity;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x6e2

    iput-object p1, p0, Ly3;->a:Lcom/google/android/gms/internal/consent_sdk/zzj;

    const/16 v0, 0xd79

    iput-object p2, p0, Ly3;->b:Landroid/app/Activity;

    return-void
.end method


# virtual methods
.method public final a(Lch0;)V
    .registers 6

    .prologue
    if-eqz p1, :cond_2d

    const/4 v0, -0x3

    new-instance v2, Ljava/lang/StringBuilder;

    nop

    const/4 v0, -0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v0, 0x10bf

    iget v3, p1, Lch0;->a:I

    nop

    const/16 v0, 0x33

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v3, ": "

    const/4 v0, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x98a

    iget-object p1, p1, Lch0;->b:Ljava/lang/String;

    nop

    const/4 v0, 0x0

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string/jumbo v2, "Ads-UMP"

    nop

    :cond_2d
    const/16 v0, 0x57d

    iget-object p1, p0, Ly3;->a:Lcom/google/android/gms/internal/consent_sdk/zzj;

    nop

    const/16 v0, 0xfd0

    invoke-virtual {p1}, Lcom/google/android/gms/internal/consent_sdk/zzj;->canRequestAds()Z

    move-result p1

    if-eqz p1, :cond_53

    const/16 v0, 0x140

    sget-boolean p1, Lg4;->a:Z

    nop

    const/16 v0, 0xd05

    iget-object p0, p0, Ly3;->b:Landroid/app/Activity;

    nop

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x1136

    invoke-static {p0}, Lg4;->e(Landroid/content/Context;)V

    :cond_53
    return-void
.end method
