.class public final Lsd;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Landroid/content/pm/ApplicationInfo;

.field public b:Z


# direct methods
.method public constructor <init>(Landroid/content/pm/ApplicationInfo;Z)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x58c

    iput-object p1, p0, Lsd;->a:Landroid/content/pm/ApplicationInfo;

    const/16 v0, 0xf7f

    iput-boolean p2, p0, Lsd;->b:Z

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .prologue
    if-ne p0, p1, :cond_3

    goto :goto_2b

    :cond_3
    instance-of v2, p1, Lsd;

    if-nez v2, :cond_8

    goto :goto_29

    :cond_8
    check-cast p1, Lsd;

    const/16 v0, 0x1dc

    iget-object v2, p0, Lsd;->a:Landroid/content/pm/ApplicationInfo;

    nop

    const/16 v0, 0x1dc

    iget-object v3, p1, Lsd;->a:Landroid/content/pm/ApplicationInfo;

    nop

    const/16 v0, 0x128

    invoke-virtual {v2, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_1d

    goto :goto_29

    :cond_1d
    const/16 v0, 0x293

    iget-boolean p0, p0, Lsd;->b:Z

    nop

    const/16 v0, 0x293

    iget-boolean p1, p1, Lsd;->b:Z

    nop

    if-eq p0, p1, :cond_2b

    :goto_29
    const/4 p0, 0x0

    return p0

    :cond_2b
    :goto_2b
    const/4 p0, 0x1

    return p0
.end method

.method public final hashCode()I
    .registers 4

    const/16 v0, 0x1dc

    iget-object v2, p0, Lsd;->a:Landroid/content/pm/ApplicationInfo;

    nop

    const/16 v0, 0xec8

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v2

    mul-int/lit8 v2, v2, 0x1f

    const/16 v0, 0x293

    iget-boolean p0, p0, Lsd;->b:Z

    nop

    const/16 v0, 0x10a

    invoke-static {p0}, Ljava/lang/Boolean;->hashCode(Z)I

    move-result p0

    add-int/2addr p0, v2

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 5

    const/4 v0, -0x3

    new-instance v2, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v3, "AppInfo(appInfo="

    const/16 v0, 0x97

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x1dc

    iget-object v3, p0, Lsd;->a:Landroid/content/pm/ApplicationInfo;

    nop

    const/16 v0, 0x190

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string/jumbo v3, ", checked="

    const/4 v0, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x293

    iget-boolean p0, p0, Lsd;->b:Z

    nop

    const/16 v0, 0x6a

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/16 p0, 0x29

    const/16 v0, 0x1b

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    return-object p0
.end method
