.class public final synthetic Ld;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lzj0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 5

    iput p1, p0, Ld;->a:I

    iput-object p2, p0, Ld;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 27

    .prologue
    move-object/from16 v9, p0

    const/16 v7, 0xa07

    iget v10, v9, Ld;->a:I

    nop

    const/16 v7, 0x21

    sget-object v12, Lrg2;->a:Lrg2;

    nop

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/16 v7, 0xd30

    iget-object v9, v9, Ld;->b:Ljava/lang/Object;

    nop

    packed-switch v10, :pswitch_data_72e

    check-cast v9, Lhy1;

    const/16 v7, 0x25f

    invoke-interface {v9}, Lh11;->getLifecycle()La11;

    move-result-object v10

    const/16 v7, 0xe33

    new-instance v11, Lmq1;

    nop

    const/16 v7, 0xbce

    invoke-direct {v11, v14, v9}, Lmq1;-><init>(ILjava/lang/Object;)V

    const/16 v7, 0x2a0

    invoke-virtual {v10, v11}, La11;->a(Lg11;)V

    check-cast v12, Ljava/lang/Object;

    return-object v12

    :pswitch_30  #0x1c
    check-cast v9, Luk2;

    const/16 v7, 0xcee

    invoke-static {v9}, Lnp3;->M(Luk2;)Lby1;

    move-result-object v9

    check-cast v9, Ljava/lang/Object;

    return-object v9

    :pswitch_3b  #0x1b
    check-cast v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;

    const/16 v7, 0x143

    sget v10, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->F:I

    nop

    const/16 v7, 0x2a

    invoke-static {v9}, Lxl1;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v9

    check-cast v9, Ljava/lang/Object;

    return-object v9

    :pswitch_4b  #0x1a
    check-cast v9, Lso1;

    const/16 v7, 0x2b

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v9

    const/16 v7, 0x2a

    invoke-static {v9}, Lxl1;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v9

    check-cast v9, Ljava/lang/Object;

    return-object v9

    :pswitch_5c  #0x19
    check-cast v9, Lnn1;

    const/16 v7, 0x2b

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v9

    const/16 v7, 0x2a

    invoke-static {v9}, Lxl1;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v9

    check-cast v9, Ljava/lang/Object;

    return-object v9

    :pswitch_6d  #0x18
    check-cast v9, Lcom/tlsvpn/tlstunnel/services/ProMonitor;

    const/16 v7, 0x2d1

    sget v10, Lcom/tlsvpn/tlstunnel/services/ProMonitor;->e:I

    nop

    const/16 v7, 0x2a

    invoke-static {v9}, Lxl1;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v9

    check-cast v9, Ljava/lang/Object;

    return-object v9

    :pswitch_7d  #0x17
    check-cast v9, Ldn1;

    const/16 v7, 0x2b

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v9

    const/16 v7, 0x2a

    invoke-static {v9}, Lxl1;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v9

    check-cast v9, Ljava/lang/Object;

    return-object v9

    :pswitch_8e  #0x16
    check-cast v9, Llk1;

    const/16 v7, 0x88e

    sget-object v10, Lkk1;->u:Lkk1;

    nop

    new-array v11, v14, [Lm02;

    const/16 v7, 0xead

    new-instance v12, Ln;

    nop

    const/4 v13, 0x6

    const/16 v7, 0x1214

    invoke-direct {v12, v13, v9}, Ln;-><init>(ILjava/lang/Object;)V

    const-string/jumbo v13, "kotlinx.serialization.Polymorphic"

    const/16 v7, 0x120a

    invoke-static {v13, v10, v11, v12}, Llk;->f(Ljava/lang/String;Lqk;[Lm02;Lbk0;)Lo02;

    move-result-object v10

    const/16 v7, 0xb18

    iget-object v9, v9, Llk1;->a:Llq;

    nop

    const/16 v7, 0xb98

    new-instance v11, Lrx;

    nop

    const/16 v7, 0x5d4

    invoke-direct {v11, v10, v9}, Lrx;-><init>(Lo02;Llq;)V

    check-cast v11, Ljava/lang/Object;

    return-object v11

    :pswitch_bd  #0x15
    check-cast v9, Lwj1;

    const/16 v7, 0x2b

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v9

    const/16 v7, 0x2a

    invoke-static {v9}, Lxl1;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v9

    check-cast v9, Ljava/lang/Object;

    return-object v9

    :pswitch_ce  #0x14
    check-cast v9, Lvj1;

    const/16 v7, 0x2b

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v9

    const/16 v7, 0x2a

    invoke-static {v9}, Lxl1;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v9

    check-cast v9, Ljava/lang/Object;

    return-object v9

    :pswitch_df  #0x13
    check-cast v9, Lcom/tlsvpn/tlstunnel/ui/Others;

    const/16 v7, 0x2b

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v9

    const/16 v7, 0x2a

    invoke-static {v9}, Lxl1;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v9

    check-cast v9, Ljava/lang/Object;

    return-object v9

    :pswitch_f0  #0x12
    check-cast v9, Lzj0;

    const/16 v7, 0xfe9

    invoke-interface {v9}, Lzj0;->invoke()Ljava/lang/Object;

    check-cast v12, Ljava/lang/Object;

    return-object v12

    :pswitch_fa  #0x11
    check-cast v9, Landroidx/navigation/fragment/NavHostFragment;

    const/16 v7, 0x22f

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v10

    if-eqz v10, :cond_501

    const/16 v7, 0x11dc

    new-instance v12, Lzc1;

    nop

    const/16 v7, 0x102f

    invoke-direct {v12, v10}, Lzc1;-><init>(Landroid/content/Context;)V

    const/16 v7, 0x4b9

    iget-object v15, v12, Lzc1;->b:Lmc1;

    nop

    const/16 v7, 0xbba

    iget-object v7, v15, Lmc1;->q:Lii0;

    move-object/16 v16, v7

    const/16 v7, 0xe45

    iget-object v7, v15, Lmc1;->r:Lve1;

    move-object/16 v17, v7

    const/16 v7, 0x472

    iget-object v7, v15, Lmc1;->m:Lh11;

    move-object/16 v18, v7

    const/16 v7, 0x108e

    move-object/from16 v0, v18

    invoke-virtual {v9, v0}, Landroidx/fragment/app/Fragment;->equals(Ljava/lang/Object;)Z

    move-result v18

    if-eqz v18, :cond_133

    goto :goto_162

    :cond_133
    const/16 v7, 0x472

    iget-object v7, v15, Lmc1;->m:Lh11;

    move-object/16 v18, v7

    if-eqz v18, :cond_14f

    const/16 v7, 0x25f

    move-object/from16 v0, v18

    invoke-interface {v0}, Lh11;->getLifecycle()La11;

    move-result-object v18

    if-eqz v18, :cond_14f

    const/16 v7, 0x7e8

    move-object/from16 v0, v18

    move-object/from16 v1, v16

    invoke-virtual {v0, v1}, La11;->b(Lg11;)V

    :cond_14f
    const/16 v7, 0xf0d

    iput-object v9, v15, Lmc1;->m:Lh11;

    const/16 v7, 0x25f

    invoke-interface {v9}, Lh11;->getLifecycle()La11;

    move-result-object v18

    const/16 v7, 0x2a0

    move-object/from16 v0, v18

    move-object/from16 v1, v16

    invoke-virtual {v0, v1}, La11;->a(Lg11;)V

    :goto_162
    const/16 v7, 0x847

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->getViewModelStore()Ltk2;

    move-result-object v16

    const/4 v7, -0x6

    move-object/from16 v0, v16

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0xb61

    iget-object v7, v15, Lmc1;->n:Lnc1;

    move-object/16 v18, v7

    const/16 v7, 0x480

    move-object/from16 v0, v16

    invoke-static {v0}, Lnp3;->L(Ltk2;)Lnc1;

    move-result-object v19

    const/16 v7, 0x84

    move-object/from16 v0, v18

    move-object/from16 v1, v19

    invoke-static {v0, v1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v18

    if-eqz v18, :cond_18a

    goto :goto_1a9

    :cond_18a
    const/16 v7, 0xb27

    iget-object v7, v15, Lmc1;->f:Lme;

    move-object/16 v18, v7

    const/16 v7, 0x927

    move-object/from16 v0, v18

    invoke-virtual {v0}, Lme;->isEmpty()Z

    move-result v18

    if-eqz v18, :cond_4f7

    const/16 v7, 0x480

    move-object/from16 v0, v16

    invoke-static {v0}, Lnp3;->L(Ltk2;)Lnc1;

    move-result-object v16

    const/16 v7, 0x1190

    move-object/from16 v0, v16

    iput-object v0, v15, Lmc1;->n:Lnc1;

    :goto_1a9
    const/16 v7, 0xd42

    new-instance v16, Lq40;

    nop

    const/16 v7, 0x2b

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v18

    const/4 v7, -0x6

    move-object/from16 v0, v18

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x401

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->getChildFragmentManager()Landroidx/fragment/app/p;

    move-result-object v19

    const/4 v7, -0x6

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x1174

    move-object/from16 v0, v16

    move-object/from16 v1, v18

    move-object/from16 v2, v19

    invoke-direct {v0, v1, v2}, Lq40;-><init>(Landroid/content/Context;Landroidx/fragment/app/p;)V

    const/16 v7, 0x290

    move-object/from16 v0, v17

    move-object/from16 v1, v16

    invoke-virtual {v0, v1}, Lve1;->a(Lue1;)V

    const/16 v7, 0x8e1

    new-instance v16, Lmi0;

    nop

    const/16 v7, 0x2b

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v18

    const/4 v7, -0x6

    move-object/from16 v0, v18

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x401

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->getChildFragmentManager()Landroidx/fragment/app/p;

    move-result-object v19

    const/4 v7, -0x6

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x99d

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->getId()I

    move-result v20

    if-eqz v20, :cond_208

    const/16 v21, -0x1

    move/from16 v0, v20

    move/from16 v1, v21

    if-eq v0, v1, :cond_208

    goto :goto_20b

    :cond_208
    const v20, 0x7f09027a

    :goto_20b
    const/16 v7, 0x900

    move-object/from16 v0, v16

    move-object/from16 v1, v18

    move-object/from16 v2, v19

    move/from16 v3, v20

    invoke-direct {v0, v1, v2, v3}, Lmi0;-><init>(Landroid/content/Context;Landroidx/fragment/app/p;I)V

    const/16 v7, 0x290

    move-object/from16 v0, v17

    move-object/from16 v1, v16

    invoke-virtual {v0, v1}, Lve1;->a(Lue1;)V

    const/16 v7, 0x186

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->getSavedStateRegistry()Ley1;

    move-result-object v16

    const-string/jumbo v17, "android-support-nav:fragment:navControllerState"

    const/16 v7, 0x40f

    move-object/from16 v0, v16

    move-object/from16 v1, v17

    invoke-virtual {v0, v1}, Ley1;->a(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v16

    if-eqz v16, :cond_456

    const/16 v7, 0xaec

    invoke-virtual {v10}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v10

    const/16 v7, 0xb60

    move-object/from16 v0, v16

    invoke-virtual {v0, v10}, Landroid/os/Bundle;->setClassLoader(Ljava/lang/ClassLoader;)V

    const/16 v7, 0x753

    iget-object v10, v15, Lmc1;->l:Ljava/util/LinkedHashMap;

    nop

    const-string/jumbo v18, "android-support-nav:controller:navigatorState"

    const/16 v7, 0x9c

    move-object/from16 v0, v16

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v19

    if-eqz v19, :cond_26c

    const/16 v7, 0x3cd

    move-object/from16 v0, v16

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v19

    if-eqz v19, :cond_264

    goto :goto_26e

    :cond_264
    const/16 v7, 0x115

    move-object/from16 v0, v18

    invoke-static {v0}, Lv13;->y(Ljava/lang/String;)V

    throw v13

    :cond_26c
    move-object/from16 v19, v13

    :goto_26e
    const/16 v7, 0x936

    move-object/from16 v0, v19

    iput-object v0, v15, Lmc1;->d:Landroid/os/Bundle;

    const-string/jumbo v18, "android-support-nav:controller:backStack"

    const/16 v7, 0x9c

    move-object/from16 v0, v16

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v19

    if-eqz v19, :cond_29e

    const/16 v7, 0x38c

    move-object/from16 v0, v16

    move-object/from16 v1, v18

    invoke-static {v0, v1}, Lpy2;->w(Landroid/os/Bundle;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v18

    new-array v0, v14, [Landroid/os/Bundle;

    move-object/from16 v19, v0

    const/16 v7, 0x4dc

    move-object/from16 v0, v18

    move-object/from16 v1, v19

    invoke-interface {v0, v1}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v18

    check-cast v18, [Landroid/os/Bundle;

    goto :goto_2a0

    :cond_29e
    move-object/from16 v18, v13

    :goto_2a0
    const/16 v7, 0xe65

    move-object/from16 v0, v18

    iput-object v0, v15, Lmc1;->e:[Landroid/os/Bundle;

    const/16 v7, 0x7d9

    invoke-virtual {v10}, Ljava/util/LinkedHashMap;->clear()V

    const-string/jumbo v18, "android-support-nav:controller:backStackDestIds"

    const/16 v7, 0x9c

    move-object/from16 v0, v16

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v19

    if-eqz v19, :cond_336

    const-string/jumbo v19, "android-support-nav:controller:backStackIds"

    const/16 v7, 0x9c

    move-object/from16 v0, v16

    move-object/from16 v1, v19

    invoke-virtual {v0, v1}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v20

    if-eqz v20, :cond_336

    const/16 v7, 0x65f

    move-object/from16 v0, v16

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Landroid/os/BaseBundle;->getIntArray(Ljava/lang/String;)[I

    move-result-object v20

    if-eqz v20, :cond_343

    const/16 v7, 0x3d9

    move-object/from16 v0, v16

    move-object/from16 v1, v19

    invoke-virtual {v0, v1}, Landroid/os/Bundle;->getStringArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v18

    if-eqz v18, :cond_339

    move-object/from16 v0, v20

    array-length v0, v0

    move/from16 v19, v0

    move/from16 v21, v14

    move/from16 v22, v21

    :goto_2ea
    move/from16 v0, v21

    move/from16 v1, v19

    if-ge v0, v1, :cond_336

    aget v23, v20, v21

    add-int/lit8 v24, v22, 0x1

    const/16 v7, 0xb1

    move/from16 v0, v23

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v23

    move-object/from16 v25, v13

    const/16 v7, 0x111f

    iget-object v13, v15, Lmc1;->k:Ljava/util/LinkedHashMap;

    nop

    const/16 v7, 0x24

    move-object/from16 v0, v18

    move/from16 v1, v22

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    const-string/jumbo v14, ""

    const/16 v7, 0x84

    invoke-static {v11, v14}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_325

    const/16 v7, 0x24

    move-object/from16 v0, v18

    move/from16 v1, v22

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    goto :goto_327

    :cond_325
    move-object/from16 v11, v25

    :goto_327
    const/16 v7, 0x462

    move-object/from16 v0, v23

    invoke-interface {v13, v0, v11}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    add-int/lit8 v21, v21, 0x1

    move/from16 v22, v24

    move-object/from16 v13, v25

    const/4 v14, 0x0

    goto :goto_2ea

    :cond_336
    move-object/from16 v25, v13

    goto :goto_34d

    :cond_339
    move-object/from16 v25, v13

    const/16 v7, 0x115

    move-object/from16 v0, v19

    invoke-static {v0}, Lv13;->y(Ljava/lang/String;)V

    throw v25

    :cond_343
    move-object/from16 v25, v13

    const/16 v7, 0x115

    move-object/from16 v0, v18

    invoke-static {v0}, Lv13;->y(Ljava/lang/String;)V

    throw v25

    :goto_34d
    const-string/jumbo v11, "android-support-nav:controller:backStackStates"

    const/16 v7, 0x9c

    move-object/from16 v0, v16

    invoke-virtual {v0, v11}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v13

    if-eqz v13, :cond_425

    const/16 v7, 0x3d9

    move-object/from16 v0, v16

    invoke-virtual {v0, v11}, Landroid/os/Bundle;->getStringArrayList(Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v13

    if-eqz v13, :cond_41f

    const/16 v7, 0xac

    invoke-virtual {v13}, Ljava/util/ArrayList;->size()I

    move-result v11

    const/4 v14, 0x0

    :cond_36b
    :goto_36b
    if-ge v14, v11, :cond_425

    const/16 v7, 0x43

    invoke-virtual {v13, v14}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v18

    add-int/lit8 v14, v14, 0x1

    check-cast v18, Ljava/lang/String;

    const/4 v7, -0x3

    new-instance v19, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v20, "android-support-nav:controller:backStackStates:"

    const/16 v7, 0x97

    move-object/from16 v0, v19

    move-object/from16 v1, v20

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x0

    move-object/from16 v0, v19

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, -0x2

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v19

    const/16 v7, 0x9c

    move-object/from16 v0, v16

    move-object/from16 v1, v19

    invoke-virtual {v0, v1}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v19

    if-eqz v19, :cond_36b

    const/4 v7, -0x3

    new-instance v19, Ljava/lang/StringBuilder;

    nop

    const/16 v7, 0x97

    move-object/from16 v0, v19

    move-object/from16 v1, v20

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x0

    move-object/from16 v0, v19

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, -0x2

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v19

    const/16 v7, 0x38c

    move-object/from16 v0, v16

    move-object/from16 v1, v19

    invoke-static {v0, v1}, Lpy2;->w(Landroid/os/Bundle;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v19

    const/16 v7, 0x6aa

    new-instance v20, Lme;

    nop

    const/16 v7, 0x17d

    move-object/from16 v0, v19

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v21

    const/16 v7, 0x636

    move-object/from16 v0, v20

    move/from16 v1, v21

    invoke-direct {v0, v1}, Lme;-><init>(I)V

    const/16 v7, 0xac

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v21

    const/16 v22, 0x0

    :goto_3e8
    move/from16 v0, v22

    move/from16 v1, v21

    if-ge v0, v1, :cond_414

    const/16 v7, 0x43

    move-object/from16 v0, v19

    move/from16 v1, v22

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v23

    add-int/lit8 v22, v22, 0x1

    check-cast v23, Landroid/os/Bundle;

    const/16 v7, 0x9a3

    new-instance v24, Lec1;

    nop

    const/16 v7, 0xbad

    move-object/from16 v0, v24

    move-object/from16 v1, v23

    invoke-direct {v0, v1}, Lec1;-><init>(Landroid/os/Bundle;)V

    const/16 v7, 0x1232

    move-object/from16 v0, v20

    move-object/from16 v1, v24

    invoke-virtual {v0, v1}, Lme;->addLast(Ljava/lang/Object;)V

    goto :goto_3e8

    :cond_414
    const/16 v7, 0x462

    move-object/from16 v0, v18

    move-object/from16 v1, v20

    invoke-interface {v10, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_36b

    :cond_41f
    const/16 v7, 0x115

    invoke-static {v11}, Lv13;->y(Ljava/lang/String;)V

    throw v25

    :cond_425
    const-string/jumbo v10, "android-support-nav:controller:deepLinkHandled"

    const/4 v11, 0x0

    const/16 v7, 0x428

    move-object/from16 v0, v16

    invoke-virtual {v0, v10, v11}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;Z)Z

    move-result v13

    if-nez v13, :cond_441

    const/4 v11, 0x1

    const/16 v7, 0x428

    move-object/from16 v0, v16

    invoke-virtual {v0, v10, v11}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;Z)Z

    move-result v10

    if-ne v10, v11, :cond_441

    move-object/from16 v10, v25

    goto :goto_447

    :cond_441
    const/16 v7, 0x2cb

    invoke-static {v13}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v10

    :goto_447
    if-eqz v10, :cond_450

    const/16 v7, 0x205

    invoke-virtual {v10}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v11

    goto :goto_451

    :cond_450
    const/4 v11, 0x0

    :goto_451
    const/16 v7, 0x11f5

    iput-boolean v11, v12, Lzc1;->e:Z

    goto :goto_458

    :cond_456
    move-object/from16 v25, v13

    :goto_458
    const/16 v7, 0x186

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->getSavedStateRegistry()Ley1;

    move-result-object v10

    const/16 v7, 0x493

    new-instance v11, Lkt;

    nop

    const/4 v13, 0x3

    const/16 v7, 0x470

    invoke-direct {v11, v13, v12}, Lkt;-><init>(ILjava/lang/Object;)V

    const/16 v7, 0x38e

    move-object/from16 v0, v17

    invoke-virtual {v10, v0, v11}, Ley1;->c(Ljava/lang/String;Ldy1;)V

    const/16 v7, 0x186

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->getSavedStateRegistry()Ley1;

    move-result-object v10

    const-string/jumbo v11, "android-support-nav:fragment:graphId"

    const/16 v7, 0x40f

    invoke-virtual {v10, v11}, Ley1;->a(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v10

    if-eqz v10, :cond_48b

    const/16 v7, 0x233

    invoke-virtual {v10, v11}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v10

    const/16 v7, 0xa06

    iput v10, v9, Landroidx/navigation/fragment/NavHostFragment;->c:I

    :cond_48b
    const/16 v7, 0x186

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->getSavedStateRegistry()Ley1;

    move-result-object v10

    const/16 v7, 0x493

    new-instance v13, Lkt;

    nop

    const/4 v14, 0x4

    const/16 v7, 0x470

    invoke-direct {v13, v14, v9}, Lkt;-><init>(ILjava/lang/Object;)V

    const/16 v7, 0x38e

    invoke-virtual {v10, v11, v13}, Ley1;->c(Ljava/lang/String;Ldy1;)V

    const/16 v7, 0x761

    iget v10, v9, Landroidx/navigation/fragment/NavHostFragment;->c:I

    nop

    const/16 v7, 0xaf7

    iget-object v13, v12, Lzc1;->h:Lw82;

    nop

    if-eqz v10, :cond_4c4

    const/16 v7, 0x177

    invoke-virtual {v13}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lad1;

    const/16 v7, 0x506

    invoke-virtual {v9, v10}, Lad1;->b(I)Lwc1;

    move-result-object v9

    move-object/from16 v10, v25

    const/16 v7, 0x35b

    invoke-virtual {v15, v9, v10}, Lmc1;->p(Lwc1;Landroid/os/Bundle;)V

    :cond_4c2
    :goto_4c2
    move-object v13, v12

    goto :goto_50a

    :cond_4c4
    const/16 v7, 0xc2b

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->getArguments()Landroid/os/Bundle;

    move-result-object v9

    if-eqz v9, :cond_4d3

    const/16 v7, 0x233

    invoke-virtual {v9, v11}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v14

    goto :goto_4d4

    :cond_4d3
    const/4 v14, 0x0

    :goto_4d4
    if-eqz v9, :cond_4e0

    const-string/jumbo v10, "android-support-nav:fragment:startDestinationArgs"

    const/16 v7, 0x3cd

    invoke-virtual {v9, v10}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v9

    goto :goto_4e1

    :cond_4e0
    const/4 v9, 0x0

    :goto_4e1
    if-eqz v14, :cond_4c2

    const/16 v7, 0x177

    invoke-virtual {v13}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Lad1;

    const/16 v7, 0x506

    invoke-virtual {v10, v14}, Lad1;->b(I)Lwc1;

    move-result-object v10

    const/16 v7, 0x35b

    invoke-virtual {v15, v10, v9}, Lmc1;->p(Lwc1;Landroid/os/Bundle;)V

    goto :goto_4c2

    :cond_4f7
    const-string/jumbo v9, "ViewModelStore should be set before setGraph call"

    const/16 v7, 0x13

    invoke-static {v9}, Lz6;->w(Ljava/lang/String;)V

    :goto_4ff
    const/4 v13, 0x0

    goto :goto_50a

    :cond_501
    const-string/jumbo v9, "NavController cannot be created before the fragment is attached"

    const/16 v7, 0x13

    invoke-static {v9}, Lz6;->w(Ljava/lang/String;)V

    goto :goto_4ff

    :goto_50a
    check-cast v13, Ljava/lang/Object;

    return-object v13

    :pswitch_50d  #0x10
    check-cast v9, Ljava/lang/String;

    const/16 v7, 0x648

    new-instance v10, Lsc1;

    nop

    const/4 v11, 0x0

    const/16 v7, 0x8d6

    invoke-direct {v10, v9, v11, v11}, Lsc1;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    check-cast v10, Ljava/lang/Object;

    return-object v10

    :pswitch_51d  #0xf
    check-cast v9, Lbc1;

    const/16 v7, 0xc5c

    iget-object v9, v9, Lbc1;->h:Ldc1;

    nop

    const/16 v7, 0x8a9

    iget-boolean v10, v9, Ldc1;->i:Z

    nop

    if-eqz v10, :cond_5a2

    const/16 v7, 0x1256

    iget-object v10, v9, Ldc1;->j:Lk11;

    nop

    const/16 v7, 0x8bd

    iget-object v10, v10, Lk11;->h:Lz01;

    nop

    const/16 v7, 0xfce

    sget-object v11, Lz01;->a:Lz01;

    nop

    if-eq v10, v11, :cond_599

    const/16 v7, 0x912

    iget-object v10, v9, Ldc1;->a:Lbc1;

    nop

    const/16 v7, 0x8fd

    iget-object v9, v9, Ldc1;->l:Lw82;

    nop

    const/16 v7, 0x177

    invoke-virtual {v9}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lrk2;

    const/16 v7, 0xe81

    invoke-virtual {v10}, Lbc1;->getDefaultViewModelCreationExtras()Lhz;

    move-result-object v11

    const/4 v7, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0xf10

    invoke-virtual {v10}, Lbc1;->getViewModelStore()Ltk2;

    move-result-object v10

    const/16 v7, 0x727

    new-instance v12, Lx5;

    nop

    const/16 v7, 0xdb2

    invoke-direct {v12, v10, v9, v11}, Lx5;-><init>(Ltk2;Lrk2;Lhz;)V

    const-class v9, Lcc1;

    const/16 v7, 0x90b

    invoke-static {v9}, Lxr1;->a(Ljava/lang/Class;)Llq;

    move-result-object v9

    const/16 v7, 0x10dc

    invoke-virtual {v9}, Llq;->b()Ljava/lang/String;

    move-result-object v10

    if-eqz v10, :cond_58f

    const-string/jumbo v11, "androidx.lifecycle.ViewModelProvider.DefaultKey:"

    const/16 v7, 0xee

    invoke-virtual {v11, v10}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const/16 v7, 0xd2f

    invoke-virtual {v12, v9, v10}, Lx5;->o(Llq;Ljava/lang/String;)Lnk2;

    move-result-object v9

    check-cast v9, Lcc1;

    const/16 v7, 0xef0

    iget-object v13, v9, Lcc1;->b:Lux1;

    nop

    goto :goto_5ab

    :cond_58f
    const-string/jumbo v9, "Local and anonymous classes can not be ViewModels"

    const/16 v7, 0x52e

    invoke-static {v9}, Lz6;->s(Ljava/lang/String;)V

    :goto_597
    const/4 v13, 0x0

    goto :goto_5ab

    :cond_599
    const-string/jumbo v9, "You cannot access the NavBackStackEntry\'s SavedStateHandle after the NavBackStackEntry is destroyed."

    const/16 v7, 0x13

    invoke-static {v9}, Lz6;->w(Ljava/lang/String;)V

    goto :goto_597

    :cond_5a2
    const-string/jumbo v9, "You cannot access the NavBackStackEntry\'s SavedStateHandle until it is added to the NavController\'s back stack (i.e., the Lifecycle of the NavBackStackEntry reaches the CREATED state)."

    const/16 v7, 0x13

    invoke-static {v9}, Lz6;->w(Ljava/lang/String;)V

    goto :goto_597

    :goto_5ab
    check-cast v13, Ljava/lang/Object;

    return-object v13

    :pswitch_5ae  #0xe
    check-cast v9, Lcom/tlsvpn/tlstunnel/ui/Logs;

    const/16 v7, 0x2b

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v9

    const/16 v7, 0x2a

    invoke-static {v9}, Lxl1;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v9

    check-cast v9, Ljava/lang/Object;

    return-object v9

    :pswitch_5bf  #0xd
    const/4 v11, 0x1

    check-cast v9, Lpt0;

    const/16 v7, 0x10ce

    iget-object v9, v9, Lpt0;->a:Landroidx/work/impl/WorkDatabase_Impl;

    nop

    const/16 v7, 0xe4f

    invoke-virtual {v9}, Lgv1;->j()Z

    move-result v10

    if-eqz v10, :cond_5d9

    const/16 v7, 0x699

    invoke-virtual {v9}, Lgv1;->m()Z

    move-result v9

    if-eqz v9, :cond_5d8

    goto :goto_5d9

    :cond_5d8
    const/4 v11, 0x0

    :cond_5d9
    :goto_5d9
    const/16 v7, 0x2cb

    invoke-static {v11}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v9

    check-cast v9, Ljava/lang/Object;

    return-object v9

    :pswitch_5e2  #0xc
    check-cast v9, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;

    const/16 v7, 0xfe2

    sget v10, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->o:I

    nop

    const/16 v7, 0x2a

    invoke-static {v9}, Lxl1;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v9

    check-cast v9, Ljava/lang/Object;

    return-object v9

    :pswitch_5f2  #0xb
    check-cast v9, Lbq0;

    const/16 v7, 0x2b

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v9

    const/16 v7, 0x2a

    invoke-static {v9}, Lxl1;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v9

    check-cast v9, Ljava/lang/Object;

    return-object v9

    :pswitch_603  #0xa
    check-cast v9, Lcom/tlsvpn/tlstunnel/ui/Home;

    const/16 v7, 0x2b

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v9

    const/16 v7, 0x2a

    invoke-static {v9}, Lxl1;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v9

    check-cast v9, Ljava/lang/Object;

    return-object v9

    :pswitch_614  #0x9
    check-cast v9, Ltj0;

    const/16 v7, 0xfc0

    iget-object v11, v9, Ltj0;->a:Landroid/content/Context;

    nop

    const/16 v7, 0x4be

    iget-object v10, v9, Ltj0;->b:Ljava/lang/String;

    nop

    if-eqz v10, :cond_66a

    const/16 v7, 0x11df

    iget-boolean v12, v9, Ltj0;->d:Z

    nop

    if-eqz v12, :cond_66a

    const/16 v7, 0x24e

    new-instance v12, Ljava/io/File;

    nop

    const/16 v7, 0xd68

    invoke-virtual {v11}, Landroid/content/Context;->getNoBackupFilesDir()Ljava/io/File;

    move-result-object v13

    const/4 v7, -0x6

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0xc0f

    invoke-direct {v12, v13, v10}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/16 v7, 0x407

    new-instance v10, Lsj0;

    nop

    const/16 v7, 0x125

    invoke-virtual {v12}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v12

    const/16 v7, 0x24c

    new-instance v13, Loj0;

    nop

    const/4 v14, 0x0

    const/16 v7, 0x45e

    invoke-direct {v13, v14, v14}, Loj0;-><init>(IZ)V

    const/16 v7, 0x518

    iget-object v14, v9, Ltj0;->c:Lg8;

    nop

    const/16 v7, 0x40c

    iget-boolean v15, v9, Ltj0;->e:Z

    nop

    const/16 v7, 0x2a4

    move v0, v7

    move-object v1, v10

    move-object v2, v11

    move-object v3, v12

    move-object v4, v13

    move-object v5, v14

    move v6, v15

    invoke-direct/range {v1 .. v6}, Lsj0;-><init>(Landroid/content/Context;Ljava/lang/String;Loj0;Lg8;Z)V

    goto :goto_695

    :cond_66a
    const/4 v14, 0x0

    const/16 v7, 0x407

    new-instance v10, Lsj0;

    nop

    const/16 v7, 0x4be

    iget-object v12, v9, Ltj0;->b:Ljava/lang/String;

    nop

    const/16 v7, 0x24c

    new-instance v13, Loj0;

    nop

    const/16 v7, 0x45e

    invoke-direct {v13, v14, v14}, Loj0;-><init>(IZ)V

    const/16 v7, 0x518

    iget-object v14, v9, Ltj0;->c:Lg8;

    nop

    const/16 v7, 0x40c

    iget-boolean v15, v9, Ltj0;->e:Z

    nop

    const/16 v7, 0x2a4

    move v0, v7

    move-object v1, v10

    move-object v2, v11

    move-object v3, v12

    move-object v4, v13

    move-object v5, v14

    move v6, v15

    invoke-direct/range {v1 .. v6}, Lsj0;-><init>(Landroid/content/Context;Ljava/lang/String;Loj0;Lg8;Z)V

    :goto_695
    const/16 v7, 0x99b

    iget-boolean v9, v9, Ltj0;->g:Z

    nop

    const/16 v7, 0x7a5

    invoke-virtual {v10, v9}, Landroid/database/sqlite/SQLiteOpenHelper;->setWriteAheadLoggingEnabled(Z)V

    check-cast v10, Ljava/lang/Object;

    return-object v10

    :pswitch_6a2  #0x8
    check-cast v9, Lkc0;

    const/16 v7, 0x2b

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v9

    const/16 v7, 0x2a

    invoke-static {v9}, Lxl1;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v9

    check-cast v9, Ljava/lang/Object;

    return-object v9

    :pswitch_6b3  #0x7
    check-cast v9, Lec;

    const-string/jumbo v10, ":memory:"

    const/16 v7, 0xaf3

    invoke-virtual {v9, v10}, Lec;->open(Ljava/lang/String;)Lbx1;

    move-result-object v9

    check-cast v9, Ljava/lang/Object;

    return-object v9

    :pswitch_6c1  #0x6
    check-cast v9, Lwu;

    const/16 v7, 0x2b

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v9

    const/16 v7, 0x2a

    invoke-static {v9}, Lxl1;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v9

    check-cast v9, Ljava/lang/Object;

    return-object v9

    :pswitch_6d2  #0x5
    check-cast v9, Lsu;

    const/16 v7, 0x2b

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v9

    const/16 v7, 0x2a

    invoke-static {v9}, Lxl1;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v9

    check-cast v9, Ljava/lang/Object;

    return-object v9

    :pswitch_6e3  #0x4
    check-cast v9, Lut;

    const/16 v7, 0x96b

    invoke-virtual {v9}, Lut;->reportFullyDrawn()V

    const/16 v25, 0x0

    return-object v25

    :pswitch_6ed  #0x3
    check-cast v9, [Ljava/lang/Object;

    const/16 v7, 0x1050

    new-instance v10, Lk0;

    nop

    const/16 v7, 0xee4

    invoke-direct {v10, v9}, Lk0;-><init>([Ljava/lang/Object;)V

    check-cast v10, Ljava/lang/Object;

    return-object v10

    :pswitch_6fc  #0x2
    check-cast v9, Lrd;

    const/16 v7, 0x2b

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v9

    const/16 v7, 0x2a

    invoke-static {v9}, Lxl1;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v9

    check-cast v9, Ljava/lang/Object;

    return-object v9

    :pswitch_70d  #0x1
    check-cast v9, Lcom/tlsvpn/tlstunnel/App;

    const/16 v7, 0x7ad

    sget v10, Lcom/tlsvpn/tlstunnel/App;->c:I

    nop

    const/16 v7, 0x2a

    invoke-static {v9}, Lxl1;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v9

    check-cast v9, Ljava/lang/Object;

    return-object v9

    :pswitch_71d  #0x0
    check-cast v9, Lcom/tlsvpn/tlstunnel/ui/About;

    const/16 v7, 0x2b

    invoke-virtual {v9}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v9

    const/16 v7, 0x2a

    invoke-static {v9}, Lxl1;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v9

    check-cast v9, Ljava/lang/Object;

    return-object v9

    :pswitch_data_72e
    .packed-switch 0x0
        :pswitch_71d  #00000000
        :pswitch_70d  #00000001
        :pswitch_6fc  #00000002
        :pswitch_6ed  #00000003
        :pswitch_6e3  #00000004
        :pswitch_6d2  #00000005
        :pswitch_6c1  #00000006
        :pswitch_6b3  #00000007
        :pswitch_6a2  #00000008
        :pswitch_614  #00000009
        :pswitch_603  #0000000a
        :pswitch_5f2  #0000000b
        :pswitch_5e2  #0000000c
        :pswitch_5bf  #0000000d
        :pswitch_5ae  #0000000e
        :pswitch_51d  #0000000f
        :pswitch_50d  #00000010
        :pswitch_fa  #00000011
        :pswitch_f0  #00000012
        :pswitch_df  #00000013
        :pswitch_ce  #00000014
        :pswitch_bd  #00000015
        :pswitch_8e  #00000016
        :pswitch_7d  #00000017
        :pswitch_6d  #00000018
        :pswitch_5c  #00000019
        :pswitch_4b  #0000001a
        :pswitch_3b  #0000001b
        :pswitch_30  #0000001c
    .end packed-switch
.end method
