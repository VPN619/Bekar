.class public final synthetic Luj1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lvj1;


# direct methods
.method public synthetic constructor <init>(Lvj1;I)V
    .registers 5

    iput p2, p0, Luj1;->a:I

    iput-object p1, p0, Luj1;->b:Lvj1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 9

    .prologue
    const/16 v0, 0x6e4

    iget p1, p0, Luj1;->a:I

    nop

    const-string/jumbo v2, "close"

    const-string/jumbo v3, "keepalive"

    const-string/jumbo v4, "generatepayloadlayout"

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/16 v0, 0x85e

    iget-object p0, p0, Luj1;->b:Lvj1;

    nop

    packed-switch p1, :pswitch_data_134

    const/16 v0, 0x2f2

    invoke-virtual {p0}, Lvj1;->d()V

    return-void

    :pswitch_1e  #0x6
    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p1

    const-string/jumbo v2, "clipboard"

    const/16 v0, 0x31d

    invoke-virtual {p1, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p1, Landroid/content/ClipboardManager;

    const/16 v0, 0x4fc

    iget-object v2, p0, Lvj1;->I:Landroid/widget/EditText;

    nop

    if-eqz v2, :cond_63

    const/16 v0, 0x2d

    invoke-virtual {v2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v2

    const-string/jumbo v3, "Payload"

    const/16 v0, 0x703

    invoke-static {v3, v2}, Landroid/content/ClipData;->newPlainText(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;

    move-result-object v2

    const/16 v0, 0xba6

    invoke-virtual {p1, v2}, Landroid/content/ClipboardManager;->setPrimaryClip(Landroid/content/ClipData;)V

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p0

    const p1, 0x7f130097

    const/16 v0, 0x6d8

    invoke-static {p0, p1, v5}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object p0

    const/16 v0, 0x8f6

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    return-void

    :cond_63
    const-string/jumbo p0, "generatedpayload"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :pswitch_6b  #0x5
    const/16 v0, 0x3c9

    iget-object p1, p0, Lvj1;->u:Landroid/widget/LinearLayout;

    nop

    if-eqz p1, :cond_8c

    const/4 v0, -0x5

    invoke-virtual {p1, v5}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0x662

    iget-object p0, p0, Lvj1;->v:Landroid/widget/LinearLayout;

    nop

    if-eqz p0, :cond_84

    const/16 p1, 0x8

    const/4 v0, -0x5

    invoke-virtual {p0, p1}, Landroid/view/View;->setVisibility(I)V

    return-void

    :cond_84
    const-string/jumbo p0, "generatedpayloadlayout"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_8c
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :pswitch_91  #0x4
    const/16 v0, 0x4b4

    invoke-virtual {p0}, Lvj1;->c()V

    return-void

    :pswitch_97  #0x3
    const/16 v0, 0x3c9

    iget-object p1, p0, Lvj1;->u:Landroid/widget/LinearLayout;

    nop

    if-eqz p1, :cond_c2

    const/16 v0, 0x631

    invoke-virtual {p1}, Landroid/view/View;->getVisibility()I

    move-result p1

    if-nez p1, :cond_ac

    const/16 v0, 0x4b4

    invoke-virtual {p0}, Lvj1;->c()V

    goto :goto_c1

    :cond_ac
    const/16 v0, 0x3fb

    iget-object p1, p0, Lvj1;->r:Ljava/lang/String;

    nop

    const-string/jumbo v2, "pnull"

    const/16 v0, 0x84

    invoke-static {p1, v2}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_c1

    const/16 v0, 0x2f2

    invoke-virtual {p0}, Lvj1;->d()V

    :cond_c1
    :goto_c1
    return-void

    :cond_c2
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :pswitch_c7  #0x2
    const/16 v0, 0xea0

    new-instance p1, Lwj1;

    nop

    const/16 v0, 0x59e

    invoke-direct {p1}, Lwj1;-><init>()V

    const/16 v0, 0x8b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getParentFragmentManager()Landroidx/fragment/app/p;

    move-result-object v2

    const v3, 0x7f1301ed

    const/16 v0, 0x4c

    invoke-virtual {p0, v3}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x8c

    invoke-virtual {p1, v2, p0}, Landroidx/fragment/app/g;->show(Landroidx/fragment/app/p;Ljava/lang/String;)V

    return-void

    :pswitch_e6  #0x1
    const/16 v0, 0x32b

    iget-object p1, p0, Lvj1;->A:Landroid/widget/CheckBox;

    nop

    if-eqz p1, :cond_108

    const/16 v0, 0x36

    invoke-virtual {p1}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result p1

    if-eqz p1, :cond_107

    const/16 v0, 0x298

    iget-object p0, p0, Lvj1;->z:Landroid/widget/CheckBox;

    nop

    if-eqz p0, :cond_102

    const/16 v0, 0x7e

    invoke-virtual {p0, v5}, Landroid/widget/CompoundButton;->setChecked(Z)V

    goto :goto_107

    :cond_102
    const/4 v0, 0x5

    invoke-static {v3}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_107
    :goto_107
    return-void

    :cond_108
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :pswitch_10d  #0x0
    const/16 v0, 0x298

    iget-object p1, p0, Lvj1;->z:Landroid/widget/CheckBox;

    nop

    if-eqz p1, :cond_12f

    const/16 v0, 0x36

    invoke-virtual {p1}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result p1

    if-eqz p1, :cond_12e

    const/16 v0, 0x32b

    iget-object p0, p0, Lvj1;->A:Landroid/widget/CheckBox;

    nop

    if-eqz p0, :cond_129

    const/16 v0, 0x7e

    invoke-virtual {p0, v5}, Landroid/widget/CompoundButton;->setChecked(Z)V

    goto :goto_12e

    :cond_129
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_12e
    :goto_12e
    return-void

    :cond_12f
    const/4 v0, 0x5

    invoke-static {v3}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :pswitch_data_134
    .packed-switch 0x0
        :pswitch_10d  #00000000
        :pswitch_e6  #00000001
        :pswitch_c7  #00000002
        :pswitch_97  #00000003
        :pswitch_91  #00000004
        :pswitch_6b  #00000005
        :pswitch_1e  #00000006
    .end packed-switch
.end method
