.class public final Lin1;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public final synthetic t:I

.field public final synthetic u:Lnn1;


# direct methods
.method public synthetic constructor <init>(Lnn1;Lvx;I)V
    .registers 6

    iput p3, p0, Lin1;->t:I

    iput-object p1, p0, Lin1;->u:Lnn1;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 6

    .prologue
    const/16 v0, 0x1059

    iget p2, p0, Lin1;->t:I

    nop

    const/16 v0, 0xc1a

    iget-object p0, p0, Lin1;->u:Lnn1;

    nop

    packed-switch p2, :pswitch_data_46

    const/16 v0, 0x161

    new-instance p2, Lin1;

    nop

    const/4 v2, 0x3

    const/16 v0, 0x16a

    invoke-direct {p2, p0, p1, v2}, Lin1;-><init>(Lnn1;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_1b  #0x2
    const/16 v0, 0x161

    new-instance p2, Lin1;

    nop

    const/4 v2, 0x2

    const/16 v0, 0x16a

    invoke-direct {p2, p0, p1, v2}, Lin1;-><init>(Lnn1;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_29  #0x1
    const/16 v0, 0x161

    new-instance p2, Lin1;

    nop

    const/4 v2, 0x1

    const/16 v0, 0x16a

    invoke-direct {p2, p0, p1, v2}, Lin1;-><init>(Lnn1;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_37  #0x0
    const/16 v0, 0x161

    new-instance p2, Lin1;

    nop

    const/4 v2, 0x0

    const/16 v0, 0x16a

    invoke-direct {p2, p0, p1, v2}, Lin1;-><init>(Lnn1;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    nop

    :pswitch_data_46
    .packed-switch 0x0
        :pswitch_37  #00000000
        :pswitch_29  #00000001
        :pswitch_1b  #00000002
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7

    .prologue
    const/16 v0, 0x1059

    iget v2, p0, Lin1;->t:I

    nop

    const/16 v0, 0x21

    sget-object v3, Lrg2;->a:Lrg2;

    nop

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    packed-switch v2, :pswitch_data_52

    const/16 v0, 0x118

    invoke-virtual {p0, p2, p1}, Lin1;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lin1;

    const/16 v0, 0x127

    invoke-virtual {p0, v3}, Lin1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v3, Ljava/lang/Object;

    return-object v3

    :pswitch_21  #0x2
    const/16 v0, 0x118

    invoke-virtual {p0, p2, p1}, Lin1;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lin1;

    const/16 v0, 0x127

    invoke-virtual {p0, v3}, Lin1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v3, Ljava/lang/Object;

    return-object v3

    :pswitch_31  #0x1
    const/16 v0, 0x118

    invoke-virtual {p0, p2, p1}, Lin1;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lin1;

    const/16 v0, 0x127

    invoke-virtual {p0, v3}, Lin1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v3, Ljava/lang/Object;

    return-object v3

    :pswitch_41  #0x0
    const/16 v0, 0x118

    invoke-virtual {p0, p2, p1}, Lin1;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lin1;

    const/16 v0, 0x127

    invoke-virtual {p0, v3}, Lin1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v3, Ljava/lang/Object;

    return-object v3

    nop

    :pswitch_data_52
    .packed-switch 0x0
        :pswitch_41  #00000000
        :pswitch_31  #00000001
        :pswitch_21  #00000002
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 20

    .prologue
    const/16 v2, 0x1059

    move-object/from16 v0, p0

    iget v4, v0, Lin1;->t:I

    nop

    const-string/jumbo v5, "msginfo"

    const-string/jumbo v6, "rgplanos"

    const-string/jumbo v7, "assinartxt"

    const v8, 0x7f1300e2

    const-string/jumbo v9, "assinar"

    const-string/jumbo v10, "conteudo"

    const-string/jumbo v11, "progress"

    const/16 v2, 0x21

    sget-object v12, Lrg2;->a:Lrg2;

    nop

    const/4 v13, 0x1

    const/16 v2, 0xc1a

    move-object/from16 v0, p0

    iget-object v2, v0, Lin1;->u:Lnn1;

    move-object/16 p0, v2

    const/4 v14, 0x0

    const/16 v15, 0x8

    const/16 v16, 0x0

    packed-switch v4, :pswitch_data_30c

    const/4 v2, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v2, 0x101

    sget-boolean p1, Lmi2;->n:Z

    nop

    if-eqz p1, :cond_b9

    const/16 v2, 0x4f1

    sput-boolean v14, Lmi2;->n:Z

    const/16 v2, 0x8d7

    move-object/from16 v0, p0

    iget-object v2, v0, Lnn1;->q:Lw82;

    move-object/16 p1, v2

    const/16 v2, 0x177

    move-object/from16 v0, p1

    invoke-virtual {v0}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/content/SharedPreferences;

    const/4 v2, -0x6

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v2, 0x7a

    move-object/from16 v0, p1

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    const-string/jumbo v4, "pvdata"

    const-string/jumbo v17, ""

    const/16 v2, 0x3c

    move-object/from16 v0, p1

    move-object/from16 v1, v17

    invoke-interface {v0, v4, v1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v2, 0x6f

    move-object/from16 v0, p1

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/16 v2, 0x2b

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p1

    const/16 v2, 0x5b

    new-instance v4, Landroid/content/Intent;

    nop

    const-string/jumbo v17, "dipro"

    const/16 v2, 0x62

    move-object/from16 v0, v17

    invoke-direct {v4, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v2, 0x2b

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v17

    const/16 v2, 0x53

    move-object/from16 v0, v17

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v17

    const/16 v2, 0x4a

    move-object/from16 v0, v17

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v17

    const/16 v2, 0x64

    move-object/from16 v0, v17

    invoke-virtual {v4, v0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v4

    const/16 v2, 0x63

    move-object/from16 v0, p1

    invoke-virtual {v0, v4}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    :cond_b9
    const/16 v2, 0x12c

    move-object/from16 v0, p0

    iget-object v2, v0, Lnn1;->t:Landroid/widget/LinearLayout;

    move-object/16 p1, v2

    if-eqz p1, :cond_165

    const/4 v2, -0x5

    move-object/from16 v0, p1

    invoke-virtual {v0, v14}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0x17a

    move-object/from16 v0, p0

    iget-object v2, v0, Lnn1;->s:Landroid/widget/ProgressBar;

    move-object/16 p1, v2

    if-eqz p1, :cond_160

    const/4 v2, -0x5

    move-object/from16 v0, p1

    invoke-virtual {v0, v15}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0x251

    move-object/from16 v0, p0

    iget-object v2, v0, Lnn1;->u:Landroid/widget/TextView;

    move-object/16 p1, v2

    if-eqz p1, :cond_15b

    const v4, 0x7f130208

    const/16 v2, 0x93

    move-object/from16 v0, p1

    invoke-virtual {v0, v4}, Landroid/widget/TextView;->setText(I)V

    const/16 v2, 0x25e

    move-object/from16 v0, p0

    iget-object v2, v0, Lnn1;->x:Landroid/widget/RadioGroup;

    move-object/16 p1, v2

    if-eqz p1, :cond_156

    const/4 v2, -0x5

    move-object/from16 v0, p1

    invoke-virtual {v0, v15}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0xc2

    move-object/from16 v0, p0

    iget-object v2, v0, Lnn1;->v:Landroid/widget/LinearLayout;

    move-object/16 p1, v2

    if-eqz p1, :cond_151

    const/16 v2, 0xf7

    move-object/from16 v0, p1

    invoke-virtual {v0, v13}, Landroid/view/View;->setEnabled(Z)V

    const/16 v2, 0x1e4

    move-object/from16 v0, p0

    iget-object v2, v0, Lnn1;->w:Landroid/widget/TextView;

    move-object/16 p1, v2

    if-eqz p1, :cond_14c

    const/16 v2, 0x93

    move-object/from16 v0, p1

    invoke-virtual {v0, v8}, Landroid/widget/TextView;->setText(I)V

    const/16 v2, 0xc2

    move-object/from16 v0, p0

    iget-object v2, v0, Lnn1;->v:Landroid/widget/LinearLayout;

    move-object/16 p1, v2

    if-eqz p1, :cond_147

    const/16 v2, 0x1dd

    new-instance v4, Lgn1;

    nop

    const/4 v5, 0x3

    const/16 v2, 0x276

    move-object/from16 v0, p0

    invoke-direct {v4, v0, v5}, Lgn1;-><init>(Lnn1;I)V

    const/16 v2, 0x5f

    move-object/from16 v0, p1

    invoke-virtual {v0, v4}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    check-cast v12, Ljava/lang/Object;

    return-object v12

    :cond_147
    const/4 v2, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw v16

    :cond_14c
    const/4 v2, 0x5

    invoke-static {v7}, Lgt0;->F0(Ljava/lang/String;)V

    throw v16

    :cond_151
    const/4 v2, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw v16

    :cond_156
    const/4 v2, 0x5

    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw v16

    :cond_15b
    const/4 v2, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v16

    :cond_160
    const/4 v2, 0x5

    invoke-static {v11}, Lgt0;->F0(Ljava/lang/String;)V

    throw v16

    :cond_165
    const/4 v2, 0x5

    invoke-static {v10}, Lgt0;->F0(Ljava/lang/String;)V

    throw v16

    :pswitch_16a  #0x2
    const/4 v2, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v2, 0x17a

    move-object/from16 v0, p0

    iget-object v2, v0, Lnn1;->s:Landroid/widget/ProgressBar;

    move-object/16 p1, v2

    if-eqz p1, :cond_21c

    const/4 v2, -0x5

    move-object/from16 v0, p1

    invoke-virtual {v0, v15}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0x12c

    move-object/from16 v0, p0

    iget-object v2, v0, Lnn1;->t:Landroid/widget/LinearLayout;

    move-object/16 p1, v2

    if-eqz p1, :cond_217

    const/4 v2, -0x5

    move-object/from16 v0, p1

    invoke-virtual {v0, v14}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0x251

    move-object/from16 v0, p0

    iget-object v2, v0, Lnn1;->u:Landroid/widget/TextView;

    move-object/16 p1, v2

    if-eqz p1, :cond_212

    const v4, 0x7f130207

    const/16 v2, 0x93

    move-object/from16 v0, p1

    invoke-virtual {v0, v4}, Landroid/widget/TextView;->setText(I)V

    const/16 v2, 0x25e

    move-object/from16 v0, p0

    iget-object v2, v0, Lnn1;->x:Landroid/widget/RadioGroup;

    move-object/16 p1, v2

    if-eqz p1, :cond_20d

    const/4 v2, -0x5

    move-object/from16 v0, p1

    invoke-virtual {v0, v15}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0xc2

    move-object/from16 v0, p0

    iget-object v2, v0, Lnn1;->v:Landroid/widget/LinearLayout;

    move-object/16 p1, v2

    if-eqz p1, :cond_208

    const/16 v2, 0xf7

    move-object/from16 v0, p1

    invoke-virtual {v0, v13}, Landroid/view/View;->setEnabled(Z)V

    const/16 v2, 0x1e4

    move-object/from16 v0, p0

    iget-object v2, v0, Lnn1;->w:Landroid/widget/TextView;

    move-object/16 p1, v2

    if-eqz p1, :cond_203

    const/16 v2, 0x93

    move-object/from16 v0, p1

    invoke-virtual {v0, v8}, Landroid/widget/TextView;->setText(I)V

    const/16 v2, 0xc2

    move-object/from16 v0, p0

    iget-object v2, v0, Lnn1;->v:Landroid/widget/LinearLayout;

    move-object/16 p1, v2

    if-eqz p1, :cond_1fe

    const/16 v2, 0x1dd

    new-instance v4, Lgn1;

    nop

    const/4 v5, 0x2

    const/16 v2, 0x276

    move-object/from16 v0, p0

    invoke-direct {v4, v0, v5}, Lgn1;-><init>(Lnn1;I)V

    const/16 v2, 0x5f

    move-object/from16 v0, p1

    invoke-virtual {v0, v4}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    check-cast v12, Ljava/lang/Object;

    return-object v12

    :cond_1fe
    const/4 v2, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw v16

    :cond_203
    const/4 v2, 0x5

    invoke-static {v7}, Lgt0;->F0(Ljava/lang/String;)V

    throw v16

    :cond_208
    const/4 v2, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw v16

    :cond_20d
    const/4 v2, 0x5

    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw v16

    :cond_212
    const/4 v2, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v16

    :cond_217
    const/4 v2, 0x5

    invoke-static {v10}, Lgt0;->F0(Ljava/lang/String;)V

    throw v16

    :cond_21c
    const/4 v2, 0x5

    invoke-static {v11}, Lgt0;->F0(Ljava/lang/String;)V

    throw v16

    :pswitch_221  #0x1
    const/4 v2, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v2, 0x12c

    move-object/from16 v0, p0

    iget-object v2, v0, Lnn1;->t:Landroid/widget/LinearLayout;

    move-object/16 p1, v2

    if-eqz p1, :cond_2d2

    const/4 v2, -0x5

    move-object/from16 v0, p1

    invoke-virtual {v0, v14}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0x17a

    move-object/from16 v0, p0

    iget-object v2, v0, Lnn1;->s:Landroid/widget/ProgressBar;

    move-object/16 p1, v2

    if-eqz p1, :cond_2cd

    const/4 v2, -0x5

    move-object/from16 v0, p1

    invoke-virtual {v0, v15}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0x251

    move-object/from16 v0, p0

    iget-object v2, v0, Lnn1;->u:Landroid/widget/TextView;

    move-object/16 p1, v2

    if-eqz p1, :cond_2c8

    const v4, 0x7f13020e

    const/16 v2, 0x93

    move-object/from16 v0, p1

    invoke-virtual {v0, v4}, Landroid/widget/TextView;->setText(I)V

    const/16 v2, 0x25e

    move-object/from16 v0, p0

    iget-object v2, v0, Lnn1;->x:Landroid/widget/RadioGroup;

    move-object/16 p1, v2

    if-eqz p1, :cond_2c3

    const/4 v2, -0x5

    move-object/from16 v0, p1

    invoke-virtual {v0, v15}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0xc2

    move-object/from16 v0, p0

    iget-object v2, v0, Lnn1;->v:Landroid/widget/LinearLayout;

    move-object/16 p1, v2

    if-eqz p1, :cond_2be

    const/16 v2, 0xf7

    move-object/from16 v0, p1

    invoke-virtual {v0, v13}, Landroid/view/View;->setEnabled(Z)V

    const/16 v2, 0x1e4

    move-object/from16 v0, p0

    iget-object v2, v0, Lnn1;->w:Landroid/widget/TextView;

    move-object/16 p1, v2

    if-eqz p1, :cond_2b9

    const/16 v2, 0x93

    move-object/from16 v0, p1

    invoke-virtual {v0, v8}, Landroid/widget/TextView;->setText(I)V

    const/16 v2, 0xc2

    move-object/from16 v0, p0

    iget-object v2, v0, Lnn1;->v:Landroid/widget/LinearLayout;

    move-object/16 p1, v2

    if-eqz p1, :cond_2b4

    const/16 v2, 0x1dd

    new-instance v4, Lgn1;

    nop

    const/16 v2, 0x276

    move-object/from16 v0, p0

    invoke-direct {v4, v0, v13}, Lgn1;-><init>(Lnn1;I)V

    const/16 v2, 0x5f

    move-object/from16 v0, p1

    invoke-virtual {v0, v4}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    check-cast v12, Ljava/lang/Object;

    return-object v12

    :cond_2b4
    const/4 v2, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw v16

    :cond_2b9
    const/4 v2, 0x5

    invoke-static {v7}, Lgt0;->F0(Ljava/lang/String;)V

    throw v16

    :cond_2be
    const/4 v2, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw v16

    :cond_2c3
    const/4 v2, 0x5

    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw v16

    :cond_2c8
    const/4 v2, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v16

    :cond_2cd
    const/4 v2, 0x5

    invoke-static {v11}, Lgt0;->F0(Ljava/lang/String;)V

    throw v16

    :cond_2d2
    const/4 v2, 0x5

    invoke-static {v10}, Lgt0;->F0(Ljava/lang/String;)V

    throw v16

    :pswitch_2d7  #0x0
    const/4 v2, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v2, 0x12c

    move-object/from16 v0, p0

    iget-object v2, v0, Lnn1;->t:Landroid/widget/LinearLayout;

    move-object/16 p1, v2

    if-eqz p1, :cond_307

    const/4 v2, -0x5

    move-object/from16 v0, p1

    invoke-virtual {v0, v15}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0x17a

    move-object/from16 v0, p0

    iget-object v2, v0, Lnn1;->s:Landroid/widget/ProgressBar;

    move-object/16 p0, v2

    if-eqz p0, :cond_302

    const/4 v2, -0x5

    move-object/from16 v0, p0

    invoke-virtual {v0, v14}, Landroid/view/View;->setVisibility(I)V

    check-cast v12, Ljava/lang/Object;

    return-object v12

    :cond_302
    const/4 v2, 0x5

    invoke-static {v11}, Lgt0;->F0(Ljava/lang/String;)V

    throw v16

    :cond_307
    const/4 v2, 0x5

    invoke-static {v10}, Lgt0;->F0(Ljava/lang/String;)V

    throw v16

    :pswitch_data_30c
    .packed-switch 0x0
        :pswitch_2d7  #00000000
        :pswitch_221  #00000001
        :pswitch_16a  #00000002
    .end packed-switch
.end method
