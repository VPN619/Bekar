.class public abstract Lmi2;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static a:Z

.field public static final b:Ljava/util/concurrent/CopyOnWriteArrayList;

.field public static c:I

.field public static d:Z

.field public static e:Z

.field public static f:Z

.field public static g:I

.field public static h:Z

.field public static i:J

.field public static j:J

.field public static k:Z

.field public static l:Z

.field public static m:Ljava/lang/String;

.field public static n:Z

.field public static o:I

.field public static p:Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;

.field public static q:Lcom/tlsvpn/tlstunnel/MainActivity;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    const/16 v0, 0xd14

    new-instance v2, Ljava/util/concurrent/CopyOnWriteArrayList;

    nop

    const/16 v0, 0x7e3

    invoke-direct {v2}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    check-cast v2, Ljava/util/concurrent/CopyOnWriteArrayList;

    sput-object v2, Lmi2;->b:Ljava/util/concurrent/CopyOnWriteArrayList;

    const-wide/32 v2, 0x5265c00

    const/16 v0, 0x11a9

    sput-wide v2, Lmi2;->j:J

    const/4 v2, 0x1

    const/16 v0, 0x3f0

    sput-boolean v2, Lmi2;->k:Z

    const-string/jumbo v2, ""

    sput-object v2, Lmi2;->m:Ljava/lang/String;

    return-void
.end method

.method public static a(Ljava/lang/String;)Z
    .registers 4

    .prologue
    :try_start_0
    const/16 v0, 0x6d9

    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v2

    const/16 v0, 0x1189

    invoke-virtual {v2, p0}, Ljava/lang/Runtime;->exec(Ljava/lang/String;)Ljava/lang/Process;

    move-result-object p0

    const/16 v0, 0xd0f

    invoke-virtual {p0}, Ljava/lang/Process;->exitValue()I

    move-result p0
    :try_end_12
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_12} :catch_16

    if-nez p0, :cond_16

    const/4 p0, 0x1

    return p0

    :catch_16
    :cond_16
    const/4 p0, 0x0

    return p0
.end method

.method public static b(Ljava/lang/String;Lou;)Ljava/lang/String;
    .registers 15

    .prologue
    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x3b

    iget-object v2, p1, Lou;->i:Ljava/lang/String;

    nop

    const/16 v0, 0x7c

    invoke-static {v2}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_18

    const-string/jumbo v2, "localhost"

    :cond_18
    const/16 v0, 0x34a

    iget-object v3, p1, Lou;->g:Ljava/lang/String;

    nop

    const/16 v0, 0x7c

    invoke-static {v3}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_39

    const/16 v0, 0x34a

    iget-object v3, p1, Lou;->g:Ljava/lang/String;

    nop

    const/4 v4, 0x0

    const/4 v5, 0x2

    const/16 v0, 0x21c

    invoke-static {v3, v4, v5}, Lc72;->z0(Ljava/lang/CharSequence;II)Ljava/lang/CharSequence;

    move-result-object v3

    const/16 v0, 0xcb

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    goto :goto_3c

    :cond_39
    const-string/jumbo v3, "22"

    :goto_3c
    const/16 v0, 0x1e1

    iget-object v4, p1, Lou;->u:Ljava/lang/String;

    nop

    const/16 v0, 0x7c

    invoke-static {v4}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_4a

    move-object v4, v2

    :cond_4a
    const/16 v0, 0x1f4

    iget-object v5, p1, Lou;->v:Ljava/lang/String;

    nop

    const/16 v0, 0x7c

    invoke-static {v5}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v6

    if-eqz v6, :cond_58

    move-object v5, v3

    :cond_58
    const/16 v0, 0x3b

    iget-object v6, p1, Lou;->i:Ljava/lang/String;

    nop

    const/16 v0, 0x7c

    invoke-static {v6}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v6

    if-nez v6, :cond_72

    const/16 v0, 0x9d

    iget-boolean v6, p1, Lou;->h:Z

    nop

    if-eqz v6, :cond_72

    const/16 v0, 0x3b

    iget-object v6, p1, Lou;->i:Ljava/lang/String;

    nop

    goto :goto_73

    :cond_72
    move-object v6, v2

    :goto_73
    const/16 v0, 0x34b

    iget-object v7, p1, Lou;->j:Ljava/lang/String;

    nop

    const/16 v0, 0x7c

    invoke-static {v7}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v7

    if-nez v7, :cond_8d

    const/16 v0, 0x9d

    iget-boolean v7, p1, Lou;->h:Z

    nop

    if-eqz v7, :cond_8d

    const/16 v0, 0x34b

    iget-object p1, p1, Lou;->j:Ljava/lang/String;

    nop

    goto :goto_8e

    :cond_8d
    move-object p1, v3

    :goto_8e
    const-string/jumbo v7, "[crlf]"

    const-string/jumbo v8, "\r\n"

    const/4 v9, 0x1

    const/16 v0, 0x1a

    invoke-static {p0, v7, v8, v9}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p0

    const-string/jumbo v7, "[cr]"

    const-string/jumbo v8, "\r"

    const/16 v0, 0x1a

    invoke-static {p0, v7, v8, v9}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p0

    const-string/jumbo v7, "[lf]"

    const-string/jumbo v10, "\n"

    const/16 v0, 0x1a

    invoke-static {p0, v7, v10, v9}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p0

    const-string/jumbo v7, "[tab]"

    const-string/jumbo v11, "\t"

    const/16 v0, 0x1a

    invoke-static {p0, v7, v11, v9}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p0

    const-string/jumbo v7, "[host]"

    const/16 v0, 0x1a

    invoke-static {p0, v7, v2, v9}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p0

    const-string/jumbo v7, "[port]"

    const/16 v0, 0x1a

    invoke-static {p0, v7, v3, v9}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p0

    const/4 v0, -0x3

    new-instance v7, Ljava/lang/StringBuilder;

    nop

    const/16 v0, 0x97

    invoke-direct {v7, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v11, 0x3a

    const/16 v0, 0x1b

    invoke-virtual {v7, v11}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const-string/jumbo v12, "[host_port]"

    const/16 v0, 0x1a

    invoke-static {p0, v12, v7, v9}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p0

    const-string/jumbo v7, "[proxy_host]"

    const/16 v0, 0x1a

    invoke-static {p0, v7, v4, v9}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p0

    const-string/jumbo v7, "[proxy_port]"

    const/16 v0, 0x1a

    invoke-static {p0, v7, v5, v9}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p0

    const/4 v0, -0x3

    new-instance v7, Ljava/lang/StringBuilder;

    nop

    const/16 v0, 0x97

    invoke-direct {v7, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x1b

    invoke-virtual {v7, v11}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const-string/jumbo v12, "[proxy_host_port]"

    const/16 v0, 0x1a

    invoke-static {p0, v12, v7, v9}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p0

    const-string/jumbo v7, "[prxh]"

    const/16 v0, 0x1a

    invoke-static {p0, v7, v4, v9}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p0

    const-string/jumbo v7, "[prxp]"

    const/16 v0, 0x1a

    invoke-static {p0, v7, v5, v9}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p0

    const/4 v0, -0x3

    new-instance v7, Ljava/lang/StringBuilder;

    nop

    const/16 v0, 0x97

    invoke-direct {v7, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x1b

    invoke-virtual {v7, v11}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const-string/jumbo v5, "[prxhp]"

    const/16 v0, 0x1a

    invoke-static {p0, v5, v4, v9}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p0

    const-string/jumbo v4, "[ssh_host]"

    const/16 v0, 0x1a

    invoke-static {p0, v4, v6, v9}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p0

    const-string/jumbo v4, "[ssh_port]"

    const/16 v0, 0x1a

    invoke-static {p0, v4, p1, v9}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p0

    const/4 v0, -0x3

    new-instance v4, Ljava/lang/StringBuilder;

    nop

    const/16 v0, 0x97

    invoke-direct {v4, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x1b

    invoke-virtual {v4, v11}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const-string/jumbo v5, "[ssh_host_port]"

    const/16 v0, 0x1a

    invoke-static {p0, v5, v4, v9}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p0

    const-string/jumbo v4, "[sshh]"

    const/16 v0, 0x1a

    invoke-static {p0, v4, v6, v9}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p0

    const-string/jumbo v4, "[sshp]"

    const/16 v0, 0x1a

    invoke-static {p0, v4, p1, v9}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p0

    const/4 v0, -0x3

    new-instance v4, Ljava/lang/StringBuilder;

    nop

    const/16 v0, 0x97

    invoke-direct {v4, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x1b

    invoke-virtual {v4, v11}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string/jumbo v4, "[sshhp]"

    const/16 v0, 0x1a

    invoke-static {p0, v4, p1, v9}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p0

    const-string/jumbo p1, "[protocol]"

    const-string/jumbo v4, "HTTP/1.1"

    const/16 v0, 0x1a

    invoke-static {p0, p1, v4, v9}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p0

    const-string/jumbo p1, "[method]"

    const-string/jumbo v4, "GET"

    const/16 v0, 0x1a

    invoke-static {p0, p1, v4, v9}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p0

    const-string/jumbo p1, "[ua]"

    const-string/jumbo v4, "TLS Tunnel v8.1.0"

    const/16 v0, 0x1a

    invoke-static {p0, p1, v4, v9}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p0

    const-string/jumbo p1, "[delay_split]"

    const-string/jumbo v4, "[split]"

    const/16 v0, 0x1a

    invoke-static {p0, p1, v4, v9}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p0

    const-string/jumbo p1, "[instant_split]"

    const/16 v0, 0x1a

    invoke-static {p0, p1, v4, v9}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p0

    const-string/jumbo p1, "[netdata]"

    const-string/jumbo v4, "[raw]"

    const/16 v0, 0x1a

    invoke-static {p0, p1, v4, v9}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p0

    const/4 v0, -0x3

    new-instance p1, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v5, "CONNECT "

    const/16 v0, 0x97

    invoke-direct {p1, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v0, 0x0

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x1b

    invoke-virtual {p1, v11}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v2, " HTTP/1.1\r\n\r\n"

    const/4 v0, 0x0

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0x1a

    invoke-static {p0, v4, p1, v9}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p0

    const-string/jumbo p1, "[upws]"

    const-string/jumbo v2, "Upgrade: websocket"

    const/16 v0, 0x1a

    invoke-static {p0, p1, v2, v9}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p0

    const-string/jumbo p1, "\\n"

    const/16 v0, 0x1a

    invoke-static {p0, p1, v10, v9}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p0

    const-string/jumbo p1, "\\r"

    const/16 v0, 0x1a

    invoke-static {p0, p1, v8, v9}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    return-object p0
.end method

.method public static c(Z)Ljava/lang/String;
    .registers 5

    .prologue
    const/16 v0, 0xd54

    new-instance v2, Ljava/text/SimpleDateFormat;

    nop

    if-eqz p0, :cond_b

    const-string/jumbo p0, "yyyyMMddHH"

    goto :goto_e

    :cond_b
    const-string/jumbo p0, "yyyyMMdd"

    :goto_e
    const/16 v0, 0xaae

    sget-object v3, Ljava/util/Locale;->US:Ljava/util/Locale;

    nop

    const/16 v0, 0xc81

    invoke-direct {v2, p0, v3}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    const/16 v0, 0x1062

    new-instance p0, Ljava/util/Date;

    nop

    const/16 v0, 0x958

    invoke-direct {p0}, Ljava/util/Date;-><init>()V

    const/16 v0, 0xa9e

    invoke-virtual {v2, p0}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object p0

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p0, Ljava/lang/String;

    return-object p0
.end method

.method public static d(Landroid/content/SharedPreferences;)Z
    .registers 5

    .prologue
    const-string/jumbo v2, "nfslavailable"

    const/4 v3, 0x0

    const/16 v0, 0x77

    invoke-interface {p0, v2, v3}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v2

    if-nez v2, :cond_19

    const-string/jumbo v2, "nfplavailable"

    const/16 v0, 0x77

    invoke-interface {p0, v2, v3}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p0

    if-eqz p0, :cond_18

    goto :goto_19

    :cond_18
    return v3

    :cond_19
    :goto_19
    const/4 p0, 0x1

    return p0
.end method

.method public static e()Z
    .registers 1

    const/4 v0, 0x0

    return v0
.end method

.method public static f(Landroid/content/Context;)Z
    .registers 5

    .prologue
    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x5c3

    invoke-static {}, Lmi2;->e()Z

    move-result v2

    const/4 v3, 0x1

    if-nez v2, :cond_21

    :try_start_d
    const/16 v0, 0x1d2

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    const-string/jumbo v2, "development_settings_enabled"

    const/16 v0, 0x10db

    invoke-static {p0, v2}, Landroid/provider/Settings$Global;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;)I

    move-result p0
    :try_end_1c
    .catch Ljava/lang/Exception; {:try_start_d .. :try_end_1c} :catch_1f

    if-ne p0, v3, :cond_1f

    goto :goto_21

    :catch_1f
    :cond_1f
    const/4 p0, 0x0

    return p0

    :cond_21
    :goto_21
    return v3
.end method

.method public static g(Ljava/lang/String;)Ljava/lang/String;
    .registers 14

    .prologue
    const/16 v0, 0xfec

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v2

    const/16 v0, 0x65c

    invoke-virtual {v2}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/16 v0, 0x50b

    invoke-virtual {v2, v4, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v2

    const-string/jumbo v3, "STRRAND"

    const/16 v0, 0x1a

    invoke-static {p0, v3, v2, v4}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    const-wide/16 v5, 0x3e8

    div-long/2addr v2, v5

    const/16 v0, 0x107c

    invoke-static {v2, v3}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v2

    const-string/jumbo v3, "CHECKSUMAQUI"

    const-string/jumbo v5, ""

    const/16 v0, 0x1a

    invoke-static {p0, v3, v5, v4}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v6

    const-string/jumbo v7, "3gf5gScKszDhÇakfVsaPqkg1337"

    const/16 v0, 0x6ac

    invoke-static {v6, v2, v7}, Lrt2;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string/jumbo v7, "SHA-256"

    const/16 v0, 0x984

    invoke-static {v7}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v7

    const/16 v0, 0x2e4

    sget-object v8, Lip;->a:Ljava/nio/charset/Charset;

    nop

    const/16 v0, 0x2c

    invoke-virtual {v6, v8}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v6

    const/4 v0, -0x6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x85f

    invoke-virtual {v7, v6}, Ljava/security/MessageDigest;->digest([B)[B

    move-result-object v6

    const/4 v0, -0x6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, -0x3

    new-instance v7, Ljava/lang/StringBuilder;

    nop

    const/4 v0, -0x4

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v0, 0x155

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;

    array-length v8, v6

    move v9, v4

    move v10, v9

    :goto_77
    if-ge v9, v8, :cond_a5

    aget-byte v11, v6, v9

    const/4 v12, 0x1

    add-int/2addr v10, v12

    if-le v10, v12, :cond_84

    const/16 v0, 0x155

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;

    :cond_84
    const/16 v0, 0x113a

    invoke-static {v11}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v11

    filled-new-array {v11}, [Ljava/lang/Object;

    move-result-object v11

    const/16 v0, 0x120e

    invoke-static {v11, v12}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v11

    const-string/jumbo v12, "%02x"

    const/16 v0, 0x377

    invoke-static {v12, v11}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v11

    const/16 v0, 0x155

    invoke-virtual {v7, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;

    add-int/lit8 v9, v9, 0x1

    goto :goto_77

    :cond_a5
    const/16 v0, 0x155

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;)Ljava/lang/Appendable;

    const/4 v0, -0x2

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/16 v6, 0x10

    const/16 v0, 0x50b

    invoke-virtual {v5, v4, v6}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v5

    const/4 v0, -0x3

    new-instance v6, Ljava/lang/StringBuilder;

    nop

    const/4 v0, -0x4

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v0, 0x0

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v2, 0x7e

    const/16 v0, 0x1b

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/16 v0, 0x1a

    invoke-static {p0, v3, v2, v4}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    return-object p0
.end method
