.class public final synthetic Lud;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# instance fields
.field public final synthetic a:Lxd;

.field public final synthetic b:I

.field public final synthetic c:Lwd;


# direct methods
.method public synthetic constructor <init>(Lxd;ILwd;)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x8a1

    iput-object p1, p0, Lud;->a:Lxd;

    const/16 v0, 0x5a6

    iput p2, p0, Lud;->b:I

    const/16 v0, 0x11a7

    iput-object p3, p0, Lud;->c:Lwd;

    return-void
.end method


# virtual methods
.method public final onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .registers 9

    .prologue
    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xf22

    iget-object p1, p0, Lud;->a:Lxd;

    nop

    const/16 v0, 0x124c

    iget-object v2, p1, Lxd;->d:Ljava/util/ArrayList;

    nop

    const/16 v0, 0x9ba

    iget v3, p0, Lud;->b:I

    nop

    const/16 v0, 0x43

    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lsd;

    const/16 v0, 0xf7f

    iput-boolean p2, v2, Lsd;->b:Z

    const/16 v0, 0x6b5

    iget-object p1, p1, Lxd;->e:Landroid/content/SharedPreferences;

    nop

    const/16 v0, 0xc01

    sget-object v2, Lea0;->a:Lea0;

    nop

    const-string/jumbo v3, "checkedapps"

    const/16 v0, 0x514

    invoke-interface {p1, v3, v2}, Landroid/content/SharedPreferences;->getStringSet(Ljava/lang/String;Ljava/util/Set;)Ljava/util/Set;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v2, Ljava/lang/Iterable;

    const/16 v0, 0x167

    new-instance v4, Ljava/util/HashSet;

    nop

    const/16 v5, 0xc

    const/16 v0, 0x4bc

    invoke-static {v2, v5}, Lds;->Y(Ljava/lang/Iterable;I)I

    move-result v5

    const/16 v0, 0x856

    invoke-static {v5}, Lb61;->Q(I)I

    move-result v5

    const/16 v0, 0xf65

    invoke-direct {v4, v5}, Ljava/util/HashSet;-><init>(I)V

    const/16 v0, 0x118d

    invoke-static {v2, v4}, Lbs;->A0(Ljava/lang/Iterable;Ljava/util/AbstractCollection;)V

    const/16 v0, 0xb17

    iget-object p0, p0, Lud;->c:Lwd;

    nop

    const/16 v0, 0x777

    iget-object p0, p0, Lwd;->w:Landroid/widget/TextView;

    nop

    if-eqz p2, :cond_73

    const/16 v0, 0x275

    invoke-virtual {p0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object p0

    const/16 v0, 0xcb

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0xba2

    invoke-virtual {v4, p0}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    goto :goto_84

    :cond_73
    const/16 v0, 0x275

    invoke-virtual {p0}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object p0

    const/16 v0, 0xcb

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0xe62

    invoke-virtual {v4, p0}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    :goto_84
    const/16 v0, 0x7a

    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/16 v0, 0x123d

    invoke-interface {p0, v3, v4}, Landroid/content/SharedPreferences$Editor;->putStringSet(Ljava/lang/String;Ljava/util/Set;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x6f

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method
