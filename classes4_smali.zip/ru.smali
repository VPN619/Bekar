.class public final Lru;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/widget/AdapterView$OnItemSelectedListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 5

    iput p1, p0, Lru;->a:I

    iput-object p2, p0, Lru;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final a(Landroid/widget/AdapterView;)V
    .registers 4

    return-void
.end method

.method private final b(Landroid/widget/AdapterView;)V
    .registers 4

    return-void
.end method

.method private final c(Landroid/widget/AdapterView;)V
    .registers 4

    return-void
.end method

.method private final d(Landroid/widget/AdapterView;)V
    .registers 4

    return-void
.end method


# virtual methods
.method public final onItemSelected(Landroid/widget/AdapterView;Landroid/view/View;IJ)V
    .registers 11

    .prologue
    const/16 v0, 0x111a

    iget p1, p0, Lru;->a:I

    nop

    const/16 p2, 0x8

    const/4 p4, 0x1

    const/4 p5, 0x0

    const/4 v2, 0x0

    const/16 v0, 0xcac

    iget-object p0, p0, Lru;->b:Ljava/lang/Object;

    nop

    packed-switch p1, :pswitch_data_fa

    const/4 p1, -0x1

    if-eq p3, p1, :cond_23

    check-cast p0, Ly21;

    const/16 v0, 0xf92

    iget-object p0, p0, Ly21;->c:Ln60;

    nop

    if-eqz p0, :cond_23

    const/16 v0, 0x93d

    invoke-virtual {p0, v2}, Ln60;->setListSelectionHidden(Z)V

    :cond_23
    return-void

    :pswitch_24  #0x2
    check-cast p0, Landroidx/preference/DropDownPreference;

    if-ltz p3, :cond_4b

    const/16 v0, 0x691

    iget-object p1, p0, Landroidx/preference/ListPreference;->U:[Ljava/lang/CharSequence;

    nop

    aget-object p1, p1, p3

    const/16 v0, 0xffb

    invoke-interface {p1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0x939

    iget-object p2, p0, Landroidx/preference/ListPreference;->V:Ljava/lang/String;

    nop

    const/4 v0, -0x7

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_4b

    const/16 v0, 0x61a

    invoke-virtual {p0, p1}, Landroidx/preference/Preference;->a(Ljava/io/Serializable;)V

    const/16 v0, 0xa87

    invoke-virtual {p0, p1}, Landroidx/preference/ListPreference;->A(Ljava/lang/String;)V

    :cond_4b
    return-void

    :pswitch_4c  #0x1
    check-cast p0, Lwu;

    const/16 v0, 0x111

    invoke-virtual {p0}, Lwu;->c()Landroid/content/SharedPreferences;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x7a

    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    const-string/jumbo v3, "metodo"

    const/16 v0, 0x56

    invoke-interface {p1, v3, p3}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x6f

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    const-string/jumbo p1, "custommetodo"

    if-eqz p3, :cond_84

    if-eq p3, p4, :cond_73

    goto :goto_8f

    :cond_73
    const/16 v0, 0x456

    iget-object p0, p0, Lwu;->t:Landroid/widget/LinearLayout;

    nop

    if-eqz p0, :cond_7f

    const/4 v0, -0x5

    invoke-virtual {p0, v2}, Landroid/view/View;->setVisibility(I)V

    goto :goto_8f

    :cond_7f
    const/4 v0, 0x5

    invoke-static {p1}, Lgt0;->F0(Ljava/lang/String;)V

    throw p5

    :cond_84
    const/16 v0, 0x456

    iget-object p0, p0, Lwu;->t:Landroid/widget/LinearLayout;

    nop

    if-eqz p0, :cond_90

    const/4 v0, -0x5

    invoke-virtual {p0, p2}, Landroid/view/View;->setVisibility(I)V

    :goto_8f
    return-void

    :cond_90
    const/4 v0, 0x5

    invoke-static {p1}, Lgt0;->F0(Ljava/lang/String;)V

    throw p5

    :pswitch_95  #0x0
    check-cast p0, Lsu;

    const/16 v0, 0x720

    iget-boolean p1, p0, Lsu;->y:Z

    nop

    const-string/jumbo v3, "editcustomport"

    const-string/jumbo v4, "portsavailablelink"

    if-nez p1, :cond_d8

    const/16 v0, 0x502

    iget-object p1, p0, Lsu;->r:[Ljava/lang/String;

    nop

    if-eqz p1, :cond_d0

    array-length p1, p1

    sub-int/2addr p1, p4

    if-ne p3, p1, :cond_d8

    const/16 v0, 0x2c3

    iget-object p1, p0, Lsu;->t:Landroid/widget/TextView;

    nop

    if-eqz p1, :cond_cb

    const/4 v0, -0x5

    invoke-virtual {p1, v2}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0x2da

    iget-object p0, p0, Lsu;->v:Landroid/widget/EditText;

    nop

    if-eqz p0, :cond_c6

    const/4 v0, -0x5

    invoke-virtual {p0, v2}, Landroid/view/View;->setVisibility(I)V

    goto :goto_ee

    :cond_c6
    const/4 v0, 0x5

    invoke-static {v3}, Lgt0;->F0(Ljava/lang/String;)V

    throw p5

    :cond_cb
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw p5

    :cond_d0
    const-string/jumbo p0, "portas"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p5

    :cond_d8
    const/16 v0, 0x2c3

    iget-object p1, p0, Lsu;->t:Landroid/widget/TextView;

    nop

    if-eqz p1, :cond_f4

    const/4 v0, -0x5

    invoke-virtual {p1, p2}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0x2da

    iget-object p0, p0, Lsu;->v:Landroid/widget/EditText;

    nop

    if-eqz p0, :cond_ef

    const/4 v0, -0x5

    invoke-virtual {p0, p2}, Landroid/view/View;->setVisibility(I)V

    :goto_ee
    return-void

    :cond_ef
    const/4 v0, 0x5

    invoke-static {v3}, Lgt0;->F0(Ljava/lang/String;)V

    throw p5

    :cond_f4
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw p5

    nop

    :pswitch_data_fa
    .packed-switch 0x0
        :pswitch_95  #00000000
        :pswitch_4c  #00000001
        :pswitch_24  #00000002
    .end packed-switch
.end method

.method public final onNothingSelected(Landroid/widget/AdapterView;)V
    .registers 4

    const/4 v1, 0x0

    const/16 v0, 0x111a

    iget p0, p0, Lru;->a:I

    nop

    return-void
.end method
