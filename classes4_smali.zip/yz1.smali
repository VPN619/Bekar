.class public final Lyz1;
.super Lvb;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public A:Landroid/widget/TextView;

.field public B:Landroid/widget/ImageView;

.field public C:Ljava/lang/String;

.field public final q:Lw82;

.field public r:Landroidx/constraintlayout/widget/ConstraintLayout;

.field public s:Landroid/widget/ImageView;

.field public t:Landroid/widget/TextView;

.field public u:Landroid/widget/TextView;

.field public v:Ljava/lang/String;

.field public w:Landroid/view/View;

.field public x:Landroidx/constraintlayout/widget/ConstraintLayout;

.field public y:Landroid/widget/ImageView;

.field public z:Landroid/widget/TextView;


# direct methods
.method public constructor <init>()V
    .registers 5

    invoke-direct {p0}, Lvb;-><init>()V

    const/16 v0, 0x9ca

    new-instance v2, Lsz1;

    nop

    const/4 v3, 0x1

    const/16 v0, 0xf0b

    invoke-direct {v2, v3, p0}, Lsz1;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x27a

    new-instance v3, Lw82;

    nop

    const/16 v0, 0x215

    invoke-direct {v3, v2}, Lw82;-><init>(Lzj0;)V

    const/16 v0, 0xc10

    iput-object v3, p0, Lyz1;->q:Lw82;

    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/String;)V
    .registers 7

    const/16 v0, 0x5b

    new-instance v2, Landroid/content/Intent;

    nop

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v3

    const-class v4, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;

    const/16 v0, 0xd0

    invoke-direct {v2, v3, v4}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string/jumbo v3, "serverh"

    const/16 v0, 0x4b

    invoke-virtual {v2, v3, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v2

    const/16 v0, 0xc9

    invoke-virtual {v2, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    const/16 v0, 0x181

    invoke-virtual {p0}, Landroidx/fragment/app/g;->dismiss()V

    return-void
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .registers 6

    .prologue
    const/16 v0, 0x11c5

    invoke-super {p0, p1}, Landroidx/fragment/app/g;->onCreate(Landroid/os/Bundle;)V

    const/16 v0, 0xc2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getArguments()Landroid/os/Bundle;

    move-result-object p1

    if-eqz p1, :cond_31

    const-string/jumbo v2, "chost"

    const/16 v0, 0x183

    invoke-virtual {p1, v2}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const-string/jumbo v3, ""

    if-nez v2, :cond_1c

    move-object v2, v3

    :cond_1c
    const/16 v0, 0xe43

    iput-object v2, p0, Lyz1;->v:Ljava/lang/String;

    const-string/jumbo v2, "shost"

    const/16 v0, 0x183

    invoke-virtual {p1, v2}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    if-nez p1, :cond_2c

    goto :goto_2d

    :cond_2c
    move-object v3, p1

    :goto_2d
    const/16 v0, 0xb75

    iput-object v3, p0, Lyz1;->C:Ljava/lang/String;

    :cond_31
    return-void
.end method

.method public final onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .registers 21

    .prologue
    const/4 v4, -0x6

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const p3, 0x7f0c00cf

    const/4 v6, 0x0

    const/16 v4, 0x107b

    move-object/from16 v0, p1

    move/from16 v1, p3

    move-object/from16 v2, p2

    invoke-virtual {v0, v1, v2, v6}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    const p2, 0x7f0900b6

    const/16 v4, 0x11

    move-object/from16 v0, p1

    move/from16 v1, p2

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v4, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroidx/constraintlayout/widget/ConstraintLayout;

    const/16 v4, 0x10cf

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    iput-object v1, v0, Lyz1;->r:Landroidx/constraintlayout/widget/ConstraintLayout;

    const p2, 0x7f0900ba

    const/16 v4, 0x11

    move-object/from16 v0, p1

    move/from16 v1, p2

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v4, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/ImageView;

    const/16 v4, 0x993

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    iput-object v1, v0, Lyz1;->s:Landroid/widget/ImageView;

    const p2, 0x7f0900b8

    const/16 v4, 0x11

    move-object/from16 v0, p1

    move/from16 v1, p2

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v4, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/TextView;

    const/16 v4, 0x860

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    iput-object v1, v0, Lyz1;->t:Landroid/widget/TextView;

    const p2, 0x7f0900b9

    const/16 v4, 0x11

    move-object/from16 v0, p1

    move/from16 v1, p2

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v4, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/TextView;

    const/16 v4, 0x5c6

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    iput-object v1, v0, Lyz1;->u:Landroid/widget/TextView;

    const p2, 0x7f0900b4

    const/16 v4, 0x11

    move-object/from16 v0, p1

    move/from16 v1, p2

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v4, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/ImageView;

    const p2, 0x7f0900b7

    const/16 v4, 0x11

    move-object/from16 v0, p1

    move/from16 v1, p2

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v4, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v4, 0x54a

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    iput-object v1, v0, Lyz1;->w:Landroid/view/View;

    const/16 v4, 0x52b

    sget-object p2, Ldz;->a:Lcz;

    nop

    const/16 v4, 0x4cb

    move-object/from16 v0, p0

    iget-object v4, v0, Lyz1;->v:Ljava/lang/String;

    move-object/16 p2, v4

    const/16 p3, 0x0

    const-string/jumbo v7, "connectedServerHost"

    if-eqz p2, :cond_53d

    const/4 v8, 0x2

    const/16 v4, 0x196

    move-object/from16 v0, p2

    invoke-static {v8, v0}, Lc72;->G0(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/16 v4, 0x1f7

    sget-object v9, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    nop

    const/16 v4, 0x3b0

    move-object/from16 v0, p2

    invoke-virtual {v0, v9}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p2

    const/4 v4, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v4, 0x334

    move-object/from16 v0, p2

    invoke-static {v0}, Ldz;->a(Ljava/lang/String;)Lcz;

    move-result-object p2

    const/16 v4, 0x63a

    move-object/from16 v0, p0

    iget-object v10, v0, Lyz1;->s:Landroid/widget/ImageView;

    nop

    if-eqz v10, :cond_533

    const/16 v4, 0x3c6

    move-object/from16 v0, p2

    iget v11, v0, Lcz;->a:I

    nop

    const/16 v4, 0x87

    invoke-virtual {v10, v11}, Landroid/widget/ImageView;->setImageResource(I)V

    const/4 v4, -0x3

    new-instance v10, Ljava/lang/StringBuilder;

    nop

    const/16 v4, 0x4cb

    move-object/from16 v0, p0

    iget-object v11, v0, Lyz1;->v:Ljava/lang/String;

    nop

    if-eqz v11, :cond_52e

    const/4 v7, 0x3

    const/16 v4, 0x196

    invoke-static {v7, v11}, Lc72;->G0(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const/16 v4, 0x12d

    invoke-virtual {v11, v9}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v11

    const/4 v4, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v4, 0x97

    invoke-direct {v10, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string/jumbo v11, " ("

    const/4 v4, 0x0

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v12, 0x7f130090

    const/16 v4, 0x4c

    move-object/from16 v0, p0

    invoke-virtual {v0, v12}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v12

    const/4 v4, 0x0

    invoke-virtual {v10, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v12, 0x29

    const/16 v4, 0x1b

    invoke-virtual {v10, v12}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v4, -0x2

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    const/16 v4, 0xb12

    move-object/from16 v0, p0

    iget-object v13, v0, Lyz1;->t:Landroid/widget/TextView;

    nop

    if-eqz v13, :cond_524

    const/16 v4, 0x8a

    invoke-virtual {v13, v10}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v4, 0x7f9

    move-object/from16 v0, p0

    iget-object v10, v0, Lyz1;->u:Landroid/widget/TextView;

    nop

    if-eqz v10, :cond_51a

    const/16 v4, 0x36f

    move-object/from16 v0, p2

    iget v4, v0, Lcz;->b:I

    move/16 p2, v4

    const/16 v4, 0x93

    move/from16 v0, p2

    invoke-virtual {v10, v0}, Landroid/widget/TextView;->setText(I)V

    const/16 v4, 0xfdf

    move-object/from16 v0, p0

    iget-object v4, v0, Lyz1;->w:Landroid/view/View;

    move-object/16 p2, v4

    if-eqz p2, :cond_510

    const/16 v4, 0x22b

    sget-object v10, Lg4;->A:Lxu1;

    nop

    if-eqz v10, :cond_188

    move v10, v6

    goto :goto_18a

    :cond_188
    const/16 v10, 0x8

    :goto_18a
    const/4 v4, -0x5

    move-object/from16 v0, p2

    invoke-virtual {v0, v10}, Landroid/view/View;->setVisibility(I)V

    const/16 v4, 0x396

    move-object/from16 v0, p0

    iget-object v4, v0, Lyz1;->r:Landroidx/constraintlayout/widget/ConstraintLayout;

    move-object/16 p2, v4

    const-string/jumbo v10, "connectedServer"

    if-eqz p2, :cond_50b

    const/16 v4, 0x4f8

    new-instance v13, Lwz1;

    nop

    const/16 v4, 0x4ef

    move-object/from16 v0, p0

    invoke-direct {v13, v0, v6}, Lwz1;-><init>(Lyz1;I)V

    const/16 v4, 0x5f

    move-object/from16 v0, p2

    invoke-virtual {v0, v13}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v4, 0x396

    move-object/from16 v0, p0

    iget-object v4, v0, Lyz1;->r:Landroidx/constraintlayout/widget/ConstraintLayout;

    move-object/16 p2, v4

    if-eqz p2, :cond_506

    const/16 v4, 0x490

    new-instance v10, Lxz1;

    nop

    const/16 v4, 0x382

    move-object/from16 v0, p0

    invoke-direct {v10, v0, v6}, Lxz1;-><init>(Lvb;I)V

    const/16 v4, 0x8f

    move-object/from16 v0, p2

    invoke-virtual {v0, v10}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    const p2, 0x7f09030e

    const/16 v4, 0x11

    move-object/from16 v0, p1

    move/from16 v1, p2

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v4, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroidx/constraintlayout/widget/ConstraintLayout;

    const/16 v4, 0xe46

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    iput-object v1, v0, Lyz1;->x:Landroidx/constraintlayout/widget/ConstraintLayout;

    const p2, 0x7f090311

    const/16 v4, 0x11

    move-object/from16 v0, p1

    move/from16 v1, p2

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v4, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/ImageView;

    const/16 v4, 0x767

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    iput-object v1, v0, Lyz1;->y:Landroid/widget/ImageView;

    const p2, 0x7f09030f

    const/16 v4, 0x11

    move-object/from16 v0, p1

    move/from16 v1, p2

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v4, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/TextView;

    const/16 v4, 0xda6

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    iput-object v1, v0, Lyz1;->z:Landroid/widget/TextView;

    const p2, 0x7f090310

    const/16 v4, 0x11

    move-object/from16 v0, p1

    move/from16 v1, p2

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v4, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/TextView;

    const/16 v4, 0x70e

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    iput-object v1, v0, Lyz1;->A:Landroid/widget/TextView;

    const p2, 0x7f09030c

    const/16 v4, 0x11

    move-object/from16 v0, p1

    move/from16 v1, p2

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v4, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/ImageView;

    const/16 v4, 0xa6e

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    iput-object v1, v0, Lyz1;->B:Landroid/widget/ImageView;

    const/16 v4, 0x1f1

    move-object/from16 v0, p0

    iget-object v4, v0, Lyz1;->C:Ljava/lang/String;

    move-object/16 p2, v4

    const-string/jumbo v10, "selectedServerHost"

    if-eqz p2, :cond_501

    const/16 v4, 0x196

    move-object/from16 v0, p2

    invoke-static {v8, v0}, Lc72;->G0(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/16 v4, 0x3b0

    move-object/from16 v0, p2

    invoke-virtual {v0, v9}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p2

    const/4 v4, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v4, 0x334

    move-object/from16 v0, p2

    invoke-static {v0}, Ldz;->a(Ljava/lang/String;)Lcz;

    move-result-object p2

    const/16 v4, 0x101d

    move-object/from16 v0, p0

    iget-object v13, v0, Lyz1;->y:Landroid/widget/ImageView;

    nop

    if-eqz v13, :cond_4f7

    const/16 v4, 0x3c6

    move-object/from16 v0, p2

    iget v14, v0, Lcz;->a:I

    nop

    const/16 v4, 0x87

    invoke-virtual {v13, v14}, Landroid/widget/ImageView;->setImageResource(I)V

    const/4 v4, -0x3

    new-instance v13, Ljava/lang/StringBuilder;

    nop

    const/16 v4, 0x1f1

    move-object/from16 v0, p0

    iget-object v14, v0, Lyz1;->C:Ljava/lang/String;

    nop

    if-eqz v14, :cond_4f2

    const/16 v4, 0x196

    invoke-static {v7, v14}, Lc72;->G0(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const/16 v4, 0x12d

    invoke-virtual {v7, v9}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v7

    const/4 v4, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v4, 0x97

    invoke-direct {v13, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    invoke-virtual {v13, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v7, 0x7f130237

    const/16 v4, 0x4c

    move-object/from16 v0, p0

    invoke-virtual {v0, v7}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v7

    const/4 v4, 0x0

    invoke-virtual {v13, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v4, 0x1b

    invoke-virtual {v13, v12}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v4, -0x2

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const/16 v4, 0xa1f

    move-object/from16 v0, p0

    iget-object v9, v0, Lyz1;->z:Landroid/widget/TextView;

    nop

    if-eqz v9, :cond_4e8

    const/16 v4, 0x8a

    invoke-virtual {v9, v7}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v4, 0xab1

    move-object/from16 v0, p0

    iget-object v7, v0, Lyz1;->A:Landroid/widget/TextView;

    nop

    if-eqz v7, :cond_4de

    const/16 v4, 0x36f

    move-object/from16 v0, p2

    iget v4, v0, Lcz;->b:I

    move/16 p2, v4

    const/16 v4, 0x93

    move/from16 v0, p2

    invoke-virtual {v7, v0}, Landroid/widget/TextView;->setText(I)V

    const/16 v4, 0xd2

    move-object/from16 v0, p0

    iget-object v4, v0, Lyz1;->x:Landroidx/constraintlayout/widget/ConstraintLayout;

    move-object/16 p2, v4

    const-string/jumbo v7, "selectedServer"

    if-eqz p2, :cond_4d9

    const/16 v4, 0x4f8

    new-instance v9, Lwz1;

    nop

    const/4 v11, 0x1

    const/16 v4, 0x4ef

    move-object/from16 v0, p0

    invoke-direct {v9, v0, v11}, Lwz1;-><init>(Lyz1;I)V

    const/16 v4, 0x5f

    move-object/from16 v0, p2

    invoke-virtual {v0, v9}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v4, 0xd2

    move-object/from16 v0, p0

    iget-object v4, v0, Lyz1;->x:Landroidx/constraintlayout/widget/ConstraintLayout;

    move-object/16 p2, v4

    if-eqz p2, :cond_4d4

    const/16 v4, 0x490

    new-instance v9, Lxz1;

    nop

    const/16 v4, 0x382

    move-object/from16 v0, p0

    invoke-direct {v9, v0, v11}, Lxz1;-><init>(Lvb;I)V

    const/16 v4, 0x8f

    move-object/from16 v0, p2

    invoke-virtual {v0, v9}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    const/16 v4, 0x1198

    move-object/from16 v0, p0

    iget-object v4, v0, Lyz1;->q:Lw82;

    move-object/16 p2, v4

    const/16 v4, 0x177

    move-object/from16 v0, p2

    invoke-virtual {v0}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Landroid/content/SharedPreferences;

    const/4 v4, -0x3

    new-instance v12, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v13, "~bsr"

    const/16 v4, 0x97

    invoke-direct {v12, v13}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v4, 0x1f1

    move-object/from16 v0, p0

    iget-object v13, v0, Lyz1;->C:Ljava/lang/String;

    nop

    if-eqz v13, :cond_4cf

    const-string/jumbo v10, "."

    check-cast v10, Ljava/lang/String;

    filled-new-array {v10}, [Ljava/lang/String;

    move-result-object v10

    const/4 v14, 0x6

    const/16 v4, 0x89

    invoke-static {v13, v10, v14}, Lc72;->E0(Ljava/lang/CharSequence;[Ljava/lang/String;I)Ljava/util/List;

    move-result-object v10

    const/16 v4, 0x535

    invoke-static {v10}, Lbs;->k0(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    const/4 v4, 0x0

    invoke-virtual {v12, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v10, 0x78

    const/16 v4, 0x1b

    invoke-virtual {v12, v10}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v4, -0x2

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    const/16 v4, 0x511

    invoke-static {v10}, Lc72;->B0(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    const/16 v4, 0xcb

    invoke-virtual {v10}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v10

    const-string/jumbo v12, ""

    const/16 v4, 0x2e

    invoke-interface {v9, v10, v12}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const/4 v4, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v4, 0x511

    invoke-static {v9}, Lc72;->B0(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    const/16 v4, 0xcb

    invoke-virtual {v9}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v9

    const-string/jumbo v10, "~"

    check-cast v10, Ljava/lang/String;

    filled-new-array {v10}, [Ljava/lang/String;

    move-result-object v12

    const/16 v4, 0x89

    invoke-static {v9, v12, v14}, Lc72;->E0(Ljava/lang/CharSequence;[Ljava/lang/String;I)Ljava/util/List;

    move-result-object v12

    const/16 v4, 0x17d

    invoke-interface {v12}, Ljava/util/List;->size()I

    move-result v12

    if-ne v12, v8, :cond_4a0

    :try_start_3d3
    check-cast v10, Ljava/lang/String;

    filled-new-array {v10}, [Ljava/lang/String;

    move-result-object v8

    const/16 v4, 0x89

    invoke-static {v9, v8, v14}, Lc72;->E0(Ljava/lang/CharSequence;[Ljava/lang/String;I)Ljava/util/List;

    move-result-object v8

    const/16 v4, 0x24

    invoke-interface {v8, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    const/16 v4, 0x51d

    invoke-static {v8}, Lj72;->c0(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v8

    const-wide/16 v12, 0x0

    if-eqz v8, :cond_3f8

    const/16 v4, 0x417

    invoke-virtual {v8}, Ljava/lang/Long;->longValue()J

    move-result-wide v15

    goto :goto_3f9

    :cond_3f8
    move-wide v15, v12

    :goto_3f9
    check-cast v10, Ljava/lang/String;

    filled-new-array {v10}, [Ljava/lang/String;

    move-result-object v8

    const/16 v4, 0x89

    invoke-static {v9, v8, v14}, Lc72;->E0(Ljava/lang/CharSequence;[Ljava/lang/String;I)Ljava/util/List;

    move-result-object v8

    const/16 v4, 0x24

    invoke-interface {v8, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    const/16 v4, 0x51d

    invoke-static {v8}, Lj72;->c0(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v8

    if-eqz v8, :cond_41b

    const/16 v4, 0x417

    invoke-virtual {v8}, Ljava/lang/Long;->longValue()J

    move-result-wide v12

    :cond_41b
    cmp-long v8, v15, v12

    if-lez v8, :cond_4a0

    const/16 v4, 0xd2

    move-object/from16 v0, p0

    iget-object v8, v0, Lyz1;->x:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz v8, :cond_49b

    const/16 v4, 0xf7

    invoke-virtual {v8, v6}, Landroid/view/View;->setEnabled(Z)V

    const/16 v4, 0xd2

    move-object/from16 v0, p0

    iget-object v8, v0, Lyz1;->x:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz v8, :cond_496

    const/16 v4, 0xd8

    invoke-virtual {v8, v6}, Landroid/view/View;->setFocusable(Z)V

    const/16 v4, 0xd2

    move-object/from16 v0, p0

    iget-object v8, v0, Lyz1;->x:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz v8, :cond_491

    const/16 v4, 0xed

    invoke-virtual {v8, v6}, Landroid/view/View;->setClickable(Z)V

    const/16 v4, 0xd5

    new-instance v6, Landroid/util/TypedValue;

    nop

    const/16 v4, 0xe7

    invoke-direct {v6}, Landroid/util/TypedValue;-><init>()V

    const/16 v4, 0xfb

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object v7

    const/16 v4, 0x1a9

    invoke-virtual {v7}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v7

    const v8, 0x7f040116

    const/16 v4, 0x68

    invoke-virtual {v7, v8, v6, v11}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    const/16 v4, 0xc35

    move-object/from16 v0, p0

    iget-object v7, v0, Lyz1;->B:Landroid/widget/ImageView;

    nop

    if-eqz v7, :cond_489

    const/16 v4, 0x9b

    iget v4, v6, Landroid/util/TypedValue;->data:I

    move/16 p3, v4

    const/16 v4, 0x171

    move/from16 v0, p3

    invoke-static {v0}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object p3

    const/16 v4, 0x172

    move-object/from16 v0, p3

    invoke-virtual {v7, v0}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    goto :goto_4a0

    :cond_489
    const-string/jumbo v6, "selectedClock"

    const/4 v4, 0x5

    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_491
    const/4 v4, 0x5

    invoke-static {v7}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_496
    const/4 v4, 0x5

    invoke-static {v7}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_49b
    const/4 v4, 0x5

    invoke-static {v7}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3
    :try_end_4a0
    .catch Ljava/lang/Exception; {:try_start_3d3 .. :try_end_4a0} :catch_4a0

    :catch_4a0
    :cond_4a0
    :goto_4a0
    const/16 v4, 0x140

    sget-boolean p3, Lg4;->a:Z

    nop

    const/16 v4, 0xfb

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object p0

    const/4 v4, -0x6

    move-object/from16 v0, p0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v4, 0x177

    move-object/from16 v0, p2

    invoke-virtual {v0}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Landroid/content/SharedPreferences;

    const/4 v4, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v4, 0x394

    move-object/from16 v0, p2

    move-object/from16 v1, p0

    invoke-static {v0, v1}, Lg4;->n(Landroid/content/SharedPreferences;Landroidx/fragment/app/l;)V

    check-cast p1, Landroid/view/View;

    return-object p1

    :cond_4cf
    const/4 v4, 0x5

    invoke-static {v10}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_4d4
    const/4 v4, 0x5

    invoke-static {v7}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_4d9
    const/4 v4, 0x5

    invoke-static {v7}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_4de
    const-string/jumbo p0, "selectedServerName"

    const/4 v4, 0x5

    move-object/from16 v0, p0

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_4e8
    const-string/jumbo p0, "selectedServerIdStr"

    const/4 v4, 0x5

    move-object/from16 v0, p0

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_4f2
    const/4 v4, 0x5

    invoke-static {v10}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_4f7
    const-string/jumbo p0, "selectedSflag"

    const/4 v4, 0x5

    move-object/from16 v0, p0

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_501
    const/4 v4, 0x5

    invoke-static {v10}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_506
    const/4 v4, 0x5

    invoke-static {v10}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_50b
    const/4 v4, 0x5

    invoke-static {v10}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_510
    const-string/jumbo p0, "connectedServerRd"

    const/4 v4, 0x5

    move-object/from16 v0, p0

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_51a
    const-string/jumbo p0, "connectedServerName"

    const/4 v4, 0x5

    move-object/from16 v0, p0

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_524
    const-string/jumbo p0, "connectedServerIdStr"

    const/4 v4, 0x5

    move-object/from16 v0, p0

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_52e
    const/4 v4, 0x5

    invoke-static {v7}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_533
    const-string/jumbo p0, "connectedSflag"

    const/4 v4, 0x5

    move-object/from16 v0, p0

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_53d
    const/4 v4, 0x5

    invoke-static {v7}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3
.end method

.method public final onStart()V
    .registers 5

    .prologue
    const/16 v0, 0x55f

    invoke-super {p0}, Landroidx/fragment/app/g;->onStart()V

    const/16 v0, 0xaeb

    invoke-virtual {p0}, Landroidx/fragment/app/g;->getDialog()Landroid/app/Dialog;

    move-result-object p0

    if-eqz p0, :cond_34

    const/16 v0, 0xc8b

    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object p0

    if-eqz p0, :cond_34

    const/4 v2, -0x1

    const/4 v3, -0x2

    const/16 v0, 0x1132

    invoke-virtual {p0, v2, v3}, Landroid/view/Window;->setLayout(II)V

    const/16 v0, 0x10ad

    new-instance v2, Landroid/graphics/drawable/ColorDrawable;

    nop

    const/4 v3, 0x0

    const/16 v0, 0xc14

    invoke-direct {v2, v3}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    const/16 v0, 0xba3

    invoke-virtual {p0, v2}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    const v2, 0x7f140137

    const/16 v0, 0xa0d

    invoke-virtual {p0, v2}, Landroid/view/Window;->setWindowAnimations(I)V

    :cond_34
    return-void
.end method
