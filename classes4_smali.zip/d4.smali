.class public final Ld4;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lde;


# instance fields
.field public final synthetic a:Landroid/content/SharedPreferences;

.field public final synthetic b:Landroid/app/Activity;


# direct methods
.method public constructor <init>(Landroid/content/SharedPreferences;Landroid/app/Activity;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x87e

    iput-object p1, p0, Ld4;->a:Landroid/content/SharedPreferences;

    const/16 v0, 0xffc

    iput-object p2, p0, Ld4;->b:Landroid/app/Activity;

    return-void
.end method


# virtual methods
.method public final onAdDismissedFullScreenContent()V
    .registers 6

    .prologue
    const/16 v0, 0x140

    sget-boolean v2, Lg4;->a:Z

    nop

    const/16 v0, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    const/16 v0, 0x713

    sput-wide v2, Lg4;->i:J

    const/4 v2, 0x0

    const/16 v0, 0x881

    sput-boolean v2, Lg4;->j:Z

    const/4 v3, 0x0

    const/16 v0, 0x7aa

    sput-object v3, Lg4;->s:Lce;

    const/16 v0, 0xbaa

    iget-object v3, p0, Ld4;->a:Landroid/content/SharedPreferences;

    nop

    const/16 v0, 0xc7e

    invoke-static {v3}, Lg4;->b(Landroid/content/SharedPreferences;)V

    const/16 v0, 0xa8f

    iget-object p0, p0, Ld4;->b:Landroid/app/Activity;

    nop

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-wide/32 v3, 0xafc8

    const/16 v0, 0x3a0

    invoke-static {v3, v4, p0}, Lg4;->j(JLandroid/content/Context;)V

    const/16 v0, 0x154

    sget-object p0, Lg4;->m:Ljava/util/ArrayList;

    nop

    const/16 v0, 0xac

    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v3

    :goto_45
    if-ge v2, v3, :cond_57

    const/16 v0, 0x43

    invoke-virtual {p0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    add-int/lit8 v2, v2, 0x1

    check-cast v4, Lzj0;

    const/16 v0, 0xfe9

    invoke-interface {v4}, Lzj0;->invoke()Ljava/lang/Object;

    goto :goto_45

    :cond_57
    const/16 v0, 0x154

    sget-object p0, Lg4;->m:Ljava/util/ArrayList;

    nop

    const/16 v0, 0x15b

    invoke-virtual {p0}, Ljava/util/ArrayList;->clear()V

    return-void
.end method

.method public final onAdFailedToShowFullScreenContent(Lxj0;)V
    .registers 6

    .prologue
    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, -0x3

    new-instance v2, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v3, "Erro ao exibir AppOpen ("

    const/16 v0, 0x97

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0xad8

    iget v3, p1, Lxj0;->j:I

    nop

    const/16 v0, 0xbbf

    invoke-static {v3}, Lc33;->y(I)Ljava/lang/String;

    move-result-object v3

    const/4 v0, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v3, ": "

    const/4 v0, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0xf00

    iget-object p1, p1, Lxj0;->k:Ljava/lang/String;

    nop

    const/4 v0, 0x0

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 p1, 0x29

    const/16 v0, 0x1b

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string/jumbo v2, "Ads-Show"

    nop

    const/16 v0, 0x140

    sget-boolean p1, Lg4;->a:Z

    nop

    const/4 p1, 0x0

    const/16 v0, 0x881

    sput-boolean p1, Lg4;->j:Z

    const/4 v2, 0x0

    const/16 v0, 0x7aa

    sput-object v2, Lg4;->s:Lce;

    const/16 v0, 0xbaa

    iget-object v2, p0, Ld4;->a:Landroid/content/SharedPreferences;

    nop

    const/16 v0, 0xc7e

    invoke-static {v2}, Lg4;->b(Landroid/content/SharedPreferences;)V

    const/16 v0, 0xa8f

    iget-object p0, p0, Ld4;->b:Landroid/app/Activity;

    nop

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-wide/16 v2, 0xbb8

    const/16 v0, 0x3a0

    invoke-static {v2, v3, p0}, Lg4;->j(JLandroid/content/Context;)V

    const/16 v0, 0x154

    sget-object p0, Lg4;->m:Ljava/util/ArrayList;

    nop

    const/16 v0, 0xac

    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v2

    :goto_79
    if-ge p1, v2, :cond_8b

    const/16 v0, 0x43

    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    add-int/lit8 p1, p1, 0x1

    check-cast v3, Lzj0;

    const/16 v0, 0xfe9

    invoke-interface {v3}, Lzj0;->invoke()Ljava/lang/Object;

    goto :goto_79

    :cond_8b
    const/16 v0, 0x154

    sget-object p0, Lg4;->m:Ljava/util/ArrayList;

    nop

    const/16 v0, 0x15b

    invoke-virtual {p0}, Ljava/util/ArrayList;->clear()V

    return-void
.end method

.method public final onAdShowedFullScreenContent()V
    .registers 4

    const/16 v0, 0x140

    sget-boolean p0, Lg4;->a:Z

    nop

    const/4 p0, 0x1

    const/16 v0, 0x881

    sput-boolean p0, Lg4;->j:Z

    const-string/jumbo p0, "Ads-Show"

    const-string/jumbo v2, "O AppOpen foi exibido!"

    nop

    return-void
.end method
