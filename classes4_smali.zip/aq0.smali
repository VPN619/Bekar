.class public final synthetic Laq0;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lbq0;


# direct methods
.method public synthetic constructor <init>(Lbq0;I)V
    .registers 5

    iput p2, p0, Laq0;->a:I

    iput-object p1, p0, Laq0;->b:Lbq0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 6

    .prologue
    const/16 v0, 0xd55

    iget p1, p0, Laq0;->a:I

    nop

    const/16 v0, 0x61b

    iget-object p0, p0, Laq0;->b:Lbq0;

    nop

    packed-switch p1, :pswitch_data_84

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p1

    const/16 v0, 0x5b

    new-instance v2, Landroid/content/Intent;

    nop

    const-string/jumbo v3, "dialogRestaurar"

    const/16 v0, 0x62

    invoke-direct {v2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v3

    const/16 v0, 0x53

    invoke-virtual {v3}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    const/16 v0, 0x4a

    invoke-virtual {v3}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    const/16 v0, 0x64

    invoke-virtual {v2, v3}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v2

    const/16 v0, 0x63

    invoke-virtual {p1, v2}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    const/16 v0, 0x24a

    invoke-virtual {p0}, Lkk;->dismiss()V

    return-void

    :pswitch_43  #0x1
    const/16 v0, 0x5b

    new-instance p1, Landroid/content/Intent;

    nop

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v2

    const-class v3, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;

    const/16 v0, 0xd0

    invoke-direct {p1, v2, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/16 v0, 0x634

    invoke-virtual {p0, p1}, Landroidx/fragment/app/Fragment;->startActivity(Landroid/content/Intent;)V

    const/16 v0, 0x24a

    invoke-virtual {p0}, Lkk;->dismiss()V

    return-void

    :pswitch_60  #0x0
    const/16 v0, 0x787

    new-instance p1, Lkc0;

    nop

    const/16 v0, 0x117f

    invoke-direct {p1}, Lkc0;-><init>()V

    const/16 v0, 0x8b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getParentFragmentManager()Landroidx/fragment/app/p;

    move-result-object v2

    const v3, 0x7f1300d8

    const/16 v0, 0x4c

    invoke-virtual {p0, v3}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/16 v0, 0x8c

    invoke-virtual {p1, v2, v3}, Landroidx/fragment/app/g;->show(Landroidx/fragment/app/p;Ljava/lang/String;)V

    const/16 v0, 0x24a

    invoke-virtual {p0}, Lkk;->dismiss()V

    return-void

    :pswitch_data_84
    .packed-switch 0x0
        :pswitch_60  #00000000
        :pswitch_43  #00000001
    .end packed-switch
.end method
