.class public final Lkn0;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lir;
.implements Lyt;
.implements Lcom/google/android/gms/common/api/internal/RemoteCall;
.implements Lcom/google/android/gms/internal/consent_sdk/zzqp;
.implements Lk4;
.implements Lml1;
.implements Lua0;
.implements Lxn1;


# static fields
.field public static final b:Lkn0;

.field public static final c:Lkn0;

.field public static final d:Lkn0;

.field public static final e:Lkn0;

.field public static final f:Lkn0;

.field public static final g:Lkn0;

.field public static final h:Lkn0;

.field public static final i:Lkn0;

.field public static final j:Lkn0;

.field public static final k:Lkn0;

.field public static final l:Lkn0;

.field public static final m:Lkn0;

.field public static final n:Lkn0;

.field public static final o:Lkn0;

.field public static final p:Lkn0;

.field public static final q:Lkn0;

.field public static r:Lkn0;

.field public static s:Z


# instance fields
.field public final synthetic a:I


# direct methods
.method static synthetic constructor <clinit>()V
    .registers 2

    new-instance v0, Lkn0;

    const/4 v1, 0x1

    invoke-direct {v0, v1}, Lkn0;-><init>(I)V

    sput-object v0, Lkn0;->b:Lkn0;

    new-instance v0, Lkn0;

    const/4 v1, 0x2

    invoke-direct {v0, v1}, Lkn0;-><init>(I)V

    sput-object v0, Lkn0;->c:Lkn0;

    new-instance v0, Lkn0;

    const/4 v1, 0x3

    invoke-direct {v0, v1}, Lkn0;-><init>(I)V

    sput-object v0, Lkn0;->d:Lkn0;

    new-instance v0, Lkn0;

    const/4 v1, 0x4

    invoke-direct {v0, v1}, Lkn0;-><init>(I)V

    sput-object v0, Lkn0;->e:Lkn0;

    new-instance v0, Lkn0;

    const/4 v1, 0x5

    invoke-direct {v0, v1}, Lkn0;-><init>(I)V

    sput-object v0, Lkn0;->f:Lkn0;

    new-instance v0, Lkn0;

    const/4 v1, 0x6

    invoke-direct {v0, v1}, Lkn0;-><init>(I)V

    sput-object v0, Lkn0;->g:Lkn0;

    new-instance v0, Lkn0;

    const/4 v1, 0x7

    invoke-direct {v0, v1}, Lkn0;-><init>(I)V

    sput-object v0, Lkn0;->h:Lkn0;

    new-instance v0, Lkn0;

    const/16 v1, 0x8

    invoke-direct {v0, v1}, Lkn0;-><init>(I)V

    sput-object v0, Lkn0;->i:Lkn0;

    new-instance v0, Lkn0;

    const/16 v1, 0x9

    invoke-direct {v0, v1}, Lkn0;-><init>(I)V

    sput-object v0, Lkn0;->j:Lkn0;

    new-instance v0, Lkn0;

    const/16 v1, 0xa

    invoke-direct {v0, v1}, Lkn0;-><init>(I)V

    sput-object v0, Lkn0;->k:Lkn0;

    new-instance v0, Lkn0;

    const/16 v1, 0xb

    invoke-direct {v0, v1}, Lkn0;-><init>(I)V

    sput-object v0, Lkn0;->l:Lkn0;

    new-instance v0, Lkn0;

    const/16 v1, 0xc

    invoke-direct {v0, v1}, Lkn0;-><init>(I)V

    sput-object v0, Lkn0;->m:Lkn0;

    new-instance v0, Lkn0;

    const/16 v1, 0xd

    invoke-direct {v0, v1}, Lkn0;-><init>(I)V

    sput-object v0, Lkn0;->n:Lkn0;

    new-instance v0, Lkn0;

    const/16 v1, 0xe

    invoke-direct {v0, v1}, Lkn0;-><init>(I)V

    sput-object v0, Lkn0;->o:Lkn0;

    new-instance v0, Lkn0;

    const/16 v1, 0xf

    invoke-direct {v0, v1}, Lkn0;-><init>(I)V

    sput-object v0, Lkn0;->p:Lkn0;

    new-instance v0, Lkn0;

    const/16 v1, 0x10

    invoke-direct {v0, v1}, Lkn0;-><init>(I)V

    sput-object v0, Lkn0;->q:Lkn0;

    return-void
.end method

.method public synthetic constructor <init>(I)V
    .registers 2

    iput p1, p0, Lkn0;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static e(Ljava/lang/String;)Lxl;
    .registers 16

    .prologue
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v1, Los2;->a:[B

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    :goto_9
    const/16 v2, 0x9

    const/16 v3, 0x20

    const/16 v4, 0xd

    const/16 v5, 0xa

    if-lez v1, :cond_29

    add-int/lit8 v6, v1, -0x1

    invoke-virtual {p0, v6}, Ljava/lang/String;->charAt(I)C

    move-result v6

    const/16 v7, 0x3d

    if-eq v6, v7, :cond_26

    if-eq v6, v5, :cond_26

    if-eq v6, v4, :cond_26

    if-eq v6, v3, :cond_26

    if-eq v6, v2, :cond_26

    goto :goto_29

    :cond_26
    add-int/lit8 v1, v1, -0x1

    goto :goto_9

    :cond_29
    :goto_29
    int-to-long v6, v1

    const-wide/16 v8, 0x6

    mul-long/2addr v6, v8

    const-wide/16 v8, 0x8

    div-long/2addr v6, v8

    long-to-int v6, v6

    new-array v7, v6, [B

    const/4 v8, 0x0

    move v9, v8

    move v10, v9

    move v11, v10

    :goto_37
    const/4 v12, 0x0

    if-ge v8, v1, :cond_a0

    invoke-virtual {p0, v8}, Ljava/lang/String;->charAt(I)C

    move-result v13

    const/16 v14, 0x41

    if-gt v14, v13, :cond_49

    const/16 v14, 0x5b

    if-ge v13, v14, :cond_49

    add-int/lit8 v13, v13, -0x41

    goto :goto_81

    :cond_49
    const/16 v14, 0x61

    if-gt v14, v13, :cond_54

    const/16 v14, 0x7b

    if-ge v13, v14, :cond_54

    add-int/lit8 v13, v13, -0x47

    goto :goto_81

    :cond_54
    const/16 v14, 0x30

    if-gt v14, v13, :cond_5f

    const/16 v14, 0x3a

    if-ge v13, v14, :cond_5f

    add-int/lit8 v13, v13, 0x4

    goto :goto_81

    :cond_5f
    const/16 v14, 0x2b

    if-eq v13, v14, :cond_7f

    const/16 v14, 0x2d

    if-ne v13, v14, :cond_68

    goto :goto_7f

    :cond_68
    const/16 v14, 0x2f

    if-eq v13, v14, :cond_7c

    const/16 v14, 0x5f

    if-ne v13, v14, :cond_71

    goto :goto_7c

    :cond_71
    if-eq v13, v5, :cond_9d

    if-eq v13, v4, :cond_9d

    if-eq v13, v3, :cond_9d

    if-ne v13, v2, :cond_7a

    goto :goto_9d

    :cond_7a
    move-object v7, v12

    goto :goto_ce

    :cond_7c
    :goto_7c
    const/16 v13, 0x3f

    goto :goto_81

    :cond_7f
    :goto_7f
    const/16 v13, 0x3e

    :goto_81
    shl-int/lit8 v10, v10, 0x6

    or-int/2addr v10, v13

    add-int/lit8 v9, v9, 0x1

    rem-int/lit8 v12, v9, 0x4

    if-nez v12, :cond_9d

    add-int/lit8 v12, v11, 0x1

    shr-int/lit8 v13, v10, 0x10

    int-to-byte v13, v13

    aput-byte v13, v7, v11

    add-int/lit8 v13, v11, 0x2

    shr-int/lit8 v14, v10, 0x8

    int-to-byte v14, v14

    aput-byte v14, v7, v12

    add-int/lit8 v11, v11, 0x3

    int-to-byte v12, v10

    aput-byte v12, v7, v13

    :cond_9d
    :goto_9d
    add-int/lit8 v8, v8, 0x1

    goto :goto_37

    :cond_a0
    rem-int/lit8 v9, v9, 0x4

    const/4 p0, 0x1

    if-eq v9, p0, :cond_7a

    const/4 p0, 0x2

    if-eq v9, p0, :cond_bd

    const/4 p0, 0x3

    if-eq v9, p0, :cond_ac

    goto :goto_c7

    :cond_ac
    shl-int/lit8 p0, v10, 0x6

    add-int/lit8 v1, v11, 0x1

    shr-int/lit8 v2, p0, 0x10

    int-to-byte v2, v2

    aput-byte v2, v7, v11

    add-int/lit8 v11, v11, 0x2

    shr-int/lit8 p0, p0, 0x8

    int-to-byte p0, p0

    aput-byte p0, v7, v1

    goto :goto_c7

    :cond_bd
    shl-int/lit8 p0, v10, 0xc

    add-int/lit8 v1, v11, 0x1

    shr-int/lit8 p0, p0, 0x10

    int-to-byte p0, p0

    aput-byte p0, v7, v11

    move v11, v1

    :goto_c7
    if-ne v11, v6, :cond_ca

    goto :goto_ce

    :cond_ca
    invoke-static {v7, v11}, Ljava/util/Arrays;->copyOf([BI)[B

    move-result-object v7

    :goto_ce
    if-eqz v7, :cond_d6

    new-instance p0, Lxl;

    invoke-direct {p0, v7}, Lxl;-><init>([B)V

    return-object p0

    :cond_d6
    return-object v12
.end method

.method public static i(Ljava/lang/String;)Lxl;
    .registers 6

    .prologue
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    rem-int/lit8 v0, v0, 0x2

    if-nez v0, :cond_36

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    div-int/lit8 v0, v0, 0x2

    new-array v1, v0, [B

    const/4 v2, 0x0

    :goto_11
    if-ge v2, v0, :cond_30

    mul-int/lit8 v3, v2, 0x2

    invoke-virtual {p0, v3}, Ljava/lang/String;->charAt(I)C

    move-result v4

    invoke-static {v4}, Lnp3;->D(C)I

    move-result v4

    shl-int/lit8 v4, v4, 0x4

    add-int/lit8 v3, v3, 0x1

    invoke-virtual {p0, v3}, Ljava/lang/String;->charAt(I)C

    move-result v3

    invoke-static {v3}, Lnp3;->D(C)I

    move-result v3

    add-int/2addr v3, v4

    int-to-byte v3, v3

    aput-byte v3, v1, v2

    add-int/lit8 v2, v2, 0x1

    goto :goto_11

    :cond_30
    new-instance p0, Lxl;

    invoke-direct {p0, v1}, Lxl;-><init>([B)V

    return-object p0

    :cond_36
    const-string/jumbo v0, "Unexpected hex string: "

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->v(Ljava/lang/Object;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public static j(Ljava/lang/String;)Lxl;
    .registers 3

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v0, Lxl;

    sget-object v1, Lip;->a:Ljava/nio/charset/Charset;

    invoke-virtual {p0, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {v0, v1}, Lxl;-><init>([B)V

    iput-object p0, v0, Lxl;->c:Ljava/lang/String;

    return-object v0
.end method

.method public static k([B)Lxl;
    .registers 9

    sget-object v0, Lxl;->d:Lxl;

    array-length v0, p0

    array-length v1, p0

    int-to-long v2, v1

    const-wide/16 v4, 0x0

    int-to-long v6, v0

    invoke-static/range {v2 .. v7}, Lpy2;->l(JJJ)V

    new-instance v1, Lxl;

    const/4 v2, 0x0

    invoke-static {p0, v2, v0}, Laf;->g0([BII)[B

    move-result-object p0

    invoke-direct {v1, p0}, Lxl;-><init>([B)V

    return-object v1
.end method

.method public static l(Landroid/os/Bundle;)V
    .registers 3

    .prologue
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string/jumbo v0, "enable_multiple_ads_per_unit"

    invoke-virtual {p0, v0}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v1

    if-eqz v1, :cond_1c

    invoke-virtual {p0, v0}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const-string/jumbo v0, "true"

    invoke-static {p0, v0}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_1c

    const/4 p0, 0x1

    sput-boolean p0, Lkn0;->s:Z

    :cond_1c
    return-void
.end method

.method public static n()Z
    .registers 7

    .prologue
    const/4 v0, 0x1

    const/4 v1, 0x0

    :try_start_2
    const-string/jumbo v2, "com.google.android.gms.ads.internal.adaptersettings.AdapterSettings"

    invoke-static {v2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v2

    const-string/jumbo v3, "getInstance"

    const/4 v4, 0x0

    invoke-virtual {v2, v3, v4}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    invoke-virtual {v2, v4, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    const-string/jumbo v4, "getBoolean"

    const-class v5, Ljava/lang/String;

    sget-object v6, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    filled-new-array {v5, v6}, [Ljava/lang/Class;

    move-result-object v5

    invoke-virtual {v3, v4, v5}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    const-string/jumbo v4, "adapter:mintegral_android_restrict_multiple_ads"

    sget-object v5, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    filled-new-array {v4, v5}, [Ljava/lang/Object;

    move-result-object v4

    invoke-virtual {v3, v2, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v2, Ljava/lang/Boolean;

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2
    :try_end_44
    .catch Ljava/lang/ClassNotFoundException; {:try_start_2 .. :try_end_44} :catch_45
    .catch Ljava/lang/NoSuchMethodException; {:try_start_2 .. :try_end_44} :catch_45
    .catch Ljava/lang/IllegalAccessException; {:try_start_2 .. :try_end_44} :catch_45
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_2 .. :try_end_44} :catch_45
    .catch Ljava/lang/NullPointerException; {:try_start_2 .. :try_end_44} :catch_45

    goto :goto_46

    :catch_45
    move v2, v1

    :goto_46
    if-nez v2, :cond_4e

    sget-boolean v2, Lkn0;->s:Z

    if-eqz v2, :cond_4d

    goto :goto_4e

    :cond_4d
    move v0, v1

    :cond_4e
    :goto_4e
    return v0
.end method


# virtual methods
.method public a(Ljava/io/Closeable;Ljava/lang/Throwable;Ljava/lang/Throwable;)V
    .registers 6

    sget-object p0, Lfr;->a:Ljava/util/logging/Logger;

    sget-object p2, Ljava/util/logging/Level;->WARNING:Ljava/util/logging/Level;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string/jumbo v1, "Suppressing exception thrown when closing "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p2, p1, p3}, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V

    return-void
.end method

.method public accept(Ljava/lang/Object;Ljava/lang/Object;)V
    .registers 3

    check-cast p1, Lcom/google/android/gms/internal/location/zzaz;

    check-cast p2, Lcom/google/android/gms/tasks/TaskCompletionSource;

    invoke-virtual {p1}, Lcom/google/android/gms/internal/location/zzaz;->zzA()Lcom/google/android/gms/location/LocationAvailability;

    move-result-object p0

    invoke-virtual {p2, p0}, Lcom/google/android/gms/tasks/TaskCompletionSource;->setResult(Ljava/lang/Object;)V

    return-void
.end method

.method public b()V
    .registers 1

    return-void
.end method

.method public c(Landroid/content/Context;Ljava/lang/String;Landroidx/work/WorkerParameters;)Lj31;
    .registers 7

    .prologue
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_6
    invoke-static {p2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const-class v1, Lj31;

    invoke-virtual {v0, v1}, Ljava/lang/Class;->asSubclass(Ljava/lang/Class;)Ljava/lang/Class;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_13
    .catchall {:try_start_6 .. :try_end_13} :catchall_59

    :try_start_13
    const-class v1, Landroid/content/Context;

    const-class v2, Landroidx/work/WorkerParameters;

    filled-new-array {v1, v2}, [Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v0

    filled-new-array {p1, p3}, [Ljava/lang/Object;

    move-result-object p1

    invoke-virtual {v0, p1}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p1, Lj31;
    :try_end_2c
    .catchall {:try_start_13 .. :try_end_2c} :catchall_47

    iget-boolean p3, p1, Lj31;->d:Z

    if-nez p3, :cond_31

    return-object p1

    :cond_31
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    const-string/jumbo p1, ") returned an instance of a ListenableWorker ("

    const-string/jumbo p3, ") which has already been invoked. createWorker() must always return a new instance of a ListenableWorker."

    const-string/jumbo v0, "WorkerFactory ("

    invoke-static {v0, p0, p1, p2, p3}, Ldm2;->o(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 p0, 0x0

    return-object p0

    :catchall_47
    move-exception p0

    invoke-static {}, Lj41;->e()Lj41;

    move-result-object p1

    sget-object p3, Ldr2;->a:Ljava/lang/String;

    const-string/jumbo v0, "Could not instantiate "

    invoke-virtual {v0, p2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p3, p2, p0}, Lj41;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    throw p0

    :catchall_59
    move-exception p0

    invoke-static {}, Lj41;->e()Lj41;

    move-result-object p1

    sget-object p3, Ldr2;->a:Ljava/lang/String;

    const-string/jumbo v0, "Invalid class: "

    invoke-virtual {v0, p2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-virtual {p1, p3, p2, p0}, Lj41;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    throw p0
.end method

.method public d(ILjava/lang/Object;)V
    .registers 3

    return-void
.end method

.method public f(Ljava/lang/String;Ljava/security/Provider;)Ljava/lang/Object;
    .registers 3

    .prologue
    iget p0, p0, Lkn0;->a:I

    packed-switch p0, :pswitch_data_1e

    if-nez p2, :cond_c

    invoke-static {p1}, Ljava/security/Signature;->getInstance(Ljava/lang/String;)Ljava/security/Signature;

    move-result-object p0

    goto :goto_10

    :cond_c
    invoke-static {p1, p2}, Ljava/security/Signature;->getInstance(Ljava/lang/String;Ljava/security/Provider;)Ljava/security/Signature;

    move-result-object p0

    :goto_10
    return-object p0

    :pswitch_11  #0x17
    if-nez p2, :cond_18

    invoke-static {p1}, Ljavax/crypto/KeyAgreement;->getInstance(Ljava/lang/String;)Ljavax/crypto/KeyAgreement;

    move-result-object p0

    goto :goto_1c

    :cond_18
    invoke-static {p1, p2}, Ljavax/crypto/KeyAgreement;->getInstance(Ljava/lang/String;Ljava/security/Provider;)Ljavax/crypto/KeyAgreement;

    move-result-object p0

    :goto_1c
    return-object p0

    nop

    :pswitch_data_1e
    .packed-switch 0x17
        :pswitch_11  #00000017
    .end packed-switch
.end method

.method public g(Landroidx/preference/Preference;)Ljava/lang/CharSequence;
    .registers 2

    .prologue
    check-cast p1, Landroidx/preference/EditTextPreference;

    iget-object p0, p1, Landroidx/preference/EditTextPreference;->T:Ljava/lang/String;

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p0

    if-eqz p0, :cond_14

    iget-object p0, p1, Landroidx/preference/Preference;->a:Landroid/content/Context;

    const p1, 0x7f1301df

    invoke-virtual {p0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_14
    iget-object p0, p1, Landroidx/preference/EditTextPreference;->T:Ljava/lang/String;

    return-object p0
.end method

.method public h(Lk20;)Ljava/lang/Object;
    .registers 4

    .prologue
    iget p0, p0, Lkn0;->a:I

    const-class v0, Ljava/util/concurrent/Executor;

    packed-switch p0, :pswitch_data_32

    new-instance p0, Lyo1;

    const-class v1, Lhg2;

    invoke-direct {p0, v1, v0}, Lyo1;-><init>(Ljava/lang/Class;Ljava/lang/Class;)V

    invoke-virtual {p1, p0}, Lk20;->f(Lyo1;)Ljava/lang/Object;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p0, Ljava/util/concurrent/Executor;

    invoke-static {p0}, Lnp3;->I(Ljava/util/concurrent/Executor;)Loy;

    move-result-object p0

    return-object p0

    :pswitch_1c  #0x3
    new-instance p0, Lyo1;

    const-class v1, Lm11;

    invoke-direct {p0, v1, v0}, Lyo1;-><init>(Ljava/lang/Class;Ljava/lang/Class;)V

    invoke-virtual {p1, p0}, Lk20;->f(Lyo1;)Ljava/lang/Object;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p0, Ljava/util/concurrent/Executor;

    invoke-static {p0}, Lnp3;->I(Ljava/util/concurrent/Executor;)Loy;

    move-result-object p0

    return-object p0

    nop

    :pswitch_data_32
    .packed-switch 0x3
        :pswitch_1c  #00000003
    .end packed-switch
.end method

.method public m(Lcom/google/firebase/components/ComponentRegistrar;)Ljava/util/List;
    .registers 3

    .prologue
    new-instance p0, Ljava/util/ArrayList;

    invoke-direct {p0}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {p1}, Lcom/google/firebase/components/ComponentRegistrar;->getComponents()Ljava/util/List;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_d
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_20

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljt;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_d

    :cond_20
    return-object p0
.end method

.method public onAdFailedToLoad(Lq31;)V
    .registers 6

    .prologue
    const/4 v0, -0x3

    new-instance p0, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v2, "Falha ao carregar AppOpen ("

    const/16 v0, 0x97

    invoke-direct {p0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0xf55

    invoke-virtual {p1}, Lq31;->V()Lp31;

    move-result-object v2

    const/16 v0, 0x190

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string/jumbo v2, ": "

    const/4 v0, 0x0

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0xaf5

    invoke-virtual {p1}, Lq31;->W()Ljava/lang/String;

    move-result-object p1

    const/4 v0, 0x0

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 p1, 0x29

    const/16 v0, 0x1b

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string/jumbo p1, "Ads-Load"

    nop

    const/4 p0, 0x0

    const/16 v0, 0xfa5

    sput-boolean p0, Lg4;->t:Z

    const/4 p0, 0x0

    const/16 v0, 0x7aa

    sput-object p0, Lg4;->s:Lce;

    const/16 v0, 0x101

    sget-boolean p0, Lmi2;->n:Z

    nop

    if-eqz p0, :cond_4a

    goto :goto_75

    :cond_4a
    const/16 v0, 0xbfc

    sget-object p0, Lmi2;->q:Lcom/tlsvpn/tlstunnel/MainActivity;

    nop

    if-eqz p0, :cond_75

    const/16 v0, 0x140

    sget-boolean p1, Lg4;->a:Z

    nop

    const/16 v0, 0xfe7

    sget p1, Lg4;->u:I

    nop

    add-int/lit8 v2, p1, 0x1

    const/16 v0, 0xa94

    sput v2, Lg4;->u:I

    const/4 v2, 0x4

    if-ge p1, v2, :cond_75

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-wide/16 v2, 0x3a98

    const/16 v0, 0x3a0

    invoke-static {v2, v3, p0}, Lg4;->j(JLandroid/content/Context;)V

    :cond_75
    :goto_75
    return-void
.end method

.method public onAdLoaded(Ljava/lang/Object;)V
    .registers 5

    .prologue
    check-cast p1, Lce;

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string/jumbo p0, "Ads-Load"

    const-string/jumbo v2, "AppOpen Carregado!"

    nop

    const/4 p0, 0x0

    const/16 v0, 0xfa5

    sput-boolean p0, Lg4;->t:Z

    const/16 v0, 0xa94

    sput p0, Lg4;->u:I

    const/16 v0, 0x195

    sget-boolean p0, Lmi2;->d:Z

    nop

    if-nez p0, :cond_25

    const/16 v0, 0xf11

    sget-boolean p0, Lmi2;->e:Z

    nop

    if-nez p0, :cond_25

    goto :goto_2c

    :cond_25
    const/16 v0, 0x101

    sget-boolean p0, Lmi2;->n:Z

    nop

    if-eqz p0, :cond_2d

    :goto_2c
    return-void

    :cond_2d
    const/16 v0, 0x7aa

    sput-object p1, Lg4;->s:Lce;

    check-cast p1, Lads_mobile_sdk/bh;

    const/16 v0, 0xd98

    iget-object p0, p1, Lads_mobile_sdk/bh;->b:Lads_mobile_sdk/jd1;

    nop

    const/4 p1, 0x1

    const/16 v0, 0xb06

    iput-boolean p1, p0, Lads_mobile_sdk/xo;->n:Z

    const/16 v0, 0xcb4

    iput-boolean p1, p0, Lads_mobile_sdk/xo;->o:Z

    const/16 v0, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    return-void
.end method
