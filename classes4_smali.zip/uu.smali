.class public final synthetic Luu;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lwu;


# direct methods
.method public synthetic constructor <init>(Lwu;I)V
    .registers 5

    iput p2, p0, Luu;->a:I

    iput-object p1, p0, Luu;->b:Lwu;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 8

    .prologue
    const/16 v0, 0x904

    iget p1, p0, Luu;->a:I

    nop

    const-string/jumbo v2, "pasni"

    const-string/jumbo v3, ""

    const/16 v0, 0xa91

    iget-object p0, p0, Luu;->b:Lwu;

    nop

    packed-switch p1, :pswitch_data_b4

    const/16 v0, 0x250

    invoke-virtual {p0}, Lwu;->e()V

    const/16 v0, 0x378

    new-instance p1, Lvj1;

    nop

    const/16 v0, 0x311

    invoke-direct {p1}, Lvj1;-><init>()V

    const/16 v0, 0x108

    new-instance v4, Landroid/os/Bundle;

    nop

    const/16 v0, 0x198

    invoke-direct {v4}, Landroid/os/Bundle;-><init>()V

    const/16 v0, 0x76

    invoke-virtual {v4, v2, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v0, 0x19a

    invoke-virtual {p1, v4}, Landroidx/fragment/app/Fragment;->setArguments(Landroid/os/Bundle;)V

    const/16 v0, 0x8b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getParentFragmentManager()Landroidx/fragment/app/p;

    move-result-object p0

    const/16 v0, 0x8c

    invoke-virtual {p1, p0, v3}, Landroidx/fragment/app/g;->show(Landroidx/fragment/app/p;Ljava/lang/String;)V

    return-void

    :pswitch_42  #0x3
    const/16 v0, 0x250

    invoke-virtual {p0}, Lwu;->e()V

    const/16 v0, 0x378

    new-instance p1, Lvj1;

    nop

    const/16 v0, 0x311

    invoke-direct {p1}, Lvj1;-><init>()V

    const/16 v0, 0x108

    new-instance v4, Landroid/os/Bundle;

    nop

    const/16 v0, 0x198

    invoke-direct {v4}, Landroid/os/Bundle;-><init>()V

    const-string/jumbo v5, "pn"

    const/16 v0, 0x76

    invoke-virtual {v4, v2, v5}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v0, 0x19a

    invoke-virtual {p1, v4}, Landroidx/fragment/app/Fragment;->setArguments(Landroid/os/Bundle;)V

    const/16 v0, 0x8b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getParentFragmentManager()Landroidx/fragment/app/p;

    move-result-object p0

    const/16 v0, 0x8c

    invoke-virtual {p1, p0, v3}, Landroidx/fragment/app/g;->show(Landroidx/fragment/app/p;Ljava/lang/String;)V

    return-void

    :pswitch_74  #0x2
    const/16 v0, 0x181

    invoke-virtual {p0}, Landroidx/fragment/app/g;->dismiss()V

    return-void

    :pswitch_7a  #0x1
    const/16 v0, 0x181

    invoke-virtual {p0}, Landroidx/fragment/app/g;->dismiss()V

    return-void

    :pswitch_80  #0x0
    const/16 v0, 0x250

    invoke-virtual {p0}, Lwu;->e()V

    const/16 v0, 0xe47

    new-instance p1, Lso1;

    nop

    const/16 v0, 0xe2c

    invoke-direct {p1}, Lso1;-><init>()V

    const/16 v0, 0x108

    new-instance v2, Landroid/os/Bundle;

    nop

    const/16 v0, 0x198

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    const-string/jumbo v4, "eptalert"

    const/4 v5, 0x0

    const/16 v0, 0x27b

    invoke-virtual {v2, v4, v5}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/16 v0, 0x19a

    invoke-virtual {p1, v2}, Landroidx/fragment/app/Fragment;->setArguments(Landroid/os/Bundle;)V

    const/16 v0, 0x8b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getParentFragmentManager()Landroidx/fragment/app/p;

    move-result-object p0

    const/16 v0, 0x8c

    invoke-virtual {p1, p0, v3}, Landroidx/fragment/app/g;->show(Landroidx/fragment/app/p;Ljava/lang/String;)V

    return-void

    nop

    :pswitch_data_b4
    .packed-switch 0x0
        :pswitch_80  #00000000
        :pswitch_7a  #00000001
        :pswitch_74  #00000002
        :pswitch_42  #00000003
    .end packed-switch
.end method
