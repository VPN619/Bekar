.class public final synthetic Le51;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lbk0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/tlsvpn/tlstunnel/MainActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/tlsvpn/tlstunnel/MainActivity;I)V
    .registers 5

    iput p2, p0, Le51;->a:I

    iput-object p1, p0, Le51;->b:Lcom/tlsvpn/tlstunnel/MainActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 8

    .prologue
    const/16 v0, 0x823

    iget v2, p0, Le51;->a:I

    nop

    const/16 v0, 0x21

    sget-object v3, Lrg2;->a:Lrg2;

    nop

    const-string/jumbo v4, "InAppUpdate"

    const/16 v0, 0xdf7

    iget-object p0, p0, Le51;->b:Lcom/tlsvpn/tlstunnel/MainActivity;

    nop

    check-cast p1, Lfe;

    packed-switch v2, :pswitch_data_ee

    const/16 v0, 0x44d

    sget v2, Lcom/tlsvpn/tlstunnel/MainActivity;->m:I

    nop

    const/16 v0, 0x464

    iget v2, p1, Lfe;->a:I

    nop

    const/4 v5, 0x2

    if-ne v2, v5, :cond_9a

    const/16 v0, 0x214

    invoke-static {}, Lkq3;->a()Ldq3;

    move-result-object v2

    const/16 v0, 0x1ca

    invoke-virtual {v2}, Ldq3;->a()Lkq3;

    const/16 v0, 0x7eb

    iget-object v2, p1, Lfe;->b:Landroid/app/PendingIntent;

    nop

    if-eqz v2, :cond_37

    goto :goto_38

    :cond_37
    const/4 v2, 0x0

    :goto_38
    if-eqz v2, :cond_9a

    :try_start_3a
    const/16 v0, 0x302

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/MainActivity;->l:Lw82;

    nop

    const/16 v0, 0x177

    invoke-virtual {v2}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lli3;

    const/16 v0, 0x214

    invoke-static {}, Lkq3;->a()Ldq3;

    move-result-object v5

    const/16 v0, 0x1ca

    invoke-virtual {v5}, Ldq3;->a()Lkq3;

    move-result-object v5

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x287

    invoke-static {p1, p0, v5}, Lli3;->b(Lfe;Landroid/app/Activity;Lkq3;)V
    :try_end_5c
    .catch Landroid/content/IntentSender$SendIntentException; {:try_start_3a .. :try_end_5c} :catch_5f
    .catch Ljava/lang/Exception; {:try_start_3a .. :try_end_5c} :catch_5d

    goto :goto_9a

    :catch_5d
    move-exception p0

    goto :goto_61

    :catch_5f
    move-exception p0

    goto :goto_7e

    :goto_61
    const/4 v0, -0x3

    new-instance p1, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v2, "Erro genérico ao tentar atualizar: "

    const/16 v0, 0x97

    invoke-direct {p1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x1da

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v0, 0x0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    nop

    goto :goto_9a

    :goto_7e
    const/4 v0, -0x3

    new-instance p1, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v2, "Erro de Intent da Play Store: "

    const/16 v0, 0x97

    invoke-direct {p1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x1da

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v0, 0x0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    nop

    :cond_9a
    :goto_9a
    check-cast v3, Ljava/lang/Object;

    return-object v3

    :pswitch_9d  #0x0
    const/16 v0, 0x44d

    sget v2, Lcom/tlsvpn/tlstunnel/MainActivity;->m:I

    nop

    const/16 v0, 0x464

    iget v2, p1, Lfe;->a:I

    nop

    const/4 v5, 0x3

    if-ne v2, v5, :cond_ea

    :try_start_aa
    const/16 v0, 0x302

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/MainActivity;->l:Lw82;

    nop

    const/16 v0, 0x177

    invoke-virtual {v2}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lli3;

    const/16 v0, 0x214

    invoke-static {}, Lkq3;->a()Ldq3;

    move-result-object v5

    const/16 v0, 0x1ca

    invoke-virtual {v5}, Ldq3;->a()Lkq3;

    move-result-object v5

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x287

    invoke-static {p1, p0, v5}, Lli3;->b(Lfe;Landroid/app/Activity;Lkq3;)V
    :try_end_cc
    .catch Ljava/lang/Exception; {:try_start_aa .. :try_end_cc} :catch_cd

    goto :goto_ea

    :catch_cd
    move-exception p0

    const/4 v0, -0x3

    new-instance p1, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v2, "Erro genérico ao retomar: "

    const/16 v0, 0x97

    invoke-direct {p1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x1da

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v0, 0x0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    nop

    :cond_ea
    :goto_ea
    check-cast v3, Ljava/lang/Object;

    return-object v3

    nop

    :pswitch_data_ee
    .packed-switch 0x0
        :pswitch_9d  #00000000
    .end packed-switch
.end method
