.class public Lcom/google/firebase/provider/FirebaseInitProvider;
.super Landroid/content/ContentProvider;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final a:Lwg;

.field public static final b:Ljava/util/concurrent/atomic/AtomicBoolean;


# direct methods
.method static constructor <clinit>()V
    .registers 18

    const/16 v9, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v12

    const/16 v9, 0xa03

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v14

    const/16 v9, 0x223

    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    move-result-wide v16

    const/16 v9, 0x1138

    new-instance v11, Lwg;

    nop

    const/16 v9, 0xf60

    move v0, v9

    move-object v1, v11

    move-wide v2, v12

    move-wide v4, v14

    move-wide/from16 v6, v16

    invoke-direct/range {v1 .. v7}, Lwg;-><init>(JJJ)V

    check-cast v11, Lwg;

    sput-object v11, Lcom/google/firebase/provider/FirebaseInitProvider;->a:Lwg;

    const/16 v9, 0x43d

    new-instance v11, Ljava/util/concurrent/atomic/AtomicBoolean;

    nop

    const/4 v12, 0x0

    const/16 v9, 0x309

    invoke-direct {v11, v12}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    check-cast v11, Ljava/util/concurrent/atomic/AtomicBoolean;

    sput-object v11, Lcom/google/firebase/provider/FirebaseInitProvider;->b:Ljava/util/concurrent/atomic/AtomicBoolean;

    return-void
.end method

.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Landroid/content/ContentProvider;-><init>()V

    return-void
.end method


# virtual methods
.method public final attachInfo(Landroid/content/Context;Landroid/content/pm/ProviderInfo;)V
    .registers 7

    .prologue
    const-string/jumbo v2, "FirebaseInitProvider ProviderInfo cannot be null."

    nop

    nop

    const/16 v0, 0x1074

    invoke-static {p2, v2}, Lcom/google/android/gms/common/internal/Preconditions;->checkNotNull(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v2, "com.google.firebase.firebaseinitprovider"

    nop

    nop

    const/16 v0, 0x323

    iget-object v3, p2, Landroid/content/pm/ProviderInfo;->authority:Ljava/lang/String;

    nop

    const/4 v0, -0x7

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_21

    const/16 v0, 0x725

    invoke-super {p0, p1, p2}, Landroid/content/ContentProvider;->attachInfo(Landroid/content/Context;Landroid/content/pm/ProviderInfo;)V

    return-void

    :cond_21
    const-string/jumbo p0, "Incorrect provider authority in manifest. Most likely due to a missing applicationId variable in application\'s build.gradle."

    nop

    nop

    const/16 v0, 0x13

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-void
.end method

.method public final delete(Landroid/net/Uri;Ljava/lang/String;[Ljava/lang/String;)I
    .registers 6

    const/4 p0, 0x0

    return p0
.end method

.method public final getType(Landroid/net/Uri;)Ljava/lang/String;
    .registers 4

    const/4 p0, 0x0

    return-object p0
.end method

.method public final insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;
    .registers 5

    const/4 p0, 0x0

    return-object p0
.end method

.method public final onCreate()Z
    .registers 6

    .prologue
    const/16 v0, 0x10a1

    sget-object v2, Lcom/google/firebase/provider/FirebaseInitProvider;->b:Ljava/util/concurrent/atomic/AtomicBoolean;

    nop

    const/4 v3, 0x1

    const/4 v4, 0x0

    :try_start_7
    const/16 v0, 0x254

    invoke-virtual {v2, v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    const/16 v0, 0x6c7

    invoke-virtual {p0}, Landroid/content/ContentProvider;->getContext()Landroid/content/Context;

    move-result-object p0

    const/16 v0, 0xec0

    invoke-static {p0}, Lee0;->e(Landroid/content/Context;)Lee0;

    move-result-object p0
    :try_end_18
    .catchall {:try_start_7 .. :try_end_18} :catchall_26

    const-string/jumbo v3, "FirebaseInitProvider"

    nop

    nop

    if-nez p0, :cond_28

    :try_start_1f
    const-string/jumbo p0, "FirebaseApp initialization unsuccessful"

    nop

    nop

    nop

    goto :goto_2e

    :catchall_26
    move-exception p0

    goto :goto_34

    :cond_28
    const-string/jumbo p0, "FirebaseApp initialization successful"

    nop

    nop

    nop
    :try_end_2e
    .catchall {:try_start_1f .. :try_end_2e} :catchall_26

    :goto_2e
    const/16 v0, 0x254

    invoke-virtual {v2, v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    return v4

    :goto_34
    const/16 v0, 0x254

    invoke-virtual {v2, v4}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    throw p0
.end method

.method public final query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    .registers 8

    const/4 p0, 0x0

    return-object p0
.end method

.method public final update(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I
    .registers 7

    const/4 p0, 0x0

    return p0
.end method
