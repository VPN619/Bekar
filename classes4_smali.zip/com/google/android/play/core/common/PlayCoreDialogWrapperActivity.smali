.class public Lcom/google/android/play/core/common/PlayCoreDialogWrapperActivity;
.super Landroid/app/Activity;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public a:Landroid/os/ResultReceiver;


# direct methods
.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method


# virtual methods
.method public final onActivityResult(IILandroid/content/Intent;)V
    .registers 6

    .prologue
    const/16 v0, 0xd8d

    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onActivityResult(IILandroid/content/Intent;)V

    if-nez p1, :cond_34

    const/16 v0, 0x4de

    iget-object p1, p0, Lcom/google/android/play/core/common/PlayCoreDialogWrapperActivity;->a:Landroid/os/ResultReceiver;

    nop

    if-eqz p1, :cond_34

    const/4 p3, -0x1

    if-ne p2, p3, :cond_22

    const/16 v0, 0x108

    new-instance p2, Landroid/os/Bundle;

    nop

    const/16 v0, 0x198

    invoke-direct {p2}, Landroid/os/Bundle;-><init>()V

    const/4 p3, 0x1

    const/16 v0, 0x3e4

    invoke-virtual {p1, p3, p2}, Landroid/os/ResultReceiver;->send(ILandroid/os/Bundle;)V

    goto :goto_34

    :cond_22
    if-nez p2, :cond_34

    const/16 v0, 0x108

    new-instance p2, Landroid/os/Bundle;

    nop

    const/16 v0, 0x198

    invoke-direct {p2}, Landroid/os/Bundle;-><init>()V

    const/4 p3, 0x2

    const/16 v0, 0x3e4

    invoke-virtual {p1, p3, p2}, Landroid/os/ResultReceiver;->send(ILandroid/os/Bundle;)V

    :cond_34
    :goto_34
    const/16 v0, 0x107

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    return-void
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .registers 23

    .prologue
    const/16 v8, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v10

    const/4 v11, 0x0

    const-string/jumbo v12, "window_flags"

    nop

    nop

    const/16 v8, 0xa8

    invoke-virtual {v10, v12, v11}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v10

    const/4 v11, 0x0

    if-eqz v10, :cond_3c

    const/16 v8, 0x86

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v13

    const/16 v8, 0x213

    invoke-virtual {v13}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v13

    const/16 v8, 0x848

    invoke-virtual {v13, v10}, Landroid/view/View;->setSystemUiVisibility(I)V

    const/16 v8, 0x5b

    new-instance v13, Landroid/content/Intent;

    nop

    const/16 v8, 0x96c

    invoke-direct {v13}, Landroid/content/Intent;-><init>()V

    const/16 v8, 0x29

    invoke-virtual {v13, v12, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-object/from16 v17, v13

    goto :goto_3e

    :cond_3c
    move-object/from16 v17, v11

    :goto_3e
    const/16 v8, 0xdef

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-super {v0, v1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const-string/jumbo v10, "result_receiver"

    nop

    nop

    if-nez p1, :cond_ff

    const/16 v8, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const/16 v8, 0x3f

    move-object/from16 v0, p1

    invoke-virtual {v0, v10}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p1

    check-cast p1, Landroid/os/ResultReceiver;

    const/16 v8, 0x369

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iput-object v1, v0, Lcom/google/android/play/core/common/PlayCoreDialogWrapperActivity;->a:Landroid/os/ResultReceiver;

    const/16 v8, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const/16 v8, 0xdf

    move-object/from16 v0, p1

    invoke-virtual {v0}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object p1

    if-eqz p1, :cond_8a

    const-string/jumbo v10, "confirmation_intent"

    nop

    nop

    const/16 v8, 0x45b

    move-object/from16 v0, p1

    invoke-virtual {v0, v10}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v10

    move-object v11, v10

    check-cast v11, Landroid/app/PendingIntent;

    :cond_8a
    const/4 v10, 0x3

    if-eqz p1, :cond_8f

    if-nez v11, :cond_92

    :cond_8f
    move-object/from16 v14, p0

    goto :goto_db

    :cond_92
    :try_start_92
    const/16 v8, 0xc7

    invoke-virtual {v11}, Landroid/app/PendingIntent;->getIntentSender()Landroid/content/IntentSender;

    move-result-object v15
    :try_end_98
    .catch Landroid/content/IntentSender$SendIntentException; {:try_start_92 .. :try_end_98} :catch_b5

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v16, 0x0

    const/16 v18, 0x0

    move-object/from16 v14, p0

    :try_start_a2
    const/16 v8, 0x11f7

    move v0, v8

    move-object v1, v14

    move-object v2, v15

    move/from16 v3, v16

    move-object/from16 v4, v17

    move/from16 v5, v18

    move/from16 v6, v19

    move/from16 v7, v20

    invoke-virtual/range {v1 .. v7}, Landroid/app/Activity;->startIntentSenderForResult(Landroid/content/IntentSender;ILandroid/content/Intent;III)V
    :try_end_b4
    .catch Landroid/content/IntentSender$SendIntentException; {:try_start_a2 .. :try_end_b4} :catch_b7

    return-void

    :catch_b5
    move-object/from16 v14, p0

    :catch_b7
    const/16 v8, 0x4de

    iget-object v8, v14, Lcom/google/android/play/core/common/PlayCoreDialogWrapperActivity;->a:Landroid/os/ResultReceiver;

    move-object/16 p0, v8

    if-eqz p0, :cond_d5

    const/16 v8, 0x108

    new-instance p1, Landroid/os/Bundle;

    nop

    const/16 v8, 0x198

    move-object/from16 v0, p1

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/16 v8, 0x3e4

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual {v0, v10, v1}, Landroid/os/ResultReceiver;->send(ILandroid/os/Bundle;)V

    :cond_d5
    const/16 v8, 0x107

    invoke-virtual {v14}, Landroid/app/Activity;->finish()V

    return-void

    :goto_db
    const/16 v8, 0x4de

    iget-object v8, v14, Lcom/google/android/play/core/common/PlayCoreDialogWrapperActivity;->a:Landroid/os/ResultReceiver;

    move-object/16 p0, v8

    if-eqz p0, :cond_f9

    const/16 v8, 0x108

    new-instance p1, Landroid/os/Bundle;

    nop

    const/16 v8, 0x198

    move-object/from16 v0, p1

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/16 v8, 0x3e4

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual {v0, v10, v1}, Landroid/os/ResultReceiver;->send(ILandroid/os/Bundle;)V

    :cond_f9
    const/16 v8, 0x107

    invoke-virtual {v14}, Landroid/app/Activity;->finish()V

    return-void

    :cond_ff
    move-object/from16 v14, p0

    const/16 v8, 0xc3

    move-object/from16 v0, p1

    invoke-virtual {v0, v10}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p0

    check-cast p0, Landroid/os/ResultReceiver;

    const/16 v8, 0x369

    move-object/from16 v0, p0

    iput-object v0, v14, Lcom/google/android/play/core/common/PlayCoreDialogWrapperActivity;->a:Landroid/os/ResultReceiver;

    return-void
.end method

.method public final onSaveInstanceState(Landroid/os/Bundle;)V
    .registers 5

    const-string/jumbo v2, "result_receiver"

    nop

    nop

    const/16 v0, 0x4de

    iget-object p0, p0, Lcom/google/android/play/core/common/PlayCoreDialogWrapperActivity;->a:Landroid/os/ResultReceiver;

    nop

    const/16 v0, 0x9a

    invoke-virtual {p1, v2, p0}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    return-void
.end method
