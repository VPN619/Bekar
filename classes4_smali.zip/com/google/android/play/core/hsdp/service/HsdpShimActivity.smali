.class public Lcom/google/android/play/core/hsdp/service/HsdpShimActivity;
.super Landroid/app/Activity;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public a:Ljava/lang/String;

.field public b:Z


# direct methods
.method public constructor <init>()V
    .registers 4

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v2, 0x0

    const/16 v0, 0x92d

    iput-object v2, p0, Lcom/google/android/play/core/hsdp/service/HsdpShimActivity;->a:Ljava/lang/String;

    const/4 v2, 0x0

    const/16 v0, 0x854

    iput-boolean v2, p0, Lcom/google/android/play/core/hsdp/service/HsdpShimActivity;->b:Z

    return-void
.end method


# virtual methods
.method public final a(Z)V
    .registers 23

    .prologue
    const/16 v9, 0x86

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v11

    const/16 v9, 0x213

    invoke-virtual {v11}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v11

    const/16 v9, 0xb52

    invoke-virtual {v11}, Landroid/view/View;->getWindowToken()Landroid/os/IBinder;

    move-result-object v15

    if-eqz v15, :cond_1c0

    const/16 v9, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v11

    const-string/jumbo v12, "target_package_name"

    nop

    nop

    const/16 v9, 0x8d

    invoke-virtual {v11, v12}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    if-eqz v13, :cond_1b3

    const/16 v9, 0x8a4

    invoke-static {}, Lcom/google/android/play/core/hsdp/service/HsdpDeepLinkServiceFactory;->createHsdpServiceIntent()Landroid/content/Intent;

    move-result-object v12

    const/16 v9, 0x1201

    move-object/from16 v0, p0

    invoke-static {v0, v12}, Lnp3;->j0(Landroid/content/Context;Landroid/content/Intent;)Lzo3;

    move-result-object v12

    if-nez p1, :cond_b1

    const/16 v9, 0x917

    move-object/from16 v0, p0

    iget-object v9, v0, Lcom/google/android/play/core/hsdp/service/HsdpShimActivity;->a:Ljava/lang/String;

    move-object/16 p1, v9

    const/4 v9, -0x7

    move-object/from16 v0, p1

    invoke-virtual {v13, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_b1

    move-object/from16 p1, v12

    check-cast p1, Lyb3;

    const/16 v9, 0xb2e

    move-object/from16 v0, p1

    iget-object v9, v0, Lyb3;->c:Ljava/util/concurrent/ConcurrentHashMap;

    move-object/16 p1, v9

    const/16 v9, 0x116f

    move-object/from16 v0, p1

    invoke-virtual {v0, v13}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lfd3;

    if-eqz p1, :cond_b1

    const/16 v9, 0x7f5

    move-object/from16 v0, p1

    iget v9, v0, Lfd3;->a:I

    move/16 p1, v9

    const/4 v14, 0x2

    move/from16 v0, p1

    if-ne v0, v14, :cond_b1

    const/16 p0, 0x4

    const-string/jumbo p1, "HsdpShimActivity"

    nop

    nop

    const/16 v9, 0x481

    move-object/from16 v0, p1

    move/from16 v1, p0

    invoke-static {v0, v1}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result p0

    if-eqz p0, :cond_b0

    const/4 v9, -0x3

    new-instance p0, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v11, "HSDP is already showing for "

    nop

    nop

    const/16 v9, 0x97

    move-object/from16 v0, p0

    invoke-direct {v0, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x0

    move-object/from16 v0, p0

    invoke-virtual {v0, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v11, ", ignore."

    nop

    nop

    const/4 v9, 0x0

    move-object/from16 v0, p0

    invoke-virtual {v0, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, -0x2

    move-object/from16 v0, p0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    nop

    :cond_b0
    return-void

    :cond_b1
    const/16 v9, 0x92d

    move-object/from16 v0, p0

    iput-object v13, v0, Lcom/google/android/play/core/hsdp/service/HsdpShimActivity;->a:Ljava/lang/String;

    const/16 p1, 0x0

    const/16 v9, 0x854

    move-object/from16 v0, p0

    move/from16 v1, p1

    iput-boolean v1, v0, Lcom/google/android/play/core/hsdp/service/HsdpShimActivity;->b:Z

    const-string/jumbo v14, "referrer"

    nop

    nop

    const/16 v9, 0x8d

    invoke-virtual {v11, v14}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    if-eqz v14, :cond_1a6

    const-string/jumbo v16, "deeplink_url"

    nop

    nop

    const/16 v9, 0x8d

    move-object/from16 v0, v16

    invoke-virtual {v11, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v16

    if-eqz v16, :cond_199

    const-string/jumbo v17, "auto_trigger"

    nop

    nop

    const/16 v9, 0x151

    move-object/from16 v0, v17

    move/from16 v1, p1

    invoke-virtual {v11, v0, v1}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v18

    const-string/jumbo p1, "extra_query_params_bundle"

    nop

    nop

    const/16 v9, 0xd83

    move-object/from16 v0, p1

    invoke-virtual {v11, v0}, Landroid/content/Intent;->getBundleExtra(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object p1

    if-eqz p1, :cond_142

    const/16 v9, 0x8b3

    new-instance v11, Ljava/util/HashMap;

    nop

    const/16 v9, 0xf9f

    invoke-direct {v11}, Ljava/util/HashMap;-><init>()V

    const/16 v9, 0xa65

    move-object/from16 v0, p1

    invoke-virtual {v0}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    move-result-object v17

    const/16 v9, 0x14c

    move-object/from16 v0, v17

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v17

    :goto_115
    const/16 v9, 0x13e

    move-object/from16 v0, v17

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v19

    if-eqz v19, :cond_143

    const/16 v9, 0x16e

    move-object/from16 v0, v17

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v19

    check-cast v19, Ljava/lang/String;

    const/16 v9, 0x183

    move-object/from16 v0, p1

    move-object/from16 v1, v19

    invoke-virtual {v0, v1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v20

    if-nez v20, :cond_138

    const-string/jumbo v20, ""

    :cond_138
    const/16 v9, 0x9c7

    move-object/from16 v0, v19

    move-object/from16 v1, v20

    invoke-virtual {v11, v0, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_115

    :cond_142
    const/4 v11, 0x0

    :cond_143
    const/16 v9, 0x142

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const/16 v9, 0x84a

    move-object/from16 v0, p1

    invoke-virtual {v0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object p1

    const/16 v9, 0x6b2

    move-object/from16 v0, p1

    iget v9, v0, Landroid/content/res/Configuration;->screenWidthDp:I

    move/16 p1, v9

    const/16 v9, 0xf83

    move-object/from16 v0, p0

    move/from16 v1, p1

    invoke-static {v0, v1}, Lw53;->X(Landroid/app/Activity;I)I

    move-result p1

    const/16 v9, 0xf41

    move-object/from16 v0, p0

    invoke-static {v0}, Lw53;->Y(Landroid/app/Activity;)I

    move-result v17

    const/16 v9, 0x727

    new-instance v19, Lx5;

    nop

    const/16 v9, 0x5c7

    move v0, v9

    move-object/from16 v1, v19

    move-object/from16 v2, p0

    move-object v3, v13

    move-object v4, v14

    move-object v5, v11

    invoke-direct/range {v1 .. v5}, Lx5;-><init>(Lcom/google/android/play/core/hsdp/service/HsdpShimActivity;Ljava/lang/String;Ljava/lang/String;Ljava/util/HashMap;)V

    check-cast v12, Lyb3;

    move-object/from16 v14, v16

    move/from16 v16, p1

    const/16 v9, 0x886

    move v0, v9

    move-object v1, v12

    move-object v2, v13

    move-object v3, v14

    move-object v4, v15

    move/from16 v5, v16

    move/from16 v6, v17

    move/from16 v7, v18

    move-object/from16 v8, v19

    invoke-virtual/range {v1 .. v8}, Lyb3;->a(Ljava/lang/String;Ljava/lang/String;Landroid/os/IBinder;IIZLmo0;)V

    return-void

    :cond_199
    const-string/jumbo p0, "deeplinkUrl is null"

    nop

    nop

    const/16 v9, 0x13

    move-object/from16 v0, p0

    invoke-static {v0}, Lz6;->w(Ljava/lang/String;)V

    return-void

    :cond_1a6
    const-string/jumbo p0, "referrer is null"

    nop

    nop

    const/16 v9, 0x13

    move-object/from16 v0, p0

    invoke-static {v0}, Lz6;->w(Ljava/lang/String;)V

    return-void

    :cond_1b3
    const-string/jumbo p0, "targetPackageName is null"

    nop

    nop

    const/16 v9, 0x13

    move-object/from16 v0, p0

    invoke-static {v0}, Lz6;->w(Ljava/lang/String;)V

    return-void

    :cond_1c0
    const-string/jumbo p0, "windowToken is null"

    nop

    nop

    const/16 v9, 0x13

    move-object/from16 v0, p0

    invoke-static {v0}, Lz6;->w(Ljava/lang/String;)V

    return-void
.end method

.method public final onAttachedToWindow()V
    .registers 5

    const/16 v0, 0x9d9

    invoke-super {p0}, Landroid/app/Activity;->onAttachedToWindow()V

    const-string/jumbo v2, "HsdpShimActivity"

    nop

    nop

    const-string/jumbo v3, "shim activity onAttachedToWindow"

    nop

    nop

    nop

    const/4 v2, 0x0

    const/16 v0, 0x6c3

    invoke-virtual {p0, v2}, Lcom/google/android/play/core/hsdp/service/HsdpShimActivity;->a(Z)V

    return-void
.end method

.method public final onConfigurationChanged(Landroid/content/res/Configuration;)V
    .registers 5

    const/16 v0, 0xb82

    invoke-super {p0, p1}, Landroid/app/Activity;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    const-string/jumbo p1, "HsdpShimActivity"

    nop

    nop

    const-string/jumbo v2, "shim activity onConfigurationChanged"

    nop

    nop

    nop

    const/4 p1, 0x1

    const/16 v0, 0x6c3

    invoke-virtual {p0, p1}, Lcom/google/android/play/core/hsdp/service/HsdpShimActivity;->a(Z)V

    return-void
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .registers 5

    .prologue
    const/16 v0, 0xdef

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f0c003a

    const/16 v0, 0xf1a

    invoke-virtual {p0, p1}, Landroid/app/Activity;->setContentView(I)V

    const/16 v0, 0x86

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p0

    const/4 p1, -0x1

    const/16 v0, 0x1132

    invoke-virtual {p0, p1, p1}, Landroid/view/Window;->setLayout(II)V

    const/16 v0, 0x1fc

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 v2, 0x1c

    if-lt p1, v2, :cond_33

    const/16 v0, 0x10c2

    invoke-virtual {p0}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    move-result-object p1

    const/4 v2, 0x1

    const/16 v0, 0x109e

    invoke-static {p1, v2}, Lvh0;->i(Landroid/view/WindowManager$LayoutParams;I)V

    const/16 v0, 0x10e9

    invoke-virtual {p0, p1}, Landroid/view/Window;->setAttributes(Landroid/view/WindowManager$LayoutParams;)V

    :cond_33
    return-void
.end method

.method public final onDestroy()V
    .registers 4

    const/16 v0, 0xc7d

    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    const-string/jumbo p0, "HsdpShimActivity"

    nop

    nop

    const-string/jumbo v2, "shim activity onDestroy"

    nop

    nop

    nop

    return-void
.end method

.method public final onNewIntent(Landroid/content/Intent;)V
    .registers 6

    const/16 v0, 0xb86

    invoke-super {p0, p1}, Landroid/app/Activity;->onNewIntent(Landroid/content/Intent;)V

    const-string/jumbo v2, "HsdpShimActivity"

    nop

    nop

    const-string/jumbo v3, "shim activity onNewIntent"

    nop

    nop

    nop

    const/16 v0, 0x9f5

    invoke-virtual {p0, p1}, Landroid/app/Activity;->setIntent(Landroid/content/Intent;)V

    const/4 p1, 0x0

    const/16 v0, 0x6c3

    invoke-virtual {p0, p1}, Lcom/google/android/play/core/hsdp/service/HsdpShimActivity;->a(Z)V

    return-void
.end method

.method public final onPause()V
    .registers 4

    const/16 v0, 0xfb4

    invoke-super {p0}, Landroid/app/Activity;->onPause()V

    const-string/jumbo p0, "HsdpShimActivity"

    nop

    nop

    const-string/jumbo v2, "shim activity onPause"

    nop

    nop

    nop

    return-void
.end method

.method public final onResume()V
    .registers 4

    const/16 v0, 0xdde

    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    const-string/jumbo p0, "HsdpShimActivity"

    nop

    nop

    const-string/jumbo v2, "shim activity onResume"

    nop

    nop

    nop

    return-void
.end method

.method public final onStart()V
    .registers 4

    const/16 v0, 0xa99

    invoke-super {p0}, Landroid/app/Activity;->onStart()V

    const-string/jumbo p0, "HsdpShimActivity"

    nop

    nop

    const-string/jumbo v2, "shim activity onStart"

    nop

    nop

    nop

    return-void
.end method

.method public final onStop()V
    .registers 4

    const/16 v0, 0xc23

    invoke-super {p0}, Landroid/app/Activity;->onStop()V

    const-string/jumbo p0, "HsdpShimActivity"

    nop

    nop

    const-string/jumbo v2, "shim activity onStop"

    nop

    nop

    nop

    return-void
.end method
