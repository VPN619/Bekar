.class public final Lcom/google/android/libraries/ads/mobile/sdk/common/AdActivity;
.super Lut;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public a:Lez2;


# direct methods
.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Lut;-><init>()V

    return-void
.end method


# virtual methods
.method public final onConfigurationChanged(Landroid/content/res/Configuration;)V
    .registers 4

    .prologue
    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xf08

    invoke-super {p0, p1}, Lut;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    const/16 v0, 0xb54

    iget-object p0, p0, Lcom/google/android/libraries/ads/mobile/sdk/common/AdActivity;->a:Lez2;

    nop

    if-eqz p0, :cond_15

    const/16 v0, 0x10ef

    invoke-interface {p0, p1}, Lez2;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    :cond_15
    return-void
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .registers 14

    .prologue
    const/16 v6, 0x871

    invoke-super {p0, p1}, Lut;->onCreate(Landroid/os/Bundle;)V

    const/16 v6, 0x3d3

    sget-object p1, Lo43;->a:Lads_mobile_sdk/ru0;

    nop

    const/4 v6, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xc37

    sget-object p1, Lads_mobile_sdk/ru0;->b:Lads_mobile_sdk/e7;

    nop

    const/16 v6, 0xc30

    iget-object p1, p1, Lads_mobile_sdk/e7;->a:Ljava/lang/Object;

    nop

    if-eqz p1, :cond_18f

    const/16 v6, 0x28

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const/16 v6, 0xdf

    invoke-virtual {p1}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object p1

    const/4 v8, 0x0

    if-eqz p1, :cond_48

    const-string/jumbo v9, "ad_activity_delegate_bundle"

    nop

    nop

    const/16 v6, 0x3cd

    invoke-virtual {p1, v9}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object p1

    if-eqz p1, :cond_48

    const-string/jumbo v9, "ad_activity_delegate"

    nop

    nop

    const/16 v6, 0x233

    invoke-virtual {p1, v9}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result p1

    const/16 v6, 0xb1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    goto :goto_49

    :cond_48
    move-object p1, v8

    :goto_49
    if-nez p1, :cond_84

    const/16 v6, 0xeb

    invoke-static {}, Lads_mobile_sdk/ru0;->a()Lo43;

    move-result-object p1

    check-cast p1, Lads_mobile_sdk/sb0;

    const/16 v6, 0x203

    iget-object p1, p1, Lads_mobile_sdk/sb0;->F:Lads_mobile_sdk/ah0;

    nop

    const/16 v6, 0x136

    invoke-virtual {p1}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lads_mobile_sdk/ah3;

    const/16 v6, 0x36a

    new-instance v9, Ljava/lang/Exception;

    nop

    const-string/jumbo v10, "AdActivityMissingDelegateKey"

    nop

    nop

    const/16 v6, 0x46d

    invoke-direct {v9, v10}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    const/16 v6, 0x280

    invoke-virtual {p1, v10, v9}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V

    const-string/jumbo p1, "Could not retrieve AdActivityDelegate key"

    nop

    nop

    const/16 v6, 0x267

    invoke-static {p1, v8}, Lads_mobile_sdk/nw;->a(Ljava/lang/String;Ljava/lang/Exception;)V

    const/16 v6, 0x107

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    return-void

    :cond_84
    const/16 v6, 0xeb

    invoke-static {}, Lads_mobile_sdk/ru0;->a()Lo43;

    move-result-object v9

    check-cast v9, Lads_mobile_sdk/sb0;

    const/16 v6, 0xcef

    iget-object v9, v9, Lads_mobile_sdk/sb0;->Q:Ltv2;

    nop

    const/16 v6, 0x1e8

    invoke-interface {v9}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lads_mobile_sdk/l0;

    const/16 v6, 0x124b

    iget-object v9, v9, Lads_mobile_sdk/l0;->d:Ljava/util/concurrent/ConcurrentHashMap;

    nop

    const/16 v6, 0x92a

    invoke-virtual {v9, p1}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lads_mobile_sdk/j0;

    if-eqz p1, :cond_b2

    const/16 v6, 0xb25

    iget-object v9, p1, Lads_mobile_sdk/j0;->b:Lx52;

    nop

    const/16 v6, 0x43a

    invoke-virtual {v9, v8}, Lnv0;->a(Ljava/util/concurrent/CancellationException;)V

    :cond_b2
    if-eqz p1, :cond_ba

    const/16 v6, 0x53b

    iget-object p1, p1, Lads_mobile_sdk/j0;->a:Lez2;

    nop

    goto :goto_bb

    :cond_ba
    move-object p1, v8

    :goto_bb
    if-nez p1, :cond_f6

    const/16 v6, 0xeb

    invoke-static {}, Lads_mobile_sdk/ru0;->a()Lo43;

    move-result-object p1

    check-cast p1, Lads_mobile_sdk/sb0;

    const/16 v6, 0x203

    iget-object p1, p1, Lads_mobile_sdk/sb0;->F:Lads_mobile_sdk/ah0;

    nop

    const/16 v6, 0x136

    invoke-virtual {p1}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lads_mobile_sdk/ah3;

    const/16 v6, 0x36a

    new-instance v9, Ljava/lang/Exception;

    nop

    const-string/jumbo v10, "AdActivityMissingDelegate"

    nop

    nop

    const/16 v6, 0x46d

    invoke-direct {v9, v10}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    const/16 v6, 0x280

    invoke-virtual {p1, v10, v9}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V

    const-string/jumbo p1, "No AdActivityDelegate associated with key"

    nop

    nop

    const/16 v6, 0x267

    invoke-static {p1, v8}, Lads_mobile_sdk/nw;->a(Ljava/lang/String;Ljava/lang/Exception;)V

    const/16 v6, 0x107

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    return-void

    :cond_f6
    const/16 v6, 0xfd6

    iput-object p1, p0, Lcom/google/android/libraries/ads/mobile/sdk/common/AdActivity;->a:Lez2;

    const/4 v9, 0x1

    const/16 v6, 0x1081

    invoke-virtual {p0, v9}, Landroid/app/Activity;->requestWindowFeature(I)Z

    :try_start_100
    const/16 v6, 0x86

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v9

    const/16 v6, 0x213

    invoke-virtual {v9}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v9

    const/4 v6, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_110
    .catch Ljava/lang/Exception; {:try_start_100 .. :try_end_110} :catch_116

    const/16 v6, 0x757

    invoke-interface {p1, p0}, Lez2;->a(Lcom/google/android/libraries/ads/mobile/sdk/common/AdActivity;)V

    return-void

    :catch_116
    move-exception v9

    const/16 v6, 0x3d3

    sget-object v10, Lo43;->a:Lads_mobile_sdk/ru0;

    nop

    const/4 v6, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xeb

    invoke-static {}, Lads_mobile_sdk/ru0;->a()Lo43;

    move-result-object v10

    check-cast v10, Lads_mobile_sdk/sb0;

    const/16 v6, 0x203

    iget-object v10, v10, Lads_mobile_sdk/sb0;->F:Lads_mobile_sdk/ah0;

    nop

    const/16 v6, 0x136

    invoke-virtual {v10}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Lads_mobile_sdk/ah3;

    const-string/jumbo v11, "AdActivityDecorViewWorkaround"

    nop

    nop

    const/16 v6, 0x280

    invoke-virtual {v10, v11, v9}, Lads_mobile_sdk/ah3;->a(Ljava/lang/String;Ljava/lang/Throwable;)V

    const-string/jumbo v10, "Failed to get DecorView"

    nop

    nop

    const/16 v6, 0x267

    invoke-static {v10, v9}, Lads_mobile_sdk/nw;->a(Ljava/lang/String;Ljava/lang/Exception;)V

    const/16 v6, 0xeb

    invoke-static {}, Lads_mobile_sdk/ru0;->a()Lo43;

    move-result-object v9

    check-cast v9, Lads_mobile_sdk/sb0;

    const/16 v6, 0xd7b

    iget-object v9, v9, Lads_mobile_sdk/sb0;->u:Lads_mobile_sdk/ah0;

    nop

    const/16 v6, 0x136

    invoke-virtual {v9}, Lads_mobile_sdk/ah0;->get()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Lvy;

    const/16 v6, 0x16

    new-instance v10, Lqd;

    nop

    const/16 v11, 0xb

    const/16 v6, 0x17

    invoke-direct {v10, p1, v8, v11}, Lqd;-><init>(Ljava/lang/Object;Lvx;I)V

    const/4 v6, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x137

    new-instance p1, La42;

    nop

    const/16 v6, 0x13b

    invoke-direct {p1, v10, v8}, La42;-><init>(Lpk0;Lvx;)V

    const/4 v10, 0x2

    const/16 v6, 0x247

    sget-object v11, Ly90;->a:Ly90;

    nop

    const/16 v6, 0xb3

    move v0, v6

    move-object v1, v9

    move-object v2, v11

    move-object v3, v8

    move-object v4, p1

    move v5, v10

    invoke-static/range {v1 .. v5}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    const/16 v6, 0x107

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    return-void

    :cond_18f
    const/16 v6, 0x107

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    return-void
.end method

.method public final onDestroy()V
    .registers 4

    .prologue
    const/16 v0, 0xb54

    iget-object v2, p0, Lcom/google/android/libraries/ads/mobile/sdk/common/AdActivity;->a:Lez2;

    nop

    if-eqz v2, :cond_c

    const/16 v0, 0x10b9

    invoke-interface {v2}, Lez2;->onDestroy()V

    :cond_c
    const/4 v2, 0x0

    const/16 v0, 0xfd6

    iput-object v2, p0, Lcom/google/android/libraries/ads/mobile/sdk/common/AdActivity;->a:Lez2;

    const/16 v0, 0xc7d

    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    return-void
.end method

.method public final onPause()V
    .registers 4

    .prologue
    const/16 v0, 0xb54

    iget-object v2, p0, Lcom/google/android/libraries/ads/mobile/sdk/common/AdActivity;->a:Lez2;

    nop

    if-eqz v2, :cond_c

    const/16 v0, 0xd22

    invoke-interface {v2}, Lez2;->onPause()V

    :cond_c
    const/16 v0, 0xfb4

    invoke-super {p0}, Landroid/app/Activity;->onPause()V

    return-void
.end method

.method public final onRestart()V
    .registers 3

    .prologue
    const/16 v0, 0x5eb

    invoke-super {p0}, Landroid/app/Activity;->onRestart()V

    const/16 v0, 0xb54

    iget-object p0, p0, Lcom/google/android/libraries/ads/mobile/sdk/common/AdActivity;->a:Lez2;

    nop

    if-eqz p0, :cond_11

    const/16 v0, 0xfb7

    invoke-interface {p0}, Lez2;->c()V

    :cond_11
    return-void
.end method

.method public final onResume()V
    .registers 3

    .prologue
    const/16 v0, 0xdde

    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    const/16 v0, 0xb54

    iget-object p0, p0, Lcom/google/android/libraries/ads/mobile/sdk/common/AdActivity;->a:Lez2;

    nop

    if-eqz p0, :cond_11

    const/16 v0, 0xbe5

    invoke-interface {p0}, Lez2;->onResume()V

    :cond_11
    return-void
.end method

.method public final onStart()V
    .registers 3

    .prologue
    const/16 v0, 0xa99

    invoke-super {p0}, Landroid/app/Activity;->onStart()V

    const/16 v0, 0xb54

    iget-object p0, p0, Lcom/google/android/libraries/ads/mobile/sdk/common/AdActivity;->a:Lez2;

    nop

    if-eqz p0, :cond_11

    const/16 v0, 0xe79

    invoke-interface {p0}, Lez2;->a()V

    :cond_11
    return-void
.end method

.method public final onStop()V
    .registers 4

    .prologue
    const/16 v0, 0xb54

    iget-object v2, p0, Lcom/google/android/libraries/ads/mobile/sdk/common/AdActivity;->a:Lez2;

    nop

    if-eqz v2, :cond_c

    const/16 v0, 0x121e

    invoke-interface {v2}, Lez2;->onStop()V

    :cond_c
    const/16 v0, 0xc23

    invoke-super {p0}, Landroid/app/Activity;->onStop()V

    return-void
.end method

.method public final onUserLeaveHint()V
    .registers 3

    .prologue
    const/16 v0, 0x11ef

    invoke-super {p0}, Landroid/app/Activity;->onUserLeaveHint()V

    const/16 v0, 0xb54

    iget-object p0, p0, Lcom/google/android/libraries/ads/mobile/sdk/common/AdActivity;->a:Lez2;

    nop

    if-eqz p0, :cond_11

    const/16 v0, 0x1009

    invoke-interface {p0}, Lez2;->b()V

    :cond_11
    return-void
.end method

.method public final setContentView(I)V
    .registers 4

    .prologue
    const/16 v0, 0xeae

    invoke-super {p0, p1}, Lut;->setContentView(I)V

    const/16 v0, 0xb54

    iget-object p0, p0, Lcom/google/android/libraries/ads/mobile/sdk/common/AdActivity;->a:Lez2;

    nop

    if-eqz p0, :cond_11

    const/16 v0, 0x5ae

    invoke-interface {p0}, Lez2;->e()V

    :cond_11
    return-void
.end method

.method public final setContentView(Landroid/view/View;)V
    .registers 4

    .prologue
    const/16 v0, 0x8e7

    invoke-super {p0, p1}, Lut;->setContentView(Landroid/view/View;)V

    const/16 v0, 0xb54

    iget-object p0, p0, Lcom/google/android/libraries/ads/mobile/sdk/common/AdActivity;->a:Lez2;

    nop

    if-eqz p0, :cond_11

    const/16 v0, 0x5ae

    invoke-interface {p0}, Lez2;->e()V

    :cond_11
    return-void
.end method

.method public final setContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    .registers 5

    .prologue
    const/16 v0, 0xfb0

    invoke-super {p0, p1, p2}, Lut;->setContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v0, 0xb54

    iget-object p0, p0, Lcom/google/android/libraries/ads/mobile/sdk/common/AdActivity;->a:Lez2;

    nop

    if-eqz p0, :cond_11

    const/16 v0, 0x5ae

    invoke-interface {p0}, Lez2;->e()V

    :cond_11
    return-void
.end method
