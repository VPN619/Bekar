.class public Lcom/google/android/datatransport/runtime/scheduling/jobscheduling/JobInfoSchedulerService;
.super Landroid/app/job/JobService;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final synthetic a:I


# direct methods
.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Landroid/app/job/JobService;-><init>()V

    return-void
.end method


# virtual methods
.method public final onStartJob(Landroid/app/job/JobParameters;)Z
    .registers 22

    .prologue
    const/16 v7, 0x176

    move-object/from16 v0, p1

    invoke-virtual {v0}, Landroid/app/job/JobParameters;->getExtras()Landroid/os/PersistableBundle;

    move-result-object v9

    const-string/jumbo v10, "backendName"

    nop

    nop

    const/16 v7, 0x183

    invoke-virtual {v9, v10}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const/16 v7, 0x176

    move-object/from16 v0, p1

    invoke-virtual {v0}, Landroid/app/job/JobParameters;->getExtras()Landroid/os/PersistableBundle;

    move-result-object v10

    const-string/jumbo v11, "extras"

    nop

    nop

    const/16 v7, 0x183

    invoke-virtual {v10, v11}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const/16 v7, 0x176

    move-object/from16 v0, p1

    invoke-virtual {v0}, Landroid/app/job/JobParameters;->getExtras()Landroid/os/PersistableBundle;

    move-result-object v11

    const-string/jumbo v12, "priority"

    nop

    nop

    const/16 v7, 0x233

    invoke-virtual {v11, v12}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v11

    const/16 v7, 0x176

    move-object/from16 v0, p1

    invoke-virtual {v0}, Landroid/app/job/JobParameters;->getExtras()Landroid/os/PersistableBundle;

    move-result-object v12

    const-string/jumbo v13, "attemptNumber"

    nop

    nop

    const/16 v7, 0x233

    invoke-virtual {v12, v13}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v17

    const/16 v7, 0x53

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v12

    const/16 v7, 0x6e1

    invoke-static {v12}, Lwc2;->b(Landroid/content/Context;)V

    const/16 v7, 0xcaf

    invoke-static {}, Lyg;->a()Ltd;

    move-result-object v12

    const/16 v7, 0x1195

    invoke-virtual {v12, v9}, Ltd;->D(Ljava/lang/String;)V

    const/16 v7, 0x7a9

    invoke-static {v11}, Lan1;->b(I)Lym1;

    move-result-object v9

    const/16 v7, 0x5e5

    iput-object v9, v12, Ltd;->d:Ljava/lang/Object;

    if-eqz v10, :cond_7b

    const/4 v9, 0x0

    const/16 v7, 0x3ce

    invoke-static {v10, v9}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v9

    const/16 v7, 0x1211

    iput-object v9, v12, Ltd;->c:Ljava/lang/Object;

    :cond_7b
    const/16 v7, 0x9cf

    invoke-static {}, Lwc2;->a()Lwc2;

    move-result-object v9

    const/16 v7, 0x9d8

    iget-object v15, v9, Lwc2;->d:Lvh2;

    nop

    const/16 v7, 0xacb

    invoke-virtual {v12}, Ltd;->j()Lyg;

    move-result-object v16

    const/16 v7, 0xd45

    new-instance v18, Lu7;

    nop

    const/16 v9, 0xf

    const/16 v7, 0x1080

    move-object/from16 v0, v18

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    invoke-direct {v0, v9, v1, v2}, Lu7;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    const/16 v7, 0x11d9

    iget-object v7, v15, Lvh2;->g:Ljava/lang/Object;

    move-object/16 p0, v7

    check-cast p0, Ljava/util/concurrent/Executor;

    const/16 v7, 0x7ae

    new-instance v14, Lfx;

    nop

    const/16 v19, 0x2

    const/16 v7, 0x84f

    move v0, v7

    move-object v1, v14

    move-object v2, v15

    move-object/from16 v3, v16

    move/from16 v4, v17

    move-object/from16 v5, v18

    move/from16 v6, v19

    invoke-direct/range {v1 .. v6}, Lfx;-><init>(Ljava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;I)V

    const/16 v7, 0x2a2

    move-object/from16 v0, p0

    invoke-interface {v0, v14}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    const/16 p0, 0x1

    return p0
.end method

.method public final onStopJob(Landroid/app/job/JobParameters;)Z
    .registers 4

    const/4 p0, 0x1

    return p0
.end method
