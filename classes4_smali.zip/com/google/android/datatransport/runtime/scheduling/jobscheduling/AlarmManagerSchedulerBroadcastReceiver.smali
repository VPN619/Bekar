.class public Lcom/google/android/datatransport/runtime/scheduling/jobscheduling/AlarmManagerSchedulerBroadcastReceiver;
.super Landroid/content/BroadcastReceiver;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final synthetic a:I


# direct methods
.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .registers 21

    .prologue
    const/16 v7, 0x187

    move-object/from16 v0, p2

    invoke-virtual {v0}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p0

    const-string/jumbo v9, "backendName"

    nop

    nop

    const/16 v7, 0x219

    move-object/from16 v0, p0

    invoke-virtual {v0, v9}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/16 v7, 0x187

    move-object/from16 v0, p2

    invoke-virtual {v0}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v9

    const-string/jumbo v10, "extras"

    nop

    nop

    const/16 v7, 0x219

    invoke-virtual {v9, v10}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const/16 v7, 0x187

    move-object/from16 v0, p2

    invoke-virtual {v0}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v10

    const-string/jumbo v11, "priority"

    nop

    nop

    const/16 v7, 0x219

    invoke-virtual {v10, v11}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const/16 v7, 0x60c

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v10

    const/16 v7, 0x451

    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    move-result v10

    const/16 v7, 0xdf

    move-object/from16 v0, p2

    invoke-virtual {v0}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object p2

    const-string/jumbo v11, "attemptNumber"

    nop

    nop

    const/16 v7, 0x233

    move-object/from16 v0, p2

    invoke-virtual {v0, v11}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v15

    const/16 v7, 0x6e1

    move-object/from16 v0, p1

    invoke-static {v0}, Lwc2;->b(Landroid/content/Context;)V

    const/16 v7, 0xcaf

    invoke-static {}, Lyg;->a()Ltd;

    move-result-object p1

    const/16 v7, 0x1195

    move-object/from16 v0, p1

    move-object/from16 v1, p0

    invoke-virtual {v0, v1}, Ltd;->D(Ljava/lang/String;)V

    const/16 v7, 0x7a9

    invoke-static {v10}, Lan1;->b(I)Lym1;

    move-result-object p0

    const/16 v7, 0x5e5

    move-object/from16 v0, p1

    move-object/from16 v1, p0

    iput-object v1, v0, Ltd;->d:Ljava/lang/Object;

    if-eqz v9, :cond_94

    const/16 p0, 0x0

    const/16 v7, 0x3ce

    move/from16 v0, p0

    invoke-static {v9, v0}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object p0

    const/16 v7, 0x1211

    move-object/from16 v0, p1

    move-object/from16 v1, p0

    iput-object v1, v0, Ltd;->c:Ljava/lang/Object;

    :cond_94
    const/16 v7, 0x9cf

    invoke-static {}, Lwc2;->a()Lwc2;

    move-result-object p0

    const/16 v7, 0x9d8

    move-object/from16 v0, p0

    iget-object v13, v0, Lwc2;->d:Lvh2;

    nop

    const/16 v7, 0xacb

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ltd;->j()Lyg;

    move-result-object v14

    const/16 v7, 0xf67

    new-instance v16, Lw3;

    nop

    const/16 p0, 0x2

    const/16 v7, 0x11c0

    move-object/from16 v0, v16

    move/from16 v1, p0

    invoke-direct {v0, v1}, Lw3;-><init>(I)V

    const/16 v7, 0x11d9

    iget-object v7, v13, Lvh2;->g:Ljava/lang/Object;

    move-object/16 p0, v7

    check-cast p0, Ljava/util/concurrent/Executor;

    const/16 v7, 0x7ae

    new-instance v12, Lfx;

    nop

    const/16 v17, 0x2

    const/16 v7, 0x84f

    move v0, v7

    move-object v1, v12

    move-object v2, v13

    move-object v3, v14

    move v4, v15

    move-object/from16 v5, v16

    move/from16 v6, v17

    invoke-direct/range {v1 .. v6}, Lfx;-><init>(Ljava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;I)V

    const/16 v7, 0x2a2

    move-object/from16 v0, p0

    invoke-interface {v0, v12}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method
