.class public final Lcom/google/android/gms/measurement/AppMeasurementService;
.super Landroid/app/Service;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lcom/google/android/gms/measurement/internal/zzno;


# instance fields
.field public a:Lcom/google/android/gms/measurement/internal/zzns;


# direct methods
.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()Lcom/google/android/gms/measurement/internal/zzns;
    .registers 4

    .prologue
    const/16 v0, 0xdf3

    iget-object v2, p0, Lcom/google/android/gms/measurement/AppMeasurementService;->a:Lcom/google/android/gms/measurement/internal/zzns;

    nop

    if-nez v2, :cond_15

    const/16 v0, 0x885

    new-instance v2, Lcom/google/android/gms/measurement/internal/zzns;

    nop

    const/16 v0, 0x116d

    invoke-direct {v2, p0}, Lcom/google/android/gms/measurement/internal/zzns;-><init>(Landroid/content/Context;)V

    const/16 v0, 0x706

    iput-object v2, p0, Lcom/google/android/gms/measurement/AppMeasurementService;->a:Lcom/google/android/gms/measurement/internal/zzns;

    :cond_15
    check-cast v2, Lcom/google/android/gms/measurement/internal/zzns;

    return-object v2
.end method

.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .registers 4
    .param p1  # Landroid/content/Intent;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/Nullable;
    .end annotation

    const/16 v0, 0x9f0

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/AppMeasurementService;->a()Lcom/google/android/gms/measurement/internal/zzns;

    move-result-object p0

    const/16 v0, 0x104c

    invoke-virtual {p0, p1}, Lcom/google/android/gms/measurement/internal/zzns;->zzd(Landroid/content/Intent;)Landroid/os/IBinder;

    move-result-object p0

    check-cast p0, Landroid/os/IBinder;

    return-object p0
.end method

.method public onCreate()V
    .registers 3

    const/16 v0, 0x1095

    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    const/16 v0, 0x9f0

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/AppMeasurementService;->a()Lcom/google/android/gms/measurement/internal/zzns;

    move-result-object p0

    const/16 v0, 0xbcb

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/internal/zzns;->zza()V

    return-void
.end method

.method public onDestroy()V
    .registers 4

    const/16 v0, 0x9f0

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/AppMeasurementService;->a()Lcom/google/android/gms/measurement/internal/zzns;

    move-result-object v2

    const/16 v0, 0xa17

    invoke-virtual {v2}, Lcom/google/android/gms/measurement/internal/zzns;->zzb()V

    const/16 v0, 0xc0a

    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    return-void
.end method

.method public onRebind(Landroid/content/Intent;)V
    .registers 4
    .param p1  # Landroid/content/Intent;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param

    const/16 v0, 0x9f0

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/AppMeasurementService;->a()Lcom/google/android/gms/measurement/internal/zzns;

    const/16 v0, 0x596

    invoke-static {p1}, Lcom/google/android/gms/measurement/internal/zzns;->zzi(Landroid/content/Intent;)V

    return-void
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .registers 6
    .param p1  # Landroid/content/Intent;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param

    const/16 v0, 0x9f0

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/AppMeasurementService;->a()Lcom/google/android/gms/measurement/internal/zzns;

    move-result-object p0

    const/16 v0, 0xa4e

    invoke-virtual {p0, p1, p2, p3}, Lcom/google/android/gms/measurement/internal/zzns;->zzc(Landroid/content/Intent;II)I

    const/4 p0, 0x2

    return p0
.end method

.method public onUnbind(Landroid/content/Intent;)Z
    .registers 4
    .param p1  # Landroid/content/Intent;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param

    const/16 v0, 0x9f0

    invoke-virtual {p0}, Lcom/google/android/gms/measurement/AppMeasurementService;->a()Lcom/google/android/gms/measurement/internal/zzns;

    const/16 v0, 0xa33

    invoke-static {p1}, Lcom/google/android/gms/measurement/internal/zzns;->zzj(Landroid/content/Intent;)Z

    const/4 p0, 0x1

    return p0
.end method

.method public final zza(I)Z
    .registers 4

    const/16 v0, 0xf73

    invoke-virtual {p0, p1}, Landroid/app/Service;->stopSelfResult(I)Z

    move-result p0

    return p0
.end method

.method public final zzb(Landroid/app/job/JobParameters;Z)V
    .registers 5
    .param p1  # Landroid/app/job/JobParameters;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param

    const/16 v0, 0x1097

    new-instance p0, Ljava/lang/UnsupportedOperationException;

    nop

    const/16 v0, 0x9c5

    invoke-direct {p0}, Ljava/lang/UnsupportedOperationException;-><init>()V

    check-cast p0, Ljava/lang/Throwable;

    throw p0
.end method

.method public final zzc(Landroid/content/Intent;)V
    .registers 4
    .param p1  # Landroid/content/Intent;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param

    const/16 v0, 0xa51

    invoke-static {p1}, Lin2;->completeWakefulIntent(Landroid/content/Intent;)Z

    return-void
.end method
