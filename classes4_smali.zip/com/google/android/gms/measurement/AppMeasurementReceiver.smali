.class public final Lcom/google/android/gms/measurement/AppMeasurementReceiver;
.super Lin2;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lcom/google/android/gms/measurement/internal/zzhk$zza;


# instance fields
.field public c:Lcom/google/android/gms/measurement/internal/zzhk;


# direct methods
.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public doGoAsync()Landroid/content/BroadcastReceiver$PendingResult;
    .registers 3
    .annotation build Landroidx/annotation/NonNull;
    .end annotation

    const/16 v0, 0x576

    invoke-virtual {p0}, Landroid/content/BroadcastReceiver;->goAsync()Landroid/content/BroadcastReceiver$PendingResult;

    move-result-object p0

    check-cast p0, Landroid/content/BroadcastReceiver$PendingResult;

    return-object p0
.end method

.method public doStartService(Landroid/content/Context;Landroid/content/Intent;)V
    .registers 5
    .param p1  # Landroid/content/Context;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p2  # Landroid/content/Intent;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param

    const/16 v0, 0xb3a

    invoke-static {p1, p2}, Lin2;->startWakefulService(Landroid/content/Context;Landroid/content/Intent;)Landroid/content/ComponentName;

    return-void
.end method

.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .registers 6
    .param p1  # Landroid/content/Context;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p2  # Landroid/content/Intent;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param

    .prologue
    const/16 v0, 0xe8b

    iget-object v2, p0, Lcom/google/android/gms/measurement/AppMeasurementReceiver;->c:Lcom/google/android/gms/measurement/internal/zzhk;

    nop

    if-nez v2, :cond_15

    const/16 v0, 0xf18

    new-instance v2, Lcom/google/android/gms/measurement/internal/zzhk;

    nop

    const/16 v0, 0xaa4

    invoke-direct {v2, p0}, Lcom/google/android/gms/measurement/internal/zzhk;-><init>(Lcom/google/android/gms/measurement/internal/zzhk$zza;)V

    const/16 v0, 0xe85

    iput-object v2, p0, Lcom/google/android/gms/measurement/AppMeasurementReceiver;->c:Lcom/google/android/gms/measurement/internal/zzhk;

    :cond_15
    const/16 v0, 0x5fe

    invoke-virtual {v2, p1, p2}, Lcom/google/android/gms/measurement/internal/zzhk;->zza(Landroid/content/Context;Landroid/content/Intent;)V

    return-void
.end method
