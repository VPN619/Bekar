.class public Lcom/google/android/gms/common/api/GoogleApiActivity;
.super Landroid/app/Activity;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/content/DialogInterface$OnCancelListener;


# annotations
.annotation build Lcom/google/android/gms/common/annotation/KeepName;
.end annotation


# instance fields
.field protected zaa:I


# direct methods
.method public constructor <init>()V
    .registers 4

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v2, 0x0

    const/16 v0, 0x180

    iput v2, p0, Lcom/google/android/gms/common/api/GoogleApiActivity;->zaa:I

    return-void
.end method

.method public static zaa(Landroid/content/Context;Landroid/app/PendingIntent;IZ)Landroid/content/Intent;
    .registers 8
    .param p0  # Landroid/content/Context;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .param p1  # Landroid/app/PendingIntent;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/NonNull;
    .end annotation

    const/16 v0, 0x5b

    new-instance v2, Landroid/content/Intent;

    nop

    const-class v3, Lcom/google/android/gms/common/api/GoogleApiActivity;

    const/16 v0, 0xd0

    invoke-direct {v2, p0, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string/jumbo p0, "pending_intent"

    nop

    nop

    const/16 v0, 0x436

    invoke-virtual {v2, p0, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;

    const-string/jumbo p0, "failing_client_id"

    nop

    nop

    const/16 v0, 0x29

    invoke-virtual {v2, p0, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string/jumbo p0, "notify_manager"

    nop

    nop

    const/16 v0, 0x178

    invoke-virtual {v2, p0, p3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    check-cast v2, Landroid/content/Intent;

    return-object v2
.end method


# virtual methods
.method public final onActivityResult(IILandroid/content/Intent;)V
    .registers 9
    .param p3  # Landroid/content/Intent;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param

    .prologue
    const/16 v0, 0xd8d

    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onActivityResult(IILandroid/content/Intent;)V

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-ne p1, v3, :cond_5b

    const/16 v0, 0x28

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const-string/jumbo v4, "notify_manager"

    nop

    nop

    const/16 v0, 0x151

    invoke-virtual {p1, v4, v3}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result p1

    const/16 v0, 0x180

    iput v2, p0, Lcom/google/android/gms/common/api/GoogleApiActivity;->zaa:I

    const/16 v0, 0x3e0

    invoke-virtual {p0, p2, p3}, Landroid/app/Activity;->setResult(ILandroid/content/Intent;)V

    if-eqz p1, :cond_67

    const/16 v0, 0x6bd

    invoke-static {p0}, Lcom/google/android/gms/common/api/internal/GoogleApiManager;->zak(Landroid/content/Context;)Lcom/google/android/gms/common/api/internal/GoogleApiManager;

    move-result-object p1

    const/4 p3, -0x1

    if-eq p2, p3, :cond_55

    if-eqz p2, :cond_31

    goto :goto_67

    :cond_31
    const/16 v0, 0xf86

    new-instance p2, Lcom/google/android/gms/common/ConnectionResult;

    nop

    const/16 v2, 0xd

    const/4 v3, 0x0

    const/16 v0, 0x106b

    invoke-direct {p2, v2, v3}, Lcom/google/android/gms/common/ConnectionResult;-><init>(ILandroid/app/PendingIntent;)V

    const/16 v0, 0x28

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v2

    const-string/jumbo v3, "failing_client_id"

    nop

    nop

    const/16 v0, 0xa8

    invoke-virtual {v2, v3, p3}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p3

    const/16 v0, 0x8f2

    invoke-virtual {p1, p2, p3}, Lcom/google/android/gms/common/api/internal/GoogleApiManager;->zax(Lcom/google/android/gms/common/ConnectionResult;I)V

    goto :goto_67

    :cond_55
    const/16 v0, 0x114b

    invoke-virtual {p1}, Lcom/google/android/gms/common/api/internal/GoogleApiManager;->zay()V

    goto :goto_67

    :cond_5b
    const/4 v3, 0x2

    if-ne p1, v3, :cond_67

    const/16 v0, 0x180

    iput v2, p0, Lcom/google/android/gms/common/api/GoogleApiActivity;->zaa:I

    const/16 v0, 0x3e0

    invoke-virtual {p0, p2, p3}, Landroid/app/Activity;->setResult(ILandroid/content/Intent;)V

    :cond_67
    :goto_67
    const/16 v0, 0x107

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    return-void
.end method

.method public final onCancel(Landroid/content/DialogInterface;)V
    .registers 4
    .param p1  # Landroid/content/DialogInterface;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param

    const/4 p1, 0x0

    const/16 v0, 0x180

    iput p1, p0, Lcom/google/android/gms/common/api/GoogleApiActivity;->zaa:I

    const/16 v0, 0x1245

    invoke-virtual {p0, p1}, Landroid/app/Activity;->setResult(I)V

    const/16 v0, 0x107

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    return-void
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .registers 23
    .param p1  # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    .prologue
    const/16 v8, 0xdef

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-super {v0, v1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    if-eqz p1, :cond_20

    const-string/jumbo v10, "resolution"

    nop

    nop

    const/16 v8, 0x233

    move-object/from16 v0, p1

    invoke-virtual {v0, v10}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result p1

    const/16 v8, 0x180

    move-object/from16 v0, p0

    move/from16 v1, p1

    iput v1, v0, Lcom/google/android/gms/common/api/GoogleApiActivity;->zaa:I

    :cond_20
    const/16 v8, 0x1124

    move-object/from16 v0, p0

    iget v8, v0, Lcom/google/android/gms/common/api/GoogleApiActivity;->zaa:I

    move/16 p1, v8

    const/4 v11, 0x1

    move/from16 v0, p1

    if-eq v0, v11, :cond_179

    const/16 v8, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const/16 v8, 0xdf

    move-object/from16 v0, p1

    invoke-virtual {v0}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object p1

    const-string/jumbo v12, "GoogleApiActivity"

    nop

    nop

    if-nez p1, :cond_53

    const-string/jumbo p1, "Activity started without extras"

    nop

    nop

    nop

    const/16 v8, 0x107

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->finish()V

    return-void

    :cond_53
    const-string/jumbo v10, "pending_intent"

    nop

    nop

    const/16 v8, 0x45b

    move-object/from16 v0, p1

    invoke-virtual {v0, v10}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v10

    move-object v13, v10

    check-cast v13, Landroid/app/PendingIntent;

    const-string/jumbo v10, "error_code"

    nop

    nop

    const/16 v8, 0x45b

    move-object/from16 v0, p1

    invoke-virtual {v0, v10}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/Integer;

    if-nez v13, :cond_85

    if-eqz v10, :cond_77

    goto :goto_85

    :cond_77
    const-string/jumbo p1, "Activity started without resolution"

    nop

    nop

    nop

    const/16 v8, 0x107

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->finish()V

    return-void

    :cond_85
    :goto_85
    if-eqz v13, :cond_14f

    :try_start_87
    const/16 v8, 0xc7

    invoke-virtual {v13}, Landroid/app/PendingIntent;->getIntentSender()Landroid/content/IntentSender;

    move-result-object v15
    :try_end_8d
    .catch Landroid/content/ActivityNotFoundException; {:try_start_87 .. :try_end_8d} :catch_c9
    .catch Landroid/content/IntentSender$SendIntentException; {:try_start_87 .. :try_end_8d} :catch_b8

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v16, 0x1

    const/16 v17, 0x0

    const/16 v18, 0x0

    move-object/from16 v14, p0

    :try_start_99
    const/16 v8, 0x11f7

    move v0, v8

    move-object v1, v14

    move-object v2, v15

    move/from16 v3, v16

    move-object/from16 v4, v17

    move/from16 v5, v18

    move/from16 v6, v19

    move/from16 v7, v20

    invoke-virtual/range {v1 .. v7}, Landroid/app/Activity;->startIntentSenderForResult(Landroid/content/IntentSender;ILandroid/content/Intent;III)V

    const/16 v8, 0x180

    iput v11, v14, Lcom/google/android/gms/common/api/GoogleApiActivity;->zaa:I
    :try_end_af
    .catch Landroid/content/ActivityNotFoundException; {:try_start_99 .. :try_end_af} :catch_b4
    .catch Landroid/content/IntentSender$SendIntentException; {:try_start_99 .. :try_end_af} :catch_b0

    return-void

    :catch_b0
    move-exception v10

    :goto_b1
    move-object/from16 p0, v10

    goto :goto_bc

    :catch_b4
    move-exception v10

    :goto_b5
    move-object/from16 p0, v10

    goto :goto_cd

    :catch_b8
    move-exception v10

    move-object/from16 v14, p0

    goto :goto_b1

    :goto_bc
    const-string/jumbo p1, "Failed to launch pendingIntent"

    nop

    nop

    nop

    const/16 v8, 0x107

    invoke-virtual {v14}, Landroid/app/Activity;->finish()V

    goto/16 :goto_179

    :catch_c9
    move-exception v10

    move-object/from16 v14, p0

    goto :goto_b5

    :goto_cd
    const-string/jumbo v10, "notify_manager"

    nop

    nop

    const/16 v8, 0x428

    move-object/from16 v0, p1

    invoke-virtual {v0, v10, v11}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;Z)Z

    move-result p1

    if-eqz p1, :cond_10d

    const/16 v8, 0x6bd

    invoke-static {v14}, Lcom/google/android/gms/common/api/internal/GoogleApiManager;->zak(Landroid/content/Context;)Lcom/google/android/gms/common/api/internal/GoogleApiManager;

    move-result-object p0

    const/16 v8, 0xf86

    new-instance p1, Lcom/google/android/gms/common/ConnectionResult;

    nop

    const/16 v10, 0x16

    const/4 v12, 0x0

    const/16 v8, 0x106b

    move-object/from16 v0, p1

    invoke-direct {v0, v10, v12}, Lcom/google/android/gms/common/ConnectionResult;-><init>(ILandroid/app/PendingIntent;)V

    const/16 v8, 0x28

    invoke-virtual {v14}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v10

    const-string/jumbo v12, "failing_client_id"

    nop

    nop

    const/4 v13, -0x1

    const/16 v8, 0xa8

    invoke-virtual {v10, v12, v13}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v10

    const/16 v8, 0x8f2

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual {v0, v1, v10}, Lcom/google/android/gms/common/api/internal/GoogleApiManager;->zax(Lcom/google/android/gms/common/ConnectionResult;I)V

    goto :goto_145

    :cond_10d
    const/16 v8, 0xcb

    invoke-virtual {v13}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const-string/jumbo v10, "Activity not found while launching "

    nop

    nop

    const-string/jumbo v13, "."

    nop

    nop

    const/16 v8, 0x6ac

    move-object/from16 v0, p1

    invoke-static {v10, v0, v13}, Lrt2;->i(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/16 v8, 0x729

    sget-object v10, Landroid/os/Build;->FINGERPRINT:Ljava/lang/String;

    nop

    const-string/jumbo v13, "generic"

    nop

    nop

    const/16 v8, 0xd7d

    invoke-virtual {v10, v13}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v10

    if-eqz v10, :cond_144

    const-string/jumbo v10, " This may occur when resolving Google Play services connection issues on emulators with Google APIs but not Google Play Store."

    nop

    nop

    const/16 v8, 0xee

    move-object/from16 v0, p1

    invoke-virtual {v0, v10}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    :cond_144
    nop

    :goto_145
    const/16 v8, 0x180

    iput v11, v14, Lcom/google/android/gms/common/api/GoogleApiActivity;->zaa:I

    const/16 v8, 0x107

    invoke-virtual {v14}, Landroid/app/Activity;->finish()V

    goto :goto_179

    :cond_14f
    move-object/from16 v14, p0

    const/16 v8, 0x6c9

    invoke-static {v10}, Lcom/google/android/gms/common/internal/Preconditions;->checkNotNull(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Ljava/lang/Integer;

    const/16 v8, 0x451

    move-object/from16 v0, p0

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    const/16 v8, 0x1023

    invoke-static {}, Lcom/google/android/gms/common/GoogleApiAvailability;->getInstance()Lcom/google/android/gms/common/GoogleApiAvailability;

    move-result-object p1

    const/4 v10, 0x2

    const/16 v8, 0x73c

    move v0, v8

    move-object/from16 v1, p1

    move-object v2, v14

    move/from16 v3, p0

    move v4, v10

    move-object v5, v14

    invoke-virtual/range {v1 .. v5}, Lcom/google/android/gms/common/GoogleApiAvailability;->showErrorDialogFragment(Landroid/app/Activity;IILandroid/content/DialogInterface$OnCancelListener;)Z

    const/16 v8, 0x180

    iput v11, v14, Lcom/google/android/gms/common/api/GoogleApiActivity;->zaa:I

    :cond_179
    :goto_179
    return-void
.end method

.method public final onSaveInstanceState(Landroid/os/Bundle;)V
    .registers 6
    .param p1  # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param

    const-string/jumbo v2, "resolution"

    nop

    nop

    const/16 v0, 0x1124

    iget v3, p0, Lcom/google/android/gms/common/api/GoogleApiActivity;->zaa:I

    nop

    const/16 v0, 0x23e

    invoke-virtual {p1, v2, v3}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/16 v0, 0x100a

    invoke-super {p0, p1}, Landroid/app/Activity;->onSaveInstanceState(Landroid/os/Bundle;)V

    return-void
.end method
