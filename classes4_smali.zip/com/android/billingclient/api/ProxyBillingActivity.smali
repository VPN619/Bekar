.class public Lcom/android/billingclient/api/ProxyBillingActivity;
.super Landroid/app/Activity;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation build Lcom/android/billingclient/api/zzw;
.end annotation

.annotation build Lcom/google/android/apps/common/proguard/UsedByReflection;
    value = "PlatformActivityProxy"
.end annotation


# static fields
.field static final EXTERNAL_BROADCAST_PERMISSION:Ljava/lang/String;

.field private static final KEY_ACTIVITY_CODE:Ljava/lang/String;

.field static final KEY_IN_APP_MESSAGE_RESULT_RECEIVER:Ljava/lang/String;

.field private static final KEY_SEND_CANCELLED_BROADCAST_IF_FINISHED:Ljava/lang/String;

.field private static final REQUEST_CODE_FIRST_PARTY_PURCHASE_FLOW:I = 0x6e

.field private static final REQUEST_CODE_IN_APP_MESSAGE_FLOW:I = 0x65

.field private static final REQUEST_CODE_LAUNCH_ACTIVITY:I = 0x64

.field static final RESULT_CODE_PLAY_CANCELED_WITH_ON_CREATE_RUNTIME_EXCEPTION:I = 0x5

.field static final RESULT_CODE_PLAY_CANCELLED:I = 0x3

.field static final RESULT_CODE_PLAY_CANCELLED_WITHOUT_COMPLETE_ACTION:I = 0x4

.field private static final TAG:Ljava/lang/String;


# instance fields
.field private activityCode:I

.field private billingClientTransactionId:J

.field billingLogger:Lcom/android/billingclient/api/zzdd;
    .annotation build Landroidx/annotation/Nullable;
    .end annotation
.end field

.field private inAppMessageResultReceiver:Landroid/os/ResultReceiver;
    .annotation build Landroidx/annotation/Nullable;
    .end annotation
.end field

.field private isFlowFromFirstPartyClient:Z

.field proxyBillingBroadcastReceiver:Lcom/android/billingclient/api/zzej;
    .annotation build Landroidx/annotation/Nullable;
    .end annotation
.end field

.field private sendCancelledBroadcastIfFinished:Z

.field private wasServiceAutoReconnected:Z


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-string/jumbo v0, "in_app_message_result_receiver"

    nop

    nop

    sput-object v0, Lcom/android/billingclient/api/ProxyBillingActivity;->KEY_IN_APP_MESSAGE_RESULT_RECEIVER:Ljava/lang/String;

    const-string/jumbo v0, "com.google.android.finsky.permission.PLAY_BILLING_LIBRARY_BROADCAST"

    nop

    nop

    sput-object v0, Lcom/android/billingclient/api/ProxyBillingActivity;->EXTERNAL_BROADCAST_PERMISSION:Ljava/lang/String;

    const-string/jumbo v0, "ProxyBillingActivity"

    nop

    nop

    sput-object v0, Lcom/android/billingclient/api/ProxyBillingActivity;->TAG:Ljava/lang/String;

    const-string/jumbo v0, "activity_code"

    nop

    nop

    sput-object v0, Lcom/android/billingclient/api/ProxyBillingActivity;->KEY_ACTIVITY_CODE:Ljava/lang/String;

    const-string/jumbo v0, "send_cancelled_broadcast_if_finished"

    nop

    nop

    sput-object v0, Lcom/android/billingclient/api/ProxyBillingActivity;->KEY_SEND_CANCELLED_BROADCAST_IF_FINISHED:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    return-void
.end method

.method private getLoggingErrorReason(ILandroid/content/Intent;)Lcom/google/android/gms/internal/play_billing/zzjs;
    .registers 5
    .param p2  # Landroid/content/Intent;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    .prologue
    if-nez p2, :cond_35

    const/4 p0, -0x1

    if-eq p1, p0, :cond_2d

    if-eqz p1, :cond_25

    const/4 p0, 0x3

    if-eq p1, p0, :cond_1d

    const/4 p0, 0x4

    if-eq p1, p0, :cond_15

    const/16 v0, 0xcfb

    sget-object p0, Lcom/google/android/gms/internal/play_billing/zzjs;->zzbm:Lcom/google/android/gms/internal/play_billing/zzjs;

    nop

    check-cast p0, Lcom/google/android/gms/internal/play_billing/zzjs;

    return-object p0

    :cond_15
    const/16 v0, 0x9d4

    sget-object p0, Lcom/google/android/gms/internal/play_billing/zzjs;->zzbl:Lcom/google/android/gms/internal/play_billing/zzjs;

    nop

    check-cast p0, Lcom/google/android/gms/internal/play_billing/zzjs;

    return-object p0

    :cond_1d
    const/16 v0, 0xac3

    sget-object p0, Lcom/google/android/gms/internal/play_billing/zzjs;->zzbk:Lcom/google/android/gms/internal/play_billing/zzjs;

    nop

    check-cast p0, Lcom/google/android/gms/internal/play_billing/zzjs;

    return-object p0

    :cond_25
    const/16 v0, 0x575

    sget-object p0, Lcom/google/android/gms/internal/play_billing/zzjs;->zzbj:Lcom/google/android/gms/internal/play_billing/zzjs;

    nop

    check-cast p0, Lcom/google/android/gms/internal/play_billing/zzjs;

    return-object p0

    :cond_2d
    const/16 v0, 0xbc0

    sget-object p0, Lcom/google/android/gms/internal/play_billing/zzjs;->zzbi:Lcom/google/android/gms/internal/play_billing/zzjs;

    nop

    check-cast p0, Lcom/google/android/gms/internal/play_billing/zzjs;

    return-object p0

    :cond_35
    const/16 v0, 0xdf

    invoke-virtual {p2}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object p0

    if-nez p0, :cond_45

    const/16 v0, 0x1087

    sget-object p0, Lcom/google/android/gms/internal/play_billing/zzjs;->zzv:Lcom/google/android/gms/internal/play_billing/zzjs;

    nop

    check-cast p0, Lcom/google/android/gms/internal/play_billing/zzjs;

    return-object p0

    :cond_45
    const/4 p0, 0x5

    if-ne p1, p0, :cond_50

    const/16 v0, 0xedf

    sget-object p0, Lcom/google/android/gms/internal/play_billing/zzjs;->zzbI:Lcom/google/android/gms/internal/play_billing/zzjs;

    nop

    check-cast p0, Lcom/google/android/gms/internal/play_billing/zzjs;

    return-object p0

    :cond_50
    const/16 v0, 0x615

    sget-object p0, Lcom/google/android/gms/internal/play_billing/zzjs;->zza:Lcom/google/android/gms/internal/play_billing/zzjs;

    nop

    check-cast p0, Lcom/google/android/gms/internal/play_billing/zzjs;

    return-object p0
.end method

.method private isInAppMessageFlow(Landroid/os/Bundle;)Z
    .registers 4
    .param p1  # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    .prologue
    if-nez p1, :cond_1e

    const/16 v0, 0x28

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    if-nez p1, :cond_c

    const/4 p0, 0x0

    return p0

    :cond_c
    const/16 v0, 0x28

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p0

    const-string/jumbo p1, "IN_APP_MESSAGE_INTENT"

    nop

    nop

    const/16 v0, 0xb2

    invoke-virtual {p0, p1}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result p0

    return p0

    :cond_1e
    const-string/jumbo p0, "in_app_message_result_receiver"

    nop

    nop

    const/16 v0, 0x9c

    invoke-virtual {p1, p0}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result p0

    return p0
.end method

.method private isKnownError(ILandroid/content/Intent;)Z
    .registers 5
    .param p2  # Landroid/content/Intent;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    .prologue
    const/16 v0, 0xe23

    invoke-direct {p0, p1, p2}, Lcom/android/billingclient/api/ProxyBillingActivity;->getLoggingErrorReason(ILandroid/content/Intent;)Lcom/google/android/gms/internal/play_billing/zzjs;

    move-result-object p0

    const/16 v0, 0x615

    sget-object p1, Lcom/google/android/gms/internal/play_billing/zzjs;->zza:Lcom/google/android/gms/internal/play_billing/zzjs;

    nop

    const/16 v0, 0x128

    invoke-virtual {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_15

    const/4 p0, 0x1

    return p0

    :cond_15
    const/4 p0, 0x0

    return p0
.end method

.method private isProxyBillingBroadcastReceiverRegistered()Z
    .registers 3

    .prologue
    const/16 v1, 0x20a

    iget-object p0, p0, Lcom/android/billingclient/api/ProxyBillingActivity;->proxyBillingBroadcastReceiver:Lcom/android/billingclient/api/zzej;

    nop

    if-eqz p0, :cond_9

    const/4 p0, 0x1

    return p0

    :cond_9
    const/4 p0, 0x0

    return p0
.end method

.method private makeAlternativeBillingIntent(Ljava/lang/String;)Landroid/content/Intent;
    .registers 6

    const/16 v0, 0x5b

    new-instance v2, Landroid/content/Intent;

    nop

    const-string/jumbo v3, "com.android.vending.billing.ALTERNATIVE_BILLING"

    nop

    nop

    const/16 v0, 0x62

    invoke-direct {v2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/16 v0, 0x4a

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x64

    invoke-virtual {v2, p0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const-string/jumbo p0, "ALTERNATIVE_BILLING_USER_CHOICE_DATA"

    nop

    nop

    const/16 v0, 0x4b

    invoke-virtual {v2, p0, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    check-cast v2, Landroid/content/Intent;

    return-object v2
.end method

.method private makePurchaseUpdatedIntentWithResponseCodeAndReason(Lcom/google/android/gms/internal/play_billing/zzjs;JZ)Landroid/content/Intent;
    .registers 19

    .prologue
    const/16 v6, 0x11fc

    invoke-direct {p0}, Lcom/android/billingclient/api/ProxyBillingActivity;->makePurchasesUpdatedIntent()Landroid/content/Intent;

    move-result-object v8

    const-string/jumbo v9, "FAILURE_LOGGING_PAYLOAD"

    nop

    nop

    const/4 v10, 0x0

    const/4 v11, 0x2

    const-string/jumbo v12, "DEBUG_MESSAGE"

    nop

    nop

    const-string/jumbo v13, "RESPONSE_CODE"

    nop

    nop

    if-eqz p4, :cond_c2

    const/16 v6, 0x49a

    invoke-direct {p0}, Lcom/android/billingclient/api/ProxyBillingActivity;->isProxyBillingBroadcastReceiverRegistered()Z

    move-result p4

    if-eqz p4, :cond_57

    const/16 v6, 0x20a

    iget-object v6, p0, Lcom/android/billingclient/api/ProxyBillingActivity;->proxyBillingBroadcastReceiver:Lcom/android/billingclient/api/zzej;

    move-object/16 p4, v6

    const/16 v6, 0x40b

    move-object/from16 v0, p4

    invoke-virtual {v0}, Lcom/android/billingclient/api/zzej;->zza()Lcom/android/billingclient/api/BillingResult;

    move-result-object p4

    if-eqz p4, :cond_57

    const/16 v6, 0x20a

    iget-object p1, p0, Lcom/android/billingclient/api/ProxyBillingActivity;->proxyBillingBroadcastReceiver:Lcom/android/billingclient/api/zzej;

    nop

    const/16 v6, 0x40b

    invoke-virtual {p1}, Lcom/android/billingclient/api/zzej;->zza()Lcom/android/billingclient/api/BillingResult;

    move-result-object p1

    const/16 v6, 0x450

    invoke-virtual {p1}, Lcom/android/billingclient/api/BillingResult;->getResponseCode()I

    move-result p4

    const/16 v6, 0x29

    move/from16 v0, p4

    invoke-virtual {v8, v13, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/16 v6, 0xd07

    invoke-virtual {p1}, Lcom/android/billingclient/api/BillingResult;->getDebugMessage()Ljava/lang/String;

    move-result-object p1

    const/16 v6, 0x4b

    invoke-virtual {v8, v12, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    goto/16 :goto_10f

    :cond_57
    const/16 v6, 0x49a

    invoke-direct {p0}, Lcom/android/billingclient/api/ProxyBillingActivity;->isProxyBillingBroadcastReceiverRegistered()Z

    move-result p4

    if-eqz p4, :cond_c2

    const/16 v6, 0x20a

    iget-object v6, p0, Lcom/android/billingclient/api/ProxyBillingActivity;->proxyBillingBroadcastReceiver:Lcom/android/billingclient/api/zzej;

    move-object/16 p4, v6

    const/16 v6, 0x569

    move-object/from16 v0, p4

    invoke-virtual {v0}, Lcom/android/billingclient/api/zzej;->zzc()Z

    move-result p4

    if-nez p4, :cond_c2

    const/4 p1, 0x3

    const/16 v6, 0x29

    invoke-virtual {v8, v13, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string/jumbo p4, "Play Store is blocked."

    nop

    nop

    const/16 v6, 0x4b

    move-object/from16 v0, p4

    invoke-virtual {v8, v12, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/16 v6, 0x2c6

    invoke-static {}, Lcom/android/billingclient/api/BillingResult;->newBuilder()Lcom/android/billingclient/api/BillingResult$Builder;

    move-result-object v12

    const/16 v6, 0x361

    invoke-virtual {v12, p1}, Lcom/android/billingclient/api/BillingResult$Builder;->setResponseCode(I)Lcom/android/billingclient/api/BillingResult$Builder;

    const/16 v6, 0x4bf

    move-object/from16 v0, p4

    invoke-virtual {v12, v0}, Lcom/android/billingclient/api/BillingResult$Builder;->setDebugMessage(Ljava/lang/String;)Lcom/android/billingclient/api/BillingResult$Builder;

    const/16 v6, 0x2dd

    invoke-virtual {v12}, Lcom/android/billingclient/api/BillingResult$Builder;->build()Lcom/android/billingclient/api/BillingResult;

    move-result-object p1

    const/16 v6, 0x555

    sget-object p4, Lcom/google/android/gms/internal/play_billing/zzjs;->zzbL:Lcom/google/android/gms/internal/play_billing/zzjs;

    nop

    const/16 v6, 0x384

    sget v12, Lcom/android/billingclient/api/zzdc;->zza:I

    nop

    const/16 v6, 0x4c3

    sget-object v12, Lcom/google/android/gms/internal/play_billing/zzjz;->zza:Lcom/google/android/gms/internal/play_billing/zzjz;

    nop

    const/16 v6, 0x28e

    move v0, v6

    move-object/from16 v1, p4

    move v2, v11

    move-object v3, p1

    move-object v4, v10

    move-object v5, v12

    invoke-static/range {v1 .. v5}, Lcom/android/billingclient/api/zzdc;->zzb(Lcom/google/android/gms/internal/play_billing/zzjs;ILcom/android/billingclient/api/BillingResult;Ljava/lang/String;Lcom/google/android/gms/internal/play_billing/zzjz;)Lcom/google/android/gms/internal/play_billing/zzjl;

    move-result-object p1

    const/16 v6, 0x4c9

    invoke-virtual {p1}, Lcom/google/android/gms/internal/play_billing/zzfa;->zzQ()[B

    move-result-object p1

    const/16 v6, 0x2d4

    invoke-virtual {v8, v9, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[B)Landroid/content/Intent;

    goto :goto_10f

    :cond_c2
    const/16 p4, 0x6

    const/16 v6, 0x29

    move/from16 v0, p4

    invoke-virtual {v8, v13, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string/jumbo v13, "An internal error occurred."

    nop

    nop

    const/16 v6, 0x4b

    invoke-virtual {v8, v12, v13}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/16 v6, 0x2c6

    invoke-static {}, Lcom/android/billingclient/api/BillingResult;->newBuilder()Lcom/android/billingclient/api/BillingResult$Builder;

    move-result-object v12

    const/16 v6, 0x361

    move/from16 v0, p4

    invoke-virtual {v12, v0}, Lcom/android/billingclient/api/BillingResult$Builder;->setResponseCode(I)Lcom/android/billingclient/api/BillingResult$Builder;

    const/16 v6, 0x4bf

    invoke-virtual {v12, v13}, Lcom/android/billingclient/api/BillingResult$Builder;->setDebugMessage(Ljava/lang/String;)Lcom/android/billingclient/api/BillingResult$Builder;

    const/16 v6, 0x2dd

    invoke-virtual {v12}, Lcom/android/billingclient/api/BillingResult$Builder;->build()Lcom/android/billingclient/api/BillingResult;

    move-result-object p4

    const/16 v6, 0x384

    sget v12, Lcom/android/billingclient/api/zzdc;->zza:I

    nop

    const/16 v6, 0x4c3

    sget-object v12, Lcom/google/android/gms/internal/play_billing/zzjz;->zza:Lcom/google/android/gms/internal/play_billing/zzjz;

    nop

    const/16 v6, 0x28e

    move v0, v6

    move-object v1, p1

    move v2, v11

    move-object/from16 v3, p4

    move-object v4, v10

    move-object v5, v12

    invoke-static/range {v1 .. v5}, Lcom/android/billingclient/api/zzdc;->zzb(Lcom/google/android/gms/internal/play_billing/zzjs;ILcom/android/billingclient/api/BillingResult;Ljava/lang/String;Lcom/google/android/gms/internal/play_billing/zzjz;)Lcom/google/android/gms/internal/play_billing/zzjl;

    move-result-object p1

    const/16 v6, 0x4c9

    invoke-virtual {p1}, Lcom/google/android/gms/internal/play_billing/zzfa;->zzQ()[B

    move-result-object p1

    const/16 v6, 0x2d4

    invoke-virtual {v8, v9, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[B)Landroid/content/Intent;

    :goto_10f
    const-string/jumbo p1, "INTENT_SOURCE"

    nop

    nop

    const-string/jumbo p4, "LAUNCH_BILLING_FLOW"

    nop

    nop

    const/16 v6, 0x4b

    move-object/from16 v0, p4

    invoke-virtual {v8, p1, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string/jumbo p1, "billingClientTransactionId"

    nop

    nop

    const/16 v6, 0xba

    move-wide/from16 v0, p2

    invoke-virtual {v8, p1, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/16 v6, 0x796

    iget-boolean p0, p0, Lcom/android/billingclient/api/ProxyBillingActivity;->wasServiceAutoReconnected:Z

    nop

    const-string/jumbo p1, "wasServiceAutoReconnected"

    nop

    nop

    const/16 v6, 0x178

    invoke-virtual {v8, p1, p0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    check-cast v8, Landroid/content/Intent;

    return-object v8
.end method

.method private makePurchasesUpdatedIntent()Landroid/content/Intent;
    .registers 5

    const/16 v0, 0x5b

    new-instance v2, Landroid/content/Intent;

    nop

    const-string/jumbo v3, "com.android.vending.billing.LOCAL_BROADCAST_PURCHASES_UPDATED"

    nop

    nop

    const/16 v0, 0x62

    invoke-direct {v2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/16 v0, 0x4a

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x64

    invoke-virtual {v2, p0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    check-cast v2, Landroid/content/Intent;

    return-object v2
.end method

.method private declared-synchronized registerProxyBillingBroadcastReceiver()V
    .registers 18

    .prologue
    monitor-enter p0

    :try_start_1
    const/16 v7, 0x123c

    new-instance v9, Lcom/android/billingclient/api/zzej;

    nop

    const/16 v7, 0x3c1

    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/android/billingclient/api/ProxyBillingActivity;->billingLogger:Lcom/android/billingclient/api/zzdd;

    nop

    const/16 v7, 0xae5

    invoke-direct {v9, v10}, Lcom/android/billingclient/api/zzej;-><init>(Lcom/android/billingclient/api/zzdd;)V

    const/16 v7, 0x49f

    move-object/from16 v0, p0

    iput-object v9, v0, Lcom/android/billingclient/api/ProxyBillingActivity;->proxyBillingBroadcastReceiver:Lcom/android/billingclient/api/zzej;

    const/16 v7, 0x1f

    new-instance v13, Landroid/content/IntentFilter;

    nop

    const-string/jumbo v9, "com.android.vending.billing.IN_APP_BILLING_RESULT_UPDATE_ACTION"

    nop

    nop

    const/16 v7, 0x1d

    invoke-direct {v13, v9}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const-string/jumbo v9, "com.android.vending.billing.PLAY_BILLING_ACTIVITY_CREATED_ACTION"

    nop

    nop

    const/16 v7, 0xc1f

    invoke-virtual {v13, v9}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/16 v7, 0x20a

    move-object/from16 v0, p0

    iget-object v12, v0, Lcom/android/billingclient/api/ProxyBillingActivity;->proxyBillingBroadcastReceiver:Lcom/android/billingclient/api/zzej;

    nop

    const-string/jumbo v14, "com.google.android.finsky.permission.PLAY_BILLING_LIBRARY_BROADCAST"

    nop

    nop
    :try_end_3d
    .catch Ljava/lang/RuntimeException; {:try_start_1 .. :try_end_3d} :catch_63
    .catch Ljava/lang/NoSuchMethodError; {:try_start_1 .. :try_end_3d} :catch_5f
    .catchall {:try_start_1 .. :try_end_3d} :catchall_5b

    const/4 v15, 0x0

    const/16 v16, 0x2

    move-object/from16 v11, p0

    :try_start_42
    const/16 v7, 0xdfc

    move v0, v7

    move-object v1, v11

    move-object v2, v12

    move-object v3, v13

    move-object v4, v14

    move-object v5, v15

    move/from16 v6, v16

    invoke-static/range {v1 .. v6}, Lqx;->registerReceiver(Landroid/content/Context;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Ljava/lang/String;Landroid/os/Handler;I)Landroid/content/Intent;
    :try_end_4f
    .catch Ljava/lang/RuntimeException; {:try_start_42 .. :try_end_4f} :catch_59
    .catch Ljava/lang/NoSuchMethodError; {:try_start_42 .. :try_end_4f} :catch_55
    .catchall {:try_start_42 .. :try_end_4f} :catchall_51

    monitor-exit v11

    return-void

    :catchall_51
    move-exception v9

    :goto_52
    move-object/from16 p0, v9

    goto :goto_bb

    :catch_55
    move-exception v9

    :goto_56
    move-object/from16 p0, v9

    goto :goto_65

    :catch_59
    move-exception v9

    goto :goto_56

    :catchall_5b
    move-exception v9

    move-object/from16 v11, p0

    goto :goto_52

    :catch_5f
    move-exception v9

    :goto_60
    move-object/from16 v11, p0

    goto :goto_56

    :catch_63
    move-exception v9

    goto :goto_60

    :goto_65
    const/4 v9, 0x0

    :try_start_66
    const/16 v7, 0x49f

    iput-object v9, v11, Lcom/android/billingclient/api/ProxyBillingActivity;->proxyBillingBroadcastReceiver:Lcom/android/billingclient/api/zzej;

    move-object/from16 v0, p0

    instance-of v9, v0, Ljava/lang/NoSuchMethodError;
    :try_end_6e
    .catchall {:try_start_66 .. :try_end_6e} :catchall_51

    const/16 v7, 0x3c1

    iget-object v10, v11, Lcom/android/billingclient/api/ProxyBillingActivity;->billingLogger:Lcom/android/billingclient/api/zzdd;

    nop

    if-eqz v9, :cond_8f

    :try_start_75
    const/16 v7, 0x423

    invoke-static {}, Lcom/google/android/gms/internal/play_billing/zzld;->zza()Lcom/google/android/gms/internal/play_billing/zzla;

    move-result-object v9

    const/4 v12, 0x2

    const/16 v7, 0x387

    invoke-virtual {v9, v12}, Lcom/google/android/gms/internal/play_billing/zzla;->zza(I)Lcom/google/android/gms/internal/play_billing/zzla;

    const/16 v7, 0x32a

    invoke-virtual {v9}, Lcom/google/android/gms/internal/play_billing/zzgl;->zzi()Lcom/google/android/gms/internal/play_billing/zzgp;

    move-result-object v9

    check-cast v9, Lcom/google/android/gms/internal/play_billing/zzld;

    const/16 v7, 0x46c

    invoke-interface {v10, v9}, Lcom/android/billingclient/api/zzdd;->zzl(Lcom/google/android/gms/internal/play_billing/zzld;)V

    goto :goto_a8

    :cond_8f
    const/16 v7, 0x423

    invoke-static {}, Lcom/google/android/gms/internal/play_billing/zzld;->zza()Lcom/google/android/gms/internal/play_billing/zzla;

    move-result-object v9

    const/4 v12, 0x1

    const/16 v7, 0x387

    invoke-virtual {v9, v12}, Lcom/google/android/gms/internal/play_billing/zzla;->zza(I)Lcom/google/android/gms/internal/play_billing/zzla;

    const/16 v7, 0x32a

    invoke-virtual {v9}, Lcom/google/android/gms/internal/play_billing/zzgl;->zzi()Lcom/google/android/gms/internal/play_billing/zzgp;

    move-result-object v9

    check-cast v9, Lcom/google/android/gms/internal/play_billing/zzld;

    const/16 v7, 0x46c

    invoke-interface {v10, v9}, Lcom/android/billingclient/api/zzdd;->zzl(Lcom/google/android/gms/internal/play_billing/zzld;)V

    :goto_a8
    const-string/jumbo v9, "ProxyBillingActivity"

    nop

    nop

    const-string/jumbo v10, "Failed to register receiver."

    nop

    nop

    const/16 v7, 0x34e

    move-object/from16 v0, p0

    invoke-static {v9, v10, v0}, Lcom/google/android/gms/internal/play_billing/zzc;->zzo(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_b9
    .catchall {:try_start_75 .. :try_end_b9} :catchall_51

    monitor-exit v11

    return-void

    :goto_bb
    :try_start_bb
    monitor-exit v11
    :try_end_bc
    .catchall {:try_start_bb .. :try_end_bc} :catchall_51

    throw p0
.end method


# virtual methods
.method public onActivityResult(IILandroid/content/Intent;)V
    .registers 20
    .param p3  # Landroid/content/Intent;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param
    .annotation build Lcom/android/billingclient/api/zzw;
    .end annotation

    .prologue
    const/16 v6, 0xd8d

    move-object/from16 v0, p0

    move/from16 v1, p1

    move/from16 v2, p2

    move-object/from16 v3, p3

    invoke-super {v0, v1, v2, v3}, Landroid/app/Activity;->onActivityResult(IILandroid/content/Intent;)V

    const/16 v8, 0x64

    const/16 v9, 0x6e

    const/4 v10, 0x1

    const/4 v11, 0x0

    const-string/jumbo v12, "ProxyBillingActivity"

    nop

    nop

    move/from16 v0, p1

    if-eq v0, v8, :cond_b1

    move/from16 v0, p1

    if-ne v0, v9, :cond_28

    if-nez p3, :cond_25

    :goto_22
    move v8, v11

    goto/16 :goto_b5

    :cond_25
    move v8, v10

    goto/16 :goto_b5

    :cond_28
    const/16 p2, 0x65

    move/from16 v0, p1

    move/from16 v1, p2

    if-ne v0, v1, :cond_79

    const/16 v6, 0x7f8

    sget p1, Lcom/google/android/gms/internal/play_billing/zzc;->zza:I

    nop

    const/16 p1, 0x0

    if-nez p3, :cond_4a

    const-string/jumbo p2, "Got null intent!"

    nop

    nop

    const/16 v6, 0xe3

    move-object/from16 v0, p2

    invoke-static {v12, v0}, Lcom/google/android/gms/internal/play_billing/zzc;->zzn(Ljava/lang/String;Ljava/lang/String;)V

    move-object/from16 p3, p1

    move/from16 p2, v11

    goto :goto_5a

    :cond_4a
    const/16 v6, 0xdf

    move-object/from16 v0, p3

    invoke-virtual {v0}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object p2

    const/16 v6, 0x10c7

    move-object/from16 v0, p2

    invoke-static {v0, v12}, Lcom/google/android/gms/internal/play_billing/zzc;->zza(Landroid/os/Bundle;Ljava/lang/String;)I

    move-result p2

    :goto_5a
    const/16 v6, 0xbd9

    move-object/from16 v0, p0

    iget-object v8, v0, Lcom/android/billingclient/api/ProxyBillingActivity;->inAppMessageResultReceiver:Landroid/os/ResultReceiver;

    nop

    if-eqz v8, :cond_212

    if-nez p3, :cond_66

    goto :goto_6e

    :cond_66
    const/16 v6, 0xdf

    move-object/from16 v0, p3

    invoke-virtual {v0}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object p1

    :goto_6e
    const/16 v6, 0x3e4

    move/from16 v0, p2

    move-object/from16 v1, p1

    invoke-virtual {v8, v0, v1}, Landroid/os/ResultReceiver;->send(ILandroid/os/Bundle;)V

    goto/16 :goto_212

    :cond_79
    const/4 v6, -0x3

    new-instance p2, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo p3, "Got onActivityResult with wrong requestCode: "

    nop

    nop

    const/16 v6, 0x97

    move-object/from16 v0, p2

    move-object/from16 v1, p3

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v6, 0x33

    move-object/from16 v0, p2

    move/from16 v1, p1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo p1, "; skipping..."

    nop

    nop

    const/4 v6, 0x0

    move-object/from16 v0, p2

    move-object/from16 v1, p1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, -0x2

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/16 v6, 0xe3

    move-object/from16 v0, p1

    invoke-static {v12, v0}, Lcom/google/android/gms/internal/play_billing/zzc;->zzn(Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_212

    :cond_b1
    if-nez p3, :cond_25

    goto/16 :goto_22

    :goto_b5
    const/16 v6, 0x7b2

    move-object/from16 v0, p3

    invoke-static {v0, v12}, Lcom/google/android/gms/internal/play_billing/zzc;->zzi(Landroid/content/Intent;Ljava/lang/String;)Lcom/android/billingclient/api/BillingResult;

    move-result-object v13

    const/16 v6, 0x450

    invoke-virtual {v13}, Lcom/android/billingclient/api/BillingResult;->getResponseCode()I

    move-result v13

    const/4 v14, -0x1

    move/from16 v0, p2

    if-ne v0, v14, :cond_cc

    if-eqz v13, :cond_fb

    move/from16 p2, v14

    :cond_cc
    const/4 v6, -0x3

    new-instance v14, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v15, "Activity finished with resultCode "

    nop

    nop

    const/16 v6, 0x97

    invoke-direct {v14, v15}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v6, 0x33

    move/from16 v0, p2

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v15, " and billing\'s responseCode: "

    nop

    nop

    const/4 v6, 0x0

    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v6, 0x33

    invoke-virtual {v14, v13}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, -0x2

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v13

    const/16 v6, 0xe3

    invoke-static {v12, v13}, Lcom/google/android/gms/internal/play_billing/zzc;->zzn(Ljava/lang/String;Ljava/lang/String;)V

    move/from16 v14, p2

    :cond_fb
    if-eq v10, v8, :cond_12e

    const/4 v6, -0x3

    new-instance p2, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v8, "Got null data with resultCode "

    nop

    nop

    const/16 v6, 0x97

    move-object/from16 v0, p2

    invoke-direct {v0, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v6, 0x33

    move-object/from16 v0, p2

    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v8, "!"

    nop

    nop

    const/4 v6, 0x0

    move-object/from16 v0, p2

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, -0x2

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/16 v6, 0xe3

    move-object/from16 v0, p2

    invoke-static {v12, v0}, Lcom/google/android/gms/internal/play_billing/zzc;->zzn(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_144

    :cond_12e
    const/16 v6, 0xdf

    move-object/from16 v0, p3

    invoke-virtual {v0}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object p2

    if-nez p2, :cond_144

    const-string/jumbo p2, "Got null bundle!"

    nop

    nop

    const/16 v6, 0xe3

    move-object/from16 v0, p2

    invoke-static {v12, v0}, Lcom/google/android/gms/internal/play_billing/zzc;->zzn(Ljava/lang/String;Ljava/lang/String;)V

    :cond_144
    :goto_144
    const/16 v6, 0xd2b

    move-object/from16 v0, p0

    move-object/from16 v1, p3

    invoke-direct {v0, v14, v1}, Lcom/android/billingclient/api/ProxyBillingActivity;->isKnownError(ILandroid/content/Intent;)Z

    move-result p2

    if-eqz p2, :cond_178

    const/16 v6, 0xe23

    move-object/from16 v0, p0

    move-object/from16 v1, p3

    invoke-direct {v0, v14, v1}, Lcom/android/billingclient/api/ProxyBillingActivity;->getLoggingErrorReason(ILandroid/content/Intent;)Lcom/google/android/gms/internal/play_billing/zzjs;

    move-result-object p2

    const/16 v6, 0x2d2

    move-object/from16 v0, p0

    iget-wide v12, v0, Lcom/android/billingclient/api/ProxyBillingActivity;->billingClientTransactionId:J

    nop

    if-nez p3, :cond_166

    move/from16 p3, v10

    goto :goto_168

    :cond_166
    move/from16 p3, v11

    :goto_168
    const/16 v6, 0x8bb

    move v0, v6

    move-object/from16 v1, p0

    move-object/from16 v2, p2

    move-wide v3, v12

    move/from16 v5, p3

    invoke-direct/range {v1 .. v5}, Lcom/android/billingclient/api/ProxyBillingActivity;->makePurchaseUpdatedIntentWithResponseCodeAndReason(Lcom/google/android/gms/internal/play_billing/zzjs;JZ)Landroid/content/Intent;

    move-result-object p2

    goto/16 :goto_1f7

    :cond_178
    const/16 v6, 0xdf

    move-object/from16 v0, p3

    invoke-virtual {v0}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object p2

    const-string/jumbo v8, "ALTERNATIVE_BILLING_USER_CHOICE_DATA"

    nop

    nop

    const/16 v6, 0x183

    move-object/from16 v0, p2

    invoke-virtual {v0, v8}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const-string/jumbo v8, "LAUNCH_BILLING_FLOW"

    nop

    nop

    const-string/jumbo v12, "INTENT_SOURCE"

    nop

    nop

    if-eqz p2, :cond_1ab

    const/16 v6, 0x673

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    invoke-direct {v0, v1}, Lcom/android/billingclient/api/ProxyBillingActivity;->makeAlternativeBillingIntent(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p2

    const/16 v6, 0x4b

    move-object/from16 v0, p2

    invoke-virtual {v0, v12, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    goto :goto_1cb

    :cond_1ab
    const/16 v6, 0x11fc

    move-object/from16 v0, p0

    invoke-direct {v0}, Lcom/android/billingclient/api/ProxyBillingActivity;->makePurchasesUpdatedIntent()Landroid/content/Intent;

    move-result-object p2

    const/16 v6, 0xdf

    move-object/from16 v0, p3

    invoke-virtual {v0}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object p3

    const/16 v6, 0x11ce

    move-object/from16 v0, p2

    move-object/from16 v1, p3

    invoke-virtual {v0, v1}, Landroid/content/Intent;->putExtras(Landroid/os/Bundle;)Landroid/content/Intent;

    const/16 v6, 0x4b

    move-object/from16 v0, p2

    invoke-virtual {v0, v12, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    :goto_1cb
    const/16 v6, 0x2d2

    move-object/from16 v0, p0

    iget-wide v12, v0, Lcom/android/billingclient/api/ProxyBillingActivity;->billingClientTransactionId:J

    nop

    const-string/jumbo p3, "billingClientTransactionId"

    nop

    nop

    const/16 v6, 0xba

    move-object/from16 v0, p2

    move-object/from16 v1, p3

    invoke-virtual {v0, v1, v12, v13}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/16 v6, 0x796

    move-object/from16 v0, p0

    iget-boolean v6, v0, Lcom/android/billingclient/api/ProxyBillingActivity;->wasServiceAutoReconnected:Z

    move/16 p3, v6

    const-string/jumbo v8, "wasServiceAutoReconnected"

    nop

    nop

    const/16 v6, 0x178

    move-object/from16 v0, p2

    move/from16 v1, p3

    invoke-virtual {v0, v8, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    :goto_1f7
    move/from16 v0, p1

    if-ne v0, v9, :cond_209

    const-string/jumbo p1, "IS_FIRST_PARTY_PURCHASE"

    nop

    nop

    const/16 v6, 0x178

    move-object/from16 v0, p2

    move-object/from16 v1, p1

    invoke-virtual {v0, v1, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    :cond_209
    const/16 v6, 0x63

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    invoke-virtual {v0, v1}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    :cond_212
    :goto_212
    const/16 v6, 0x1fe

    move-object/from16 v0, p0

    iput-boolean v11, v0, Lcom/android/billingclient/api/ProxyBillingActivity;->sendCancelledBroadcastIfFinished:Z

    const/16 v6, 0x49a

    move-object/from16 v0, p0

    invoke-direct {v0}, Lcom/android/billingclient/api/ProxyBillingActivity;->isProxyBillingBroadcastReceiverRegistered()Z

    move-result p1

    if-eqz p1, :cond_232

    const/16 v6, 0x20a

    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/android/billingclient/api/ProxyBillingActivity;->proxyBillingBroadcastReceiver:Lcom/android/billingclient/api/zzej;

    move-object/16 p1, v6

    const/16 v6, 0xa5a

    move-object/from16 v0, p1

    invoke-virtual {v0}, Lcom/android/billingclient/api/zzej;->zzb()V

    :cond_232
    const/16 v6, 0x107

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->finish()V

    return-void
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .registers 26
    .param p1  # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param
    .annotation build Lcom/android/billingclient/api/zzw;
    .end annotation

    .prologue
    const/16 v9, 0xdef

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-super {v0, v1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const/16 v9, 0x71c

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-direct {v0, v1}, Lcom/android/billingclient/api/ProxyBillingActivity;->isInAppMessageFlow(Landroid/os/Bundle;)Z

    move-result v11

    const-string/jumbo v20, "ProxyBillingActivity"

    nop

    nop

    const/16 v21, 0x0

    if-nez v11, :cond_b2

    :try_start_1c
    const/16 v9, 0xea

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v11

    const/16 v9, 0x4a

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v14

    const/16 v9, 0xf17

    move/from16 v0, v21

    invoke-virtual {v11, v14, v0}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v11

    const/16 v9, 0x10fc

    iget v11, v11, Landroid/content/pm/PackageInfo;->versionCode:I

    nop
    :try_end_39
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_1c .. :try_end_39} :catch_3a

    goto :goto_48

    :catch_3a
    move-exception v11

    const-string/jumbo v14, "Failed to get package info for current package."

    nop

    nop

    const/16 v9, 0x34e

    move-object/from16 v0, v20

    invoke-static {v0, v14, v11}, Lcom/google/android/gms/internal/play_billing/zzc;->zzo(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v11, -0x1

    :goto_48
    const/16 v9, 0x3c1

    move-object/from16 v0, p0

    iget-object v14, v0, Lcom/android/billingclient/api/ProxyBillingActivity;->billingLogger:Lcom/android/billingclient/api/zzdd;

    nop

    if-nez v14, :cond_ab

    const/16 v9, 0x53

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v14

    const/16 v9, 0xeb7

    invoke-static {}, Lcom/google/android/gms/internal/play_billing/zzkg;->zza()Lcom/google/android/gms/internal/play_billing/zzke;

    move-result-object v15

    const/16 v9, 0x4a

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v16

    const/16 v9, 0xb71

    move-object/from16 v0, v16

    invoke-virtual {v15, v0}, Lcom/google/android/gms/internal/play_billing/zzke;->zzq(Ljava/lang/String;)Lcom/google/android/gms/internal/play_billing/zzke;

    const-string/jumbo v16, "9.1.0"

    nop

    nop

    const/16 v9, 0x580

    move-object/from16 v0, v16

    invoke-virtual {v15, v0}, Lcom/google/android/gms/internal/play_billing/zzke;->zzx(Ljava/lang/String;)Lcom/google/android/gms/internal/play_billing/zzke;

    const/16 v9, 0x80f

    invoke-virtual {v15, v11}, Lcom/google/android/gms/internal/play_billing/zzke;->zzb(I)Lcom/google/android/gms/internal/play_billing/zzke;

    const/16 v9, 0x1fc

    sget v11, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 v9, 0xbbc

    invoke-virtual {v15, v11}, Lcom/google/android/gms/internal/play_billing/zzke;->zza(I)Lcom/google/android/gms/internal/play_billing/zzke;

    const-wide/32 v16, 0x373637b7

    const/16 v9, 0x686

    move-wide/from16 v0, v16

    invoke-virtual {v15, v0, v1}, Lcom/google/android/gms/internal/play_billing/zzke;->zzp(J)Lcom/google/android/gms/internal/play_billing/zzke;

    const/16 v9, 0x32a

    invoke-virtual {v15}, Lcom/google/android/gms/internal/play_billing/zzgl;->zzi()Lcom/google/android/gms/internal/play_billing/zzgp;

    move-result-object v11

    check-cast v11, Lcom/google/android/gms/internal/play_billing/zzkg;

    const/16 v9, 0xd0c

    new-instance v15, Lcom/android/billingclient/api/zzdr;

    nop

    const/16 v9, 0x5dd

    invoke-direct {v15, v14, v11}, Lcom/android/billingclient/api/zzdr;-><init>(Landroid/content/Context;Lcom/google/android/gms/internal/play_billing/zzkg;)V

    const/16 v9, 0xdd7

    move-object/from16 v0, p0

    iput-object v15, v0, Lcom/android/billingclient/api/ProxyBillingActivity;->billingLogger:Lcom/android/billingclient/api/zzdd;

    :cond_ab
    const/16 v9, 0x895

    move-object/from16 v0, p0

    invoke-direct {v0}, Lcom/android/billingclient/api/ProxyBillingActivity;->registerProxyBillingBroadcastReceiver()V

    :cond_b2
    const/16 v11, 0x64

    const-string/jumbo v14, "in_app_message_result_receiver"

    nop

    nop

    const-string/jumbo v15, "IS_FLOW_FROM_FIRST_PARTY_CLIENT"

    nop

    nop

    const-string/jumbo v16, "wasServiceAutoReconnected"

    nop

    nop

    const-string/jumbo v17, "billingClientTransactionId"

    nop

    nop

    if-nez p1, :cond_2ad

    const-string/jumbo v13, "Launching Play Store billing flow"

    nop

    nop

    const/16 v9, 0x353

    move-object/from16 v0, v20

    invoke-static {v0, v13}, Lcom/google/android/gms/internal/play_billing/zzc;->zzm(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v9, 0x199

    move-object/from16 v0, p0

    iput v11, v0, Lcom/android/billingclient/api/ProxyBillingActivity;->activityCode:I

    const/16 v9, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v11

    const-string/jumbo v13, "BUY_INTENT"

    nop

    nop

    const/16 v9, 0xb2

    invoke-virtual {v11, v13}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v11

    const/16 v22, 0x0

    const/16 v23, 0x1

    if-eqz v11, :cond_138

    const/16 v9, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v11

    const/16 v9, 0x3f

    invoke-virtual {v11, v13}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v11

    check-cast v11, Landroid/app/PendingIntent;

    const/16 v9, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v13

    const/16 v9, 0xb2

    invoke-virtual {v13, v15}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v13

    if-eqz v13, :cond_17e

    const/16 v9, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v13

    const/16 v9, 0x151

    move/from16 v0, v21

    invoke-virtual {v13, v15, v0}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v13

    if-eqz v13, :cond_17e

    const/16 v9, 0x51e

    move-object/from16 v0, p0

    move/from16 v1, v23

    iput-boolean v1, v0, Lcom/android/billingclient/api/ProxyBillingActivity;->isFlowFromFirstPartyClient:Z

    const/16 v13, 0x6e

    const/16 v9, 0x199

    move-object/from16 v0, p0

    iput v13, v0, Lcom/android/billingclient/api/ProxyBillingActivity;->activityCode:I

    goto :goto_17e

    :cond_138
    const/16 v9, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v11

    const-string/jumbo v13, "IN_APP_MESSAGE_INTENT"

    nop

    nop

    const/16 v9, 0xb2

    invoke-virtual {v11, v13}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v11

    if-eqz v11, :cond_17c

    const/16 v9, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v11

    const/16 v9, 0x3f

    invoke-virtual {v11, v13}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v11

    check-cast v11, Landroid/app/PendingIntent;

    const/16 v9, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v13

    const/16 v9, 0x3f

    invoke-virtual {v13, v14}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v13

    check-cast v13, Landroid/os/ResultReceiver;

    const/16 v9, 0x48c

    move-object/from16 v0, p0

    iput-object v13, v0, Lcom/android/billingclient/api/ProxyBillingActivity;->inAppMessageResultReceiver:Landroid/os/ResultReceiver;

    const/16 v13, 0x65

    const/16 v9, 0x199

    move-object/from16 v0, p0

    iput v13, v0, Lcom/android/billingclient/api/ProxyBillingActivity;->activityCode:I

    goto :goto_17e

    :cond_17c
    move-object/from16 v11, v22

    :cond_17e
    :goto_17e
    const/16 v9, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v13

    const/16 v9, 0xb2

    move-object/from16 v0, v17

    invoke-virtual {v13, v0}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v13

    if-eqz v13, :cond_1a8

    const/16 v9, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v13

    const-wide/16 v14, 0x0

    const/16 v9, 0x4dd

    move-object/from16 v0, v17

    invoke-virtual {v13, v0, v14, v15}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v13

    const/16 v9, 0x2c5

    move-object/from16 v0, p0

    iput-wide v13, v0, Lcom/android/billingclient/api/ProxyBillingActivity;->billingClientTransactionId:J

    :cond_1a8
    const/16 v9, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v13

    const/16 v9, 0xb2

    move-object/from16 v0, v16

    invoke-virtual {v13, v0}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v13

    if-eqz v13, :cond_1d2

    const/16 v9, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v13

    const/16 v9, 0x151

    move-object/from16 v0, v16

    move/from16 v1, v21

    invoke-virtual {v13, v0, v1}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v13

    const/16 v9, 0x3be

    move-object/from16 v0, p0

    iput-boolean v13, v0, Lcom/android/billingclient/api/ProxyBillingActivity;->wasServiceAutoReconnected:Z

    :cond_1d2
    :try_start_1d2
    const/16 v9, 0x1fe

    move-object/from16 v0, p0

    move/from16 v1, v23

    iput-boolean v1, v0, Lcom/android/billingclient/api/ProxyBillingActivity;->sendCancelledBroadcastIfFinished:Z

    const/16 v9, 0x1fc

    sget v13, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 v14, 0x24

    if-lt v13, v14, :cond_1fb

    const/16 v9, 0x38f

    invoke-static {}, Landroid/app/ActivityOptions;->makeBasic()Landroid/app/ActivityOptions;

    move-result-object v13

    const/4 v14, 0x3

    const/16 v9, 0x44b

    invoke-virtual {v13, v14}, Landroid/app/ActivityOptions;->setPendingIntentBackgroundActivityStartMode(I)Landroid/app/ActivityOptions;

    move-result-object v13

    const/16 v9, 0x4c0

    invoke-virtual {v13}, Landroid/app/ActivityOptions;->toBundle()Landroid/os/Bundle;

    move-result-object v13

    :goto_1f6
    move-object/from16 v19, v13

    goto :goto_216

    :catch_1f9
    move-exception v11

    goto :goto_249

    :cond_1fb
    const/16 v14, 0x22

    if-lt v13, v14, :cond_214

    const/16 v9, 0x38f

    invoke-static {}, Landroid/app/ActivityOptions;->makeBasic()Landroid/app/ActivityOptions;

    move-result-object v13

    const/16 v9, 0x44b

    move/from16 v0, v23

    invoke-virtual {v13, v0}, Landroid/app/ActivityOptions;->setPendingIntentBackgroundActivityStartMode(I)Landroid/app/ActivityOptions;

    move-result-object v13

    const/16 v9, 0x4c0

    invoke-virtual {v13}, Landroid/app/ActivityOptions;->toBundle()Landroid/os/Bundle;

    move-result-object v13

    goto :goto_1f6

    :cond_214
    move-object/from16 v19, v22

    :goto_216
    const/16 v9, 0xc7

    invoke-virtual {v11}, Landroid/app/PendingIntent;->getIntentSender()Landroid/content/IntentSender;

    move-result-object v13

    const/16 v9, 0xe94

    move-object/from16 v0, p0

    iget v14, v0, Lcom/android/billingclient/api/ProxyBillingActivity;->activityCode:I

    nop

    const/16 v9, 0x5b

    new-instance v15, Landroid/content/Intent;

    nop

    const/16 v9, 0x96c

    invoke-direct {v15}, Landroid/content/Intent;-><init>()V

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v16, 0x0

    move-object/from16 v12, p0

    const/16 v9, 0x652

    move v0, v9

    move-object v1, v12

    move-object v2, v13

    move v3, v14

    move-object v4, v15

    move/from16 v5, v16

    move/from16 v6, v17

    move/from16 v7, v18

    move-object/from16 v8, v19

    invoke-virtual/range {v1 .. v8}, Landroid/app/Activity;->startIntentSenderForResult(Landroid/content/IntentSender;ILandroid/content/Intent;IIILandroid/os/Bundle;)V
    :try_end_247
    .catch Landroid/content/IntentSender$SendIntentException; {:try_start_1d2 .. :try_end_247} :catch_1f9

    goto/16 :goto_349

    :goto_249
    const-string/jumbo v13, "Got exception while trying to start a purchase flow."

    nop

    nop

    const/16 v9, 0x34e

    move-object/from16 v0, v20

    invoke-static {v0, v13, v11}, Lcom/google/android/gms/internal/play_billing/zzc;->zzo(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/16 v9, 0xbd9

    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/android/billingclient/api/ProxyBillingActivity;->inAppMessageResultReceiver:Landroid/os/ResultReceiver;

    nop

    if-eqz v11, :cond_268

    const/16 v9, 0x3e4

    move/from16 v0, v21

    move-object/from16 v1, v22

    invoke-virtual {v11, v0, v1}, Landroid/os/ResultReceiver;->send(ILandroid/os/Bundle;)V

    goto :goto_29d

    :cond_268
    const/16 v9, 0x1057

    sget-object v11, Lcom/google/android/gms/internal/play_billing/zzjs;->zzbG:Lcom/google/android/gms/internal/play_billing/zzjs;

    nop

    const/16 v9, 0x2d2

    move-object/from16 v0, p0

    iget-wide v13, v0, Lcom/android/billingclient/api/ProxyBillingActivity;->billingClientTransactionId:J

    nop

    const/16 v9, 0x8bb

    move v0, v9

    move-object/from16 v1, p0

    move-object v2, v11

    move-wide v3, v13

    move/from16 v5, v21

    invoke-direct/range {v1 .. v5}, Lcom/android/billingclient/api/ProxyBillingActivity;->makePurchaseUpdatedIntentWithResponseCodeAndReason(Lcom/google/android/gms/internal/play_billing/zzjs;JZ)Landroid/content/Intent;

    move-result-object v11

    const/16 v9, 0x1031

    move-object/from16 v0, p0

    iget-boolean v13, v0, Lcom/android/billingclient/api/ProxyBillingActivity;->isFlowFromFirstPartyClient:Z

    nop

    if-eqz v13, :cond_296

    const-string/jumbo v13, "IS_FIRST_PARTY_PURCHASE"

    nop

    nop

    const/16 v9, 0x178

    move/from16 v0, v23

    invoke-virtual {v11, v13, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    :cond_296
    const/16 v9, 0x63

    move-object/from16 v0, p0

    invoke-virtual {v0, v11}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    :goto_29d
    const/16 v9, 0x1fe

    move-object/from16 v0, p0

    move/from16 v1, v21

    iput-boolean v1, v0, Lcom/android/billingclient/api/ProxyBillingActivity;->sendCancelledBroadcastIfFinished:Z

    const/16 v9, 0x107

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->finish()V

    return-void

    :cond_2ad
    const-string/jumbo v18, "Launching Play Store billing flow from savedInstanceState"

    nop

    nop

    const/16 v9, 0x353

    move-object/from16 v0, v20

    move-object/from16 v1, v18

    invoke-static {v0, v1}, Lcom/google/android/gms/internal/play_billing/zzc;->zzm(Ljava/lang/String;Ljava/lang/String;)V

    const-string/jumbo v18, "send_cancelled_broadcast_if_finished"

    nop

    nop

    const/16 v9, 0x428

    move-object/from16 v0, p1

    move-object/from16 v1, v18

    move/from16 v2, v21

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;Z)Z

    move-result v18

    const/16 v9, 0x1fe

    move-object/from16 v0, p0

    move/from16 v1, v18

    iput-boolean v1, v0, Lcom/android/billingclient/api/ProxyBillingActivity;->sendCancelledBroadcastIfFinished:Z

    const/16 v9, 0x9c

    move-object/from16 v0, p1

    invoke-virtual {v0, v14}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v18

    if-eqz v18, :cond_2ee

    const/16 v9, 0xc3

    move-object/from16 v0, p1

    invoke-virtual {v0, v14}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v14

    check-cast v14, Landroid/os/ResultReceiver;

    const/16 v9, 0x48c

    move-object/from16 v0, p0

    iput-object v14, v0, Lcom/android/billingclient/api/ProxyBillingActivity;->inAppMessageResultReceiver:Landroid/os/ResultReceiver;

    :cond_2ee
    const/16 v9, 0x428

    move-object/from16 v0, p1

    move/from16 v1, v21

    invoke-virtual {v0, v15, v1}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;Z)Z

    move-result v14

    const/16 v9, 0x51e

    move-object/from16 v0, p0

    iput-boolean v14, v0, Lcom/android/billingclient/api/ProxyBillingActivity;->isFlowFromFirstPartyClient:Z

    const-string/jumbo v14, "activity_code"

    nop

    nop

    const/16 v9, 0xef2

    move-object/from16 v0, p1

    invoke-virtual {v0, v14, v11}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    move-result v11

    const/16 v9, 0x199

    move-object/from16 v0, p0

    iput v11, v0, Lcom/android/billingclient/api/ProxyBillingActivity;->activityCode:I

    const/16 v9, 0x9c

    move-object/from16 v0, p1

    move-object/from16 v1, v17

    invoke-virtual {v0, v1}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v11

    if-eqz v11, :cond_32d

    const/16 v9, 0xdba

    move-object/from16 v0, p1

    move-object/from16 v1, v17

    invoke-virtual {v0, v1}, Landroid/os/BaseBundle;->getLong(Ljava/lang/String;)J

    move-result-wide v14

    const/16 v9, 0x2c5

    move-object/from16 v0, p0

    iput-wide v14, v0, Lcom/android/billingclient/api/ProxyBillingActivity;->billingClientTransactionId:J

    :cond_32d
    const/16 v9, 0x9c

    move-object/from16 v0, p1

    move-object/from16 v1, v16

    invoke-virtual {v0, v1}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v11

    if-eqz v11, :cond_349

    const/16 v9, 0x123b

    move-object/from16 v0, p1

    move-object/from16 v1, v16

    invoke-virtual {v0, v1}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    move-result v11

    const/16 v9, 0x3be

    move-object/from16 v0, p0

    iput-boolean v11, v0, Lcom/android/billingclient/api/ProxyBillingActivity;->wasServiceAutoReconnected:Z

    :cond_349
    :goto_349
    return-void
.end method

.method public onDestroy()V
    .registers 9
    .annotation build Lcom/android/billingclient/api/zzw;
    .end annotation

    .prologue
    const/16 v0, 0xc7d

    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    const/16 v0, 0x49a

    invoke-direct {p0}, Lcom/android/billingclient/api/ProxyBillingActivity;->isProxyBillingBroadcastReceiverRegistered()Z

    move-result v2

    if-eqz v2, :cond_34

    const/16 v0, 0x20a

    iget-object v2, p0, Lcom/android/billingclient/api/ProxyBillingActivity;->proxyBillingBroadcastReceiver:Lcom/android/billingclient/api/zzej;

    nop

    const/16 v0, 0x40b

    invoke-virtual {v2}, Lcom/android/billingclient/api/zzej;->zza()Lcom/android/billingclient/api/BillingResult;

    move-result-object v2

    :try_start_18
    const/16 v0, 0x20a

    iget-object v3, p0, Lcom/android/billingclient/api/ProxyBillingActivity;->proxyBillingBroadcastReceiver:Lcom/android/billingclient/api/zzej;

    nop

    const/16 v0, 0x345

    invoke-virtual {p0, v3}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_22
    .catch Ljava/lang/RuntimeException; {:try_start_18 .. :try_end_22} :catch_23

    goto :goto_35

    :catch_23
    move-exception v3

    const-string/jumbo v4, "ProxyBillingActivity"

    nop

    nop

    const-string/jumbo v5, "Failed to unregister receiver."

    nop

    nop

    const/16 v0, 0x34e

    invoke-static {v4, v5, v3}, Lcom/google/android/gms/internal/play_billing/zzc;->zzo(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    goto :goto_35

    :cond_34
    const/4 v2, 0x0

    :goto_35
    const/16 v0, 0x415

    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    move-result v3

    if-nez v3, :cond_3f

    goto/16 :goto_c0

    :cond_3f
    const/16 v0, 0x72e

    iget-boolean v3, p0, Lcom/android/billingclient/api/ProxyBillingActivity;->sendCancelledBroadcastIfFinished:Z

    nop

    if-eqz v3, :cond_c0

    const/16 v0, 0x11fc

    invoke-direct {p0}, Lcom/android/billingclient/api/ProxyBillingActivity;->makePurchasesUpdatedIntent()Landroid/content/Intent;

    move-result-object v3

    const/4 v4, 0x1

    const-string/jumbo v5, "DEBUG_MESSAGE"

    nop

    nop

    const-string/jumbo v6, "RESPONSE_CODE"

    nop

    nop

    if-eqz v2, :cond_70

    const/16 v0, 0x450

    invoke-virtual {v2}, Lcom/android/billingclient/api/BillingResult;->getResponseCode()I

    move-result v7

    const/16 v0, 0x29

    invoke-virtual {v3, v6, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/16 v0, 0xd07

    invoke-virtual {v2}, Lcom/android/billingclient/api/BillingResult;->getDebugMessage()Ljava/lang/String;

    move-result-object v2

    const/16 v0, 0x4b

    invoke-virtual {v3, v5, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    goto :goto_7f

    :cond_70
    const/16 v0, 0x29

    invoke-virtual {v3, v6, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string/jumbo v2, "Billing dialog closed."

    nop

    nop

    const/16 v0, 0x4b

    invoke-virtual {v3, v5, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    :goto_7f
    const/16 v0, 0x1031

    iget-boolean v2, p0, Lcom/android/billingclient/api/ProxyBillingActivity;->isFlowFromFirstPartyClient:Z

    nop

    if-eqz v2, :cond_90

    const-string/jumbo v2, "IS_FIRST_PARTY_PURCHASE"

    nop

    nop

    const/16 v0, 0x178

    invoke-virtual {v3, v2, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    :cond_90
    const/16 v0, 0xe94

    iget v2, p0, Lcom/android/billingclient/api/ProxyBillingActivity;->activityCode:I

    nop

    const/16 v4, 0x6e

    if-eq v2, v4, :cond_9d

    const/16 v4, 0x64

    if-ne v2, v4, :cond_bb

    :cond_9d
    const-string/jumbo v2, "INTENT_SOURCE"

    nop

    nop

    const-string/jumbo v4, "LAUNCH_BILLING_FLOW"

    nop

    nop

    const/16 v0, 0x4b

    invoke-virtual {v3, v2, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/16 v0, 0x2d2

    iget-wide v4, p0, Lcom/android/billingclient/api/ProxyBillingActivity;->billingClientTransactionId:J

    nop

    const-string/jumbo v2, "billingClientTransactionId"

    nop

    nop

    const/16 v0, 0xba

    invoke-virtual {v3, v2, v4, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    :cond_bb
    const/16 v0, 0x63

    invoke-virtual {p0, v3}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    :cond_c0
    :goto_c0
    return-void
.end method

.method public onSaveInstanceState(Landroid/os/Bundle;)V
    .registers 7
    .param p1  # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param
    .annotation build Lcom/android/billingclient/api/zzw;
    .end annotation

    .prologue
    const/16 v0, 0x100a

    invoke-super {p0, p1}, Landroid/app/Activity;->onSaveInstanceState(Landroid/os/Bundle;)V

    const/16 v0, 0xbd9

    iget-object v2, p0, Lcom/android/billingclient/api/ProxyBillingActivity;->inAppMessageResultReceiver:Landroid/os/ResultReceiver;

    nop

    if-eqz v2, :cond_16

    const-string/jumbo v3, "in_app_message_result_receiver"

    nop

    nop

    const/16 v0, 0x9a

    invoke-virtual {p1, v3, v2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    :cond_16
    const/16 v0, 0x72e

    iget-boolean v2, p0, Lcom/android/billingclient/api/ProxyBillingActivity;->sendCancelledBroadcastIfFinished:Z

    nop

    const-string/jumbo v3, "send_cancelled_broadcast_if_finished"

    nop

    nop

    const/16 v0, 0x27b

    invoke-virtual {p1, v3, v2}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/16 v0, 0x1031

    iget-boolean v2, p0, Lcom/android/billingclient/api/ProxyBillingActivity;->isFlowFromFirstPartyClient:Z

    nop

    const-string/jumbo v3, "IS_FLOW_FROM_FIRST_PARTY_CLIENT"

    nop

    nop

    const/16 v0, 0x27b

    invoke-virtual {p1, v3, v2}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/16 v0, 0xe94

    iget v2, p0, Lcom/android/billingclient/api/ProxyBillingActivity;->activityCode:I

    nop

    const-string/jumbo v3, "activity_code"

    nop

    nop

    const/16 v0, 0x23e

    invoke-virtual {p1, v3, v2}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/16 v0, 0x2d2

    iget-wide v2, p0, Lcom/android/billingclient/api/ProxyBillingActivity;->billingClientTransactionId:J

    nop

    const-string/jumbo v4, "billingClientTransactionId"

    nop

    nop

    const/16 v0, 0xc15

    invoke-virtual {p1, v4, v2, v3}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    const/16 v0, 0x796

    iget-boolean p0, p0, Lcom/android/billingclient/api/ProxyBillingActivity;->wasServiceAutoReconnected:Z

    nop

    const-string/jumbo v2, "wasServiceAutoReconnected"

    nop

    nop

    const/16 v0, 0x27b

    invoke-virtual {p1, v2, p0}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    return-void
.end method
