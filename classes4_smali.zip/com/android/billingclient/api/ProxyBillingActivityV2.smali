.class public Lcom/android/billingclient/api/ProxyBillingActivityV2;
.super Lut;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation build Lcom/google/android/apps/common/proguard/UsedByReflection;
    value = "PlatformActivityProxy"
.end annotation


# instance fields
.field private zza:Lm3;

.field private zzb:Lm3;

.field private zzc:Lm3;

.field private zzd:Lm3;

.field private zze:Lm3;

.field private zzf:Lm3;

.field private zzg:Landroid/os/ResultReceiver;
    .annotation build Landroidx/annotation/Nullable;
    .end annotation
.end field

.field private zzh:Landroid/os/ResultReceiver;
    .annotation build Landroidx/annotation/Nullable;
    .end annotation
.end field

.field private zzi:Landroid/os/ResultReceiver;
    .annotation build Landroidx/annotation/Nullable;
    .end annotation
.end field

.field private zzj:Landroid/os/ResultReceiver;
    .annotation build Landroidx/annotation/Nullable;
    .end annotation
.end field

.field private zzk:Landroid/os/ResultReceiver;
    .annotation build Landroidx/annotation/Nullable;
    .end annotation
.end field

.field private zzl:Landroid/os/ResultReceiver;
    .annotation build Landroidx/annotation/Nullable;
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Lut;-><init>()V

    return-void
.end method

.method private static final zzg()Lf3;
    .registers 4
    .annotation build Landroidx/annotation/Nullable;
    .end annotation

    .prologue
    const/16 v0, 0x1fc

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 v3, 0x24

    if-lt v2, v3, :cond_22

    const/16 v0, 0x4b8

    new-instance v2, Le3;

    nop

    const/16 v0, 0x38f

    invoke-static {}, Landroid/app/ActivityOptions;->makeBasic()Landroid/app/ActivityOptions;

    move-result-object v3

    const/16 v0, 0x418

    invoke-direct {v2, v3}, Le3;-><init>(Landroid/app/ActivityOptions;)V

    const/4 v3, 0x3

    const/16 v0, 0x333

    invoke-virtual {v2, v3}, Le3;->a(I)Le3;

    check-cast v2, Lf3;

    return-object v2

    :cond_22
    const/16 v3, 0x22

    if-lt v2, v3, :cond_3f

    const/16 v0, 0x4b8

    new-instance v2, Le3;

    nop

    const/16 v0, 0x38f

    invoke-static {}, Landroid/app/ActivityOptions;->makeBasic()Landroid/app/ActivityOptions;

    move-result-object v3

    const/16 v0, 0x418

    invoke-direct {v2, v3}, Le3;-><init>(Landroid/app/ActivityOptions;)V

    const/4 v3, 0x1

    const/16 v0, 0x333

    invoke-virtual {v2, v3}, Le3;->a(I)Le3;

    check-cast v2, Lf3;

    return-object v2

    :cond_3f
    const/4 v2, 0x0

    return-object v2
.end method


# virtual methods
.method public final onCreate(Landroid/os/Bundle;)V
    .registers 19
    .param p1  # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/Nullable;
        .end annotation
    .end param

    .prologue
    const/16 v6, 0x871

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-super {v0, v1}, Lut;->onCreate(Landroid/os/Bundle;)V

    const/16 v6, 0xa2

    new-instance v8, Ll3;

    nop

    const/4 v9, 0x3

    const/16 v6, 0x9e

    invoke-direct {v8, v9}, Ll3;-><init>(I)V

    const/16 v6, 0x63d

    new-instance v10, Lcom/android/billingclient/api/zzed;

    nop

    const/16 v6, 0x87a

    move-object/from16 v0, p0

    invoke-direct {v10, v0}, Lcom/android/billingclient/api/zzed;-><init>(Lcom/android/billingclient/api/ProxyBillingActivityV2;)V

    const/16 v6, 0xaa

    move-object/from16 v0, p0

    invoke-virtual {v0, v8, v10}, Lut;->registerForActivityResult(Lk3;Lj3;)Lm3;

    move-result-object v8

    const/16 v6, 0xb7b

    move-object/from16 v0, p0

    iput-object v8, v0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zza:Lm3;

    const/16 v6, 0xa2

    new-instance v8, Ll3;

    nop

    const/16 v6, 0x9e

    invoke-direct {v8, v9}, Ll3;-><init>(I)V

    const/16 v6, 0x645

    new-instance v10, Lcom/android/billingclient/api/zzee;

    nop

    const/16 v6, 0xc6a

    move-object/from16 v0, p0

    invoke-direct {v10, v0}, Lcom/android/billingclient/api/zzee;-><init>(Lcom/android/billingclient/api/ProxyBillingActivityV2;)V

    const/16 v6, 0xaa

    move-object/from16 v0, p0

    invoke-virtual {v0, v8, v10}, Lut;->registerForActivityResult(Lk3;Lj3;)Lm3;

    move-result-object v8

    const/16 v6, 0x8c6

    move-object/from16 v0, p0

    iput-object v8, v0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzb:Lm3;

    const/16 v6, 0xa2

    new-instance v8, Ll3;

    nop

    const/16 v6, 0x9e

    invoke-direct {v8, v9}, Ll3;-><init>(I)V

    const/16 v6, 0x105b

    new-instance v10, Lcom/android/billingclient/api/zzef;

    nop

    const/16 v6, 0x9f2

    move-object/from16 v0, p0

    invoke-direct {v10, v0}, Lcom/android/billingclient/api/zzef;-><init>(Lcom/android/billingclient/api/ProxyBillingActivityV2;)V

    const/16 v6, 0xaa

    move-object/from16 v0, p0

    invoke-virtual {v0, v8, v10}, Lut;->registerForActivityResult(Lk3;Lj3;)Lm3;

    move-result-object v8

    const/16 v6, 0x6d7

    move-object/from16 v0, p0

    iput-object v8, v0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzc:Lm3;

    const/16 v6, 0xa2

    new-instance v8, Ll3;

    nop

    const/16 v6, 0x9e

    invoke-direct {v8, v9}, Ll3;-><init>(I)V

    const/16 v6, 0xde0

    new-instance v10, Lcom/android/billingclient/api/zzeg;

    nop

    const/16 v6, 0x75b

    move-object/from16 v0, p0

    invoke-direct {v10, v0}, Lcom/android/billingclient/api/zzeg;-><init>(Lcom/android/billingclient/api/ProxyBillingActivityV2;)V

    const/16 v6, 0xaa

    move-object/from16 v0, p0

    invoke-virtual {v0, v8, v10}, Lut;->registerForActivityResult(Lk3;Lj3;)Lm3;

    move-result-object v8

    const/16 v6, 0x1184

    move-object/from16 v0, p0

    iput-object v8, v0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzd:Lm3;

    const/16 v6, 0xa2

    new-instance v8, Ll3;

    nop

    const/16 v6, 0x9e

    invoke-direct {v8, v9}, Ll3;-><init>(I)V

    const/16 v6, 0xc8a

    new-instance v10, Lcom/android/billingclient/api/zzeh;

    nop

    const/16 v6, 0xc1c

    move-object/from16 v0, p0

    invoke-direct {v10, v0}, Lcom/android/billingclient/api/zzeh;-><init>(Lcom/android/billingclient/api/ProxyBillingActivityV2;)V

    const/16 v6, 0xaa

    move-object/from16 v0, p0

    invoke-virtual {v0, v8, v10}, Lut;->registerForActivityResult(Lk3;Lj3;)Lm3;

    move-result-object v8

    const/16 v6, 0xee5

    move-object/from16 v0, p0

    iput-object v8, v0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zze:Lm3;

    const/16 v6, 0xa2

    new-instance v8, Ll3;

    nop

    const/16 v6, 0x9e

    invoke-direct {v8, v9}, Ll3;-><init>(I)V

    const/16 v6, 0xdff

    new-instance v9, Lcom/android/billingclient/api/zzei;

    nop

    const/16 v6, 0x1030

    move-object/from16 v0, p0

    invoke-direct {v9, v0}, Lcom/android/billingclient/api/zzei;-><init>(Lcom/android/billingclient/api/ProxyBillingActivityV2;)V

    const/16 v6, 0xaa

    move-object/from16 v0, p0

    invoke-virtual {v0, v8, v9}, Lut;->registerForActivityResult(Lk3;Lj3;)Lm3;

    move-result-object v8

    const/16 v6, 0xa68

    move-object/from16 v0, p0

    iput-object v8, v0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzf:Lm3;

    const-string/jumbo v8, "subscription_management_action_result_receiver"

    nop

    nop

    const-string/jumbo v9, "billing_program_information_dialog_result_receiver"

    nop

    nop

    const-string/jumbo v10, "launch_external_link_result_receiver"

    nop

    nop

    const-string/jumbo v11, "external_offer_flow_result_receiver"

    nop

    nop

    const-string/jumbo v12, "external_payment_dialog_result_receiver"

    nop

    nop

    const-string/jumbo v13, "alternative_billing_only_dialog_result_receiver"

    nop

    nop

    if-nez p1, :cond_410

    const-string/jumbo p1, "ProxyBillingActivityV2"

    nop

    nop

    const-string/jumbo v14, "Launching Play Store billing dialog"

    nop

    nop

    const/16 v6, 0x353

    move-object/from16 v0, p1

    invoke-static {v0, v14}, Lcom/google/android/gms/internal/play_billing/zzc;->zzm(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v6, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const-string/jumbo v14, "ALTERNATIVE_BILLING_ONLY_DIALOG_INTENT"

    nop

    nop

    const/16 v6, 0xb2

    move-object/from16 v0, p1

    invoke-virtual {v0, v14}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result p1

    const/4 v15, 0x0

    const/16 v16, 0x0

    if-eqz p1, :cond_195

    const/16 v6, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const/16 v6, 0x3f

    move-object/from16 v0, p1

    invoke-virtual {v0, v14}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p1

    check-cast p1, Landroid/app/PendingIntent;

    const/16 v6, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v8

    const/16 v6, 0x3f

    invoke-virtual {v8, v13}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v8

    check-cast v8, Landroid/os/ResultReceiver;

    const/16 v6, 0x3a6

    move-object/from16 v0, p0

    iput-object v8, v0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzg:Landroid/os/ResultReceiver;

    const/16 v6, 0xc84

    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zza:Lm3;

    move-object/16 p0, v6

    const/4 v6, -0x6

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xc7

    move-object/from16 v0, p1

    invoke-virtual {v0}, Landroid/app/PendingIntent;->getIntentSender()Landroid/content/IntentSender;

    move-result-object p1

    const/4 v6, -0x6

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xb5

    new-instance v8, Lls0;

    nop

    const/16 v6, 0x9f

    move v0, v6

    move-object v1, v8

    move-object/from16 v2, p1

    move-object v3, v15

    move/from16 v4, v16

    move/from16 v5, v16

    invoke-direct/range {v1 .. v5}, Lls0;-><init>(Landroid/content/IntentSender;Landroid/content/Intent;II)V

    const/16 v6, 0xa6

    invoke-static {}, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzg()Lf3;

    move-result-object p1

    const/16 v6, 0xad

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual {v0, v8, v1}, Lm3;->a(Ljava/lang/Object;Lf3;)V

    return-void

    :cond_195
    const/16 v6, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const-string/jumbo v13, "external_payment_dialog_pending_intent"

    nop

    nop

    const/16 v6, 0xb2

    move-object/from16 v0, p1

    invoke-virtual {v0, v13}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_214

    const/16 v6, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const/16 v6, 0x3f

    move-object/from16 v0, p1

    invoke-virtual {v0, v13}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p1

    check-cast p1, Landroid/app/PendingIntent;

    const/16 v6, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v8

    const/16 v6, 0x3f

    invoke-virtual {v8, v12}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v8

    check-cast v8, Landroid/os/ResultReceiver;

    const/16 v6, 0x4ab

    move-object/from16 v0, p0

    iput-object v8, v0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzh:Landroid/os/ResultReceiver;

    const/16 v6, 0xee2

    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzb:Lm3;

    move-object/16 p0, v6

    const/4 v6, -0x6

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xc7

    move-object/from16 v0, p1

    invoke-virtual {v0}, Landroid/app/PendingIntent;->getIntentSender()Landroid/content/IntentSender;

    move-result-object p1

    const/4 v6, -0x6

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xb5

    new-instance v8, Lls0;

    nop

    const/16 v6, 0x9f

    move v0, v6

    move-object v1, v8

    move-object/from16 v2, p1

    move-object v3, v15

    move/from16 v4, v16

    move/from16 v5, v16

    invoke-direct/range {v1 .. v5}, Lls0;-><init>(Landroid/content/IntentSender;Landroid/content/Intent;II)V

    const/16 v6, 0xa6

    invoke-static {}, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzg()Lf3;

    move-result-object p1

    const/16 v6, 0xad

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual {v0, v8, v1}, Lm3;->a(Ljava/lang/Object;Lf3;)V

    return-void

    :cond_214
    const/16 v6, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const-string/jumbo v12, "external_offer_flow_pending_intent"

    nop

    nop

    const/16 v6, 0xb2

    move-object/from16 v0, p1

    invoke-virtual {v0, v12}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_293

    const/16 v6, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const/16 v6, 0x3f

    move-object/from16 v0, p1

    invoke-virtual {v0, v12}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p1

    check-cast p1, Landroid/app/PendingIntent;

    const/16 v6, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v8

    const/16 v6, 0x3f

    invoke-virtual {v8, v11}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v8

    check-cast v8, Landroid/os/ResultReceiver;

    const/16 v6, 0x376

    move-object/from16 v0, p0

    iput-object v8, v0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzi:Landroid/os/ResultReceiver;

    const/16 v6, 0x57b

    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzc:Lm3;

    move-object/16 p0, v6

    const/4 v6, -0x6

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xc7

    move-object/from16 v0, p1

    invoke-virtual {v0}, Landroid/app/PendingIntent;->getIntentSender()Landroid/content/IntentSender;

    move-result-object p1

    const/4 v6, -0x6

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xb5

    new-instance v8, Lls0;

    nop

    const/16 v6, 0x9f

    move v0, v6

    move-object v1, v8

    move-object/from16 v2, p1

    move-object v3, v15

    move/from16 v4, v16

    move/from16 v5, v16

    invoke-direct/range {v1 .. v5}, Lls0;-><init>(Landroid/content/IntentSender;Landroid/content/Intent;II)V

    const/16 v6, 0xa6

    invoke-static {}, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzg()Lf3;

    move-result-object p1

    const/16 v6, 0xad

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual {v0, v8, v1}, Lm3;->a(Ljava/lang/Object;Lf3;)V

    return-void

    :cond_293
    const/16 v6, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const-string/jumbo v11, "launch_external_link_flow_pending_intent"

    nop

    nop

    const/16 v6, 0xb2

    move-object/from16 v0, p1

    invoke-virtual {v0, v11}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_312

    const/16 v6, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const/16 v6, 0x3f

    move-object/from16 v0, p1

    invoke-virtual {v0, v11}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p1

    check-cast p1, Landroid/app/PendingIntent;

    const/16 v6, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v8

    const/16 v6, 0x3f

    invoke-virtual {v8, v10}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v8

    check-cast v8, Landroid/os/ResultReceiver;

    const/16 v6, 0x3f2

    move-object/from16 v0, p0

    iput-object v8, v0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzj:Landroid/os/ResultReceiver;

    const/16 v6, 0x1027

    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzd:Lm3;

    move-object/16 p0, v6

    const/4 v6, -0x6

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xc7

    move-object/from16 v0, p1

    invoke-virtual {v0}, Landroid/app/PendingIntent;->getIntentSender()Landroid/content/IntentSender;

    move-result-object p1

    const/4 v6, -0x6

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xb5

    new-instance v8, Lls0;

    nop

    const/16 v6, 0x9f

    move v0, v6

    move-object v1, v8

    move-object/from16 v2, p1

    move-object v3, v15

    move/from16 v4, v16

    move/from16 v5, v16

    invoke-direct/range {v1 .. v5}, Lls0;-><init>(Landroid/content/IntentSender;Landroid/content/Intent;II)V

    const/16 v6, 0xa6

    invoke-static {}, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzg()Lf3;

    move-result-object p1

    const/16 v6, 0xad

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual {v0, v8, v1}, Lm3;->a(Ljava/lang/Object;Lf3;)V

    return-void

    :cond_312
    const/16 v6, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const-string/jumbo v10, "billing_program_information_dialog_pending_intent"

    nop

    nop

    const/16 v6, 0xb2

    move-object/from16 v0, p1

    invoke-virtual {v0, v10}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_391

    const/16 v6, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const/16 v6, 0x3f

    move-object/from16 v0, p1

    invoke-virtual {v0, v10}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p1

    check-cast p1, Landroid/app/PendingIntent;

    const/16 v6, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v8

    const/16 v6, 0x3f

    invoke-virtual {v8, v9}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v8

    check-cast v8, Landroid/os/ResultReceiver;

    const/16 v6, 0x476

    move-object/from16 v0, p0

    iput-object v8, v0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzk:Landroid/os/ResultReceiver;

    const/16 v6, 0xedd

    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zze:Lm3;

    move-object/16 p0, v6

    const/4 v6, -0x6

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xc7

    move-object/from16 v0, p1

    invoke-virtual {v0}, Landroid/app/PendingIntent;->getIntentSender()Landroid/content/IntentSender;

    move-result-object p1

    const/4 v6, -0x6

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xb5

    new-instance v8, Lls0;

    nop

    const/16 v6, 0x9f

    move v0, v6

    move-object v1, v8

    move-object/from16 v2, p1

    move-object v3, v15

    move/from16 v4, v16

    move/from16 v5, v16

    invoke-direct/range {v1 .. v5}, Lls0;-><init>(Landroid/content/IntentSender;Landroid/content/Intent;II)V

    const/16 v6, 0xa6

    invoke-static {}, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzg()Lf3;

    move-result-object p1

    const/16 v6, 0xad

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual {v0, v8, v1}, Lm3;->a(Ljava/lang/Object;Lf3;)V

    return-void

    :cond_391
    const/16 v6, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const-string/jumbo v9, "SUBSCRIPTION_MANAGEMENT_INTENT"

    nop

    nop

    const/16 v6, 0xb2

    move-object/from16 v0, p1

    invoke-virtual {v0, v9}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result p1

    if-eqz p1, :cond_4ae

    const/16 v6, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const/16 v6, 0x3f

    move-object/from16 v0, p1

    invoke-virtual {v0, v9}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p1

    check-cast p1, Landroid/app/PendingIntent;

    const/16 v6, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v9

    const/16 v6, 0x3f

    invoke-virtual {v9, v8}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v8

    check-cast v8, Landroid/os/ResultReceiver;

    const/16 v6, 0x348

    move-object/from16 v0, p0

    iput-object v8, v0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzl:Landroid/os/ResultReceiver;

    const/16 v6, 0xae1

    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzf:Lm3;

    move-object/16 p0, v6

    const/4 v6, -0x6

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xc7

    move-object/from16 v0, p1

    invoke-virtual {v0}, Landroid/app/PendingIntent;->getIntentSender()Landroid/content/IntentSender;

    move-result-object p1

    const/4 v6, -0x6

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xb5

    new-instance v8, Lls0;

    nop

    const/16 v6, 0x9f

    move v0, v6

    move-object v1, v8

    move-object/from16 v2, p1

    move-object v3, v15

    move/from16 v4, v16

    move/from16 v5, v16

    invoke-direct/range {v1 .. v5}, Lls0;-><init>(Landroid/content/IntentSender;Landroid/content/Intent;II)V

    const/16 v6, 0xa6

    invoke-static {}, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzg()Lf3;

    move-result-object p1

    const/16 v6, 0xad

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual {v0, v8, v1}, Lm3;->a(Ljava/lang/Object;Lf3;)V

    return-void

    :cond_410
    const/16 v6, 0x9c

    move-object/from16 v0, p1

    invoke-virtual {v0, v13}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v14

    if-eqz v14, :cond_42a

    const/16 v6, 0xc3

    move-object/from16 v0, p1

    invoke-virtual {v0, v13}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v13

    check-cast v13, Landroid/os/ResultReceiver;

    const/16 v6, 0x3a6

    move-object/from16 v0, p0

    iput-object v13, v0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzg:Landroid/os/ResultReceiver;

    :cond_42a
    const/16 v6, 0x9c

    move-object/from16 v0, p1

    invoke-virtual {v0, v12}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v13

    if-eqz v13, :cond_444

    const/16 v6, 0xc3

    move-object/from16 v0, p1

    invoke-virtual {v0, v12}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v12

    check-cast v12, Landroid/os/ResultReceiver;

    const/16 v6, 0x4ab

    move-object/from16 v0, p0

    iput-object v12, v0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzh:Landroid/os/ResultReceiver;

    :cond_444
    const/16 v6, 0x9c

    move-object/from16 v0, p1

    invoke-virtual {v0, v11}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v12

    if-eqz v12, :cond_45e

    const/16 v6, 0xc3

    move-object/from16 v0, p1

    invoke-virtual {v0, v11}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v11

    check-cast v11, Landroid/os/ResultReceiver;

    const/16 v6, 0x376

    move-object/from16 v0, p0

    iput-object v11, v0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzi:Landroid/os/ResultReceiver;

    :cond_45e
    const/16 v6, 0x9c

    move-object/from16 v0, p1

    invoke-virtual {v0, v10}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v11

    if-eqz v11, :cond_478

    const/16 v6, 0xc3

    move-object/from16 v0, p1

    invoke-virtual {v0, v10}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v10

    check-cast v10, Landroid/os/ResultReceiver;

    const/16 v6, 0x3f2

    move-object/from16 v0, p0

    iput-object v10, v0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzj:Landroid/os/ResultReceiver;

    :cond_478
    const/16 v6, 0x9c

    move-object/from16 v0, p1

    invoke-virtual {v0, v9}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v10

    if-eqz v10, :cond_492

    const/16 v6, 0xc3

    move-object/from16 v0, p1

    invoke-virtual {v0, v9}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v9

    check-cast v9, Landroid/os/ResultReceiver;

    const/16 v6, 0x476

    move-object/from16 v0, p0

    iput-object v9, v0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzk:Landroid/os/ResultReceiver;

    :cond_492
    const/16 v6, 0x9c

    move-object/from16 v0, p1

    invoke-virtual {v0, v8}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v9

    if-eqz v9, :cond_4ae

    const/16 v6, 0xc3

    move-object/from16 v0, p1

    invoke-virtual {v0, v8}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p1

    check-cast p1, Landroid/os/ResultReceiver;

    const/16 v6, 0x348

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iput-object v1, v0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzl:Landroid/os/ResultReceiver;

    :cond_4ae
    return-void
.end method

.method public final onSaveInstanceState(Landroid/os/Bundle;)V
    .registers 6
    .param p1  # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/NonNull;
        .end annotation
    .end param

    .prologue
    const/16 v0, 0x1209

    invoke-super {p0, p1}, Lut;->onSaveInstanceState(Landroid/os/Bundle;)V

    const/16 v0, 0x616

    iget-object v2, p0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzg:Landroid/os/ResultReceiver;

    nop

    if-eqz v2, :cond_16

    const-string/jumbo v3, "alternative_billing_only_dialog_result_receiver"

    nop

    nop

    const/16 v0, 0x9a

    invoke-virtual {p1, v3, v2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    :cond_16
    const/16 v0, 0x10b1

    iget-object v2, p0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzh:Landroid/os/ResultReceiver;

    nop

    if-eqz v2, :cond_27

    const-string/jumbo v3, "external_payment_dialog_result_receiver"

    nop

    nop

    const/16 v0, 0x9a

    invoke-virtual {p1, v3, v2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    :cond_27
    const/16 v0, 0xe53

    iget-object v2, p0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzi:Landroid/os/ResultReceiver;

    nop

    if-eqz v2, :cond_38

    const-string/jumbo v3, "external_offer_flow_result_receiver"

    nop

    nop

    const/16 v0, 0x9a

    invoke-virtual {p1, v3, v2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    :cond_38
    const/16 v0, 0xede

    iget-object v2, p0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzj:Landroid/os/ResultReceiver;

    nop

    if-eqz v2, :cond_49

    const-string/jumbo v3, "launch_external_link_result_receiver"

    nop

    nop

    const/16 v0, 0x9a

    invoke-virtual {p1, v3, v2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    :cond_49
    const/16 v0, 0xdc7

    iget-object v2, p0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzk:Landroid/os/ResultReceiver;

    nop

    if-eqz v2, :cond_5a

    const-string/jumbo v3, "billing_program_information_dialog_result_receiver"

    nop

    nop

    const/16 v0, 0x9a

    invoke-virtual {p1, v3, v2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    :cond_5a
    const/16 v0, 0x8d1

    iget-object p0, p0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzl:Landroid/os/ResultReceiver;

    nop

    if-eqz p0, :cond_6b

    const-string/jumbo v2, "subscription_management_action_result_receiver"

    nop

    nop

    const/16 v0, 0x9a

    invoke-virtual {p1, v2, p0}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    :cond_6b
    return-void
.end method

.method public final zza(Li3;)V
    .registers 8

    .prologue
    const/16 v0, 0x37f

    iget-object v2, p1, Li3;->b:Landroid/content/Intent;

    nop

    const-string/jumbo v3, "ProxyBillingActivityV2"

    nop

    nop

    const/16 v0, 0x7b2

    invoke-static {v2, v3}, Lcom/google/android/gms/internal/play_billing/zzc;->zzi(Landroid/content/Intent;Ljava/lang/String;)Lcom/android/billingclient/api/BillingResult;

    move-result-object v4

    const/16 v0, 0x450

    invoke-virtual {v4}, Lcom/android/billingclient/api/BillingResult;->getResponseCode()I

    move-result v4

    const/16 v0, 0x616

    iget-object v5, p0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzg:Landroid/os/ResultReceiver;

    nop

    if-eqz v5, :cond_2c

    if-nez v2, :cond_21

    const/4 v2, 0x0

    goto :goto_27

    :cond_21
    const/16 v0, 0xdf

    invoke-virtual {v2}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v2

    :goto_27
    const/16 v0, 0x3e4

    invoke-virtual {v5, v4, v2}, Landroid/os/ResultReceiver;->send(ILandroid/os/Bundle;)V

    :cond_2c
    const/16 v0, 0x1bf

    iget p1, p1, Li3;->a:I

    nop

    const/4 v2, -0x1

    if-ne p1, v2, :cond_36

    if-eqz v4, :cond_61

    :cond_36
    const/4 v0, -0x3

    new-instance v2, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v5, "Alternative billing only dialog finished with resultCode "

    nop

    nop

    const/16 v0, 0x97

    invoke-direct {v2, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x33

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo p1, " and billing\'s responseCode: "

    nop

    nop

    const/4 v0, 0x0

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x33

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0xe3

    invoke-static {v3, p1}, Lcom/google/android/gms/internal/play_billing/zzc;->zzn(Ljava/lang/String;Ljava/lang/String;)V

    :cond_61
    const/16 v0, 0x107

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    return-void
.end method

.method public final zzb(Li3;)V
    .registers 8

    .prologue
    const/16 v0, 0x37f

    iget-object v2, p1, Li3;->b:Landroid/content/Intent;

    nop

    const-string/jumbo v3, "ProxyBillingActivityV2"

    nop

    nop

    const/16 v0, 0x7b2

    invoke-static {v2, v3}, Lcom/google/android/gms/internal/play_billing/zzc;->zzi(Landroid/content/Intent;Ljava/lang/String;)Lcom/android/billingclient/api/BillingResult;

    move-result-object v4

    const/16 v0, 0x450

    invoke-virtual {v4}, Lcom/android/billingclient/api/BillingResult;->getResponseCode()I

    move-result v4

    const/16 v0, 0xdc7

    iget-object v5, p0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzk:Landroid/os/ResultReceiver;

    nop

    if-eqz v5, :cond_2c

    if-nez v2, :cond_21

    const/4 v2, 0x0

    goto :goto_27

    :cond_21
    const/16 v0, 0xdf

    invoke-virtual {v2}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v2

    :goto_27
    const/16 v0, 0x3e4

    invoke-virtual {v5, v4, v2}, Landroid/os/ResultReceiver;->send(ILandroid/os/Bundle;)V

    :cond_2c
    const/16 v0, 0x1bf

    iget p1, p1, Li3;->a:I

    nop

    const/4 v2, -0x1

    if-ne p1, v2, :cond_36

    if-eqz v4, :cond_61

    :cond_36
    const/4 v0, -0x3

    new-instance v2, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v5, "Billing program info dialog finished with resultCode "

    nop

    nop

    const/16 v0, 0x97

    invoke-direct {v2, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x33

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo p1, " and billing\'s responseCode: "

    nop

    nop

    const/4 v0, 0x0

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x33

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0xe3

    invoke-static {v3, p1}, Lcom/google/android/gms/internal/play_billing/zzc;->zzn(Ljava/lang/String;Ljava/lang/String;)V

    :cond_61
    const/16 v0, 0x107

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    return-void
.end method

.method public final zzc(Li3;)V
    .registers 8

    .prologue
    const/16 v0, 0x37f

    iget-object v2, p1, Li3;->b:Landroid/content/Intent;

    nop

    const-string/jumbo v3, "ProxyBillingActivityV2"

    nop

    nop

    const/16 v0, 0x7b2

    invoke-static {v2, v3}, Lcom/google/android/gms/internal/play_billing/zzc;->zzi(Landroid/content/Intent;Ljava/lang/String;)Lcom/android/billingclient/api/BillingResult;

    move-result-object v4

    const/16 v0, 0x450

    invoke-virtual {v4}, Lcom/android/billingclient/api/BillingResult;->getResponseCode()I

    move-result v4

    const/16 v0, 0x10b1

    iget-object v5, p0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzh:Landroid/os/ResultReceiver;

    nop

    if-eqz v5, :cond_2c

    if-nez v2, :cond_21

    const/4 v2, 0x0

    goto :goto_27

    :cond_21
    const/16 v0, 0xdf

    invoke-virtual {v2}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v2

    :goto_27
    const/16 v0, 0x3e4

    invoke-virtual {v5, v4, v2}, Landroid/os/ResultReceiver;->send(ILandroid/os/Bundle;)V

    :cond_2c
    const/16 v0, 0x1bf

    iget p1, p1, Li3;->a:I

    nop

    const/4 v2, -0x1

    if-ne p1, v2, :cond_36

    if-eqz v4, :cond_61

    :cond_36
    const/4 v0, -0x3

    new-instance v2, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v5, "External offer dialog finished with resultCode: "

    nop

    nop

    const/16 v0, 0x97

    invoke-direct {v2, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x33

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo p1, " and billing\'s responseCode: "

    nop

    nop

    const/4 v0, 0x0

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x33

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0xe3

    invoke-static {v3, p1}, Lcom/google/android/gms/internal/play_billing/zzc;->zzn(Ljava/lang/String;Ljava/lang/String;)V

    :cond_61
    const/16 v0, 0x107

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    return-void
.end method

.method public final zzd(Li3;)V
    .registers 9

    .prologue
    const/16 v0, 0x37f

    iget-object v2, p1, Li3;->b:Landroid/content/Intent;

    nop

    const/16 v0, 0x1bf

    iget p1, p1, Li3;->a:I

    nop

    if-nez v2, :cond_e

    const/4 v3, 0x0

    goto :goto_14

    :cond_e
    const/16 v0, 0xdf

    invoke-virtual {v2}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v3

    :goto_14
    const/4 v4, -0x1

    const-string/jumbo v5, "ProxyBillingActivityV2"

    nop

    nop

    if-eq p1, v4, :cond_7c

    if-nez v3, :cond_28

    const/16 v0, 0x108

    new-instance v3, Landroid/os/Bundle;

    nop

    const/16 v0, 0x198

    invoke-direct {v3}, Landroid/os/Bundle;-><init>()V

    :cond_28
    const/4 v0, -0x3

    new-instance v4, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v6, "External offer flow finished with resultCode: "

    nop

    nop

    const/16 v0, 0x97

    invoke-direct {v4, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x33

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/16 v0, 0xe3

    invoke-static {v5, v4}, Lcom/google/android/gms/internal/play_billing/zzc;->zzn(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v0, 0x10f0

    sget-object v4, Lcom/google/android/gms/internal/play_billing/zzjs;->zzbv:Lcom/google/android/gms/internal/play_billing/zzjs;

    nop

    const/16 v0, 0xbf5

    invoke-virtual {v4}, Lcom/google/android/gms/internal/play_billing/zzjs;->zza()I

    move-result v4

    const-string/jumbo v6, "INTERNAL_LOG_ERROR_REASON"

    nop

    nop

    const/16 v0, 0x23e

    invoke-virtual {v3, v6, v4}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v0, -0x3

    new-instance v4, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v6, "External offer flow finished with error resultCode: "

    nop

    nop

    const/16 v0, 0x97

    invoke-direct {v4, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x33

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string/jumbo v4, "INTERNAL_LOG_ERROR_ADDITIONAL_DETAILS"

    nop

    nop

    const/16 v0, 0x76

    invoke-virtual {v3, v4, p1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    :cond_7c
    const/16 v0, 0x7b2

    invoke-static {v2, v5}, Lcom/google/android/gms/internal/play_billing/zzc;->zzi(Landroid/content/Intent;Ljava/lang/String;)Lcom/android/billingclient/api/BillingResult;

    move-result-object p1

    const/16 v0, 0x450

    invoke-virtual {p1}, Lcom/android/billingclient/api/BillingResult;->getResponseCode()I

    move-result p1

    const/16 v0, 0xe53

    iget-object v2, p0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzi:Landroid/os/ResultReceiver;

    nop

    if-eqz v2, :cond_95

    const/16 v0, 0x3e4

    invoke-virtual {v2, p1, v3}, Landroid/os/ResultReceiver;->send(ILandroid/os/Bundle;)V

    goto :goto_9f

    :cond_95
    const-string/jumbo v2, "External offer flow result receiver is null"

    nop

    nop

    const/16 v0, 0xe3

    invoke-static {v5, v2}, Lcom/google/android/gms/internal/play_billing/zzc;->zzn(Ljava/lang/String;Ljava/lang/String;)V

    :goto_9f
    if-eqz p1, :cond_be

    const/4 v0, -0x3

    new-instance v2, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v3, "External offer flow finished with billing responseCode: "

    nop

    nop

    const/16 v0, 0x97

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x33

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0xe3

    invoke-static {v5, p1}, Lcom/google/android/gms/internal/play_billing/zzc;->zzn(Ljava/lang/String;Ljava/lang/String;)V

    :cond_be
    const/16 v0, 0x107

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    return-void
.end method

.method public final zze(Li3;)V
    .registers 9

    .prologue
    const/16 v0, 0x37f

    iget-object v2, p1, Li3;->b:Landroid/content/Intent;

    nop

    const/16 v0, 0x1bf

    iget p1, p1, Li3;->a:I

    nop

    if-nez v2, :cond_e

    const/4 v3, 0x0

    goto :goto_14

    :cond_e
    const/16 v0, 0xdf

    invoke-virtual {v2}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v3

    :goto_14
    const/4 v4, -0x1

    const-string/jumbo v5, "ProxyBillingActivityV2"

    nop

    nop

    if-eq p1, v4, :cond_7c

    if-nez v3, :cond_28

    const/16 v0, 0x108

    new-instance v3, Landroid/os/Bundle;

    nop

    const/16 v0, 0x198

    invoke-direct {v3}, Landroid/os/Bundle;-><init>()V

    :cond_28
    const/4 v0, -0x3

    new-instance v4, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v6, "Launch external link flow finished with resultCode: "

    nop

    nop

    const/16 v0, 0x97

    invoke-direct {v4, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x33

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/16 v0, 0xe3

    invoke-static {v5, v4}, Lcom/google/android/gms/internal/play_billing/zzc;->zzn(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v0, 0x10f0

    sget-object v4, Lcom/google/android/gms/internal/play_billing/zzjs;->zzbv:Lcom/google/android/gms/internal/play_billing/zzjs;

    nop

    const/16 v0, 0xbf5

    invoke-virtual {v4}, Lcom/google/android/gms/internal/play_billing/zzjs;->zza()I

    move-result v4

    const-string/jumbo v6, "INTERNAL_LOG_ERROR_REASON"

    nop

    nop

    const/16 v0, 0x23e

    invoke-virtual {v3, v6, v4}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v0, -0x3

    new-instance v4, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v6, "Launch external link flow finished with error resultCode: "

    nop

    nop

    const/16 v0, 0x97

    invoke-direct {v4, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x33

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string/jumbo v4, "INTERNAL_LOG_ERROR_ADDITIONAL_DETAILS"

    nop

    nop

    const/16 v0, 0x76

    invoke-virtual {v3, v4, p1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    :cond_7c
    const/16 v0, 0x7b2

    invoke-static {v2, v5}, Lcom/google/android/gms/internal/play_billing/zzc;->zzi(Landroid/content/Intent;Ljava/lang/String;)Lcom/android/billingclient/api/BillingResult;

    move-result-object p1

    const/16 v0, 0x450

    invoke-virtual {p1}, Lcom/android/billingclient/api/BillingResult;->getResponseCode()I

    move-result p1

    const/16 v0, 0xede

    iget-object v2, p0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzj:Landroid/os/ResultReceiver;

    nop

    if-eqz v2, :cond_95

    const/16 v0, 0x3e4

    invoke-virtual {v2, p1, v3}, Landroid/os/ResultReceiver;->send(ILandroid/os/Bundle;)V

    goto :goto_9f

    :cond_95
    const-string/jumbo v2, "Launch external link flow result receiver is null"

    nop

    nop

    const/16 v0, 0xe3

    invoke-static {v5, v2}, Lcom/google/android/gms/internal/play_billing/zzc;->zzn(Ljava/lang/String;Ljava/lang/String;)V

    :goto_9f
    if-eqz p1, :cond_be

    const/4 v0, -0x3

    new-instance v2, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v3, "Launch external link flow finished with billing responseCode: "

    nop

    nop

    const/16 v0, 0x97

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x33

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0xe3

    invoke-static {v5, p1}, Lcom/google/android/gms/internal/play_billing/zzc;->zzn(Ljava/lang/String;Ljava/lang/String;)V

    :cond_be
    const/16 v0, 0x107

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    return-void
.end method

.method public final zzf(Li3;)V
    .registers 8

    .prologue
    const/16 v0, 0x37f

    iget-object v2, p1, Li3;->b:Landroid/content/Intent;

    nop

    const-string/jumbo v3, "ProxyBillingActivityV2"

    nop

    nop

    const/16 v0, 0x7b2

    invoke-static {v2, v3}, Lcom/google/android/gms/internal/play_billing/zzc;->zzi(Landroid/content/Intent;Ljava/lang/String;)Lcom/android/billingclient/api/BillingResult;

    move-result-object v4

    const/16 v0, 0x450

    invoke-virtual {v4}, Lcom/android/billingclient/api/BillingResult;->getResponseCode()I

    move-result v4

    const/16 v0, 0x8d1

    iget-object v5, p0, Lcom/android/billingclient/api/ProxyBillingActivityV2;->zzl:Landroid/os/ResultReceiver;

    nop

    if-eqz v5, :cond_2c

    if-nez v2, :cond_21

    const/4 v2, 0x0

    goto :goto_27

    :cond_21
    const/16 v0, 0xdf

    invoke-virtual {v2}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v2

    :goto_27
    const/16 v0, 0x3e4

    invoke-virtual {v5, v4, v2}, Landroid/os/ResultReceiver;->send(ILandroid/os/Bundle;)V

    :cond_2c
    const/16 v0, 0x1bf

    iget p1, p1, Li3;->a:I

    nop

    const/4 v2, -0x1

    if-ne p1, v2, :cond_36

    if-eqz v4, :cond_61

    :cond_36
    const/4 v0, -0x3

    new-instance v2, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v5, "Subscription management action finished with resultCode: "

    nop

    nop

    const/16 v0, 0x97

    invoke-direct {v2, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x33

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo p1, " and billing\'s responseCode: "

    nop

    nop

    const/4 v0, 0x0

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x33

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0xe3

    invoke-static {v3, p1}, Lcom/google/android/gms/internal/play_billing/zzc;->zzn(Ljava/lang/String;Ljava/lang/String;)V

    :cond_61
    const/16 v0, 0x107

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    return-void
.end method
