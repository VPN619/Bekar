.class public final Lcom/vungle/ads/internal/ui/VungleActivity;
.super Lcom/vungle/ads/internal/ui/l;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# direct methods
.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Lcom/vungle/ads/internal/ui/l;-><init>()V

    return-void
.end method
