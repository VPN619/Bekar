.class public Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;
.super Lcom/mbridge/msdk/video/signal/activity/AbstractJSActivity;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity$f;,
        Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity$e;
    }
.end annotation


# static fields
.field public static INTENT_LOCAL_REQUEST_ID:Ljava/lang/String;

.field public static SAVE_STATE_KEY_REPORT:Ljava/lang/String;


# instance fields
.field private A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

.field private B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

.field private C:Lcom/mbridge/msdk/mbsignalcommon/windvane/WindVaneWebView;

.field private D:Lcom/mbridge/msdk/video/bt/module/listener/a;

.field private E:Ljava/lang/String;

.field private F:Ljava/lang/String;

.field private G:Z

.field private H:I

.field private I:I

.field private J:I

.field private K:I

.field private L:I

.field private M:I

.field private N:I

.field private O:Ljava/lang/String;

.field private P:Lcom/mbridge/msdk/foundation/same/report/metrics/c;

.field private Q:Z

.field private R:Z

.field private S:Lp4;

.field private T:Lz71;

.field private U:Li4;

.field private V:J

.field private W:Ljava/lang/String;

.field private X:Ljava/lang/Boolean;

.field private Y:I

.field private Z:Z

.field private a0:Z

.field private b0:Z

.field private c0:I

.field private d0:Ljava/lang/String;

.field private e0:Lcom/mbridge/msdk/video/dynview/listener/a;

.field private f0:Lcom/mbridge/msdk/video/dynview/listener/d;

.field private g:Ljava/lang/String;

.field private h:Ljava/lang/String;

.field private i:Ljava/lang/String;

.field private j:Lcom/mbridge/msdk/videocommon/entity/c;

.field private k:I

.field private l:Z

.field private m:Z

.field private n:I

.field private o:I

.field private p:I

.field private q:Z

.field private r:Z

.field private s:Lcom/mbridge/msdk/video/bt/module/orglistener/h;

.field private t:Lcom/mbridge/msdk/videocommon/setting/c;

.field private u:Z

.field private v:Z

.field private w:Lcom/mbridge/msdk/videocommon/download/a;

.field private x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

.field private y:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/mbridge/msdk/videocommon/download/a;",
            ">;"
        }
    .end annotation
.end field

.field private z:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/mbridge/msdk/foundation/entity/CampaignEx;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-string/jumbo v0, "lRid"

    nop

    nop

    sput-object v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->INTENT_LOCAL_REQUEST_ID:Ljava/lang/String;

    const-string/jumbo v0, "hasRelease"

    nop

    nop

    sput-object v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->SAVE_STATE_KEY_REPORT:Ljava/lang/String;

    return-void
.end method

.method public constructor <init>()V
    .registers 7

    invoke-direct {p0}, Lcom/mbridge/msdk/video/signal/activity/AbstractJSActivity;-><init>()V

    const/4 v2, 0x2

    const/16 v0, 0xae3

    iput v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->k:I

    const/4 v2, 0x0

    const/16 v0, 0x89b

    iput-boolean v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->l:Z

    const/16 v0, 0x73e

    iput-boolean v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->m:Z

    const/16 v0, 0x452

    iput-boolean v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->q:Z

    const/16 v0, 0xc71

    iput-boolean v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->r:Z

    const/16 v0, 0x9c4

    iput-boolean v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->u:Z

    const/16 v0, 0x7fa

    iput-boolean v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->v:Z

    const/4 v3, 0x1

    const/16 v0, 0xc1d

    iput v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->H:I

    const/16 v0, 0xa44

    iput v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->I:I

    const/16 v0, 0x8b8

    iput v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->J:I

    const/16 v0, 0x78d

    iput v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->K:I

    const/16 v0, 0x60b

    iput v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->L:I

    const/16 v0, 0x114c

    iput v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->M:I

    const/16 v0, 0xf9c

    iput v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->N:I

    const/16 v0, 0xb00

    iput-boolean v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->Q:Z

    const/4 v3, 0x0

    const/16 v0, 0x7f6

    iput-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->S:Lp4;

    const/16 v0, 0x9f3

    iput-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->T:Lz71;

    const/16 v0, 0x91a

    iput-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->U:Li4;

    const-wide/16 v4, 0x0

    const/16 v0, 0x119c

    iput-wide v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->V:J

    const-string/jumbo v4, ""

    const/16 v0, 0x867

    iput-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->W:Ljava/lang/String;

    const/16 v0, 0x29d

    iput-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->X:Ljava/lang/Boolean;

    const/16 v0, 0xbd1

    iput v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->Y:I

    const/16 v0, 0xbb0

    iput-boolean v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->Z:Z

    const/16 v0, 0xacc

    iput-boolean v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->a0:Z

    const/16 v0, 0xcde

    iput-boolean v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->b0:Z

    const/4 v2, -0x1

    const/16 v0, 0x3cb

    iput v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->c0:I

    const-string/jumbo v2, "null"

    nop

    nop

    const/16 v0, 0x1253

    iput-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->d0:Ljava/lang/String;

    const/16 v0, 0xa31

    new-instance v2, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity$a;

    nop

    const/16 v0, 0x899

    invoke-direct {v2, p0}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity$a;-><init>(Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;)V

    const/16 v0, 0xf69

    iput-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->e0:Lcom/mbridge/msdk/video/dynview/listener/a;

    const/16 v0, 0x7bf

    new-instance v2, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity$b;

    nop

    const/16 v0, 0x642

    invoke-direct {v2, p0}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity$b;-><init>(Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;)V

    const/16 v0, 0xa4b

    iput-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->f0:Lcom/mbridge/msdk/video/dynview/listener/d;

    return-void
.end method

.method private a(II)I
    .registers 10

    .prologue
    const/16 v0, 0x60

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    nop

    if-nez v2, :cond_8

    goto :goto_6a

    :cond_8
    const/16 v0, 0x17d

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    if-nez v2, :cond_11

    goto :goto_6a

    :cond_11
    const/4 v2, 0x0

    move v3, v2

    move v4, v3

    move v5, v4

    :goto_15
    const/16 v0, 0x60

    iget-object v6, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    nop

    const/16 v0, 0x17d

    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v6

    if-ge v3, v6, :cond_5b

    const/16 v0, 0x60

    iget-object v6, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    nop

    const/16 v0, 0x24

    invoke-interface {v6, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    if-eqz v6, :cond_58

    if-nez v3, :cond_44

    const/16 v0, 0x60

    iget-object v5, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    nop

    const/16 v0, 0x24

    invoke-interface {v5, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    const/16 v0, 0xf4b

    invoke-virtual {v5}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->getVideoCompleteTime()I

    move-result v5

    :cond_44
    const/16 v0, 0x60

    iget-object v6, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    nop

    const/16 v0, 0x24

    invoke-interface {v6, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    const/16 v0, 0x3b5

    invoke-virtual {v6}, Lcom/mbridge/msdk/out/Campaign;->getVideoLength()I

    move-result v6

    add-int/2addr v4, v6

    :cond_58
    add-int/lit8 v3, v3, 0x1

    goto :goto_15

    :cond_5b
    const/4 v3, 0x1

    if-ne p2, v3, :cond_6c

    const/16 p0, 0x2d

    if-nez p1, :cond_65

    if-lt v4, p0, :cond_6b

    return p0

    :cond_65
    if-le v4, p1, :cond_6b

    if-le p1, p0, :cond_6a

    return p0

    :cond_6a
    :goto_6a
    return p1

    :cond_6b
    return v4

    :cond_6c
    move p1, v2

    move v4, p1

    :goto_6e
    add-int/lit8 v6, p2, -0x1

    if-ge p1, v6, :cond_96

    const/16 v0, 0x60

    iget-object v6, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    nop

    const/16 v0, 0x24

    invoke-interface {v6, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    if-eqz v6, :cond_93

    const/16 v0, 0x60

    iget-object v6, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    nop

    const/16 v0, 0x24

    invoke-interface {v6, p1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    const/16 v0, 0x3b5

    invoke-virtual {v6}, Lcom/mbridge/msdk/out/Campaign;->getVideoLength()I

    move-result v6

    add-int/2addr v4, v6

    :cond_93
    add-int/lit8 p1, p1, 0x1

    goto :goto_6e

    :cond_96
    if-le v5, v4, :cond_9a

    sub-int/2addr v5, v4

    return v5

    :cond_9a
    return v2
.end method

.method public static synthetic a(Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;I)I
    .registers 4

    const/4 v1, 0x0

    const/16 v0, 0xae3

    iput p1, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->k:I

    return p1
.end method

.method public static synthetic a(Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;II)I
    .registers 5

    const/16 v0, 0xab4

    invoke-direct {p0, p1, p2}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->a(II)I

    move-result p0

    return p0
.end method

.method public static synthetic a(Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;Lcom/mbridge/msdk/foundation/entity/CampaignEx;)Lcom/mbridge/msdk/foundation/entity/CampaignEx;
    .registers 4

    const/16 v1, 0x1bc

    iput-object p1, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    return-object p1
.end method

.method private a(Ljava/lang/String;)Lcom/mbridge/msdk/mbsignalcommon/windvane/WindVaneWebView;
    .registers 4

    .prologue
    const/16 v0, 0xdac

    invoke-static {p1}, Lcom/mbridge/msdk/videocommon/a;->b(Ljava/lang/String;)Lcom/mbridge/msdk/videocommon/a$a;

    move-result-object p0

    if-eqz p0, :cond_11

    const/16 v0, 0xeb0

    invoke-virtual {p0}, Lcom/mbridge/msdk/videocommon/a$a;->b()Lcom/mbridge/msdk/mbsignalcommon/windvane/WindVaneWebView;

    move-result-object p0

    check-cast p0, Lcom/mbridge/msdk/mbsignalcommon/windvane/WindVaneWebView;

    return-object p0

    :cond_11
    const/4 p0, 0x0

    return-object p0
.end method

.method public static synthetic a(Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;)Ljava/util/List;
    .registers 3

    const/4 v1, 0x0

    const/16 v0, 0x60

    iget-object p0, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    nop

    check-cast p0, Ljava/util/List;

    return-object p0
.end method

.method private a(Lcom/mbridge/msdk/foundation/entity/CampaignEx;)V
    .registers 5

    .prologue
    if-eqz p1, :cond_40

    const/16 v0, 0x497

    invoke-virtual {p1}, Lcom/mbridge/msdk/out/Campaign;->getImageUrl()Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x3ca

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p0

    if-nez p0, :cond_21

    const/16 v0, 0x471

    invoke-static {}, Lrt2;->d()Lcom/mbridge/msdk/foundation/same/image/b;

    move-result-object p0

    const/16 v0, 0x497

    invoke-virtual {p1}, Lcom/mbridge/msdk/out/Campaign;->getImageUrl()Ljava/lang/String;

    move-result-object v2

    const/16 v0, 0x523

    invoke-virtual {p0, v2}, Lcom/mbridge/msdk/foundation/same/image/b;->a(Ljava/lang/String;)V

    :cond_21
    const/16 v0, 0x36d

    invoke-virtual {p1}, Lcom/mbridge/msdk/out/Campaign;->getIconUrl()Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x3ca

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p0

    if-nez p0, :cond_40

    const/16 v0, 0x471

    invoke-static {}, Lrt2;->d()Lcom/mbridge/msdk/foundation/same/image/b;

    move-result-object p0

    const/16 v0, 0x36d

    invoke-virtual {p1}, Lcom/mbridge/msdk/out/Campaign;->getIconUrl()Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0x523

    invoke-virtual {p0, p1}, Lcom/mbridge/msdk/foundation/same/image/b;->a(Ljava/lang/String;)V

    :cond_40
    return-void
.end method

.method public static synthetic a(Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;Ljava/lang/String;)V
    .registers 4

    const/16 v0, 0x50

    invoke-direct {p0, p1}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->b(Ljava/lang/String;)V

    return-void
.end method

.method private a(Ljava/util/List;)V
    .registers 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/mbridge/msdk/foundation/entity/CampaignEx;",
            ">;)V"
        }
    .end annotation

    .prologue
    const/16 v0, 0x5a8

    iget-boolean v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->R:Z

    nop

    if-eqz v2, :cond_9

    goto/16 :goto_19c

    :cond_9
    const/4 v2, 0x0

    if-nez p1, :cond_5f

    :try_start_c
    const/16 v0, 0x524

    iget-boolean p1, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->q:Z

    nop

    if-eqz p1, :cond_19

    const/16 v0, 0x60

    iget-object p1, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    nop

    goto :goto_5f

    :cond_19
    const/16 v0, 0xd7

    new-instance p1, Ljava/util/ArrayList;

    nop

    const/16 v0, 0x16b

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    const/16 v0, 0x14f

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->y:Ljava/util/List;

    nop

    if-eqz v3, :cond_5f

    const/16 v0, 0x24

    invoke-interface {v3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    if-eqz v3, :cond_5f

    const/16 v0, 0x14f

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->y:Ljava/util/List;

    nop

    const/16 v0, 0x24

    invoke-interface {v3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/mbridge/msdk/videocommon/download/a;

    const/16 v0, 0x2c9

    invoke-virtual {v3}, Lcom/mbridge/msdk/videocommon/download/a;->h()Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    move-result-object v3

    if-eqz v3, :cond_5f

    const/16 v0, 0x14f

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->y:Ljava/util/List;

    nop

    const/16 v0, 0x24

    invoke-interface {v3, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/mbridge/msdk/videocommon/download/a;

    const/16 v0, 0x2c9

    invoke-virtual {v3}, Lcom/mbridge/msdk/videocommon/download/a;->h()Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    move-result-object v3

    const/16 v0, 0x174

    invoke-virtual {p1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_5f
    :goto_5f
    const-string/jumbo v3, ""

    if-eqz p1, :cond_7c

    const/16 v0, 0xeb6

    invoke-interface {p1}, Ljava/util/List;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_7c

    const/16 v0, 0x24

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    if-eqz v2, :cond_7c

    const/16 v0, 0x1cf

    invoke-virtual {v2}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->getCurrentLocalRid()Ljava/lang/String;

    move-result-object v3

    :cond_7c
    const/16 v0, 0x3ca

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2
    :try_end_82
    .catch Ljava/lang/Exception; {:try_start_c .. :try_end_82} :catch_18f

    const-string/jumbo v4, "activity_name"

    nop

    nop

    const-string/jumbo v5, "context_status"

    nop

    nop

    const-string/jumbo v6, "2000129"

    nop

    nop

    if-nez v2, :cond_cc

    :try_start_93
    const/16 v0, 0x2d6

    new-instance v2, Lcom/mbridge/msdk/foundation/same/report/metrics/e;

    nop

    const/16 v0, 0x4d2

    invoke-direct {v2}, Lcom/mbridge/msdk/foundation/same/report/metrics/e;-><init>()V

    const/16 v0, 0x352

    iget v7, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->c0:I

    nop

    const/16 v0, 0xb1

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    const/16 v0, 0x5c

    invoke-virtual {v2, v5, v7}, Lcom/mbridge/msdk/foundation/same/report/metrics/e;->a(Ljava/lang/String;Ljava/lang/Object;)V

    const/16 v0, 0x33a

    iget-object v7, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->d0:Ljava/lang/String;

    nop

    const/16 v0, 0x5c

    invoke-virtual {v2, v4, v7}, Lcom/mbridge/msdk/foundation/same/report/metrics/e;->a(Ljava/lang/String;Ljava/lang/Object;)V

    const/16 v0, 0xb51

    invoke-static {}, Lcom/mbridge/msdk/foundation/same/report/metrics/d;->b()Lcom/mbridge/msdk/foundation/same/report/metrics/d;

    move-result-object v7

    const/16 v0, 0x1144

    invoke-virtual {v7, v3}, Lcom/mbridge/msdk/foundation/same/report/metrics/d;->b(Ljava/lang/String;)Lcom/mbridge/msdk/foundation/same/report/metrics/c;

    move-result-object v3

    const/16 v0, 0x444

    iput-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->P:Lcom/mbridge/msdk/foundation/same/report/metrics/c;

    const/16 v0, 0x427

    invoke-virtual {v3, v6, v2}, Lcom/mbridge/msdk/foundation/same/report/metrics/c;->a(Ljava/lang/String;Lcom/mbridge/msdk/foundation/same/report/metrics/e;)V

    :cond_cc
    const/16 v0, 0x189

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->P:Lcom/mbridge/msdk/foundation/same/report/metrics/c;

    nop

    if-nez v2, :cond_16d

    const/16 v0, 0x9f8

    new-instance v2, Lcom/mbridge/msdk/foundation/same/report/metrics/c;

    nop

    const/16 v0, 0x728

    invoke-direct {v2}, Lcom/mbridge/msdk/foundation/same/report/metrics/c;-><init>()V

    const/16 v0, 0x444

    iput-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->P:Lcom/mbridge/msdk/foundation/same/report/metrics/c;

    const/16 v0, 0x2d6

    new-instance v2, Lcom/mbridge/msdk/foundation/same/report/metrics/e;

    nop

    const/16 v0, 0x4d2

    invoke-direct {v2}, Lcom/mbridge/msdk/foundation/same/report/metrics/e;-><init>()V

    const-string/jumbo v3, "unit_id"

    nop

    nop

    const/16 v0, 0x55

    iget-object v7, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->g:Ljava/lang/String;

    nop

    const/16 v0, 0x5c

    invoke-virtual {v2, v3, v7}, Lcom/mbridge/msdk/foundation/same/report/metrics/e;->a(Ljava/lang/String;Ljava/lang/Object;)V

    const-string/jumbo v3, "hb"

    nop

    nop

    const/16 v0, 0xb20

    iget-boolean v7, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->m:Z

    nop

    const/16 v0, 0xb1

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    const/16 v0, 0x5c

    invoke-virtual {v2, v3, v7}, Lcom/mbridge/msdk/foundation/same/report/metrics/e;->a(Ljava/lang/String;Ljava/lang/Object;)V

    const-string/jumbo v3, "adtp"

    nop

    nop

    const/16 v0, 0x10c

    iget-boolean v7, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->l:Z

    nop

    if-eqz v7, :cond_11e

    const/16 v7, 0x11f

    goto :goto_120

    :cond_11e
    const/16 v7, 0x5e

    :goto_120
    const/16 v0, 0xb1

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    const/16 v0, 0x5c

    invoke-virtual {v2, v3, v7}, Lcom/mbridge/msdk/foundation/same/report/metrics/e;->a(Ljava/lang/String;Ljava/lang/Object;)V

    const-string/jumbo v3, "lrid"

    nop

    nop

    const/16 v0, 0x717

    iget-object v7, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->O:Ljava/lang/String;

    nop

    const/16 v0, 0x5c

    invoke-virtual {v2, v3, v7}, Lcom/mbridge/msdk/foundation/same/report/metrics/e;->a(Ljava/lang/String;Ljava/lang/Object;)V

    const-string/jumbo v3, "his_reason"

    nop

    nop

    const-string/jumbo v7, "show campaign is null"

    nop

    nop

    const/16 v0, 0x5c

    invoke-virtual {v2, v3, v7}, Lcom/mbridge/msdk/foundation/same/report/metrics/e;->a(Ljava/lang/String;Ljava/lang/Object;)V

    const/16 v0, 0x352

    iget v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->c0:I

    nop

    const/16 v0, 0xb1

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/16 v0, 0x5c

    invoke-virtual {v2, v5, v3}, Lcom/mbridge/msdk/foundation/same/report/metrics/e;->a(Ljava/lang/String;Ljava/lang/Object;)V

    const/16 v0, 0x33a

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->d0:Ljava/lang/String;

    nop

    const/16 v0, 0x5c

    invoke-virtual {v2, v4, v3}, Lcom/mbridge/msdk/foundation/same/report/metrics/e;->a(Ljava/lang/String;Ljava/lang/Object;)V

    const/16 v0, 0x189

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->P:Lcom/mbridge/msdk/foundation/same/report/metrics/c;

    nop

    const/16 v0, 0x427

    invoke-virtual {v3, v6, v2}, Lcom/mbridge/msdk/foundation/same/report/metrics/c;->a(Ljava/lang/String;Lcom/mbridge/msdk/foundation/same/report/metrics/e;)V

    :cond_16d
    if-eqz p1, :cond_179

    const/16 v0, 0x189

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->P:Lcom/mbridge/msdk/foundation/same/report/metrics/c;

    nop

    const/16 v0, 0xd77

    invoke-virtual {v2, p1}, Lcom/mbridge/msdk/foundation/same/report/metrics/c;->b(Ljava/util/List;)V

    :cond_179
    const/4 p1, 0x1

    const/16 v0, 0x956

    iput-boolean p1, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->R:Z

    const/16 v0, 0x864

    invoke-static {}, Lcom/mbridge/msdk/reward/report/metrics/a;->a()Lcom/mbridge/msdk/reward/report/metrics/a;

    move-result-object p1

    const/16 v0, 0x189

    iget-object p0, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->P:Lcom/mbridge/msdk/foundation/same/report/metrics/c;

    nop

    const/16 v0, 0x9c0

    invoke-virtual {p1, v6, p0}, Lcom/mbridge/msdk/reward/report/metrics/a;->a(Ljava/lang/String;Lcom/mbridge/msdk/foundation/same/report/metrics/c;)V
    :try_end_18e
    .catch Ljava/lang/Exception; {:try_start_93 .. :try_end_18e} :catch_18f

    return-void

    :catch_18f
    move-exception p0

    const/16 v0, 0x58d

    sget-boolean p1, Lcom/mbridge/msdk/MBridgeConstans;->DEBUG:Z

    nop

    if-eqz p1, :cond_19c

    const/16 v0, 0xa8e

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_19c
    :goto_19c
    return-void
.end method

.method public static synthetic a(Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;Z)Z
    .registers 4

    const/4 v1, 0x0

    const/16 v0, 0x452

    iput-boolean p1, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->q:Z

    return p1
.end method

.method public static synthetic b(Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;I)I
    .registers 5

    const/16 v1, 0xcdb

    iget v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->I:I

    nop

    sub-int/2addr v2, p1

    const/16 v0, 0xa44

    iput v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->I:I

    return v2
.end method

.method private b(Lcom/mbridge/msdk/foundation/entity/CampaignEx;)V
    .registers 22

    .prologue
    if-eqz p1, :cond_af

    :try_start_2
    const/16 v9, 0x88b

    move-object/from16 v0, p1

    invoke-virtual {v0}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->isActiveOm()Z

    move-result v11

    if-eqz v11, :cond_af

    const/16 v9, 0x228

    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->S:Lp4;

    nop

    if-nez v11, :cond_af

    const/16 v9, 0x53

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v12

    const/16 v9, 0x1186

    move-object/from16 v0, p1

    invoke-virtual {v0}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->getOmid()Ljava/lang/String;

    move-result-object v14

    const/16 v9, 0x2ed

    move-object/from16 v0, p1

    invoke-virtual {v0}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->getRequestId()Ljava/lang/String;

    move-result-object v15

    const/16 v9, 0x33d

    move-object/from16 v0, p1

    invoke-virtual {v0}, Lcom/mbridge/msdk/out/Campaign;->getId()Ljava/lang/String;

    move-result-object v16

    const/16 v9, 0x55

    move-object/from16 v0, p0

    iget-object v9, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->g:Ljava/lang/String;

    move-object/16 v17, v9

    const/16 v9, 0x85a

    move-object/from16 v0, p1

    invoke-virtual {v0}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->getVideoUrlEncode()Ljava/lang/String;

    move-result-object v18

    const/16 v9, 0xf64

    move-object/from16 v0, p1

    invoke-virtual {v0}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->getRequestIdNotice()Ljava/lang/String;

    move-result-object v19

    const/4 v13, 0x0

    const/16 v9, 0x546

    move v0, v9

    move-object v1, v12

    move v2, v13

    move-object v3, v14

    move-object v4, v15

    move-object/from16 v5, v16

    move-object/from16 v6, v17

    move-object/from16 v7, v18

    move-object/from16 v8, v19

    invoke-static/range {v1 .. v8}, Lcom/mbridge/msdk/omsdk/b;->a(Landroid/content/Context;ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Lp4;

    move-result-object p1

    const/16 v9, 0x7f6

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iput-object v1, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->S:Lp4;

    if-eqz p1, :cond_af

    const/16 v9, 0x92e

    move-object/from16 v0, p1

    invoke-static {v0}, Li4;->a(Lp4;)Li4;

    move-result-object p1

    const/16 v9, 0x91a

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iput-object v1, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->U:Li4;

    const/16 v9, 0x228

    move-object/from16 v0, p0

    iget-object v9, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->S:Lp4;

    move-object/16 p1, v9

    const/16 v9, 0xfde

    move-object/from16 v0, p1

    invoke-static {v0}, Lz71;->d(Lp4;)Lz71;

    move-result-object p1

    const/16 v9, 0x9f3

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iput-object v1, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->T:Lz71;
    :try_end_95
    .catchall {:try_start_2 .. :try_end_95} :catchall_96

    return-void

    :catchall_96
    move-exception v11

    move-object/from16 p0, v11

    const/16 v9, 0x1da

    move-object/from16 v0, p0

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const-string/jumbo p1, "MBRewardVideoActivity"

    nop

    nop

    const/16 v9, 0xd96

    move-object/from16 v0, p1

    move-object/from16 v1, p0

    invoke-static {v0, v1}, Lcom/mbridge/msdk/foundation/tools/q0;->b(Ljava/lang/String;Ljava/lang/String;)V

    :cond_af
    return-void
.end method

.method public static synthetic b(Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;)V
    .registers 3

    const/16 v0, 0x3ae

    invoke-direct {p0}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->j()V

    return-void
.end method

.method public static synthetic b(Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;Lcom/mbridge/msdk/foundation/entity/CampaignEx;)V
    .registers 4

    const/16 v0, 0xd46

    invoke-direct {p0, p1}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->c(Lcom/mbridge/msdk/foundation/entity/CampaignEx;)V

    return-void
.end method

.method private b(Ljava/lang/String;)V
    .registers 6

    .prologue
    const-string/jumbo v2, "MBRewardVideoActivity"

    nop

    nop

    const/16 v0, 0xd96

    invoke-static {v2, p1}, Lcom/mbridge/msdk/foundation/tools/q0;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v0, 0x60

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    nop

    const/16 v0, 0x1d8

    invoke-direct {p0, v2}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->a(Ljava/util/List;)V

    const/16 v0, 0x4ee

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->s:Lcom/mbridge/msdk/video/bt/module/orglistener/h;

    nop

    if-eqz v2, :cond_25

    const/16 v0, 0x189

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->P:Lcom/mbridge/msdk/foundation/same/report/metrics/c;

    nop

    const/16 v0, 0x62d

    invoke-interface {v2, v3, p1}, Lcom/mbridge/msdk/video/bt/module/orglistener/h;->a(Lcom/mbridge/msdk/foundation/same/report/metrics/c;Ljava/lang/String;)V

    :cond_25
    const/16 v0, 0xeba

    invoke-virtual {p0}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->finish()V

    return-void
.end method

.method private b(Ljava/util/List;)V
    .registers 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/mbridge/msdk/foundation/entity/CampaignEx;",
            ">;)V"
        }
    .end annotation

    .prologue
    const-string/jumbo v2, "no available campaign"

    nop

    nop

    if-nez p1, :cond_d

    const/16 v0, 0x50

    invoke-direct {p0, v2}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->b(Ljava/lang/String;)V

    return-void

    :cond_d
    const/16 v0, 0x17d

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v3

    if-nez v3, :cond_1b

    const/16 v0, 0x50

    invoke-direct {p0, v2}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->b(Ljava/lang/String;)V

    return-void

    :cond_1b
    const/4 v2, 0x0

    const/16 v0, 0x24

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    if-eqz v3, :cond_45

    const/16 v0, 0x24

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    const/16 v0, 0xa6a

    invoke-virtual {v3}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->getDynamicTempCode()I

    move-result v3

    const/16 v0, 0x24

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    const/16 v0, 0x1cf

    invoke-virtual {v4}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->getCurrentLocalRid()Ljava/lang/String;

    move-result-object v4

    const/16 v0, 0x1e0

    iput-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->O:Ljava/lang/String;

    goto :goto_46

    :cond_45
    move v3, v2

    :goto_46
    const/4 v4, 0x5

    if-eq v3, v4, :cond_4f

    const/16 v0, 0x669

    invoke-direct {p0}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->k()V

    return-void

    :cond_4f
    const/16 v0, 0x170

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_55
    :goto_55
    const/16 v0, 0x13e

    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_78

    const/16 v0, 0x16e

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    if-eqz v4, :cond_55

    const/16 v0, 0xcdb

    iget v5, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->I:I

    nop

    const/16 v0, 0x3b5

    invoke-virtual {v4}, Lcom/mbridge/msdk/out/Campaign;->getVideoLength()I

    move-result v4

    add-int/2addr v4, v5

    const/16 v0, 0xa44

    iput v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->I:I

    goto :goto_55

    :cond_78
    const/16 v0, 0x24

    invoke-interface {p1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    const/16 v0, 0x10ab

    invoke-direct {p0, p1}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->e(Lcom/mbridge/msdk/foundation/entity/CampaignEx;)V

    return-void
.end method

.method public static synthetic c(Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;)Lcom/mbridge/msdk/video/bt/module/MBTempContainer;
    .registers 3

    const/16 v1, 0x1e

    iget-object p0, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    check-cast p0, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    return-object p0
.end method

.method private c(Lcom/mbridge/msdk/foundation/entity/CampaignEx;)V
    .registers 17

    .prologue
    :try_start_0
    const/16 v7, 0x14f

    iget-object v9, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->y:Ljava/util/List;

    nop

    if-eqz v9, :cond_69

    const/16 v7, 0x17d

    invoke-interface {v9}, Ljava/util/List;->size()I

    move-result v9

    if-lez v9, :cond_69

    const/16 v7, 0x14f

    iget-object v9, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->y:Ljava/util/List;

    nop

    const/16 v7, 0x170

    invoke-interface {v9}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :cond_1a
    :goto_1a
    const/16 v7, 0x13e

    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_69

    const/16 v7, 0x16e

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Lcom/mbridge/msdk/videocommon/download/a;

    if-eqz v10, :cond_1a

    const/16 v7, 0x2c9

    invoke-virtual {v10}, Lcom/mbridge/msdk/videocommon/download/a;->h()Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    move-result-object v11

    if-eqz v11, :cond_1a

    const/16 v7, 0x33d

    invoke-virtual {v11}, Lcom/mbridge/msdk/out/Campaign;->getId()Ljava/lang/String;

    move-result-object v12

    const/16 v7, 0x33d

    move-object/from16 v0, p1

    invoke-virtual {v0}, Lcom/mbridge/msdk/out/Campaign;->getId()Ljava/lang/String;

    move-result-object v13

    const/16 v7, 0x403

    invoke-static {v12, v13}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v12

    if-eqz v12, :cond_1a

    const/16 v7, 0x2ed

    invoke-virtual {v11}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->getRequestId()Ljava/lang/String;

    move-result-object v11

    const/16 v7, 0x2ed

    move-object/from16 v0, p1

    invoke-virtual {v0}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->getRequestId()Ljava/lang/String;

    move-result-object v12

    const/16 v7, 0x403

    invoke-static {v11, v12}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v11

    if-eqz v11, :cond_1a

    const/16 v7, 0x1cd

    iput-object v10, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->w:Lcom/mbridge/msdk/videocommon/download/a;

    goto :goto_1a

    :catch_65
    move-exception v9

    move-object/from16 p1, v9

    goto :goto_a3

    :cond_69
    const/16 p1, 0x1

    const/16 v7, 0x452

    move/from16 v0, p1

    iput-boolean v0, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->q:Z

    const/16 v7, 0x3ae

    invoke-direct {p0}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->j()V

    const/16 v7, 0x1e

    iget-object v9, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    if-eqz v9, :cond_a2

    const/16 v7, 0x83c

    iget v10, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->N:I

    nop

    const/16 v7, 0xe68

    iget v11, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->J:I

    nop

    const/16 v7, 0x124d

    iget v12, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->L:I

    nop

    const/16 v7, 0xff3

    iget v13, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->K:I

    nop

    const/16 v7, 0x6b9

    iget v14, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->M:I

    nop

    const/16 v7, 0xa57

    move v0, v7

    move-object v1, v9

    move v2, v10

    move v3, v11

    move v4, v12

    move v5, v13

    move v6, v14

    invoke-virtual/range {v1 .. v6}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->setNotchPadding(IIIII)V
    :try_end_a2
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_a2} :catch_65

    :cond_a2
    return-void

    :goto_a3
    const/16 v7, 0x1da

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const-string/jumbo v9, "MBRewardVideoActivity"

    nop

    nop

    const/16 v7, 0xd96

    move-object/from16 v0, p1

    invoke-static {v9, v0}, Lcom/mbridge/msdk/foundation/tools/q0;->b(Ljava/lang/String;Ljava/lang/String;)V

    const-string/jumbo p1, "more offer to one offer exception"

    nop

    nop

    const/16 v7, 0x50

    move-object/from16 v0, p1

    invoke-direct {p0, v0}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->b(Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic d(Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;)I
    .registers 3

    const/4 v1, 0x0

    const/16 v0, 0x83c

    iget p0, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->N:I

    nop

    return p0
.end method

.method private d(Lcom/mbridge/msdk/foundation/entity/CampaignEx;)V
    .registers 6

    const/16 v0, 0x6d0

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->t:Lcom/mbridge/msdk/videocommon/setting/c;

    nop

    const/16 v0, 0x55

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->g:Ljava/lang/String;

    nop

    const/16 v0, 0xe91

    invoke-static {p0, p1, v2, v3}, Lcom/mbridge/msdk/reward/player/a;->a(Landroid/content/Context;Lcom/mbridge/msdk/foundation/entity/CampaignEx;Lcom/mbridge/msdk/videocommon/setting/c;Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic e(Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;)I
    .registers 3

    const/4 v1, 0x0

    const/16 v0, 0xe68

    iget p0, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->J:I

    nop

    return p0
.end method

.method private e()V
    .registers 7

    .prologue
    :try_start_0
    const/16 v0, 0x86

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v2

    const/16 v0, 0x213

    invoke-virtual {v2}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/view/ViewGroup;

    const/16 v0, 0x67

    invoke-static {}, Lcom/mbridge/msdk/foundation/controller/c;->n()Lcom/mbridge/msdk/foundation/controller/c;

    move-result-object v3

    const/16 v0, 0x55

    iget-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->g:Ljava/lang/String;

    nop

    const/16 v0, 0x10c

    iget-boolean v5, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->l:Z

    nop

    if-eqz v5, :cond_23

    const/16 v5, 0x11f

    goto :goto_25

    :cond_23
    const/16 v5, 0x5e

    :goto_25
    const/16 v0, 0xc53

    invoke-virtual {v3, v4, v5}, Lcom/mbridge/msdk/foundation/controller/a;->a(Ljava/lang/String;I)Landroid/graphics/drawable/BitmapDrawable;

    move-result-object v3

    if-eqz v3, :cond_8f

    const/16 v0, 0x111e

    new-instance v4, Landroid/widget/ImageView;

    nop

    const/16 v0, 0x67

    invoke-static {}, Lcom/mbridge/msdk/foundation/controller/c;->n()Lcom/mbridge/msdk/foundation/controller/c;

    move-result-object v5

    const/16 v0, 0x466

    invoke-virtual {v5}, Lcom/mbridge/msdk/foundation/controller/a;->d()Landroid/content/Context;

    move-result-object v5

    const/16 v0, 0x1205

    invoke-direct {v4, v5}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    const/16 v0, 0x142

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v5

    const/16 v0, 0x953

    invoke-virtual {v5}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v5

    const/16 v0, 0xc6e

    invoke-static {v4, v3, v5}, Lcom/mbridge/msdk/foundation/tools/v0;->a(Landroid/widget/ImageView;Landroid/graphics/drawable/BitmapDrawable;Landroid/util/DisplayMetrics;)Landroid/widget/ImageView;

    const/4 v3, 0x0

    const/16 v0, 0x229

    invoke-virtual {v2, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/view/ViewGroup;

    const/4 v5, 0x1

    const/16 v0, 0x229

    invoke-virtual {v2, v5}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/view/ViewGroup;

    const/16 v0, 0x229

    invoke-virtual {v2, v3}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/view/ViewGroup;

    const/16 v0, 0x116c

    new-instance v3, Landroid/view/ViewGroup$LayoutParams;

    nop

    const/4 v5, -0x1

    const/16 v0, 0x106d

    invoke-direct {v3, v5, v5}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    const/16 v0, 0x106

    invoke-virtual {v2, v4, v3}, Landroid/view/ViewGroup;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/16 v0, 0x228

    iget-object p0, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->S:Lp4;

    nop

    if-eqz p0, :cond_8f

    const/16 v0, 0x11a8

    sget-object v2, Lwj0;->d:Lwj0;

    nop

    const/16 v0, 0xb3b

    invoke-virtual {p0, v4, v2}, Lp4;->a(Landroid/view/View;Lwj0;)V
    :try_end_8f
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_8f} :catch_90

    :cond_8f
    return-void

    :catch_90
    move-exception p0

    const/16 v0, 0xa8e

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    return-void
.end method

.method private e(Lcom/mbridge/msdk/foundation/entity/CampaignEx;)V
    .registers 6

    .prologue
    if-eqz p1, :cond_4f

    const/16 v0, 0xf4b

    invoke-virtual {p1}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->getVideoCompleteTime()I

    move-result v2

    const/16 v0, 0x3b4

    iget v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->H:I

    nop

    const/16 v0, 0xab4

    invoke-direct {p0, v2, v3}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->a(II)I

    move-result v2

    const/16 v0, 0x1bc

    iput-object p1, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    const/4 v3, 0x1

    const/16 v0, 0x909

    invoke-virtual {p1, v3}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->setCampaignIsFiltered(Z)V

    const/16 v0, 0xc1d

    iput v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->H:I

    const/16 v0, 0x35

    iget-object p1, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    nop

    const/16 v0, 0x560

    invoke-virtual {p1, v2}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->setVideoCompleteTime(I)V

    const/16 v0, 0x35

    iget-object p1, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    nop

    const/16 v0, 0x3b4

    iget v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->H:I

    nop

    const/16 v0, 0x118f

    invoke-virtual {p1, v2}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->setShowIndex(I)V

    const/16 v0, 0x35

    iget-object p1, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    nop

    const/16 v0, 0x1213

    invoke-virtual {p1, v3}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->setShowType(I)V

    const/16 v0, 0x35

    iget-object p1, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    nop

    const/16 v0, 0xd46

    invoke-direct {p0, p1}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->c(Lcom/mbridge/msdk/foundation/entity/CampaignEx;)V

    return-void

    :cond_4f
    const-string/jumbo p1, "campaign is less"

    nop

    nop

    const/16 v0, 0x50

    invoke-direct {p0, p1}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->b(Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic f(Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;)I
    .registers 3

    const/4 v1, 0x0

    const/16 v0, 0x124d

    iget p0, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->L:I

    nop

    return p0
.end method

.method private f()V
    .registers 6

    .prologue
    const/16 v0, 0x4ee

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->s:Lcom/mbridge/msdk/video/bt/module/orglistener/h;

    nop

    if-eqz v2, :cond_57

    instance-of v3, v2, Lcom/mbridge/msdk/video/bt/module/orglistener/b;

    if-eqz v3, :cond_57

    :try_start_b
    check-cast v2, Lcom/mbridge/msdk/video/bt/module/orglistener/b;

    const/16 v0, 0xfdb

    invoke-virtual {v2}, Lcom/mbridge/msdk/video/bt/module/orglistener/b;->d()Ljava/lang/Boolean;

    move-result-object v3

    const/16 v0, 0x6eb

    invoke-virtual {v2}, Lcom/mbridge/msdk/video/bt/module/orglistener/b;->c()Ljava/lang/Boolean;

    move-result-object v2

    if-nez v3, :cond_23

    if-nez v2, :cond_23

    const/4 v2, 0x0

    const/16 v0, 0x29d

    iput-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->X:Ljava/lang/Boolean;

    return-void

    :cond_23
    const/16 v0, 0x10d

    sget-object v4, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    nop

    const/16 v0, 0x519

    invoke-virtual {v4, v3}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_3a

    const/16 v0, 0x519

    invoke-virtual {v4, v2}, Ljava/lang/Boolean;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_3a

    const/4 v2, 0x1

    goto :goto_3b

    :cond_3a
    const/4 v2, 0x0

    :goto_3b
    const/16 v0, 0x2cb

    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    const/16 v0, 0x29d

    iput-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->X:Ljava/lang/Boolean;
    :try_end_45
    .catchall {:try_start_b .. :try_end_45} :catchall_46

    return-void

    :catchall_46
    move-exception p0

    const/16 v0, 0x1da

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const-string/jumbo v2, "MBRewardVideoActivity"

    nop

    nop

    const/16 v0, 0xd96

    invoke-static {v2, p0}, Lcom/mbridge/msdk/foundation/tools/q0;->b(Ljava/lang/String;Ljava/lang/String;)V

    :cond_57
    return-void
.end method

.method public static synthetic g(Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;)I
    .registers 3

    const/4 v1, 0x0

    const/16 v0, 0xff3

    iget p0, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->K:I

    nop

    return p0
.end method

.method private g()V
    .registers 5

    .prologue
    :try_start_0
    const/16 v0, 0xf01

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->X:Ljava/lang/Boolean;

    nop

    if-eqz v2, :cond_f

    const/16 v0, 0x205

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-eqz v2, :cond_25

    :cond_f
    const/16 v0, 0x4ee

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->s:Lcom/mbridge/msdk/video/bt/module/orglistener/h;

    nop

    if-eqz v2, :cond_25

    const/16 v0, 0x189

    iget-object p0, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->P:Lcom/mbridge/msdk/foundation/same/report/metrics/c;

    nop

    const-string/jumbo v3, "show fail : unexpected destroy"

    nop

    nop

    const/16 v0, 0x62d

    invoke-interface {v2, p0, v3}, Lcom/mbridge/msdk/video/bt/module/orglistener/h;->a(Lcom/mbridge/msdk/foundation/same/report/metrics/c;Ljava/lang/String;)V
    :try_end_25
    .catchall {:try_start_0 .. :try_end_25} :catchall_26

    :cond_25
    return-void

    :catchall_26
    move-exception p0

    const/16 v0, 0x1da

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const-string/jumbo v2, "MBRewardVideoActivity"

    nop

    nop

    const/16 v0, 0xd96

    invoke-static {v2, p0}, Lcom/mbridge/msdk/foundation/tools/q0;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public static synthetic h(Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;)I
    .registers 3

    const/4 v1, 0x0

    const/16 v0, 0x6b9

    iget p0, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->M:I

    nop

    return p0
.end method

.method private h()V
    .registers 5

    .prologue
    :try_start_0
    const/16 v0, 0x60

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    nop

    if-eqz v2, :cond_30

    const/16 v0, 0x17d

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    if-lez v2, :cond_30

    const/16 v0, 0x60

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    nop

    const/16 v0, 0x170

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_1a
    const/16 v0, 0x13e

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_30

    const/16 v0, 0x16e

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    const/16 v0, 0x4b7

    invoke-direct {p0, v3}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->a(Lcom/mbridge/msdk/foundation/entity/CampaignEx;)V

    goto :goto_1a

    :cond_30
    const/16 v0, 0x35

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    nop

    if-eqz v2, :cond_3c

    const/16 v0, 0x4b7

    invoke-direct {p0, v2}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->a(Lcom/mbridge/msdk/foundation/entity/CampaignEx;)V
    :try_end_3c
    .catchall {:try_start_0 .. :try_end_3c} :catchall_3d

    :cond_3c
    return-void

    :catchall_3d
    move-exception p0

    const/16 v0, 0x1da

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const-string/jumbo v2, "MBRewardVideoActivity"

    nop

    nop

    const/16 v0, 0xd96

    invoke-static {v2, p0}, Lcom/mbridge/msdk/foundation/tools/q0;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method private i()Lcom/mbridge/msdk/video/bt/module/listener/a;
    .registers 4

    .prologue
    const/16 v0, 0xced

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->D:Lcom/mbridge/msdk/video/bt/module/listener/a;

    nop

    if-nez v2, :cond_15

    const/16 v0, 0xf58

    new-instance v2, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity$c;

    nop

    const/16 v0, 0xdbf

    invoke-direct {v2, p0}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity$c;-><init>(Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;)V

    const/16 v0, 0x6b3

    iput-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->D:Lcom/mbridge/msdk/video/bt/module/listener/a;

    :cond_15
    check-cast v2, Lcom/mbridge/msdk/video/bt/module/listener/a;

    return-object v2
.end method

.method public static synthetic i(Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;)Lcom/mbridge/msdk/video/bt/module/orglistener/h;
    .registers 3

    const/4 v1, 0x0

    const/16 v0, 0x4ee

    iget-object p0, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->s:Lcom/mbridge/msdk/video/bt/module/orglistener/h;

    nop

    check-cast p0, Lcom/mbridge/msdk/video/bt/module/orglistener/h;

    return-object p0
.end method

.method public static synthetic j(Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;)Lcom/mbridge/msdk/foundation/same/report/metrics/c;
    .registers 3

    const/4 v1, 0x0

    const/16 v0, 0x189

    iget-object p0, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->P:Lcom/mbridge/msdk/foundation/same/report/metrics/c;

    nop

    check-cast p0, Lcom/mbridge/msdk/foundation/same/report/metrics/c;

    return-object p0
.end method

.method private j()V
    .registers 10

    .prologue
    const-string/jumbo v3, "mbridge_temp_container"

    nop

    nop

    const/16 v1, 0x4c2

    invoke-virtual {p0, v3}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->findID(Ljava/lang/String;)I

    move-result v3

    const/16 v1, 0x1ab

    invoke-static {v3}, Lcom/mbridge/msdk/foundation/tools/i0;->a(I)Z

    move-result v4

    if-nez v4, :cond_1d

    const-string/jumbo v4, "no id mbridge_bt_container in mbridge_more_offer_activity layout"

    nop

    nop

    const/16 v1, 0x50

    invoke-direct {p0, v4}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->b(Ljava/lang/String;)V

    :cond_1d
    const/16 v1, 0x2bd

    invoke-virtual {p0, v3}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v3

    check-cast v3, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    const/16 v1, 0xdb1

    iput-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    if-nez v3, :cond_35

    const-string/jumbo v3, "env error"

    nop

    nop

    const/16 v1, 0x50

    invoke-direct {p0, v3}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->b(Ljava/lang/String;)V

    :cond_35
    const/16 v1, 0x60

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    nop

    const/4 v4, 0x0

    if-eqz v3, :cond_71

    const/16 v1, 0x17d

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    if-lez v3, :cond_71

    const/16 v1, 0x60

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    nop

    const/16 v1, 0x24

    invoke-interface {v3, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    const/16 v1, 0x7ea

    invoke-virtual {v3}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->isDynamicView()Z

    move-result v3

    if-eqz v3, :cond_71

    const/16 v1, 0xe59

    new-instance v3, Lcom/mbridge/msdk/video/dynview/ui/b;

    nop

    const/16 v1, 0x611

    invoke-direct {v3}, Lcom/mbridge/msdk/video/dynview/ui/b;-><init>()V

    const/16 v1, 0x1e

    iget-object v5, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    const-wide/16 v6, 0x1f4

    const/16 v1, 0x6a4

    invoke-virtual {v3, v5, v6, v7}, Lcom/mbridge/msdk/video/dynview/ui/b;->a(Landroid/view/View;J)V

    goto :goto_7a

    :cond_71
    const/16 v1, 0x1e

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    const/4 v1, -0x5

    invoke-virtual {v3, v4}, Landroid/view/View;->setVisibility(I)V

    :goto_7a
    const/4 v3, -0x1

    const/16 v1, 0x969

    invoke-virtual {p0, v3}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->changeHalfScreenPadding(I)V

    const/16 v1, 0x1e

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    const/16 v1, 0xd38

    invoke-virtual {v3, p0}, Lcom/mbridge/msdk/video/signal/container/AbstractJSContainer;->setActivity(Landroid/app/Activity;)V

    const/16 v1, 0x1e

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    const/16 v1, 0xb20

    iget-boolean v5, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->m:Z

    nop

    const/16 v1, 0x68b

    invoke-virtual {v3, v5}, Lcom/mbridge/msdk/video/signal/container/AbstractJSContainer;->setBidCampaign(Z)V

    const/16 v1, 0x1e

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    const/16 v1, 0x524

    iget-boolean v5, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->q:Z

    nop

    const/16 v1, 0xae6

    invoke-virtual {v3, v5}, Lcom/mbridge/msdk/video/signal/container/AbstractJSContainer;->setBigOffer(Z)V

    const/16 v1, 0x1e

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    const/16 v1, 0x55

    iget-object v5, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->g:Ljava/lang/String;

    nop

    const/16 v1, 0x11fa

    invoke-virtual {v3, v5}, Lcom/mbridge/msdk/video/signal/container/AbstractJSContainer;->setUnitId(Ljava/lang/String;)V

    const/16 v1, 0x1e

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    const/16 v1, 0x35

    iget-object v5, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    nop

    const/16 v1, 0x809

    invoke-virtual {v3, v5}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->setCampaign(Lcom/mbridge/msdk/foundation/entity/CampaignEx;)V

    const/16 v1, 0x35

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    nop

    const/16 v1, 0xa6a

    invoke-virtual {v3}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->getDynamicTempCode()I

    move-result v3

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-ne v3, v5, :cond_130

    const/16 v1, 0x60

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    nop

    if-eqz v3, :cond_130

    const/16 v1, 0x17d

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    if-le v3, v6, :cond_130

    const-string/jumbo v3, "mbridge_reward_root_container"

    nop

    nop

    const/16 v1, 0x4c2

    invoke-virtual {p0, v3}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->findID(Ljava/lang/String;)I

    move-result v3

    const/16 v1, 0x2bd

    invoke-virtual {p0, v3}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v3

    if-eqz v3, :cond_fe

    const/high16 v5, -0x1000000

    const/16 v1, 0x1024

    invoke-virtual {v3, v5}, Landroid/view/View;->setBackgroundColor(I)V

    :cond_fe
    const/16 v1, 0x1e

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    const/16 v1, 0x42c

    invoke-virtual {v3}, Landroid/view/ViewGroup;->removeAllViews()V

    const/16 v1, 0x1e

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    const/16 v1, 0x60

    iget-object v5, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    nop

    const/16 v1, 0xcdb

    iget v7, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->I:I

    nop

    const/16 v1, 0x990

    invoke-virtual {v3, v5, v7}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->setCampOrderViewData(Ljava/util/List;I)V

    const/16 v1, 0x1e

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    const/16 v1, 0x1093

    iget-object v5, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->e0:Lcom/mbridge/msdk/video/dynview/listener/a;

    nop

    const/16 v1, 0x3b4

    iget v7, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->H:I

    nop

    const/16 v1, 0xa5b

    invoke-virtual {v3, v5, v7}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->setCamPlayOrderCallback(Lcom/mbridge/msdk/video/dynview/listener/a;I)V

    :cond_130
    const/16 v1, 0x1e

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    const/16 v1, 0x58

    iget-object v5, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->w:Lcom/mbridge/msdk/videocommon/download/a;

    nop

    const/16 v1, 0xdbb

    invoke-virtual {v3, v5}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->setCampaignDownLoadTask(Lcom/mbridge/msdk/videocommon/download/a;)V

    const/16 v1, 0x1e

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    const/16 v1, 0x10c

    iget-boolean v5, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->l:Z

    nop

    const/16 v1, 0x1167

    invoke-virtual {v3, v5}, Lcom/mbridge/msdk/video/signal/container/AbstractJSContainer;->setIV(Z)V

    const/16 v1, 0x35

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    nop

    if-eqz v3, :cond_169

    const/16 v1, 0xb1e

    invoke-virtual {v3}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->getAdSpaceT()I

    move-result v3

    const/4 v5, 0x2

    if-ne v3, v5, :cond_169

    const/16 v1, 0x1e

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    const/16 v1, 0x2fe

    invoke-virtual {v3, v4, v4, v4}, Lcom/mbridge/msdk/video/signal/container/AbstractJSContainer;->setIVRewardEnable(III)V

    goto :goto_182

    :cond_169
    const/16 v1, 0x1e

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    const/16 v1, 0x123f

    iget v5, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->n:I

    nop

    const/16 v1, 0x6ad

    iget v7, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->o:I

    nop

    const/16 v1, 0x832

    iget v8, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->p:I

    nop

    const/16 v1, 0x2fe

    invoke-virtual {v3, v5, v7, v8}, Lcom/mbridge/msdk/video/signal/container/AbstractJSContainer;->setIVRewardEnable(III)V

    :goto_182
    const/16 v1, 0x1e

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    const/16 v1, 0xcca

    iget v5, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->k:I

    nop

    const/16 v1, 0x606

    invoke-virtual {v3, v5}, Lcom/mbridge/msdk/video/signal/container/AbstractJSContainer;->setMute(I)V

    const/16 v1, 0x35

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    nop

    if-eqz v3, :cond_1a0

    const/16 v1, 0x45f

    invoke-virtual {v3}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->getRewardPlus()Lcom/mbridge/msdk/foundation/entity/RewardPlus;

    move-result-object v3

    if-nez v3, :cond_1d1

    :cond_1a0
    const/16 v1, 0x60

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    nop

    if-eqz v3, :cond_20e

    const/16 v1, 0x17d

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    if-lez v3, :cond_20e

    const/16 v1, 0x60

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    nop

    const/16 v1, 0x24

    invoke-interface {v3, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    if-eqz v3, :cond_20e

    const/16 v1, 0x60

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    nop

    const/16 v1, 0x24

    invoke-interface {v3, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    const/16 v1, 0x45f

    invoke-virtual {v3}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->getRewardPlus()Lcom/mbridge/msdk/foundation/entity/RewardPlus;

    move-result-object v3

    if-eqz v3, :cond_20e

    :cond_1d1
    const/16 v1, 0x2fc

    invoke-virtual {v3}, Lcom/mbridge/msdk/foundation/entity/RewardPlus;->getName()Ljava/lang/String;

    move-result-object v4

    const/16 v1, 0x3ca

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_20e

    const/16 v1, 0x468

    invoke-virtual {v3}, Lcom/mbridge/msdk/foundation/entity/RewardPlus;->getAmount()I

    move-result v4

    if-lez v4, :cond_20e

    const/16 v1, 0x10f4

    new-instance v4, Lcom/mbridge/msdk/videocommon/entity/c;

    nop

    const/16 v1, 0x2fc

    invoke-virtual {v3}, Lcom/mbridge/msdk/foundation/entity/RewardPlus;->getName()Ljava/lang/String;

    move-result-object v5

    const/16 v1, 0x468

    invoke-virtual {v3}, Lcom/mbridge/msdk/foundation/entity/RewardPlus;->getAmount()I

    move-result v3

    const/16 v1, 0xdc0

    invoke-direct {v4, v5, v3}, Lcom/mbridge/msdk/videocommon/entity/c;-><init>(Ljava/lang/String;I)V

    const/16 v1, 0x101c

    invoke-virtual {v4}, Lcom/mbridge/msdk/videocommon/entity/c;->a()I

    move-result v3

    if-gez v3, :cond_20a

    const/16 v1, 0x2ca

    invoke-virtual {v4, v6}, Lcom/mbridge/msdk/videocommon/entity/c;->a(I)V

    :cond_20a
    const/16 v1, 0xb93

    iput-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->j:Lcom/mbridge/msdk/videocommon/entity/c;

    :cond_20e
    const/16 v1, 0x1e

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    const/16 v1, 0xa5

    iget-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->j:Lcom/mbridge/msdk/videocommon/entity/c;

    nop

    const/16 v1, 0x9b5

    invoke-virtual {v3, v4}, Lcom/mbridge/msdk/video/signal/container/AbstractJSContainer;->setReward(Lcom/mbridge/msdk/videocommon/entity/c;)V

    const/16 v1, 0x1e

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    const/16 v1, 0x6d0

    iget-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->t:Lcom/mbridge/msdk/videocommon/setting/c;

    nop

    const/16 v1, 0xb66

    invoke-virtual {v3, v4}, Lcom/mbridge/msdk/video/signal/container/AbstractJSContainer;->setRewardUnitSetting(Lcom/mbridge/msdk/videocommon/setting/c;)V

    const/16 v1, 0x1e

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    const/16 v1, 0xe1e

    iget-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->h:Ljava/lang/String;

    nop

    const/16 v1, 0x989

    invoke-virtual {v3, v4}, Lcom/mbridge/msdk/video/signal/container/AbstractJSContainer;->setPlacementId(Ljava/lang/String;)V

    const/16 v1, 0x1e

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    const/16 v1, 0x846

    iget-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->i:Ljava/lang/String;

    nop

    const/16 v1, 0x1113

    invoke-virtual {v3, v4}, Lcom/mbridge/msdk/video/signal/container/AbstractJSContainer;->setUserId(Ljava/lang/String;)V

    const/16 v1, 0x1e

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    const/16 v1, 0x4ee

    iget-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->s:Lcom/mbridge/msdk/video/bt/module/orglistener/h;

    nop

    const/16 v1, 0x940

    invoke-virtual {v3, v4}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->setShowRewardListener(Lcom/mbridge/msdk/video/bt/module/orglistener/h;)V

    const/16 v1, 0x1e

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    const/16 v1, 0x5db

    iget-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->F:Ljava/lang/String;

    nop

    const/16 v1, 0x562

    invoke-virtual {v3, v4}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->setDeveloperExtraData(Ljava/lang/String;)V

    const/16 v1, 0x1e

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    const/16 v1, 0x5ee

    invoke-virtual {v3, p0}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->init(Landroid/content/Context;)V

    const/16 v1, 0x1e

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    const/16 v1, 0x228

    iget-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->S:Lp4;

    nop

    const/16 v1, 0x68d

    invoke-virtual {v3, v4}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->setAdSession(Lp4;)V

    const/16 v1, 0x1e

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    const/16 v1, 0x7db

    iget-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->U:Li4;

    nop

    const/16 v1, 0x734

    invoke-virtual {v3, v4}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->setAdEvents(Li4;)V

    const/16 v1, 0x1e

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    const/16 v1, 0xd11

    iget-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->T:Lz71;

    nop

    const/16 v1, 0x11e9

    invoke-virtual {v3, v4}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->setVideoEvents(Lz71;)V

    const/16 v1, 0x1e

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    const/16 v1, 0xb94

    invoke-virtual {v3}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->onCreate()V

    const/16 v1, 0x3ed

    invoke-static {}, Lcom/mbridge/msdk/util/b;->a()Z

    move-result v3

    if-eqz v3, :cond_2bd

    const/16 v1, 0x35

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    nop

    if-eqz v3, :cond_2bd

    const/16 v1, 0x105c

    invoke-direct {p0, v3}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->d(Lcom/mbridge/msdk/foundation/entity/CampaignEx;)V

    :cond_2bd
    return-void
.end method

.method public static synthetic k(Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;)Lcom/mbridge/msdk/foundation/entity/CampaignEx;
    .registers 3

    const/4 v1, 0x0

    const/16 v0, 0x35

    iget-object p0, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    nop

    check-cast p0, Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    return-object p0
.end method

.method private k()V
    .registers 8

    .prologue
    const-string/jumbo v2, "mbridge_bt_container"

    nop

    nop

    const/16 v0, 0x4c2

    invoke-virtual {p0, v2}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->findID(Ljava/lang/String;)I

    move-result v2

    const/16 v0, 0x1ab

    invoke-static {v2}, Lcom/mbridge/msdk/foundation/tools/i0;->a(I)Z

    move-result v3

    if-nez v3, :cond_1d

    const-string/jumbo v3, "no mbridge_webview_framelayout in mbridge_more_offer_activity layout"

    nop

    nop

    const/16 v0, 0x50

    invoke-direct {p0, v3}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->b(Ljava/lang/String;)V

    :cond_1d
    const/16 v0, 0x2bd

    invoke-virtual {p0, v2}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    const/16 v0, 0xd1f

    iput-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    if-nez v2, :cond_35

    const-string/jumbo v2, "env error"

    nop

    nop

    const/16 v0, 0x50

    invoke-direct {p0, v2}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->b(Ljava/lang/String;)V

    :cond_35
    const/16 v0, 0x25

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    nop

    const/4 v3, 0x0

    const/4 v0, -0x5

    invoke-virtual {v2, v3}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0x545

    invoke-direct {p0}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->i()Lcom/mbridge/msdk/video/bt/module/listener/a;

    move-result-object v2

    const/16 v0, 0x6b3

    iput-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->D:Lcom/mbridge/msdk/video/bt/module/listener/a;

    const/16 v0, 0x25

    iget-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    nop

    const/16 v0, 0xbc5

    invoke-virtual {v4, v2}, Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;->setBTContainerCallback(Lcom/mbridge/msdk/video/bt/module/listener/a;)V

    const/16 v0, 0x25

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    nop

    const/16 v0, 0x4ee

    iget-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->s:Lcom/mbridge/msdk/video/bt/module/orglistener/h;

    nop

    const/16 v0, 0xa55

    invoke-virtual {v2, v4}, Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;->setShowRewardVideoListener(Lcom/mbridge/msdk/video/bt/module/orglistener/h;)V

    const/16 v0, 0x25

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    nop

    const/16 v0, 0x6f1

    iget-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->f0:Lcom/mbridge/msdk/video/dynview/listener/d;

    nop

    const/16 v0, 0x640

    invoke-virtual {v2, v4}, Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;->setChoiceOneCallback(Lcom/mbridge/msdk/video/dynview/listener/d;)V

    const/16 v0, 0x25

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    nop

    const/16 v0, 0x60

    iget-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    nop

    const/16 v0, 0x1107

    invoke-virtual {v2, v4}, Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;->setCampaigns(Ljava/util/List;)V

    const/16 v0, 0x25

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    nop

    const/16 v0, 0x14f

    iget-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->y:Ljava/util/List;

    nop

    const/16 v0, 0x960

    invoke-virtual {v2, v4}, Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;->setCampaignDownLoadTasks(Ljava/util/List;)V

    const/16 v0, 0x25

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    nop

    const/16 v0, 0x6d0

    iget-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->t:Lcom/mbridge/msdk/videocommon/setting/c;

    nop

    const/16 v0, 0xb66

    invoke-virtual {v2, v4}, Lcom/mbridge/msdk/video/signal/container/AbstractJSContainer;->setRewardUnitSetting(Lcom/mbridge/msdk/videocommon/setting/c;)V

    const/16 v0, 0x25

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    nop

    const/16 v0, 0x55

    iget-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->g:Ljava/lang/String;

    nop

    const/16 v0, 0x11fa

    invoke-virtual {v2, v4}, Lcom/mbridge/msdk/video/signal/container/AbstractJSContainer;->setUnitId(Ljava/lang/String;)V

    const/16 v0, 0x25

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    nop

    const/16 v0, 0xe1e

    iget-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->h:Ljava/lang/String;

    nop

    const/16 v0, 0x989

    invoke-virtual {v2, v4}, Lcom/mbridge/msdk/video/signal/container/AbstractJSContainer;->setPlacementId(Ljava/lang/String;)V

    const/16 v0, 0x25

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    nop

    const/16 v0, 0x846

    iget-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->i:Ljava/lang/String;

    nop

    const/16 v0, 0x1113

    invoke-virtual {v2, v4}, Lcom/mbridge/msdk/video/signal/container/AbstractJSContainer;->setUserId(Ljava/lang/String;)V

    const/16 v0, 0x25

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    nop

    const/16 v0, 0xd38

    invoke-virtual {v2, p0}, Lcom/mbridge/msdk/video/signal/container/AbstractJSContainer;->setActivity(Landroid/app/Activity;)V

    const/16 v0, 0x35

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    nop

    if-eqz v2, :cond_e4

    const/16 v0, 0x45f

    invoke-virtual {v2}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->getRewardPlus()Lcom/mbridge/msdk/foundation/entity/RewardPlus;

    move-result-object v2

    if-nez v2, :cond_106

    :cond_e4
    const/16 v0, 0x60

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    nop

    const/16 v0, 0x24

    invoke-interface {v2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    if-eqz v2, :cond_144

    const/16 v0, 0x60

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    nop

    const/16 v0, 0x24

    invoke-interface {v2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    const/16 v0, 0x45f

    invoke-virtual {v2}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->getRewardPlus()Lcom/mbridge/msdk/foundation/entity/RewardPlus;

    move-result-object v2

    if-eqz v2, :cond_144

    :cond_106
    const/16 v0, 0x2fc

    invoke-virtual {v2}, Lcom/mbridge/msdk/foundation/entity/RewardPlus;->getName()Ljava/lang/String;

    move-result-object v4

    const/16 v0, 0x3ca

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_144

    const/16 v0, 0x468

    invoke-virtual {v2}, Lcom/mbridge/msdk/foundation/entity/RewardPlus;->getAmount()I

    move-result v4

    if-lez v4, :cond_144

    const/16 v0, 0x10f4

    new-instance v4, Lcom/mbridge/msdk/videocommon/entity/c;

    nop

    const/16 v0, 0x2fc

    invoke-virtual {v2}, Lcom/mbridge/msdk/foundation/entity/RewardPlus;->getName()Ljava/lang/String;

    move-result-object v5

    const/16 v0, 0x468

    invoke-virtual {v2}, Lcom/mbridge/msdk/foundation/entity/RewardPlus;->getAmount()I

    move-result v2

    const/16 v0, 0xdc0

    invoke-direct {v4, v5, v2}, Lcom/mbridge/msdk/videocommon/entity/c;-><init>(Ljava/lang/String;I)V

    const/16 v0, 0x101c

    invoke-virtual {v4}, Lcom/mbridge/msdk/videocommon/entity/c;->a()I

    move-result v2

    if-gez v2, :cond_140

    const/4 v2, 0x1

    const/16 v0, 0x2ca

    invoke-virtual {v4, v2}, Lcom/mbridge/msdk/videocommon/entity/c;->a(I)V

    :cond_140
    const/16 v0, 0xb93

    iput-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->j:Lcom/mbridge/msdk/videocommon/entity/c;

    :cond_144
    const/16 v0, 0x25

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    nop

    const/16 v0, 0xa5

    iget-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->j:Lcom/mbridge/msdk/videocommon/entity/c;

    nop

    const/16 v0, 0x9b5

    invoke-virtual {v2, v4}, Lcom/mbridge/msdk/video/signal/container/AbstractJSContainer;->setReward(Lcom/mbridge/msdk/videocommon/entity/c;)V

    const/16 v0, 0x25

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    nop

    const/16 v0, 0x123f

    iget v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->n:I

    nop

    const/16 v0, 0x6ad

    iget v5, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->o:I

    nop

    const/16 v0, 0x832

    iget v6, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->p:I

    nop

    const/16 v0, 0x2fe

    invoke-virtual {v2, v4, v5, v6}, Lcom/mbridge/msdk/video/signal/container/AbstractJSContainer;->setIVRewardEnable(III)V

    const/16 v0, 0x25

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    nop

    const/16 v0, 0x10c

    iget-boolean v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->l:Z

    nop

    const/16 v0, 0x1167

    invoke-virtual {v2, v4}, Lcom/mbridge/msdk/video/signal/container/AbstractJSContainer;->setIV(Z)V

    const/16 v0, 0x25

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    nop

    const/16 v0, 0xcca

    iget v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->k:I

    nop

    const/16 v0, 0x606

    invoke-virtual {v2, v4}, Lcom/mbridge/msdk/video/signal/container/AbstractJSContainer;->setMute(I)V

    const/16 v0, 0x25

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    nop

    const/16 v0, 0x7b5

    iget-object v4, p0, Lcom/mbridge/msdk/video/signal/activity/AbstractJSActivity;->jsFactory:Lcom/mbridge/msdk/video/signal/factory/IJSFactory;

    nop

    check-cast v4, Lcom/mbridge/msdk/video/signal/factory/b;

    const/16 v0, 0x96e

    invoke-virtual {v2, v4}, Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;->setJSFactory(Lcom/mbridge/msdk/video/signal/factory/b;)V

    const/16 v0, 0x25

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    nop

    const/16 v0, 0x5db

    iget-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->F:Ljava/lang/String;

    nop

    const/16 v0, 0x681

    invoke-virtual {v2, v4}, Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;->setDeveloperExtraData(Ljava/lang/String;)V

    const/16 v0, 0x25

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    nop

    const/16 v0, 0xf8e

    invoke-virtual {v2, p0}, Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;->init(Landroid/content/Context;)V

    const/16 v0, 0x25

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    nop

    const/16 v0, 0x228

    iget-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->S:Lp4;

    nop

    const/16 v0, 0x838

    invoke-virtual {v2, v4}, Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;->setAdSession(Lp4;)V

    const/16 v0, 0x25

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    nop

    const/16 v0, 0xd11

    iget-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->T:Lz71;

    nop

    const/16 v0, 0xffd

    invoke-virtual {v2, v4}, Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;->setVideoEvents(Lz71;)V

    const/16 v0, 0x25

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    nop

    const/16 v0, 0x7db

    iget-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->U:Li4;

    nop

    const/16 v0, 0x10ca

    invoke-virtual {v2, v4}, Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;->setAdEvents(Li4;)V

    const/16 v0, 0x25

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    nop

    const/16 v0, 0x735

    iget-boolean v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->Q:Z

    nop

    const/16 v0, 0x8ee

    invoke-virtual {v2, v4}, Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;->onCreate(Z)V

    const/16 v0, 0x3ed

    invoke-static {}, Lcom/mbridge/msdk/util/b;->a()Z

    move-result v2

    if-eqz v2, :cond_226

    const/16 v0, 0x60

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    nop

    if-eqz v2, :cond_226

    const/16 v0, 0x17d

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    if-lez v2, :cond_226

    const/16 v0, 0x60

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    nop

    const/16 v0, 0x24

    invoke-interface {v2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    if-eqz v2, :cond_226

    const/16 v0, 0x60

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    nop

    const/16 v0, 0x24

    invoke-interface {v2, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    const/16 v0, 0x105c

    invoke-direct {p0, v2}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->d(Lcom/mbridge/msdk/foundation/entity/CampaignEx;)V

    :cond_226
    return-void
.end method

.method public static synthetic l(Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;)I
    .registers 3

    const/4 v1, 0x0

    const/16 v0, 0x3b4

    iget p0, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->H:I

    nop

    return p0
.end method

.method public static synthetic m(Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;)I
    .registers 5

    const/4 v1, 0x0

    const/16 v0, 0x3b4

    iget v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->H:I

    nop

    add-int/lit8 v3, v2, 0x1

    const/16 v0, 0xc1d

    iput v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->H:I

    return v2
.end method

.method public static synthetic n(Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;)Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;
    .registers 3

    const/4 v1, 0x0

    const/16 v0, 0x25

    iget-object p0, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    nop

    check-cast p0, Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    return-object p0
.end method


# virtual methods
.method public changeHalfScreenPadding(I)V
    .registers 8

    .prologue
    :try_start_0
    const/16 v0, 0x35

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    nop

    if-eqz v2, :cond_bb

    const/16 v0, 0xb1e

    invoke-virtual {v2}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->getAdSpaceT()I

    move-result v2

    const/4 v3, 0x2

    if-ne v2, v3, :cond_bb

    const/16 v0, 0x86

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v2

    const/16 v0, 0x213

    invoke-virtual {v2}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v2

    const/high16 v4, -0x67000000

    const/16 v0, 0x1024

    invoke-virtual {v2, v4}, Landroid/view/View;->setBackgroundColor(I)V

    const/16 v0, 0x1e

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    const/16 v0, 0xde9

    invoke-virtual {v2}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v2

    check-cast v2, Landroid/widget/FrameLayout$LayoutParams;

    const/16 v4, 0x11

    const/16 v0, 0x117a

    iput v4, v2, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    const/16 v0, 0x35

    iget-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    nop

    const/16 v0, 0x338

    invoke-virtual {v4}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->getRewardTemplateMode()Lcom/mbridge/msdk/foundation/entity/CampaignEx$c;

    move-result-object v4

    const/16 v0, 0x50e

    invoke-virtual {v4}, Lcom/mbridge/msdk/foundation/entity/CampaignEx$c;->g()I

    move-result v4

    const v5, 0x3f19999a  # 0.6f

    if-nez v4, :cond_6e

    if-ne p1, v3, :cond_5e

    const/16 v0, 0x17b

    invoke-static {p0}, Lcom/mbridge/msdk/foundation/tools/v0;->f(Landroid/content/Context;)I

    move-result p1

    int-to-float p1, p1

    mul-float/2addr p1, v5

    float-to-int p1, p1

    const/16 v0, 0x10e

    invoke-static {p0}, Lcom/mbridge/msdk/foundation/tools/v0;->g(Landroid/content/Context;)I

    move-result v3

    goto :goto_90

    :cond_5e
    const/16 v0, 0x17b

    invoke-static {p0}, Lcom/mbridge/msdk/foundation/tools/v0;->f(Landroid/content/Context;)I

    move-result p1

    int-to-float p1, p1

    mul-float/2addr p1, v5

    float-to-int p1, p1

    const/16 v0, 0x10e

    invoke-static {p0}, Lcom/mbridge/msdk/foundation/tools/v0;->g(Landroid/content/Context;)I

    move-result v3

    goto :goto_a3

    :cond_6e
    const/16 v0, 0x35

    iget-object p1, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    nop

    const/16 v0, 0x338

    invoke-virtual {p1}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->getRewardTemplateMode()Lcom/mbridge/msdk/foundation/entity/CampaignEx$c;

    move-result-object p1

    const/16 v0, 0x50e

    invoke-virtual {p1}, Lcom/mbridge/msdk/foundation/entity/CampaignEx$c;->g()I

    move-result p1

    if-ne p1, v3, :cond_94

    const/16 v0, 0x17b

    invoke-static {p0}, Lcom/mbridge/msdk/foundation/tools/v0;->f(Landroid/content/Context;)I

    move-result p1

    int-to-float p1, p1

    mul-float/2addr p1, v5

    float-to-int p1, p1

    const/16 v0, 0x10e

    invoke-static {p0}, Lcom/mbridge/msdk/foundation/tools/v0;->g(Landroid/content/Context;)I

    move-result v3

    :goto_90
    int-to-float v3, v3

    mul-float/2addr v3, v5

    :goto_92
    float-to-int v3, v3

    goto :goto_a9

    :cond_94
    const/16 v0, 0x17b

    invoke-static {p0}, Lcom/mbridge/msdk/foundation/tools/v0;->f(Landroid/content/Context;)I

    move-result p1

    int-to-float p1, p1

    mul-float/2addr p1, v5

    float-to-int p1, p1

    const/16 v0, 0x10e

    invoke-static {p0}, Lcom/mbridge/msdk/foundation/tools/v0;->g(Landroid/content/Context;)I

    move-result v3

    :goto_a3
    int-to-float v3, v3

    const v4, 0x3f333333  # 0.7f

    mul-float/2addr v3, v4

    goto :goto_92

    :goto_a9
    const/16 v0, 0xba9

    iput p1, v2, Landroid/widget/FrameLayout$LayoutParams;->height:I

    const/16 v0, 0xabd

    iput v3, v2, Landroid/widget/FrameLayout$LayoutParams;->width:I

    const/16 v0, 0x1e

    iget-object p0, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    const/16 v0, 0xa0b

    invoke-virtual {p0, v2}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V
    :try_end_bb
    .catchall {:try_start_0 .. :try_end_bb} :catchall_bc

    :cond_bb
    return-void

    :catchall_bc
    move-exception p0

    const/16 v0, 0x1da

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const-string/jumbo p1, "MBRewardVideoActivity"

    nop

    nop

    const/16 v0, 0xd96

    invoke-static {p1, p0}, Lcom/mbridge/msdk/foundation/tools/q0;->b(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public findID(Ljava/lang/String;)I
    .registers 5

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const-string/jumbo v2, "id"

    nop

    nop

    const/16 v0, 0x463

    invoke-static {p0, p1, v2}, Lcom/mbridge/msdk/foundation/tools/i0;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public findLayout(Ljava/lang/String;)I
    .registers 5

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const-string/jumbo v2, "layout"

    nop

    nop

    const/16 v0, 0x463

    invoke-static {p0, p1, v2}, Lcom/mbridge/msdk/foundation/tools/i0;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method public finish()V
    .registers 6

    .prologue
    const/4 v2, 0x1

    const/16 v0, 0xbb0

    iput-boolean v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->Z:Z

    const/16 v0, 0x67

    invoke-static {}, Lcom/mbridge/msdk/foundation/controller/c;->n()Lcom/mbridge/msdk/foundation/controller/c;

    move-result-object v2

    const/4 v3, 0x0

    const/16 v0, 0x8c1

    invoke-virtual {v2, v3}, Lcom/mbridge/msdk/foundation/controller/a;->b(I)V

    const/16 v0, 0x1e

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    const/4 v3, 0x0

    if-eqz v2, :cond_22

    const/16 v0, 0xa09

    invoke-virtual {v2}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->onDestroy()V

    const/16 v0, 0xdb1

    iput-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    :cond_22
    const/16 v0, 0x114

    invoke-static {}, Lcom/mbridge/msdk/foundation/feedback/b;->b()Lcom/mbridge/msdk/foundation/feedback/b;

    move-result-object v2

    const/16 v0, 0x55

    iget-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->g:Ljava/lang/String;

    nop

    const/16 v0, 0x2fb

    invoke-virtual {v2, v4}, Lcom/mbridge/msdk/foundation/feedback/b;->d(Ljava/lang/String;)V

    const/16 v0, 0x228

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->S:Lp4;

    nop

    if-eqz v2, :cond_60

    const-string/jumbo v2, "omsdk"

    nop

    nop

    const-string/jumbo v4, "mbrewardvideoac finish"

    nop

    nop

    const/16 v0, 0xd96

    invoke-static {v2, v4}, Lcom/mbridge/msdk/foundation/tools/q0;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v0, 0x228

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->S:Lp4;

    nop

    const/16 v0, 0xf8a

    invoke-virtual {v2}, Lp4;->e()V

    const/16 v0, 0x228

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->S:Lp4;

    nop

    const/16 v0, 0xc75

    invoke-virtual {v2}, Lp4;->c()V

    const/16 v0, 0x7f6

    iput-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->S:Lp4;

    :cond_60
    const/16 v0, 0x25

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    nop

    if-eqz v2, :cond_70

    const/16 v0, 0x731

    invoke-virtual {v2}, Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;->onDestroy()V

    const/16 v0, 0xd1f

    iput-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    :cond_70
    const/16 v0, 0x660

    invoke-super {p0}, Landroid/app/Activity;->finish()V

    return-void
.end method

.method public onBackDispatched()V
    .registers 4

    .prologue
    const/4 v2, 0x1

    const/16 v0, 0xcde

    iput-boolean v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->b0:Z

    const/16 v0, 0x1e

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    if-eqz v2, :cond_11

    const/16 v0, 0x11cd

    invoke-virtual {v2}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->onBackPressed()V

    :cond_11
    const/16 v0, 0x25

    iget-object p0, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    nop

    if-eqz p0, :cond_1d

    const/16 v0, 0xdcc

    invoke-virtual {p0}, Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;->onBackPressed()V

    :cond_1d
    return-void
.end method

.method public onBackPressed()V
    .registers 4

    .prologue
    const/4 v2, 0x1

    const/16 v0, 0xacc

    iput-boolean v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->a0:Z

    const/16 v0, 0x1015

    invoke-super {p0}, Lcom/mbridge/msdk/video/signal/activity/AbstractJSActivity;->onBackPressed()V

    const/16 v0, 0x1e

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    if-eqz v2, :cond_16

    const/16 v0, 0x11cd

    invoke-virtual {v2}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->onBackPressed()V

    :cond_16
    const/16 v0, 0x25

    iget-object p0, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    nop

    if-eqz p0, :cond_22

    const/16 v0, 0xdcc

    invoke-virtual {p0}, Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;->onBackPressed()V

    :cond_22
    return-void
.end method

.method public onConfigurationChanged(Landroid/content/res/Configuration;)V
    .registers 5

    .prologue
    const/16 v0, 0x9fb

    invoke-super {p0, p1}, Lcom/mbridge/msdk/video/signal/activity/AbstractJSActivity;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    const/16 v0, 0x1e

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    if-eqz v2, :cond_20

    const/16 v0, 0x8b5

    iget v2, p1, Landroid/content/res/Configuration;->orientation:I

    nop

    const/16 v0, 0x969

    invoke-virtual {p0, v2}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->changeHalfScreenPadding(I)V

    const/16 v0, 0x1e

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    const/16 v0, 0x647

    invoke-virtual {v2, p1}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    :cond_20
    const/16 v0, 0x25

    iget-object p0, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    nop

    if-eqz p0, :cond_2c

    const/16 v0, 0xef6

    invoke-virtual {p0, p1}, Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    :cond_2c
    return-void
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .registers 20

    .prologue
    const-string/jumbo v5, "_"

    nop

    nop

    const-string/jumbo v6, ""

    const-string/jumbo v7, "anim"

    nop

    nop

    const-string/jumbo v8, "进入 show，大模板 "

    nop

    nop

    const/16 v3, 0x965

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-super {v0, v1}, Lcom/mbridge/msdk/activity/MBBaseActivity;->onCreate(Landroid/os/Bundle;)V

    const/4 v9, 0x1

    const/16 v3, 0xf31

    sput-boolean v9, Lcom/mbridge/msdk/MBridgeConstans;->isRewardActivityShowing:Z

    const/16 v3, 0x67

    invoke-static {}, Lcom/mbridge/msdk/foundation/controller/c;->n()Lcom/mbridge/msdk/foundation/controller/c;

    move-result-object v10

    const/16 v3, 0x340

    invoke-virtual {v10}, Lcom/mbridge/msdk/foundation/controller/a;->f()Landroid/content/Context;

    move-result-object v10

    if-eqz v10, :cond_4b

    const/16 v3, 0x67

    invoke-static {}, Lcom/mbridge/msdk/foundation/controller/c;->n()Lcom/mbridge/msdk/foundation/controller/c;

    move-result-object v10

    const/16 v3, 0x340

    invoke-virtual {v10}, Lcom/mbridge/msdk/foundation/controller/a;->f()Landroid/content/Context;

    move-result-object v10

    const/4 v3, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v10

    const/16 v3, 0xdbd

    invoke-virtual {v10}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v10

    const/16 v3, 0x1253

    move-object/from16 v0, p0

    iput-object v10, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->d0:Ljava/lang/String;

    :cond_4b
    const/16 v3, 0x67

    invoke-static {}, Lcom/mbridge/msdk/foundation/controller/c;->n()Lcom/mbridge/msdk/foundation/controller/c;

    move-result-object v10

    const/16 v3, 0xaf0

    move-object/from16 v0, p0

    invoke-virtual {v10, v0}, Lcom/mbridge/msdk/foundation/controller/a;->a(Landroid/content/Context;)V

    const/16 v3, 0xa03

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v10

    const/16 v3, 0x119c

    move-object/from16 v0, p0

    iput-wide v10, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->V:J

    const/16 v3, 0x185

    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->W:Ljava/lang/String;

    nop

    const/16 v3, 0x3ca

    invoke-static {v10}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v10

    if-eqz v10, :cond_79

    const-string/jumbo v10, "onCreate"

    nop

    nop

    goto :goto_93

    :cond_79
    const/4 v3, -0x3

    new-instance v10, Ljava/lang/StringBuilder;

    nop

    const/4 v3, -0x4

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v3, 0x185

    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->W:Ljava/lang/String;

    nop

    const-string/jumbo v12, "_onCreate"

    nop

    nop

    const/16 v3, 0x3ab

    invoke-static {v10, v11, v12}, Ly41;->s(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    :goto_93
    const/16 v3, 0x867

    move-object/from16 v0, p0

    iput-object v10, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->W:Ljava/lang/String;

    :try_start_99
    const/16 v3, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v10

    const/16 v3, 0xc59

    sget-object v11, Lcom/mbridge/msdk/MBridgeConstans;->UNIT_ID:Ljava/lang/String;

    nop

    const/16 v3, 0x8d

    invoke-virtual {v10, v11}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const/16 v3, 0x83e

    move-object/from16 v0, p0

    iput-object v11, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->g:Ljava/lang/String;

    const/16 v3, 0xd34

    sget-object v11, Lcom/mbridge/msdk/MBridgeConstans;->PLACEMENT_ID:Ljava/lang/String;

    nop

    const/16 v3, 0x8d

    invoke-virtual {v10, v11}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const/16 v3, 0xd7e

    move-object/from16 v0, p0

    iput-object v11, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->h:Ljava/lang/String;

    const/16 v3, 0x117e

    sget-object v11, Lcom/mbridge/msdk/MBridgeConstans;->REWARD_ID:Ljava/lang/String;

    nop

    const/16 v3, 0x8d

    invoke-virtual {v10, v11}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const/16 v3, 0xa6c

    invoke-static {v11}, Lcom/mbridge/msdk/videocommon/entity/c;->a(Ljava/lang/String;)Lcom/mbridge/msdk/videocommon/entity/c;

    move-result-object v11

    const/16 v3, 0xb93

    move-object/from16 v0, p0

    iput-object v11, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->j:Lcom/mbridge/msdk/videocommon/entity/c;

    const/16 v3, 0x11de

    sget-object v11, Lcom/mbridge/msdk/MBridgeConstans;->USER_ID:Ljava/lang/String;

    nop

    const/16 v3, 0x8d

    invoke-virtual {v10, v11}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const/16 v3, 0x6a1

    move-object/from16 v0, p0

    iput-object v11, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->i:Ljava/lang/String;

    const/16 v3, 0xf54

    sget-object v11, Lcom/mbridge/msdk/MBridgeConstans;->MUTE_STATE:Ljava/lang/String;

    nop

    const/4 v12, 0x2

    const/16 v3, 0xa8

    invoke-virtual {v10, v11, v12}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v11

    const/16 v3, 0xae3

    move-object/from16 v0, p0

    iput v11, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->k:I

    const/16 v3, 0xc76

    sget-object v11, Lcom/mbridge/msdk/MBridgeConstans;->IS_IV:Ljava/lang/String;

    nop

    const/4 v12, 0x0

    const/16 v3, 0x151

    invoke-virtual {v10, v11, v12}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v11

    const/16 v3, 0x89b

    move-object/from16 v0, p0

    iput-boolean v11, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->l:Z

    const/16 v3, 0x67

    invoke-static {}, Lcom/mbridge/msdk/foundation/controller/c;->n()Lcom/mbridge/msdk/foundation/controller/c;

    move-result-object v11

    const/16 v3, 0x10c

    move-object/from16 v0, p0

    iget-boolean v13, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->l:Z

    nop

    const/16 v14, 0x5e

    const/16 v15, 0x11f

    if-eqz v13, :cond_124

    move v13, v15

    goto :goto_125

    :cond_124
    move v13, v14

    :goto_125
    const/16 v3, 0x8c1

    invoke-virtual {v11, v13}, Lcom/mbridge/msdk/foundation/controller/a;->b(I)V

    const/16 v3, 0xd44

    sget-object v11, Lcom/mbridge/msdk/MBridgeConstans;->IS_BID:Ljava/lang/String;

    nop

    const/16 v3, 0x151

    invoke-virtual {v10, v11, v12}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v11

    const/16 v3, 0x73e

    move-object/from16 v0, p0

    iput-boolean v11, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->m:Z

    const/16 v3, 0x553

    sget-object v11, Lcom/mbridge/msdk/MBridgeConstans;->EXTRA_DATA:Ljava/lang/String;

    nop

    const/16 v3, 0x8d

    invoke-virtual {v10, v11}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const/16 v3, 0x5c2

    move-object/from16 v0, p0

    iput-object v11, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->F:Ljava/lang/String;

    const-string/jumbo v11, "is_refactor"

    nop

    nop

    const/16 v3, 0x151

    invoke-virtual {v10, v11, v12}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v11

    const/16 v3, 0xb00

    move-object/from16 v0, p0

    iput-boolean v11, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->Q:Z

    const/16 v3, 0xef5

    invoke-virtual {v10}, Landroid/content/Intent;->getFlags()I

    move-result v11

    const/high16 v13, 0x10000000

    and-int/2addr v11, v13

    if-eqz v11, :cond_172

    const/16 v3, 0x3cb

    move-object/from16 v0, p0

    iput v12, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->c0:I

    goto :goto_178

    :catchall_16f
    move-exception p1

    goto/16 :goto_905

    :cond_172
    const/16 v3, 0x3cb

    move-object/from16 v0, p0

    iput v9, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->c0:I

    :goto_178
    const/16 v3, 0x735

    move-object/from16 v0, p0

    iget-boolean v11, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->Q:Z

    nop

    if-eqz v11, :cond_19c

    const/16 v3, 0xa92

    sget-object v11, Lcom/mbridge/msdk/newreward/function/common/MBridgeGlobalCommon;->showRewardListenerMap:Ljava/util/Map;

    nop

    const/16 v3, 0x55

    move-object/from16 v0, p0

    iget-object v13, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->g:Ljava/lang/String;

    nop

    const/16 v3, 0xb0b

    invoke-interface {v11, v13}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lcom/mbridge/msdk/video/bt/module/orglistener/h;

    const/16 v3, 0x4e9

    move-object/from16 v0, p0

    iput-object v11, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->s:Lcom/mbridge/msdk/video/bt/module/orglistener/h;

    goto :goto_1b6

    :cond_19c
    const/16 v3, 0x774

    sget-object v11, Lcom/mbridge/msdk/reward/controller/a;->f0:Ljava/util/concurrent/ConcurrentHashMap;

    nop

    const/16 v3, 0x55

    move-object/from16 v0, p0

    iget-object v13, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->g:Ljava/lang/String;

    nop

    const/16 v3, 0x116f

    invoke-virtual {v11, v13}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lcom/mbridge/msdk/video/bt/module/orglistener/h;

    const/16 v3, 0x4e9

    move-object/from16 v0, p0

    iput-object v11, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->s:Lcom/mbridge/msdk/video/bt/module/orglistener/h;

    :goto_1b6
    const/16 v3, 0x10c

    move-object/from16 v0, p0

    iget-boolean v11, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->l:Z

    nop

    if-eqz v11, :cond_1f2

    const/16 v3, 0x578

    sget-object v11, Lcom/mbridge/msdk/MBridgeConstans;->IV_REWARD_MODE_TYPE:Ljava/lang/String;

    nop

    const/16 v3, 0xa8

    invoke-virtual {v10, v11, v12}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v11

    const/16 v3, 0x5dc

    move-object/from16 v0, p0

    iput v11, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->n:I

    const/16 v3, 0xc22

    sget-object v11, Lcom/mbridge/msdk/MBridgeConstans;->IV_REWARD_VALUE_TYPE:Ljava/lang/String;

    nop

    const/16 v3, 0xa8

    invoke-virtual {v10, v11, v12}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v11

    const/16 v3, 0x665

    move-object/from16 v0, p0

    iput v11, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->o:I

    const/16 v3, 0xf9b

    sget-object v11, Lcom/mbridge/msdk/MBridgeConstans;->IV_REWARD_VALUE:Ljava/lang/String;

    nop

    const/16 v3, 0xa8

    invoke-virtual {v10, v11, v12}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v11

    const/16 v3, 0x11f6

    move-object/from16 v0, p0

    iput v11, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->p:I

    :cond_1f2
    const/16 v3, 0x1212

    sget-object v11, Lcom/mbridge/msdk/MBridgeConstans;->IS_BIG_OFFER:Ljava/lang/String;

    nop

    const/16 v3, 0x151

    invoke-virtual {v10, v11, v12}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v10

    const/16 v3, 0x452

    move-object/from16 v0, p0

    iput-boolean v10, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->q:Z

    const/16 v3, 0x1a2

    invoke-static {}, Lcom/mbridge/msdk/videocommon/download/b;->getInstance()Lcom/mbridge/msdk/videocommon/download/b;

    move-result-object v10

    const/16 v3, 0x55

    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->g:Ljava/lang/String;

    nop

    const/16 v3, 0x961

    invoke-virtual {v10, v11}, Lcom/mbridge/msdk/videocommon/download/b;->a(Ljava/lang/String;)Ljava/util/concurrent/CopyOnWriteArrayList;

    move-result-object v10

    const/16 v3, 0x10a5

    move-object/from16 v0, p0

    iput-object v10, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->y:Ljava/util/List;

    const/16 v3, 0x1a2

    invoke-static {}, Lcom/mbridge/msdk/videocommon/download/b;->getInstance()Lcom/mbridge/msdk/videocommon/download/b;

    move-result-object v10

    const/16 v3, 0x55

    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->g:Ljava/lang/String;

    nop

    const/16 v3, 0xf78

    invoke-virtual {v10, v11}, Lcom/mbridge/msdk/videocommon/download/b;->b(Ljava/lang/String;)Ljava/util/concurrent/CopyOnWriteArrayList;

    move-result-object v10

    const/16 v3, 0x8a5

    move-object/from16 v0, p0

    iput-object v10, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    const-string/jumbo v10, "mbridge_more_offer_activity"

    nop

    nop

    const/16 v3, 0x10ee

    move-object/from16 v0, p0

    invoke-virtual {v0, v10}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->findLayout(Ljava/lang/String;)I

    move-result v10

    const/16 v3, 0x1ab

    invoke-static {v10}, Lcom/mbridge/msdk/foundation/tools/i0;->a(I)Z

    move-result v11

    if-nez v11, :cond_259

    const-string/jumbo p1, "no mbridge_more_offer_activity layout"

    nop

    nop

    const/16 v3, 0x50

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-direct {v0, v1}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->b(Ljava/lang/String;)V

    return-void

    :cond_259
    const/16 v3, 0xf1a

    move-object/from16 v0, p0

    invoke-virtual {v0, v10}, Landroid/app/Activity;->setContentView(I)V

    const/16 v3, 0x55

    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->g:Ljava/lang/String;

    nop

    const/16 v3, 0x3ca

    invoke-static {v10}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v10
    :try_end_26d
    .catchall {:try_start_99 .. :try_end_26d} :catchall_16f

    const-string/jumbo v11, "data empty error"

    nop

    nop

    if-eqz v10, :cond_27c

    :try_start_274
    const/16 v3, 0x50

    move-object/from16 v0, p0

    invoke-direct {v0, v11}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->b(Ljava/lang/String;)V

    return-void

    :cond_27c
    const/16 v3, 0xe7c

    new-instance v10, Lcom/mbridge/msdk/video/signal/factory/b;

    nop

    const/16 v3, 0x597

    move-object/from16 v0, p0

    invoke-direct {v10, v0}, Lcom/mbridge/msdk/video/signal/factory/b;-><init>(Landroid/app/Activity;)V

    const/16 v3, 0x11bc

    move-object/from16 v0, p0

    iput-object v10, v0, Lcom/mbridge/msdk/video/signal/activity/AbstractJSActivity;->jsFactory:Lcom/mbridge/msdk/video/signal/factory/IJSFactory;

    const/16 v3, 0xb13

    move-object/from16 v0, p0

    invoke-virtual {v0, v10}, Lcom/mbridge/msdk/video/signal/activity/AbstractJSActivity;->registerJsFactory(Lcom/mbridge/msdk/video/signal/factory/IJSFactory;)V

    const/16 v3, 0x4ee

    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->s:Lcom/mbridge/msdk/video/bt/module/orglistener/h;

    nop

    if-nez v10, :cond_2ad

    const-string/jumbo p1, "showRewardListener is null"

    nop

    nop

    const/16 v3, 0x50

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-direct {v0, v1}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->b(Ljava/lang/String;)V

    return-void

    :cond_2ad
    const/16 v3, 0xec8

    invoke-virtual {v10}, Ljava/lang/Object;->hashCode()I

    move-result v10

    const/16 v3, 0xbd1

    move-object/from16 v0, p0

    iput v10, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->Y:I

    const/16 v3, 0xda9

    invoke-static {}, Lcom/mbridge/msdk/reward/adapter/RewardUnitCacheManager;->getInstance()Lcom/mbridge/msdk/reward/adapter/RewardUnitCacheManager;

    move-result-object v10

    const/16 v3, 0xe1e

    move-object/from16 v0, p0

    iget-object v13, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->h:Ljava/lang/String;

    nop

    const/16 v3, 0x55

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->g:Ljava/lang/String;

    move-object/16 v16, v3

    const/16 v3, 0x534

    move-object/from16 v0, v16

    invoke-virtual {v10, v13, v0}, Lcom/mbridge/msdk/reward/adapter/RewardUnitCacheManager;->get(Ljava/lang/String;Ljava/lang/String;)Lcom/mbridge/msdk/videocommon/setting/c;

    move-result-object v10

    const/16 v3, 0x211

    move-object/from16 v0, p0

    iput-object v10, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->t:Lcom/mbridge/msdk/videocommon/setting/c;

    if-nez v10, :cond_33e

    const/16 v3, 0x425

    invoke-static {}, Lcom/mbridge/msdk/videocommon/setting/b;->b()Lcom/mbridge/msdk/videocommon/setting/b;

    move-result-object v10

    const/16 v3, 0x67

    invoke-static {}, Lcom/mbridge/msdk/foundation/controller/c;->n()Lcom/mbridge/msdk/foundation/controller/c;

    move-result-object v13

    const/16 v3, 0x4f6

    invoke-virtual {v13}, Lcom/mbridge/msdk/foundation/controller/a;->b()Ljava/lang/String;

    move-result-object v13

    const/16 v3, 0x55

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->g:Ljava/lang/String;

    move-object/16 v16, v3

    const/16 v3, 0x10da

    move-object/from16 v0, v16

    invoke-virtual {v10, v13, v0}, Lcom/mbridge/msdk/videocommon/setting/b;->c(Ljava/lang/String;Ljava/lang/String;)Lcom/mbridge/msdk/videocommon/setting/c;

    move-result-object v10

    const/16 v3, 0x211

    move-object/from16 v0, p0

    iput-object v10, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->t:Lcom/mbridge/msdk/videocommon/setting/c;

    if-nez v10, :cond_33e

    const/16 v3, 0x425

    invoke-static {}, Lcom/mbridge/msdk/videocommon/setting/b;->b()Lcom/mbridge/msdk/videocommon/setting/b;

    move-result-object v10

    const/16 v3, 0x67

    invoke-static {}, Lcom/mbridge/msdk/foundation/controller/c;->n()Lcom/mbridge/msdk/foundation/controller/c;

    move-result-object v13

    const/16 v3, 0x4f6

    invoke-virtual {v13}, Lcom/mbridge/msdk/foundation/controller/a;->b()Ljava/lang/String;

    move-result-object v13

    const/16 v3, 0x55

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->g:Ljava/lang/String;

    move-object/16 v16, v3

    const/16 v3, 0x10c

    move-object/from16 v0, p0

    iget-boolean v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->l:Z

    move/16 v17, v3

    const/16 v3, 0xfd9

    move-object/from16 v0, v16

    move/from16 v1, v17

    invoke-virtual {v10, v13, v0, v1}, Lcom/mbridge/msdk/videocommon/setting/b;->a(Ljava/lang/String;Ljava/lang/String;Z)Lcom/mbridge/msdk/videocommon/setting/c;

    move-result-object v10

    const/16 v3, 0x211

    move-object/from16 v0, p0

    iput-object v10, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->t:Lcom/mbridge/msdk/videocommon/setting/c;

    :cond_33e
    if-eqz v10, :cond_36b

    const/16 v3, 0xa5

    move-object/from16 v0, p0

    iget-object v13, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->j:Lcom/mbridge/msdk/videocommon/entity/c;

    nop

    const/16 v3, 0xe84

    invoke-virtual {v10}, Lcom/mbridge/msdk/videocommon/setting/c;->d()I

    move-result v10

    const/16 v3, 0x2ca

    invoke-virtual {v13, v10}, Lcom/mbridge/msdk/videocommon/entity/c;->a(I)V

    const/16 v3, 0xa5

    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->j:Lcom/mbridge/msdk/videocommon/entity/c;

    nop

    const/16 v3, 0x6d0

    move-object/from16 v0, p0

    iget-object v13, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->t:Lcom/mbridge/msdk/videocommon/setting/c;

    nop

    const/16 v3, 0xee8

    invoke-virtual {v13}, Lcom/mbridge/msdk/videocommon/setting/c;->s()Ljava/lang/String;

    move-result-object v13

    const/16 v3, 0x974

    invoke-virtual {v10, v13}, Lcom/mbridge/msdk/videocommon/entity/c;->b(Ljava/lang/String;)V

    :cond_36b
    const/16 v3, 0xa5

    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->j:Lcom/mbridge/msdk/videocommon/entity/c;

    nop

    if-eqz v10, :cond_388

    const/16 v3, 0x101c

    invoke-virtual {v10}, Lcom/mbridge/msdk/videocommon/entity/c;->a()I

    move-result v10

    if-gtz v10, :cond_388

    const/16 v3, 0xa5

    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->j:Lcom/mbridge/msdk/videocommon/entity/c;

    nop

    const/16 v3, 0x2ca

    invoke-virtual {v10, v9}, Lcom/mbridge/msdk/videocommon/entity/c;->a(I)V

    :cond_388
    const-string/jumbo v10, "mbridge_reward_activity_open"

    nop

    nop

    const/16 v3, 0x463

    move-object/from16 v0, p0

    invoke-static {v0, v10, v7}, Lcom/mbridge/msdk/foundation/tools/i0;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I

    move-result v10

    const-string/jumbo v13, "mbridge_reward_activity_stay"

    nop

    nop

    const/16 v3, 0x463

    move-object/from16 v0, p0

    invoke-static {v0, v13, v7}, Lcom/mbridge/msdk/foundation/tools/i0;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I

    move-result v7

    const/16 v3, 0x1ab

    invoke-static {v10}, Lcom/mbridge/msdk/foundation/tools/i0;->a(I)Z

    move-result v13

    if-eqz v13, :cond_3b9

    const/16 v3, 0x1ab

    invoke-static {v7}, Lcom/mbridge/msdk/foundation/tools/i0;->a(I)Z

    move-result v13

    if-eqz v13, :cond_3b9

    const/16 v3, 0x5c8

    move-object/from16 v0, p0

    invoke-virtual {v0, v10, v7}, Landroid/app/Activity;->overridePendingTransition(II)V
    :try_end_3b9
    .catchall {:try_start_274 .. :try_end_3b9} :catchall_16f

    :cond_3b9
    if-eqz p1, :cond_3d9

    :try_start_3bb
    const/16 v3, 0xb47

    sget-object v7, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->SAVE_STATE_KEY_REPORT:Ljava/lang/String;

    nop

    const/16 v3, 0x123b

    move-object/from16 v0, p1

    invoke-virtual {v0, v7}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    move-result p1

    const/16 v3, 0x7fa

    move-object/from16 v0, p0

    move/from16 v1, p1

    iput-boolean v1, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->v:Z
    :try_end_3d0
    .catch Ljava/lang/Exception; {:try_start_3bb .. :try_end_3d0} :catch_3d1
    .catchall {:try_start_3bb .. :try_end_3d0} :catchall_16f

    goto :goto_3d9

    :catch_3d1
    move-exception p1

    :try_start_3d2
    const/16 v3, 0xa8e

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_3d9
    :goto_3d9
    const-string/jumbo p1, "DynamicViewCampaignResourceDownloader"

    nop

    nop

    const/4 v3, -0x3

    new-instance v7, Ljava/lang/StringBuilder;

    nop

    const/16 v3, 0x97

    invoke-direct {v7, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v3, 0x524

    move-object/from16 v0, p0

    iget-boolean v8, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->q:Z

    nop

    const/16 v3, 0x6a

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v3, -0x2

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const/16 v3, 0x620

    move-object/from16 v0, p1

    invoke-static {v0, v7}, Lcom/mbridge/msdk/foundation/tools/q0;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v3, 0x524

    move-object/from16 v0, p0

    iget-boolean v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->q:Z

    move/16 p1, v3
    :try_end_408
    .catchall {:try_start_3d2 .. :try_end_408} :catchall_16f

    const-string/jumbo v7, "env is exception"

    nop

    nop

    const/4 v8, 0x0

    if-nez p1, :cond_59c

    :try_start_410
    const/16 v3, 0x14f

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->y:Ljava/util/List;

    move-object/16 p1, v3

    if-eqz p1, :cond_440

    const/16 v3, 0x17d

    move-object/from16 v0, p1

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result p1

    if-lez p1, :cond_440

    const/16 v3, 0x14f

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->y:Ljava/util/List;

    move-object/16 p1, v3

    const/16 v3, 0x24

    move-object/from16 v0, p1

    invoke-interface {v0, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/mbridge/msdk/videocommon/download/a;

    const/16 v3, 0x1cd

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iput-object v1, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->w:Lcom/mbridge/msdk/videocommon/download/a;

    :cond_440
    const/16 v3, 0x58

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->w:Lcom/mbridge/msdk/videocommon/download/a;

    move-object/16 p1, v3

    if-eqz p1, :cond_4fc

    const/16 v3, 0x2c9

    move-object/from16 v0, p1

    invoke-virtual {v0}, Lcom/mbridge/msdk/videocommon/download/a;->h()Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    move-result-object p1

    const/16 v3, 0x1bc

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iput-object v1, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    const/16 v3, 0x58

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->w:Lcom/mbridge/msdk/videocommon/download/a;

    move-object/16 p1, v3

    const/16 v3, 0x2f9

    move-object/from16 v0, p1

    invoke-virtual {v0, v9}, Lcom/mbridge/msdk/videocommon/download/a;->b(Z)V

    const/16 v3, 0x58

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->w:Lcom/mbridge/msdk/videocommon/download/a;

    move-object/16 p1, v3

    const/16 v3, 0x52d

    move-object/from16 v0, p1

    invoke-virtual {v0, v12}, Lcom/mbridge/msdk/videocommon/download/a;->d(Z)V

    const/16 v3, 0x35

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    move-object/16 p1, v3

    if-eqz p1, :cond_4fc

    const/16 v3, 0x1cf

    move-object/from16 v0, p1

    invoke-virtual {v0}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->getCurrentLocalRid()Ljava/lang/String;

    move-result-object p1

    const/16 v3, 0x1e0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iput-object v1, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->O:Ljava/lang/String;

    const/16 v3, 0x35

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    move-object/16 p1, v3

    const/16 v3, 0x118f

    move-object/from16 v0, p1

    invoke-virtual {v0, v9}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->setShowIndex(I)V

    const/16 v3, 0x35

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    move-object/16 p1, v3

    const/16 v3, 0x1213

    move-object/from16 v0, p1

    invoke-virtual {v0, v9}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->setShowType(I)V

    const/16 v3, 0x35

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    move-object/16 p1, v3

    const/16 v3, 0x51b

    move-object/from16 v0, p1

    invoke-virtual {v0}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->getEcppv()Ljava/lang/String;

    move-result-object p1

    const/16 v3, 0x381

    move-object/from16 v0, p1

    sput-object v0, Lcom/mbridge/msdk/reward/controller/a;->b0:Ljava/lang/String;

    const/16 v3, 0x67

    invoke-static {}, Lcom/mbridge/msdk/foundation/controller/c;->n()Lcom/mbridge/msdk/foundation/controller/c;

    move-result-object p1

    const/16 v3, 0x466

    move-object/from16 v0, p1

    invoke-virtual {v0}, Lcom/mbridge/msdk/foundation/controller/a;->d()Landroid/content/Context;

    move-result-object p1

    const/16 v3, 0x35

    move-object/from16 v0, p0

    iget-object v5, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    nop

    const/16 v3, 0x304

    invoke-virtual {v5}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->getMaitve()I

    move-result v5

    const/16 v3, 0x35

    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    nop

    const/16 v3, 0x37c

    invoke-virtual {v6}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->getMaitve_src()Ljava/lang/String;

    move-result-object v6

    const/16 v3, 0x4a3

    move-object/from16 v0, p1

    invoke-static {v0, v5, v6}, Lcom/mbridge/msdk/click/c;->a(Landroid/content/Context;ILjava/lang/String;)V

    :cond_4fc
    const/16 v3, 0x35

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    move-object/16 p1, v3

    if-eqz p1, :cond_524

    const/16 v3, 0x2ae

    move-object/from16 v0, p1

    invoke-virtual {v0}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->getImpReportType()I

    move-result v5

    const/16 v3, 0x8ef

    move-object/from16 v0, p1

    move-object/from16 v1, p0

    invoke-static {v0, v1, v8, v5}, Lcom/mbridge/msdk/foundation/tools/h;->a(Lcom/mbridge/msdk/foundation/entity/CampaignEx;Landroid/content/Context;Landroid/view/View;I)Z

    move-result p1

    if-nez p1, :cond_524

    const/16 v3, 0x50

    move-object/from16 v0, p0

    invoke-direct {v0, v7}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->b(Ljava/lang/String;)V

    goto/16 :goto_936

    :cond_524
    const/16 v3, 0x58

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->w:Lcom/mbridge/msdk/videocommon/download/a;

    move-object/16 p1, v3

    if-eqz p1, :cond_593

    const/16 v3, 0x35

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    move-object/16 p1, v3

    if-eqz p1, :cond_593

    const/16 v3, 0xa5

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->j:Lcom/mbridge/msdk/videocommon/entity/c;

    move-object/16 p1, v3

    if-nez p1, :cond_546

    goto :goto_593

    :cond_546
    const/16 v3, 0xd7

    new-instance p1, Ljava/util/ArrayList;

    nop

    const/16 v3, 0x16b

    move-object/from16 v0, p1

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/16 v3, 0x35

    move-object/from16 v0, p0

    iget-object v5, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    nop

    const/16 v3, 0x174

    move-object/from16 v0, p1

    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/16 v3, 0x1d8

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-direct {v0, v1}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->a(Ljava/util/List;)V

    const/16 v3, 0x35

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    move-object/16 p1, v3

    const/16 v3, 0x1b3

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-direct {v0, v1}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->b(Lcom/mbridge/msdk/foundation/entity/CampaignEx;)V

    const/16 v3, 0x3ae

    move-object/from16 v0, p0

    invoke-direct {v0}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->j()V

    const/16 v3, 0x3ed

    invoke-static {}, Lcom/mbridge/msdk/util/b;->a()Z

    move-result p1

    if-nez p1, :cond_936

    const/16 v3, 0x4fa

    move-object/from16 v0, p0

    invoke-direct {v0}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->e()V

    goto/16 :goto_936

    :cond_593
    :goto_593
    const/16 v3, 0x50

    move-object/from16 v0, p0

    invoke-direct {v0, v11}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->b(Ljava/lang/String;)V

    goto/16 :goto_936

    :cond_59c
    const/16 v3, 0x60

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    move-object/16 p1, v3

    const/16 v3, 0x1d8

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-direct {v0, v1}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->a(Ljava/util/List;)V

    const/16 v3, 0x3d2

    move-object/from16 v0, p0

    iput-object v6, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->E:Ljava/lang/String;

    const/16 v3, 0x60

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    move-object/16 p1, v3

    if-eqz p1, :cond_65a

    const/16 v3, 0x17d

    move-object/from16 v0, p1

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result p1

    if-lez p1, :cond_65a

    const/16 v3, 0x60

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    move-object/16 p1, v3

    const/16 v3, 0x24

    move-object/from16 v0, p1

    invoke-interface {v0, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    const/16 v3, 0x60

    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    nop

    const/16 v3, 0x2ae

    move-object/from16 v0, p1

    invoke-virtual {v0}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->getImpReportType()I

    move-result v10

    const/16 v3, 0x5d6

    move-object/from16 v0, p0

    invoke-static {v6, v0, v8, v10}, Lcom/mbridge/msdk/foundation/tools/h;->a(Ljava/util/List;Landroid/content/Context;Landroid/view/View;I)Z

    move-result v6

    if-nez v6, :cond_5fe

    const/16 v3, 0x50

    move-object/from16 v0, p0

    invoke-direct {v0, v7}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->b(Ljava/lang/String;)V

    goto/16 :goto_936

    :cond_5fe
    const/16 v3, 0x1b3

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-direct {v0, v1}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->b(Lcom/mbridge/msdk/foundation/entity/CampaignEx;)V

    const/16 v3, 0x9aa

    move-object/from16 v0, p1

    invoke-virtual {v0}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->getCMPTEntryUrl()Ljava/lang/String;

    move-result-object v6

    const/16 v3, 0x2ed

    move-object/from16 v0, p1

    invoke-virtual {v0}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->getRequestId()Ljava/lang/String;

    move-result-object v7

    const/16 v3, 0x3d2

    move-object/from16 v0, p0

    iput-object v7, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->E:Ljava/lang/String;

    const/16 v3, 0x1cf

    move-object/from16 v0, p1

    invoke-virtual {v0}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->getCurrentLocalRid()Ljava/lang/String;

    move-result-object v7

    const/16 v3, 0x1e0

    move-object/from16 v0, p0

    iput-object v7, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->O:Ljava/lang/String;

    const/16 v3, 0x51b

    move-object/from16 v0, p1

    invoke-virtual {v0}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->getEcppv()Ljava/lang/String;

    move-result-object v7

    const/16 v3, 0x381

    sput-object v7, Lcom/mbridge/msdk/reward/controller/a;->b0:Ljava/lang/String;

    const/16 v3, 0x67

    invoke-static {}, Lcom/mbridge/msdk/foundation/controller/c;->n()Lcom/mbridge/msdk/foundation/controller/c;

    move-result-object v7

    const/16 v3, 0x466

    invoke-virtual {v7}, Lcom/mbridge/msdk/foundation/controller/a;->d()Landroid/content/Context;

    move-result-object v7

    const/16 v3, 0x304

    move-object/from16 v0, p1

    invoke-virtual {v0}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->getMaitve()I

    move-result v8

    const/16 v3, 0x37c

    move-object/from16 v0, p1

    invoke-virtual {v0}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->getMaitve_src()Ljava/lang/String;

    move-result-object p1

    const/16 v3, 0x4a3

    move-object/from16 v0, p1

    invoke-static {v7, v8, v0}, Lcom/mbridge/msdk/click/c;->a(Landroid/content/Context;ILjava/lang/String;)V

    :cond_65a
    const/4 v3, -0x3

    new-instance p1, Ljava/lang/StringBuilder;

    nop

    const/4 v3, -0x4

    move-object/from16 v0, p1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v3, 0x55

    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->g:Ljava/lang/String;

    nop

    const/4 v3, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v3, 0x122d

    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->E:Ljava/lang/String;

    nop

    const/4 v3, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    move-object/from16 v0, p1

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, -0x2

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/16 v3, 0xb0e

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-direct {v0, v1}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->a(Ljava/lang/String;)Lcom/mbridge/msdk/mbsignalcommon/windvane/WindVaneWebView;

    move-result-object p1

    const/16 v3, 0xbfb

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iput-object v1, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->C:Lcom/mbridge/msdk/mbsignalcommon/windvane/WindVaneWebView;

    if-nez p1, :cond_835

    const/16 v3, 0x58

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->w:Lcom/mbridge/msdk/videocommon/download/a;

    move-object/16 p1, v3

    if-nez p1, :cond_6e6

    const/16 v3, 0x14f

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->y:Ljava/util/List;

    move-object/16 p1, v3

    if-eqz p1, :cond_6e6

    const/16 v3, 0x17d

    move-object/from16 v0, p1

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result p1

    if-lez p1, :cond_6e6

    const/16 v3, 0x14f

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->y:Ljava/util/List;

    move-object/16 p1, v3

    const/16 v3, 0x24

    move-object/from16 v0, p1

    invoke-interface {v0, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/mbridge/msdk/videocommon/download/a;

    const/16 v3, 0x1cd

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iput-object v1, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->w:Lcom/mbridge/msdk/videocommon/download/a;

    :cond_6e6
    const/16 v3, 0x58

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->w:Lcom/mbridge/msdk/videocommon/download/a;

    move-object/16 p1, v3

    if-nez p1, :cond_71f

    const/16 v3, 0x1a2

    invoke-static {}, Lcom/mbridge/msdk/videocommon/download/b;->getInstance()Lcom/mbridge/msdk/videocommon/download/b;

    move-result-object p1

    const/16 v3, 0x10c

    move-object/from16 v0, p0

    iget-boolean v5, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->l:Z

    nop

    if-eqz v5, :cond_701

    move v14, v15

    :cond_701
    const/16 v3, 0x55

    move-object/from16 v0, p0

    iget-object v5, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->g:Ljava/lang/String;

    nop

    const/16 v3, 0xb20

    move-object/from16 v0, p0

    iget-boolean v6, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->m:Z

    nop

    const/16 v3, 0xc46

    move-object/from16 v0, p1

    invoke-virtual {v0, v14, v5, v6}, Lcom/mbridge/msdk/videocommon/download/b;->a(ILjava/lang/String;Z)Lcom/mbridge/msdk/videocommon/download/a;

    move-result-object p1

    const/16 v3, 0x1cd

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iput-object v1, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->w:Lcom/mbridge/msdk/videocommon/download/a;

    :cond_71f
    if-eqz p1, :cond_751

    const/16 v3, 0x2c9

    move-object/from16 v0, p1

    invoke-virtual {v0}, Lcom/mbridge/msdk/videocommon/download/a;->h()Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    move-result-object p1

    const/16 v3, 0x1bc

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iput-object v1, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    const/16 v3, 0x58

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->w:Lcom/mbridge/msdk/videocommon/download/a;

    move-object/16 p1, v3

    const/16 v3, 0x2f9

    move-object/from16 v0, p1

    invoke-virtual {v0, v9}, Lcom/mbridge/msdk/videocommon/download/a;->b(Z)V

    const/16 v3, 0x58

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->w:Lcom/mbridge/msdk/videocommon/download/a;

    move-object/16 p1, v3

    const/16 v3, 0x52d

    move-object/from16 v0, p1

    invoke-virtual {v0, v12}, Lcom/mbridge/msdk/videocommon/download/a;->d(Z)V

    :cond_751
    const/16 v3, 0x58

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->w:Lcom/mbridge/msdk/videocommon/download/a;

    move-object/16 p1, v3

    if-eqz p1, :cond_82c

    const/16 v3, 0x35

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    move-object/16 p1, v3

    if-eqz p1, :cond_82c

    const/16 v3, 0xa5

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->j:Lcom/mbridge/msdk/videocommon/entity/c;

    move-object/16 p1, v3

    if-nez p1, :cond_774

    goto/16 :goto_82c

    :cond_774
    const/16 v3, 0x452

    move-object/from16 v0, p0

    iput-boolean v12, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->q:Z

    const/16 v3, 0x10ed

    invoke-static {}, Lcom/mbridge/msdk/videocommon/cache/a;->a()Lcom/mbridge/msdk/videocommon/cache/a;

    move-result-object p1

    const/16 v3, 0x60

    move-object/from16 v0, p0

    iget-object v5, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    nop

    const/16 v3, 0xf52

    move-object/from16 v0, p1

    invoke-virtual {v0, v5}, Lcom/mbridge/msdk/videocommon/cache/a;->a(Ljava/util/List;)Ljava/util/List;

    move-result-object p1
    :try_end_78f
    .catchall {:try_start_410 .. :try_end_78f} :catchall_16f

    const-string/jumbo v5, "no available campaign"

    nop

    nop

    if-nez p1, :cond_79f

    :try_start_796
    const/16 v3, 0x50

    move-object/from16 v0, p0

    invoke-direct {v0, v5}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->b(Ljava/lang/String;)V

    goto/16 :goto_936

    :cond_79f
    const/16 v3, 0x17d

    move-object/from16 v0, p1

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v6

    if-nez v6, :cond_7b2

    const/16 v3, 0x50

    move-object/from16 v0, p0

    invoke-direct {v0, v5}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->b(Ljava/lang/String;)V

    goto/16 :goto_936

    :cond_7b2
    const/16 v3, 0x24

    move-object/from16 v0, p1

    invoke-interface {v0, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    if-eqz v5, :cond_823

    const/16 v3, 0x24

    move-object/from16 v0, p1

    invoke-interface {v0, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    const/16 v3, 0x7ea

    invoke-virtual {v5}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->isDynamicView()Z

    move-result v5

    if-eqz v5, :cond_823

    if-ne v6, v9, :cond_818

    const/16 v3, 0x24

    move-object/from16 v0, p1

    invoke-interface {v0, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    const/16 v3, 0x1bc

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iput-object v1, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    if-eqz p1, :cond_804

    const/16 v3, 0x1cf

    move-object/from16 v0, p1

    invoke-virtual {v0}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->getCurrentLocalRid()Ljava/lang/String;

    move-result-object p1

    const/16 v3, 0x1e0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iput-object v1, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->O:Ljava/lang/String;

    const/16 v3, 0x35

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    move-object/16 p1, v3

    const/16 v3, 0x909

    move-object/from16 v0, p1

    invoke-virtual {v0, v9}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->setCampaignIsFiltered(Z)V

    :cond_804
    const/16 v3, 0x35

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    move-object/16 p1, v3

    const/16 v3, 0xd46

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-direct {v0, v1}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->c(Lcom/mbridge/msdk/foundation/entity/CampaignEx;)V

    goto/16 :goto_8f5

    :cond_818
    const/16 v3, 0x802

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-direct {v0, v1}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->b(Ljava/util/List;)V

    goto/16 :goto_8f5

    :cond_823
    const/16 v3, 0x3ae

    move-object/from16 v0, p0

    invoke-direct {v0}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->j()V

    goto/16 :goto_8f5

    :cond_82c
    :goto_82c
    const/16 v3, 0x50

    move-object/from16 v0, p0

    invoke-direct {v0, v11}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->b(Ljava/lang/String;)V

    goto/16 :goto_936

    :cond_835
    const/16 v3, 0x60

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    move-object/16 p1, v3

    const/16 v3, 0x24

    move-object/from16 v0, p1

    invoke-interface {v0, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    const/16 v3, 0x1b3

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-direct {v0, v1}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->b(Lcom/mbridge/msdk/foundation/entity/CampaignEx;)V

    const/16 v3, 0x256

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->C:Lcom/mbridge/msdk/mbsignalcommon/windvane/WindVaneWebView;

    move-object/16 p1, v3

    if-eqz p1, :cond_8ee

    const/16 v3, 0x60

    move-object/from16 v0, p0

    iget-object v5, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    nop

    const/16 v3, 0x24

    invoke-interface {v5, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    const/16 v3, 0xf24

    invoke-virtual {v5}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->getLocalRequestId()Ljava/lang/String;

    move-result-object v5

    const/16 v3, 0x60

    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    nop

    const/16 v3, 0x24

    invoke-interface {v6, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    const/16 v3, 0x1255

    invoke-virtual {v6}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->getLocalAllowTrackClick()I

    move-result v6

    const/16 v3, 0x849

    move-object/from16 v0, p1

    invoke-static {v0, v5, v6}, Lcom/mbridge/msdk/foundation/tools/b1;->a(Landroid/view/View;Ljava/lang/String;I)V
    :try_end_88d
    .catchall {:try_start_796 .. :try_end_88d} :catchall_16f

    :try_start_88d
    const/16 v3, 0x256

    move-object/from16 v0, p0

    iget-object v3, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->C:Lcom/mbridge/msdk/mbsignalcommon/windvane/WindVaneWebView;

    move-object/16 p1, v3

    const/16 v3, 0x538

    move-object/from16 v0, p1

    invoke-virtual {v0}, Lcom/mbridge/msdk/mbsignalcommon/windvane/WindVaneWebView;->getObject()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Lcom/mbridge/msdk/video/signal/impl/k;

    const/16 v3, 0x7db

    move-object/from16 v0, p0

    iget-object v5, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->U:Li4;

    nop

    const/16 v3, 0x5f7

    move-object/from16 v0, p1

    invoke-virtual {v0, v5}, Lcom/mbridge/msdk/video/signal/impl/a;->setAdEvents(Li4;)V

    const/16 v3, 0x228

    move-object/from16 v0, p0

    iget-object v5, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->S:Lp4;

    nop

    const/16 v3, 0x101a

    move-object/from16 v0, p1

    invoke-virtual {v0, v5}, Lcom/mbridge/msdk/video/signal/impl/a;->setAdSession(Lp4;)V

    const/16 v3, 0xd11

    move-object/from16 v0, p0

    iget-object v5, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->T:Lz71;

    nop

    const/16 v3, 0x9ae

    move-object/from16 v0, p1

    invoke-virtual {v0, v5}, Lcom/mbridge/msdk/video/signal/impl/a;->setVideoEvents(Lz71;)V

    const/16 v3, 0x256

    move-object/from16 v0, p0

    iget-object v5, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->C:Lcom/mbridge/msdk/mbsignalcommon/windvane/WindVaneWebView;

    nop

    const/16 v3, 0x56a

    move-object/from16 v0, p1

    invoke-virtual {v5, v0}, Lcom/mbridge/msdk/mbsignalcommon/windvane/WindVaneWebView;->setObject(Ljava/lang/Object;)V
    :try_end_8d8
    .catch Ljava/lang/Exception; {:try_start_88d .. :try_end_8d8} :catch_8d9
    .catchall {:try_start_88d .. :try_end_8d8} :catchall_16f

    goto :goto_8ee

    :catch_8d9
    move-exception p1

    :try_start_8da
    const-string/jumbo v5, "MBRewardVideoActivity"

    nop

    nop

    const/16 v3, 0x1da

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/16 v3, 0xd96

    move-object/from16 v0, p1

    invoke-static {v5, v0}, Lcom/mbridge/msdk/foundation/tools/q0;->b(Ljava/lang/String;Ljava/lang/String;)V

    :cond_8ee
    :goto_8ee
    const/16 v3, 0x669

    move-object/from16 v0, p0

    invoke-direct {v0}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->k()V

    :goto_8f5
    const/16 v3, 0x3ed

    invoke-static {}, Lcom/mbridge/msdk/util/b;->a()Z

    move-result p1

    if-nez p1, :cond_936

    const/16 v3, 0x4fa

    move-object/from16 v0, p0

    invoke-direct {v0}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->e()V
    :try_end_904
    .catchall {:try_start_8da .. :try_end_904} :catchall_16f

    goto :goto_936

    :goto_905
    const/16 v3, 0x60

    move-object/from16 v0, p0

    iget-object v5, v0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    nop

    const/16 v3, 0x1d8

    move-object/from16 v0, p0

    invoke-direct {v0, v5}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->a(Ljava/util/List;)V

    const/4 v3, -0x3

    new-instance v5, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v6, "onCreate error"

    nop

    nop

    const/16 v3, 0x97

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v3, 0x190

    move-object/from16 v0, p1

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, -0x2

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/16 v3, 0x50

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-direct {v0, v1}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->b(Ljava/lang/String;)V

    :cond_936
    :goto_936
    return-void
.end method

.method public onDestroy()V
    .registers 10

    .prologue
    const/16 v1, 0x185

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->W:Ljava/lang/String;

    nop

    const/16 v1, 0x3ca

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_13

    const-string/jumbo v3, "onDestroy"

    nop

    nop

    goto :goto_2b

    :cond_13
    const/4 v1, -0x3

    new-instance v3, Ljava/lang/StringBuilder;

    nop

    const/4 v1, -0x4

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v1, 0x185

    iget-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->W:Ljava/lang/String;

    nop

    const-string/jumbo v5, "_onDestroy"

    nop

    nop

    const/16 v1, 0x3ab

    invoke-static {v3, v4, v5}, Ly41;->s(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    :goto_2b
    const/16 v1, 0x867

    iput-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->W:Ljava/lang/String;

    const/16 v1, 0x100c

    invoke-super {p0}, Lcom/mbridge/msdk/video/signal/activity/AbstractJSActivity;->onDestroy()V

    const/16 v1, 0xc61

    invoke-direct {p0}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->f()V

    const/16 v1, 0x2d6

    new-instance v3, Lcom/mbridge/msdk/foundation/same/report/metrics/e;

    nop

    const/16 v1, 0x4d2

    invoke-direct {v3}, Lcom/mbridge/msdk/foundation/same/report/metrics/e;-><init>()V

    const/16 v1, 0x185

    iget-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->W:Ljava/lang/String;

    nop

    const/16 v1, 0x3ca

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_56

    const-string/jumbo v4, "unKnown"

    nop

    nop

    goto :goto_5b

    :cond_56
    const/16 v1, 0x185

    iget-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->W:Ljava/lang/String;

    nop

    :goto_5b
    const-string/jumbo v5, "activity_life_cycle"

    nop

    nop

    const/16 v1, 0x5c

    invoke-virtual {v3, v5, v4}, Lcom/mbridge/msdk/foundation/same/report/metrics/e;->a(Ljava/lang/String;Ljava/lang/Object;)V

    const/16 v1, 0xa03

    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    move-result-wide v4

    const/16 v1, 0x72d

    iget-wide v6, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->V:J

    nop

    sub-long/2addr v4, v6

    const/16 v1, 0x61

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    const-string/jumbo v5, "activity_duration"

    nop

    nop

    const/16 v1, 0x5c

    invoke-virtual {v3, v5, v4}, Lcom/mbridge/msdk/foundation/same/report/metrics/e;->a(Ljava/lang/String;Ljava/lang/Object;)V

    const/16 v1, 0xf01

    iget-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->X:Ljava/lang/Boolean;

    nop

    const/4 v5, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-nez v4, :cond_8d

    move v4, v5

    goto :goto_98

    :cond_8d
    const/16 v1, 0x205

    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v4

    if-eqz v4, :cond_97

    move v4, v7

    goto :goto_98

    :cond_97
    move v4, v6

    :goto_98
    const/16 v1, 0xb1

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const-string/jumbo v8, "is_unexpected_destroy"

    nop

    nop

    const/16 v1, 0x5c

    invoke-virtual {v3, v8, v4}, Lcom/mbridge/msdk/foundation/same/report/metrics/e;->a(Ljava/lang/String;Ljava/lang/Object;)V

    const/16 v1, 0x4ee

    iget-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->s:Lcom/mbridge/msdk/video/bt/module/orglistener/h;

    nop

    if-nez v4, :cond_b1

    move v4, v7

    goto :goto_b2

    :cond_b1
    move v4, v6

    :goto_b2
    const/16 v1, 0xb1

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const-string/jumbo v8, "is_listener_null"

    nop

    nop

    const/16 v1, 0x5c

    invoke-virtual {v3, v8, v4}, Lcom/mbridge/msdk/foundation/same/report/metrics/e;->a(Ljava/lang/String;Ljava/lang/Object;)V

    const/16 v1, 0x816

    iget-boolean v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->Z:Z

    nop

    if-eqz v4, :cond_cb

    move v4, v7

    goto :goto_cc

    :cond_cb
    move v4, v6

    :goto_cc
    const/16 v1, 0xb1

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const-string/jumbo v8, "is_called_finish"

    nop

    nop

    const/16 v1, 0x5c

    invoke-virtual {v3, v8, v4}, Lcom/mbridge/msdk/foundation/same/report/metrics/e;->a(Ljava/lang/String;Ljava/lang/Object;)V

    const/16 v1, 0xdae

    iget-boolean v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->a0:Z

    nop

    if-eqz v4, :cond_e5

    move v4, v7

    goto :goto_e6

    :cond_e5
    move v4, v6

    :goto_e6
    const/16 v1, 0xb1

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const-string/jumbo v8, "is_back_pressed"

    nop

    nop

    const/16 v1, 0x5c

    invoke-virtual {v3, v8, v4}, Lcom/mbridge/msdk/foundation/same/report/metrics/e;->a(Ljava/lang/String;Ljava/lang/Object;)V

    const/16 v1, 0xbc1

    iget-boolean v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->b0:Z

    nop

    if-eqz v4, :cond_ff

    move v4, v7

    goto :goto_100

    :cond_ff
    move v4, v6

    :goto_100
    const/16 v1, 0xb1

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const-string/jumbo v8, "is_back_dispatcher_invoked"

    nop

    nop

    const/16 v1, 0x5c

    invoke-virtual {v3, v8, v4}, Lcom/mbridge/msdk/foundation/same/report/metrics/e;->a(Ljava/lang/String;Ljava/lang/Object;)V

    const/16 v1, 0x4ee

    iget-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->s:Lcom/mbridge/msdk/video/bt/module/orglistener/h;

    nop

    if-nez v4, :cond_118

    goto :goto_128

    :cond_118
    const/16 v1, 0xec8

    invoke-virtual {v4}, Ljava/lang/Object;->hashCode()I

    move-result v4

    const/16 v1, 0xb68

    iget v5, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->Y:I

    nop

    if-ne v4, v5, :cond_127

    move v5, v7

    goto :goto_128

    :cond_127
    move v5, v6

    :goto_128
    const/16 v1, 0xb1

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const-string/jumbo v5, "is_listener_change"

    nop

    nop

    const/16 v1, 0x5c

    invoke-virtual {v3, v5, v4}, Lcom/mbridge/msdk/foundation/same/report/metrics/e;->a(Ljava/lang/String;Ljava/lang/Object;)V

    const/16 v1, 0xb51

    invoke-static {}, Lcom/mbridge/msdk/foundation/same/report/metrics/d;->b()Lcom/mbridge/msdk/foundation/same/report/metrics/d;

    move-result-object v4

    const/16 v1, 0x35

    iget-object v5, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    nop

    const-string/jumbo v6, "2000151"

    nop

    nop

    const/16 v1, 0xecb

    invoke-virtual {v4, v6, v5, v3}, Lcom/mbridge/msdk/foundation/same/report/metrics/d;->a(Ljava/lang/String;Lcom/mbridge/msdk/foundation/entity/CampaignEx;Lcom/mbridge/msdk/foundation/same/report/metrics/e;)V

    const/16 v1, 0xe29

    invoke-direct {p0}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->g()V

    const/16 v1, 0x55

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->g:Ljava/lang/String;

    nop

    const/16 v1, 0x594

    invoke-static {v3}, Lcom/mbridge/msdk/video/module/report/b;->a(Ljava/lang/String;)V

    const/16 v1, 0x971

    invoke-direct {p0}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->h()V

    const/16 v1, 0x1e

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    const/4 v4, 0x0

    if-eqz v3, :cond_172

    const/16 v1, 0xa09

    invoke-virtual {v3}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->onDestroy()V

    const/16 v1, 0xdb1

    iput-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    :cond_172
    const/16 v1, 0x25

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    nop

    if-eqz v3, :cond_182

    const/16 v1, 0x731

    invoke-virtual {v3}, Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;->onDestroy()V

    const/16 v1, 0xd1f

    iput-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    :cond_182
    const/16 v1, 0xf69

    iput-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->e0:Lcom/mbridge/msdk/video/dynview/listener/a;

    const/16 v1, 0xa4b

    iput-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->f0:Lcom/mbridge/msdk/video/dynview/listener/d;

    const/16 v1, 0x114

    invoke-static {}, Lcom/mbridge/msdk/foundation/feedback/b;->b()Lcom/mbridge/msdk/foundation/feedback/b;

    move-result-object v3

    const/4 v1, -0x3

    new-instance v4, Ljava/lang/StringBuilder;

    nop

    const/4 v1, -0x4

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v1, 0x55

    iget-object v5, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->g:Ljava/lang/String;

    nop

    const/4 v1, 0x0

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v5, "_1"

    nop

    nop

    const/4 v1, 0x0

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, -0x2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/16 v1, 0x2fb

    invoke-virtual {v3, v4}, Lcom/mbridge/msdk/foundation/feedback/b;->d(Ljava/lang/String;)V

    const/16 v1, 0x114

    invoke-static {}, Lcom/mbridge/msdk/foundation/feedback/b;->b()Lcom/mbridge/msdk/foundation/feedback/b;

    move-result-object v3

    const/4 v1, -0x3

    new-instance v4, Ljava/lang/StringBuilder;

    nop

    const/4 v1, -0x4

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v1, 0x55

    iget-object v5, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->g:Ljava/lang/String;

    nop

    const/4 v1, 0x0

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v5, "_2"

    nop

    nop

    const/4 v1, 0x0

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, -0x2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/16 v1, 0x2fb

    invoke-virtual {v3, v4}, Lcom/mbridge/msdk/foundation/feedback/b;->d(Ljava/lang/String;)V

    const/16 v1, 0x7de

    invoke-static {}, Lcom/mbridge/msdk/foundation/same/threadpool/a;->b()Ljava/util/concurrent/ThreadPoolExecutor;

    move-result-object v3

    const/16 v1, 0x100e

    new-instance v4, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity$e;

    nop

    const/16 v1, 0x14f

    iget-object v5, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->y:Ljava/util/List;

    nop

    const/16 v1, 0x55

    iget-object v6, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->g:Ljava/lang/String;

    nop

    const/16 v1, 0x122d

    iget-object p0, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->E:Ljava/lang/String;

    nop

    const/16 v1, 0x110c

    invoke-direct {v4, v5, v6, p0}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity$e;-><init>(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;)V

    const/16 v1, 0xbec

    invoke-virtual {v3, v4}, Ljava/util/concurrent/ThreadPoolExecutor;->execute(Ljava/lang/Runnable;)V

    return-void
.end method

.method public onPause()V
    .registers 6

    .prologue
    const/16 v0, 0x680

    invoke-super {p0}, Lcom/mbridge/msdk/video/signal/activity/AbstractJSActivity;->onPause()V

    const/16 v0, 0x185

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->W:Ljava/lang/String;

    nop

    const/16 v0, 0x3ca

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_18

    const-string/jumbo v2, "onPause"

    nop

    nop

    goto :goto_30

    :cond_18
    const/4 v0, -0x3

    new-instance v2, Ljava/lang/StringBuilder;

    nop

    const/4 v0, -0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v0, 0x185

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->W:Ljava/lang/String;

    nop

    const-string/jumbo v4, "_onPause"

    nop

    nop

    const/16 v0, 0x3ab

    invoke-static {v2, v3, v4}, Ly41;->s(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :goto_30
    const/16 v0, 0x867

    iput-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->W:Ljava/lang/String;

    const/16 v0, 0x1e

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    if-eqz v2, :cond_40

    const/16 v0, 0xe07

    invoke-virtual {v2}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->onPause()V

    :cond_40
    const/16 v0, 0x25

    iget-object p0, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    nop

    if-eqz p0, :cond_4c

    const/16 v0, 0x86a

    invoke-virtual {p0}, Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;->onPause()V

    :cond_4c
    return-void
.end method

.method public onRestart()V
    .registers 6

    .prologue
    const/16 v0, 0x5eb

    invoke-super {p0}, Landroid/app/Activity;->onRestart()V

    const/16 v0, 0x185

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->W:Ljava/lang/String;

    nop

    const/16 v0, 0x3ca

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_18

    const-string/jumbo v2, "onRestart"

    nop

    nop

    goto :goto_30

    :cond_18
    const/4 v0, -0x3

    new-instance v2, Ljava/lang/StringBuilder;

    nop

    const/4 v0, -0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v0, 0x185

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->W:Ljava/lang/String;

    nop

    const-string/jumbo v4, "_onRestart"

    nop

    nop

    const/16 v0, 0x3ab

    invoke-static {v2, v3, v4}, Ly41;->s(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :goto_30
    const/16 v0, 0x867

    iput-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->W:Ljava/lang/String;

    const/16 v0, 0x1e

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    if-eqz v2, :cond_40

    const/16 v0, 0x31f

    invoke-virtual {v2}, Lcom/mbridge/msdk/video/signal/container/AbstractJSContainer;->onRestart()V

    :cond_40
    const/16 v0, 0x25

    iget-object p0, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    nop

    if-eqz p0, :cond_4c

    const/16 v0, 0x31f

    invoke-virtual {p0}, Lcom/mbridge/msdk/video/signal/container/AbstractJSContainer;->onRestart()V

    :cond_4c
    return-void
.end method

.method public onResume()V
    .registers 7

    .prologue
    const/16 v0, 0xdea

    invoke-super {p0}, Lcom/mbridge/msdk/video/signal/activity/AbstractJSActivity;->onResume()V

    const/16 v0, 0x185

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->W:Ljava/lang/String;

    nop

    const/16 v0, 0x3ca

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_18

    const-string/jumbo v2, "onResume"

    nop

    nop

    goto :goto_30

    :cond_18
    const/4 v0, -0x3

    new-instance v2, Ljava/lang/StringBuilder;

    nop

    const/4 v0, -0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v0, 0x185

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->W:Ljava/lang/String;

    nop

    const-string/jumbo v4, "_onResume"

    nop

    nop

    const/16 v0, 0x3ab

    invoke-static {v2, v3, v4}, Ly41;->s(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :goto_30
    const/16 v0, 0x867

    iput-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->W:Ljava/lang/String;

    const/16 v0, 0xd7c

    sget-boolean v2, Lcom/mbridge/msdk/foundation/feedback/b;->f:Z

    nop

    if-eqz v2, :cond_50

    const/16 v0, 0x1e

    iget-object p0, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    if-eqz p0, :cond_a4

    const/16 v0, 0xaac

    iget-object p0, p0, Lcom/mbridge/msdk/video/bt/module/MBTempContainerDiff;->mbridgeVideoView:Lcom/mbridge/msdk/video/module/MBridgeVideoView;

    nop

    if-eqz p0, :cond_a4

    const/4 v2, 0x0

    const/16 v0, 0x6c5

    invoke-virtual {p0, v2}, Lcom/mbridge/msdk/video/module/MBridgeVideoView;->setCover(Z)V

    return-void

    :cond_50
    const/16 v0, 0x67

    invoke-static {}, Lcom/mbridge/msdk/foundation/controller/c;->n()Lcom/mbridge/msdk/foundation/controller/c;

    move-result-object v2

    const/16 v0, 0xaf0

    invoke-virtual {v2, p0}, Lcom/mbridge/msdk/foundation/controller/a;->a(Landroid/content/Context;)V

    :try_start_5b
    const/16 v0, 0x7de

    invoke-static {}, Lcom/mbridge/msdk/foundation/same/threadpool/a;->b()Ljava/util/concurrent/ThreadPoolExecutor;

    move-result-object v2

    const/16 v0, 0xdf8

    new-instance v3, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity$f;

    nop

    const/16 v0, 0x55

    iget-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->g:Ljava/lang/String;

    nop

    const/16 v0, 0x14f

    iget-object v5, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->y:Ljava/util/List;

    nop

    const/16 v0, 0xd4f

    invoke-direct {v3, v4, v5}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity$f;-><init>(Ljava/lang/String;Ljava/util/List;)V

    const/16 v0, 0xbec

    invoke-virtual {v2, v3}, Ljava/util/concurrent/ThreadPoolExecutor;->execute(Ljava/lang/Runnable;)V
    :try_end_7a
    .catchall {:try_start_5b .. :try_end_7a} :catchall_7b

    goto :goto_8c

    :catchall_7b
    move-exception v2

    const/16 v0, 0x1da

    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    const-string/jumbo v3, "MBRewardVideoActivity"

    nop

    nop

    const/16 v0, 0xd96

    invoke-static {v3, v2}, Lcom/mbridge/msdk/foundation/tools/q0;->b(Ljava/lang/String;Ljava/lang/String;)V

    :goto_8c
    const/16 v0, 0x1e

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    if-eqz v2, :cond_98

    const/16 v0, 0xa9a

    invoke-virtual {v2}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->onResume()V

    :cond_98
    const/16 v0, 0x25

    iget-object p0, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    nop

    if-eqz p0, :cond_a4

    const/16 v0, 0xd65

    invoke-virtual {p0}, Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;->onResume()V

    :cond_a4
    return-void
.end method

.method public onSaveInstanceState(Landroid/os/Bundle;)V
    .registers 6

    const/16 v0, 0xb47

    sget-object v2, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->SAVE_STATE_KEY_REPORT:Ljava/lang/String;

    nop

    const/16 v0, 0x941

    iget-boolean v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->v:Z

    nop

    const/16 v0, 0x27b

    invoke-virtual {p1, v2, v3}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/16 v0, 0x100a

    invoke-super {p0, p1}, Landroid/app/Activity;->onSaveInstanceState(Landroid/os/Bundle;)V

    return-void
.end method

.method public onStart()V
    .registers 8

    .prologue
    const/16 v0, 0xa99

    invoke-super {p0}, Landroid/app/Activity;->onStart()V

    const/16 v0, 0x185

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->W:Ljava/lang/String;

    nop

    const/16 v0, 0x3ca

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_18

    const-string/jumbo v2, "onStart"

    nop

    nop

    goto :goto_30

    :cond_18
    const/4 v0, -0x3

    new-instance v2, Ljava/lang/StringBuilder;

    nop

    const/4 v0, -0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v0, 0x185

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->W:Ljava/lang/String;

    nop

    const-string/jumbo v4, "_onStart"

    nop

    nop

    const/16 v0, 0x3ab

    invoke-static {v2, v3, v4}, Ly41;->s(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :goto_30
    const/16 v0, 0x867

    iput-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->W:Ljava/lang/String;

    const/16 v0, 0xd7c

    sget-boolean v2, Lcom/mbridge/msdk/foundation/feedback/b;->f:Z

    nop

    if-eqz v2, :cond_3d

    goto/16 :goto_13d

    :cond_3d
    const/16 v0, 0x8c9

    new-instance v2, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity$d;

    nop

    const/16 v0, 0x11f4

    invoke-direct {v2, p0}, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity$d;-><init>(Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;)V

    const/16 v0, 0x1e

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    const-string/jumbo v3, "_1"

    nop

    nop

    if-eqz v2, :cond_8a

    const/16 v0, 0x465

    invoke-virtual {v2}, Lcom/mbridge/msdk/video/signal/container/AbstractJSContainer;->onStart()V

    const/16 v0, 0x35

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    nop

    const/16 v0, 0x55

    iget-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->g:Ljava/lang/String;

    nop

    const/16 v0, 0x2d7

    invoke-virtual {v2, v4}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->setCampaignUnitId(Ljava/lang/String;)V

    const/16 v0, 0x114

    invoke-static {}, Lcom/mbridge/msdk/foundation/feedback/b;->b()Lcom/mbridge/msdk/foundation/feedback/b;

    move-result-object v2

    const/4 v0, -0x3

    new-instance v4, Ljava/lang/StringBuilder;

    nop

    const/4 v0, -0x4

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v0, 0x55

    iget-object v5, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->g:Ljava/lang/String;

    nop

    const/16 v0, 0x3ab

    invoke-static {v4, v5, v3}, Ly41;->s(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/16 v0, 0x35

    iget-object v5, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->x:Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    nop

    const/16 v0, 0x2c0

    invoke-virtual {v2, v4, v5}, Lcom/mbridge/msdk/foundation/feedback/b;->a(Ljava/lang/String;Lcom/mbridge/msdk/foundation/entity/CampaignEx;)V

    :cond_8a
    const/16 v0, 0x25

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    nop

    if-eqz v2, :cond_e2

    const/16 v0, 0x465

    invoke-virtual {v2}, Lcom/mbridge/msdk/video/signal/container/AbstractJSContainer;->onStart()V

    const/16 v0, 0x60

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    nop

    if-eqz v2, :cond_e2

    const/16 v0, 0x17d

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    if-lez v2, :cond_e2

    const/16 v0, 0x60

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->z:Ljava/util/List;

    nop

    const/4 v4, 0x0

    const/16 v0, 0x24

    invoke-interface {v2, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/mbridge/msdk/foundation/entity/CampaignEx;

    const/16 v0, 0x55

    iget-object v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->g:Ljava/lang/String;

    nop

    const/16 v0, 0x2d7

    invoke-virtual {v2, v4}, Lcom/mbridge/msdk/foundation/entity/CampaignEx;->setCampaignUnitId(Ljava/lang/String;)V

    const/16 v0, 0x114

    invoke-static {}, Lcom/mbridge/msdk/foundation/feedback/b;->b()Lcom/mbridge/msdk/foundation/feedback/b;

    move-result-object v4

    const/4 v0, -0x3

    new-instance v5, Ljava/lang/StringBuilder;

    nop

    const/4 v0, -0x4

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v0, 0x55

    iget-object v6, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->g:Ljava/lang/String;

    nop

    const/4 v0, 0x0

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/16 v0, 0x2c0

    invoke-virtual {v4, v5, v2}, Lcom/mbridge/msdk/foundation/feedback/b;->a(Ljava/lang/String;Lcom/mbridge/msdk/foundation/entity/CampaignEx;)V

    :cond_e2
    const/16 v0, 0xf81

    iget-boolean v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->G:Z

    nop

    if-nez v2, :cond_13d

    const/16 v0, 0x114

    invoke-static {}, Lcom/mbridge/msdk/foundation/feedback/b;->b()Lcom/mbridge/msdk/foundation/feedback/b;

    move-result-object v2

    const/4 v0, -0x3

    new-instance v4, Ljava/lang/StringBuilder;

    nop

    const/4 v0, -0x4

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v0, 0x55

    iget-object v5, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->g:Ljava/lang/String;

    nop

    const/4 v0, 0x0

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x1

    const/16 v0, 0x11a2

    invoke-virtual {v2, v3, v4}, Lcom/mbridge/msdk/foundation/feedback/b;->a(Ljava/lang/String;I)V

    const/16 v0, 0x114

    invoke-static {}, Lcom/mbridge/msdk/foundation/feedback/b;->b()Lcom/mbridge/msdk/foundation/feedback/b;

    move-result-object v2

    const/4 v0, -0x3

    new-instance v3, Ljava/lang/StringBuilder;

    nop

    const/4 v0, -0x4

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v0, 0x55

    iget-object v5, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->g:Ljava/lang/String;

    nop

    const/4 v0, 0x0

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v5, "_2"

    nop

    nop

    const/4 v0, 0x0

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/16 v0, 0x2fb

    invoke-virtual {v2, v3}, Lcom/mbridge/msdk/foundation/feedback/b;->d(Ljava/lang/String;)V

    const/16 v0, 0xee0

    iput-boolean v4, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->G:Z

    :cond_13d
    :goto_13d
    return-void
.end method

.method public onStop()V
    .registers 6

    .prologue
    const/16 v0, 0x185

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->W:Ljava/lang/String;

    nop

    const/16 v0, 0x3ca

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_13

    const-string/jumbo v2, "onStop"

    nop

    nop

    goto :goto_2b

    :cond_13
    const/4 v0, -0x3

    new-instance v2, Ljava/lang/StringBuilder;

    nop

    const/4 v0, -0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v0, 0x185

    iget-object v3, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->W:Ljava/lang/String;

    nop

    const-string/jumbo v4, "_onStop"

    nop

    nop

    const/16 v0, 0x3ab

    invoke-static {v2, v3, v4}, Ly41;->s(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :goto_2b
    const/16 v0, 0x867

    iput-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->W:Ljava/lang/String;

    const/4 v2, 0x0

    const/16 v0, 0xf31

    sput-boolean v2, Lcom/mbridge/msdk/MBridgeConstans;->isRewardActivityShowing:Z

    const/16 v0, 0xc23

    invoke-super {p0}, Landroid/app/Activity;->onStop()V

    const/16 v0, 0x1e

    iget-object v2, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    if-eqz v2, :cond_45

    const/16 v0, 0xb7c

    invoke-virtual {v2}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->onStop()V

    :cond_45
    const/16 v0, 0x25

    iget-object p0, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    nop

    if-eqz p0, :cond_51

    const/16 v0, 0x1153

    invoke-virtual {p0}, Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;->onStop()V

    :cond_51
    return-void
.end method

.method public setTheme(I)V
    .registers 5

    const-string/jumbo p1, "mbridge_transparent_theme"

    nop

    nop

    const-string/jumbo v2, "style"

    nop

    nop

    const/16 v0, 0x463

    invoke-static {p0, p1, v2}, Lcom/mbridge/msdk/foundation/tools/i0;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I

    move-result p1

    const/16 v0, 0xe5b

    invoke-super {p0, p1}, Landroid/app/Activity;->setTheme(I)V

    return-void
.end method

.method public setTopControllerPadding(IIIII)V
    .registers 21

    .prologue
    const/16 v7, 0x8b8

    move/from16 v0, p2

    iput v0, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->J:I

    const/16 v7, 0x60b

    move/from16 v0, p3

    iput v0, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->L:I

    const/16 v7, 0x78d

    move/from16 v0, p4

    iput v0, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->K:I

    const/16 v7, 0x114c

    move/from16 v0, p5

    iput v0, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->M:I

    const/16 v7, 0xf9c

    move/from16 v0, p1

    iput v0, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->N:I

    const/16 v7, 0x1e

    iget-object v9, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->A:Lcom/mbridge/msdk/video/bt/module/MBTempContainer;

    nop

    if-eqz v9, :cond_3b

    move/from16 v10, p1

    move/from16 v11, p2

    move/from16 v12, p3

    move/from16 v13, p4

    move/from16 v14, p5

    const/16 v7, 0xa57

    move v0, v7

    move-object v1, v9

    move v2, v10

    move v3, v11

    move v4, v12

    move v5, v13

    move v6, v14

    invoke-virtual/range {v1 .. v6}, Lcom/mbridge/msdk/video/bt/module/MBTempContainer;->setNotchPadding(IIIII)V

    :cond_3b
    const/16 v7, 0x25

    iget-object p0, p0, Lcom/mbridge/msdk/reward/player/MBRewardVideoActivity;->B:Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;

    nop

    if-eqz p0, :cond_53

    const/16 v7, 0xecc

    move v0, v7

    move-object v1, p0

    move/from16 v2, p1

    move/from16 v3, p2

    move/from16 v4, p3

    move/from16 v5, p4

    move/from16 v6, p5

    invoke-virtual/range {v1 .. v6}, Lcom/mbridge/msdk/video/bt/module/MBridgeBTContainer;->setNotchPadding(IIIII)V

    :cond_53
    const/16 v7, 0x7a2

    move v0, v7

    move/from16 v1, p1

    move/from16 v2, p2

    move/from16 v3, p3

    move/from16 v4, p4

    move/from16 v5, p5

    invoke-static/range {v1 .. v5}, Lcom/mbridge/msdk/video/dynview/constant/a;->a(IIIII)V

    return-void
.end method
