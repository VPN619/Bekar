.class public Lcom/mbridge/msdk/activity/MBCommonActivity;
.super Lcom/mbridge/msdk/activity/DomainMBCommonActivity;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final synthetic e:I


# instance fields
.field private d:Z


# direct methods
.method public constructor <init>()V
    .registers 4

    invoke-direct {p0}, Lcom/mbridge/msdk/activity/DomainMBCommonActivity;-><init>()V

    const/4 v2, 0x0

    const/16 v0, 0x9a6

    iput-boolean v2, p0, Lcom/mbridge/msdk/activity/MBCommonActivity;->d:Z

    return-void
.end method


# virtual methods
.method public finish()V
    .registers 6

    .prologue
    const/16 v0, 0x31b

    iget-object v2, p0, Lcom/mbridge/msdk/activity/DomainMBCommonActivity;->browserView:Lcom/mbridge/msdk/foundation/webview/BrowserView;

    nop

    const/4 v3, 0x0

    if-eqz v2, :cond_17

    const/16 v0, 0x297

    invoke-virtual {v2, v3}, Lcom/mbridge/msdk/foundation/webview/BrowserView;->setListener(Lcom/mbridge/msdk/foundation/webview/BrowserView$e;)V

    const/16 v0, 0x31b

    iget-object v2, p0, Lcom/mbridge/msdk/activity/DomainMBCommonActivity;->browserView:Lcom/mbridge/msdk/foundation/webview/BrowserView;

    nop

    const/16 v0, 0x28b

    invoke-virtual {v2}, Lcom/mbridge/msdk/foundation/webview/BrowserView;->destroy()V

    :cond_17
    const/16 v0, 0xd2a

    sget-object v2, Lcom/mbridge/msdk/foundation/webview/b;->a:Ljava/util/HashMap;

    nop

    const/16 v0, 0x10d2

    iget-object v4, p0, Lcom/mbridge/msdk/activity/DomainMBCommonActivity;->a:Ljava/lang/String;

    nop

    const/16 v0, 0x1072

    invoke-virtual {v2, v4}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/mbridge/msdk/foundation/webview/BrowserView;

    if-eqz v2, :cond_35

    const/16 v0, 0x297

    invoke-virtual {v2, v3}, Lcom/mbridge/msdk/foundation/webview/BrowserView;->setListener(Lcom/mbridge/msdk/foundation/webview/BrowserView$e;)V

    const/16 v0, 0x28b

    invoke-virtual {v2}, Lcom/mbridge/msdk/foundation/webview/BrowserView;->destroy()V

    :cond_35
    const/4 v2, 0x1

    const/16 v0, 0x9a6

    iput-boolean v2, p0, Lcom/mbridge/msdk/activity/MBCommonActivity;->d:Z

    const/16 v0, 0x660

    invoke-super {p0}, Landroid/app/Activity;->finish()V

    return-void
.end method

.method public onCreate(Landroid/os/Bundle;)V
    .registers 6

    .prologue
    const/16 v0, 0x1fc

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 v3, 0x1a

    if-eq v2, v3, :cond_f

    const/4 v2, 0x1

    const/16 v0, 0xeb9

    invoke-virtual {p0, v2}, Landroid/app/Activity;->setRequestedOrientation(I)V

    :cond_f
    const/16 v0, 0x9a1

    invoke-super {p0, p1}, Lcom/mbridge/msdk/activity/DomainMBCommonActivity;->onCreate(Landroid/os/Bundle;)V

    return-void
.end method

.method public onDestroy()V
    .registers 5

    .prologue
    const/16 v0, 0xc7d

    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    const/16 v0, 0xf95

    iget-boolean v2, p0, Lcom/mbridge/msdk/activity/MBCommonActivity;->d:Z

    nop

    if-nez v2, :cond_41

    const/16 v0, 0x31b

    iget-object v2, p0, Lcom/mbridge/msdk/activity/DomainMBCommonActivity;->browserView:Lcom/mbridge/msdk/foundation/webview/BrowserView;

    nop

    const/4 v3, 0x0

    if-eqz v2, :cond_23

    const/16 v0, 0x297

    invoke-virtual {v2, v3}, Lcom/mbridge/msdk/foundation/webview/BrowserView;->setListener(Lcom/mbridge/msdk/foundation/webview/BrowserView$e;)V

    const/16 v0, 0x31b

    iget-object v2, p0, Lcom/mbridge/msdk/activity/DomainMBCommonActivity;->browserView:Lcom/mbridge/msdk/foundation/webview/BrowserView;

    nop

    const/16 v0, 0x28b

    invoke-virtual {v2}, Lcom/mbridge/msdk/foundation/webview/BrowserView;->destroy()V

    :cond_23
    const/16 v0, 0xd2a

    sget-object v2, Lcom/mbridge/msdk/foundation/webview/b;->a:Ljava/util/HashMap;

    nop

    const/16 v0, 0x10d2

    iget-object p0, p0, Lcom/mbridge/msdk/activity/DomainMBCommonActivity;->a:Ljava/lang/String;

    nop

    const/16 v0, 0x1072

    invoke-virtual {v2, p0}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lcom/mbridge/msdk/foundation/webview/BrowserView;

    if-eqz p0, :cond_41

    const/16 v0, 0x297

    invoke-virtual {p0, v3}, Lcom/mbridge/msdk/foundation/webview/BrowserView;->setListener(Lcom/mbridge/msdk/foundation/webview/BrowserView$e;)V

    const/16 v0, 0x28b

    invoke-virtual {p0}, Lcom/mbridge/msdk/foundation/webview/BrowserView;->destroy()V

    :cond_41
    return-void
.end method
