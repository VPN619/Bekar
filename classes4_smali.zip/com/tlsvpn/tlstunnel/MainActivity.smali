.class public final Lcom/tlsvpn/tlstunnel/MainActivity;
.super Lra;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final synthetic m:I


# instance fields
.field public final g:Lw82;

.field public h:Lcom/google/firebase/analytics/FirebaseAnalytics;

.field public i:Lcom/google/android/material/bottomnavigation/BottomNavigationView;

.field public j:Z

.field public final k:Lob;

.field public final l:Lw82;


# direct methods
.method public constructor <init>()V
    .registers 5

    invoke-direct {p0}, Lra;-><init>()V

    const/16 v0, 0x3b2

    new-instance v2, Lf51;

    nop

    const/4 v3, 0x0

    const/16 v0, 0x440

    invoke-direct {v2, p0, v3}, Lf51;-><init>(Lcom/tlsvpn/tlstunnel/MainActivity;I)V

    const/16 v0, 0x27a

    new-instance v3, Lw82;

    nop

    const/16 v0, 0x215

    invoke-direct {v3, v2}, Lw82;-><init>(Lzj0;)V

    const/16 v0, 0x7af

    iput-object v3, p0, Lcom/tlsvpn/tlstunnel/MainActivity;->g:Lw82;

    const/4 v2, 0x1

    const/16 v0, 0x10b8

    iput-boolean v2, p0, Lcom/tlsvpn/tlstunnel/MainActivity;->j:Z

    const/16 v0, 0xf6e

    new-instance v2, Lob;

    nop

    const/4 v3, 0x5

    const/16 v0, 0x11c1

    invoke-direct {v2, v3, p0}, Lob;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x1128

    iput-object v2, p0, Lcom/tlsvpn/tlstunnel/MainActivity;->k:Lob;

    const/16 v0, 0x3b2

    new-instance v2, Lf51;

    nop

    const/4 v3, 0x1

    const/16 v0, 0x440

    invoke-direct {v2, p0, v3}, Lf51;-><init>(Lcom/tlsvpn/tlstunnel/MainActivity;I)V

    const/16 v0, 0x27a

    new-instance v3, Lw82;

    nop

    const/16 v0, 0x215

    invoke-direct {v3, v2}, Lw82;-><init>(Lzj0;)V

    const/16 v0, 0x801

    iput-object v3, p0, Lcom/tlsvpn/tlstunnel/MainActivity;->l:Lw82;

    return-void
.end method

.method public static l()Ljava/lang/String;
    .registers 6

    const/16 v0, 0x1062

    new-instance v2, Ljava/util/Date;

    nop

    const/16 v0, 0x958

    invoke-direct {v2}, Ljava/util/Date;-><init>()V

    const/16 v0, 0xd54

    new-instance v3, Ljava/text/SimpleDateFormat;

    nop

    const-string/jumbo v4, "HH:mm:ss"

    nop

    nop

    const/16 v0, 0xa75

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v5

    const/16 v0, 0xc81

    invoke-direct {v3, v4, v5}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    const/16 v0, 0xa9e

    invoke-virtual {v3, v2}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v2, Ljava/lang/String;

    return-object v2
.end method


# virtual methods
.method public final g()V
    .registers 22

    .prologue
    const/16 v6, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v8

    const/16 v6, 0x95

    move-object/from16 v0, p0

    invoke-virtual {v0}, Lcom/tlsvpn/tlstunnel/MainActivity;->j()Landroid/content/SharedPreferences;

    move-result-object v10

    const-string/jumbo v11, "csldhtupd"

    nop

    nop

    const-wide/16 v12, 0x0

    const/16 v6, 0x46e

    invoke-interface {v10, v11, v12, v13}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v10

    const/16 v6, 0x95

    move-object/from16 v0, p0

    invoke-virtual {v0}, Lcom/tlsvpn/tlstunnel/MainActivity;->j()Landroid/content/SharedPreferences;

    move-result-object v14

    const-string/jumbo v15, "cpsldhtupd"

    nop

    nop

    const/16 v6, 0x46e

    invoke-interface {v14, v15, v12, v13}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v14

    sub-long v16, v8, v10

    const-wide/32 v18, 0xdbba0

    cmp-long v16, v16, v18

    const/16 v17, 0x0

    const/16 v20, 0x1

    if-gtz v16, :cond_43

    cmp-long v10, v10, v12

    if-nez v10, :cond_40

    goto :goto_43

    :cond_40
    move/from16 v10, v17

    goto :goto_45

    :cond_43
    :goto_43
    move/from16 v10, v20

    :goto_45
    sub-long/2addr v8, v14

    cmp-long v8, v8, v18

    if-gtz v8, :cond_52

    cmp-long v8, v14, v12

    if-nez v8, :cond_4f

    goto :goto_52

    :cond_4f
    move/from16 v8, v17

    goto :goto_54

    :cond_52
    :goto_52
    move/from16 v8, v20

    :goto_54
    const/16 v6, 0x5b

    new-instance v9, Landroid/content/Intent;

    nop

    const-string/jumbo v11, "SLISTUPDATE"

    nop

    nop

    const/4 v12, 0x0

    const-class v13, Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;

    const/16 v6, 0x3fd

    move v0, v6

    move-object v1, v9

    move-object v2, v11

    move-object v3, v12

    move-object/from16 v4, p0

    move-object v5, v13

    invoke-direct/range {v1 .. v5}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;Landroid/content/Context;Ljava/lang/Class;)V

    const-string/jumbo v14, "cTp"

    nop

    nop

    const/4 v15, 0x4

    const/16 v6, 0x29

    invoke-virtual {v9, v14, v15}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v9

    const-string/jumbo v16, "cspl"

    nop

    nop

    const/16 v6, 0x178

    move-object/from16 v0, v16

    move/from16 v1, v17

    invoke-virtual {v9, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    move-result-object v9

    const/16 v6, 0x234

    move-object/from16 v0, p0

    iget-boolean v6, v0, Lcom/tlsvpn/tlstunnel/MainActivity;->j:Z

    move/16 v17, v6

    xor-int v17, v17, v20

    const-string/jumbo v18, "notifymain"

    nop

    nop

    const/16 v6, 0x178

    move-object/from16 v0, v18

    move/from16 v1, v17

    invoke-virtual {v9, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    move-result-object v9

    const/4 v6, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x5b

    new-instance v17, Landroid/content/Intent;

    nop

    const/16 v6, 0x3fd

    move v0, v6

    move-object/from16 v1, v17

    move-object v2, v11

    move-object v3, v12

    move-object/from16 v4, p0

    move-object v5, v13

    invoke-direct/range {v1 .. v5}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;Landroid/content/Context;Ljava/lang/Class;)V

    const/16 v6, 0x29

    move-object/from16 v0, v17

    invoke-virtual {v0, v14, v15}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v11

    const/16 v6, 0x178

    move-object/from16 v0, v16

    move/from16 v1, v20

    invoke-virtual {v11, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    move-result-object v11

    const/16 v6, 0x234

    move-object/from16 v0, p0

    iget-boolean v12, v0, Lcom/tlsvpn/tlstunnel/MainActivity;->j:Z

    nop

    xor-int v12, v12, v20

    const/16 v6, 0x178

    move-object/from16 v0, v18

    invoke-virtual {v11, v0, v12}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    move-result-object v11

    const/4 v6, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-eqz v10, :cond_e8

    :try_start_e1
    const/16 v6, 0x4a7

    move-object/from16 v0, p0

    invoke-virtual {v0, v9}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_e8
    .catch Ljava/lang/Exception; {:try_start_e1 .. :try_end_e8} :catch_e8

    :catch_e8
    :cond_e8
    if-eqz v8, :cond_f1

    :try_start_ea
    const/16 v6, 0x4a7

    move-object/from16 v0, p0

    invoke-virtual {v0, v11}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_f1
    .catch Ljava/lang/Exception; {:try_start_ea .. :try_end_f1} :catch_f1

    :catch_f1
    :cond_f1
    return-void
.end method

.method public final h()Lcom/google/android/material/bottomnavigation/BottomNavigationView;
    .registers 3

    .prologue
    const/16 v0, 0x1016

    iget-object p0, p0, Lcom/tlsvpn/tlstunnel/MainActivity;->i:Lcom/google/android/material/bottomnavigation/BottomNavigationView;

    nop

    if-eqz p0, :cond_a

    check-cast p0, Lcom/google/android/material/bottomnavigation/BottomNavigationView;

    return-object p0

    :cond_a
    const-string/jumbo p0, "bottomNavigationView"

    nop

    nop

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0
.end method

.method public final i(Lwx;)Ljava/lang/Object;
    .registers 18

    .prologue
    move-object/from16 v0, p1

    instance-of v8, v0, Lg51;

    if-eqz v8, :cond_1b

    move-object/from16 v8, p1

    check-cast v8, Lg51;

    const/16 v6, 0x30f

    iget v9, v8, Lg51;->x:I

    nop

    const/high16 v10, -0x80000000

    and-int v11, v9, v10

    if-eqz v11, :cond_1b

    sub-int/2addr v9, v10

    const/16 v6, 0x3fe

    iput v9, v8, Lg51;->x:I

    goto :goto_29

    :cond_1b
    const/16 v6, 0xbff

    new-instance v8, Lg51;

    nop

    const/16 v6, 0xa18

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-direct {v8, v0, v1}, Lg51;-><init>(Lcom/tlsvpn/tlstunnel/MainActivity;Lwx;)V

    :goto_29
    const/16 v6, 0xb28

    iget-object v6, v8, Lg51;->v:Ljava/lang/Object;

    move-object/16 p1, v6

    const/16 v6, 0x30f

    iget v9, v8, Lg51;->x:I

    nop

    const/4 v10, 0x1

    const/4 v11, 0x0

    if-eqz v9, :cond_5a

    if-ne v9, v10, :cond_4d

    const/16 v6, 0xfef

    iget v9, v8, Lg51;->u:I

    nop

    const/16 v6, 0xe71

    iget-object v12, v8, Lg51;->t:Ljava/util/Iterator;

    nop

    const/4 v6, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    goto/16 :goto_d4

    :cond_4d
    const-string/jumbo p0, "call to \'resume\' before \'invoke\' with coroutine"

    nop

    nop

    const/16 v6, 0x13

    move-object/from16 v0, p0

    invoke-static {v0}, Lz6;->w(Ljava/lang/String;)V

    return-object v11

    :cond_5a
    const/4 v6, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    const-string/jumbo p1, "connectivity"

    nop

    nop

    const/16 v6, 0x31d

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, -0x6

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p1, Landroid/net/ConnectivityManager;

    const/16 v6, 0x4d7

    move-object/from16 v0, p1

    invoke-virtual {v0}, Landroid/net/ConnectivityManager;->getActiveNetwork()Landroid/net/Network;

    move-result-object v9

    if-eqz v9, :cond_11f

    const/16 v6, 0x4d7

    move-object/from16 v0, p1

    invoke-virtual {v0}, Landroid/net/ConnectivityManager;->getActiveNetwork()Landroid/net/Network;

    move-result-object v9

    const/16 v6, 0xa24

    move-object/from16 v0, p1

    invoke-virtual {v0, v9}, Landroid/net/ConnectivityManager;->getLinkProperties(Landroid/net/Network;)Landroid/net/LinkProperties;

    move-result-object p1

    if-eqz p1, :cond_11f

    const/16 v6, 0x6fc

    move-object/from16 v0, p1

    invoke-virtual {v0}, Landroid/net/LinkProperties;->getLinkAddresses()Ljava/util/List;

    move-result-object p1

    if-eqz p1, :cond_11f

    check-cast p1, Ljava/lang/Iterable;

    const/16 v6, 0x3cc

    new-instance v9, Laq;

    nop

    const/4 v12, 0x6

    const/16 v6, 0x2ac

    invoke-direct {v9, v12}, Laq;-><init>(I)V

    const/16 v6, 0x4d1

    move-object/from16 v0, p1

    invoke-static {v0, v9}, Lbs;->x0(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object p1

    check-cast p1, Ljava/lang/Iterable;

    const/16 v6, 0x3cc

    new-instance v9, Laq;

    nop

    const/4 v12, 0x7

    const/16 v6, 0x2ac

    invoke-direct {v9, v12}, Laq;-><init>(I)V

    const/16 v6, 0x4d1

    move-object/from16 v0, p1

    invoke-static {v0, v9}, Lbs;->x0(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object p1

    check-cast p1, Ljava/lang/Iterable;

    const/16 v6, 0x429

    move-object/from16 v0, p1

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    const/4 v9, 0x0

    move-object/from16 v12, p1

    :cond_d4
    :goto_d4
    const/16 v6, 0x13e

    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_11f

    const/16 v6, 0x16e

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/net/LinkAddress;

    const/16 v6, 0x132

    sget-object v13, Lh50;->a:Li20;

    nop

    const/16 v6, 0x124a

    sget-object v13, Lh51;->a:Lum0;

    nop

    const/16 v6, 0x1215

    new-instance v14, Lb11;

    nop

    const/4 v15, 0x2

    const/16 v6, 0xc74

    move v0, v6

    move-object v1, v14

    move-object/from16 v2, p0

    move-object/from16 v3, p1

    move-object v4, v11

    move v5, v15

    invoke-direct/range {v1 .. v5}, Lb11;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lvx;I)V

    const/16 v6, 0x5c1

    iput-object v12, v8, Lg51;->t:Ljava/util/Iterator;

    const/16 v6, 0x90a

    iput v9, v8, Lg51;->u:I

    const/16 v6, 0x3fe

    iput v10, v8, Lg51;->x:I

    const/16 v6, 0x121

    invoke-static {v13, v14, v8}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object p1

    const/16 v6, 0x15

    sget-object v13, Lwy;->a:Lwy;

    nop

    move-object/from16 v0, p1

    if-ne v0, v13, :cond_d4

    check-cast v13, Ljava/lang/Object;

    return-object v13

    :cond_11f
    const/16 v6, 0x21

    sget-object p0, Lrg2;->a:Lrg2;

    nop

    check-cast p0, Ljava/lang/Object;

    return-object p0
.end method

.method public final j()Landroid/content/SharedPreferences;
    .registers 3

    const/16 v0, 0x7cf

    iget-object p0, p0, Lcom/tlsvpn/tlstunnel/MainActivity;->g:Lw82;

    nop

    const/16 v0, 0x177

    invoke-virtual {p0}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/content/SharedPreferences;

    return-object p0
.end method

.method public final k()V
    .registers 7

    .prologue
    const/16 v0, 0x1f9

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/MainActivity;->h()Lcom/google/android/material/bottomnavigation/BottomNavigationView;

    move-result-object v2

    const v3, 0x7f090130

    const/16 v0, 0x5b9

    invoke-virtual {v2, v3}, Lyd1;->a(I)Ljh;

    move-result-object v2

    const/16 v0, 0x140

    sget-boolean v3, Lg4;->a:Z

    nop

    const/16 v0, 0x22b

    sget-object v3, Lg4;->A:Lxu1;

    nop

    const/4 v4, 0x0

    if-eqz v3, :cond_2d

    const/16 v0, 0x95

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/MainActivity;->j()Landroid/content/SharedPreferences;

    move-result-object v3

    const/4 v0, -0x6

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xfa8

    invoke-static {v3}, Lg4;->g(Landroid/content/SharedPreferences;)Z

    move-result v3

    goto :goto_2e

    :cond_2d
    move v3, v4

    :goto_2e
    const/16 v0, 0x905

    sget-boolean v5, Lmi2;->a:Z

    nop

    const/16 v0, 0x95

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/MainActivity;->j()Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x1112

    invoke-static {p0}, Lmi2;->d(Landroid/content/SharedPreferences;)Z

    move-result p0

    if-eqz p0, :cond_47

    add-int/lit8 v3, v3, 0x1

    :cond_47
    const/16 v0, 0x5cb

    invoke-virtual {v2, v3}, Ljh;->i(I)V

    if-lez v3, :cond_4f

    const/4 v4, 0x1

    :cond_4f
    const/16 v0, 0xb65

    invoke-virtual {v2, v4}, Ljh;->j(Z)V

    return-void
.end method

.method public final m()V
    .registers 13

    const/16 v6, 0x95

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/MainActivity;->j()Landroid/content/SharedPreferences;

    move-result-object v8

    const/4 v6, -0x6

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x7a

    invoke-interface {v8}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v8

    const-string/jumbo v9, "cryptoconfig"

    nop

    nop

    const-string/jumbo v10, ""

    const/16 v6, 0x3c

    invoke-interface {v8, v9, v10}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const-string/jumbo v9, "port"

    nop

    nop

    const/4 v11, 0x0

    const/16 v6, 0x56

    invoke-interface {v8, v9, v11}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const-string/jumbo v9, "metodo"

    nop

    nop

    const/16 v6, 0x56

    invoke-interface {v8, v9, v11}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const-string/jumbo v9, "upayload"

    nop

    nop

    const/16 v6, 0x48

    invoke-interface {v8, v9, v11}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const-string/jumbo v9, "payload"

    nop

    nop

    const/16 v6, 0x3c

    invoke-interface {v8, v9, v10}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const-string/jumbo v9, "usnihost"

    nop

    nop

    const/16 v6, 0x48

    invoke-interface {v8, v9, v11}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const-string/jumbo v9, "snihost"

    nop

    nop

    const/16 v6, 0x3c

    invoke-interface {v8, v9, v10}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const-string/jumbo v9, "upayloadat"

    nop

    nop

    const/16 v6, 0x48

    invoke-interface {v8, v9, v11}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const-string/jumbo v9, "payloadat"

    nop

    nop

    const/16 v6, 0x3c

    invoke-interface {v8, v9, v10}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const-string/jumbo v9, "uprx"

    nop

    nop

    const/16 v6, 0x48

    invoke-interface {v8, v9, v11}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const-string/jumbo v9, "prxhost"

    nop

    nop

    const/16 v6, 0x3c

    invoke-interface {v8, v9, v10}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const-string/jumbo v9, "prxport"

    nop

    nop

    const/16 v6, 0x3c

    invoke-interface {v8, v9, v10}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v6, 0x6f

    invoke-interface {v8}, Landroid/content/SharedPreferences$Editor;->apply()V

    const v8, 0x7f090170

    const/16 v6, 0x41

    invoke-virtual {p0, v8}, Lra;->findViewById(I)Landroid/view/View;

    move-result-object v8

    const/4 v6, -0x6

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const v9, 0x7f130229

    const/16 v6, 0xb4

    invoke-virtual {p0, v9}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v9

    const/4 v6, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v11, -0x1

    const/16 v6, 0x1ae

    move v0, v6

    move-object v1, p0

    move-object v2, v9

    move-object v3, v10

    move-object v4, v8

    move v5, v11

    invoke-virtual/range {v1 .. v5}, Lcom/tlsvpn/tlstunnel/MainActivity;->n(Ljava/lang/String;Ljava/lang/String;Landroid/view/View;I)V

    const/16 v6, 0x5b

    new-instance v8, Landroid/content/Intent;

    nop

    const-string/jumbo v9, "restoreHome"

    nop

    nop

    const/16 v6, 0x62

    invoke-direct {v8, v9}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v6, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v9

    const/16 v6, 0x4a

    invoke-virtual {v9}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v9

    const/16 v6, 0x64

    invoke-virtual {v8, v9}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v8

    const/16 v6, 0x63

    invoke-virtual {p0, v8}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    return-void
.end method

.method public final n(Ljava/lang/String;Ljava/lang/String;Landroid/view/View;I)V
    .registers 22

    .prologue
    const/16 v6, 0x32e

    sget-object v8, Lj42;->E:[I

    nop

    const/4 v8, 0x0

    move-object v9, v8

    :cond_7
    move-object/from16 v0, p3

    instance-of v10, v0, Landroidx/coordinatorlayout/widget/CoordinatorLayout;

    if-eqz v10, :cond_10

    check-cast p3, Landroid/view/ViewGroup;

    goto :goto_41

    :cond_10
    move-object/from16 v0, p3

    instance-of v10, v0, Landroid/widget/FrameLayout;

    if-eqz v10, :cond_2a

    const/16 v6, 0xc31

    move-object/from16 v0, p3

    invoke-virtual {v0}, Landroid/view/View;->getId()I

    move-result v9

    const v10, 0x1020002

    if-ne v9, v10, :cond_26

    check-cast p3, Landroid/view/ViewGroup;

    goto :goto_41

    :cond_26
    move-object/from16 v9, p3

    check-cast v9, Landroid/view/ViewGroup;

    :cond_2a
    const/16 v6, 0xbfe

    move-object/from16 v0, p3

    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p3

    move-object/from16 v0, p3

    instance-of v10, v0, Landroid/view/View;

    if-eqz v10, :cond_3b

    check-cast p3, Landroid/view/View;

    goto :goto_3d

    :cond_3b
    move-object/from16 p3, v8

    :goto_3d
    if-nez p3, :cond_7

    move-object/from16 p3, v9

    :goto_41
    if-eqz p3, :cond_2e4

    const/16 v6, 0xee7

    move-object/from16 v0, p3

    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v9

    const/16 v6, 0x8f9

    invoke-static {v9}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object v10

    const/16 v6, 0x32e

    sget-object v11, Lj42;->E:[I

    nop

    const/16 v6, 0x7a7

    invoke-virtual {v9, v11}, Landroid/content/Context;->obtainStyledAttributes([I)Landroid/content/res/TypedArray;

    move-result-object v11

    const/4 v12, 0x0

    const/4 v13, -0x1

    const/16 v6, 0x2a5

    invoke-virtual {v11, v12, v13}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v14

    const/4 v15, 0x1

    const/16 v6, 0x2a5

    invoke-virtual {v11, v15, v13}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v16

    const/16 v6, 0xe78

    invoke-virtual {v11}, Landroid/content/res/TypedArray;->recycle()V

    if-eq v14, v13, :cond_7a

    move/from16 v0, v16

    if-eq v0, v13, :cond_7a

    const v11, 0x7f0c009c

    goto :goto_7d

    :cond_7a
    const v11, 0x7f0c0028

    :goto_7d
    const/16 v6, 0x107b

    move-object/from16 v0, p3

    invoke-virtual {v10, v11, v0, v12}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v10

    check-cast v10, Lcom/google/android/material/snackbar/SnackbarContentLayout;

    const/16 v6, 0x6cf

    new-instance v11, Lj42;

    nop

    const/16 v6, 0x1005

    move v0, v6

    move-object v1, v11

    move-object v2, v9

    move-object/from16 v3, p3

    move-object v4, v10

    move-object v5, v10

    invoke-direct/range {v1 .. v5}, Lj42;-><init>(Landroid/content/Context;Landroid/view/ViewGroup;Lcom/google/android/material/snackbar/SnackbarContentLayout;Lcom/google/android/material/snackbar/SnackbarContentLayout;)V

    const/16 v6, 0xf1f

    iget-object v6, v11, Lwi;->i:Lvi;

    move-object/16 p3, v6

    const/16 v6, 0x229

    move-object/from16 v0, p3

    invoke-virtual {v0, v12}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object p3

    check-cast p3, Lcom/google/android/material/snackbar/SnackbarContentLayout;

    const/16 v6, 0x6b8

    move-object/from16 v0, p3

    invoke-virtual {v0}, Lcom/google/android/material/snackbar/SnackbarContentLayout;->getMessageView()Landroid/widget/TextView;

    move-result-object p3

    const/16 v6, 0x8a

    move-object/from16 v0, p3

    move-object/from16 v1, p1

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v6, 0x582

    move/from16 v0, p4

    iput v0, v11, Lwi;->k:I

    const/16 v6, 0x51

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result p1

    const p3, -0x359f4d01

    const p4, 0x7f13023e

    move/from16 v0, p1

    move/from16 v1, p3

    if-eq v0, v1, :cond_180

    const p3, 0x1b0fa

    move/from16 v0, p1

    move/from16 v1, p3

    if-eq v0, v1, :cond_113

    const p3, 0x6873f91

    move/from16 v0, p1

    move/from16 v1, p3

    if-eq v0, v1, :cond_e8

    goto/16 :goto_1a8

    :cond_e8
    const-string/jumbo p1, "slist"

    nop

    nop

    const/4 v6, -0x7

    move-object/from16 v0, p2

    move-object/from16 v1, p1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_fa

    goto/16 :goto_1a8

    :cond_fa
    const/16 v6, 0x525

    new-instance p1, Lc51;

    nop

    const/16 v6, 0x30c

    move-object/from16 v0, p1

    move-object/from16 v1, p0

    invoke-direct {v0, v1, v12}, Lc51;-><init>(Lcom/tlsvpn/tlstunnel/MainActivity;I)V

    const/16 v6, 0x23a

    move/from16 v0, p4

    move-object/from16 v1, p1

    invoke-virtual {v11, v0, v1}, Lj42;->i(ILandroid/view/View$OnClickListener;)V

    goto/16 :goto_1a8

    :cond_113
    const-string/jumbo p1, "pdn"

    nop

    nop

    const/4 v6, -0x7

    move-object/from16 v0, p2

    move-object/from16 v1, p1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_125

    goto/16 :goto_1a8

    :cond_125
    const/16 v6, 0x5b

    new-instance p1, Landroid/content/Intent;

    nop

    const-string/jumbo p2, "android.settings.APPLICATION_DETAILS_SETTINGS"

    nop

    nop

    const/16 v6, 0x62

    move-object/from16 v0, p1

    move-object/from16 v1, p2

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string/jumbo p2, "package"

    nop

    nop

    const/16 v6, 0x4a

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p3

    const/16 v6, 0xa74

    move-object/from16 v0, p2

    move-object/from16 v1, p3

    invoke-static {v0, v1, v8}, Landroid/net/Uri;->fromParts(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p2

    const/16 v6, 0x11c6

    move-object/from16 v0, p1

    move-object/from16 v1, p2

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    const/high16 p2, 0x10000000

    const/16 v6, 0x59

    move-object/from16 v0, p1

    move/from16 v1, p2

    invoke-virtual {v0, v1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/16 v6, 0xf56

    new-instance p2, Lgd0;

    nop

    const/16 v6, 0x708

    move-object/from16 v0, p2

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    invoke-direct {v0, v15, v1, v2}, Lgd0;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    const p1, 0x7f130240

    const/16 v6, 0x23a

    move/from16 v0, p1

    move-object/from16 v1, p2

    invoke-virtual {v11, v0, v1}, Lj42;->i(ILandroid/view/View$OnClickListener;)V

    goto :goto_1a8

    :cond_180
    const-string/jumbo p1, "slistp"

    nop

    nop

    const/4 v6, -0x7

    move-object/from16 v0, p2

    move-object/from16 v1, p1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_191

    goto :goto_1a8

    :cond_191
    const/16 v6, 0x525

    new-instance p1, Lc51;

    nop

    const/16 v6, 0x30c

    move-object/from16 v0, p1

    move-object/from16 v1, p0

    invoke-direct {v0, v1, v15}, Lc51;-><init>(Lcom/tlsvpn/tlstunnel/MainActivity;I)V

    const/16 v6, 0x23a

    move/from16 v0, p4

    move-object/from16 v1, p1

    invoke-virtual {v11, v0, v1}, Lj42;->i(ILandroid/view/View$OnClickListener;)V

    :goto_1a8
    const/16 v6, 0x1f9

    move-object/from16 v0, p0

    invoke-virtual {v0}, Lcom/tlsvpn/tlstunnel/MainActivity;->h()Lcom/google/android/material/bottomnavigation/BottomNavigationView;

    move-result-object p0

    const/16 v6, 0xb79

    iget-object v6, v11, Lwi;->l:Lti;

    move-object/16 p1, v6

    if-eqz p1, :cond_1c0

    const/16 v6, 0x66d

    move-object/from16 v0, p1

    invoke-virtual {v0}, Lti;->a()V

    :cond_1c0
    const/16 v6, 0xd66

    new-instance p1, Lti;

    nop

    const/16 v6, 0x89f

    move-object/from16 v0, p1

    move-object/from16 v1, p0

    invoke-direct {v0, v11, v1}, Lti;-><init>(Lj42;Lcom/google/android/material/bottomnavigation/BottomNavigationView;)V

    const/16 v6, 0xc9f

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/view/View;->isAttachedToWindow()Z

    move-result p2

    if-eqz p2, :cond_1e9

    const/16 v6, 0x8c2

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    move-result-object p2

    const/16 v6, 0x766

    move-object/from16 v0, p2

    move-object/from16 v1, p1

    invoke-virtual {v0, v1}, Landroid/view/ViewTreeObserver;->addOnGlobalLayoutListener(Landroid/view/ViewTreeObserver$OnGlobalLayoutListener;)V

    :cond_1e9
    const/16 v6, 0x8a0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual {v0, v1}, Landroid/view/View;->addOnAttachStateChangeListener(Landroid/view/View$OnAttachStateChangeListener;)V

    const/16 v6, 0x1070

    move-object/from16 v0, p1

    iput-object v0, v11, Lwi;->l:Lti;

    const/16 v6, 0x948

    invoke-static {}, Lx5;->m()Lx5;

    move-result-object p0

    const/16 v6, 0xb78

    invoke-virtual {v11}, Lj42;->h()I

    move-result p1

    const/16 v6, 0x9a7

    iget-object v6, v11, Lwi;->v:Lsi;

    move-object/16 p2, v6

    const/16 v6, 0x3a9

    move-object/from16 v0, p0

    iget-object v6, v0, Lx5;->c:Ljava/lang/Object;

    move-object/16 p3, v6

    monitor-enter p3

    :try_start_215
    const/16 v6, 0xf16

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    invoke-virtual {v0, v1}, Lx5;->p(Lsi;)Z

    move-result p4

    if-eqz p4, :cond_261

    const/16 v6, 0x1e3

    move-object/from16 v0, p0

    iget-object v6, v0, Lx5;->e:Ljava/lang/Object;

    move-object/16 p2, v6

    check-cast p2, Ll42;

    const/16 v6, 0x4cd

    move-object/from16 v0, p2

    move/from16 v1, p1

    iput v1, v0, Ll42;->b:I

    const/16 v6, 0x916

    move-object/from16 v0, p0

    iget-object v6, v0, Lx5;->d:Ljava/lang/Object;

    move-object/16 p1, v6

    check-cast p1, Landroid/os/Handler;

    const/16 v6, 0x53f

    move-object/from16 v0, p1

    move-object/from16 v1, p2

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    const/16 v6, 0x1e3

    move-object/from16 v0, p0

    iget-object v6, v0, Lx5;->e:Ljava/lang/Object;

    move-object/16 p1, v6

    check-cast p1, Ll42;

    const/16 v6, 0xa52

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual {v0, v1}, Lx5;->x(Ll42;)V

    monitor-exit p3

    return-void

    :catchall_25e
    move-exception p0

    goto/16 :goto_2e2

    :cond_261
    const/16 v6, 0x385

    move-object/from16 v0, p0

    iget-object v6, v0, Lx5;->b:Ljava/lang/Object;

    move-object/16 p4, v6

    check-cast p4, Ll42;

    if-eqz p4, :cond_286

    const/16 v6, 0xc62

    move-object/from16 v0, p4

    iget-object v6, v0, Ll42;->a:Ljava/lang/ref/WeakReference;

    move-object/16 p4, v6

    const/16 v6, 0xa29

    move-object/from16 v0, p4

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object p4

    move-object/from16 v0, p4

    move-object/from16 v1, p2

    if-ne v0, v1, :cond_286

    move v12, v15

    :cond_286
    if-eqz v12, :cond_29c

    const/16 v6, 0x385

    move-object/from16 v0, p0

    iget-object v6, v0, Lx5;->b:Ljava/lang/Object;

    move-object/16 p2, v6

    check-cast p2, Ll42;

    const/16 v6, 0x4cd

    move-object/from16 v0, p2

    move/from16 v1, p1

    iput v1, v0, Ll42;->b:I

    goto :goto_2b4

    :cond_29c
    const/16 v6, 0x7bc

    new-instance p4, Ll42;

    nop

    const/16 v6, 0x10b3

    move-object/from16 v0, p4

    move/from16 v1, p1

    move-object/from16 v2, p2

    invoke-direct {v0, v1, v2}, Ll42;-><init>(ILsi;)V

    const/16 v6, 0xdd0

    move-object/from16 v0, p0

    move-object/from16 v1, p4

    iput-object v1, v0, Lx5;->b:Ljava/lang/Object;

    :goto_2b4
    const/16 v6, 0x1e3

    move-object/from16 v0, p0

    iget-object v6, v0, Lx5;->e:Ljava/lang/Object;

    move-object/16 p1, v6

    check-cast p1, Ll42;

    if-eqz p1, :cond_2d3

    const/16 p2, 0x4

    const/16 v6, 0xc7b

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p2

    invoke-virtual {v0, v1, v2}, Lx5;->g(Ll42;I)Z

    move-result p1

    if-eqz p1, :cond_2d3

    monitor-exit p3

    return-void

    :cond_2d3
    const/16 v6, 0xf2a

    move-object/from16 v0, p0

    iput-object v8, v0, Lx5;->e:Ljava/lang/Object;

    const/16 v6, 0xf94

    move-object/from16 v0, p0

    invoke-virtual {v0}, Lx5;->D()V

    monitor-exit p3

    return-void

    :goto_2e2
    monitor-exit p3
    :try_end_2e3
    .catchall {:try_start_215 .. :try_end_2e3} :catchall_25e

    throw p0

    :cond_2e4
    const-string/jumbo p0, "No suitable parent found from the given view. Please provide a valid view."

    nop

    nop

    const/16 v6, 0x52e

    move-object/from16 v0, p0

    invoke-static {v0}, Lz6;->s(Ljava/lang/String;)V

    return-void
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .registers 33

    .prologue
    move-object/from16 v11, p0

    const/16 v9, 0x1fc

    sget v12, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 v13, 0x1f

    if-lt v12, v13, :cond_16

    const/16 v9, 0x10be

    new-instance v13, Lc52;

    nop

    const/16 v9, 0x612

    invoke-direct {v13, v11}, Lc52;-><init>(Lcom/tlsvpn/tlstunnel/MainActivity;)V

    goto :goto_20

    :cond_16
    const/16 v9, 0x24c

    new-instance v13, Loj0;

    nop

    const/16 v9, 0x246

    invoke-direct {v13, v11}, Loj0;-><init>(Ljava/lang/Object;)V

    :goto_20
    const/16 v9, 0x7d4

    invoke-virtual {v13}, Loj0;->l()V

    const/16 v9, 0xddd

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-super {v0, v1}, Landroidx/fragment/app/l;->onCreate(Landroid/os/Bundle;)V

    const/16 v9, 0x86

    invoke-virtual {v11}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v13

    const/4 v14, 0x0

    const/16 v9, 0xb4f

    invoke-static {v13, v14}, Lnp3;->f0(Landroid/view/Window;Z)V

    const/16 v9, 0x3d1

    sget v13, Lk80;->a:I

    nop

    const/16 v9, 0x4e7

    new-instance v16, Lc92;

    nop

    const/16 v9, 0xb31

    sget-object v13, Lb92;->i:Lb92;

    nop

    const/16 v9, 0x410

    move-object/from16 v0, v16

    invoke-direct {v0, v14, v14, v13}, Lc92;-><init>(IILbk0;)V

    const/16 v9, 0x3d1

    sget v15, Lk80;->a:I

    nop

    const/16 v9, 0xe3f

    sget v17, Lk80;->b:I

    nop

    const/16 v9, 0x4e7

    new-instance v18, Lc92;

    nop

    const/16 v9, 0x410

    move-object/from16 v0, v18

    move/from16 v1, v17

    invoke-direct {v0, v15, v1, v13}, Lc92;-><init>(IILbk0;)V

    const/16 v9, 0x86

    invoke-virtual {v11}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v15

    const/16 v9, 0x213

    invoke-virtual {v15}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v19

    const/4 v9, -0x6

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v9, 0x305

    move-object/from16 v0, v19

    invoke-virtual {v0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v15

    const/4 v9, -0x6

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v9, 0x457

    invoke-virtual {v13, v15}, Lb92;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Ljava/lang/Boolean;

    const/16 v9, 0x205

    invoke-virtual {v15}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v20

    const/16 v9, 0x305

    move-object/from16 v0, v19

    invoke-virtual {v0}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    move-result-object v15

    const/4 v9, -0x6

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v9, 0x457

    invoke-virtual {v13, v15}, Lb92;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/Boolean;

    const/16 v9, 0x205

    invoke-virtual {v13}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v21

    const/16 v13, 0x1d

    const/16 v22, 0x1a

    if-lt v12, v13, :cond_c2

    const/16 v9, 0xc73

    new-instance v13, Ln80;

    nop

    const/16 v9, 0x21a

    invoke-direct {v13}, Ljava/lang/Object;-><init>()V

    :goto_be
    move-object v15, v13

    move-object/from16 v17, v18

    goto :goto_dc

    :cond_c2
    move/from16 v0, v22

    if-lt v12, v0, :cond_d1

    const/16 v9, 0x1222

    new-instance v13, Lm80;

    nop

    const/16 v9, 0x21a

    invoke-direct {v13}, Ljava/lang/Object;-><init>()V

    goto :goto_be

    :cond_d1
    const/16 v9, 0x1003

    new-instance v13, Ll80;

    nop

    const/16 v9, 0x21a

    invoke-direct {v13}, Ljava/lang/Object;-><init>()V

    goto :goto_be

    :goto_dc
    const/16 v9, 0x86

    invoke-virtual {v11}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v18

    const/4 v9, -0x6

    move-object/from16 v0, v18

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v9, 0xa36

    move v0, v9

    move-object v1, v15

    move-object/from16 v2, v16

    move-object/from16 v3, v17

    move-object/from16 v4, v18

    move-object/from16 v5, v19

    move/from16 v6, v20

    move/from16 v7, v21

    invoke-interface/range {v1 .. v7}, Lo80;->a(Lc92;Lc92;Landroid/view/Window;Landroid/view/View;ZZ)V

    const v13, 0x7f0c001c

    const/16 v9, 0x1157

    invoke-virtual {v11, v13}, Lra;->setContentView(I)V

    const/16 v9, 0x95

    invoke-virtual {v11}, Lcom/tlsvpn/tlstunnel/MainActivity;->j()Landroid/content/SharedPreferences;

    move-result-object v13

    const-string/jumbo v15, "firstopen"

    nop

    nop

    const/16 v16, 0x1

    const/16 v9, 0x77

    move/from16 v0, v16

    invoke-interface {v13, v15, v0}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v13

    const/16 v9, 0x10b8

    iput-boolean v13, v11, Lcom/tlsvpn/tlstunnel/MainActivity;->j:Z

    const/16 v9, 0x95

    invoke-virtual {v11}, Lcom/tlsvpn/tlstunnel/MainActivity;->j()Landroid/content/SharedPreferences;

    move-result-object v13

    const-string/jumbo v17, "language"

    nop

    nop

    const-string/jumbo v18, "system"

    nop

    nop

    const/16 v9, 0x2e

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-interface {v13, v0, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    const/16 v9, 0x84

    move-object/from16 v0, v18

    invoke-static {v13, v0}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v17

    if-eqz v17, :cond_146

    const/16 v9, 0x39b

    sget-object v13, Lv31;->b:Lv31;

    nop

    goto :goto_14c

    :cond_146
    const/16 v9, 0x11a3

    invoke-static {v13}, Lv31;->a(Ljava/lang/String;)Lv31;

    move-result-object v13

    :goto_14c
    const/16 v9, 0x474

    invoke-static {v13}, Leb;->l(Lv31;)V

    const/16 v9, 0x86

    invoke-virtual {v11}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v13

    const/16 v9, 0x86

    invoke-virtual {v11}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v17

    const/16 v9, 0x213

    move-object/from16 v0, v17

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v17

    const/16 v9, 0x24c

    new-instance v18, Loj0;

    nop

    const/16 v9, 0x422

    move-object/from16 v0, v18

    move-object/from16 v1, v17

    invoke-direct {v0, v1}, Loj0;-><init>(Landroid/view/View;)V

    const/16 v9, 0x1fc

    sget v17, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 v19, 0x1e

    const/16 v20, 0x23

    move/from16 v0, v17

    move/from16 v1, v20

    if-lt v0, v1, :cond_191

    const/16 v9, 0x3f7

    new-instance v17, Ltp2;

    nop

    const/16 v9, 0x10f

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-direct {v0, v13, v1}, Lsp2;-><init>(Landroid/view/Window;Loj0;)V

    goto :goto_1c9

    :cond_191
    move/from16 v0, v17

    move/from16 v1, v19

    if-lt v0, v1, :cond_1a6

    const/16 v9, 0x421

    new-instance v17, Lsp2;

    nop

    const/16 v9, 0x10f

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-direct {v0, v13, v1}, Lsp2;-><init>(Landroid/view/Window;Loj0;)V

    goto :goto_1c9

    :cond_1a6
    move/from16 v0, v17

    move/from16 v1, v22

    if-lt v0, v1, :cond_1bb

    const/16 v9, 0x461

    new-instance v17, Lrp2;

    nop

    const/16 v9, 0x113

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-direct {v0, v13, v1}, Lqp2;-><init>(Landroid/view/Window;Loj0;)V

    goto :goto_1c9

    :cond_1bb
    const/16 v9, 0x32d

    new-instance v17, Lqp2;

    nop

    const/16 v9, 0x113

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-direct {v0, v13, v1}, Lqp2;-><init>(Landroid/view/Window;Loj0;)V

    :goto_1c9
    const/16 v9, 0x112e

    move-object/from16 v0, v17

    invoke-virtual {v0, v14}, Llk;->D(Z)V

    const/16 v9, 0x86

    invoke-virtual {v11}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v13

    const/16 v9, 0x86

    invoke-virtual {v11}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v17

    const/16 v9, 0x213

    move-object/from16 v0, v17

    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;

    move-result-object v17

    const/16 v9, 0x24c

    new-instance v18, Loj0;

    nop

    const/16 v9, 0x422

    move-object/from16 v0, v18

    move-object/from16 v1, v17

    invoke-direct {v0, v1}, Loj0;-><init>(Landroid/view/View;)V

    const/16 v9, 0x1fc

    sget v17, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    move/from16 v0, v17

    move/from16 v1, v20

    if-lt v0, v1, :cond_20c

    const/16 v9, 0x3f7

    new-instance v17, Ltp2;

    nop

    const/16 v9, 0x10f

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-direct {v0, v13, v1}, Lsp2;-><init>(Landroid/view/Window;Loj0;)V

    goto :goto_244

    :cond_20c
    move/from16 v0, v17

    move/from16 v1, v19

    if-lt v0, v1, :cond_221

    const/16 v9, 0x421

    new-instance v17, Lsp2;

    nop

    const/16 v9, 0x10f

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-direct {v0, v13, v1}, Lsp2;-><init>(Landroid/view/Window;Loj0;)V

    goto :goto_244

    :cond_221
    move/from16 v0, v17

    move/from16 v1, v22

    if-lt v0, v1, :cond_236

    const/16 v9, 0x461

    new-instance v17, Lrp2;

    nop

    const/16 v9, 0x113

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-direct {v0, v13, v1}, Lqp2;-><init>(Landroid/view/Window;Loj0;)V

    goto :goto_244

    :cond_236
    const/16 v9, 0x32d

    new-instance v17, Lqp2;

    nop

    const/16 v9, 0x113

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-direct {v0, v13, v1}, Lqp2;-><init>(Landroid/view/Window;Loj0;)V

    :goto_244
    const/16 v9, 0x826

    move-object/from16 v0, v17

    invoke-virtual {v0, v14}, Llk;->E(Z)V

    const v13, 0x7f090170

    const/16 v9, 0x41

    invoke-virtual {v11, v13}, Lra;->findViewById(I)Landroid/view/View;

    move-result-object v13

    const/4 v9, -0x6

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v13, Landroidx/constraintlayout/widget/ConstraintLayout;

    const/16 v9, 0x8de

    new-instance v17, Lvh0;

    nop

    const/16 v18, 0x1c

    const/16 v9, 0x11ff

    move-object/from16 v0, v17

    move/from16 v1, v18

    invoke-direct {v0, v1}, Lvh0;-><init>(I)V

    const/16 v9, 0xadd

    sget-object v18, Lek2;->a:Ljava/util/WeakHashMap;

    nop

    const/16 v9, 0x61f

    move-object/from16 v0, v17

    invoke-static {v13, v0}, Lwj2;->k(Landroid/view/View;Lih1;)V

    const/16 v9, 0xb7a

    sget-object v13, Lmi2;->b:Ljava/util/concurrent/CopyOnWriteArrayList;

    nop

    const/16 v9, 0x105d

    invoke-virtual {v13}, Ljava/util/concurrent/CopyOnWriteArrayList;->isEmpty()Z

    move-result v17

    const/16 v18, 0x0

    if-eqz v17, :cond_402

    const/4 v9, -0x3

    new-instance v17, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v19, "["

    nop

    nop

    const/16 v9, 0x97

    move-object/from16 v0, v17

    move-object/from16 v1, v19

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v9, 0x18e

    invoke-static {}, Lcom/tlsvpn/tlstunnel/MainActivity;->l()Ljava/lang/String;

    move-result-object v20

    const/4 v9, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v20

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v20, "] TLS Tunnel "

    nop

    nop

    const/4 v9, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v20

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v20, 0x7f130270

    const/16 v9, 0xb4

    move/from16 v0, v20

    invoke-virtual {v11, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v20

    const/4 v9, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v20

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, -0x2

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v17

    const/16 v9, 0x14e

    move-object/from16 v0, v17

    invoke-static {v0}, Landroid/text/SpannedString;->valueOf(Ljava/lang/CharSequence;)Landroid/text/SpannedString;

    move-result-object v17

    const/16 v9, 0x146

    move-object/from16 v0, v17

    invoke-virtual {v13, v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    const/4 v9, -0x3

    new-instance v17, Ljava/lang/StringBuilder;

    nop

    const/16 v9, 0x97

    move-object/from16 v0, v17

    move-object/from16 v1, v19

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v9, 0x18e

    invoke-static {}, Lcom/tlsvpn/tlstunnel/MainActivity;->l()Ljava/lang/String;

    move-result-object v20

    const/4 v9, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v20

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v20, "] "

    nop

    nop

    const/4 v9, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v20

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v9, 0x5a

    sget-object v21, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->a:Lcom/tlsvpn/tlstunnel/utils/SocketOps;

    nop

    const/16 v9, 0xcad

    move-object/from16 v0, v21

    invoke-virtual {v0}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->umI()Ljava/lang/String;

    move-result-object v22

    const/4 v9, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v22

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, -0x2

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v17

    const/16 v9, 0x14e

    move-object/from16 v0, v17

    invoke-static {v0}, Landroid/text/SpannedString;->valueOf(Ljava/lang/CharSequence;)Landroid/text/SpannedString;

    move-result-object v17

    const/16 v9, 0x146

    move-object/from16 v0, v17

    invoke-virtual {v13, v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    const/4 v9, -0x3

    new-instance v17, Ljava/lang/StringBuilder;

    nop

    const/16 v9, 0x97

    move-object/from16 v0, v17

    move-object/from16 v1, v19

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v9, 0x18e

    invoke-static {}, Lcom/tlsvpn/tlstunnel/MainActivity;->l()Ljava/lang/String;

    move-result-object v22

    const/4 v9, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v22

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v22, "] Zstandard v"

    nop

    nop

    const/4 v9, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v22

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v9, 0x6ab

    move-object/from16 v0, v21

    invoke-virtual {v0}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->C()Ljava/lang/String;

    move-result-object v21

    const/4 v9, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, -0x2

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v17

    const/16 v9, 0x14e

    move-object/from16 v0, v17

    invoke-static {v0}, Landroid/text/SpannedString;->valueOf(Ljava/lang/CharSequence;)Landroid/text/SpannedString;

    move-result-object v17

    const/16 v9, 0x146

    move-object/from16 v0, v17

    invoke-virtual {v13, v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    const/16 v9, 0x132

    sget-object v17, Lh50;->a:Li20;

    nop

    const/16 v9, 0x126

    sget-object v17, Lx10;->c:Lx10;

    nop

    const/16 v9, 0xf43

    move-object/from16 v0, v17

    invoke-static {v0}, Lw53;->a(Lly;)Lsx;

    move-result-object v17

    const/16 v9, 0x16

    new-instance v21, Lqd;

    nop

    const/16 v22, 0x6

    const/16 v9, 0x17

    move-object/from16 v0, v21

    move-object/from16 v1, v18

    move/from16 v2, v22

    invoke-direct {v0, v11, v1, v2}, Lqd;-><init>(Ljava/lang/Object;Lvx;I)V

    const/16 v22, 0x3

    const/16 v9, 0xb3

    move v0, v9

    move-object/from16 v1, v17

    move-object/from16 v2, v18

    move-object/from16 v3, v18

    move-object/from16 v4, v21

    move/from16 v5, v22

    invoke-static/range {v1 .. v5}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    const-string/jumbo v17, "http.agent"

    nop

    nop

    const/16 v9, 0x77d

    move-object/from16 v0, v17

    invoke-static {v0}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v17

    if-eqz v17, :cond_402

    const/4 v9, -0x3

    new-instance v21, Ljava/lang/StringBuilder;

    nop

    const/16 v9, 0x97

    move-object/from16 v0, v21

    move-object/from16 v1, v19

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v9, 0x18e

    invoke-static {}, Lcom/tlsvpn/tlstunnel/MainActivity;->l()Ljava/lang/String;

    move-result-object v19

    const/4 v9, 0x0

    move-object/from16 v0, v21

    move-object/from16 v1, v19

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    move-object/from16 v0, v21

    move-object/from16 v1, v20

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    move-object/from16 v0, v21

    move-object/from16 v1, v17

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, -0x2

    move-object/from16 v0, v21

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v17

    const/16 v9, 0x14e

    move-object/from16 v0, v17

    invoke-static {v0}, Landroid/text/SpannedString;->valueOf(Ljava/lang/CharSequence;)Landroid/text/SpannedString;

    move-result-object v17

    const/16 v9, 0x146

    move-object/from16 v0, v17

    invoke-virtual {v13, v0}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    :cond_402
    const/16 v9, 0x95

    invoke-virtual {v11}, Lcom/tlsvpn/tlstunnel/MainActivity;->j()Landroid/content/SharedPreferences;

    move-result-object v13

    const-string/jumbo v17, "tlsvpnVersion"

    nop

    nop

    const/16 v9, 0xb0

    move-object/from16 v0, v17

    invoke-interface {v13, v0, v14}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v13

    const v19, 0x7f09016f

    const/16 v9, 0x41

    move/from16 v0, v19

    invoke-virtual {v11, v0}, Lra;->findViewById(I)Landroid/view/View;

    move-result-object v19

    const/4 v9, -0x6

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v19, Lcom/google/android/material/bottomnavigation/BottomNavigationView;

    const/16 v9, 0xdfd

    move-object/from16 v0, v19

    iput-object v0, v11, Lcom/tlsvpn/tlstunnel/MainActivity;->i:Lcom/google/android/material/bottomnavigation/BottomNavigationView;

    const/16 v9, 0x2ff

    invoke-virtual {v11}, Landroidx/fragment/app/l;->c()Lfi0;

    move-result-object v19

    const v20, 0x7f090279

    const/16 v9, 0xf63

    move-object/from16 v0, v19

    move/from16 v1, v20

    invoke-virtual {v0, v1}, Landroidx/fragment/app/p;->B(I)Landroidx/fragment/app/Fragment;

    move-result-object v19

    const/4 v9, -0x6

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v19, Landroidx/navigation/fragment/NavHostFragment;

    if-nez p1, :cond_4c3

    const/16 v9, 0x25c

    move-object/from16 v0, v19

    invoke-virtual {v0}, Landroidx/navigation/fragment/NavHostFragment;->b()Lzc1;

    move-result-object v20

    const/16 v9, 0xaf7

    move-object/from16 v0, v20

    iget-object v9, v0, Lzc1;->h:Lw82;

    move-object/16 v20, v9

    const/16 v9, 0x177

    move-object/from16 v0, v20

    invoke-virtual {v0}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v20

    check-cast v20, Lad1;

    const/high16 v21, 0x7f100000

    const/16 v9, 0x506

    move-object/from16 v0, v20

    move/from16 v1, v21

    invoke-virtual {v0, v1}, Lad1;->b(I)Lwc1;

    move-result-object v20

    const/16 v9, 0x234

    iget-boolean v9, v11, Lcom/tlsvpn/tlstunnel/MainActivity;->j:Z

    move/16 v21, v9

    if-nez v21, :cond_486

    const/16 v21, 0x1cb

    move/from16 v0, v21

    if-ge v13, v0, :cond_482

    goto :goto_486

    :cond_482
    const v21, 0x7f090130

    goto :goto_489

    :cond_486
    :goto_486
    const v21, 0x7f09000e

    :goto_489
    const/16 v9, 0x1175

    move-object/from16 v0, v20

    iget-object v9, v0, Lwc1;->g:Lfc1;

    move-object/16 v22, v9

    const/16 v9, 0xe32

    move-object/from16 v0, v22

    move/from16 v1, v21

    invoke-virtual {v0, v1}, Lfc1;->g(I)V

    const/16 v9, 0x25c

    move-object/from16 v0, v19

    invoke-virtual {v0}, Landroidx/navigation/fragment/NavHostFragment;->b()Lzc1;

    move-result-object v21

    const/4 v9, -0x6

    move-object/from16 v0, v21

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v9, 0x4b9

    move-object/from16 v0, v21

    iget-object v9, v0, Lzc1;->b:Lmc1;

    move-object/16 v21, v9

    const/4 v9, -0x6

    move-object/from16 v0, v21

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v9, 0x35b

    move-object/from16 v0, v21

    move-object/from16 v1, v20

    move-object/from16 v2, v18

    invoke-virtual {v0, v1, v2}, Lmc1;->p(Lwc1;Landroid/os/Bundle;)V

    :cond_4c3
    const/16 v9, 0x1f9

    invoke-virtual {v11}, Lcom/tlsvpn/tlstunnel/MainActivity;->h()Lcom/google/android/material/bottomnavigation/BottomNavigationView;

    move-result-object v20

    const/16 v9, 0x25c

    move-object/from16 v0, v19

    invoke-virtual {v0}, Landroidx/navigation/fragment/NavHostFragment;->b()Lzc1;

    move-result-object v21

    const/4 v9, -0x6

    move-object/from16 v0, v21

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v9, 0x50f

    new-instance v22, Lah;

    nop

    const/16 v23, 0x11

    const/16 v9, 0x3bf

    move-object/from16 v0, v22

    move/from16 v1, v23

    move-object/from16 v2, v21

    invoke-direct {v0, v1, v2}, Lah;-><init>(ILjava/lang/Object;)V

    const/16 v9, 0x2b2

    move-object/from16 v0, v20

    move-object/from16 v1, v22

    invoke-virtual {v0, v1}, Lyd1;->setOnItemSelectedListener(Lwd1;)V

    const/16 v9, 0x750

    new-instance v22, Ljava/lang/ref/WeakReference;

    nop

    const/16 v9, 0x922

    move-object/from16 v0, v22

    move-object/from16 v1, v20

    invoke-direct {v0, v1}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    const/16 v9, 0xdeb

    new-instance v20, Lpe1;

    nop

    const/16 v9, 0xd17

    move-object/from16 v0, v20

    move-object/from16 v1, v22

    move-object/from16 v2, v21

    invoke-direct {v0, v1, v2}, Lpe1;-><init>(Ljava/lang/ref/WeakReference;Lzc1;)V

    const/16 v9, 0x4b9

    move-object/from16 v0, v21

    iget-object v9, v0, Lzc1;->b:Lmc1;

    move-object/16 v21, v9

    const/4 v9, -0x6

    move-object/from16 v0, v21

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v9, 0xdc3

    move-object/from16 v0, v21

    iget-object v9, v0, Lmc1;->o:Ljava/util/ArrayList;

    move-object/16 v22, v9

    const/16 v9, 0x174

    move-object/from16 v0, v22

    move-object/from16 v1, v20

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/16 v9, 0xb27

    move-object/from16 v0, v21

    iget-object v9, v0, Lmc1;->f:Lme;

    move-object/16 v22, v9

    const/16 v9, 0x927

    move-object/from16 v0, v22

    invoke-virtual {v0}, Lme;->isEmpty()Z

    move-result v23

    if-nez v23, :cond_57b

    const/16 v9, 0x902

    move-object/from16 v0, v22

    invoke-virtual {v0}, Lme;->last()Ljava/lang/Object;

    move-result-object v22

    check-cast v22, Lbc1;

    const/16 v9, 0xa9f

    move-object/from16 v0, v21

    iget-object v9, v0, Lmc1;->a:Lzc1;

    move-object/16 v21, v9

    const/16 v9, 0xa38

    move-object/from16 v0, v22

    iget-object v9, v0, Lbc1;->b:Luc1;

    move-object/16 v23, v9

    const/16 v9, 0xc5c

    move-object/from16 v0, v22

    iget-object v9, v0, Lbc1;->h:Ldc1;

    move-object/16 v22, v9

    const/16 v9, 0xa3d

    move-object/from16 v0, v22

    invoke-virtual {v0}, Ldc1;->a()Landroid/os/Bundle;

    const/16 v9, 0x65b

    move-object/from16 v0, v20

    move-object/from16 v1, v21

    move-object/from16 v2, v23

    invoke-virtual {v0, v1, v2}, Lpe1;->a(Lzc1;Luc1;)V

    :cond_57b
    const/16 v9, 0x1f9

    invoke-virtual {v11}, Lcom/tlsvpn/tlstunnel/MainActivity;->h()Lcom/google/android/material/bottomnavigation/BottomNavigationView;

    move-result-object v20

    const/16 v9, 0x108b

    new-instance v21, Lx3;

    nop

    const/16 v22, 0x8

    const/16 v9, 0xf34

    move-object/from16 v0, v21

    move/from16 v1, v22

    move-object/from16 v2, v19

    invoke-direct {v0, v1, v2, v11}, Lx3;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    const/16 v9, 0x2b2

    move-object/from16 v0, v20

    move-object/from16 v1, v21

    invoke-virtual {v0, v1}, Lyd1;->setOnItemSelectedListener(Lwd1;)V

    const/16 v9, 0x1f9

    invoke-virtual {v11}, Lcom/tlsvpn/tlstunnel/MainActivity;->h()Lcom/google/android/material/bottomnavigation/BottomNavigationView;

    move-result-object v19

    const v20, 0x7f09016c

    const/16 v9, 0x5b9

    move-object/from16 v0, v19

    move/from16 v1, v20

    invoke-virtual {v0, v1}, Lyd1;->a(I)Ljh;

    move-result-object v19

    const/16 v9, 0x4d0

    sget v20, Lmi2;->c:I

    nop

    if-lez v20, :cond_5b9

    move/from16 v20, v16

    goto :goto_5bb

    :cond_5b9
    move/from16 v20, v14

    :goto_5bb
    const/16 v9, 0xb65

    move-object/from16 v0, v19

    move/from16 v1, v20

    invoke-virtual {v0, v1}, Ljh;->j(Z)V

    const/16 v9, 0x4d0

    sget v20, Lmi2;->c:I

    nop

    const/16 v9, 0x5cb

    move-object/from16 v0, v19

    move/from16 v1, v20

    invoke-virtual {v0, v1}, Ljh;->i(I)V

    const/16 v19, 0x126

    const/16 v20, 0x1f2

    move/from16 v0, v19

    if-lt v13, v0, :cond_5de

    move/from16 v0, v20

    if-le v13, v0, :cond_5f8

    :cond_5de
    const/16 v9, 0x95

    invoke-virtual {v11}, Lcom/tlsvpn/tlstunnel/MainActivity;->j()Landroid/content/SharedPreferences;

    move-result-object v13

    const/4 v9, -0x6

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v9, 0x7a

    invoke-interface {v13}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v13

    const/16 v9, 0xb45

    invoke-interface {v13}, Landroid/content/SharedPreferences$Editor;->clear()Landroid/content/SharedPreferences$Editor;

    const/16 v9, 0x6f

    invoke-interface {v13}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_5f8
    const/16 v9, 0x95

    invoke-virtual {v11}, Lcom/tlsvpn/tlstunnel/MainActivity;->j()Landroid/content/SharedPreferences;

    move-result-object v13

    const/4 v9, -0x6

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v9, 0x7a

    invoke-interface {v13}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v13

    const/16 v9, 0x56

    move-object/from16 v0, v17

    move/from16 v1, v20

    invoke-interface {v13, v0, v1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/16 v9, 0x6f

    invoke-interface {v13}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/16 v9, 0xa70

    invoke-static {v11}, Lcom/google/firebase/analytics/FirebaseAnalytics;->getInstance(Landroid/content/Context;)Lcom/google/firebase/analytics/FirebaseAnalytics;

    move-result-object v13

    const/4 v9, -0x6

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v9, 0xaa8

    iput-object v13, v11, Lcom/tlsvpn/tlstunnel/MainActivity;->h:Lcom/google/firebase/analytics/FirebaseAnalytics;

    const/16 v9, 0x7ff

    new-instance v13, Ljava/util/EnumMap;

    nop

    const-class v17, Lae0;

    const/16 v9, 0xe2a

    move-object/from16 v0, v17

    invoke-direct {v13, v0}, Ljava/util/EnumMap;-><init>(Ljava/lang/Class;)V

    const/16 v9, 0xd9a

    sget-object v17, Lae0;->b:Lae0;

    nop

    const/16 v9, 0xc28

    sget-object v19, Lzd0;->a:Lzd0;

    nop

    const/16 v9, 0x15f

    move-object/from16 v0, v17

    move-object/from16 v1, v19

    invoke-virtual {v13, v0, v1}, Ljava/util/EnumMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v9, 0xe76

    sget-object v20, Lae0;->a:Lae0;

    nop

    const/16 v9, 0x15f

    move-object/from16 v0, v20

    move-object/from16 v1, v19

    invoke-virtual {v13, v0, v1}, Ljava/util/EnumMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v9, 0x7f1

    sget-object v21, Lae0;->c:Lae0;

    nop

    const/16 v9, 0x15f

    move-object/from16 v0, v21

    move-object/from16 v1, v19

    invoke-virtual {v13, v0, v1}, Ljava/util/EnumMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v9, 0x5a4

    sget-object v22, Lae0;->d:Lae0;

    nop

    const/16 v9, 0x15f

    move-object/from16 v0, v22

    move-object/from16 v1, v19

    invoke-virtual {v13, v0, v1}, Ljava/util/EnumMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v9, 0x47e

    iget-object v9, v11, Lcom/tlsvpn/tlstunnel/MainActivity;->h:Lcom/google/firebase/analytics/FirebaseAnalytics;

    move-object/16 v19, v9

    const-string/jumbo v23, "firebaseAnalytics"

    nop

    nop

    if-eqz v19, :cond_b14

    const/16 v9, 0x108

    new-instance v24, Landroid/os/Bundle;

    nop

    const/16 v9, 0x198

    move-object/from16 v0, v24

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/16 v9, 0x173

    move-object/from16 v0, v20

    invoke-virtual {v13, v0}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v20

    check-cast v20, Lzd0;

    const-string/jumbo v25, "granted"

    nop

    nop

    const-string/jumbo v26, "denied"

    nop

    nop

    if-eqz v20, :cond_6cf

    const/16 v9, 0x134

    move-object/from16 v0, v20

    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v20

    move-object/from16 v27, v18

    const-string/jumbo v18, "ad_storage"

    nop

    nop

    if-eqz v20, :cond_6c3

    move/from16 v0, v20

    move/from16 v1, v16

    if-eq v0, v1, :cond_6b7

    goto :goto_6d1

    :cond_6b7
    const/16 v9, 0x76

    move-object/from16 v0, v24

    move-object/from16 v1, v18

    move-object/from16 v2, v26

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_6d1

    :cond_6c3
    const/16 v9, 0x76

    move-object/from16 v0, v24

    move-object/from16 v1, v18

    move-object/from16 v2, v25

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_6d1

    :cond_6cf
    move-object/from16 v27, v18

    :goto_6d1
    const/16 v9, 0x173

    move-object/from16 v0, v17

    invoke-virtual {v13, v0}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v17

    check-cast v17, Lzd0;

    if-eqz v17, :cond_70a

    const/16 v9, 0x134

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v17

    const-string/jumbo v18, "analytics_storage"

    nop

    nop

    if-eqz v17, :cond_6ff

    move/from16 v0, v17

    move/from16 v1, v16

    if-eq v0, v1, :cond_6f3

    goto :goto_70a

    :cond_6f3
    const/16 v9, 0x76

    move-object/from16 v0, v24

    move-object/from16 v1, v18

    move-object/from16 v2, v26

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_70a

    :cond_6ff
    const/16 v9, 0x76

    move-object/from16 v0, v24

    move-object/from16 v1, v18

    move-object/from16 v2, v25

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    :cond_70a
    :goto_70a
    const/16 v9, 0x173

    move-object/from16 v0, v21

    invoke-virtual {v13, v0}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v17

    check-cast v17, Lzd0;

    if-eqz v17, :cond_743

    const/16 v9, 0x134

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/Enum;->ordinal()I

    move-result v17

    const-string/jumbo v18, "ad_user_data"

    nop

    nop

    if-eqz v17, :cond_738

    move/from16 v0, v17

    move/from16 v1, v16

    if-eq v0, v1, :cond_72c

    goto :goto_743

    :cond_72c
    const/16 v9, 0x76

    move-object/from16 v0, v24

    move-object/from16 v1, v18

    move-object/from16 v2, v26

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_743

    :cond_738
    const/16 v9, 0x76

    move-object/from16 v0, v24

    move-object/from16 v1, v18

    move-object/from16 v2, v25

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    :cond_743
    :goto_743
    const/16 v9, 0x173

    move-object/from16 v0, v22

    invoke-virtual {v13, v0}, Ljava/util/EnumMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lzd0;

    if-eqz v13, :cond_778

    const/16 v9, 0x134

    invoke-virtual {v13}, Ljava/lang/Enum;->ordinal()I

    move-result v13

    const-string/jumbo v17, "ad_personalization"

    nop

    nop

    if-eqz v13, :cond_76d

    move/from16 v0, v16

    if-eq v13, v0, :cond_761

    goto :goto_778

    :cond_761
    const/16 v9, 0x76

    move-object/from16 v0, v24

    move-object/from16 v1, v17

    move-object/from16 v2, v26

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_778

    :cond_76d
    const/16 v9, 0x76

    move-object/from16 v0, v24

    move-object/from16 v1, v17

    move-object/from16 v2, v25

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    :cond_778
    :goto_778
    const/16 v9, 0x3f1

    move-object/from16 v0, v19

    iget-object v13, v0, Lcom/google/firebase/analytics/FirebaseAnalytics;->a:Lcom/google/android/gms/internal/measurement/zzfb;

    nop

    const/16 v9, 0xd74

    move-object/from16 v0, v24

    invoke-virtual {v13, v0}, Lcom/google/android/gms/internal/measurement/zzfb;->zzr(Landroid/os/Bundle;)V

    const/16 v9, 0x47e

    iget-object v13, v11, Lcom/tlsvpn/tlstunnel/MainActivity;->h:Lcom/google/firebase/analytics/FirebaseAnalytics;

    nop

    if-eqz v13, :cond_b0d

    const/16 v9, 0x3f1

    iget-object v13, v13, Lcom/google/firebase/analytics/FirebaseAnalytics;->a:Lcom/google/android/gms/internal/measurement/zzfb;

    nop

    const/16 v9, 0x159

    sget-object v17, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    nop

    const/16 v9, 0x11da

    move-object/from16 v0, v17

    invoke-virtual {v13, v0}, Lcom/google/android/gms/internal/measurement/zzfb;->zzq(Ljava/lang/Boolean;)V

    const/16 v13, 0x21

    if-lt v12, v13, :cond_823

    const/16 v9, 0x53

    invoke-virtual {v11}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v17

    const-string/jumbo v18, "android.permission.POST_NOTIFICATIONS"

    nop

    nop

    const/16 v9, 0x2b7

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-static {v0, v1}, Lqx;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result v17

    if-eqz v17, :cond_823

    const/16 v9, 0x5b

    new-instance v17, Landroid/content/Intent;

    nop

    const/16 v9, 0x53

    invoke-virtual {v11}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v18

    const-class v19, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;

    const/16 v9, 0xd0

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    move-object/from16 v2, v19

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string/jumbo v18, "atype"

    nop

    nop

    const-string/jumbo v19, "perminotif"

    nop

    nop

    const/16 v9, 0x4b

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    move-object/from16 v2, v19

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const v18, 0x7f1301f2

    const/16 v9, 0xb4

    move/from16 v0, v18

    invoke-virtual {v11, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v18

    const-string/jumbo v19, "title"

    nop

    nop

    const/16 v9, 0x4b

    move-object/from16 v0, v17

    move-object/from16 v1, v19

    move-object/from16 v2, v18

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const v18, 0x7f1301f4

    const/16 v9, 0xb4

    move/from16 v0, v18

    invoke-virtual {v11, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v18

    const-string/jumbo v19, "msg"

    nop

    nop

    const/16 v9, 0x4b

    move-object/from16 v0, v17

    move-object/from16 v1, v19

    move-object/from16 v2, v18

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/16 v9, 0xc9

    move-object/from16 v0, v17

    invoke-virtual {v11, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    :cond_823
    const-string/jumbo v17, "restoreHome"

    nop

    nop

    const-string/jumbo v18, "addLog"

    nop

    nop

    const-string/jumbo v19, "vpnOff"

    nop

    nop

    const-string/jumbo v20, "vpnOn"

    nop

    nop

    const-string/jumbo v21, "dipro"

    nop

    nop

    const-string/jumbo v22, "pVacTd"

    nop

    nop

    const-string/jumbo v23, "admobIniciado"

    nop

    nop

    const-string/jumbo v24, "stelegrambs"

    nop

    nop

    const-string/jumbo v25, "ssb"

    nop

    nop

    const-string/jumbo v26, "evaluate"

    nop

    nop

    move/from16 v28, v16

    const-string/jumbo v16, "resetCfgFromMain"

    nop

    nop

    const-string/jumbo v14, "dialogRestaurar"

    nop

    nop

    move-object/from16 v30, v15

    const-string/jumbo v15, "recreateMain"

    nop

    nop

    move-object/from16 p1, v17

    const/16 v9, 0x8be

    iget-object v9, v11, Lcom/tlsvpn/tlstunnel/MainActivity;->k:Lob;

    move-object/16 v17, v9

    if-ge v12, v13, :cond_968

    const/16 v9, 0x1f

    new-instance v12, Landroid/content/IntentFilter;

    nop

    const/16 v9, 0x1d

    invoke-direct {v12, v15}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v9, 0x3a

    move-object/from16 v0, v17

    invoke-virtual {v11, v0, v12}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/16 v9, 0x1f

    new-instance v12, Landroid/content/IntentFilter;

    nop

    const/16 v9, 0x1d

    invoke-direct {v12, v14}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v9, 0x3a

    move-object/from16 v0, v17

    invoke-virtual {v11, v0, v12}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/16 v9, 0x1f

    new-instance v12, Landroid/content/IntentFilter;

    nop

    const/16 v9, 0x1d

    move-object/from16 v0, v16

    invoke-direct {v12, v0}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v9, 0x3a

    move-object/from16 v0, v17

    invoke-virtual {v11, v0, v12}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/16 v9, 0x1f

    new-instance v12, Landroid/content/IntentFilter;

    nop

    const/16 v9, 0x1d

    move-object/from16 v0, v26

    invoke-direct {v12, v0}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v9, 0x3a

    move-object/from16 v0, v17

    invoke-virtual {v11, v0, v12}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/16 v9, 0x1f

    new-instance v12, Landroid/content/IntentFilter;

    nop

    const/16 v9, 0x1d

    move-object/from16 v0, v25

    invoke-direct {v12, v0}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v9, 0x3a

    move-object/from16 v0, v17

    invoke-virtual {v11, v0, v12}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/16 v9, 0x1f

    new-instance v12, Landroid/content/IntentFilter;

    nop

    const/16 v9, 0x1d

    move-object/from16 v0, v24

    invoke-direct {v12, v0}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v9, 0x3a

    move-object/from16 v0, v17

    invoke-virtual {v11, v0, v12}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/16 v9, 0x1f

    new-instance v12, Landroid/content/IntentFilter;

    nop

    const/16 v9, 0x1d

    move-object/from16 v0, v23

    invoke-direct {v12, v0}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v9, 0x3a

    move-object/from16 v0, v17

    invoke-virtual {v11, v0, v12}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/16 v9, 0x1f

    new-instance v12, Landroid/content/IntentFilter;

    nop

    const/16 v9, 0x1d

    move-object/from16 v0, v22

    invoke-direct {v12, v0}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v9, 0x3a

    move-object/from16 v0, v17

    invoke-virtual {v11, v0, v12}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/16 v9, 0x1f

    new-instance v12, Landroid/content/IntentFilter;

    nop

    const/16 v9, 0x1d

    move-object/from16 v0, v21

    invoke-direct {v12, v0}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v9, 0x3a

    move-object/from16 v0, v17

    invoke-virtual {v11, v0, v12}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/16 v9, 0x1f

    new-instance v12, Landroid/content/IntentFilter;

    nop

    const/16 v9, 0x1d

    move-object/from16 v0, v20

    invoke-direct {v12, v0}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v9, 0x3a

    move-object/from16 v0, v17

    invoke-virtual {v11, v0, v12}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/16 v9, 0x1f

    new-instance v12, Landroid/content/IntentFilter;

    nop

    const/16 v9, 0x1d

    move-object/from16 v0, v19

    invoke-direct {v12, v0}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v9, 0x3a

    move-object/from16 v0, v17

    invoke-virtual {v11, v0, v12}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/16 v9, 0x1f

    new-instance v12, Landroid/content/IntentFilter;

    nop

    const/16 v9, 0x1d

    move-object/from16 v0, v18

    invoke-direct {v12, v0}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v9, 0x3a

    move-object/from16 v0, v17

    invoke-virtual {v11, v0, v12}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/16 v9, 0x1f

    new-instance v12, Landroid/content/IntentFilter;

    nop

    move-object/from16 v13, p1

    const/16 v9, 0x1d

    invoke-direct {v12, v13}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v9, 0x3a

    move-object/from16 v0, v17

    invoke-virtual {v11, v0, v12}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    goto/16 :goto_a5c

    :cond_968
    move-object/from16 v13, p1

    const/16 v9, 0x1f

    new-instance v12, Landroid/content/IntentFilter;

    nop

    const/16 v9, 0x1d

    invoke-direct {v12, v15}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/4 v15, 0x4

    const/16 v9, 0x39

    move-object/from16 v0, v17

    invoke-virtual {v11, v0, v12, v15}, Landroid/app/Activity;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    const/16 v9, 0x1f

    new-instance v12, Landroid/content/IntentFilter;

    nop

    const/16 v9, 0x1d

    invoke-direct {v12, v14}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v9, 0x39

    move-object/from16 v0, v17

    invoke-virtual {v11, v0, v12, v15}, Landroid/app/Activity;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    const/16 v9, 0x1f

    new-instance v12, Landroid/content/IntentFilter;

    nop

    const/16 v9, 0x1d

    move-object/from16 v0, v16

    invoke-direct {v12, v0}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v9, 0x39

    move-object/from16 v0, v17

    invoke-virtual {v11, v0, v12, v15}, Landroid/app/Activity;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    const/16 v9, 0x1f

    new-instance v12, Landroid/content/IntentFilter;

    nop

    const/16 v9, 0x1d

    move-object/from16 v0, v26

    invoke-direct {v12, v0}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v9, 0x39

    move-object/from16 v0, v17

    invoke-virtual {v11, v0, v12, v15}, Landroid/app/Activity;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    const/16 v9, 0x1f

    new-instance v12, Landroid/content/IntentFilter;

    nop

    const/16 v9, 0x1d

    move-object/from16 v0, v25

    invoke-direct {v12, v0}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v9, 0x39

    move-object/from16 v0, v17

    invoke-virtual {v11, v0, v12, v15}, Landroid/app/Activity;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    const/16 v9, 0x1f

    new-instance v12, Landroid/content/IntentFilter;

    nop

    const/16 v9, 0x1d

    move-object/from16 v0, v24

    invoke-direct {v12, v0}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v9, 0x39

    move-object/from16 v0, v17

    invoke-virtual {v11, v0, v12, v15}, Landroid/app/Activity;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    const/16 v9, 0x1f

    new-instance v12, Landroid/content/IntentFilter;

    nop

    const/16 v9, 0x1d

    move-object/from16 v0, v23

    invoke-direct {v12, v0}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v9, 0x39

    move-object/from16 v0, v17

    invoke-virtual {v11, v0, v12, v15}, Landroid/app/Activity;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    const/16 v9, 0x1f

    new-instance v12, Landroid/content/IntentFilter;

    nop

    const/16 v9, 0x1d

    move-object/from16 v0, v22

    invoke-direct {v12, v0}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v9, 0x39

    move-object/from16 v0, v17

    invoke-virtual {v11, v0, v12, v15}, Landroid/app/Activity;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    const/16 v9, 0x1f

    new-instance v12, Landroid/content/IntentFilter;

    nop

    const/16 v9, 0x1d

    move-object/from16 v0, v21

    invoke-direct {v12, v0}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v9, 0x39

    move-object/from16 v0, v17

    invoke-virtual {v11, v0, v12, v15}, Landroid/app/Activity;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    const/16 v9, 0x1f

    new-instance v12, Landroid/content/IntentFilter;

    nop

    const/16 v9, 0x1d

    move-object/from16 v0, v20

    invoke-direct {v12, v0}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v9, 0x39

    move-object/from16 v0, v17

    invoke-virtual {v11, v0, v12, v15}, Landroid/app/Activity;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    const/16 v9, 0x1f

    new-instance v12, Landroid/content/IntentFilter;

    nop

    const/16 v9, 0x1d

    move-object/from16 v0, v19

    invoke-direct {v12, v0}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v9, 0x39

    move-object/from16 v0, v17

    invoke-virtual {v11, v0, v12, v15}, Landroid/app/Activity;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    const/16 v9, 0x1f

    new-instance v12, Landroid/content/IntentFilter;

    nop

    const/16 v9, 0x1d

    move-object/from16 v0, v18

    invoke-direct {v12, v0}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v9, 0x39

    move-object/from16 v0, v17

    invoke-virtual {v11, v0, v12, v15}, Landroid/app/Activity;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    const/16 v9, 0x1f

    new-instance v12, Landroid/content/IntentFilter;

    nop

    const/16 v9, 0x1d

    invoke-direct {v12, v13}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v9, 0x39

    move-object/from16 v0, v17

    invoke-virtual {v11, v0, v12, v15}, Landroid/app/Activity;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    :goto_a5c
    const/16 v9, 0xed3

    move/from16 v0, v28

    sput-boolean v0, Lmi2;->d:Z

    const/16 v9, 0x234

    iget-boolean v12, v11, Lcom/tlsvpn/tlstunnel/MainActivity;->j:Z

    nop

    if-eqz v12, :cond_a86

    const/16 v9, 0x95

    invoke-virtual {v11}, Lcom/tlsvpn/tlstunnel/MainActivity;->j()Landroid/content/SharedPreferences;

    move-result-object v12

    const/4 v9, -0x6

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v9, 0x7a

    invoke-interface {v12}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v12

    move-object/from16 v13, v30

    const/4 v14, 0x0

    const/16 v9, 0x48

    invoke-interface {v12, v13, v14}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/16 v9, 0x6f

    invoke-interface {v12}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_a86
    const/16 v9, 0x942

    sput-object v11, Lmi2;->q:Lcom/tlsvpn/tlstunnel/MainActivity;

    const/16 v9, 0x95

    invoke-virtual {v11}, Lcom/tlsvpn/tlstunnel/MainActivity;->j()Landroid/content/SharedPreferences;

    move-result-object v12

    const-string/jumbo v13, "nup"

    nop

    nop

    move/from16 v14, v28

    const/16 v9, 0x77

    invoke-interface {v12, v13, v14}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v12

    if-nez v12, :cond_aa0

    goto :goto_ad2

    :cond_aa0
    const/16 v9, 0x302

    iget-object v12, v11, Lcom/tlsvpn/tlstunnel/MainActivity;->l:Lw82;

    nop

    const/16 v9, 0x177

    invoke-virtual {v12}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Lli3;

    const/16 v9, 0x11cc

    invoke-virtual {v12}, Lli3;->a()Lcom/google/android/gms/tasks/Task;

    move-result-object v12

    const/4 v9, -0x6

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v9, 0x9fc

    new-instance v13, Le51;

    nop

    const/16 v9, 0x1096

    invoke-direct {v13, v11, v14}, Le51;-><init>(Lcom/tlsvpn/tlstunnel/MainActivity;I)V

    const/16 v9, 0x50f

    new-instance v14, Lah;

    nop

    const/16 v15, 0xe

    const/16 v9, 0x3bf

    invoke-direct {v14, v15, v13}, Lah;-><init>(ILjava/lang/Object;)V

    const/16 v9, 0xbdb

    invoke-virtual {v12, v14}, Lcom/google/android/gms/tasks/Task;->addOnSuccessListener(Lcom/google/android/gms/tasks/OnSuccessListener;)Lcom/google/android/gms/tasks/Task;

    :goto_ad2
    const/16 v9, 0x234

    iget-boolean v12, v11, Lcom/tlsvpn/tlstunnel/MainActivity;->j:Z

    nop

    if-eqz v12, :cond_ae8

    const/16 v9, 0x140

    sget-boolean v12, Lg4;->a:Z

    nop

    const/16 v9, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v12

    const/16 v9, 0x713

    sput-wide v12, Lg4;->i:J

    :cond_ae8
    const/16 v9, 0x140

    sget-boolean v12, Lg4;->a:Z

    nop

    const/16 v29, 0x0

    const/16 v9, 0x119d

    move/from16 v0, v29

    sput v0, Lg4;->q:I

    const/16 v9, 0xa94

    move/from16 v0, v29

    sput v0, Lg4;->u:I

    const/16 v9, 0x1257

    move/from16 v0, v29

    sput v0, Lg4;->y:I

    const/16 v9, 0x929

    move/from16 v0, v29

    sput v0, Lg4;->C:I

    const/16 v9, 0x2cc

    invoke-static {v11}, Lg4;->d(Landroid/app/Activity;)V

    return-void

    :cond_b0d
    const/4 v9, 0x5

    move-object/from16 v0, v23

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_b14
    move-object/from16 v27, v18

    const/4 v9, 0x5

    move-object/from16 v0, v23

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27
.end method

.method public final onDestroy()V
    .registers 4

    .prologue
    const/16 v0, 0xd70

    invoke-super {p0}, Lra;->onDestroy()V

    :try_start_5
    const/16 v0, 0x8be

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/MainActivity;->k:Lob;

    nop

    const/16 v0, 0x345

    invoke-virtual {p0, v2}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_f
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_f} :catch_f

    :catch_f
    const/4 v2, 0x0

    const/16 v0, 0xed3

    sput-boolean v2, Lmi2;->d:Z

    const/4 v2, 0x0

    const/16 v0, 0x942

    sput-object v2, Lmi2;->q:Lcom/tlsvpn/tlstunnel/MainActivity;

    const/16 v0, 0x415

    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    move-result v2

    if-eqz v2, :cond_35

    const/16 v0, 0x140

    sget-boolean v2, Lg4;->a:Z

    nop

    const/16 v0, 0x95

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/MainActivity;->j()Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x120b

    invoke-static {p0}, Lg4;->a(Landroid/content/SharedPreferences;)V

    :cond_35
    return-void
.end method

.method public final onPause()V
    .registers 3

    const/16 v0, 0x855

    invoke-super {p0}, Landroidx/fragment/app/l;->onPause()V

    const/16 v0, 0x905

    sget-boolean p0, Lmi2;->a:Z

    nop

    return-void
.end method

.method public final onResume()V
    .registers 8

    .prologue
    const/16 v1, 0xd37

    invoke-super {p0}, Landroidx/fragment/app/l;->onResume()V

    const/16 v1, 0x905

    sget-boolean v3, Lmi2;->a:Z

    nop

    const/16 v1, 0x302

    iget-object v3, p0, Lcom/tlsvpn/tlstunnel/MainActivity;->l:Lw82;

    nop

    const/16 v1, 0x177

    invoke-virtual {v3}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lli3;

    const/16 v1, 0x11cc

    invoke-virtual {v3}, Lli3;->a()Lcom/google/android/gms/tasks/Task;

    move-result-object v3

    const/16 v1, 0x9fc

    new-instance v4, Le51;

    nop

    const/4 v5, 0x0

    const/16 v1, 0x1096

    invoke-direct {v4, p0, v5}, Le51;-><init>(Lcom/tlsvpn/tlstunnel/MainActivity;I)V

    const/16 v1, 0x50f

    new-instance v5, Lah;

    nop

    const/16 v6, 0xd

    const/16 v1, 0x3bf

    invoke-direct {v5, v6, v4}, Lah;-><init>(ILjava/lang/Object;)V

    const/16 v1, 0xbdb

    invoke-virtual {v3, v5}, Lcom/google/android/gms/tasks/Task;->addOnSuccessListener(Lcom/google/android/gms/tasks/OnSuccessListener;)Lcom/google/android/gms/tasks/Task;

    const/16 v1, 0xaf4

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/MainActivity;->g()V

    const/16 v1, 0x140

    sget-boolean v3, Lg4;->a:Z

    nop

    const/16 v1, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    const/4 v1, -0x6

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-wide/16 v4, 0x0

    const/16 v1, 0x3a0

    invoke-static {v4, v5, v3}, Lg4;->j(JLandroid/content/Context;)V

    const/16 v1, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    const/4 v1, -0x6

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v1, 0x2ce

    invoke-static {v4, v5, v3}, Lg4;->k(JLandroid/content/Context;)V

    const/16 v1, 0x95

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/MainActivity;->j()Landroid/content/SharedPreferences;

    move-result-object v3

    const/4 v1, -0x6

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v1, 0xfa8

    invoke-static {v3}, Lg4;->g(Landroid/content/SharedPreferences;)Z

    move-result v3

    if-eqz v3, :cond_85

    const/16 v1, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    const/4 v1, -0x6

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v6, 0x6

    const/16 v1, 0x3d5

    invoke-static {v3, v6, v4, v5}, Lg4;->m(Landroid/content/Context;IJ)V

    :cond_85
    const/16 v1, 0x27c

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/MainActivity;->k()V

    return-void
.end method
