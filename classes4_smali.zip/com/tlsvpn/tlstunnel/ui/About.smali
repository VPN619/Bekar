.class public final Lcom/tlsvpn/tlstunnel/ui/About;
.super Landroidx/fragment/app/Fragment;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Lw82;

.field public b:Landroid/widget/TextView;

.field public c:Landroid/view/View;

.field public d:Landroid/widget/ImageView;

.field public e:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;


# direct methods
.method public constructor <init>()V
    .registers 5

    invoke-direct {p0}, Landroidx/fragment/app/Fragment;-><init>()V

    const/16 v0, 0xa84

    new-instance v2, Ld;

    nop

    const/4 v3, 0x0

    const/16 v0, 0x6cb

    invoke-direct {v2, v3, p0}, Ld;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x27a

    new-instance v3, Lw82;

    nop

    const/16 v0, 0x215

    invoke-direct {v3, v2}, Lw82;-><init>(Lzj0;)V

    const/16 v0, 0x830

    iput-object v3, p0, Lcom/tlsvpn/tlstunnel/ui/About;->a:Lw82;

    return-void
.end method


# virtual methods
.method public final onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .registers 10

    .prologue
    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x119

    iget-object p3, p0, Lcom/tlsvpn/tlstunnel/ui/About;->c:Landroid/view/View;

    nop

    const/4 v2, 0x0

    if-nez p3, :cond_15

    const p3, 0x7f0c00d2

    const/16 v0, 0x107b

    invoke-virtual {p1, p3, p2, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p3

    :cond_15
    const/16 v0, 0x11a6

    iput-object p3, p0, Lcom/tlsvpn/tlstunnel/ui/About;->c:Landroid/view/View;

    const/4 p1, 0x0

    if-eqz p3, :cond_28

    const p2, 0x7f09013b

    const/16 v0, 0x11

    invoke-virtual {p3, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/ImageView;

    goto :goto_29

    :cond_28
    move-object p2, p1

    :goto_29
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xbaf

    iput-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/About;->d:Landroid/widget/ImageView;

    const/16 v0, 0x119

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/About;->c:Landroid/view/View;

    nop

    if-eqz p2, :cond_44

    const p3, 0x7f09005a

    const/16 v0, 0x11

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/TextView;

    goto :goto_45

    :cond_44
    move-object p2, p1

    :goto_45
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xafa

    iput-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/About;->b:Landroid/widget/TextView;

    const/16 v0, 0x119

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/About;->c:Landroid/view/View;

    nop

    if-eqz p2, :cond_60

    const p3, 0x7f0900a2

    const/16 v0, 0x11

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    goto :goto_61

    :cond_60
    move-object p2, p1

    :goto_61
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x76c

    iput-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/About;->e:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    const/16 v0, 0x106c

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/About;->d:Landroid/widget/ImageView;

    nop

    if-eqz p2, :cond_13b

    const/16 v0, 0x33e

    new-instance p3, Lb;

    nop

    const/16 v0, 0x2cd

    invoke-direct {p3, p0, v2}, Lb;-><init>(Lcom/tlsvpn/tlstunnel/ui/About;I)V

    const/16 v0, 0x5f

    invoke-virtual {p2, p3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0x108f

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/About;->e:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    nop

    if-eqz p2, :cond_133

    const/16 v0, 0x33e

    new-instance p3, Lb;

    nop

    const/4 v3, 0x1

    const/16 v0, 0x2cd

    invoke-direct {p3, p0, v3}, Lb;-><init>(Lcom/tlsvpn/tlstunnel/ui/About;I)V

    const/16 v0, 0x5f

    invoke-virtual {p2, p3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0x4f5

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/About;->b:Landroid/widget/TextView;

    nop

    const-string/jumbo p3, "appdesc"

    if-eqz p2, :cond_12e

    const v4, 0x7f130026

    const/16 v0, 0x4c

    invoke-virtual {p0, v4}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v4

    const/16 v5, 0x3f

    const/16 v0, 0x9b4

    invoke-static {v4, v5}, Landroid/text/Html;->fromHtml(Ljava/lang/String;I)Landroid/text/Spanned;

    move-result-object v4

    const/16 v0, 0x8a

    invoke-virtual {p2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v0, 0x4f5

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/About;->b:Landroid/widget/TextView;

    nop

    if-eqz p2, :cond_129

    const/16 v0, 0xb9c

    invoke-static {}, Landroid/text/method/LinkMovementMethod;->getInstance()Landroid/text/method/MovementMethod;

    move-result-object p1

    const/16 v0, 0xfc1

    invoke-virtual {p2, p1}, Landroid/widget/TextView;->setMovementMethod(Landroid/text/method/MovementMethod;)V

    const/16 v0, 0x1046

    iget-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/About;->a:Lw82;

    nop

    const/16 v0, 0x177

    invoke-virtual {p1}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Landroid/content/SharedPreferences;

    const-string/jumbo p3, "achkedS"

    const/16 v0, 0x77

    invoke-interface {p2, p3, v3}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p2

    if-eqz p2, :cond_101

    const/16 v0, 0x5d3

    new-instance p2, Landroid/os/Handler;

    nop

    const/16 v0, 0x1210

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object p3

    const/16 v0, 0xad4

    invoke-direct {p2, p3}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/16 v0, 0xb36

    new-instance p3, Lc;

    nop

    const/16 v0, 0x87c

    invoke-direct {p3, v2, p0}, Lc;-><init>(ILjava/lang/Object;)V

    const-wide/16 v2, 0x1388

    const/16 v0, 0xc45

    invoke-virtual {p2, p3, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_101
    const/16 v0, 0x140

    sget-boolean p2, Lg4;->a:Z

    nop

    const/16 v0, 0xfb

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x177

    invoke-virtual {p1}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/content/SharedPreferences;

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x394

    invoke-static {p1, p2}, Lg4;->n(Landroid/content/SharedPreferences;Landroidx/fragment/app/l;)V

    const/16 v0, 0x119

    iget-object p0, p0, Lcom/tlsvpn/tlstunnel/ui/About;->c:Landroid/view/View;

    nop

    check-cast p0, Landroid/view/View;

    return-object p0

    :cond_129
    const/4 v0, 0x5

    invoke-static {p3}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_12e
    const/4 v0, 0x5

    invoke-static {p3}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_133
    const-string/jumbo p0, "check"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_13b
    const-string/jumbo p0, "home"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1
.end method

.method public final onDestroyView()V
    .registers 5

    .prologue
    const/16 v0, 0x122b

    invoke-super {p0}, Landroidx/fragment/app/Fragment;->onDestroyView()V

    const/16 v0, 0x108f

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/ui/About;->e:Lcom/google/android/material/floatingactionbutton/FloatingActionButton;

    nop

    if-eqz v2, :cond_38

    const/4 v3, 0x1

    const/16 v0, 0xe37

    invoke-virtual {v2, v3}, Lcom/google/android/material/floatingactionbutton/FloatingActionButton;->d(Z)V

    const/16 v0, 0x1046

    iget-object p0, p0, Lcom/tlsvpn/tlstunnel/ui/About;->a:Lw82;

    nop

    const/16 v0, 0x177

    invoke-virtual {p0}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/content/SharedPreferences;

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x7a

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo v2, "achkedS"

    const/4 v3, 0x0

    const/16 v0, 0x48

    invoke-interface {p0, v2, v3}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x6f

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void

    :cond_38
    const-string/jumbo p0, "check"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0
.end method
