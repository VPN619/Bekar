.class public final Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;
.super Lra;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final synthetic F:I


# instance fields
.field public A:Z

.field public B:Ljava/lang/String;

.field public C:Z

.field public D:Z

.field public final E:Lob;

.field public final g:Lw82;

.field public h:Landroidx/constraintlayout/widget/ConstraintLayout;

.field public i:Landroid/widget/TextView;

.field public j:Landroid/widget/TextView;

.field public k:Landroid/widget/TextView;

.field public l:Landroid/widget/ProgressBar;

.field public m:Landroid/widget/TextView;

.field public n:Landroidx/constraintlayout/widget/ConstraintLayout;

.field public o:Landroid/widget/ImageView;

.field public p:Landroid/widget/TextView;

.field public q:Landroid/widget/ImageView;

.field public r:Landroid/view/View;

.field public s:I

.field public t:Ljava/lang/String;

.field public u:I

.field public v:I

.field public w:J

.field public x:Lbt1;

.field public y:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

.field public z:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .registers 7

    invoke-direct {p0}, Lra;-><init>()V

    const/16 v1, 0xa84

    new-instance v3, Ld;

    nop

    const/16 v4, 0x1b

    const/16 v1, 0x6cb

    invoke-direct {v3, v4, p0}, Ld;-><init>(ILjava/lang/Object;)V

    const/16 v1, 0x27a

    new-instance v4, Lw82;

    nop

    const/16 v1, 0x215

    invoke-direct {v4, v3}, Lw82;-><init>(Lzj0;)V

    const/16 v1, 0x771

    iput-object v4, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->g:Lw82;

    const-string/jumbo v3, ""

    const/16 v1, 0x50a

    iput-object v3, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->t:Ljava/lang/String;

    const v4, 0x19000

    const/16 v1, 0x123

    sget-object v5, Lpp1;->a:Lv0;

    nop

    const/16 v1, 0x16d

    invoke-virtual {v5, v4}, Lv0;->l(I)I

    move-result v4

    const/16 v1, 0x82d

    iput v4, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->v:I

    const-wide/32 v4, 0x927c0

    const/16 v1, 0x10cd

    iput-wide v4, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->w:J

    const-string/jumbo v4, "nothing"

    nop

    nop

    const/16 v1, 0xaf8

    iput-object v4, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->z:Ljava/lang/String;

    const/4 v4, 0x1

    const/16 v1, 0x9c6

    iput-boolean v4, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->A:Z

    const/16 v1, 0x1191

    iput-object v3, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->B:Ljava/lang/String;

    const/16 v1, 0x6a9

    iput-boolean v4, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->C:Z

    const/16 v1, 0xf6e

    new-instance v3, Lob;

    nop

    const/4 v4, 0x6

    const/16 v1, 0x11c1

    invoke-direct {v3, v4, p0}, Lob;-><init>(ILjava/lang/Object;)V

    const/16 v1, 0xb33

    iput-object v3, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->E:Lob;

    return-void
.end method


# virtual methods
.method public final finish()V
    .registers 7

    .prologue
    const/16 v0, 0x1fc

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 v3, 0x22

    const v4, 0x7f010033

    const v5, 0x7f010032

    if-lt v2, v3, :cond_16

    const/4 v2, 0x1

    const/16 v0, 0xd40

    invoke-virtual {p0, v2, v5, v4}, Landroid/app/Activity;->overrideActivityTransition(III)V

    goto :goto_1b

    :cond_16
    const/16 v0, 0x5c8

    invoke-virtual {p0, v5, v4}, Landroid/app/Activity;->overridePendingTransition(II)V

    :goto_1b
    const/16 v0, 0x905

    sget-boolean v2, Lmi2;->a:Z

    nop

    const/16 v0, 0x195

    sget-boolean v2, Lmi2;->d:Z

    nop

    if-nez v2, :cond_2d

    const/16 v0, 0x83a

    invoke-virtual {p0}, Landroid/app/Activity;->finishAndRemoveTask()V

    return-void

    :cond_2d
    const/16 v0, 0x660

    invoke-super {p0}, Landroid/app/Activity;->finish()V

    return-void
.end method

.method public final g(Ljava/lang/String;)V
    .registers 10

    .prologue
    const/16 v0, 0x5b

    new-instance v2, Landroid/content/Intent;

    nop

    const-string/jumbo v3, "addLog"

    nop

    nop

    const/16 v0, 0x62

    invoke-direct {v2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    const/16 v0, 0x4a

    invoke-virtual {v3}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    const/16 v0, 0x64

    invoke-virtual {v2, v3}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v2

    const/high16 v3, 0x10000000

    const/16 v0, 0x59

    invoke-virtual {v2, v3}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x905

    sget-boolean v3, Lmi2;->a:Z

    nop

    if-eqz v3, :cond_45

    const-string/jumbo v3, "lmsg"

    nop

    nop

    const/16 v0, 0x4b

    invoke-virtual {v2, v3, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    goto/16 :goto_c2

    :cond_45
    const/16 v0, 0x1062

    new-instance v3, Ljava/util/Date;

    nop

    const/16 v0, 0x958

    invoke-direct {v3}, Ljava/util/Date;-><init>()V

    const/16 v0, 0xd54

    new-instance v4, Ljava/text/SimpleDateFormat;

    nop

    const-string/jumbo v5, "HH:mm:ss"

    nop

    nop

    const/16 v0, 0xa75

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v6

    const/16 v0, 0xc81

    invoke-direct {v4, v5, v6}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    const/16 v0, 0xb7a

    sget-object v5, Lmi2;->b:Ljava/util/concurrent/CopyOnWriteArrayList;

    nop

    const/4 v0, -0x3

    new-instance v6, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v7, "["

    nop

    nop

    const/16 v0, 0x97

    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0xa9e

    invoke-virtual {v4, v3}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v3

    const/4 v0, 0x0

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v3, "] "

    nop

    nop

    const/4 v0, 0x0

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {v6, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/16 v3, 0x3f

    const/16 v0, 0x9b4

    invoke-static {p1, v3}, Landroid/text/Html;->fromHtml(Ljava/lang/String;I)Landroid/text/Spanned;

    move-result-object p1

    const/16 v0, 0x146

    invoke-virtual {v5, p1}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    const/16 v0, 0x13d

    invoke-virtual {v5}, Ljava/util/concurrent/CopyOnWriteArrayList;->size()I

    move-result p1

    const/16 v3, 0x3e7

    if-le p1, v3, :cond_b0

    const/4 p1, 0x0

    const/16 v0, 0xac6

    invoke-virtual {v5, p1}, Ljava/util/concurrent/CopyOnWriteArrayList;->remove(I)Ljava/lang/Object;

    :cond_b0
    const/16 v0, 0x195

    sget-boolean p1, Lmi2;->d:Z

    nop

    if-nez p1, :cond_c2

    const/16 v0, 0x4d0

    sget p1, Lmi2;->c:I

    nop

    add-int/lit8 p1, p1, 0x1

    const/16 v0, 0x100f

    sput p1, Lmi2;->c:I

    :cond_c2
    :goto_c2
    const/16 v0, 0x63

    invoke-virtual {p0, v2}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    return-void
.end method

.method public final h()Landroid/content/SharedPreferences;
    .registers 3

    const/16 v0, 0x11f0

    iget-object p0, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->g:Lw82;

    nop

    const/16 v0, 0x177

    invoke-virtual {p0}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/content/SharedPreferences;

    return-object p0
.end method

.method public final i(Ljava/lang/String;Z)V
    .registers 16

    .prologue
    const/4 v6, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x22e

    new-instance v8, Lzs1;

    nop

    const/4 v9, 0x4

    const/16 v6, 0x1d4

    invoke-direct {v8, p0, v9}, Lzs1;-><init>(Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;I)V

    const/16 v6, 0x147

    invoke-virtual {p0, v8}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    const/16 v6, 0xaf8

    iput-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->z:Ljava/lang/String;

    const/16 v6, 0x9c6

    iput-boolean p2, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->A:Z

    const/16 v6, 0x5b

    new-instance v8, Landroid/content/Intent;

    nop

    const/16 v6, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v9

    const-class v10, Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;

    const-string/jumbo v11, "CONSULTSTATUS"

    nop

    nop

    const/4 v12, 0x0

    const/16 v6, 0x3fd

    move v0, v6

    move-object v1, v8

    move-object v2, v11

    move-object v3, v12

    move-object v4, v9

    move-object v5, v10

    invoke-direct/range {v1 .. v5}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;Landroid/content/Context;Ljava/lang/Class;)V

    const-string/jumbo v9, "srv"

    nop

    nop

    const/16 v6, 0x88

    iget-object v10, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->t:Ljava/lang/String;

    nop

    const/16 v6, 0x4b

    invoke-virtual {v8, v9, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string/jumbo v9, "cId"

    nop

    nop

    const/16 v6, 0xa48

    iget v10, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->v:I

    nop

    const/16 v6, 0x29

    invoke-virtual {v8, v9, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string/jumbo v9, "frn"

    nop

    nop

    const/16 v6, 0x178

    invoke-virtual {v8, v9, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    const-string/jumbo p2, "rtype"

    nop

    nop

    const/16 v6, 0x4b

    invoke-virtual {v8, p2, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string/jumbo p1, "cTp"

    nop

    nop

    const/4 p2, 0x2

    const/16 v6, 0x29

    invoke-virtual {v8, p1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    :try_start_77
    const/16 v6, 0x4a7

    invoke-virtual {p0, v8}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_7c
    .catch Ljava/lang/Exception; {:try_start_77 .. :try_end_7c} :catch_7c

    :catch_7c
    return-void
.end method

.method public final j()V
    .registers 7

    .prologue
    const/16 v0, 0x242

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->h()Landroid/content/SharedPreferences;

    move-result-object v2

    const-string/jumbo v3, "drVw5ad"

    nop

    nop

    const/4 v4, 0x0

    const/16 v0, 0xb0

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v2

    const/16 v0, 0x242

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->h()Landroid/content/SharedPreferences;

    move-result-object v3

    const-string/jumbo v5, "adXs5SFd"

    nop

    nop

    const/16 v0, 0xb0

    invoke-interface {v3, v5, v4}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v3

    rsub-int/lit8 v3, v3, 0x18

    rsub-int/lit8 v4, v2, 0x8

    if-le v3, v4, :cond_2c

    const/16 v3, 0x8

    goto :goto_2d

    :cond_2c
    add-int/2addr v3, v2

    :goto_2d
    const/4 v0, -0x3

    new-instance v4, Ljava/lang/StringBuilder;

    nop

    const/4 v0, -0x4

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v0, 0x33

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 v2, 0x2f

    const/16 v0, 0x1b

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v0, 0x33

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/16 v0, 0x6f9

    iget-object p0, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->m:Landroid/widget/TextView;

    nop

    if-eqz p0, :cond_58

    const/16 v0, 0x8a

    invoke-virtual {p0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    :cond_58
    const-string/jumbo p0, "freeRenewLimit"

    nop

    nop

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .registers 16

    .prologue
    const/16 v0, 0xddd

    invoke-super {p0, p1}, Landroidx/fragment/app/l;->onCreate(Landroid/os/Bundle;)V

    const/16 v0, 0x1fc

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 v3, 0x22

    const v4, 0x7f010033

    const v5, 0x7f010032

    const/4 v6, 0x0

    if-lt v2, v3, :cond_1b

    const/16 v0, 0xd40

    invoke-virtual {p0, v6, v5, v4}, Landroid/app/Activity;->overrideActivityTransition(III)V

    goto :goto_20

    :cond_1b
    const/16 v0, 0x5c8

    invoke-virtual {p0, v5, v4}, Landroid/app/Activity;->overridePendingTransition(II)V

    :goto_20
    const/4 v3, 0x1

    const/16 v0, 0x1064

    sput-boolean v3, Lmi2;->e:Z

    const v4, 0x7f0c00c9

    const/16 v0, 0x1157

    invoke-virtual {p0, v4}, Lra;->setContentView(I)V

    const/16 v0, 0x11fd

    invoke-virtual {p0, v6}, Landroid/app/Activity;->setFinishOnTouchOutside(Z)V

    const v4, 0x7f09038e

    const/16 v0, 0x41

    invoke-virtual {p0, v4}, Lra;->findViewById(I)Landroid/view/View;

    move-result-object v4

    const/4 v0, -0x6

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v4, Landroidx/constraintlayout/widget/ConstraintLayout;

    const/16 v0, 0xff5

    iput-object v4, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->h:Landroidx/constraintlayout/widget/ConstraintLayout;

    const v4, 0x7f090393

    const/16 v0, 0x41

    invoke-virtual {p0, v4}, Lra;->findViewById(I)Landroid/view/View;

    move-result-object v4

    const/4 v0, -0x6

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v4, Landroid/widget/TextView;

    const/16 v0, 0xdc5

    iput-object v4, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->i:Landroid/widget/TextView;

    const v4, 0x7f090258

    const/16 v0, 0x41

    invoke-virtual {p0, v4}, Lra;->findViewById(I)Landroid/view/View;

    move-result-object v4

    const/4 v0, -0x6

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v4, Landroid/widget/TextView;

    const/16 v0, 0xb59

    iput-object v4, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->j:Landroid/widget/TextView;

    const v4, 0x7f090313

    const/16 v0, 0x41

    invoke-virtual {p0, v4}, Lra;->findViewById(I)Landroid/view/View;

    move-result-object v4

    const/4 v0, -0x6

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v4, Landroid/widget/TextView;

    const/16 v0, 0x66c

    iput-object v4, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->k:Landroid/widget/TextView;

    const v4, 0x7f09016a

    const/16 v0, 0x41

    invoke-virtual {p0, v4}, Lra;->findViewById(I)Landroid/view/View;

    move-result-object v4

    const/4 v0, -0x6

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v4, Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    const/16 v0, 0x10a9

    iput-object v4, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->y:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    const v4, 0x7f090064

    const/16 v0, 0x41

    invoke-virtual {p0, v4}, Lra;->findViewById(I)Landroid/view/View;

    move-result-object v4

    const/4 v0, -0x6

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v4, Landroidx/constraintlayout/widget/ConstraintLayout;

    const/16 v0, 0x7b7

    iput-object v4, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->n:Landroidx/constraintlayout/widget/ConstraintLayout;

    const v4, 0x7f090065

    const/16 v0, 0x41

    invoke-virtual {p0, v4}, Lra;->findViewById(I)Landroid/view/View;

    move-result-object v4

    const/4 v0, -0x6

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v4, Landroid/widget/ImageView;

    const/16 v0, 0x67c

    iput-object v4, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->o:Landroid/widget/ImageView;

    const v4, 0x7f090066

    const/16 v0, 0x41

    invoke-virtual {p0, v4}, Lra;->findViewById(I)Landroid/view/View;

    move-result-object v4

    const/4 v0, -0x6

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v4, Landroid/widget/TextView;

    const/16 v0, 0x8d0

    iput-object v4, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->p:Landroid/widget/TextView;

    const v4, 0x7f0902cf

    const/16 v0, 0x41

    invoke-virtual {p0, v4}, Lra;->findViewById(I)Landroid/view/View;

    move-result-object v4

    const/4 v0, -0x6

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v4, Landroid/widget/ProgressBar;

    const/16 v0, 0xfc2

    iput-object v4, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->l:Landroid/widget/ProgressBar;

    const v4, 0x7f090118

    const/16 v0, 0x41

    invoke-virtual {p0, v4}, Lra;->findViewById(I)Landroid/view/View;

    move-result-object v4

    const/4 v0, -0x6

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v4, Landroid/widget/TextView;

    const/16 v0, 0xb5d

    iput-object v4, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->m:Landroid/widget/TextView;

    const v4, 0x7f0902e3

    const/16 v0, 0x41

    invoke-virtual {p0, v4}, Lra;->findViewById(I)Landroid/view/View;

    move-result-object v4

    const/4 v0, -0x6

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v4, Landroid/widget/ImageView;

    const/16 v0, 0xbd4

    iput-object v4, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->q:Landroid/widget/ImageView;

    const v4, 0x7f0902e4

    const/16 v0, 0x41

    invoke-virtual {p0, v4}, Lra;->findViewById(I)Landroid/view/View;

    move-result-object v4

    const/4 v0, -0x6

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x11bf

    iput-object v4, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->r:Landroid/view/View;

    const/16 v0, 0x140

    sget-boolean v4, Lg4;->a:Z

    nop

    const/16 v0, 0x242

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->h()Landroid/content/SharedPreferences;

    move-result-object v4

    const/4 v0, -0x6

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x622

    invoke-static {v4}, Lg4;->i(Landroid/content/SharedPreferences;)Z

    move-result v4

    const/16 v0, 0x869

    iput-boolean v4, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->D:Z

    const/16 v0, 0xb15

    iget-object v4, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->i:Landroid/widget/TextView;

    nop

    const/4 v5, 0x0

    if-eqz v4, :cond_51d

    const v7, 0x7f130226

    const/16 v0, 0x93

    invoke-virtual {v4, v7}, Landroid/widget/TextView;->setText(I)V

    const/16 v0, 0x319

    iget-boolean v4, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->D:Z

    nop

    const/16 v0, 0x413

    iget-object v7, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->r:Landroid/view/View;

    nop

    const-string/jumbo v8, "removeAdsDot"

    nop

    nop

    if-eqz v4, :cond_163

    if-eqz v7, :cond_15e

    const/4 v0, -0x5

    invoke-virtual {v7, v6}, Landroid/view/View;->setVisibility(I)V

    const v4, 0x7f130221

    const/16 v0, 0xb4

    invoke-virtual {p0, v4}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v4

    goto :goto_174

    :cond_15e
    const/4 v0, 0x5

    invoke-static {v8}, Lgt0;->F0(Ljava/lang/String;)V

    throw v5

    :cond_163
    if-eqz v7, :cond_518

    const/16 v4, 0x8

    const/4 v0, -0x5

    invoke-virtual {v7, v4}, Landroid/view/View;->setVisibility(I)V

    const v4, 0x7f130220

    const/16 v0, 0xb4

    invoke-virtual {p0, v4}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v4

    :goto_174
    const/4 v0, -0x6

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x120

    iget-object v7, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->j:Landroid/widget/TextView;

    nop

    const-string/jumbo v8, "txtMensagem"

    nop

    nop

    if-eqz v7, :cond_513

    const/16 v9, 0x3f

    const/16 v0, 0x9b4

    invoke-static {v4, v9}, Landroid/text/Html;->fromHtml(Ljava/lang/String;I)Landroid/text/Spanned;

    move-result-object v4

    const/16 v0, 0x8a

    invoke-virtual {v7, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v4, 0x21

    const-string/jumbo v7, "admobIniciado"

    nop

    nop

    const-string/jumbo v9, "pVacTd"

    nop

    nop

    const-string/jumbo v10, "SERVERLURPL"

    nop

    nop

    const-string/jumbo v11, "SERVERRPL"

    nop

    nop

    const/4 v12, 0x4

    const/16 v0, 0x6fb

    iget-object v13, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->E:Lob;

    nop

    if-ge v2, v4, :cond_1ec

    const/16 v0, 0x1f

    new-instance v2, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {v2, v11}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x3a

    invoke-virtual {p0, v13, v2}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/16 v0, 0x1f

    new-instance v2, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {v2, v10}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x3a

    invoke-virtual {p0, v13, v2}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/16 v0, 0x1f

    new-instance v2, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {v2, v9}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x3a

    invoke-virtual {p0, v13, v2}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/16 v0, 0x1f

    new-instance v2, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {v2, v7}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x3a

    invoke-virtual {p0, v13, v2}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    goto :goto_228

    :cond_1ec
    const/16 v0, 0x1f

    new-instance v2, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {v2, v11}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x39

    invoke-virtual {p0, v13, v2, v12}, Landroid/app/Activity;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    const/16 v0, 0x1f

    new-instance v2, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {v2, v10}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x39

    invoke-virtual {p0, v13, v2, v12}, Landroid/app/Activity;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    const/16 v0, 0x1f

    new-instance v2, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {v2, v9}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x39

    invoke-virtual {p0, v13, v2, v12}, Landroid/app/Activity;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    const/16 v0, 0x1f

    new-instance v2, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {v2, v7}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x39

    invoke-virtual {p0, v13, v2, v12}, Landroid/app/Activity;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    :goto_228
    const/16 v2, 0x5d

    const-string/jumbo v4, "Renew"

    nop

    nop

    const-string/jumbo v7, "serverh"

    nop

    nop

    if-eqz p1, :cond_2f9

    const-string/jumbo v9, "cdTimeLeft"

    nop

    nop

    const/16 v0, 0xdba

    invoke-virtual {p1, v9}, Landroid/os/BaseBundle;->getLong(Ljava/lang/String;)J

    move-result-wide v9

    const/16 v0, 0x10cd

    iput-wide v9, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->w:J

    const-string/jumbo v9, "rstatus"

    nop

    nop

    const/16 v0, 0x233

    invoke-virtual {p1, v9}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v9

    const/16 v0, 0x1a6

    iput v9, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->u:I

    const-string/jumbo v9, "renewCID"

    nop

    nop

    const/16 v0, 0x233

    invoke-virtual {p1, v9}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v9

    const/16 v0, 0x82d

    iput v9, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->v:I

    const-string/jumbo v9, "sserver"

    nop

    nop

    const/16 v0, 0x233

    invoke-virtual {p1, v9}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v9

    const/16 v0, 0x318

    iput v9, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->s:I

    const-string/jumbo v9, "tleft"

    nop

    nop

    const/16 v0, 0x183

    invoke-virtual {p1, v9}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const-string/jumbo v10, ""

    if-nez v9, :cond_283

    move-object v9, v10

    :cond_283
    const/16 v0, 0x1191

    iput-object v9, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->B:Ljava/lang/String;

    const/16 v0, 0x120

    iget-object v9, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->j:Landroid/widget/TextView;

    nop

    if-eqz v9, :cond_2f4

    const-string/jumbo v8, "rmsg"

    nop

    nop

    const/16 v0, 0x183

    invoke-virtual {p1, v8}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const/16 v0, 0x8a

    invoke-virtual {v9, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v0, 0x183

    invoke-virtual {p1, v7}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    if-nez v8, :cond_2a7

    goto :goto_2a8

    :cond_2a7
    move-object v10, v8

    :goto_2a8
    const/16 v0, 0x50a

    iput-object v10, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->t:Ljava/lang/String;

    const-string/jumbo v8, "lrtype"

    nop

    nop

    const/16 v0, 0x183

    invoke-virtual {p1, v8}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    if-nez v8, :cond_2be

    const-string/jumbo v8, "nothing"

    nop

    nop

    :cond_2be
    const/16 v0, 0xaf8

    iput-object v8, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->z:Ljava/lang/String;

    const-string/jumbo v8, "lrifdn"

    nop

    nop

    const/16 v0, 0x428

    invoke-virtual {p1, v8, v3}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;Z)Z

    move-result p1

    const/16 v0, 0x9c6

    iput-boolean p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->A:Z

    const/4 v0, -0x3

    new-instance p1, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v8, "Recuperando estado (savedInstanceState) ["

    nop

    nop

    const/16 v0, 0x97

    invoke-direct {p1, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x88

    iget-object v8, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->t:Ljava/lang/String;

    nop

    const/4 v0, 0x0

    invoke-virtual {p1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x1b

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    nop

    goto :goto_2f9

    :cond_2f4
    const/4 v0, 0x5

    invoke-static {v8}, Lgt0;->F0(Ljava/lang/String;)V

    throw v5

    :cond_2f9
    :goto_2f9
    const/16 v0, 0x33c

    iget-wide v8, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->w:J

    nop

    const-wide/16 v10, 0x0

    cmp-long p1, v8, v10

    if-lez p1, :cond_343

    const/16 v0, 0x27

    iget-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->y:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    nop

    const-string/jumbo v8, "loadIndicator"

    nop

    nop

    if-eqz p1, :cond_33e

    const/4 v0, -0x5

    invoke-virtual {p1, v6}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0x27

    iget-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->y:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    nop

    if-eqz p1, :cond_339

    const/16 v0, 0xe4

    invoke-virtual {p1, v6}, Lki;->setProgress(I)V

    const/16 v0, 0xcd5

    new-instance p1, Lbt1;

    nop

    const/16 v0, 0x33c

    iget-wide v8, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->w:J

    nop

    const/16 v0, 0xf2d

    invoke-direct {p1, p0, v8, v9}, Lbt1;-><init>(Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;J)V

    const/16 v0, 0xadf

    iput-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->x:Lbt1;

    const/16 v0, 0xcf1

    invoke-virtual {p1}, Landroid/os/CountDownTimer;->start()Landroid/os/CountDownTimer;

    goto :goto_343

    :cond_339
    const/4 v0, 0x5

    invoke-static {v8}, Lgt0;->F0(Ljava/lang/String;)V

    throw v5

    :cond_33e
    const/4 v0, 0x5

    invoke-static {v8}, Lgt0;->F0(Ljava/lang/String;)V

    throw v5

    :cond_343
    :goto_343
    const/16 v0, 0x28

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const/16 v0, 0x8d

    invoke-virtual {p1, v7}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    if-nez p1, :cond_356

    const/16 v0, 0x88

    iget-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->t:Ljava/lang/String;

    nop

    :cond_356
    const/16 v0, 0x50a

    iput-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->t:Ljava/lang/String;

    const/16 v0, 0x47

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result p1

    if-nez p1, :cond_368

    const/16 v0, 0x224

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->finish()V

    return-void

    :cond_368
    const/16 v0, 0x242

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->h()Landroid/content/SharedPreferences;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xa82

    invoke-virtual {p0}, Lra;->getResources()Landroid/content/res/Resources;

    move-result-object v7

    const/4 v0, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x4fe

    invoke-static {p1, v7, v6}, Lqk;->p(Landroid/content/SharedPreferences;Landroid/content/res/Resources;I)[Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0x88

    iget-object v7, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->t:Ljava/lang/String;

    nop

    const/16 v0, 0x48e

    invoke-static {p1, v7}, Laf;->a0([Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_395

    const/16 v0, 0x224

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->finish()V

    return-void

    :cond_395
    const/16 v0, 0x88

    iget-object v7, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->t:Ljava/lang/String;

    nop

    const/16 v0, 0x1ed

    invoke-static {v7, p1}, Laf;->l0(Ljava/lang/Object;[Ljava/lang/Object;)I

    move-result p1

    const/16 v0, 0x318

    iput p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->s:I

    if-ge p1, v3, :cond_3ac

    const/16 v0, 0x224

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->finish()V

    return-void

    :cond_3ac
    const/4 v0, -0x3

    new-instance p1, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v7, "Renovar servidor: "

    nop

    nop

    const/16 v0, 0x97

    invoke-direct {p1, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x88

    iget-object v7, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->t:Ljava/lang/String;

    nop

    const/4 v0, 0x0

    invoke-virtual {p1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v7, " ["

    nop

    nop

    const/4 v0, 0x0

    invoke-virtual {p1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x5d9

    iget v7, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->s:I

    nop

    const/16 v0, 0x33

    invoke-virtual {p1, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 v0, 0x1b

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    nop

    const/16 v0, 0x52b

    sget-object p1, Ldz;->a:Lcz;

    nop

    const/16 v0, 0x88

    iget-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->t:Ljava/lang/String;

    nop

    const/4 v2, 0x2

    const/16 v0, 0x196

    invoke-static {v2, p1}, Lc72;->G0(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0x1f7

    sget-object v4, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    nop

    const/16 v0, 0x3b0

    invoke-virtual {p1, v4}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x334

    invoke-static {p1}, Ldz;->a(Ljava/lang/String;)Lcz;

    move-result-object p1

    const/4 v0, -0x3

    new-instance v7, Ljava/lang/StringBuilder;

    nop

    const/16 v0, 0x1e6

    iget-object p1, p1, Lcz;->c:Ljava/lang/String;

    nop

    const/16 v0, 0x97

    invoke-direct {v7, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 p1, 0x20

    const/16 v0, 0x1b

    invoke-virtual {v7, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v0, 0x88

    iget-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->t:Ljava/lang/String;

    nop

    const/4 v8, 0x3

    const/16 v0, 0x196

    invoke-static {v8, p1}, Lc72;->G0(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0x12d

    invoke-virtual {p1, v4}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x0

    invoke-virtual {v7, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0x265

    iget-object v4, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->k:Landroid/widget/TextView;

    nop

    if-eqz v4, :cond_509

    const/16 v0, 0x8a

    invoke-virtual {v4, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v0, 0x101

    sget-boolean p1, Lmi2;->n:Z

    nop

    if-eqz p1, :cond_459

    const-string/jumbo p1, "video"

    nop

    nop

    const/16 v0, 0x399

    invoke-virtual {p0, p1, v6}, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->i(Ljava/lang/String;Z)V

    return-void

    :cond_459
    const/16 v0, 0x1e7

    iget p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->u:I

    nop

    if-eqz p1, :cond_49f

    if-eq p1, v3, :cond_48f

    if-eq p1, v2, :cond_478

    if-eq p1, v8, :cond_467

    goto :goto_4ae

    :cond_467
    const/16 v0, 0x22e

    new-instance p1, Lzs1;

    nop

    const/4 v2, 0x5

    const/16 v0, 0x1d4

    invoke-direct {p1, p0, v2}, Lzs1;-><init>(Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;I)V

    const/16 v0, 0x147

    invoke-virtual {p0, p1}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    goto :goto_4ae

    :cond_478
    const/16 v0, 0xda7

    iget-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->B:Ljava/lang/String;

    nop

    const/16 v0, 0xd45

    new-instance v2, Lu7;

    nop

    const/16 v3, 0x12

    const/16 v0, 0x1080

    invoke-direct {v2, v3, p0, p1}, Lu7;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    const/16 v0, 0x147

    invoke-virtual {p0, v2}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    goto :goto_4ae

    :cond_48f
    const/16 v0, 0x22e

    new-instance p1, Lzs1;

    nop

    const/16 v0, 0x1d4

    invoke-direct {p1, p0, v12}, Lzs1;-><init>(Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;I)V

    const/16 v0, 0x147

    invoke-virtual {p0, p1}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    goto :goto_4ae

    :cond_49f
    const/16 v0, 0x22e

    new-instance p1, Lzs1;

    nop

    const/16 v0, 0x1d4

    invoke-direct {p1, p0, v2}, Lzs1;-><init>(Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;I)V

    const/16 v0, 0x147

    invoke-virtual {p0, p1}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    :goto_4ae
    const/16 v0, 0x4ca

    iget-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->q:Landroid/widget/ImageView;

    nop

    if-eqz p1, :cond_4ff

    const/16 v0, 0x14d

    new-instance v2, Lat1;

    nop

    const/16 v0, 0x193

    invoke-direct {v2, p0, v8}, Lat1;-><init>(Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;I)V

    const/16 v0, 0x5f

    invoke-virtual {p1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0xc4b

    sput-object p0, Lmi2;->p:Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;

    const/16 v0, 0x2cc

    invoke-static {p0}, Lg4;->d(Landroid/app/Activity;)V

    const/16 v0, 0x5f5

    sget-wide v2, Lg4;->k:J

    nop

    const/16 v0, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    cmp-long p1, v2, v4

    if-gtz p1, :cond_4e3

    const/16 v0, 0x319

    iget-boolean p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->D:Z

    nop

    if-eqz p1, :cond_4f9

    :cond_4e3
    const/16 v0, 0x195

    sget-boolean p1, Lmi2;->d:Z

    nop

    if-eqz p1, :cond_4f9

    const/16 v0, 0x242

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->h()Landroid/content/SharedPreferences;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x394

    invoke-static {p1, p0}, Lg4;->n(Landroid/content/SharedPreferences;Landroidx/fragment/app/l;)V

    :cond_4f9
    const/16 v0, 0xf19

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->j()V

    return-void

    :cond_4ff
    const-string/jumbo p0, "removeads"

    nop

    nop

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v5

    :cond_509
    const-string/jumbo p0, "server"

    nop

    nop

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v5

    :cond_513
    const/4 v0, 0x5

    invoke-static {v8}, Lgt0;->F0(Ljava/lang/String;)V

    throw v5

    :cond_518
    const/4 v0, 0x5

    invoke-static {v8}, Lgt0;->F0(Ljava/lang/String;)V

    throw v5

    :cond_51d
    const-string/jumbo p0, "txtTitulo"

    nop

    nop

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v5
.end method

.method public final onDestroy()V
    .registers 4

    .prologue
    const/16 v0, 0xd70

    invoke-super {p0}, Lra;->onDestroy()V

    const/4 v2, 0x0

    const/16 v0, 0x1064

    sput-boolean v2, Lmi2;->e:Z

    const/4 v2, 0x0

    const/16 v0, 0xc4b

    sput-object v2, Lmi2;->p:Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;

    :try_start_f
    const/16 v0, 0x6fb

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->E:Lob;

    nop

    const/16 v0, 0x345

    invoke-virtual {p0, v2}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_19
    .catch Ljava/lang/Exception; {:try_start_f .. :try_end_19} :catch_19

    :catch_19
    const/16 v0, 0xbd

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->x:Lbt1;

    nop

    if-eqz v2, :cond_25

    :try_start_20
    const/16 v0, 0x2f3

    invoke-virtual {v2}, Landroid/os/CountDownTimer;->cancel()V
    :try_end_25
    .catch Ljava/lang/Exception; {:try_start_20 .. :try_end_25} :catch_25

    :catch_25
    :cond_25
    const/16 v0, 0x195

    sget-boolean v2, Lmi2;->d:Z

    nop

    if-nez v2, :cond_48

    const/16 v0, 0x415

    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    move-result v2

    if-eqz v2, :cond_48

    const/16 v0, 0x140

    sget-boolean v2, Lg4;->a:Z

    nop

    const/16 v0, 0x242

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->h()Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x120b

    invoke-static {p0}, Lg4;->a(Landroid/content/SharedPreferences;)V

    :cond_48
    return-void
.end method

.method public final onNewIntent(Landroid/content/Intent;)V
    .registers 7

    .prologue
    const/16 v0, 0xae0

    invoke-super {p0, p1}, Lut;->onNewIntent(Landroid/content/Intent;)V

    const/16 v0, 0x9f5

    invoke-virtual {p0, p1}, Landroid/app/Activity;->setIntent(Landroid/content/Intent;)V

    if-eqz p1, :cond_130

    const-string/jumbo v2, "serverh"

    nop

    nop

    const/16 v0, 0x8d

    invoke-virtual {p1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    if-nez p1, :cond_1b

    goto/16 :goto_130

    :cond_1b
    const/16 v0, 0x88

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->t:Ljava/lang/String;

    nop

    const/16 v0, 0x128

    invoke-virtual {p1, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_2a

    goto/16 :goto_130

    :cond_2a
    const/16 v0, 0x50a

    iput-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->t:Ljava/lang/String;

    const/16 v0, 0x47

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result p1

    if-nez p1, :cond_3c

    const/16 v0, 0x224

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->finish()V

    return-void

    :cond_3c
    const/16 v0, 0x242

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->h()Landroid/content/SharedPreferences;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xa82

    invoke-virtual {p0}, Lra;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v3, 0x0

    const/16 v0, 0x4fe

    invoke-static {p1, v2, v3}, Lqk;->p(Landroid/content/SharedPreferences;Landroid/content/res/Resources;I)[Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0x88

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->t:Ljava/lang/String;

    nop

    const/16 v0, 0x48e

    invoke-static {p1, v2}, Laf;->a0([Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_6a

    const/16 v0, 0x224

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->finish()V

    return-void

    :cond_6a
    const/16 v0, 0x88

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->t:Ljava/lang/String;

    nop

    const/16 v0, 0x1ed

    invoke-static {v2, p1}, Laf;->l0(Ljava/lang/Object;[Ljava/lang/Object;)I

    move-result p1

    const/16 v0, 0x318

    iput p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->s:I

    const/4 v2, 0x1

    if-ge p1, v2, :cond_82

    const/16 v0, 0x224

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->finish()V

    return-void

    :cond_82
    const/4 v0, -0x3

    new-instance p1, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v2, "onNewIntent: Atualizando para o servidor conectado: "

    nop

    nop

    const/16 v0, 0x97

    invoke-direct {p1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x88

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->t:Ljava/lang/String;

    nop

    const/4 v0, 0x0

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v2, " ["

    nop

    nop

    const/4 v0, 0x0

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x5d9

    iget v2, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->s:I

    nop

    const/16 v0, 0x33

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 v2, 0x5d

    const/16 v0, 0x1b

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string/jumbo v2, "Renew"

    nop

    nop

    nop

    const/16 v0, 0x52b

    sget-object p1, Ldz;->a:Lcz;

    nop

    const/16 v0, 0x88

    iget-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->t:Ljava/lang/String;

    nop

    const/4 v2, 0x2

    const/16 v0, 0x196

    invoke-static {v2, p1}, Lc72;->G0(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0x1f7

    sget-object v2, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    nop

    const/16 v0, 0x3b0

    invoke-virtual {p1, v2}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x334

    invoke-static {p1}, Ldz;->a(Ljava/lang/String;)Lcz;

    move-result-object p1

    const/4 v0, -0x3

    new-instance v3, Ljava/lang/StringBuilder;

    nop

    const/16 v0, 0x1e6

    iget-object p1, p1, Lcz;->c:Ljava/lang/String;

    nop

    const/16 v0, 0x97

    invoke-direct {v3, p1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 p1, 0x20

    const/16 v0, 0x1b

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v0, 0x88

    iget-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->t:Ljava/lang/String;

    nop

    const/4 v4, 0x3

    const/16 v0, 0x196

    invoke-static {v4, p1}, Lc72;->G0(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0x12d

    invoke-virtual {p1, v2}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x0

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0x265

    iget-object p0, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->k:Landroid/widget/TextView;

    nop

    if-eqz p0, :cond_125

    const/16 v0, 0x8a

    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    :cond_125
    const-string/jumbo p0, "server"

    nop

    nop

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0

    :cond_130
    :goto_130
    return-void
.end method

.method public final onPause()V
    .registers 5

    .prologue
    const/16 v0, 0x855

    invoke-super {p0}, Landroidx/fragment/app/l;->onPause()V

    const/16 v0, 0x905

    sget-boolean v2, Lmi2;->a:Z

    nop

    const/16 v0, 0x1e7

    iget v2, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->u:I

    nop

    const/4 v3, 0x2

    if-ne v2, v3, :cond_1e

    const/16 v0, 0x195

    sget-boolean v2, Lmi2;->d:Z

    nop

    if-nez v2, :cond_1e

    const/16 v0, 0x224

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->finish()V

    :cond_1e
    return-void
.end method

.method public final onResume()V
    .registers 5

    .prologue
    const/16 v0, 0xd37

    invoke-super {p0}, Landroidx/fragment/app/l;->onResume()V

    const/16 v0, 0x101

    sget-boolean v2, Lmi2;->n:Z

    nop

    if-eqz v2, :cond_11

    const/16 v0, 0x224

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->finish()V

    :cond_11
    const/16 v0, 0x140

    sget-boolean v2, Lg4;->a:Z

    nop

    const/16 v0, 0x242

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->h()Landroid/content/SharedPreferences;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x622

    invoke-static {v2}, Lg4;->i(Landroid/content/SharedPreferences;)Z

    move-result v2

    const/16 v0, 0x869

    iput-boolean v2, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->D:Z

    const/16 v0, 0x1e7

    iget v2, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->u:I

    nop

    if-nez v2, :cond_41

    const/16 v0, 0x22e

    new-instance v2, Lzs1;

    nop

    const/4 v3, 0x2

    const/16 v0, 0x1d4

    invoke-direct {v2, p0, v3}, Lzs1;-><init>(Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;I)V

    const/16 v0, 0x147

    invoke-virtual {p0, v2}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    :cond_41
    return-void
.end method

.method public final onSaveInstanceState(Landroid/os/Bundle;)V
    .registers 10

    .prologue
    const/4 v1, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, -0x3

    new-instance v3, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v4, "onSaveInstanceState isFinishing = "

    nop

    nop

    const/16 v1, 0x97

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v1, 0x415

    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    move-result v4

    const/16 v1, 0x6a

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v1, -0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const-string/jumbo v4, "Renew"

    nop

    nop

    nop

    const/16 v1, 0x415

    invoke-virtual {p0}, Landroid/app/Activity;->isFinishing()Z

    move-result v3

    if-eqz v3, :cond_31

    return-void

    :cond_31
    const-string/jumbo v3, "renewCID"

    nop

    nop

    const/16 v1, 0xa48

    iget v4, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->v:I

    nop

    const/16 v1, 0x23e

    invoke-virtual {p1, v3, v4}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const-string/jumbo v3, "rstatus"

    nop

    nop

    const/16 v1, 0x1e7

    iget v4, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->u:I

    nop

    const/16 v1, 0x23e

    invoke-virtual {p1, v3, v4}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const-string/jumbo v3, "sserver"

    nop

    nop

    const/16 v1, 0x5d9

    iget v4, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->s:I

    nop

    const/16 v1, 0x23e

    invoke-virtual {p1, v3, v4}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const-string/jumbo v3, "serverh"

    nop

    nop

    const/16 v1, 0x88

    iget-object v4, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->t:Ljava/lang/String;

    nop

    const/16 v1, 0x76

    invoke-virtual {p1, v3, v4}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v1, 0x120

    iget-object v3, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->j:Landroid/widget/TextView;

    nop

    if-eqz v3, :cond_da

    const/16 v1, 0x275

    invoke-virtual {v3}, Landroid/widget/TextView;->getText()Ljava/lang/CharSequence;

    move-result-object v3

    const/16 v1, 0xcb

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    const-string/jumbo v4, "rmsg"

    nop

    nop

    const/16 v1, 0x76

    invoke-virtual {p1, v4, v3}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const-string/jumbo v3, "tleft"

    nop

    nop

    const/16 v1, 0xda7

    iget-object v4, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->B:Ljava/lang/String;

    nop

    const/16 v1, 0x76

    invoke-virtual {p1, v3, v4}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const-string/jumbo v3, "lrtype"

    nop

    nop

    const/16 v1, 0x79d

    iget-object v4, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->z:Ljava/lang/String;

    nop

    const/16 v1, 0x76

    invoke-virtual {p1, v3, v4}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const-string/jumbo v3, "lrifdn"

    nop

    nop

    const/16 v1, 0x112b

    iget-boolean v4, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->A:Z

    nop

    const/16 v1, 0x27b

    invoke-virtual {p1, v3, v4}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/16 v1, 0xbd

    iget-object v3, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->x:Lbt1;

    nop

    const-wide/16 v4, 0x0

    if-eqz v3, :cond_ca

    const/16 v1, 0x33c

    iget-wide v6, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->w:J

    nop

    cmp-long v3, v6, v4

    if-lez v3, :cond_ca

    move-wide v4, v6

    :cond_ca
    const-string/jumbo v3, "cdTimeLeft"

    nop

    nop

    const/16 v1, 0xc15

    invoke-virtual {p1, v3, v4, v5}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    const/16 v1, 0x1209

    invoke-super {p0, p1}, Lut;->onSaveInstanceState(Landroid/os/Bundle;)V

    return-void

    :cond_da
    const-string/jumbo p0, "txtMensagem"

    nop

    nop

    const/4 v1, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0
.end method
