.class public final Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;
.super Lra;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final synthetic o:I


# instance fields
.field public g:Landroidx/constraintlayout/widget/ConstraintLayout;

.field public h:Landroid/widget/ImageView;

.field public i:Landroid/widget/ImageView;

.field public j:Landroid/widget/TextView;

.field public k:Landroid/widget/TextView;

.field public l:Landroid/widget/LinearLayout;

.field public m:Landroid/widget/TextView;

.field public final n:Lm3;


# direct methods
.method public constructor <init>()V
    .registers 6

    invoke-direct {p0}, Lra;-><init>()V

    const/16 v0, 0xa2

    new-instance v2, Ll3;

    nop

    const/4 v3, 0x1

    const/16 v0, 0x9e

    invoke-direct {v2, v3}, Ll3;-><init>(I)V

    const/16 v0, 0x50f

    new-instance v3, Lah;

    nop

    const/4 v4, 0x0

    const/16 v0, 0x3bf

    invoke-direct {v3, v4, p0}, Lah;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0xaa

    invoke-virtual {p0, v2, v3}, Lut;->registerForActivityResult(Lk3;Lj3;)Lm3;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xce2

    iput-object v2, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;->n:Lm3;

    return-void
.end method


# virtual methods
.method public final finish()V
    .registers 7

    .prologue
    const/16 v0, 0x660

    invoke-super {p0}, Landroid/app/Activity;->finish()V

    const/16 v0, 0x1fc

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 v3, 0x22

    const v4, 0x7f010033

    const v5, 0x7f010032

    if-lt v2, v3, :cond_1b

    const/4 v2, 0x1

    const/16 v0, 0xd40

    invoke-virtual {p0, v2, v5, v4}, Landroid/app/Activity;->overrideActivityTransition(III)V

    return-void

    :cond_1b
    const/16 v0, 0x5c8

    invoke-virtual {p0, v5, v4}, Landroid/app/Activity;->overridePendingTransition(II)V

    return-void
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .registers 11

    .prologue
    const/16 v0, 0xddd

    invoke-super {p0, p1}, Landroidx/fragment/app/l;->onCreate(Landroid/os/Bundle;)V

    const/16 v0, 0x1fc

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 v2, 0x22

    const/4 v3, 0x0

    const v4, 0x7f010033

    const v5, 0x7f010032

    if-lt p1, v2, :cond_1b

    const/16 v0, 0xd40

    invoke-virtual {p0, v3, v5, v4}, Landroid/app/Activity;->overrideActivityTransition(III)V

    goto :goto_20

    :cond_1b
    const/16 v0, 0x5c8

    invoke-virtual {p0, v5, v4}, Landroid/app/Activity;->overridePendingTransition(II)V

    :goto_20
    const p1, 0x7f0c0020

    const/16 v0, 0x1157

    invoke-virtual {p0, p1}, Lra;->setContentView(I)V

    const p1, 0x7f09038e

    const/16 v0, 0x41

    invoke-virtual {p0, p1}, Lra;->findViewById(I)Landroid/view/View;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p1, Landroidx/constraintlayout/widget/ConstraintLayout;

    const/16 v0, 0x1091

    iput-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;->g:Landroidx/constraintlayout/widget/ConstraintLayout;

    const p1, 0x7f090392

    const/16 v0, 0x41

    invoke-virtual {p0, p1}, Lra;->findViewById(I)Landroid/view/View;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p1, Landroid/widget/ImageView;

    const/16 v0, 0xe87

    iput-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;->h:Landroid/widget/ImageView;

    const p1, 0x7f09013b

    const/16 v0, 0x41

    invoke-virtual {p0, p1}, Lra;->findViewById(I)Landroid/view/View;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p1, Landroid/widget/ImageView;

    const/16 v0, 0xb6f

    iput-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;->i:Landroid/widget/ImageView;

    const p1, 0x7f090393

    const/16 v0, 0x41

    invoke-virtual {p0, p1}, Lra;->findViewById(I)Landroid/view/View;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p1, Landroid/widget/TextView;

    const/16 v0, 0x11e7

    iput-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;->j:Landroid/widget/TextView;

    const p1, 0x7f090258

    const/16 v0, 0x41

    invoke-virtual {p0, p1}, Lra;->findViewById(I)Landroid/view/View;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p1, Landroid/widget/TextView;

    const/16 v0, 0xdf6

    iput-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;->k:Landroid/widget/TextView;

    const p1, 0x7f090058

    const/16 v0, 0x41

    invoke-virtual {p0, p1}, Lra;->findViewById(I)Landroid/view/View;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p1, Landroid/widget/LinearLayout;

    const/16 v0, 0x5d1

    iput-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;->l:Landroid/widget/LinearLayout;

    const p1, 0x7f090059

    const/16 v0, 0x41

    invoke-virtual {p0, p1}, Lra;->findViewById(I)Landroid/view/View;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p1, Landroid/widget/TextView;

    const/16 v0, 0x1137

    iput-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;->m:Landroid/widget/TextView;

    const/16 v0, 0x1c0

    iget-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;->l:Landroid/widget/LinearLayout;

    nop

    const-string/jumbo v2, "aplicar"

    nop

    nop

    const/4 v4, 0x0

    if-eqz p1, :cond_255

    const/16 v0, 0x2d5

    new-instance v5, Lzg;

    nop

    const/16 v0, 0x2c8

    invoke-direct {v5, p0, v3}, Lzg;-><init>(Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;I)V

    const/16 v0, 0x5f

    invoke-virtual {p1, v5}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0x28

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    if-eqz p1, :cond_24f

    const/16 v0, 0x28

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const-string/jumbo v5, "atype"

    nop

    nop

    const/16 v0, 0x8d

    invoke-virtual {p1, v5}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0x28

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v5

    const-string/jumbo v6, "title"

    nop

    nop

    const/16 v0, 0x8d

    invoke-virtual {v5, v6}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/16 v0, 0x28

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v6

    const-string/jumbo v7, "msg"

    nop

    nop

    const/16 v0, 0x8d

    invoke-virtual {v6, v7}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    if-eqz v6, :cond_117

    const-string/jumbo v7, "\n"

    nop

    nop

    const-string/jumbo v8, "<br>"

    nop

    nop

    const/16 v0, 0x1a

    invoke-static {v6, v7, v8, v3}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v3

    goto :goto_118

    :cond_117
    move-object v3, v4

    :goto_118
    if-eqz v5, :cond_13a

    const/16 v0, 0x47

    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v6

    if-nez v6, :cond_123

    goto :goto_13a

    :cond_123
    const/16 v0, 0x8b1

    iget-object v6, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;->j:Landroid/widget/TextView;

    nop

    if-eqz v6, :cond_130

    const/16 v0, 0x8a

    invoke-virtual {v6, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_13a

    :cond_130
    const-string/jumbo p0, "titulo"

    nop

    nop

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_13a
    :goto_13a
    if-eqz v3, :cond_164

    const/16 v0, 0x47

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v5

    if-nez v5, :cond_145

    goto :goto_164

    :cond_145
    const/16 v0, 0x2c7

    iget-object v5, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;->k:Landroid/widget/TextView;

    nop

    if-eqz v5, :cond_15a

    const/16 v6, 0x3f

    const/16 v0, 0x9b4

    invoke-static {v3, v6}, Landroid/text/Html;->fromHtml(Ljava/lang/String;I)Landroid/text/Spanned;

    move-result-object v3

    const/16 v0, 0x8a

    invoke-virtual {v5, v3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_164

    :cond_15a
    const-string/jumbo p0, "msginfo"

    nop

    nop

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_164
    :goto_164
    const-string/jumbo v3, "sshaf"

    nop

    nop

    const/16 v0, 0x84

    invoke-static {p1, v3}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    const-string/jumbo v5, "topBarRightIcon"

    nop

    nop

    const-string/jumbo v6, "topBarLeftIcon"

    nop

    nop

    if-eqz v3, :cond_1a1

    const/16 v0, 0x35d

    iget-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;->h:Landroid/widget/ImageView;

    nop

    if-eqz p1, :cond_19c

    const v2, 0x7f080113

    const/16 v0, 0x87

    invoke-virtual {p1, v2}, Landroid/widget/ImageView;->setImageResource(I)V

    const/16 v0, 0x43f

    iget-object p0, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;->i:Landroid/widget/ImageView;

    nop

    if-eqz p0, :cond_197

    const/16 v0, 0x87

    invoke-virtual {p0, v2}, Landroid/widget/ImageView;->setImageResource(I)V

    return-void

    :cond_197
    const/4 v0, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_19c
    const/4 v0, 0x5

    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_1a1
    const-string/jumbo v3, "perminotif"

    nop

    nop

    const/16 v0, 0x84

    invoke-static {p1, v3}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_24e

    const/16 v0, 0x35d

    iget-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;->h:Landroid/widget/ImageView;

    nop

    if-eqz p1, :cond_249

    const v3, 0x7f080107

    const/16 v0, 0x87

    invoke-virtual {p1, v3}, Landroid/widget/ImageView;->setImageResource(I)V

    const/16 v0, 0x43f

    iget-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;->i:Landroid/widget/ImageView;

    nop

    if-eqz p1, :cond_244

    const/16 v0, 0x87

    invoke-virtual {p1, v3}, Landroid/widget/ImageView;->setImageResource(I)V

    const/16 v0, 0x8da

    iget-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;->g:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz p1, :cond_23a

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    const v5, 0x7f06003b

    const/16 v0, 0x52f

    invoke-static {v3, v5}, Lqx;->getDrawable(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v3

    const/16 v0, 0x2fd

    invoke-virtual {p1, v3}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/16 v0, 0x1c0

    iget-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;->l:Landroid/widget/LinearLayout;

    nop

    if-eqz p1, :cond_235

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    const v5, 0x7f08007c

    const/16 v0, 0x52f

    invoke-static {v3, v5}, Lqx;->getDrawable(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v3

    const/16 v0, 0x2fd

    invoke-virtual {p1, v3}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/16 v0, 0xee9

    iget-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;->m:Landroid/widget/TextView;

    nop

    if-eqz p1, :cond_22b

    const v3, 0x7f1301f6

    const/16 v0, 0x93

    invoke-virtual {p1, v3}, Landroid/widget/TextView;->setText(I)V

    const/16 v0, 0x1c0

    iget-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;->l:Landroid/widget/LinearLayout;

    nop

    if-eqz p1, :cond_226

    const/16 v0, 0x2d5

    new-instance v2, Lzg;

    nop

    const/4 v3, 0x1

    const/16 v0, 0x2c8

    invoke-direct {v2, p0, v3}, Lzg;-><init>(Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;I)V

    const/16 v0, 0x5f

    invoke-virtual {p1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void

    :cond_226
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_22b
    const-string/jumbo p0, "aplicartxt"

    nop

    nop

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_235
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_23a
    const-string/jumbo p0, "toolbar"

    nop

    nop

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_244
    const/4 v0, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_249
    const/4 v0, 0x5

    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_24e
    return-void

    :cond_24f
    const/16 v0, 0x337

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;->finish()V

    return-void

    :cond_255
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4
.end method
