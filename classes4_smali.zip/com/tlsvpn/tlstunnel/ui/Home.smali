.class public final Lcom/tlsvpn/tlstunnel/ui/Home;
.super Landroidx/fragment/app/Fragment;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public A:Landroid/widget/TextView;

.field public B:Z

.field public C:Z

.field public D:Landroid/widget/FrameLayout;

.field public E:Landroid/widget/FrameLayout;

.field public F:Ljava/lang/String;

.field public G:I

.field public final H:Lm3;

.field public final I:Lob;

.field public final a:Lw82;

.field public final b:J

.field public c:Landroid/view/View;

.field public d:Landroidx/constraintlayout/widget/ConstraintLayout;

.field public e:Landroid/view/View;

.field public f:Landroid/widget/ImageView;

.field public g:Landroid/widget/ImageView;

.field public h:Landroid/widget/TextView;

.field public i:Landroid/widget/TextView;

.field public j:Landroid/widget/ImageView;

.field public k:Landroid/widget/TextView;

.field public l:Landroid/widget/TextView;

.field public m:Landroidx/constraintlayout/widget/ConstraintLayout;

.field public n:Landroid/widget/ImageView;

.field public o:Landroid/widget/TextView;

.field public p:Landroid/widget/ImageButton;

.field public q:Landroid/view/View;

.field public r:Landroid/widget/ImageButton;

.field public s:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

.field public t:Lho0;

.field public u:Z

.field public v:Landroidx/constraintlayout/widget/ConstraintLayout;

.field public w:Landroid/widget/TextView;

.field public x:Landroid/widget/ImageView;

.field public y:Landroid/widget/ImageView;

.field public z:Landroid/widget/LinearLayout;


# direct methods
.method public constructor <init>()V
    .registers 6

    invoke-direct {p0}, Landroidx/fragment/app/Fragment;-><init>()V

    const/16 v0, 0xa84

    new-instance v2, Ld;

    nop

    const/16 v3, 0xa

    const/16 v0, 0x6cb

    invoke-direct {v2, v3, p0}, Ld;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x27a

    new-instance v3, Lw82;

    nop

    const/16 v0, 0x215

    invoke-direct {v3, v2}, Lw82;-><init>(Lzj0;)V

    const/16 v0, 0xa4d

    iput-object v3, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->a:Lw82;

    const-wide/32 v2, 0x6ddd00

    const/16 v0, 0x92b

    iput-wide v2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->b:J

    const/4 v2, 0x1

    const/16 v0, 0x93e

    iput-boolean v2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->u:Z

    const-string/jumbo v2, ""

    const/16 v0, 0x9ab

    iput-object v2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->F:Ljava/lang/String;

    const/16 v0, 0xa2

    new-instance v2, Ll3;

    nop

    const/4 v3, 0x2

    const/16 v0, 0x9e

    invoke-direct {v2, v3}, Ll3;-><init>(I)V

    const/16 v0, 0x50f

    new-instance v3, Lah;

    nop

    const/4 v4, 0x7

    const/16 v0, 0x3bf

    invoke-direct {v3, v4, p0}, Lah;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0xbe4

    invoke-virtual {p0, v2, v3}, Landroidx/fragment/app/Fragment;->registerForActivityResult(Lk3;Lj3;)Lm3;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xd1a

    iput-object v2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->H:Lm3;

    const/16 v0, 0xf6e

    new-instance v2, Lob;

    nop

    const/4 v3, 0x3

    const/16 v0, 0x11c1

    invoke-direct {v2, v3, p0}, Lob;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x1077

    iput-object v2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->I:Lob;

    return-void
.end method


# virtual methods
.method public final b()Landroid/content/SharedPreferences;
    .registers 3

    const/16 v0, 0xa98

    iget-object p0, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->a:Lw82;

    nop

    const/16 v0, 0x177

    invoke-virtual {p0}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/content/SharedPreferences;

    return-object p0
.end method

.method public final c()V
    .registers 7

    .prologue
    const/16 v0, 0x101

    sget-boolean v2, Lmi2;->n:Z

    nop

    const/4 v3, 0x0

    const-string/jumbo v4, "bannerContainerBCFG"

    const-string/jumbo v5, "bannerContainerDft"

    if-eqz v2, :cond_31

    const/16 v0, 0x508

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->E:Landroid/widget/FrameLayout;

    nop

    if-eqz v2, :cond_2c

    const/16 v5, 0x8

    const/4 v0, -0x5

    invoke-virtual {v2, v5}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0x395

    iget-object p0, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->D:Landroid/widget/FrameLayout;

    nop

    if-eqz p0, :cond_27

    const/4 v0, -0x5

    invoke-virtual {p0, v5}, Landroid/view/View;->setVisibility(I)V

    return-void

    :cond_27
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_2c
    const/4 v0, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_31
    const/16 v0, 0x195

    sget-boolean v2, Lmi2;->d:Z

    nop

    if-eqz v2, :cond_96

    const/16 v0, 0x8f7

    sget-boolean v2, Lg4;->b:Z

    nop

    if-eqz v2, :cond_96

    const/16 v0, 0xd9

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->isAdded()Z

    move-result v2

    if-nez v2, :cond_48

    goto :goto_96

    :cond_48
    const/16 v0, 0x498

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->z:Landroid/widget/LinearLayout;

    nop

    if-eqz v2, :cond_8e

    const/16 v0, 0x631

    invoke-virtual {v2}, Landroid/view/View;->getVisibility()I

    move-result v2

    if-nez v2, :cond_64

    const/16 v0, 0x395

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->D:Landroid/widget/FrameLayout;

    nop

    if-eqz v2, :cond_5f

    goto :goto_6b

    :cond_5f
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_64
    const/16 v0, 0x508

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->E:Landroid/widget/FrameLayout;

    nop

    if-eqz v2, :cond_89

    :goto_6b
    const/16 v0, 0xbfe

    invoke-virtual {v2}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v3

    const/4 v0, -0x6

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v3, Landroid/view/View;

    const/16 v0, 0xd45

    new-instance v4, Lu7;

    nop

    const/16 v5, 0xb

    const/16 v0, 0x1080

    invoke-direct {v4, v5, p0, v2}, Lu7;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    const/16 v0, 0x1156

    invoke-virtual {v3, v4}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    return-void

    :cond_89
    const/4 v0, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_8e
    const-string/jumbo p0, "cfgmensageml"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_96
    :goto_96
    return-void
.end method

.method public final d()V
    .registers 24

    .prologue
    const/16 v6, 0x8ea

    new-instance v8, Lou;

    nop

    const/16 v6, 0xc6

    move-object/from16 v0, p0

    invoke-virtual {v0}, Lcom/tlsvpn/tlstunnel/ui/Home;->b()Landroid/content/SharedPreferences;

    move-result-object v9

    const/4 v6, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x1c6

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getResources()Landroid/content/res/Resources;

    move-result-object v10

    const/4 v6, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v11, 0x0

    const/16 v6, 0x83d

    move v0, v6

    move-object v1, v8

    move-object v2, v9

    move-object v3, v10

    move v4, v11

    move v5, v11

    invoke-direct/range {v1 .. v5}, Lou;-><init>(Landroid/content/SharedPreferences;Landroid/content/res/Resources;ZZ)V

    const/16 v6, 0xb83

    move-object/from16 v0, p0

    iget-object v9, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->e:Landroid/view/View;

    nop

    const/4 v10, 0x0

    if-eqz v9, :cond_59e

    const/16 v6, 0x905

    sget-boolean v12, Lmi2;->a:Z

    nop

    const/16 v6, 0xc6

    move-object/from16 v0, p0

    invoke-virtual {v0}, Lcom/tlsvpn/tlstunnel/ui/Home;->b()Landroid/content/SharedPreferences;

    move-result-object v12

    const/4 v6, -0x6

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x1112

    invoke-static {v12}, Lmi2;->d(Landroid/content/SharedPreferences;)Z

    move-result v12

    const/16 v13, 0x8

    if-eqz v12, :cond_50

    move v12, v11

    goto :goto_51

    :cond_50
    move v12, v13

    :goto_51
    const/4 v6, -0x5

    invoke-virtual {v9, v12}, Landroid/view/View;->setVisibility(I)V

    const/16 v6, 0xf1

    iget-boolean v9, v8, Lou;->c:Z

    nop

    const-string/jumbo v12, "psrvslctd"

    if-eqz v9, :cond_92

    const/16 v6, 0x101

    sget-boolean v9, Lmi2;->n:Z

    nop

    if-nez v9, :cond_92

    const/16 v6, 0x49b

    iput-boolean v11, v8, Lou;->c:Z

    const/16 v6, 0x103

    iput v11, v8, Lou;->d:I

    const/16 v6, 0xc6

    move-object/from16 v0, p0

    invoke-virtual {v0}, Lcom/tlsvpn/tlstunnel/ui/Home;->b()Landroid/content/SharedPreferences;

    move-result-object v9

    const/4 v6, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x7a

    invoke-interface {v9}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v9

    const/16 v6, 0x48

    invoke-interface {v9, v12, v11}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const-string/jumbo v14, "server"

    const/16 v6, 0x56

    invoke-interface {v9, v14, v11}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/16 v6, 0x6f

    invoke-interface {v9}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_92
    const/16 v6, 0x9d

    iget-boolean v9, v8, Lou;->h:Z

    nop

    const/16 v6, 0xe0b

    move-object/from16 v0, p0

    iput-boolean v9, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->C:Z

    const/16 v6, 0xcf

    move-object/from16 v0, p0

    iget-object v9, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->i:Landroid/widget/TextView;

    nop

    const-string/jumbo v14, "servernamefull"

    if-eqz v9, :cond_599

    const/16 v6, 0xc6

    move-object/from16 v0, p0

    invoke-virtual {v0}, Lcom/tlsvpn/tlstunnel/ui/Home;->b()Landroid/content/SharedPreferences;

    move-result-object v15

    const-string/jumbo v16, "cname"

    const/16 v17, 0x1

    const/16 v6, 0x77

    move-object/from16 v0, v16

    move/from16 v1, v17

    invoke-interface {v15, v0, v1}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v15

    if-eqz v15, :cond_c4

    move v15, v11

    goto :goto_c5

    :cond_c4
    move v15, v13

    :goto_c5
    const/4 v6, -0x5

    invoke-virtual {v9, v15}, Landroid/view/View;->setVisibility(I)V

    const/16 v6, 0xc6

    move-object/from16 v0, p0

    invoke-virtual {v0}, Lcom/tlsvpn/tlstunnel/ui/Home;->b()Landroid/content/SharedPreferences;

    move-result-object v9

    const-string/jumbo v15, "atcountdown"

    const/16 v6, 0x77

    move/from16 v0, v17

    invoke-interface {v9, v15, v0}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v9

    const/16 v6, 0x93e

    move-object/from16 v0, p0

    iput-boolean v9, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->u:Z

    const/16 v6, 0x182

    move-object/from16 v0, p0

    invoke-virtual {v0}, Lcom/tlsvpn/tlstunnel/ui/Home;->g()V

    const/16 v6, 0x5b6

    move-object/from16 v0, p0

    invoke-virtual {v0}, Lcom/tlsvpn/tlstunnel/ui/Home;->e()V

    const/16 v6, 0x75

    iget-boolean v9, v8, Lou;->w:Z

    nop

    const-string/jumbo v15, "cfgmensageml"

    const-string/jumbo v16, "mtdName"

    const-string/jumbo v18, "editcfgImg"

    const-string/jumbo v19, "cfgmethod"

    const-string/jumbo v20, "serverport"

    if-eqz v9, :cond_262

    const/16 v6, 0x7ec

    iget-boolean v9, v8, Lou;->y:Z

    nop

    if-eqz v9, :cond_197

    const/16 v6, 0x2b

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v9

    const/4 v6, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xa5c

    invoke-static {v9}, Lmi2;->f(Landroid/content/Context;)Z

    move-result v9

    if-eqz v9, :cond_197

    const/16 v6, 0x5b

    new-instance v8, Landroid/content/Intent;

    nop

    const/16 v6, 0x2b

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v9

    const-class v10, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;

    const/16 v6, 0xd0

    invoke-direct {v8, v9, v10}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const v9, 0x7f130045

    const/16 v6, 0x4c

    move-object/from16 v0, p0

    invoke-virtual {v0, v9}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v9

    const-string/jumbo v10, "msg"

    const/16 v6, 0x4b

    invoke-virtual {v8, v10, v9}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string/jumbo v9, "atype"

    const-string/jumbo v10, "atmsgonly"

    const/16 v6, 0x4b

    invoke-virtual {v8, v9, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/16 v6, 0x634

    move-object/from16 v0, p0

    invoke-virtual {v0, v8}, Landroidx/fragment/app/Fragment;->startActivity(Landroid/content/Intent;)V

    const/16 v6, 0xfb

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object v8

    const/16 v6, 0x5b

    new-instance v9, Landroid/content/Intent;

    nop

    const-string/jumbo v10, "resetCfgFromMain"

    const/16 v6, 0x62

    invoke-direct {v9, v10}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v6, 0x2b

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p0

    const/16 v6, 0x53

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/16 v6, 0x4a

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/16 v6, 0x64

    move-object/from16 v0, p0

    invoke-virtual {v9, v0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    const/16 v6, 0x63

    move-object/from16 v0, p0

    invoke-virtual {v8, v0}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    return-void

    :cond_197
    const/16 v6, 0x32f

    move-object/from16 v0, p0

    move/from16 v1, v17

    iput-boolean v1, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->B:Z

    const/16 v6, 0x52c

    move-object/from16 v0, p0

    iget-object v9, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->v:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz v9, :cond_25b

    const/16 v6, 0xf7

    invoke-virtual {v9, v11}, Landroid/view/View;->setEnabled(Z)V

    const/16 v6, 0x32c

    move-object/from16 v0, p0

    iget-object v9, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->x:Landroid/widget/ImageView;

    nop

    if-eqz v9, :cond_254

    const v18, 0x7f08010c

    const/16 v6, 0x87

    move/from16 v0, v18

    invoke-virtual {v9, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    const/16 v6, 0x449

    move-object/from16 v0, p0

    iget-object v9, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->w:Landroid/widget/TextView;

    nop

    if-eqz v9, :cond_24d

    const v16, 0x7f130068

    const/16 v6, 0x93

    move/from16 v0, v16

    invoke-virtual {v9, v0}, Landroid/widget/TextView;->setText(I)V

    const/16 v6, 0x498

    move-object/from16 v0, p0

    iget-object v9, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->z:Landroid/widget/LinearLayout;

    nop

    if-eqz v9, :cond_248

    const/16 v6, 0x4d6

    iget-object v15, v8, Lou;->B:Ljava/lang/String;

    nop

    const/16 v6, 0x47

    invoke-virtual {v15}, Ljava/lang/String;->length()I

    move-result v15

    if-lez v15, :cond_1eb

    move v15, v11

    goto :goto_1ec

    :cond_1eb
    move v15, v13

    :goto_1ec
    const/4 v6, -0x5

    invoke-virtual {v9, v15}, Landroid/view/View;->setVisibility(I)V

    const/16 v6, 0x344

    move-object/from16 v0, p0

    iget-object v9, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->A:Landroid/widget/TextView;

    nop

    const-string/jumbo v15, "cfgmensagem"

    if-eqz v9, :cond_243

    const/16 v6, 0x4d6

    iget-object v6, v8, Lou;->B:Ljava/lang/String;

    move-object/16 v16, v6

    const-string/jumbo v18, "\\"

    const-string/jumbo v19, ""

    const/16 v6, 0x1a

    move-object/from16 v0, v16

    move-object/from16 v1, v18

    move-object/from16 v2, v19

    invoke-static {v0, v1, v2, v11}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v16

    const/16 v18, 0x3f

    const/16 v6, 0x9b4

    move-object/from16 v0, v16

    move/from16 v1, v18

    invoke-static {v0, v1}, Landroid/text/Html;->fromHtml(Ljava/lang/String;I)Landroid/text/Spanned;

    move-result-object v16

    const/16 v6, 0x8a

    move-object/from16 v0, v16

    invoke-virtual {v9, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v6, 0x344

    move-object/from16 v0, p0

    iget-object v9, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->A:Landroid/widget/TextView;

    nop

    if-eqz v9, :cond_23e

    const/16 v6, 0xb9c

    invoke-static {}, Landroid/text/method/LinkMovementMethod;->getInstance()Landroid/text/method/MovementMethod;

    move-result-object v15

    const/16 v6, 0xfc1

    invoke-virtual {v9, v15}, Landroid/widget/TextView;->setMovementMethod(Landroid/text/method/MovementMethod;)V

    goto/16 :goto_2f8

    :cond_23e
    const/4 v6, 0x5

    invoke-static {v15}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_243
    const/4 v6, 0x5

    invoke-static {v15}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_248
    const/4 v6, 0x5

    invoke-static {v15}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_24d
    const/4 v6, 0x5

    move-object/from16 v0, v16

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_254
    const/4 v6, 0x5

    move-object/from16 v0, v18

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_25b
    const/4 v6, 0x5

    move-object/from16 v0, v19

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_262
    const/16 v6, 0x32f

    move-object/from16 v0, p0

    iput-boolean v11, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->B:Z

    const/16 v6, 0x52c

    move-object/from16 v0, p0

    iget-object v9, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->v:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz v9, :cond_592

    const/16 v6, 0xf7

    move/from16 v0, v17

    invoke-virtual {v9, v0}, Landroid/view/View;->setEnabled(Z)V

    const/16 v6, 0x32c

    move-object/from16 v0, p0

    iget-object v9, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->x:Landroid/widget/ImageView;

    nop

    if-eqz v9, :cond_58b

    const v18, 0x7f080101

    const/16 v6, 0x87

    move/from16 v0, v18

    invoke-virtual {v9, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    const/16 v6, 0x1c6

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getResources()Landroid/content/res/Resources;

    move-result-object v9

    const v18, 0x7f030004

    const/16 v6, 0x3e2

    move/from16 v0, v18

    invoke-virtual {v9, v0}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v9

    const/4 v6, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x449

    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->w:Landroid/widget/TextView;

    move-object/16 v18, v6

    if-eqz v18, :cond_584

    const/16 v6, 0x1b8

    iget v6, v8, Lou;->m:I

    move/16 v16, v6

    const/16 v6, 0x5e8

    move/from16 v0, v16

    invoke-static {v0, v9}, Laf;->k0(I[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v16

    check-cast v16, Ljava/lang/String;

    if-eqz v16, :cond_2c1

    goto :goto_2cb

    :cond_2c1
    const/16 v6, 0x86d

    invoke-static {v9}, Laf;->j0([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v9

    move-object/from16 v16, v9

    check-cast v16, Ljava/lang/CharSequence;

    :goto_2cb
    const/16 v6, 0x8a

    move-object/from16 v0, v18

    move-object/from16 v1, v16

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v6, 0x14b

    move-object/from16 v0, p0

    iget-object v9, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->k:Landroid/widget/TextView;

    nop

    if-eqz v9, :cond_57d

    const/16 v6, 0x34a

    iget-object v6, v8, Lou;->g:Ljava/lang/String;

    move-object/16 v16, v6

    const/16 v6, 0x8a

    move-object/from16 v0, v16

    invoke-virtual {v9, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v6, 0x498

    move-object/from16 v0, p0

    iget-object v9, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->z:Landroid/widget/LinearLayout;

    nop

    if-eqz v9, :cond_578

    const/4 v6, -0x5

    invoke-virtual {v9, v13}, Landroid/view/View;->setVisibility(I)V

    :goto_2f8
    const/16 v6, 0x102a

    move-object/from16 v0, p0

    iget-object v9, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->l:Landroid/widget/TextView;

    nop

    if-eqz v9, :cond_56e

    const/4 v6, -0x5

    invoke-virtual {v9, v11}, Landroid/view/View;->setVisibility(I)V

    const/16 v6, 0x14b

    move-object/from16 v0, p0

    iget-object v9, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->k:Landroid/widget/TextView;

    nop

    if-eqz v9, :cond_567

    const/4 v6, -0x5

    invoke-virtual {v9, v11}, Landroid/view/View;->setVisibility(I)V

    const/16 v6, 0x9d

    iget-boolean v9, v8, Lou;->h:Z

    nop

    const v15, 0x7f080113

    const-string/jumbo v16, "serverflag"

    const-string/jumbo v18, "servername"

    if-nez v9, :cond_4e8

    const/16 v6, 0x3b

    iget-object v9, v8, Lou;->i:Ljava/lang/String;

    nop

    const/16 v6, 0x9ab

    move-object/from16 v0, p0

    iput-object v9, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->F:Ljava/lang/String;

    const/16 v6, 0x11f

    iget v6, v8, Lou;->d:I

    move/16 v19, v6

    const/16 v6, 0x91e

    move-object/from16 v0, p0

    move/from16 v1, v19

    iput v1, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->G:I

    const/16 v6, 0x37d

    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->h:Landroid/widget/TextView;

    move-object/16 v21, v6

    const/16 v22, 0x2

    if-nez v19, :cond_3a4

    if-eqz v21, :cond_39d

    const v9, 0x7f130039

    const/16 v6, 0x4c

    move-object/from16 v0, p0

    invoke-virtual {v0, v9}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v9

    const/16 v6, 0x8a

    move-object/from16 v0, v21

    invoke-virtual {v0, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v6, 0xcf

    move-object/from16 v0, p0

    iget-object v9, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->i:Landroid/widget/TextView;

    nop

    if-eqz v9, :cond_398

    const/4 v6, -0x5

    invoke-virtual {v9, v13}, Landroid/view/View;->setVisibility(I)V

    const/16 v6, 0xc6

    move-object/from16 v0, p0

    invoke-virtual {v0}, Lcom/tlsvpn/tlstunnel/ui/Home;->b()Landroid/content/SharedPreferences;

    move-result-object v9

    const/16 v6, 0x77

    invoke-interface {v9, v12, v11}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v9

    const/16 v6, 0x26d

    move-object/from16 v0, p0

    iget-object v12, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->f:Landroid/widget/ImageView;

    nop

    if-eqz v12, :cond_391

    if-eqz v9, :cond_387

    const v9, 0x7f08010d

    goto :goto_38a

    :cond_387
    const v9, 0x7f080114

    :goto_38a
    const/16 v6, 0x87

    invoke-virtual {v12, v9}, Landroid/widget/ImageView;->setImageResource(I)V

    goto/16 :goto_41e

    :cond_391
    const/4 v6, 0x5

    move-object/from16 v0, v16

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_398
    const/4 v6, 0x5

    invoke-static {v14}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_39d
    const/4 v6, 0x5

    move-object/from16 v0, v18

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_3a4
    if-eqz v21, :cond_4e1

    move/from16 v0, v17

    new-array v12, v0, [C

    const/16 v17, 0x2e

    aput-char v17, v12, v11

    const/16 v6, 0x31

    invoke-static {v9, v12}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v9

    const/16 v6, 0x24

    invoke-interface {v9, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    const/16 v6, 0x1f7

    sget-object v12, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    nop

    const/16 v6, 0x12d

    invoke-virtual {v9, v12}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v9

    const/4 v6, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x8a

    move-object/from16 v0, v21

    invoke-virtual {v0, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v6, 0x52b

    sget-object v9, Ldz;->a:Lcz;

    nop

    const/16 v6, 0x3b

    iget-object v9, v8, Lou;->i:Ljava/lang/String;

    nop

    const/16 v6, 0x196

    move/from16 v0, v22

    invoke-static {v0, v9}, Lc72;->G0(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const/16 v6, 0x3b0

    invoke-virtual {v9, v12}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v9

    const/4 v6, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x334

    invoke-static {v9}, Ldz;->a(Ljava/lang/String;)Lcz;

    move-result-object v9

    const/16 v6, 0x26d

    move-object/from16 v0, p0

    iget-object v12, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->f:Landroid/widget/ImageView;

    nop

    if-eqz v12, :cond_4da

    const/16 v6, 0x3c6

    iget v6, v9, Lcz;->a:I

    move/16 v16, v6

    const/16 v6, 0x87

    move/from16 v0, v16

    invoke-virtual {v12, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    const/16 v6, 0xcf

    move-object/from16 v0, p0

    iget-object v12, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->i:Landroid/widget/TextView;

    nop

    if-eqz v12, :cond_4d5

    const/16 v6, 0x36f

    iget v9, v9, Lcz;->b:I

    nop

    const/16 v6, 0x93

    invoke-virtual {v12, v9}, Landroid/widget/TextView;->setText(I)V

    :goto_41e
    const/16 v6, 0x1ff

    sget v9, Lmi2;->o:I

    nop

    const/4 v12, 0x3

    const-string/jumbo v14, "connectedSsflag"

    if-ne v9, v12, :cond_4a2

    const/16 v6, 0x272

    sget-object v9, Lmi2;->m:Ljava/lang/String;

    nop

    const/16 v6, 0x3b

    iget-object v12, v8, Lou;->i:Ljava/lang/String;

    nop

    const/16 v6, 0x84

    invoke-static {v9, v12}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_4a2

    const/16 v6, 0x52b

    sget-object v9, Ldz;->a:Lcz;

    nop

    const/16 v6, 0x272

    sget-object v9, Lmi2;->m:Ljava/lang/String;

    nop

    const/16 v6, 0x196

    move/from16 v0, v22

    invoke-static {v0, v9}, Lc72;->G0(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const/16 v6, 0x1f7

    sget-object v12, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    nop

    const/16 v6, 0x3b0

    invoke-virtual {v9, v12}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v9

    const/4 v6, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x334

    invoke-static {v9}, Ldz;->a(Ljava/lang/String;)Lcz;

    move-result-object v9

    const/16 v6, 0x307

    sget-boolean v12, Lmi2;->k:Z

    nop

    const/16 v6, 0x1ea

    move-object/from16 v0, p0

    iget-object v13, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->g:Landroid/widget/ImageView;

    nop

    if-eqz v12, :cond_482

    if-eqz v13, :cond_47d

    const/16 v6, 0x3c6

    iget v9, v9, Lcz;->a:I

    nop

    const/16 v6, 0x87

    invoke-virtual {v13, v9}, Landroid/widget/ImageView;->setImageResource(I)V

    goto :goto_489

    :cond_47d
    const/4 v6, 0x5

    invoke-static {v14}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_482
    if-eqz v13, :cond_49d

    const/16 v6, 0x87

    invoke-virtual {v13, v15}, Landroid/widget/ImageView;->setImageResource(I)V

    :goto_489
    const/16 v6, 0x1ea

    move-object/from16 v0, p0

    iget-object v9, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->g:Landroid/widget/ImageView;

    nop

    if-eqz v9, :cond_498

    const/16 v6, 0x23d

    invoke-virtual {v9, v11}, Landroid/widget/ImageView;->setVisibility(I)V

    goto :goto_4b0

    :cond_498
    const/4 v6, 0x5

    invoke-static {v14}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_49d
    const/4 v6, 0x5

    invoke-static {v14}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_4a2
    const/16 v6, 0x1ea

    move-object/from16 v0, p0

    iget-object v9, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->g:Landroid/widget/ImageView;

    nop

    if-eqz v9, :cond_4d0

    const/16 v6, 0x23d

    invoke-virtual {v9, v13}, Landroid/widget/ImageView;->setVisibility(I)V

    :goto_4b0
    const/16 v6, 0x14b

    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->k:Landroid/widget/TextView;

    move-object/16 p0, v6

    if-eqz p0, :cond_4c9

    const/16 v6, 0x34a

    iget-object v9, v8, Lou;->g:Ljava/lang/String;

    nop

    const/16 v6, 0x8a

    move-object/from16 v0, p0

    invoke-virtual {v0, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto/16 :goto_549

    :cond_4c9
    const/4 v6, 0x5

    move-object/from16 v0, v20

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_4d0
    const/4 v6, 0x5

    invoke-static {v14}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_4d5
    const/4 v6, 0x5

    invoke-static {v14}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_4da
    const/4 v6, 0x5

    move-object/from16 v0, v16

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_4e1
    const/4 v6, 0x5

    move-object/from16 v0, v18

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_4e8
    const/16 v6, 0x37d

    move-object/from16 v0, p0

    iget-object v9, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->h:Landroid/widget/TextView;

    nop

    if-eqz v9, :cond_560

    const v11, 0x7f130202

    const/16 v6, 0x93

    invoke-virtual {v9, v11}, Landroid/widget/TextView;->setText(I)V

    const/16 v6, 0xcf

    move-object/from16 v0, p0

    iget-object v9, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->i:Landroid/widget/TextView;

    nop

    if-eqz v9, :cond_55b

    const v11, 0x7f1301d0

    const/16 v6, 0x93

    invoke-virtual {v9, v11}, Landroid/widget/TextView;->setText(I)V

    const/16 v6, 0xcf

    move-object/from16 v0, p0

    iget-object v9, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->i:Landroid/widget/TextView;

    nop

    if-eqz v9, :cond_556

    const/4 v6, -0x5

    invoke-virtual {v9, v13}, Landroid/view/View;->setVisibility(I)V

    const/16 v6, 0x26d

    move-object/from16 v0, p0

    iget-object v9, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->f:Landroid/widget/ImageView;

    nop

    if-eqz v9, :cond_54f

    const/16 v6, 0x87

    invoke-virtual {v9, v15}, Landroid/widget/ImageView;->setImageResource(I)V

    const/16 v6, 0x75

    iget-boolean v9, v8, Lou;->w:Z

    nop

    if-eqz v9, :cond_549

    const/16 v6, 0x14b

    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->k:Landroid/widget/TextView;

    move-object/16 p0, v6

    if-eqz p0, :cond_542

    const-string/jumbo v9, "T ****"

    const/16 v6, 0x8a

    move-object/from16 v0, p0

    invoke-virtual {v0, v9}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_549

    :cond_542
    const/4 v6, 0x5

    move-object/from16 v0, v20

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_549
    :goto_549
    const/16 v6, 0x20c

    invoke-virtual {v8}, Lou;->a()V

    return-void

    :cond_54f
    const/4 v6, 0x5

    move-object/from16 v0, v16

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_556
    const/4 v6, 0x5

    invoke-static {v14}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_55b
    const/4 v6, 0x5

    invoke-static {v14}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_560
    const/4 v6, 0x5

    move-object/from16 v0, v18

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_567
    const/4 v6, 0x5

    move-object/from16 v0, v20

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_56e
    const-string/jumbo p0, "porthint"

    const/4 v6, 0x5

    move-object/from16 v0, p0

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_578
    const/4 v6, 0x5

    invoke-static {v15}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_57d
    const/4 v6, 0x5

    move-object/from16 v0, v20

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_584
    const/4 v6, 0x5

    move-object/from16 v0, v16

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_58b
    const/4 v6, 0x5

    move-object/from16 v0, v18

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_592
    const/4 v6, 0x5

    move-object/from16 v0, v19

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_599
    const/4 v6, 0x5

    invoke-static {v14}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_59e
    const-string/jumbo p0, "sserverRedDot"

    const/4 v6, 0x5

    move-object/from16 v0, p0

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10
.end method

.method public final e()V
    .registers 13

    .prologue
    const/16 v0, 0xd5

    new-instance v2, Landroid/util/TypedValue;

    nop

    const/16 v0, 0xe7

    invoke-direct {v2}, Landroid/util/TypedValue;-><init>()V

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v3

    const/16 v0, 0x1a9

    invoke-virtual {v3}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v3

    const/16 v0, 0x35f

    iget-boolean v4, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->C:Z

    nop

    const/4 v5, 0x1

    const v6, 0x7f0402b1

    if-eqz v4, :cond_23

    goto/16 :goto_ad

    :cond_23
    const/16 v0, 0xc6

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/Home;->b()Landroid/content/SharedPreferences;

    move-result-object v4

    const-string/jumbo v7, "psrvslctd"

    const/4 v8, 0x0

    const/16 v0, 0x77

    invoke-interface {v4, v7, v8}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v4

    const/16 v0, 0xc6

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/Home;->b()Landroid/content/SharedPreferences;

    move-result-object v7

    const-string/jumbo v9, "server"

    const/16 v0, 0xb0

    invoke-interface {v7, v9, v8}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v7

    const/16 v0, 0xc6

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/Home;->b()Landroid/content/SharedPreferences;

    move-result-object v9

    const/4 v0, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x1c6

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getResources()Landroid/content/res/Resources;

    move-result-object v10

    const/4 v0, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v11, 0x3

    if-eqz v4, :cond_5b

    move v4, v11

    goto :goto_5c

    :cond_5b
    move v4, v8

    :goto_5c
    const/16 v0, 0x4fe

    invoke-static {v9, v10, v4}, Lqk;->p(Landroid/content/SharedPreferences;Landroid/content/res/Resources;I)[Ljava/lang/String;

    move-result-object v4

    array-length v9, v4

    if-lt v7, v9, :cond_66

    move v7, v8

    :cond_66
    const/16 v0, 0x5e8

    invoke-static {v7, v4}, Laf;->k0(I[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    if-eqz v4, :cond_94

    const/16 v0, 0xc6

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/Home;->b()Landroid/content/SharedPreferences;

    move-result-object v9

    const/16 v0, 0x1f7

    sget-object v10, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    nop

    const/16 v0, 0x3b0

    invoke-virtual {v4, v10}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v4

    const/4 v0, -0x6

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string/jumbo v10, "-status"

    const/16 v0, 0xee

    invoke-virtual {v4, v10}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/16 v0, 0xb0

    invoke-interface {v9, v4, v8}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v8

    :cond_94
    if-nez v7, :cond_97

    goto :goto_ad

    :cond_97
    if-eq v8, v5, :cond_aa

    const/4 v4, 0x2

    if-eq v8, v4, :cond_a6

    if-eq v8, v11, :cond_a2

    const v6, 0x7f040117

    goto :goto_ad

    :cond_a2
    const v6, 0x7f0402b2

    goto :goto_ad

    :cond_a6
    const v6, 0x7f0402b3

    goto :goto_ad

    :cond_aa
    const v6, 0x7f0402af

    :goto_ad
    const/16 v0, 0x68

    invoke-virtual {v3, v6, v2, v5}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    const/16 v0, 0x114e

    iget-object p0, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->j:Landroid/widget/ImageView;

    nop

    if-eqz p0, :cond_ca

    const/16 v0, 0x9b

    iget v2, v2, Landroid/util/TypedValue;->data:I

    nop

    const/16 v0, 0x171

    invoke-static {v2}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v2

    const/16 v0, 0x172

    invoke-virtual {p0, v2}, Landroid/widget/ImageView;->setImageTintList(Landroid/content/res/ColorStateList;)V

    return-void

    :cond_ca
    const-string/jumbo p0, "sstatus"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0
.end method

.method public final f(Landroid/view/View;)V
    .registers 8

    .prologue
    const/16 v0, 0x905

    sget-boolean v2, Lmi2;->a:Z

    nop

    const/16 v0, 0x101

    sget-boolean v2, Lmi2;->n:Z

    nop

    if-nez v2, :cond_d

    return-void

    :cond_d
    const v2, 0x7f090392

    const/16 v0, 0x11

    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/ImageView;

    const v3, 0x7f08013a

    const/16 v0, 0x87

    invoke-virtual {v2, v3}, Landroid/widget/ImageView;->setImageResource(I)V

    const v2, 0x7f090393

    const/16 v0, 0x11

    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/TextView;

    const/16 v0, 0xd5

    new-instance v2, Landroid/util/TypedValue;

    nop

    const/16 v0, 0xe7

    invoke-direct {v2}, Landroid/util/TypedValue;-><init>()V

    const/16 v0, 0xa89

    sget-boolean v3, Lmi2;->h:Z

    nop

    const v4, 0x7f04046f

    const/4 v5, 0x1

    if-eqz v3, :cond_52

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v3

    const/16 v0, 0x1a9

    invoke-virtual {v3}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v3

    const/16 v0, 0x68

    invoke-virtual {v3, v4, v2, v5}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    goto :goto_63

    :cond_52
    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v3

    const/16 v0, 0x1a9

    invoke-virtual {v3}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v3

    const/16 v0, 0x68

    invoke-virtual {v3, v4, v2, v5}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    :goto_63
    const v3, 0xffffff

    const/16 v0, 0x9b

    iget v2, v2, Landroid/util/TypedValue;->data:I

    nop

    and-int/2addr v2, v3

    const/16 v0, 0xb1

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v2

    const/16 v0, 0x120e

    invoke-static {v2, v5}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v2

    const-string/jumbo v3, "#%06X"

    const/16 v0, 0x377

    invoke-static {v3, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const/4 v0, -0x3

    new-instance v3, Ljava/lang/StringBuilder;

    nop

    const/4 v0, -0x4

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const v4, 0x7f130024

    const/16 v0, 0x4c

    invoke-virtual {p0, v4}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v4

    const/4 v0, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v4, " <font color=\""

    const/4 v0, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v2, "\"><b>PRO</b>"

    const/4 v0, 0x0

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/16 v3, 0x3f

    const/16 v0, 0x9b4

    invoke-static {v2, v3}, Landroid/text/Html;->fromHtml(Ljava/lang/String;I)Landroid/text/Spanned;

    move-result-object v2

    const/16 v0, 0x8a

    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v0, 0x508

    iget-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->E:Landroid/widget/FrameLayout;

    nop

    const/4 v2, 0x0

    if-eqz p1, :cond_e0

    const/16 v3, 0x8

    const/4 v0, -0x5

    invoke-virtual {p1, v3}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0x395

    iget-object p0, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->D:Landroid/widget/FrameLayout;

    nop

    if-eqz p0, :cond_d8

    const/4 v0, -0x5

    invoke-virtual {p0, v3}, Landroid/view/View;->setVisibility(I)V

    return-void

    :cond_d8
    const-string/jumbo p0, "bannerContainerBCFG"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v2

    :cond_e0
    const-string/jumbo p0, "bannerContainerDft"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v2
.end method

.method public final g()V
    .registers 23

    .prologue
    move-object/from16 v4, p0

    const/16 v2, 0x5b6

    invoke-virtual {v4}, Lcom/tlsvpn/tlstunnel/ui/Home;->e()V

    const/16 v2, 0x1ff

    sget v5, Lmi2;->o:I

    nop

    const/4 v6, 0x0

    const/4 v7, 0x4

    const-string/jumbo v8, "btnStartStopImg"

    const-string/jumbo v9, "btnStartStopTxt"

    const-string/jumbo v10, "btnReconnect"

    const-string/jumbo v11, "btnAddTimeRedDot"

    const-string/jumbo v12, "btnAddTime"

    const-string/jumbo v13, "progressConnecting"

    const/16 v14, 0x8

    const/4 v15, 0x0

    if-eqz v5, :cond_317

    const v16, 0x7f08011d

    const/16 v17, 0x1

    move/from16 v0, v17

    if-eq v5, v0, :cond_296

    const/16 v18, 0x2

    move/from16 v0, v18

    if-eq v5, v0, :cond_215

    const/16 v18, 0x3

    move/from16 v0, v18

    if-eq v5, v0, :cond_be

    if-eq v5, v7, :cond_3d

    return-void

    :cond_3d
    const/16 v2, 0x7b

    iget-object v5, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->p:Landroid/widget/ImageButton;

    nop

    if-eqz v5, :cond_b9

    const/4 v2, -0x5

    invoke-virtual {v5, v14}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0xb6

    iget-object v5, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->q:Landroid/view/View;

    nop

    if-eqz v5, :cond_b4

    const/4 v2, -0x5

    invoke-virtual {v5, v14}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0x102

    iget-object v5, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->r:Landroid/widget/ImageButton;

    nop

    if-eqz v5, :cond_af

    const/4 v2, -0x5

    invoke-virtual {v5, v15}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0x54

    iget-object v5, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->s:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    nop

    if-eqz v5, :cond_aa

    const/16 v2, 0xd3

    move/from16 v0, v17

    invoke-virtual {v5, v0}, Lki;->setIndeterminate(Z)V

    const/16 v2, 0x54

    iget-object v5, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->s:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    nop

    if-eqz v5, :cond_a5

    const/16 v2, 0xe4

    invoke-virtual {v5, v15}, Lki;->setProgress(I)V

    const/16 v2, 0xa9

    invoke-virtual {v4}, Lcom/tlsvpn/tlstunnel/ui/Home;->j()V

    const/16 v2, 0xef

    iget-object v5, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->o:Landroid/widget/TextView;

    nop

    if-eqz v5, :cond_a0

    const v7, 0x7f13024e

    const/16 v2, 0x93

    invoke-virtual {v5, v7}, Landroid/widget/TextView;->setText(I)V

    const/16 v2, 0xfd

    iget-object v4, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->n:Landroid/widget/ImageView;

    nop

    if-eqz v4, :cond_9b

    const/16 v2, 0x87

    move/from16 v0, v16

    invoke-virtual {v4, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    return-void

    :cond_9b
    const/4 v2, 0x5

    invoke-static {v8}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_a0
    const/4 v2, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_a5
    const/4 v2, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_aa
    const/4 v2, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_af
    const/4 v2, 0x5

    invoke-static {v10}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_b4
    const/4 v2, 0x5

    invoke-static {v11}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_b9
    const/4 v2, 0x5

    invoke-static {v12}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_be
    const/16 v2, 0x7b

    iget-object v5, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->p:Landroid/widget/ImageButton;

    nop

    if-eqz v5, :cond_210

    const/16 v2, 0x307

    sget-boolean v7, Lmi2;->k:Z

    nop

    if-eqz v7, :cond_d5

    const/16 v2, 0x101

    sget-boolean v7, Lmi2;->n:Z

    nop

    if-nez v7, :cond_d5

    move v7, v15

    goto :goto_d6

    :cond_d5
    move v7, v14

    :goto_d6
    const/4 v2, -0x5

    invoke-virtual {v5, v7}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0xb6

    iget-object v5, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->q:Landroid/view/View;

    nop

    if-eqz v5, :cond_20b

    const/16 v2, 0x307

    sget-boolean v7, Lmi2;->k:Z

    nop

    if-eqz v7, :cond_120

    const/16 v2, 0x101

    sget-boolean v7, Lmi2;->n:Z

    nop

    if-nez v7, :cond_120

    const/16 v2, 0x22b

    sget-object v7, Lg4;->A:Lxu1;

    nop

    if-eqz v7, :cond_120

    const/16 v2, 0x7b

    iget-object v7, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->p:Landroid/widget/ImageButton;

    nop

    if-eqz v7, :cond_11b

    const/16 v2, 0x692

    invoke-virtual {v7}, Landroid/view/View;->isEnabled()Z

    move-result v7

    if-eqz v7, :cond_120

    const/16 v2, 0x7b

    iget-object v7, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->p:Landroid/widget/ImageButton;

    nop

    if-eqz v7, :cond_116

    const/16 v2, 0x631

    invoke-virtual {v7}, Landroid/view/View;->getVisibility()I

    move-result v7

    if-nez v7, :cond_120

    move v14, v15

    goto :goto_120

    :cond_116
    const/4 v2, 0x5

    invoke-static {v12}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_11b
    const/4 v2, 0x5

    invoke-static {v12}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_120
    :goto_120
    const/4 v2, -0x5

    invoke-virtual {v5, v14}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0x102

    iget-object v5, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->r:Landroid/widget/ImageButton;

    nop

    if-eqz v5, :cond_206

    const/4 v2, -0x5

    invoke-virtual {v5, v15}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0x26f

    sget-wide v18, Lmi2;->i:J

    nop

    const/16 v2, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v20

    sub-long v18, v18, v20

    const/16 v2, 0xb6

    iget-object v5, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->q:Landroid/view/View;

    nop

    if-eqz v5, :cond_201

    const/16 v2, 0xbae

    iget-wide v10, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->b:J

    nop

    cmp-long v7, v18, v10

    if-gez v7, :cond_150

    const v7, 0x7f080081

    goto :goto_153

    :cond_150
    const v7, 0x7f080082

    :goto_153
    const/16 v2, 0xb4b

    invoke-virtual {v5, v7}, Landroid/view/View;->setBackgroundResource(I)V

    const/16 v2, 0x7b

    iget-object v5, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->p:Landroid/widget/ImageButton;

    nop

    if-eqz v5, :cond_1fc

    const/16 v2, 0x26f

    sget-wide v10, Lmi2;->i:J

    nop

    const/16 v2, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v18

    sub-long v10, v10, v18

    const/16 v2, 0x29a

    sget-wide v18, Lmi2;->j:J

    nop

    cmp-long v7, v10, v18

    if-gez v7, :cond_176

    goto :goto_178

    :cond_176
    move/from16 v17, v15

    :goto_178
    const/16 v2, 0xf7

    move/from16 v0, v17

    invoke-virtual {v5, v0}, Landroid/view/View;->setEnabled(Z)V

    const/16 v2, 0x54

    iget-object v5, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->s:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    nop

    if-eqz v5, :cond_1f7

    const/16 v2, 0xd3

    invoke-virtual {v5, v15}, Lki;->setIndeterminate(Z)V

    const/16 v2, 0x54

    iget-object v5, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->s:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    nop

    if-eqz v5, :cond_1f2

    const/16 v7, 0x64

    const/16 v2, 0xe4

    invoke-virtual {v5, v7}, Lki;->setProgress(I)V

    const/16 v2, 0xb84

    iget-boolean v5, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->u:Z

    nop

    if-eqz v5, :cond_1c5

    const/16 v2, 0x26f

    sget-wide v9, Lmi2;->i:J

    nop

    const/16 v2, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v11

    sub-long/2addr v9, v11

    const/16 v2, 0xa9

    invoke-virtual {v4}, Lcom/tlsvpn/tlstunnel/ui/Home;->j()V

    const/16 v2, 0x806

    new-instance v5, Lho0;

    nop

    const/16 v2, 0xa37

    invoke-direct {v5, v4, v9, v10}, Lho0;-><init>(Lcom/tlsvpn/tlstunnel/ui/Home;J)V

    const/16 v2, 0x10ac

    iput-object v5, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->t:Lho0;

    const/16 v2, 0xcf1

    invoke-virtual {v5}, Landroid/os/CountDownTimer;->start()Landroid/os/CountDownTimer;

    goto :goto_1d9

    :cond_1c5
    const/16 v2, 0xa9

    invoke-virtual {v4}, Lcom/tlsvpn/tlstunnel/ui/Home;->j()V

    const/16 v2, 0xef

    iget-object v5, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->o:Landroid/widget/TextView;

    nop

    if-eqz v5, :cond_1ed

    const v7, 0x7f13024d

    const/16 v2, 0x93

    invoke-virtual {v5, v7}, Landroid/widget/TextView;->setText(I)V

    :goto_1d9
    const/16 v2, 0xfd

    iget-object v4, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->n:Landroid/widget/ImageView;

    nop

    if-eqz v4, :cond_1e8

    const/16 v2, 0x87

    move/from16 v0, v16

    invoke-virtual {v4, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    return-void

    :cond_1e8
    const/4 v2, 0x5

    invoke-static {v8}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_1ed
    const/4 v2, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_1f2
    const/4 v2, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_1f7
    const/4 v2, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_1fc
    const/4 v2, 0x5

    invoke-static {v12}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_201
    const/4 v2, 0x5

    invoke-static {v11}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_206
    const/4 v2, 0x5

    invoke-static {v10}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_20b
    const/4 v2, 0x5

    invoke-static {v11}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_210
    const/4 v2, 0x5

    invoke-static {v12}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_215
    const/16 v2, 0x7b

    iget-object v5, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->p:Landroid/widget/ImageButton;

    nop

    if-eqz v5, :cond_291

    const/4 v2, -0x5

    invoke-virtual {v5, v14}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0xb6

    iget-object v5, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->q:Landroid/view/View;

    nop

    if-eqz v5, :cond_28c

    const/4 v2, -0x5

    invoke-virtual {v5, v14}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0x102

    iget-object v5, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->r:Landroid/widget/ImageButton;

    nop

    if-eqz v5, :cond_287

    const/4 v2, -0x5

    invoke-virtual {v5, v15}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0x54

    iget-object v5, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->s:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    nop

    if-eqz v5, :cond_282

    const/16 v2, 0xd3

    move/from16 v0, v17

    invoke-virtual {v5, v0}, Lki;->setIndeterminate(Z)V

    const/16 v2, 0x54

    iget-object v5, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->s:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    nop

    if-eqz v5, :cond_27d

    const/16 v2, 0xe4

    invoke-virtual {v5, v15}, Lki;->setProgress(I)V

    const/16 v2, 0xa9

    invoke-virtual {v4}, Lcom/tlsvpn/tlstunnel/ui/Home;->j()V

    const/16 v2, 0xef

    iget-object v5, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->o:Landroid/widget/TextView;

    nop

    if-eqz v5, :cond_278

    const v7, 0x7f13021c

    const/16 v2, 0x93

    invoke-virtual {v5, v7}, Landroid/widget/TextView;->setText(I)V

    const/16 v2, 0xfd

    iget-object v4, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->n:Landroid/widget/ImageView;

    nop

    if-eqz v4, :cond_273

    const/16 v2, 0x87

    move/from16 v0, v16

    invoke-virtual {v4, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    return-void

    :cond_273
    const/4 v2, 0x5

    invoke-static {v8}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_278
    const/4 v2, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_27d
    const/4 v2, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_282
    const/4 v2, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_287
    const/4 v2, 0x5

    invoke-static {v10}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_28c
    const/4 v2, 0x5

    invoke-static {v11}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_291
    const/4 v2, 0x5

    invoke-static {v12}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_296
    const/16 v2, 0x7b

    iget-object v5, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->p:Landroid/widget/ImageButton;

    nop

    if-eqz v5, :cond_312

    const/4 v2, -0x5

    invoke-virtual {v5, v14}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0xb6

    iget-object v5, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->q:Landroid/view/View;

    nop

    if-eqz v5, :cond_30d

    const/4 v2, -0x5

    invoke-virtual {v5, v14}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0x102

    iget-object v5, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->r:Landroid/widget/ImageButton;

    nop

    if-eqz v5, :cond_308

    const/4 v2, -0x5

    invoke-virtual {v5, v15}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0x54

    iget-object v5, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->s:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    nop

    if-eqz v5, :cond_303

    const/16 v2, 0xd3

    move/from16 v0, v17

    invoke-virtual {v5, v0}, Lki;->setIndeterminate(Z)V

    const/16 v2, 0x54

    iget-object v5, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->s:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    nop

    if-eqz v5, :cond_2fe

    const/16 v2, 0xe4

    invoke-virtual {v5, v15}, Lki;->setProgress(I)V

    const/16 v2, 0xa9

    invoke-virtual {v4}, Lcom/tlsvpn/tlstunnel/ui/Home;->j()V

    const/16 v2, 0xef

    iget-object v5, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->o:Landroid/widget/TextView;

    nop

    if-eqz v5, :cond_2f9

    const v7, 0x7f130093

    const/16 v2, 0x93

    invoke-virtual {v5, v7}, Landroid/widget/TextView;->setText(I)V

    const/16 v2, 0xfd

    iget-object v4, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->n:Landroid/widget/ImageView;

    nop

    if-eqz v4, :cond_2f4

    const/16 v2, 0x87

    move/from16 v0, v16

    invoke-virtual {v4, v0}, Landroid/widget/ImageView;->setImageResource(I)V

    return-void

    :cond_2f4
    const/4 v2, 0x5

    invoke-static {v8}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_2f9
    const/4 v2, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_2fe
    const/4 v2, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_303
    const/4 v2, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_308
    const/4 v2, 0x5

    invoke-static {v10}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_30d
    const/4 v2, 0x5

    invoke-static {v11}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_312
    const/4 v2, 0x5

    invoke-static {v12}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_317
    const/16 v2, 0x7b

    iget-object v5, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->p:Landroid/widget/ImageButton;

    nop

    if-eqz v5, :cond_392

    const/4 v2, -0x5

    invoke-virtual {v5, v14}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0x102

    iget-object v5, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->r:Landroid/widget/ImageButton;

    nop

    if-eqz v5, :cond_38d

    const/4 v2, -0x5

    invoke-virtual {v5, v7}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0xb6

    iget-object v5, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->q:Landroid/view/View;

    nop

    if-eqz v5, :cond_388

    const/4 v2, -0x5

    invoke-virtual {v5, v14}, Landroid/view/View;->setVisibility(I)V

    const/16 v2, 0x54

    iget-object v5, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->s:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    nop

    if-eqz v5, :cond_383

    const/16 v2, 0xd3

    invoke-virtual {v5, v15}, Lki;->setIndeterminate(Z)V

    const/16 v2, 0x54

    iget-object v5, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->s:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    nop

    if-eqz v5, :cond_37e

    const/16 v2, 0xe4

    invoke-virtual {v5, v15}, Lki;->setProgress(I)V

    const/16 v2, 0xa9

    invoke-virtual {v4}, Lcom/tlsvpn/tlstunnel/ui/Home;->j()V

    const/16 v2, 0xef

    iget-object v5, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->o:Landroid/widget/TextView;

    nop

    if-eqz v5, :cond_379

    const v7, 0x7f13024a

    const/16 v2, 0x93

    invoke-virtual {v5, v7}, Landroid/widget/TextView;->setText(I)V

    const/16 v2, 0xfd

    iget-object v4, v4, Lcom/tlsvpn/tlstunnel/ui/Home;->n:Landroid/widget/ImageView;

    nop

    if-eqz v4, :cond_374

    const v5, 0x7f080112

    const/16 v2, 0x87

    invoke-virtual {v4, v5}, Landroid/widget/ImageView;->setImageResource(I)V

    return-void

    :cond_374
    const/4 v2, 0x5

    invoke-static {v8}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_379
    const/4 v2, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_37e
    const/4 v2, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_383
    const/4 v2, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_388
    const/4 v2, 0x5

    invoke-static {v11}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_38d
    const/4 v2, 0x5

    invoke-static {v10}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6

    :cond_392
    const/4 v2, 0x5

    invoke-static {v12}, Lgt0;->F0(Ljava/lang/String;)V

    throw v6
.end method

.method public final h(J)V
    .registers 22

    .prologue
    const-wide/16 v4, 0x0

    cmp-long v4, p1, v4

    const/4 v5, 0x0

    const v6, 0x7f13024d

    const-string/jumbo v7, "btnStartStopTxt"

    if-lez v4, :cond_1a3

    const/16 v2, 0x101

    sget-boolean v4, Lmi2;->n:Z

    nop

    if-nez v4, :cond_1a3

    const-wide/16 v8, 0x3e8

    div-long v8, p1, v8

    const-wide/16 v10, 0x3c

    rem-long v12, v8, v10

    long-to-int v4, v12

    div-long/2addr v8, v10

    rem-long v12, v8, v10

    long-to-int v12, v12

    div-long/2addr v8, v10

    long-to-int v8, v8

    const-string/jumbo v9, ""

    const-string/jumbo v10, "0"

    const/16 v11, 0xa

    const/16 v13, 0x9

    const/4 v14, 0x1

    if-le v8, v13, :cond_37

    const/16 v2, 0x262

    invoke-static {v8}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v15

    goto :goto_43

    :cond_37
    if-gt v14, v8, :cond_42

    if-ge v8, v11, :cond_42

    const/16 v2, 0x1f5

    invoke-static {v8, v10}, Lrt2;->f(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v15

    goto :goto_43

    :cond_42
    move-object v15, v9

    :goto_43
    const-string/jumbo v16, "00"

    if-le v12, v13, :cond_4f

    const/16 v2, 0x262

    invoke-static {v12}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v17

    goto :goto_63

    :cond_4f
    if-gt v14, v12, :cond_5a

    if-ge v12, v11, :cond_5a

    const/16 v2, 0x1f5

    invoke-static {v12, v10}, Lrt2;->f(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v17

    goto :goto_63

    :cond_5a
    if-nez v12, :cond_61

    if-lez v8, :cond_61

    move-object/from16 v17, v16

    goto :goto_63

    :cond_61
    move-object/from16 v17, v9

    :goto_63
    if-le v4, v13, :cond_6c

    const/16 v2, 0x262

    invoke-static {v4}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v9

    goto :goto_7f

    :cond_6c
    if-gt v14, v4, :cond_77

    if-ge v4, v11, :cond_77

    const/16 v2, 0x1f5

    invoke-static {v4, v10}, Lrt2;->f(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v9

    goto :goto_7f

    :cond_77
    if-nez v4, :cond_7f

    if-gtz v12, :cond_7d

    if-lez v8, :cond_7f

    :cond_7d
    move-object/from16 v9, v16

    :cond_7f
    :goto_7f
    const/16 v2, 0x47

    invoke-virtual {v15}, Ljava/lang/String;->length()I

    move-result v4

    const/16 v8, 0x3a

    if-lez v4, :cond_ac

    const/4 v2, -0x3

    new-instance v4, Ljava/lang/StringBuilder;

    nop

    const/16 v2, 0x97

    invoke-direct {v4, v15}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v2, 0x1b

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    move-object/from16 v0, v17

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v2, 0x1b

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, -0x2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    goto :goto_cf

    :cond_ac
    const/16 v2, 0x47

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v4

    if-lez v4, :cond_cf

    const/4 v2, -0x3

    new-instance v4, Ljava/lang/StringBuilder;

    nop

    const/16 v2, 0x97

    move-object/from16 v0, v17

    invoke-direct {v4, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v2, 0x1b

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, -0x2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    :cond_cf
    :goto_cf
    const/16 v2, 0x47

    invoke-virtual {v9}, Ljava/lang/String;->length()I

    move-result v4

    const/16 v2, 0xef

    move-object/from16 v0, p0

    iget-object v8, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->o:Landroid/widget/TextView;

    nop

    if-lez v4, :cond_10f

    if-eqz v8, :cond_10a

    const/4 v2, -0x3

    new-instance v4, Ljava/lang/StringBuilder;

    nop

    const/4 v2, -0x4

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v2, 0x4c

    move-object/from16 v0, p0

    invoke-virtual {v0, v6}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v6

    const/4 v2, 0x0

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v6, 0x20

    const/16 v2, 0x1b

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, -0x2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/16 v2, 0x8a

    invoke-virtual {v8, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    goto :goto_116

    :cond_10a
    const/4 v2, 0x5

    invoke-static {v7}, Lgt0;->F0(Ljava/lang/String;)V

    throw v5

    :cond_10f
    if-eqz v8, :cond_19e

    const/16 v2, 0x93

    invoke-virtual {v8, v6}, Landroid/widget/TextView;->setText(I)V

    :goto_116
    const/16 v2, 0x7b

    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->p:Landroid/widget/ImageButton;

    nop

    const-string/jumbo v6, "btnAddTime"

    if-eqz v4, :cond_199

    const/16 v2, 0x29a

    sget-wide v7, Lmi2;->j:J

    nop

    cmp-long v7, p1, v7

    const/4 v8, 0x0

    if-gez v7, :cond_12d

    goto :goto_12e

    :cond_12d
    move v14, v8

    :goto_12e
    const/16 v2, 0xf7

    invoke-virtual {v4, v14}, Landroid/view/View;->setEnabled(Z)V

    const/16 v2, 0x7b

    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->p:Landroid/widget/ImageButton;

    nop

    if-eqz v4, :cond_194

    const/16 v2, 0x631

    invoke-virtual {v4}, Landroid/view/View;->getVisibility()I

    move-result v4

    const-string/jumbo v7, "btnAddTimeRedDot"

    if-nez v4, :cond_17b

    const/16 v2, 0x7b

    move-object/from16 v0, p0

    iget-object v4, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->p:Landroid/widget/ImageButton;

    nop

    if-eqz v4, :cond_176

    const/16 v2, 0x692

    invoke-virtual {v4}, Landroid/view/View;->isEnabled()Z

    move-result v4

    if-eqz v4, :cond_17b

    const/16 v2, 0x22b

    sget-object v4, Lg4;->A:Lxu1;

    nop

    if-eqz v4, :cond_17b

    const/16 v2, 0xb6

    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->q:Landroid/view/View;

    move-object/16 p0, v2

    if-eqz p0, :cond_171

    const/4 v2, -0x5

    move-object/from16 v0, p0

    invoke-virtual {v0, v8}, Landroid/view/View;->setVisibility(I)V

    return-void

    :cond_171
    const/4 v2, 0x5

    invoke-static {v7}, Lgt0;->F0(Ljava/lang/String;)V

    throw v5

    :cond_176
    const/4 v2, 0x5

    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw v5

    :cond_17b
    const/16 v2, 0xb6

    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->q:Landroid/view/View;

    move-object/16 p0, v2

    if-eqz p0, :cond_18f

    const/16 v4, 0x8

    const/4 v2, -0x5

    move-object/from16 v0, p0

    invoke-virtual {v0, v4}, Landroid/view/View;->setVisibility(I)V

    return-void

    :cond_18f
    const/4 v2, 0x5

    invoke-static {v7}, Lgt0;->F0(Ljava/lang/String;)V

    throw v5

    :cond_194
    const/4 v2, 0x5

    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw v5

    :cond_199
    const/4 v2, 0x5

    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw v5

    :cond_19e
    const/4 v2, 0x5

    invoke-static {v7}, Lgt0;->F0(Ljava/lang/String;)V

    throw v5

    :cond_1a3
    const/16 v2, 0xef

    move-object/from16 v0, p0

    iget-object v2, v0, Lcom/tlsvpn/tlstunnel/ui/Home;->o:Landroid/widget/TextView;

    move-object/16 p0, v2

    if-eqz p0, :cond_1b6

    const/16 v2, 0x93

    move-object/from16 v0, p0

    invoke-virtual {v0, v6}, Landroid/widget/TextView;->setText(I)V

    return-void

    :cond_1b6
    const/4 v2, 0x5

    invoke-static {v7}, Lgt0;->F0(Ljava/lang/String;)V

    throw v5
.end method

.method public final i()V
    .registers 14

    .prologue
    const/16 v6, 0x1ff

    sget v8, Lmi2;->o:I

    nop

    if-nez v8, :cond_1bd

    const/16 v6, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v8

    const/4 v6, -0x6

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v9, 0x1

    :try_start_12
    const/16 v6, 0x1d2

    invoke-virtual {v8}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v8

    const-string/jumbo v10, "auto_time"

    const/16 v6, 0x10db

    invoke-static {v8, v10}, Landroid/provider/Settings$Global;->getInt(Landroid/content/ContentResolver;Ljava/lang/String;)I

    move-result v8
    :try_end_21
    .catch Landroid/provider/Settings$SettingNotFoundException; {:try_start_12 .. :try_end_21} :catch_69

    if-ne v8, v9, :cond_24

    goto :goto_69

    :cond_24
    const/16 v6, 0x5b

    new-instance v8, Landroid/content/Intent;

    nop

    const/16 v6, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v9

    const-class v10, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;

    const/16 v6, 0xd0

    invoke-direct {v8, v9, v10}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const v9, 0x7f1300f0

    const/16 v6, 0x4c

    invoke-virtual {p0, v9}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v9

    const-string/jumbo v10, "title"

    const/16 v6, 0x4b

    invoke-virtual {v8, v10, v9}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const v9, 0x7f1300f1

    const/16 v6, 0x4c

    invoke-virtual {p0, v9}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v9

    const-string/jumbo v10, "msg"

    const/16 v6, 0x4b

    invoke-virtual {v8, v10, v9}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string/jumbo v9, "atype"

    const-string/jumbo v10, "atmsgonly"

    const/16 v6, 0x4b

    invoke-virtual {v8, v9, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/16 v6, 0x634

    invoke-virtual {p0, v8}, Landroidx/fragment/app/Fragment;->startActivity(Landroid/content/Intent;)V

    return-void

    :catch_69
    :goto_69
    const/16 v6, 0x8ea

    new-instance v8, Lou;

    nop

    const/16 v6, 0xc6

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/Home;->b()Landroid/content/SharedPreferences;

    move-result-object v10

    const/4 v6, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x1c6

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getResources()Landroid/content/res/Resources;

    move-result-object v11

    const/4 v6, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v12, 0x0

    const/16 v6, 0x83d

    move v0, v6

    move-object v1, v8

    move-object v2, v10

    move-object v3, v11

    move v4, v12

    move v5, v9

    invoke-direct/range {v1 .. v5}, Lou;-><init>(Landroid/content/SharedPreferences;Landroid/content/res/Resources;ZZ)V

    const/16 v6, 0x75

    iget-boolean v10, v8, Lou;->w:Z

    nop

    const-string/jumbo v11, "eptalert"

    if-nez v10, :cond_f4

    const/16 v6, 0x1b8

    iget v10, v8, Lou;->m:I

    nop

    if-ne v10, v9, :cond_f4

    const/16 v6, 0x3f5

    iget-boolean v10, v8, Lou;->t:Z

    nop

    if-eqz v10, :cond_f4

    const/16 v6, 0x1e1

    iget-object v10, v8, Lou;->u:Ljava/lang/String;

    nop

    const/16 v6, 0x47

    invoke-virtual {v10}, Ljava/lang/String;->length()I

    move-result v10

    if-nez v10, :cond_b4

    goto :goto_c1

    :cond_b4
    const/16 v6, 0x1f4

    iget-object v10, v8, Lou;->v:Ljava/lang/String;

    nop

    const/16 v6, 0x47

    invoke-virtual {v10}, Ljava/lang/String;->length()I

    move-result v10

    if-nez v10, :cond_f4

    :goto_c1
    const/16 v6, 0xe47

    new-instance v8, Lso1;

    nop

    const/16 v6, 0xe2c

    invoke-direct {v8}, Lso1;-><init>()V

    const/16 v6, 0x108

    new-instance v10, Landroid/os/Bundle;

    nop

    const/16 v6, 0x198

    invoke-direct {v10}, Landroid/os/Bundle;-><init>()V

    const/16 v6, 0x27b

    invoke-virtual {v10, v11, v9}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/16 v6, 0x19a

    invoke-virtual {v8, v10}, Landroidx/fragment/app/Fragment;->setArguments(Landroid/os/Bundle;)V

    const/16 v6, 0x8b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getParentFragmentManager()Landroidx/fragment/app/p;

    move-result-object v9

    const v10, 0x7f13020f

    const/16 v6, 0x4c

    invoke-virtual {p0, v10}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/16 v6, 0x8c

    invoke-virtual {v8, v9, p0}, Landroidx/fragment/app/g;->show(Landroidx/fragment/app/p;Ljava/lang/String;)V

    return-void

    :cond_f4
    const/16 v6, 0x9d

    iget-boolean v10, v8, Lou;->h:Z

    nop

    if-eqz v10, :cond_149

    const/16 v6, 0x2e2

    iget-object v10, v8, Lou;->k:Ljava/lang/String;

    nop

    const/16 v6, 0x47

    invoke-virtual {v10}, Ljava/lang/String;->length()I

    move-result v10

    if-nez v10, :cond_109

    goto :goto_116

    :cond_109
    const/16 v6, 0xef9

    iget-object v8, v8, Lou;->l:Ljava/lang/String;

    nop

    const/16 v6, 0x47

    invoke-virtual {v8}, Ljava/lang/String;->length()I

    move-result v8

    if-nez v8, :cond_149

    :goto_116
    const/16 v6, 0x310

    new-instance v8, Ldn1;

    nop

    const/16 v6, 0x3f8

    invoke-direct {v8}, Ldn1;-><init>()V

    const/16 v6, 0x108

    new-instance v10, Landroid/os/Bundle;

    nop

    const/16 v6, 0x198

    invoke-direct {v10}, Landroid/os/Bundle;-><init>()V

    const/16 v6, 0x27b

    invoke-virtual {v10, v11, v9}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/16 v6, 0x19a

    invoke-virtual {v8, v10}, Landroidx/fragment/app/Fragment;->setArguments(Landroid/os/Bundle;)V

    const/16 v6, 0x8b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getParentFragmentManager()Landroidx/fragment/app/p;

    move-result-object v9

    const v10, 0x7f130211

    const/16 v6, 0x4c

    invoke-virtual {p0, v10}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/16 v6, 0x8c

    invoke-virtual {v8, v9, p0}, Landroidx/fragment/app/g;->show(Landroidx/fragment/app/p;Ljava/lang/String;)V

    return-void

    :cond_149
    const/16 v6, 0xef

    iget-object v8, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->o:Landroid/widget/TextView;

    nop

    const/4 v9, 0x0

    if-eqz v8, :cond_1b5

    const v10, 0x7f130093

    const/16 v6, 0x93

    invoke-virtual {v8, v10}, Landroid/widget/TextView;->setText(I)V

    const/16 v6, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v8

    const/16 v6, 0x115d

    invoke-static {v8}, Landroid/net/VpnService;->prepare(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object v8

    if-eqz v8, :cond_172

    const/16 v6, 0x71b

    iget-object p0, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->H:Lm3;

    nop

    const/16 v6, 0xad

    invoke-virtual {p0, v8, v9}, Lm3;->a(Ljava/lang/Object;Lf3;)V

    goto :goto_1b4

    :cond_172
    const/16 v6, 0x1fc

    sget v8, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 v9, 0x1a

    const-class v10, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;

    if-ge v8, v9, :cond_199

    const/16 v6, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v8

    const/16 v6, 0x5b

    new-instance v9, Landroid/content/Intent;

    nop

    const/16 v6, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p0

    const/16 v6, 0xd0

    invoke-direct {v9, p0, v10}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/16 v6, 0x4a7

    invoke-virtual {v8, v9}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    goto :goto_1b4

    :cond_199
    const/16 v6, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v8

    const/16 v6, 0x5b

    new-instance v9, Landroid/content/Intent;

    nop

    const/16 v6, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p0

    const/16 v6, 0xd0

    invoke-direct {v9, p0, v10}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/16 v6, 0xd2c

    invoke-virtual {v8, v9}, Landroid/content/Context;->startForegroundService(Landroid/content/Intent;)Landroid/content/ComponentName;

    :goto_1b4
    return-void

    :cond_1b5
    const-string/jumbo p0, "btnStartStopTxt"

    const/4 v6, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v9

    :cond_1bd
    const/4 v8, 0x4

    const/16 v6, 0x332

    sput v8, Lmi2;->o:I

    const/16 v6, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v8

    const/16 v6, 0x5b

    new-instance v9, Landroid/content/Intent;

    nop

    const-string/jumbo v10, "stopVpn"

    const/16 v6, 0x62

    invoke-direct {v9, v10}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v6, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v10

    const/16 v6, 0x53

    invoke-virtual {v10}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v10

    const/16 v6, 0x4a

    invoke-virtual {v10}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v10

    const/16 v6, 0x64

    invoke-virtual {v9, v10}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v9

    const/16 v6, 0x63

    invoke-virtual {v8, v9}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    const/16 v6, 0xa9

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/Home;->j()V

    const/16 v6, 0x182

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/Home;->g()V

    return-void
.end method

.method public final j()V
    .registers 4

    .prologue
    const/16 v0, 0xf4d

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->t:Lho0;

    nop

    if-eqz v2, :cond_c

    const/16 v0, 0x2f3

    invoke-virtual {v2}, Landroid/os/CountDownTimer;->cancel()V

    :cond_c
    const/4 v2, 0x0

    const/16 v0, 0x10ac

    iput-object v2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->t:Lho0;

    return-void
.end method

.method public final k()V
    .registers 13

    .prologue
    const/16 v6, 0x69

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getView()Landroid/view/View;

    move-result-object v8

    if-eqz v8, :cond_5f

    const/16 v6, 0xd9

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->isAdded()Z

    move-result v8

    if-nez v8, :cond_11

    goto :goto_5f

    :cond_11
    const/16 v6, 0x1ff

    sget v8, Lmi2;->o:I

    nop

    if-nez v8, :cond_5f

    const/16 v6, 0x2c2

    iget-object v8, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->m:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    const/4 v9, 0x0

    if-eqz v8, :cond_57

    const/4 v10, 0x0

    const/16 v6, 0xf7

    invoke-virtual {v8, v10}, Landroid/view/View;->setEnabled(Z)V

    const/16 v6, 0x102

    iget-object v8, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->r:Landroid/widget/ImageButton;

    nop

    if-eqz v8, :cond_4f

    const/16 v6, 0xf7

    invoke-virtual {v8, v10}, Landroid/view/View;->setEnabled(Z)V

    const/16 v6, 0x341

    invoke-static {p0}, Lns2;->m(Lh11;)Lc11;

    move-result-object v8

    const/16 v6, 0x16

    new-instance v10, Lqd;

    nop

    const/4 v11, 0x3

    const/16 v6, 0x17

    invoke-direct {v10, p0, v9, v11}, Lqd;-><init>(Ljava/lang/Object;Lvx;I)V

    const/16 v6, 0xb3

    move v0, v6

    move-object v1, v8

    move-object v2, v9

    move-object v3, v9

    move-object v4, v10

    move v5, v11

    invoke-static/range {v1 .. v5}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    return-void

    :cond_4f
    const-string/jumbo p0, "btnReconnect"

    const/4 v6, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v9

    :cond_57
    const-string/jumbo p0, "btnStartStop"

    const/4 v6, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v9

    :cond_5f
    :goto_5f
    return-void
.end method

.method public final onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .registers 16

    .prologue
    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, -0x1

    iget-object p3, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->c:Landroid/view/View;

    nop

    const/4 v2, 0x0

    if-nez p3, :cond_14

    const p3, 0x7f0c0038

    const/16 v0, 0x107b

    invoke-virtual {p1, p3, p2, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p3

    :cond_14
    const/16 v0, 0x10f2

    iput-object p3, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->c:Landroid/view/View;

    const/4 p1, 0x0

    if-eqz p3, :cond_27

    const p2, 0x7f09008c

    const/16 v0, 0x11

    invoke-virtual {p3, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroidx/constraintlayout/widget/ConstraintLayout;

    goto :goto_28

    :cond_27
    move-object p2, p1

    :goto_28
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xcd2

    iput-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->m:Landroidx/constraintlayout/widget/ConstraintLayout;

    const/4 v0, -0x1

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->c:Landroid/view/View;

    nop

    if-eqz p2, :cond_42

    const p3, 0x7f09008d

    const/16 v0, 0x11

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/ImageView;

    goto :goto_43

    :cond_42
    move-object p2, p1

    :goto_43
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x5e9

    iput-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->n:Landroid/widget/ImageView;

    const/4 v0, -0x1

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->c:Landroid/view/View;

    nop

    if-eqz p2, :cond_5d

    const p3, 0x7f09008e

    const/16 v0, 0x11

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/TextView;

    goto :goto_5e

    :cond_5d
    move-object p2, p1

    :goto_5e
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x11b3

    iput-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->o:Landroid/widget/TextView;

    const/4 v0, -0x1

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->c:Landroid/view/View;

    nop

    if-eqz p2, :cond_78

    const p3, 0x7f090049

    const/16 v0, 0x11

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/ImageButton;

    goto :goto_79

    :cond_78
    move-object p2, p1

    :goto_79
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x107e

    iput-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->p:Landroid/widget/ImageButton;

    const/4 v0, -0x1

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->c:Landroid/view/View;

    nop

    if-eqz p2, :cond_91

    const p3, 0x7f090089

    const/16 v0, 0x11

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    goto :goto_92

    :cond_91
    move-object p2, p1

    :goto_92
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xf4f

    iput-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->q:Landroid/view/View;

    const/4 v0, -0x1

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->c:Landroid/view/View;

    nop

    if-eqz p2, :cond_ac

    const p3, 0x7f09008a

    const/16 v0, 0x11

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/ImageButton;

    goto :goto_ad

    :cond_ac
    move-object p2, p1

    :goto_ad
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xdf9

    iput-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->r:Landroid/widget/ImageButton;

    const/4 v0, -0x1

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->c:Landroid/view/View;

    nop

    if-eqz p2, :cond_c5

    const p3, 0x7f09008b

    const/16 v0, 0x11

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    goto :goto_c6

    :cond_c5
    move-object p2, p1

    :goto_c6
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, -0x1

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->c:Landroid/view/View;

    nop

    if-eqz p2, :cond_dc

    const p3, 0x7f09009c

    const/16 v0, 0x11

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroidx/constraintlayout/widget/ConstraintLayout;

    goto :goto_dd

    :cond_dc
    move-object p2, p1

    :goto_dd
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xebc

    iput-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->v:Landroidx/constraintlayout/widget/ConstraintLayout;

    const/4 v0, -0x1

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->c:Landroid/view/View;

    nop

    if-eqz p2, :cond_f7

    const p3, 0x7f09025b

    const/16 v0, 0x11

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/TextView;

    goto :goto_f8

    :cond_f7
    move-object p2, p1

    :goto_f8
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xb8c

    iput-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->w:Landroid/widget/TextView;

    const/4 v0, -0x1

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->c:Landroid/view/View;

    nop

    if-eqz p2, :cond_112

    const p3, 0x7f0900f9

    const/16 v0, 0x11

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/ImageView;

    goto :goto_113

    :cond_112
    move-object p2, p1

    :goto_113
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x6e6

    iput-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->x:Landroid/widget/ImageView;

    const/4 v0, -0x1

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->c:Landroid/view/View;

    nop

    if-eqz p2, :cond_12d

    const p3, 0x7f090147

    const/16 v0, 0x11

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/ImageView;

    goto :goto_12e

    :cond_12d
    move-object p2, p1

    :goto_12e
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x10a8

    iput-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->y:Landroid/widget/ImageView;

    const/4 v0, -0x1

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->c:Landroid/view/View;

    nop

    if-eqz p2, :cond_148

    const p3, 0x7f09009a

    const/16 v0, 0x11

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/TextView;

    goto :goto_149

    :cond_148
    move-object p2, p1

    :goto_149
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xbeb

    iput-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->A:Landroid/widget/TextView;

    const/4 v0, -0x1

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->c:Landroid/view/View;

    nop

    if-eqz p2, :cond_163

    const p3, 0x7f09009b

    const/16 v0, 0x11

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/LinearLayout;

    goto :goto_164

    :cond_163
    move-object p2, p1

    :goto_164
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x1251

    iput-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->z:Landroid/widget/LinearLayout;

    const/4 v0, -0x1

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->c:Landroid/view/View;

    nop

    if-eqz p2, :cond_17e

    const p3, 0x7f090346

    const/16 v0, 0x11

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroidx/constraintlayout/widget/ConstraintLayout;

    goto :goto_17f

    :cond_17e
    move-object p2, p1

    :goto_17f
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xf0f

    iput-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->d:Landroidx/constraintlayout/widget/ConstraintLayout;

    const/4 v0, -0x1

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->c:Landroid/view/View;

    nop

    if-eqz p2, :cond_197

    const p3, 0x7f090347

    const/16 v0, 0x11

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    goto :goto_198

    :cond_197
    move-object p2, p1

    :goto_198
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x6c0

    iput-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->e:Landroid/view/View;

    const/4 v0, -0x1

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->c:Landroid/view/View;

    nop

    if-eqz p2, :cond_1b2

    const p3, 0x7f09031a

    const/16 v0, 0x11

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/ImageView;

    goto :goto_1b3

    :cond_1b2
    move-object p2, p1

    :goto_1b3
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xa5d

    iput-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->f:Landroid/widget/ImageView;

    const/4 v0, -0x1

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->c:Landroid/view/View;

    nop

    if-eqz p2, :cond_1cd

    const p3, 0x7f0900bb

    const/16 v0, 0x11

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/ImageView;

    goto :goto_1ce

    :cond_1cd
    move-object p2, p1

    :goto_1ce
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x808

    iput-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->g:Landroid/widget/ImageView;

    const/4 v0, -0x1

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->c:Landroid/view/View;

    nop

    if-eqz p2, :cond_1e8

    const p3, 0x7f09032e

    const/16 v0, 0x11

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/TextView;

    goto :goto_1e9

    :cond_1e8
    move-object p2, p1

    :goto_1e9
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x7d5

    iput-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->h:Landroid/widget/TextView;

    const/4 v0, -0x1

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->c:Landroid/view/View;

    nop

    if-eqz p2, :cond_203

    const p3, 0x7f09032f

    const/16 v0, 0x11

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/TextView;

    goto :goto_204

    :cond_203
    move-object p2, p1

    :goto_204
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x1083

    iput-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->i:Landroid/widget/TextView;

    const/4 v0, -0x1

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->c:Landroid/view/View;

    nop

    if-eqz p2, :cond_21e

    const p3, 0x7f090355

    const/16 v0, 0x11

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/ImageView;

    goto :goto_21f

    :cond_21e
    move-object p2, p1

    :goto_21f
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xb24

    iput-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->j:Landroid/widget/ImageView;

    const/4 v0, -0x1

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->c:Landroid/view/View;

    nop

    if-eqz p2, :cond_239

    const p3, 0x7f090315

    const/16 v0, 0x11

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/TextView;

    goto :goto_23a

    :cond_239
    move-object p2, p1

    :goto_23a
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x8c3

    iput-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->k:Landroid/widget/TextView;

    const/4 v0, -0x1

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->c:Landroid/view/View;

    nop

    if-eqz p2, :cond_254

    const p3, 0x7f090318

    const/16 v0, 0x11

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/TableLayout;

    goto :goto_255

    :cond_254
    move-object p2, p1

    :goto_255
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, -0x1

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->c:Landroid/view/View;

    nop

    if-eqz p2, :cond_26b

    const p3, 0x7f0902a9

    const/16 v0, 0x11

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/TableRow;

    goto :goto_26c

    :cond_26b
    move-object p2, p1

    :goto_26c
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, -0x1

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->c:Landroid/view/View;

    nop

    if-eqz p2, :cond_282

    const p3, 0x7f090316

    const/16 v0, 0x11

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/TableRow;

    goto :goto_283

    :cond_282
    move-object p2, p1

    :goto_283
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, -0x1

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->c:Landroid/view/View;

    nop

    if-eqz p2, :cond_299

    const p3, 0x7f0902c4

    const/16 v0, 0x11

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/TextView;

    goto :goto_29a

    :cond_299
    move-object p2, p1

    :goto_29a
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x5e0

    iput-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->l:Landroid/widget/TextView;

    const/4 v0, -0x1

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->c:Landroid/view/View;

    nop

    if-eqz p2, :cond_2b4

    const p3, 0x7f0900bc

    const/16 v0, 0x11

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    goto :goto_2b5

    :cond_2b4
    move-object p2, p1

    :goto_2b5
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x614

    iput-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->s:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    const/4 v0, -0x1

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->c:Landroid/view/View;

    nop

    if-eqz p2, :cond_2cf

    const p3, 0x7f090072

    const/16 v0, 0x11

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/FrameLayout;

    goto :goto_2d0

    :cond_2cf
    move-object p2, p1

    :goto_2d0
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xcba

    iput-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->D:Landroid/widget/FrameLayout;

    const/4 v0, -0x1

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->c:Landroid/view/View;

    nop

    if-eqz p2, :cond_2ea

    const p3, 0x7f090073

    const/16 v0, 0x11

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/FrameLayout;

    goto :goto_2eb

    :cond_2ea
    move-object p2, p1

    :goto_2eb
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x835

    iput-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->E:Landroid/widget/FrameLayout;

    const/16 v0, 0x182

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/Home;->g()V

    const/4 v0, -0x1

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->c:Landroid/view/View;

    nop

    if-eqz p2, :cond_30a

    const p3, 0x7f090392

    const/16 v0, 0x11

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/ImageView;

    goto :goto_30b

    :cond_30a
    move-object p2, p1

    :goto_30b
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x66

    new-instance p3, Lfo0;

    nop

    const/4 v3, 0x5

    const/16 v0, 0x65

    invoke-direct {p3, p0, v3}, Lfo0;-><init>(Lcom/tlsvpn/tlstunnel/ui/Home;I)V

    const/16 v0, 0x5f

    invoke-virtual {p2, p3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0x101

    sget-boolean p2, Lmi2;->n:Z

    nop

    if-eqz p2, :cond_333

    const/4 v0, -0x1

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->c:Landroid/view/View;

    nop

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x64a

    invoke-virtual {p0, p2}, Lcom/tlsvpn/tlstunnel/ui/Home;->f(Landroid/view/View;)V

    :cond_333
    const/4 v0, -0x1

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->c:Landroid/view/View;

    nop

    if-eqz p2, :cond_345

    const p3, 0x7f09013b

    const/16 v0, 0x11

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/ImageView;

    goto :goto_346

    :cond_345
    move-object p2, p1

    :goto_346
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x66

    new-instance p3, Lfo0;

    nop

    const/16 v0, 0x65

    invoke-direct {p3, p0, v2}, Lfo0;-><init>(Lcom/tlsvpn/tlstunnel/ui/Home;I)V

    const/16 v0, 0x5f

    invoke-virtual {p2, p3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0x2d9

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->d:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    const-string/jumbo p3, "sserver"

    if-eqz p2, :cond_6ba

    const/16 v0, 0x66

    new-instance v4, Lfo0;

    nop

    const/4 v5, 0x1

    const/16 v0, 0x65

    invoke-direct {v4, p0, v5}, Lfo0;-><init>(Lcom/tlsvpn/tlstunnel/ui/Home;I)V

    const/16 v0, 0x5f

    invoke-virtual {p2, v4}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0x2d9

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->d:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz p2, :cond_6b5

    const/16 v0, 0x80

    new-instance p3, Lgo0;

    nop

    const/16 v0, 0x85

    invoke-direct {p3, p0, v2}, Lgo0;-><init>(Lcom/tlsvpn/tlstunnel/ui/Home;I)V

    const/16 v0, 0x8f

    invoke-virtual {p2, p3}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    const/16 v0, 0x14b

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->k:Landroid/widget/TextView;

    nop

    const-string/jumbo p3, "serverport"

    if-eqz p2, :cond_6b0

    const/16 v0, 0x66

    new-instance v2, Lfo0;

    nop

    const/4 v4, 0x2

    const/16 v0, 0x65

    invoke-direct {v2, p0, v4}, Lfo0;-><init>(Lcom/tlsvpn/tlstunnel/ui/Home;I)V

    const/16 v0, 0x5f

    invoke-virtual {p2, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0x14b

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->k:Landroid/widget/TextView;

    nop

    if-eqz p2, :cond_6ab

    const/16 v0, 0x80

    new-instance p3, Lgo0;

    nop

    const/16 v0, 0x85

    invoke-direct {p3, p0, v5}, Lgo0;-><init>(Lcom/tlsvpn/tlstunnel/ui/Home;I)V

    const/16 v0, 0x8f

    invoke-virtual {p2, p3}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    const/16 v0, 0x2c2

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->m:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    const-string/jumbo p3, "btnStartStop"

    if-eqz p2, :cond_6a6

    const/16 v0, 0x66

    new-instance v2, Lfo0;

    nop

    const/4 v5, 0x3

    const/16 v0, 0x65

    invoke-direct {v2, p0, v5}, Lfo0;-><init>(Lcom/tlsvpn/tlstunnel/ui/Home;I)V

    const/16 v0, 0x5f

    invoke-virtual {p2, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0x2c2

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->m:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz p2, :cond_6a1

    const/16 v0, 0x80

    new-instance p3, Lgo0;

    nop

    const/16 v0, 0x85

    invoke-direct {p3, p0, v4}, Lgo0;-><init>(Lcom/tlsvpn/tlstunnel/ui/Home;I)V

    const/16 v0, 0x8f

    invoke-virtual {p2, p3}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    const/16 v0, 0x7b

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->p:Landroid/widget/ImageButton;

    nop

    const-string/jumbo p3, "btnAddTime"

    if-eqz p2, :cond_69c

    const/16 v0, 0x66

    new-instance v2, Lfo0;

    nop

    const/4 v4, 0x4

    const/16 v0, 0x65

    invoke-direct {v2, p0, v4}, Lfo0;-><init>(Lcom/tlsvpn/tlstunnel/ui/Home;I)V

    const/16 v0, 0x5f

    invoke-virtual {p2, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0x7b

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->p:Landroid/widget/ImageButton;

    nop

    if-eqz p2, :cond_697

    const/16 v0, 0x80

    new-instance p3, Lgo0;

    nop

    const/16 v0, 0x85

    invoke-direct {p3, p0, v5}, Lgo0;-><init>(Lcom/tlsvpn/tlstunnel/ui/Home;I)V

    const/16 v0, 0x8f

    invoke-virtual {p2, p3}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    const/16 v0, 0x102

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->r:Landroid/widget/ImageButton;

    nop

    const-string/jumbo p3, "btnReconnect"

    if-eqz p2, :cond_692

    const/16 v0, 0x66

    new-instance v2, Lfo0;

    nop

    const/4 v5, 0x6

    const/16 v0, 0x65

    invoke-direct {v2, p0, v5}, Lfo0;-><init>(Lcom/tlsvpn/tlstunnel/ui/Home;I)V

    const/16 v0, 0x5f

    invoke-virtual {p2, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0x102

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->r:Landroid/widget/ImageButton;

    nop

    if-eqz p2, :cond_68d

    const/16 v0, 0x80

    new-instance p3, Lgo0;

    nop

    const/16 v0, 0x85

    invoke-direct {p3, p0, v4}, Lgo0;-><init>(Lcom/tlsvpn/tlstunnel/ui/Home;I)V

    const/16 v0, 0x8f

    invoke-virtual {p2, p3}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    const/16 v0, 0x52c

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->v:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    const-string/jumbo p3, "cfgmethod"

    if-eqz p2, :cond_688

    const/16 v0, 0x66

    new-instance v2, Lfo0;

    nop

    const/4 v6, 0x7

    const/16 v0, 0x65

    invoke-direct {v2, p0, v6}, Lfo0;-><init>(Lcom/tlsvpn/tlstunnel/ui/Home;I)V

    const/16 v0, 0x5f

    invoke-virtual {p2, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0x52c

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->v:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz p2, :cond_683

    const/16 v0, 0x80

    new-instance p3, Lgo0;

    nop

    const/16 v0, 0x85

    invoke-direct {p3, p0, v3}, Lgo0;-><init>(Lcom/tlsvpn/tlstunnel/ui/Home;I)V

    const/16 v0, 0x8f

    invoke-virtual {p2, p3}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    const/16 v0, 0x3df

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->y:Landroid/widget/ImageView;

    nop

    const-string/jumbo p3, "imexclImg"

    if-eqz p2, :cond_67e

    const/16 v0, 0x66

    new-instance v2, Lfo0;

    nop

    const/16 v3, 0x8

    const/16 v0, 0x65

    invoke-direct {v2, p0, v3}, Lfo0;-><init>(Lcom/tlsvpn/tlstunnel/ui/Home;I)V

    const/16 v0, 0x5f

    invoke-virtual {p2, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0x3df

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->y:Landroid/widget/ImageView;

    nop

    if-eqz p2, :cond_679

    const/16 v0, 0x80

    new-instance p1, Lgo0;

    nop

    const/16 v0, 0x85

    invoke-direct {p1, p0, v5}, Lgo0;-><init>(Lcom/tlsvpn/tlstunnel/ui/Home;I)V

    const/16 v0, 0x8f

    invoke-virtual {p2, p1}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    const/16 v0, 0x11b

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/Home;->d()V

    const/16 v0, 0x1fc

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 p2, 0x21

    const-string/jumbo p3, "admobIniciado"

    const-string/jumbo v2, "pVacTd"

    const-string/jumbo v3, "dipro"

    const-string/jumbo v5, "vpnOff"

    const-string/jumbo v6, "vpnOn"

    const-string/jumbo v7, "renewed"

    const-string/jumbo v8, "setProgress"

    const-string/jumbo v9, "restoreHome"

    const-string/jumbo v10, "saveHome"

    const/16 v0, 0xf13

    iget-object v11, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->I:Lob;

    nop

    if-ge p1, p2, :cond_597

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p1

    const/16 v0, 0x1f

    new-instance p2, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {p2, v10}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x3a

    invoke-virtual {p1, v11, p2}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p1

    const/16 v0, 0x1f

    new-instance p2, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {p2, v9}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x3a

    invoke-virtual {p1, v11, p2}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p1

    const/16 v0, 0x1f

    new-instance p2, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {p2, v8}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x3a

    invoke-virtual {p1, v11, p2}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p1

    const/16 v0, 0x1f

    new-instance p2, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {p2, v7}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x3a

    invoke-virtual {p1, v11, p2}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p1

    const/16 v0, 0x1f

    new-instance p2, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {p2, v6}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x3a

    invoke-virtual {p1, v11, p2}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p1

    const/16 v0, 0x1f

    new-instance p2, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {p2, v5}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x3a

    invoke-virtual {p1, v11, p2}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p1

    const/16 v0, 0x1f

    new-instance p2, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {p2, v3}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x3a

    invoke-virtual {p1, v11, p2}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p1

    const/16 v0, 0x1f

    new-instance p2, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {p2, v2}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x3a

    invoke-virtual {p1, v11, p2}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p1

    const/16 v0, 0x1f

    new-instance p2, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {p2, p3}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x3a

    invoke-virtual {p1, v11, p2}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    goto/16 :goto_654

    :cond_597
    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p1

    const/16 v0, 0x1f

    new-instance p2, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {p2, v10}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x5d

    invoke-virtual {p1, v11, p2, v4}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p1

    const/16 v0, 0x1f

    new-instance p2, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {p2, v9}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x5d

    invoke-virtual {p1, v11, p2, v4}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p1

    const/16 v0, 0x1f

    new-instance p2, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {p2, v8}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x5d

    invoke-virtual {p1, v11, p2, v4}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p1

    const/16 v0, 0x1f

    new-instance p2, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {p2, v7}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x5d

    invoke-virtual {p1, v11, p2, v4}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p1

    const/16 v0, 0x1f

    new-instance p2, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {p2, v6}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x5d

    invoke-virtual {p1, v11, p2, v4}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p1

    const/16 v0, 0x1f

    new-instance p2, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {p2, v5}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x5d

    invoke-virtual {p1, v11, p2, v4}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p1

    const/16 v0, 0x1f

    new-instance p2, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {p2, v3}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x5d

    invoke-virtual {p1, v11, p2, v4}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p1

    const/16 v0, 0x1f

    new-instance p2, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {p2, v2}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x5d

    invoke-virtual {p1, v11, p2, v4}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p1

    const/16 v0, 0x1f

    new-instance p2, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {p2, p3}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x5d

    invoke-virtual {p1, v11, p2, v4}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    :goto_654
    const/16 v0, 0x140

    sget-boolean p1, Lg4;->a:Z

    nop

    const/16 v0, 0xfb

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xc6

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/Home;->b()Landroid/content/SharedPreferences;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x394

    invoke-static {p2, p1}, Lg4;->n(Landroid/content/SharedPreferences;Landroidx/fragment/app/l;)V

    const/4 v0, -0x1

    iget-object p0, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->c:Landroid/view/View;

    nop

    check-cast p0, Landroid/view/View;

    return-object p0

    :cond_679
    const/4 v0, 0x5

    invoke-static {p3}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_67e
    const/4 v0, 0x5

    invoke-static {p3}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_683
    const/4 v0, 0x5

    invoke-static {p3}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_688
    const/4 v0, 0x5

    invoke-static {p3}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_68d
    const/4 v0, 0x5

    invoke-static {p3}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_692
    const/4 v0, 0x5

    invoke-static {p3}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_697
    const/4 v0, 0x5

    invoke-static {p3}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_69c
    const/4 v0, 0x5

    invoke-static {p3}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_6a1
    const/4 v0, 0x5

    invoke-static {p3}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_6a6
    const/4 v0, 0x5

    invoke-static {p3}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_6ab
    const/4 v0, 0x5

    invoke-static {p3}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_6b0
    const/4 v0, 0x5

    invoke-static {p3}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_6b5
    const/4 v0, 0x5

    invoke-static {p3}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_6ba
    const/4 v0, 0x5

    invoke-static {p3}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1
.end method

.method public final onDestroyView()V
    .registers 5

    .prologue
    const/16 v0, 0x122b

    invoke-super {p0}, Landroidx/fragment/app/Fragment;->onDestroyView()V

    :try_start_5
    const/16 v0, 0x22f

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v2

    if-eqz v2, :cond_17

    const/16 v0, 0xf13

    iget-object v3, p0, Lcom/tlsvpn/tlstunnel/ui/Home;->I:Lob;

    nop

    const/16 v0, 0x345

    invoke-virtual {v2, v3}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_17
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_17} :catch_17

    :catch_17
    :cond_17
    const/16 v0, 0xa9

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/Home;->j()V

    return-void
.end method

.method public final onResume()V
    .registers 6

    const/16 v0, 0x7d7

    invoke-super {p0}, Landroidx/fragment/app/Fragment;->onResume()V

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v2

    const/16 v0, 0x5b

    new-instance v3, Landroid/content/Intent;

    nop

    const-string/jumbo v4, "homeFrag"

    const/16 v0, 0x62

    invoke-direct {v3, v4}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v4

    const/16 v0, 0x53

    invoke-virtual {v4}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v4

    const/16 v0, 0x4a

    invoke-virtual {v4}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    const/16 v0, 0x64

    invoke-virtual {v3, v4}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v3

    const/16 v0, 0x63

    invoke-virtual {v2, v3}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    const/16 v0, 0x11b

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/Home;->d()V

    const/16 v0, 0x322

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/Home;->c()V

    return-void
.end method
