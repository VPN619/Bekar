.class public final Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings;
.super Landroidx/fragment/app/Fragment;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings$a;
    }
.end annotation


# static fields
.field public static final synthetic c:I


# instance fields
.field public final a:Lw82;

.field public b:Landroid/view/View;


# direct methods
.method public constructor <init>()V
    .registers 5

    invoke-direct {p0}, Landroidx/fragment/app/Fragment;-><init>()V

    const/16 v0, 0x9ca

    new-instance v2, Lsz1;

    nop

    const/4 v3, 0x7

    const/16 v0, 0xf0b

    invoke-direct {v2, v3, p0}, Lsz1;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x27a

    new-instance v3, Lw82;

    nop

    const/16 v0, 0x215

    invoke-direct {v3, v2}, Lw82;-><init>(Lzj0;)V

    const/16 v0, 0xde1

    iput-object v3, p0, Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings;->a:Lw82;

    return-void
.end method


# virtual methods
.method public final onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .registers 8

    .prologue
    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x192

    iget-object p3, p0, Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings;->b:Landroid/view/View;

    nop

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-nez p3, :cond_45

    const p3, 0x7f0c00d6

    const/16 v0, 0x107b

    invoke-virtual {p1, p3, p2, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    const/16 v0, 0xed4

    iput-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings;->b:Landroid/view/View;

    const/16 v0, 0x401

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getChildFragmentManager()Landroidx/fragment/app/p;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xca0

    new-instance p2, Landroidx/fragment/app/a;

    nop

    const/16 v0, 0xf9e

    invoke-direct {p2, p1}, Landroidx/fragment/app/a;-><init>(Landroidx/fragment/app/p;)V

    const/16 v0, 0x586

    new-instance p1, Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings$a;

    nop

    const/16 v0, 0x11f1

    invoke-direct {p1}, Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings$a;-><init>()V

    const p3, 0x7f0903a2

    const/16 v0, 0xbb7

    invoke-virtual {p2, p3, p1, v3}, Lvi0;->e(ILandroidx/fragment/app/Fragment;Ljava/lang/String;)V

    const/16 v0, 0xae9

    invoke-virtual {p2, v2}, Landroidx/fragment/app/a;->g(Z)I

    :cond_45
    const/16 v0, 0x192

    iget-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings;->b:Landroid/view/View;

    nop

    if-eqz p1, :cond_58

    const p2, 0x7f090392

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ImageView;

    goto :goto_59

    :cond_58
    move-object p1, v3

    :goto_59
    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x192

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings;->b:Landroid/view/View;

    nop

    if-eqz p2, :cond_70

    const p3, 0x7f09013b

    const/16 v0, 0x11

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    move-object v3, p2

    check-cast v3, Landroid/widget/ImageView;

    :cond_70
    const/4 v0, -0x6

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x40d

    new-instance p2, Lk92;

    nop

    const/16 v0, 0x482

    invoke-direct {p2, p0, v2}, Lk92;-><init>(Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings;I)V

    const/16 v0, 0x5f

    invoke-virtual {p1, p2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0x40d

    new-instance p1, Lk92;

    nop

    const/4 p2, 0x1

    const/16 v0, 0x482

    invoke-direct {p1, p0, p2}, Lk92;-><init>(Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings;I)V

    const/16 v0, 0x5f

    invoke-virtual {v3, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0x140

    sget-boolean p1, Lg4;->a:Z

    nop

    const/16 v0, 0xfb

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x637

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings;->a:Lw82;

    nop

    const/16 v0, 0x177

    invoke-virtual {p2}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Landroid/content/SharedPreferences;

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x394

    invoke-static {p2, p1}, Lg4;->n(Landroid/content/SharedPreferences;Landroidx/fragment/app/l;)V

    const/16 v0, 0x192

    iget-object p0, p0, Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings;->b:Landroid/view/View;

    nop

    check-cast p0, Landroid/view/View;

    return-object p0
.end method
