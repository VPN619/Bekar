.class public final Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings$a;
.super Lsl1;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "a"
.end annotation


# instance fields
.field public final i:Ll92;


# direct methods
.method public constructor <init>()V
    .registers 5

    invoke-direct {p0}, Lsl1;-><init>()V

    const/16 v0, 0x3b8

    new-instance v2, Ll92;

    nop

    const/4 v3, 0x2

    const/16 v0, 0x2cf

    invoke-direct {v2, p0, v3}, Ll92;-><init>(Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings$a;I)V

    const/16 v0, 0x70b

    iput-object v2, p0, Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings$a;->i:Ll92;

    return-void
.end method


# virtual methods
.method public final c()V
    .registers 10

    .prologue
    const/16 v0, 0x1eb

    iget-object v2, p0, Lsl1;->b:Lxl1;

    nop

    if-eqz v2, :cond_228

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v3

    const/16 v0, 0x1eb

    iget-object v4, p0, Lsl1;->b:Lxl1;

    nop

    const/16 v0, 0x4fb

    iget-object v4, v4, Lxl1;->g:Landroidx/preference/PreferenceScreen;

    nop

    const/4 v5, 0x1

    const/16 v0, 0x45d

    iput-boolean v5, v2, Lxl1;->e:Z

    const/16 v0, 0x6c2

    new-instance v6, Lwl1;

    nop

    const/16 v0, 0x1227

    invoke-direct {v6, v3, v2}, Lwl1;-><init>(Landroid/content/Context;Lxl1;)V

    const/16 v0, 0x142

    invoke-virtual {v3}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v3

    const v7, 0x7f16000a

    const/16 v0, 0x89c

    invoke-virtual {v3, v7}, Landroid/content/res/Resources;->getXml(I)Landroid/content/res/XmlResourceParser;

    move-result-object v3

    :try_start_35
    const/16 v0, 0x5cf

    invoke-virtual {v6, v3, v4}, Lwl1;->c(Landroid/content/res/XmlResourceParser;Landroidx/preference/PreferenceGroup;)Landroidx/preference/PreferenceGroup;

    move-result-object v4
    :try_end_3b
    .catchall {:try_start_35 .. :try_end_3b} :catchall_221

    const/16 v0, 0x313

    invoke-interface {v3}, Landroid/content/res/XmlResourceParser;->close()V

    check-cast v4, Landroidx/preference/PreferenceScreen;

    const/16 v0, 0x99f

    invoke-virtual {v4, v2}, Landroidx/preference/Preference;->l(Lxl1;)V

    const/16 v0, 0xf2c

    iget-object v3, v2, Lxl1;->d:Landroid/content/SharedPreferences$Editor;

    nop

    if-eqz v3, :cond_53

    const/16 v0, 0x6f

    invoke-interface {v3}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_53
    const/4 v3, 0x0

    const/16 v0, 0x45d

    iput-boolean v3, v2, Lxl1;->e:Z

    const/16 v0, 0x1eb

    iget-object v2, p0, Lsl1;->b:Lxl1;

    nop

    const/16 v0, 0x4fb

    iget-object v6, v2, Lxl1;->g:Landroidx/preference/PreferenceScreen;

    nop

    if-eq v4, v6, :cond_93

    if-eqz v6, :cond_6b

    const/16 v0, 0xb58

    invoke-virtual {v6}, Landroidx/preference/PreferenceGroup;->o()V

    :cond_6b
    const/16 v0, 0xf99

    iput-object v4, v2, Lxl1;->g:Landroidx/preference/PreferenceScreen;

    const/16 v0, 0xce9

    iput-boolean v5, p0, Lsl1;->d:Z

    const/16 v0, 0xeb2

    iget-boolean v2, p0, Lsl1;->e:Z

    nop

    if-eqz v2, :cond_93

    const/16 v0, 0xf2b

    iget-object v2, p0, Lsl1;->g:Ld8;

    nop

    const/16 v0, 0x10ec

    invoke-virtual {v2, v5}, Landroid/os/Handler;->hasMessages(I)Z

    move-result v4

    if-eqz v4, :cond_88

    goto :goto_93

    :cond_88
    const/16 v0, 0x783

    invoke-virtual {v2, v5}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v2

    const/16 v0, 0x86c

    invoke-virtual {v2}, Landroid/os/Message;->sendToTarget()V

    :cond_93
    :goto_93
    const/16 v0, 0xd5

    new-instance v2, Landroid/util/TypedValue;

    nop

    const/16 v0, 0xe7

    invoke-direct {v2}, Landroid/util/TypedValue;-><init>()V

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v4

    const/16 v0, 0x1a9

    invoke-virtual {v4}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v4

    const v6, 0x7f04029c

    const/16 v0, 0x68

    invoke-virtual {v4, v6, v2, v5}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    const-string/jumbo v4, "dmode"

    const/16 v0, 0x46

    invoke-virtual {p0, v4}, Lsl1;->b(Ljava/lang/String;)Landroidx/preference/Preference;

    move-result-object v4

    const/4 v0, -0x6

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v4, Landroidx/preference/SwitchPreference;

    const/16 v0, 0xa4a

    iget-object v6, p0, Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings$a;->i:Ll92;

    nop

    const/16 v0, 0x95e

    iput-object v6, v4, Landroidx/preference/Preference;->e:Ll92;

    const/16 v0, 0x75f

    iget-boolean v6, v4, Landroidx/preference/TwoStatePreference;->N:Z

    nop

    if-eqz v6, :cond_d4

    const v6, 0x7f080110

    goto :goto_d7

    :cond_d4
    const v6, 0x7f08011f

    :goto_d7
    const/16 v0, 0x741

    iget-object v7, v4, Landroidx/preference/Preference;->a:Landroid/content/Context;

    nop

    const/16 v0, 0x10f1

    invoke-static {v7, v6}, Lqk;->m(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v7

    const/16 v0, 0xc0d

    iget-object v8, v4, Landroidx/preference/Preference;->k:Landroid/graphics/drawable/Drawable;

    nop

    if-eq v8, v7, :cond_f6

    const/16 v0, 0xc4a

    iput-object v7, v4, Landroidx/preference/Preference;->k:Landroid/graphics/drawable/Drawable;

    const/16 v0, 0x370

    iput v3, v4, Landroidx/preference/Preference;->j:I

    const/16 v0, 0xe64

    invoke-virtual {v4}, Landroidx/preference/Preference;->i()V

    :cond_f6
    const/16 v0, 0x370

    iput v6, v4, Landroidx/preference/Preference;->j:I

    const/16 v0, 0xe8

    invoke-virtual {v4}, Landroidx/preference/Preference;->d()Landroid/graphics/drawable/Drawable;

    move-result-object v4

    const/4 v0, -0x6

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x9b

    iget v6, v2, Landroid/util/TypedValue;->data:I

    nop

    const/16 v0, 0xf9

    invoke-virtual {v4, v6}, Landroid/graphics/drawable/Drawable;->setTint(I)V

    const-string/jumbo v4, "atcountdown"

    const/16 v0, 0x46

    invoke-virtual {p0, v4}, Lsl1;->b(Ljava/lang/String;)Landroidx/preference/Preference;

    move-result-object v4

    const/4 v0, -0x6

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v4, Landroidx/preference/SwitchPreference;

    const/16 v0, 0xe8

    invoke-virtual {v4}, Landroidx/preference/Preference;->d()Landroid/graphics/drawable/Drawable;

    move-result-object v4

    const/4 v0, -0x6

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x9b

    iget v6, v2, Landroid/util/TypedValue;->data:I

    nop

    const/16 v0, 0xf9

    invoke-virtual {v4, v6}, Landroid/graphics/drawable/Drawable;->setTint(I)V

    const-string/jumbo v4, "cname"

    const/16 v0, 0x46

    invoke-virtual {p0, v4}, Lsl1;->b(Ljava/lang/String;)Landroidx/preference/Preference;

    move-result-object v4

    const/4 v0, -0x6

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v4, Landroidx/preference/SwitchPreference;

    const/16 v0, 0xe8

    invoke-virtual {v4}, Landroidx/preference/Preference;->d()Landroid/graphics/drawable/Drawable;

    move-result-object v4

    const/4 v0, -0x6

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x9b

    iget v6, v2, Landroid/util/TypedValue;->data:I

    nop

    const/16 v0, 0xf9

    invoke-virtual {v4, v6}, Landroid/graphics/drawable/Drawable;->setTint(I)V

    const-string/jumbo v4, "language"

    const/16 v0, 0x46

    invoke-virtual {p0, v4}, Lsl1;->b(Ljava/lang/String;)Landroidx/preference/Preference;

    move-result-object v4

    const/4 v0, -0x6

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v4, Landroidx/preference/ListPreference;

    const/16 v0, 0xe8

    invoke-virtual {v4}, Landroidx/preference/Preference;->d()Landroid/graphics/drawable/Drawable;

    move-result-object v6

    const/4 v0, -0x6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x9b

    iget v7, v2, Landroid/util/TypedValue;->data:I

    nop

    const/16 v0, 0xf9

    invoke-virtual {v6, v7}, Landroid/graphics/drawable/Drawable;->setTint(I)V

    const-string/jumbo v6, "appfilter"

    const/16 v0, 0x46

    invoke-virtual {p0, v6}, Lsl1;->b(Ljava/lang/String;)Landroidx/preference/Preference;

    move-result-object v6

    const/4 v0, -0x6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x3b8

    new-instance v7, Ll92;

    nop

    const/16 v0, 0x2cf

    invoke-direct {v7, p0, v3}, Ll92;-><init>(Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings$a;I)V

    const/16 v0, 0x392

    iput-object v7, v6, Landroidx/preference/Preference;->f:Lkl1;

    const-string/jumbo v3, "ssettings"

    const/16 v0, 0x46

    invoke-virtual {p0, v3}, Lsl1;->b(Ljava/lang/String;)Landroidx/preference/Preference;

    move-result-object v3

    const/4 v0, -0x6

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xe8

    invoke-virtual {v3}, Landroidx/preference/Preference;->d()Landroid/graphics/drawable/Drawable;

    move-result-object v6

    const/4 v0, -0x6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x9b

    iget v2, v2, Landroid/util/TypedValue;->data:I

    nop

    const/16 v0, 0xf9

    invoke-virtual {v6, v2}, Landroid/graphics/drawable/Drawable;->setTint(I)V

    const/16 v0, 0x3b8

    new-instance v2, Ll92;

    nop

    const/16 v0, 0x2cf

    invoke-direct {v2, p0, v5}, Ll92;-><init>(Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings$a;I)V

    const/16 v0, 0x392

    iput-object v2, v3, Landroidx/preference/Preference;->f:Lkl1;

    const/16 v0, 0xbe

    invoke-virtual {p0, v4}, Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings$a;->d(Landroidx/preference/Preference;)V

    const-string/jumbo v2, "intranet"

    const/16 v0, 0x46

    invoke-virtual {p0, v2}, Lsl1;->b(Ljava/lang/String;)Landroidx/preference/Preference;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xbe

    invoke-virtual {p0, v2}, Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings$a;->d(Landroidx/preference/Preference;)V

    const-string/jumbo v2, "compresspkt"

    const/16 v0, 0x46

    invoke-virtual {p0, v2}, Lsl1;->b(Ljava/lang/String;)Landroidx/preference/Preference;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xbe

    invoke-virtual {p0, v2}, Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings$a;->d(Landroidx/preference/Preference;)V

    const-string/jumbo v2, "encdns"

    const/16 v0, 0x46

    invoke-virtual {p0, v2}, Lsl1;->b(Ljava/lang/String;)Landroidx/preference/Preference;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xbe

    invoke-virtual {p0, v2}, Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings$a;->d(Landroidx/preference/Preference;)V

    const-string/jumbo v2, "dnsP"

    const/16 v0, 0x46

    invoke-virtual {p0, v2}, Lsl1;->b(Ljava/lang/String;)Landroidx/preference/Preference;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xbe

    invoke-virtual {p0, v2}, Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings$a;->d(Landroidx/preference/Preference;)V

    const-string/jumbo v2, "dnsS"

    const/16 v0, 0x46

    invoke-virtual {p0, v2}, Lsl1;->b(Ljava/lang/String;)Landroidx/preference/Preference;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xbe

    invoke-virtual {p0, v2}, Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings$a;->d(Landroidx/preference/Preference;)V

    return-void

    :catchall_221
    move-exception p0

    const/16 v0, 0x313

    invoke-interface {v3}, Landroid/content/res/XmlResourceParser;->close()V

    throw p0

    :cond_228
    const-string/jumbo p0, "This should be called after super.onCreate."

    const/16 v0, 0xe25

    invoke-static {p0}, Lvx2;->j(Ljava/lang/String;)V

    return-void
.end method

.method public final d(Landroidx/preference/Preference;)V
    .registers 7

    .prologue
    instance-of v2, p1, Landroidx/preference/EditTextPreference;

    const/16 v0, 0xa4a

    iget-object v3, p0, Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings$a;->i:Ll92;

    nop

    if-eqz v2, :cond_2b

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p0

    const/16 v0, 0x2a

    invoke-static {p0}, Lxl1;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    move-object v2, p1

    check-cast v2, Landroidx/preference/EditTextPreference;

    const/16 v0, 0x499

    iget-object v2, v2, Landroidx/preference/Preference;->l:Ljava/lang/String;

    nop

    const-string/jumbo v4, ""

    const/16 v0, 0x2e

    invoke-interface {p0, v2, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x918

    invoke-virtual {v3, p1, p0}, Ll92;->b(Landroidx/preference/Preference;Ljava/lang/Object;)V

    :cond_2b
    const/16 v0, 0x95e

    iput-object v3, p1, Landroidx/preference/Preference;->e:Ll92;

    return-void
.end method
