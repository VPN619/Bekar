.class public final Lcom/tlsvpn/tlstunnel/ui/imex/Importar;
.super Lra;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final synthetic o:I


# instance fields
.field public final g:Lw82;

.field public h:Landroidx/appcompat/widget/Toolbar;

.field public i:Landroidx/recyclerview/widget/RecyclerView;

.field public j:Lrq0;

.field public final k:I

.field public final l:I

.field public m:Ljava/lang/String;

.field public final n:Lm3;


# direct methods
.method public constructor <init>()V
    .registers 6

    invoke-direct {p0}, Lra;-><init>()V

    const/16 v0, 0xa84

    new-instance v2, Ld;

    nop

    const/16 v3, 0xc

    const/16 v0, 0x6cb

    invoke-direct {v2, v3, p0}, Ld;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x27a

    new-instance v3, Lw82;

    nop

    const/16 v0, 0x215

    invoke-direct {v3, v2}, Lw82;-><init>(Lzj0;)V

    const/16 v0, 0x5ba

    iput-object v3, p0, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->g:Lw82;

    const/16 v2, 0x1cd0

    const/16 v0, 0xe9f

    iput v2, p0, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->k:I

    const/16 v2, 0x2000

    const/16 v0, 0xd00

    iput v2, p0, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->l:I

    const-string/jumbo v2, ""

    const/16 v0, 0xc24

    iput-object v2, p0, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->m:Ljava/lang/String;

    const/16 v0, 0xa2

    new-instance v2, Ll3;

    nop

    const/4 v3, 0x2

    const/16 v0, 0x9e

    invoke-direct {v2, v3}, Ll3;-><init>(I)V

    const/16 v0, 0x50f

    new-instance v3, Lah;

    nop

    const/16 v4, 0x8

    const/16 v0, 0x3bf

    invoke-direct {v3, v4, p0}, Lah;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0xaa

    invoke-virtual {p0, v2, v3}, Lut;->registerForActivityResult(Lk3;Lj3;)Lm3;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x6b7

    iput-object v2, p0, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->n:Lm3;

    return-void
.end method

.method public static h(Landroid/content/SharedPreferences$Editor;)V
    .registers 7

    const-string/jumbo v2, "cryptoconfig"

    nop

    nop

    const-string/jumbo v3, ""

    const/16 v0, 0x3c

    invoke-interface {p0, v2, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo v2, "prxhost"

    nop

    nop

    const/16 v0, 0x3c

    invoke-interface {p0, v2, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo v2, "prxport"

    nop

    nop

    const/16 v0, 0x3c

    invoke-interface {p0, v2, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo v2, "psrvslctd"

    nop

    nop

    const/4 v4, 0x0

    const/16 v0, 0x48

    invoke-interface {p0, v2, v4}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo v2, "server"

    nop

    nop

    const/16 v0, 0x56

    invoke-interface {p0, v2, v4}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo v2, "port"

    nop

    nop

    const/16 v0, 0x56

    invoke-interface {p0, v2, v4}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo v2, "cport"

    nop

    nop

    const/16 v0, 0x3c

    invoke-interface {p0, v2, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo v2, "pserver"

    nop

    nop

    const/16 v0, 0x48

    invoke-interface {p0, v2, v4}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo v2, "sshhost"

    nop

    nop

    const/16 v0, 0x3c

    invoke-interface {p0, v2, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo v2, "sshport"

    nop

    nop

    const/16 v0, 0x3c

    invoke-interface {p0, v2, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo v2, "sshuser"

    nop

    nop

    const/16 v0, 0x3c

    invoke-interface {p0, v2, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo v2, "sshpass"

    nop

    nop

    const/16 v0, 0x3c

    invoke-interface {p0, v2, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo v2, "metodo"

    nop

    nop

    const/4 v5, 0x1

    const/16 v0, 0x56

    invoke-interface {p0, v2, v5}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo v2, "upayload"

    nop

    nop

    const/16 v0, 0x48

    invoke-interface {p0, v2, v4}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo v2, "payload"

    nop

    nop

    const/16 v0, 0x3c

    invoke-interface {p0, v2, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo v2, "usnihost"

    nop

    nop

    const/16 v0, 0x48

    invoke-interface {p0, v2, v4}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo v2, "snihost"

    nop

    nop

    const/16 v0, 0x3c

    invoke-interface {p0, v2, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo v2, "upayloadat"

    nop

    nop

    const/16 v0, 0x48

    invoke-interface {p0, v2, v4}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo v2, "payloadat"

    nop

    nop

    const/16 v0, 0x3c

    invoke-interface {p0, v2, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo v2, "uprx"

    nop

    nop

    const/16 v0, 0x48

    invoke-interface {p0, v2, v4}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo v2, "udpgwport"

    nop

    nop

    const-string/jumbo v3, "7300"

    nop

    nop

    const/16 v0, 0x3c

    invoke-interface {p0, v2, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/16 v0, 0x6f

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method


# virtual methods
.method public final g(Ljava/lang/String;)V
    .registers 16

    .prologue
    const/16 v0, 0x1bb

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->j:Lrq0;

    nop

    const/4 v3, 0x0

    const-string/jumbo v4, "adaptador"

    nop

    nop

    if-eqz v2, :cond_195

    const/16 v0, 0x342

    iget-object v2, v2, Lrq0;->c:Ljava/util/ArrayList;

    nop

    const/16 v0, 0x15b

    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    const/16 v0, 0x1bb

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->j:Lrq0;

    nop

    if-eqz v2, :cond_190

    const/16 v0, 0x342

    iget-object v2, v2, Lrq0;->c:Ljava/util/ArrayList;

    nop

    const-string/jumbo v5, "/"

    nop

    nop

    const/16 v0, 0x84

    invoke-static {p1, v5}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    const/4 v7, 0x1

    const-string/jumbo v8, "../"

    nop

    nop

    const-string/jumbo v9, ""

    if-eqz v6, :cond_46

    const/16 v0, 0x2ea

    invoke-static {v9}, Landroid/os/Environment;->getExternalStoragePublicDirectory(Ljava/lang/String;)Ljava/io/File;

    move-result-object p1

    const/16 v0, 0x125

    invoke-virtual {p1}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object p1

    goto :goto_af

    :cond_46
    const/16 v0, 0x84

    invoke-static {p1, v8}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    const/16 v0, 0x21e

    iget-object v10, p0, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->m:Ljava/lang/String;

    nop

    if-eqz v6, :cond_93

    const/16 v0, 0x47

    invoke-virtual {v10}, Ljava/lang/String;->length()I

    move-result p1

    const/16 v0, 0x21e

    iget-object v6, p0, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->m:Ljava/lang/String;

    nop

    check-cast v5, Ljava/lang/String;

    filled-new-array {v5}, [Ljava/lang/String;

    move-result-object v5

    const/4 v11, 0x6

    const/16 v0, 0x89

    invoke-static {v6, v5, v11}, Lc72;->E0(Ljava/lang/CharSequence;[Ljava/lang/String;I)Ljava/util/List;

    move-result-object v5

    const/16 v0, 0x306

    invoke-static {v5}, Lbs;->q0(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    const/16 v0, 0x47

    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v5

    sub-int/2addr p1, v5

    sub-int/2addr p1, v7

    const/16 v0, 0x21e

    iget-object v5, p0, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->m:Ljava/lang/String;

    nop

    const/16 v0, 0x47

    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v5

    const/16 v0, 0x21c

    invoke-static {v10, p1, v5}, Lc72;->z0(Ljava/lang/CharSequence;II)Ljava/lang/CharSequence;

    move-result-object p1

    const/16 v0, 0xcb

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    goto :goto_af

    :cond_93
    const/4 v0, -0x3

    new-instance v5, Ljava/lang/StringBuilder;

    nop

    const/4 v0, -0x4

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v0, 0x0

    invoke-virtual {v5, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v6, 0x2f

    const/16 v0, 0x1b

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {v5, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    :goto_af
    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xd7

    new-instance v5, Ljava/util/ArrayList;

    nop

    const/16 v0, 0x16b

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    const/16 v0, 0xd7

    new-instance v6, Ljava/util/ArrayList;

    nop

    const/16 v0, 0x16b

    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    const/16 v0, 0x2ea

    invoke-static {v9}, Landroid/os/Environment;->getExternalStoragePublicDirectory(Ljava/lang/String;)Ljava/io/File;

    move-result-object v9

    const/16 v0, 0x125

    invoke-virtual {v9}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v9

    const/16 v0, 0x128

    invoke-virtual {p1, v9}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_e0

    const/16 v0, 0x174

    invoke-virtual {v6, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_e0
    const-string/jumbo v8, "Android/data"

    nop

    nop

    const/4 v9, 0x0

    const/16 v0, 0x390

    invoke-static {p1, v8, v9}, Lk72;->e0(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v8

    if-eqz v8, :cond_101

    const/16 v0, 0x1fc

    sget v8, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 v10, 0x1d

    if-le v8, v10, :cond_101

    const-string/jumbo v8, "com.tlsvpn.tlstunnel"

    nop

    nop

    const/16 v0, 0x174

    invoke-virtual {v6, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_101
    const/16 v0, 0x24e

    new-instance v8, Ljava/io/File;

    nop

    const/16 v0, 0x212

    invoke-direct {v8, p1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/16 v0, 0xb95

    invoke-virtual {v8}, Ljava/io/File;->listFiles()[Ljava/io/File;

    move-result-object v8

    if-eqz v8, :cond_159

    array-length v10, v8

    :goto_114
    if-ge v9, v10, :cond_159

    aget-object v11, v8, v9

    const/16 v0, 0xc2a

    invoke-virtual {v11}, Ljava/io/File;->isFile()Z

    move-result v12

    if-eqz v12, :cond_143

    const/16 v0, 0x1b7

    invoke-virtual {v11}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v12

    const/4 v0, -0x6

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string/jumbo v13, ".tls"

    nop

    nop

    const/16 v0, 0x390

    invoke-static {v12, v13, v7}, Lk72;->e0(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v12

    if-eqz v12, :cond_143

    const/16 v0, 0x1b7

    invoke-virtual {v11}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v11

    const/16 v0, 0x174

    invoke-virtual {v6, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_156

    :cond_143
    const/16 v0, 0x1118

    invoke-virtual {v11}, Ljava/io/File;->isDirectory()Z

    move-result v12

    if-eqz v12, :cond_156

    const/16 v0, 0x1b7

    invoke-virtual {v11}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v11

    const/16 v0, 0x174

    invoke-virtual {v5, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_156
    :goto_156
    add-int/lit8 v9, v9, 0x1

    goto :goto_114

    :cond_159
    const/16 v0, 0x371

    invoke-static {v6}, Lgs;->Z(Ljava/util/List;)V

    const/16 v0, 0x371

    invoke-static {v5}, Lgs;->Z(Ljava/util/List;)V

    const/16 v0, 0x10eb

    invoke-static {v5}, Lbs;->C0(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v5

    check-cast v5, Ljava/util/Collection;

    const/16 v0, 0x12a

    invoke-virtual {v6, v5}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    const/16 v0, 0xc24

    iput-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->m:Ljava/lang/String;

    const/16 v0, 0x12a

    invoke-virtual {v2, v6}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    const/16 v0, 0x1bb

    iget-object p0, p0, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->j:Lrq0;

    nop

    if-eqz p0, :cond_18b

    const/16 v0, 0x504

    iget-object p0, p0, Lqq1;->a:Lrq1;

    nop

    const/16 v0, 0xc42

    invoke-virtual {p0}, Lrq1;->b()V

    return-void

    :cond_18b
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_190
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_195
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3
.end method

.method public final i(Ljava/lang/String;)V
    .registers 17

    .prologue
    const/16 v6, 0x8ea

    new-instance v8, Lou;

    nop

    const/16 v6, 0x1004

    iget-object v9, p0, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->g:Lw82;

    nop

    const/16 v6, 0x177

    invoke-virtual {v9}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Landroid/content/SharedPreferences;

    const/4 v6, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xa82

    invoke-virtual {p0}, Lra;->getResources()Landroid/content/res/Resources;

    move-result-object v11

    const/4 v6, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v12, 0x1

    const/16 v6, 0x83d

    move v0, v6

    move-object v1, v8

    move-object v2, v10

    move-object v3, v11

    move v4, v12

    move v5, v12

    invoke-direct/range {v1 .. v5}, Lou;-><init>(Landroid/content/SharedPreferences;Landroid/content/res/Resources;ZZ)V

    const/16 v6, 0x20c

    invoke-virtual {v8}, Lou;->a()V

    new-array v10, v12, [C

    const/4 v11, 0x0

    const/16 v13, 0x3a

    aput-char v13, v10, v11

    const/16 v6, 0x31

    move-object/from16 v0, p1

    invoke-static {v0, v10}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v10

    const/16 v6, 0x24

    invoke-interface {v10, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    const/16 v6, 0x2e4

    sget-object v13, Lip;->a:Ljava/nio/charset/Charset;

    nop

    const/16 v6, 0x2c

    invoke-virtual {v10, v13}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v10

    const/4 v6, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x11e1

    invoke-virtual {v8, v10}, Lou;->b([B)Z

    move-result v10

    const-string/jumbo v13, "Incompatible"

    nop

    nop

    if-eqz v10, :cond_256

    const/16 v6, 0x1fc

    sget v10, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 v14, 0x1d

    if-ge v10, v14, :cond_89

    const/16 v6, 0x1002

    iget-boolean v10, v8, Lou;->z:Z

    nop

    if-nez v10, :cond_7c

    const/16 v6, 0x9d

    iget-boolean v10, v8, Lou;->h:Z

    nop

    if-nez v10, :cond_7c

    goto :goto_89

    :cond_7c
    const/16 v6, 0x36a

    new-instance p0, Ljava/lang/Exception;

    nop

    const/16 v6, 0x46d

    invoke-direct {p0, v13}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    check-cast p0, Ljava/lang/Throwable;

    throw p0

    :cond_89
    :goto_89
    const/16 v6, 0x177

    invoke-virtual {v9}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Landroid/content/SharedPreferences;

    const/4 v6, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x7a

    invoke-interface {v9}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v9

    const/16 v6, 0x75

    iget-boolean v10, v8, Lou;->w:Z

    nop

    const-string/jumbo v13, "pserver"

    nop

    nop

    if-eqz v10, :cond_ff

    const/16 v6, 0x7ec

    iget-boolean v10, v8, Lou;->y:Z

    nop

    if-eqz v10, :cond_dd

    const/16 v6, 0x905

    sget-boolean v10, Lmi2;->a:Z

    nop

    const/16 v6, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v10

    const/4 v6, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xa5c

    invoke-static {v10}, Lmi2;->f(Landroid/content/Context;)Z

    move-result v10

    if-eqz v10, :cond_dd

    const/16 v6, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const p1, 0x7f130045

    const/16 v6, 0x6d8

    move/from16 v0, p1

    invoke-static {p0, v0, v12}, Landroid/widget/Toast;->makeText(Landroid/content/Context;II)Landroid/widget/Toast;

    move-result-object p0

    const/16 v6, 0x8f6

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    goto/16 :goto_250

    :cond_dd
    const/16 v6, 0x41f

    invoke-static {v9}, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->h(Landroid/content/SharedPreferences$Editor;)V

    const-string/jumbo p0, "cryptoconfig"

    nop

    nop

    const/16 v6, 0x3c

    move-object/from16 v0, p1

    invoke-interface {v9, p0, v0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/16 v6, 0x9d

    iget-boolean v6, v8, Lou;->h:Z

    move/16 p1, v6

    const/16 v6, 0x48

    move/from16 v0, p1

    invoke-interface {p0, v13, v0}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    goto/16 :goto_250

    :cond_ff
    const/16 v6, 0x41f

    invoke-static {v9}, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->h(Landroid/content/SharedPreferences$Editor;)V

    const-string/jumbo p0, "server"

    nop

    nop

    const/16 v6, 0x56

    invoke-interface {v9, p0, v11}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo p1, "port"

    nop

    nop

    const/16 v6, 0x56

    move-object/from16 v0, p1

    invoke-interface {p0, v0, v11}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo p1, "psrvslctd"

    nop

    nop

    const/16 v6, 0xf1

    iget-boolean v10, v8, Lou;->c:Z

    nop

    const/16 v6, 0x48

    move-object/from16 v0, p1

    invoke-interface {p0, v0, v10}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/16 v6, 0x9d

    iget-boolean v6, v8, Lou;->h:Z

    move/16 p1, v6

    const/16 v6, 0x48

    move/from16 v0, p1

    invoke-interface {p0, v13, v0}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo p1, "sshuser"

    nop

    nop

    const/16 v6, 0x2e2

    iget-object v10, v8, Lou;->k:Ljava/lang/String;

    nop

    const/16 v6, 0x3c

    move-object/from16 v0, p1

    invoke-interface {p0, v0, v10}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo p1, "sshpass"

    nop

    nop

    const/16 v6, 0xef9

    iget-object v10, v8, Lou;->l:Ljava/lang/String;

    nop

    const/16 v6, 0x3c

    move-object/from16 v0, p1

    invoke-interface {p0, v0, v10}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo p1, "sshhost"

    nop

    nop

    const/16 v6, 0x3b

    iget-object v10, v8, Lou;->i:Ljava/lang/String;

    nop

    const/16 v6, 0x3c

    move-object/from16 v0, p1

    invoke-interface {p0, v0, v10}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo p1, "sshport"

    nop

    nop

    const/16 v6, 0x34b

    iget-object v10, v8, Lou;->j:Ljava/lang/String;

    nop

    const/16 v6, 0x3c

    move-object/from16 v0, p1

    invoke-interface {p0, v0, v10}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo p1, "cport"

    nop

    nop

    const/16 v6, 0xe1

    iget-object v10, v8, Lou;->f:Ljava/lang/String;

    nop

    const/16 v6, 0x3c

    move-object/from16 v0, p1

    invoke-interface {p0, v0, v10}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo p1, "metodo"

    nop

    nop

    const/16 v6, 0x1b8

    iget v10, v8, Lou;->m:I

    nop

    const/16 v6, 0x56

    move-object/from16 v0, p1

    invoke-interface {p0, v0, v10}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo p1, "upayload"

    nop

    nop

    const/16 v6, 0x8eb

    iget-boolean v10, v8, Lou;->n:Z

    nop

    const/16 v6, 0x48

    move-object/from16 v0, p1

    invoke-interface {p0, v0, v10}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo p1, "payload"

    nop

    nop

    const/16 v6, 0x285

    iget-object v10, v8, Lou;->o:Ljava/lang/String;

    nop

    const/16 v6, 0x3c

    move-object/from16 v0, p1

    invoke-interface {p0, v0, v10}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo p1, "usnihost"

    nop

    nop

    const/16 v6, 0x7f

    iget-boolean v10, v8, Lou;->p:Z

    nop

    const/16 v6, 0x48

    move-object/from16 v0, p1

    invoke-interface {p0, v0, v10}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo p1, "snihost"

    nop

    nop

    const/16 v6, 0x26e

    iget-object v10, v8, Lou;->q:Ljava/lang/String;

    nop

    const/16 v6, 0x3c

    move-object/from16 v0, p1

    invoke-interface {p0, v0, v10}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo p1, "upayloadat"

    nop

    nop

    const/16 v6, 0xfdd

    iget-boolean v10, v8, Lou;->r:Z

    nop

    const/16 v6, 0x48

    move-object/from16 v0, p1

    invoke-interface {p0, v0, v10}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo p1, "payloadat"

    nop

    nop

    const/16 v6, 0x2e3

    iget-object v10, v8, Lou;->s:Ljava/lang/String;

    nop

    const/16 v6, 0x3c

    move-object/from16 v0, p1

    invoke-interface {p0, v0, v10}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo p1, "uprx"

    nop

    nop

    const/16 v6, 0x3f5

    iget-boolean v10, v8, Lou;->t:Z

    nop

    const/16 v6, 0x48

    move-object/from16 v0, p1

    invoke-interface {p0, v0, v10}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo p1, "prxhost"

    nop

    nop

    const/16 v6, 0x1e1

    iget-object v10, v8, Lou;->u:Ljava/lang/String;

    nop

    const/16 v6, 0x3c

    move-object/from16 v0, p1

    invoke-interface {p0, v0, v10}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo p1, "prxport"

    nop

    nop

    const/16 v6, 0x1f4

    iget-object v8, v8, Lou;->v:Ljava/lang/String;

    nop

    const/16 v6, 0x3c

    move-object/from16 v0, p1

    invoke-interface {p0, v0, v8}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/16 v6, 0x6f

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :goto_250
    const/16 v6, 0x6f

    invoke-interface {v9}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void

    :cond_256
    const/16 v6, 0x52e

    invoke-static {v13}, Lz6;->s(Ljava/lang/String;)V

    return-void
.end method

.method public final j(Ljava/lang/String;Z)V
    .registers 7

    .prologue
    if-eqz p2, :cond_3

    goto :goto_20

    :cond_3
    :try_start_3
    new-instance v2, Ljava/lang/String;

    const/16 v0, 0x24e

    new-instance v3, Ljava/io/File;

    nop

    const/16 v0, 0x212

    invoke-direct {v3, p1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/16 v0, 0xaea

    invoke-static {v3}, Lwd0;->g0(Ljava/io/File;)[B

    move-result-object p1

    const/16 v0, 0x2e4

    sget-object v3, Lip;->a:Ljava/nio/charset/Charset;

    nop

    check-cast v3, Ljava/nio/charset/Charset;

    invoke-direct {v2, p1, v3}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    move-object p1, v2

    :goto_20
    const/16 v0, 0xcc7

    invoke-virtual {p0, p1}, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->i(Ljava/lang/String;)V
    :try_end_25
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_25} :catch_26

    goto :goto_3b

    :catch_26
    const p1, 0x7f130069

    const/16 v0, 0xb4

    invoke-virtual {p0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string/jumbo v2, ""

    const/16 v0, 0x430

    invoke-virtual {p0, p1, v2}, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->k(Ljava/lang/String;Ljava/lang/String;)V

    :goto_3b
    if-eqz p2, :cond_4e

    const/16 v0, 0x5b

    new-instance p1, Landroid/content/Intent;

    nop

    const-class p2, Lcom/tlsvpn/tlstunnel/MainActivity;

    const/16 v0, 0xd0

    invoke-direct {p1, p0, p2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/16 v0, 0xc9

    invoke-virtual {p0, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    :cond_4e
    const/16 v0, 0x5b

    new-instance p1, Landroid/content/Intent;

    nop

    const-string/jumbo p2, "restoreHome"

    nop

    nop

    const/16 v0, 0x62

    invoke-direct {p1, p2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p2

    const/16 v0, 0x4a

    invoke-virtual {p2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p2

    const/16 v0, 0x64

    invoke-virtual {p1, p2}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/16 v0, 0x63

    invoke-virtual {p0, p1}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    const/16 v0, 0x107

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    return-void
.end method

.method public final k(Ljava/lang/String;Ljava/lang/String;)V
    .registers 7

    const/16 v0, 0x5b

    new-instance v2, Landroid/content/Intent;

    nop

    const-string/jumbo v3, "ssb"

    nop

    nop

    const/16 v0, 0x62

    invoke-direct {v2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string/jumbo v3, "msg"

    nop

    nop

    const/16 v0, 0x4b

    invoke-virtual {v2, v3, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string/jumbo p1, "dur"

    nop

    nop

    const/16 v3, 0xbb8

    const/16 v0, 0x29

    invoke-virtual {v2, p1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string/jumbo p1, "act"

    nop

    nop

    const/16 v0, 0x4b

    invoke-virtual {v2, p1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const/16 v0, 0x4a

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0x64

    invoke-virtual {v2, p1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/16 v0, 0x63

    invoke-virtual {p0, v2}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    return-void
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .registers 24

    .prologue
    const/16 v7, 0xddd

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-super {v0, v1}, Landroidx/fragment/app/l;->onCreate(Landroid/os/Bundle;)V

    const p1, 0x7f0c003f

    const/16 v7, 0x1157

    move-object/from16 v0, p0

    move/from16 v1, p1

    invoke-virtual {v0, v1}, Lra;->setContentView(I)V

    const p1, 0x7f09014d

    const/16 v7, 0x41

    move-object/from16 v0, p0

    move/from16 v1, p1

    invoke-virtual {v0, v1}, Lra;->findViewById(I)Landroid/view/View;

    move-result-object p1

    const/4 v7, -0x6

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p1, Landroidx/appcompat/widget/Toolbar;

    const/16 v7, 0x1180

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iput-object v1, v0, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->h:Landroidx/appcompat/widget/Toolbar;

    const p1, 0x7f090060

    const/16 v7, 0x41

    move-object/from16 v0, p0

    move/from16 v1, p1

    invoke-virtual {v0, v1}, Lra;->findViewById(I)Landroid/view/View;

    move-result-object p1

    const/4 v7, -0x6

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p1, Landroidx/recyclerview/widget/RecyclerView;

    const/16 v7, 0xd29

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iput-object v1, v0, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->i:Landroidx/recyclerview/widget/RecyclerView;

    const/16 v7, 0x752

    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->h:Landroidx/appcompat/widget/Toolbar;

    move-object/16 p1, v7

    const/4 v10, 0x0

    if-eqz p1, :cond_45c

    const/16 v7, 0xad0

    move-object/from16 v0, p0

    invoke-virtual {v0}, Lra;->e()Leb;

    move-result-object v9

    check-cast v9, Lsb;

    const/16 v7, 0xfd7

    iget-object v11, v9, Lsb;->j:Ljava/lang/Object;

    nop

    instance-of v12, v11, Landroid/app/Activity;

    const/4 v13, 0x1

    if-nez v12, :cond_70

    goto :goto_ce

    :cond_70
    const/16 v7, 0x9d2

    invoke-virtual {v9}, Lsb;->F()V

    const/16 v7, 0xe96

    iget-object v12, v9, Lsb;->n:Lq23;

    nop

    instance-of v14, v12, Lro2;

    if-nez v14, :cond_44f

    const/16 v7, 0xfa9

    iput-object v10, v9, Lsb;->o:Lz72;

    if-eqz v12, :cond_89

    const/16 v7, 0xfe1

    invoke-virtual {v12}, Lq23;->I()V

    :cond_89
    const/16 v7, 0x30a

    iput-object v10, v9, Lsb;->n:Lq23;

    const/16 v7, 0x6cd

    new-instance v12, Lqb2;

    nop

    instance-of v14, v11, Landroid/app/Activity;

    if-eqz v14, :cond_9f

    check-cast v11, Landroid/app/Activity;

    const/16 v7, 0xe88

    invoke-virtual {v11}, Landroid/app/Activity;->getTitle()Ljava/lang/CharSequence;

    move-result-object v11

    goto :goto_a4

    :cond_9f
    const/16 v7, 0x1126

    iget-object v11, v9, Lsb;->p:Ljava/lang/CharSequence;

    nop

    :goto_a4
    const/16 v7, 0x503

    iget-object v14, v9, Lsb;->m:Lmb;

    nop

    const/16 v7, 0x83b

    move-object/from16 v0, p1

    invoke-direct {v12, v0, v11, v14}, Lqb2;-><init>(Landroidx/appcompat/widget/Toolbar;Ljava/lang/CharSequence;Lmb;)V

    const/16 v7, 0x30a

    iput-object v12, v9, Lsb;->n:Lq23;

    const/16 v7, 0x503

    iget-object v11, v9, Lsb;->m:Lmb;

    nop

    const/16 v7, 0x852

    iget-object v12, v12, Lqb2;->w:Lpb2;

    nop

    const/16 v7, 0x84c

    iput-object v12, v11, Lmb;->b:Lpb2;

    const/16 v7, 0xc05

    move-object/from16 v0, p1

    invoke-virtual {v0, v13}, Landroidx/appcompat/widget/Toolbar;->setBackInvokedCallbackEnabled(Z)V

    const/16 v7, 0xe58

    invoke-virtual {v9}, Lsb;->e()V

    :goto_ce
    const/16 v7, 0x336

    move-object/from16 v0, p0

    invoke-virtual {v0}, Lra;->f()Lq23;

    move-result-object p1

    if-eqz p1, :cond_df

    const/16 v7, 0x95d

    move-object/from16 v0, p1

    invoke-virtual {v0, v13}, Lq23;->S(Z)V

    :cond_df
    const/16 v7, 0x336

    move-object/from16 v0, p0

    invoke-virtual {v0}, Lra;->f()Lq23;

    move-result-object p1

    if-eqz p1, :cond_f0

    const/16 v7, 0xb70

    move-object/from16 v0, p1

    invoke-virtual {v0}, Lq23;->T()V

    :cond_f0
    const/16 v7, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    if-eqz p1, :cond_2d0

    const/16 v7, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const/16 v7, 0x2f

    move-object/from16 v0, p1

    invoke-virtual {v0}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p1

    const-string/jumbo v9, "android.intent.action.VIEW"

    nop

    nop

    const/16 v7, 0x84

    move-object/from16 v0, p1

    invoke-static {v0, v9}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_2d0

    const/16 v7, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const/16 v7, 0x187

    move-object/from16 v0, p1

    invoke-virtual {v0}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p1

    if-eqz p1, :cond_2d0

    :try_start_12b
    const/16 v7, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const/16 v7, 0x779

    move-object/from16 v0, p1

    invoke-virtual {v0}, Landroid/content/Intent;->getScheme()Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_296

    const/16 v7, 0x51

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v9
    :try_end_145
    .catch Ljava/lang/OutOfMemoryError; {:try_start_12b .. :try_end_145} :catch_296
    .catch Ljava/lang/Exception; {:try_start_12b .. :try_end_145} :catch_296

    const v11, 0x2ff57c

    const/16 v7, 0x11fe

    move-object/from16 v0, p0

    iget v12, v0, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->l:I

    nop

    if-eq v9, v11, :cond_248

    const v11, 0x38b73479

    if-eq v9, v11, :cond_158

    goto/16 :goto_296

    :cond_158
    :try_start_158
    const-string/jumbo v9, "content"

    nop

    nop

    const/4 v7, -0x7

    move-object/from16 v0, p1

    invoke-virtual {v0, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1
    :try_end_164
    .catch Ljava/lang/OutOfMemoryError; {:try_start_158 .. :try_end_164} :catch_296
    .catch Ljava/lang/Exception; {:try_start_158 .. :try_end_164} :catch_296

    if-eqz p1, :cond_296

    const-wide/16 v14, -0x1

    :try_start_168
    const/16 v7, 0x1d2

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v16

    const/16 v7, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const/16 v7, 0x187

    move-object/from16 v0, p1

    invoke-virtual {v0}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v17

    const/4 v7, -0x6

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v20, 0x0

    const/16 v21, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v7, 0xc9e

    move v0, v7

    move-object/from16 v1, v16

    move-object/from16 v2, v17

    move-object/from16 v3, v18

    move-object/from16 v4, v19

    move-object/from16 v5, v20

    move-object/from16 v6, v21

    invoke-virtual/range {v1 .. v6}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object p1

    if-eqz p1, :cond_1e0

    check-cast p1, Ljava/io/Closeable;
    :try_end_1a5
    .catch Ljava/lang/Exception; {:try_start_168 .. :try_end_1a5} :catch_1e0
    .catch Ljava/lang/OutOfMemoryError; {:try_start_168 .. :try_end_1a5} :catch_296

    :try_start_1a5
    move-object/from16 v9, p1

    check-cast v9, Landroid/database/Cursor;

    const/16 v7, 0x7ee

    invoke-interface {v9}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v11

    if-eqz v11, :cond_1cc

    const-string/jumbo v11, "_size"

    nop

    nop

    const/16 v7, 0x711

    invoke-interface {v9, v11}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v11

    const/16 v16, -0x1

    move/from16 v0, v16

    if-eq v11, v0, :cond_1cc

    const/16 v7, 0x11c

    invoke-interface {v9, v11}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v16
    :try_end_1c8
    .catchall {:try_start_1a5 .. :try_end_1c8} :catchall_1c9

    goto :goto_1ce

    :catchall_1c9
    move-exception v9

    move-object v11, v9

    goto :goto_1d6

    :cond_1cc
    move-wide/from16 v16, v14

    :goto_1ce
    :try_start_1ce
    const/16 v7, 0x1103

    move-object/from16 v0, p1

    invoke-interface {v0}, Ljava/io/Closeable;->close()V
    :try_end_1d5
    .catch Ljava/lang/Exception; {:try_start_1ce .. :try_end_1d5} :catch_1e2
    .catch Ljava/lang/OutOfMemoryError; {:try_start_1ce .. :try_end_1d5} :catch_296

    goto :goto_1e2

    :goto_1d6
    :try_start_1d6
    throw v11
    :try_end_1d7
    .catchall {:try_start_1d6 .. :try_end_1d7} :catchall_1d7

    :catchall_1d7
    move-exception v9

    :try_start_1d8
    const/16 v7, 0x343

    move-object/from16 v0, p1

    invoke-static {v0, v11}, Lmd3;->j(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    throw v9
    :try_end_1e0
    .catch Ljava/lang/Exception; {:try_start_1d8 .. :try_end_1e0} :catch_1e0
    .catch Ljava/lang/OutOfMemoryError; {:try_start_1d8 .. :try_end_1e0} :catch_296

    :catch_1e0
    :cond_1e0
    move-wide/from16 v16, v14

    :catch_1e2
    :goto_1e2
    cmp-long p1, v16, v14

    if-eqz p1, :cond_1ed

    int-to-long v11, v12

    cmp-long p1, v16, v11

    if-lez p1, :cond_1ed

    goto/16 :goto_296

    :cond_1ed
    :try_start_1ed
    const/16 v7, 0x1d2

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p1

    const/16 v7, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v9

    const/16 v7, 0x187

    invoke-virtual {v9}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v9

    const/4 v7, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0xd0a

    move-object/from16 v0, p1

    invoke-virtual {v0, v9}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object p1

    const/4 v7, -0x6

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x858

    new-instance v9, Ljava/io/ByteArrayOutputStream;

    nop

    const/16 v7, 0x63b

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/io/InputStream;->available()I

    move-result v11

    const/16 v12, 0x2000

    const/16 v7, 0xff6

    invoke-static {v12, v11}, Ljava/lang/Math;->max(II)I

    move-result v11

    const/16 v7, 0xf6b

    invoke-direct {v9, v11}, Ljava/io/ByteArrayOutputStream;-><init>(I)V

    const/16 v7, 0xee1

    move-object/from16 v0, p1

    invoke-static {v0, v9}, Luz;->l(Ljava/io/InputStream;Ljava/io/ByteArrayOutputStream;)V

    const/16 v7, 0xd3f

    invoke-virtual {v9}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v9

    const/4 v7, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x122

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/io/InputStream;->close()V

    goto :goto_297

    :cond_248
    const-string/jumbo v9, "file"

    nop

    nop

    const/4 v7, -0x7

    move-object/from16 v0, p1

    invoke-virtual {v0, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-nez p1, :cond_257

    goto :goto_296

    :cond_257
    const/16 v7, 0x24e

    new-instance p1, Ljava/io/File;

    nop

    const/16 v7, 0x28

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v9

    const/16 v7, 0x187

    invoke-virtual {v9}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v9

    const/4 v7, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x441

    invoke-virtual {v9}, Landroid/net/Uri;->getPath()Ljava/lang/String;

    move-result-object v9

    const/4 v7, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x212

    move-object/from16 v0, p1

    invoke-direct {v0, v9}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/16 v7, 0x9b7

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/io/File;->length()J

    move-result-wide v14

    int-to-long v11, v12

    cmp-long v9, v14, v11

    if-lez v9, :cond_28d

    goto :goto_296

    :cond_28d
    const/16 v7, 0xaea

    move-object/from16 v0, p1

    invoke-static {v0}, Lwd0;->g0(Ljava/io/File;)[B

    move-result-object v9
    :try_end_295
    .catch Ljava/lang/OutOfMemoryError; {:try_start_1ed .. :try_end_295} :catch_296
    .catch Ljava/lang/Exception; {:try_start_1ed .. :try_end_295} :catch_296

    goto :goto_297

    :catch_296
    :cond_296
    :goto_296
    move-object v9, v10

    :goto_297
    if-eqz v9, :cond_2b1

    new-instance p1, Ljava/lang/String;

    const/16 v7, 0x2e4

    sget-object v10, Lip;->a:Ljava/nio/charset/Charset;

    nop

    check-cast v10, Ljava/nio/charset/Charset;

    move-object/from16 v0, p1

    invoke-direct {v0, v9, v10}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const/16 v7, 0x64f

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual {v0, v1, v13}, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->j(Ljava/lang/String;Z)V

    return-void

    :cond_2b1
    const p1, 0x7f130069

    const/16 v7, 0xb4

    move-object/from16 v0, p0

    move/from16 v1, p1

    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v7, -0x6

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string/jumbo v9, ""

    const/16 v7, 0x430

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual {v0, v1, v9}, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->k(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2d0
    const/16 v7, 0x1fc

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 v9, 0x1e

    move/from16 v0, p1

    if-lt v0, v9, :cond_324

    const/16 v7, 0x5b

    new-instance p1, Landroid/content/Intent;

    nop

    const-string/jumbo v9, "android.intent.action.OPEN_DOCUMENT"

    nop

    nop

    const/16 v7, 0x62

    move-object/from16 v0, p1

    invoke-direct {v0, v9}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string/jumbo v9, "application/octet-stream"

    nop

    nop

    const/16 v7, 0x3dd

    move-object/from16 v0, p1

    invoke-virtual {v0, v9}, Landroid/content/Intent;->setType(Ljava/lang/String;)Landroid/content/Intent;

    const-string/jumbo v9, "android.intent.category.OPENABLE"

    nop

    nop

    const/16 v7, 0xcce

    move-object/from16 v0, p1

    invoke-virtual {v0, v9}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    const-string/jumbo v9, "android.intent.extra.ALLOW_MULTIPLE"

    nop

    nop

    const/4 v11, 0x0

    const/16 v7, 0x178

    move-object/from16 v0, p1

    invoke-virtual {v0, v9, v11}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    const/16 v7, 0x600

    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->n:Lm3;

    move-object/16 p0, v7

    const/16 v7, 0xad

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual {v0, v1, v10}, Lm3;->a(Ljava/lang/Object;Lf3;)V

    return-void

    :cond_324
    const/16 v7, 0xc70

    new-instance p1, Lrq0;

    nop

    const/16 v7, 0xd7

    new-instance v9, Ljava/util/ArrayList;

    nop

    const/16 v7, 0x16b

    invoke-direct {v9}, Ljava/util/ArrayList;-><init>()V

    const/16 v7, 0xcb5

    move-object/from16 v0, p1

    move-object/from16 v1, p0

    invoke-direct {v0, v9, v1}, Lrq0;-><init>(Ljava/util/ArrayList;Lcom/tlsvpn/tlstunnel/ui/imex/Importar;)V

    const/16 v7, 0x7cc

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    iput-object v1, v0, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->j:Lrq0;

    const/16 v7, 0x191

    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->i:Landroidx/recyclerview/widget/RecyclerView;

    move-object/16 p1, v7

    const-string/jumbo v9, "arquivos"

    nop

    nop

    if-eqz p1, :cond_44a

    const/16 v7, 0xf33

    new-instance v11, Landroidx/recyclerview/widget/LinearLayoutManager;

    nop

    const/16 v7, 0xda3

    invoke-direct {v11, v13}, Landroidx/recyclerview/widget/LinearLayoutManager;-><init>(I)V

    const/16 v7, 0x5ce

    move-object/from16 v0, p1

    invoke-virtual {v0, v11}, Landroidx/recyclerview/widget/RecyclerView;->setLayoutManager(Lzq1;)V

    const/16 v7, 0x191

    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->i:Landroidx/recyclerview/widget/RecyclerView;

    move-object/16 p1, v7

    if-eqz p1, :cond_445

    const/16 v7, 0xeca

    move-object/from16 v0, p1

    invoke-virtual {v0, v13}, Landroidx/recyclerview/widget/RecyclerView;->setHasFixedSize(Z)V

    const/16 v7, 0xf80

    new-instance p1, Lp50;

    nop

    const/16 v7, 0x53

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v11

    const/16 v7, 0x1133

    move-object/from16 v0, p1

    invoke-direct {v0, v11}, Lp50;-><init>(Landroid/content/Context;)V

    const/16 v7, 0x53

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v11

    const v12, 0x7f0800a6

    const/16 v7, 0x52f

    invoke-static {v11, v12}, Lqx;->getDrawable(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v11

    const/4 v7, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x8fa

    move-object/from16 v0, p1

    iput-object v11, v0, Lp50;->b:Ljava/lang/Object;

    const/16 v7, 0x191

    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->i:Landroidx/recyclerview/widget/RecyclerView;

    nop

    if-eqz v11, :cond_440

    const/16 v7, 0x892

    move-object/from16 v0, p1

    invoke-virtual {v11, v0}, Landroidx/recyclerview/widget/RecyclerView;->i(Lwq1;)V

    const/16 v7, 0x191

    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->i:Landroidx/recyclerview/widget/RecyclerView;

    move-object/16 p1, v7

    if-eqz p1, :cond_43b

    const/16 v7, 0x1bb

    move-object/from16 v0, p0

    iget-object v9, v0, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->j:Lrq0;

    nop

    if-eqz v9, :cond_42f

    const/16 v7, 0xc87

    move-object/from16 v0, p1

    invoke-virtual {v0, v9}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Lqq1;)V

    const-string/jumbo p1, "android.permission.READ_EXTERNAL_STORAGE"

    nop

    nop

    const/16 v7, 0x2b7

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-static {v0, v1}, Lqx;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result v9

    if-eqz v9, :cond_3f9

    check-cast p1, Ljava/lang/String;

    filled-new-array/range {p1 .. p1}, [Ljava/lang/String;

    move-result-object p1

    const/16 v7, 0x1008

    move-object/from16 v0, p0

    iget v9, v0, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->k:I

    nop

    const/16 v7, 0xf38

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-static {v0, v1, v9}, La3;->b(Landroid/app/Activity;[Ljava/lang/String;I)V

    goto :goto_407

    :cond_3f9
    const-string/jumbo p1, "/"

    nop

    nop

    const/16 v7, 0x54b

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual {v0, v1}, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->g(Ljava/lang/String;)V

    :goto_407
    const/16 v7, 0x140

    sget-boolean p1, Lg4;->a:Z

    nop

    const/16 v7, 0x1004

    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->g:Lw82;

    move-object/16 p1, v7

    const/16 v7, 0x177

    move-object/from16 v0, p1

    invoke-virtual {v0}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/content/SharedPreferences;

    const/4 v7, -0x6

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x394

    move-object/from16 v0, p1

    move-object/from16 v1, p0

    invoke-static {v0, v1}, Lg4;->n(Landroid/content/SharedPreferences;Landroidx/fragment/app/l;)V

    return-void

    :cond_42f
    const-string/jumbo p0, "adaptador"

    nop

    nop

    const/4 v7, 0x5

    move-object/from16 v0, p0

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_43b
    const/4 v7, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_440
    const/4 v7, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_445
    const/4 v7, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_44a
    const/4 v7, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_44f
    const-string/jumbo p0, "This Activity already has an action bar supplied by the window decor. Do not request Window.FEATURE_SUPPORT_ACTION_BAR and set windowActionBar to false in your theme to use a Toolbar instead."

    nop

    nop

    const/16 v7, 0x13

    move-object/from16 v0, p0

    invoke-static {v0}, Lz6;->w(Ljava/lang/String;)V

    return-void

    :cond_45c
    const-string/jumbo p0, "toolbar"

    nop

    nop

    const/4 v7, 0x5

    move-object/from16 v0, p0

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10
.end method

.method public final onCreateOptionsMenu(Landroid/view/Menu;)Z
    .registers 6

    .prologue
    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xf25

    invoke-virtual {p0}, Lra;->getMenuInflater()Landroid/view/MenuInflater;

    move-result-object v2

    const/high16 v3, 0x7f0e0000

    const/16 v0, 0x824

    invoke-virtual {v2, v3, p1}, Landroid/view/MenuInflater;->inflate(ILandroid/view/Menu;)V

    const v2, 0x7f090058

    const/16 v0, 0xf8d

    invoke-interface {p1, v2}, Landroid/view/Menu;->findItem(I)Landroid/view/MenuItem;

    move-result-object p1

    if-eqz p1, :cond_2a

    const v2, 0x7f1300ff

    const/16 v0, 0xb4

    invoke-virtual {p0, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x9ce

    invoke-interface {p1, p0}, Landroid/view/MenuItem;->setTitle(Ljava/lang/CharSequence;)Landroid/view/MenuItem;

    :cond_2a
    const/4 p0, 0x1

    return p0
.end method

.method public final onOptionsItemSelected(Landroid/view/MenuItem;)Z
    .registers 5

    .prologue
    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x17e

    invoke-interface {p1}, Landroid/view/MenuItem;->getItemId()I

    move-result p1

    const v2, 0x102002c

    if-ne p1, v2, :cond_1b

    const/16 v0, 0x475

    invoke-virtual {p0}, Lut;->getOnBackPressedDispatcher()Lsh1;

    move-result-object p0

    const/16 v0, 0x51a

    invoke-virtual {p0}, Lsh1;->b()V

    goto :goto_2b

    :cond_1b
    const v2, 0x7f090058

    if-ne p1, v2, :cond_2b

    const/16 v0, 0x475

    invoke-virtual {p0}, Lut;->getOnBackPressedDispatcher()Lsh1;

    move-result-object p0

    const/16 v0, 0x51a

    invoke-virtual {p0}, Lsh1;->b()V

    :cond_2b
    :goto_2b
    const/4 p0, 0x1

    return p0
.end method

.method public final onRequestPermissionsResult(I[Ljava/lang/String;[I)V
    .registers 9

    .prologue
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, -0x6

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x73a

    invoke-super {p0, p1, p2, p3}, Landroidx/fragment/app/l;->onRequestPermissionsResult(I[Ljava/lang/String;[I)V

    const/16 v0, 0x1008

    iget p2, p0, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->k:I

    nop

    if-ne p1, p2, :cond_69

    array-length p1, p3

    const-string/jumbo p2, "pdn"

    nop

    nop

    const v2, 0x7f1301f3

    if-nez p1, :cond_3a

    const/16 v0, 0xb4

    invoke-virtual {p0, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x430

    invoke-virtual {p0, p1, p2}, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->k(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v0, 0x475

    invoke-virtual {p0}, Lut;->getOnBackPressedDispatcher()Lsh1;

    move-result-object p0

    const/16 v0, 0x51a

    invoke-virtual {p0}, Lsh1;->b()V

    return-void

    :cond_3a
    array-length p1, p3

    const/4 v3, 0x0

    :goto_3c
    if-ge v3, p1, :cond_69

    aget v4, p3, v3

    if-nez v4, :cond_4f

    const-string/jumbo v4, "/"

    nop

    nop

    const/16 v0, 0x54b

    invoke-virtual {p0, v4}, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->g(Ljava/lang/String;)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_3c

    :cond_4f
    const/16 v0, 0xb4

    invoke-virtual {p0, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x430

    invoke-virtual {p0, p1, p2}, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->k(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v0, 0x475

    invoke-virtual {p0}, Lut;->getOnBackPressedDispatcher()Lsh1;

    move-result-object p0

    const/16 v0, 0x51a

    invoke-virtual {p0}, Lsh1;->b()V

    :cond_69
    return-void
.end method
