.class public final Lcom/tlsvpn/tlstunnel/ui/Logs;
.super Landroidx/fragment/app/Fragment;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Lw82;

.field public b:Landroidx/swiperefreshlayout/widget/SwipeRefreshLayout;

.field public c:Landroidx/recyclerview/widget/RecyclerView;

.field public d:Lm41;

.field public e:Landroid/view/View;

.field public final f:Lob;


# direct methods
.method public constructor <init>()V
    .registers 5

    invoke-direct {p0}, Landroidx/fragment/app/Fragment;-><init>()V

    const/16 v0, 0xa84

    new-instance v2, Ld;

    nop

    const/16 v3, 0xe

    const/16 v0, 0x6cb

    invoke-direct {v2, v3, p0}, Ld;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x27a

    new-instance v3, Lw82;

    nop

    const/16 v0, 0x215

    invoke-direct {v3, v2}, Lw82;-><init>(Lzj0;)V

    const/16 v0, 0x116e

    iput-object v3, p0, Lcom/tlsvpn/tlstunnel/ui/Logs;->a:Lw82;

    const/16 v0, 0xf6e

    new-instance v2, Lob;

    nop

    const/4 v3, 0x4

    const/16 v0, 0x11c1

    invoke-direct {v2, v3, p0}, Lob;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0xc03

    iput-object v2, p0, Lcom/tlsvpn/tlstunnel/ui/Logs;->f:Lob;

    return-void
.end method


# virtual methods
.method public final b(Ljava/lang/String;)V
    .registers 11

    .prologue
    const/16 v0, 0xb7a

    sget-object v2, Lmi2;->b:Ljava/util/concurrent/CopyOnWriteArrayList;

    nop

    const/4 v0, -0x3

    new-instance v3, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v4, "["

    const/16 v0, 0x97

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x1062

    new-instance v4, Ljava/util/Date;

    nop

    const/16 v0, 0x958

    invoke-direct {v4}, Ljava/util/Date;-><init>()V

    const/16 v0, 0xd54

    new-instance v5, Ljava/text/SimpleDateFormat;

    nop

    const-string/jumbo v6, "HH:mm:ss"

    const/16 v0, 0xa75

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v7

    const/16 v0, 0xc81

    invoke-direct {v5, v6, v7}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    const/16 v0, 0xa9e

    invoke-virtual {v5, v4}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v4

    const/4 v0, -0x6

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v4, "] "

    const/4 v0, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/16 v0, 0x9b4

    invoke-static {p1, v3}, Landroid/text/Html;->fromHtml(Ljava/lang/String;I)Landroid/text/Spanned;

    move-result-object p1

    const/16 v0, 0x146

    invoke-virtual {v2, p1}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    const/16 v0, 0x437

    iget-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/Logs;->d:Lm41;

    nop

    const/4 v4, 0x0

    const-string/jumbo v5, "logsAdapter"

    if-eqz p1, :cond_bd

    const/16 v0, 0x13d

    invoke-virtual {v2}, Ljava/util/concurrent/CopyOnWriteArrayList;->size()I

    move-result v6

    const/4 v7, 0x1

    sub-int/2addr v6, v7

    const/16 v0, 0x13d

    invoke-virtual {v2}, Ljava/util/concurrent/CopyOnWriteArrayList;->size()I

    move-result v8

    const/16 v0, 0x504

    iget-object p1, p1, Lqq1;->a:Lrq1;

    nop

    const/16 v0, 0xbbb

    invoke-virtual {p1, v6, v8}, Lrq1;->d(II)V

    const/16 v0, 0x10b

    iget-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/Logs;->c:Landroidx/recyclerview/widget/RecyclerView;

    nop

    if-eqz p1, :cond_b5

    const/16 v0, 0x13d

    invoke-virtual {v2}, Ljava/util/concurrent/CopyOnWriteArrayList;->size()I

    move-result v6

    sub-int/2addr v6, v7

    const/16 v0, 0xe57

    invoke-virtual {p1, v6}, Landroidx/recyclerview/widget/RecyclerView;->g0(I)V

    const/16 v0, 0x13d

    invoke-virtual {v2}, Ljava/util/concurrent/CopyOnWriteArrayList;->size()I

    move-result p1

    const/16 v6, 0x3e7

    if-le p1, v6, :cond_b4

    const/16 v0, 0x437

    iget-object p0, p0, Lcom/tlsvpn/tlstunnel/ui/Logs;->d:Lm41;

    nop

    if-eqz p0, :cond_af

    const/16 v0, 0x504

    iget-object p0, p0, Lqq1;->a:Lrq1;

    nop

    const/16 v0, 0xed7

    invoke-virtual {p0, v3, v7}, Lrq1;->e(II)V

    const/16 v0, 0xac6

    invoke-virtual {v2, v3}, Ljava/util/concurrent/CopyOnWriteArrayList;->remove(I)Ljava/lang/Object;

    return-void

    :cond_af
    const/4 v0, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_b4
    return-void

    :cond_b5
    const-string/jumbo p0, "logsView"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_bd
    const/4 v0, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4
.end method

.method public final c()V
    .registers 13

    .prologue
    const/16 v6, 0xb7a

    sget-object v8, Lmi2;->b:Ljava/util/concurrent/CopyOnWriteArrayList;

    nop

    const/16 v6, 0xd3b

    invoke-virtual {v8}, Ljava/util/concurrent/CopyOnWriteArrayList;->clear()V

    const/16 v6, 0x437

    iget-object v9, p0, Lcom/tlsvpn/tlstunnel/ui/Logs;->d:Lm41;

    nop

    const/4 v10, 0x0

    if-eqz v9, :cond_ae

    const/16 v6, 0x13d

    invoke-virtual {v8}, Ljava/util/concurrent/CopyOnWriteArrayList;->size()I

    move-result v8

    const/16 v6, 0x504

    iget-object v9, v9, Lqq1;->a:Lrq1;

    nop

    const/4 v11, 0x0

    const/16 v6, 0xed7

    invoke-virtual {v9, v11, v8}, Lrq1;->e(II)V

    const/4 v6, -0x3

    new-instance v8, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v9, "TLS Tunnel "

    const/16 v6, 0x97

    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const v9, 0x7f130270

    const/16 v6, 0x4c

    invoke-virtual {p0, v9}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v9

    const/4 v6, 0x0

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, -0x2

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    const/16 v6, 0x194

    invoke-virtual {p0, v8}, Lcom/tlsvpn/tlstunnel/ui/Logs;->b(Ljava/lang/String;)V

    const/16 v6, 0x5a

    sget-object v8, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->a:Lcom/tlsvpn/tlstunnel/utils/SocketOps;

    nop

    const/16 v6, 0xcad

    invoke-virtual {v8}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->umI()Ljava/lang/String;

    move-result-object v9

    const/16 v6, 0x194

    invoke-virtual {p0, v9}, Lcom/tlsvpn/tlstunnel/ui/Logs;->b(Ljava/lang/String;)V

    const/4 v6, -0x3

    new-instance v9, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v11, "Zstandard v"

    const/16 v6, 0x97

    invoke-direct {v9, v11}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v6, 0x6ab

    invoke-virtual {v8}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->C()Ljava/lang/String;

    move-result-object v8

    const/4 v6, 0x0

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, -0x2

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    const/16 v6, 0x194

    invoke-virtual {p0, v8}, Lcom/tlsvpn/tlstunnel/ui/Logs;->b(Ljava/lang/String;)V

    const/16 v6, 0x132

    sget-object v8, Lh50;->a:Li20;

    nop

    const/16 v6, 0x126

    sget-object v8, Lx10;->c:Lx10;

    nop

    const/16 v6, 0xf43

    invoke-static {v8}, Lw53;->a(Lly;)Lsx;

    move-result-object v8

    const/16 v6, 0x16

    new-instance v9, Lqd;

    nop

    const/4 v11, 0x5

    const/16 v6, 0x17

    invoke-direct {v9, p0, v10, v11}, Lqd;-><init>(Ljava/lang/Object;Lvx;I)V

    const/4 v11, 0x3

    const/16 v6, 0xb3

    move v0, v6

    move-object v1, v8

    move-object v2, v10

    move-object v3, v10

    move-object v4, v9

    move v5, v11

    invoke-static/range {v1 .. v5}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    const-string/jumbo v8, "http.agent"

    const/16 v6, 0x77d

    invoke-static {v8}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    if-eqz v8, :cond_ad

    const/16 v6, 0x194

    invoke-virtual {p0, v8}, Lcom/tlsvpn/tlstunnel/ui/Logs;->b(Ljava/lang/String;)V

    :cond_ad
    return-void

    :cond_ae
    const-string/jumbo p0, "logsAdapter"

    const/4 v6, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10
.end method

.method public final d(Lwx;)Ljava/lang/Object;
    .registers 17

    .prologue
    move-object/from16 v0, p1

    instance-of v8, v0, Ln41;

    if-eqz v8, :cond_1b

    move-object/from16 v8, p1

    check-cast v8, Ln41;

    const/16 v6, 0x301

    iget v9, v8, Ln41;->x:I

    nop

    const/high16 v10, -0x80000000

    and-int v11, v9, v10

    if-eqz v11, :cond_1b

    sub-int/2addr v9, v10

    const/16 v6, 0x3ec

    iput v9, v8, Ln41;->x:I

    goto :goto_27

    :cond_1b
    const/16 v6, 0xb63

    new-instance v8, Ln41;

    nop

    const/16 v6, 0xaf6

    move-object/from16 v0, p1

    invoke-direct {v8, p0, v0}, Ln41;-><init>(Lcom/tlsvpn/tlstunnel/ui/Logs;Lwx;)V

    :goto_27
    const/16 v6, 0x5b4

    iget-object v6, v8, Ln41;->v:Ljava/lang/Object;

    move-object/16 p1, v6

    const/16 v6, 0x301

    iget v9, v8, Ln41;->x:I

    nop

    const/4 v10, 0x1

    const/4 v11, 0x0

    if-eqz v9, :cond_54

    if-ne v9, v10, :cond_4b

    const/16 v6, 0x117c

    iget v9, v8, Ln41;->u:I

    nop

    const/16 v6, 0x67f

    iget-object v12, v8, Ln41;->t:Ljava/util/Iterator;

    nop

    const/4 v6, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    goto/16 :goto_d0

    :cond_4b
    const-string/jumbo p0, "call to \'resume\' before \'invoke\' with coroutine"

    const/16 v6, 0x13

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v11

    :cond_54
    const/4 v6, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v6, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p1

    const-string/jumbo v9, "connectivity"

    const/16 v6, 0x31d

    move-object/from16 v0, p1

    invoke-virtual {v0, v9}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, -0x6

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p1, Landroid/net/ConnectivityManager;

    const/16 v6, 0x4d7

    move-object/from16 v0, p1

    invoke-virtual {v0}, Landroid/net/ConnectivityManager;->getActiveNetwork()Landroid/net/Network;

    move-result-object v9

    if-eqz v9, :cond_119

    const/16 v6, 0x4d7

    move-object/from16 v0, p1

    invoke-virtual {v0}, Landroid/net/ConnectivityManager;->getActiveNetwork()Landroid/net/Network;

    move-result-object v9

    const/16 v6, 0xa24

    move-object/from16 v0, p1

    invoke-virtual {v0, v9}, Landroid/net/ConnectivityManager;->getLinkProperties(Landroid/net/Network;)Landroid/net/LinkProperties;

    move-result-object p1

    if-eqz p1, :cond_119

    const/16 v6, 0x6fc

    move-object/from16 v0, p1

    invoke-virtual {v0}, Landroid/net/LinkProperties;->getLinkAddresses()Ljava/util/List;

    move-result-object p1

    if-eqz p1, :cond_119

    check-cast p1, Ljava/lang/Iterable;

    const/16 v6, 0x3cc

    new-instance v9, Laq;

    nop

    const/4 v12, 0x4

    const/16 v6, 0x2ac

    invoke-direct {v9, v12}, Laq;-><init>(I)V

    const/16 v6, 0x4d1

    move-object/from16 v0, p1

    invoke-static {v0, v9}, Lbs;->x0(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object p1

    check-cast p1, Ljava/lang/Iterable;

    const/16 v6, 0x3cc

    new-instance v9, Laq;

    nop

    const/4 v12, 0x5

    const/16 v6, 0x2ac

    invoke-direct {v9, v12}, Laq;-><init>(I)V

    const/16 v6, 0x4d1

    move-object/from16 v0, p1

    invoke-static {v0, v9}, Lbs;->x0(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object p1

    check-cast p1, Ljava/lang/Iterable;

    const/16 v6, 0x429

    move-object/from16 v0, p1

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    const/4 v9, 0x0

    move-object/from16 v12, p1

    :cond_d0
    :goto_d0
    const/16 v6, 0x13e

    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    if-eqz p1, :cond_119

    const/16 v6, 0x16e

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    check-cast p1, Landroid/net/LinkAddress;

    const/16 v6, 0x132

    sget-object v13, Lh50;->a:Li20;

    nop

    const/16 v6, 0x124a

    sget-object v13, Lh51;->a:Lum0;

    nop

    const/16 v6, 0x1215

    new-instance v14, Lb11;

    nop

    const/16 v6, 0xc74

    move v0, v6

    move-object v1, v14

    move-object v2, p0

    move-object/from16 v3, p1

    move-object v4, v11

    move v5, v10

    invoke-direct/range {v1 .. v5}, Lb11;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lvx;I)V

    const/16 v6, 0x1129

    iput-object v12, v8, Ln41;->t:Ljava/util/Iterator;

    const/16 v6, 0xa76

    iput v9, v8, Ln41;->u:I

    const/16 v6, 0x3ec

    iput v10, v8, Ln41;->x:I

    const/16 v6, 0x121

    invoke-static {v13, v14, v8}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object p1

    const/16 v6, 0x15

    sget-object v13, Lwy;->a:Lwy;

    nop

    move-object/from16 v0, p1

    if-ne v0, v13, :cond_d0

    check-cast v13, Ljava/lang/Object;

    return-object v13

    :cond_119
    const/16 v6, 0x21

    sget-object p0, Lrg2;->a:Lrg2;

    nop

    check-cast p0, Ljava/lang/Object;

    return-object p0
.end method

.method public final onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .registers 9

    .prologue
    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x156

    iget-object p3, p0, Lcom/tlsvpn/tlstunnel/ui/Logs;->e:Landroid/view/View;

    nop

    if-nez p3, :cond_15

    const p3, 0x7f0c00c8

    const/4 v2, 0x0

    const/16 v0, 0x107b

    invoke-virtual {p1, p3, p2, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p3

    :cond_15
    const/16 v0, 0xd04

    iput-object p3, p0, Lcom/tlsvpn/tlstunnel/ui/Logs;->e:Landroid/view/View;

    const/4 p1, 0x0

    if-eqz p3, :cond_28

    const p2, 0x7f090363

    const/16 v0, 0x11

    invoke-virtual {p3, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroidx/swiperefreshlayout/widget/SwipeRefreshLayout;

    goto :goto_29

    :cond_28
    move-object p2, p1

    :goto_29
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xa00

    iput-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Logs;->b:Landroidx/swiperefreshlayout/widget/SwipeRefreshLayout;

    const/16 v0, 0x156

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Logs;->e:Landroid/view/View;

    nop

    if-eqz p2, :cond_44

    const p3, 0x7f0902e1

    const/16 v0, 0x11

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroidx/recyclerview/widget/RecyclerView;

    goto :goto_45

    :cond_44
    move-object p2, p1

    :goto_45
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xe73

    iput-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Logs;->c:Landroidx/recyclerview/widget/RecyclerView;

    const/16 v0, 0x156

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Logs;->e:Landroid/view/View;

    nop

    if-eqz p2, :cond_60

    const p3, 0x7f09013b

    const/16 v0, 0x11

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/ImageView;

    goto :goto_61

    :cond_60
    move-object p2, p1

    :goto_61
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xa20

    new-instance p3, Lvd;

    nop

    const/16 v2, 0x10

    const/16 v0, 0xd0d

    invoke-direct {p3, v2, p0}, Lvd;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x5f

    invoke-virtual {p2, p3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0xd5

    new-instance p2, Landroid/util/TypedValue;

    nop

    const/16 v0, 0xe7

    invoke-direct {p2}, Landroid/util/TypedValue;-><init>()V

    const/16 v0, 0xd5

    new-instance p3, Landroid/util/TypedValue;

    nop

    const/16 v0, 0xe7

    invoke-direct {p3}, Landroid/util/TypedValue;-><init>()V

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v2

    const/16 v0, 0x1a9

    invoke-virtual {v2}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v2

    const v3, 0x7f0405c9

    const/4 v4, 0x1

    const/16 v0, 0x68

    invoke-virtual {v2, v3, p2, v4}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v2

    const/16 v0, 0x1a9

    invoke-virtual {v2}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v2

    const v3, 0x7f040427

    const/16 v0, 0x68

    invoke-virtual {v2, v3, p3, v4}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    const/16 v0, 0x1af

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/ui/Logs;->b:Landroidx/swiperefreshlayout/widget/SwipeRefreshLayout;

    nop

    const-string/jumbo v3, "swipeToClearLog"

    if-eqz v2, :cond_233

    const/16 v0, 0x9b

    iget p2, p2, Landroid/util/TypedValue;->data:I

    nop

    const/16 v0, 0xbb5

    invoke-virtual {v2, p2}, Landroidx/swiperefreshlayout/widget/SwipeRefreshLayout;->setProgressBackgroundColorSchemeColor(I)V

    const/16 v0, 0x1af

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Logs;->b:Landroidx/swiperefreshlayout/widget/SwipeRefreshLayout;

    nop

    if-eqz p2, :cond_22e

    const/16 v0, 0x9b

    iget p3, p3, Landroid/util/TypedValue;->data:I

    nop

    filled-new-array {p3}, [I

    move-result-object p3

    const/16 v0, 0xbc3

    invoke-virtual {p2, p3}, Landroidx/swiperefreshlayout/widget/SwipeRefreshLayout;->setColorSchemeColors([I)V

    const/16 v0, 0x1af

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Logs;->b:Landroidx/swiperefreshlayout/widget/SwipeRefreshLayout;

    nop

    if-eqz p2, :cond_229

    const/16 v0, 0x50f

    new-instance p3, Lah;

    nop

    const/16 v2, 0xc

    const/16 v0, 0x3bf

    invoke-direct {p3, v2, p0}, Lah;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x1026

    invoke-virtual {p2, p3}, Landroidx/swiperefreshlayout/widget/SwipeRefreshLayout;->setOnRefreshListener(Ls82;)V

    const/16 v0, 0x89a

    new-instance p2, Lm41;

    nop

    const/16 v0, 0x554

    invoke-direct {p2}, Lqq1;-><init>()V

    const/16 v0, 0xa78

    iput-object p0, p2, Lm41;->c:Lcom/tlsvpn/tlstunnel/ui/Logs;

    const/16 v0, 0x693

    iput-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Logs;->d:Lm41;

    const/16 v0, 0x10b

    iget-object p3, p0, Lcom/tlsvpn/tlstunnel/ui/Logs;->c:Landroidx/recyclerview/widget/RecyclerView;

    nop

    const-string/jumbo v2, "logsView"

    if-eqz p3, :cond_224

    const/16 v0, 0xc87

    invoke-virtual {p3, p2}, Landroidx/recyclerview/widget/RecyclerView;->setAdapter(Lqq1;)V

    const/16 v0, 0xf80

    new-instance p2, Lp50;

    nop

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p3

    const/16 v0, 0x1133

    invoke-direct {p2, p3}, Lp50;-><init>(Landroid/content/Context;)V

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p3

    const v3, 0x7f0800a6

    const/16 v0, 0x52f

    invoke-static {p3, v3}, Lqx;->getDrawable(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p3

    const/4 v0, -0x6

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x8fa

    iput-object p3, p2, Lp50;->b:Ljava/lang/Object;

    const/16 v0, 0x10b

    iget-object p3, p0, Lcom/tlsvpn/tlstunnel/ui/Logs;->c:Landroidx/recyclerview/widget/RecyclerView;

    nop

    if-eqz p3, :cond_21f

    const/16 v0, 0x892

    invoke-virtual {p3, p2}, Landroidx/recyclerview/widget/RecyclerView;->i(Lwq1;)V

    const/16 v0, 0x10b

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Logs;->c:Landroidx/recyclerview/widget/RecyclerView;

    nop

    if-eqz p2, :cond_21a

    const/16 v0, 0x7ba

    invoke-virtual {p2, p1}, Landroidx/recyclerview/widget/RecyclerView;->setItemAnimator(Lvq1;)V

    const/16 v0, 0xb7a

    sget-object p2, Lmi2;->b:Ljava/util/concurrent/CopyOnWriteArrayList;

    nop

    const/16 v0, 0x105d

    invoke-virtual {p2}, Ljava/util/concurrent/CopyOnWriteArrayList;->isEmpty()Z

    move-result p3

    if-eqz p3, :cond_167

    const/16 v0, 0x6ea

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/Logs;->c()V

    goto :goto_17a

    :cond_167
    const/16 v0, 0x10b

    iget-object p3, p0, Lcom/tlsvpn/tlstunnel/ui/Logs;->c:Landroidx/recyclerview/widget/RecyclerView;

    nop

    if-eqz p3, :cond_215

    const/16 v0, 0x13d

    invoke-virtual {p2}, Ljava/util/concurrent/CopyOnWriteArrayList;->size()I

    move-result p1

    sub-int/2addr p1, v4

    const/16 v0, 0xe57

    invoke-virtual {p3, p1}, Landroidx/recyclerview/widget/RecyclerView;->g0(I)V

    :goto_17a
    const/16 v0, 0x1fc

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 p2, 0x21

    const-string/jumbo p3, "clearLog"

    const-string/jumbo v2, "addLog"

    const/16 v0, 0x5e6

    iget-object v3, p0, Lcom/tlsvpn/tlstunnel/ui/Logs;->f:Lob;

    nop

    if-ge p1, p2, :cond_1b9

    const/16 v0, 0xfb

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object p1

    const/16 v0, 0x1f

    new-instance p2, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {p2, v2}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x3a

    invoke-virtual {p1, v3, p2}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/16 v0, 0xfb

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object p1

    const/16 v0, 0x1f

    new-instance p2, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {p2, p3}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x3a

    invoke-virtual {p1, v3, p2}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    goto :goto_1e4

    :cond_1b9
    const/16 v0, 0xfb

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object p1

    const/16 v0, 0x1f

    new-instance p2, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {p2, v2}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x4

    const/16 v0, 0x39

    invoke-virtual {p1, v3, p2, v2}, Landroid/app/Activity;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    const/16 v0, 0xfb

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object p1

    const/16 v0, 0x1f

    new-instance p2, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {p2, p3}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x39

    invoke-virtual {p1, v3, p2, v2}, Landroid/app/Activity;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    :goto_1e4
    const/16 v0, 0xa42

    sput-boolean v4, Lmi2;->a:Z

    const/16 v0, 0x140

    sget-boolean p1, Lg4;->a:Z

    nop

    const/16 v0, 0xfb

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x1122

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Logs;->a:Lw82;

    nop

    const/16 v0, 0x177

    invoke-virtual {p2}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Landroid/content/SharedPreferences;

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x394

    invoke-static {p2, p1}, Lg4;->n(Landroid/content/SharedPreferences;Landroidx/fragment/app/l;)V

    const/16 v0, 0x156

    iget-object p0, p0, Lcom/tlsvpn/tlstunnel/ui/Logs;->e:Landroid/view/View;

    nop

    check-cast p0, Landroid/view/View;

    return-object p0

    :cond_215
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_21a
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_21f
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_224
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_229
    const/4 v0, 0x5

    invoke-static {v3}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_22e
    const/4 v0, 0x5

    invoke-static {v3}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_233
    const/4 v0, 0x5

    invoke-static {v3}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1
.end method

.method public final onDestroyView()V
    .registers 4

    .prologue
    const/16 v0, 0x122b

    invoke-super {p0}, Landroidx/fragment/app/Fragment;->onDestroyView()V

    :try_start_5
    const/16 v0, 0x22f

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v2

    if-eqz v2, :cond_17

    const/16 v0, 0x5e6

    iget-object p0, p0, Lcom/tlsvpn/tlstunnel/ui/Logs;->f:Lob;

    nop

    const/16 v0, 0x345

    invoke-virtual {v2, p0}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_17
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_17} :catch_17

    :catch_17
    :cond_17
    const/16 v0, 0x905

    sget-boolean p0, Lmi2;->a:Z

    nop

    const/4 p0, 0x0

    const/16 v0, 0xa42

    sput-boolean p0, Lmi2;->a:Z

    return-void
.end method

.method public final onResume()V
    .registers 6

    const/16 v0, 0x7d7

    invoke-super {p0}, Landroidx/fragment/app/Fragment;->onResume()V

    const/16 v0, 0xfb

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object v2

    const/16 v0, 0x5b

    new-instance v3, Landroid/content/Intent;

    nop

    const-string/jumbo v4, "logsOn"

    const/16 v0, 0x62

    invoke-direct {v3, v4}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p0

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/16 v0, 0x4a

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x64

    invoke-virtual {v3, p0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    const/16 v0, 0x63

    invoke-virtual {v2, p0}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    return-void
.end method
