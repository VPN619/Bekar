.class public final Lcom/tlsvpn/tlstunnel/ui/Others;
.super Landroidx/fragment/app/Fragment;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lre1;


# instance fields
.field public final a:Lw82;

.field public b:Lcom/google/android/material/navigation/NavigationView;

.field public c:Landroid/widget/ImageView;

.field public d:Landroid/view/View;


# direct methods
.method public constructor <init>()V
    .registers 5

    invoke-direct {p0}, Landroidx/fragment/app/Fragment;-><init>()V

    const/16 v0, 0xa84

    new-instance v2, Ld;

    nop

    const/16 v3, 0x13

    const/16 v0, 0x6cb

    invoke-direct {v2, v3, p0}, Ld;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x27a

    new-instance v3, Lw82;

    nop

    const/16 v0, 0x215

    invoke-direct {v3, v2}, Lw82;-><init>(Lzj0;)V

    const/16 v0, 0xaee

    iput-object v3, p0, Lcom/tlsvpn/tlstunnel/ui/Others;->a:Lw82;

    return-void
.end method


# virtual methods
.method public final onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .registers 7

    .prologue
    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x26a

    iget-object p3, p0, Lcom/tlsvpn/tlstunnel/ui/Others;->d:Landroid/view/View;

    nop

    if-nez p3, :cond_15

    const p3, 0x7f0c00b0

    const/4 v2, 0x0

    const/16 v0, 0x107b

    invoke-virtual {p1, p3, p2, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p3

    :cond_15
    const/16 v0, 0xd18

    iput-object p3, p0, Lcom/tlsvpn/tlstunnel/ui/Others;->d:Landroid/view/View;

    const/4 p1, 0x0

    if-eqz p3, :cond_28

    const p2, 0x7f090256

    const/16 v0, 0x11

    invoke-virtual {p3, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Lcom/google/android/material/navigation/NavigationView;

    goto :goto_29

    :cond_28
    move-object p2, p1

    :goto_29
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x85b

    iput-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Others;->b:Lcom/google/android/material/navigation/NavigationView;

    const/16 v0, 0x26a

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Others;->d:Landroid/view/View;

    nop

    if-eqz p2, :cond_44

    const p3, 0x7f09013b

    const/16 v0, 0x11

    invoke-virtual {p2, p3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/ImageView;

    goto :goto_45

    :cond_44
    move-object p2, p1

    :goto_45
    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xc5b

    iput-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Others;->c:Landroid/widget/ImageView;

    const/16 v0, 0xf57

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Others;->b:Lcom/google/android/material/navigation/NavigationView;

    nop

    if-eqz p2, :cond_a6

    const/16 v0, 0xbf3

    invoke-virtual {p2, p0}, Lcom/google/android/material/navigation/NavigationView;->setNavigationItemSelectedListener(Lre1;)V

    const/16 v0, 0x1224

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Others;->c:Landroid/widget/ImageView;

    nop

    if-eqz p2, :cond_9e

    const/16 v0, 0xa20

    new-instance p1, Lvd;

    nop

    const/16 p3, 0x13

    const/16 v0, 0xd0d

    invoke-direct {p1, p3, p0}, Lvd;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x5f

    invoke-virtual {p2, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0x140

    sget-boolean p1, Lg4;->a:Z

    nop

    const/16 v0, 0xfb

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xb7d

    iget-object p2, p0, Lcom/tlsvpn/tlstunnel/ui/Others;->a:Lw82;

    nop

    const/16 v0, 0x177

    invoke-virtual {p2}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Landroid/content/SharedPreferences;

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x394

    invoke-static {p2, p1}, Lg4;->n(Landroid/content/SharedPreferences;Landroidx/fragment/app/l;)V

    const/16 v0, 0x26a

    iget-object p0, p0, Lcom/tlsvpn/tlstunnel/ui/Others;->d:Landroid/view/View;

    nop

    check-cast p0, Landroid/view/View;

    return-object p0

    :cond_9e
    const-string/jumbo p0, "home"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_a6
    const-string/jumbo p0, "moreOptionsNavView"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1
.end method
