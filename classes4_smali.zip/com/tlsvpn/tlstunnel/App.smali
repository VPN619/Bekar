.class public final Lcom/tlsvpn/tlstunnel/App;
.super Landroid/app/Application;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Llu;
.implements Landroid/app/Application$ActivityLifecycleCallbacks;
.implements Lf20;


# static fields
.field public static final synthetic c:I


# instance fields
.field public final a:Lw82;

.field public b:Landroid/app/Activity;


# direct methods
.method public constructor <init>()V
    .registers 5

    invoke-direct {p0}, Landroid/app/Application;-><init>()V

    const/16 v0, 0xdbe

    new-instance v2, Landroid/os/StrictMode$ThreadPolicy$Builder;

    nop

    const/16 v0, 0xc11

    invoke-direct {v2}, Landroid/os/StrictMode$ThreadPolicy$Builder;-><init>()V

    const/16 v0, 0x1181

    invoke-virtual {v2}, Landroid/os/StrictMode$ThreadPolicy$Builder;->permitNetwork()Landroid/os/StrictMode$ThreadPolicy$Builder;

    move-result-object v2

    const/16 v0, 0x1165

    invoke-virtual {v2}, Landroid/os/StrictMode$ThreadPolicy$Builder;->build()Landroid/os/StrictMode$ThreadPolicy;

    move-result-object v2

    const/16 v0, 0xf62

    invoke-static {v2}, Landroid/os/StrictMode;->setThreadPolicy(Landroid/os/StrictMode$ThreadPolicy;)V

    const/16 v0, 0xa84

    new-instance v2, Ld;

    nop

    const/4 v3, 0x1

    const/16 v0, 0x6cb

    invoke-direct {v2, v3, p0}, Ld;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x27a

    new-instance v3, Lw82;

    nop

    const/16 v0, 0x215

    invoke-direct {v3, v2}, Lw82;-><init>(Lzj0;)V

    const/16 v0, 0xb30

    iput-object v3, p0, Lcom/tlsvpn/tlstunnel/App;->a:Lw82;

    return-void
.end method


# virtual methods
.method public final b(Lh11;)V
    .registers 12

    .prologue
    const/16 v0, 0xe97

    iget-object p1, p0, Lcom/tlsvpn/tlstunnel/App;->b:Landroid/app/Activity;

    nop

    if-eqz p1, :cond_136

    const/16 v0, 0x140

    sget-boolean v2, Lg4;->a:Z

    nop

    const/16 v0, 0x5bf

    iget-object p0, p0, Lcom/tlsvpn/tlstunnel/App;->a:Lw82;

    nop

    const/16 v0, 0x177

    invoke-virtual {p0}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/content/SharedPreferences;

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x1084

    sget-object v2, Lpn1;->i:Lpn1;

    nop

    const/16 v0, 0xb6e

    iget-object v2, v2, Lpn1;->f:Lk11;

    nop

    const/16 v0, 0x8bd

    iget-object v2, v2, Lk11;->h:Lz01;

    nop

    const/16 v0, 0xe66

    sget-object v3, Lz01;->e:Lz01;

    nop

    const/16 v0, 0xb56

    invoke-virtual {v2, v3}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    move-result v2

    if-ltz v2, :cond_136

    const/16 v0, 0x101

    sget-boolean v2, Lmi2;->n:Z

    nop

    if-nez v2, :cond_136

    const/16 v0, 0xd93

    sget-boolean v2, Lmi2;->f:Z

    nop

    if-nez v2, :cond_136

    const/16 v0, 0x8f7

    sget-boolean v2, Lg4;->b:Z

    nop

    if-eqz v2, :cond_136

    const/16 v0, 0xde

    sget-boolean v2, Lg4;->j:Z

    nop

    if-eqz v2, :cond_57

    goto/16 :goto_136

    :cond_57
    const/16 v0, 0x49d

    sget-wide v2, Lg4;->i:J

    nop

    const-wide/32 v4, 0xea60

    add-long/2addr v2, v4

    const/16 v0, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v6

    cmp-long v2, v2, v6

    const/4 v3, 0x0

    const/4 v6, 0x1

    if-gez v2, :cond_6e

    move v2, v6

    goto :goto_6f

    :cond_6e
    move v2, v3

    :goto_6f
    const/16 v0, 0xda5

    invoke-static {p0}, Lg4;->f(Landroid/content/SharedPreferences;)Z

    move-result v7

    if-eqz v7, :cond_81

    const/16 v0, 0x25a

    sget-object v7, Lg4;->s:Lce;

    nop

    if-eqz v7, :cond_7f

    goto :goto_81

    :cond_7f
    move v7, v3

    goto :goto_82

    :cond_81
    :goto_81
    move v7, v6

    :goto_82
    if-eqz v2, :cond_87

    if-eqz v7, :cond_87

    goto :goto_88

    :cond_87
    move v6, v3

    :goto_88
    const/4 v0, -0x3

    new-instance v7, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v8, "Exibir AppOpen? "

    nop

    nop

    const/16 v0, 0x97

    invoke-direct {v7, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x6a

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/16 v8, 0x20

    const/16 v0, 0x1b

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    if-nez v6, :cond_d8

    if-nez v2, :cond_d8

    const/4 v0, -0x3

    new-instance v2, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v8, "(Só daqui a ~"

    nop

    nop

    const/16 v0, 0x97

    invoke-direct {v2, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x49d

    sget-wide v8, Lg4;->i:J

    nop

    add-long/2addr v8, v4

    const/16 v0, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    sub-long/2addr v8, v4

    const-wide/16 v4, 0x3e8

    div-long/2addr v8, v4

    const/16 v0, 0x83

    invoke-virtual {v2, v8, v9}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string/jumbo v4, "s)"

    nop

    nop

    const/4 v0, 0x0

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    goto :goto_db

    :cond_d8
    const-string/jumbo v2, ""

    :goto_db
    const/4 v0, 0x0

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string/jumbo v4, "Ads-Limits"

    nop

    nop

    nop

    if-nez v6, :cond_ed

    goto :goto_136

    :cond_ed
    const/16 v0, 0x25a

    sget-object v2, Lg4;->s:Lce;

    nop

    if-nez v2, :cond_106

    const/16 v0, 0x53

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-wide/16 v2, 0x0

    const/16 v0, 0x3a0

    invoke-static {v2, v3, p0}, Lg4;->j(JLandroid/content/Context;)V

    return-void

    :cond_106
    const/16 v0, 0x910

    new-instance v4, Ld4;

    nop

    const/16 v0, 0x110a

    invoke-direct {v4, p0, p1}, Ld4;-><init>(Landroid/content/SharedPreferences;Landroid/app/Activity;)V

    check-cast v2, Lads_mobile_sdk/bh;

    const/16 v0, 0x1207

    iget-object p0, v2, Lads_mobile_sdk/bh;->c:Lads_mobile_sdk/ji;

    nop

    const/16 v0, 0x949

    sget-object v5, Lads_mobile_sdk/bh;->e:[Liy0;

    nop

    aget-object v3, v5, v3

    const/16 v0, 0x1037

    invoke-virtual {p0, v2, v3, v4}, Lads_mobile_sdk/ji;->setValue(Ljava/lang/Object;Liy0;Ljava/lang/Object;)V

    const/16 v0, 0x25a

    sget-object p0, Lg4;->s:Lce;

    nop

    if-eqz p0, :cond_136

    check-cast p0, Lads_mobile_sdk/bh;

    const/16 v0, 0xd98

    iget-object p0, p0, Lads_mobile_sdk/bh;->b:Lads_mobile_sdk/jd1;

    nop

    const/16 v0, 0x914

    invoke-virtual {p0, p1}, Lads_mobile_sdk/xo;->a(Landroid/content/Context;)V

    :cond_136
    :goto_136
    return-void
.end method

.method public final onActivityCreated(Landroid/app/Activity;Landroid/os/Bundle;)V
    .registers 5

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void
.end method

.method public final onActivityDestroyed(Landroid/app/Activity;)V
    .registers 5

    .prologue
    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xe97

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/App;->b:Landroid/app/Activity;

    nop

    const/16 v0, 0x84

    invoke-static {v2, p1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_16

    const/4 p1, 0x0

    const/16 v0, 0x755

    iput-object p1, p0, Lcom/tlsvpn/tlstunnel/App;->b:Landroid/app/Activity;

    :cond_16
    return-void
.end method

.method public final onActivityPaused(Landroid/app/Activity;)V
    .registers 4

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void
.end method

.method public final onActivityResumed(Landroid/app/Activity;)V
    .registers 4

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x755

    iput-object p1, p0, Lcom/tlsvpn/tlstunnel/App;->b:Landroid/app/Activity;

    return-void
.end method

.method public final onActivitySaveInstanceState(Landroid/app/Activity;Landroid/os/Bundle;)V
    .registers 5

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void
.end method

.method public final onActivityStarted(Landroid/app/Activity;)V
    .registers 4

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x755

    iput-object p1, p0, Lcom/tlsvpn/tlstunnel/App;->b:Landroid/app/Activity;

    return-void
.end method

.method public final onActivityStopped(Landroid/app/Activity;)V
    .registers 4

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void
.end method

.method public final onCreate()V
    .registers 21

    .prologue
    const-string/jumbo v9, "WorkMan"

    nop

    nop

    const/16 v7, 0xdc1

    move-object/from16 v0, p0

    invoke-super {v0}, Landroid/app/Application;->onCreate()V

    const-string/jumbo v10, "java.net.preferIPv6Addresses"

    nop

    nop

    const-string/jumbo v11, "true"

    nop

    nop

    const/16 v7, 0x7d

    invoke-static {v10, v11}, Ljava/lang/System;->setProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    const-string/jumbo v10, "java.net.preferIPv4Stack"

    nop

    nop

    const-string/jumbo v12, "false"

    nop

    nop

    const/16 v7, 0x7d

    invoke-static {v10, v12}, Ljava/lang/System;->setProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    const-string/jumbo v10, "networkaddress.cache.negative.ttl"

    nop

    nop

    const-string/jumbo v13, "0"

    nop

    nop

    const/16 v7, 0x4cf

    invoke-static {v10, v13}, Ljava/security/Security;->setProperty(Ljava/lang/String;Ljava/lang/String;)V

    const-string/jumbo v10, "networkaddress.cache.ttl"

    nop

    nop

    const-string/jumbo v13, "60"

    nop

    nop

    const/16 v7, 0x4cf

    invoke-static {v10, v13}, Ljava/security/Security;->setProperty(Ljava/lang/String;Ljava/lang/String;)V

    const-string/jumbo v10, "http.maxConnections"

    nop

    nop

    const-string/jumbo v13, "20"

    nop

    nop

    const/16 v7, 0x7d

    invoke-static {v10, v13}, Ljava/lang/System;->setProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    const-string/jumbo v10, "http.keepAlive"

    nop

    nop

    const/16 v7, 0x7d

    invoke-static {v10, v11}, Ljava/lang/System;->setProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    const-string/jumbo v10, "sun.net.client.defaultConnectTimeout"

    nop

    nop

    const-string/jumbo v13, "15000"

    nop

    nop

    const/16 v7, 0x7d

    invoke-static {v10, v13}, Ljava/lang/System;->setProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    const-string/jumbo v10, "sun.net.client.defaultReadTimeout"

    nop

    nop

    const/16 v7, 0x7d

    invoke-static {v10, v13}, Ljava/lang/System;->setProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    const-string/jumbo v10, "java.net.useSystemProxies"

    nop

    nop

    const/16 v7, 0x7d

    invoke-static {v10, v12}, Ljava/lang/System;->setProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    const-string/jumbo v10, "jsse.enableSNIExtension"

    nop

    nop

    const/16 v7, 0x7d

    invoke-static {v10, v11}, Ljava/lang/System;->setProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    const/16 v7, 0x2f8

    move-object/from16 v0, p0

    move-object/from16 v1, p0

    invoke-virtual {v0, v1}, Landroid/app/Application;->registerActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V

    const/16 v7, 0x1084

    sget-object v10, Lpn1;->i:Lpn1;

    nop

    const/16 v7, 0xb6e

    iget-object v10, v10, Lpn1;->f:Lk11;

    nop

    const/16 v7, 0xd13

    move-object/from16 v0, p0

    invoke-virtual {v10, v0}, Lk11;->a(Lg11;)V

    :try_start_a8
    const/16 v7, 0xc0c

    new-instance v10, Lj41;

    nop

    const/16 v7, 0x799

    invoke-direct {v10}, Lj41;-><init>()V

    const/16 v11, 0x64

    const/16 v12, 0x32

    const/16 v7, 0x9e1

    invoke-static {v11, v12}, Ljava/lang/Math;->min(II)I

    move-result v11

    const/16 v7, 0x748

    iput v11, v10, Lj41;->a:I

    const/16 v7, 0xfc7

    new-instance v11, Lsg;

    nop

    const/16 v7, 0x11ae

    invoke-direct {v11, v10}, Lsg;-><init>(Lj41;)V

    const/16 v7, 0x11e8

    move-object/from16 v0, p0

    invoke-static {v0, v11}, Lnq2;->c(Landroid/content/Context;Lsg;)V

    const-string/jumbo v10, "WorkManager inicializado manualmente com sucesso!"

    nop

    nop

    nop
    :try_end_d7
    .catch Ljava/lang/Exception; {:try_start_a8 .. :try_end_d7} :catch_d8

    goto :goto_f7

    :catch_d8
    move-exception v10

    const/4 v7, -0x3

    new-instance v11, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v12, "Falha ao inicializar manualmente (Auto-init venceu): "

    nop

    nop

    const/16 v7, 0x97

    invoke-direct {v11, v12}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v7, 0x1da

    invoke-virtual {v10}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v10

    const/4 v7, 0x0

    invoke-virtual {v11, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, -0x2

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    nop

    :goto_f7
    const/16 v7, 0x905

    sget-boolean v9, Lmi2;->a:Z

    nop

    const/16 v7, 0x5bf

    move-object/from16 v0, p0

    iget-object v9, v0, Lcom/tlsvpn/tlstunnel/App;->a:Lw82;

    nop

    const/16 v7, 0x177

    invoke-virtual {v9}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Landroid/content/SharedPreferences;

    const-string/jumbo v11, "dmode"

    nop

    nop

    const/4 v12, 0x0

    const/16 v7, 0x77

    invoke-interface {v10, v11, v12}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v10

    const/16 v7, 0x7dd

    sput-boolean v10, Lmi2;->h:Z

    const/4 v11, 0x1

    if-eqz v10, :cond_120

    const/4 v10, 0x2

    goto :goto_121

    :cond_120
    move v10, v11

    :goto_121
    const/16 v7, 0xe6d

    invoke-static {v10}, Leb;->p(I)V

    const/16 v7, 0x140

    sget-boolean v10, Lg4;->a:Z

    nop

    const/16 v7, 0x177

    invoke-virtual {v9}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Landroid/content/SharedPreferences;

    const-string/jumbo v13, "lrtms"

    nop

    nop

    const-wide/16 v14, 0x0

    const/16 v7, 0x46e

    invoke-interface {v10, v13, v14, v15}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v16

    const/16 v7, 0xc0e

    move-wide/from16 v0, v16

    sput-wide v0, Lg4;->l:J

    const/16 v7, 0x177

    invoke-virtual {v9}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Landroid/content/SharedPreferences;

    const-string/jumbo v13, "nrtms"

    nop

    nop

    const/16 v7, 0x46e

    invoke-interface {v10, v13, v14, v15}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v13

    const/16 v7, 0xa95

    sput-wide v13, Lg4;->k:J

    const/16 v7, 0x1fc

    sget v10, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 v13, 0x1a

    const/4 v14, 0x0

    if-ge v10, v13, :cond_169

    goto/16 :goto_1f1

    :cond_169
    const-string/jumbo v10, "notification"

    nop

    nop

    const/16 v7, 0x31d

    move-object/from16 v0, p0

    invoke-virtual {v0, v10}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v10

    const/4 v7, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v10, Landroid/app/NotificationManager;

    const/16 v7, 0x47d

    invoke-static {}, Lmg1;->a()V

    const/16 v7, 0x2b4

    new-instance v13, Landroid/app/NotificationChannel;

    nop

    const-string/jumbo v15, "tls_dft0"

    nop

    nop

    const-string/jumbo v16, "TLS Tunnel Notification"

    nop

    nop

    const/16 v17, 0x3

    const/16 v7, 0x31e

    move-object/from16 v0, v16

    move/from16 v1, v17

    invoke-direct {v13, v15, v0, v1}, Landroid/app/NotificationChannel;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V

    const/16 v7, 0x4da

    invoke-virtual {v13, v14, v14}, Landroid/app/NotificationChannel;->setSound(Landroid/net/Uri;Landroid/media/AudioAttributes;)V

    const/16 v7, 0x439

    invoke-virtual {v13, v12}, Landroid/app/NotificationChannel;->enableVibration(Z)V

    const v15, -0xff0001

    const/16 v7, 0x368

    invoke-virtual {v13, v15}, Landroid/app/NotificationChannel;->setLightColor(I)V

    const/16 v7, 0x47d

    invoke-static {}, Lmg1;->a()V

    const/16 v7, 0x2b4

    new-instance v16, Landroid/app/NotificationChannel;

    nop

    const-string/jumbo v17, "tls_ipt0"

    nop

    nop

    const-string/jumbo v18, "TLS Tunnel Important Notification"

    nop

    nop

    const/16 v19, 0x4

    const/16 v7, 0x31e

    move-object/from16 v0, v16

    move-object/from16 v1, v17

    move-object/from16 v2, v18

    move/from16 v3, v19

    invoke-direct {v0, v1, v2, v3}, Landroid/app/NotificationChannel;-><init>(Ljava/lang/String;Ljava/lang/CharSequence;I)V

    const/16 v7, 0x4da

    move-object/from16 v0, v16

    invoke-virtual {v0, v14, v14}, Landroid/app/NotificationChannel;->setSound(Landroid/net/Uri;Landroid/media/AudioAttributes;)V

    const/16 v7, 0x439

    move-object/from16 v0, v16

    invoke-virtual {v0, v11}, Landroid/app/NotificationChannel;->enableVibration(Z)V

    const/16 v7, 0x368

    move-object/from16 v0, v16

    invoke-virtual {v0, v15}, Landroid/app/NotificationChannel;->setLightColor(I)V

    const/16 v7, 0x2ef

    invoke-virtual {v10, v13}, Landroid/app/NotificationManager;->createNotificationChannel(Landroid/app/NotificationChannel;)V

    const/16 v7, 0x2ef

    move-object/from16 v0, v16

    invoke-virtual {v10, v0}, Landroid/app/NotificationManager;->createNotificationChannel(Landroid/app/NotificationChannel;)V

    :goto_1f1
    const-string/jumbo v10, "PRO"

    nop

    nop

    const-string/jumbo v13, "App.checkProVersion(): Checando Assinatura PRO..."

    nop

    nop

    nop

    const/16 v7, 0x177

    invoke-virtual {v9}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Landroid/content/SharedPreferences;

    const-string/jumbo v10, ""

    const-string/jumbo v13, "pvdata"

    nop

    nop

    const/16 v7, 0x2e

    invoke-interface {v9, v13, v10}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const/4 v7, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x3eb

    new-instance v10, Ltd;

    nop

    const/16 v15, 0xc

    const/16 v7, 0x484

    invoke-direct {v10, v15}, Ltd;-><init>(I)V

    const/16 v7, 0x2e4

    sget-object v15, Lip;->a:Ljava/nio/charset/Charset;

    nop

    const/16 v7, 0x2c

    invoke-virtual {v9, v15}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v9

    const/4 v7, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0xd2d

    invoke-virtual {v10, v9}, Ltd;->q([B)[B

    move-result-object v9

    const/16 v7, 0x5c3

    invoke-static {}, Lmi2;->e()Z

    move-result v10

    if-nez v10, :cond_244

    array-length v10, v9

    if-nez v10, :cond_243

    goto :goto_244

    :cond_243
    move v12, v11

    :cond_244
    :goto_244
    const/16 v7, 0x4f1

    sput-boolean v12, Lmi2;->n:Z

    :try_start_248
    const/16 v7, 0x5b

    new-instance v10, Landroid/content/Intent;

    nop

    const-string/jumbo v11, "vrfysubs"

    nop

    nop

    const/16 v7, 0x53

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v12

    const-class v15, Lcom/tlsvpn/tlstunnel/services/ProMonitor;

    const/16 v7, 0x3fd

    move v0, v7

    move-object v1, v10

    move-object v2, v11

    move-object v3, v14

    move-object v4, v12

    move-object v5, v15

    invoke-direct/range {v1 .. v5}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;Landroid/content/Context;Ljava/lang/Class;)V

    const/16 v7, 0x53

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v11

    const/16 v7, 0x4a

    invoke-virtual {v11}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v11

    const/16 v7, 0x64

    invoke-virtual {v10, v11}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v10

    const/16 v7, 0x2d4

    invoke-virtual {v10, v13, v9}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[B)Landroid/content/Intent;

    move-result-object v9

    const/4 v7, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x4a7

    move-object/from16 v0, p0

    invoke-virtual {v0, v9}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_28c
    .catch Ljava/lang/Exception; {:try_start_248 .. :try_end_28c} :catch_28c

    :catch_28c
    return-void
.end method

.method public final onLowMemory()V
    .registers 5

    const-string/jumbo v2, "AppMemory"

    nop

    nop

    const-string/jumbo v3, "onLowMemory: Tentando liberar recursos críticos!"

    nop

    nop

    nop

    const/16 v0, 0x62e

    invoke-static {}, Ljava/lang/System;->gc()V

    const/16 v0, 0x1164

    invoke-super {p0}, Landroid/app/Application;->onLowMemory()V

    return-void
.end method

.method public final onTrimMemory(I)V
    .registers 6

    .prologue
    const/4 v0, -0x3

    new-instance v2, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v3, "onTrimMemory: Limpando recursos críticos! LVL("

    nop

    nop

    const/16 v0, 0x97

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x33

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 v3, 0x29

    const/16 v0, 0x1b

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string/jumbo v3, "AppMemory"

    nop

    nop

    nop

    const/16 v2, 0x14

    if-ne p1, v2, :cond_2e

    const/16 v0, 0x62e

    invoke-static {}, Ljava/lang/System;->gc()V

    :cond_2e
    const/16 v0, 0x6f3

    invoke-super {p0, p1}, Landroid/app/Application;->onTrimMemory(I)V

    return-void
.end method
