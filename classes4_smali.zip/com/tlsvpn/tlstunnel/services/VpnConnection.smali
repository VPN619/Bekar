.class public final Lcom/tlsvpn/tlstunnel/services/VpnConnection;
.super Ljava/lang/Thread;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final synthetic O:I


# instance fields
.field public A:Ljava/lang/Thread;

.field public B:Lcom/trilead/ssh2/Connection;

.field public C:Lcom/trilead/ssh2/DynamicPortForwarder;

.field public D:Z

.field public E:I

.field public F:I

.field public final G:Lr72;

.field public final H:Lsx;

.field public I:Lx52;

.field public J:I

.field public final K:Lhm2;

.field public L:Z

.field public M:Z

.field public N:Ljava/util/Set;

.field public final a:Lcom/tlsvpn/tlstunnel/services/ServicoVpn;

.field public final b:Landroid/content/SharedPreferences;

.field public final c:Lkg1;

.field public final d:Landroid/app/NotificationManager;

.field public final e:Z

.field public f:[Ljava/lang/String;

.field public g:[Ljava/lang/String;

.field public final h:Lou;

.field public final i:I

.field public final j:I

.field public final k:Ljava/lang/String;

.field public final l:Ljava/lang/String;

.field public m:Z

.field public n:Z

.field public o:Z

.field public p:Z

.field public q:I

.field public r:Ljava/lang/String;

.field public s:Ljava/lang/String;

.field public final t:Ljava/net/Socket;

.field public final u:Ljava/net/Socket;

.field public v:I

.field public w:I

.field public x:I

.field public y:I

.field public z:Ljava/net/ServerSocket;


# direct methods
.method public constructor <init>(Lcom/tlsvpn/tlstunnel/services/ServicoVpn;Landroid/content/SharedPreferences;Lkg1;Landroid/app/NotificationManager;Z)V
    .registers 14

    const/4 v6, -0x6

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v6, -0x6

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/lang/Thread;-><init>()V

    const/16 v6, 0x630

    iput-object p1, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->a:Lcom/tlsvpn/tlstunnel/services/ServicoVpn;

    const/16 v6, 0xd4a

    iput-object p2, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b:Landroid/content/SharedPreferences;

    const/16 v6, 0x1092

    iput-object p3, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->c:Lkg1;

    const/16 v6, 0xe3a

    iput-object p4, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->d:Landroid/app/NotificationManager;

    const/16 v6, 0x5bc

    iput-boolean p5, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->e:Z

    const-string/jumbo p3, "pdnsd"

    const/16 v6, 0x41d

    invoke-static {p3}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V

    const-string/jumbo p3, "tun2socks"

    const/16 v6, 0x41d

    invoke-static {p3}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V

    const/16 v6, 0x8ea

    new-instance p3, Lou;

    nop

    const/16 v6, 0x142

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const/4 v6, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 p4, 0x0

    const/4 p5, 0x1

    const/16 v6, 0x83d

    move v0, v6

    move-object v1, p3

    move-object v2, p2

    move-object v3, p1

    move v4, p4

    move v5, p5

    invoke-direct/range {v1 .. v5}, Lou;-><init>(Landroid/content/SharedPreferences;Landroid/content/res/Resources;ZZ)V

    const/16 v6, 0x107a

    iput-object p3, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h:Lou;

    const p1, 0x8f8d

    const/16 v6, 0x906

    iput p1, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->i:I

    const/16 p1, 0x1c5a

    const/16 v6, 0xa8c

    iput p1, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->j:I

    const-string/jumbo p1, "10.0.0.1"

    const/16 v6, 0xac4

    iput-object p1, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->k:Ljava/lang/String;

    const-string/jumbo p1, "10.0.0.2"

    const/16 v6, 0xcc4

    iput-object p1, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->l:Ljava/lang/String;

    const/16 v6, 0x112d

    iput-boolean p5, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->o:Z

    const/16 v6, 0xf3b

    iput-boolean p5, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->p:Z

    const-string/jumbo p1, "7300"

    const/16 v6, 0x8e

    invoke-static {p1}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result p1

    const/16 v6, 0xec2

    iput p1, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->q:I

    const/16 v6, 0x516

    new-instance p1, Ljava/net/Socket;

    nop

    const/16 v6, 0x447

    invoke-direct {p1}, Ljava/net/Socket;-><init>()V

    const/16 v6, 0xd6b

    iput-object p1, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->t:Ljava/net/Socket;

    const/16 v6, 0x516

    new-instance p1, Ljava/net/Socket;

    nop

    const/16 v6, 0x447

    invoke-direct {p1}, Ljava/net/Socket;-><init>()V

    const/16 v6, 0x1000

    iput-object p1, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->u:Ljava/net/Socket;

    const/16 v6, 0x115c

    iput-boolean p5, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    const/16 v6, 0x113c

    invoke-static {}, Lq23;->e()Lr72;

    move-result-object p1

    const/16 v6, 0x536

    iput-object p1, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->G:Lr72;

    const/16 v6, 0x132

    sget-object p2, Lh50;->a:Li20;

    nop

    const/16 v6, 0x126

    sget-object p2, Lx10;->c:Lx10;

    nop

    const/4 v6, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x76b

    invoke-static {p2, p1}, Lns2;->x(Ljy;Lly;)Lly;

    move-result-object p1

    const/16 v6, 0xf43

    invoke-static {p1}, Lw53;->a(Lly;)Lsx;

    move-result-object p1

    const/16 v6, 0xed5

    iput-object p1, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->H:Lsx;

    const/16 v6, 0xcdd

    new-instance p1, Lhm2;

    nop

    const/16 v6, 0xb90

    invoke-direct {p1, p0}, Lhm2;-><init>(Lcom/tlsvpn/tlstunnel/services/VpnConnection;)V

    const/16 v6, 0x951

    iput-object p1, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->K:Lhm2;

    const/16 v6, 0x1203

    iput-boolean p5, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->M:Z

    const/16 v6, 0x48a

    new-instance p1, Ljava/util/LinkedHashSet;

    nop

    const/16 v6, 0x3f9

    invoke-direct {p1}, Ljava/util/LinkedHashSet;-><init>()V

    const/16 v6, 0xeb5

    iput-object p1, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->N:Ljava/util/Set;

    return-void
.end method

.method private final native B(Ljava/lang/String;)I
.end method

.method public static synthetic b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V
    .registers 5

    const/4 v2, 0x0

    const/16 v0, 0x163

    invoke-virtual {p0, p1, v2}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->a(Ljava/lang/String;Z)V

    return-void
.end method

.method public static c(Landroid/net/VpnService$Builder;Z)V
    .registers 46

    .prologue
    move-object/from16 v2, p0

    const-string/jumbo v42, "200.0.0.0/5"

    const-string/jumbo v43, "208.0.0.0/4"

    const-string/jumbo v3, "0.0.0.0/5"

    const-string/jumbo v4, "8.0.0.0/7"

    const-string/jumbo v5, "10.0.0.0/8"

    const-string/jumbo v6, "11.0.0.0/8"

    const-string/jumbo v7, "12.0.0.0/6"

    const-string/jumbo v8, "16.0.0.0/4"

    const-string/jumbo v9, "32.0.0.0/3"

    const-string/jumbo v10, "64.0.0.0/3"

    const-string/jumbo v11, "96.0.0.0/6"

    const-string/jumbo v12, "100.0.0.0/10"

    const-string/jumbo v13, "100.128.0.0/9"

    const-string/jumbo v14, "101.0.0.0/8"

    const-string/jumbo v15, "102.0.0.0/7"

    const-string/jumbo v16, "104.0.0.0/5"

    const-string/jumbo v17, "112.0.0.0/5"

    const-string/jumbo v18, "120.0.0.0/6"

    const-string/jumbo v19, "124.0.0.0/7"

    const-string/jumbo v20, "126.0.0.0/8"

    const-string/jumbo v21, "128.0.0.0/3"

    const-string/jumbo v22, "160.0.0.0/5"

    const-string/jumbo v23, "168.0.0.0/6"

    const-string/jumbo v24, "172.0.0.0/12"

    const-string/jumbo v25, "172.32.0.0/11"

    const-string/jumbo v26, "172.64.0.0/10"

    const-string/jumbo v27, "172.128.0.0/9"

    const-string/jumbo v28, "173.0.0.0/8"

    const-string/jumbo v29, "174.0.0.0/7"

    const-string/jumbo v30, "176.0.0.0/4"

    const-string/jumbo v31, "192.0.0.0/9"

    const-string/jumbo v32, "192.128.0.0/11"

    const-string/jumbo v33, "192.160.0.0/13"

    const-string/jumbo v34, "192.169.0.0/16"

    const-string/jumbo v35, "192.170.0.0/15"

    const-string/jumbo v36, "192.172.0.0/14"

    const-string/jumbo v37, "192.176.0.0/12"

    const-string/jumbo v38, "192.192.0.0/10"

    const-string/jumbo v39, "193.0.0.0/8"

    const-string/jumbo v40, "194.0.0.0/7"

    const-string/jumbo v41, "196.0.0.0/6"

    check-cast v3, Ljava/lang/String;

    check-cast v4, Ljava/lang/String;

    check-cast v5, Ljava/lang/String;

    check-cast v6, Ljava/lang/String;

    check-cast v7, Ljava/lang/String;

    check-cast v8, Ljava/lang/String;

    check-cast v9, Ljava/lang/String;

    check-cast v10, Ljava/lang/String;

    check-cast v11, Ljava/lang/String;

    check-cast v12, Ljava/lang/String;

    check-cast v13, Ljava/lang/String;

    check-cast v14, Ljava/lang/String;

    check-cast v15, Ljava/lang/String;

    check-cast v16, Ljava/lang/String;

    check-cast v17, Ljava/lang/String;

    check-cast v18, Ljava/lang/String;

    check-cast v19, Ljava/lang/String;

    check-cast v20, Ljava/lang/String;

    check-cast v21, Ljava/lang/String;

    check-cast v22, Ljava/lang/String;

    check-cast v23, Ljava/lang/String;

    check-cast v24, Ljava/lang/String;

    check-cast v25, Ljava/lang/String;

    check-cast v26, Ljava/lang/String;

    check-cast v27, Ljava/lang/String;

    check-cast v28, Ljava/lang/String;

    check-cast v29, Ljava/lang/String;

    check-cast v30, Ljava/lang/String;

    check-cast v31, Ljava/lang/String;

    check-cast v32, Ljava/lang/String;

    check-cast v33, Ljava/lang/String;

    check-cast v34, Ljava/lang/String;

    check-cast v35, Ljava/lang/String;

    check-cast v36, Ljava/lang/String;

    check-cast v37, Ljava/lang/String;

    check-cast v38, Ljava/lang/String;

    check-cast v39, Ljava/lang/String;

    check-cast v40, Ljava/lang/String;

    check-cast v41, Ljava/lang/String;

    check-cast v42, Ljava/lang/String;

    check-cast v43, Ljava/lang/String;

    filled-new-array/range {v3 .. v43}, [Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x0

    move v5, v4

    :goto_d5
    const/4 v6, 0x6

    const-string/jumbo v7, "/"

    const/4 v8, 0x1

    const/16 v9, 0x29

    if-ge v5, v9, :cond_10f

    aget-object v9, v3, v5

    check-cast v7, Ljava/lang/String;

    filled-new-array {v7}, [Ljava/lang/String;

    move-result-object v7

    const/16 v0, 0x89

    invoke-static {v9, v7, v6}, Lc72;->E0(Ljava/lang/CharSequence;[Ljava/lang/String;I)Ljava/util/List;

    move-result-object v6

    :try_start_ec
    const/16 v0, 0x24

    invoke-interface {v6, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    const/16 v0, 0x24

    invoke-interface {v6, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Ljava/lang/String;

    const/16 v0, 0x8e

    invoke-static {v6}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v6

    const/16 v0, 0x3a5

    invoke-virtual {v2, v7, v6}, Landroid/net/VpnService$Builder;->addRoute(Ljava/lang/String;I)Landroid/net/VpnService$Builder;

    move-result-object v6

    const/4 v0, -0x6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_10c
    .catch Ljava/lang/Exception; {:try_start_ec .. :try_end_10c} :catch_10c

    :catch_10c
    add-int/lit8 v5, v5, 0x1

    goto :goto_d5

    :cond_10f
    if-eqz p1, :cond_154

    const-string/jumbo v3, "2000::/3"

    const-string/jumbo v5, "fd00::/8"

    check-cast v3, Ljava/lang/String;

    check-cast v5, Ljava/lang/String;

    filled-new-array {v3, v5}, [Ljava/lang/String;

    move-result-object v3

    move v5, v4

    :goto_120
    const/4 v9, 0x2

    if-ge v5, v9, :cond_154

    aget-object v9, v3, v5

    check-cast v7, Ljava/lang/String;

    filled-new-array {v7}, [Ljava/lang/String;

    move-result-object v10

    const/16 v0, 0x89

    invoke-static {v9, v10, v6}, Lc72;->E0(Ljava/lang/CharSequence;[Ljava/lang/String;I)Ljava/util/List;

    move-result-object v9

    :try_start_131
    const/16 v0, 0x24

    invoke-interface {v9, v4}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    const/16 v0, 0x24

    invoke-interface {v9, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    const/16 v0, 0x8e

    invoke-static {v9}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v9

    const/16 v0, 0x3a5

    invoke-virtual {v2, v10, v9}, Landroid/net/VpnService$Builder;->addRoute(Ljava/lang/String;I)Landroid/net/VpnService$Builder;

    move-result-object v9

    const/4 v0, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_151
    .catch Ljava/lang/Exception; {:try_start_131 .. :try_end_151} :catch_151

    :catch_151
    add-int/lit8 v5, v5, 0x1

    goto :goto_120

    :cond_154
    return-void
.end method

.method private final native y(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I
.end method


# virtual methods
.method public final a(Ljava/lang/String;Z)V
    .registers 10

    .prologue
    const/16 v0, 0x1c

    iget-boolean v2, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    nop

    if-nez v2, :cond_b

    if-eqz p2, :cond_a

    goto :goto_b

    :cond_a
    return-void

    :cond_b
    :goto_b
    const/16 v0, 0x5b

    new-instance p2, Landroid/content/Intent;

    nop

    const-string/jumbo v2, "addLog"

    const/16 v0, 0x62

    invoke-direct {p2, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v0, 0xfa

    iget-object p0, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->a:Lcom/tlsvpn/tlstunnel/services/ServicoVpn;

    nop

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const/16 v0, 0x4a

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/16 v0, 0x64

    invoke-virtual {p2, v2}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p2

    const/high16 v2, 0x10000000

    const/16 v0, 0x59

    invoke-virtual {p2, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x905

    sget-boolean v2, Lmi2;->a:Z

    nop

    if-eqz v2, :cond_50

    const-string/jumbo v2, "lmsg"

    const/16 v0, 0x4b

    invoke-virtual {p2, v2, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    goto :goto_c7

    :cond_50
    const/16 v0, 0x1062

    new-instance v2, Ljava/util/Date;

    nop

    const/16 v0, 0x958

    invoke-direct {v2}, Ljava/util/Date;-><init>()V

    const/16 v0, 0xd54

    new-instance v3, Ljava/text/SimpleDateFormat;

    nop

    const-string/jumbo v4, "HH:mm:ss"

    const/16 v0, 0xa75

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v5

    const/16 v0, 0xc81

    invoke-direct {v3, v4, v5}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    const/16 v0, 0xb7a

    sget-object v4, Lmi2;->b:Ljava/util/concurrent/CopyOnWriteArrayList;

    nop

    const/4 v0, -0x3

    new-instance v5, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v6, "["

    const/16 v0, 0x97

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0xa9e

    invoke-virtual {v3, v2}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v2

    const/4 v0, 0x0

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v2, "] "

    const/4 v0, 0x0

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {v5, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/16 v2, 0x3f

    const/16 v0, 0x9b4

    invoke-static {p1, v2}, Landroid/text/Html;->fromHtml(Ljava/lang/String;I)Landroid/text/Spanned;

    move-result-object p1

    const/16 v0, 0x146

    invoke-virtual {v4, p1}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    const/16 v0, 0x13d

    invoke-virtual {v4}, Ljava/util/concurrent/CopyOnWriteArrayList;->size()I

    move-result p1

    const/16 v2, 0x3e7

    if-le p1, v2, :cond_b5

    const/4 p1, 0x0

    const/16 v0, 0xac6

    invoke-virtual {v4, p1}, Ljava/util/concurrent/CopyOnWriteArrayList;->remove(I)Ljava/lang/Object;

    :cond_b5
    const/16 v0, 0x195

    sget-boolean p1, Lmi2;->d:Z

    nop

    if-nez p1, :cond_c7

    const/16 v0, 0x4d0

    sget p1, Lmi2;->c:I

    nop

    add-int/lit8 p1, p1, 0x1

    const/16 v0, 0x100f

    sput p1, Lmi2;->c:I

    :cond_c7
    :goto_c7
    const/16 v0, 0x63

    invoke-virtual {p0, p2}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    return-void
.end method

.method public final d(Landroid/net/VpnService$Builder;)V
    .registers 11

    .prologue
    const/16 v0, 0x745

    iget-boolean v2, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->L:Z

    nop

    const/16 v0, 0xb91

    iget-object v3, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h:Lou;

    nop

    if-nez v2, :cond_34

    const/16 v0, 0x1b9

    iget-boolean p0, v3, Lou;->x:Z

    nop

    if-eqz p0, :cond_128

    const/16 v0, 0x25b

    sget-object p0, Lil1;->a:Ljava/util/Set;

    nop

    const/16 v0, 0x14c

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_1e
    const/16 v0, 0x13e

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_128

    const/16 v0, 0x16e

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    const/16 v0, 0x22d

    invoke-virtual {p1, v2}, Landroid/net/VpnService$Builder;->addDisallowedApplication(Ljava/lang/String;)Landroid/net/VpnService$Builder;

    goto :goto_1e

    :cond_34
    const/16 v0, 0xf6a

    iget-boolean v2, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->M:Z

    nop

    const/4 v4, 0x0

    const-string/jumbo v5, "</b> "

    const-string/jumbo v6, "<b>"

    if-eqz v2, :cond_b2

    const/16 v0, 0x1b9

    iget-boolean v2, v3, Lou;->x:Z

    nop

    if-eqz v2, :cond_6a

    const/16 v0, 0x25b

    sget-object v2, Lil1;->a:Ljava/util/Set;

    nop

    const/16 v0, 0x14c

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_54
    const/16 v0, 0x13e

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_6a

    const/16 v0, 0x16e

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    const/16 v0, 0x22d

    invoke-virtual {p1, v3}, Landroid/net/VpnService$Builder;->addDisallowedApplication(Ljava/lang/String;)Landroid/net/VpnService$Builder;

    goto :goto_54

    :cond_6a
    const/16 v0, 0x238

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->N:Ljava/util/Set;

    nop

    const/16 v0, 0x14c

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_75
    const/16 v0, 0x13e

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_128

    const/16 v0, 0x16e

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    const/4 v0, -0x3

    new-instance v7, Ljava/lang/StringBuilder;

    nop

    const/16 v0, 0x97

    invoke-direct {v7, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const v8, 0x7f1300d4

    const/4 v0, 0x7

    invoke-virtual {p0, v8}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v8

    const/4 v0, 0x0

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const/16 v0, 0x163

    invoke-virtual {p0, v7, v4}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->a(Ljava/lang/String;Z)V

    const/16 v0, 0x22d

    invoke-virtual {p1, v3}, Landroid/net/VpnService$Builder;->addDisallowedApplication(Ljava/lang/String;)Landroid/net/VpnService$Builder;

    goto :goto_75

    :cond_b2
    const/16 v0, 0x1b9

    iget-boolean v2, v3, Lou;->x:Z

    nop

    if-eqz v2, :cond_ca

    const/16 v0, 0x238

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->N:Ljava/util/Set;

    nop

    const/16 v0, 0x25b

    sget-object v3, Lil1;->a:Ljava/util/Set;

    nop

    check-cast v3, Ljava/util/Collection;

    const/16 v0, 0x94f

    invoke-interface {v2, v3}, Ljava/util/Set;->removeAll(Ljava/util/Collection;)Z

    :cond_ca
    const/16 v0, 0xfa

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->a:Lcom/tlsvpn/tlstunnel/services/ServicoVpn;

    nop

    const/16 v0, 0x53

    invoke-virtual {v2}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const/16 v0, 0x4a

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/16 v0, 0x4c6

    invoke-virtual {p1, v2}, Landroid/net/VpnService$Builder;->addAllowedApplication(Ljava/lang/String;)Landroid/net/VpnService$Builder;

    const/16 v0, 0x238

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->N:Ljava/util/Set;

    nop

    const/16 v0, 0x14c

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_eb
    const/16 v0, 0x13e

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_128

    const/16 v0, 0x16e

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    const/4 v0, -0x3

    new-instance v7, Ljava/lang/StringBuilder;

    nop

    const/16 v0, 0x97

    invoke-direct {v7, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const v8, 0x7f130100

    const/4 v0, 0x7

    invoke-virtual {p0, v8}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v8

    const/4 v0, 0x0

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const/16 v0, 0x163

    invoke-virtual {p0, v7, v4}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->a(Ljava/lang/String;Z)V

    const/16 v0, 0x4c6

    invoke-virtual {p1, v3}, Landroid/net/VpnService$Builder;->addAllowedApplication(Ljava/lang/String;)Landroid/net/VpnService$Builder;

    goto :goto_eb

    :cond_128
    return-void
.end method

.method public final e()V
    .registers 16

    .prologue
    const/16 v6, 0xfa

    iget-object v8, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->a:Lcom/tlsvpn/tlstunnel/services/ServicoVpn;

    nop

    const-string/jumbo v9, ""

    const/16 v6, 0xcbf

    iget-object p0, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b:Landroid/content/SharedPreferences;

    nop

    const-string/jumbo v10, "pvdata"

    const/16 v6, 0x2e

    invoke-interface {p0, v10, v9}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x3eb

    new-instance v9, Ltd;

    nop

    const/16 v11, 0xc

    const/16 v6, 0x484

    invoke-direct {v9, v11}, Ltd;-><init>(I)V

    const/16 v6, 0x2e4

    sget-object v11, Lip;->a:Ljava/nio/charset/Charset;

    nop

    const/16 v6, 0x2c

    invoke-virtual {p0, v11}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p0

    const/4 v6, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xd2d

    invoke-virtual {v9, p0}, Ltd;->q([B)[B

    move-result-object p0

    const/16 v6, 0x5c3

    invoke-static {}, Lmi2;->e()Z

    move-result v9

    if-nez v9, :cond_49

    array-length v9, p0

    if-nez v9, :cond_47

    goto :goto_49

    :cond_47
    const/4 v9, 0x1

    goto :goto_4a

    :cond_49
    :goto_49
    const/4 v9, 0x0

    :goto_4a
    const/16 v6, 0x4f1

    sput-boolean v9, Lmi2;->n:Z

    :try_start_4e
    const/16 v6, 0x5b

    new-instance v9, Landroid/content/Intent;

    nop

    const-string/jumbo v11, "vrfysubs"

    const/16 v6, 0x53

    invoke-virtual {v8}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v12

    const-class v13, Lcom/tlsvpn/tlstunnel/services/ProMonitor;

    const/4 v14, 0x0

    const/16 v6, 0x3fd

    move v0, v6

    move-object v1, v9

    move-object v2, v11

    move-object v3, v14

    move-object v4, v12

    move-object v5, v13

    invoke-direct/range {v1 .. v5}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;Landroid/content/Context;Ljava/lang/Class;)V

    const/16 v6, 0x53

    invoke-virtual {v8}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v11

    const/16 v6, 0x4a

    invoke-virtual {v11}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v11

    const/16 v6, 0x64

    invoke-virtual {v9, v11}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v9

    const/16 v6, 0x2d4

    invoke-virtual {v9, v10, p0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;[B)Landroid/content/Intent;

    move-result-object p0

    const/4 v6, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x4a7

    invoke-virtual {v8, p0}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_8b
    .catch Ljava/lang/Exception; {:try_start_4e .. :try_end_8b} :catch_8b

    :catch_8b
    return-void
.end method

.method public final f()J
    .registers 77

    .prologue
    move-object/from16 v15, p0

    const-string/jumbo v21, "127.0.0.1:"

    const/16 v12, 0x1258

    iget v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->i:I

    move/16 v22, v12

    const/16 v12, 0x10aa

    iget v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->j:I

    move/16 v23, v12

    const-string/jumbo v14, "."

    const/16 v12, 0xb02

    iget-object v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->u:Ljava/net/Socket;

    move-object/16 v16, v12

    const/16 v12, 0x739

    iget-object v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->k:Ljava/lang/String;

    move-object/16 v24, v12

    const/16 v12, 0x11aa

    iget-object v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->t:Ljava/net/Socket;

    move-object/16 v20, v12

    const-string/jumbo v25, "</b>: "

    const-string/jumbo v26, "<b>"

    const/16 v12, 0xfa

    iget-object v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->a:Lcom/tlsvpn/tlstunnel/services/ServicoVpn;

    move-object/16 v27, v12

    const/16 v12, 0xb91

    iget-object v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h:Lou;

    move-object/16 v28, v12

    const v29, 0x7f13009d

    const-wide/16 v30, 0x0

    :try_start_44
    const/16 v12, 0x1c

    iget-boolean v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    move/16 v17, v12
    :try_end_4b
    .catch Ljava/lang/Exception; {:try_start_44 .. :try_end_4b} :catch_d2
    .catchall {:try_start_44 .. :try_end_4b} :catchall_cc

    if-nez v17, :cond_59

    const/4 v12, 0x7

    move/from16 v0, v29

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v14

    :goto_54
    const/4 v12, -0x8

    invoke-static {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    return-wide v30

    :cond_59
    :try_start_59
    const/16 v12, 0x1b8

    move-object/from16 v0, v28

    iget v12, v0, Lou;->m:I

    move/16 v17, v12

    const/16 v18, 0x1

    const/16 v19, 0x2

    move-object/from16 v32, v16

    const/16 v16, 0x0

    move/from16 v0, v17

    move/from16 v1, v18

    if-ne v0, v1, :cond_d5

    const/16 v12, 0x3f5

    move-object/from16 v0, v28

    iget-boolean v12, v0, Lou;->t:Z

    move/16 v17, v12

    if-eqz v17, :cond_d5

    const/16 v12, 0x1e1

    move-object/from16 v0, v28

    iget-object v12, v0, Lou;->u:Ljava/lang/String;

    move-object/16 v17, v12

    const/16 v12, 0x7c

    move-object/from16 v0, v17

    invoke-static {v0}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v17

    if-nez v17, :cond_d5

    const/16 v12, 0x1f4

    move-object/from16 v0, v28

    iget-object v12, v0, Lou;->v:Ljava/lang/String;

    move-object/16 v17, v12

    const/16 v12, 0x7c

    move-object/from16 v0, v17

    invoke-static {v0}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v17

    if-nez v17, :cond_d5

    const/16 v12, 0x162

    new-instance v17, Ljava/net/InetSocketAddress;

    nop

    const/16 v12, 0x1e1

    move-object/from16 v0, v28

    iget-object v12, v0, Lou;->u:Ljava/lang/String;

    move-object/16 v29, v12

    const/16 v12, 0x1f4

    move-object/from16 v0, v28

    iget-object v12, v0, Lou;->v:Ljava/lang/String;

    move-object/16 v18, v12

    const/16 v12, 0x8e

    move-object/from16 v0, v18

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v18

    const/16 v12, 0x17c

    move-object/from16 v0, v17

    move-object/from16 v1, v29

    move/from16 v2, v18

    invoke-direct {v0, v1, v2}, Ljava/net/InetSocketAddress;-><init>(Ljava/lang/String;I)V

    goto :goto_113

    :catchall_cc
    move-exception v14

    :goto_cd
    const v17, 0x7f13009d

    goto/16 :goto_1f4f

    :catch_d2
    move-exception v14

    goto/16 :goto_1f05

    :cond_d5
    const/16 v12, 0x162

    new-instance v17, Ljava/net/InetSocketAddress;

    nop

    const/16 v12, 0x3b

    move-object/from16 v0, v28

    iget-object v12, v0, Lou;->i:Ljava/lang/String;

    move-object/16 v18, v12

    const/16 v12, 0x34a

    move-object/from16 v0, v28

    iget-object v12, v0, Lou;->g:Ljava/lang/String;

    move-object/16 v29, v12

    const/16 v12, 0x21c

    move-object/from16 v0, v29

    move/from16 v1, v16

    move/from16 v2, v19

    invoke-static {v0, v1, v2}, Lc72;->z0(Ljava/lang/CharSequence;II)Ljava/lang/CharSequence;

    move-result-object v29

    const/16 v12, 0xcb

    move-object/from16 v0, v29

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v29

    const/16 v12, 0x8e

    move-object/from16 v0, v29

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v29

    const/16 v12, 0x17c

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    move/from16 v2, v29

    invoke-direct {v0, v1, v2}, Ljava/net/InetSocketAddress;-><init>(Ljava/lang/String;I)V

    :goto_113
    const/16 v18, 0x2710

    const/16 v12, 0x840

    move-object/from16 v0, v20

    move-object/from16 v1, v17

    move/from16 v2, v18

    invoke-virtual {v0, v1, v2}, Ljava/net/Socket;->connect(Ljava/net/SocketAddress;I)V

    const/16 v17, 0x1

    const/16 v12, 0x44c

    move-object/from16 v0, v20

    move/from16 v1, v17

    invoke-virtual {v0, v1}, Ljava/net/Socket;->setTcpNoDelay(Z)V

    const/16 v12, 0x4b2

    move-object/from16 v0, v20

    move/from16 v1, v17

    invoke-virtual {v0, v1}, Ljava/net/Socket;->setKeepAlive(Z)V

    const/16 v12, 0xe05

    move-object/from16 v0, v27

    move-object/from16 v1, v20

    invoke-virtual {v0, v1}, Landroid/net/VpnService;->protect(Ljava/net/Socket;)Z

    const/16 v12, 0x964

    move-object/from16 v0, v20

    invoke-virtual {v0}, Ljava/net/Socket;->isConnected()Z

    move-result v17
    :try_end_145
    .catch Ljava/lang/Exception; {:try_start_59 .. :try_end_145} :catch_d2
    .catchall {:try_start_59 .. :try_end_145} :catchall_cc

    if-nez v17, :cond_153

    :goto_147
    const v17, 0x7f13009d

    :goto_14a
    const/4 v12, 0x7

    move/from16 v0, v17

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v14

    goto/16 :goto_54

    :cond_153
    :try_start_153
    const/16 v12, 0x2e0

    move-object/from16 v0, v20

    invoke-static {v0}, Landroid/os/ParcelFileDescriptor;->fromSocket(Ljava/net/Socket;)Landroid/os/ParcelFileDescriptor;

    move-result-object v17

    const/16 v12, 0x398

    move-object/from16 v0, v17

    invoke-virtual {v0}, Landroid/os/ParcelFileDescriptor;->detachFd()I

    move-result v17

    const/16 v12, 0xfe0

    move/from16 v0, v17

    iput v0, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->v:I

    const/16 v12, 0x5a

    sget-object v18, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->a:Lcom/tlsvpn/tlstunnel/utils/SocketOps;

    nop

    const/16 v12, 0x891

    move-object/from16 v0, v18

    move/from16 v1, v17

    invoke-virtual {v0, v1}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->H(I)V

    const/16 v12, 0x1c

    iget-boolean v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    move/16 v17, v12

    if-nez v17, :cond_181

    goto :goto_147

    :cond_181
    const v17, 0x7f13009d

    const/16 v12, 0xab

    iget v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->v:I

    move/16 v29, v12
    :try_end_18b
    .catch Ljava/lang/Exception; {:try_start_153 .. :try_end_18b} :catch_d2
    .catchall {:try_start_153 .. :try_end_18b} :catchall_cc

    const-string/jumbo v19, "Bad FileDescriptor"

    move/from16 v34, v16

    const/16 v16, 0x1

    move/from16 v0, v29

    move/from16 v1, v16

    if-ge v0, v1, :cond_19f

    :try_start_198
    const/4 v12, -0x8

    move-object/from16 v0, v19

    invoke-static {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    goto :goto_14a

    :cond_19f
    const v16, 0x7f1300d5

    const/4 v12, 0x7

    move/from16 v0, v16

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v17

    const/4 v12, -0x8

    move-object/from16 v0, v17

    invoke-static {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    const/4 v12, 0x7

    move/from16 v0, v16

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v16

    const/16 v12, 0x157

    move-object/from16 v0, v16

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->k(Ljava/lang/String;)V

    const/16 v12, 0x1b8

    move-object/from16 v0, v28

    iget v12, v0, Lou;->m:I

    move/16 v16, v12

    const/16 v29, 0x6

    const/16 v17, 0x1

    const/16 v35, 0xa

    move/from16 v0, v16

    move/from16 v1, v17

    if-ne v0, v1, :cond_62b

    const/16 v12, 0x8eb

    move-object/from16 v0, v28

    iget-boolean v12, v0, Lou;->n:Z

    move/16 v16, v12
    :try_end_1db
    .catch Ljava/lang/Exception; {:try_start_198 .. :try_end_1db} :catch_d2
    .catchall {:try_start_198 .. :try_end_1db} :catchall_cc

    const-wide/16 v36, 0xfa

    const v17, 0x7f1300cb

    const-string/jumbo v39, "[split]"

    if-eqz v16, :cond_37d

    :try_start_1e5
    const/16 v12, 0x75

    move-object/from16 v0, v28

    iget-boolean v12, v0, Lou;->w:Z

    move/16 v16, v12

    if-nez v16, :cond_1fd

    const/4 v12, 0x7

    move/from16 v0, v17

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v16

    const/4 v12, -0x8

    move-object/from16 v0, v16

    invoke-static {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    :cond_1fd
    const/16 v12, 0x9d

    move-object/from16 v0, v28

    iget-boolean v12, v0, Lou;->h:Z

    move/16 v16, v12

    if-eqz v16, :cond_280

    const/16 v12, 0x7f

    move-object/from16 v0, v28

    iget-boolean v12, v0, Lou;->p:Z

    move/16 v16, v12

    if-nez v16, :cond_280

    const/16 v12, 0x285

    move-object/from16 v0, v28

    iget-object v12, v0, Lou;->o:Ljava/lang/String;

    move-object/16 v16, v12

    check-cast v39, Ljava/lang/String;

    filled-new-array/range {v39 .. v39}, [Ljava/lang/String;

    move-result-object v17

    const/16 v12, 0x89

    move-object/from16 v0, v16

    move-object/from16 v1, v17

    move/from16 v2, v29

    invoke-static {v0, v1, v2}, Lc72;->E0(Ljava/lang/CharSequence;[Ljava/lang/String;I)Ljava/util/List;

    move-result-object v16

    const/16 v12, 0x170

    move-object/from16 v0, v16

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v16

    :cond_236
    :goto_236
    const/16 v12, 0x13e

    move-object/from16 v0, v16

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v17

    if-eqz v17, :cond_37d

    const/16 v12, 0x16e

    move-object/from16 v0, v16

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v17

    check-cast v17, Ljava/lang/String;

    const/16 v12, 0x7c

    move-object/from16 v0, v17

    invoke-static {v0}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v41

    if-nez v41, :cond_236

    const/16 v12, 0x5a

    sget-object v18, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->a:Lcom/tlsvpn/tlstunnel/utils/SocketOps;

    nop

    const/16 v12, 0xab

    iget v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->v:I

    move/16 v29, v12

    const/16 v12, 0x68f

    move-object/from16 v0, v18

    move/from16 v1, v29

    move-object/from16 v2, v17

    invoke-virtual {v0, v1, v2}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->D(ILjava/lang/String;)V

    const/16 v12, 0x209

    move-wide/from16 v0, v36

    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V

    const/16 v12, 0x1c

    iget-boolean v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    move/16 v17, v12

    if-nez v17, :cond_27d

    goto/16 :goto_147

    :cond_27d
    const/16 v29, 0x6

    goto :goto_236

    :cond_280
    const/16 v12, 0x285

    move-object/from16 v0, v28

    iget-object v12, v0, Lou;->o:Ljava/lang/String;

    move-object/16 v16, v12

    check-cast v39, Ljava/lang/String;

    filled-new-array/range {v39 .. v39}, [Ljava/lang/String;

    move-result-object v17

    const/16 v18, 0x6

    const/16 v12, 0x89

    move-object/from16 v0, v16

    move-object/from16 v1, v17

    move/from16 v2, v18

    invoke-static {v0, v1, v2}, Lc72;->E0(Ljava/lang/CharSequence;[Ljava/lang/String;I)Ljava/util/List;

    move-result-object v16

    const/16 v12, 0x170

    move-object/from16 v0, v16

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v16

    :goto_2a5
    const/16 v12, 0x13e

    move-object/from16 v0, v16

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v17

    if-eqz v17, :cond_37d

    const/16 v12, 0x16e

    move-object/from16 v0, v16

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v17

    check-cast v17, Ljava/lang/String;

    const/16 v12, 0x7c

    move-object/from16 v0, v17

    invoke-static {v0}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v18

    if-nez v18, :cond_379

    const/16 v12, 0x5a

    sget-object v18, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->a:Lcom/tlsvpn/tlstunnel/utils/SocketOps;

    nop

    const/16 v12, 0xab

    iget v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->v:I

    move/16 v29, v12

    const/16 v12, 0xe0a

    move-object/from16 v0, v18

    move/from16 v1, v29

    move-object/from16 v2, v17

    invoke-virtual {v0, v1, v2}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->E(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v17

    const/16 v12, 0x1c

    iget-boolean v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    move/16 v18, v12
    :try_end_2e2
    .catch Ljava/lang/Exception; {:try_start_1e5 .. :try_end_2e2} :catch_d2
    .catchall {:try_start_1e5 .. :try_end_2e2} :catchall_cc

    if-nez v18, :cond_2f0

    const v18, 0x7f13009d

    const/4 v12, 0x7

    move/from16 v0, v18

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v14

    goto/16 :goto_54

    :cond_2f0
    :try_start_2f0
    const/16 v12, 0x75

    move-object/from16 v0, v28

    iget-boolean v12, v0, Lou;->w:Z

    move/16 v18, v12

    if-nez v18, :cond_379

    const/16 v12, 0x47

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v18

    if-nez v18, :cond_312

    const v18, 0x7f1301d4

    const/4 v12, 0x7

    move/from16 v0, v18

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v17

    move-object/from16 v42, v16

    goto :goto_371

    :cond_312
    const/4 v12, -0x3

    new-instance v18, Ljava/lang/StringBuilder;

    nop

    const/4 v12, -0x4

    move-object/from16 v0, v18

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x0

    move-object/from16 v0, v18

    move-object/from16 v1, v26

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v42, v16

    const v29, 0x7f130219

    const/4 v12, 0x7

    move/from16 v0, v29

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v16

    const/4 v12, 0x0

    move-object/from16 v0, v18

    move-object/from16 v1, v16

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    move-object/from16 v0, v18

    move-object/from16 v1, v25

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v16, 0x1

    move/from16 v0, v16

    new-array v0, v0, [C

    move-object/from16 v29, v0

    aput-char v35, v29, v34

    const/16 v12, 0x31

    move-object/from16 v0, v17

    move-object/from16 v1, v29

    invoke-static {v0, v1}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v16

    move/from16 v17, v34

    const/16 v12, 0x24

    move-object/from16 v0, v16

    move/from16 v1, v17

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v16

    check-cast v16, Ljava/lang/String;

    const/4 v12, 0x0

    move-object/from16 v0, v18

    move-object/from16 v1, v16

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, -0x2

    move-object/from16 v0, v18

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v17

    :goto_371
    const/4 v12, -0x8

    move-object/from16 v0, v17

    invoke-static {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    move-object/from16 v16, v42

    :cond_379
    const/16 v34, 0x0

    goto/16 :goto_2a5

    :cond_37d
    const/16 v12, 0x1c

    iget-boolean v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    move/16 v16, v12

    if-nez v16, :cond_388

    goto/16 :goto_147

    :cond_388
    const/16 v12, 0x7f

    move-object/from16 v0, v28

    iget-boolean v12, v0, Lou;->p:Z

    move/16 v16, v12

    if-nez v16, :cond_3a3

    const/16 v12, 0x9d

    move-object/from16 v0, v28

    iget-boolean v12, v0, Lou;->h:Z

    move/16 v16, v12

    if-nez v16, :cond_39f

    goto :goto_3a3

    :cond_39f
    move-wide/from16 v16, v30

    goto/16 :goto_44d

    :cond_3a3
    :goto_3a3
    const/16 v12, 0x75

    move-object/from16 v0, v28

    iget-boolean v12, v0, Lou;->w:Z

    move/16 v16, v12

    if-nez v16, :cond_3be

    const v16, 0x7f1300d2

    const/4 v12, 0x7

    move/from16 v0, v16

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v17

    const/4 v12, -0x8

    move-object/from16 v0, v17

    invoke-static {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    :cond_3be
    const/16 v12, 0x5a

    sget-object v16, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->a:Lcom/tlsvpn/tlstunnel/utils/SocketOps;

    nop

    const/16 v12, 0xab

    iget v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->v:I

    move/16 v17, v12

    const/16 v12, 0x7f

    move-object/from16 v0, v28

    iget-boolean v12, v0, Lou;->p:Z

    move/16 v18, v12

    if-eqz v18, :cond_3f2

    const/16 v12, 0x26e

    move-object/from16 v0, v28

    iget-object v12, v0, Lou;->q:Ljava/lang/String;

    move-object/16 v18, v12

    const/16 v12, 0x7c

    move-object/from16 v0, v18

    invoke-static {v0}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v18

    if-nez v18, :cond_3f2

    const/16 v12, 0x26e

    move-object/from16 v0, v28

    iget-object v12, v0, Lou;->q:Ljava/lang/String;

    move-object/16 v18, v12

    goto :goto_3fb

    :cond_3f2
    const/16 v12, 0x3b

    move-object/from16 v0, v28

    iget-object v12, v0, Lou;->i:Ljava/lang/String;

    move-object/16 v18, v12

    :goto_3fb
    const/16 v12, 0x7f

    move-object/from16 v0, v28

    iget-boolean v12, v0, Lou;->p:Z

    move/16 v29, v12

    const/16 v33, 0x1

    xor-int/lit8 v29, v29, 0x1

    const/16 v12, 0x206

    move-object/from16 v0, v16

    move/from16 v1, v17

    move-object/from16 v2, v18

    move/from16 v3, v29

    invoke-virtual {v0, v1, v2, v3}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->g(ILjava/lang/String;Z)J

    move-result-wide v16
    :try_end_416
    .catch Ljava/lang/Exception; {:try_start_2f0 .. :try_end_416} :catch_d2
    .catchall {:try_start_2f0 .. :try_end_416} :catchall_cc

    cmp-long v18, v16, v30

    if-nez v18, :cond_432

    const v18, 0x7f130067

    :try_start_41d
    const/4 v12, 0x7

    move/from16 v0, v18

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v14

    const/4 v12, -0x8

    invoke-static {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    const v17, 0x7f13009d

    goto/16 :goto_14a

    :catch_42d
    move-exception v14

    move-wide/from16 v30, v16

    goto/16 :goto_1f05

    :cond_432
    const/16 v12, 0x75

    move-object/from16 v0, v28

    iget-boolean v12, v0, Lou;->w:Z

    move/16 v18, v12

    if-nez v18, :cond_44d

    const v18, 0x7f13025b

    const/4 v12, 0x7

    move/from16 v0, v18

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v29

    const/4 v12, -0x8

    move-object/from16 v0, v29

    invoke-static {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V
    :try_end_44d
    .catch Ljava/lang/Exception; {:try_start_41d .. :try_end_44d} :catch_42d
    .catchall {:try_start_41d .. :try_end_44d} :catchall_cc

    :cond_44d
    :goto_44d
    :try_start_44d
    const/16 v12, 0x1c

    iget-boolean v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    move/16 v18, v12
    :try_end_454
    .catch Ljava/lang/Exception; {:try_start_44d .. :try_end_454} :catch_608
    .catchall {:try_start_44d .. :try_end_454} :catchall_cc

    if-nez v18, :cond_465

    const v18, 0x7f13009d

    const/4 v12, 0x7

    move/from16 v0, v18

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v14

    :goto_460
    const/4 v12, -0x8

    invoke-static {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    return-wide v16

    :cond_465
    :try_start_465
    const/16 v12, 0x7f

    move-object/from16 v0, v28

    iget-boolean v12, v0, Lou;->p:Z

    move/16 v18, v12

    if-eqz v18, :cond_60c

    const/16 v12, 0xfdd

    move-object/from16 v0, v28

    iget-boolean v12, v0, Lou;->r:Z

    move/16 v18, v12

    if-eqz v18, :cond_60c

    const/16 v12, 0x75

    move-object/from16 v0, v28

    iget-boolean v12, v0, Lou;->w:Z

    move/16 v18, v12
    :try_end_484
    .catch Ljava/lang/Exception; {:try_start_465 .. :try_end_484} :catch_608
    .catchall {:try_start_465 .. :try_end_484} :catchall_cc

    if-nez v18, :cond_496

    const v18, 0x7f1300cb

    :try_start_489
    const/4 v12, 0x7

    move/from16 v0, v18

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v18

    const/4 v12, -0x8

    move-object/from16 v0, v18

    invoke-static {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V
    :try_end_496
    .catch Ljava/lang/Exception; {:try_start_489 .. :try_end_496} :catch_42d
    .catchall {:try_start_489 .. :try_end_496} :catchall_cc

    :cond_496
    :try_start_496
    const/16 v12, 0x9d

    move-object/from16 v0, v28

    iget-boolean v12, v0, Lou;->h:Z

    move/16 v18, v12
    :try_end_49f
    .catch Ljava/lang/Exception; {:try_start_496 .. :try_end_49f} :catch_608
    .catchall {:try_start_496 .. :try_end_49f} :catchall_cc

    const/16 v12, 0x2e3

    move-object/from16 v0, v28

    iget-object v12, v0, Lou;->s:Ljava/lang/String;

    move-object/16 v29, v12

    if-eqz v18, :cond_520

    :try_start_4aa
    check-cast v39, Ljava/lang/String;

    filled-new-array/range {v39 .. v39}, [Ljava/lang/String;

    move-result-object v18

    move-object/from16 v40, v20

    const/16 v20, 0x6

    const/16 v12, 0x89

    move-object/from16 v0, v29

    move-object/from16 v1, v18

    move/from16 v2, v20

    invoke-static {v0, v1, v2}, Lc72;->E0(Ljava/lang/CharSequence;[Ljava/lang/String;I)Ljava/util/List;

    move-result-object v18

    const/16 v12, 0x170

    move-object/from16 v0, v18

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v18

    :cond_4c8
    const/16 v12, 0x13e

    move-object/from16 v0, v18

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v20

    if-eqz v20, :cond_51c

    const/16 v12, 0x16e

    move-object/from16 v0, v18

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v20

    check-cast v20, Ljava/lang/String;

    const/16 v12, 0x7c

    move-object/from16 v0, v20

    invoke-static {v0}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v29

    if-nez v29, :cond_4c8

    const/16 v12, 0x1c

    iget-boolean v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    move/16 v29, v12
    :try_end_4ed
    .catch Ljava/lang/Exception; {:try_start_4aa .. :try_end_4ed} :catch_42d
    .catchall {:try_start_4aa .. :try_end_4ed} :catchall_cc

    if-nez v29, :cond_4fb

    :goto_4ef
    const v29, 0x7f13009d

    :goto_4f2
    const/4 v12, 0x7

    move/from16 v0, v29

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v14

    goto/16 :goto_460

    :cond_4fb
    :try_start_4fb
    const/16 v12, 0x5a

    sget-object v29, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->a:Lcom/tlsvpn/tlstunnel/utils/SocketOps;

    nop

    const/16 v12, 0x1100

    move-object/from16 v0, v29

    move-wide/from16 v1, v16

    move-object/from16 v3, v20

    invoke-virtual {v0, v1, v2, v3}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->q(JLjava/lang/String;)V

    const/16 v12, 0x209

    move-wide/from16 v0, v36

    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V

    const/16 v12, 0x1c

    iget-boolean v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    move/16 v20, v12
    :try_end_519
    .catch Ljava/lang/Exception; {:try_start_4fb .. :try_end_519} :catch_42d
    .catchall {:try_start_4fb .. :try_end_519} :catchall_cc

    if-nez v20, :cond_4c8

    goto :goto_4ef

    :cond_51c
    move-wide/from16 v36, v16

    goto/16 :goto_610

    :cond_520
    move-object/from16 v40, v20

    :try_start_522
    check-cast v39, Ljava/lang/String;

    filled-new-array/range {v39 .. v39}, [Ljava/lang/String;

    move-result-object v18

    const/16 v20, 0x6

    const/16 v12, 0x89

    move-object/from16 v0, v29

    move-object/from16 v1, v18

    move/from16 v2, v20

    invoke-static {v0, v1, v2}, Lc72;->E0(Ljava/lang/CharSequence;[Ljava/lang/String;I)Ljava/util/List;

    move-result-object v18

    const/16 v12, 0x170

    move-object/from16 v0, v18

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v18

    :cond_53e
    :goto_53e
    const/16 v12, 0x13e

    move-object/from16 v0, v18

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v20

    if-eqz v20, :cond_51c

    const/16 v12, 0x16e

    move-object/from16 v0, v18

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v20

    check-cast v20, Ljava/lang/String;

    const/16 v12, 0x7c

    move-object/from16 v0, v20

    invoke-static {v0}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v29

    if-nez v29, :cond_53e

    const/16 v12, 0x5a

    sget-object v29, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->a:Lcom/tlsvpn/tlstunnel/utils/SocketOps;

    nop

    const/16 v12, 0x49c

    move-object/from16 v0, v29

    move-wide/from16 v1, v16

    move-object/from16 v3, v20

    invoke-virtual {v0, v1, v2, v3}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->k(JLjava/lang/String;)Ljava/lang/String;

    move-result-object v20

    const/16 v12, 0x1c

    iget-boolean v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    move/16 v29, v12

    if-nez v29, :cond_578

    goto/16 :goto_4ef

    :cond_578
    const/16 v12, 0x75

    move-object/from16 v0, v28

    iget-boolean v12, v0, Lou;->w:Z

    move/16 v29, v12

    if-nez v29, :cond_53e

    const/16 v12, 0x47

    move-object/from16 v0, v20

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v29
    :try_end_58b
    .catch Ljava/lang/Exception; {:try_start_522 .. :try_end_58b} :catch_608
    .catchall {:try_start_522 .. :try_end_58b} :catchall_cc

    if-nez v29, :cond_59a

    const v29, 0x7f1301d4

    :try_start_590
    const/4 v12, 0x7

    move/from16 v0, v29

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v20
    :try_end_597
    .catch Ljava/lang/Exception; {:try_start_590 .. :try_end_597} :catch_42d
    .catchall {:try_start_590 .. :try_end_597} :catchall_cc

    move-wide/from16 v36, v16

    goto :goto_5f9

    :cond_59a
    :try_start_59a
    const/4 v12, -0x3

    new-instance v29, Ljava/lang/StringBuilder;

    nop

    const/4 v12, -0x4

    move-object/from16 v0, v29

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x0

    move-object/from16 v0, v29

    move-object/from16 v1, v26

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    :try_end_5ac
    .catch Ljava/lang/Exception; {:try_start_59a .. :try_end_5ac} :catch_608
    .catchall {:try_start_59a .. :try_end_5ac} :catchall_cc

    move-wide/from16 v36, v16

    const v16, 0x7f130219

    :try_start_5b1
    const/4 v12, 0x7

    move/from16 v0, v16

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v17

    const/4 v12, 0x0

    move-object/from16 v0, v29

    move-object/from16 v1, v17

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    move-object/from16 v0, v29

    move-object/from16 v1, v25

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v17, 0x1

    move/from16 v0, v17

    new-array v0, v0, [C

    move-object/from16 v16, v0

    const/16 v17, 0x0

    aput-char v35, v16, v17

    const/16 v12, 0x31

    move-object/from16 v0, v20

    move-object/from16 v1, v16

    invoke-static {v0, v1}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v16

    const/16 v12, 0x24

    move-object/from16 v0, v16

    move/from16 v1, v17

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v16

    check-cast v16, Ljava/lang/String;

    const/4 v12, 0x0

    move-object/from16 v0, v29

    move-object/from16 v1, v16

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, -0x2

    move-object/from16 v0, v29

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v20

    :goto_5f9
    const/4 v12, -0x8

    move-object/from16 v0, v20

    invoke-static {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    move-wide/from16 v16, v36

    goto/16 :goto_53e

    :catch_603
    move-exception v14

    :goto_604
    move-wide/from16 v30, v36

    goto/16 :goto_1f05

    :catch_608
    move-exception v14

    move-wide/from16 v36, v16

    goto :goto_604

    :cond_60c
    move-wide/from16 v36, v16

    move-object/from16 v40, v20

    :goto_610
    const/16 v12, 0x1c

    iget-boolean v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    move/16 v16, v12
    :try_end_617
    .catch Ljava/lang/Exception; {:try_start_5b1 .. :try_end_617} :catch_603
    .catchall {:try_start_5b1 .. :try_end_617} :catchall_cc

    if-nez v16, :cond_628

    const v17, 0x7f13009d

    const/4 v12, 0x7

    move/from16 v0, v17

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v14

    const/4 v12, -0x8

    invoke-static {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    return-wide v36

    :cond_628
    move-wide/from16 v16, v36

    goto :goto_692

    :cond_62b
    move-object/from16 v40, v20

    :try_start_62d
    const/16 v12, 0x9d

    move-object/from16 v0, v28

    iget-boolean v12, v0, Lou;->h:Z

    move/16 v16, v12

    if-nez v16, :cond_690

    const v16, 0x7f1300d2

    const/4 v12, 0x7

    move/from16 v0, v16

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v17

    const/4 v12, -0x8

    move-object/from16 v0, v17

    invoke-static {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    const/16 v12, 0xab

    iget v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->v:I

    move/16 v16, v12

    const/16 v12, 0x3b

    move-object/from16 v0, v28

    iget-object v12, v0, Lou;->i:Ljava/lang/String;

    move-object/16 v17, v12

    const/16 v20, 0x1

    const/16 v12, 0x206

    move-object/from16 v0, v18

    move/from16 v1, v16

    move-object/from16 v2, v17

    move/from16 v3, v20

    invoke-virtual {v0, v1, v2, v3}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->g(ILjava/lang/String;Z)J

    move-result-wide v16
    :try_end_668
    .catch Ljava/lang/Exception; {:try_start_62d .. :try_end_668} :catch_d2
    .catchall {:try_start_62d .. :try_end_668} :catchall_cc

    cmp-long v18, v16, v30

    if-nez v18, :cond_67f

    const v18, 0x7f130067

    :try_start_66f
    const/4 v12, 0x7

    move/from16 v0, v18

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v14

    const/4 v12, -0x8

    invoke-static {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    const v17, 0x7f13009d

    goto/16 :goto_14a

    :cond_67f
    const v18, 0x7f13025b

    const/4 v12, 0x7

    move/from16 v0, v18

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v20

    const/4 v12, -0x8

    move-object/from16 v0, v20

    invoke-static {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    goto :goto_692

    :cond_690
    move-wide/from16 v16, v30

    :goto_692
    const/16 v12, 0x1c

    iget-boolean v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    move/16 v18, v12

    if-nez v18, :cond_69d

    goto/16 :goto_4ef

    :cond_69d
    const/16 v12, 0x1b8

    move-object/from16 v0, v28

    iget v12, v0, Lou;->m:I

    move/16 v18, v12

    const/16 v20, 0x1

    move/from16 v0, v18

    move/from16 v1, v20

    if-ne v0, v1, :cond_6bc

    const/16 v12, 0x7f

    move-object/from16 v0, v28

    iget-boolean v12, v0, Lou;->p:Z

    move/16 v20, v12

    if-eqz v20, :cond_6bc

    const/16 v20, 0x1

    goto :goto_6be

    :cond_6bc
    const/16 v20, 0x0

    :goto_6be
    const/16 v12, 0x9d

    move-object/from16 v0, v28

    iget-boolean v12, v0, Lou;->h:Z

    move/16 v29, v12
    :try_end_6c7
    .catch Ljava/lang/Exception; {:try_start_66f .. :try_end_6c7} :catch_42d
    .catchall {:try_start_66f .. :try_end_6c7} :catchall_cc

    move/from16 v36, v18

    const-string/jumbo v18, "Failed to create tun interface"

    move-object/from16 v37, v18

    const-string/jumbo v18, "stelegrambs"

    move-object/from16 v38, v18

    const-string/jumbo v18, "evaluate"

    move-object/from16 v39, v18

    const-string/jumbo v18, "reviewRequested"

    move-object/from16 v41, v18

    const-string/jumbo v18, "</b>"

    move-object/from16 v42, v18

    const-string/jumbo v18, "KB"

    move-object/from16 v43, v18

    const-string/jumbo v18, "csuscgaE"

    move-object/from16 v44, v18

    const-string/jumbo v18, "vpnOn"

    move-object/from16 v45, v18

    const-string/jumbo v18, "setProgress"

    move-object/from16 v46, v18

    const-string/jumbo v18, "firstconn"

    move-object/from16 v47, v18

    const-string/jumbo v48, "lSocketServer"

    const-string/jumbo v49, "dnsSecu"

    const-string/jumbo v50, "dnsPrim"

    const/16 v12, 0xcbf

    iget-object v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b:Landroid/content/SharedPreferences;

    move-object/16 v18, v12

    move-object/from16 v52, v18

    if-eqz v29, :cond_1059

    :try_start_70f
    const/16 v12, 0x35e

    new-instance v14, Ljava/net/ServerSocket;

    nop

    const/16 v12, 0x4c5

    invoke-static {}, Ljava/net/InetAddress;->getLocalHost()Ljava/net/InetAddress;

    move-result-object v19

    const/16 v18, 0x0

    const/16 v29, 0x1

    const/16 v12, 0x2a3

    move/from16 v0, v18

    move/from16 v1, v29

    move-object/from16 v2, v19

    invoke-direct {v14, v0, v1, v2}, Ljava/net/ServerSocket;-><init>(IILjava/net/InetAddress;)V

    const/16 v12, 0x29f

    iput-object v14, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->z:Ljava/net/ServerSocket;
    :try_end_72d
    .catch Ljava/lang/Exception; {:try_start_70f .. :try_end_72d} :catch_42d
    .catchall {:try_start_70f .. :try_end_72d} :catchall_cc

    :try_start_72d
    const/16 v12, 0x3fa

    new-instance v14, Ljava/lang/Thread;

    nop

    const/16 v12, 0xf84

    new-instance v19, Lem2;

    nop

    const/16 v12, 0xc96

    move v0, v12

    move-object/from16 v1, v19

    move-object v2, v15

    move-wide/from16 v3, v16

    move/from16 v5, v20

    invoke-direct/range {v1 .. v5}, Lem2;-><init>(Lcom/tlsvpn/tlstunnel/services/VpnConnection;JZ)V

    const/16 v12, 0x4cc

    move-object/from16 v0, v19

    invoke-direct {v14, v0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    const/16 v12, 0x328

    iput-object v14, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->A:Ljava/lang/Thread;

    const/16 v12, 0x41b

    invoke-virtual {v14}, Ljava/lang/Thread;->start()V

    const v14, 0x7f130094

    const/4 v12, 0x7

    invoke-virtual {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v16

    const/4 v12, -0x8

    move-object/from16 v0, v16

    invoke-static {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    const/4 v12, 0x7

    invoke-virtual {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v14

    const/16 v12, 0x157

    invoke-virtual {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->k(Ljava/lang/String;)V

    const/16 v12, 0x5fd

    new-instance v14, Lcom/trilead/ssh2/Connection;

    nop

    const/16 v12, 0x152

    iget-object v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->z:Ljava/net/ServerSocket;

    move-object/16 v16, v12

    if-eqz v16, :cond_1050

    const/16 v12, 0x531

    move-object/from16 v0, v16

    invoke-virtual {v0}, Ljava/net/ServerSocket;->getInetAddress()Ljava/net/InetAddress;

    move-result-object v16

    const/16 v12, 0x21f

    move-object/from16 v0, v16

    invoke-virtual {v0}, Ljava/net/InetAddress;->getHostAddress()Ljava/lang/String;

    move-result-object v16

    const/16 v12, 0x152

    iget-object v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->z:Ljava/net/ServerSocket;

    move-object/16 v17, v12

    if-eqz v17, :cond_1047

    const/16 v12, 0x4c8

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/net/ServerSocket;->getLocalPort()I

    move-result v17

    const/16 v12, 0x862

    move-object/from16 v0, v16

    move/from16 v1, v17

    invoke-direct {v14, v0, v1}, Lcom/trilead/ssh2/Connection;-><init>(Ljava/lang/String;I)V

    const/16 v12, 0xab8

    iput-object v14, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->B:Lcom/trilead/ssh2/Connection;
    :try_end_7a8
    .catch Ljava/lang/Exception; {:try_start_72d .. :try_end_7a8} :catch_d2
    .catchall {:try_start_72d .. :try_end_7a8} :catchall_cc

    const/16 v17, 0x3a98

    move/from16 v34, v18

    const/16 v18, 0x3a98

    const/4 v15, 0x0

    const/16 v16, 0x3a98

    move-object/from16 v19, p0

    move/from16 v20, v29

    move-object/from16 v54, v37

    move-object/from16 v55, v38

    move-object/from16 v56, v39

    move-object/from16 v57, v41

    move-object/from16 v58, v42

    move-object/from16 v60, v43

    move-object/from16 v29, v44

    move-object/from16 v63, v45

    move-object/from16 v64, v46

    move-object/from16 v66, v47

    move-object/from16 v67, v52

    :try_start_7cb
    const/16 v12, 0x8e2

    move v0, v12

    move-object v1, v14

    move-object v2, v15

    move/from16 v3, v16

    move/from16 v4, v17

    move/from16 v5, v18

    move-object/from16 v6, v19

    invoke-virtual/range {v1 .. v6}, Lcom/trilead/ssh2/Connection;->connect(Lcom/trilead/ssh2/ServerHostKeyVerifier;IIILcom/tlsvpn/tlstunnel/services/VpnConnection;)Lcom/trilead/ssh2/ConnectionInfo;
    :try_end_7db
    .catch Ljava/lang/Exception; {:try_start_7cb .. :try_end_7db} :catch_1042
    .catchall {:try_start_7cb .. :try_end_7db} :catchall_103d

    move-object/from16 v15, v19

    :try_start_7dd
    const/16 v12, 0x1c

    iget-boolean v14, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    nop

    if-nez v14, :cond_7e6

    goto/16 :goto_147

    :cond_7e6
    const/16 v12, 0x222

    iget-object v14, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->B:Lcom/trilead/ssh2/Connection;

    nop
    :try_end_7eb
    .catch Ljava/lang/Exception; {:try_start_7dd .. :try_end_7eb} :catch_d2
    .catchall {:try_start_7dd .. :try_end_7eb} :catchall_cc

    const-string/jumbo v16, "sshClient"

    if-eqz v14, :cond_1034

    :try_start_7f0
    const/16 v12, 0x2e2

    move-object/from16 v0, v28

    iget-object v12, v0, Lou;->k:Ljava/lang/String;

    move-object/16 v17, v12

    const/16 v12, 0xecf

    move-object/from16 v0, v17

    invoke-virtual {v14, v0}, Lcom/trilead/ssh2/Connection;->getBanner(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    const/16 v12, 0x1c

    iget-boolean v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    move/16 v17, v12

    if-nez v17, :cond_80c

    goto/16 :goto_147

    :cond_80c
    const/16 v12, 0x47

    invoke-virtual {v14}, Ljava/lang/String;->length()I

    move-result v17

    move/from16 v0, v17

    move/from16 v1, v20

    if-le v0, v1, :cond_861

    const/4 v12, -0x3

    new-instance v17, Ljava/lang/StringBuilder;

    nop

    const/4 v12, -0x4

    move-object/from16 v0, v17

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v26

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v18, 0x7f13023d

    const/4 v12, 0x7

    move/from16 v0, v18

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v18

    const/4 v12, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v18, "</b>:<br><br>"

    const/4 v12, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    move-object/from16 v0, v17

    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v14, "<br>"

    const/4 v12, 0x0

    move-object/from16 v0, v17

    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, -0x2

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v14

    const/4 v12, -0x8

    invoke-static {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    :cond_861
    const v18, 0x7f130036

    const/4 v12, 0x7

    move/from16 v0, v18

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v14

    const/4 v12, -0x8

    invoke-static {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    const/4 v12, 0x7

    move/from16 v0, v18

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v14

    const/16 v12, 0x157

    invoke-virtual {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->k(Ljava/lang/String;)V

    const/16 v12, 0x222

    iget-object v14, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->B:Lcom/trilead/ssh2/Connection;

    nop

    if-eqz v14, :cond_102b

    const/16 v12, 0x2e2

    move-object/from16 v0, v28

    iget-object v12, v0, Lou;->k:Ljava/lang/String;

    move-object/16 v17, v12

    const/16 v12, 0xef9

    move-object/from16 v0, v28

    iget-object v12, v0, Lou;->l:Ljava/lang/String;

    move-object/16 v18, v12

    const/16 v12, 0xc9d

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-virtual {v14, v0, v1}, Lcom/trilead/ssh2/Connection;->authenticateWithPassword(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v14

    if-eqz v14, :cond_fdc

    const/16 v12, 0x1c

    iget-boolean v14, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    nop

    if-nez v14, :cond_8a9

    goto/16 :goto_147

    :cond_8a9
    const v14, 0x7f130035

    const/4 v12, 0x7

    invoke-virtual {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v14

    const/4 v12, -0x8

    invoke-static {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    const/16 v12, 0x222

    iget-object v14, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->B:Lcom/trilead/ssh2/Connection;

    nop

    if-eqz v14, :cond_fd3

    const/16 v12, 0x162

    new-instance v16, Ljava/net/InetSocketAddress;

    nop

    const-string/jumbo v17, "localhost"

    const/16 v12, 0x17c

    move-object/from16 v0, v16

    move-object/from16 v1, v17

    move/from16 v2, v23

    invoke-direct {v0, v1, v2}, Ljava/net/InetSocketAddress;-><init>(Ljava/lang/String;I)V

    const/16 v12, 0xa30

    move-object/from16 v0, v16

    invoke-virtual {v14, v0}, Lcom/trilead/ssh2/Connection;->createDynamicPortForwarder(Ljava/net/InetSocketAddress;)Lcom/trilead/ssh2/DynamicPortForwarder;

    move-result-object v14

    const/4 v12, -0x6

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v12, 0xadb

    iput-object v14, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->C:Lcom/trilead/ssh2/DynamicPortForwarder;

    const/16 v12, 0x367

    move/from16 v0, v34

    sput v0, Lmi2;->g:I

    const/16 v65, 0x3

    const/16 v12, 0x332

    move/from16 v0, v65

    sput v0, Lmi2;->o:I

    const/16 v12, 0x40a

    move-wide/from16 v0, v30

    sput-wide v0, Lmi2;->i:J

    const/16 v12, 0x3f0

    move/from16 v0, v34

    sput-boolean v0, Lmi2;->k:Z

    const/16 v12, 0x5b

    new-instance v14, Landroid/content/Intent;

    nop

    move-object/from16 v18, v64

    const/16 v12, 0x62

    move-object/from16 v0, v18

    invoke-direct {v14, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v12, 0x53

    move-object/from16 v0, v27

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v16

    const/16 v12, 0x4a

    move-object/from16 v0, v16

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v16

    const/16 v12, 0x64

    move-object/from16 v0, v16

    invoke-virtual {v14, v0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v14

    const/high16 v16, 0x10000000

    const/16 v12, 0x59

    move/from16 v0, v16

    invoke-virtual {v14, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v14

    const/16 v12, 0x63

    move-object/from16 v0, v27

    invoke-virtual {v0, v14}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    const/16 v12, 0x5b

    new-instance v14, Landroid/content/Intent;

    nop

    move-object/from16 v18, v63

    const/16 v12, 0x62

    move-object/from16 v0, v18

    invoke-direct {v14, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v12, 0x178

    move-object/from16 v0, v29

    move/from16 v1, v20

    invoke-virtual {v14, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    move-result-object v14

    const/16 v12, 0x53

    move-object/from16 v0, v27

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v17

    const/16 v12, 0x4a

    move-object/from16 v0, v17

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v17

    const/16 v12, 0x64

    move-object/from16 v0, v17

    invoke-virtual {v14, v0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v14

    const/16 v12, 0x59

    move/from16 v0, v16

    invoke-virtual {v14, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v14

    const/16 v12, 0x63

    move-object/from16 v0, v27

    invoke-virtual {v0, v14}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    const/16 v12, 0x402

    iget-object v14, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->I:Lx52;

    nop

    if-eqz v14, :cond_fc9

    const/16 v29, 0x0

    const/16 v12, 0x43a

    move-object/from16 v0, v29

    invoke-virtual {v14, v0}, Lnv0;->a(Ljava/util/concurrent/CancellationException;)V

    const v14, 0x7f130090

    const/4 v12, 0x7

    invoke-virtual {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v14

    const/4 v12, -0x8

    invoke-static {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    const/16 v12, 0x75

    move-object/from16 v0, v28

    iget-boolean v14, v0, Lou;->w:Z

    nop

    if-eqz v14, :cond_99f

    const v14, 0x7f130211

    const/4 v12, 0x7

    invoke-virtual {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v14

    const/16 v17, 0x3a

    goto :goto_9da

    :cond_99f
    const/4 v12, -0x3

    new-instance v14, Ljava/lang/StringBuilder;

    nop

    const/4 v12, -0x4

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v12, 0x121d

    move-object/from16 v0, v40

    invoke-virtual {v0}, Ljava/net/Socket;->getInetAddress()Ljava/net/InetAddress;

    move-result-object v17

    const/16 v12, 0x21f

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/net/InetAddress;->getHostAddress()Ljava/lang/String;

    move-result-object v17

    const/4 v12, 0x0

    move-object/from16 v0, v17

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v17, 0x3a

    const/16 v12, 0x1b

    move/from16 v0, v17

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v12, 0xe3e

    move-object/from16 v0, v40

    invoke-virtual {v0}, Ljava/net/Socket;->getPort()I

    move-result v18

    const/16 v12, 0x33

    move/from16 v0, v18

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, -0x2

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v14

    :goto_9da
    const-string/jumbo v18, ""

    const-string/jumbo v19, ""

    move/from16 v33, v20

    const/16 v20, 0x0

    move/from16 v53, v16

    const/16 v16, 0x1

    move/from16 v33, v17

    move-object/from16 v17, v14

    move/from16 v14, v33

    move-object/from16 v33, v29

    move/from16 v29, v53

    const/16 v12, 0x2ad

    move v0, v12

    move-object v1, v15

    move/from16 v2, v16

    move-object/from16 v3, v17

    move-object/from16 v4, v18

    move-object/from16 v5, v19

    move/from16 v6, v20

    invoke-virtual/range {v1 .. v6}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->j(ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V

    const/16 v12, 0x3dc

    new-instance v16, Landroid/net/VpnService$Builder;

    nop

    const/16 v12, 0x433

    move-object/from16 v0, v16

    move-object/from16 v1, v27

    invoke-direct {v0, v1}, Landroid/net/VpnService$Builder;-><init>(Landroid/net/VpnService;)V

    const v20, 0x7f130024

    const/4 v12, 0x7

    move/from16 v0, v20

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v17

    const/16 v12, 0x4f2

    move-object/from16 v0, v16

    move-object/from16 v1, v17

    invoke-virtual {v0, v1}, Landroid/net/VpnService$Builder;->setSession(Ljava/lang/String;)Landroid/net/VpnService$Builder;

    move-result-object v16

    const/16 v18, 0x20

    const/16 v12, 0x1d0

    move-object/from16 v0, v16

    move-object/from16 v1, v24

    move/from16 v2, v18

    invoke-virtual {v0, v1, v2}, Landroid/net/VpnService$Builder;->addAddress(Ljava/lang/String;I)Landroid/net/VpnService$Builder;

    move-result-object v16

    move/from16 v17, v34

    const/16 v12, 0x283

    move-object/from16 v0, v16

    move/from16 v1, v17

    invoke-virtual {v0, v1}, Landroid/net/VpnService$Builder;->setBlocking(Z)Landroid/net/VpnService$Builder;

    move-result-object v16

    const/16 v17, 0x5dc

    const/16 v12, 0x3c4

    move-object/from16 v0, v16

    move/from16 v1, v17

    invoke-virtual {v0, v1}, Landroid/net/VpnService$Builder;->setMtu(I)Landroid/net/VpnService$Builder;

    move-result-object v16

    const/4 v12, -0x6

    move-object/from16 v0, v16

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v12, 0x4a5

    iget-boolean v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->o:Z

    move/16 v17, v12

    if-eqz v17, :cond_ae5

    const/16 v12, 0xf6

    iget-object v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->r:Ljava/lang/String;

    move-object/16 v17, v12

    if-eqz v17, :cond_afd

    const/16 v12, 0xd4

    move-object/from16 v0, v16

    move-object/from16 v1, v17

    invoke-virtual {v0, v1}, Landroid/net/VpnService$Builder;->addDnsServer(Ljava/lang/String;)Landroid/net/VpnService$Builder;

    move-result-object v17

    const/16 v12, 0xd6

    iget-object v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->s:Ljava/lang/String;

    move-object/16 v18, v12

    if-eqz v18, :cond_af6

    const/16 v12, 0xd4

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Landroid/net/VpnService$Builder;->addDnsServer(Ljava/lang/String;)Landroid/net/VpnService$Builder;

    const/4 v12, -0x3

    new-instance v17, Ljava/lang/StringBuilder;

    nop

    const/4 v12, -0x4

    move-object/from16 v0, v17

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v18, "<b>1º DNS</b>: "

    const/4 v12, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v12, 0xf6

    iget-object v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->r:Ljava/lang/String;

    move-object/16 v18, v12

    if-eqz v18, :cond_aef

    const/4 v12, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, -0x2

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v17

    const/4 v12, -0x8

    move-object/from16 v0, v17

    invoke-static {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    const/4 v12, -0x3

    new-instance v17, Ljava/lang/StringBuilder;

    nop

    const/4 v12, -0x4

    move-object/from16 v0, v17

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v18, "<b>2º DNS</b>: "

    const/4 v12, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v12, 0xd6

    iget-object v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->s:Ljava/lang/String;

    move-object/16 v18, v12

    if-eqz v18, :cond_ae8

    const/4 v12, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, -0x2

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v17

    const/4 v12, -0x8

    move-object/from16 v0, v17

    invoke-static {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    :cond_ae5
    const/16 v17, 0x0

    goto :goto_b04

    :cond_ae8
    const/4 v12, 0x5

    move-object/from16 v0, v49

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v33

    :cond_aef
    const/4 v12, 0x5

    move-object/from16 v0, v50

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v33

    :cond_af6
    const/4 v12, 0x5

    move-object/from16 v0, v49

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v33

    :cond_afd
    const/4 v12, 0x5

    move-object/from16 v0, v50

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v33

    :goto_b04
    const/16 v12, 0x404

    move-object/from16 v0, v16

    move/from16 v1, v17

    invoke-static {v0, v1}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->c(Landroid/net/VpnService$Builder;Z)V

    const/16 v12, 0x1fc

    sget v18, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 v19, 0x1d

    move/from16 v0, v18

    move/from16 v1, v19

    if-lt v0, v1, :cond_b23

    const/16 v12, 0x284

    move-object/from16 v0, v16

    move/from16 v1, v17

    invoke-virtual {v0, v1}, Landroid/net/VpnService$Builder;->setMetered(Z)Landroid/net/VpnService$Builder;

    :cond_b23
    const/4 v12, -0x3

    new-instance v17, Ljava/lang/StringBuilder;

    nop

    const/4 v12, -0x4

    move-object/from16 v0, v17

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v26

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v18, 0x7f130055

    const/4 v12, 0x7

    move/from16 v0, v18

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v18

    const/4 v12, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v25

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v12, 0x2e8

    sget v18, Lhl1;->a:I

    nop

    move/from16 v0, v18

    div-int/lit16 v0, v0, 0x400

    move/from16 v18, v0

    const/16 v12, 0x33

    move-object/from16 v0, v17

    move/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-object/from16 v18, v60

    const/4 v12, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, -0x2

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v17

    const/4 v12, -0x8

    move-object/from16 v0, v17

    invoke-static {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    const/16 v12, 0x75

    move-object/from16 v0, v28

    iget-boolean v12, v0, Lou;->w:Z

    move/16 v17, v12

    if-eqz v17, :cond_c02

    const/16 v12, 0x1b9

    move-object/from16 v0, v28

    iget-boolean v12, v0, Lou;->x:Z

    move/16 v17, v12

    if-eqz v17, :cond_c02

    const/4 v12, -0x3

    new-instance v17, Ljava/lang/StringBuilder;

    nop

    const/4 v12, -0x4

    move-object/from16 v0, v17

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v18, "<b>\ud83d\udeab "

    const/4 v12, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v18, 0x7f13025e

    const/4 v12, 0x7

    move/from16 v0, v18

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v18

    const/4 v12, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v18, v58

    const/4 v12, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, -0x2

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v17

    const/4 v12, -0x8

    move-object/from16 v0, v17

    invoke-static {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    const/16 v12, 0x195

    sget-boolean v17, Lmi2;->d:Z

    nop

    if-eqz v17, :cond_c02

    const/16 v12, 0x175

    new-instance v17, Lfm2;

    nop

    const/16 v18, 0x0

    const/16 v12, 0x16f

    move-object/from16 v0, v17

    move/from16 v1, v18

    invoke-direct {v0, v15, v1}, Lfm2;-><init>(Lcom/tlsvpn/tlstunnel/services/VpnConnection;I)V

    const/16 v12, 0xde

    sget-boolean v18, Lg4;->j:Z

    nop

    if-nez v18, :cond_bf4

    const/16 v12, 0x197

    move-object/from16 v0, v17

    invoke-virtual {v0}, Lfm2;->invoke()Ljava/lang/Object;

    goto :goto_c02

    :cond_bf4
    const/16 v12, 0x154

    sget-object v18, Lg4;->m:Ljava/util/ArrayList;

    nop

    const/16 v12, 0x174

    move-object/from16 v0, v18

    move-object/from16 v1, v17

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_c02
    :goto_c02
    const/4 v12, -0x3

    new-instance v17, Ljava/lang/StringBuilder;

    nop

    const/4 v12, -0x4

    move-object/from16 v0, v17

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v26

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v18, 0x7f130241

    const/4 v12, 0x7

    move/from16 v0, v18

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v18

    const/4 v12, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v25

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v24

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, -0x2

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v17

    const/4 v12, -0x8

    move-object/from16 v0, v17

    invoke-static {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    const/16 v12, 0x1c

    iget-boolean v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    move/16 v17, v12

    if-nez v17, :cond_c4e

    goto/16 :goto_147

    :cond_c4e
    const/16 v12, 0x2c4

    move-object/from16 v0, v16

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->d(Landroid/net/VpnService$Builder;)V

    const/16 v12, 0x3a4

    move-object/from16 v0, v16

    invoke-virtual {v0}, Landroid/net/VpnService$Builder;->establish()Landroid/os/ParcelFileDescriptor;

    move-result-object v16

    const/16 v12, 0x3c2

    move-object/from16 v0, v27

    move-object/from16 v1, v16

    iput-object v1, v0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->i:Landroid/os/ParcelFileDescriptor;
    :try_end_c65
    .catch Ljava/lang/Exception; {:try_start_7f0 .. :try_end_c65} :catch_d2
    .catchall {:try_start_7f0 .. :try_end_c65} :catchall_cc

    if-eqz v16, :cond_fb8

    :try_start_c67
    const/16 v12, 0x358

    move-object/from16 v0, v27

    iget-object v12, v0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->j:Landroid/os/ParcelFileDescriptor;

    move-object/16 v16, v12

    const/4 v12, -0x6

    move-object/from16 v0, v16

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v12, 0x18b

    move-object/from16 v0, v16

    invoke-virtual {v0}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_c7d
    .catch Ljava/lang/Exception; {:try_start_c67 .. :try_end_c7d} :catch_c7d
    .catchall {:try_start_c67 .. :try_end_c7d} :catchall_cc

    :catch_c7d
    :try_start_c7d
    const/16 v12, 0x24e

    new-instance v16, Ljava/io/File;

    nop

    const/4 v12, -0x3

    new-instance v17, Ljava/lang/StringBuilder;

    nop

    const/4 v12, -0x4

    move-object/from16 v0, v17

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v12, 0x1c3

    move-object/from16 v0, v27

    invoke-virtual {v0}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v18

    const/16 v12, 0x125

    move-object/from16 v0, v18

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v18

    const/4 v12, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v18, "/pdnsd.cache"

    const/4 v12, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, -0x2

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v17

    const/16 v12, 0x212

    move-object/from16 v0, v16

    move-object/from16 v1, v17

    invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/16 v12, 0xca

    move-object/from16 v0, v16

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v17

    if-nez v17, :cond_cd0

    const/16 v12, 0x288

    move-object/from16 v0, v16

    invoke-virtual {v0}, Ljava/io/File;->createNewFile()Z

    :cond_cd0
    const/16 v12, 0x24e

    new-instance v16, Ljava/io/File;

    nop

    const/4 v12, -0x3

    new-instance v17, Ljava/lang/StringBuilder;

    nop

    const/4 v12, -0x4

    move-object/from16 v0, v17

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v12, 0x1c3

    move-object/from16 v0, v27

    invoke-virtual {v0}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v18

    const/16 v12, 0x125

    move-object/from16 v0, v18

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v18

    const/4 v12, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v18, "/pdnsd.conf"

    const/4 v12, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, -0x2

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v17

    const/16 v12, 0x212

    move-object/from16 v0, v16

    move-object/from16 v1, v17

    invoke-direct {v0, v1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/16 v12, 0xca

    move-object/from16 v0, v16

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v17

    if-eqz v17, :cond_d23

    const/16 v12, 0x460

    move-object/from16 v0, v16

    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    :cond_d23
    const/16 v12, 0x288

    move-object/from16 v0, v16

    invoke-virtual {v0}, Ljava/io/File;->createNewFile()Z

    const/4 v12, -0x3

    new-instance v17, Ljava/lang/StringBuilder;

    nop

    const/4 v12, -0x4

    move-object/from16 v0, v17

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v18, "\tglobal {\n\t\tperm_cache = 8192;\n\t\tserver_ip = "

    const/4 v12, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v24

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v18, ";\n\t\tserver_port = "

    const/4 v12, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v12, 0x33

    move-object/from16 v0, v17

    move/from16 v1, v22

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v18, ";\n\t\tparanoid = off;\n\t\ttcp_server = off;\n\t\tquery_method = tcp_only;\n\t\tmin_ttl = 1800;\n\t\tmax_ttl = 86400;\n\t\ttimeout = 5;\n\t\tpar_queries = 2;\n\t\tcache_dir = \""

    const/4 v12, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v12, 0x1c3

    move-object/from16 v0, v27

    invoke-virtual {v0}, Landroid/content/Context;->getFilesDir()Ljava/io/File;

    move-result-object v18

    const/16 v12, 0x125

    move-object/from16 v0, v18

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v18

    const/4 v12, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v18, "/\";\n\t\tdaemon = on;\n\t\tdebug = off;\n\t\tverbosity = 0;\n\t}\n\tserver {\n\t\tvpnip4 = "

    const/4 v12, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v12, 0xf6

    iget-object v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->r:Ljava/lang/String;

    move-object/16 v18, v12

    if-eqz v18, :cond_fb1

    const/4 v12, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v18, 0x2c

    const/16 v12, 0x1b

    move-object/from16 v0, v17

    move/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v12, 0xd6

    iget-object v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->s:Ljava/lang/String;

    move-object/16 v18, v12

    if-eqz v18, :cond_faa

    const/4 v12, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v18, ";\n\t\tport = 53;\n\t\tuptest = none;\n\t\tcaching = on;\n\t\tpurge_cache = off;\n\t}"

    const/4 v12, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, -0x2

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v17

    const/16 v12, 0x2e4

    sget-object v18, Lip;->a:Ljava/nio/charset/Charset;

    nop

    const/16 v12, 0x2c

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v17

    const/4 v12, -0x6

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v12, 0x1170

    move-object/from16 v0, v16

    move-object/from16 v1, v17

    invoke-static {v0, v1}, Lwd0;->j0(Ljava/io/File;[B)V

    const/16 v12, 0x1c

    iget-boolean v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    move/16 v17, v12

    if-nez v17, :cond_df1

    goto/16 :goto_147

    :cond_df1
    const/16 v12, 0x125

    move-object/from16 v0, v16

    invoke-virtual {v0}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object v16

    const/4 v12, -0x6

    move-object/from16 v0, v16

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v12, 0xbd0

    move-object/from16 v0, v16

    invoke-direct {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->B(Ljava/lang/String;)I

    move-result v16

    const/16 v12, 0xc95

    move/from16 v0, v16

    iput v0, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->E:I

    const/16 v12, 0x1c

    iget-boolean v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    move/16 v16, v12

    if-nez v16, :cond_e18

    goto/16 :goto_147

    :cond_e18
    const/16 v12, 0x2b5

    move-object/from16 v0, v27

    iget-object v12, v0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->i:Landroid/os/ParcelFileDescriptor;

    move-object/16 v16, v12

    const/4 v12, -0x6

    move-object/from16 v0, v16

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v12, 0xc8

    move-object/from16 v0, v16

    invoke-virtual {v0}, Landroid/os/ParcelFileDescriptor;->getFd()I

    move-result v16

    const/16 v12, 0xdb7

    iget-object v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->l:Ljava/lang/String;

    move-object/16 v18, v12

    const-string/jumbo v19, "255.255.255.0"

    const/4 v12, -0x3

    new-instance v17, Ljava/lang/StringBuilder;

    nop

    const/4 v12, -0x4

    move-object/from16 v0, v17

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v12, 0x33

    move-object/from16 v0, v17

    move/from16 v1, v23

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, -0x2

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v20

    const/4 v12, -0x3

    new-instance v17, Ljava/lang/StringBuilder;

    nop

    const/4 v12, -0x4

    move-object/from16 v0, v17

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v12, 0x610

    iget v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->q:I

    move/16 v21, v12

    const/16 v12, 0x33

    move-object/from16 v0, v17

    move/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, -0x2

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v21

    const/4 v12, -0x3

    new-instance v17, Ljava/lang/StringBuilder;

    nop

    const/4 v12, -0x4

    move-object/from16 v0, v17

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x0

    move-object/from16 v0, v17

    move-object/from16 v1, v24

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v12, 0x1b

    move-object/from16 v0, v17

    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v12, 0x33

    move-object/from16 v0, v17

    move/from16 v1, v22

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, -0x2

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v22

    const/16 v17, 0x5dc

    const/16 v12, 0xa40

    move v0, v12

    move-object v1, v15

    move/from16 v2, v16

    move/from16 v3, v17

    move-object/from16 v4, v18

    move-object/from16 v5, v19

    move-object/from16 v6, v20

    move-object/from16 v7, v21

    move-object/from16 v8, v22

    invoke-direct/range {v1 .. v8}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->y(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v14

    const/16 v12, 0xe21

    iput v14, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->F:I

    const/16 v12, 0x1c

    iget-boolean v14, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    nop

    if-nez v14, :cond_ed2

    goto/16 :goto_147

    :cond_ed2
    const/16 v12, 0x20c

    move-object/from16 v0, v28

    invoke-virtual {v0}, Lou;->a()V

    move-object/from16 v21, v57

    move-object/from16 v22, v67

    const/16 v17, 0x0

    const/16 v12, 0x77

    move-object/from16 v0, v22

    move-object/from16 v1, v21

    move/from16 v2, v17

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v14

    if-nez v14, :cond_f29

    const/16 v12, 0xde

    sget-boolean v14, Lg4;->j:Z

    nop

    if-nez v14, :cond_f29

    const/16 v12, 0x5b

    new-instance v14, Landroid/content/Intent;

    nop

    move-object/from16 v23, v56

    const/16 v12, 0x62

    move-object/from16 v0, v23

    invoke-direct {v14, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v12, 0x53

    move-object/from16 v0, v27

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v16

    const/16 v12, 0x4a

    move-object/from16 v0, v16

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v16

    const/16 v12, 0x64

    move-object/from16 v0, v16

    invoke-virtual {v14, v0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v14

    const/16 v12, 0x59

    move/from16 v0, v29

    invoke-virtual {v14, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v14

    const/16 v12, 0x63

    move-object/from16 v0, v27

    invoke-virtual {v0, v14}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    :cond_f29
    move-object/from16 v24, v66

    const/16 v18, 0x1

    const/16 v12, 0x77

    move-object/from16 v0, v22

    move-object/from16 v1, v24

    move/from16 v2, v18

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v14

    if-eqz v14, :cond_f88

    const/16 v12, 0x7a

    move-object/from16 v0, v22

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v14

    const/16 v17, 0x0

    const/16 v12, 0x48

    move-object/from16 v0, v24

    move/from16 v1, v17

    invoke-interface {v14, v0, v1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/16 v12, 0x6f

    invoke-interface {v14}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/16 v12, 0x5b

    new-instance v14, Landroid/content/Intent;

    nop

    move-object/from16 v18, v55

    const/16 v12, 0x62

    move-object/from16 v0, v18

    invoke-direct {v14, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v12, 0x53

    move-object/from16 v0, v27

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v16

    const/16 v12, 0x4a

    move-object/from16 v0, v16

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v16

    const/16 v12, 0x64

    move-object/from16 v0, v16

    invoke-virtual {v14, v0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v14

    const/16 v12, 0x59

    move/from16 v0, v29

    invoke-virtual {v14, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v14

    const/16 v12, 0x63

    move-object/from16 v0, v27

    invoke-virtual {v0, v14}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    :cond_f88
    const/16 v12, 0x316

    invoke-virtual {v15}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->e()V

    const/16 v12, 0x1c

    iget-boolean v14, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    nop

    if-eqz v14, :cond_1026

    const/16 v12, 0x101f

    iget-object v14, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->A:Ljava/lang/Thread;

    nop

    if-eqz v14, :cond_fa2

    const/16 v12, 0x911

    invoke-virtual {v14}, Ljava/lang/Thread;->join()V

    goto/16 :goto_1026

    :cond_fa2
    const-string/jumbo v14, "lServerJob"

    const/4 v12, 0x5

    invoke-static {v14}, Lgt0;->F0(Ljava/lang/String;)V

    throw v33

    :cond_faa
    const/4 v12, 0x5

    move-object/from16 v0, v49

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v33

    :cond_fb1
    const/4 v12, 0x5

    move-object/from16 v0, v50

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v33

    :cond_fb8
    const/16 v12, 0x4bb

    new-instance v14, Ljava/lang/IllegalStateException;

    nop

    move-object/from16 v18, v54

    const/16 v12, 0x49e

    move-object/from16 v0, v18

    invoke-direct {v14, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    check-cast v14, Ljava/lang/Throwable;

    throw v14

    :cond_fc9
    const/16 v33, 0x0

    const-string/jumbo v14, "notGifConectando"

    const/4 v12, 0x5

    invoke-static {v14}, Lgt0;->F0(Ljava/lang/String;)V

    throw v33

    :cond_fd3
    const/16 v33, 0x0

    const/4 v12, 0x5

    move-object/from16 v0, v16

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v33

    :cond_fdc
    move/from16 v18, v20

    const/16 v12, 0x20c

    move-object/from16 v0, v28

    invoke-virtual {v0}, Lou;->a()V

    const v14, 0x7f130037

    const/4 v12, 0x7

    invoke-virtual {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v14

    const/4 v12, -0x8

    invoke-static {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    const/16 v12, 0x1c

    iget-boolean v14, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    nop

    if-nez v14, :cond_ffa

    goto/16 :goto_147

    :cond_ffa
    const/16 v12, 0x195

    sget-boolean v14, Lmi2;->d:Z

    nop

    if-eqz v14, :cond_1026

    const/16 v12, 0x175

    new-instance v14, Lfm2;

    nop

    const/16 v12, 0x16f

    move/from16 v0, v18

    invoke-direct {v14, v15, v0}, Lfm2;-><init>(Lcom/tlsvpn/tlstunnel/services/VpnConnection;I)V

    const/16 v12, 0xde

    sget-boolean v16, Lg4;->j:Z

    nop

    if-nez v16, :cond_101a

    const/16 v12, 0x197

    invoke-virtual {v14}, Lfm2;->invoke()Ljava/lang/Object;

    goto :goto_1026

    :cond_101a
    const/16 v12, 0x154

    sget-object v16, Lg4;->m:Ljava/util/ArrayList;

    nop

    const/16 v12, 0x174

    move-object/from16 v0, v16

    invoke-virtual {v0, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1026
    :goto_1026
    const v17, 0x7f13009d

    goto/16 :goto_1e99

    :cond_102b
    const/16 v33, 0x0

    const/4 v12, 0x5

    move-object/from16 v0, v16

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v33

    :cond_1034
    const/16 v33, 0x0

    const/4 v12, 0x5

    move-object/from16 v0, v16

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v33

    :catchall_103d
    move-exception v14

    move-object/from16 v15, v19

    goto/16 :goto_cd

    :catch_1042
    move-exception v14

    move-object/from16 v15, v19

    goto/16 :goto_1f05

    :cond_1047
    const/16 v33, 0x0

    const/4 v12, 0x5

    move-object/from16 v0, v48

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v33

    :cond_1050
    const/16 v33, 0x0

    const/4 v12, 0x5

    move-object/from16 v0, v48

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v33
    :try_end_1059
    .catch Ljava/lang/Exception; {:try_start_c7d .. :try_end_1059} :catch_d2
    .catchall {:try_start_c7d .. :try_end_1059} :catchall_cc

    :cond_1059
    move/from16 v29, v36

    move-object/from16 v69, v37

    move-object/from16 v70, v38

    move-object/from16 v23, v39

    move-object/from16 v21, v41

    move-object/from16 v71, v42

    move-object/from16 v72, v43

    move-object/from16 v73, v44

    move-object/from16 v74, v45

    move-object/from16 v75, v46

    move-object/from16 v24, v47

    move-object/from16 v22, v52

    const/16 v18, 0x0

    const/16 v20, 0x1

    move/from16 v0, v29

    move/from16 v1, v20

    if-ne v0, v1, :cond_11f6

    :try_start_107b
    const/16 v12, 0x7f

    move-object/from16 v0, v28

    iget-boolean v12, v0, Lou;->p:Z

    move/16 v29, v12

    if-eqz v29, :cond_11f6

    const/16 v12, 0x3f5

    move-object/from16 v0, v28

    iget-boolean v12, v0, Lou;->t:Z

    move/16 v29, v12

    if-eqz v29, :cond_11f6

    const/16 v12, 0x1e1

    move-object/from16 v0, v28

    iget-object v12, v0, Lou;->u:Ljava/lang/String;

    move-object/16 v29, v12

    const/16 v12, 0x47

    move-object/from16 v0, v29

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v29

    if-lez v29, :cond_11f6

    const/16 v12, 0x1f4

    move-object/from16 v0, v28

    iget-object v12, v0, Lou;->v:Ljava/lang/String;

    move-object/16 v29, v12

    const/16 v12, 0x47

    move-object/from16 v0, v29

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v29

    if-lez v29, :cond_11f6

    const/16 v12, 0x35e

    new-instance v29, Ljava/net/ServerSocket;

    nop

    move-object/from16 v33, v18

    const/16 v12, 0x4c5

    invoke-static {}, Ljava/net/InetAddress;->getLocalHost()Ljava/net/InetAddress;

    move-result-object v18

    move-object/from16 v47, v24

    const/16 v24, 0x0

    const/16 v12, 0x2a3

    move-object/from16 v0, v29

    move/from16 v1, v24

    move/from16 v2, v20

    move-object/from16 v3, v18

    invoke-direct {v0, v1, v2, v3}, Ljava/net/ServerSocket;-><init>(IILjava/net/InetAddress;)V

    const/16 v12, 0x29f

    move-object/from16 v0, v29

    iput-object v0, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->z:Ljava/net/ServerSocket;
    :try_end_10db
    .catch Ljava/lang/Exception; {:try_start_107b .. :try_end_10db} :catch_42d
    .catchall {:try_start_107b .. :try_end_10db} :catchall_cc

    :try_start_10db
    const/16 v12, 0x3fa

    new-instance v18, Ljava/lang/Thread;

    nop

    const/16 v12, 0xc64

    new-instance v24, Lgm2;

    nop

    const/16 v12, 0xbee

    move-object/from16 v0, v24

    move-wide/from16 v1, v16

    invoke-direct {v0, v15, v1, v2}, Lgm2;-><init>(Lcom/tlsvpn/tlstunnel/services/VpnConnection;J)V

    const/16 v12, 0x4cc

    move-object/from16 v0, v18

    move-object/from16 v1, v24

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    const/16 v12, 0x328

    move-object/from16 v0, v18

    iput-object v0, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->A:Ljava/lang/Thread;

    const/16 v12, 0x41b

    move-object/from16 v0, v18

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    const/16 v12, 0x162

    new-instance v16, Ljava/net/InetSocketAddress;

    nop

    const/16 v12, 0x152

    iget-object v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->z:Ljava/net/ServerSocket;

    move-object/16 v17, v12

    if-eqz v17, :cond_11ef

    const/16 v12, 0x531

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/net/ServerSocket;->getInetAddress()Ljava/net/InetAddress;

    move-result-object v17

    const/16 v12, 0x21f

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/net/InetAddress;->getHostAddress()Ljava/lang/String;

    move-result-object v17

    const/16 v12, 0x152

    iget-object v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->z:Ljava/net/ServerSocket;

    move-object/16 v18, v12

    if-eqz v18, :cond_11e8

    const/16 v12, 0x4c8

    move-object/from16 v0, v18

    invoke-virtual {v0}, Ljava/net/ServerSocket;->getLocalPort()I

    move-result v18

    const/16 v12, 0x17c

    move-object/from16 v0, v16

    move-object/from16 v1, v17

    move/from16 v2, v18

    invoke-direct {v0, v1, v2}, Ljava/net/InetSocketAddress;-><init>(Ljava/lang/String;I)V

    move-object/from16 v17, v32

    const/16 v12, 0xc07

    move-object/from16 v0, v17

    move-object/from16 v1, v16

    invoke-virtual {v0, v1}, Ljava/net/Socket;->connect(Ljava/net/SocketAddress;)V

    const/16 v12, 0x44c

    move-object/from16 v0, v17

    move/from16 v1, v20

    invoke-virtual {v0, v1}, Ljava/net/Socket;->setTcpNoDelay(Z)V

    const/16 v12, 0x4b2

    move-object/from16 v0, v17

    move/from16 v1, v20

    invoke-virtual {v0, v1}, Ljava/net/Socket;->setKeepAlive(Z)V

    const/16 v12, 0x2e0

    move-object/from16 v0, v17

    invoke-static {v0}, Landroid/os/ParcelFileDescriptor;->fromSocket(Ljava/net/Socket;)Landroid/os/ParcelFileDescriptor;

    move-result-object v16

    const/16 v12, 0x398

    move-object/from16 v0, v16

    invoke-virtual {v0}, Landroid/os/ParcelFileDescriptor;->detachFd()I

    move-result v16

    const/16 v12, 0x501

    move/from16 v0, v16

    iput v0, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->w:I

    const/16 v12, 0x1c

    iget-boolean v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    move/16 v17, v12

    if-nez v17, :cond_117c

    goto/16 :goto_147

    :cond_117c
    const v17, 0x7f13009d

    move/from16 v0, v16

    move/from16 v1, v20

    if-ge v0, v1, :cond_118d

    const/4 v12, -0x8

    move-object/from16 v0, v19

    invoke-static {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    goto/16 :goto_14a

    :cond_118d
    const v16, 0x7f1300d2

    const/4 v12, 0x7

    move/from16 v0, v16

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v16

    const/4 v12, -0x8

    move-object/from16 v0, v16

    invoke-static {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    const/16 v12, 0x5a

    sget-object v16, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->a:Lcom/tlsvpn/tlstunnel/utils/SocketOps;

    nop

    const/16 v12, 0x34f

    iget v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->w:I

    move/16 v17, v12

    const/16 v12, 0x3b

    move-object/from16 v0, v28

    iget-object v12, v0, Lou;->i:Ljava/lang/String;

    move-object/16 v18, v12

    const/16 v12, 0x206

    move-object/from16 v0, v16

    move/from16 v1, v17

    move-object/from16 v2, v18

    move/from16 v3, v20

    invoke-virtual {v0, v1, v2, v3}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->g(ILjava/lang/String;Z)J

    move-result-wide v16
    :try_end_11c0
    .catch Ljava/lang/Exception; {:try_start_10db .. :try_end_11c0} :catch_d2
    .catchall {:try_start_10db .. :try_end_11c0} :catchall_cc

    cmp-long v18, v16, v30

    if-nez v18, :cond_11d7

    const v18, 0x7f130067

    :try_start_11c7
    const/4 v12, 0x7

    move/from16 v0, v18

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v14

    const/4 v12, -0x8

    invoke-static {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    const v17, 0x7f13009d

    goto/16 :goto_14a

    :cond_11d7
    const v18, 0x7f13025b

    const/4 v12, 0x7

    move/from16 v0, v18

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v18

    const/4 v12, -0x8

    move-object/from16 v0, v18

    invoke-static {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V
    :try_end_11e7
    .catch Ljava/lang/Exception; {:try_start_11c7 .. :try_end_11e7} :catch_42d
    .catchall {:try_start_11c7 .. :try_end_11e7} :catchall_cc

    goto :goto_1207

    :cond_11e8
    :try_start_11e8
    const/4 v12, 0x5

    move-object/from16 v0, v48

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v33

    :cond_11ef
    const/4 v12, 0x5

    move-object/from16 v0, v48

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v33
    :try_end_11f6
    .catch Ljava/lang/Exception; {:try_start_11e8 .. :try_end_11f6} :catch_d2
    .catchall {:try_start_11e8 .. :try_end_11f6} :catchall_cc

    :cond_11f6
    move-object/from16 v33, v18

    move-object/from16 v47, v24

    :try_start_11fa
    const/16 v12, 0xab

    iget v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->v:I

    move/16 v18, v12

    const/16 v12, 0x501

    move/from16 v0, v18

    iput v0, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->w:I
    :try_end_1207
    .catch Ljava/lang/Exception; {:try_start_11fa .. :try_end_1207} :catch_42d
    .catchall {:try_start_11fa .. :try_end_1207} :catchall_cc

    :goto_1207
    :try_start_1207
    const/16 v12, 0x1c

    iget-boolean v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    move/16 v18, v12

    if-nez v18, :cond_1212

    goto/16 :goto_4ef

    :cond_1212
    const v18, 0x7f130036

    const/4 v12, 0x7

    move/from16 v0, v18

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v19

    const/4 v12, -0x8

    move-object/from16 v0, v19

    invoke-static {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    const/4 v12, 0x7

    move/from16 v0, v18

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v18

    const/16 v12, 0x157

    move-object/from16 v0, v18

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->k(Ljava/lang/String;)V

    const/16 v12, 0x5a

    sget-object v18, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->a:Lcom/tlsvpn/tlstunnel/utils/SocketOps;

    nop

    const/16 v12, 0x391

    move-object/from16 v0, v18

    move-wide/from16 v1, v16

    invoke-virtual {v0, v1, v2}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->eA(J)Z

    move-result v19
    :try_end_123f
    .catch Ljava/lang/Exception; {:try_start_1207 .. :try_end_123f} :catch_1ec1
    .catchall {:try_start_1207 .. :try_end_123f} :catchall_cc

    if-nez v19, :cond_125e

    const v14, 0x7f130105

    :try_start_1244
    const/4 v12, 0x7

    invoke-virtual {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v14

    const/4 v12, -0x8

    invoke-static {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    const v14, 0x7f130106

    const/4 v12, 0x7

    invoke-virtual {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v14

    const/4 v12, -0x8

    invoke-static {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V
    :try_end_1259
    .catch Ljava/lang/Exception; {:try_start_1244 .. :try_end_1259} :catch_42d
    .catchall {:try_start_1244 .. :try_end_1259} :catchall_cc

    const v29, 0x7f13009d

    goto/16 :goto_4f2

    :cond_125e
    :try_start_125e
    const/16 v12, 0x1c

    iget-boolean v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    move/16 v19, v12

    if-nez v19, :cond_1269

    goto/16 :goto_4ef

    :cond_1269
    const/4 v12, -0x3

    new-instance v19, Ljava/lang/StringBuilder;

    nop

    const/4 v12, -0x4

    move-object/from16 v0, v19

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v24, "TLSVPN:498:"

    const/4 v12, 0x0

    move-object/from16 v0, v19

    move-object/from16 v1, v24

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v12, 0x1d2

    move-object/from16 v0, v27

    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v24

    const-string/jumbo v29, "android_id"

    const/16 v12, 0x249

    move-object/from16 v0, v24

    move-object/from16 v1, v29

    invoke-static {v0, v1}, Landroid/provider/Settings$Secure;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v24

    const/4 v12, 0x0

    move-object/from16 v0, v19

    move-object/from16 v1, v24

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v24, 0x3a

    const/16 v12, 0x1b

    move-object/from16 v0, v19

    move/from16 v1, v24

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const v29, 0x7f130024

    const/4 v12, 0x7

    move/from16 v0, v29

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v20

    const/4 v12, 0x0

    move-object/from16 v0, v19

    move-object/from16 v1, v20

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v12, 0x1b

    move-object/from16 v0, v19

    move/from16 v1, v24

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v12, 0x53

    move-object/from16 v0, v27

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v20

    const/16 v12, 0x4a

    move-object/from16 v0, v20

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v20

    const/4 v12, 0x0

    move-object/from16 v0, v19

    move-object/from16 v1, v20

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v20, ".3dUcP:true:"

    const/4 v12, 0x0

    move-object/from16 v0, v19

    move-object/from16 v1, v20

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v12, 0x11d

    iget-boolean v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->n:Z

    move/16 v20, v12

    const/16 v12, 0x6a

    move-object/from16 v0, v19

    move/from16 v1, v20

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string/jumbo v20, ":CHECKSUMAQUI:STRRAND::::"

    const/4 v12, 0x0

    move-object/from16 v0, v19

    move-object/from16 v1, v20

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, -0x2

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v19

    const/16 v12, 0xab0

    move-object/from16 v0, v19

    invoke-static {v0}, Lmi2;->g(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v19

    const/16 v12, 0x49c

    move-object/from16 v0, v18

    move-wide/from16 v1, v16

    move-object/from16 v3, v19

    invoke-virtual {v0, v1, v2, v3}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->k(JLjava/lang/String;)Ljava/lang/String;

    move-result-object v18

    const/16 v20, 0x1

    move/from16 v0, v20

    new-array v0, v0, [C

    move-object/from16 v19, v0

    const/16 v34, 0x0

    const/16 v51, 0x3a

    aput-char v51, v19, v34

    const/16 v12, 0x31

    move-object/from16 v0, v18

    move-object/from16 v1, v19

    invoke-static {v0, v1}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v24

    const/16 v12, 0x1c

    iget-boolean v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    move/16 v18, v12

    if-eqz v18, :cond_134b

    const/16 v12, 0x17d

    move-object/from16 v0, v24

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v18

    const/16 v19, 0xe

    move/from16 v0, v18

    move/from16 v1, v19

    if-ge v0, v1, :cond_1352

    :cond_134b
    move-wide/from16 v58, v16

    const v17, 0x7f13009d

    goto/16 :goto_1efc

    :cond_1352
    const/16 v18, 0x0

    const/16 v12, 0x24

    move-object/from16 v0, v24

    move/from16 v1, v18

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v19

    const-string/jumbo v18, "AUTHOK"

    const/16 v12, 0x84

    move-object/from16 v0, v19

    move-object/from16 v1, v18

    invoke-static {v0, v1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v18
    :try_end_136b
    .catch Ljava/lang/Exception; {:try_start_125e .. :try_end_136b} :catch_1ec1
    .catchall {:try_start_125e .. :try_end_136b} :catchall_cc

    if-eqz v18, :cond_138c

    const/16 v18, 0x2

    :try_start_136f
    const/16 v12, 0x24

    move-object/from16 v0, v24

    move/from16 v1, v18

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v19

    check-cast v19, Ljava/lang/String;

    const/16 v12, 0x8e

    move-object/from16 v0, v19

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v18
    :try_end_1383
    .catch Ljava/lang/Exception; {:try_start_136f .. :try_end_1383} :catch_1384
    .catchall {:try_start_136f .. :try_end_1383} :catchall_cc

    goto :goto_1386

    :catch_1384
    const/16 v18, 0x0

    :goto_1386
    move/from16 v29, v18

    :goto_1388
    const v18, 0x7f130035

    goto :goto_13aa

    :cond_138c
    const/16 v18, 0x0

    :try_start_138e
    const/16 v12, 0x24

    move-object/from16 v0, v24

    move/from16 v1, v18

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v19

    const-string/jumbo v18, "EXPIRADO"

    const/16 v12, 0x84

    move-object/from16 v0, v19

    move-object/from16 v1, v18

    invoke-static {v0, v1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v18

    if-eqz v18, :cond_1ee1

    const/16 v29, 0x0

    goto :goto_1388

    :goto_13aa
    const/4 v12, 0x7

    move/from16 v0, v18

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v18

    const/4 v12, -0x8

    move-object/from16 v0, v18

    invoke-static {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    const/16 v20, 0x1

    const/16 v12, 0x24

    move-object/from16 v0, v24

    move/from16 v1, v20

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v18

    check-cast v18, Ljava/lang/String;

    const/16 v12, 0x7c

    move-object/from16 v0, v18

    invoke-static {v0}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v19

    if-nez v19, :cond_1ec6

    const/16 v12, 0x52b

    sget-object v19, Ldz;->a:Lcz;

    nop

    const/16 v12, 0x3b

    move-object/from16 v0, v28

    iget-object v12, v0, Lou;->i:Ljava/lang/String;

    move-object/16 v19, v12

    const/16 v20, 0x2

    const/16 v12, 0x196

    move/from16 v0, v20

    move-object/from16 v1, v19

    invoke-static {v0, v1}, Lc72;->G0(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v19

    const/16 v12, 0x1f7

    sget-object v20, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    nop

    const/16 v12, 0x3b0

    move-object/from16 v0, v19

    move-object/from16 v1, v20

    invoke-virtual {v0, v1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v19

    const/4 v12, -0x6

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v12, 0x334

    move-object/from16 v0, v19

    invoke-static {v0}, Ldz;->a(Ljava/lang/String;)Lcz;

    move-result-object v19
    :try_end_1406
    .catch Ljava/lang/Exception; {:try_start_138e .. :try_end_1406} :catch_1ec1
    .catchall {:try_start_138e .. :try_end_1406} :catchall_cc

    move-wide/from16 v58, v16

    :try_start_1408
    const/4 v12, -0x3

    new-instance v16, Ljava/lang/StringBuilder;

    nop

    const/4 v12, -0x4

    move-object/from16 v0, v16

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x0

    move-object/from16 v0, v16

    move-object/from16 v1, v26

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v12, 0x1e6

    move-object/from16 v0, v19

    iget-object v12, v0, Lcz;->c:Ljava/lang/String;

    move-object/16 v17, v12

    const/4 v12, 0x0

    move-object/from16 v0, v16

    move-object/from16 v1, v17

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v17, 0x20

    const/16 v12, 0x1b

    move-object/from16 v0, v16

    move/from16 v1, v17

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v12, 0x3b

    move-object/from16 v0, v28

    iget-object v12, v0, Lou;->i:Ljava/lang/String;

    move-object/16 v17, v12

    move-object/from16 v39, v23

    check-cast v14, Ljava/lang/String;

    filled-new-array {v14}, [Ljava/lang/String;

    move-result-object v23

    move-object/from16 v41, v21

    const/16 v21, 0x6

    const/16 v12, 0x89

    move-object/from16 v0, v17

    move-object/from16 v1, v23

    move/from16 v2, v21

    invoke-static {v0, v1, v2}, Lc72;->E0(Ljava/lang/CharSequence;[Ljava/lang/String;I)Ljava/util/List;

    move-result-object v17

    const/16 v21, 0x0

    const/16 v12, 0x24

    move-object/from16 v0, v17

    move/from16 v1, v21

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v17

    check-cast v17, Ljava/lang/String;

    const/16 v12, 0x12d

    move-object/from16 v0, v17

    move-object/from16 v1, v20

    invoke-virtual {v0, v1}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v17

    const/4 v12, -0x6

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v12, 0x0

    move-object/from16 v0, v16

    move-object/from16 v1, v17

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    move-object/from16 v0, v16

    move-object/from16 v1, v25

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v17, 0x7f130090

    const/4 v12, 0x7

    move/from16 v0, v17

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v17

    const/4 v12, 0x0

    move-object/from16 v0, v16

    move-object/from16 v1, v17

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, -0x2

    move-object/from16 v0, v16

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    const/4 v12, -0x8

    move-object/from16 v0, v16

    invoke-static {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    const/16 v16, 0xf

    move/from16 v0, v29

    move/from16 v1, v16

    if-gt v0, v1, :cond_14bb

    const/16 v12, 0x101

    sget-boolean v17, Lmi2;->n:Z

    nop

    if-nez v17, :cond_14bb

    const/16 v17, 0x1

    goto :goto_14bd

    :catch_14b6
    move-exception v14

    :goto_14b7
    move-wide/from16 v30, v58

    goto/16 :goto_1f05

    :cond_14bb
    const/16 v17, 0x0

    :goto_14bd
    const/16 v12, 0xd20

    move-object/from16 v0, v27

    move/from16 v1, v17

    iput-boolean v1, v0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->c:Z

    const/16 v12, 0x101

    sget-boolean v17, Lmi2;->n:Z

    nop

    if-eqz v17, :cond_14d7

    const v17, 0x7f130265

    const/4 v12, 0x7

    move/from16 v0, v17

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v17

    goto :goto_1543

    :cond_14d7
    rem-int/lit8 v17, v29, 0x3c

    const/16 v21, 0x1

    move/from16 v0, v21

    move/from16 v1, v17

    if-gt v0, v1, :cond_151c

    move/from16 v21, v35

    move/from16 v0, v17

    move/from16 v1, v21

    if-ge v0, v1, :cond_151c

    const/4 v12, -0x3

    new-instance v17, Ljava/lang/StringBuilder;

    nop

    const/4 v12, -0x4

    move-object/from16 v0, v17

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v21, 0x30

    const/16 v12, 0x1b

    move-object/from16 v0, v17

    move/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    rem-int/lit8 v21, v29, 0x3c

    const/16 v12, 0x33

    move-object/from16 v0, v17

    move/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 v21, 0x6d

    const/16 v12, 0x1b

    move-object/from16 v0, v17

    move/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v12, -0x2

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v17

    goto :goto_1543

    :cond_151c
    const/4 v12, -0x3

    new-instance v17, Ljava/lang/StringBuilder;

    nop

    const/4 v12, -0x4

    move-object/from16 v0, v17

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    rem-int/lit8 v21, v29, 0x3c

    const/16 v12, 0x33

    move-object/from16 v0, v17

    move/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 v21, 0x6d

    const/16 v12, 0x1b

    move-object/from16 v0, v17

    move/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v12, -0x2

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v17

    :goto_1543
    const/4 v12, -0x3

    new-instance v21, Ljava/lang/StringBuilder;

    nop

    const/4 v12, -0x4

    move-object/from16 v0, v21

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x0

    move-object/from16 v0, v21

    move-object/from16 v1, v26

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v12, 0x1e6

    move-object/from16 v0, v19

    iget-object v12, v0, Lcz;->c:Ljava/lang/String;

    move-object/16 v23, v12

    const/4 v12, 0x0

    move-object/from16 v0, v21

    move-object/from16 v1, v23

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v23, 0x20

    const/16 v12, 0x1b

    move-object/from16 v0, v21

    move/from16 v1, v23

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v12, 0x3b

    move-object/from16 v0, v28

    iget-object v12, v0, Lou;->i:Ljava/lang/String;

    move-object/16 v23, v12

    check-cast v14, Ljava/lang/String;

    filled-new-array {v14}, [Ljava/lang/String;

    move-result-object v16

    move-object/from16 v52, v22

    const/16 v22, 0x6

    const/16 v12, 0x89

    move-object/from16 v0, v23

    move-object/from16 v1, v16

    move/from16 v2, v22

    invoke-static {v0, v1, v2}, Lc72;->E0(Ljava/lang/CharSequence;[Ljava/lang/String;I)Ljava/util/List;

    move-result-object v16

    const/16 v22, 0x0

    const/16 v12, 0x24

    move-object/from16 v0, v16

    move/from16 v1, v22

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v16

    check-cast v16, Ljava/lang/String;

    const/16 v12, 0x12d

    move-object/from16 v0, v16

    move-object/from16 v1, v20

    invoke-virtual {v0, v1}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v16

    const/4 v12, -0x6

    move-object/from16 v0, v16

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v12, 0x0

    move-object/from16 v0, v21

    move-object/from16 v1, v16

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v16, "</b>: <b>"

    const/4 v12, 0x0

    move-object/from16 v0, v21

    move-object/from16 v1, v16

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v16, 0x7f130258

    const/4 v12, 0x7

    move/from16 v0, v16

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v16

    const/4 v12, 0x0

    move-object/from16 v0, v21

    move-object/from16 v1, v16

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v16, "</b> ~ "

    const/4 v12, 0x0

    move-object/from16 v0, v21

    move-object/from16 v1, v16

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    div-int/lit8 v16, v29, 0x3c

    if-lez v16, :cond_1618

    const/16 v12, 0x101

    sget-boolean v16, Lmi2;->n:Z

    nop

    if-nez v16, :cond_1618

    const/4 v12, -0x3

    new-instance v16, Ljava/lang/StringBuilder;

    nop

    const/4 v12, -0x4

    move-object/from16 v0, v16

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    div-int/lit8 v22, v29, 0x3c

    const/16 v12, 0x33

    move-object/from16 v0, v16

    move/from16 v1, v22

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v22, "h "

    const/4 v12, 0x0

    move-object/from16 v0, v16

    move-object/from16 v1, v22

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    move-object/from16 v0, v16

    move-object/from16 v1, v17

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, -0x2

    move-object/from16 v0, v16

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v17

    :cond_1618
    const/4 v12, 0x0

    move-object/from16 v0, v21

    move-object/from16 v1, v17

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, -0x2

    move-object/from16 v0, v21

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    const/4 v12, -0x8

    move-object/from16 v0, v16

    invoke-static {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    const/16 v21, 0x6

    const/16 v12, 0x24

    move-object/from16 v0, v24

    move/from16 v1, v21

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v16

    const-string/jumbo v17, "true"

    const/16 v12, 0x84

    move-object/from16 v0, v16

    move-object/from16 v1, v17

    invoke-static {v0, v1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v16

    const/16 v12, 0xa25

    move-object/from16 v0, v28

    move/from16 v1, v16

    iput-boolean v1, v0, Lou;->x:Z

    if-eqz v16, :cond_1710

    const/4 v12, -0x3

    new-instance v16, Ljava/lang/StringBuilder;

    nop

    const/4 v12, -0x4

    move-object/from16 v0, v16

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x0

    move-object/from16 v0, v16

    move-object/from16 v1, v26

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v12, 0x1e6

    move-object/from16 v0, v19

    iget-object v12, v0, Lcz;->c:Ljava/lang/String;

    move-object/16 v17, v12

    const/4 v12, 0x0

    move-object/from16 v0, v16

    move-object/from16 v1, v17

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v17, 0x20

    const/16 v12, 0x1b

    move-object/from16 v0, v16

    move/from16 v1, v17

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v12, 0x3b

    move-object/from16 v0, v28

    iget-object v12, v0, Lou;->i:Ljava/lang/String;

    move-object/16 v17, v12

    check-cast v14, Ljava/lang/String;

    filled-new-array {v14}, [Ljava/lang/String;

    move-result-object v14

    const/16 v21, 0x6

    const/16 v12, 0x89

    move-object/from16 v0, v17

    move/from16 v1, v21

    invoke-static {v0, v14, v1}, Lc72;->E0(Ljava/lang/CharSequence;[Ljava/lang/String;I)Ljava/util/List;

    move-result-object v14

    const/16 v17, 0x0

    const/16 v12, 0x24

    move/from16 v0, v17

    invoke-interface {v14, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/lang/String;

    const/16 v12, 0x12d

    move-object/from16 v0, v20

    invoke-virtual {v14, v0}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v14

    const/4 v12, -0x6

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v12, 0x0

    move-object/from16 v0, v16

    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v14, "</b>: <b>\ud83d\udeab "

    const/4 v12, 0x0

    move-object/from16 v0, v16

    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v14, 0x7f13025e

    const/4 v12, 0x7

    invoke-virtual {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v14

    const/4 v12, 0x0

    move-object/from16 v0, v16

    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v14, v71

    const/4 v12, 0x0

    move-object/from16 v0, v16

    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, -0x2

    move-object/from16 v0, v16

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v14

    const/4 v12, -0x8

    invoke-static {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    const/16 v12, 0x195

    sget-boolean v14, Lmi2;->d:Z

    nop

    if-eqz v14, :cond_1710

    const/16 v12, 0x175

    new-instance v14, Lfm2;

    nop

    const/16 v20, 0x2

    const/16 v12, 0x16f

    move/from16 v0, v20

    invoke-direct {v14, v15, v0}, Lfm2;-><init>(Lcom/tlsvpn/tlstunnel/services/VpnConnection;I)V

    const/16 v12, 0xde

    sget-boolean v16, Lg4;->j:Z

    nop

    if-nez v16, :cond_1703

    const/16 v12, 0x197

    invoke-virtual {v14}, Lfm2;->invoke()Ljava/lang/Object;

    goto :goto_1712

    :cond_1703
    const/16 v12, 0x154

    sget-object v16, Lg4;->m:Ljava/util/ArrayList;

    nop

    const/16 v12, 0x174

    move-object/from16 v0, v16

    invoke-virtual {v0, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_1712

    :cond_1710
    const/16 v20, 0x2

    :goto_1712
    const/16 v12, 0x299

    iget-boolean v14, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->m:Z

    nop

    if-eqz v14, :cond_1749

    const/4 v12, -0x3

    new-instance v14, Ljava/lang/StringBuilder;

    nop

    const/4 v12, -0x4

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x0

    move-object/from16 v0, v26

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v16, 0x7f130103

    const/4 v12, 0x7

    move/from16 v0, v16

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v16

    const/4 v12, 0x0

    move-object/from16 v0, v16

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v16, " ✔</b>"

    const/4 v12, 0x0

    move-object/from16 v0, v16

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, -0x2

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v14

    const/4 v12, -0x8

    invoke-static {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    :cond_1749
    const/16 v12, 0x11d

    iget-boolean v14, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->n:Z

    nop

    if-eqz v14, :cond_1769

    const/16 v14, 0xc

    const/16 v12, 0x24

    move-object/from16 v0, v24

    invoke-interface {v0, v14}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v14

    const-string/jumbo v16, "true"

    const/16 v12, 0x84

    move-object/from16 v0, v16

    invoke-static {v14, v0}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v14

    if-eqz v14, :cond_1769

    const/4 v14, 0x1

    goto :goto_176a

    :cond_1769
    const/4 v14, 0x0

    :goto_176a
    const/16 v12, 0x5a7

    iput-boolean v14, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->n:Z

    if-eqz v14, :cond_17a0

    const/4 v12, -0x3

    new-instance v14, Ljava/lang/StringBuilder;

    nop

    const/4 v12, -0x4

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x0

    move-object/from16 v0, v26

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v16, 0x7f13008a

    const/4 v12, 0x7

    move/from16 v0, v16

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v16

    const/4 v12, 0x0

    move-object/from16 v0, v16

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v16, " ✔</b>"

    const/4 v12, 0x0

    move-object/from16 v0, v16

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, -0x2

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v14

    const/4 v12, -0x8

    invoke-static {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    :cond_17a0
    const/4 v14, 0x7

    const/16 v12, 0x24

    move-object/from16 v0, v24

    invoke-interface {v0, v14}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v14

    move-object/from16 v21, v14

    check-cast v21, Ljava/lang/String;

    const/16 v12, 0x3dc

    new-instance v14, Landroid/net/VpnService$Builder;

    nop

    const/16 v12, 0x433

    move-object/from16 v0, v27

    invoke-direct {v14, v0}, Landroid/net/VpnService$Builder;-><init>(Landroid/net/VpnService;)V

    const v16, 0x7f130024

    const/4 v12, 0x7

    move/from16 v0, v16

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v16

    const/16 v12, 0x4f2

    move-object/from16 v0, v16

    invoke-virtual {v14, v0}, Landroid/net/VpnService$Builder;->setSession(Ljava/lang/String;)Landroid/net/VpnService$Builder;

    move-result-object v14

    const/16 v17, 0x20

    const/16 v12, 0x1d0

    move-object/from16 v0, v18

    move/from16 v1, v17

    invoke-virtual {v14, v0, v1}, Landroid/net/VpnService$Builder;->addAddress(Ljava/lang/String;I)Landroid/net/VpnService$Builder;

    move-result-object v14

    const/16 v17, 0x0

    const/16 v12, 0x283

    move/from16 v0, v17

    invoke-virtual {v14, v0}, Landroid/net/VpnService$Builder;->setBlocking(Z)Landroid/net/VpnService$Builder;

    move-result-object v14

    const/16 v16, 0x2328

    const/16 v12, 0x3c4

    move/from16 v0, v16

    invoke-virtual {v14, v0}, Landroid/net/VpnService$Builder;->setMtu(I)Landroid/net/VpnService$Builder;

    move-result-object v16

    const/4 v12, -0x6

    move-object/from16 v0, v16

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v14, 0xd

    const/16 v12, 0x24

    move-object/from16 v0, v24

    invoke-interface {v0, v14}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/lang/String;

    const-string/jumbo v17, "$"

    const-string/jumbo v19, ":"

    const/16 v12, 0xf8f

    move-object/from16 v0, v17

    move-object/from16 v1, v19

    invoke-static {v14, v0, v1}, Lk72;->i0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v17

    const/16 v12, 0x47

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v14
    :try_end_1815
    .catch Ljava/lang/Exception; {:try_start_1408 .. :try_end_1815} :catch_14b6
    .catchall {:try_start_1408 .. :try_end_1815} :catchall_cc

    if-lez v14, :cond_1855

    const/16 v14, 0x80

    :try_start_1819
    const/16 v12, 0x1d0

    move-object/from16 v0, v16

    move-object/from16 v1, v17

    invoke-virtual {v0, v1, v14}, Landroid/net/VpnService$Builder;->addAddress(Ljava/lang/String;I)Landroid/net/VpnService$Builder;

    move-result-object v14

    const/4 v12, -0x6

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_1827
    .catch Ljava/lang/Exception; {:try_start_1819 .. :try_end_1827} :catch_1828
    .catchall {:try_start_1819 .. :try_end_1827} :catchall_cc

    goto :goto_1855

    :catch_1828
    move-exception v14

    :try_start_1829
    const/4 v12, -0x3

    new-instance v19, Ljava/lang/StringBuilder;

    nop

    const/4 v12, -0x4

    move-object/from16 v0, v19

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v22, "<b>IPv6 Config Err</b>: "

    const/4 v12, 0x0

    move-object/from16 v0, v19

    move-object/from16 v1, v22

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v12, 0x1da

    invoke-virtual {v14}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v14

    const/4 v12, 0x0

    move-object/from16 v0, v19

    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, -0x2

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v14

    const/4 v12, -0x8

    invoke-static {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    :cond_1855
    :goto_1855
    const/16 v12, 0x4a5

    iget-boolean v14, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->o:Z

    nop

    if-eqz v14, :cond_1942

    const/16 v12, 0x118b

    iget-boolean v14, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->p:Z

    nop
    :try_end_1861
    .catch Ljava/lang/Exception; {:try_start_1829 .. :try_end_1861} :catch_14b6
    .catchall {:try_start_1829 .. :try_end_1861} :catchall_cc

    const-string/jumbo v19, "º DNS</b>: "

    if-eqz v14, :cond_189c

    :try_start_1866
    const/16 v12, 0xd4

    move-object/from16 v0, v16

    move-object/from16 v1, v21

    invoke-virtual {v0, v1}, Landroid/net/VpnService$Builder;->addDnsServer(Ljava/lang/String;)Landroid/net/VpnService$Builder;

    const/4 v12, -0x3

    new-instance v14, Ljava/lang/StringBuilder;

    nop

    const/4 v12, -0x4

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x0

    move-object/from16 v0, v26

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v22, 0x1

    const/16 v12, 0x33

    move/from16 v0, v22

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    move-object/from16 v0, v19

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    move-object/from16 v0, v21

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, -0x2

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v14

    const/4 v12, -0x8

    invoke-static {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    goto :goto_189e

    :cond_189c
    const/16 v20, 0x1

    :goto_189e
    const/16 v12, 0xf6

    iget-object v14, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->r:Ljava/lang/String;

    nop

    if-eqz v14, :cond_193b

    const/16 v12, 0xd4

    move-object/from16 v0, v16

    invoke-virtual {v0, v14}, Landroid/net/VpnService$Builder;->addDnsServer(Ljava/lang/String;)Landroid/net/VpnService$Builder;

    move-result-object v14

    const/16 v12, 0xd6

    iget-object v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->s:Ljava/lang/String;

    move-object/16 v22, v12

    if-eqz v22, :cond_1934

    const/16 v12, 0xd4

    move-object/from16 v0, v22

    invoke-virtual {v14, v0}, Landroid/net/VpnService$Builder;->addDnsServer(Ljava/lang/String;)Landroid/net/VpnService$Builder;

    const/4 v12, -0x3

    new-instance v14, Ljava/lang/StringBuilder;

    nop

    const/4 v12, -0x4

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x0

    move-object/from16 v0, v26

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    add-int/lit8 v22, v20, 0x1

    const/16 v12, 0x33

    move/from16 v0, v20

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    move-object/from16 v0, v19

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v12, 0xf6

    iget-object v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->r:Ljava/lang/String;

    move-object/16 v20, v12

    if-eqz v20, :cond_192d

    const/4 v12, 0x0

    move-object/from16 v0, v20

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, -0x2

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v14

    const/4 v12, -0x8

    invoke-static {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    const/4 v12, -0x3

    new-instance v14, Ljava/lang/StringBuilder;

    nop

    const/4 v12, -0x4

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x0

    move-object/from16 v0, v26

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v12, 0x33

    move/from16 v0, v22

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    move-object/from16 v0, v19

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v12, 0xd6

    iget-object v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->s:Ljava/lang/String;

    move-object/16 v19, v12

    if-eqz v19, :cond_1926

    const/4 v12, 0x0

    move-object/from16 v0, v19

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, -0x2

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v14

    const/4 v12, -0x8

    invoke-static {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    goto :goto_1942

    :cond_1926
    const/4 v12, 0x5

    move-object/from16 v0, v49

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v33

    :cond_192d
    const/4 v12, 0x5

    move-object/from16 v0, v50

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v33

    :cond_1934
    const/4 v12, 0x5

    move-object/from16 v0, v49

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v33

    :cond_193b
    const/4 v12, 0x5

    move-object/from16 v0, v50

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v33

    :cond_1942
    :goto_1942
    const/4 v12, -0x3

    new-instance v14, Ljava/lang/StringBuilder;

    nop

    const/4 v12, -0x4

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x0

    move-object/from16 v0, v26

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v19, 0x7f130055

    const/4 v12, 0x7

    move/from16 v0, v19

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v19

    const/4 v12, 0x0

    move-object/from16 v0, v19

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    move-object/from16 v0, v25

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v12, 0x2e8

    sget v19, Lhl1;->a:I

    nop

    move/from16 v0, v19

    div-int/lit16 v0, v0, 0x400

    move/from16 v19, v0

    const/16 v12, 0x33

    move/from16 v0, v19

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-object/from16 v19, v72

    const/4 v12, 0x0

    move-object/from16 v0, v19

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, -0x2

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v14

    const/4 v12, -0x8

    invoke-static {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    const/4 v12, -0x3

    new-instance v14, Ljava/lang/StringBuilder;

    nop

    const/4 v12, -0x4

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x0

    move-object/from16 v0, v26

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v19, 0x7f130241

    const/4 v12, 0x7

    move/from16 v0, v19

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v20

    const/4 v12, 0x0

    move-object/from16 v0, v20

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    move-object/from16 v0, v25

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    move-object/from16 v0, v18

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, -0x2

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v14

    const/4 v12, -0x8

    invoke-static {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    const/16 v12, 0x47

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v14

    if-lez v14, :cond_19f6

    const/4 v12, -0x3

    new-instance v14, Ljava/lang/StringBuilder;

    nop

    const/4 v12, -0x4

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x0

    move-object/from16 v0, v26

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    move/from16 v0, v19

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v19

    const/4 v12, 0x0

    move-object/from16 v0, v19

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    move-object/from16 v0, v25

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    move-object/from16 v0, v17

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, -0x2

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v14

    const/4 v12, -0x8

    invoke-static {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    :cond_19f6
    const/16 v12, 0x47

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v14

    if-lez v14, :cond_1a02

    const/4 v14, 0x1

    goto :goto_1a03

    :cond_1a02
    const/4 v14, 0x0

    :goto_1a03
    const/16 v12, 0x404

    move-object/from16 v0, v16

    invoke-static {v0, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->c(Landroid/net/VpnService$Builder;Z)V

    const/16 v12, 0x1fc

    sget v14, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 v19, 0x1d

    move/from16 v0, v19

    if-lt v14, v0, :cond_1a20

    const/16 v22, 0x0

    const/16 v12, 0x284

    move-object/from16 v0, v16

    move/from16 v1, v22

    invoke-virtual {v0, v1}, Landroid/net/VpnService$Builder;->setMetered(Z)Landroid/net/VpnService$Builder;

    :cond_1a20
    const/16 v12, 0x1c

    iget-boolean v14, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    nop
    :try_end_1a25
    .catch Ljava/lang/Exception; {:try_start_1866 .. :try_end_1a25} :catch_14b6
    .catchall {:try_start_1866 .. :try_end_1a25} :catchall_cc

    if-nez v14, :cond_1a36

    const v19, 0x7f13009d

    const/4 v12, 0x7

    move/from16 v0, v19

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v14

    :goto_1a31
    const/4 v12, -0x8

    invoke-static {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    return-wide v58

    :cond_1a36
    :try_start_1a36
    const/16 v12, 0x2c4

    move-object/from16 v0, v16

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->d(Landroid/net/VpnService$Builder;)V

    const/16 v12, 0x3a4

    move-object/from16 v0, v16

    invoke-virtual {v0}, Landroid/net/VpnService$Builder;->establish()Landroid/os/ParcelFileDescriptor;

    move-result-object v14

    const/16 v12, 0x3c2

    move-object/from16 v0, v27

    iput-object v14, v0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->i:Landroid/os/ParcelFileDescriptor;
    :try_end_1a4b
    .catch Ljava/lang/Exception; {:try_start_1a36 .. :try_end_1a4b} :catch_14b6
    .catchall {:try_start_1a36 .. :try_end_1a4b} :catchall_cc

    if-eqz v14, :cond_1eb0

    :try_start_1a4d
    const/16 v12, 0x358

    move-object/from16 v0, v27

    iget-object v14, v0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->j:Landroid/os/ParcelFileDescriptor;

    nop

    const/4 v12, -0x6

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v12, 0x18b

    invoke-virtual {v14}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_1a5d
    .catch Ljava/lang/Exception; {:try_start_1a4d .. :try_end_1a5d} :catch_1a5d
    .catchall {:try_start_1a4d .. :try_end_1a5d} :catchall_cc

    :catch_1a5d
    const/16 v34, 0x0

    :try_start_1a5f
    const/16 v12, 0x367

    move/from16 v0, v34

    sput v0, Lmi2;->g:I

    const/16 v22, 0x3

    const/16 v12, 0x332

    move/from16 v0, v22

    sput v0, Lmi2;->o:I

    const/16 v16, 0xf

    move/from16 v0, v29

    move/from16 v1, v16

    if-le v0, v1, :cond_1a88

    const/16 v12, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v19

    const v14, 0xea60

    mul-int v14, v14, v29

    move-object/from16 v61, v17

    int-to-long v0, v14

    move-wide/from16 v16, v0

    add-long v19, v19, v16

    goto :goto_1a95

    :cond_1a88
    move-object/from16 v61, v17

    const/16 v12, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v16

    const-wide/32 v19, 0xdbba0

    add-long v19, v19, v16

    :goto_1a95
    const/16 v12, 0x40a

    move-wide/from16 v0, v19

    sput-wide v0, Lmi2;->i:J
    :try_end_1a9b
    .catch Ljava/lang/Exception; {:try_start_1a5f .. :try_end_1a9b} :catch_14b6
    .catchall {:try_start_1a5f .. :try_end_1a9b} :catchall_cc

    const/16 v16, 0xa

    :try_start_1a9d
    const/16 v12, 0x24

    move-object/from16 v0, v24

    move/from16 v1, v16

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/lang/String;

    const/16 v12, 0xd35

    invoke-static {v14}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v16
    :try_end_1aaf
    .catch Ljava/lang/Exception; {:try_start_1a9d .. :try_end_1aaf} :catch_1ab0
    .catchall {:try_start_1a9d .. :try_end_1aaf} :catchall_cc

    goto :goto_1ab2

    :catch_1ab0
    const-wide/16 v16, 0x5a0

    :goto_1ab2
    const-wide/32 v19, 0xea60

    mul-long v16, v16, v19

    :try_start_1ab7
    const/16 v12, 0x11a9

    move-wide/from16 v0, v16

    sput-wide v0, Lmi2;->j:J

    const/16 v68, 0x1

    const/16 v12, 0x3f0

    move/from16 v0, v68

    sput-boolean v0, Lmi2;->k:Z

    const/16 v12, 0xf1

    move-object/from16 v0, v28

    iget-boolean v14, v0, Lou;->c:Z

    nop

    const/16 v12, 0xe04

    sput-boolean v14, Lmi2;->l:Z

    const/16 v12, 0x3b

    move-object/from16 v0, v28

    iget-object v14, v0, Lou;->i:Ljava/lang/String;

    nop

    const/4 v12, -0x6

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v12, 0xe86

    sput-object v14, Lmi2;->m:Ljava/lang/String;

    const/16 v12, 0x5b

    new-instance v14, Landroid/content/Intent;

    nop

    move-object/from16 v16, v75

    const/16 v12, 0x62

    move-object/from16 v0, v16

    invoke-direct {v14, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v12, 0x53

    move-object/from16 v0, v27

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v16

    const/16 v12, 0x4a

    move-object/from16 v0, v16

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v16

    const/16 v12, 0x64

    move-object/from16 v0, v16

    invoke-virtual {v14, v0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v14

    const/high16 v16, 0x10000000

    const/16 v12, 0x59

    move/from16 v0, v16

    invoke-virtual {v14, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v14

    const/16 v12, 0x63

    move-object/from16 v0, v27

    invoke-virtual {v0, v14}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    const/16 v12, 0x5b

    new-instance v14, Landroid/content/Intent;

    nop

    move-object/from16 v16, v74

    const/16 v12, 0x62

    move-object/from16 v0, v16

    invoke-direct {v14, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    move-object/from16 v16, v73

    const/16 v20, 0x1

    const/16 v12, 0x178

    move-object/from16 v0, v16

    move/from16 v1, v20

    invoke-virtual {v14, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    move-result-object v14

    const/16 v12, 0x53

    move-object/from16 v0, v27

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v16

    const/16 v12, 0x4a

    move-object/from16 v0, v16

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v16

    const/16 v12, 0x64

    move-object/from16 v0, v16

    invoke-virtual {v14, v0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v14

    const/high16 v16, 0x10000000

    const/16 v12, 0x59

    move/from16 v0, v16

    invoke-virtual {v14, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v14

    const/16 v12, 0x63

    move-object/from16 v0, v27

    invoke-virtual {v0, v14}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    const/16 v12, 0x402

    iget-object v14, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->I:Lx52;

    nop

    if-eqz v14, :cond_1ea6

    move-object/from16 v16, v33

    const/16 v12, 0x43a

    move-object/from16 v0, v16

    invoke-virtual {v14, v0}, Lnv0;->a(Ljava/util/concurrent/CancellationException;)V

    const/16 v12, 0x3b

    move-object/from16 v0, v28

    iget-object v14, v0, Lou;->i:Ljava/lang/String;

    nop

    const/16 v20, 0x1

    move/from16 v0, v20

    new-array v0, v0, [C

    move-object/from16 v16, v0

    const/16 v17, 0x2e

    const/16 v19, 0x0

    aput-char v17, v16, v19

    const/16 v12, 0x31

    move-object/from16 v0, v16

    invoke-static {v14, v0}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v14

    const/16 v12, 0x24

    move/from16 v0, v19

    invoke-interface {v14, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/lang/String;

    const/16 v12, 0x1f7

    sget-object v16, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    nop

    const/16 v12, 0x12d

    move-object/from16 v0, v16

    invoke-virtual {v14, v0}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v19

    const/4 v12, -0x6

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-lez v29, :cond_1baa

    move/from16 v16, v29

    goto :goto_1bac

    :cond_1baa
    const/16 v16, 0xf

    :goto_1bac
    const/4 v14, 0x0

    move-object/from16 v17, v18

    move/from16 v23, v20

    move-object/from16 v18, v61

    move/from16 v20, v16

    move/from16 v16, v14

    const/16 v12, 0x2ad

    move v0, v12

    move-object v1, v15

    move/from16 v2, v16

    move-object/from16 v3, v17

    move-object/from16 v4, v18

    move-object/from16 v5, v19

    move/from16 v6, v20

    invoke-virtual/range {v1 .. v6}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->j(ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V

    const/16 v12, 0x1c

    iget-boolean v14, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    nop

    if-eqz v14, :cond_1c04

    const/16 v12, 0x380

    move-object/from16 v0, v27

    iget-boolean v14, v0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->c:Z

    nop

    if-eqz v14, :cond_1c04

    const/16 v12, 0x195

    sget-boolean v14, Lmi2;->d:Z

    nop

    if-eqz v14, :cond_1c04

    const/16 v12, 0x175

    new-instance v14, Lfm2;

    nop

    const/16 v12, 0x16f

    move/from16 v0, v22

    invoke-direct {v14, v15, v0}, Lfm2;-><init>(Lcom/tlsvpn/tlstunnel/services/VpnConnection;I)V

    const/16 v12, 0xde

    sget-boolean v16, Lg4;->j:Z

    nop

    if-nez v16, :cond_1bf8

    const/16 v12, 0x197

    invoke-virtual {v14}, Lfm2;->invoke()Ljava/lang/Object;

    goto :goto_1c04

    :cond_1bf8
    const/16 v12, 0x154

    sget-object v16, Lg4;->m:Ljava/util/ArrayList;

    nop

    const/16 v12, 0x174

    move-object/from16 v0, v16

    invoke-virtual {v0, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1c04
    :goto_1c04
    const/16 v12, 0x5b

    new-instance v14, Landroid/content/Intent;

    nop

    const-string/jumbo v16, "timeLeft"

    const/16 v12, 0x62

    move-object/from16 v0, v16

    invoke-direct {v14, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string/jumbo v16, "serverhost"

    const/16 v12, 0x3b

    move-object/from16 v0, v28

    iget-object v12, v0, Lou;->i:Ljava/lang/String;

    move-object/16 v18, v12

    const/16 v12, 0x4b

    move-object/from16 v0, v16

    move-object/from16 v1, v18

    invoke-virtual {v14, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v14

    const-string/jumbo v16, "mLeft"

    const/16 v12, 0x29

    move-object/from16 v0, v16

    move/from16 v1, v29

    invoke-virtual {v14, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v14

    const/16 v12, 0x53

    move-object/from16 v0, v27

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v16

    const/16 v12, 0x4a

    move-object/from16 v0, v16

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v16

    const/16 v12, 0x64

    move-object/from16 v0, v16

    invoke-virtual {v14, v0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v14

    const/high16 v16, 0x10000000

    const/16 v12, 0x59

    move/from16 v0, v16

    invoke-virtual {v14, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v14

    const/4 v12, -0x6

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v12, 0x63

    move-object/from16 v0, v27

    invoke-virtual {v0, v14}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V
    :try_end_1c63
    .catch Ljava/lang/Exception; {:try_start_1ab7 .. :try_end_1c63} :catch_14b6
    .catchall {:try_start_1ab7 .. :try_end_1c63} :catchall_cc

    const/16 v14, 0x8

    :try_start_1c65
    const/16 v12, 0x24

    move-object/from16 v0, v24

    invoke-interface {v0, v14}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/lang/String;

    const/16 v12, 0x8e

    invoke-static {v14}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v14
    :try_end_1c75
    .catch Ljava/lang/Exception; {:try_start_1c65 .. :try_end_1c75} :catch_1c76
    .catchall {:try_start_1c65 .. :try_end_1c75} :catchall_cc

    goto :goto_1ca7

    :catch_1c76
    :try_start_1c76
    const/16 v12, 0x24

    move-object/from16 v0, v24

    move/from16 v1, v22

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/lang/String;

    const/16 v12, 0x8e

    invoke-static {v14}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v14

    const/16 v16, 0x4

    const/16 v12, 0x24

    move-object/from16 v0, v24

    move/from16 v1, v16

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v16

    check-cast v16, Ljava/lang/String;

    const/16 v12, 0x8e

    move-object/from16 v0, v16

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v16

    div-int v14, v14, v16
    :try_end_1ca0
    .catch Ljava/lang/Exception; {:try_start_1c76 .. :try_end_1ca0} :catch_1ca3
    .catchall {:try_start_1c76 .. :try_end_1ca0} :catchall_cc

    add-int/lit8 v16, v14, 0x1

    goto :goto_1ca5

    :catch_1ca3
    const/16 v16, 0x0

    :goto_1ca5
    move/from16 v14, v16

    :goto_1ca7
    :try_start_1ca7
    const/16 v12, 0x7a

    move-object/from16 v0, v52

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v16

    const/4 v12, -0x3

    new-instance v18, Ljava/lang/StringBuilder;

    nop

    const/4 v12, -0x4

    move-object/from16 v0, v18

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v12, 0x3b

    move-object/from16 v0, v28

    iget-object v12, v0, Lou;->i:Ljava/lang/String;

    move-object/16 v19, v12

    const/16 v12, 0x1f7

    sget-object v20, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    nop

    const/16 v12, 0x3b0

    move-object/from16 v0, v19

    move-object/from16 v1, v20

    invoke-virtual {v0, v1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v19

    const/4 v12, -0x6

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v12, 0x0

    move-object/from16 v0, v18

    move-object/from16 v1, v19

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v19, "-status"

    const/4 v12, 0x0

    move-object/from16 v0, v18

    move-object/from16 v1, v19

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, -0x2

    move-object/from16 v0, v18

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v18

    const/16 v12, 0x56

    move-object/from16 v0, v16

    move-object/from16 v1, v18

    invoke-interface {v0, v1, v14}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/16 v12, 0x6f

    move-object/from16 v0, v16

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/16 v12, 0x20c

    move-object/from16 v0, v28

    invoke-virtual {v0}, Lou;->a()V

    move-object/from16 v16, v41

    move-object/from16 v22, v52

    const/16 v18, 0x0

    const/16 v12, 0x77

    move-object/from16 v0, v22

    move-object/from16 v1, v16

    move/from16 v2, v18

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v14

    if-nez v14, :cond_1d5c

    const/16 v12, 0x380

    move-object/from16 v0, v27

    iget-boolean v14, v0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->c:Z

    nop

    if-nez v14, :cond_1d5c

    const/16 v12, 0x5b

    new-instance v14, Landroid/content/Intent;

    nop

    move-object/from16 v16, v39

    const/16 v12, 0x62

    move-object/from16 v0, v16

    invoke-direct {v14, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v12, 0x53

    move-object/from16 v0, v27

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v16

    const/16 v12, 0x4a

    move-object/from16 v0, v16

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v16

    const/16 v12, 0x64

    move-object/from16 v0, v16

    invoke-virtual {v14, v0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v14

    const/high16 v16, 0x10000000

    const/16 v12, 0x59

    move/from16 v0, v16

    invoke-virtual {v14, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v14

    const/16 v12, 0x63

    move-object/from16 v0, v27

    invoke-virtual {v0, v14}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    :cond_1d5c
    move-object/from16 v24, v47

    const/16 v12, 0x77

    move-object/from16 v0, v22

    move-object/from16 v1, v24

    move/from16 v2, v23

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v14

    if-eqz v14, :cond_1dbb

    const/16 v12, 0x7a

    move-object/from16 v0, v22

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v14

    const/16 v18, 0x0

    const/16 v12, 0x48

    move-object/from16 v0, v24

    move/from16 v1, v18

    invoke-interface {v14, v0, v1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/16 v12, 0x6f

    invoke-interface {v14}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/16 v12, 0x5b

    new-instance v14, Landroid/content/Intent;

    nop

    move-object/from16 v18, v70

    const/16 v12, 0x62

    move-object/from16 v0, v18

    invoke-direct {v14, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v12, 0x53

    move-object/from16 v0, v27

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v16

    const/16 v12, 0x4a

    move-object/from16 v0, v16

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v16

    const/16 v12, 0x64

    move-object/from16 v0, v16

    invoke-virtual {v14, v0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v14

    const/high16 v16, 0x10000000

    const/16 v12, 0x59

    move/from16 v0, v16

    invoke-virtual {v14, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v14

    const/16 v12, 0x63

    move-object/from16 v0, v27

    invoke-virtual {v0, v14}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    :cond_1dbb
    const/16 v12, 0x316

    invoke-virtual {v15}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->e()V

    const/16 v12, 0x5a

    sget-object v54, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->a:Lcom/tlsvpn/tlstunnel/utils/SocketOps;

    nop

    const/16 v12, 0x730

    move-object/from16 v0, v54

    invoke-virtual {v0}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->i()I

    move-result v14

    const/16 v12, 0xdf4

    iput v14, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->y:I

    const/16 v12, 0x34f

    iget v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->w:I

    move/16 v16, v12

    const/16 v12, 0x2b5

    move-object/from16 v0, v27

    iget-object v12, v0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->i:Landroid/os/ParcelFileDescriptor;

    move-object/16 v18, v12

    const/4 v12, -0x6

    move-object/from16 v0, v18

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v12, 0xc8

    move-object/from16 v0, v18

    invoke-virtual {v0}, Landroid/os/ParcelFileDescriptor;->getFd()I

    move-result v57

    const/16 v12, 0x299

    iget-boolean v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->m:Z

    move/16 v18, v12

    const/16 v12, 0x11d

    iget-boolean v12, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->n:Z

    move/16 v19, v12

    move/from16 v55, v14

    move/from16 v56, v16

    move-object/from16 v60, v17

    move/from16 v63, v18

    move/from16 v64, v19

    move-object/from16 v62, v21

    const/16 v12, 0x1234

    move v0, v12

    move-object/from16 v1, v54

    move/from16 v2, v55

    move/from16 v3, v56

    move/from16 v4, v57

    move-wide/from16 v5, v58

    move-object/from16 v7, v60

    move-object/from16 v8, v61

    move-object/from16 v9, v62

    move/from16 v10, v63

    move/from16 v11, v64

    invoke-virtual/range {v1 .. v11}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->r(IIIJLjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZ)D

    move-result-wide v16

    const/16 v12, 0x11d

    iget-boolean v14, v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->n:Z

    nop

    if-eqz v14, :cond_1e95

    const/4 v12, -0x3

    new-instance v14, Ljava/lang/StringBuilder;

    nop

    const/4 v12, -0x4

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x0

    move-object/from16 v0, v26

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v18, 0x7f13008b

    const/4 v12, 0x7

    move/from16 v0, v18

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v18

    const/4 v12, 0x0

    move-object/from16 v0, v18

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    move-object/from16 v0, v25

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v12, 0xa75

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v18

    const-string/jumbo v19, "%.2f"

    const/16 v12, 0xc25

    move-wide/from16 v0, v16

    invoke-static {v0, v1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v16

    filled-new-array/range {v16 .. v16}, [Ljava/lang/Object;

    move-result-object v16

    const/16 v12, 0x120e

    move-object/from16 v0, v16

    move/from16 v1, v23

    invoke-static {v0, v1}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v16

    const/16 v12, 0xb81

    move-object/from16 v0, v18

    move-object/from16 v1, v19

    move-object/from16 v2, v16

    invoke-static {v0, v1, v2}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v16

    const/4 v12, 0x0

    move-object/from16 v0, v16

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v16, " MB"

    const/4 v12, 0x0

    move-object/from16 v0, v16

    invoke-virtual {v14, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, -0x2

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v14

    const/16 v12, 0x163

    move/from16 v0, v23

    invoke-virtual {v15, v14, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->a(Ljava/lang/String;Z)V
    :try_end_1e95
    .catch Ljava/lang/Exception; {:try_start_1ca7 .. :try_end_1e95} :catch_14b6
    .catchall {:try_start_1ca7 .. :try_end_1e95} :catchall_cc

    :cond_1e95
    move-wide/from16 v30, v58

    goto/16 :goto_1026

    :goto_1e99
    const/4 v12, 0x7

    move/from16 v0, v17

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v14

    const/4 v12, -0x8

    invoke-static {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    goto/16 :goto_1f4e

    :cond_1ea6
    :try_start_1ea6
    const-string/jumbo v14, "notGifConectando"

    const/4 v12, 0x5

    invoke-static {v14}, Lgt0;->F0(Ljava/lang/String;)V

    const/16 v33, 0x0

    throw v33

    :cond_1eb0
    const/16 v12, 0x4bb

    new-instance v14, Ljava/lang/IllegalStateException;

    nop

    move-object/from16 v18, v69

    const/16 v12, 0x49e

    move-object/from16 v0, v18

    invoke-direct {v14, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    check-cast v14, Ljava/lang/Throwable;

    throw v14

    :catch_1ec1
    move-exception v14

    move-wide/from16 v58, v16

    goto/16 :goto_14b7

    :cond_1ec6
    move-wide/from16 v58, v16

    const/16 v12, 0x36a

    new-instance v14, Ljava/lang/Exception;

    nop

    const v16, 0x7f130108

    const/4 v12, 0x7

    move/from16 v0, v16

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v16

    const/16 v12, 0x46d

    move-object/from16 v0, v16

    invoke-direct {v14, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    check-cast v14, Ljava/lang/Throwable;

    throw v14

    :cond_1ee1
    move-wide/from16 v58, v16

    const/16 v12, 0x36a

    new-instance v14, Ljava/lang/Exception;

    nop

    const v16, 0x7f13023f

    const/4 v12, 0x7

    move/from16 v0, v16

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v16

    const/16 v12, 0x46d

    move-object/from16 v0, v16

    invoke-direct {v14, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    check-cast v14, Ljava/lang/Throwable;

    throw v14
    :try_end_1efc
    .catch Ljava/lang/Exception; {:try_start_1ea6 .. :try_end_1efc} :catch_14b6
    .catchall {:try_start_1ea6 .. :try_end_1efc} :catchall_cc

    :goto_1efc
    const/4 v12, 0x7

    move/from16 v0, v17

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v14

    goto/16 :goto_1a31

    :goto_1f05
    :try_start_1f05
    const/4 v12, -0x3

    new-instance v16, Ljava/lang/StringBuilder;

    nop

    const/4 v12, -0x4

    move-object/from16 v0, v16

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x0

    move-object/from16 v0, v16

    move-object/from16 v1, v26

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v17, 0x7f1300cd

    const/4 v12, 0x7

    move/from16 v0, v17

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v17

    const/4 v12, 0x0

    move-object/from16 v0, v16

    move-object/from16 v1, v17

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    move-object/from16 v0, v16

    move-object/from16 v1, v25

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v12, 0xda1

    invoke-virtual {v14}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v14

    const/16 v12, 0x190

    move-object/from16 v0, v16

    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v12, -0x2

    move-object/from16 v0, v16

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v14

    const/4 v12, -0x8

    invoke-static {v15, v14}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V
    :try_end_1f49
    .catchall {:try_start_1f05 .. :try_end_1f49} :catchall_cc

    const v17, 0x7f13009d

    goto/16 :goto_1e99

    :goto_1f4e
    return-wide v30

    :goto_1f4f
    const/4 v12, 0x7

    move/from16 v0, v17

    invoke-virtual {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v16

    const/4 v12, -0x8

    move-object/from16 v0, v16

    invoke-static {v15, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Ljava/lang/String;)V

    throw v14
.end method

.method public final g(ZZ)V
    .registers 12

    .prologue
    const-string/jumbo v2, "notGifConectando"

    const/16 v0, 0xfa

    iget-object v3, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->a:Lcom/tlsvpn/tlstunnel/services/ServicoVpn;

    nop

    const/16 v0, 0x1c

    iget-boolean v4, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    nop

    if-nez v4, :cond_11

    goto/16 :goto_114

    :cond_11
    const/4 v4, 0x0

    const/16 v0, 0x115c

    iput-boolean v4, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    const-string/jumbo v4, "</b>"

    const-string/jumbo v5, "<b>"

    const/4 v6, 0x1

    if-nez p1, :cond_42

    const/4 v0, -0x3

    new-instance v7, Ljava/lang/StringBuilder;

    nop

    const/16 v0, 0x97

    invoke-direct {v7, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const v8, 0x7f13024e

    const/4 v0, 0x7

    invoke-virtual {p0, v8}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v8

    const/4 v0, 0x0

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const/16 v0, 0x163

    invoke-virtual {p0, v7, v6}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->a(Ljava/lang/String;Z)V

    :cond_42
    const/16 v0, 0x5a

    sget-object v7, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->a:Lcom/tlsvpn/tlstunnel/utils/SocketOps;

    nop

    const/16 v0, 0xab

    iget v8, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->v:I

    nop

    const/16 v0, 0x362

    invoke-virtual {v7, v8}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->I(I)V

    const/16 v0, 0x34f

    iget v8, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->w:I

    nop

    const/16 v0, 0x362

    invoke-virtual {v7, v8}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->I(I)V

    const/16 v0, 0x7c7

    iget v8, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->x:I

    nop

    if-lez v8, :cond_67

    const/16 v0, 0x488

    invoke-virtual {v7, v8}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->F(I)V

    :cond_67
    const/16 v0, 0x6e5

    iget v8, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->y:I

    nop

    if-lez v8, :cond_73

    const/16 v0, 0x488

    invoke-virtual {v7, v8}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->F(I)V

    :cond_73
    :try_start_73
    const/16 v0, 0x11aa

    iget-object v7, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->t:Ljava/net/Socket;

    nop

    const/16 v0, 0x1a5

    invoke-virtual {v7}, Ljava/net/Socket;->close()V
    :try_end_7d
    .catch Ljava/lang/Exception; {:try_start_73 .. :try_end_7d} :catch_7d

    :catch_7d
    :try_start_7d
    const/16 v0, 0xb02

    iget-object v7, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->u:Ljava/net/Socket;

    nop

    const/16 v0, 0x1a5

    invoke-virtual {v7}, Ljava/net/Socket;->close()V
    :try_end_87
    .catch Ljava/lang/Exception; {:try_start_7d .. :try_end_87} :catch_87

    :catch_87
    const/16 v0, 0x402

    iget-object v7, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->I:Lx52;

    nop

    const/4 v8, 0x0

    if-eqz v7, :cond_a9

    const/16 v0, 0x123a

    invoke-virtual {v7}, Lnv0;->isActive()Z

    move-result v7

    if-eqz v7, :cond_a9

    :try_start_97
    const/16 v0, 0x402

    iget-object v7, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->I:Lx52;

    nop

    if-eqz v7, :cond_a4

    const/16 v0, 0x43a

    invoke-virtual {v7, v8}, Lnv0;->a(Ljava/util/concurrent/CancellationException;)V

    goto :goto_a9

    :cond_a4
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw v8
    :try_end_a9
    .catch Ljava/lang/Exception; {:try_start_97 .. :try_end_a9} :catch_a9

    :catch_a9
    :cond_a9
    :goto_a9
    const/16 v0, 0x152

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->z:Ljava/net/ServerSocket;

    nop

    if-eqz v2, :cond_b5

    :try_start_b0
    const/16 v0, 0x110e

    invoke-virtual {v2}, Ljava/net/ServerSocket;->close()V
    :try_end_b5
    .catch Ljava/lang/Exception; {:try_start_b0 .. :try_end_b5} :catch_b5

    :catch_b5
    :cond_b5
    const/16 v0, 0xe92

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->C:Lcom/trilead/ssh2/DynamicPortForwarder;

    nop

    if-eqz v2, :cond_c1

    :try_start_bc
    const/16 v0, 0xf50

    invoke-virtual {v2}, Lcom/trilead/ssh2/DynamicPortForwarder;->close()V
    :try_end_c1
    .catch Ljava/lang/Exception; {:try_start_bc .. :try_end_c1} :catch_c1

    :catch_c1
    :cond_c1
    const/16 v0, 0x646

    iget v2, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->F:I

    nop

    if-lez v2, :cond_cd

    const/16 v0, 0x409

    invoke-static {v2}, Landroid/os/Process;->killProcess(I)V

    :cond_cd
    const/16 v0, 0x7fb

    iget v2, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->E:I

    nop

    if-lez v2, :cond_d9

    const/16 v0, 0x409

    invoke-static {v2}, Landroid/os/Process;->killProcess(I)V

    :cond_d9
    :try_start_d9
    const/16 v0, 0xe19

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->K:Lhm2;

    nop

    const/16 v0, 0x345

    invoke-virtual {v3, v2}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_e3
    .catch Ljava/lang/Exception; {:try_start_d9 .. :try_end_e3} :catch_e3

    :catch_e3
    if-nez p1, :cond_108

    const/4 v0, -0x3

    new-instance p1, Ljava/lang/StringBuilder;

    nop

    const/16 v0, 0x97

    invoke-direct {p1, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const v2, 0x7f130248

    const/4 v0, 0x7

    invoke-virtual {p0, v2}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v2

    const/4 v0, 0x0

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {p1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0x163

    invoke-virtual {p0, p1, v6}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->a(Ljava/lang/String;Z)V

    :cond_108
    const/16 v0, 0xca9

    iget-object p1, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->G:Lr72;

    nop

    const/16 v0, 0x43a

    invoke-virtual {p1, v8}, Lnv0;->a(Ljava/util/concurrent/CancellationException;)V

    if-eqz p2, :cond_115

    :goto_114
    return-void

    :cond_115
    const/16 v0, 0x5b

    new-instance p1, Landroid/content/Intent;

    nop

    const/16 v0, 0x66f

    iget-boolean p0, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->e:Z

    nop

    if-eqz p0, :cond_125

    const-string/jumbo p0, "reconnect"

    goto :goto_128

    :cond_125
    const-string/jumbo p0, "stopVpn"

    :goto_128
    const/16 v0, 0x62

    invoke-direct {p1, p0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x53

    invoke-virtual {v3}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/16 v0, 0x4a

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x64

    invoke-virtual {p1, p0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    const/high16 p1, 0x10000000

    const/16 v0, 0x59

    invoke-virtual {p0, p1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object p0

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x63

    invoke-virtual {v3, p0}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    return-void
.end method

.method public final h(I)Ljava/lang/String;
    .registers 4

    .prologue
    const/16 v0, 0xfa

    iget-object p0, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->a:Lcom/tlsvpn/tlstunnel/services/ServicoVpn;

    nop

    const/16 v0, 0xdb8

    iget-object p0, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->k:Landroid/content/Context;

    nop

    if-eqz p0, :cond_19

    const/16 v0, 0xb4

    invoke-virtual {p0, p1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p0, Ljava/lang/String;

    return-object p0

    :cond_19
    const-string/jumbo p0, "languageContext"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0
.end method

.method public final i(Lwx;)Ljava/lang/Object;
    .registers 10

    .prologue
    instance-of v2, p1, Lim2;

    if-eqz v2, :cond_18

    move-object v2, p1

    check-cast v2, Lim2;

    const/16 v0, 0x3aa

    iget v3, v2, Lim2;->w:I

    nop

    const/high16 v4, -0x80000000

    and-int v5, v3, v4

    if-eqz v5, :cond_18

    sub-int/2addr v3, v4

    const/16 v0, 0x455

    iput v3, v2, Lim2;->w:I

    goto :goto_22

    :cond_18
    const/16 v0, 0xd9b

    new-instance v2, Lim2;

    nop

    const/16 v0, 0x107d

    invoke-direct {v2, p0, p1}, Lim2;-><init>(Lcom/tlsvpn/tlstunnel/services/VpnConnection;Lwx;)V

    :goto_22
    const/16 v0, 0xfc4

    iget-object p1, v2, Lim2;->u:Ljava/lang/Object;

    nop

    const/16 v0, 0x3aa

    iget v3, v2, Lim2;->w:I

    nop

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz v3, :cond_47

    if-ne v3, v5, :cond_3d

    const/16 v0, 0xf7d

    iget v3, v2, Lim2;->t:I

    nop

    :try_start_37
    const/4 v0, 0x6

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_3b
    .catch Ljava/lang/Exception; {:try_start_37 .. :try_end_3b} :catch_c1

    move p1, v3

    goto :goto_4c

    :cond_3d
    const-string/jumbo p0, "call to \'resume\' before \'invoke\' with coroutine"

    const/16 v0, 0x13

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0

    :cond_47
    const/4 v0, 0x6

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    move p1, v4

    :cond_4c
    :goto_4c
    const/16 v0, 0x8f3

    invoke-virtual {p0}, Ljava/lang/Thread;->isAlive()Z

    move-result v3

    if-eqz v3, :cond_c1

    const/16 v0, 0x2b8

    invoke-virtual {p0}, Ljava/lang/Thread;->isInterrupted()Z

    move-result v3

    if-nez v3, :cond_c1

    const/16 v0, 0x1c

    iget-boolean v3, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    nop

    if-eqz v3, :cond_c1

    const/16 v0, 0x1ff

    sget v3, Lmi2;->o:I

    nop

    const/4 v6, 0x3

    if-eq v3, v6, :cond_c1

    if-eqz p1, :cond_71

    const v3, 0x7f08012a

    goto :goto_74

    :cond_71
    const v3, 0x7f08012b

    :goto_74
    if-nez p1, :cond_78

    move p1, v5

    goto :goto_79

    :cond_78
    move p1, v4

    :goto_79
    :try_start_79
    const/16 v0, 0x109a

    iget-object v6, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->c:Lkg1;

    nop

    const/16 v0, 0x1bd

    iget-object v7, v6, Lkg1;->u:Landroid/app/Notification;

    nop

    const/16 v0, 0xdd4

    iput v3, v7, Landroid/app/Notification;->icon:I

    const/16 v0, 0x97e

    iget-object v3, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->d:Landroid/app/NotificationManager;

    nop

    const/16 v0, 0x1df

    invoke-virtual {v6}, Lkg1;->b()Landroid/app/Notification;

    move-result-object v6

    const/16 v0, 0x1be

    invoke-virtual {v3, v5, v6}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    const/16 v0, 0x424

    sget-object v3, Lv60;->b:Lp80;

    nop

    const/16 v0, 0x99e

    sget-object v3, Ly60;->d:Ly60;

    nop

    const/16 v6, 0x1f4

    const/16 v0, 0x405

    invoke-static {v6, v3}, Li10;->G0(ILy60;)J

    move-result-wide v6

    const/16 v0, 0xf28

    iput p1, v2, Lim2;->t:I

    const/16 v0, 0x455

    iput v5, v2, Lim2;->w:I

    const/16 v0, 0x1e9

    invoke-static {v6, v7, v2}, Lsz;->u(JLvx;)Ljava/lang/Object;

    move-result-object v3
    :try_end_b7
    .catch Ljava/lang/Exception; {:try_start_79 .. :try_end_b7} :catch_c1

    const/16 v0, 0x15

    sget-object v6, Lwy;->a:Lwy;

    nop

    if-ne v3, v6, :cond_4c

    check-cast v6, Ljava/lang/Object;

    return-object v6

    :catch_c1
    :cond_c1
    const/16 v0, 0x21

    sget-object p0, Lrg2;->a:Lrg2;

    nop

    check-cast p0, Ljava/lang/Object;

    return-object p0
.end method

.method public final j(ZLjava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V
    .registers 14

    .prologue
    const-wide/16 v2, 0xfa

    const/16 v0, 0x209

    invoke-static {v2, v3}, Ljava/lang/Thread;->sleep(J)V

    const/16 v0, 0x1c

    iget-boolean v2, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    nop

    if-eqz v2, :cond_e1

    const/16 v0, 0x109a

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->c:Lkg1;

    nop

    const/16 v0, 0x1bd

    iget-object v3, v2, Lkg1;->u:Landroid/app/Notification;

    nop

    const v4, 0x7f080139

    const/16 v0, 0xdd4

    iput v4, v3, Landroid/app/Notification;->icon:I

    const/16 v0, 0x101

    sget-boolean v4, Lmi2;->n:Z

    nop

    const/4 v5, 0x1

    if-nez v4, :cond_38

    if-lez p5, :cond_38

    const/16 v0, 0x26f

    sget-wide v6, Lmi2;->i:J

    nop

    const/16 v0, 0x210

    iput-wide v6, v3, Landroid/app/Notification;->when:J

    const/16 v0, 0x226

    invoke-virtual {v2, v5}, Lkg1;->d(Z)V

    goto :goto_4d

    :cond_38
    const/16 v0, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    const/16 v0, 0x1bd

    iget-object p5, v2, Lkg1;->u:Landroid/app/Notification;

    nop

    const/16 v0, 0x210

    iput-wide v3, p5, Landroid/app/Notification;->when:J

    const/4 p5, 0x0

    const/16 v0, 0x226

    invoke-virtual {v2, p5}, Lkg1;->d(Z)V

    :goto_4d
    const/16 v0, 0x2db

    iput-boolean v5, v2, Lkg1;->j:Z

    const/16 v0, 0x52b

    sget-object p5, Ldz;->a:Lcz;

    nop

    const/4 p5, 0x2

    const/16 v0, 0x196

    invoke-static {p5, p4}, Lc72;->G0(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p5

    const/16 v0, 0x1f7

    sget-object v2, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    nop

    const/16 v0, 0x3b0

    invoke-virtual {p5, v2}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object p5

    const/4 v0, -0x6

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x334

    invoke-static {p5}, Ldz;->a(Ljava/lang/String;)Lcz;

    move-result-object p5

    const-string/jumbo v2, ": "

    const v3, 0x7f130090

    if-eqz p1, :cond_8f

    const/4 v0, -0x3

    new-instance p1, Ljava/lang/StringBuilder;

    nop

    const/4 v0, 0x7

    invoke-virtual {p0, v3}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object p3

    const/16 v0, 0x97

    invoke-direct {p1, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x3ab

    invoke-static {p1, v2, p2}, Ly41;->s(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    goto :goto_dc

    :cond_8f
    const/4 v0, -0x3

    new-instance p1, Ljava/lang/StringBuilder;

    nop

    const/16 v0, 0x1e6

    iget-object p5, p5, Lcz;->c:Ljava/lang/String;

    nop

    const/16 v0, 0x97

    invoke-direct {p1, p5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 p5, 0x20

    const/16 v0, 0x1b

    invoke-virtual {p1, p5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {p1, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, 0x7

    invoke-virtual {p0, v3}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object p4

    const/4 v0, 0x0

    invoke-virtual {p1, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x1b

    invoke-virtual {p1, p5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x47

    invoke-virtual {p3}, Ljava/lang/String;->length()I

    move-result p2

    if-lez p2, :cond_d0

    const-string/jumbo p2, " / "

    const/16 v0, 0xee

    invoke-virtual {p2, p3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    goto :goto_d3

    :cond_d0
    const-string/jumbo p2, ""

    :goto_d3
    const/4 v0, 0x0

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    :goto_dc
    const/16 v0, 0x157

    invoke-virtual {p0, p1}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->k(Ljava/lang/String;)V

    :cond_e1
    return-void
.end method

.method public final k(Ljava/lang/String;)V
    .registers 5

    .prologue
    const/16 v0, 0x1c

    iget-boolean v2, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    nop

    if-nez v2, :cond_8

    goto :goto_2c

    :cond_8
    const/16 v0, 0x109a

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->c:Lkg1;

    nop

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x3e6

    invoke-static {p1}, Lkg1;->c(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object p1

    const/16 v0, 0x67b

    iput-object p1, v2, Lkg1;->f:Ljava/lang/CharSequence;

    :try_start_1b
    const/16 v0, 0x97e

    iget-object p0, p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->d:Landroid/app/NotificationManager;

    nop

    const/16 v0, 0x1df

    invoke-virtual {v2}, Lkg1;->b()Landroid/app/Notification;

    move-result-object p1

    const/4 v2, 0x1

    const/16 v0, 0x1be

    invoke-virtual {p0, v2, p1}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V
    :try_end_2c
    .catch Ljava/lang/Exception; {:try_start_1b .. :try_end_2c} :catch_2c

    :catch_2c
    :goto_2c
    return-void
.end method

.method public final l(JZ)V
    .registers 25

    .prologue
    const/4 v11, 0x0

    :try_start_1
    const/16 v8, 0x152

    move-object/from16 v0, p0

    iget-object v10, v0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->z:Ljava/net/ServerSocket;

    nop

    if-eqz v10, :cond_99

    const/16 v8, 0x6de

    invoke-virtual {v10}, Ljava/net/ServerSocket;->accept()Ljava/net/Socket;

    move-result-object v10

    const/4 v12, 0x1

    const/16 v8, 0x44c

    invoke-virtual {v10, v12}, Ljava/net/Socket;->setTcpNoDelay(Z)V

    const/16 v8, 0x4b2

    invoke-virtual {v10, v12}, Ljava/net/Socket;->setKeepAlive(Z)V

    const/16 v8, 0x2e0

    invoke-static {v10}, Landroid/os/ParcelFileDescriptor;->fromSocket(Ljava/net/Socket;)Landroid/os/ParcelFileDescriptor;

    move-result-object v13

    const/16 v8, 0x5a

    sget-object v14, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->a:Lcom/tlsvpn/tlstunnel/utils/SocketOps;

    nop

    const/16 v8, 0x730

    invoke-virtual {v14}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->i()I

    move-result v15

    const/16 v8, 0xc4f

    move-object/from16 v0, p0

    iput v15, v0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->x:I

    const/16 v8, 0xc8

    invoke-virtual {v13}, Landroid/os/ParcelFileDescriptor;->getFd()I

    move-result v15

    const/16 v8, 0x891

    invoke-virtual {v14, v15}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->H(I)V

    const/16 v8, 0x7c7

    move-object/from16 v0, p0

    iget v15, v0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->x:I

    nop

    const/16 v8, 0xab

    move-object/from16 v0, p0

    iget v8, v0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->v:I

    move/16 v16, v8

    const/16 v8, 0xc8

    invoke-virtual {v13}, Landroid/os/ParcelFileDescriptor;->getFd()I

    move-result v17
    :try_end_53
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_53} :catch_93

    move-wide/from16 v18, p1

    move/from16 v20, p3

    :try_start_57
    const/16 v8, 0xe0c

    move v0, v8

    move-object v1, v14

    move v2, v15

    move/from16 v3, v16

    move/from16 v4, v17

    move-wide/from16 v5, v18

    move/from16 v7, v20

    invoke-virtual/range {v1 .. v7}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->e(IIIJZ)V

    const/16 v8, 0x1a5

    invoke-virtual {v10}, Ljava/net/Socket;->close()V

    const/16 v8, 0x18b

    invoke-virtual {v13}, Landroid/os/ParcelFileDescriptor;->close()V

    const/16 v8, 0xfa

    move-object/from16 v0, p0

    iget-object v8, v0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->a:Lcom/tlsvpn/tlstunnel/services/ServicoVpn;

    move-object/16 p1, v8

    const/16 v8, 0x380

    move-object/from16 v0, p1

    iget-boolean v8, v0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->c:Z

    move/16 p1, v8

    xor-int p1, p1, v12

    const/16 v8, 0x82e

    move-object/from16 v0, p0

    move/from16 v1, p1

    invoke-virtual {v0, v1, v11}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->g(ZZ)V

    goto :goto_f9

    :catch_8f
    move-exception v10

    :goto_90
    move-object/from16 p1, v10

    goto :goto_a9

    :catch_93
    move-exception v10

    move-wide/from16 v18, p1

    move/from16 v20, p3

    goto :goto_90

    :cond_99
    move-wide/from16 v18, p1

    move/from16 v20, p3

    const-string/jumbo p1, "lSocketServer"

    const/4 v8, 0x5

    move-object/from16 v0, p1

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    const/16 p1, 0x0

    throw p1
    :try_end_a9
    .catch Ljava/lang/Exception; {:try_start_57 .. :try_end_a9} :catch_8f

    :goto_a9
    const/4 v8, -0x3

    new-instance p2, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo p3, "<b>"

    const/16 v8, 0x97

    move-object/from16 v0, p2

    move-object/from16 v1, p3

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const p3, 0x7f1300cd

    const/4 v8, 0x7

    move-object/from16 v0, p0

    move/from16 v1, p3

    invoke-virtual {v0, v1}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object p3

    const/4 v8, 0x0

    move-object/from16 v0, p2

    move-object/from16 v1, p3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo p3, "</b>: openLocalSocket() "

    const/4 v8, 0x0

    move-object/from16 v0, p2

    move-object/from16 v1, p3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v8, 0xda1

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object p1

    const/16 v8, 0x190

    move-object/from16 v0, p2

    move-object/from16 v1, p1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v8, -0x2

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/16 v8, 0x163

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual {v0, v1, v11}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->a(Ljava/lang/String;Z)V

    :goto_f9
    if-eqz v20, :cond_109

    const/16 v8, 0x5a

    sget-object p0, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->a:Lcom/tlsvpn/tlstunnel/utils/SocketOps;

    nop

    const/16 v8, 0x3ea

    move-object/from16 v0, p0

    move-wide/from16 v1, v18

    invoke-virtual {v0, v1, v2}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->x(J)V

    :cond_109
    return-void
.end method

.method public final run()V
    .registers 61

    .prologue
    move-object/from16 v8, p0

    const/16 v6, 0xb32

    invoke-super {v8}, Ljava/lang/Thread;->run()V

    const/16 v9, -0x13

    const/16 v6, 0xa63

    invoke-static {v9}, Landroid/os/Process;->setThreadPriority(I)V

    const/16 v6, 0x6d9

    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v9

    const/16 v6, 0x90f

    invoke-virtual {v9}, Ljava/lang/Runtime;->availableProcessors()I

    move-result v9

    const/4 v10, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x2

    if-le v9, v12, :cond_21

    move v9, v10

    goto :goto_22

    :cond_21
    move v9, v11

    :goto_22
    const/16 v6, 0x5a

    sget-object v13, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->a:Lcom/tlsvpn/tlstunnel/utils/SocketOps;

    nop

    const/16 v6, 0x9f9

    invoke-virtual {v13, v9}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->v(I)Z

    const/16 v6, 0x16

    new-instance v9, Lqd;

    nop

    const/16 v13, 0xa

    const/4 v14, 0x0

    const/16 v6, 0x17

    invoke-direct {v9, v8, v14, v13}, Lqd;-><init>(Ljava/lang/Object;Lvx;I)V

    const/16 v6, 0x9ea

    iget-object v13, v8, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->H:Lsx;

    nop

    const/4 v15, 0x3

    const/16 v6, 0xb3

    move v0, v6

    move-object v1, v13

    move-object v2, v14

    move-object v3, v14

    move-object v4, v9

    move v5, v15

    invoke-static/range {v1 .. v5}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    move-result-object v9

    const/16 v6, 0x5ef

    iput-object v9, v8, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->I:Lx52;

    const/16 v6, 0x66f

    iget-boolean v9, v8, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->e:Z

    nop

    if-eqz v9, :cond_c2

    const/16 v6, 0x1ee

    sget v9, Lmi2;->g:I

    nop

    const/16 v13, 0x3c

    if-ge v9, v13, :cond_64

    add-int/2addr v9, v10

    const/16 v6, 0x367

    sput v9, Lmi2;->g:I

    :cond_64
    const/4 v6, -0x3

    new-instance v9, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v13, "<b>"

    const/16 v6, 0x97

    invoke-direct {v9, v13}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const v13, 0x7f13021c

    const/4 v6, 0x7

    invoke-virtual {v8, v13}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v16

    const/4 v6, 0x0

    move-object/from16 v0, v16

    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v16, "</b> ("

    const/4 v6, 0x0

    move-object/from16 v0, v16

    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v6, 0x1ee

    sget v16, Lmi2;->g:I

    nop

    const/16 v6, 0x33

    move/from16 v0, v16

    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v16, "s)"

    const/4 v6, 0x0

    move-object/from16 v0, v16

    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, -0x2

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    const/16 v6, 0x163

    invoke-virtual {v8, v9, v11}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->a(Ljava/lang/String;Z)V

    const/4 v6, 0x7

    invoke-virtual {v8, v13}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v9

    const/16 v6, 0x157

    invoke-virtual {v8, v9}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->k(Ljava/lang/String;)V

    :try_start_b0
    const/16 v6, 0x1ee

    sget v9, Lmi2;->g:I

    nop

    mul-int/lit16 v9, v9, 0x3e8

    int-to-long v0, v9

    move-wide/from16 v16, v0

    const/16 v6, 0x209

    move-wide/from16 v0, v16

    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V
    :try_end_c1
    .catch Ljava/lang/Exception; {:try_start_b0 .. :try_end_c1} :catch_dd

    goto :goto_dd

    :cond_c2
    const v9, 0x7f130093

    const/4 v6, 0x7

    invoke-virtual {v8, v9}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v13

    const/16 v6, 0x163

    invoke-virtual {v8, v13, v11}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->a(Ljava/lang/String;Z)V

    const/4 v6, 0x7

    invoke-virtual {v8, v9}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v9

    const/16 v6, 0x157

    invoke-virtual {v8, v9}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->k(Ljava/lang/String;)V

    const/16 v6, 0x367

    sput v11, Lmi2;->g:I

    :catch_dd
    :goto_dd
    const/16 v6, 0x1c

    iget-boolean v9, v8, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    nop

    const/16 v6, 0xb91

    iget-object v13, v8, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h:Lou;

    nop

    const/16 v6, 0xfa

    iget-object v6, v8, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->a:Lcom/tlsvpn/tlstunnel/services/ServicoVpn;

    move-object/16 v16, v6

    if-eqz v9, :cond_a3a

    const-string/jumbo v9, "7300"

    const/16 v6, 0x142

    move-object/from16 v0, v16

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v17

    const/4 v6, -0x6

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xf1

    iget-boolean v6, v13, Lou;->c:Z

    move/16 v18, v6

    if-eqz v18, :cond_10b

    goto :goto_10c

    :cond_10b
    move v15, v11

    :goto_10c
    const/16 v6, 0xcbf

    iget-object v6, v8, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b:Landroid/content/SharedPreferences;

    move-object/16 v18, v6

    const/16 v6, 0x4fe

    move-object/from16 v0, v18

    move-object/from16 v1, v17

    invoke-static {v0, v1, v15}, Lqk;->p(Landroid/content/SharedPreferences;Landroid/content/res/Resources;I)[Ljava/lang/String;

    move-result-object v15

    const/16 v6, 0xbdf

    iput-object v15, v8, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->f:[Ljava/lang/String;

    const/16 v6, 0x142

    move-object/from16 v0, v16

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v15

    const v17, 0x7f030005

    const/16 v6, 0x3e2

    move/from16 v0, v17

    invoke-virtual {v15, v0}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v15

    const/4 v6, -0x6

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xfe4

    iput-object v15, v8, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->g:[Ljava/lang/String;

    const-string/jumbo v15, "intranet"

    const/16 v6, 0x77

    move-object/from16 v0, v18

    invoke-interface {v0, v15, v11}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v15

    const/16 v6, 0x834

    iput-boolean v15, v8, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->m:Z

    const-string/jumbo v15, "compresspkt"

    const/16 v6, 0x77

    move-object/from16 v0, v18

    invoke-interface {v0, v15, v11}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v15

    const/16 v6, 0x5a7

    iput-boolean v15, v8, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->n:Z

    const-string/jumbo v15, "encdns"

    const/16 v6, 0x77

    move-object/from16 v0, v18

    invoke-interface {v0, v15, v10}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v15

    const/16 v6, 0x112d

    iput-boolean v15, v8, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->o:Z

    const-string/jumbo v15, "osdns"

    const/16 v6, 0x77

    move-object/from16 v0, v18

    invoke-interface {v0, v15, v10}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v15

    const/16 v6, 0xf3b

    iput-boolean v15, v8, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->p:Z

    const-string/jumbo v15, "dnsP"

    const-string/jumbo v17, "8.8.8.8"

    const/16 v6, 0x2e

    move-object/from16 v0, v18

    move-object/from16 v1, v17

    invoke-interface {v0, v15, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    const/4 v6, -0x6

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x11d2

    iput-object v15, v8, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->r:Ljava/lang/String;

    const-string/jumbo v15, "dnsS"

    const-string/jumbo v17, "1.1.1.1"

    const/16 v6, 0x2e

    move-object/from16 v0, v18

    move-object/from16 v1, v17

    invoke-interface {v0, v15, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    const/4 v6, -0x6

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xfb3

    iput-object v15, v8, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->s:Ljava/lang/String;

    const-string/jumbo v15, "appfilter"

    const/16 v6, 0x77

    move-object/from16 v0, v18

    invoke-interface {v0, v15, v11}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v15

    const/16 v6, 0x69e

    iput-boolean v15, v8, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->L:Z

    const-string/jumbo v15, "appfilter_mode"

    const/16 v6, 0x77

    move-object/from16 v0, v18

    invoke-interface {v0, v15, v10}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v15

    const/16 v6, 0x1203

    iput-boolean v15, v8, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->M:Z

    const-string/jumbo v15, "checkedapps"

    const/16 v6, 0xc01

    sget-object v17, Lea0;->a:Lea0;

    nop

    const/16 v6, 0x514

    move-object/from16 v0, v18

    move-object/from16 v1, v17

    invoke-interface {v0, v15, v1}, Landroid/content/SharedPreferences;->getStringSet(Ljava/lang/String;Ljava/util/Set;)Ljava/util/Set;

    move-result-object v19

    const/4 v6, -0x6

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xeb5

    move-object/from16 v0, v19

    iput-object v0, v8, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->N:Ljava/util/Set;

    :try_start_1e4
    const-string/jumbo v19, "udpgwport"

    const/16 v6, 0x2e

    move-object/from16 v0, v18

    move-object/from16 v1, v19

    invoke-interface {v0, v1, v9}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v19

    const/4 v6, -0x6

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x8e

    move-object/from16 v0, v19

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v9
    :try_end_1ff
    .catch Ljava/lang/Exception; {:try_start_1e4 .. :try_end_1ff} :catch_200

    goto :goto_206

    :catch_200
    const/16 v6, 0x8e

    invoke-static {v9}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v9

    :goto_206
    const/16 v6, 0xec2

    iput v9, v8, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->q:I

    const/16 v6, 0x7ec

    iget-boolean v9, v13, Lou;->y:Z

    nop

    const/16 v19, 0x4

    const-string/jumbo v20, "restoreHome"

    const/high16 v23, 0x10000000

    move-object/from16 v24, v14

    const-string/jumbo v14, ""

    if-eqz v9, :cond_564

    const/16 v6, 0xa5c

    move-object/from16 v0, v16

    invoke-static {v0}, Lmi2;->f(Landroid/content/Context;)Z

    move-result v9

    if-eqz v9, :cond_564

    const/16 v6, 0x195

    sget-boolean v9, Lmi2;->d:Z

    nop

    if-eqz v9, :cond_251

    const/16 v6, 0x175

    new-instance v9, Lfm2;

    nop

    const/16 v6, 0x16f

    move/from16 v0, v19

    invoke-direct {v9, v8, v0}, Lfm2;-><init>(Lcom/tlsvpn/tlstunnel/services/VpnConnection;I)V

    const/16 v6, 0xde

    sget-boolean v12, Lg4;->j:Z

    nop

    if-nez v12, :cond_247

    const/16 v6, 0x197

    invoke-virtual {v9}, Lfm2;->invoke()Ljava/lang/Object;

    goto :goto_251

    :cond_247
    const/16 v6, 0x154

    sget-object v12, Lg4;->m:Ljava/util/ArrayList;

    nop

    const/16 v6, 0x174

    invoke-virtual {v12, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_251
    :goto_251
    const/16 v6, 0x5b

    new-instance v9, Landroid/content/Intent;

    nop

    const-string/jumbo v12, "resetCfgFromMain"

    const/16 v6, 0x62

    invoke-direct {v9, v12}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v6, 0x53

    move-object/from16 v0, v16

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v12

    const/16 v6, 0x4a

    invoke-virtual {v12}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v12

    const/16 v6, 0x64

    invoke-virtual {v9, v12}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v9

    const/16 v6, 0x59

    move/from16 v0, v23

    invoke-virtual {v9, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v9

    const/16 v6, 0x63

    move-object/from16 v0, v16

    invoke-virtual {v0, v9}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    const-string/jumbo v9, "cname"

    const/16 v6, 0x77

    move-object/from16 v0, v18

    invoke-interface {v0, v9, v10}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v12

    const-string/jumbo v19, "reviewRequested"

    move/from16 v25, v10

    const/16 v6, 0x77

    move-object/from16 v0, v18

    move-object/from16 v1, v19

    invoke-interface {v0, v1, v11}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v10

    const/16 v6, 0x514

    move-object/from16 v0, v18

    move-object/from16 v1, v17

    invoke-interface {v0, v15, v1}, Landroid/content/SharedPreferences;->getStringSet(Ljava/lang/String;Ljava/util/Set;)Ljava/util/Set;

    move-result-object v17

    const/4 v6, -0x6

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string/jumbo v23, "osrvlistid"

    const/16 v6, 0x2e

    move-object/from16 v0, v18

    move-object/from16 v1, v23

    invoke-interface {v0, v1, v14}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v21

    const-string/jumbo v22, "osrvlist"

    move/from16 v28, v11

    const/16 v6, 0x2e

    move-object/from16 v0, v18

    move-object/from16 v1, v22

    invoke-interface {v0, v1, v14}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const-string/jumbo v8, "psrvlistid"

    move-object/from16 v29, v13

    const/16 v6, 0x2e

    move-object/from16 v0, v18

    invoke-interface {v0, v8, v14}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    move-object/from16 v30, v16

    const-string/jumbo v16, "psrvlist"

    const/16 v6, 0x2e

    move-object/from16 v0, v18

    move-object/from16 v1, v16

    invoke-interface {v0, v1, v14}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    move-object/from16 v31, v20

    const/16 v6, 0x98

    move/from16 v0, v28

    invoke-static {v0}, Lmi2;->c(Z)Ljava/lang/String;

    move-result-object v20

    move-object/from16 v24, v14

    const-string/jumbo v14, "Bs6dlTz"

    const/16 v6, 0x2e

    move-object/from16 v0, v18

    move-object/from16 v1, v20

    invoke-interface {v0, v14, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v20

    move-object/from16 v32, v14

    const/16 v6, 0x98

    move/from16 v0, v25

    invoke-static {v0}, Lmi2;->c(Z)Ljava/lang/String;

    move-result-object v14

    move-object/from16 v33, v20

    const-string/jumbo v20, "lA4dtxV"

    const/16 v6, 0x2e

    move-object/from16 v0, v18

    move-object/from16 v1, v20

    invoke-interface {v0, v1, v14}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    move-object/from16 v34, v20

    const-string/jumbo v20, "PkHfz5S"

    move-object/from16 v35, v14

    move-object/from16 v36, v16

    move/from16 v14, v28

    const/16 v6, 0xb0

    move-object/from16 v0, v18

    move-object/from16 v1, v20

    invoke-interface {v0, v1, v14}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v16

    move-object/from16 v37, v20

    const-string/jumbo v20, "VkB8aR"

    move/from16 v38, v16

    const/16 v6, 0xb0

    move-object/from16 v0, v18

    move-object/from16 v1, v20

    invoke-interface {v0, v1, v14}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v16

    const/16 v6, 0x98

    move/from16 v0, v28

    invoke-static {v0}, Lmi2;->c(Z)Ljava/lang/String;

    move-result-object v14

    move-object/from16 v39, v20

    const-string/jumbo v20, "ks6dlFx"

    const/16 v6, 0x2e

    move-object/from16 v0, v18

    move-object/from16 v1, v20

    invoke-interface {v0, v1, v14}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    move-object/from16 v40, v14

    const/16 v6, 0x98

    move/from16 v0, v25

    invoke-static {v0}, Lmi2;->c(Z)Ljava/lang/String;

    move-result-object v14

    move/from16 v41, v16

    const-string/jumbo v16, "hAPdtA1"

    const/16 v6, 0x2e

    move-object/from16 v0, v18

    move-object/from16 v1, v16

    invoke-interface {v0, v1, v14}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    move-object/from16 v42, v14

    const-string/jumbo v14, "fTHfz4g"

    move-object/from16 v43, v16

    move-object/from16 v44, v20

    move/from16 v16, v28

    const/16 v6, 0xb0

    move-object/from16 v0, v18

    move/from16 v1, v16

    invoke-interface {v0, v14, v1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v20

    move/from16 v45, v20

    const-string/jumbo v20, "sR3sd4"

    move-object/from16 v46, v14

    const/16 v6, 0xb0

    move-object/from16 v0, v18

    move-object/from16 v1, v20

    move/from16 v2, v16

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v14

    const/16 v6, 0x98

    move/from16 v0, v28

    invoke-static {v0}, Lmi2;->c(Z)Ljava/lang/String;

    move-result-object v16

    move/from16 v47, v14

    const-string/jumbo v14, "gd4Lrfa"

    const/16 v6, 0x2e

    move-object/from16 v0, v18

    move-object/from16 v1, v16

    invoke-interface {v0, v14, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v16

    move-object/from16 v48, v14

    const/16 v6, 0x98

    move/from16 v0, v25

    invoke-static {v0}, Lmi2;->c(Z)Ljava/lang/String;

    move-result-object v14

    move-object/from16 v49, v16

    const-string/jumbo v16, "Ss5fGn2"

    const/16 v6, 0x2e

    move-object/from16 v0, v18

    move-object/from16 v1, v16

    invoke-interface {v0, v1, v14}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    move-object/from16 v50, v14

    const-string/jumbo v14, "drVw5ad"

    move-object/from16 v51, v16

    move-object/from16 v52, v20

    move/from16 v16, v28

    const/16 v6, 0xb0

    move-object/from16 v0, v18

    move/from16 v1, v16

    invoke-interface {v0, v14, v1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v20

    move-object/from16 v53, v14

    const-string/jumbo v14, "adXs5SFd"

    move/from16 v54, v20

    const/16 v6, 0xb0

    move-object/from16 v0, v18

    move/from16 v1, v16

    invoke-interface {v0, v14, v1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v20

    const-string/jumbo v16, "lrtms"

    move-object/from16 v55, v13

    move-object/from16 v56, v14

    move/from16 v27, v20

    move-object/from16 v26, v21

    const-wide/16 v13, 0x0

    const/16 v6, 0x46e

    move-object/from16 v0, v18

    move-object/from16 v1, v16

    invoke-interface {v0, v1, v13, v14}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v20

    move-object/from16 v57, v16

    const-string/jumbo v16, "nrtms"

    const/16 v6, 0x46e

    move-object/from16 v0, v18

    move-object/from16 v1, v16

    invoke-interface {v0, v1, v13, v14}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide v13

    const/16 v6, 0x7a

    move-object/from16 v0, v18

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v18

    const/16 v6, 0xb45

    move-object/from16 v0, v18

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->clear()Landroid/content/SharedPreferences$Editor;

    move-wide/from16 v58, v13

    const-string/jumbo v13, "tlsvpnVersion"

    const/16 v14, 0x1f2

    const/16 v6, 0x56

    move-object/from16 v0, v18

    invoke-interface {v0, v13, v14}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const-string/jumbo v13, "firstopen"

    const/4 v14, 0x0

    const/16 v6, 0x48

    move-object/from16 v0, v18

    invoke-interface {v0, v13, v14}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const-string/jumbo v13, "dmode"

    const/16 v6, 0xa89

    sget-boolean v14, Lmi2;->h:Z

    nop

    const/16 v6, 0x48

    move-object/from16 v0, v18

    invoke-interface {v0, v13, v14}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/16 v6, 0x48

    move-object/from16 v0, v18

    invoke-interface {v0, v9, v12}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/16 v6, 0x48

    move-object/from16 v0, v18

    move-object/from16 v1, v19

    invoke-interface {v0, v1, v10}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/16 v6, 0x123d

    move-object/from16 v0, v18

    move-object/from16 v1, v17

    invoke-interface {v0, v15, v1}, Landroid/content/SharedPreferences$Editor;->putStringSet(Ljava/lang/String;Ljava/util/Set;)Landroid/content/SharedPreferences$Editor;

    move-object/from16 v9, v26

    const/16 v6, 0x3c

    move-object/from16 v0, v18

    move-object/from16 v1, v23

    invoke-interface {v0, v1, v9}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v6, 0x3c

    move-object/from16 v0, v18

    move-object/from16 v1, v22

    invoke-interface {v0, v1, v11}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-object/from16 v9, v55

    const/16 v6, 0x3c

    move-object/from16 v0, v18

    invoke-interface {v0, v8, v9}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-object/from16 v8, v24

    move-object/from16 v9, v36

    const/16 v6, 0x3c

    move-object/from16 v0, v18

    invoke-interface {v0, v9, v8}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-object/from16 v8, v33

    move-object/from16 v9, v44

    const/16 v6, 0x3c

    move-object/from16 v0, v18

    invoke-interface {v0, v9, v8}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-object/from16 v8, v35

    move-object/from16 v9, v43

    const/16 v6, 0x3c

    move-object/from16 v0, v18

    invoke-interface {v0, v9, v8}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move/from16 v8, v38

    move-object/from16 v9, v46

    const/16 v6, 0x56

    move-object/from16 v0, v18

    invoke-interface {v0, v9, v8}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move/from16 v8, v41

    move-object/from16 v9, v52

    const/16 v6, 0x56

    move-object/from16 v0, v18

    invoke-interface {v0, v9, v8}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-object/from16 v9, v32

    move-object/from16 v8, v40

    const/16 v6, 0x3c

    move-object/from16 v0, v18

    invoke-interface {v0, v9, v8}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-object/from16 v9, v34

    move-object/from16 v8, v42

    const/16 v6, 0x3c

    move-object/from16 v0, v18

    invoke-interface {v0, v9, v8}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-object/from16 v9, v37

    move/from16 v8, v45

    const/16 v6, 0x56

    move-object/from16 v0, v18

    invoke-interface {v0, v9, v8}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-object/from16 v9, v39

    move/from16 v8, v47

    const/16 v6, 0x56

    move-object/from16 v0, v18

    invoke-interface {v0, v9, v8}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-object/from16 v9, v48

    move-object/from16 v8, v49

    const/16 v6, 0x3c

    move-object/from16 v0, v18

    invoke-interface {v0, v9, v8}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-object/from16 v8, v50

    move-object/from16 v9, v51

    const/16 v6, 0x3c

    move-object/from16 v0, v18

    invoke-interface {v0, v9, v8}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    move-object/from16 v9, v53

    move/from16 v8, v54

    const/16 v6, 0x56

    move-object/from16 v0, v18

    invoke-interface {v0, v9, v8}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move/from16 v8, v27

    move-object/from16 v9, v56

    const/16 v6, 0x56

    move-object/from16 v0, v18

    invoke-interface {v0, v9, v8}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    move-object/from16 v8, v57

    const/16 v6, 0x37a

    move-object/from16 v0, v18

    move-wide/from16 v1, v20

    invoke-interface {v0, v8, v1, v2}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    move-wide/from16 v8, v58

    const/16 v6, 0x37a

    move-object/from16 v0, v18

    move-object/from16 v1, v16

    invoke-interface {v0, v1, v8, v9}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    const/16 v6, 0x6f

    move-object/from16 v0, v18

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/16 v6, 0x6f

    move-object/from16 v0, v18

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/16 v6, 0x5b

    new-instance v8, Landroid/content/Intent;

    nop

    move-object/from16 v9, v31

    const/16 v6, 0x62

    invoke-direct {v8, v9}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v6, 0x53

    move-object/from16 v0, v30

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v9

    const/16 v6, 0x4a

    invoke-virtual {v9}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v9

    const/16 v6, 0x64

    invoke-virtual {v8, v9}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v8

    const/high16 v9, 0x10000000

    const/16 v6, 0x59

    invoke-virtual {v8, v9}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v8

    move-object/from16 v10, v30

    const/16 v6, 0x63

    invoke-virtual {v10, v8}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    move-object/from16 v12, p0

    move-object/from16 v8, v29

    goto/16 :goto_a3e

    :cond_564
    move/from16 v25, v10

    move-object/from16 v10, v16

    move-object/from16 v9, v20

    move-object v8, v13

    const/16 v6, 0x9d

    iget-boolean v11, v8, Lou;->h:Z

    nop

    const-string/jumbo v13, "T "

    if-nez v11, :cond_9be

    const/16 v6, 0x7a

    move-object/from16 v0, v18

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v11

    const/16 v6, 0x11f

    iget v15, v8, Lou;->d:I

    nop

    const-string/jumbo v16, "Array is empty."

    const-string/jumbo v17, "port"

    const-string/jumbo v22, "cspl"

    const-string/jumbo v23, "cTp"

    const-wide/16 v29, 0x1388

    const-string/jumbo v20, "cId"

    const-string/jumbo v21, "CONSULTSTATUS"

    const-class v19, Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;

    const-string/jumbo v18, "SERVERRPL"

    move-object/from16 v12, p0

    move-object/from16 v35, v14

    const/16 v6, 0xe19

    iget-object v14, v12, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->K:Lhm2;

    nop

    const-string/jumbo v36, "servidores"

    const-string/jumbo v37, "portas"

    move-object/from16 v38, v16

    if-eqz v15, :cond_5ce

    const/16 v6, 0x110

    iget-object v6, v12, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->f:[Ljava/lang/String;

    move-object/16 v16, v6

    if-eqz v16, :cond_5c7

    move-object/from16 v0, v16

    array-length v0, v0

    move/from16 v16, v0

    move/from16 v0, v16

    if-lt v15, v0, :cond_5c1

    goto :goto_5ce

    :cond_5c1
    move-object/from16 v39, v9

    move-object/from16 v40, v19

    goto/16 :goto_763

    :cond_5c7
    const/4 v6, 0x5

    move-object/from16 v0, v36

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_5ce
    :goto_5ce
    const v15, 0x7f130238

    const/4 v6, 0x7

    invoke-virtual {v12, v15}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v16

    move-object/from16 v39, v9

    const/4 v9, 0x0

    const/16 v6, 0x163

    move-object/from16 v0, v16

    invoke-virtual {v12, v0, v9}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->a(Ljava/lang/String;Z)V

    const/4 v6, 0x7

    invoke-virtual {v12, v15}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v9

    const/16 v6, 0x157

    invoke-virtual {v12, v9}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->k(Ljava/lang/String;)V

    const/16 v6, 0x5b

    new-instance v9, Landroid/content/Intent;

    nop

    const/16 v6, 0xd0

    move-object/from16 v0, v19

    invoke-direct {v9, v10, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/16 v6, 0x123

    sget-object v15, Lpp1;->a:Lv0;

    nop

    const/16 v6, 0x123

    sget-object v15, Lpp1;->a:Lv0;

    nop

    move-object/from16 v40, v19

    const v16, 0x19000

    const/16 v6, 0x16d

    move/from16 v0, v16

    invoke-virtual {v15, v0}, Lv0;->l(I)I

    move-result v19

    const/16 v6, 0x1c8

    move/from16 v0, v19

    iput v0, v12, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->J:I

    const/16 v6, 0x48f

    move-object/from16 v0, v21

    invoke-virtual {v9, v0}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    const/16 v6, 0x419

    iget v6, v12, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->J:I

    move/16 v16, v6

    const/16 v6, 0x29

    move-object/from16 v0, v20

    move/from16 v1, v16

    invoke-virtual {v9, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/16 v16, 0x0

    const/16 v6, 0x29

    move-object/from16 v0, v23

    move/from16 v1, v16

    invoke-virtual {v9, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/16 v6, 0xf1

    iget-boolean v6, v8, Lou;->c:Z

    move/16 v16, v6

    const/16 v6, 0x178

    move-object/from16 v0, v22

    move/from16 v1, v16

    invoke-virtual {v9, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    const/16 v6, 0x1fc

    sget v16, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 v19, 0x21

    move/from16 v0, v16

    move/from16 v1, v19

    if-ge v0, v1, :cond_668

    const/16 v6, 0x1f

    new-instance v16, Landroid/content/IntentFilter;

    nop

    const/16 v6, 0x1d

    move-object/from16 v0, v16

    move-object/from16 v1, v18

    invoke-direct {v0, v1}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v6, 0x3a

    move-object/from16 v0, v16

    invoke-virtual {v10, v14, v0}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    goto :goto_681

    :cond_668
    const/16 v6, 0x1f

    new-instance v16, Landroid/content/IntentFilter;

    nop

    const/16 v6, 0x1d

    move-object/from16 v0, v16

    move-object/from16 v1, v18

    invoke-direct {v0, v1}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v19, 0x4

    const/16 v6, 0xbf

    move-object/from16 v0, v16

    move/from16 v1, v19

    invoke-virtual {v10, v14, v0, v1}, Landroid/net/VpnService;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    :goto_681
    const/16 v6, 0x1c

    iget-boolean v6, v12, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    move/16 v16, v6

    if-nez v16, :cond_68c

    goto/16 :goto_a3e

    :cond_68c
    :try_start_68c
    const/16 v6, 0x4a7

    invoke-virtual {v10, v9}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    const/16 v6, 0x209

    move-wide/from16 v0, v29

    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V

    const/16 v6, 0x345

    invoke-virtual {v10, v14}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    const/16 v6, 0x1c

    iget-boolean v9, v12, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    nop
    :try_end_6a2
    .catch Ljava/lang/Exception; {:try_start_68c .. :try_end_6a2} :catch_a3e

    if-nez v9, :cond_6a6

    goto/16 :goto_a3e

    :cond_6a6
    const/16 v6, 0x11f

    iget v9, v8, Lou;->d:I

    nop

    if-lez v9, :cond_711

    const/16 v6, 0x110

    iget-object v6, v12, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->f:[Ljava/lang/String;

    move-object/16 v16, v6

    if-eqz v16, :cond_70a

    move-object/from16 v0, v16

    array-length v0, v0

    move/from16 v16, v0

    move/from16 v0, v16

    if-ge v9, v0, :cond_711

    const-string/jumbo v9, "psrvslctd"

    const/16 v6, 0xf1

    iget-boolean v15, v8, Lou;->c:Z

    nop

    const/16 v6, 0x48

    invoke-interface {v11, v9, v15}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v9

    const-string/jumbo v15, "server"

    const/16 v6, 0x11f

    iget v6, v8, Lou;->d:I

    move/16 v16, v6

    const/16 v6, 0x56

    move/from16 v0, v16

    invoke-interface {v9, v15, v0}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/16 v6, 0x32

    iget v9, v8, Lou;->e:I

    nop

    if-lez v9, :cond_6f7

    const/16 v6, 0xa7

    iget-object v15, v12, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->g:[Ljava/lang/String;

    nop

    if-eqz v15, :cond_6fa

    array-length v15, v15

    if-ge v9, v15, :cond_6f7

    const/16 v6, 0x56

    move-object/from16 v0, v17

    invoke-interface {v11, v0, v9}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    goto :goto_707

    :cond_6f7
    const/16 v16, 0x0

    goto :goto_701

    :cond_6fa
    const/4 v6, 0x5

    move-object/from16 v0, v37

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :goto_701
    const/16 v6, 0x103

    move/from16 v0, v16

    iput v0, v8, Lou;->d:I

    :goto_707
    move/from16 v9, v25

    goto :goto_764

    :cond_70a
    const/4 v6, 0x5

    move-object/from16 v0, v36

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_711
    const/16 v6, 0x110

    iget-object v9, v12, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->f:[Ljava/lang/String;

    nop

    if-eqz v9, :cond_9b7

    array-length v0, v9

    move/from16 v16, v0

    move/from16 v19, v25

    move/from16 v0, v16

    move/from16 v1, v19

    if-le v0, v1, :cond_74d

    array-length v0, v9

    move/from16 v16, v0

    const/16 v6, 0x218

    move/from16 v0, v19

    move/from16 v1, v16

    invoke-static {v9, v0, v1}, Laf;->h0([Ljava/lang/Object;II)[Ljava/lang/Object;

    move-result-object v9

    array-length v0, v9

    move/from16 v16, v0

    if-eqz v16, :cond_745

    array-length v0, v9

    move/from16 v16, v0

    const/16 v6, 0x16d

    move/from16 v0, v16

    invoke-virtual {v15, v0}, Lv0;->l(I)I

    move-result v15

    aget-object v9, v9, v15

    check-cast v9, Ljava/lang/String;

    goto :goto_75b

    :cond_745
    const/16 v6, 0x4f9

    move-object/from16 v0, v38

    invoke-static {v0}, Lpw1;->m(Ljava/lang/String;)V

    return-void

    :cond_74d
    array-length v15, v9

    if-nez v15, :cond_753

    move-object/from16 v9, v24

    goto :goto_757

    :cond_753
    const/16 v28, 0x0

    aget-object v9, v9, v28

    :goto_757
    if-nez v9, :cond_75b

    move-object/from16 v9, v35

    :cond_75b
    :goto_75b
    const/4 v6, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x244

    iput-object v9, v8, Lou;->i:Ljava/lang/String;

    :goto_763
    const/4 v9, 0x0

    :goto_764
    const/16 v6, 0x32

    iget v15, v8, Lou;->e:I

    nop

    if-eqz v15, :cond_7b7

    const/16 v6, 0xa7

    iget-object v6, v12, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->g:[Ljava/lang/String;

    move-object/16 v16, v6

    if-eqz v16, :cond_7b0

    move-object/from16 v0, v16

    array-length v0, v0

    move/from16 v19, v0

    move/from16 v0, v19

    if-lt v15, v0, :cond_77e

    goto :goto_7b7

    :cond_77e
    move-object/from16 v0, v16

    array-length v14, v0

    const/16 v25, 0x1

    add-int/lit8 v14, v14, -0x1

    if-ne v15, v14, :cond_7a4

    const/4 v6, -0x3

    new-instance v14, Ljava/lang/StringBuilder;

    nop

    const/16 v6, 0x97

    invoke-direct {v14, v13}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v6, 0xe1

    iget-object v13, v8, Lou;->f:Ljava/lang/String;

    nop

    const/4 v6, 0x0

    invoke-virtual {v14, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, -0x2

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v13

    const/16 v6, 0xdb

    iput-object v13, v8, Lou;->g:Ljava/lang/String;

    goto/16 :goto_96a

    :cond_7a4
    aget-object v13, v16, v15

    const/4 v6, -0x6

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xdb

    iput-object v13, v8, Lou;->g:Ljava/lang/String;

    goto/16 :goto_96a

    :cond_7b0
    const/4 v6, 0x5

    move-object/from16 v0, v37

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_7b7
    :goto_7b7
    const v15, 0x7f130239

    const/4 v6, 0x7

    invoke-virtual {v12, v15}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v16

    const/16 v19, 0x0

    const/16 v6, 0x163

    move-object/from16 v0, v16

    move/from16 v1, v19

    invoke-virtual {v12, v0, v1}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->a(Ljava/lang/String;Z)V

    const/4 v6, 0x7

    invoke-virtual {v12, v15}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h(I)Ljava/lang/String;

    move-result-object v15

    const/16 v6, 0x157

    invoke-virtual {v12, v15}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->k(Ljava/lang/String;)V

    const/16 v6, 0x5b

    new-instance v15, Landroid/content/Intent;

    nop

    move-object/from16 v16, v40

    const/16 v6, 0xd0

    move-object/from16 v0, v16

    invoke-direct {v15, v10, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/16 v6, 0x123

    sget-object v16, Lpp1;->a:Lv0;

    nop

    const/16 v6, 0x123

    sget-object v16, Lpp1;->a:Lv0;

    nop

    const v19, 0x19000

    const/16 v6, 0x16d

    move-object/from16 v0, v16

    move/from16 v1, v19

    invoke-virtual {v0, v1}, Lv0;->l(I)I

    move-result v19

    const/16 v6, 0x1c8

    move/from16 v0, v19

    iput v0, v12, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->J:I

    const/16 v6, 0x48f

    move-object/from16 v0, v21

    invoke-virtual {v15, v0}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    const/16 v6, 0x419

    iget v6, v12, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->J:I

    move/16 v19, v6

    const/16 v6, 0x29

    move-object/from16 v0, v20

    move/from16 v1, v19

    invoke-virtual {v15, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string/jumbo v19, "srv"

    const/16 v6, 0x3b

    iget-object v6, v8, Lou;->i:Ljava/lang/String;

    move-object/16 v20, v6

    const/16 v6, 0x4b

    move-object/from16 v0, v19

    move-object/from16 v1, v20

    invoke-virtual {v15, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/16 v19, 0x0

    const/16 v6, 0x29

    move-object/from16 v0, v23

    move/from16 v1, v19

    invoke-virtual {v15, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/16 v6, 0xf1

    iget-boolean v6, v8, Lou;->c:Z

    move/16 v19, v6

    const/16 v6, 0x178

    move-object/from16 v0, v22

    move/from16 v1, v19

    invoke-virtual {v15, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    const/16 v6, 0x1fc

    sget v19, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 v20, 0x21

    move/from16 v0, v19

    move/from16 v1, v20

    if-ge v0, v1, :cond_867

    const/16 v6, 0x1f

    new-instance v19, Landroid/content/IntentFilter;

    nop

    const/16 v6, 0x1d

    move-object/from16 v0, v19

    move-object/from16 v1, v18

    invoke-direct {v0, v1}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v6, 0x3a

    move-object/from16 v0, v19

    invoke-virtual {v10, v14, v0}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    goto :goto_880

    :cond_867
    const/16 v6, 0x1f

    new-instance v19, Landroid/content/IntentFilter;

    nop

    const/16 v6, 0x1d

    move-object/from16 v0, v19

    move-object/from16 v1, v18

    invoke-direct {v0, v1}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v18, 0x4

    const/16 v6, 0xbf

    move-object/from16 v0, v19

    move/from16 v1, v18

    invoke-virtual {v10, v14, v0, v1}, Landroid/net/VpnService;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    :goto_880
    const/16 v6, 0x1c

    iget-boolean v6, v12, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    move/16 v18, v6

    if-nez v18, :cond_88b

    goto/16 :goto_a3e

    :cond_88b
    :try_start_88b
    const/16 v6, 0x4a7

    invoke-virtual {v10, v15}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    const/16 v6, 0x209

    move-wide/from16 v0, v29

    invoke-static {v0, v1}, Ljava/lang/Thread;->sleep(J)V

    const/16 v6, 0x345

    invoke-virtual {v10, v14}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    const/16 v6, 0x1c

    iget-boolean v14, v12, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    nop
    :try_end_8a1
    .catch Ljava/lang/Exception; {:try_start_88b .. :try_end_8a1} :catch_a3e

    if-nez v14, :cond_8a5

    goto/16 :goto_a3e

    :cond_8a5
    const/16 v6, 0x32

    iget v14, v8, Lou;->e:I

    nop

    if-lez v14, :cond_903

    const/16 v6, 0xa7

    iget-object v15, v12, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->g:[Ljava/lang/String;

    nop

    if-eqz v15, :cond_8fc

    array-length v15, v15

    if-ge v14, v15, :cond_903

    const/16 v6, 0x56

    move-object/from16 v0, v17

    invoke-interface {v11, v0, v14}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/16 v6, 0x32

    iget v9, v8, Lou;->e:I

    nop

    const/16 v6, 0xa7

    iget-object v14, v12, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->g:[Ljava/lang/String;

    nop

    if-eqz v14, :cond_8f5

    array-length v15, v14

    const/16 v25, 0x1

    add-int/lit8 v15, v15, -0x1

    if-ne v9, v15, :cond_8e8

    const/4 v6, -0x3

    new-instance v9, Ljava/lang/StringBuilder;

    nop

    const/16 v6, 0x97

    invoke-direct {v9, v13}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v6, 0xe1

    iget-object v13, v8, Lou;->f:Ljava/lang/String;

    nop

    const/4 v6, 0x0

    invoke-virtual {v9, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, -0x2

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    goto :goto_8ea

    :cond_8e8
    aget-object v9, v14, v9

    :goto_8ea
    const/4 v6, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xdb

    iput-object v9, v8, Lou;->g:Ljava/lang/String;

    const/16 v19, 0x1

    goto :goto_96c

    :cond_8f5
    const/4 v6, 0x5

    move-object/from16 v0, v37

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_8fc
    const/4 v6, 0x5

    move-object/from16 v0, v37

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_903
    const/16 v6, 0xa7

    iget-object v13, v12, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->g:[Ljava/lang/String;

    nop

    if-eqz v13, :cond_9b0

    array-length v14, v13

    const/4 v15, 0x2

    if-le v14, v15, :cond_934

    array-length v14, v13

    const/16 v19, 0x1

    sub-int v14, v14, v19

    const/16 v6, 0x218

    move/from16 v0, v19

    invoke-static {v13, v0, v14}, Laf;->h0([Ljava/lang/Object;II)[Ljava/lang/Object;

    move-result-object v13

    array-length v14, v13

    if-eqz v14, :cond_92c

    array-length v14, v13

    const/16 v6, 0x16d

    move-object/from16 v0, v16

    invoke-virtual {v0, v14}, Lv0;->l(I)I

    move-result v14

    aget-object v13, v13, v14

    check-cast v13, Ljava/lang/String;

    goto :goto_962

    :cond_92c
    const/16 v6, 0x4f9

    move-object/from16 v0, v38

    invoke-static {v0}, Lpw1;->m(Ljava/lang/String;)V

    return-void

    :cond_934
    const/16 v19, 0x1

    const/16 v6, 0x5e8

    move/from16 v0, v19

    invoke-static {v0, v13}, Laf;->k0(I[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/String;

    if-nez v13, :cond_962

    const/16 v6, 0xa7

    iget-object v13, v12, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->g:[Ljava/lang/String;

    nop

    if-eqz v13, :cond_95b

    array-length v14, v13

    if-nez v14, :cond_94f

    move-object/from16 v14, v24

    goto :goto_953

    :cond_94f
    const/16 v28, 0x0

    aget-object v14, v13, v28

    :goto_953
    if-nez v14, :cond_959

    const-string/jumbo v13, "443"

    goto :goto_962

    :cond_959
    move-object v13, v14

    goto :goto_962

    :cond_95b
    const/4 v6, 0x5

    move-object/from16 v0, v37

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_962
    :goto_962
    const/4 v6, -0x6

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xdb

    iput-object v13, v8, Lou;->g:Ljava/lang/String;

    :goto_96a
    move/from16 v19, v9

    :goto_96c
    const/16 v6, 0x1c

    iget-boolean v9, v12, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->D:Z

    nop

    if-nez v9, :cond_975

    goto/16 :goto_a3e

    :cond_975
    const/16 v16, 0x0

    const/16 v6, 0x1c8

    move/from16 v0, v16

    iput v0, v12, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->J:I

    if-eqz v19, :cond_9db

    const/16 v6, 0x6f

    invoke-interface {v11}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/16 v6, 0x5b

    new-instance v9, Landroid/content/Intent;

    nop

    move-object/from16 v11, v39

    const/16 v6, 0x62

    invoke-direct {v9, v11}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v6, 0x53

    invoke-virtual {v10}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v11

    const/16 v6, 0x4a

    invoke-virtual {v11}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v11

    const/16 v6, 0x64

    invoke-virtual {v9, v11}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v9

    const/high16 v11, 0x10000000

    const/16 v6, 0x59

    invoke-virtual {v9, v11}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v9

    const/16 v6, 0x63

    invoke-virtual {v10, v9}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    goto :goto_9db

    :cond_9b0
    const/4 v6, 0x5

    move-object/from16 v0, v37

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_9b7
    const/4 v6, 0x5

    move-object/from16 v0, v36

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v24

    :cond_9be
    move-object/from16 v12, p0

    const/4 v6, -0x3

    new-instance v9, Ljava/lang/StringBuilder;

    nop

    const/16 v6, 0x97

    invoke-direct {v9, v13}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v6, 0x34b

    iget-object v11, v8, Lou;->j:Ljava/lang/String;

    nop

    const/4 v6, 0x0

    invoke-virtual {v9, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, -0x2

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    const/16 v6, 0xdb

    iput-object v9, v8, Lou;->g:Ljava/lang/String;

    :cond_9db
    :goto_9db
    const/16 v6, 0x905

    sget-boolean v9, Lmi2;->a:Z

    nop

    const/16 v6, 0xf1

    iget-boolean v9, v8, Lou;->c:Z

    nop

    const/16 v6, 0xe04

    sput-boolean v9, Lmi2;->l:Z

    const/16 v6, 0x3b

    iget-object v9, v8, Lou;->i:Ljava/lang/String;

    nop

    const/4 v6, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xe86

    sput-object v9, Lmi2;->m:Ljava/lang/String;

    const/16 v6, 0x285

    iget-object v9, v8, Lou;->o:Ljava/lang/String;

    nop

    const/16 v6, 0x20e

    invoke-static {v9, v8}, Lmi2;->b(Ljava/lang/String;Lou;)Ljava/lang/String;

    move-result-object v9

    const/16 v6, 0x3d4

    iput-object v9, v8, Lou;->o:Ljava/lang/String;

    const/16 v6, 0x2e3

    iget-object v9, v8, Lou;->s:Ljava/lang/String;

    nop

    const/16 v6, 0x20e

    invoke-static {v9, v8}, Lmi2;->b(Ljava/lang/String;Lou;)Ljava/lang/String;

    move-result-object v9

    const/16 v6, 0x360

    iput-object v9, v8, Lou;->s:Ljava/lang/String;

    const/16 v6, 0x26e

    iget-object v9, v8, Lou;->q:Ljava/lang/String;

    nop

    const/16 v6, 0x20e

    invoke-static {v9, v8}, Lmi2;->b(Ljava/lang/String;Lou;)Ljava/lang/String;

    move-result-object v9

    const/16 v6, 0x47f

    iput-object v9, v8, Lou;->q:Ljava/lang/String;

    const/16 v6, 0x714

    invoke-virtual {v12}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->f()J

    move-result-wide v8

    const-wide/16 v26, 0x0

    cmp-long v11, v8, v26

    if-lez v11, :cond_a43

    const/16 v6, 0x5a

    sget-object v11, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->a:Lcom/tlsvpn/tlstunnel/utils/SocketOps;

    nop

    const/16 v6, 0x3ea

    invoke-virtual {v11, v8, v9}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->x(J)V

    goto :goto_a43

    :cond_a3a
    move-object v12, v8

    move-object v8, v13

    move-object/from16 v10, v16

    :catch_a3e
    :goto_a3e
    const/16 v6, 0x20c

    invoke-virtual {v8}, Lou;->a()V

    :cond_a43
    :goto_a43
    const/16 v6, 0x380

    iget-boolean v8, v10, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->c:Z

    nop

    const/16 v25, 0x1

    xor-int/lit8 v8, v8, 0x1

    const/16 v16, 0x0

    const/16 v6, 0x82e

    move/from16 v0, v16

    invoke-virtual {v12, v8, v0}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->g(ZZ)V

    return-void
.end method
