.class public final Lcom/tlsvpn/tlstunnel/services/ServicoVpn;
.super Landroid/net/VpnService;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# annotations
.annotation build Landroid/annotation/SuppressLint;
    value = {
        "VpnServicePolicy"
    }
.end annotation


# static fields
.field public static final synthetic q:I


# instance fields
.field public a:Lcom/tlsvpn/tlstunnel/services/VpnConnection;

.field public b:Ljava/util/Timer;

.field public c:Z

.field public d:Z

.field public final e:Lw82;

.field public f:Lkg1;

.field public final g:Lw82;

.field public final h:Lw82;

.field public i:Landroid/os/ParcelFileDescriptor;

.field public j:Landroid/os/ParcelFileDescriptor;

.field public k:Landroid/content/Context;

.field public final l:Lr72;

.field public final m:Lsx;

.field public n:Lx52;

.field public final o:Lob;

.field public final p:Ldr0;


# direct methods
.method public constructor <init>()V
    .registers 6

    invoke-direct {p0}, Landroid/net/VpnService;-><init>()V

    const/4 v2, 0x1

    const/16 v0, 0xe7e

    iput-boolean v2, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->d:Z

    const/16 v0, 0x225

    new-instance v3, Lo12;

    nop

    const/4 v4, 0x0

    const/16 v0, 0x277

    invoke-direct {v3, p0, v4}, Lo12;-><init>(Lcom/tlsvpn/tlstunnel/services/ServicoVpn;I)V

    const/16 v0, 0x27a

    new-instance v4, Lw82;

    nop

    const/16 v0, 0x215

    invoke-direct {v4, v3}, Lw82;-><init>(Lzj0;)V

    const/16 v0, 0xea4

    iput-object v4, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->e:Lw82;

    const/16 v0, 0x225

    new-instance v3, Lo12;

    nop

    const/16 v0, 0x277

    invoke-direct {v3, p0, v2}, Lo12;-><init>(Lcom/tlsvpn/tlstunnel/services/ServicoVpn;I)V

    const/16 v0, 0x27a

    new-instance v2, Lw82;

    nop

    const/16 v0, 0x215

    invoke-direct {v2, v3}, Lw82;-><init>(Lzj0;)V

    const/16 v0, 0xe72

    iput-object v2, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->g:Lw82;

    const/16 v0, 0x225

    new-instance v2, Lo12;

    nop

    const/4 v3, 0x2

    const/16 v0, 0x277

    invoke-direct {v2, p0, v3}, Lo12;-><init>(Lcom/tlsvpn/tlstunnel/services/ServicoVpn;I)V

    const/16 v0, 0x27a

    new-instance v4, Lw82;

    nop

    const/16 v0, 0x215

    invoke-direct {v4, v2}, Lw82;-><init>(Lzj0;)V

    const/16 v0, 0x770

    iput-object v4, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->h:Lw82;

    const/16 v0, 0x113c

    invoke-static {}, Lq23;->e()Lr72;

    move-result-object v2

    const/16 v0, 0xa71

    iput-object v2, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->l:Lr72;

    const/16 v0, 0x132

    sget-object v4, Lh50;->a:Li20;

    nop

    const/16 v0, 0x126

    sget-object v4, Lx10;->c:Lx10;

    nop

    const/4 v0, -0x6

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x76b

    invoke-static {v4, v2}, Lns2;->x(Ljy;Lly;)Lly;

    move-result-object v2

    const/16 v0, 0xf43

    invoke-static {v2}, Lw53;->a(Lly;)Lsx;

    move-result-object v2

    const/16 v0, 0x9ed

    iput-object v2, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->m:Lsx;

    const/16 v0, 0xf6e

    new-instance v2, Lob;

    nop

    const/16 v4, 0x8

    const/16 v0, 0x11c1

    invoke-direct {v2, v4, p0}, Lob;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x915

    iput-object v2, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->o:Lob;

    const/16 v0, 0x1121

    new-instance v2, Ldr0;

    nop

    const/16 v0, 0x827

    invoke-direct {v2, v3, p0}, Ldr0;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0xb19

    iput-object v2, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->p:Ldr0;

    return-void
.end method


# virtual methods
.method public final a()Landroid/app/NotificationManager;
    .registers 3

    const/16 v0, 0xf30

    iget-object p0, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->g:Lw82;

    nop

    const/16 v0, 0x177

    invoke-virtual {p0}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/app/NotificationManager;

    return-object p0
.end method

.method public final b(Z)V
    .registers 23

    .prologue
    const-string/jumbo v9, "renewTimer"

    nop

    nop

    const-string/jumbo v10, "processo"

    nop

    nop

    const/16 v7, 0x329

    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->a:Lcom/tlsvpn/tlstunnel/services/VpnConnection;

    nop

    const/4 v12, 0x1

    const/4 v13, 0x0

    if-eqz v11, :cond_33

    const/16 v7, 0x2b8

    invoke-virtual {v11}, Ljava/lang/Thread;->isInterrupted()Z

    move-result v11

    if-nez v11, :cond_33

    :try_start_1d
    const/16 v7, 0x329

    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->a:Lcom/tlsvpn/tlstunnel/services/VpnConnection;

    nop

    if-eqz v11, :cond_2e

    const/16 v7, 0x82e

    move/from16 v0, p1

    invoke-virtual {v11, v0, v12}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->g(ZZ)V

    goto :goto_33

    :cond_2e
    const/4 v7, 0x5

    invoke-static {v10}, Lgt0;->F0(Ljava/lang/String;)V

    throw v13
    :try_end_33
    .catch Ljava/lang/Exception; {:try_start_1d .. :try_end_33} :catch_33

    :catch_33
    :cond_33
    :goto_33
    const/4 v10, 0x0

    const/16 v7, 0xd20

    move-object/from16 v0, p0

    iput-boolean v10, v0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->c:Z

    const/16 v7, 0x5b

    new-instance v11, Landroid/content/Intent;

    nop

    const-string/jumbo v14, "setProgress"

    nop

    nop

    const/16 v7, 0x62

    invoke-direct {v11, v14}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v7, 0x53

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v14

    const/16 v7, 0x4a

    invoke-virtual {v14}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v14

    const/16 v7, 0x64

    invoke-virtual {v11, v14}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v11

    const/high16 v14, 0x10000000

    const/16 v7, 0x59

    invoke-virtual {v11, v14}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v11

    const/16 v7, 0x63

    move-object/from16 v0, p0

    invoke-virtual {v0, v11}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    const/16 v7, 0x1172

    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->n:Lx52;

    nop

    if-eqz v11, :cond_7a

    const/16 v7, 0x43a

    invoke-virtual {v11, v13}, Lnv0;->a(Ljava/util/concurrent/CancellationException;)V

    :cond_7a
    const/16 v7, 0xb46

    new-instance v11, Lyh;

    nop

    const/16 v15, 0x9

    const/16 v7, 0xecd

    move-object/from16 v0, p0

    invoke-direct {v11, v0, v13, v15}, Lyh;-><init>(Ljava/lang/Object;Lvx;I)V

    const/4 v15, 0x3

    const/16 v7, 0x843

    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->m:Lsx;

    move-object/16 v16, v7

    const/16 v7, 0xb3

    move v0, v7

    move-object/from16 v1, v16

    move-object v2, v13

    move-object v3, v13

    move-object v4, v11

    move v5, v15

    invoke-static/range {v1 .. v5}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    move-result-object v11

    const/16 v7, 0x10d7

    move-object/from16 v0, p0

    iput-object v11, v0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->n:Lx52;

    const/16 v7, 0x358

    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->j:Landroid/os/ParcelFileDescriptor;

    nop

    :try_start_ac
    const/16 v7, 0x3dc

    new-instance v15, Landroid/net/VpnService$Builder;

    nop

    const/16 v7, 0x433

    move-object/from16 v0, p0

    invoke-direct {v15, v0}, Landroid/net/VpnService$Builder;-><init>(Landroid/net/VpnService;)V

    const/4 v7, -0x3

    new-instance v16, Ljava/lang/StringBuilder;

    nop

    const/4 v7, -0x4

    move-object/from16 v0, v16

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const v17, 0x7f130024

    const/16 v7, 0xb4

    move-object/from16 v0, p0

    move/from16 v1, v17

    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v17

    const/4 v7, 0x0

    move-object/from16 v0, v16

    move-object/from16 v1, v17

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v17, " FKIFF"

    nop

    nop

    const/4 v7, 0x0

    move-object/from16 v0, v16

    move-object/from16 v1, v17

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, -0x2

    move-object/from16 v0, v16

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v16

    const/16 v7, 0x4f2

    move-object/from16 v0, v16

    invoke-virtual {v15, v0}, Landroid/net/VpnService$Builder;->setSession(Ljava/lang/String;)Landroid/net/VpnService$Builder;

    move-result-object v15

    const-string/jumbo v16, "33.82.73.6"

    nop

    nop

    const/16 v17, 0x20

    const/16 v7, 0x1d0

    move-object/from16 v0, v16

    move/from16 v1, v17

    invoke-virtual {v15, v0, v1}, Landroid/net/VpnService$Builder;->addAddress(Ljava/lang/String;I)Landroid/net/VpnService$Builder;

    move-result-object v15

    const-string/jumbo v16, "0.0.0.0"

    nop

    nop

    const/16 v7, 0x3a5

    move-object/from16 v0, v16

    invoke-virtual {v15, v0, v10}, Landroid/net/VpnService$Builder;->addRoute(Ljava/lang/String;I)Landroid/net/VpnService$Builder;

    move-result-object v15

    const/16 v7, 0x53

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v16

    const/16 v7, 0x4a

    move-object/from16 v0, v16

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v16

    const/16 v7, 0x22d

    move-object/from16 v0, v16

    invoke-virtual {v15, v0}, Landroid/net/VpnService$Builder;->addDisallowedApplication(Ljava/lang/String;)Landroid/net/VpnService$Builder;

    move-result-object v15

    const/16 v7, 0x283

    invoke-virtual {v15, v10}, Landroid/net/VpnService$Builder;->setBlocking(Z)Landroid/net/VpnService$Builder;

    move-result-object v15

    const/16 v16, 0x5dc

    const/16 v7, 0x3c4

    move/from16 v0, v16

    invoke-virtual {v15, v0}, Landroid/net/VpnService$Builder;->setMtu(I)Landroid/net/VpnService$Builder;

    move-result-object v15

    const/16 v7, 0x3a4

    invoke-virtual {v15}, Landroid/net/VpnService$Builder;->establish()Landroid/os/ParcelFileDescriptor;

    move-result-object v15

    const/16 v7, 0x945

    move-object/from16 v0, p0

    iput-object v15, v0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->j:Landroid/os/ParcelFileDescriptor;
    :try_end_145
    .catch Ljava/lang/Exception; {:try_start_ac .. :try_end_145} :catch_252

    :try_start_145
    const/16 v7, 0x2b5

    move-object/from16 v0, p0

    iget-object v15, v0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->i:Landroid/os/ParcelFileDescriptor;

    nop

    const/4 v7, -0x6

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x18b

    invoke-virtual {v15}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_155
    .catch Ljava/lang/Exception; {:try_start_145 .. :try_end_155} :catch_155

    :catch_155
    :try_start_155
    const/4 v7, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x18b

    invoke-virtual {v11}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_15e
    .catch Ljava/lang/Exception; {:try_start_155 .. :try_end_15e} :catch_15e

    :catch_15e
    const/16 v7, 0x105e

    move-object/from16 v0, p0

    iget-object v11, v0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->e:Lw82;

    nop

    const/16 v7, 0x177

    invoke-virtual {v11}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Landroid/content/SharedPreferences;

    const-string/jumbo v16, "renewnotf"

    nop

    nop

    const/16 v7, 0x77

    move-object/from16 v0, v16

    invoke-interface {v15, v0, v12}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v12

    const/16 v7, 0xe7e

    move-object/from16 v0, p0

    iput-boolean v12, v0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->d:Z

    const/16 v7, 0x133

    move-object/from16 v0, p0

    iget-object v12, v0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->b:Ljava/util/Timer;

    nop

    if-eqz v12, :cond_1a2

    :try_start_189
    const/16 v7, 0x4b1

    invoke-virtual {v12}, Ljava/util/Timer;->cancel()V

    const/16 v7, 0x133

    move-object/from16 v0, p0

    iget-object v12, v0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->b:Ljava/util/Timer;

    nop

    if-eqz v12, :cond_19d

    const/16 v7, 0x31c

    invoke-virtual {v12}, Ljava/util/Timer;->purge()I

    goto :goto_1a2

    :cond_19d
    const/4 v7, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw v13
    :try_end_1a2
    .catch Ljava/lang/Exception; {:try_start_189 .. :try_end_1a2} :catch_1a2

    :catch_1a2
    :cond_1a2
    :goto_1a2
    const/16 v7, 0xe9

    move-object/from16 v0, p0

    invoke-virtual {v0}, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->a()Landroid/app/NotificationManager;

    move-result-object v9

    const/4 v12, 0x2

    const/16 v7, 0x2f4

    invoke-virtual {v9, v12}, Landroid/app/NotificationManager;->cancel(I)V

    const/16 v7, 0x119b

    new-instance v15, Lcom/tlsvpn/tlstunnel/services/VpnConnection;

    nop

    const/16 v7, 0x177

    invoke-virtual {v11}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v9

    move-object/from16 v17, v9

    check-cast v17, Landroid/content/SharedPreferences;

    const/4 v7, -0x6

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x4f

    move-object/from16 v0, p0

    iget-object v7, v0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->f:Lkg1;

    move-object/16 v18, v7

    if-eqz v18, :cond_246

    const/16 v7, 0xe9

    move-object/from16 v0, p0

    invoke-virtual {v0}, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->a()Landroid/app/NotificationManager;

    move-result-object v19

    move-object/from16 v16, p0

    move/from16 v20, p1

    const/16 v7, 0xe95

    move v0, v7

    move-object v1, v15

    move-object/from16 v2, v16

    move-object/from16 v3, v17

    move-object/from16 v4, v18

    move-object/from16 v5, v19

    move/from16 v6, v20

    invoke-direct/range {v1 .. v6}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;-><init>(Lcom/tlsvpn/tlstunnel/services/ServicoVpn;Landroid/content/SharedPreferences;Lkg1;Landroid/app/NotificationManager;Z)V

    const/16 v7, 0x1236

    move-object/from16 v0, v16

    iput-object v15, v0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->a:Lcom/tlsvpn/tlstunnel/services/VpnConnection;

    const/16 v7, 0x41b

    invoke-virtual {v15}, Ljava/lang/Thread;->start()V

    const/16 v7, 0x5b

    new-instance p0, Landroid/content/Intent;

    nop

    const-string/jumbo p1, "vpnOn"

    nop

    nop

    const/16 v7, 0x62

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string/jumbo p1, "csuscgaE"

    nop

    nop

    const/16 v7, 0x178

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual {v0, v1, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    move-result-object p0

    const/16 v7, 0x53

    move-object/from16 v0, v16

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const/16 v7, 0x4a

    move-object/from16 v0, p1

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    const/16 v7, 0x64

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    const/16 v7, 0x59

    move-object/from16 v0, p0

    invoke-virtual {v0, v14}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object p0

    const/16 v7, 0x63

    move-object/from16 v0, v16

    move-object/from16 v1, p0

    invoke-virtual {v0, v1}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    return-void

    :cond_246
    const-string/jumbo p0, "notificacao"

    nop

    nop

    const/4 v7, 0x5

    move-object/from16 v0, p0

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v13

    :catch_252
    move-object/from16 v16, p0

    :try_start_254
    const/16 v7, 0x2b5

    move-object/from16 v0, v16

    iget-object v7, v0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->i:Landroid/os/ParcelFileDescriptor;

    move-object/16 p0, v7

    const/4 v7, -0x6

    move-object/from16 v0, p0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x18b

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_26a
    .catch Ljava/lang/Exception; {:try_start_254 .. :try_end_26a} :catch_26a

    :catch_26a
    :try_start_26a
    const/4 v7, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x18b

    invoke-virtual {v11}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_273
    .catch Ljava/lang/Exception; {:try_start_26a .. :try_end_273} :catch_273

    :catch_273
    const/16 v7, 0x4f7

    move-object/from16 v0, v16

    invoke-virtual {v0}, Landroid/app/Service;->stopSelf()V

    return-void
.end method

.method public final c()V
    .registers 13

    .prologue
    const-string/jumbo v3, "renewTimer"

    nop

    nop

    const/16 v1, 0x1ff

    sget v4, Lmi2;->o:I

    nop

    if-nez v4, :cond_12

    const/16 v1, 0x4f7

    invoke-virtual {p0}, Landroid/app/Service;->stopSelf()V

    return-void

    :cond_12
    const/16 v1, 0x1172

    iget-object v4, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->n:Lx52;

    nop

    const/4 v5, 0x0

    if-eqz v4, :cond_1f

    const/16 v1, 0x43a

    invoke-virtual {v4, v5}, Lnv0;->a(Ljava/util/concurrent/CancellationException;)V

    :cond_1f
    const/4 v4, 0x4

    const/16 v1, 0x332

    sput v4, Lmi2;->o:I

    const-string/jumbo v4, ""

    const/16 v1, 0xe86

    sput-object v4, Lmi2;->m:Ljava/lang/String;

    const-wide/16 v6, 0x0

    const/16 v1, 0x40a

    sput-wide v6, Lmi2;->i:J

    const/4 v4, 0x0

    const/16 v1, 0xe04

    sput-boolean v4, Lmi2;->l:Z

    const/4 v8, 0x1

    const/16 v1, 0x3f0

    sput-boolean v8, Lmi2;->k:Z

    const/16 v1, 0x4f

    iget-object v9, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->f:Lkg1;

    nop

    const-string/jumbo v10, "notificacao"

    nop

    nop

    if-eqz v9, :cond_ee

    const/16 v1, 0x1bd

    iget-object v11, v9, Lkg1;->u:Landroid/app/Notification;

    nop

    const/16 v1, 0x210

    iput-wide v6, v11, Landroid/app/Notification;->when:J

    const/16 v1, 0x226

    invoke-virtual {v9, v4}, Lkg1;->d(Z)V

    const/16 v1, 0x4f

    iget-object v6, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->f:Lkg1;

    nop

    if-eqz v6, :cond_e9

    const/16 v1, 0x2db

    iput-boolean v4, v6, Lkg1;->j:Z

    const v7, 0x7f13024e

    const/16 v1, 0xb4

    invoke-virtual {p0, v7}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v7

    const/16 v1, 0x3e6

    invoke-static {v7}, Lkg1;->c(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v7

    const/16 v1, 0x67b

    iput-object v7, v6, Lkg1;->f:Ljava/lang/CharSequence;

    :try_start_73
    const/16 v1, 0xe9

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->a()Landroid/app/NotificationManager;

    move-result-object v6

    const/16 v1, 0x4f

    iget-object v7, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->f:Lkg1;

    nop

    if-eqz v7, :cond_8c

    const/16 v1, 0x1df

    invoke-virtual {v7}, Lkg1;->b()Landroid/app/Notification;

    move-result-object v7

    const/16 v1, 0x1be

    invoke-virtual {v6, v8, v7}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    goto :goto_91

    :cond_8c
    const/4 v1, 0x5

    invoke-static {v10}, Lgt0;->F0(Ljava/lang/String;)V

    throw v5
    :try_end_91
    .catch Ljava/lang/Exception; {:try_start_73 .. :try_end_91} :catch_91

    :catch_91
    :goto_91
    const/16 v1, 0x133

    iget-object v6, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->b:Ljava/util/Timer;

    nop

    if-eqz v6, :cond_af

    :try_start_98
    const/16 v1, 0x4b1

    invoke-virtual {v6}, Ljava/util/Timer;->cancel()V

    const/16 v1, 0x133

    iget-object v6, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->b:Ljava/util/Timer;

    nop

    if-eqz v6, :cond_aa

    const/16 v1, 0x31c

    invoke-virtual {v6}, Ljava/util/Timer;->purge()I

    goto :goto_af

    :cond_aa
    const/4 v1, 0x5

    invoke-static {v3}, Lgt0;->F0(Ljava/lang/String;)V

    throw v5
    :try_end_af
    .catch Ljava/lang/Exception; {:try_start_98 .. :try_end_af} :catch_af

    :catch_af
    :cond_af
    :goto_af
    const/16 v1, 0xe9

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->a()Landroid/app/NotificationManager;

    move-result-object v3

    const/4 v5, 0x2

    const/16 v1, 0x2f4

    invoke-virtual {v3, v5}, Landroid/app/NotificationManager;->cancel(I)V

    const/16 v1, 0x329

    iget-object v3, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->a:Lcom/tlsvpn/tlstunnel/services/VpnConnection;

    nop

    if-eqz v3, :cond_c7

    :try_start_c2
    const/16 v1, 0x82e

    invoke-virtual {v3, v4, v8}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->g(ZZ)V
    :try_end_c7
    .catch Ljava/lang/Exception; {:try_start_c2 .. :try_end_c7} :catch_c7

    :catch_c7
    :cond_c7
    :try_start_c7
    const/16 v1, 0x2b5

    iget-object v3, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->i:Landroid/os/ParcelFileDescriptor;

    nop

    const/4 v1, -0x6

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v1, 0x18b

    invoke-virtual {v3}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_d5
    .catch Ljava/lang/Exception; {:try_start_c7 .. :try_end_d5} :catch_d5

    :catch_d5
    :try_start_d5
    const/16 v1, 0x358

    iget-object v3, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->j:Landroid/os/ParcelFileDescriptor;

    nop

    const/4 v1, -0x6

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v1, 0x18b

    invoke-virtual {v3}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_e3
    .catch Ljava/lang/Exception; {:try_start_d5 .. :try_end_e3} :catch_e3

    :catch_e3
    const/16 v1, 0x4f7

    invoke-virtual {p0}, Landroid/app/Service;->stopSelf()V

    return-void

    :cond_e9
    const/4 v1, 0x5

    invoke-static {v10}, Lgt0;->F0(Ljava/lang/String;)V

    throw v5

    :cond_ee
    const/4 v1, 0x5

    invoke-static {v10}, Lgt0;->F0(Ljava/lang/String;)V

    throw v5
.end method

.method public final d()V
    .registers 13

    .prologue
    const-string/jumbo v2, "renewTimer"

    nop

    nop

    const/16 v0, 0x1ff

    sget v3, Lmi2;->o:I

    nop

    if-nez v3, :cond_12

    const/16 v0, 0x4f7

    invoke-virtual {p0}, Landroid/app/Service;->stopSelf()V

    return-void

    :cond_12
    const/4 v3, 0x2

    const/16 v0, 0x332

    sput v3, Lmi2;->o:I

    const-string/jumbo v4, ""

    const/16 v0, 0xe86

    sput-object v4, Lmi2;->m:Ljava/lang/String;

    const-wide/16 v4, 0x0

    const/16 v0, 0x40a

    sput-wide v4, Lmi2;->i:J

    const/4 v6, 0x0

    const/16 v0, 0xe04

    sput-boolean v6, Lmi2;->l:Z

    const/4 v7, 0x1

    const/16 v0, 0x3f0

    sput-boolean v7, Lmi2;->k:Z

    const/16 v0, 0x5b

    new-instance v8, Landroid/content/Intent;

    nop

    const-string/jumbo v9, "setProgress"

    nop

    nop

    const/16 v0, 0x62

    invoke-direct {v8, v9}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v9

    const/16 v0, 0x4a

    invoke-virtual {v9}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v9

    const/16 v0, 0x64

    invoke-virtual {v8, v9}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v8

    const/high16 v9, 0x10000000

    const/16 v0, 0x59

    invoke-virtual {v8, v9}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v8

    const/16 v0, 0x63

    invoke-virtual {p0, v8}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    const/16 v0, 0x4f

    iget-object v8, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->f:Lkg1;

    nop

    const/4 v9, 0x0

    const-string/jumbo v10, "notificacao"

    nop

    nop

    if-eqz v8, :cond_e7

    const/16 v0, 0x1bd

    iget-object v11, v8, Lkg1;->u:Landroid/app/Notification;

    nop

    const/16 v0, 0x210

    iput-wide v4, v11, Landroid/app/Notification;->when:J

    const/16 v0, 0x226

    invoke-virtual {v8, v6}, Lkg1;->d(Z)V

    const/16 v0, 0x4f

    iget-object v4, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->f:Lkg1;

    nop

    if-eqz v4, :cond_e2

    const/16 v0, 0x2db

    iput-boolean v6, v4, Lkg1;->j:Z

    const v5, 0x7f13021e

    const/16 v0, 0xb4

    invoke-virtual {p0, v5}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v5

    const/16 v0, 0x3e6

    invoke-static {v5}, Lkg1;->c(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v5

    const/16 v0, 0x67b

    iput-object v5, v4, Lkg1;->f:Ljava/lang/CharSequence;

    :try_start_95
    const/16 v0, 0xe9

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->a()Landroid/app/NotificationManager;

    move-result-object v4

    const/16 v0, 0x4f

    iget-object v5, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->f:Lkg1;

    nop

    if-eqz v5, :cond_ae

    const/16 v0, 0x1df

    invoke-virtual {v5}, Lkg1;->b()Landroid/app/Notification;

    move-result-object v5

    const/16 v0, 0x1be

    invoke-virtual {v4, v7, v5}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    goto :goto_b3

    :cond_ae
    const/4 v0, 0x5

    invoke-static {v10}, Lgt0;->F0(Ljava/lang/String;)V

    throw v9
    :try_end_b3
    .catch Ljava/lang/Exception; {:try_start_95 .. :try_end_b3} :catch_b3

    :catch_b3
    :goto_b3
    const/16 v0, 0x133

    iget-object v4, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->b:Ljava/util/Timer;

    nop

    if-eqz v4, :cond_d1

    :try_start_ba
    const/16 v0, 0x4b1

    invoke-virtual {v4}, Ljava/util/Timer;->cancel()V

    const/16 v0, 0x133

    iget-object v4, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->b:Ljava/util/Timer;

    nop

    if-eqz v4, :cond_cc

    const/16 v0, 0x31c

    invoke-virtual {v4}, Ljava/util/Timer;->purge()I

    goto :goto_d1

    :cond_cc
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw v9
    :try_end_d1
    .catch Ljava/lang/Exception; {:try_start_ba .. :try_end_d1} :catch_d1

    :catch_d1
    :cond_d1
    :goto_d1
    const/16 v0, 0xe9

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->a()Landroid/app/NotificationManager;

    move-result-object v2

    const/16 v0, 0x2f4

    invoke-virtual {v2, v3}, Landroid/app/NotificationManager;->cancel(I)V

    const/16 v0, 0x57a

    invoke-virtual {p0, v7}, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->b(Z)V

    return-void

    :cond_e2
    const/4 v0, 0x5

    invoke-static {v10}, Lgt0;->F0(Ljava/lang/String;)V

    throw v9

    :cond_e7
    const/4 v0, 0x5

    invoke-static {v10}, Lgt0;->F0(Ljava/lang/String;)V

    throw v9
.end method

.method public final onCreate()V
    .registers 15

    .prologue
    const/16 v0, 0x1095

    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    const/16 v0, 0xc33

    new-instance v2, Landroid/content/res/Configuration;

    nop

    const/16 v0, 0xebb

    invoke-direct {v2}, Landroid/content/res/Configuration;-><init>()V

    const/16 v0, 0x1fc

    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 v4, 0x21

    if-lt v3, v4, :cond_3b

    const/16 v0, 0xb22

    invoke-static {}, Leb;->b()Ljava/lang/Object;

    move-result-object v5

    if-eqz v5, :cond_43

    const/16 v0, 0x8cc

    invoke-static {v5}, Lbb;->a(Ljava/lang/Object;)Landroid/os/LocaleList;

    move-result-object v5

    const/16 v0, 0x896

    new-instance v6, Lv31;

    nop

    const/16 v0, 0xac2

    new-instance v7, Lw31;

    nop

    const/16 v0, 0xf4a

    invoke-direct {v7, v5}, Lw31;-><init>(Landroid/os/LocaleList;)V

    const/16 v0, 0xd36

    invoke-direct {v6, v7}, Lv31;-><init>(Lw31;)V

    goto :goto_48

    :cond_3b
    const/16 v0, 0x64d

    sget-object v6, Leb;->c:Lv31;

    nop

    if-eqz v6, :cond_43

    goto :goto_48

    :cond_43
    const/16 v0, 0x39b

    sget-object v6, Lv31;->b:Lv31;

    nop

    :goto_48
    const/16 v0, 0xdc4

    iget-object v5, v6, Lv31;->a:Lw31;

    nop

    const/16 v0, 0x8f4

    iget-object v5, v5, Lw31;->a:Landroid/os/LocaleList;

    nop

    const/4 v6, 0x0

    const/16 v0, 0xb62

    invoke-virtual {v5, v6}, Landroid/os/LocaleList;->get(I)Ljava/util/Locale;

    move-result-object v5

    const/16 v0, 0x103d

    invoke-virtual {v2, v5}, Landroid/content/res/Configuration;->setLocale(Ljava/util/Locale;)V

    const/16 v0, 0x1188

    invoke-virtual {p0, v2}, Landroid/content/Context;->createConfigurationContext(Landroid/content/res/Configuration;)Landroid/content/Context;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x6db

    iput-object v2, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->k:Landroid/content/Context;

    const/16 v0, 0x5b

    new-instance v2, Landroid/content/Intent;

    nop

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v5

    const-class v7, Lcom/tlsvpn/tlstunnel/MainActivity;

    const/16 v0, 0xd0

    invoke-direct {v2, v5, v7}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/high16 v5, 0x4000000

    const/16 v0, 0x1067

    invoke-static {p0, v6, v2, v5}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v2

    const/16 v0, 0x5b

    new-instance v7, Landroid/content/Intent;

    nop

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v8

    const-class v9, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;

    const/16 v0, 0xd0

    invoke-direct {v7, v8, v9}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string/jumbo v8, "reconnect"

    nop

    nop

    const/16 v0, 0x48f

    invoke-virtual {v7, v8}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v7

    const/16 v0, 0x29e

    invoke-static {p0, v6, v7, v5}, Landroid/app/PendingIntent;->getService(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v5

    const/16 v0, 0x5b

    new-instance v7, Landroid/content/Intent;

    nop

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v10

    const/16 v0, 0xd0

    invoke-direct {v7, v10, v9}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string/jumbo v9, "stopVpn"

    nop

    nop

    const/16 v0, 0x48f

    invoke-virtual {v7, v9}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v7

    const/high16 v10, 0x44000000  # 512.0f

    const/16 v0, 0x29e

    invoke-static {p0, v6, v7, v10}, Landroid/app/PendingIntent;->getService(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v7

    const/16 v0, 0xedb

    new-instance v10, Lkg1;

    nop

    const-string/jumbo v11, "tls_dft0"

    nop

    nop

    const/16 v0, 0xefa

    invoke-direct {v10, p0, v11}, Lkg1;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    const-string/jumbo v11, "vpn-status"

    nop

    nop

    const/16 v0, 0xf4e

    iput-object v11, v10, Lkg1;->l:Ljava/lang/String;

    const/4 v11, 0x2

    const/4 v12, 0x1

    const/16 v0, 0x4df

    invoke-virtual {v10, v11, v12}, Lkg1;->e(IZ)V

    const/16 v11, 0x10

    const/16 v0, 0x4df

    invoke-virtual {v10, v11, v6}, Lkg1;->e(IZ)V

    const/16 v0, 0x2db

    iput-boolean v6, v10, Lkg1;->j:Z

    const/16 v0, 0xf14

    iput v6, v10, Lkg1;->h:I

    const/16 v0, 0xe40

    iput-boolean v12, v10, Lkg1;->n:Z

    const/16 v0, 0xc3e

    iput-boolean v12, v10, Lkg1;->o:Z

    const v6, 0x7f130024

    const/16 v0, 0xb4

    invoke-virtual {p0, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v6

    const/16 v0, 0x3e6

    invoke-static {v6}, Lkg1;->c(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v6

    const/16 v0, 0xbc2

    iput-object v6, v10, Lkg1;->e:Ljava/lang/CharSequence;

    const/16 v0, 0x1bd

    iget-object v6, v10, Lkg1;->u:Landroid/app/Notification;

    nop

    const v11, 0x7f08012a

    const/16 v0, 0xdd4

    iput v11, v6, Landroid/app/Notification;->icon:I

    const/4 v11, 0x0

    const/16 v0, 0xa3a

    iput-object v11, v6, Landroid/app/Notification;->sound:Landroid/net/Uri;

    const/4 v11, -0x1

    const/16 v0, 0x8b7

    iput v11, v6, Landroid/app/Notification;->audioStreamType:I

    const/16 v0, 0xcbe

    invoke-static {}, Ljg1;->b()Landroid/media/AudioAttributes$Builder;

    move-result-object v11

    const/4 v12, 0x4

    const/16 v0, 0xc44

    invoke-static {v11, v12}, Ljg1;->c(Landroid/media/AudioAttributes$Builder;I)Landroid/media/AudioAttributes$Builder;

    move-result-object v11

    const/4 v13, 0x5

    const/16 v0, 0x1237

    invoke-static {v11, v13}, Ljg1;->d(Landroid/media/AudioAttributes$Builder;I)Landroid/media/AudioAttributes$Builder;

    move-result-object v11

    const/16 v0, 0xd33

    invoke-static {v11}, Ljg1;->a(Landroid/media/AudioAttributes$Builder;)Landroid/media/AudioAttributes;

    move-result-object v11

    const/16 v0, 0xab9

    iput-object v11, v6, Landroid/app/Notification;->audioAttributes:Landroid/media/AudioAttributes;

    const v6, 0x7f130066

    const/16 v0, 0xb4

    invoke-virtual {p0, v6}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v6

    const/16 v0, 0x3e6

    invoke-static {v6}, Lkg1;->c(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v6

    const/16 v0, 0x67b

    iput-object v6, v10, Lkg1;->f:Ljava/lang/CharSequence;

    const-string/jumbo v6, "service"

    nop

    nop

    const/16 v0, 0xe89

    iput-object v6, v10, Lkg1;->p:Ljava/lang/String;

    const/16 v0, 0x947

    iput-object v2, v10, Lkg1;->g:Landroid/app/PendingIntent;

    const v2, 0x7f06003b

    const/16 v0, 0x77c

    invoke-static {p0, v2}, Lqx;->getColor(Landroid/content/Context;I)I

    move-result v2

    const/16 v0, 0x11d7

    iput v2, v10, Lkg1;->r:I

    const v2, 0x7f13021d

    const/16 v0, 0xb4

    invoke-virtual {p0, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    const v6, 0x7f080115

    const/16 v0, 0x3d6

    invoke-virtual {v10, v6, v2, v5}, Lkg1;->a(ILjava/lang/String;Landroid/app/PendingIntent;)V

    const v2, 0x7f13024d

    const/16 v0, 0xb4

    invoke-virtual {p0, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v2

    const v5, 0x7f08011d

    const/16 v0, 0x3d6

    invoke-virtual {v10, v5, v2, v7}, Lkg1;->a(ILjava/lang/String;Landroid/app/PendingIntent;)V

    const/16 v0, 0xd81

    iput-object v10, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->f:Lkg1;

    const-string/jumbo v2, "dipro"

    nop

    nop

    const-string/jumbo v5, "pVacTd"

    nop

    nop

    const-string/jumbo v6, "SERVERRPL"

    nop

    nop

    const-string/jumbo v7, "timeLeft"

    nop

    nop

    const/16 v0, 0x907

    iget-object v10, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->o:Lob;

    nop

    if-ge v3, v4, :cond_212

    const/16 v0, 0x1f

    new-instance v3, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {v3, v7}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x3a

    invoke-virtual {p0, v10, v3}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/16 v0, 0x1f

    new-instance v3, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {v3, v9}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x3a

    invoke-virtual {p0, v10, v3}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/16 v0, 0x1f

    new-instance v3, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {v3, v8}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x3a

    invoke-virtual {p0, v10, v3}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/16 v0, 0x1f

    new-instance v3, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {v3, v6}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x3a

    invoke-virtual {p0, v10, v3}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/16 v0, 0x1f

    new-instance v3, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {v3, v5}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x3a

    invoke-virtual {p0, v10, v3}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/16 v0, 0x1f

    new-instance v3, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {v3, v2}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x3a

    invoke-virtual {p0, v10, v3}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    return-void

    :cond_212
    const/16 v0, 0x1f

    new-instance v3, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {v3, v7}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0xbf

    invoke-virtual {p0, v10, v3, v12}, Landroid/net/VpnService;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    const/16 v0, 0x1f

    new-instance v3, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {v3, v9}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0xbf

    invoke-virtual {p0, v10, v3, v12}, Landroid/net/VpnService;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    const/16 v0, 0x1f

    new-instance v3, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {v3, v8}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0xbf

    invoke-virtual {p0, v10, v3, v12}, Landroid/net/VpnService;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    const/16 v0, 0x1f

    new-instance v3, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {v3, v6}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0xbf

    invoke-virtual {p0, v10, v3, v12}, Landroid/net/VpnService;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    const/16 v0, 0x1f

    new-instance v3, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {v3, v5}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0xbf

    invoke-virtual {p0, v10, v3, v12}, Landroid/net/VpnService;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    const/16 v0, 0x1f

    new-instance v3, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {v3, v2}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0xbf

    invoke-virtual {p0, v10, v3, v12}, Landroid/net/VpnService;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    return-void
.end method

.method public final onDestroy()V
    .registers 7

    .prologue
    const-string/jumbo v2, "renewTimer"

    nop

    nop

    const/16 v0, 0xc0a

    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    const/4 v3, 0x0

    const/16 v0, 0x332

    sput v3, Lmi2;->o:I

    const/16 v0, 0x1172

    iget-object v3, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->n:Lx52;

    nop

    const/4 v4, 0x0

    if-eqz v3, :cond_1c

    const/16 v0, 0x43a

    invoke-virtual {v3, v4}, Lnv0;->a(Ljava/util/concurrent/CancellationException;)V

    :cond_1c
    const/16 v0, 0x133

    iget-object v3, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->b:Ljava/util/Timer;

    nop

    if-eqz v3, :cond_3a

    :try_start_23
    const/16 v0, 0x4b1

    invoke-virtual {v3}, Ljava/util/Timer;->cancel()V

    const/16 v0, 0x133

    iget-object v3, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->b:Ljava/util/Timer;

    nop

    if-eqz v3, :cond_35

    const/16 v0, 0x31c

    invoke-virtual {v3}, Ljava/util/Timer;->purge()I

    goto :goto_3a

    :cond_35
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4
    :try_end_3a
    .catch Ljava/lang/Exception; {:try_start_23 .. :try_end_3a} :catch_3a

    :catch_3a
    :cond_3a
    :goto_3a
    :try_start_3a
    const/16 v0, 0x907

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->o:Lob;

    nop

    const/16 v0, 0x345

    invoke-virtual {p0, v2}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_44
    .catch Ljava/lang/Exception; {:try_start_3a .. :try_end_44} :catch_44

    :catch_44
    :try_start_44
    const/16 v0, 0x654

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->h:Lw82;

    nop

    const/16 v0, 0x177

    invoke-virtual {v2}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/net/ConnectivityManager;

    const/16 v0, 0x8f5

    iget-object v3, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->p:Ldr0;

    nop

    const/16 v0, 0x9d7

    invoke-virtual {v2, v3}, Landroid/net/ConnectivityManager;->unregisterNetworkCallback(Landroid/net/ConnectivityManager$NetworkCallback;)V
    :try_end_5b
    .catch Ljava/lang/Exception; {:try_start_44 .. :try_end_5b} :catch_5b

    :catch_5b
    const/16 v0, 0x5b

    new-instance v2, Landroid/content/Intent;

    nop

    const-string/jumbo v3, "vpnOff"

    nop

    nop

    const/16 v0, 0x62

    invoke-direct {v2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    const/16 v0, 0x4a

    invoke-virtual {v3}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    const/16 v0, 0x64

    invoke-virtual {v2, v3}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v2

    const/high16 v3, 0x10000000

    const/16 v0, 0x59

    invoke-virtual {v2, v3}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v2

    const/16 v0, 0x63

    invoke-virtual {p0, v2}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    const/16 v0, 0x5b

    new-instance v2, Landroid/content/Intent;

    nop

    const-string/jumbo v5, "setProgress"

    nop

    nop

    const/16 v0, 0x62

    invoke-direct {v2, v5}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v5

    const/16 v0, 0x4a

    invoke-virtual {v5}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v5

    const/16 v0, 0x64

    invoke-virtual {v2, v5}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v2

    const/16 v0, 0x59

    invoke-virtual {v2, v3}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v2

    const/16 v0, 0x63

    invoke-virtual {p0, v2}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    const/16 v0, 0xe9

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->a()Landroid/app/NotificationManager;

    move-result-object v2

    const/4 v3, 0x1

    const/16 v0, 0x2f4

    invoke-virtual {v2, v3}, Landroid/app/NotificationManager;->cancel(I)V

    const/16 v0, 0xe9

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->a()Landroid/app/NotificationManager;

    move-result-object v2

    const/4 v5, 0x2

    const/16 v0, 0x2f4

    invoke-virtual {v2, v5}, Landroid/app/NotificationManager;->cancel(I)V

    const/16 v0, 0xcd3

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->l:Lr72;

    nop

    const/16 v0, 0x43a

    invoke-virtual {v2, v4}, Lnv0;->a(Ljava/util/concurrent/CancellationException;)V

    const/16 v0, 0xe83

    invoke-virtual {p0, v3}, Landroid/app/Service;->stopForeground(I)V

    return-void
.end method

.method public final onRevoke()V
    .registers 3

    const/16 v0, 0x1163

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->c()V

    const/16 v0, 0x9dd

    invoke-super {p0}, Landroid/net/VpnService;->onRevoke()V

    return-void
.end method

.method public final onStartCommand(Landroid/content/Intent;II)I
    .registers 9

    .prologue
    const-string/jumbo p2, "VPN"

    nop

    nop

    const/4 p3, 0x0

    if-eqz p1, :cond_f

    const/16 v0, 0x2f

    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p1

    goto :goto_10

    :cond_f
    move-object p1, p3

    :goto_10
    const/16 v0, 0x4f

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->f:Lkg1;

    nop

    if-eqz v2, :cond_f4

    const p3, 0x7f08012a

    const/16 v0, 0x1bd

    iget-object v3, v2, Lkg1;->u:Landroid/app/Notification;

    nop

    const/16 v0, 0xdd4

    iput p3, v3, Landroid/app/Notification;->icon:I

    const/4 p3, 0x1

    :try_start_24
    const/16 v0, 0x1fc

    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 v4, 0x22

    if-lt v3, v4, :cond_3d

    const/16 v0, 0x1df

    invoke-virtual {v2}, Lkg1;->b()Landroid/app/Notification;

    move-result-object v2

    const/high16 v3, 0x40000000  # 2.0f

    const/16 v0, 0x74f

    invoke-virtual {p0, p3, v2, v3}, Landroid/net/VpnService;->startForeground(ILandroid/app/Notification;I)V

    goto :goto_4f

    :catch_3b
    move-exception v2

    goto :goto_49

    :cond_3d
    const/16 v0, 0x1df

    invoke-virtual {v2}, Lkg1;->b()Landroid/app/Notification;

    move-result-object v2

    const/16 v0, 0x659

    invoke-virtual {p0, p3, v2}, Landroid/app/Service;->startForeground(ILandroid/app/Notification;)V
    :try_end_48
    .catch Ljava/lang/Exception; {:try_start_24 .. :try_end_48} :catch_3b

    goto :goto_4f

    :goto_49
    const-string/jumbo v3, "Falha ao iniciar Foreground Service"

    nop

    nop

    nop

    :goto_4f
    const-string/jumbo v2, "reconnect"

    nop

    nop

    const/16 v0, 0x84

    invoke-static {p1, v2}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    const/4 v3, 0x3

    if-eqz v2, :cond_69

    const-string/jumbo p1, "(ServicoVpn) onStartCommand: RECONNECT"

    nop

    nop

    nop

    const/16 v0, 0x496

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->d()V

    return v3

    :cond_69
    const-string/jumbo v2, "stopVpn"

    nop

    nop

    const/16 v0, 0x84

    invoke-static {p1, v2}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_83

    const-string/jumbo p1, "(ServicoVpn) onStartCommand: STOP_VPN"

    nop

    nop

    nop

    const/16 v0, 0x1163

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->c()V

    const/4 p0, 0x2

    return p0

    :cond_83
    const/16 v0, 0x1ff

    sget p1, Lmi2;->o:I

    nop

    if-nez p1, :cond_f3

    const/4 p1, 0x0

    :try_start_8b
    const/16 v0, 0x6a7

    new-instance p2, Landroid/net/NetworkRequest$Builder;

    nop

    const/16 v0, 0xd15

    invoke-direct {p2}, Landroid/net/NetworkRequest$Builder;-><init>()V

    const/16 v0, 0x35a

    invoke-virtual {p2, p3}, Landroid/net/NetworkRequest$Builder;->addTransportType(I)Landroid/net/NetworkRequest$Builder;

    const/16 v0, 0x35a

    invoke-virtual {p2, p1}, Landroid/net/NetworkRequest$Builder;->addTransportType(I)Landroid/net/NetworkRequest$Builder;

    const/16 v0, 0x654

    iget-object v2, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->h:Lw82;

    nop

    const/16 v0, 0x177

    invoke-virtual {v2}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/net/ConnectivityManager;

    const/16 v0, 0x732

    invoke-virtual {p2}, Landroid/net/NetworkRequest$Builder;->build()Landroid/net/NetworkRequest;

    move-result-object p2

    const/16 v0, 0x8f5

    iget-object v4, p0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->p:Ldr0;

    nop

    const/16 v0, 0xc2f

    invoke-virtual {v2, p2, v4}, Landroid/net/ConnectivityManager;->registerNetworkCallback(Landroid/net/NetworkRequest;Landroid/net/ConnectivityManager$NetworkCallback;)V
    :try_end_bc
    .catch Ljava/lang/Exception; {:try_start_8b .. :try_end_bc} :catch_bc

    :catch_bc
    const/16 v0, 0x332

    sput p3, Lmi2;->o:I

    const/16 v0, 0x5b

    new-instance p2, Landroid/content/Intent;

    nop

    const-string/jumbo p3, "setProgress"

    nop

    nop

    const/16 v0, 0x62

    invoke-direct {p2, p3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p3

    const/16 v0, 0x4a

    invoke-virtual {p3}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p3

    const/16 v0, 0x64

    invoke-virtual {p2, p3}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p2

    const/high16 p3, 0x10000000

    const/16 v0, 0x59

    invoke-virtual {p2, p3}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object p2

    const/16 v0, 0x63

    invoke-virtual {p0, p2}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    const/16 v0, 0x57a

    invoke-virtual {p0, p1}, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->b(Z)V

    :cond_f3
    return v3

    :cond_f4
    const-string/jumbo p0, "notificacao"

    nop

    nop

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3
.end method
