.class public final Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;
.super Landroid/app/Service;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final synthetic j:I


# instance fields
.field public final a:Lw82;

.field public final b:Ljava/util/ArrayList;

.field public final c:Ljava/util/ArrayList;

.field public final d:Ljava/util/ArrayList;

.field public final e:Ljava/util/ArrayList;

.field public f:Lgx;

.field public g:Lgx;

.field public final h:Lr72;

.field public final i:Lsx;


# direct methods
.method public constructor <init>()V
    .registers 5

    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    const/16 v0, 0x9ca

    new-instance v2, Lsz1;

    nop

    const/4 v3, 0x5

    const/16 v0, 0xf0b

    invoke-direct {v2, v3, p0}, Lsz1;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x27a

    new-instance v3, Lw82;

    nop

    const/16 v0, 0x215

    invoke-direct {v3, v2}, Lw82;-><init>(Lzj0;)V

    const/16 v0, 0x10a4

    iput-object v3, p0, Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;->a:Lw82;

    const/16 v0, 0xd7

    new-instance v2, Ljava/util/ArrayList;

    nop

    const/16 v0, 0x16b

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    const/16 v0, 0x944

    iput-object v2, p0, Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;->b:Ljava/util/ArrayList;

    const/16 v0, 0xd7

    new-instance v2, Ljava/util/ArrayList;

    nop

    const/16 v0, 0x16b

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    const/16 v0, 0xfbe

    iput-object v2, p0, Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;->c:Ljava/util/ArrayList;

    const/16 v0, 0xd7

    new-instance v2, Ljava/util/ArrayList;

    nop

    const/16 v0, 0x16b

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    const/16 v0, 0x103e

    iput-object v2, p0, Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;->d:Ljava/util/ArrayList;

    const/16 v0, 0xd7

    new-instance v2, Ljava/util/ArrayList;

    nop

    const/16 v0, 0x16b

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    const/16 v0, 0x11e4

    iput-object v2, p0, Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;->e:Ljava/util/ArrayList;

    const/16 v0, 0x113c

    invoke-static {}, Lq23;->e()Lr72;

    move-result-object v2

    const/16 v0, 0xd67

    iput-object v2, p0, Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;->h:Lr72;

    const/16 v0, 0x132

    sget-object v3, Lh50;->a:Li20;

    nop

    const/16 v0, 0x126

    sget-object v3, Lx10;->c:Lx10;

    nop

    const/4 v0, -0x6

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x76b

    invoke-static {v3, v2}, Lns2;->x(Ljy;Lly;)Lly;

    move-result-object v2

    const/16 v0, 0xf43

    invoke-static {v2}, Lw53;->a(Lly;)Lsx;

    move-result-object v2

    const/16 v0, 0xc02

    iput-object v2, p0, Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;->i:Lsx;

    return-void
.end method


# virtual methods
.method public final onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .registers 4

    const/4 p0, 0x0

    return-object p0
.end method

.method public final onDestroy()V
    .registers 4

    const/16 v0, 0xc0a

    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    const/16 v0, 0xb2c

    iget-object p0, p0, Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;->h:Lr72;

    nop

    const/4 v2, 0x0

    const/16 v0, 0x43a

    invoke-virtual {p0, v2}, Lnv0;->a(Ljava/util/concurrent/CancellationException;)V

    return-void
.end method

.method public final onStartCommand(Landroid/content/Intent;II)I
    .registers 23

    .prologue
    const-string/jumbo p2, "slistUpdateThread"

    nop

    nop

    const/16 v6, 0x9e4

    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;->b:Ljava/util/ArrayList;

    move-object/16 p3, v6

    const/16 v6, 0x89d

    move-object/from16 v0, p0

    iget-object v8, v0, Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;->c:Ljava/util/ArrayList;

    nop

    const-string/jumbo v9, "consultThread"

    nop

    nop

    const/4 v10, 0x2

    if-eqz p1, :cond_1dd

    const/16 v6, 0x2f

    move-object/from16 v0, p1

    invoke-virtual {v0}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v11

    if-eqz v11, :cond_1dd

    const/16 v6, 0x51

    invoke-virtual {v11}, Ljava/lang/String;->hashCode()I

    move-result v12

    const v13, -0x4d68a486

    const/16 v6, 0xe20

    move-object/from16 v0, p0

    iget-object v14, v0, Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;->a:Lw82;

    nop

    const/4 v15, 0x3

    const/16 v6, 0x11ba

    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;->i:Lsx;

    move-object/16 v16, v6

    const/16 v17, 0x0

    const/16 v18, 0x0

    if-eq v12, v13, :cond_108

    const p2, 0x5d1942be

    move/from16 v0, p2

    if-eq v12, v0, :cond_50

    goto/16 :goto_1dd

    :cond_50
    const-string/jumbo p2, "CONSULTSTATUS"

    nop

    nop

    const/4 v6, -0x7

    move-object/from16 v0, p2

    invoke-virtual {v11, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-nez p2, :cond_60

    goto/16 :goto_1dd

    :cond_60
    const/16 v6, 0x4a9

    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;->f:Lgx;

    move-object/16 p2, v6

    if-eqz p2, :cond_d7

    const/16 v6, 0x2b8

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Thread;->isInterrupted()Z

    move-result p2

    if-nez p2, :cond_d7

    :try_start_75
    const/16 v6, 0x4a9

    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;->f:Lgx;

    move-object/16 p2, v6

    if-eqz p2, :cond_d2

    const/16 v6, 0x3e3

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Thread;->interrupt()V

    const/16 v6, 0x653

    move-object/from16 v0, p3

    invoke-static {v0, v8}, Lbs;->t0(Ljava/lang/Iterable;Ljava/util/Collection;)Ljava/util/ArrayList;

    move-result-object p2

    const/16 v6, 0xac

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v9

    :goto_97
    move/from16 v0, v17

    if-ge v0, v9, :cond_c5

    const/16 v6, 0x43

    move-object/from16 v0, p2

    move/from16 v1, v17

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v11

    add-int/lit8 v17, v17, 0x1

    check-cast v11, Llt1;

    const/16 v6, 0x245

    new-instance v12, Ljt1;

    nop

    const/4 v13, 0x1

    const/16 v6, 0x1c7

    move-object/from16 v0, v18

    invoke-direct {v12, v11, v0, v13}, Ljt1;-><init>(Llt1;Lvx;I)V

    const/16 v6, 0xb3

    move v0, v6

    move-object/from16 v1, v16

    move-object/from16 v2, v18

    move-object/from16 v3, v18

    move-object v4, v12

    move v5, v15

    invoke-static/range {v1 .. v5}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    goto :goto_97

    :cond_c5
    const/16 v6, 0x15b

    invoke-virtual {v8}, Ljava/util/ArrayList;->clear()V

    const/16 v6, 0x15b

    move-object/from16 v0, p3

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    goto :goto_d7

    :cond_d2
    const/4 v6, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw v18
    :try_end_d7
    .catch Ljava/lang/Exception; {:try_start_75 .. :try_end_d7} :catch_d7

    :catch_d7
    :cond_d7
    :goto_d7
    const/16 v6, 0x517

    new-instance p2, Lgx;

    nop

    const/16 v6, 0x177

    invoke-virtual {v14}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Landroid/content/SharedPreferences;

    const/4 v6, -0x6

    move-object/from16 v0, p3

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x51c

    move-object/from16 v0, p2

    move-object/from16 v1, p0

    move-object/from16 v2, p3

    move-object/from16 v3, p1

    invoke-direct {v0, v1, v2, v3}, Lgx;-><init>(Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;Landroid/content/SharedPreferences;Landroid/content/Intent;)V

    const/16 v6, 0x676

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    iput-object v1, v0, Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;->f:Lgx;

    const/16 v6, 0x41b

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    goto/16 :goto_1dd

    :cond_108
    const-string/jumbo p3, "SLISTUPDATE"

    nop

    nop

    const/4 v6, -0x7

    move-object/from16 v0, p3

    invoke-virtual {v11, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p3

    if-nez p3, :cond_118

    goto/16 :goto_1dd

    :cond_118
    const-string/jumbo p3, "cspl"

    nop

    nop

    const/16 v6, 0x151

    move-object/from16 v0, p1

    move-object/from16 v1, p3

    move/from16 v2, v17

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result p3

    const/16 v6, 0x41c

    move-object/from16 v0, p0

    iget-object v8, v0, Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;->g:Lgx;

    nop

    if-eqz v8, :cond_1ae

    const/16 v6, 0x2b8

    invoke-virtual {v8}, Ljava/lang/Thread;->isInterrupted()Z

    move-result v8

    if-nez v8, :cond_1ae

    :try_start_13a
    const/16 v6, 0x41c

    move-object/from16 v0, p0

    iget-object v8, v0, Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;->g:Lgx;

    nop

    if-eqz v8, :cond_1a7

    const/16 v6, 0x3e3

    invoke-virtual {v8}, Ljava/lang/Thread;->interrupt()V
    :try_end_148
    .catch Ljava/lang/Exception; {:try_start_13a .. :try_end_148} :catch_1ae

    const/16 v6, 0xf7a

    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;->d:Ljava/util/ArrayList;

    move-object/16 p2, v6

    const/16 v6, 0xfe6

    move-object/from16 v0, p0

    iget-object v8, v0, Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;->e:Ljava/util/ArrayList;

    nop

    if-eqz p3, :cond_15c

    move-object v9, v8

    goto :goto_15e

    :cond_15c
    move-object/from16 v9, p2

    :goto_15e
    :try_start_15e
    const/16 v6, 0xb5b

    invoke-virtual {v9}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v9

    const/4 v6, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :goto_168
    const/16 v6, 0x13e

    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_197

    const/16 v6, 0x16e

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    const/4 v6, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v11, Llt1;

    const/16 v6, 0x245

    new-instance v12, Ljt1;

    nop

    const/16 v6, 0x1c7

    move-object/from16 v0, v18

    invoke-direct {v12, v11, v0, v10}, Ljt1;-><init>(Llt1;Lvx;I)V

    const/16 v6, 0xb3

    move v0, v6

    move-object/from16 v1, v16

    move-object/from16 v2, v18

    move-object/from16 v3, v18

    move-object v4, v12

    move v5, v15

    invoke-static/range {v1 .. v5}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    goto :goto_168

    :cond_197
    if-eqz p3, :cond_19f

    const/16 v6, 0x15b

    invoke-virtual {v8}, Ljava/util/ArrayList;->clear()V

    goto :goto_1ae

    :cond_19f
    const/16 v6, 0x15b

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    goto :goto_1ae

    :cond_1a7
    const/4 v6, 0x5

    move-object/from16 v0, p2

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v18
    :try_end_1ae
    .catch Ljava/lang/Exception; {:try_start_15e .. :try_end_1ae} :catch_1ae

    :catch_1ae
    :cond_1ae
    :goto_1ae
    const/16 v6, 0x517

    new-instance p2, Lgx;

    nop

    const/16 v6, 0x177

    invoke-virtual {v14}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Landroid/content/SharedPreferences;

    const/4 v6, -0x6

    move-object/from16 v0, p3

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x51c

    move-object/from16 v0, p2

    move-object/from16 v1, p0

    move-object/from16 v2, p3

    move-object/from16 v3, p1

    invoke-direct {v0, v1, v2, v3}, Lgx;-><init>(Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;Landroid/content/SharedPreferences;Landroid/content/Intent;)V

    const/16 v6, 0x1039

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    iput-object v1, v0, Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;->g:Lgx;

    const/16 v6, 0x41b

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    :cond_1dd
    :goto_1dd
    return v10
.end method
