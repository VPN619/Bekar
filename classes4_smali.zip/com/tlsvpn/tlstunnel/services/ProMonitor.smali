.class public final Lcom/tlsvpn/tlstunnel/services/ProMonitor;
.super Landroid/app/Service;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lcom/android/billingclient/api/BillingClientStateListener;
.implements Lcom/android/billingclient/api/PurchasesUpdatedListener;
.implements Lcom/android/billingclient/api/PurchasesResponseListener;


# static fields
.field public static final synthetic e:I


# instance fields
.field public final a:Lw82;

.field public b:Lcom/android/billingclient/api/BillingClient;

.field public final c:Lr72;

.field public final d:Lsx;


# direct methods
.method public constructor <init>()V
    .registers 5

    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    const/16 v0, 0xa84

    new-instance v2, Ld;

    nop

    const/16 v3, 0x18

    const/16 v0, 0x6cb

    invoke-direct {v2, v3, p0}, Ld;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x27a

    new-instance v3, Lw82;

    nop

    const/16 v0, 0x215

    invoke-direct {v3, v2}, Lw82;-><init>(Lzj0;)V

    const/16 v0, 0x74c

    iput-object v3, p0, Lcom/tlsvpn/tlstunnel/services/ProMonitor;->a:Lw82;

    const/16 v0, 0x113c

    invoke-static {}, Lq23;->e()Lr72;

    move-result-object v2

    const/16 v0, 0x5f8

    iput-object v2, p0, Lcom/tlsvpn/tlstunnel/services/ProMonitor;->c:Lr72;

    const/16 v0, 0x132

    sget-object v3, Lh50;->a:Li20;

    nop

    const/16 v0, 0x126

    sget-object v3, Lx10;->c:Lx10;

    nop

    const/4 v0, -0x6

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x76b

    invoke-static {v3, v2}, Lns2;->x(Ljy;Lly;)Lly;

    move-result-object v2

    const/16 v0, 0xf43

    invoke-static {v2}, Lw53;->a(Lly;)Lsx;

    move-result-object v2

    const/16 v0, 0x668

    iput-object v2, p0, Lcom/tlsvpn/tlstunnel/services/ProMonitor;->d:Lsx;

    return-void
.end method


# virtual methods
.method public final a()V
    .registers 8

    return-void
.end method

.method public final b(Lcom/android/billingclient/api/BillingResult;Ljava/util/List;)V
    .registers 9

    const/4 v0, 0x1

    sput-boolean v0, Lmi2;->n:Z

    iget-object v0, p0, Lcom/tlsvpn/tlstunnel/services/ProMonitor;->a:Lw82;

    invoke-virtual {v0}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/content/SharedPreferences;

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const-string v2, "pvdata"

    const-string v3, "dummy:dummy"

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V

    new-instance v1, Landroid/content/Intent;

    const-string v2, "pVacTd"

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    invoke-virtual {p0, v1}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    invoke-virtual {p0}, Landroid/app/Service;->stopSelf()V

    return-void
.end method

.method public final onBillingServiceDisconnected()V
    .registers 3

    const/16 v0, 0x4f7

    invoke-virtual {p0}, Landroid/app/Service;->stopSelf()V

    return-void
.end method

.method public final onBillingSetupFinished(Lcom/android/billingclient/api/BillingResult;)V
    .registers 12

    .prologue
    const/4 v6, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x450

    invoke-virtual {p1}, Lcom/android/billingclient/api/BillingResult;->getResponseCode()I

    move-result p1

    if-nez p1, :cond_28

    const/16 v6, 0x64b

    new-instance p1, Len1;

    nop

    const/4 v8, 0x0

    const/16 v6, 0x98f

    invoke-direct {p1, p0, v8}, Len1;-><init>(Lcom/tlsvpn/tlstunnel/services/ProMonitor;Lvx;)V

    const/4 v9, 0x3

    const/16 v6, 0x56e

    iget-object p0, p0, Lcom/tlsvpn/tlstunnel/services/ProMonitor;->d:Lsx;

    nop

    const/16 v6, 0xb3

    move v0, v6

    move-object v1, p0

    move-object v2, v8

    move-object v3, v8

    move-object v4, p1

    move v5, v9

    invoke-static/range {v1 .. v5}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    :cond_28
    return-void
.end method

.method public final onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .registers 4

    const/4 p0, 0x0

    return-object p0
.end method

.method public final onCreate()V
    .registers 5

    const/16 v0, 0x1095

    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const/16 v0, 0x1155

    invoke-static {v2}, Lcom/android/billingclient/api/BillingClient;->newBuilder(Landroid/content/Context;)Lcom/android/billingclient/api/BillingClient$Builder;

    move-result-object v2

    const/16 v0, 0xcd8

    invoke-virtual {v2, p0}, Lcom/android/billingclient/api/BillingClient$Builder;->setListener(Lcom/android/billingclient/api/PurchasesUpdatedListener;)Lcom/android/billingclient/api/BillingClient$Builder;

    move-result-object v2

    const/16 v0, 0xc54

    invoke-static {}, Lcom/android/billingclient/api/PendingPurchasesParams;->newBuilder()Lcom/android/billingclient/api/PendingPurchasesParams$Builder;

    move-result-object v3

    const/16 v0, 0x66e

    invoke-virtual {v3}, Lcom/android/billingclient/api/PendingPurchasesParams$Builder;->enableOneTimeProducts()Lcom/android/billingclient/api/PendingPurchasesParams$Builder;

    move-result-object v3

    const/16 v0, 0x1025

    invoke-virtual {v3}, Lcom/android/billingclient/api/PendingPurchasesParams$Builder;->build()Lcom/android/billingclient/api/PendingPurchasesParams;

    move-result-object v3

    const/16 v0, 0xe8d

    invoke-virtual {v2, v3}, Lcom/android/billingclient/api/BillingClient$Builder;->enablePendingPurchases(Lcom/android/billingclient/api/PendingPurchasesParams;)Lcom/android/billingclient/api/BillingClient$Builder;

    move-result-object v2

    const/16 v0, 0xbe6

    invoke-virtual {v2}, Lcom/android/billingclient/api/BillingClient$Builder;->build()Lcom/android/billingclient/api/BillingClient;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x6ec

    iput-object v2, p0, Lcom/tlsvpn/tlstunnel/services/ProMonitor;->b:Lcom/android/billingclient/api/BillingClient;

    const/16 v0, 0x10d6

    invoke-virtual {v2, p0}, Lcom/android/billingclient/api/BillingClient;->startConnection(Lcom/android/billingclient/api/BillingClientStateListener;)V

    return-void
.end method

.method public final onDestroy()V
    .registers 5

    .prologue
    const/16 v0, 0xc0a

    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    const/4 v2, 0x0

    :try_start_6
    const/16 v0, 0x4ea

    iget-object v3, p0, Lcom/tlsvpn/tlstunnel/services/ProMonitor;->b:Lcom/android/billingclient/api/BillingClient;

    nop

    if-eqz v3, :cond_13

    const/16 v0, 0xe5e

    invoke-virtual {v3}, Lcom/android/billingclient/api/BillingClient;->endConnection()V

    goto :goto_1d

    :cond_13
    const-string/jumbo v3, "billingClient"

    nop

    nop

    const/4 v0, 0x5

    invoke-static {v3}, Lgt0;->F0(Ljava/lang/String;)V

    throw v2
    :try_end_1d
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_1d} :catch_1d

    :catch_1d
    :goto_1d
    const/16 v0, 0x552

    iget-object p0, p0, Lcom/tlsvpn/tlstunnel/services/ProMonitor;->c:Lr72;

    nop

    const/16 v0, 0x43a

    invoke-virtual {p0, v2}, Lnv0;->a(Ljava/util/concurrent/CancellationException;)V

    return-void
.end method

.method public final onPurchasesUpdated(Lcom/android/billingclient/api/BillingResult;Ljava/util/List;)V
    .registers 18

    const/4 v7, -0x6

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x38b

    new-instance v9, Lfn1;

    nop

    const/4 v14, 0x0

    const/4 v13, 0x0

    move-object v10, p0

    move-object/from16 v11, p1

    move-object/from16 v12, p2

    const/16 v7, 0x406

    move v0, v7

    move-object v1, v9

    move-object v2, v10

    move-object v3, v11

    move-object v4, v12

    move-object v5, v13

    move v6, v14

    invoke-direct/range {v1 .. v6}, Lfn1;-><init>(Lcom/tlsvpn/tlstunnel/services/ProMonitor;Lcom/android/billingclient/api/BillingResult;Ljava/util/List;Lvx;I)V

    const/4 p0, 0x3

    const/16 v7, 0x56e

    iget-object v7, v10, Lcom/tlsvpn/tlstunnel/services/ProMonitor;->d:Lsx;

    move-object/16 p1, v7

    const/16 v7, 0xb3

    move v0, v7

    move-object/from16 v1, p1

    move-object v2, v13

    move-object v3, v13

    move-object v4, v9

    move v5, p0

    invoke-static/range {v1 .. v5}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    return-void
.end method

.method public final onQueryPurchasesResponse(Lcom/android/billingclient/api/BillingResult;Ljava/util/List;)V
    .registers 18

    const/4 v7, -0x6

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v7, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x38b

    new-instance v9, Lfn1;

    nop

    const/4 v14, 0x1

    const/4 v13, 0x0

    move-object v10, p0

    move-object/from16 v11, p1

    move-object/from16 v12, p2

    const/16 v7, 0x406

    move v0, v7

    move-object v1, v9

    move-object v2, v10

    move-object v3, v11

    move-object v4, v12

    move-object v5, v13

    move v6, v14

    invoke-direct/range {v1 .. v6}, Lfn1;-><init>(Lcom/tlsvpn/tlstunnel/services/ProMonitor;Lcom/android/billingclient/api/BillingResult;Ljava/util/List;Lvx;I)V

    const/4 p0, 0x3

    const/16 v7, 0x56e

    iget-object v7, v10, Lcom/tlsvpn/tlstunnel/services/ProMonitor;->d:Lsx;

    move-object/16 p1, v7

    const/16 v7, 0xb3

    move v0, v7

    move-object/from16 v1, p1

    move-object v2, v13

    move-object v3, v13

    move-object v4, v9

    move v5, p0

    invoke-static/range {v1 .. v5}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    return-void
.end method

.method public final onStartCommand(Landroid/content/Intent;II)I
    .registers 8

    .prologue
    const/4 p2, 0x2

    if-eqz p1, :cond_5d

    const/16 v0, 0x2f

    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p1

    const-string/jumbo p3, "vrfysubs"

    nop

    nop

    const/16 v0, 0x84

    invoke-static {p1, p3}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_5d

    const/16 v0, 0x4ea

    iget-object p1, p0, Lcom/tlsvpn/tlstunnel/services/ProMonitor;->b:Lcom/android/billingclient/api/BillingClient;

    nop

    const/4 p3, 0x0

    const-string/jumbo v2, "billingClient"

    nop

    nop

    if-eqz p1, :cond_58

    const/16 v0, 0x1177

    invoke-virtual {p1}, Lcom/android/billingclient/api/BillingClient;->getConnectionState()I

    move-result p1

    if-ne p1, p2, :cond_5d

    const/16 v0, 0xdcb

    invoke-static {}, Lcom/android/billingclient/api/QueryPurchasesParams;->newBuilder()Lcom/android/billingclient/api/QueryPurchasesParams$Builder;

    move-result-object p1

    const-string/jumbo v3, "subs"

    nop

    nop

    const/16 v0, 0x102c

    invoke-virtual {p1, v3}, Lcom/android/billingclient/api/QueryPurchasesParams$Builder;->setProductType(Ljava/lang/String;)Lcom/android/billingclient/api/QueryPurchasesParams$Builder;

    move-result-object p1

    const/16 v0, 0x7a0

    invoke-virtual {p1}, Lcom/android/billingclient/api/QueryPurchasesParams$Builder;->build()Lcom/android/billingclient/api/QueryPurchasesParams;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x4ea

    iget-object v3, p0, Lcom/tlsvpn/tlstunnel/services/ProMonitor;->b:Lcom/android/billingclient/api/BillingClient;

    nop

    if-eqz v3, :cond_53

    const/16 v0, 0xbb2

    invoke-virtual {v3, p1, p0}, Lcom/android/billingclient/api/BillingClient;->queryPurchasesAsync(Lcom/android/billingclient/api/QueryPurchasesParams;Lcom/android/billingclient/api/PurchasesResponseListener;)V

    goto :goto_5d

    :cond_53
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_58
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_5d
    :goto_5d
    return p2
.end method
