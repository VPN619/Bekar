.class public final Lcom/tlsvpn/tlstunnel/ProtectedApp$ProtectedApp$ProtectedApp$j;
.super Ljava/lang/Object;


# static fields
.field public static m:Ljava/lang/String;

.field public static sCjw:Ljava/lang/String;


# instance fields
.field public final AzIFf:Z

.field public final B:Z

.field public final E:Z

.field public final EA:Z

.field public final Elz:Ljava/lang/String;

.field public final Gjf:Z

.field public final Gzos:Z

.field public final Ho:Z

.field public final fzgxE:Z

.field public final lpj:I

.field public final n:Z

.field public final p:Z

.field public final pf:Z

.field public final r:Ljava/lang/String;

.field public final rlt:Z

.field public final ulu:Z

.field public final whgJ:I

.field public final zcDG:Z


# direct methods
.method static constructor <clinit>()V
    .registers 18

    const/16 v7, 0xfec

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v9

    const/16 v7, 0x1272

    invoke-virtual {v9}, Ljava/util/UUID;->getMostSignificantBits()J

    move-result-wide v10

    const/16 v7, 0x1271

    invoke-virtual {v9}, Ljava/util/UUID;->getLeastSignificantBits()J

    move-result-wide v12

    const/16 v7, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v14

    const/16 v9, 0x10

    shl-long/2addr v14, v9

    const-wide/32 v16, 0xffff

    and-long v9, v10, v16

    or-long/2addr v9, v14

    const/16 v7, 0x1275

    new-instance v11, Ljava/util/UUID;

    nop

    const/16 v7, 0x1273

    move v0, v7

    move-object v1, v11

    move-wide v2, v9

    move-wide v4, v12

    invoke-direct/range {v1 .. v5}, Ljava/util/UUID;-><init>(JJ)V

    const/16 v7, 0x65c

    invoke-virtual {v11}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    sput-object v9, Lcom/tlsvpn/tlstunnel/ProtectedApp$ProtectedApp$ProtectedApp$j;->m:Ljava/lang/String;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;Ljava/lang/String;II)V
    .registers 8

    .prologue
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x126b

    sget-object p1, Lcom/tlsvpn/tlstunnel/ProtectedApp$ProtectedApp$ProtectedApp$j;->m:Ljava/lang/String;

    nop

    const/16 v0, 0x1269

    iput-object p1, p0, Lcom/tlsvpn/tlstunnel/ProtectedApp$ProtectedApp$ProtectedApp$j;->Elz:Ljava/lang/String;

    const/16 v0, 0x1268

    iput-object p2, p0, Lcom/tlsvpn/tlstunnel/ProtectedApp$ProtectedApp$ProtectedApp$j;->r:Ljava/lang/String;

    const/16 v0, 0x126c

    iput p3, p0, Lcom/tlsvpn/tlstunnel/ProtectedApp$ProtectedApp$ProtectedApp$j;->lpj:I

    and-int/lit8 p1, p3, 0x1

    const/4 p2, 0x0

    if-eqz p1, :cond_1a

    const/4 p2, 0x1

    :cond_1a
    const/16 v0, 0x1260

    iput-boolean p2, p0, Lcom/tlsvpn/tlstunnel/ProtectedApp$ProtectedApp$ProtectedApp$j;->n:Z

    and-int/lit8 p1, p3, 0x2

    const/4 p2, 0x0

    if-eqz p1, :cond_24

    const/4 p2, 0x1

    :cond_24
    const/16 v0, 0x125e

    iput-boolean p2, p0, Lcom/tlsvpn/tlstunnel/ProtectedApp$ProtectedApp$ProtectedApp$j;->zcDG:Z

    and-int/lit8 p1, p3, 0x4

    const/4 p2, 0x0

    if-eqz p1, :cond_2e

    const/4 p2, 0x1

    :cond_2e
    const/16 v0, 0x1261

    iput-boolean p2, p0, Lcom/tlsvpn/tlstunnel/ProtectedApp$ProtectedApp$ProtectedApp$j;->Gzos:Z

    and-int/lit8 p1, p3, 0x8

    const/4 p2, 0x0

    if-eqz p1, :cond_38

    const/4 p2, 0x1

    :cond_38
    const/16 v0, 0x126e

    iput-boolean p2, p0, Lcom/tlsvpn/tlstunnel/ProtectedApp$ProtectedApp$ProtectedApp$j;->E:Z

    and-int/lit8 p1, p3, 0x10

    const/4 p2, 0x0

    if-eqz p1, :cond_42

    const/4 p2, 0x1

    :cond_42
    const/16 v0, 0x125f

    iput-boolean p2, p0, Lcom/tlsvpn/tlstunnel/ProtectedApp$ProtectedApp$ProtectedApp$j;->p:Z

    and-int/lit8 p1, p3, 0x20

    const/4 p2, 0x0

    if-eqz p1, :cond_4c

    const/4 p2, 0x1

    :cond_4c
    const/16 v0, 0x1267

    iput-boolean p2, p0, Lcom/tlsvpn/tlstunnel/ProtectedApp$ProtectedApp$ProtectedApp$j;->EA:Z

    and-int/lit8 p1, p3, 0x40

    const/4 p2, 0x0

    if-eqz p1, :cond_56

    const/4 p2, 0x1

    :cond_56
    const/16 v0, 0x1270

    iput-boolean p2, p0, Lcom/tlsvpn/tlstunnel/ProtectedApp$ProtectedApp$ProtectedApp$j;->rlt:Z

    and-int/lit16 p1, p3, 0x80

    const/4 p2, 0x0

    if-eqz p1, :cond_60

    const/4 p2, 0x1

    :cond_60
    const/16 v0, 0x126f

    iput-boolean p2, p0, Lcom/tlsvpn/tlstunnel/ProtectedApp$ProtectedApp$ProtectedApp$j;->B:Z

    and-int/lit16 p1, p3, 0x100

    const/4 p2, 0x0

    if-eqz p1, :cond_6a

    const/4 p2, 0x1

    :cond_6a
    const/16 v0, 0x126a

    iput-boolean p2, p0, Lcom/tlsvpn/tlstunnel/ProtectedApp$ProtectedApp$ProtectedApp$j;->pf:Z

    and-int/lit16 p1, p3, 0x200

    const/4 p2, 0x0

    if-eqz p1, :cond_74

    const/4 p2, 0x1

    :cond_74
    const/16 v0, 0x1265

    iput-boolean p2, p0, Lcom/tlsvpn/tlstunnel/ProtectedApp$ProtectedApp$ProtectedApp$j;->AzIFf:Z

    and-int/lit8 p1, p4, 0x1

    const/4 p2, 0x0

    if-eqz p1, :cond_7e

    const/4 p2, 0x1

    :cond_7e
    const/16 v0, 0x1266

    iput-boolean p2, p0, Lcom/tlsvpn/tlstunnel/ProtectedApp$ProtectedApp$ProtectedApp$j;->ulu:Z

    and-int/lit8 p1, p4, 0x2

    const/4 p2, 0x0

    if-eqz p1, :cond_88

    const/4 p2, 0x1

    :cond_88
    const/16 v0, 0x126d

    iput-boolean p2, p0, Lcom/tlsvpn/tlstunnel/ProtectedApp$ProtectedApp$ProtectedApp$j;->fzgxE:Z

    and-int/lit8 p1, p4, 0x4

    const/4 p2, 0x0

    if-eqz p1, :cond_92

    const/4 p2, 0x1

    :cond_92
    const/16 v0, 0x1264

    iput-boolean p2, p0, Lcom/tlsvpn/tlstunnel/ProtectedApp$ProtectedApp$ProtectedApp$j;->Gjf:Z

    and-int/lit8 p1, p4, 0x8

    const/4 p2, 0x0

    if-eqz p1, :cond_9c

    const/4 p2, 0x1

    :cond_9c
    const/16 v0, 0x1262

    iput-boolean p2, p0, Lcom/tlsvpn/tlstunnel/ProtectedApp$ProtectedApp$ProtectedApp$j;->Ho:Z

    const/4 p1, 0x2

    const/16 v0, 0x1263

    iput p1, p0, Lcom/tlsvpn/tlstunnel/ProtectedApp$ProtectedApp$ProtectedApp$j;->whgJ:I

    return-void
.end method

.method public static native Fmi()Lcom/tlsvpn/tlstunnel/ProtectedApp$ProtectedApp$ProtectedApp$j;
.end method

.method public static lkxbAmF()V
    .registers 4

    const/16 v0, 0x1210

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    const/16 v0, 0x5d3

    new-instance v3, Landroid/os/Handler;

    nop

    const/16 v0, 0xad4

    invoke-direct {v3, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/16 v0, 0x1277

    new-instance v2, Lcom/tlsvpn/tlstunnel/ProtectedApp$ProtectedApp$ProtectedApp$ProtectedApp$j;

    nop

    const/16 v0, 0x1276

    invoke-direct {v2}, Lcom/tlsvpn/tlstunnel/ProtectedApp$ProtectedApp$ProtectedApp$ProtectedApp$j;-><init>()V

    const/16 v0, 0x1278

    invoke-virtual {v3, v2}, Landroid/os/Handler;->postAtFrontOfQueue(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public static nct(Ljava/lang/String;)V
    .registers 3

    return-void
.end method


# virtual methods
.method public native DbDtntf(Ljava/lang/String;)Ljava/lang/String;
.end method
