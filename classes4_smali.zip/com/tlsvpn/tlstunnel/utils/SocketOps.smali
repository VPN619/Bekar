.class public final Lcom/tlsvpn/tlstunnel/utils/SocketOps;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final a:Lcom/tlsvpn/tlstunnel/utils/SocketOps;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    const/16 v0, 0xea9

    new-instance v2, Lcom/tlsvpn/tlstunnel/utils/SocketOps;

    nop

    const/16 v0, 0x21a

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    check-cast v2, Lcom/tlsvpn/tlstunnel/utils/SocketOps;

    sput-object v2, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->a:Lcom/tlsvpn/tlstunnel/utils/SocketOps;

    const-string/jumbo v2, "zstd"

    const/16 v0, 0x41d

    invoke-static {v2}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V

    const-string/jumbo v2, "tlsvpn"

    const/16 v0, 0x41d

    invoke-static {v2}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V

    return-void
.end method


# virtual methods
.method public final native C()Ljava/lang/String;
.end method

.method public final native D(ILjava/lang/String;)V
.end method

.method public final native E(ILjava/lang/String;)Ljava/lang/String;
.end method

.method public final native F(I)V
.end method

.method public final native H(I)V
.end method

.method public final native I(I)V
.end method

.method public final native e(IIIJZ)V
.end method

.method public final native eA(J)Z
.end method

.method public final native g(ILjava/lang/String;Z)J
.end method

.method public final native i()I
.end method

.method public final native k(JLjava/lang/String;)Ljava/lang/String;
.end method

.method public final native q(JLjava/lang/String;)V
.end method

.method public final native r(IIIJLjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZ)D
.end method

.method public final native umI()Ljava/lang/String;
.end method

.method public final native v(I)Z
.end method

.method public final native x(J)V
.end method

.method public final native z()I
.end method
