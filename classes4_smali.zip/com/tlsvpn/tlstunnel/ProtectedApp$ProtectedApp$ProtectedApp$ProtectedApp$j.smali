.class public final Lcom/tlsvpn/tlstunnel/ProtectedApp$ProtectedApp$ProtectedApp$ProtectedApp$j;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# direct methods
.method public constructor <init>()V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 5

    const/16 v0, 0x379

    new-instance v2, Ljava/lang/RuntimeException;

    nop

    const/16 v0, 0x125d

    invoke-direct {v2}, Ljava/lang/RuntimeException;-><init>()V

    const/4 v3, 0x0

    new-array v3, v3, [Ljava/lang/StackTraceElement;

    const/16 v0, 0x125c

    invoke-virtual {v2, v3}, Ljava/lang/Throwable;->setStackTrace([Ljava/lang/StackTraceElement;)V

    check-cast v2, Ljava/lang/Throwable;

    throw v2
.end method
