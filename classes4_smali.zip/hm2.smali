.class public final Lhm2;
.super Landroid/content/BroadcastReceiver;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public a:F

.field public final synthetic b:Lcom/tlsvpn/tlstunnel/services/VpnConnection;


# direct methods
.method public constructor <init>(Lcom/tlsvpn/tlstunnel/services/VpnConnection;)V
    .registers 4

    iput-object p1, p0, Lhm2;->b:Lcom/tlsvpn/tlstunnel/services/VpnConnection;

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    return-void
.end method


# virtual methods
.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .registers 25

    .prologue
    move-object/from16 v4, p0

    move-object/from16 v5, p2

    const-string/jumbo v6, "cTp"

    const/16 v2, 0x577

    iget-object v7, v4, Lhm2;->b:Lcom/tlsvpn/tlstunnel/services/VpnConnection;

    nop

    const/16 v2, 0xb91

    iget-object v8, v7, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->h:Lou;

    nop

    const-string/jumbo v9, "-status"

    if-eqz v5, :cond_28b

    const/16 v2, 0x2f

    invoke-virtual {v5}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v10

    const-string/jumbo v11, "SERVERRPL"

    const/16 v2, 0x84

    invoke-static {v10, v11}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_28b

    const/4 v10, 0x0

    :try_start_28
    const/16 v2, 0xa8

    invoke-virtual {v5, v6, v10}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v11
    :try_end_2e
    .catch Ljava/lang/Exception; {:try_start_28 .. :try_end_2e} :catch_28b

    const/4 v13, 0x0

    const-wide/16 v14, 0x0

    const-string/jumbo v16, "rtime"

    const/16 v17, 0x1

    const-string/jumbo v18, "RPL"

    const-string/jumbo v19, "cId"

    const-string/jumbo v20, "servidores"

    const/16 v21, 0x3a

    if-nez v11, :cond_1f1

    :try_start_43
    const/16 v2, 0xa8

    move-object/from16 v0, v19

    invoke-virtual {v5, v0, v10}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v11

    const/16 p1, 0x0

    const/16 v2, 0x419

    iget v12, v7, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->J:I

    nop

    if-ne v11, v12, :cond_1f3

    const/16 v2, 0x8d

    move-object/from16 v0, v18

    invoke-virtual {v5, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    if-eqz v6, :cond_28b

    const/16 v2, 0x7c

    invoke-static {v6}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v11

    if-eqz v11, :cond_68

    goto/16 :goto_28b

    :cond_68
    move/from16 v0, v17

    new-array v11, v0, [C

    aput-char v21, v11, v10

    const/16 v2, 0x31

    invoke-static {v6, v11}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v11

    const/16 v2, 0x17d

    invoke-interface {v11}, Ljava/util/List;->size()I

    move-result v11

    const/4 v12, 0x5

    if-le v11, v12, :cond_28b

    move/from16 v0, v17

    new-array v11, v0, [C

    aput-char v21, v11, v10

    const/16 v2, 0x31

    invoke-static {v6, v11}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v11

    const/16 v2, 0x24

    invoke-interface {v11, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    const/16 v2, 0x47

    invoke-virtual {v11}, Ljava/lang/String;->length()I

    move-result v11

    move/from16 v0, v17

    new-array v12, v0, [C

    aput-char v21, v12, v10

    const/16 v2, 0x31

    invoke-static {v6, v12}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v12

    const/16 v2, 0x24

    move/from16 v0, v17

    invoke-interface {v12, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/String;

    const/16 v2, 0x47

    invoke-virtual {v12}, Ljava/lang/String;->length()I

    move-result v12

    add-int/2addr v11, v12

    const/4 v12, 0x2

    add-int/2addr v11, v12

    const/16 v2, 0x21c

    invoke-static {v6, v10, v11}, Lc72;->z0(Ljava/lang/CharSequence;II)Ljava/lang/CharSequence;

    move-result-object v11

    const/16 v2, 0xcb

    invoke-virtual {v11}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v11

    move/from16 v0, v17

    new-array v0, v0, [C

    move-object/from16 v18, v0

    aput-char v21, v18, v10

    const/16 v2, 0x31

    move-object/from16 v0, v18

    invoke-static {v11, v0}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v18

    const/16 v2, 0x24

    move-object/from16 v0, v18

    move/from16 v1, v17

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v18

    check-cast v18, Ljava/lang/String;

    const/16 v2, 0x2e9

    move-object/from16 v0, v18

    invoke-static {v0}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v18

    const/16 v2, 0x4dd

    move-object/from16 v0, v16

    invoke-virtual {v5, v0, v14, v15}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v14
    :try_end_ee
    .catch Ljava/lang/Exception; {:try_start_43 .. :try_end_ee} :catch_28b

    long-to-float v14, v14

    :try_start_ef
    move/from16 v0, v17

    new-array v15, v0, [C

    aput-char v21, v15, v10

    const/16 v2, 0x31

    invoke-static {v11, v15}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v15

    const/16 v2, 0x24

    invoke-interface {v15, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, Ljava/lang/String;

    const/16 v2, 0x2e9

    invoke-static {v12}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v12
    :try_end_109
    .catch Ljava/lang/Exception; {:try_start_ef .. :try_end_109} :catch_10a

    goto :goto_10c

    :catch_10a
    const/high16 v12, 0x43fa0000  # 500.0f

    :goto_10c
    const/high16 v15, 0x41400000  # 12.0f

    mul-float/2addr v14, v15

    add-float v14, v14, v18

    div-float/2addr v14, v12

    :try_start_112
    move/from16 v0, v17

    new-array v15, v0, [C

    aput-char v21, v15, v10

    const/16 v2, 0x31

    invoke-static {v11, v15}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v11

    const/4 v15, 0x4

    const/16 v2, 0x24

    invoke-interface {v11, v15}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    const/16 v2, 0x8e

    invoke-static {v11}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v11

    const/16 v2, 0xb1

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11
    :try_end_133
    .catch Ljava/lang/Exception; {:try_start_112 .. :try_end_133} :catch_134

    goto :goto_142

    :catch_134
    div-float v18, v18, v12

    const/high16 v11, 0x3f800000  # 1.0f

    add-float v18, v18, v11

    :try_start_13a
    const/16 v2, 0x77f

    move/from16 v0, v18

    invoke-static {v0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v11

    :goto_142
    const/16 v2, 0x46f

    iget v12, v4, Lhm2;->a:F

    nop

    cmpg-float v15, v14, v12

    if-ltz v15, :cond_14f

    cmpg-float v12, v12, v13

    if-nez v12, :cond_28b

    :cond_14f
    const/16 v2, 0x4e4

    iput v14, v4, Lhm2;->a:F

    move/from16 v0, v17

    new-array v4, v0, [C

    aput-char v21, v4, v10

    const/16 v2, 0x31

    invoke-static {v6, v4}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v4

    const/16 v2, 0x24

    invoke-interface {v4, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    const/4 v2, -0x6

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v2, -0x6

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v2, 0x244

    iput-object v4, v8, Lou;->i:Ljava/lang/String;

    const/16 v2, 0x110

    iget-object v4, v7, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->f:[Ljava/lang/String;

    nop

    if-eqz v4, :cond_1ea

    const/16 v2, 0x3b

    iget-object v6, v8, Lou;->i:Ljava/lang/String;

    nop

    const/16 v2, 0x48e

    invoke-static {v4, v6}, Laf;->a0([Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_1a1

    const/16 v2, 0x110

    iget-object v4, v7, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->f:[Ljava/lang/String;

    nop

    if-eqz v4, :cond_19a

    const/16 v2, 0x3b

    iget-object v6, v8, Lou;->i:Ljava/lang/String;

    nop

    const/16 v2, 0x1ed

    invoke-static {v6, v4}, Laf;->l0(Ljava/lang/Object;[Ljava/lang/Object;)I

    move-result v4

    goto :goto_1a2

    :cond_19a
    const/4 v2, 0x5

    move-object/from16 v0, v20

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_1a1
    move v4, v10

    :goto_1a2
    const/16 v2, 0x103

    iput v4, v8, Lou;->d:I

    const-string/jumbo v4, "srv"

    const/16 v2, 0xa8

    invoke-virtual {v5, v4, v10}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v4

    const/16 v2, 0x91

    iput v4, v8, Lou;->e:I

    const/16 v2, 0xcbf

    iget-object v4, v7, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->b:Landroid/content/SharedPreferences;

    nop

    const/16 v2, 0x7a

    invoke-interface {v4}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v4

    const/16 v2, 0x3b

    iget-object v5, v8, Lou;->i:Ljava/lang/String;

    nop

    const/16 v2, 0x1f7

    sget-object v6, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    nop

    const/16 v2, 0x3b0

    invoke-virtual {v5, v6}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v5

    const/4 v2, -0x6

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v2, 0xee

    invoke-virtual {v5, v9}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/16 v2, 0x4bd

    invoke-virtual {v11}, Ljava/lang/Number;->intValue()I

    move-result v6

    const/16 v2, 0x56

    invoke-interface {v4, v5, v6}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/16 v2, 0x6f

    invoke-interface {v4}, Landroid/content/SharedPreferences$Editor;->apply()V

    goto/16 :goto_28b

    :cond_1ea
    const/4 v2, 0x5

    move-object/from16 v0, v20

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_1f1
    const/16 p1, 0x0

    :cond_1f3
    const/16 v2, 0xa8

    invoke-virtual {v5, v6, v10}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v6

    const/4 v9, 0x3

    if-ne v6, v9, :cond_28b

    const/16 v2, 0xa8

    move-object/from16 v0, v19

    invoke-virtual {v5, v0, v10}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v6

    const/16 v2, 0x419

    iget v9, v7, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->J:I

    nop

    if-ne v6, v9, :cond_28b

    const/16 v2, 0x8d

    move-object/from16 v0, v18

    invoke-virtual {v5, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const/4 v2, -0x6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v2, 0x4dd

    move-object/from16 v0, v16

    invoke-virtual {v5, v0, v14, v15}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v11

    long-to-float v5, v11

    const/16 v2, 0x46f

    iget v9, v4, Lhm2;->a:F

    nop

    cmpg-float v11, v5, v9

    if-ltz v11, :cond_22d

    cmpg-float v9, v9, v13

    if-nez v9, :cond_28b

    :cond_22d
    const/16 v2, 0x4e4

    iput v5, v4, Lhm2;->a:F

    move/from16 v0, v17

    new-array v4, v0, [C

    aput-char v21, v4, v10

    const/16 v2, 0x31

    invoke-static {v6, v4}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v4

    const/16 v2, 0x24

    invoke-interface {v4, v10}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    const/4 v2, -0x6

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v2, -0x6

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v2, 0x244

    iput-object v4, v8, Lou;->i:Ljava/lang/String;

    const/16 v2, 0x110

    iget-object v4, v7, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->f:[Ljava/lang/String;

    nop

    if-eqz v4, :cond_284

    const/16 v2, 0x3b

    iget-object v5, v8, Lou;->i:Ljava/lang/String;

    nop

    const/16 v2, 0x48e

    invoke-static {v4, v5}, Laf;->a0([Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_27f

    const/16 v2, 0x110

    iget-object v4, v7, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->f:[Ljava/lang/String;

    nop

    if-eqz v4, :cond_278

    const/16 v2, 0x3b

    iget-object v5, v8, Lou;->i:Ljava/lang/String;

    nop

    const/16 v2, 0x1ed

    invoke-static {v5, v4}, Laf;->l0(Ljava/lang/Object;[Ljava/lang/Object;)I

    move-result v10

    goto :goto_27f

    :cond_278
    const/4 v2, 0x5

    move-object/from16 v0, v20

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_27f
    :goto_27f
    const/16 v2, 0x103

    iput v10, v8, Lou;->d:I

    return-void

    :cond_284
    const/4 v2, 0x5

    move-object/from16 v0, v20

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1
    :try_end_28b
    .catch Ljava/lang/Exception; {:try_start_13a .. :try_end_28b} :catch_28b

    :catch_28b
    :cond_28b
    :goto_28b
    return-void
.end method
