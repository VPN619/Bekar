.class public final Lso1;
.super Lvb;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final q:Lw82;

.field public r:Z

.field public s:Landroid/widget/ImageView;

.field public t:Landroid/widget/EditText;

.field public u:Lcom/google/android/material/textfield/TextInputLayout;

.field public v:Landroid/widget/EditText;

.field public w:Lcom/google/android/material/textfield/TextInputLayout;

.field public x:Landroidx/constraintlayout/widget/ConstraintLayout;


# direct methods
.method public constructor <init>()V
    .registers 5

    invoke-direct {p0}, Lvb;-><init>()V

    const/16 v0, 0xa84

    new-instance v2, Ld;

    nop

    const/16 v3, 0x1a

    const/16 v0, 0x6cb

    invoke-direct {v2, v3, p0}, Ld;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x27a

    new-instance v3, Lw82;

    nop

    const/16 v0, 0x215

    invoke-direct {v3, v2}, Lw82;-><init>(Lzj0;)V

    const/16 v0, 0x98c

    iput-object v3, p0, Lso1;->q:Lw82;

    const/4 v2, 0x1

    const/16 v0, 0x1202

    iput-boolean v2, p0, Lso1;->r:Z

    return-void
.end method


# virtual methods
.method public final c()V
    .registers 6

    .prologue
    const/16 v0, 0x1c1

    iget-object v2, p0, Lso1;->t:Landroid/widget/EditText;

    nop

    const/4 v3, 0x0

    if-eqz v2, :cond_7f

    const/16 v0, 0x2d

    invoke-virtual {v2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xff

    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    move-result v2

    const v4, 0x7f1300c8

    if-nez v2, :cond_38

    const/16 v0, 0x2e1

    iget-object v2, p0, Lso1;->u:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz v2, :cond_30

    const/16 v0, 0x4c

    invoke-virtual {p0, v4}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x6e

    invoke-virtual {v2, p0}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    return-void

    :cond_30
    const-string/jumbo p0, "prxhost_l"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_38
    const/16 v0, 0x526

    iget-object v2, p0, Lso1;->v:Landroid/widget/EditText;

    nop

    if-eqz v2, :cond_77

    const/16 v0, 0x2d

    invoke-virtual {v2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xff

    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    move-result v2

    if-nez v2, :cond_6c

    const/16 v0, 0x45a

    iget-object v2, p0, Lso1;->w:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz v2, :cond_64

    const/16 v0, 0x4c

    invoke-virtual {p0, v4}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x6e

    invoke-virtual {v2, p0}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    return-void

    :cond_64
    const-string/jumbo p0, "prxport_l"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_6c
    const/16 v0, 0x116b

    invoke-virtual {p0}, Lso1;->e()V

    const/16 v0, 0x181

    invoke-virtual {p0}, Landroidx/fragment/app/g;->dismiss()V

    return-void

    :cond_77
    const-string/jumbo p0, "prxport"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_7f
    const-string/jumbo p0, "prxhost"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3
.end method

.method public final d()V
    .registers 9

    .prologue
    const/16 v0, 0x1c1

    iget-object v2, p0, Lso1;->t:Landroid/widget/EditText;

    nop

    const/4 v3, 0x0

    const-string/jumbo v4, "prxhost"

    if-eqz v2, :cond_49

    const/16 v0, 0x1229

    iget-object v5, p0, Lso1;->q:Lw82;

    nop

    const/16 v0, 0x177

    invoke-virtual {v5}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/content/SharedPreferences;

    const-string/jumbo v7, ""

    const/16 v0, 0x2e

    invoke-interface {v6, v4, v7}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/16 v0, 0x8a

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v0, 0x526

    iget-object p0, p0, Lso1;->v:Landroid/widget/EditText;

    nop

    const-string/jumbo v2, "prxport"

    if-eqz p0, :cond_44

    const/16 v0, 0x177

    invoke-virtual {v5}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroid/content/SharedPreferences;

    const/16 v0, 0x2e

    invoke-interface {v3, v2, v7}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/16 v0, 0x8a

    invoke-virtual {p0, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    :cond_44
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_49
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3
.end method

.method public final e()V
    .registers 9

    .prologue
    const/16 v0, 0x1229

    iget-object v2, p0, Lso1;->q:Lw82;

    nop

    const/16 v0, 0x177

    invoke-virtual {v2}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/content/SharedPreferences;

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x7a

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const/16 v0, 0x1c1

    iget-object v3, p0, Lso1;->t:Landroid/widget/EditText;

    nop

    const/4 v4, 0x0

    const-string/jumbo v5, "prxhost"

    if-eqz v3, :cond_a0

    const/16 v0, 0x2d

    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v3

    const/4 v0, -0x6

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xff

    invoke-interface {v3}, Ljava/lang/CharSequence;->length()I

    move-result v3

    const-string/jumbo v6, "prxport"

    if-lez v3, :cond_57

    const/16 v0, 0x526

    iget-object v3, p0, Lso1;->v:Landroid/widget/EditText;

    nop

    if-eqz v3, :cond_52

    const/16 v0, 0x2d

    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v3

    const/4 v0, -0x6

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xff

    invoke-interface {v3}, Ljava/lang/CharSequence;->length()I

    move-result v3

    if-lez v3, :cond_57

    const/4 v3, 0x1

    goto :goto_58

    :cond_52
    const/4 v0, 0x5

    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_57
    const/4 v3, 0x0

    :goto_58
    const-string/jumbo v7, "uprx"

    const/16 v0, 0x48

    invoke-interface {v2, v7, v3}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x1c1

    iget-object v3, p0, Lso1;->t:Landroid/widget/EditText;

    nop

    if-eqz v3, :cond_9b

    const/16 v0, 0x2d

    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v3

    const/16 v0, 0xcb

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    const/16 v0, 0x3c

    invoke-interface {v2, v5, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x526

    iget-object p0, p0, Lso1;->v:Landroid/widget/EditText;

    nop

    if-eqz p0, :cond_96

    const/16 v0, 0x2d

    invoke-virtual {p0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p0

    const/16 v0, 0xcb

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x3c

    invoke-interface {v2, v6, p0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x6f

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void

    :cond_96
    const/4 v0, 0x5

    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_9b
    const/4 v0, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_a0
    const/4 v0, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .registers 6

    .prologue
    const/16 v0, 0x11c5

    invoke-super {p0, p1}, Landroidx/fragment/app/g;->onCreate(Landroid/os/Bundle;)V

    const/16 v0, 0xc2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getArguments()Landroid/os/Bundle;

    move-result-object p1

    if-eqz p1, :cond_1b

    const-string/jumbo v2, "eptalert"

    const/4 v3, 0x1

    const/16 v0, 0x428

    invoke-virtual {p1, v2, v3}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;Z)Z

    move-result p1

    const/16 v0, 0x1202

    iput-boolean p1, p0, Lso1;->r:Z

    :cond_1b
    return-void
.end method

.method public final onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .registers 11

    .prologue
    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const p3, 0x7f0c00c6

    const/4 v2, 0x0

    const/16 v0, 0x107b

    invoke-virtual {p1, p3, p2, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    const p2, 0x7f09013b

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/ImageView;

    const/16 v0, 0x1135

    iput-object p2, p0, Lso1;->s:Landroid/widget/ImageView;

    const p2, 0x7f0902d5

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/EditText;

    const/16 v0, 0xff9

    iput-object p2, p0, Lso1;->t:Landroid/widget/EditText;

    const p2, 0x7f0902d6

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Lcom/google/android/material/textfield/TextInputLayout;

    const/16 v0, 0x6d2

    iput-object p2, p0, Lso1;->u:Lcom/google/android/material/textfield/TextInputLayout;

    const p2, 0x7f0902d7

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/EditText;

    const/16 v0, 0x77a

    iput-object p2, p0, Lso1;->v:Landroid/widget/EditText;

    const p2, 0x7f0902d8

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Lcom/google/android/material/textfield/TextInputLayout;

    const/16 v0, 0xea2

    iput-object p2, p0, Lso1;->w:Lcom/google/android/material/textfield/TextInputLayout;

    const p2, 0x7f090058

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroidx/constraintlayout/widget/ConstraintLayout;

    const/16 v0, 0x1162

    iput-object p2, p0, Lso1;->x:Landroidx/constraintlayout/widget/ConstraintLayout;

    const/16 v0, 0x1c1

    iget-object p2, p0, Lso1;->t:Landroid/widget/EditText;

    nop

    const/4 p3, 0x0

    const-string/jumbo v3, "prxhost"

    if-eqz p2, :cond_1bb

    const/16 v0, 0xb36

    new-instance v4, Lc;

    nop

    const/16 v5, 0x18

    const/16 v0, 0x87c

    invoke-direct {v4, v5, p0}, Lc;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x1156

    invoke-virtual {p2, v4}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    const/16 v0, 0x1c1

    iget-object p2, p0, Lso1;->t:Landroid/widget/EditText;

    nop

    if-eqz p2, :cond_1b6

    const/16 v0, 0x3d8

    new-instance v4, Lro1;

    nop

    const/16 v0, 0x48d

    invoke-direct {v4, p0, v2}, Lro1;-><init>(Lvb;I)V

    const/16 v0, 0xb8

    invoke-virtual {p2, v4}, Landroid/widget/TextView;->addTextChangedListener(Landroid/text/TextWatcher;)V

    const/16 v0, 0x526

    iget-object p2, p0, Lso1;->v:Landroid/widget/EditText;

    nop

    const-string/jumbo v4, "prxport"

    if-eqz p2, :cond_1b1

    const/16 v0, 0x3d8

    new-instance v5, Lro1;

    nop

    const/4 v6, 0x1

    const/16 v0, 0x48d

    invoke-direct {v5, p0, v6}, Lro1;-><init>(Lvb;I)V

    const/16 v0, 0xb8

    invoke-virtual {p2, v5}, Landroid/widget/TextView;->addTextChangedListener(Landroid/text/TextWatcher;)V

    const/16 v0, 0xc3a

    iget-boolean p2, p0, Lso1;->r:Z

    nop

    if-eqz p2, :cond_148

    const/16 v0, 0x1c1

    iget-object p2, p0, Lso1;->t:Landroid/widget/EditText;

    nop

    if-eqz p2, :cond_143

    const/16 v0, 0x2d

    invoke-virtual {p2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xff

    invoke-interface {p2}, Ljava/lang/CharSequence;->length()I

    move-result p2

    const v3, 0x7f1300c8

    if-nez p2, :cond_10a

    const/16 v0, 0x2e1

    iget-object p2, p0, Lso1;->u:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz p2, :cond_102

    const/16 v0, 0x4c

    invoke-virtual {p0, v3}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v5

    const/16 v0, 0x6e

    invoke-virtual {p2, v5}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    goto :goto_10a

    :cond_102
    const-string/jumbo p0, "prxhost_l"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_10a
    :goto_10a
    const/16 v0, 0x526

    iget-object p2, p0, Lso1;->v:Landroid/widget/EditText;

    nop

    if-eqz p2, :cond_13e

    const/16 v0, 0x2d

    invoke-virtual {p2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xff

    invoke-interface {p2}, Ljava/lang/CharSequence;->length()I

    move-result p2

    if-nez p2, :cond_148

    const/16 v0, 0x45a

    iget-object p2, p0, Lso1;->w:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz p2, :cond_136

    const/16 v0, 0x4c

    invoke-virtual {p0, v3}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/16 v0, 0x6e

    invoke-virtual {p2, v3}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    goto :goto_148

    :cond_136
    const-string/jumbo p0, "prxport_l"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_13e
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_143
    const/4 v0, 0x5

    invoke-static {v3}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_148
    :goto_148
    const/16 v0, 0x121f

    iget-object p2, p0, Lso1;->s:Landroid/widget/ImageView;

    nop

    if-eqz p2, :cond_1a9

    const/16 v0, 0x4f3

    new-instance v3, Lqo1;

    nop

    const/16 v0, 0x2f5

    invoke-direct {v3, p0, v2}, Lqo1;-><init>(Lso1;I)V

    const/16 v0, 0x5f

    invoke-virtual {p2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0x5df

    iget-object p2, p0, Lso1;->x:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz p2, :cond_1a1

    const/16 v0, 0x4f3

    new-instance p3, Lqo1;

    nop

    const/16 v0, 0x2f5

    invoke-direct {p3, p0, v6}, Lqo1;-><init>(Lso1;I)V

    const/16 v0, 0x5f

    invoke-virtual {p2, p3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0xc39

    invoke-virtual {p0}, Lso1;->d()V

    const/16 v0, 0x140

    sget-boolean p2, Lg4;->a:Z

    nop

    const/16 v0, 0xfb

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x1229

    iget-object p0, p0, Lso1;->q:Lw82;

    nop

    const/16 v0, 0x177

    invoke-virtual {p0}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/content/SharedPreferences;

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x394

    invoke-static {p0, p2}, Lg4;->n(Landroid/content/SharedPreferences;Landroidx/fragment/app/l;)V

    check-cast p1, Landroid/view/View;

    return-object p1

    :cond_1a1
    const-string/jumbo p0, "btnAplicar"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_1a9
    const-string/jumbo p0, "top_bar_right_icon"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_1b1
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_1b6
    const/4 v0, 0x5

    invoke-static {v3}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_1bb
    const/4 v0, 0x5

    invoke-static {v3}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3
.end method

.method public final onDestroyView()V
    .registers 6

    .prologue
    const/16 v0, 0x53a

    invoke-super {p0}, Landroidx/fragment/app/g;->onDestroyView()V

    const/16 v0, 0x22f

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v2

    if-eqz v2, :cond_3d

    const/16 v0, 0x5b

    new-instance v3, Landroid/content/Intent;

    nop

    const-string/jumbo v4, "restoremtdcfg"

    const/16 v0, 0x62

    invoke-direct {v3, v4}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x22f

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object p0

    if-eqz p0, :cond_31

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    if-eqz p0, :cond_31

    const/16 v0, 0x4a

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    goto :goto_32

    :cond_31
    const/4 p0, 0x0

    :goto_32
    const/16 v0, 0x64

    invoke-virtual {v3, p0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    const/16 v0, 0x63

    invoke-virtual {v2, p0}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    :cond_3d
    return-void
.end method

.method public final onPause()V
    .registers 3

    const/16 v0, 0xbf8

    invoke-super {p0}, Landroidx/fragment/app/Fragment;->onPause()V

    const/16 v0, 0x116b

    invoke-virtual {p0}, Lso1;->e()V

    return-void
.end method

.method public final onResume()V
    .registers 3

    const/16 v0, 0x7d7

    invoke-super {p0}, Landroidx/fragment/app/Fragment;->onResume()V

    const/16 v0, 0xc39

    invoke-virtual {p0}, Lso1;->d()V

    return-void
.end method

.method public final onStart()V
    .registers 5

    .prologue
    const/16 v0, 0x55f

    invoke-super {p0}, Landroidx/fragment/app/g;->onStart()V

    const/16 v0, 0xaeb

    invoke-virtual {p0}, Landroidx/fragment/app/g;->getDialog()Landroid/app/Dialog;

    move-result-object p0

    if-eqz p0, :cond_34

    const/16 v0, 0xc8b

    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object p0

    if-eqz p0, :cond_34

    const/4 v2, -0x1

    const/4 v3, -0x2

    const/16 v0, 0x1132

    invoke-virtual {p0, v2, v3}, Landroid/view/Window;->setLayout(II)V

    const/16 v0, 0x10ad

    new-instance v2, Landroid/graphics/drawable/ColorDrawable;

    nop

    const/4 v3, 0x0

    const/16 v0, 0xc14

    invoke-direct {v2, v3}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    const/16 v0, 0xba3

    invoke-virtual {p0, v2}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    const v2, 0x7f140137

    const/16 v0, 0xa0d

    invoke-virtual {p0, v2}, Landroid/view/Window;->setWindowAnimations(I)V

    :cond_34
    return-void
.end method
