.class public final Lwj1;
.super Lkk;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final q:Lw82;


# direct methods
.method public constructor <init>()V
    .registers 5

    invoke-direct {p0}, Lkk;-><init>()V

    const/16 v0, 0xa84

    new-instance v2, Ld;

    nop

    const/16 v3, 0x15

    const/16 v0, 0x6cb

    invoke-direct {v2, v3, p0}, Ld;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x27a

    new-instance v3, Lw82;

    nop

    const/16 v0, 0x215

    invoke-direct {v3, v2}, Lw82;-><init>(Lzj0;)V

    const/16 v0, 0x1216

    iput-object v3, p0, Lwj1;->q:Lw82;

    return-void
.end method


# virtual methods
.method public final onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .registers 10

    .prologue
    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const p3, 0x7f0c00b2

    const/4 v2, 0x0

    const/16 v0, 0x107b

    invoke-virtual {p1, p3, p2, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    const p2, 0x7f0902bd

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    check-cast p2, Landroid/widget/TextView;

    const/16 v0, 0xd5

    new-instance p3, Landroid/util/TypedValue;

    nop

    const/16 v0, 0xe7

    invoke-direct {p3}, Landroid/util/TypedValue;-><init>()V

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v3

    const/16 v0, 0x1a9

    invoke-virtual {v3}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v3

    const v4, 0x7f04029c

    const/4 v5, 0x1

    const/16 v0, 0x68

    invoke-virtual {v3, v4, p3, v5}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    const v3, 0xffffff

    const/16 v0, 0x9b

    iget p3, p3, Landroid/util/TypedValue;->data:I

    nop

    and-int/2addr p3, v3

    const/16 v0, 0xb1

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p3

    filled-new-array {p3}, [Ljava/lang/Object;

    move-result-object p3

    const/16 v0, 0x120e

    invoke-static {p3, v5}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p3

    const-string/jumbo v3, "#%06X"

    const/16 v0, 0x377

    invoke-static {v3, p3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p3

    const-string/jumbo v3, "http.agent"

    const/16 v0, 0x77d

    invoke-static {v3}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const v4, 0x7f1301f0

    const/16 v0, 0x4c

    invoke-virtual {p0, v4}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v4

    const/4 v0, -0x6

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string/jumbo v5, "?hintTextColor"

    const/16 v0, 0x1a

    invoke-static {v4, v5, p3, v2}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p3

    if-nez v3, :cond_9c

    const/4 v0, -0x3

    new-instance v3, Ljava/lang/StringBuilder;

    nop

    const/4 v0, -0x4

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const v4, 0x7f130024

    const/16 v0, 0x4c

    invoke-virtual {p0, v4}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v4

    const/4 v0, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v4, "/8.1.0"

    const/4 v0, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    :cond_9c
    const-string/jumbo v4, "?userAgent"

    const/16 v0, 0x1a

    invoke-static {p3, v4, v3, v2}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p3

    const/16 v2, 0x3f

    const/16 v0, 0x9b4

    invoke-static {p3, v2}, Landroid/text/Html;->fromHtml(Ljava/lang/String;I)Landroid/text/Spanned;

    move-result-object p3

    const/16 v0, 0x8a

    invoke-virtual {p2, p3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v0, 0x140

    sget-boolean p2, Lg4;->a:Z

    nop

    const/16 v0, 0xfb

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xa46

    iget-object p0, p0, Lwj1;->q:Lw82;

    nop

    const/16 v0, 0x177

    invoke-virtual {p0}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/content/SharedPreferences;

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x394

    invoke-static {p0, p2}, Lg4;->n(Landroid/content/SharedPreferences;Landroidx/fragment/app/l;)V

    check-cast p1, Landroid/view/View;

    return-object p1
.end method

.method public final onStart()V
    .registers 6

    .prologue
    const/16 v0, 0x55f

    invoke-super {p0}, Landroidx/fragment/app/g;->onStart()V

    const/16 v0, 0xaeb

    invoke-virtual {p0}, Landroidx/fragment/app/g;->getDialog()Landroid/app/Dialog;

    move-result-object v2

    instance-of v3, v2, Ljk;

    const/4 v4, 0x0

    if-eqz v3, :cond_13

    check-cast v2, Ljk;

    goto :goto_14

    :cond_13
    move-object v2, v4

    :goto_14
    if-eqz v2, :cond_1c

    const/16 v0, 0xff7

    invoke-virtual {v2}, Ljk;->f()Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    move-result-object v4

    :cond_1c
    const/16 v0, 0x1c6

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/16 v0, 0x84a

    invoke-virtual {p0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object p0

    const/16 v0, 0x8b5

    iget p0, p0, Landroid/content/res/Configuration;->orientation:I

    nop

    const/4 v2, 0x2

    if-ne p0, v2, :cond_3d

    if-eqz v4, :cond_3d

    const/4 p0, 0x3

    const/16 v0, 0x8a6

    invoke-virtual {v4, p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->L(I)V

    const/4 p0, 0x1

    const/16 v0, 0x1099

    iput-boolean p0, v4, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->K:Z

    :cond_3d
    return-void
.end method
