.class public final Lwu;
.super Lvb;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public A:Landroid/widget/CheckBox;

.field public B:Lcom/google/android/material/textfield/TextInputEditText;

.field public C:Lcom/google/android/material/textfield/TextInputLayout;

.field public D:Landroid/widget/CheckBox;

.field public E:Landroid/widget/LinearLayout;

.field public F:Landroid/widget/TextView;

.field public G:Landroid/widget/TextView;

.field public H:Landroidx/constraintlayout/widget/ConstraintLayout;

.field public final I:Lob;

.field public final q:Lw82;

.field public r:Landroid/widget/ImageView;

.field public s:Landroid/widget/Spinner;

.field public t:Landroid/widget/LinearLayout;

.field public u:Landroid/widget/CheckBox;

.field public v:Lcom/google/android/material/textfield/TextInputLayout;

.field public w:Lcom/google/android/material/textfield/TextInputEditText;

.field public x:Landroid/widget/CheckBox;

.field public y:Lcom/google/android/material/textfield/TextInputLayout;

.field public z:Lcom/google/android/material/textfield/TextInputEditText;


# direct methods
.method public constructor <init>()V
    .registers 5

    invoke-direct {p0}, Lvb;-><init>()V

    const/16 v0, 0xa84

    new-instance v2, Ld;

    nop

    const/4 v3, 0x6

    const/16 v0, 0x6cb

    invoke-direct {v2, v3, p0}, Ld;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x27a

    new-instance v3, Lw82;

    nop

    const/16 v0, 0x215

    invoke-direct {v3, v2}, Lw82;-><init>(Lzj0;)V

    const/16 v0, 0xb43

    iput-object v3, p0, Lwu;->q:Lw82;

    const/16 v0, 0xf6e

    new-instance v2, Lob;

    nop

    const/4 v3, 0x2

    const/16 v0, 0x11c1

    invoke-direct {v2, v3, p0}, Lob;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x541

    iput-object v2, p0, Lwu;->I:Lob;

    return-void
.end method


# virtual methods
.method public final c()Landroid/content/SharedPreferences;
    .registers 3

    const/16 v0, 0xa7c

    iget-object p0, p0, Lwu;->q:Lw82;

    nop

    const/16 v0, 0x177

    invoke-virtual {p0}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/content/SharedPreferences;

    return-object p0
.end method

.method public final d()V
    .registers 16

    .prologue
    const/16 v6, 0x8ea

    new-instance v8, Lou;

    nop

    const/16 v6, 0x111

    invoke-virtual {p0}, Lwu;->c()Landroid/content/SharedPreferences;

    move-result-object v9

    const/4 v6, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x1c6

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getResources()Landroid/content/res/Resources;

    move-result-object v10

    const/4 v6, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v11, 0x0

    const/16 v6, 0x83d

    move v0, v6

    move-object v1, v8

    move-object v2, v9

    move-object v3, v10

    move v4, v11

    move v5, v11

    invoke-direct/range {v1 .. v5}, Lou;-><init>(Landroid/content/SharedPreferences;Landroid/content/res/Resources;ZZ)V

    const/16 v6, 0x75

    iget-boolean v9, v8, Lou;->w:Z

    nop

    if-eqz v9, :cond_31

    const/16 v6, 0x181

    invoke-virtual {p0}, Landroidx/fragment/app/g;->dismiss()V

    :cond_31
    const/16 v6, 0x8cf

    iget-object v9, p0, Lwu;->s:Landroid/widget/Spinner;

    nop

    const/4 v10, 0x0

    if-eqz v9, :cond_164

    const/16 v6, 0x1b8

    iget v12, v8, Lou;->m:I

    nop

    const/16 v6, 0x1c6

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getResources()Landroid/content/res/Resources;

    move-result-object v13

    const v14, 0x7f030004

    const/16 v6, 0x3e2

    invoke-virtual {v13, v14}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v13

    array-length v13, v13

    if-lt v12, v13, :cond_51

    goto :goto_56

    :cond_51
    const/16 v6, 0x1b8

    iget v11, v8, Lou;->m:I

    nop

    :goto_56
    const/16 v6, 0x820

    invoke-virtual {v9, v11}, Landroid/widget/AdapterView;->setSelection(I)V

    const/16 v6, 0x11b0

    iget-object v9, p0, Lwu;->u:Landroid/widget/CheckBox;

    nop

    if-eqz v9, :cond_15c

    const/16 v6, 0x8eb

    iget-boolean v11, v8, Lou;->n:Z

    nop

    const/16 v6, 0x7e

    invoke-virtual {v9, v11}, Landroid/widget/CompoundButton;->setChecked(Z)V

    const/16 v6, 0x7fe

    iget-object v9, p0, Lwu;->w:Lcom/google/android/material/textfield/TextInputEditText;

    nop

    if-eqz v9, :cond_154

    const/16 v6, 0x285

    iget-object v11, v8, Lou;->o:Ljava/lang/String;

    nop

    const/16 v6, 0x8a

    invoke-virtual {v9, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v6, 0xbf1

    iget-object v9, p0, Lwu;->x:Landroid/widget/CheckBox;

    nop

    if-eqz v9, :cond_14c

    const/16 v6, 0x7f

    iget-boolean v11, v8, Lou;->p:Z

    nop

    const/16 v6, 0x7e

    invoke-virtual {v9, v11}, Landroid/widget/CompoundButton;->setChecked(Z)V

    const/16 v6, 0xb3d

    iget-object v9, p0, Lwu;->z:Lcom/google/android/material/textfield/TextInputEditText;

    nop

    if-eqz v9, :cond_144

    const/16 v6, 0x26e

    iget-object v11, v8, Lou;->q:Ljava/lang/String;

    nop

    const/16 v6, 0x8a

    invoke-virtual {v9, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v6, 0x339

    iget-object v9, p0, Lwu;->A:Landroid/widget/CheckBox;

    nop

    if-eqz v9, :cond_13c

    const/16 v6, 0xfdd

    iget-boolean v11, v8, Lou;->r:Z

    nop

    const/16 v6, 0x7e

    invoke-virtual {v9, v11}, Landroid/widget/CompoundButton;->setChecked(Z)V

    const/16 v6, 0xbd3

    iget-object v9, p0, Lwu;->B:Lcom/google/android/material/textfield/TextInputEditText;

    nop

    if-eqz v9, :cond_134

    const/16 v6, 0x2e3

    iget-object v11, v8, Lou;->s:Ljava/lang/String;

    nop

    const/16 v6, 0x8a

    invoke-virtual {v9, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v6, 0xd59

    iget-object v9, p0, Lwu;->D:Landroid/widget/CheckBox;

    nop

    if-eqz v9, :cond_12c

    const/16 v6, 0x3f5

    iget-boolean v11, v8, Lou;->t:Z

    nop

    const/16 v6, 0x7e

    invoke-virtual {v9, v11}, Landroid/widget/CompoundButton;->setChecked(Z)V

    const/16 v6, 0x78f

    iget-object v9, p0, Lwu;->F:Landroid/widget/TextView;

    nop

    if-eqz v9, :cond_124

    const/16 v6, 0x1e1

    iget-object v11, v8, Lou;->u:Ljava/lang/String;

    nop

    const/16 v6, 0xff

    invoke-interface {v11}, Ljava/lang/CharSequence;->length()I

    move-result v12

    const v13, 0x7f1300c8

    if-nez v12, :cond_f3

    const/16 v6, 0x4c

    invoke-virtual {p0, v13}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v11

    const/4 v6, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :cond_f3
    const/16 v6, 0x8a

    invoke-virtual {v9, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v6, 0xd6e

    iget-object v9, p0, Lwu;->G:Landroid/widget/TextView;

    nop

    if-eqz v9, :cond_11c

    const/16 v6, 0x1f4

    iget-object v8, v8, Lou;->v:Ljava/lang/String;

    nop

    const/16 v6, 0xff

    invoke-interface {v8}, Ljava/lang/CharSequence;->length()I

    move-result v10

    if-nez v10, :cond_116

    const/16 v6, 0x4c

    invoke-virtual {p0, v13}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v8

    const/4 v6, -0x6

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :cond_116
    const/16 v6, 0x8a

    invoke-virtual {v9, v8}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    :cond_11c
    const-string/jumbo p0, "prxport"

    const/4 v6, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_124
    const-string/jumbo p0, "prxhost"

    const/4 v6, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_12c
    const-string/jumbo p0, "useprxserver"

    const/4 v6, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_134
    const-string/jumbo p0, "payloadas"

    const/4 v6, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_13c
    const-string/jumbo p0, "usepayloadas"

    const/4 v6, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_144
    const-string/jumbo p0, "snihost"

    const/4 v6, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_14c
    const-string/jumbo p0, "usesnihost"

    const/4 v6, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_154
    const-string/jumbo p0, "payload"

    const/4 v6, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_15c
    const-string/jumbo p0, "usepayload"

    const/4 v6, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_164
    const-string/jumbo p0, "spnMetodos"

    const/4 v6, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10
.end method

.method public final e()V
    .registers 7

    .prologue
    const/16 v0, 0x111

    invoke-virtual {p0}, Lwu;->c()Landroid/content/SharedPreferences;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x7a

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const/16 v0, 0x8cf

    iget-object v3, p0, Lwu;->s:Landroid/widget/Spinner;

    nop

    const/4 v4, 0x0

    if-eqz v3, :cond_141

    const/16 v0, 0x1e2

    invoke-virtual {v3}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    move-result v3

    const-string/jumbo v5, "metodo"

    const/16 v0, 0x56

    invoke-interface {v2, v5, v3}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x11b0

    iget-object v3, p0, Lwu;->u:Landroid/widget/CheckBox;

    nop

    if-eqz v3, :cond_139

    const/16 v0, 0x36

    invoke-virtual {v3}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v3

    const-string/jumbo v5, "upayload"

    const/16 v0, 0x48

    invoke-interface {v2, v5, v3}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x7fe

    iget-object v3, p0, Lwu;->w:Lcom/google/android/material/textfield/TextInputEditText;

    nop

    const-string/jumbo v5, "payload"

    if-eqz v3, :cond_134

    const/16 v0, 0x20b

    invoke-virtual {v3}, Lyb;->getText()Landroid/text/Editable;

    move-result-object v3

    const/16 v0, 0x1a8

    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    const/16 v0, 0x3c

    invoke-interface {v2, v5, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0xbf1

    iget-object v3, p0, Lwu;->x:Landroid/widget/CheckBox;

    nop

    if-eqz v3, :cond_12c

    const/16 v0, 0x36

    invoke-virtual {v3}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v3

    const-string/jumbo v5, "usnihost"

    const/16 v0, 0x48

    invoke-interface {v2, v5, v3}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0xb3d

    iget-object v3, p0, Lwu;->z:Lcom/google/android/material/textfield/TextInputEditText;

    nop

    const-string/jumbo v5, "snihost"

    if-eqz v3, :cond_127

    const/16 v0, 0x20b

    invoke-virtual {v3}, Lyb;->getText()Landroid/text/Editable;

    move-result-object v3

    const/16 v0, 0x1a8

    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    const/16 v0, 0x3c

    invoke-interface {v2, v5, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x339

    iget-object v3, p0, Lwu;->A:Landroid/widget/CheckBox;

    nop

    if-eqz v3, :cond_11f

    const/16 v0, 0x36

    invoke-virtual {v3}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v3

    const-string/jumbo v5, "upayloadat"

    const/16 v0, 0x48

    invoke-interface {v2, v5, v3}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0xbd3

    iget-object v3, p0, Lwu;->B:Lcom/google/android/material/textfield/TextInputEditText;

    nop

    if-eqz v3, :cond_117

    const/16 v0, 0x20b

    invoke-virtual {v3}, Lyb;->getText()Landroid/text/Editable;

    move-result-object v3

    const/16 v0, 0x1a8

    invoke-static {v3}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    const-string/jumbo v5, "payloadat"

    const/16 v0, 0x3c

    invoke-interface {v2, v5, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0xd59

    iget-object v3, p0, Lwu;->D:Landroid/widget/CheckBox;

    nop

    if-eqz v3, :cond_10f

    const/16 v0, 0x36

    invoke-virtual {v3}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v3

    if-eqz v3, :cond_100

    const/16 v0, 0x111

    invoke-virtual {p0}, Lwu;->c()Landroid/content/SharedPreferences;

    move-result-object v3

    const-string/jumbo v4, "prxhost"

    const-string/jumbo v5, ""

    const/16 v0, 0x2e

    invoke-interface {v3, v4, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v0, -0x6

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xff

    invoke-interface {v3}, Ljava/lang/CharSequence;->length()I

    move-result v3

    if-lez v3, :cond_100

    const/16 v0, 0x111

    invoke-virtual {p0}, Lwu;->c()Landroid/content/SharedPreferences;

    move-result-object p0

    const-string/jumbo v3, "prxport"

    const/16 v0, 0x2e

    invoke-interface {p0, v3, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xff

    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result p0

    if-lez p0, :cond_100

    const/4 p0, 0x1

    goto :goto_101

    :cond_100
    const/4 p0, 0x0

    :goto_101
    const-string/jumbo v3, "uprx"

    const/16 v0, 0x48

    invoke-interface {v2, v3, p0}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x6f

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void

    :cond_10f
    const-string/jumbo p0, "useprxserver"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_117
    const-string/jumbo p0, "payloadas"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_11f
    const-string/jumbo p0, "usepayloadas"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_127
    const/4 v0, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_12c
    const-string/jumbo p0, "usesnihost"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_134
    const/4 v0, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_139
    const-string/jumbo p0, "usepayload"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_141
    const-string/jumbo p0, "spnMetodos"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4
.end method

.method public final onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .registers 11

    .prologue
    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const p3, 0x7f0c0023

    const/4 v2, 0x0

    const/16 v0, 0x107b

    invoke-virtual {p1, p3, p2, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    const p2, 0x7f09013b

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/ImageView;

    const/16 v0, 0xd1c

    iput-object p2, p0, Lwu;->r:Landroid/widget/ImageView;

    const p2, 0x7f09033e

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/Spinner;

    const/16 v0, 0x10d4

    iput-object p2, p0, Lwu;->s:Landroid/widget/Spinner;

    const p2, 0x7f090099

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/LinearLayout;

    const/16 v0, 0xb96

    iput-object p2, p0, Lwu;->t:Landroid/widget/LinearLayout;

    const p2, 0x7f0903af

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/CheckBox;

    const/16 v0, 0xd5d

    iput-object p2, p0, Lwu;->u:Landroid/widget/CheckBox;

    const p2, 0x7f0902ba

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Lcom/google/android/material/textfield/TextInputLayout;

    const/16 v0, 0xb0f

    iput-object p2, p0, Lwu;->v:Lcom/google/android/material/textfield/TextInputLayout;

    const p2, 0x7f0902b9

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Lcom/google/android/material/textfield/TextInputEditText;

    const/16 v0, 0x736

    iput-object p2, p0, Lwu;->w:Lcom/google/android/material/textfield/TextInputEditText;

    const p2, 0x7f0903b4

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/CheckBox;

    const/16 v0, 0x10e2

    iput-object p2, p0, Lwu;->x:Landroid/widget/CheckBox;

    const p2, 0x7f090333

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Lcom/google/android/material/textfield/TextInputLayout;

    const/16 v0, 0x10bd

    iput-object p2, p0, Lwu;->y:Lcom/google/android/material/textfield/TextInputLayout;

    const p2, 0x7f090332

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Lcom/google/android/material/textfield/TextInputEditText;

    const/16 v0, 0x926

    iput-object p2, p0, Lwu;->z:Lcom/google/android/material/textfield/TextInputEditText;

    const p2, 0x7f0903b0

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/CheckBox;

    const/16 v0, 0xeb4

    iput-object p2, p0, Lwu;->A:Landroid/widget/CheckBox;

    const p2, 0x7f0902bb

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Lcom/google/android/material/textfield/TextInputEditText;

    const/16 v0, 0x11bb

    iput-object p2, p0, Lwu;->B:Lcom/google/android/material/textfield/TextInputEditText;

    const p2, 0x7f0902bc

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Lcom/google/android/material/textfield/TextInputLayout;

    const/16 v0, 0xdcd

    iput-object p2, p0, Lwu;->C:Lcom/google/android/material/textfield/TextInputLayout;

    const p2, 0x7f0903b1

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/CheckBox;

    const/16 v0, 0xc51

    iput-object p2, p0, Lwu;->D:Landroid/widget/CheckBox;

    const p2, 0x7f0902d9

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/LinearLayout;

    const/16 v0, 0x79c

    iput-object p2, p0, Lwu;->E:Landroid/widget/LinearLayout;

    const p2, 0x7f0902d5

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/TextView;

    const/16 v0, 0x66b

    iput-object p2, p0, Lwu;->F:Landroid/widget/TextView;

    const p2, 0x7f0902d7

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/TextView;

    const/16 v0, 0xe9e

    iput-object p2, p0, Lwu;->G:Landroid/widget/TextView;

    const p2, 0x7f090058

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroidx/constraintlayout/widget/ConstraintLayout;

    const/16 v0, 0x7a4

    iput-object p2, p0, Lwu;->H:Landroidx/constraintlayout/widget/ConstraintLayout;

    const/16 v0, 0x78f

    iget-object p2, p0, Lwu;->F:Landroid/widget/TextView;

    nop

    const/4 p3, 0x0

    if-eqz p2, :cond_343

    const/16 v0, 0xb36

    new-instance v3, Lc;

    nop

    const/16 v4, 0x9

    const/16 v0, 0x87c

    invoke-direct {v3, v4, p0}, Lc;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x1156

    invoke-virtual {p2, v3}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    const/16 v0, 0x111

    invoke-virtual {p0}, Lwu;->c()Landroid/content/SharedPreferences;

    move-result-object p2

    const-string/jumbo v3, "pserver"

    const/16 v0, 0x77

    invoke-interface {p2, v3, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p2

    if-eqz p2, :cond_1b1

    const/16 v0, 0x111

    invoke-virtual {p0}, Lwu;->c()Landroid/content/SharedPreferences;

    move-result-object p2

    const-string/jumbo v3, "sshhost"

    const-string/jumbo v4, ""

    const/16 v0, 0x2e

    invoke-interface {p2, v3, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    if-nez p2, :cond_190

    move-object p2, v4

    :cond_190
    const/16 v0, 0x47

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result p2

    if-lez p2, :cond_1b1

    const/16 v0, 0x111

    invoke-virtual {p0}, Lwu;->c()Landroid/content/SharedPreferences;

    move-result-object p2

    const-string/jumbo v3, "sshport"

    const/16 v0, 0x2e

    invoke-interface {p2, v3, v4}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    if-nez p2, :cond_1aa

    goto :goto_1ab

    :cond_1aa
    move-object v4, p2

    :goto_1ab
    const/16 v0, 0x47

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result p2

    :cond_1b1
    const/16 v0, 0xf5e

    iget-object p2, p0, Lwu;->r:Landroid/widget/ImageView;

    nop

    if-eqz p2, :cond_33b

    const/16 v0, 0xfe

    new-instance v3, Luu;

    nop

    const/4 v4, 0x1

    const/16 v0, 0xd1

    invoke-direct {v3, p0, v4}, Luu;-><init>(Lwu;I)V

    const/16 v0, 0x5f

    invoke-virtual {p2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0x1226

    iget-object p2, p0, Lwu;->H:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz p2, :cond_333

    const/16 v0, 0xfe

    new-instance v3, Luu;

    nop

    const/4 v5, 0x2

    const/16 v0, 0xd1

    invoke-direct {v3, p0, v5}, Luu;-><init>(Lwu;I)V

    const/16 v0, 0x5f

    invoke-virtual {p2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0x8cf

    iget-object p2, p0, Lwu;->s:Landroid/widget/Spinner;

    nop

    if-eqz p2, :cond_32b

    const/16 v0, 0x69d

    new-instance v3, Lru;

    nop

    const/16 v0, 0x1116

    invoke-direct {v3, v4, p0}, Lru;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x613

    invoke-virtual {p2, v3}, Landroid/widget/AdapterView;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    const/16 v0, 0x11b0

    iget-object p2, p0, Lwu;->u:Landroid/widget/CheckBox;

    nop

    if-eqz p2, :cond_323

    const/16 v0, 0x168

    new-instance v3, Lvu;

    nop

    const/16 v0, 0x18a

    invoke-direct {v3, p0, v2}, Lvu;-><init>(Lwu;I)V

    const/16 v0, 0x14a

    invoke-virtual {p2, v3}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    const/16 v0, 0x558

    iget-object p2, p0, Lwu;->v:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz p2, :cond_31b

    const/16 v0, 0xfe

    new-instance v3, Luu;

    nop

    const/4 v6, 0x3

    const/16 v0, 0xd1

    invoke-direct {v3, p0, v6}, Luu;-><init>(Lwu;I)V

    const/16 v0, 0x28d

    invoke-virtual {p2, v3}, Lcom/google/android/material/textfield/TextInputLayout;->setEndIconOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0xbf1

    iget-object p2, p0, Lwu;->x:Landroid/widget/CheckBox;

    nop

    if-eqz p2, :cond_313

    const/16 v0, 0x168

    new-instance v3, Lvu;

    nop

    const/16 v0, 0x18a

    invoke-direct {v3, p0, v4}, Lvu;-><init>(Lwu;I)V

    const/16 v0, 0x14a

    invoke-virtual {p2, v3}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    const/16 v0, 0x339

    iget-object p2, p0, Lwu;->A:Landroid/widget/CheckBox;

    nop

    if-eqz p2, :cond_30b

    const/16 v0, 0x168

    new-instance v3, Lvu;

    nop

    const/16 v0, 0x18a

    invoke-direct {v3, p0, v5}, Lvu;-><init>(Lwu;I)V

    const/16 v0, 0x14a

    invoke-virtual {p2, v3}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    const/16 v0, 0x3f3

    iget-object p2, p0, Lwu;->C:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz p2, :cond_303

    const/16 v0, 0xfe

    new-instance v3, Luu;

    nop

    const/4 v4, 0x4

    const/16 v0, 0xd1

    invoke-direct {v3, p0, v4}, Luu;-><init>(Lwu;I)V

    const/16 v0, 0x28d

    invoke-virtual {p2, v3}, Lcom/google/android/material/textfield/TextInputLayout;->setEndIconOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0xd59

    iget-object p2, p0, Lwu;->D:Landroid/widget/CheckBox;

    nop

    if-eqz p2, :cond_2fb

    const/16 v0, 0x168

    new-instance v3, Lvu;

    nop

    const/16 v0, 0x18a

    invoke-direct {v3, p0, v6}, Lvu;-><init>(Lwu;I)V

    const/16 v0, 0x14a

    invoke-virtual {p2, v3}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    const/16 v0, 0xb8a

    iget-object p2, p0, Lwu;->E:Landroid/widget/LinearLayout;

    nop

    if-eqz p2, :cond_2f3

    const/16 v0, 0xfe

    new-instance p3, Luu;

    nop

    const/16 v0, 0xd1

    invoke-direct {p3, p0, v2}, Luu;-><init>(Lwu;I)V

    const/16 v0, 0x5f

    invoke-virtual {p2, p3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0xe11

    invoke-virtual {p0}, Lwu;->d()V

    const/16 v0, 0x1fc

    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 p3, 0x21

    const-string/jumbo v2, "restoremtdcfg"

    const/16 v0, 0x559

    iget-object v3, p0, Lwu;->I:Lob;

    nop

    if-ge p2, p3, :cond_2bd

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p2

    const/16 v0, 0x1f

    new-instance p3, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {p3, v2}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x3a

    invoke-virtual {p2, v3, p3}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    goto :goto_2d2

    :cond_2bd
    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p2

    const/16 v0, 0x1f

    new-instance p3, Landroid/content/IntentFilter;

    nop

    const/16 v0, 0x1d

    invoke-direct {p3, v2}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x5d

    invoke-virtual {p2, v3, p3, v4}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    :goto_2d2
    const/16 v0, 0x140

    sget-boolean p2, Lg4;->a:Z

    nop

    const/16 v0, 0xfb

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x111

    invoke-virtual {p0}, Lwu;->c()Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x394

    invoke-static {p0, p2}, Lg4;->n(Landroid/content/SharedPreferences;Landroidx/fragment/app/l;)V

    check-cast p1, Landroid/view/View;

    return-object p1

    :cond_2f3
    const-string/jumbo p0, "prxserverL"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_2fb
    const-string/jumbo p0, "useprxserver"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_303
    const-string/jumbo p0, "payloadasL"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_30b
    const-string/jumbo p0, "usepayloadas"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_313
    const-string/jumbo p0, "usesnihost"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_31b
    const-string/jumbo p0, "payloadL"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_323
    const-string/jumbo p0, "usepayload"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_32b
    const-string/jumbo p0, "spnMetodos"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_333
    const-string/jumbo p0, "aplicar"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_33b
    const-string/jumbo p0, "ic_salvar"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_343
    const-string/jumbo p0, "prxhost"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3
.end method

.method public final onDestroyView()V
    .registers 6

    .prologue
    const/16 v0, 0x53a

    invoke-super {p0}, Landroidx/fragment/app/g;->onDestroyView()V

    :try_start_5
    const/16 v0, 0x22f

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v2

    if-eqz v2, :cond_17

    const/16 v0, 0x559

    iget-object v3, p0, Lwu;->I:Lob;

    nop

    const/16 v0, 0x345

    invoke-virtual {v2, v3}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_17
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_17} :catch_17

    :catch_17
    :cond_17
    const/16 v0, 0x22f

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v2

    if-eqz v2, :cond_4f

    const/16 v0, 0x5b

    new-instance v3, Landroid/content/Intent;

    nop

    const-string/jumbo v4, "restoreHome"

    const/16 v0, 0x62

    invoke-direct {v3, v4}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x22f

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object p0

    if-eqz p0, :cond_43

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    if-eqz p0, :cond_43

    const/16 v0, 0x4a

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    goto :goto_44

    :cond_43
    const/4 p0, 0x0

    :goto_44
    const/16 v0, 0x64

    invoke-virtual {v3, p0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    const/16 v0, 0x63

    invoke-virtual {v2, p0}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    :cond_4f
    return-void
.end method

.method public final onPause()V
    .registers 3

    const/16 v0, 0xbf8

    invoke-super {p0}, Landroidx/fragment/app/Fragment;->onPause()V

    const/16 v0, 0x250

    invoke-virtual {p0}, Lwu;->e()V

    return-void
.end method

.method public final onResume()V
    .registers 3

    const/16 v0, 0x7d7

    invoke-super {p0}, Landroidx/fragment/app/Fragment;->onResume()V

    const/16 v0, 0xe11

    invoke-virtual {p0}, Lwu;->d()V

    return-void
.end method

.method public final onStart()V
    .registers 5

    .prologue
    const/16 v0, 0x55f

    invoke-super {p0}, Landroidx/fragment/app/g;->onStart()V

    const/16 v0, 0xaeb

    invoke-virtual {p0}, Landroidx/fragment/app/g;->getDialog()Landroid/app/Dialog;

    move-result-object p0

    if-eqz p0, :cond_34

    const/16 v0, 0xc8b

    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object p0

    if-eqz p0, :cond_34

    const/4 v2, -0x1

    const/4 v3, -0x2

    const/16 v0, 0x1132

    invoke-virtual {p0, v2, v3}, Landroid/view/Window;->setLayout(II)V

    const/16 v0, 0x10ad

    new-instance v2, Landroid/graphics/drawable/ColorDrawable;

    nop

    const/4 v3, 0x0

    const/16 v0, 0xc14

    invoke-direct {v2, v3}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    const/16 v0, 0xba3

    invoke-virtual {p0, v2}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    const v2, 0x7f140137

    const/16 v0, 0xa0d

    invoke-virtual {p0, v2}, Landroid/view/Window;->setWindowAnimations(I)V

    :cond_34
    return-void
.end method
