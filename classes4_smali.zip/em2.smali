.class public final synthetic Lem2;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Z

.field public final synthetic c:J

.field public final synthetic d:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lcom/mbridge/msdk/system/a;ZJ)V
    .registers 8

    const/4 v2, 0x1

    iput v2, p0, Lem2;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x6ef

    iput-object p1, p0, Lem2;->d:Ljava/lang/Object;

    const/16 v0, 0x697

    iput-boolean p2, p0, Lem2;->b:Z

    const/16 v0, 0xbbe

    iput-wide p3, p0, Lem2;->c:J

    return-void
.end method

.method public synthetic constructor <init>(Lcom/tlsvpn/tlstunnel/services/VpnConnection;JZ)V
    .registers 9

    const/4 v2, 0x0

    iput v2, p0, Lem2;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x6ef

    iput-object p1, p0, Lem2;->d:Ljava/lang/Object;

    const/16 v0, 0xbbe

    iput-wide p2, p0, Lem2;->c:J

    const/16 v0, 0x697

    iput-boolean p4, p0, Lem2;->b:Z

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 9

    .prologue
    const/16 v1, 0x740

    iget v3, p0, Lem2;->a:I

    nop

    const/16 v1, 0x618

    iget-wide v4, p0, Lem2;->c:J

    nop

    const/16 v1, 0xfa1

    iget-boolean v6, p0, Lem2;->b:Z

    nop

    const/16 v1, 0xe8f

    iget-object p0, p0, Lem2;->d:Ljava/lang/Object;

    nop

    packed-switch v3, :pswitch_data_50

    check-cast p0, Lcom/mbridge/msdk/system/a;

    const/16 v1, 0xe09

    invoke-static {p0, v6, v4, v5}, Lcom/mbridge/msdk/system/a;->c(Lcom/mbridge/msdk/system/a;ZJ)V

    return-void

    :pswitch_1f  #0x0
    check-cast p0, Lcom/tlsvpn/tlstunnel/services/VpnConnection;

    const/16 v1, 0xe2

    sget v3, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->O:I

    nop

    const/16 v1, 0x6d9

    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v3

    const/16 v1, 0x90f

    invoke-virtual {v3}, Ljava/lang/Runtime;->availableProcessors()I

    move-result v3

    const/4 v7, 0x2

    if-le v3, v7, :cond_37

    const/4 v3, 0x1

    goto :goto_38

    :cond_37
    const/4 v3, 0x0

    :goto_38
    const/16 v1, 0x5a

    sget-object v7, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->a:Lcom/tlsvpn/tlstunnel/utils/SocketOps;

    nop

    const/16 v1, 0x9f9

    invoke-virtual {v7, v3}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->v(I)Z

    const/16 v3, -0x13

    const/16 v1, 0xa63

    invoke-static {v3}, Landroid/os/Process;->setThreadPriority(I)V

    const/16 v1, 0xccd

    invoke-virtual {p0, v4, v5, v6}, Lcom/tlsvpn/tlstunnel/services/VpnConnection;->l(JZ)V

    return-void

    nop

    :pswitch_data_50
    .packed-switch 0x0
        :pswitch_1f  #00000000
    .end packed-switch
.end method
