.class public final Lvp1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lky;
.implements Lyt;
.implements Lcom/google/android/gms/internal/consent_sdk/zzqp;
.implements Lk4;
.implements Lsl;
.implements Lua0;
.implements Lxn1;


# static fields
.field public static final synthetic a:Lvp1;

.field public static final b:Lvp1;

.field public static final c:Lvp1;

.field public static final d:Lvp1;

.field public static final e:Lvp1;

.field public static final f:Lvp1;

.field public static final g:Lvp1;

.field public static final h:Lvp1;

.field public static final i:Lvp1;

.field public static final j:Lvp1;

.field public static final k:Lvp1;

.field public static final l:Lvp1;

.field public static final m:Lvp1;

.field public static final n:Lvp1;

.field public static volatile o:Lvp1;


# direct methods
.method static synthetic constructor <clinit>()V
    .registers 1

    new-instance v0, Lvp1;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lvp1;->a:Lvp1;

    new-instance v0, Lvp1;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lvp1;->b:Lvp1;

    new-instance v0, Lvp1;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lvp1;->c:Lvp1;

    new-instance v0, Lvp1;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lvp1;->d:Lvp1;

    new-instance v0, Lvp1;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lvp1;->e:Lvp1;

    new-instance v0, Lvp1;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lvp1;->f:Lvp1;

    new-instance v0, Lvp1;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lvp1;->g:Lvp1;

    new-instance v0, Lvp1;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lvp1;->h:Lvp1;

    new-instance v0, Lvp1;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lvp1;->i:Lvp1;

    new-instance v0, Lvp1;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lvp1;->j:Lvp1;

    new-instance v0, Lvp1;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lvp1;->k:Lvp1;

    new-instance v0, Lvp1;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lvp1;->l:Lvp1;

    new-instance v0, Lvp1;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lvp1;->m:Lvp1;

    new-instance v0, Lvp1;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lvp1;->n:Lvp1;

    return-void
.end method

.method public static c(Ljava/util/List;)Ljava/util/ArrayList;
    .registers 5

    .prologue
    check-cast p0, Ljava/lang/Iterable;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_b
    :goto_b
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_20

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    move-object v2, v1

    check-cast v2, Lno1;

    sget-object v3, Lno1;->b:Lno1;

    if-eq v2, v3, :cond_b

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_b

    :cond_20
    new-instance p0, Ljava/util/ArrayList;

    const/16 v1, 0xa

    invoke-static {v0, v1}, Lds;->Y(Ljava/lang/Iterable;I)I

    move-result v1

    invoke-direct {p0, v1}, Ljava/util/ArrayList;-><init>(I)V

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x0

    :goto_30
    if-ge v2, v1, :cond_40

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    add-int/lit8 v2, v2, 0x1

    check-cast v3, Lno1;

    iget-object v3, v3, Lno1;->a:Ljava/lang/String;

    invoke-virtual {p0, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_30

    :cond_40
    return-object p0
.end method

.method public static e(Ljava/util/List;)[B
    .registers 7

    .prologue
    new-instance v1, Lvk;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    invoke-static {p0}, Lvp1;->c(Ljava/util/List;)Ljava/util/ArrayList;

    move-result-object p0

    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v3, 0x0

    :goto_e
    if-ge v3, v2, :cond_23

    invoke-virtual {p0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    add-int/lit8 v3, v3, 0x1

    check-cast v4, Ljava/lang/String;

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v5

    invoke-virtual {v1, v5}, Lvk;->U(I)V

    invoke-virtual {v1, v4}, Lvk;->a0(Ljava/lang/String;)V

    goto :goto_e

    :cond_23
    iget-wide v2, v1, Lvk;->b:J

    invoke-virtual {v1, v2, v3}, Lvk;->M(J)[B

    move-result-object p0

    return-object p0
.end method

.method public static g(Lly2;Luc1;Landroid/os/Bundle;Lz01;Lnc1;)Lbc1;
    .registers 14

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Lbc1;

    const/4 v8, 0x0

    move-object v2, p0

    move-object v3, p1

    move-object v4, p2

    move-object v5, p3

    move-object v6, p4

    invoke-direct/range {v1 .. v8}, Lbc1;-><init>(Lly2;Luc1;Landroid/os/Bundle;Lz01;Lnc1;Ljava/lang/String;Landroid/os/Bundle;)V

    return-object v1
.end method

.method public static i()Z
    .registers 2

    const-string/jumbo v0, "java.vm.name"

    invoke-static {v0}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string/jumbo v1, "Dalvik"

    invoke-virtual {v1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method public static j(Lm4;Lk4;)V
    .registers 20

    invoke-virtual/range {p1 .. p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lads_mobile_sdk/ai1;->d:Lyx1;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lo43;->a:Lads_mobile_sdk/ru0;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Lads_mobile_sdk/ru0;->a()Lo43;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/sb0;

    iget-object v0, v0, Lads_mobile_sdk/sb0;->T2:Ltv2;

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/rf1;

    invoke-static {}, Lads_mobile_sdk/ru0;->a()Lo43;

    move-result-object v1

    check-cast v1, Lads_mobile_sdk/sb0;

    iget-object v1, v1, Lads_mobile_sdk/sb0;->c:Lads_mobile_sdk/sb0;

    sget-object v2, Lads_mobile_sdk/av2;->h:Lads_mobile_sdk/av2;

    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-static/range {p0 .. p0}, Lads_mobile_sdk/ob1;->a(Ljava/lang/Object;)Lads_mobile_sdk/ob1;

    move-result-object v7

    sget-object v4, Lgv2;->a:Lads_mobile_sdk/ob1;

    new-instance v5, Lads_mobile_sdk/a3;

    invoke-direct {v5, v4, v4, v4}, Lads_mobile_sdk/a3;-><init>(Lads_mobile_sdk/ob1;Lads_mobile_sdk/ob1;Lads_mobile_sdk/ob1;)V

    new-instance v8, Lads_mobile_sdk/nj0;

    invoke-direct {v8, v5}, Lads_mobile_sdk/nj0;-><init>(Ltv2;)V

    iget-object v4, v1, Lads_mobile_sdk/sb0;->v0:Ltv2;

    new-instance v5, Lads_mobile_sdk/b;

    const/16 v6, 0x1c

    invoke-direct {v5, v4, v6}, Lads_mobile_sdk/b;-><init>(Ltv2;I)V

    new-instance v11, Lads_mobile_sdk/nj0;

    invoke-direct {v11, v5}, Lads_mobile_sdk/nj0;-><init>(Ltv2;)V

    invoke-static {v2}, Lads_mobile_sdk/ob1;->a(Ljava/lang/Object;)Lads_mobile_sdk/ob1;

    move-result-object v12

    invoke-static {v3}, Lads_mobile_sdk/ob1;->a(Ljava/lang/Object;)Lads_mobile_sdk/ob1;

    move-result-object v2

    invoke-static/range {p0 .. p0}, Lads_mobile_sdk/ob1;->a(Ljava/lang/Object;)Lads_mobile_sdk/ob1;

    move-result-object v4

    move-object v13, v11

    move-object v11, v12

    new-instance v12, Lads_mobile_sdk/n90;

    invoke-direct {v12, v4}, Lads_mobile_sdk/n90;-><init>(Ltv2;)V

    invoke-static {v3}, Lads_mobile_sdk/ob1;->a(Ljava/lang/Object;)Lads_mobile_sdk/ob1;

    move-result-object v14

    iget-object v10, v1, Lads_mobile_sdk/sb0;->g1:Lads_mobile_sdk/ah0;

    iget-object v15, v1, Lads_mobile_sdk/sb0;->h:Ltv2;

    new-instance v9, Lads_mobile_sdk/np;

    invoke-direct/range {v9 .. v15}, Lads_mobile_sdk/np;-><init>(Lads_mobile_sdk/ah0;Ltv2;Ltv2;Ltv2;Lads_mobile_sdk/ob1;Ltv2;)V

    new-instance v15, Lads_mobile_sdk/nj0;

    invoke-direct {v15, v9}, Lads_mobile_sdk/nj0;-><init>(Ltv2;)V

    sget-object v3, Lsz;->m:Lct2;

    new-instance v4, Lads_mobile_sdk/nj0;

    invoke-direct {v4, v3}, Lads_mobile_sdk/nj0;-><init>(Ltv2;)V

    iget-object v6, v1, Lads_mobile_sdk/sb0;->u:Lads_mobile_sdk/ah0;

    new-instance v3, Lads_mobile_sdk/dw;

    const/4 v5, 0x1

    invoke-direct {v3, v6, v4, v5}, Lads_mobile_sdk/dw;-><init>(Lads_mobile_sdk/ah0;Ltv2;I)V

    new-instance v4, Lads_mobile_sdk/nj0;

    invoke-direct {v4, v3}, Lads_mobile_sdk/nj0;-><init>(Ltv2;)V

    iget-object v5, v1, Lads_mobile_sdk/sb0;->a3:Ltv2;

    iget-object v9, v1, Lads_mobile_sdk/sb0;->t:Ltv2;

    iget-object v10, v1, Lads_mobile_sdk/sb0;->G:Ltv2;

    move-object v12, v11

    move-object v11, v13

    iget-object v13, v1, Lads_mobile_sdk/sb0;->d:Ltv2;

    iget-object v1, v1, Lads_mobile_sdk/sb0;->d3:Lads_mobile_sdk/ab0;

    move-object/from16 v17, v4

    new-instance v4, Lads_mobile_sdk/gq2;

    move-object/from16 v16, v1

    move-object v14, v2

    invoke-direct/range {v4 .. v17}, Lads_mobile_sdk/gq2;-><init>(Ltv2;Lads_mobile_sdk/ah0;Ltv2;Ltv2;Ltv2;Ltv2;Ltv2;Ltv2;Ltv2;Ltv2;Ltv2;Lads_mobile_sdk/ab0;Ltv2;)V

    new-instance v1, Lads_mobile_sdk/nj0;

    invoke-direct {v1, v4}, Lads_mobile_sdk/nj0;-><init>(Ltv2;)V

    invoke-interface {v1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lads_mobile_sdk/jp2;

    new-instance v2, Lads_mobile_sdk/wg;

    const/4 v3, 0x0

    const/4 v4, 0x3

    move-object/from16 v5, p1

    invoke-direct {v2, v1, v5, v3, v4}, Lads_mobile_sdk/wg;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lvx;I)V

    invoke-virtual {v0, v2}, Lads_mobile_sdk/rf1;->a(Lbk0;)V

    return-void
.end method

.method public static k(Lm4;Lk4;)V
    .registers 23

    invoke-virtual/range {p1 .. p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lads_mobile_sdk/lw2;->d:Lxx1;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lo43;->a:Lads_mobile_sdk/ru0;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {}, Lads_mobile_sdk/ru0;->a()Lo43;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/sb0;

    iget-object v0, v0, Lads_mobile_sdk/sb0;->T2:Ltv2;

    invoke-interface {v0}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lads_mobile_sdk/rf1;

    invoke-static {}, Lads_mobile_sdk/ru0;->a()Lo43;

    move-result-object v1

    check-cast v1, Lads_mobile_sdk/sb0;

    iget-object v1, v1, Lads_mobile_sdk/sb0;->c:Lads_mobile_sdk/sb0;

    sget-object v2, Lads_mobile_sdk/av2;->j:Lads_mobile_sdk/av2;

    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    sget-object v4, Lgv2;->a:Lads_mobile_sdk/ob1;

    new-instance v5, Lads_mobile_sdk/a3;

    invoke-direct {v5, v4, v4, v4}, Lads_mobile_sdk/a3;-><init>(Lads_mobile_sdk/ob1;Lads_mobile_sdk/ob1;Lads_mobile_sdk/ob1;)V

    new-instance v9, Lads_mobile_sdk/nj0;

    invoke-direct {v9, v5}, Lads_mobile_sdk/nj0;-><init>(Ltv2;)V

    iget-object v4, v1, Lads_mobile_sdk/sb0;->v0:Ltv2;

    new-instance v5, Lads_mobile_sdk/b;

    const/16 v6, 0x1c

    invoke-direct {v5, v4, v6}, Lads_mobile_sdk/b;-><init>(Ltv2;I)V

    new-instance v14, Lads_mobile_sdk/nj0;

    invoke-direct {v14, v5}, Lads_mobile_sdk/nj0;-><init>(Ltv2;)V

    invoke-static {v2}, Lads_mobile_sdk/ob1;->a(Ljava/lang/Object;)Lads_mobile_sdk/ob1;

    move-result-object v12

    invoke-static {v3}, Lads_mobile_sdk/ob1;->a(Ljava/lang/Object;)Lads_mobile_sdk/ob1;

    move-result-object v2

    invoke-static/range {p0 .. p0}, Lads_mobile_sdk/ob1;->a(Ljava/lang/Object;)Lads_mobile_sdk/ob1;

    move-result-object v4

    new-instance v13, Lads_mobile_sdk/n90;

    invoke-direct {v13, v4}, Lads_mobile_sdk/n90;-><init>(Ltv2;)V

    invoke-static {v3}, Lads_mobile_sdk/ob1;->a(Ljava/lang/Object;)Lads_mobile_sdk/ob1;

    move-result-object v15

    iget-object v11, v1, Lads_mobile_sdk/sb0;->g1:Lads_mobile_sdk/ah0;

    iget-object v3, v1, Lads_mobile_sdk/sb0;->h:Ltv2;

    new-instance v10, Lads_mobile_sdk/np;

    move-object/from16 v16, v3

    invoke-direct/range {v10 .. v16}, Lads_mobile_sdk/np;-><init>(Lads_mobile_sdk/ah0;Ltv2;Ltv2;Ltv2;Lads_mobile_sdk/ob1;Ltv2;)V

    new-instance v3, Lads_mobile_sdk/nj0;

    invoke-direct {v3, v10}, Lads_mobile_sdk/nj0;-><init>(Ltv2;)V

    invoke-static/range {p0 .. p0}, Lads_mobile_sdk/ob1;->a(Ljava/lang/Object;)Lads_mobile_sdk/ob1;

    move-result-object v17

    sget-object v4, Lsz;->m:Lct2;

    new-instance v5, Lads_mobile_sdk/nj0;

    invoke-direct {v5, v4}, Lads_mobile_sdk/nj0;-><init>(Ltv2;)V

    iget-object v8, v1, Lads_mobile_sdk/sb0;->u:Lads_mobile_sdk/ah0;

    new-instance v4, Lads_mobile_sdk/dw;

    const/4 v6, 0x1

    invoke-direct {v4, v8, v5, v6}, Lads_mobile_sdk/dw;-><init>(Lads_mobile_sdk/ah0;Ltv2;I)V

    new-instance v5, Lads_mobile_sdk/nj0;

    invoke-direct {v5, v4}, Lads_mobile_sdk/nj0;-><init>(Ltv2;)V

    iget-object v7, v1, Lads_mobile_sdk/sb0;->a3:Ltv2;

    iget-object v10, v1, Lads_mobile_sdk/sb0;->t:Ltv2;

    iget-object v11, v1, Lads_mobile_sdk/sb0;->G:Ltv2;

    move-object v13, v12

    move-object v12, v14

    iget-object v14, v1, Lads_mobile_sdk/sb0;->d:Ltv2;

    iget-object v1, v1, Lads_mobile_sdk/sb0;->f3:Lads_mobile_sdk/ab0;

    move v4, v6

    new-instance v6, Lads_mobile_sdk/gq2;

    const/16 v20, 0x0

    move-object/from16 v18, v1

    move-object v15, v2

    move-object/from16 v16, v3

    move-object/from16 v19, v5

    invoke-direct/range {v6 .. v20}, Lads_mobile_sdk/gq2;-><init>(Ltv2;Lads_mobile_sdk/ah0;Ltv2;Ltv2;Ltv2;Ltv2;Ltv2;Ltv2;Ltv2;Ltv2;Lads_mobile_sdk/ob1;Ltv2;Ltv2;I)V

    new-instance v1, Lads_mobile_sdk/nj0;

    invoke-direct {v1, v6}, Lads_mobile_sdk/nj0;-><init>(Ltv2;)V

    invoke-interface {v1}, Ltv2;->get()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lads_mobile_sdk/fq2;

    new-instance v2, Lads_mobile_sdk/wg;

    const/4 v3, 0x0

    move-object/from16 v5, p1

    invoke-direct {v2, v1, v5, v3, v4}, Lads_mobile_sdk/wg;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lvx;I)V

    invoke-virtual {v0, v2}, Lads_mobile_sdk/rf1;->a(Lbk0;)V

    return-void
.end method


# virtual methods
.method public a([BII)[B
    .registers 5

    new-array p0, p3, [B

    const/4 v0, 0x0

    invoke-static {p1, p2, p0, v0, p3}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    return-object p0
.end method

.method public b()V
    .registers 2

    const-string/jumbo p0, "DIAGNOSTIC_PROFILE_IS_COMPRESSED"

    const-string/jumbo v0, "ProfileInstaller"

    nop

    return-void
.end method

.method public d(ILjava/lang/Object;)V
    .registers 5

    .prologue
    packed-switch p1, :pswitch_data_42

    :pswitch_3  #0x9
    const-string/jumbo p0, ""

    goto :goto_2e

    :pswitch_7  #0xb
    const-string/jumbo p0, "RESULT_DELETE_SKIP_FILE_SUCCESS"

    goto :goto_2e

    :pswitch_b  #0xa
    const-string/jumbo p0, "RESULT_INSTALL_SKIP_FILE_SUCCESS"

    goto :goto_2e

    :pswitch_f  #0x8
    const-string/jumbo p0, "RESULT_PARSE_EXCEPTION"

    goto :goto_2e

    :pswitch_13  #0x7
    const-string/jumbo p0, "RESULT_IO_EXCEPTION"

    goto :goto_2e

    :pswitch_17  #0x6
    const-string/jumbo p0, "RESULT_BASELINE_PROFILE_NOT_FOUND"

    goto :goto_2e

    :pswitch_1b  #0x5
    const-string/jumbo p0, "RESULT_DESIRED_FORMAT_UNSUPPORTED"

    goto :goto_2e

    :pswitch_1f  #0x4
    const-string/jumbo p0, "RESULT_NOT_WRITABLE"

    goto :goto_2e

    :pswitch_23  #0x3
    const-string/jumbo p0, "RESULT_UNSUPPORTED_ART_VERSION"

    goto :goto_2e

    :pswitch_27  #0x2
    const-string/jumbo p0, "RESULT_ALREADY_INSTALLED"

    goto :goto_2e

    :pswitch_2b  #0x1
    const-string/jumbo p0, "RESULT_INSTALL_SUCCESS"

    :goto_2e
    const/4 v0, 0x6

    const-string/jumbo v1, "ProfileInstaller"

    if-eq p1, v0, :cond_3d

    const/4 v0, 0x7

    if-eq p1, v0, :cond_3d

    const/16 v0, 0x8

    if-eq p1, v0, :cond_3d

    nop

    return-void

    :cond_3d
    check-cast p2, Ljava/lang/Throwable;

    nop

    return-void

    nop

    :pswitch_data_42
    .packed-switch 0x1
        :pswitch_2b  #00000001
        :pswitch_27  #00000002
        :pswitch_23  #00000003
        :pswitch_1f  #00000004
        :pswitch_1b  #00000005
        :pswitch_17  #00000006
        :pswitch_13  #00000007
        :pswitch_f  #00000008
        :pswitch_3  #00000009
        :pswitch_b  #0000000a
        :pswitch_7  #0000000b
    .end packed-switch
.end method

.method public f(Ljava/lang/String;Ljava/security/Provider;)Ljava/lang/Object;
    .registers 3

    .prologue
    if-nez p2, :cond_7

    invoke-static {p1}, Ljava/security/KeyFactory;->getInstance(Ljava/lang/String;)Ljava/security/KeyFactory;

    move-result-object p0

    return-object p0

    :cond_7
    invoke-static {p1, p2}, Ljava/security/KeyFactory;->getInstance(Ljava/lang/String;Ljava/security/Provider;)Ljava/security/KeyFactory;

    move-result-object p0

    return-object p0
.end method

.method public h(Lk20;)Ljava/lang/Object;
    .registers 4

    new-instance p0, Lyo1;

    const-class v0, Lm11;

    const-class v1, Ljava/util/concurrent/Executor;

    invoke-direct {p0, v0, v1}, Lyo1;-><init>(Ljava/lang/Class;Ljava/lang/Class;)V

    invoke-virtual {p1, p0}, Lk20;->f(Lyo1;)Ljava/lang/Object;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p0, Ljava/util/concurrent/Executor;

    invoke-static {p0}, Lnp3;->I(Ljava/util/concurrent/Executor;)Loy;

    move-result-object p0

    return-object p0
.end method

.method public l(Ljava/util/List;Lu32;Lwx;)Ljava/lang/Object;
    .registers 10

    .prologue
    instance-of v0, p3, Lz00;

    if-eqz v0, :cond_13

    move-object v0, p3

    check-cast v0, Lz00;

    iget v1, v0, Lz00;->x:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_13

    sub-int/2addr v1, v2

    iput v1, v0, Lz00;->x:I

    goto :goto_18

    :cond_13
    new-instance v0, Lz00;

    invoke-direct {v0, p0, p3}, Lz00;-><init>(Lvp1;Lwx;)V

    :goto_18
    iget-object p0, v0, Lz00;->v:Ljava/lang/Object;

    iget p3, v0, Lz00;->x:I

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    sget-object v4, Lwy;->a:Lwy;

    if-eqz p3, :cond_42

    if-eq p3, v3, :cond_3a

    if-ne p3, v2, :cond_33

    iget-object p1, v0, Lz00;->u:Ljava/util/Iterator;

    iget-object p2, v0, Lz00;->t:Ljava/io/Serializable;

    check-cast p2, Lvr1;

    :try_start_2d
    invoke-static {p0}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_30
    .catchall {:try_start_2d .. :try_end_30} :catchall_31

    goto :goto_68

    :catchall_31
    move-exception p0

    goto :goto_81

    :cond_33
    const-string/jumbo p0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v1

    :cond_3a
    iget-object p1, v0, Lz00;->t:Ljava/io/Serializable;

    check-cast p1, Ljava/util/List;

    invoke-static {p0}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_5c

    :cond_42
    invoke-static {p0}, Lt12;->W(Ljava/lang/Object;)V

    new-instance p0, Ljava/util/ArrayList;

    invoke-direct {p0}, Ljava/util/ArrayList;-><init>()V

    new-instance p3, Lb10;

    const/4 v5, 0x0

    invoke-direct {p3, p1, p0, v1, v5}, Lb10;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lvx;I)V

    iput-object p0, v0, Lz00;->t:Ljava/io/Serializable;

    iput v3, v0, Lz00;->x:I

    invoke-virtual {p2, p3, v0}, Lu32;->a(Lb10;Lwx;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v4, :cond_5b

    goto :goto_80

    :cond_5b
    move-object p1, p0

    :goto_5c
    new-instance p0, Lvr1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    check-cast p1, Ljava/lang/Iterable;

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    move-object p2, p0

    :cond_68
    :goto_68
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p0

    if-eqz p0, :cond_8e

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lbk0;

    :try_start_74
    iput-object p2, v0, Lz00;->t:Ljava/io/Serializable;

    iput-object p1, v0, Lz00;->u:Ljava/util/Iterator;

    iput v2, v0, Lz00;->x:I

    invoke-interface {p0, v0}, Lbk0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0
    :try_end_7e
    .catchall {:try_start_74 .. :try_end_7e} :catchall_31

    if-ne p0, v4, :cond_68

    :goto_80
    return-object v4

    :goto_81
    iget-object p3, p2, Lvr1;->a:Ljava/lang/Object;

    if-nez p3, :cond_88

    iput-object p0, p2, Lvr1;->a:Ljava/lang/Object;

    goto :goto_68

    :cond_88
    check-cast p3, Ljava/lang/Throwable;

    invoke-static {p3, p0}, Lmd3;->g(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    goto :goto_68

    :cond_8e
    iget-object p0, p2, Lvr1;->a:Ljava/lang/Object;

    check-cast p0, Ljava/lang/Throwable;

    if-nez p0, :cond_97

    sget-object p0, Lrg2;->a:Lrg2;

    return-object p0

    :cond_97
    throw p0
.end method

.method public onAdFailedToLoad(Lq31;)V
    .registers 6

    .prologue
    sget-boolean v0, Lg4;->a:Z

    sget-boolean v0, Lmi2;->n:Z

    if-nez v0, :cond_58

    sget-boolean v0, Lmi2;->d:Z

    if-nez v0, :cond_b

    goto :goto_58

    :cond_b
    sget v0, Lg4;->q:I

    add-int/lit8 v1, v0, 0x1

    sput v1, Lg4;->q:I

    const/4 v1, 0x4

    if-ge v0, v1, :cond_2c

    const/4 v0, 0x1

    sput-boolean v0, Lg4;->p:Z

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v1, Lc;

    const/4 v2, 0x2

    invoke-direct {v1, v2, p0}, Lc;-><init>(ILjava/lang/Object;)V

    const-wide/16 v2, 0x3a98

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    goto :goto_2f

    :cond_2c
    const/4 p0, 0x0

    sput-boolean p0, Lg4;->p:Z

    :goto_2f
    new-instance p0, Ljava/lang/StringBuilder;

    const-string/jumbo v0, "Falha ao carregar Banner ("

    invoke-direct {p0, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1}, Lq31;->V()Lp31;

    move-result-object v0

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string/jumbo v0, ": "

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Lq31;->W()Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 p1, 0x29

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string/jumbo p1, "Ads-Load"

    nop

    :cond_58
    :goto_58
    return-void
.end method

.method public onAdLoaded(Ljava/lang/Object;)V
    .registers 7

    .prologue
    check-cast p1, Lmh;

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 p0, 0x0

    const/16 v0, 0x119d

    sput p0, Lg4;->q:I

    const/16 v0, 0x8ba

    sput-boolean p0, Lg4;->p:Z

    const-string/jumbo v2, "Ads-Load"

    const-string/jumbo v3, "Banner Carregado!"

    nop

    const/4 v0, -0x3

    new-instance v2, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v3, "BannerAd(onAdLoaded) isShown("

    const/16 v0, 0x97

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x12f

    sget-object v3, Lg4;->n:Lx4;

    nop

    const/4 v4, 0x0

    if-eqz v3, :cond_37

    const/16 v0, 0xbd2

    invoke-virtual {v3}, Landroid/view/View;->isShown()Z

    move-result v3

    const/16 v0, 0x2cb

    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    goto :goto_38

    :cond_37
    move-object v3, v4

    :goto_38
    const/16 v0, 0x190

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string/jumbo v3, ") isHovered("

    const/4 v0, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x12f

    sget-object v3, Lg4;->n:Lx4;

    nop

    if-eqz v3, :cond_58

    const/16 v0, 0xaab

    invoke-virtual {v3}, Landroid/view/View;->isHovered()Z

    move-result v3

    const/16 v0, 0x2cb

    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    goto :goto_59

    :cond_58
    move-object v3, v4

    :goto_59
    const/16 v0, 0x190

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string/jumbo v3, ") width("

    const/4 v0, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x12f

    sget-object v3, Lg4;->n:Lx4;

    nop

    if-eqz v3, :cond_79

    const/16 v0, 0x1fd

    invoke-virtual {v3}, Landroid/view/View;->getWidth()I

    move-result v3

    const/16 v0, 0xb1

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    goto :goto_7a

    :cond_79
    move-object v3, v4

    :goto_7a
    const/16 v0, 0x190

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string/jumbo v3, ") height("

    const/4 v0, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x12f

    sget-object v3, Lg4;->n:Lx4;

    nop

    if-eqz v3, :cond_99

    const/16 v0, 0x994

    invoke-virtual {v3}, Landroid/view/View;->getHeight()I

    move-result v3

    const/16 v0, 0xb1

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    :cond_99
    const/16 v0, 0x190

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v3, 0x29

    const/16 v0, 0x1b

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string/jumbo v3, "Ads-Show"

    nop

    const/16 v0, 0x1254

    new-instance v2, La4;

    nop

    const/16 v0, 0x21a

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    check-cast p1, Lads_mobile_sdk/bt2;

    const/16 v0, 0x9cb

    iget-object p1, p1, Lads_mobile_sdk/bt2;->e:Lads_mobile_sdk/uo2;

    nop

    const/16 v0, 0x10e1

    iget-object v3, p1, Lads_mobile_sdk/uo2;->u:Lads_mobile_sdk/ji;

    nop

    const/16 v0, 0x861

    sget-object v4, Lads_mobile_sdk/uo2;->B:[Liy0;

    nop

    aget-object p0, v4, p0

    const/16 v0, 0x1037

    invoke-virtual {v3, p1, p0, v2}, Lads_mobile_sdk/ji;->setValue(Ljava/lang/Object;Liy0;Ljava/lang/Object;)V

    return-void
.end method
