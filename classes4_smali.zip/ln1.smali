.class public final Lln1;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public final synthetic t:Lnn1;


# direct methods
.method public constructor <init>(Lnn1;Lvx;)V
    .registers 5

    iput-object p1, p0, Lln1;->t:Lnn1;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 5

    const/16 v0, 0x9f4

    new-instance p2, Lln1;

    nop

    const/16 v0, 0x123e

    iget-object p0, p0, Lln1;->t:Lnn1;

    nop

    const/16 v0, 0x7ca

    invoke-direct {p2, p0, p1}, Lln1;-><init>(Lnn1;Lvx;)V

    check-cast p2, Lvx;

    return-object p2
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    const/16 v0, 0xd51

    invoke-virtual {p0, p2, p1}, Lln1;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lln1;

    const/16 v0, 0x21

    sget-object p1, Lrg2;->a:Lrg2;

    nop

    const/16 v0, 0x6b1

    invoke-virtual {p0, p1}, Lln1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast p1, Ljava/lang/Object;

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .prologue
    const/4 v0, 0x6

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v0, 0xdcb

    invoke-static {}, Lcom/android/billingclient/api/QueryPurchasesParams;->newBuilder()Lcom/android/billingclient/api/QueryPurchasesParams$Builder;

    move-result-object p1

    const-string/jumbo v2, "subs"

    const/16 v0, 0x102c

    invoke-virtual {p1, v2}, Lcom/android/billingclient/api/QueryPurchasesParams$Builder;->setProductType(Ljava/lang/String;)Lcom/android/billingclient/api/QueryPurchasesParams$Builder;

    move-result-object p1

    const/16 v0, 0x7a0

    invoke-virtual {p1}, Lcom/android/billingclient/api/QueryPurchasesParams$Builder;->build()Lcom/android/billingclient/api/QueryPurchasesParams;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x123e

    iget-object p0, p0, Lln1;->t:Lnn1;

    nop

    const/16 v0, 0xafe

    iget-object v2, p0, Lnn1;->B:Lcom/android/billingclient/api/BillingClient;

    nop

    if-eqz v2, :cond_36

    const/16 v0, 0xbb2

    invoke-virtual {v2, p1, p0}, Lcom/android/billingclient/api/BillingClient;->queryPurchasesAsync(Lcom/android/billingclient/api/QueryPurchasesParams;Lcom/android/billingclient/api/PurchasesResponseListener;)V

    const/16 v0, 0x21

    sget-object p0, Lrg2;->a:Lrg2;

    nop

    check-cast p0, Ljava/lang/Object;

    return-object p0

    :cond_36
    const-string/jumbo p0, "billingClient"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0
.end method
