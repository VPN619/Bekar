.class public abstract Lqk;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final g:Lij1;

.field public static final h:Lgj1;

.field public static final i:Lwy0;

.field public static final j:Luy0;

.field public static final k:Lzi;

.field public static final l:Ljava/lang/Object;

.field public static m:[Ljava/lang/String;

.field public static n:[Ljava/lang/String;

.field public static o:[Ljava/lang/String;

.field public static p:[Ljava/lang/String;

.field public static final q:Lct2;

.field public static final r:Lct2;

.field public static final s:Lct2;

.field public static t:Lcom/google/android/gms/measurement/internal/zzae;


# instance fields
.field public final synthetic f:I


# direct methods
.method static synthetic constructor <clinit>()V
    .registers 4

    new-instance v0, Lo1;

    const/16 v1, 0x16

    invoke-direct {v0, v1}, Lo1;-><init>(I)V

    new-instance v1, Lij1;

    const-class v2, Lg6;

    invoke-direct {v1, v2, v0}, Lij1;-><init>(Ljava/lang/Class;Ljj1;)V

    sput-object v1, Lqk;->g:Lij1;

    new-instance v0, Lo1;

    const/16 v1, 0x17

    invoke-direct {v0, v1}, Lo1;-><init>(I)V

    new-instance v1, Lgj1;

    const-string/jumbo v2, "type.googleapis.com/google.crypto.tink.AesCtrHmacAeadKey"

    invoke-direct {v1, v2, v0}, Lgj1;-><init>(Ljava/lang/String;Lhj1;)V

    sput-object v1, Lqk;->h:Lgj1;

    new-instance v0, Lo1;

    const/16 v1, 0x18

    invoke-direct {v0, v1}, Lo1;-><init>(I)V

    new-instance v1, Lwy0;

    const-class v3, Lz5;

    invoke-direct {v1, v3, v0}, Lwy0;-><init>(Ljava/lang/Class;Lxy0;)V

    sput-object v1, Lqk;->i:Lwy0;

    new-instance v0, Lo1;

    const/16 v1, 0x19

    invoke-direct {v0, v1}, Lo1;-><init>(I)V

    new-instance v1, Luy0;

    invoke-direct {v1, v2, v0}, Luy0;-><init>(Ljava/lang/String;Lvy0;)V

    sput-object v1, Lqk;->j:Luy0;

    new-instance v0, Lzi;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lqk;->k:Lzi;

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Lqk;->l:Ljava/lang/Object;

    const/4 v0, 0x0

    new-array v1, v0, [Ljava/lang/String;

    sput-object v1, Lqk;->m:[Ljava/lang/String;

    new-array v1, v0, [Ljava/lang/String;

    sput-object v1, Lqk;->n:[Ljava/lang/String;

    new-array v0, v0, [Ljava/lang/String;

    sput-object v0, Lqk;->o:[Ljava/lang/String;

    new-instance v0, Lct2;

    const/4 v1, 0x4

    invoke-direct {v0, v1}, Lct2;-><init>(I)V

    sput-object v0, Lqk;->q:Lct2;

    new-instance v0, Lct2;

    const/16 v1, 0x16

    invoke-direct {v0, v1}, Lct2;-><init>(I)V

    sput-object v0, Lqk;->r:Lct2;

    new-instance v0, Lct2;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lct2;-><init>(I)V

    sput-object v0, Lqk;->s:Lct2;

    return-void
.end method

.method public synthetic constructor <init>(I)V
    .registers 2

    iput p1, p0, Lqk;->f:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static A(Landroid/view/ViewGroup;)V
    .registers 3

    .prologue
    invoke-virtual {p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object v0

    instance-of v1, v0, Lp71;

    if-eqz v1, :cond_d

    check-cast v0, Lp71;

    invoke-static {p0, v0}, Lqk;->z(Landroid/view/View;Lp71;)V

    :cond_d
    return-void
.end method

.method public static C(ILzv;Lvw;Z)V
    .registers 10

    .prologue
    iget v0, p2, Lvw;->d0:F

    iget-object v1, p2, Lvw;->I:Ltv;

    iget-object v2, v1, Ltv;->f:Ltv;

    invoke-virtual {v2}, Ltv;->d()I

    move-result v2

    iget-object v3, p2, Lvw;->K:Ltv;

    iget-object v4, v3, Ltv;->f:Ltv;

    invoke-virtual {v4}, Ltv;->d()I

    move-result v4

    invoke-virtual {v1}, Ltv;->e()I

    move-result v1

    add-int/2addr v1, v2

    invoke-virtual {v3}, Ltv;->e()I

    move-result v3

    sub-int v3, v4, v3

    const/high16 v5, 0x3f000000  # 0.5f

    if-ne v2, v4, :cond_23

    move v0, v5

    goto :goto_25

    :cond_23
    move v2, v1

    move v4, v3

    :goto_25
    invoke-virtual {p2}, Lvw;->q()I

    move-result v1

    sub-int v3, v4, v2

    sub-int/2addr v3, v1

    if-le v2, v4, :cond_31

    sub-int v3, v2, v4

    sub-int/2addr v3, v1

    :cond_31
    if-lez v3, :cond_38

    int-to-float v3, v3

    mul-float/2addr v0, v3

    add-float/2addr v0, v5

    :goto_36
    float-to-int v0, v0

    goto :goto_3b

    :cond_38
    int-to-float v3, v3

    mul-float/2addr v0, v3

    goto :goto_36

    :goto_3b
    add-int/2addr v0, v2

    add-int v3, v0, v1

    if-le v2, v4, :cond_42

    sub-int v3, v0, v1

    :cond_42
    invoke-virtual {p2, v0, v3}, Lvw;->J(II)V

    add-int/lit8 p0, p0, 0x1

    invoke-static {p0, p1, p2, p3}, Lqk;->s(ILzv;Lvw;Z)V

    return-void
.end method

.method public static D(ILvw;Lzv;Lvw;Z)V
    .registers 12

    .prologue
    iget v0, p3, Lvw;->d0:F

    iget-object v1, p3, Lvw;->I:Ltv;

    iget-object v2, v1, Ltv;->f:Ltv;

    invoke-virtual {v2}, Ltv;->d()I

    move-result v2

    invoke-virtual {v1}, Ltv;->e()I

    move-result v1

    add-int/2addr v1, v2

    iget-object v2, p3, Lvw;->K:Ltv;

    iget-object v3, v2, Ltv;->f:Ltv;

    invoke-virtual {v3}, Ltv;->d()I

    move-result v3

    invoke-virtual {v2}, Ltv;->e()I

    move-result v2

    sub-int/2addr v3, v2

    if-lt v3, v1, :cond_67

    invoke-virtual {p3}, Lvw;->q()I

    move-result v2

    iget v4, p3, Lvw;->g0:I

    const/16 v5, 0x8

    const/high16 v6, 0x3f000000  # 0.5f

    if-eq v4, v5, :cond_57

    iget v4, p3, Lvw;->r:I

    const/4 v5, 0x2

    if-ne v4, v5, :cond_45

    instance-of v2, p1, Lww;

    if-eqz v2, :cond_38

    invoke-virtual {p1}, Lvw;->q()I

    move-result p1

    goto :goto_3e

    :cond_38
    iget-object p1, p1, Lvw;->T:Lww;

    invoke-virtual {p1}, Lvw;->q()I

    move-result p1

    :goto_3e
    iget v2, p3, Lvw;->d0:F

    mul-float/2addr v2, v6

    int-to-float p1, p1

    mul-float/2addr v2, p1

    float-to-int v2, v2

    goto :goto_49

    :cond_45
    if-nez v4, :cond_49

    sub-int v2, v3, v1

    :cond_49
    :goto_49
    iget p1, p3, Lvw;->u:I

    invoke-static {p1, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    iget p1, p3, Lvw;->v:I

    if-lez p1, :cond_57

    invoke-static {p1, v2}, Ljava/lang/Math;->min(II)I

    move-result v2

    :cond_57
    sub-int/2addr v3, v1

    sub-int/2addr v3, v2

    int-to-float p1, v3

    mul-float/2addr v0, p1

    add-float/2addr v0, v6

    float-to-int p1, v0

    add-int/2addr v1, p1

    add-int/2addr v2, v1

    invoke-virtual {p3, v1, v2}, Lvw;->J(II)V

    add-int/lit8 p0, p0, 0x1

    invoke-static {p0, p2, p3, p4}, Lqk;->s(ILzv;Lvw;Z)V

    :cond_67
    return-void
.end method

.method public static E(ILzv;Lvw;)V
    .registers 9

    .prologue
    iget v0, p2, Lvw;->e0:F

    iget-object v1, p2, Lvw;->J:Ltv;

    iget-object v2, v1, Ltv;->f:Ltv;

    invoke-virtual {v2}, Ltv;->d()I

    move-result v2

    iget-object v3, p2, Lvw;->L:Ltv;

    iget-object v4, v3, Ltv;->f:Ltv;

    invoke-virtual {v4}, Ltv;->d()I

    move-result v4

    invoke-virtual {v1}, Ltv;->e()I

    move-result v1

    add-int/2addr v1, v2

    invoke-virtual {v3}, Ltv;->e()I

    move-result v3

    sub-int v3, v4, v3

    const/high16 v5, 0x3f000000  # 0.5f

    if-ne v2, v4, :cond_23

    move v0, v5

    goto :goto_25

    :cond_23
    move v2, v1

    move v4, v3

    :goto_25
    invoke-virtual {p2}, Lvw;->k()I

    move-result v1

    sub-int v3, v4, v2

    sub-int/2addr v3, v1

    if-le v2, v4, :cond_31

    sub-int v3, v2, v4

    sub-int/2addr v3, v1

    :cond_31
    if-lez v3, :cond_38

    int-to-float v3, v3

    mul-float/2addr v0, v3

    add-float/2addr v0, v5

    :goto_36
    float-to-int v0, v0

    goto :goto_3b

    :cond_38
    int-to-float v3, v3

    mul-float/2addr v0, v3

    goto :goto_36

    :goto_3b
    add-int v3, v2, v0

    add-int v5, v3, v1

    if-le v2, v4, :cond_45

    sub-int v3, v2, v0

    sub-int v5, v3, v1

    :cond_45
    invoke-virtual {p2, v3, v5}, Lvw;->K(II)V

    add-int/lit8 p0, p0, 0x1

    invoke-static {p0, p1, p2}, Lqk;->L(ILzv;Lvw;)V

    return-void
.end method

.method public static F(ILvw;Lzv;Lvw;)V
    .registers 11

    .prologue
    iget v0, p3, Lvw;->e0:F

    iget-object v1, p3, Lvw;->J:Ltv;

    iget-object v2, v1, Ltv;->f:Ltv;

    invoke-virtual {v2}, Ltv;->d()I

    move-result v2

    invoke-virtual {v1}, Ltv;->e()I

    move-result v1

    add-int/2addr v1, v2

    iget-object v2, p3, Lvw;->L:Ltv;

    iget-object v3, v2, Ltv;->f:Ltv;

    invoke-virtual {v3}, Ltv;->d()I

    move-result v3

    invoke-virtual {v2}, Ltv;->e()I

    move-result v2

    sub-int/2addr v3, v2

    if-lt v3, v1, :cond_66

    invoke-virtual {p3}, Lvw;->k()I

    move-result v2

    iget v4, p3, Lvw;->g0:I

    const/16 v5, 0x8

    const/high16 v6, 0x3f000000  # 0.5f

    if-eq v4, v5, :cond_56

    iget v4, p3, Lvw;->s:I

    const/4 v5, 0x2

    if-ne v4, v5, :cond_44

    instance-of v2, p1, Lww;

    if-eqz v2, :cond_38

    invoke-virtual {p1}, Lvw;->k()I

    move-result p1

    goto :goto_3e

    :cond_38
    iget-object p1, p1, Lvw;->T:Lww;

    invoke-virtual {p1}, Lvw;->k()I

    move-result p1

    :goto_3e
    mul-float v2, v0, v6

    int-to-float p1, p1

    mul-float/2addr v2, p1

    float-to-int v2, v2

    goto :goto_48

    :cond_44
    if-nez v4, :cond_48

    sub-int v2, v3, v1

    :cond_48
    :goto_48
    iget p1, p3, Lvw;->x:I

    invoke-static {p1, v2}, Ljava/lang/Math;->max(II)I

    move-result v2

    iget p1, p3, Lvw;->y:I

    if-lez p1, :cond_56

    invoke-static {p1, v2}, Ljava/lang/Math;->min(II)I

    move-result v2

    :cond_56
    sub-int/2addr v3, v1

    sub-int/2addr v3, v2

    int-to-float p1, v3

    mul-float/2addr v0, p1

    add-float/2addr v0, v6

    float-to-int p1, v0

    add-int/2addr v1, p1

    add-int/2addr v2, v1

    invoke-virtual {p3, v1, v2}, Lvw;->K(II)V

    add-int/lit8 p0, p0, 0x1

    invoke-static {p0, p2, p3}, Lqk;->L(ILzv;Lvw;)V

    :cond_66
    return-void
.end method

.method public static final G(Lwy1;Lwy1;Lpk0;)Ljava/lang/Object;
    .registers 4

    .prologue
    const/4 v0, 0x2

    :try_start_1
    invoke-static {v0, p2}, Lvr0;->h(ILjava/lang/Object;)V

    invoke-interface {p2, p1, p0}, Lpk0;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1
    :try_end_8
    .catchall {:try_start_1 .. :try_end_8} :catchall_9

    goto :goto_11

    :catchall_9
    move-exception p1

    new-instance p2, Let;

    const/4 v0, 0x0

    invoke-direct {p2, p1, v0}, Let;-><init>(Ljava/lang/Throwable;Z)V

    move-object p1, p2

    :goto_11
    sget-object p2, Lwy;->a:Lwy;

    if-ne p1, p2, :cond_16

    goto :goto_27

    :cond_16
    invoke-virtual {p0, p1}, Lnv0;->O(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    sget-object p1, Lw53;->c:Lq5;

    if-ne p0, p1, :cond_1f

    goto :goto_27

    :cond_1f
    instance-of p1, p0, Let;

    if-nez p1, :cond_28

    invoke-static {p0}, Lw53;->W(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    :goto_27
    return-object p2

    :cond_28
    check-cast p0, Let;

    iget-object p0, p0, Let;->a:Ljava/lang/Throwable;

    throw p0
.end method

.method public static H(Ldn0;)Lq5;
    .registers 3

    .prologue
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    move-result v0

    const/4 v1, 0x1

    if-eq v0, v1, :cond_30

    const/4 v1, 0x2

    if-eq v0, v1, :cond_2d

    const/4 v1, 0x3

    if-eq v0, v1, :cond_2a

    const/4 v1, 0x4

    if-eq v0, v1, :cond_27

    const/4 v1, 0x5

    if-ne v0, v1, :cond_16

    sget-object p0, Lq5;->h:Lq5;

    return-object p0

    :cond_16
    new-instance v0, Ljava/security/GeneralSecurityException;

    invoke-virtual {p0}, Ldn0;->d()I

    move-result p0

    const-string/jumbo v1, "Unable to parse HashType: "

    invoke-static {p0, v1}, Lrt2;->f(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_27
    sget-object p0, Lq5;->k:Lq5;

    return-object p0

    :cond_2a
    sget-object p0, Lq5;->i:Lq5;

    return-object p0

    :cond_2d
    sget-object p0, Lq5;->j:Lq5;

    return-object p0

    :cond_30
    sget-object p0, Lq5;->g:Lq5;

    return-object p0
.end method

.method public static I(Lq5;)Lq5;
    .registers 3

    .prologue
    sget-object v0, Lq5;->l:Lq5;

    invoke-virtual {p0, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_b

    sget-object p0, Lq5;->k0:Lq5;

    return-object p0

    :cond_b
    sget-object v0, Lq5;->m:Lq5;

    if-eq p0, v0, :cond_27

    sget-object v0, Lq5;->n:Lq5;

    if-ne p0, v0, :cond_16

    sget-object p0, Lq5;->m0:Lq5;

    return-object p0

    :cond_16
    new-instance v0, Ljava/security/GeneralSecurityException;

    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const-string/jumbo v1, "Unable to serialize variant: "

    invoke-virtual {v1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_27
    sget-object p0, Lq5;->n0:Lq5;

    return-object p0
.end method

.method public static J(Lq5;)Lq5;
    .registers 3

    .prologue
    sget-object v0, Lq5;->m:Lq5;

    sget-object v1, Lq5;->k0:Lq5;

    if-ne p0, v1, :cond_9

    sget-object p0, Lq5;->l:Lq5;

    return-object p0

    :cond_9
    sget-object v1, Lq5;->n0:Lq5;

    if-ne p0, v1, :cond_e

    goto :goto_12

    :cond_e
    sget-object v1, Lq5;->l0:Lq5;

    if-ne p0, v1, :cond_13

    :goto_12
    return-object v0

    :cond_13
    sget-object v0, Lq5;->m0:Lq5;

    if-ne p0, v0, :cond_1a

    sget-object p0, Lq5;->n:Lq5;

    return-object p0

    :cond_1a
    new-instance v0, Ljava/security/GeneralSecurityException;

    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const-string/jumbo v1, "Unable to parse OutputPrefixType: "

    invoke-virtual {v1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static K(Ljn0;)Ljava/util/Set;
    .registers 8

    .prologue
    invoke-virtual {p0}, Ljn0;->size()I

    move-result v0

    const/4 v1, 0x0

    const/4 v2, 0x0

    move v3, v2

    :goto_7
    if-ge v3, v0, :cond_51

    add-int/lit8 v4, v3, 0x1

    const-string/jumbo v5, "Vary"

    invoke-virtual {p0, v3}, Ljn0;->b(I)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_1a

    :cond_18
    move v3, v4

    goto :goto_7

    :cond_1a
    invoke-virtual {p0, v3}, Ljn0;->d(I)Ljava/lang/String;

    move-result-object v3

    if-nez v1, :cond_2a

    new-instance v1, Ljava/util/TreeSet;

    sget-object v5, Ljava/lang/String;->CASE_INSENSITIVE_ORDER:Ljava/util/Comparator;

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {v1, v5}, Ljava/util/TreeSet;-><init>(Ljava/util/Comparator;)V

    :cond_2a
    const/4 v5, 0x1

    new-array v5, v5, [C

    const/16 v6, 0x2c

    aput-char v6, v5, v2

    invoke-static {v3, v5}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_39
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_18

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/String;

    invoke-static {v5}, Lc72;->I0(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-interface {v1, v5}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    goto :goto_39

    :cond_51
    if-nez v1, :cond_56

    sget-object p0, Lea0;->a:Lea0;

    return-object p0

    :cond_56
    return-object v1
.end method

.method public static L(ILzv;Lvw;)V
    .registers 22

    .prologue
    move-object/from16 v0, p1

    move-object/from16 v1, p2

    iget-boolean v2, v1, Lvw;->n:Z

    if-eqz v2, :cond_a

    goto/16 :goto_10c

    :cond_a
    instance-of v2, v1, Lww;

    if-nez v2, :cond_22

    invoke-virtual {v1}, Lvw;->z()Z

    move-result v2

    if-eqz v2, :cond_22

    invoke-static {v1}, Lqk;->e(Lvw;)Z

    move-result v2

    if-eqz v2, :cond_22

    new-instance v2, Lzi;

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    invoke-static {v1, v0, v2}, Lww;->V(Lvw;Lzv;Lzi;)V

    :cond_22
    const/4 v2, 0x3

    invoke-virtual {v1, v2}, Lvw;->i(I)Ltv;

    move-result-object v3

    const/4 v4, 0x5

    invoke-virtual {v1, v4}, Lvw;->i(I)Ltv;

    move-result-object v4

    invoke-virtual {v3}, Ltv;->d()I

    move-result v5

    invoke-virtual {v4}, Ltv;->d()I

    move-result v6

    iget-object v7, v3, Ltv;->a:Ljava/util/HashSet;

    const/16 v9, 0x8

    if-eqz v7, :cond_104

    iget-boolean v3, v3, Ltv;->c:Z

    if-eqz v3, :cond_104

    invoke-virtual {v7}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_42
    :goto_42
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_104

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ltv;

    iget-object v12, v7, Ltv;->d:Lvw;

    add-int/lit8 v13, p0, 0x1

    invoke-static {v12}, Lqk;->e(Lvw;)Z

    move-result v14

    iget-object v15, v12, Lvw;->J:Ltv;

    const/16 v16, 0x0

    iget-object v8, v12, Lvw;->L:Ltv;

    invoke-virtual {v12}, Lvw;->z()Z

    move-result v17

    if-eqz v17, :cond_6c

    if-eqz v14, :cond_6c

    new-instance v10, Lzi;

    invoke-direct {v10}, Ljava/lang/Object;-><init>()V

    invoke-static {v12, v0, v10}, Lww;->V(Lvw;Lzv;Lzi;)V

    :cond_6c
    if-ne v7, v15, :cond_76

    iget-object v10, v8, Ltv;->f:Ltv;

    if-eqz v10, :cond_76

    iget-boolean v10, v10, Ltv;->c:Z

    if-nez v10, :cond_80

    :cond_76
    if-ne v7, v8, :cond_84

    iget-object v10, v15, Ltv;->f:Ltv;

    if-eqz v10, :cond_84

    iget-boolean v10, v10, Ltv;->c:Z

    if-eqz v10, :cond_84

    :cond_80
    const/4 v10, 0x1

    :goto_81
    const/16 v18, 0x1

    goto :goto_86

    :cond_84
    const/4 v10, 0x0

    goto :goto_81

    :goto_86
    iget-object v11, v12, Lvw;->p0:[I

    aget v11, v11, v18

    if-ne v11, v2, :cond_bd

    if-eqz v14, :cond_8f

    goto :goto_bd

    :cond_8f
    if-ne v11, v2, :cond_42

    iget v7, v12, Lvw;->y:I

    if-ltz v7, :cond_42

    iget v7, v12, Lvw;->x:I

    if-ltz v7, :cond_42

    iget v7, v12, Lvw;->g0:I

    if-eq v7, v9, :cond_a7

    iget v7, v12, Lvw;->s:I

    if-nez v7, :cond_42

    iget v7, v12, Lvw;->W:F

    cmpl-float v7, v7, v16

    if-nez v7, :cond_42

    :cond_a7
    invoke-virtual {v12}, Lvw;->y()Z

    move-result v7

    if-nez v7, :cond_42

    iget-boolean v7, v12, Lvw;->F:Z

    if-nez v7, :cond_42

    if-eqz v10, :cond_42

    invoke-virtual {v12}, Lvw;->y()Z

    move-result v7

    if-nez v7, :cond_42

    invoke-static {v13, v1, v0, v12}, Lqk;->F(ILvw;Lzv;Lvw;)V

    goto :goto_42

    :cond_bd
    :goto_bd
    invoke-virtual {v12}, Lvw;->z()Z

    move-result v11

    if-eqz v11, :cond_c5

    goto/16 :goto_42

    :cond_c5
    if-ne v7, v15, :cond_dd

    iget-object v11, v8, Ltv;->f:Ltv;

    if-nez v11, :cond_dd

    invoke-virtual {v15}, Ltv;->e()I

    move-result v7

    add-int/2addr v7, v5

    invoke-virtual {v12}, Lvw;->k()I

    move-result v8

    add-int/2addr v8, v7

    invoke-virtual {v12, v7, v8}, Lvw;->K(II)V

    invoke-static {v13, v0, v12}, Lqk;->L(ILzv;Lvw;)V

    goto/16 :goto_42

    :cond_dd
    if-ne v7, v8, :cond_f7

    iget-object v7, v15, Ltv;->f:Ltv;

    if-nez v7, :cond_f7

    invoke-virtual {v8}, Ltv;->e()I

    move-result v7

    sub-int v7, v5, v7

    invoke-virtual {v12}, Lvw;->k()I

    move-result v8

    sub-int v8, v7, v8

    invoke-virtual {v12, v8, v7}, Lvw;->K(II)V

    invoke-static {v13, v0, v12}, Lqk;->L(ILzv;Lvw;)V

    goto/16 :goto_42

    :cond_f7
    if-eqz v10, :cond_42

    invoke-virtual {v12}, Lvw;->y()Z

    move-result v7

    if-nez v7, :cond_42

    invoke-static {v13, v0, v12}, Lqk;->E(ILzv;Lvw;)V

    goto/16 :goto_42

    :cond_104
    const/16 v16, 0x0

    const/16 v18, 0x1

    instance-of v3, v1, Lpm0;

    if-eqz v3, :cond_10d

    :goto_10c
    return-void

    :cond_10d
    iget-object v3, v4, Ltv;->a:Ljava/util/HashSet;

    if-eqz v3, :cond_1d6

    iget-boolean v4, v4, Ltv;->c:Z

    if-eqz v4, :cond_1d6

    invoke-virtual {v3}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_119
    :goto_119
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_1d6

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ltv;

    iget-object v5, v4, Ltv;->d:Lvw;

    add-int/lit8 v7, p0, 0x1

    invoke-static {v5}, Lqk;->e(Lvw;)Z

    move-result v8

    iget-object v10, v5, Lvw;->J:Ltv;

    iget-object v11, v5, Lvw;->L:Ltv;

    invoke-virtual {v5}, Lvw;->z()Z

    move-result v12

    if-eqz v12, :cond_141

    if-eqz v8, :cond_141

    new-instance v12, Lzi;

    invoke-direct {v12}, Ljava/lang/Object;-><init>()V

    invoke-static {v5, v0, v12}, Lww;->V(Lvw;Lzv;Lzi;)V

    :cond_141
    if-ne v4, v10, :cond_14b

    iget-object v12, v11, Ltv;->f:Ltv;

    if-eqz v12, :cond_14b

    iget-boolean v12, v12, Ltv;->c:Z

    if-nez v12, :cond_155

    :cond_14b
    if-ne v4, v11, :cond_158

    iget-object v12, v10, Ltv;->f:Ltv;

    if-eqz v12, :cond_158

    iget-boolean v12, v12, Ltv;->c:Z

    if-eqz v12, :cond_158

    :cond_155
    move/from16 v12, v18

    goto :goto_159

    :cond_158
    const/4 v12, 0x0

    :goto_159
    iget-object v13, v5, Lvw;->p0:[I

    aget v13, v13, v18

    if-ne v13, v2, :cond_190

    if-eqz v8, :cond_162

    goto :goto_190

    :cond_162
    if-ne v13, v2, :cond_119

    iget v4, v5, Lvw;->y:I

    if-ltz v4, :cond_119

    iget v4, v5, Lvw;->x:I

    if-ltz v4, :cond_119

    iget v4, v5, Lvw;->g0:I

    if-eq v4, v9, :cond_17a

    iget v4, v5, Lvw;->s:I

    if-nez v4, :cond_119

    iget v4, v5, Lvw;->W:F

    cmpl-float v4, v4, v16

    if-nez v4, :cond_119

    :cond_17a
    invoke-virtual {v5}, Lvw;->y()Z

    move-result v4

    if-nez v4, :cond_119

    iget-boolean v4, v5, Lvw;->F:Z

    if-nez v4, :cond_119

    if-eqz v12, :cond_119

    invoke-virtual {v5}, Lvw;->y()Z

    move-result v4

    if-nez v4, :cond_119

    invoke-static {v7, v1, v0, v5}, Lqk;->F(ILvw;Lzv;Lvw;)V

    goto :goto_119

    :cond_190
    :goto_190
    invoke-virtual {v5}, Lvw;->z()Z

    move-result v8

    if-eqz v8, :cond_197

    goto :goto_119

    :cond_197
    if-ne v4, v10, :cond_1af

    iget-object v8, v11, Ltv;->f:Ltv;

    if-nez v8, :cond_1af

    invoke-virtual {v10}, Ltv;->e()I

    move-result v4

    add-int/2addr v4, v6

    invoke-virtual {v5}, Lvw;->k()I

    move-result v8

    add-int/2addr v8, v4

    invoke-virtual {v5, v4, v8}, Lvw;->K(II)V

    invoke-static {v7, v0, v5}, Lqk;->L(ILzv;Lvw;)V

    goto/16 :goto_119

    :cond_1af
    if-ne v4, v11, :cond_1c9

    iget-object v4, v10, Ltv;->f:Ltv;

    if-nez v4, :cond_1c9

    invoke-virtual {v11}, Ltv;->e()I

    move-result v4

    sub-int v4, v6, v4

    invoke-virtual {v5}, Lvw;->k()I

    move-result v8

    sub-int v8, v4, v8

    invoke-virtual {v5, v8, v4}, Lvw;->K(II)V

    invoke-static {v7, v0, v5}, Lqk;->L(ILzv;Lvw;)V

    goto/16 :goto_119

    :cond_1c9
    if-eqz v12, :cond_119

    invoke-virtual {v5}, Lvw;->y()Z

    move-result v4

    if-nez v4, :cond_119

    invoke-static {v7, v0, v5}, Lqk;->E(ILzv;Lvw;)V

    goto/16 :goto_119

    :cond_1d6
    const/4 v3, 0x6

    invoke-virtual {v1, v3}, Lvw;->i(I)Ltv;

    move-result-object v3

    iget-object v4, v3, Ltv;->a:Ljava/util/HashSet;

    if-eqz v4, :cond_254

    iget-boolean v4, v3, Ltv;->c:Z

    if-eqz v4, :cond_254

    invoke-virtual {v3}, Ltv;->d()I

    move-result v4

    iget-object v3, v3, Ltv;->a:Ljava/util/HashSet;

    invoke-virtual {v3}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_1ed
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_254

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ltv;

    iget-object v6, v5, Ltv;->d:Lvw;

    add-int/lit8 v11, p0, 0x1

    invoke-static {v6}, Lqk;->e(Lvw;)Z

    move-result v7

    iget-object v8, v6, Lvw;->M:Ltv;

    invoke-virtual {v6}, Lvw;->z()Z

    move-result v9

    if-eqz v9, :cond_213

    if-eqz v7, :cond_213

    new-instance v9, Lzi;

    invoke-direct {v9}, Ljava/lang/Object;-><init>()V

    invoke-static {v6, v0, v9}, Lww;->V(Lvw;Lzv;Lzi;)V

    :cond_213
    iget-object v9, v6, Lvw;->p0:[I

    aget v9, v9, v18

    if-ne v9, v2, :cond_21f

    if-eqz v7, :cond_21c

    goto :goto_21f

    :cond_21c
    move/from16 v5, v18

    goto :goto_251

    :cond_21f
    :goto_21f
    invoke-virtual {v6}, Lvw;->z()Z

    move-result v7

    if-eqz v7, :cond_226

    goto :goto_1ed

    :cond_226
    if-ne v5, v8, :cond_21c

    invoke-virtual {v5}, Ltv;->e()I

    move-result v5

    add-int/2addr v5, v4

    iget-boolean v7, v6, Lvw;->E:Z

    if-nez v7, :cond_234

    move/from16 v5, v18

    goto :goto_24e

    :cond_234
    iget v7, v6, Lvw;->a0:I

    sub-int v7, v5, v7

    iget v9, v6, Lvw;->V:I

    add-int/2addr v9, v7

    iput v7, v6, Lvw;->Z:I

    iget-object v10, v6, Lvw;->J:Ltv;

    invoke-virtual {v10, v7}, Ltv;->l(I)V

    iget-object v7, v6, Lvw;->L:Ltv;

    invoke-virtual {v7, v9}, Ltv;->l(I)V

    invoke-virtual {v8, v5}, Ltv;->l(I)V

    move/from16 v5, v18

    iput-boolean v5, v6, Lvw;->l:Z

    :goto_24e
    invoke-static {v11, v0, v6}, Lqk;->L(ILzv;Lvw;)V

    :goto_251
    move/from16 v18, v5

    goto :goto_1ed

    :cond_254
    move/from16 v5, v18

    iput-boolean v5, v1, Lvw;->n:Z

    return-void
.end method

.method public static a(IIII)I
    .registers 4

    add-int/2addr p0, p1

    sub-int/2addr p0, p2

    add-int/2addr p0, p3

    return p0
.end method

.method public static b(Lb13;)I
    .registers 4

    .prologue
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    instance-of v0, p0, Lads_mobile_sdk/hv0;

    if-eqz v0, :cond_9

    const/4 p0, 0x1

    return p0

    :cond_9
    instance-of v0, p0, Lads_mobile_sdk/iv0;

    const/4 v1, 0x3

    if-eqz v0, :cond_f

    return v1

    :cond_f
    instance-of v0, p0, Lads_mobile_sdk/bv0;

    if-eqz v0, :cond_1f

    check-cast p0, Lads_mobile_sdk/bv0;

    iget-object p0, p0, Lads_mobile_sdk/bv0;->c:Ljava/lang/Throwable;

    instance-of p0, p0, Ljava/util/concurrent/CancellationException;

    if-eqz p0, :cond_1d

    const/4 p0, 0x5

    return p0

    :cond_1d
    const/4 p0, 0x6

    return p0

    :cond_1f
    instance-of v0, p0, Lads_mobile_sdk/dv0;

    const/4 v2, 0x7

    if-eqz v0, :cond_38

    check-cast p0, Lads_mobile_sdk/dv0;

    iget-object p0, p0, Lads_mobile_sdk/dv0;->c:Lc81;

    invoke-virtual {p0}, Lc81;->V()Ljava/lang/Integer;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    if-ne p0, v2, :cond_34

    const/4 p0, 0x4

    return p0

    :cond_34
    if-ne p0, v1, :cond_38

    const/4 p0, 0x2

    return p0

    :cond_38
    return v2
.end method

.method public static final c(Lads_mobile_sdk/vv0;Lads_mobile_sdk/kh3;)V
    .registers 5

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v0, p1, Lads_mobile_sdk/kh3;->a:Lads_mobile_sdk/eq2;

    iget-object v1, v0, Lads_mobile_sdk/eq2;->a:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p0, p0, Lads_mobile_sdk/vv0;->a:Lm33;

    invoke-virtual {p0}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v2, p0, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v2, Lads_mobile_sdk/tv0;

    invoke-virtual {v2, v1}, Lads_mobile_sdk/tv0;->s(Ljava/lang/String;)V

    iget-object v1, v0, Lads_mobile_sdk/eq2;->b:Ljava/lang/String;

    invoke-virtual {p0}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v2, p0, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v2, Lads_mobile_sdk/tv0;

    invoke-virtual {v2, v1}, Lads_mobile_sdk/tv0;->c(Ljava/lang/String;)V

    iget-object v1, v0, Lads_mobile_sdk/eq2;->g:Ljava/lang/String;

    invoke-virtual {p0}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v2, p0, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v2, Lads_mobile_sdk/tv0;

    invoke-virtual {v2, v1}, Lads_mobile_sdk/tv0;->r(Ljava/lang/String;)V

    iget-object v1, p1, Lads_mobile_sdk/kh3;->b:Lads_mobile_sdk/ih1;

    iget-object v1, v1, Lads_mobile_sdk/ih1;->b:Ljava/lang/String;

    invoke-virtual {p0}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v2, p0, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v2, Lads_mobile_sdk/tv0;

    invoke-virtual {v2, v1}, Lads_mobile_sdk/tv0;->l(Ljava/lang/String;)V

    iget-object v1, p1, Lads_mobile_sdk/kh3;->c:Lads_mobile_sdk/dt2;

    iget-object v1, v1, Lads_mobile_sdk/dt2;->d:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v2, p0, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v2, Lads_mobile_sdk/tv0;

    invoke-virtual {v2, v1}, Lads_mobile_sdk/tv0;->m(Ljava/lang/String;)V

    iget-object v1, p1, Lads_mobile_sdk/kh3;->c:Lads_mobile_sdk/dt2;

    iget-object v1, v1, Lads_mobile_sdk/dt2;->e:Ljava/lang/String;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v2, p0, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v2, Lads_mobile_sdk/tv0;

    invoke-virtual {v2, v1}, Lads_mobile_sdk/tv0;->n(Ljava/lang/String;)V

    iget-object v1, p1, Lads_mobile_sdk/kh3;->b:Lads_mobile_sdk/ih1;

    iget v1, v1, Lads_mobile_sdk/ih1;->e:I

    invoke-virtual {p0}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v2, p0, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v2, Lads_mobile_sdk/tv0;

    invoke-static {v2, v1}, Lads_mobile_sdk/tv0;->y(Lads_mobile_sdk/tv0;I)V

    iget-object v1, p1, Lads_mobile_sdk/kh3;->d:Lads_mobile_sdk/s8;

    iget-object v1, v1, Lads_mobile_sdk/s8;->c:Ljava/lang/String;

    invoke-virtual {p0}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v2, p0, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v2, Lads_mobile_sdk/tv0;

    invoke-virtual {v2, v1}, Lads_mobile_sdk/tv0;->h(Ljava/lang/String;)V

    iget-object p1, p1, Lads_mobile_sdk/kh3;->d:Lads_mobile_sdk/s8;

    iget-object p1, p1, Lads_mobile_sdk/s8;->b:Ljava/lang/String;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p0}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object v1, p0, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast v1, Lads_mobile_sdk/tv0;

    invoke-virtual {v1, p1}, Lads_mobile_sdk/tv0;->b(Ljava/lang/String;)V

    iget-object p1, v0, Lads_mobile_sdk/eq2;->c:Lads_mobile_sdk/av2;

    invoke-static {p1}, Luz;->b(Lads_mobile_sdk/av2;)I

    move-result p1

    invoke-virtual {p0}, Lads_mobile_sdk/iu0;->b$1()V

    iget-object p0, p0, Lads_mobile_sdk/iu0;->b:Lads_mobile_sdk/ku0;

    check-cast p0, Lads_mobile_sdk/tv0;

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {p1}, Lmz2;->_getNumber$3(I)I

    move-result p1

    invoke-static {p0, p1}, Lads_mobile_sdk/tv0;->v(Lads_mobile_sdk/tv0;I)V

    return-void
.end method

.method public static e(Lvw;)Z
    .registers 9

    .prologue
    iget-object v0, p0, Lvw;->p0:[I

    const/4 v1, 0x0

    aget v2, v0, v1

    const/4 v3, 0x1

    aget v0, v0, v3

    iget-object v4, p0, Lvw;->T:Lww;

    if-eqz v4, :cond_d

    goto :goto_e

    :cond_d
    const/4 v4, 0x0

    :goto_e
    if-eqz v4, :cond_14

    iget-object v5, v4, Lvw;->p0:[I

    aget v5, v5, v1

    :cond_14
    if-eqz v4, :cond_1a

    iget-object v4, v4, Lvw;->p0:[I

    aget v4, v4, v3

    :cond_1a
    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-eq v2, v3, :cond_4c

    invoke-virtual {p0}, Lvw;->A()Z

    move-result v7

    if-nez v7, :cond_4c

    if-eq v2, v5, :cond_4c

    if-ne v2, v4, :cond_39

    iget v7, p0, Lvw;->r:I

    if-nez v7, :cond_39

    iget v7, p0, Lvw;->W:F

    cmpl-float v7, v7, v6

    if-nez v7, :cond_39

    invoke-virtual {p0, v1}, Lvw;->t(I)Z

    move-result v7

    if-nez v7, :cond_4c

    :cond_39
    if-ne v2, v4, :cond_4a

    iget v2, p0, Lvw;->r:I

    if-ne v2, v3, :cond_4a

    invoke-virtual {p0}, Lvw;->q()I

    move-result v2

    invoke-virtual {p0, v1, v2}, Lvw;->u(II)Z

    move-result v2

    if-eqz v2, :cond_4a

    goto :goto_4c

    :cond_4a
    move v2, v1

    goto :goto_4d

    :cond_4c
    :goto_4c
    move v2, v3

    :goto_4d
    if-eq v0, v3, :cond_7c

    invoke-virtual {p0}, Lvw;->B()Z

    move-result v7

    if-nez v7, :cond_7c

    if-eq v0, v5, :cond_7c

    if-ne v0, v4, :cond_69

    iget v5, p0, Lvw;->s:I

    if-nez v5, :cond_69

    iget v5, p0, Lvw;->W:F

    cmpl-float v5, v5, v6

    if-nez v5, :cond_69

    invoke-virtual {p0, v3}, Lvw;->t(I)Z

    move-result v5

    if-nez v5, :cond_7c

    :cond_69
    if-ne v0, v4, :cond_7a

    iget v0, p0, Lvw;->s:I

    if-ne v0, v3, :cond_7a

    invoke-virtual {p0}, Lvw;->k()I

    move-result v0

    invoke-virtual {p0, v3, v0}, Lvw;->u(II)Z

    move-result v0

    if-eqz v0, :cond_7a

    goto :goto_7c

    :cond_7a
    move v0, v1

    goto :goto_7d

    :cond_7c
    :goto_7c
    move v0, v3

    :goto_7d
    iget p0, p0, Lvw;->W:F

    cmpl-float p0, p0, v6

    if-lez p0, :cond_88

    if-nez v2, :cond_8c

    if-eqz v0, :cond_88

    goto :goto_8c

    :cond_88
    if-eqz v2, :cond_8d

    if-eqz v0, :cond_8d

    :cond_8c
    :goto_8c
    return v3

    :cond_8d
    return v1
.end method

.method public static f(Ljava/lang/Class;Ljava/lang/reflect/InvocationHandler;)Ljava/lang/Object;
    .registers 4

    .prologue
    if-nez p1, :cond_4

    const/4 p0, 0x0

    return-object p0

    :cond_4
    const-class v0, Lqk;

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    filled-new-array {p0}, [Ljava/lang/Class;

    move-result-object v1

    invoke-static {v0, v1, p1}, Ljava/lang/reflect/Proxy;->newProxyInstance(Ljava/lang/ClassLoader;[Ljava/lang/Class;Ljava/lang/reflect/InvocationHandler;)Ljava/lang/Object;

    move-result-object p1

    invoke-virtual {p0, p1}, Ljava/lang/Class;->cast(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public static g(Landroid/util/TypedValue;Ljd1;Ljd1;Ljava/lang/String;Ljava/lang/String;)Ljd1;
    .registers 7

    .prologue
    if-eqz p1, :cond_21

    if-ne p1, p2, :cond_5

    goto :goto_21

    :cond_5
    new-instance p1, Lorg/xmlpull/v1/XmlPullParserException;

    const-string/jumbo p2, " but found "

    const-string/jumbo v0, ": "

    const-string/jumbo v1, "Type is "

    invoke-static {v1, p3, p2, p4, v0}, Ly41;->t(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p2

    iget p0, p0, Landroid/util/TypedValue;->data:I

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {p1, p0}, Lorg/xmlpull/v1/XmlPullParserException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_21
    :goto_21
    if-nez p1, :cond_24

    return-object p2

    :cond_24
    return-object p1
.end method

.method public static h(Ljava/lang/Comparable;Ljava/lang/Comparable;)I
    .registers 2

    .prologue
    if-ne p0, p1, :cond_4

    const/4 p0, 0x0

    return p0

    :cond_4
    if-nez p0, :cond_8

    const/4 p0, -0x1

    return p0

    :cond_8
    if-nez p1, :cond_c

    const/4 p0, 0x1

    return p0

    :cond_c
    invoke-interface {p0, p1}, Ljava/lang/Comparable;->compareTo(Ljava/lang/Object;)I

    move-result p0

    return p0
.end method

.method public static i(Landroid/content/Context;)Log0;
    .registers 9

    .prologue
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1c

    const/16 v2, 0x15

    if-lt v0, v1, :cond_e

    new-instance v0, Lr10;

    invoke-direct {v0, v2}, Lms1;-><init>(I)V

    goto :goto_13

    :cond_e
    new-instance v0, Lms1;

    invoke-direct {v0, v2}, Lms1;-><init>(I)V

    :goto_13
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const-string/jumbo v2, "Package manager required to locate emoji font provider"

    invoke-static {v1, v2}, Lhi1;->w(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v2, Landroid/content/Intent;

    const-string/jumbo v3, "androidx.content.action.LOAD_EMOJI_FONT"

    invoke-direct {v2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    invoke-virtual {v1, v2, v3}, Landroid/content/pm/PackageManager;->queryIntentContentProviders(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_2e
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v5, 0x0

    if-eqz v4, :cond_4a

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/content/pm/ResolveInfo;

    iget-object v4, v4, Landroid/content/pm/ResolveInfo;->providerInfo:Landroid/content/pm/ProviderInfo;

    if-eqz v4, :cond_2e

    iget-object v6, v4, Landroid/content/pm/ProviderInfo;->applicationInfo:Landroid/content/pm/ApplicationInfo;

    if-eqz v6, :cond_2e

    iget v6, v6, Landroid/content/pm/ApplicationInfo;->flags:I

    const/4 v7, 0x1

    and-int/2addr v6, v7

    if-ne v6, v7, :cond_2e

    goto :goto_4b

    :cond_4a
    move-object v4, v5

    :goto_4b
    if-nez v4, :cond_4f

    :goto_4d
    move-object v1, v5

    goto :goto_7e

    :cond_4f
    :try_start_4f
    iget-object v2, v4, Landroid/content/pm/ProviderInfo;->authority:Ljava/lang/String;

    iget-object v4, v4, Landroid/content/pm/ProviderInfo;->packageName:Ljava/lang/String;

    invoke-virtual {v0, v1, v4}, Lms1;->l(Landroid/content/pm/PackageManager;Ljava/lang/String;)[Landroid/content/pm/Signature;

    move-result-object v0

    new-instance v1, Ljava/util/ArrayList;

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    array-length v6, v0

    :goto_5d
    if-ge v3, v6, :cond_6b

    aget-object v7, v0, v3

    invoke-virtual {v7}, Landroid/content/pm/Signature;->toByteArray()[B

    move-result-object v7

    invoke-virtual {v1, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x1

    goto :goto_5d

    :cond_6b
    invoke-static {v1}, Ljava/util/Collections;->singletonList(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    new-instance v1, Lmg0;

    const-string/jumbo v3, "emojicompat-emoji-font"

    invoke-direct {v1, v2, v4, v3, v0}, Lmg0;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/util/List;)V
    :try_end_77
    .catch Landroid/content/pm/PackageManager$NameNotFoundException; {:try_start_4f .. :try_end_77} :catch_78

    goto :goto_7e

    :catch_78
    move-exception v0

    const-string/jumbo v1, "emoji2.text.DefaultEmojiConfig"

    nop

    goto :goto_4d

    :goto_7e
    if-nez v1, :cond_81

    goto :goto_8b

    :cond_81
    new-instance v5, Log0;

    new-instance v0, Lng0;

    invoke-direct {v0, p0, v1}, Lng0;-><init>(Landroid/content/Context;Lmg0;)V

    invoke-direct {v5, v0}, Lc90;-><init>(Le90;)V

    :goto_8b
    return-object v5
.end method

.method public static j(I)Lhi1;
    .registers 2

    .prologue
    if-eqz p0, :cond_11

    const/4 v0, 0x1

    if-eq p0, v0, :cond_b

    new-instance p0, Ljv1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-object p0

    :cond_b
    new-instance p0, Li00;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-object p0

    :cond_11
    new-instance p0, Ljv1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-object p0
.end method

.method public static k(Lwl;)Ljava/lang/String;
    .registers 6

    .prologue
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Lwl;->size()I

    move-result v1

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    const/4 v1, 0x0

    :goto_a
    invoke-virtual {p0}, Lwl;->size()I

    move-result v2

    if-ge v1, v2, :cond_99

    invoke-virtual {p0, v1}, Lwl;->b(I)B

    move-result v2

    const/16 v3, 0x22

    if-eq v2, v3, :cond_8f

    const/16 v3, 0x27

    if-eq v2, v3, :cond_88

    const/16 v3, 0x5c

    if-eq v2, v3, :cond_81

    packed-switch v2, :pswitch_data_9e

    const/16 v4, 0x20

    if-lt v2, v4, :cond_30

    const/16 v4, 0x7e

    if-gt v2, v4, :cond_30

    int-to-char v2, v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_95

    :cond_30
    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    ushr-int/lit8 v3, v2, 0x6

    and-int/lit8 v3, v3, 0x3

    add-int/lit8 v3, v3, 0x30

    int-to-char v3, v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    ushr-int/lit8 v3, v2, 0x3

    and-int/lit8 v3, v3, 0x7

    add-int/lit8 v3, v3, 0x30

    int-to-char v3, v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    and-int/lit8 v2, v2, 0x7

    add-int/lit8 v2, v2, 0x30

    int-to-char v2, v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    goto :goto_95

    :pswitch_50  #0xd
    const-string/jumbo v2, "\\r"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_95

    :pswitch_57  #0xc
    const-string/jumbo v2, "\\f"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_95

    :pswitch_5e  #0xb
    const-string/jumbo v2, "\\v"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_95

    :pswitch_65  #0xa
    const-string/jumbo v2, "\\n"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_95

    :pswitch_6c  #0x9
    const-string/jumbo v2, "\\t"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_95

    :pswitch_73  #0x8
    const-string/jumbo v2, "\\b"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_95

    :pswitch_7a  #0x7
    const-string/jumbo v2, "\\a"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_95

    :cond_81
    const-string/jumbo v2, "\\\\"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_95

    :cond_88
    const-string/jumbo v2, "\\\'"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_95

    :cond_8f
    const-string/jumbo v2, "\\\""

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_95
    add-int/lit8 v1, v1, 0x1

    goto/16 :goto_a

    :cond_99
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :pswitch_data_9e
    .packed-switch 0x7
        :pswitch_7a  #00000007
        :pswitch_73  #00000008
        :pswitch_6c  #00000009
        :pswitch_65  #0000000a
        :pswitch_5e  #0000000b
        :pswitch_57  #0000000c
        :pswitch_50  #0000000d
    .end packed-switch
.end method

.method public static l(Landroid/content/Context;)Landroid/graphics/Rect;
    .registers 3

    .prologue
    const-string/jumbo v0, "window"

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/view/WindowManager;

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1e

    if-lt v0, v1, :cond_14

    invoke-static {p0}, Lq1;->d(Landroid/view/WindowManager;)Landroid/graphics/Rect;

    move-result-object p0

    return-object p0

    :cond_14
    invoke-interface {p0}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object p0

    new-instance v0, Landroid/graphics/Point;

    invoke-direct {v0}, Landroid/graphics/Point;-><init>()V

    invoke-virtual {p0, v0}, Landroid/view/Display;->getRealSize(Landroid/graphics/Point;)V

    new-instance p0, Landroid/graphics/Rect;

    invoke-direct {p0}, Landroid/graphics/Rect;-><init>()V

    iget v1, v0, Landroid/graphics/Point;->x:I

    iput v1, p0, Landroid/graphics/Rect;->right:I

    iget v0, v0, Landroid/graphics/Point;->y:I

    iput v0, p0, Landroid/graphics/Rect;->bottom:I

    return-object p0
.end method

.method public static m(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;
    .registers 3

    invoke-static {}, Lbu1;->b()Lbu1;

    move-result-object v0

    invoke-virtual {v0, p0, p1}, Lbu1;->c(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p0

    return-object p0
.end method

.method public static n(Lg6;)Ldo0;
    .registers 4

    .prologue
    invoke-static {}, Ldo0;->y()Lco0;

    move-result-object v0

    iget v1, p0, Lg6;->d:I

    invoke-virtual {v0}, Lkl0;->e()V

    iget-object v2, v0, Lkl0;->b:Lrl0;

    check-cast v2, Ldo0;

    invoke-virtual {v2, v1}, Ldo0;->A(I)V

    iget-object p0, p0, Lg6;->f:Lq5;

    sget-object v1, Lq5;->g:Lq5;

    invoke-virtual {p0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_1d

    sget-object p0, Ldn0;->c:Ldn0;

    goto :goto_49

    :cond_1d
    sget-object v1, Lq5;->h:Lq5;

    if-eq p0, v1, :cond_47

    sget-object v1, Lq5;->i:Lq5;

    if-eq p0, v1, :cond_44

    sget-object v1, Lq5;->j:Lq5;

    if-eq p0, v1, :cond_41

    sget-object v1, Lq5;->k:Lq5;

    if-ne p0, v1, :cond_30

    sget-object p0, Ldn0;->f:Ldn0;

    goto :goto_49

    :cond_30
    new-instance v0, Ljava/security/GeneralSecurityException;

    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const-string/jumbo v1, "Unable to serialize HashType "

    invoke-virtual {v1, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_41
    sget-object p0, Ldn0;->d:Ldn0;

    goto :goto_49

    :cond_44
    sget-object p0, Ldn0;->e:Ldn0;

    goto :goto_49

    :cond_47
    sget-object p0, Ldn0;->g:Ldn0;

    :goto_49
    invoke-virtual {v0}, Lkl0;->e()V

    iget-object v1, v0, Lkl0;->b:Lrl0;

    check-cast v1, Ldo0;

    invoke-virtual {v1, p0}, Ldo0;->z(Ldn0;)V

    invoke-virtual {v0}, Lkl0;->a()Lrl0;

    move-result-object p0

    check-cast p0, Ldo0;

    return-object p0
.end method

.method public static final o(Llq;)Ljava/lang/Class;
    .registers 3

    .prologue
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {p0}, Ljq;->a()Ljava/lang/Class;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Class;->isPrimitive()Z

    move-result v0

    if-nez v0, :cond_e

    return-object p0

    :cond_e
    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v1

    sparse-switch v1, :sswitch_data_92

    goto/16 :goto_91

    :sswitch_1b
    const-string/jumbo v1, "short"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_26

    goto/16 :goto_91

    :cond_26
    const-class p0, Ljava/lang/Short;

    goto/16 :goto_91

    :sswitch_2a
    const-string/jumbo v1, "float"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_34

    goto :goto_91

    :cond_34
    const-class p0, Ljava/lang/Float;

    goto :goto_91

    :sswitch_37
    const-string/jumbo v1, "boolean"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_41

    goto :goto_91

    :cond_41
    const-class p0, Ljava/lang/Boolean;

    goto :goto_91

    :sswitch_44
    const-string/jumbo v1, "void"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_4e

    goto :goto_91

    :cond_4e
    const-class p0, Ljava/lang/Void;

    goto :goto_91

    :sswitch_51
    const-string/jumbo v1, "long"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_5b

    goto :goto_91

    :cond_5b
    const-class p0, Ljava/lang/Long;

    goto :goto_91

    :sswitch_5e
    const-string/jumbo v1, "char"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_68

    goto :goto_91

    :cond_68
    const-class p0, Ljava/lang/Character;

    goto :goto_91

    :sswitch_6b
    const-string/jumbo v1, "byte"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_75

    goto :goto_91

    :cond_75
    const-class p0, Ljava/lang/Byte;

    goto :goto_91

    :sswitch_78
    const-string/jumbo v1, "int"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_82

    goto :goto_91

    :cond_82
    const-class p0, Ljava/lang/Integer;

    goto :goto_91

    :sswitch_85
    const-string/jumbo v1, "double"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_8f

    goto :goto_91

    :cond_8f
    const-class p0, Ljava/lang/Double;

    :goto_91
    return-object p0

    :sswitch_data_92
    .sparse-switch
        -0x4f08842f -> :sswitch_85
        0x197ef -> :sswitch_78
        0x2e6108 -> :sswitch_6b
        0x2e9356 -> :sswitch_5e
        0x32c67c -> :sswitch_51
        0x375194 -> :sswitch_44
        0x3db6c28 -> :sswitch_37
        0x5d0225c -> :sswitch_2a
        0x685847c -> :sswitch_1b
    .end sparse-switch
.end method

.method public static p(Landroid/content/SharedPreferences;Landroid/content/res/Resources;I)[Ljava/lang/String;
    .registers 15

    .prologue
    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x17f

    sget-object v2, Lqk;->p:[Ljava/lang/String;

    nop

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-eqz v2, :cond_18

    const/16 v0, 0x220

    sget-object v5, Lqk;->m:[Ljava/lang/String;

    nop

    array-length v5, v5

    if-lt v5, v3, :cond_18

    array-length v2, v2

    if-ge v2, v3, :cond_13b

    :cond_18
    const v2, 0x7f030006

    const/16 v0, 0x3e2

    invoke-virtual {p1, v2}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x8ec

    sput-object v2, Lqk;->p:[Ljava/lang/String;

    const v2, 0x7f030007

    const/16 v0, 0x3e2

    invoke-virtual {p1, v2}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x59f

    sput-object p1, Lqk;->o:[Ljava/lang/String;

    const-string/jumbo p1, "osrvlist"

    const-string/jumbo v2, ""

    const/16 v0, 0x2e

    invoke-interface {p0, p1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/4 v0, -0x6

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x47

    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v6

    const/16 v7, 0xc

    const/4 v8, 0x0

    const/16 v9, 0x2c

    const-string/jumbo v10, "0"

    if-lez v6, :cond_c0

    const/16 v0, 0x3eb

    new-instance v6, Ltd;

    nop

    const/16 v0, 0x484

    invoke-direct {v6, v7}, Ltd;-><init>(I)V

    const/16 v0, 0x2e4

    sget-object v11, Lip;->a:Ljava/nio/charset/Charset;

    nop

    const/16 v0, 0x2c

    invoke-virtual {v5, v11}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v5

    const/4 v0, -0x6

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x4e2

    invoke-virtual {v6, v5}, Ltd;->r([B)Ljava/lang/String;

    move-result-object v5

    const/16 v0, 0x7c

    invoke-static {v5}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v6

    if-eqz v6, :cond_9a

    const/16 v0, 0x7a

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v5

    const-string/jumbo v6, "osrvlistid"

    const/16 v0, 0x3c

    invoke-interface {v5, v6, v10}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x3c

    invoke-interface {v5, p1, v10}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x6f

    invoke-interface {v5}, Landroid/content/SharedPreferences$Editor;->apply()V

    goto :goto_c0

    :cond_9a
    new-array p1, v4, [C

    aput-char v9, p1, v8

    const/16 v0, 0x31

    invoke-static {v5, p1}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object p1

    const/16 v0, 0x17d

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v5

    if-le v5, v4, :cond_c0

    check-cast p1, Ljava/util/Collection;

    new-array v5, v8, [Ljava/lang/String;

    const/16 v0, 0x4dc

    invoke-interface {p1, v5}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p1

    check-cast p1, [Ljava/lang/String;

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xe56

    sput-object p1, Lqk;->m:[Ljava/lang/String;

    :cond_c0
    :goto_c0
    const-string/jumbo p1, "psrvlist"

    const/16 v0, 0x2e

    invoke-interface {p0, p1, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x47

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v5

    if-lez v5, :cond_13b

    const/16 v0, 0x3eb

    new-instance v5, Ltd;

    nop

    const/16 v0, 0x484

    invoke-direct {v5, v7}, Ltd;-><init>(I)V

    const/16 v0, 0x2e4

    sget-object v6, Lip;->a:Ljava/nio/charset/Charset;

    nop

    const/16 v0, 0x2c

    invoke-virtual {v2, v6}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x4e2

    invoke-virtual {v5, v2}, Ltd;->r([B)Ljava/lang/String;

    move-result-object v2

    const/16 v0, 0x7c

    invoke-static {v2}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_115

    const/16 v0, 0x7a

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo v2, "psrvlistid"

    const/16 v0, 0x3c

    invoke-interface {p0, v2, v10}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x3c

    invoke-interface {p0, p1, v10}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x6f

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    goto :goto_13b

    :cond_115
    new-array p0, v4, [C

    aput-char v9, p0, v8

    const/16 v0, 0x31

    invoke-static {v2, p0}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object p0

    const/16 v0, 0x17d

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result p1

    if-le p1, v4, :cond_13b

    check-cast p0, Ljava/util/Collection;

    new-array p1, v8, [Ljava/lang/String;

    const/16 v0, 0x4dc

    invoke-interface {p0, p1}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p0

    check-cast p0, [Ljava/lang/String;

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x9d0

    sput-object p0, Lqk;->n:[Ljava/lang/String;

    :cond_13b
    :goto_13b
    const/4 p0, 0x0

    const-string/jumbo p1, "servidoresRoot"

    if-eqz p2, :cond_18e

    if-eq p2, v4, :cond_17f

    if-eq p2, v3, :cond_177

    const/4 v2, 0x3

    if-eq p2, v2, :cond_162

    const/16 v0, 0x220

    sget-object p2, Lqk;->m:[Ljava/lang/String;

    nop

    array-length v2, p2

    if-le v2, v4, :cond_153

    check-cast p2, [Ljava/lang/String;

    return-object p2

    :cond_153
    const/16 v0, 0x17f

    sget-object p2, Lqk;->p:[Ljava/lang/String;

    nop

    if-eqz p2, :cond_15d

    check-cast p2, [Ljava/lang/String;

    return-object p2

    :cond_15d
    const/4 v0, 0x5

    invoke-static {p1}, Lgt0;->F0(Ljava/lang/String;)V

    throw p0

    :cond_162
    const/16 v0, 0x90e

    sget-object p0, Lqk;->n:[Ljava/lang/String;

    nop

    array-length p1, p0

    if-le p1, v4, :cond_16d

    check-cast p0, [Ljava/lang/String;

    return-object p0

    :cond_16d
    const-string/jumbo p0, "Auto"

    check-cast p0, Ljava/lang/String;

    filled-new-array {p0}, [Ljava/lang/String;

    move-result-object p0

    return-object p0

    :cond_177
    const/16 v0, 0x55a

    sget-object p0, Lqk;->o:[Ljava/lang/String;

    nop

    check-cast p0, [Ljava/lang/String;

    return-object p0

    :cond_17f
    const/16 v0, 0x17f

    sget-object p2, Lqk;->p:[Ljava/lang/String;

    nop

    if-eqz p2, :cond_189

    check-cast p2, [Ljava/lang/String;

    return-object p2

    :cond_189
    const/4 v0, 0x5

    invoke-static {p1}, Lgt0;->F0(Ljava/lang/String;)V

    throw p0

    :cond_18e
    const/16 v0, 0x220

    sget-object p2, Lqk;->m:[Ljava/lang/String;

    nop

    array-length v2, p2

    if-le v2, v4, :cond_199

    check-cast p2, [Ljava/lang/String;

    return-object p2

    :cond_199
    const/16 v0, 0x17f

    sget-object p2, Lqk;->p:[Ljava/lang/String;

    nop

    if-eqz p2, :cond_1a3

    check-cast p2, [Ljava/lang/String;

    return-object p2

    :cond_1a3
    const/4 v0, 0x5

    invoke-static {p1}, Lgt0;->F0(Ljava/lang/String;)V

    throw p0
.end method

.method public static final r(Lm02;[Lm02;)I
    .registers 9

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-interface {p0}, Lm02;->a()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    mul-int/lit8 v0, v0, 0x1f

    invoke-static {p1}, Ljava/util/Arrays;->hashCode([Ljava/lang/Object;)I

    move-result p1

    add-int/2addr v0, p1

    invoke-interface {p0}, Lm02;->f()I

    move-result p1

    const/4 v1, 0x1

    move v2, v1

    :goto_18
    const/4 v3, 0x0

    if-lez p1, :cond_1d

    move v4, v1

    goto :goto_1e

    :cond_1d
    move v4, v3

    :goto_1e
    if-eqz v4, :cond_3a

    invoke-interface {p0}, Lm02;->f()I

    move-result v4

    add-int/lit8 v5, p1, -0x1

    sub-int/2addr v4, p1

    invoke-interface {p0, v4}, Lm02;->j(I)Lm02;

    move-result-object p1

    mul-int/lit8 v2, v2, 0x1f

    invoke-interface {p1}, Lm02;->a()Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_37

    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    move-result v3

    :cond_37
    add-int/2addr v2, v3

    move p1, v5

    goto :goto_18

    :cond_3a
    invoke-interface {p0}, Lm02;->f()I

    move-result p1

    move v4, v1

    :goto_3f
    if-lez p1, :cond_43

    move v5, v1

    goto :goto_44

    :cond_43
    move v5, v3

    :goto_44
    if-eqz v5, :cond_62

    invoke-interface {p0}, Lm02;->f()I

    move-result v5

    add-int/lit8 v6, p1, -0x1

    sub-int/2addr v5, p1

    invoke-interface {p0, v5}, Lm02;->j(I)Lm02;

    move-result-object p1

    mul-int/lit8 v4, v4, 0x1f

    invoke-interface {p1}, Lm02;->e()Lqk;

    move-result-object p1

    if-eqz p1, :cond_5e

    invoke-virtual {p1}, Lqk;->hashCode()I

    move-result p1

    goto :goto_5f

    :cond_5e
    move p1, v3

    :goto_5f
    add-int/2addr v4, p1

    move p1, v6

    goto :goto_3f

    :cond_62
    mul-int/lit8 v0, v0, 0x1f

    add-int/2addr v0, v2

    mul-int/lit8 v0, v0, 0x1f

    add-int/2addr v0, v4

    return v0
.end method

.method public static s(ILzv;Lvw;Z)V
    .registers 23

    .prologue
    move-object/from16 v0, p1

    move-object/from16 v1, p2

    move/from16 v2, p3

    iget-boolean v3, v1, Lvw;->m:Z

    if-eqz v3, :cond_c

    goto/16 :goto_118

    :cond_c
    instance-of v3, v1, Lww;

    if-nez v3, :cond_24

    invoke-virtual {v1}, Lvw;->z()Z

    move-result v3

    if-eqz v3, :cond_24

    invoke-static {v1}, Lqk;->e(Lvw;)Z

    move-result v3

    if-eqz v3, :cond_24

    new-instance v3, Lzi;

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    invoke-static {v1, v0, v3}, Lww;->V(Lvw;Lzv;Lzi;)V

    :cond_24
    const/4 v3, 0x2

    invoke-virtual {v1, v3}, Lvw;->i(I)Ltv;

    move-result-object v3

    const/4 v4, 0x4

    invoke-virtual {v1, v4}, Lvw;->i(I)Ltv;

    move-result-object v4

    invoke-virtual {v3}, Ltv;->d()I

    move-result v5

    invoke-virtual {v4}, Ltv;->d()I

    move-result v6

    iget-object v7, v3, Ltv;->a:Ljava/util/HashSet;

    const/4 v10, 0x3

    if-eqz v7, :cond_10e

    iget-boolean v3, v3, Ltv;->c:Z

    if-eqz v3, :cond_10e

    invoke-virtual {v7}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_43
    :goto_43
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v7

    if-eqz v7, :cond_10e

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ltv;

    iget-object v13, v7, Ltv;->d:Lvw;

    add-int/lit8 v14, p0, 0x1

    invoke-static {v13}, Lqk;->e(Lvw;)Z

    move-result v15

    const/16 v16, 0x0

    iget-object v8, v13, Lvw;->I:Ltv;

    const/16 v17, 0x0

    iget-object v11, v13, Lvw;->K:Ltv;

    invoke-virtual {v13}, Lvw;->z()Z

    move-result v18

    if-eqz v18, :cond_72

    if-eqz v15, :cond_72

    const/16 v18, 0x1

    new-instance v12, Lzi;

    invoke-direct {v12}, Ljava/lang/Object;-><init>()V

    invoke-static {v13, v0, v12}, Lww;->V(Lvw;Lzv;Lzi;)V

    goto :goto_74

    :cond_72
    const/16 v18, 0x1

    :goto_74
    if-ne v7, v8, :cond_7e

    iget-object v12, v11, Ltv;->f:Ltv;

    if-eqz v12, :cond_7e

    iget-boolean v12, v12, Ltv;->c:Z

    if-nez v12, :cond_88

    :cond_7e
    if-ne v7, v11, :cond_8b

    iget-object v12, v8, Ltv;->f:Ltv;

    if-eqz v12, :cond_8b

    iget-boolean v12, v12, Ltv;->c:Z

    if-eqz v12, :cond_8b

    :cond_88
    move/from16 v12, v18

    goto :goto_8d

    :cond_8b
    move/from16 v12, v17

    :goto_8d
    iget-object v9, v13, Lvw;->p0:[I

    aget v9, v9, v17

    if-ne v9, v10, :cond_c7

    if-eqz v15, :cond_96

    goto :goto_c7

    :cond_96
    if-ne v9, v10, :cond_43

    iget v7, v13, Lvw;->v:I

    if-ltz v7, :cond_43

    iget v7, v13, Lvw;->u:I

    if-ltz v7, :cond_43

    iget v7, v13, Lvw;->g0:I

    const/16 v8, 0x8

    if-eq v7, v8, :cond_b0

    iget v7, v13, Lvw;->r:I

    if-nez v7, :cond_43

    iget v7, v13, Lvw;->W:F

    cmpl-float v7, v7, v16

    if-nez v7, :cond_43

    :cond_b0
    invoke-virtual {v13}, Lvw;->x()Z

    move-result v7

    if-nez v7, :cond_43

    iget-boolean v7, v13, Lvw;->F:Z

    if-nez v7, :cond_43

    if-eqz v12, :cond_43

    invoke-virtual {v13}, Lvw;->x()Z

    move-result v7

    if-nez v7, :cond_43

    invoke-static {v14, v1, v0, v13, v2}, Lqk;->D(ILvw;Lzv;Lvw;Z)V

    goto/16 :goto_43

    :cond_c7
    :goto_c7
    invoke-virtual {v13}, Lvw;->z()Z

    move-result v9

    if-eqz v9, :cond_cf

    goto/16 :goto_43

    :cond_cf
    if-ne v7, v8, :cond_e7

    iget-object v9, v11, Ltv;->f:Ltv;

    if-nez v9, :cond_e7

    invoke-virtual {v8}, Ltv;->e()I

    move-result v7

    add-int/2addr v7, v5

    invoke-virtual {v13}, Lvw;->q()I

    move-result v8

    add-int/2addr v8, v7

    invoke-virtual {v13, v7, v8}, Lvw;->J(II)V

    invoke-static {v14, v0, v13, v2}, Lqk;->s(ILzv;Lvw;Z)V

    goto/16 :goto_43

    :cond_e7
    if-ne v7, v11, :cond_101

    iget-object v7, v8, Ltv;->f:Ltv;

    if-nez v7, :cond_101

    invoke-virtual {v11}, Ltv;->e()I

    move-result v7

    sub-int v7, v5, v7

    invoke-virtual {v13}, Lvw;->q()I

    move-result v8

    sub-int v8, v7, v8

    invoke-virtual {v13, v8, v7}, Lvw;->J(II)V

    invoke-static {v14, v0, v13, v2}, Lqk;->s(ILzv;Lvw;Z)V

    goto/16 :goto_43

    :cond_101
    if-eqz v12, :cond_43

    invoke-virtual {v13}, Lvw;->x()Z

    move-result v7

    if-nez v7, :cond_43

    invoke-static {v14, v0, v13, v2}, Lqk;->C(ILzv;Lvw;Z)V

    goto/16 :goto_43

    :cond_10e
    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x1

    instance-of v3, v1, Lpm0;

    if-eqz v3, :cond_119

    :goto_118
    return-void

    :cond_119
    iget-object v3, v4, Ltv;->a:Ljava/util/HashSet;

    if-eqz v3, :cond_1eb

    iget-boolean v4, v4, Ltv;->c:Z

    if-eqz v4, :cond_1eb

    invoke-virtual {v3}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_125
    :goto_125
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_1eb

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ltv;

    iget-object v5, v4, Ltv;->d:Lvw;

    add-int/lit8 v12, p0, 0x1

    invoke-static {v5}, Lqk;->e(Lvw;)Z

    move-result v7

    iget-object v8, v5, Lvw;->I:Ltv;

    iget-object v9, v5, Lvw;->K:Ltv;

    invoke-virtual {v5}, Lvw;->z()Z

    move-result v11

    if-eqz v11, :cond_14d

    if-eqz v7, :cond_14d

    new-instance v11, Lzi;

    invoke-direct {v11}, Ljava/lang/Object;-><init>()V

    invoke-static {v5, v0, v11}, Lww;->V(Lvw;Lzv;Lzi;)V

    :cond_14d
    if-ne v4, v8, :cond_157

    iget-object v11, v9, Ltv;->f:Ltv;

    if-eqz v11, :cond_157

    iget-boolean v11, v11, Ltv;->c:Z

    if-nez v11, :cond_161

    :cond_157
    if-ne v4, v9, :cond_164

    iget-object v11, v8, Ltv;->f:Ltv;

    if-eqz v11, :cond_164

    iget-boolean v11, v11, Ltv;->c:Z

    if-eqz v11, :cond_164

    :cond_161
    move/from16 v11, v18

    goto :goto_166

    :cond_164
    move/from16 v11, v17

    :goto_166
    iget-object v13, v5, Lvw;->p0:[I

    aget v13, v13, v17

    if-ne v13, v10, :cond_16e

    if-eqz v7, :cond_171

    :cond_16e
    const/16 v7, 0x8

    goto :goto_1a4

    :cond_171
    if-ne v13, v10, :cond_1a1

    iget v4, v5, Lvw;->v:I

    if-ltz v4, :cond_1a1

    iget v4, v5, Lvw;->u:I

    if-ltz v4, :cond_1a1

    iget v4, v5, Lvw;->g0:I

    const/16 v7, 0x8

    if-eq v4, v7, :cond_18b

    iget v4, v5, Lvw;->r:I

    if-nez v4, :cond_125

    iget v4, v5, Lvw;->W:F

    cmpl-float v4, v4, v16

    if-nez v4, :cond_125

    :cond_18b
    invoke-virtual {v5}, Lvw;->x()Z

    move-result v4

    if-nez v4, :cond_125

    iget-boolean v4, v5, Lvw;->F:Z

    if-nez v4, :cond_125

    if-eqz v11, :cond_125

    invoke-virtual {v5}, Lvw;->x()Z

    move-result v4

    if-nez v4, :cond_125

    invoke-static {v12, v1, v0, v5, v2}, Lqk;->D(ILvw;Lzv;Lvw;Z)V

    goto :goto_125

    :cond_1a1
    const/16 v7, 0x8

    goto :goto_125

    :goto_1a4
    invoke-virtual {v5}, Lvw;->z()Z

    move-result v13

    if-eqz v13, :cond_1ac

    goto/16 :goto_125

    :cond_1ac
    if-ne v4, v8, :cond_1c4

    iget-object v13, v9, Ltv;->f:Ltv;

    if-nez v13, :cond_1c4

    invoke-virtual {v8}, Ltv;->e()I

    move-result v4

    add-int/2addr v4, v6

    invoke-virtual {v5}, Lvw;->q()I

    move-result v8

    add-int/2addr v8, v4

    invoke-virtual {v5, v4, v8}, Lvw;->J(II)V

    invoke-static {v12, v0, v5, v2}, Lqk;->s(ILzv;Lvw;Z)V

    goto/16 :goto_125

    :cond_1c4
    if-ne v4, v9, :cond_1de

    iget-object v4, v8, Ltv;->f:Ltv;

    if-nez v4, :cond_1de

    invoke-virtual {v9}, Ltv;->e()I

    move-result v4

    sub-int v4, v6, v4

    invoke-virtual {v5}, Lvw;->q()I

    move-result v8

    sub-int v8, v4, v8

    invoke-virtual {v5, v8, v4}, Lvw;->J(II)V

    invoke-static {v12, v0, v5, v2}, Lqk;->s(ILzv;Lvw;Z)V

    goto/16 :goto_125

    :cond_1de
    if-eqz v11, :cond_125

    invoke-virtual {v5}, Lvw;->x()Z

    move-result v4

    if-nez v4, :cond_125

    invoke-static {v12, v0, v5, v2}, Lqk;->C(ILzv;Lvw;Z)V

    goto/16 :goto_125

    :cond_1eb
    move/from16 v0, v18

    iput-boolean v0, v1, Lvw;->m:Z

    return-void
.end method

.method public static t(Lop0;)Ljava/lang/String;
    .registers 2

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lxl;->d:Lxl;

    iget-object p0, p0, Lop0;->h:Ljava/lang/String;

    invoke-static {p0}, Lkn0;->j(Ljava/lang/String;)Lxl;

    move-result-object p0

    const-string/jumbo v0, "MD5"

    invoke-virtual {p0, v0}, Lxl;->e(Ljava/lang/String;)Lxl;

    move-result-object p0

    invoke-virtual {p0}, Lxl;->h()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method public static final w(Ljava/lang/String;)Z
    .registers 2

    .prologue
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string/jumbo v0, "GET"

    invoke-virtual {p0, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_17

    const-string/jumbo v0, "HEAD"

    invoke-virtual {p0, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_17

    const/4 p0, 0x1

    return p0

    :cond_17
    const/4 p0, 0x0

    return p0
.end method

.method public static x(Lbq1;)I
    .registers 13

    .prologue
    const-string/jumbo v0, "expected an int but was \""

    :try_start_3
    iget-object v1, p0, Lbq1;->b:Lvk;

    const-wide/16 v2, 0x1

    invoke-virtual {p0, v2, v3}, Lbq1;->F(J)V

    const-wide/16 v4, 0x0

    move-wide v6, v4

    :goto_d
    add-long v8, v6, v2

    invoke-virtual {p0, v8, v9}, Lbq1;->p(J)Z

    move-result v10

    if-eqz v10, :cond_4b

    invoke-virtual {v1, v6, v7}, Lvk;->y(J)B

    move-result v10

    const/16 v11, 0x30

    if-lt v10, v11, :cond_21

    const/16 v11, 0x39

    if-le v10, v11, :cond_2a

    :cond_21
    cmp-long v6, v6, v4

    if-nez v6, :cond_2c

    const/16 v7, 0x2d

    if-eq v10, v7, :cond_2a

    goto :goto_2c

    :cond_2a
    move-wide v6, v8

    goto :goto_d

    :cond_2c
    :goto_2c
    if-eqz v6, :cond_2f

    goto :goto_4b

    :cond_2f
    new-instance p0, Ljava/lang/NumberFormatException;

    const/16 v0, 0x10

    invoke-static {v0}, Lw53;->y(I)V

    invoke-static {v0}, Lw53;->y(I)V

    invoke-static {v10, v0}, Ljava/lang/Integer;->toString(II)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string/jumbo v1, "Expected a digit or \'-\' but was 0x"

    invoke-virtual {v1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Ljava/lang/NumberFormatException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_4b
    :goto_4b
    invoke-virtual {v1}, Lvk;->N()J

    move-result-wide v1

    const-wide v6, 0x7fffffffffffffffL

    invoke-virtual {p0, v6, v7}, Lbq1;->v(J)Ljava/lang/String;

    move-result-object p0

    cmp-long v3, v1, v4

    if-ltz v3, :cond_6b

    const-wide/32 v3, 0x7fffffff

    cmp-long v3, v1, v3

    if-gtz v3, :cond_6b

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v3

    if-gtz v3, :cond_6b

    long-to-int p0, v1

    return p0

    :cond_6b
    new-instance v3, Ljava/io/IOException;

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v4, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 p0, 0x22

    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v3, p0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    throw v3
    :try_end_85
    .catch Ljava/lang/NumberFormatException; {:try_start_3 .. :try_end_85} :catch_85

    :catch_85
    move-exception p0

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lvh0;->k(Ljava/lang/String;)V

    const/4 p0, 0x0

    return p0
.end method

.method public static y(Landroid/view/ViewGroup;F)V
    .registers 3

    .prologue
    invoke-virtual {p0}, Landroid/view/View;->getBackground()Landroid/graphics/drawable/Drawable;

    move-result-object p0

    instance-of v0, p0, Lp71;

    if-eqz v0, :cond_d

    check-cast p0, Lp71;

    invoke-virtual {p0, p1}, Lp71;->r(F)V

    :cond_d
    return-void
.end method

.method public static z(Landroid/view/View;Lp71;)V
    .registers 4

    .prologue
    iget-object v0, p1, Lp71;->b:Ln71;

    iget-object v0, v0, Ln71;->b:Lu80;

    if-eqz v0, :cond_2d

    iget-boolean v0, v0, Lu80;->a:Z

    if-eqz v0, :cond_2d

    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object p0

    const/4 v0, 0x0

    :goto_f
    instance-of v1, p0, Landroid/view/View;

    if-eqz v1, :cond_20

    move-object v1, p0

    check-cast v1, Landroid/view/View;

    invoke-virtual {v1}, Landroid/view/View;->getElevation()F

    move-result v1

    add-float/2addr v0, v1

    invoke-interface {p0}, Landroid/view/ViewParent;->getParent()Landroid/view/ViewParent;

    move-result-object p0

    goto :goto_f

    :cond_20
    iget-object p0, p1, Lp71;->b:Ln71;

    iget v1, p0, Ln71;->l:F

    cmpl-float v1, v1, v0

    if-eqz v1, :cond_2d

    iput v0, p0, Ln71;->l:F

    invoke-virtual {p1}, Lp71;->z()V

    :cond_2d
    return-void
.end method


# virtual methods
.method public abstract B(Ljava/lang/Object;F)V
.end method

.method public d(I)V
    .registers 5

    new-instance v0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v1, Ltu0;

    const/4 v2, 0x3

    invoke-direct {v1, p0, p1, v2}, Ltu0;-><init>(Ljava/lang/Object;II)V

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public hashCode()I
    .registers 2

    .prologue
    iget v0, p0, Lqk;->f:I

    packed-switch v0, :pswitch_data_14

    invoke-super {p0}, Ljava/lang/Object;->hashCode()I

    move-result p0

    return p0

    :pswitch_a  #0x13
    invoke-virtual {p0}, Lqk;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result p0

    return p0

    nop

    :pswitch_data_14
    .packed-switch 0x13
        :pswitch_a  #00000013
    .end packed-switch
.end method

.method public abstract q(Ljava/lang/Object;)F
.end method

.method public toString()Ljava/lang/String;
    .registers 2

    .prologue
    iget v0, p0, Lqk;->f:I

    packed-switch v0, :pswitch_data_1a

    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :pswitch_a  #0x13
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    invoke-static {p0}, Lxr1;->a(Ljava/lang/Class;)Llq;

    move-result-object p0

    invoke-virtual {p0}, Llq;->c()Ljava/lang/String;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-object p0

    :pswitch_data_1a
    .packed-switch 0x13
        :pswitch_a  #00000013
    .end packed-switch
.end method

.method public abstract u(I)V
.end method

.method public abstract v(Landroid/graphics/Typeface;)V
.end method
