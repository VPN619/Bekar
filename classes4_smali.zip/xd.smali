.class public final Lxd;
.super Lqq1;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final c:Landroid/content/pm/PackageManager;

.field public final d:Ljava/util/ArrayList;

.field public final e:Landroid/content/SharedPreferences;


# direct methods
.method public constructor <init>(Landroid/content/pm/PackageManager;Ljava/util/ArrayList;Landroid/content/SharedPreferences;)V
    .registers 6

    invoke-direct {p0}, Lqq1;-><init>()V

    const/16 v0, 0x9e8

    iput-object p1, p0, Lxd;->c:Landroid/content/pm/PackageManager;

    const/16 v0, 0x842

    iput-object p2, p0, Lxd;->d:Ljava/util/ArrayList;

    const/16 v0, 0x1042

    iput-object p3, p0, Lxd;->e:Landroid/content/SharedPreferences;

    return-void
.end method


# virtual methods
.method public final a()I
    .registers 3

    const/16 v0, 0x124c

    iget-object p0, p0, Lxd;->d:Ljava/util/ArrayList;

    nop

    const/16 v0, 0xac

    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result p0

    return p0
.end method

.method public final e(Lpr1;I)V
    .registers 9

    check-cast p1, Lwd;

    const/16 v0, 0xcc5

    iget-object v2, p1, Lwd;->u:Landroid/widget/ImageView;

    nop

    const/16 v0, 0x124c

    iget-object v3, p0, Lxd;->d:Ljava/util/ArrayList;

    nop

    const/16 v0, 0x43

    invoke-virtual {v3, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lsd;

    const/16 v0, 0x1dc

    iget-object v4, v4, Lsd;->a:Landroid/content/pm/ApplicationInfo;

    nop

    const/16 v0, 0x6b6

    iget-object v5, p0, Lxd;->c:Landroid/content/pm/PackageManager;

    nop

    const/16 v0, 0x81e

    invoke-virtual {v4, v5}, Landroid/content/pm/PackageItemInfo;->loadIcon(Landroid/content/pm/PackageManager;)Landroid/graphics/drawable/Drawable;

    move-result-object v4

    const/16 v0, 0xcae

    invoke-virtual {v2, v4}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    const/16 v0, 0xa1c

    iget-object v2, p1, Lwd;->v:Landroid/widget/TextView;

    nop

    const/16 v0, 0x43

    invoke-virtual {v3, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lsd;

    const/16 v0, 0x1dc

    iget-object v4, v4, Lsd;->a:Landroid/content/pm/ApplicationInfo;

    nop

    const/16 v0, 0x375

    invoke-virtual {v4, v5}, Landroid/content/pm/PackageItemInfo;->loadLabel(Landroid/content/pm/PackageManager;)Ljava/lang/CharSequence;

    move-result-object v4

    const/16 v0, 0x8a

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v0, 0x777

    iget-object v2, p1, Lwd;->w:Landroid/widget/TextView;

    nop

    const/16 v0, 0x43

    invoke-virtual {v3, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lsd;

    const/16 v0, 0x1dc

    iget-object v4, v4, Lsd;->a:Landroid/content/pm/ApplicationInfo;

    nop

    const/16 v0, 0x72b

    iget-object v4, v4, Landroid/content/pm/ApplicationInfo;->packageName:Ljava/lang/String;

    nop

    const/16 v0, 0x8a

    invoke-virtual {v2, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v0, 0xb0c

    iget-object v2, p1, Lwd;->x:Landroid/widget/CheckBox;

    nop

    const/4 v4, 0x0

    const/16 v0, 0x14a

    invoke-virtual {v2, v4}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    const/16 v0, 0x43

    invoke-virtual {v3, p2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Lsd;

    const/16 v0, 0x293

    iget-boolean v3, v3, Lsd;->b:Z

    nop

    const/16 v0, 0x7e

    invoke-virtual {v2, v3}, Landroid/widget/CompoundButton;->setChecked(Z)V

    const/16 v0, 0x663

    new-instance v3, Lud;

    nop

    const/16 v0, 0xfdc

    invoke-direct {v3, p0, p2, p1}, Lud;-><init>(Lxd;ILwd;)V

    const/16 v0, 0x14a

    invoke-virtual {v2, v3}, Landroid/widget/CompoundButton;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    const/16 v0, 0x5ca

    iget-object p0, p1, Lpr1;->a:Landroid/view/View;

    nop

    const/16 v0, 0xa20

    new-instance p2, Lvd;

    nop

    const/4 v2, 0x0

    const/16 v0, 0xd0d

    invoke-direct {p2, v2, p1}, Lvd;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x5f

    invoke-virtual {p0, p2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method

.method public final f(Landroid/view/ViewGroup;I)Lpr1;
    .registers 6

    const/16 v0, 0xee7

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p0

    const/16 v0, 0x8f9

    invoke-static {p0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object p0

    const p2, 0x7f0c001e

    const/4 v2, 0x0

    const/16 v0, 0x107b

    invoke-virtual {p0, p2, p1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p0

    const/16 v0, 0x1068

    new-instance p1, Lwd;

    nop

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x1069

    invoke-direct {p1, p0}, Lwd;-><init>(Landroid/view/View;)V

    check-cast p1, Lpr1;

    return-object p1
.end method
