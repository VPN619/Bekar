.class public final Lho0;
.super Landroid/os/CountDownTimer;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Lcom/tlsvpn/tlstunnel/ui/Home;


# direct methods
.method public constructor <init>(Lcom/tlsvpn/tlstunnel/ui/Home;J)V
    .registers 8

    const-wide/16 v2, 0x3e8

    invoke-direct {p0, p2, p3, v2, v3}, Landroid/os/CountDownTimer;-><init>(JJ)V

    const/16 v0, 0x9eb

    iput-object p1, p0, Lho0;->a:Lcom/tlsvpn/tlstunnel/ui/Home;

    return-void
.end method


# virtual methods
.method public final onFinish()V
    .registers 5

    const/16 v0, 0x983

    iget-object p0, p0, Lho0;->a:Lcom/tlsvpn/tlstunnel/ui/Home;

    nop

    const-wide/16 v2, 0x0

    const/16 v0, 0x677

    invoke-virtual {p0, v2, v3}, Lcom/tlsvpn/tlstunnel/ui/Home;->h(J)V

    return-void
.end method

.method public final onTick(J)V
    .registers 6

    const/16 v0, 0x983

    iget-object p0, p0, Lho0;->a:Lcom/tlsvpn/tlstunnel/ui/Home;

    nop

    const/16 v0, 0x677

    invoke-virtual {p0, p1, p2}, Lcom/tlsvpn/tlstunnel/ui/Home;->h(J)V

    return-void
.end method
