.class public final synthetic Lfc0;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lkc0;


# direct methods
.method public synthetic constructor <init>(Lkc0;I)V
    .registers 5

    iput p2, p0, Lfc0;->a:I

    iput-object p1, p0, Lfc0;->b:Lkc0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 5

    .prologue
    const/16 v0, 0xe0d

    iget p1, p0, Lfc0;->a:I

    nop

    const/4 v2, 0x0

    const/16 v0, 0xa9b

    iget-object p0, p0, Lfc0;->b:Lkc0;

    nop

    packed-switch p1, :pswitch_data_1c

    const/4 p1, 0x1

    const/16 v0, 0x347

    invoke-virtual {p0, p1, v2}, Lkc0;->c(ZZ)V

    return-void

    :pswitch_15  #0x0
    const/16 v0, 0x347

    invoke-virtual {p0, v2, v2}, Lkc0;->c(ZZ)V

    return-void

    nop

    :pswitch_data_1c
    .packed-switch 0x0
        :pswitch_15  #00000000
    .end packed-switch
.end method
