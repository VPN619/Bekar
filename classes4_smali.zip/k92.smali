.class public final synthetic Lk92;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings;


# direct methods
.method public synthetic constructor <init>(Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings;I)V
    .registers 5

    iput p2, p0, Lk92;->a:I

    iput-object p1, p0, Lk92;->b:Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 7

    .prologue
    const/16 v0, 0x1219

    iget p1, p0, Lk92;->a:I

    nop

    const/16 v0, 0xf3e

    iget-object p0, p0, Lk92;->b:Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings;

    nop

    packed-switch p1, :pswitch_data_90

    const/16 v0, 0xfb

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object p0

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p0, Lcom/tlsvpn/tlstunnel/MainActivity;

    const/16 v0, 0x1f9

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/MainActivity;->h()Lcom/google/android/material/bottomnavigation/BottomNavigationView;

    move-result-object p0

    const p1, 0x7f090130

    const/16 v0, 0x29c

    invoke-virtual {p0, p1}, Lyd1;->setSelectedItemId(I)V

    return-void

    :pswitch_28  #0x0
    const/16 v0, 0xbb1

    new-instance p1, Lg8;

    nop

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v2

    const/16 v0, 0x100b

    invoke-direct {p1, v2}, Lg8;-><init>(Landroid/content/Context;)V

    const/16 v0, 0x11e6

    iget-object v2, p1, Lg8;->c:Ljava/lang/Object;

    nop

    check-cast v2, Lc8;

    const/16 v0, 0x505

    iget-object v3, v2, Lc8;->a:Landroid/view/ContextThemeWrapper;

    nop

    const v4, 0x7f13022a

    const/16 v0, 0x492

    invoke-virtual {v3, v4}, Landroid/content/Context;->getText(I)Ljava/lang/CharSequence;

    move-result-object v3

    const/16 v0, 0x7c3

    iput-object v3, v2, Lc8;->f:Ljava/lang/CharSequence;

    const/16 v0, 0xfe3

    new-instance v3, Ld51;

    nop

    const/4 v4, 0x3

    const/16 v0, 0xb08

    invoke-direct {v3, v4, p0}, Ld51;-><init>(ILjava/lang/Object;)V

    const p0, 0x7f130228

    const/16 v0, 0xf53

    invoke-virtual {p1, p0, v3}, Lg8;->j(ILandroid/content/DialogInterface$OnClickListener;)V

    const/16 v0, 0x120f

    new-instance p0, Lic0;

    nop

    const/16 v0, 0x1192

    invoke-direct {p0, v4}, Lic0;-><init>(I)V

    const v3, 0x7f130064

    const/16 v0, 0x505

    iget-object v4, v2, Lc8;->a:Landroid/view/ContextThemeWrapper;

    nop

    const/16 v0, 0x492

    invoke-virtual {v4, v3}, Landroid/content/Context;->getText(I)Ljava/lang/CharSequence;

    move-result-object v3

    const/16 v0, 0xe5d

    iput-object v3, v2, Lc8;->i:Ljava/lang/CharSequence;

    const/16 v0, 0xe2e

    iput-object p0, v2, Lc8;->j:Landroid/content/DialogInterface$OnClickListener;

    const/16 v0, 0x670

    invoke-virtual {p1}, Lg8;->b()Lh8;

    move-result-object p0

    const/16 v0, 0x9a5

    invoke-virtual {p0}, Landroid/app/Dialog;->show()V

    return-void

    :pswitch_data_90
    .packed-switch 0x0
        :pswitch_28  #00000000
    .end packed-switch
.end method
