.class public final Ljc0;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/text/TextWatcher;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lkc0;


# direct methods
.method public synthetic constructor <init>(Lkc0;I)V
    .registers 5

    iput p2, p0, Ljc0;->a:I

    iput-object p1, p0, Ljc0;->b:Lkc0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final a(IIILjava/lang/CharSequence;)V
    .registers 7

    return-void
.end method

.method private final b(IIILjava/lang/CharSequence;)V
    .registers 7

    return-void
.end method

.method private final c(IIILjava/lang/CharSequence;)V
    .registers 7

    return-void
.end method

.method private final d(IIILjava/lang/CharSequence;)V
    .registers 7

    return-void
.end method

.method private final e(IIILjava/lang/CharSequence;)V
    .registers 7

    return-void
.end method

.method private final f(IIILjava/lang/CharSequence;)V
    .registers 7

    return-void
.end method

.method private final g(IIILjava/lang/CharSequence;)V
    .registers 7

    return-void
.end method

.method private final h(IIILjava/lang/CharSequence;)V
    .registers 7

    return-void
.end method

.method private final i(IIILjava/lang/CharSequence;)V
    .registers 7

    return-void
.end method

.method private final j(IIILjava/lang/CharSequence;)V
    .registers 7

    return-void
.end method

.method private final k(IIILjava/lang/CharSequence;)V
    .registers 7

    return-void
.end method

.method private final l(IIILjava/lang/CharSequence;)V
    .registers 7

    return-void
.end method


# virtual methods
.method public final afterTextChanged(Landroid/text/Editable;)V
    .registers 7

    .prologue
    const/16 v0, 0x1082

    iget v2, p0, Ljc0;->a:I

    nop

    const/4 v3, 0x0

    const/16 v0, 0xffe

    iget-object p0, p0, Ljc0;->b:Lkc0;

    nop

    const/4 v4, 0x0

    packed-switch v2, :pswitch_data_108

    const/16 v0, 0x9d1

    iget-object p0, p0, Lkc0;->Q:Landroid/widget/TextView;

    nop

    if-eqz p0, :cond_42

    const/16 v0, 0x1a8

    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const-string/jumbo v2, "\n"

    const-string/jumbo v3, "<br/>"

    const/16 v0, 0x1a

    invoke-static {p1, v2, v3, v4}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p1

    const-string/jumbo v2, "\\"

    const-string/jumbo v3, ""

    const/16 v0, 0x1a

    invoke-static {p1, v2, v3, v4}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p1

    const/16 v2, 0x3f

    const/16 v0, 0x9b4

    invoke-static {p1, v2}, Landroid/text/Html;->fromHtml(Ljava/lang/String;I)Landroid/text/Spanned;

    move-result-object p1

    const/16 v0, 0x8a

    invoke-virtual {p0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    :cond_42
    const-string/jumbo p0, "txtMsgPreview"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :pswitch_4a  #0x4
    const/16 v0, 0x39a

    iget-object p1, p0, Lkc0;->K:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    const-string/jumbo v2, "sshpass_l"

    if-eqz p1, :cond_6b

    const/16 v0, 0x6e

    invoke-virtual {p1, v3}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    const/16 v0, 0x39a

    iget-object p0, p0, Lkc0;->K:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz p0, :cond_66

    const/16 v0, 0xdd

    invoke-virtual {p0, v4}, Lcom/google/android/material/textfield/TextInputLayout;->setErrorEnabled(Z)V

    return-void

    :cond_66
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_6b
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :pswitch_70  #0x3
    const/16 v0, 0x2d8

    iget-object p1, p0, Lkc0;->I:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    const-string/jumbo v2, "sshuser_l"

    if-eqz p1, :cond_91

    const/16 v0, 0x6e

    invoke-virtual {p1, v3}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    const/16 v0, 0x2d8

    iget-object p0, p0, Lkc0;->I:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz p0, :cond_8c

    const/16 v0, 0xdd

    invoke-virtual {p0, v4}, Lcom/google/android/material/textfield/TextInputLayout;->setErrorEnabled(Z)V

    return-void

    :cond_8c
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_91
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :pswitch_96  #0x2
    const/16 v0, 0x4c4

    iget-object p1, p0, Lkc0;->E:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    const-string/jumbo v2, "sshport_l"

    if-eqz p1, :cond_b7

    const/16 v0, 0x6e

    invoke-virtual {p1, v3}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    const/16 v0, 0x4c4

    iget-object p0, p0, Lkc0;->E:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz p0, :cond_b2

    const/16 v0, 0xdd

    invoke-virtual {p0, v4}, Lcom/google/android/material/textfield/TextInputLayout;->setErrorEnabled(Z)V

    return-void

    :cond_b2
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_b7
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :pswitch_bc  #0x1
    const/16 v0, 0x3e5

    iget-object p1, p0, Lkc0;->C:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    const-string/jumbo v2, "sshhost_l"

    if-eqz p1, :cond_dd

    const/16 v0, 0x6e

    invoke-virtual {p1, v3}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    const/16 v0, 0x3e5

    iget-object p0, p0, Lkc0;->C:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz p0, :cond_d8

    const/16 v0, 0xdd

    invoke-virtual {p0, v4}, Lcom/google/android/material/textfield/TextInputLayout;->setErrorEnabled(Z)V

    return-void

    :cond_d8
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_dd
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :pswitch_e2  #0x0
    const/16 v0, 0x124

    iget-object p1, p0, Lkc0;->u:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    const-string/jumbo v2, "cfgname_l"

    if-eqz p1, :cond_103

    const/16 v0, 0x6e

    invoke-virtual {p1, v3}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    const/16 v0, 0x124

    iget-object p0, p0, Lkc0;->u:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz p0, :cond_fe

    const/16 v0, 0xdd

    invoke-virtual {p0, v4}, Lcom/google/android/material/textfield/TextInputLayout;->setErrorEnabled(Z)V

    return-void

    :cond_fe
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_103
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :pswitch_data_108
    .packed-switch 0x0
        :pswitch_e2  #00000000
        :pswitch_bc  #00000001
        :pswitch_96  #00000002
        :pswitch_70  #00000003
        :pswitch_4a  #00000004
    .end packed-switch
.end method

.method public final beforeTextChanged(Ljava/lang/CharSequence;III)V
    .registers 7

    const/4 v1, 0x0

    const/16 v0, 0x1082

    iget p0, p0, Ljc0;->a:I

    nop

    return-void
.end method

.method public final onTextChanged(Ljava/lang/CharSequence;III)V
    .registers 7

    const/4 v1, 0x0

    const/16 v0, 0x1082

    iget p0, p0, Ljc0;->a:I

    nop

    return-void
.end method
