.class public final synthetic Lqo1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lso1;


# direct methods
.method public synthetic constructor <init>(Lso1;I)V
    .registers 5

    iput p2, p0, Lqo1;->a:I

    iput-object p1, p0, Lqo1;->b:Lso1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 4

    .prologue
    const/16 v0, 0xe1d

    iget p1, p0, Lqo1;->a:I

    nop

    const/16 v0, 0xbca

    iget-object p0, p0, Lqo1;->b:Lso1;

    nop

    packed-switch p1, :pswitch_data_1a

    const/16 v0, 0x453

    invoke-virtual {p0}, Lso1;->c()V

    return-void

    :pswitch_13  #0x0
    const/16 v0, 0x453

    invoke-virtual {p0}, Lso1;->c()V

    return-void

    nop

    :pswitch_data_1a
    .packed-switch 0x0
        :pswitch_13  #00000000
    .end packed-switch
.end method
