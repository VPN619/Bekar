.class public final Lro1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/text/TextWatcher;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lvb;


# direct methods
.method public synthetic constructor <init>(Lvb;I)V
    .registers 5

    iput p2, p0, Lro1;->a:I

    iput-object p1, p0, Lro1;->b:Lvb;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final a(IIILjava/lang/CharSequence;)V
    .registers 7

    return-void
.end method

.method private final b(IIILjava/lang/CharSequence;)V
    .registers 7

    return-void
.end method

.method private final c(IIILjava/lang/CharSequence;)V
    .registers 7

    return-void
.end method

.method private final d(IIILjava/lang/CharSequence;)V
    .registers 7

    return-void
.end method

.method private final e(IIILjava/lang/CharSequence;)V
    .registers 7

    return-void
.end method

.method private final f(IIILjava/lang/CharSequence;)V
    .registers 7

    return-void
.end method


# virtual methods
.method public final afterTextChanged(Landroid/text/Editable;)V
    .registers 7

    .prologue
    const/16 v0, 0x11db

    iget p1, p0, Lro1;->a:I

    nop

    const/4 v2, 0x0

    const/16 v0, 0xb74

    iget-object p0, p0, Lro1;->b:Lvb;

    nop

    const/4 v3, 0x0

    packed-switch p1, :pswitch_data_88

    check-cast p0, Lsu;

    const/16 v0, 0x36e

    iget-object p1, p0, Lsu;->w:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    const-string/jumbo v4, "customport_l"

    if-eqz p1, :cond_32

    const/16 v0, 0x6e

    invoke-virtual {p1, v3}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    const/16 v0, 0x36e

    iget-object p0, p0, Lsu;->w:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz p0, :cond_2d

    const/16 v0, 0xdd

    invoke-virtual {p0, v2}, Lcom/google/android/material/textfield/TextInputLayout;->setErrorEnabled(Z)V

    return-void

    :cond_2d
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_32
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :pswitch_37  #0x1
    check-cast p0, Lso1;

    const/16 v0, 0x45a

    iget-object p1, p0, Lso1;->w:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    const-string/jumbo v4, "prxport_l"

    if-eqz p1, :cond_5a

    const/16 v0, 0x6e

    invoke-virtual {p1, v3}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    const/16 v0, 0x45a

    iget-object p0, p0, Lso1;->w:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz p0, :cond_55

    const/16 v0, 0xdd

    invoke-virtual {p0, v2}, Lcom/google/android/material/textfield/TextInputLayout;->setErrorEnabled(Z)V

    return-void

    :cond_55
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_5a
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :pswitch_5f  #0x0
    check-cast p0, Lso1;

    const/16 v0, 0x2e1

    iget-object p1, p0, Lso1;->u:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    const-string/jumbo v4, "prxhost_l"

    if-eqz p1, :cond_82

    const/16 v0, 0x6e

    invoke-virtual {p1, v3}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    const/16 v0, 0x2e1

    iget-object p0, p0, Lso1;->u:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz p0, :cond_7d

    const/16 v0, 0xdd

    invoke-virtual {p0, v2}, Lcom/google/android/material/textfield/TextInputLayout;->setErrorEnabled(Z)V

    return-void

    :cond_7d
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_82
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    nop

    :pswitch_data_88
    .packed-switch 0x0
        :pswitch_5f  #00000000
        :pswitch_37  #00000001
    .end packed-switch
.end method

.method public final beforeTextChanged(Ljava/lang/CharSequence;III)V
    .registers 7

    const/4 v1, 0x0

    const/16 v0, 0x11db

    iget p0, p0, Lro1;->a:I

    nop

    return-void
.end method

.method public final onTextChanged(Ljava/lang/CharSequence;III)V
    .registers 7

    const/4 v1, 0x0

    const/16 v0, 0x11db

    iget p0, p0, Lro1;->a:I

    nop

    return-void
.end method
