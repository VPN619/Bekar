.class public final Llt1;
.super Ljava/lang/Thread;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final synthetic t:I


# instance fields
.field public final a:Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;

.field public final b:Landroid/content/SharedPreferences;

.field public final c:I

.field public final d:I

.field public final e:Z

.field public final f:Lou;

.field public final g:Ljava/lang/String;

.field public final h:Z

.field public final i:Ljava/net/Socket;

.field public final j:Ljava/net/Socket;

.field public k:Z

.field public l:J

.field public m:I

.field public n:Landroid/os/ParcelFileDescriptor;

.field public o:Landroid/os/ParcelFileDescriptor;

.field public p:Ljava/net/ServerSocket;

.field public q:Ljava/net/Socket;

.field public r:Lx52;

.field public final s:Lsx;


# direct methods
.method public constructor <init>(Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;Landroid/content/SharedPreferences;IIZLou;Ljava/lang/String;Z)V
    .registers 11

    invoke-direct {p0}, Ljava/lang/Thread;-><init>()V

    const/16 v0, 0xfda

    iput-object p1, p0, Llt1;->a:Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;

    const/16 v0, 0x1249

    iput-object p2, p0, Llt1;->b:Landroid/content/SharedPreferences;

    const/16 v0, 0xbb8

    iput p3, p0, Llt1;->c:I

    const/16 v0, 0xd41

    iput p4, p0, Llt1;->d:I

    const/16 v0, 0xb6a

    iput-boolean p5, p0, Llt1;->e:Z

    const/16 v0, 0x5ac

    iput-object p6, p0, Llt1;->f:Lou;

    const/16 v0, 0xd8c

    iput-object p7, p0, Llt1;->g:Ljava/lang/String;

    const/16 v0, 0xd92

    iput-boolean p8, p0, Llt1;->h:Z

    const/16 v0, 0x516

    new-instance p1, Ljava/net/Socket;

    nop

    const/16 v0, 0x447

    invoke-direct {p1}, Ljava/net/Socket;-><init>()V

    const/16 v0, 0x1017

    iput-object p1, p0, Llt1;->i:Ljava/net/Socket;

    const/16 v0, 0x516

    new-instance p1, Ljava/net/Socket;

    nop

    const/16 v0, 0x447

    invoke-direct {p1}, Ljava/net/Socket;-><init>()V

    const/16 v0, 0xc85

    iput-object p1, p0, Llt1;->j:Ljava/net/Socket;

    const/16 v0, 0x113c

    invoke-static {}, Lq23;->e()Lr72;

    move-result-object p1

    const/16 v0, 0x132

    sget-object p2, Lh50;->a:Li20;

    nop

    const/16 v0, 0x126

    sget-object p2, Lx10;->c:Lx10;

    nop

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x76b

    invoke-static {p2, p1}, Lns2;->x(Ljy;Lly;)Lly;

    move-result-object p1

    const/16 v0, 0xf43

    invoke-static {p1}, Lw53;->a(Lly;)Lsx;

    move-result-object p1

    const/16 v0, 0x7c5

    iput-object p1, p0, Llt1;->s:Lsx;

    return-void
.end method


# virtual methods
.method public final a(Lwx;)Ljava/lang/Object;
    .registers 14

    .prologue
    instance-of v2, p1, Lht1;

    if-eqz v2, :cond_18

    move-object v2, p1

    check-cast v2, Lht1;

    const/16 v0, 0x3e9

    iget v3, v2, Lht1;->v:I

    nop

    const/high16 v4, -0x80000000

    and-int v5, v3, v4

    if-eqz v5, :cond_18

    sub-int/2addr v3, v4

    const/16 v0, 0x96

    iput v3, v2, Lht1;->v:I

    goto :goto_22

    :cond_18
    const/16 v0, 0x7b1

    new-instance v2, Lht1;

    nop

    const/16 v0, 0x675

    invoke-direct {v2, p0, p1}, Lht1;-><init>(Llt1;Lwx;)V

    :goto_22
    const/16 v0, 0x97d

    iget-object p1, v2, Lht1;->t:Ljava/lang/Object;

    nop

    const/16 v0, 0x3e9

    iget v3, v2, Lht1;->v:I

    nop

    const/4 v4, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x2

    const/16 v0, 0x21

    sget-object v8, Lrg2;->a:Lrg2;

    nop

    const/4 v9, 0x1

    const/4 v10, 0x0

    const/16 v0, 0x15

    sget-object v11, Lwy;->a:Lwy;

    nop

    if-eqz v3, :cond_6f

    if-eq v3, v9, :cond_6a

    if-eq v3, v7, :cond_64

    if-eq v3, v6, :cond_5e

    if-eq v3, v5, :cond_58

    if-ne v3, v4, :cond_4f

    const/4 v0, 0x6

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    check-cast v8, Ljava/lang/Object;

    return-object v8

    :cond_4f
    const-string/jumbo p0, "call to \'resume\' before \'invoke\' with coroutine"

    const/16 v0, 0x13

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v10

    :cond_58
    :try_start_58
    const/4 v0, 0x6

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_5c
    .catch Ljava/lang/Exception; {:try_start_58 .. :try_end_5c} :catch_146

    goto/16 :goto_146

    :cond_5e
    :try_start_5e
    const/4 v0, 0x6

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_62
    .catch Ljava/lang/Exception; {:try_start_5e .. :try_end_62} :catch_11d

    goto/16 :goto_11d

    :cond_64
    :try_start_64
    const/4 v0, 0x6

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_68
    .catch Ljava/lang/Exception; {:try_start_64 .. :try_end_68} :catch_f5

    goto/16 :goto_f5

    :cond_6a
    :try_start_6a
    const/4 v0, 0x6

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V
    :try_end_6e
    .catch Ljava/lang/Exception; {:try_start_6a .. :try_end_6e} :catch_d3

    goto :goto_d3

    :cond_6f
    const/4 v0, 0x6

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v0, 0x72

    iget-boolean p1, p0, Llt1;->k:Z

    nop

    if-eqz p1, :cond_7c

    goto/16 :goto_17a

    :cond_7c
    const/16 v0, 0xfbb

    iput-boolean v9, p0, Llt1;->k:Z

    const/16 v0, 0x5a9

    iget-object p1, p0, Llt1;->s:Lsx;

    nop

    const/16 v0, 0x1108

    invoke-static {p1}, Lw53;->w(Lvy;)V

    const/16 v0, 0x5a

    sget-object p1, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->a:Lcom/tlsvpn/tlstunnel/utils/SocketOps;

    nop

    const/16 v0, 0x124f

    iget v3, p0, Llt1;->m:I

    nop

    const/16 v0, 0x488

    invoke-virtual {p1, v3}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->F(I)V

    const/16 v0, 0x1e5

    iget-object p1, p0, Llt1;->n:Landroid/os/ParcelFileDescriptor;

    nop

    if-eqz p1, :cond_a5

    :try_start_a0
    const/16 v0, 0x18b

    invoke-virtual {p1}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_a5
    .catch Ljava/lang/Exception; {:try_start_a0 .. :try_end_a5} :catch_a5

    :catch_a5
    :cond_a5
    const/16 v0, 0xc40

    iget-object p1, p0, Llt1;->o:Landroid/os/ParcelFileDescriptor;

    nop

    if-eqz p1, :cond_b1

    :try_start_ac
    const/16 v0, 0x18b

    invoke-virtual {p1}, Landroid/os/ParcelFileDescriptor;->close()V
    :try_end_b1
    .catch Ljava/lang/Exception; {:try_start_ac .. :try_end_b1} :catch_b1

    :catch_b1
    :cond_b1
    :try_start_b1
    const/16 v0, 0x132

    sget-object p1, Lh50;->a:Li20;

    nop

    const/16 v0, 0x126

    sget-object p1, Lx10;->c:Lx10;

    nop

    const/16 v0, 0x150

    new-instance v3, Lgt1;

    nop

    const/16 v0, 0x138

    invoke-direct {v3, p0, v10, v9}, Lgt1;-><init>(Llt1;Lvx;I)V

    const/16 v0, 0x96

    iput v9, v2, Lht1;->v:I

    const/16 v0, 0x121

    invoke-static {p1, v3, v2}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object p1
    :try_end_cf
    .catch Ljava/lang/Exception; {:try_start_b1 .. :try_end_cf} :catch_d3

    if-ne p1, v11, :cond_d3

    goto/16 :goto_16d

    :catch_d3
    :cond_d3
    :goto_d3
    :try_start_d3
    const/16 v0, 0x132

    sget-object p1, Lh50;->a:Li20;

    nop

    const/16 v0, 0x126

    sget-object p1, Lx10;->c:Lx10;

    nop

    const/16 v0, 0x150

    new-instance v3, Lgt1;

    nop

    const/16 v0, 0x138

    invoke-direct {v3, p0, v10, v7}, Lgt1;-><init>(Llt1;Lvx;I)V

    const/16 v0, 0x96

    iput v7, v2, Lht1;->v:I

    const/16 v0, 0x121

    invoke-static {p1, v3, v2}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object p1
    :try_end_f1
    .catch Ljava/lang/Exception; {:try_start_d3 .. :try_end_f1} :catch_f5

    if-ne p1, v11, :cond_f5

    goto/16 :goto_16d

    :catch_f5
    :cond_f5
    :goto_f5
    const/16 v0, 0x4db

    iget-object p1, p0, Llt1;->q:Ljava/net/Socket;

    nop

    if-eqz p1, :cond_11d

    :try_start_fc
    const/16 v0, 0x132

    sget-object p1, Lh50;->a:Li20;

    nop

    const/16 v0, 0x126

    sget-object p1, Lx10;->c:Lx10;

    nop

    const/16 v0, 0x150

    new-instance v3, Lgt1;

    nop

    const/16 v0, 0x138

    invoke-direct {v3, p0, v10, v6}, Lgt1;-><init>(Llt1;Lvx;I)V

    const/16 v0, 0x96

    iput v6, v2, Lht1;->v:I

    const/16 v0, 0x121

    invoke-static {p1, v3, v2}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object p1
    :try_end_11a
    .catch Ljava/lang/Exception; {:try_start_fc .. :try_end_11a} :catch_11d

    if-ne p1, v11, :cond_11d

    goto :goto_16d

    :catch_11d
    :cond_11d
    :goto_11d
    const/16 v0, 0x118a

    iget-object p1, p0, Llt1;->p:Ljava/net/ServerSocket;

    nop

    if-eqz p1, :cond_146

    :try_start_124
    const/16 v0, 0x132

    sget-object p1, Lh50;->a:Li20;

    nop

    const/16 v0, 0x126

    sget-object p1, Lx10;->c:Lx10;

    nop

    const/16 v0, 0x150

    new-instance v3, Lgt1;

    nop

    const/4 v6, 0x0

    const/16 v0, 0x138

    invoke-direct {v3, p0, v10, v6}, Lgt1;-><init>(Llt1;Lvx;I)V

    const/16 v0, 0x96

    iput v5, v2, Lht1;->v:I

    const/16 v0, 0x121

    invoke-static {p1, v3, v2}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object p1
    :try_end_143
    .catch Ljava/lang/Exception; {:try_start_124 .. :try_end_143} :catch_146

    if-ne p1, v11, :cond_146

    goto :goto_16d

    :catch_146
    :cond_146
    :goto_146
    const/16 v0, 0x28a

    iget-object p1, p0, Llt1;->r:Lx52;

    nop

    if-eqz p1, :cond_17a

    const-string/jumbo v3, "lServerJob"

    if-eqz p1, :cond_175

    const/16 v0, 0x123a

    invoke-virtual {p1}, Lnv0;->isActive()Z

    move-result p1

    if-eqz p1, :cond_17a

    const/16 v0, 0x28a

    iget-object p0, p0, Llt1;->r:Lx52;

    nop

    if-eqz p0, :cond_170

    const/16 v0, 0x96

    iput v4, v2, Lht1;->v:I

    const/16 v0, 0xf71

    invoke-virtual {p0, v2}, Lnv0;->H(Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v11, :cond_17a

    :goto_16d
    check-cast v11, Ljava/lang/Object;

    return-object v11

    :cond_170
    const/4 v0, 0x5

    invoke-static {v3}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_175
    const/4 v0, 0x5

    invoke-static {v3}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10

    :cond_17a
    :goto_17a
    check-cast v8, Ljava/lang/Object;

    return-object v8
.end method

.method public final b(Ljava/lang/String;)V
    .registers 25

    .prologue
    move-object/from16 v4, p0

    move-object/from16 v5, p1

    const/16 v1, 0x8db

    iget-object v6, v4, Llt1;->f:Lou;

    nop

    const/16 v1, 0x3b

    iget-object v3, v6, Lou;->i:Ljava/lang/String;

    nop

    const/16 v1, 0x47

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v7, 0x2

    add-int/2addr v3, v7

    const/16 v1, 0x11f

    iget v8, v6, Lou;->d:I

    nop

    const/16 v1, 0x262

    invoke-static {v8}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v8

    const/16 v1, 0x47

    invoke-virtual {v8}, Ljava/lang/String;->length()I

    move-result v8

    add-int/2addr v8, v3

    const/4 v9, 0x0

    const/16 v1, 0x21c

    invoke-static {v5, v9, v8}, Lc72;->z0(Ljava/lang/CharSequence;II)Ljava/lang/CharSequence;

    move-result-object v3

    const/16 v1, 0xcb

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    const-string/jumbo v8, " "

    const-string/jumbo v10, ""

    const/16 v1, 0x1a

    invoke-static {v3, v8, v10, v9}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v3

    const-string/jumbo v8, "\t"

    const/16 v1, 0x1a

    invoke-static {v3, v8, v10, v9}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v3

    const-string/jumbo v8, "\n"

    const/16 v1, 0x1a

    invoke-static {v3, v8, v10, v9}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object v3

    const-string/jumbo v8, "SERVERLIST:"

    const/16 v1, 0x92

    invoke-static {v3, v8, v9}, Lk72;->k0(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v8

    if-eqz v8, :cond_4d4

    const/4 v8, 0x1

    new-array v11, v8, [C

    const/16 v12, 0x3a

    aput-char v12, v11, v9

    const/16 v1, 0x31

    invoke-static {v3, v11}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v11

    const/16 v1, 0x17d

    invoke-interface {v11}, Ljava/util/List;->size()I

    move-result v11

    const/4 v13, 0x3

    if-ge v11, v13, :cond_76

    goto/16 :goto_4d4

    :cond_76
    new-array v11, v8, [C

    aput-char v12, v11, v9

    const/16 v1, 0x31

    invoke-static {v3, v11}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v11

    const/16 v1, 0x24

    invoke-interface {v11, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/CharSequence;

    new-array v14, v8, [C

    const/16 v15, 0x7c

    aput-char v15, v14, v9

    const/16 v1, 0x31

    invoke-static {v11, v14}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v11

    const/16 v1, 0x24

    invoke-interface {v11, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    const/16 v1, 0x7c

    invoke-static {v11}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v14

    if-nez v14, :cond_4d4

    const-string/jumbo v14, ","

    check-cast v14, Ljava/lang/String;

    filled-new-array {v14}, [Ljava/lang/String;

    move-result-object v14

    const/4 v15, 0x6

    const/16 v1, 0x89

    invoke-static {v11, v14, v15}, Lc72;->E0(Ljava/lang/CharSequence;[Ljava/lang/String;I)Ljava/util/List;

    move-result-object v14

    const/16 v1, 0x17d

    invoke-interface {v14}, Ljava/util/List;->size()I

    move-result v14

    if-ge v14, v7, :cond_be

    goto/16 :goto_4d4

    :cond_be
    const/4 v1, -0x3

    new-instance v14, Ljava/lang/StringBuilder;

    nop

    const/4 v1, -0x4

    invoke-direct {v14}, Ljava/lang/StringBuilder;-><init>()V

    const v15, 0x7f130039

    const/16 v1, 0xa26

    iget-object v1, v4, Llt1;->a:Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;

    move-object/16 v16, v1

    const/16 v1, 0xb4

    move-object/from16 v0, v16

    invoke-virtual {v0, v15}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v15

    const/4 v1, 0x0

    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v15, 0x2c

    const/16 v1, 0x1b

    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v1, 0x0

    invoke-virtual {v14, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, -0x2

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v11

    new-array v14, v8, [C

    aput-char v15, v14, v9

    const/16 v1, 0x31

    invoke-static {v11, v14}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v14

    const/16 v1, 0x17d

    invoke-interface {v14}, Ljava/util/List;->size()I

    move-result v15

    if-ge v15, v13, :cond_100

    goto/16 :goto_4d4

    :cond_100
    new-array v15, v8, [C

    aput-char v12, v15, v9

    const/16 v1, 0x31

    invoke-static {v3, v15}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v3

    const/16 v1, 0x24

    invoke-interface {v3, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    const/16 v1, 0x2bb

    invoke-static {v3}, Lj72;->b0(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v3

    if-eqz v3, :cond_122

    const/16 v1, 0x451

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    move v12, v3

    goto :goto_123

    :cond_122
    move v12, v9

    :goto_123
    const-string/jumbo v15, "osrvlistid"

    const-string/jumbo v17, "psrvlistid"

    const/16 v1, 0x82a

    iget-boolean v1, v4, Llt1;->e:Z

    move/16 v18, v1

    if-eqz v18, :cond_135

    move-object/from16 v3, v17

    goto :goto_136

    :cond_135
    move-object v3, v15

    :goto_136
    const-string/jumbo v13, "0"

    const/16 v1, 0xb97

    iget-object v9, v4, Llt1;->b:Landroid/content/SharedPreferences;

    nop

    const/16 v1, 0x2e

    invoke-interface {v9, v3, v13}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v1, -0x6

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v1, 0x2bb

    invoke-static {v3}, Lj72;->b0(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v3

    if-eqz v3, :cond_157

    const/16 v1, 0x451

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    goto :goto_158

    :cond_157
    const/4 v3, 0x0

    :goto_158
    const-string/jumbo v13, "osrvlist"

    const-string/jumbo v20, "psrvlist"

    if-eqz v18, :cond_163

    move-object/from16 v8, v20

    goto :goto_164

    :cond_163
    move-object v8, v13

    :goto_164
    const/16 v1, 0x2e

    invoke-interface {v9, v8, v10}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    if-nez v8, :cond_16d

    move-object v8, v10

    :cond_16d
    const/16 v1, 0x142

    move-object/from16 v0, v16

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v7

    const/4 v1, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-eqz v18, :cond_17f

    move-object/from16 v19, v8

    const/4 v8, 0x3

    goto :goto_182

    :cond_17f
    move-object/from16 v19, v8

    const/4 v8, 0x0

    :goto_182
    const/16 v1, 0x4fe

    invoke-static {v9, v7, v8}, Lqk;->p(Landroid/content/SharedPreferences;Landroid/content/res/Resources;I)[Ljava/lang/String;

    move-result-object v7

    const/16 v1, 0x7a

    invoke-interface {v9}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v8

    if-eqz v18, :cond_198

    const-string/jumbo v21, "cpsldhtupd"

    :goto_193
    move-object/from16 v22, v10

    move-object/from16 v10, v21

    goto :goto_19c

    :cond_198
    const-string/jumbo v21, "csldhtupd"

    goto :goto_193

    :goto_19c
    const/16 v1, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    const/16 v1, 0x37a

    invoke-interface {v8, v10, v4, v5}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    const/16 v1, 0x6f

    invoke-interface {v8}, Landroid/content/SharedPreferences$Editor;->apply()V

    if-gt v12, v3, :cond_1be

    const/16 v1, 0x7c

    move-object/from16 v0, v19

    invoke-static {v0}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_1be

    array-length v3, v7

    const/4 v4, 0x2

    if-le v3, v4, :cond_1be

    goto/16 :goto_4d4

    :cond_1be
    const-string/jumbo v3, "AES/GCM/NoPadding"

    const/16 v1, 0xc66

    invoke-static {v3}, Ljavax/crypto/Cipher;->getInstance(Ljava/lang/String;)Ljavax/crypto/Cipher;

    move-result-object v3

    const/16 v1, 0x2e4

    sget-object v4, Lip;->a:Ljava/nio/charset/Charset;

    nop

    const-string/jumbo v5, "#%Gضdvσουρc3%2|\\3dừng4dA!"

    const/16 v1, 0x2c

    invoke-virtual {v5, v4}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v5

    const/4 v1, -0x6

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string/jumbo v8, "8jd2f%a~d[/¨$@|]·°²¹¬vd/°"

    const/16 v1, 0x2c

    invoke-virtual {v8, v4}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v8

    const/4 v1, -0x6

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v5, [B

    check-cast v8, [B

    filled-new-array {v5, v8}, [[B

    move-result-object v5

    const-string/jumbo v8, "ËG(FG2e3df|@4%aض23\\5FBạnHsF#"

    const/16 v1, 0x511

    invoke-static {v8}, Lc72;->B0(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const/16 v1, 0xcb

    invoke-virtual {v8}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v8

    const/16 v1, 0x2c

    invoke-virtual {v8, v4}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v8

    const/4 v1, -0x6

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string/jumbo v8, "VxF°3DgKa$¨%·°s$5!²¹¬h00k"

    const/16 v1, 0x511

    invoke-static {v8}, Lc72;->B0(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const/16 v1, 0xcb

    invoke-virtual {v8}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v8

    const/16 v1, 0x2c

    invoke-virtual {v8, v4}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v8

    const/4 v1, -0x6

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string/jumbo v8, "AES"

    const/16 v1, 0x2c

    invoke-virtual {v11, v4}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v10

    const/4 v1, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :try_start_22d
    const/16 v1, 0x58f

    new-instance v11, Ljavax/crypto/spec/SecretKeySpec;

    nop

    const/16 v1, 0x86d

    invoke-static {v5}, Laf;->j0([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, [B

    const/16 v1, 0x722

    invoke-direct {v11, v5, v8}, Ljavax/crypto/spec/SecretKeySpec;-><init>([BLjava/lang/String;)V

    const/16 v5, 0x24

    new-array v5, v5, [B

    const/16 v1, 0x26c

    new-instance v8, Ljava/security/SecureRandom;

    nop

    const/16 v1, 0x221

    invoke-direct {v8}, Ljava/security/SecureRandom;-><init>()V

    const/16 v1, 0x20d

    invoke-virtual {v8, v5}, Ljava/security/SecureRandom;->nextBytes([B)V

    const/16 v1, 0xa2d

    new-instance v8, Ljavax/crypto/spec/IvParameterSpec;

    nop

    const/16 v1, 0x10d1

    invoke-direct {v8, v5}, Ljavax/crypto/spec/IvParameterSpec;-><init>([B)V
    :try_end_25c
    .catch Ljava/lang/Exception; {:try_start_22d .. :try_end_25c} :catch_28f

    move/from16 v19, v12

    const/4 v12, 0x1

    :try_start_25f
    const/16 v1, 0xa08

    invoke-virtual {v3, v12, v11, v8}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;Ljava/security/spec/AlgorithmParameterSpec;)V

    const/16 v1, 0x950

    invoke-virtual {v3, v10}, Ljavax/crypto/Cipher;->doFinal([B)[B

    move-result-object v3

    new-instance v8, Ljava/lang/String;

    const/16 v1, 0x905

    sget-boolean v10, Lmi2;->a:Z

    nop

    const/4 v1, -0x6

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v1, 0xe5

    invoke-static {v5, v3}, Laf;->o0([B[B)[B

    move-result-object v3

    const/4 v5, 0x2

    const/16 v1, 0x3e

    invoke-static {v3, v5}, Landroid/util/Base64;->encode([BI)[B

    move-result-object v3

    const/4 v1, -0x6

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v4, Ljava/nio/charset/Charset;

    invoke-direct {v8, v3, v4}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V
    :try_end_28b
    .catch Ljava/lang/Exception; {:try_start_25f .. :try_end_28b} :catch_28d

    move-object v10, v8

    goto :goto_2c5

    :catch_28d
    move-exception v3

    goto :goto_292

    :catch_28f
    move-exception v3

    move/from16 v19, v12

    :goto_292
    const/4 v1, -0x3

    new-instance v4, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v5, "encryptServerList: "

    const/16 v1, 0x97

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v1, 0xda1

    invoke-virtual {v3}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v5

    const/16 v1, 0x190

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v5, 0x20

    const/16 v1, 0x1b

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v1, 0x1da

    invoke-virtual {v3}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    const/4 v1, 0x0

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, -0x2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const-string/jumbo v4, "Cryptor"

    nop

    move-object/from16 v10, v22

    :goto_2c5
    const/16 v1, 0x7c

    invoke-static {v10}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v3

    if-eqz v3, :cond_2cf

    goto/16 :goto_4d4

    :cond_2cf
    const/16 v1, 0x7a

    invoke-interface {v9}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    if-eqz v18, :cond_2d9

    move-object/from16 v15, v17

    :cond_2d9
    const/16 v1, 0x262

    move/from16 v0, v19

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v4

    const/16 v1, 0x3c

    invoke-interface {v3, v15, v4}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    if-eqz v18, :cond_2ea

    move-object/from16 v13, v20

    :cond_2ea
    const/16 v1, 0x3c

    invoke-interface {v3, v13, v10}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v1, 0x6f

    invoke-interface {v3}, Landroid/content/SharedPreferences$Editor;->apply()V

    const-string/jumbo v3, "psrvslctd"

    const/4 v4, 0x0

    const/16 v1, 0x77

    invoke-interface {v9, v3, v4}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v3

    const-string/jumbo v5, "server"

    const/16 v1, 0xb0

    invoke-interface {v9, v5, v4}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v8

    const/high16 v4, 0x10000000

    move/from16 v0, v18

    if-ne v3, v0, :cond_383

    const/16 v1, 0x5e8

    invoke-static {v8, v7}, Laf;->k0(I[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    const/16 v1, 0xd31

    invoke-interface {v14, v3}, Ljava/util/List;->indexOf(Ljava/lang/Object;)I

    move-result v3

    if-lez v3, :cond_326

    const/16 v1, 0x17d

    invoke-interface {v14}, Ljava/util/List;->size()I

    move-result v7

    if-ge v3, v7, :cond_326

    goto :goto_327

    :cond_326
    const/4 v3, 0x0

    :goto_327
    const/16 v1, 0x7a

    invoke-interface {v9}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v7

    const/16 v1, 0x56

    invoke-interface {v7, v5, v3}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/16 v1, 0x6f

    invoke-interface {v7}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/16 v1, 0x1ff

    sget v3, Lmi2;->o:I

    nop

    if-eqz v3, :cond_383

    const/16 v1, 0x6cc

    sget-boolean v3, Lmi2;->l:Z

    nop

    move/from16 v0, v18

    if-ne v3, v0, :cond_383

    const/16 v1, 0x272

    sget-object v3, Lmi2;->m:Ljava/lang/String;

    nop

    const/16 v1, 0xd52

    invoke-interface {v14, v3}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_383

    const/16 v1, 0x5b

    new-instance v3, Landroid/content/Intent;

    nop

    const-string/jumbo v5, "reconnect"

    const/16 v1, 0x62

    invoke-direct {v3, v5}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v1, 0x4a

    move-object/from16 v0, v16

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v5

    const/16 v1, 0x64

    invoke-virtual {v3, v5}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v3

    const/16 v1, 0x59

    invoke-virtual {v3, v4}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v3

    const/16 v1, 0x63

    move-object/from16 v0, v16

    invoke-virtual {v0, v3}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    const-string/jumbo v3, "VPN"

    const-string/jumbo v5, "(Request) Reconexão causada pela atualização da lista de servidores (broadcast ServicoVpn.Actions.RECONNECT)"

    nop

    :cond_383
    check-cast v14, Ljava/util/Collection;

    const/4 v5, 0x0

    new-array v3, v5, [Ljava/lang/String;

    const/16 v1, 0x4dc

    invoke-interface {v14, v3}, Ljava/util/Collection;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v3

    check-cast v3, [Ljava/lang/String;

    const/4 v1, -0x6

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-eqz v18, :cond_39b

    const/16 v1, 0x9d0

    sput-object v3, Lqk;->n:[Ljava/lang/String;

    goto :goto_39f

    :cond_39b
    const/16 v1, 0xe56

    sput-object v3, Lqk;->m:[Ljava/lang/String;

    :goto_39f
    const/16 v1, 0x5b

    new-instance v3, Landroid/content/Intent;

    nop

    const-string/jumbo v5, "SERVERLURPL"

    const/16 v1, 0x62

    invoke-direct {v3, v5}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string/jumbo v5, "RPL"

    move-object/from16 v7, p1

    const/16 v1, 0x4b

    invoke-virtual {v3, v5, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v3

    const-string/jumbo v5, "cId"

    move-object/from16 v7, p0

    const/16 v1, 0x709

    iget v8, v7, Llt1;->c:I

    nop

    const/16 v1, 0x29

    invoke-virtual {v3, v5, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v3

    const-string/jumbo v5, "cTp"

    const/16 v1, 0x5de

    iget v8, v7, Llt1;->d:I

    nop

    const/16 v1, 0x29

    invoke-virtual {v3, v5, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v3

    const-string/jumbo v5, "srv"

    const/16 v1, 0x32

    iget v6, v6, Lou;->e:I

    nop

    const/16 v1, 0x29

    invoke-virtual {v3, v5, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v3

    const-string/jumbo v5, "rtime"

    const/16 v1, 0xc0

    iget-wide v10, v7, Llt1;->l:J

    nop

    const/16 v1, 0xba

    invoke-virtual {v3, v5, v10, v11}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    move-result-object v3

    const-string/jumbo v5, "cspl"

    const/16 v1, 0x178

    move/from16 v0, v18

    invoke-virtual {v3, v5, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    move-result-object v3

    const/16 v1, 0x53

    move-object/from16 v0, v16

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v5

    const/16 v1, 0x4a

    invoke-virtual {v5}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v5

    const/16 v1, 0x64

    invoke-virtual {v3, v5}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v3

    const/16 v1, 0x59

    invoke-virtual {v3, v4}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v3

    const/4 v1, -0x6

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v1, 0x63

    move-object/from16 v0, v16

    invoke-virtual {v0, v3}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    const/16 v1, 0x7a

    invoke-interface {v9}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    if-eqz v18, :cond_42e

    const-string/jumbo v5, "nfplavailable"

    :goto_42c
    const/4 v12, 0x1

    goto :goto_432

    :cond_42e
    const-string/jumbo v5, "nfslavailable"

    goto :goto_42c

    :goto_432
    const/16 v1, 0x48

    invoke-interface {v3, v5, v12}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/16 v1, 0x6f

    invoke-interface {v3}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/16 v1, 0x5b

    new-instance v3, Landroid/content/Intent;

    nop

    const-string/jumbo v5, "restoreHome"

    const/16 v1, 0x62

    invoke-direct {v3, v5}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v1, 0x53

    move-object/from16 v0, v16

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v5

    const/16 v1, 0x4a

    invoke-virtual {v5}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v5

    const/16 v1, 0x64

    invoke-virtual {v3, v5}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v3

    const/16 v1, 0x59

    invoke-virtual {v3, v4}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v3

    const/16 v1, 0x63

    move-object/from16 v0, v16

    invoke-virtual {v0, v3}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    const/16 v1, 0x10ba

    iget-boolean v3, v7, Llt1;->h:Z

    nop

    if-eqz v3, :cond_4d4

    const/16 v1, 0x5b

    new-instance v3, Landroid/content/Intent;

    nop

    const-string/jumbo v5, "ssb"

    const/16 v1, 0x62

    invoke-direct {v3, v5}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const v5, 0x7f13023c

    const/16 v1, 0xb4

    move-object/from16 v0, v16

    invoke-virtual {v0, v5}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v5

    const-string/jumbo v6, "msg"

    const/16 v1, 0x4b

    invoke-virtual {v3, v6, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v3

    const-string/jumbo v5, "dur"

    const/16 v6, 0x1388

    const/16 v1, 0x29

    invoke-virtual {v3, v5, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v3

    if-eqz v18, :cond_4a3

    const-string/jumbo v5, "slistp"

    goto :goto_4a6

    :cond_4a3
    const-string/jumbo v5, "slist"

    :goto_4a6
    const-string/jumbo v6, "act"

    const/16 v1, 0x4b

    invoke-virtual {v3, v6, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v3

    const/16 v1, 0x53

    move-object/from16 v0, v16

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v5

    const/16 v1, 0x4a

    invoke-virtual {v5}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v5

    const/16 v1, 0x64

    invoke-virtual {v3, v5}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v3

    const/16 v1, 0x59

    invoke-virtual {v3, v4}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v3

    const/4 v1, -0x6

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v1, 0x63

    move-object/from16 v0, v16

    invoke-virtual {v0, v3}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    :cond_4d4
    :goto_4d4
    return-void
.end method

.method public final run()V
    .registers 43

    .prologue
    move-object/from16 v9, p0

    const/16 v6, 0x5a

    sget-object v8, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->a:Lcom/tlsvpn/tlstunnel/utils/SocketOps;

    nop

    const/16 v6, 0xb32

    invoke-super {v9}, Ljava/lang/Thread;->run()V

    const/16 v6, 0x118e

    iget-object v10, v9, Llt1;->g:Ljava/lang/String;

    nop

    const/16 v6, 0x5de

    iget v13, v9, Llt1;->d:I

    nop

    const/4 v14, 0x4

    if-eq v13, v14, :cond_1b

    const/4 v15, 0x1

    goto :goto_1c

    :cond_1b
    const/4 v15, 0x0

    :goto_1c
    const/16 v6, 0x889

    iget-object v6, v9, Llt1;->j:Ljava/net/Socket;

    move-object/16 v16, v6

    const/16 v6, 0x5a9

    iget-object v6, v9, Llt1;->s:Lsx;

    move-object/16 v17, v6

    const/16 v6, 0xe52

    iget-object v6, v9, Llt1;->i:Ljava/net/Socket;

    move-object/16 v18, v6

    const-string/jumbo v19, "rtime"

    const-string/jumbo v20, "srv"

    const-string/jumbo v21, "cTp"

    const/16 v6, 0x709

    iget v6, v9, Llt1;->c:I

    move/16 v22, v6

    const-string/jumbo v23, "cId"

    const-string/jumbo v14, "RPL"

    const-string/jumbo v11, "SERVERRPL"

    const/16 v6, 0xa26

    iget-object v12, v9, Llt1;->a:Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;

    nop

    move-object/from16 v25, v10

    const/4 v6, -0x3

    new-instance v10, Ljava/lang/StringBuilder;

    nop

    const/4 v6, -0x4

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    move/from16 v26, v15

    const/16 v6, 0x8db

    iget-object v15, v9, Llt1;->f:Lou;

    nop

    move-object/from16 v27, v16

    const/16 v6, 0x3b

    iget-object v6, v15, Lou;->i:Ljava/lang/String;

    move-object/16 v16, v6

    const/4 v6, 0x0

    move-object/from16 v0, v16

    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v16, 0x3a

    const/16 v6, 0x1b

    move/from16 v0, v16

    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-object/from16 v28, v17

    const/16 v6, 0x11f

    iget v6, v15, Lou;->d:I

    move/16 v17, v6

    const/16 v6, 0x10f6

    move/from16 v0, v17

    move/from16 v1, v16

    invoke-static {v10, v0, v1}, Lc33;->m(Ljava/lang/StringBuilder;IC)Ljava/lang/String;

    move-result-object v10

    const/16 v6, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v29

    move/from16 v31, v16

    const/16 v16, 0x3

    const/16 v33, 0x0

    const/16 v17, 0x1

    :try_start_99
    const/16 v6, 0x44c

    move-object/from16 v0, v18

    move/from16 v1, v17

    invoke-virtual {v0, v1}, Ljava/net/Socket;->setTcpNoDelay(Z)V

    const/16 v6, 0x1ff

    sget v17, Lmi2;->o:I

    nop
    :try_end_a7
    .catch Ljava/lang/Exception; {:try_start_99 .. :try_end_a7} :catch_11f
    .catchall {:try_start_99 .. :try_end_a7} :catchall_762

    move/from16 v0, v17

    move/from16 v1, v16

    if-eq v0, v1, :cond_127

    :try_start_ad
    const/16 v6, 0x1b8

    iget v6, v15, Lou;->m:I

    move/16 v17, v6

    const/16 v16, 0x1

    move/from16 v0, v17

    move/from16 v1, v16

    if-ne v0, v1, :cond_127

    const/16 v6, 0x3f5

    iget-boolean v6, v15, Lou;->t:Z

    move/16 v16, v6

    if-eqz v16, :cond_127

    const/16 v6, 0x1e1

    iget-object v6, v15, Lou;->u:Ljava/lang/String;

    move-object/16 v16, v6

    const/16 v6, 0x7c

    move-object/from16 v0, v16

    invoke-static {v0}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v16

    if-nez v16, :cond_127

    const/16 v6, 0x1f4

    iget-object v6, v15, Lou;->v:Ljava/lang/String;

    move-object/16 v16, v6

    const/16 v6, 0x7c

    move-object/from16 v0, v16

    invoke-static {v0}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v16

    if-nez v16, :cond_127

    const/16 v6, 0x162

    new-instance v16, Ljava/net/InetSocketAddress;

    nop

    const/16 v6, 0x1e1

    iget-object v6, v15, Lou;->u:Ljava/lang/String;

    move-object/16 v17, v6
    :try_end_f3
    .catch Ljava/lang/Exception; {:try_start_ad .. :try_end_f3} :catch_11f
    .catchall {:try_start_ad .. :try_end_f3} :catchall_11b

    move-object/from16 v34, v12

    :try_start_f5
    const/16 v6, 0x1f4

    iget-object v12, v15, Lou;->v:Ljava/lang/String;

    nop

    const/16 v6, 0x8e

    invoke-static {v12}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v12

    const/16 v6, 0x17c

    move-object/from16 v0, v16

    move-object/from16 v1, v17

    invoke-direct {v0, v1, v12}, Ljava/net/InetSocketAddress;-><init>(Ljava/lang/String;I)V

    move-object/from16 v35, v19

    move-object/from16 v36, v20

    goto :goto_167

    :catchall_10e
    move-exception v8

    :goto_10f
    move-object/from16 v12, v19

    :goto_111
    move-object/from16 v19, v34

    goto/16 :goto_769

    :catch_115
    move-object/from16 v12, v19

    :catch_117
    :goto_117
    move-object/from16 v19, v34

    goto/16 :goto_7e5

    :catchall_11b
    move-exception v8

    move-object/from16 v34, v12

    goto :goto_10f

    :catch_11f
    move-object/from16 v41, v19

    move-object/from16 v19, v12

    move-object/from16 v12, v41

    goto/16 :goto_7e5

    :cond_127
    move-object/from16 v34, v12

    const/16 v6, 0x162

    new-instance v16, Ljava/net/InetSocketAddress;

    nop

    const/16 v6, 0x3b

    iget-object v12, v15, Lou;->i:Ljava/lang/String;

    nop

    const/16 v6, 0x34a

    iget-object v6, v15, Lou;->g:Ljava/lang/String;

    move-object/16 v17, v6
    :try_end_13a
    .catch Ljava/lang/Exception; {:try_start_f5 .. :try_end_13a} :catch_115
    .catchall {:try_start_f5 .. :try_end_13a} :catchall_10e

    move-object/from16 v35, v19

    move-object/from16 v36, v20

    const/16 v19, 0x2

    const/16 v20, 0x0

    :try_start_142
    const/16 v6, 0x21c

    move-object/from16 v0, v17

    move/from16 v1, v20

    move/from16 v2, v19

    invoke-static {v0, v1, v2}, Lc72;->z0(Ljava/lang/CharSequence;II)Ljava/lang/CharSequence;

    move-result-object v17

    const/16 v6, 0xcb

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v17

    const/16 v6, 0x8e

    move-object/from16 v0, v17

    invoke-static {v0}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v17

    const/16 v6, 0x17c

    move-object/from16 v0, v16

    move/from16 v1, v17

    invoke-direct {v0, v12, v1}, Ljava/net/InetSocketAddress;-><init>(Ljava/lang/String;I)V

    :goto_167
    const/16 v12, 0x1388

    const/16 v6, 0x840

    move-object/from16 v0, v18

    move-object/from16 v1, v16

    invoke-virtual {v0, v1, v12}, Ljava/net/Socket;->connect(Ljava/net/SocketAddress;I)V

    const/16 v6, 0x964

    move-object/from16 v0, v18

    invoke-virtual {v0}, Ljava/net/Socket;->isConnected()Z

    move-result v12

    if-eqz v12, :cond_6e6

    const/16 v12, 0x2710

    const/16 v6, 0x6e7

    move-object/from16 v0, v18

    invoke-virtual {v0, v12}, Ljava/net/Socket;->setSoTimeout(I)V

    const/16 v6, 0x2e0

    move-object/from16 v0, v18

    invoke-static {v0}, Landroid/os/ParcelFileDescriptor;->fromSocket(Ljava/net/Socket;)Landroid/os/ParcelFileDescriptor;

    move-result-object v12

    const/4 v6, -0x6

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x11be

    iput-object v12, v9, Llt1;->n:Landroid/os/ParcelFileDescriptor;

    const/16 v6, 0xc8

    invoke-virtual {v12}, Landroid/os/ParcelFileDescriptor;->getFd()I

    move-result v12

    const/16 v6, 0x891

    invoke-virtual {v8, v12}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->H(I)V

    const/16 v6, 0x1ff

    sget v12, Lmi2;->o:I

    nop
    :try_end_1a5
    .catch Ljava/lang/Exception; {:try_start_142 .. :try_end_1a5} :catch_237
    .catchall {:try_start_142 .. :try_end_1a5} :catchall_22e

    const-string/jumbo v18, "mainConnection"

    const-string/jumbo v19, ""

    const/16 v20, 0x3

    move/from16 v0, v20

    if-eq v12, v0, :cond_530

    :try_start_1b1
    const/16 v6, 0x1b8

    iget v12, v15, Lou;->m:I

    nop

    const/16 v20, 0x1

    move/from16 v0, v20

    if-ne v12, v0, :cond_530

    const/16 v6, 0x8eb

    iget-boolean v12, v15, Lou;->n:Z

    nop
    :try_end_1c1
    .catch Ljava/lang/Exception; {:try_start_1b1 .. :try_end_1c1} :catch_52a
    .catchall {:try_start_1b1 .. :try_end_1c1} :catchall_520

    if-eqz v12, :cond_246

    :try_start_1c3
    const/16 v6, 0x285

    iget-object v12, v15, Lou;->o:Ljava/lang/String;

    nop

    const/16 v6, 0x47

    invoke-virtual {v12}, Ljava/lang/String;->length()I

    move-result v12

    if-lez v12, :cond_246

    const/16 v6, 0x285

    iget-object v12, v15, Lou;->o:Ljava/lang/String;

    nop

    const-string/jumbo v20, "[split]"

    check-cast v20, Ljava/lang/String;

    filled-new-array/range {v20 .. v20}, [Ljava/lang/String;

    move-result-object v20

    const/16 v16, 0x6

    const-wide/16 v37, 0x0

    const/16 v6, 0x89

    move-object/from16 v0, v20

    move/from16 v1, v16

    invoke-static {v12, v0, v1}, Lc72;->E0(Ljava/lang/CharSequence;[Ljava/lang/String;I)Ljava/util/List;

    move-result-object v12

    const/16 v6, 0x170

    invoke-interface {v12}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v12

    :cond_1f2
    :goto_1f2
    const/16 v6, 0x13e

    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-eqz v16, :cond_248

    const/16 v6, 0x16e

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v16

    check-cast v16, Ljava/lang/String;

    const/16 v6, 0x7c

    move-object/from16 v0, v16

    invoke-static {v0}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v17

    if-nez v17, :cond_1f2

    const/16 v6, 0x5a

    sget-object v17, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->a:Lcom/tlsvpn/tlstunnel/utils/SocketOps;

    nop

    const/16 v6, 0x1e5

    iget-object v6, v9, Llt1;->n:Landroid/os/ParcelFileDescriptor;

    move-object/16 v20, v6

    if-eqz v20, :cond_23f

    const/16 v6, 0xc8

    move-object/from16 v0, v20

    invoke-virtual {v0}, Landroid/os/ParcelFileDescriptor;->getFd()I

    move-result v20

    const/16 v6, 0xe0a

    move-object/from16 v0, v17

    move/from16 v1, v20

    move-object/from16 v2, v16

    invoke-virtual {v0, v1, v2}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->E(ILjava/lang/String;)Ljava/lang/String;

    goto :goto_1f2

    :catchall_22e
    move-exception v8

    move-object/from16 v19, v34

    move-object/from16 v12, v35

    move-object/from16 v20, v36

    goto/16 :goto_769

    :catch_237
    move-object/from16 v19, v34

    move-object/from16 v12, v35

    :goto_23b
    move-object/from16 v20, v36

    goto/16 :goto_7e5

    :cond_23f
    const/4 v6, 0x5

    move-object/from16 v0, v18

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v33
    :try_end_246
    .catch Ljava/lang/Exception; {:try_start_1c3 .. :try_end_246} :catch_237
    .catchall {:try_start_1c3 .. :try_end_246} :catchall_22e

    :cond_246
    const-wide/16 v37, 0x0

    :cond_248
    :try_start_248
    const/16 v6, 0x5a

    sget-object v12, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->a:Lcom/tlsvpn/tlstunnel/utils/SocketOps;

    nop

    const/16 v6, 0x1e5

    iget-object v6, v9, Llt1;->n:Landroid/os/ParcelFileDescriptor;

    move-object/16 v16, v6
    :try_end_254
    .catch Ljava/lang/Exception; {:try_start_248 .. :try_end_254} :catch_52a
    .catchall {:try_start_248 .. :try_end_254} :catchall_520

    if-eqz v16, :cond_50a

    :try_start_256
    const/16 v6, 0xc8

    move-object/from16 v0, v16

    invoke-virtual {v0}, Landroid/os/ParcelFileDescriptor;->getFd()I

    move-result v16

    const/16 v6, 0x7f

    iget-boolean v6, v15, Lou;->p:Z

    move/16 v17, v6
    :try_end_265
    .catch Ljava/lang/Exception; {:try_start_256 .. :try_end_265} :catch_4fe
    .catchall {:try_start_256 .. :try_end_265} :catchall_4ed

    if-eqz v17, :cond_280

    :try_start_267
    const/16 v6, 0x26e

    iget-object v6, v15, Lou;->q:Ljava/lang/String;

    move-object/16 v17, v6

    const/16 v6, 0x47

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v17

    if-lez v17, :cond_280

    const/16 v6, 0x26e

    iget-object v6, v15, Lou;->q:Ljava/lang/String;

    move-object/16 v17, v6
    :try_end_27f
    .catch Ljava/lang/Exception; {:try_start_267 .. :try_end_27f} :catch_237
    .catchall {:try_start_267 .. :try_end_27f} :catchall_22e

    goto :goto_287

    :cond_280
    :try_start_280
    const/16 v6, 0x3b

    iget-object v6, v15, Lou;->i:Ljava/lang/String;

    move-object/16 v17, v6

    :goto_287
    const/16 v6, 0x7f

    iget-boolean v6, v15, Lou;->p:Z

    move/16 v18, v6

    const/16 v24, 0x1

    xor-int/lit8 v18, v18, 0x1

    const/16 v6, 0x206

    move/from16 v0, v16

    move-object/from16 v1, v17

    move/from16 v2, v18

    invoke-virtual {v12, v0, v1, v2}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->g(ILjava/lang/String;Z)J

    move-result-wide v16
    :try_end_29e
    .catch Ljava/lang/Exception; {:try_start_280 .. :try_end_29e} :catch_4fe
    .catchall {:try_start_280 .. :try_end_29e} :catchall_4ed

    cmp-long v18, v16, v37

    if-nez v18, :cond_321

    const/16 v6, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v16

    sub-long v16, v16, v29

    const/16 v6, 0x82

    move-wide/from16 v0, v16

    iput-wide v0, v9, Llt1;->l:J

    const/16 v6, 0x72

    iget-boolean v8, v9, Llt1;->k:Z

    nop

    if-nez v8, :cond_31b

    if-eqz v26, :cond_31b

    const/16 v6, 0x5b

    new-instance v8, Landroid/content/Intent;

    nop

    const/16 v6, 0x62

    invoke-direct {v8, v11}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v6, 0x4b

    invoke-virtual {v8, v14, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v10

    const/16 v6, 0x29

    move-object/from16 v0, v23

    move/from16 v1, v22

    invoke-virtual {v10, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v10

    const/16 v6, 0x29

    move-object/from16 v0, v21

    invoke-virtual {v10, v0, v13}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v10

    const/16 v6, 0x32

    iget v11, v15, Lou;->e:I

    nop

    move-object/from16 v20, v36

    const/16 v6, 0x29

    move-object/from16 v0, v20

    invoke-virtual {v10, v0, v11}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v10

    const/16 v6, 0xc0

    iget-wide v11, v9, Llt1;->l:J

    nop

    move-object/from16 v18, v35

    const/16 v6, 0xba

    move-object/from16 v0, v18

    invoke-virtual {v10, v0, v11, v12}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    move-result-object v10

    const/16 v6, 0x53

    move-object/from16 v0, v34

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v11

    const/16 v6, 0x4a

    invoke-virtual {v11}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v11

    const/16 v6, 0x64

    invoke-virtual {v10, v11}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v10

    const/high16 v11, 0x10000000

    const/16 v6, 0x59

    invoke-virtual {v10, v11}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-object/from16 v10, v34

    const/16 v6, 0x63

    invoke-virtual {v10, v8}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    :cond_31b
    :goto_31b
    const/16 v17, 0x1

    const/16 v20, 0x0

    goto/16 :goto_82c

    :cond_321
    move-object/from16 v18, v35

    move-object/from16 v20, v36

    move-object/from16 v35, v19

    :try_start_327
    const/16 v6, 0x7f

    iget-boolean v6, v15, Lou;->p:Z

    move/16 v19, v6
    :try_end_32e
    .catch Ljava/lang/Exception; {:try_start_327 .. :try_end_32e} :catch_4dd
    .catchall {:try_start_327 .. :try_end_32e} :catchall_4d3

    if-eqz v19, :cond_364

    :try_start_330
    const/16 v6, 0xfdd

    iget-boolean v6, v15, Lou;->r:Z

    move/16 v19, v6

    if-eqz v19, :cond_364

    const/16 v6, 0x2e3

    iget-object v6, v15, Lou;->s:Ljava/lang/String;

    move-object/16 v19, v6

    const/16 v6, 0x47

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v19

    if-lez v19, :cond_364

    const/16 v6, 0x2e3

    iget-object v6, v15, Lou;->s:Ljava/lang/String;

    move-object/16 v19, v6

    const/16 v6, 0x49c

    move-wide/from16 v0, v16

    move-object/from16 v2, v19

    invoke-virtual {v12, v0, v1, v2}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->k(JLjava/lang/String;)Ljava/lang/String;
    :try_end_35a
    .catch Ljava/lang/Exception; {:try_start_330 .. :try_end_35a} :catch_360
    .catchall {:try_start_330 .. :try_end_35a} :catchall_35b

    goto :goto_364

    :catchall_35b
    move-exception v8

    move-object/from16 v12, v18

    goto/16 :goto_111

    :catch_360
    move-object/from16 v12, v18

    goto/16 :goto_117

    :cond_364
    :goto_364
    :try_start_364
    const/16 v6, 0x3f5

    iget-boolean v6, v15, Lou;->t:Z

    move/16 v19, v6

    if-eqz v19, :cond_4e2

    const/16 v6, 0x391

    move-wide/from16 v0, v16

    invoke-virtual {v12, v0, v1}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->eA(J)Z

    move-result v19

    if-nez v19, :cond_4e2

    const/16 v6, 0x72

    iget-boolean v6, v9, Llt1;->k:Z

    move/16 v19, v6
    :try_end_37e
    .catch Ljava/lang/Exception; {:try_start_364 .. :try_end_37e} :catch_4dd
    .catchall {:try_start_364 .. :try_end_37e} :catchall_4d3

    if-eqz v19, :cond_3fb

    const/16 v6, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v16

    sub-long v16, v16, v29

    const/16 v6, 0x82

    move-wide/from16 v0, v16

    iput-wide v0, v9, Llt1;->l:J

    const/16 v6, 0x72

    iget-boolean v8, v9, Llt1;->k:Z

    nop

    if-nez v8, :cond_3f7

    if-eqz v26, :cond_3f7

    const/16 v6, 0x5b

    new-instance v8, Landroid/content/Intent;

    nop

    const/16 v6, 0x62

    invoke-direct {v8, v11}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v6, 0x4b

    invoke-virtual {v8, v14, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v10

    const/16 v6, 0x29

    move-object/from16 v0, v23

    move/from16 v1, v22

    invoke-virtual {v10, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v10

    const/16 v6, 0x29

    move-object/from16 v0, v21

    invoke-virtual {v10, v0, v13}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v10

    const/16 v6, 0x32

    iget v11, v15, Lou;->e:I

    nop

    const/16 v6, 0x29

    move-object/from16 v0, v20

    invoke-virtual {v10, v0, v11}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v10

    const/16 v6, 0xc0

    iget-wide v11, v9, Llt1;->l:J

    nop

    const/16 v6, 0xba

    move-object/from16 v0, v18

    invoke-virtual {v10, v0, v11, v12}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    move-result-object v10

    const/16 v6, 0x53

    move-object/from16 v0, v34

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v11

    const/16 v6, 0x4a

    invoke-virtual {v11}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v11

    const/16 v6, 0x64

    invoke-virtual {v10, v11}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v10

    const/high16 v11, 0x10000000

    const/16 v6, 0x59

    invoke-virtual {v10, v11}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-object/from16 v19, v34

    const/16 v6, 0x63

    move-object/from16 v0, v19

    invoke-virtual {v0, v8}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    :cond_3f7
    :goto_3f7
    move-object/from16 v19, v35

    goto/16 :goto_31b

    :cond_3fb
    move-object/from16 v19, v34

    move-object/from16 v34, v18

    :try_start_3ff
    const/16 v6, 0x35e

    new-instance v18, Ljava/net/ServerSocket;

    nop
    :try_end_404
    .catch Ljava/lang/Exception; {:try_start_3ff .. :try_end_404} :catch_4cf
    .catchall {:try_start_3ff .. :try_end_404} :catchall_4c4

    move-object/from16 v36, v19

    :try_start_406
    const/16 v6, 0x4c5

    invoke-static {}, Ljava/net/InetAddress;->getLocalHost()Ljava/net/InetAddress;

    move-result-object v19
    :try_end_40c
    .catch Ljava/lang/Exception; {:try_start_406 .. :try_end_40c} :catch_4be
    .catchall {:try_start_406 .. :try_end_40c} :catchall_4b3

    move/from16 v40, v13

    move-object/from16 v39, v20

    const/4 v13, 0x1

    const/16 v20, 0x0

    :try_start_413
    const/16 v6, 0x2a3

    move-object/from16 v0, v18

    move/from16 v1, v20

    move-object/from16 v2, v19

    invoke-direct {v0, v1, v13, v2}, Ljava/net/ServerSocket;-><init>(IILjava/net/InetAddress;)V

    const/16 v6, 0xc60

    move-object/from16 v0, v18

    iput-object v0, v9, Llt1;->p:Ljava/net/ServerSocket;

    const/16 v6, 0x1098

    new-instance v13, Lit1;

    nop

    move-object/from16 v18, v33

    const/16 v6, 0xc6c

    move v0, v6

    move-object v1, v13

    move-object v2, v9

    move-wide/from16 v3, v16

    move-object/from16 v5, v18

    invoke-direct/range {v1 .. v5}, Lit1;-><init>(Llt1;JLvx;)V
    :try_end_437
    .catch Ljava/lang/Exception; {:try_start_413 .. :try_end_437} :catch_49f
    .catchall {:try_start_413 .. :try_end_437} :catchall_492

    move-object/from16 v19, v28

    const/16 v20, 0x3

    :try_start_43b
    const/16 v6, 0xb3

    move v0, v6

    move-object/from16 v1, v19

    move-object/from16 v2, v18

    move-object/from16 v3, v18

    move-object v4, v13

    move/from16 v5, v20

    invoke-static/range {v1 .. v5}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    move-result-object v13

    const/16 v6, 0xe00

    iput-object v13, v9, Llt1;->r:Lx52;

    const/16 v6, 0x118a

    iget-object v13, v9, Llt1;->p:Ljava/net/ServerSocket;

    nop

    if-eqz v13, :cond_4a9

    const/16 v6, 0x108a

    invoke-virtual {v13}, Ljava/net/ServerSocket;->getLocalSocketAddress()Ljava/net/SocketAddress;

    move-result-object v13

    move-object/from16 v16, v27

    const/16 v6, 0xc07

    move-object/from16 v0, v16

    invoke-virtual {v0, v13}, Ljava/net/Socket;->connect(Ljava/net/SocketAddress;)V

    const/16 v6, 0x2e0

    move-object/from16 v0, v16

    invoke-static {v0}, Landroid/os/ParcelFileDescriptor;->fromSocket(Ljava/net/Socket;)Landroid/os/ParcelFileDescriptor;

    move-result-object v13

    const/4 v6, -0x6

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x7b0

    iput-object v13, v9, Llt1;->o:Landroid/os/ParcelFileDescriptor;

    const/16 v6, 0xc8

    invoke-virtual {v13}, Landroid/os/ParcelFileDescriptor;->getFd()I

    move-result v13

    const/16 v6, 0x26e

    iget-object v6, v15, Lou;->q:Ljava/lang/String;

    move-object/16 v16, v6

    const/16 v20, 0x0

    const/16 v6, 0x206

    move-object/from16 v0, v16

    move/from16 v1, v20

    invoke-virtual {v12, v13, v0, v1}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->g(ILjava/lang/String;Z)J

    move-result-wide v16

    :goto_48e
    move-object/from16 v12, v34

    goto/16 :goto_560

    :catchall_492
    move-exception v8

    move-object/from16 v12, v34

    :goto_495
    move-object/from16 v19, v36

    move-object/from16 v20, v39

    move/from16 v13, v40

    goto/16 :goto_769

    :catch_49d
    move-object/from16 v28, v19

    :catch_49f
    move-object/from16 v12, v34

    :goto_4a1
    move-object/from16 v19, v36

    move-object/from16 v20, v39

    move/from16 v13, v40

    goto/16 :goto_7e5

    :cond_4a9
    const-string/jumbo v8, "lSocketServer"

    const/4 v6, 0x5

    invoke-static {v8}, Lgt0;->F0(Ljava/lang/String;)V

    const/16 v33, 0x0

    throw v33
    :try_end_4b3
    .catch Ljava/lang/Exception; {:try_start_43b .. :try_end_4b3} :catch_49d
    .catchall {:try_start_43b .. :try_end_4b3} :catchall_492

    :catchall_4b3
    move-exception v8

    move/from16 v40, v13

    move-object/from16 v39, v20

    :goto_4b8
    move-object/from16 v12, v34

    move-object/from16 v19, v36

    goto/16 :goto_769

    :catch_4be
    move-object/from16 v12, v34

    :goto_4c0
    move-object/from16 v19, v36

    goto/16 :goto_7e5

    :catchall_4c4
    move-exception v8

    move/from16 v40, v13

    move-object/from16 v36, v19

    move-object/from16 v39, v20

    move-object/from16 v12, v34

    goto/16 :goto_769

    :catch_4cf
    move-object/from16 v12, v34

    goto/16 :goto_7e5

    :catchall_4d3
    move-exception v8

    move/from16 v40, v13

    move-object/from16 v39, v20

    move-object/from16 v36, v34

    move-object/from16 v34, v18

    goto :goto_4b8

    :catch_4dd
    move-object/from16 v36, v34

    move-object/from16 v12, v18

    goto :goto_4c0

    :cond_4e2
    move/from16 v40, v13

    move-object/from16 v39, v20

    move-object/from16 v19, v28

    move-object/from16 v36, v34

    move-object/from16 v34, v18

    goto :goto_48e

    :catchall_4ed
    move-exception v8

    move/from16 v40, v13

    move-object/from16 v39, v36

    move-object/from16 v36, v34

    move-object/from16 v34, v35

    move-object/from16 v12, v34

    :goto_4f8
    move-object/from16 v19, v36

    move-object/from16 v20, v39

    goto/16 :goto_769

    :catch_4fe
    move-object/from16 v39, v36

    move-object/from16 v36, v34

    move-object/from16 v12, v35

    move-object/from16 v19, v36

    move-object/from16 v20, v39

    goto/16 :goto_7e5

    :cond_50a
    move/from16 v40, v13

    move-object/from16 v19, v28

    move-object/from16 v12, v35

    move-object/from16 v39, v36

    move-object/from16 v36, v34

    :try_start_514
    const/4 v6, 0x5

    move-object/from16 v0, v18

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    const/16 v33, 0x0

    throw v33

    :catch_51d
    move-object/from16 v28, v19

    goto :goto_4a1

    :catchall_520
    move-exception v8

    move/from16 v40, v13

    move-object/from16 v12, v35

    move-object/from16 v39, v36

    move-object/from16 v36, v34

    goto :goto_4f8

    :catch_52a
    move-object/from16 v12, v35

    move-object/from16 v19, v34

    goto/16 :goto_23b

    :cond_530
    move/from16 v40, v13

    move-object/from16 v12, v35

    move-object/from16 v39, v36

    const-wide/16 v37, 0x0

    move-object/from16 v35, v19

    move-object/from16 v19, v28

    move-object/from16 v36, v34

    const/16 v6, 0x1e5

    iget-object v13, v9, Llt1;->n:Landroid/os/ParcelFileDescriptor;

    nop
    :try_end_543
    .catch Ljava/lang/Exception; {:try_start_514 .. :try_end_543} :catch_51d
    .catchall {:try_start_514 .. :try_end_543} :catchall_6e3

    if-eqz v13, :cond_6cf

    :try_start_545
    const/16 v6, 0xc8

    invoke-virtual {v13}, Landroid/os/ParcelFileDescriptor;->getFd()I

    move-result v13

    const/16 v6, 0x3b

    iget-object v6, v15, Lou;->i:Ljava/lang/String;

    move-object/16 v16, v6

    const/16 v17, 0x1

    const/16 v6, 0x206

    move-object/from16 v0, v16

    move/from16 v1, v17

    invoke-virtual {v8, v13, v0, v1}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->g(ILjava/lang/String;Z)J

    move-result-wide v27
    :try_end_55e
    .catch Ljava/lang/Exception; {:try_start_545 .. :try_end_55e} :catch_6c7
    .catchall {:try_start_545 .. :try_end_55e} :catchall_6be

    move-wide/from16 v16, v27

    :goto_560
    cmp-long v13, v16, v37

    if-nez v13, :cond_5e3

    const/16 v6, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v16

    sub-long v16, v16, v29

    const/16 v6, 0x82

    move-wide/from16 v0, v16

    iput-wide v0, v9, Llt1;->l:J

    const/16 v6, 0x72

    iget-boolean v8, v9, Llt1;->k:Z

    nop

    if-nez v8, :cond_5df

    if-eqz v26, :cond_5df

    const/16 v6, 0x5b

    new-instance v8, Landroid/content/Intent;

    nop

    const/16 v6, 0x62

    invoke-direct {v8, v11}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v6, 0x4b

    invoke-virtual {v8, v14, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v10

    const/16 v6, 0x29

    move-object/from16 v0, v23

    move/from16 v1, v22

    invoke-virtual {v10, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v10

    move/from16 v13, v40

    const/16 v6, 0x29

    move-object/from16 v0, v21

    invoke-virtual {v10, v0, v13}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v10

    const/16 v6, 0x32

    iget v11, v15, Lou;->e:I

    nop

    move-object/from16 v20, v39

    const/16 v6, 0x29

    move-object/from16 v0, v20

    invoke-virtual {v10, v0, v11}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v10

    const/16 v6, 0xc0

    iget-wide v14, v9, Llt1;->l:J

    nop

    const/16 v6, 0xba

    invoke-virtual {v10, v12, v14, v15}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    move-result-object v10

    const/16 v6, 0x53

    move-object/from16 v0, v36

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v11

    const/16 v6, 0x4a

    invoke-virtual {v11}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v11

    const/16 v6, 0x64

    invoke-virtual {v10, v11}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v10

    const/high16 v11, 0x10000000

    const/16 v6, 0x59

    invoke-virtual {v10, v11}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-object/from16 v18, v36

    :goto_5d6
    const/16 v6, 0x63

    move-object/from16 v0, v18

    invoke-virtual {v0, v8}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    goto/16 :goto_3f7

    :cond_5df
    move/from16 v13, v40

    goto/16 :goto_3f7

    :cond_5e3
    move-object/from16 v18, v36

    move-object/from16 v20, v39

    move/from16 v13, v40

    :try_start_5e9
    const/16 v6, 0x391

    move-wide/from16 v0, v16

    invoke-virtual {v8, v0, v1}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->eA(J)Z

    move-result v27
    :try_end_5f1
    .catch Ljava/lang/Exception; {:try_start_5e9 .. :try_end_5f1} :catch_66d
    .catchall {:try_start_5e9 .. :try_end_5f1} :catchall_6b9

    if-nez v27, :cond_673

    :try_start_5f3
    const/16 v6, 0x3ea

    move-wide/from16 v0, v16

    invoke-virtual {v8, v0, v1}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->x(J)V
    :try_end_5fa
    .catch Ljava/lang/Exception; {:try_start_5f3 .. :try_end_5fa} :catch_66d
    .catchall {:try_start_5f3 .. :try_end_5fa} :catchall_668

    const/16 v6, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v16

    sub-long v16, v16, v29

    const/16 v6, 0x82

    move-wide/from16 v0, v16

    iput-wide v0, v9, Llt1;->l:J

    const/16 v6, 0x72

    iget-boolean v8, v9, Llt1;->k:Z

    nop

    if-nez v8, :cond_3f7

    if-eqz v26, :cond_3f7

    const/16 v6, 0x5b

    new-instance v8, Landroid/content/Intent;

    nop

    const/16 v6, 0x62

    invoke-direct {v8, v11}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v6, 0x4b

    invoke-virtual {v8, v14, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v10

    const/16 v6, 0x29

    move-object/from16 v0, v23

    move/from16 v1, v22

    invoke-virtual {v10, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v10

    const/16 v6, 0x29

    move-object/from16 v0, v21

    invoke-virtual {v10, v0, v13}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v10

    const/16 v6, 0x32

    iget v11, v15, Lou;->e:I

    nop

    const/16 v6, 0x29

    move-object/from16 v0, v20

    invoke-virtual {v10, v0, v11}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v10

    const/16 v6, 0xc0

    iget-wide v14, v9, Llt1;->l:J

    nop

    const/16 v6, 0xba

    invoke-virtual {v10, v12, v14, v15}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    move-result-object v10

    const/16 v6, 0x53

    move-object/from16 v0, v18

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v11

    const/16 v6, 0x4a

    invoke-virtual {v11}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v11

    const/16 v6, 0x64

    invoke-virtual {v10, v11}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v10

    const/high16 v11, 0x10000000

    const/16 v6, 0x59

    invoke-virtual {v10, v11}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    goto/16 :goto_5d6

    :catchall_668
    move-exception v8

    move-object/from16 v19, v18

    goto/16 :goto_769

    :catch_66d
    move-object/from16 v28, v19

    move-object/from16 v19, v18

    goto/16 :goto_7e5

    :cond_673
    move-object/from16 v34, v18

    :try_start_675
    const/16 v6, 0xab0

    move-object/from16 v0, v25

    invoke-static {v0}, Lmi2;->g(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v18
    :try_end_67d
    .catch Ljava/lang/Exception; {:try_start_675 .. :try_end_67d} :catch_6b5
    .catchall {:try_start_675 .. :try_end_67d} :catchall_6b2

    move-object/from16 v28, v19

    :try_start_67f
    const/4 v6, -0x3

    new-instance v19, Ljava/lang/StringBuilder;

    nop

    const/4 v6, -0x4

    move-object/from16 v0, v19

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x0

    move-object/from16 v0, v19

    invoke-virtual {v0, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v6, 0x49c

    move-wide/from16 v0, v16

    move-object/from16 v2, v18

    invoke-virtual {v8, v0, v1, v2}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->k(JLjava/lang/String;)Ljava/lang/String;

    move-result-object v18

    const/4 v6, 0x0

    move-object/from16 v0, v19

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, -0x2

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    const/16 v6, 0x3ea

    move-wide/from16 v0, v16

    invoke-virtual {v8, v0, v1}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->x(J)V
    :try_end_6af
    .catch Ljava/lang/Exception; {:try_start_67f .. :try_end_6af} :catch_117
    .catchall {:try_start_67f .. :try_end_6af} :catchall_6b2

    :goto_6af
    move-object/from16 v19, v34

    goto :goto_6eb

    :catchall_6b2
    move-exception v8

    goto/16 :goto_111

    :catch_6b5
    move-object/from16 v28, v19

    goto/16 :goto_117

    :catchall_6b9
    move-exception v8

    move-object/from16 v34, v18

    goto/16 :goto_111

    :catchall_6be
    move-exception v8

    move-object/from16 v34, v36

    move-object/from16 v20, v39

    move/from16 v13, v40

    goto/16 :goto_111

    :catch_6c7
    move-object/from16 v28, v19

    move-object/from16 v20, v39

    move/from16 v13, v40

    goto/16 :goto_4c0

    :cond_6cf
    move-object/from16 v28, v19

    move-object/from16 v19, v36

    move-object/from16 v20, v39

    move/from16 v13, v40

    :try_start_6d7
    const/4 v6, 0x5

    move-object/from16 v0, v18

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    const/16 v33, 0x0

    throw v33
    :try_end_6e0
    .catch Ljava/lang/Exception; {:try_start_6d7 .. :try_end_6e0} :catch_7e5
    .catchall {:try_start_6d7 .. :try_end_6e0} :catchall_6e0

    :catchall_6e0
    move-exception v8

    goto/16 :goto_769

    :catchall_6e3
    move-exception v8

    goto/16 :goto_495

    :cond_6e6
    move-object/from16 v12, v35

    move-object/from16 v20, v36

    goto :goto_6af

    :goto_6eb
    const/16 v6, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v16

    sub-long v16, v16, v29

    const/16 v6, 0x82

    move-wide/from16 v0, v16

    iput-wide v0, v9, Llt1;->l:J

    const/16 v6, 0x72

    iget-boolean v8, v9, Llt1;->k:Z

    nop

    if-nez v8, :cond_75e

    if-eqz v26, :cond_75e

    const/16 v6, 0x5b

    new-instance v8, Landroid/content/Intent;

    nop

    const/16 v6, 0x62

    invoke-direct {v8, v11}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    :goto_70c
    const/16 v6, 0x4b

    invoke-virtual {v8, v14, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v11

    const/16 v6, 0x29

    move-object/from16 v0, v23

    move/from16 v1, v22

    invoke-virtual {v11, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v11

    const/16 v6, 0x29

    move-object/from16 v0, v21

    invoke-virtual {v11, v0, v13}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v11

    const/16 v6, 0x32

    iget v14, v15, Lou;->e:I

    nop

    const/16 v6, 0x29

    move-object/from16 v0, v20

    invoke-virtual {v11, v0, v14}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v11

    const/16 v6, 0xc0

    iget-wide v14, v9, Llt1;->l:J

    nop

    const/16 v6, 0xba

    invoke-virtual {v11, v12, v14, v15}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    move-result-object v11

    const/16 v6, 0x53

    move-object/from16 v0, v19

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v12

    const/16 v6, 0x4a

    invoke-virtual {v12}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v12

    const/16 v6, 0x64

    invoke-virtual {v11, v12}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v11

    const/high16 v12, 0x10000000

    const/16 v6, 0x59

    invoke-virtual {v11, v12}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/16 v6, 0x63

    move-object/from16 v0, v19

    invoke-virtual {v0, v8}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    :cond_75e
    move-object/from16 v19, v10

    goto/16 :goto_808

    :catchall_762
    move-exception v8

    move-object/from16 v41, v19

    move-object/from16 v19, v12

    move-object/from16 v12, v41

    :goto_769
    const/16 v6, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v16

    sub-long v16, v16, v29

    const/16 v6, 0x82

    move-wide/from16 v0, v16

    iput-wide v0, v9, Llt1;->l:J

    const/16 v6, 0x72

    iget-boolean v6, v9, Llt1;->k:Z

    move/16 v16, v6

    if-nez v16, :cond_7e4

    if-eqz v26, :cond_7e4

    const/16 v6, 0x5b

    new-instance v16, Landroid/content/Intent;

    nop

    const/16 v6, 0x62

    move-object/from16 v0, v16

    invoke-direct {v0, v11}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v6, 0x4b

    move-object/from16 v0, v16

    invoke-virtual {v0, v14, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v10

    const/16 v6, 0x29

    move-object/from16 v0, v23

    move/from16 v1, v22

    invoke-virtual {v10, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v10

    const/16 v6, 0x29

    move-object/from16 v0, v21

    invoke-virtual {v10, v0, v13}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v10

    const/16 v6, 0x32

    iget v11, v15, Lou;->e:I

    nop

    const/16 v6, 0x29

    move-object/from16 v0, v20

    invoke-virtual {v10, v0, v11}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v10

    const/16 v6, 0xc0

    iget-wide v13, v9, Llt1;->l:J

    nop

    const/16 v6, 0xba

    invoke-virtual {v10, v12, v13, v14}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    move-result-object v9

    const/16 v6, 0x53

    move-object/from16 v0, v19

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v10

    const/16 v6, 0x4a

    invoke-virtual {v10}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v10

    const/16 v6, 0x64

    invoke-virtual {v9, v10}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v9

    const/high16 v11, 0x10000000

    const/16 v6, 0x59

    invoke-virtual {v9, v11}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/16 v6, 0x63

    move-object/from16 v0, v19

    move-object/from16 v1, v16

    invoke-virtual {v0, v1}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    :cond_7e4
    throw v8

    :catch_7e5
    :goto_7e5
    const/16 v6, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v16

    sub-long v16, v16, v29

    const/16 v6, 0x82

    move-wide/from16 v0, v16

    iput-wide v0, v9, Llt1;->l:J

    const/16 v6, 0x72

    iget-boolean v8, v9, Llt1;->k:Z

    nop

    if-nez v8, :cond_75e

    if-eqz v26, :cond_75e

    const/16 v6, 0x5b

    new-instance v8, Landroid/content/Intent;

    nop

    const/16 v6, 0x62

    invoke-direct {v8, v11}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    goto/16 :goto_70c

    :goto_808
    const/16 v6, 0x245

    new-instance v8, Ljt1;

    nop

    const/16 v18, 0x0

    const/16 v20, 0x0

    const/16 v6, 0x1c7

    move-object/from16 v0, v18

    move/from16 v1, v20

    invoke-direct {v8, v9, v0, v1}, Ljt1;-><init>(Llt1;Lvx;I)V

    move-object/from16 v10, v28

    const/4 v11, 0x3

    const/16 v6, 0xb3

    move v0, v6

    move-object v1, v10

    move-object/from16 v2, v18

    move-object/from16 v3, v18

    move-object v4, v8

    move v5, v11

    invoke-static/range {v1 .. v5}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    const/16 v17, 0x1

    :goto_82c
    move/from16 v0, v17

    if-eq v13, v0, :cond_837

    const/4 v8, 0x2

    if-ne v13, v8, :cond_834

    goto :goto_837

    :catch_834
    :cond_834
    :goto_834
    const/4 v8, 0x4

    goto/16 :goto_98c

    :cond_837
    :goto_837
    :try_start_837
    move/from16 v0, v17

    new-array v8, v0, [C

    aput-char v31, v8, v20

    const/16 v6, 0x31

    move-object/from16 v0, v19

    invoke-static {v0, v8}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v8

    const/16 v6, 0x24

    move/from16 v0, v20

    invoke-interface {v8, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    move/from16 v0, v17

    new-array v10, v0, [C

    aput-char v31, v10, v20

    const/16 v6, 0x31

    move-object/from16 v0, v19

    invoke-static {v0, v10}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v10

    const/16 v6, 0x24

    move/from16 v0, v17

    invoke-interface {v10, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    const/16 v6, 0x8e

    invoke-static {v10}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v10

    const/16 v6, 0x47

    invoke-virtual {v8}, Ljava/lang/String;->length()I

    move-result v11

    const/16 v32, 0x2

    add-int/lit8 v11, v11, 0x2

    const/16 v6, 0x262

    invoke-static {v10}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v10

    const/16 v6, 0x47

    invoke-virtual {v10}, Ljava/lang/String;->length()I

    move-result v10

    add-int/2addr v11, v10

    const/16 v20, 0x0

    const/16 v6, 0x21c

    move-object/from16 v0, v19

    move/from16 v1, v20

    invoke-static {v0, v1, v11}, Lc72;->z0(Ljava/lang/CharSequence;II)Ljava/lang/CharSequence;

    move-result-object v10

    const/16 v6, 0xcb

    invoke-virtual {v10}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v10

    const-string/jumbo v11, ":"

    check-cast v11, Ljava/lang/String;

    filled-new-array {v11}, [Ljava/lang/String;

    move-result-object v11

    const/16 v16, 0x6

    const/16 v6, 0x89

    move/from16 v0, v16

    invoke-static {v10, v11, v0}, Lc72;->E0(Ljava/lang/CharSequence;[Ljava/lang/String;I)Ljava/util/List;

    move-result-object v10

    const/16 v6, 0x17d

    invoke-interface {v10}, Ljava/util/List;->size()I

    move-result v11

    const/16 v12, 0x8

    if-ge v11, v12, :cond_8b5

    goto/16 :goto_995

    :cond_8b5
    const/16 v17, 0x1

    const/16 v6, 0x24

    move/from16 v0, v17

    invoke-interface {v10, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Ljava/lang/String;

    const/16 v6, 0x8e

    invoke-static {v11}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v11

    const v12, 0xea60

    mul-int/2addr v11, v12

    int-to-long v14, v11

    const/16 v6, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v16

    add-long v14, v14, v16

    const/4 v11, 0x2

    const/16 v6, 0x24

    invoke-interface {v10, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    const/16 v6, 0x8e

    invoke-static {v10}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v10

    mul-int/2addr v10, v12

    int-to-long v10, v10

    const/16 v6, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v16

    add-long v10, v10, v16

    const/16 v6, 0xb97

    iget-object v12, v9, Llt1;->b:Landroid/content/SharedPreferences;

    nop

    const/16 v6, 0x7a

    invoke-interface {v12}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v12

    const/4 v6, -0x3

    new-instance v16, Ljava/lang/StringBuilder;

    nop

    const/4 v6, -0x4

    move-object/from16 v0, v16

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v17, "~bsr"

    const/4 v6, 0x0

    move-object/from16 v0, v16

    move-object/from16 v1, v17

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v17, "."

    check-cast v17, Ljava/lang/String;

    filled-new-array/range {v17 .. v17}, [Ljava/lang/String;

    move-result-object v17

    const/16 v18, 0x6

    const/16 v6, 0x89

    move-object/from16 v0, v17

    move/from16 v1, v18

    invoke-static {v8, v0, v1}, Lc72;->E0(Ljava/lang/CharSequence;[Ljava/lang/String;I)Ljava/util/List;

    move-result-object v8

    const/16 v6, 0x535

    invoke-static {v8}, Lbs;->k0(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    const/4 v6, 0x0

    move-object/from16 v0, v16

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v8, 0x78

    const/16 v6, 0x1b

    move-object/from16 v0, v16

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v6, -0x2

    move-object/from16 v0, v16

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    const/16 v6, 0x511

    invoke-static {v8}, Lc72;->B0(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const/16 v6, 0xcb

    invoke-virtual {v8}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v8

    const/4 v6, -0x3

    new-instance v16, Ljava/lang/StringBuilder;

    nop

    const/4 v6, -0x4

    move-object/from16 v0, v16

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v6, 0x83

    move-object/from16 v0, v16

    invoke-virtual {v0, v14, v15}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/16 v14, 0x7e

    const/16 v6, 0x1b

    move-object/from16 v0, v16

    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v6, 0x83

    move-object/from16 v0, v16

    invoke-virtual {v0, v10, v11}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v6, -0x2

    move-object/from16 v0, v16

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    const/16 v6, 0x511

    invoke-static {v10}, Lc72;->B0(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    const/16 v6, 0xcb

    invoke-virtual {v10}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v10

    const/16 v6, 0x3c

    invoke-interface {v12, v8, v10}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v6, 0x6f

    invoke-interface {v12}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_98a
    .catch Ljava/lang/Exception; {:try_start_837 .. :try_end_98a} :catch_834

    goto/16 :goto_834

    :goto_98c
    if-ne v13, v8, :cond_995

    :try_start_98e
    const/16 v6, 0xfd8

    move-object/from16 v0, v19

    invoke-virtual {v9, v0}, Llt1;->b(Ljava/lang/String;)V
    :try_end_995
    .catch Ljava/lang/Exception; {:try_start_98e .. :try_end_995} :catch_995

    :catch_995
    :cond_995
    :goto_995
    return-void
.end method
