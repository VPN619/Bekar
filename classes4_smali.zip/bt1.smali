.class public final Lbt1;
.super Landroid/os/CountDownTimer;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;

.field public b:Z

.field public c:Z


# direct methods
.method public constructor <init>(Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;J)V
    .registers 8

    const-wide/16 v2, 0x3e8

    invoke-direct {p0, p2, p3, v2, v3}, Landroid/os/CountDownTimer;-><init>(JJ)V

    const/16 v0, 0x10cb

    iput-object p1, p0, Lbt1;->a:Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;

    return-void
.end method


# virtual methods
.method public final onFinish()V
    .registers 7

    .prologue
    const/16 v1, 0x6b0

    iget-object v3, p0, Lbt1;->a:Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;

    nop

    const/16 v1, 0x232

    invoke-virtual {v3}, Landroid/app/Activity;->isDestroyed()Z

    move-result v4

    if-nez v4, :cond_48

    const/16 v1, 0x117b

    iget-boolean v4, p0, Lbt1;->c:Z

    nop

    if-eqz v4, :cond_15

    goto :goto_48

    :cond_15
    const-wide/16 v4, 0x0

    const/16 v1, 0x10cd

    iput-wide v4, v3, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->w:J

    const/4 v4, 0x1

    const/16 v1, 0x705

    iput-boolean v4, p0, Lbt1;->b:Z

    const/16 v1, 0x22b

    sget-object p0, Lg4;->A:Lxu1;

    nop

    if-eqz p0, :cond_38

    const/16 v1, 0x22e

    new-instance p0, Lzs1;

    nop

    const/4 v4, 0x0

    const/16 v1, 0x1d4

    invoke-direct {p0, v3, v4}, Lzs1;-><init>(Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;I)V

    const/16 v1, 0x147

    invoke-virtual {v3, p0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void

    :cond_38
    const/16 v1, 0x22e

    new-instance p0, Lzs1;

    nop

    const/4 v4, 0x3

    const/16 v1, 0x1d4

    invoke-direct {p0, v3, v4}, Lzs1;-><init>(Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;I)V

    const/16 v1, 0x147

    invoke-virtual {v3, p0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    :cond_48
    :goto_48
    return-void
.end method

.method public final onTick(J)V
    .registers 13

    .prologue
    const/16 v1, 0x6b0

    iget-object v3, p0, Lbt1;->a:Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;

    nop

    const/16 v1, 0x10cd

    iput-wide p1, v3, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->w:J

    const/16 v1, 0x232

    invoke-virtual {v3}, Landroid/app/Activity;->isDestroyed()Z

    move-result p1

    if-nez p1, :cond_a7

    const/16 v1, 0x117b

    iget-boolean p0, p0, Lbt1;->c:Z

    nop

    if-nez p0, :cond_a7

    const/16 v1, 0x6ff

    iget-boolean p0, v3, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->C:Z

    nop

    if-nez p0, :cond_21

    goto/16 :goto_a7

    :cond_21
    const/16 v1, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide p0

    const/16 v1, 0x2e6

    sget-wide v4, Lg4;->l:J

    nop

    sub-long/2addr p0, v4

    const/16 v1, 0x5f5

    sget-wide v4, Lg4;->k:J

    nop

    const/16 v1, 0x2e6

    sget-wide v6, Lg4;->l:J

    nop

    sub-long/2addr v4, v6

    const-wide/16 v6, 0x0

    cmp-long p2, p0, v6

    if-lez p2, :cond_a7

    cmp-long p2, v4, v6

    if-gtz p2, :cond_43

    goto :goto_a7

    :cond_43
    const-wide/16 v6, 0x64

    mul-long/2addr v6, p0

    div-long/2addr v6, v4

    long-to-int p2, v6

    const/16 v1, 0x6d6

    new-instance v8, Ltu0;

    nop

    const/4 v9, 0x2

    const/16 v1, 0x71e

    invoke-direct {v8, v3, p2, v9}, Ltu0;-><init>(Ljava/lang/Object;II)V

    const/16 v1, 0x147

    invoke-virtual {v3, v8}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    const/4 v1, -0x3

    new-instance p2, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v8, "Progresso["

    const/16 v1, 0x97

    invoke-direct {p2, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v1, 0x83

    invoke-virtual {p2, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string/jumbo v6, "%] exibidoA["

    const/4 v1, 0x0

    invoke-virtual {p2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-wide/16 v6, 0x3e8

    div-long/2addr p0, v6

    const/16 v1, 0x83

    invoke-virtual {p2, p0, p1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string/jumbo p0, "s] delayTotal["

    const/4 v1, 0x0

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    div-long/2addr v4, v6

    const/16 v1, 0x83

    invoke-virtual {p2, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string/jumbo p0, "s] renewWOAdTL["

    const/4 v1, 0x0

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v1, 0x33c

    iget-wide p0, v3, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->w:J

    nop

    div-long/2addr p0, v6

    const/16 v1, 0x83

    invoke-virtual {p2, p0, p1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string/jumbo p0, "s]"

    const/4 v1, 0x0

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, -0x2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string/jumbo p1, "Renew"

    nop

    :cond_a7
    :goto_a7
    return-void
.end method
