.class public final Le12;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public final synthetic t:I

.field public u:I

.field public final synthetic v:Lg12;


# direct methods
.method public synthetic constructor <init>(Lg12;Lvx;I)V
    .registers 6

    iput p3, p0, Le12;->t:I

    iput-object p1, p0, Le12;->v:Lg12;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 6

    .prologue
    const/16 v0, 0x819

    iget p2, p0, Le12;->t:I

    nop

    const/16 v0, 0xdb3

    iget-object p0, p0, Le12;->v:Lg12;

    nop

    packed-switch p2, :pswitch_data_38

    const/16 v0, 0x1f0

    new-instance p2, Le12;

    nop

    const/4 v2, 0x2

    const/16 v0, 0x21b

    invoke-direct {p2, p0, p1, v2}, Le12;-><init>(Lg12;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_1b  #0x1
    const/16 v0, 0x1f0

    new-instance p2, Le12;

    nop

    const/4 v2, 0x1

    const/16 v0, 0x21b

    invoke-direct {p2, p0, p1, v2}, Le12;-><init>(Lg12;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_29  #0x0
    const/16 v0, 0x1f0

    new-instance p2, Le12;

    nop

    const/4 v2, 0x0

    const/16 v0, 0x21b

    invoke-direct {p2, p0, p1, v2}, Le12;-><init>(Lg12;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    nop

    :pswitch_data_38
    .packed-switch 0x0
        :pswitch_29  #00000000
        :pswitch_1b  #00000001
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7

    .prologue
    const/16 v0, 0x819

    iget v2, p0, Le12;->t:I

    nop

    const/16 v0, 0x21

    sget-object v3, Lrg2;->a:Lrg2;

    nop

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    packed-switch v2, :pswitch_data_3e

    const/16 v0, 0x1c5

    invoke-virtual {p0, p2, p1}, Le12;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Le12;

    const/16 v0, 0x1a0

    invoke-virtual {p0, v3}, Le12;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_20  #0x1
    const/16 v0, 0x1c5

    invoke-virtual {p0, p2, p1}, Le12;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Le12;

    const/16 v0, 0x1a0

    invoke-virtual {p0, v3}, Le12;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_2f  #0x0
    const/16 v0, 0x1c5

    invoke-virtual {p0, p2, p1}, Le12;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Le12;

    const/16 v0, 0x1a0

    invoke-virtual {p0, v3}, Le12;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_data_3e
    .packed-switch 0x0
        :pswitch_2f  #00000000
        :pswitch_20  #00000001
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 33

    .prologue
    move-object/from16 v10, p0

    const/16 v8, 0x819

    iget v11, v10, Le12;->t:I

    nop

    const/16 v8, 0xdb3

    iget-object v12, v10, Le12;->v:Lg12;

    nop

    const-string/jumbo v13, "call to \'resume\' before \'invoke\' with coroutine"

    const/16 v8, 0x15

    sget-object v14, Lwy;->a:Lwy;

    nop

    const/16 v8, 0x21

    sget-object v15, Lrg2;->a:Lrg2;

    nop

    const/16 v16, 0x0

    const/16 v17, 0x1

    packed-switch v11, :pswitch_data_2a6

    const/16 v8, 0x1f2

    iget v11, v10, Le12;->u:I

    nop

    if-eqz v11, :cond_3a

    move/from16 v0, v17

    if-ne v11, v0, :cond_32

    const/4 v8, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_66

    :cond_32
    const/16 v8, 0x13

    invoke-static {v13}, Lz6;->w(Ljava/lang/String;)V

    move-object/from16 v14, v16

    goto :goto_67

    :cond_3a
    const/4 v8, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v8, 0x273

    move/from16 v0, v17

    iput v0, v10, Le12;->u:I

    const/16 v8, 0x132

    sget-object v11, Lh50;->a:Li20;

    nop

    const/16 v8, 0x1f0

    new-instance v13, Le12;

    nop

    const/16 v8, 0x21b

    move-object/from16 v0, v16

    move/from16 v1, v17

    invoke-direct {v13, v12, v0, v1}, Le12;-><init>(Lg12;Lvx;I)V

    const/16 v8, 0x121

    invoke-static {v11, v13, v10}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object v10

    if-ne v10, v14, :cond_62

    goto :goto_63

    :cond_62
    move-object v10, v15

    :goto_63
    if-ne v10, v14, :cond_66

    goto :goto_67

    :cond_66
    :goto_66
    move-object v14, v15

    :goto_67
    check-cast v14, Ljava/lang/Object;

    return-object v14

    :pswitch_6a  #0x1
    const/16 v8, 0x1f2

    iget v11, v10, Le12;->u:I

    nop

    if-eqz v11, :cond_86

    move/from16 v0, v17

    if-ne v11, v0, :cond_7d

    const/4 v8, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    goto/16 :goto_256

    :cond_7d
    const/16 v8, 0x13

    invoke-static {v13}, Lz6;->w(Ljava/lang/String;)V

    move-object/from16 v14, v16

    goto/16 :goto_257

    :cond_86
    const/4 v8, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v8, 0x131

    invoke-virtual {v12}, Lg12;->d()Landroid/content/SharedPreferences;

    move-result-object v11

    const/4 v8, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v8, 0x1c6

    invoke-virtual {v12}, Landroidx/fragment/app/Fragment;->getResources()Landroid/content/res/Resources;

    move-result-object v13

    const/4 v8, -0x6

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v8, 0x1b1

    iget-boolean v8, v12, Lg12;->r:Z

    move/16 v18, v8

    const/16 v19, 0x0

    if-eqz v18, :cond_ae

    const/16 v18, 0x3

    goto :goto_b0

    :cond_ae
    move/from16 v18, v19

    :goto_b0
    const/16 v8, 0x4fe

    move/from16 v0, v18

    invoke-static {v11, v13, v0}, Lqk;->p(Landroid/content/SharedPreferences;Landroid/content/res/Resources;I)[Ljava/lang/String;

    move-result-object v11

    array-length v13, v11

    const/16 v8, 0x218

    move/from16 v0, v17

    invoke-static {v11, v0, v13}, Laf;->h0([Ljava/lang/Object;II)[Ljava/lang/Object;

    move-result-object v11

    const/16 v8, 0x131

    invoke-virtual {v12}, Lg12;->d()Landroid/content/SharedPreferences;

    move-result-object v13

    const-string/jumbo v18, "server"

    const/16 v8, 0xb0

    move-object/from16 v0, v18

    move/from16 v1, v19

    invoke-interface {v13, v0, v1}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v13

    sub-int v13, v13, v17

    const/16 v8, 0xd7

    new-instance v18, Ljava/util/ArrayList;

    nop

    const/16 v8, 0x16b

    move-object/from16 v0, v18

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    array-length v0, v11

    move/from16 v21, v0

    move/from16 v22, v19

    :goto_e7
    move/from16 v0, v22

    move/from16 v1, v21

    if-ge v0, v1, :cond_226

    aget-object v23, v11, v22

    check-cast v23, Ljava/lang/String;

    const/16 v8, 0x52b

    sget-object v24, Ldz;->a:Lcz;

    nop

    const/16 v24, 0x2

    const/16 v8, 0x196

    move/from16 v0, v24

    move-object/from16 v1, v23

    invoke-static {v0, v1}, Lc72;->G0(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v24

    const/16 v8, 0x1f7

    sget-object v25, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    nop

    const/16 v8, 0x3b0

    move-object/from16 v0, v24

    move-object/from16 v1, v25

    invoke-virtual {v0, v1}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v24

    const/4 v8, -0x6

    move-object/from16 v0, v24

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v8, 0x334

    move-object/from16 v0, v24

    invoke-static {v0}, Ldz;->a(Ljava/lang/String;)Lcz;

    move-result-object v24

    const/16 v8, 0x3c6

    move-object/from16 v0, v24

    iget v8, v0, Lcz;->a:I

    move/16 v16, v8

    const/16 v8, 0x36f

    move-object/from16 v0, v24

    iget v8, v0, Lcz;->b:I

    move/16 v24, v8

    const/16 v8, 0x1159

    new-instance v26, La12;

    nop

    move/from16 v0, v17

    new-array v0, v0, [C

    move-object/from16 v20, v0

    const/16 v27, 0x2e

    aput-char v27, v20, v19

    const/16 v8, 0x31

    move-object/from16 v0, v23

    move-object/from16 v1, v20

    invoke-static {v0, v1}, Lc72;->D0(Ljava/lang/CharSequence;[C)Ljava/util/List;

    move-result-object v20

    const/16 v8, 0x24

    move-object/from16 v0, v20

    move/from16 v1, v19

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v20

    check-cast v20, Ljava/lang/String;

    const/16 v8, 0x12d

    move-object/from16 v0, v20

    move-object/from16 v1, v25

    invoke-virtual {v0, v1}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v27

    const/4 v8, -0x6

    move-object/from16 v0, v27

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v8, 0x4c

    move/from16 v0, v24

    invoke-virtual {v12, v0}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v28

    const/4 v8, -0x6

    move-object/from16 v0, v28

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v8, 0x1ed

    move-object/from16 v0, v23

    invoke-static {v0, v11}, Laf;->l0(Ljava/lang/Object;[Ljava/lang/Object;)I

    move-result v20

    const-string/jumbo v24, "psrvslctd"

    move/from16 v0, v20

    if-ne v13, v0, :cond_1a0

    const/16 v8, 0x1b1

    iget-boolean v8, v12, Lg12;->r:Z

    move/16 v20, v8

    if-eqz v20, :cond_1a0

    const/16 v8, 0x131

    invoke-virtual {v12}, Lg12;->d()Landroid/content/SharedPreferences;

    move-result-object v20

    const/16 v8, 0x77

    move-object/from16 v0, v20

    move-object/from16 v1, v24

    move/from16 v2, v19

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v20

    if-nez v20, :cond_1c9

    :cond_1a0
    const/16 v8, 0x1ed

    move-object/from16 v0, v23

    invoke-static {v0, v11}, Laf;->l0(Ljava/lang/Object;[Ljava/lang/Object;)I

    move-result v20

    move/from16 v0, v20

    if-ne v13, v0, :cond_1cc

    const/16 v8, 0x1b1

    iget-boolean v8, v12, Lg12;->r:Z

    move/16 v20, v8

    if-nez v20, :cond_1cc

    const/16 v8, 0x131

    invoke-virtual {v12}, Lg12;->d()Landroid/content/SharedPreferences;

    move-result-object v20

    const/16 v8, 0x77

    move-object/from16 v0, v20

    move-object/from16 v1, v24

    move/from16 v2, v19

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v20

    if-nez v20, :cond_1cc

    :cond_1c9
    move/from16 v29, v17

    goto :goto_1ce

    :cond_1cc
    move/from16 v29, v19

    :goto_1ce
    const/16 v8, 0x307

    sget-boolean v20, Lmi2;->k:Z

    nop

    if-eqz v20, :cond_1fe

    const/16 v8, 0x272

    sget-object v20, Lmi2;->m:Ljava/lang/String;

    nop

    const/16 v8, 0x84

    move-object/from16 v0, v20

    move-object/from16 v1, v23

    invoke-static {v0, v1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v20

    if-eqz v20, :cond_1fe

    const/16 v8, 0x1ff

    sget v20, Lmi2;->o:I

    nop

    const/16 v24, 0x3

    move/from16 v0, v20

    move/from16 v1, v24

    if-ne v0, v1, :cond_200

    move/from16 v30, v17

    :goto_1f5
    move/from16 v25, v16

    move/from16 v16, v24

    move-object/from16 v24, v26

    move-object/from16 v26, v23

    goto :goto_203

    :cond_1fe
    const/16 v24, 0x3

    :cond_200
    move/from16 v30, v19

    goto :goto_1f5

    :goto_203
    const/16 v8, 0x893

    move v0, v8

    move-object/from16 v1, v24

    move/from16 v2, v25

    move-object/from16 v3, v26

    move-object/from16 v4, v27

    move-object/from16 v5, v28

    move/from16 v6, v29

    move/from16 v7, v30

    invoke-direct/range {v1 .. v7}, La12;-><init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZ)V

    const/16 v8, 0x174

    move-object/from16 v0, v18

    move-object/from16 v1, v24

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v22, v22, 0x1

    const/16 v16, 0x0

    goto/16 :goto_e7

    :cond_226
    const/16 v8, 0x132

    sget-object v11, Lh50;->a:Li20;

    nop

    const/16 v8, 0x124a

    sget-object v11, Lh51;->a:Lum0;

    nop

    const/16 v8, 0x1215

    new-instance v13, Lb11;

    nop

    const/16 v16, 0x5

    const/16 v19, 0x0

    const/16 v8, 0xc74

    move v0, v8

    move-object v1, v13

    move-object v2, v12

    move-object/from16 v3, v18

    move-object/from16 v4, v19

    move/from16 v5, v16

    invoke-direct/range {v1 .. v5}, Lb11;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lvx;I)V

    const/16 v8, 0x273

    move/from16 v0, v17

    iput v0, v10, Le12;->u:I

    const/16 v8, 0x121

    invoke-static {v11, v13, v10}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object v10

    if-ne v10, v14, :cond_256

    goto :goto_257

    :cond_256
    :goto_256
    move-object v14, v15

    :goto_257
    check-cast v14, Ljava/lang/Object;

    return-object v14

    :pswitch_25a  #0x0
    const/16 v8, 0x1f2

    iget v11, v10, Le12;->u:I

    nop

    if-eqz v11, :cond_273

    move/from16 v0, v17

    if-ne v11, v0, :cond_26c

    const/4 v8, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_2a1

    :cond_26c
    const/16 v8, 0x13

    invoke-static {v13}, Lz6;->w(Ljava/lang/String;)V

    const/4 v14, 0x0

    goto :goto_2a2

    :cond_273
    const/4 v8, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v8, 0x273

    move/from16 v0, v17

    iput v0, v10, Le12;->u:I

    const/16 v8, 0x132

    sget-object v11, Lh50;->a:Li20;

    nop

    const/16 v8, 0x1f0

    new-instance v13, Le12;

    nop

    const/16 v19, 0x0

    const/16 v8, 0x21b

    move-object/from16 v0, v19

    move/from16 v1, v17

    invoke-direct {v13, v12, v0, v1}, Le12;-><init>(Lg12;Lvx;I)V

    const/16 v8, 0x121

    invoke-static {v11, v13, v10}, Lg73;->R(Lly;Lpk0;Lvx;)Ljava/lang/Object;

    move-result-object v10

    if-ne v10, v14, :cond_29d

    goto :goto_29e

    :cond_29d
    move-object v10, v15

    :goto_29e
    if-ne v10, v14, :cond_2a1

    goto :goto_2a2

    :cond_2a1
    :goto_2a1
    move-object v14, v15

    :goto_2a2
    check-cast v14, Ljava/lang/Object;

    return-object v14

    nop

    :pswitch_data_2a6
    .packed-switch 0x0
        :pswitch_25a  #00000000
        :pswitch_6a  #00000001
    .end packed-switch
.end method
