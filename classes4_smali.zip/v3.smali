.class public final synthetic Lv3;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Z

.field public final synthetic c:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lcom/mbridge/msdk/system/a;Z)V
    .registers 6

    const/4 v2, 0x1

    iput v2, p0, Lv3;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x9b0

    iput-object p1, p0, Lv3;->c:Ljava/lang/Object;

    const/16 v0, 0xf75

    iput-boolean p2, p0, Lv3;->b:Z

    return-void
.end method

.method public synthetic constructor <init>(ZLandroid/content/SharedPreferences;)V
    .registers 6

    const/4 v2, 0x0

    iput v2, p0, Lv3;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0xf75

    iput-boolean p1, p0, Lv3;->b:Z

    const/16 v0, 0x9b0

    iput-object p2, p0, Lv3;->c:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 24

    .prologue
    const/16 v11, 0xe18

    move-object/from16 v0, p0

    iget v13, v0, Lv3;->a:I

    nop

    const/16 v11, 0xbf0

    move-object/from16 v0, p0

    iget-boolean v14, v0, Lv3;->b:Z

    nop

    const/16 v11, 0x991

    move-object/from16 v0, p0

    iget-object v11, v0, Lv3;->c:Ljava/lang/Object;

    move-object/16 p0, v11

    packed-switch v13, :pswitch_data_d8

    check-cast p0, Lcom/mbridge/msdk/system/a;

    const/16 v11, 0xcc9

    move-object/from16 v0, p0

    invoke-static {v0, v14}, Lcom/mbridge/msdk/system/a;->d(Lcom/mbridge/msdk/system/a;Z)V

    return-void

    :pswitch_24  #0x0
    check-cast p0, Landroid/content/SharedPreferences;

    if-eqz v14, :cond_37

    const/16 v11, 0x140

    sget-boolean v13, Lg4;->a:Z

    nop

    const/16 v11, 0xfa8

    move-object/from16 v0, p0

    invoke-static {v0}, Lg4;->g(Landroid/content/SharedPreferences;)Z

    move-result p0

    if-eqz p0, :cond_c8

    :cond_37
    const/16 v11, 0x195

    sget-boolean p0, Lmi2;->d:Z

    nop

    if-nez p0, :cond_45

    const/16 v11, 0xf11

    sget-boolean p0, Lmi2;->e:Z

    nop

    if-eqz p0, :cond_c8

    :cond_45
    const/16 v11, 0x22b

    sget-object p0, Lg4;->A:Lxu1;

    nop

    if-nez p0, :cond_c8

    const/16 v11, 0x75a

    sget-object v14, Lg4;->h:Ljava/lang/String;

    nop

    const/4 v11, -0x6

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v11, 0x48a

    new-instance v15, Ljava/util/LinkedHashSet;

    nop

    const/16 v11, 0x3f9

    invoke-direct {v15}, Ljava/util/LinkedHashSet;-><init>()V

    const/16 v11, 0x160

    new-instance v17, Ljava/util/LinkedHashMap;

    nop

    const/16 v11, 0x158

    move-object/from16 v0, v17

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    const/16 v11, 0x108

    new-instance v18, Landroid/os/Bundle;

    nop

    const/16 v11, 0x198

    move-object/from16 v0, v18

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/16 v11, 0x167

    new-instance v19, Ljava/util/HashSet;

    nop

    const/16 v11, 0x13f

    move-object/from16 v0, v19

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    const/16 v11, 0x167

    new-instance v20, Ljava/util/HashSet;

    nop

    const/16 v11, 0x13f

    move-object/from16 v0, v20

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    const/16 v11, 0x160

    new-instance v21, Ljava/util/LinkedHashMap;

    nop

    const/16 v11, 0x158

    move-object/from16 v0, v21

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    const/16 v11, 0x28c

    new-instance v13, Lm4;

    nop

    const/16 v16, 0x0

    const/16 v22, 0x0

    const/16 v11, 0x4a4

    move v0, v11

    move-object v1, v13

    move-object v2, v14

    move-object v3, v15

    move-object/from16 v4, v16

    move-object/from16 v5, v17

    move-object/from16 v6, v18

    move-object/from16 v7, v19

    move-object/from16 v8, v20

    move-object/from16 v9, v21

    move-object/from16 v10, v22

    invoke-direct/range {v1 .. v10}, Lm4;-><init>(Ljava/lang/String;Ljava/util/LinkedHashSet;Ljava/lang/String;Ljava/util/LinkedHashMap;Landroid/os/Bundle;Ljava/util/HashSet;Ljava/util/HashSet;Ljava/util/LinkedHashMap;Ljava/lang/String;)V

    const/16 v11, 0xb49

    sget-object p0, Lg4;->D:Ln8;

    nop

    const/16 v11, 0x5bd

    move-object/from16 v0, p0

    invoke-static {v13, v0}, Lvp1;->k(Lm4;Lk4;)V

    goto :goto_d7

    :cond_c8
    const-string/jumbo p0, "Ads-Load"

    const-string/jumbo v13, "O carregamento do Rewarded foi cancelado, pois o servidor conectado já tem muito tempo disponível..."

    nop

    const/16 p0, 0x0

    const/16 v11, 0x1178

    move/from16 v0, p0

    sput-boolean v0, Lg4;->B:Z

    :goto_d7
    return-void

    :pswitch_data_d8
    .packed-switch 0x0
        :pswitch_24  #00000000
    .end packed-switch
.end method
