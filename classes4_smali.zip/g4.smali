.class public final Lg4;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static A:Lxu1;

.field public static B:Z

.field public static C:I

.field public static final D:Ln8;

.field public static a:Z

.field public static b:Z

.field public static final c:Ljava/util/List;

.field public static final d:Ljava/lang/String;

.field public static final e:Ljava/lang/String;

.field public static final f:Ljava/lang/String;

.field public static final g:Ljava/lang/String;

.field public static final h:Ljava/lang/String;

.field public static i:J

.field public static j:Z

.field public static k:J

.field public static l:J

.field public static final m:Ljava/util/ArrayList;

.field public static n:Lx4;

.field public static o:Ls4;

.field public static p:Z

.field public static q:I

.field public static final r:Lvp1;

.field public static s:Lce;

.field public static t:Z

.field public static u:I

.field public static final v:Lkn0;

.field public static w:Let0;

.field public static x:Z

.field public static y:I

.field public static final z:Lms1;


# direct methods
.method static constructor <clinit>()V
    .registers 8

    const-string/jumbo v6, "FCF3E6FC01FA56BEDD21F7E1615EF017"

    const-string/jumbo v7, "2DE6E0CE70F9EBA865B279693B4B7EBB"

    const-string/jumbo v2, "F0A6450349273DDA558187A993979325"

    const-string/jumbo v3, "D31AA9D8CF6C1EFF949B3D87EB02167F"

    const-string/jumbo v4, "1F0F82AACDBCFB075D29E42DEBAA911E"

    const-string/jumbo v5, "1D3EC922C9DB6C4120788C3D20B46407"

    check-cast v2, Ljava/lang/String;

    check-cast v3, Ljava/lang/String;

    check-cast v4, Ljava/lang/String;

    check-cast v5, Ljava/lang/String;

    check-cast v6, Ljava/lang/String;

    check-cast v7, Ljava/lang/String;

    filled-new-array/range {v2 .. v7}, [Ljava/lang/String;

    move-result-object v2

    const/16 v0, 0x7a6

    invoke-static {v2}, Lcs;->U([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v2

    check-cast v2, Ljava/util/List;

    sput-object v2, Lg4;->c:Ljava/util/List;

    const-string/jumbo v2, "ca-app-pub-8711044771139045~3669822786"

    sput-object v2, Lg4;->d:Ljava/lang/String;

    const-string/jumbo v2, "ca-app-pub-8711044771139045/4593397451"

    sput-object v2, Lg4;->e:Ljava/lang/String;

    const-string/jumbo v2, "ca-app-pub-8711044771139045/6098050813"

    sput-object v2, Lg4;->f:Ljava/lang/String;

    const-string/jumbo v2, "ca-app-pub-8711044771139045/6027418533"

    sput-object v2, Lg4;->g:Ljava/lang/String;

    const-string/jumbo v2, "ca-app-pub-8711044771139045/4920700510"

    sput-object v2, Lg4;->h:Ljava/lang/String;

    const/16 v0, 0xd7

    new-instance v2, Ljava/util/ArrayList;

    nop

    const/16 v0, 0x16b

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    check-cast v2, Ljava/util/ArrayList;

    sput-object v2, Lg4;->m:Ljava/util/ArrayList;

    const/16 v0, 0x868

    sget-object v2, Ls4;->h:Ls4;

    nop

    check-cast v2, Ls4;

    sput-object v2, Lg4;->o:Ls4;

    const/16 v0, 0x70d

    new-instance v2, Lvp1;

    nop

    const/16 v0, 0x21a

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    check-cast v2, Lvp1;

    sput-object v2, Lg4;->r:Lvp1;

    const/16 v0, 0x66a

    new-instance v2, Lkn0;

    nop

    const/16 v3, 0x11

    const/16 v0, 0x1242

    invoke-direct {v2, v3}, Lkn0;-><init>(I)V

    check-cast v2, Lkn0;

    sput-object v2, Lg4;->v:Lkn0;

    const/16 v0, 0x106e

    new-instance v2, Lms1;

    nop

    const/16 v0, 0x924

    invoke-direct {v2, v3}, Lms1;-><init>(I)V

    check-cast v2, Lms1;

    sput-object v2, Lg4;->z:Lms1;

    const/16 v0, 0x10e6

    new-instance v2, Ln8;

    nop

    const/16 v3, 0x12

    const/16 v0, 0x671

    invoke-direct {v2, v3}, Ln8;-><init>(I)V

    check-cast v2, Ln8;

    sput-object v2, Lg4;->D:Ln8;

    return-void
.end method

.method public static a(Landroid/content/SharedPreferences;)V
    .registers 5

    .prologue
    const-string/jumbo v2, "Ads-Clear"

    const-string/jumbo v3, "Limpando cache..."

    nop

    const/4 v2, 0x0

    const/16 v0, 0xce3

    sput-object v2, Lg4;->n:Lx4;

    const/16 v0, 0xd9f

    sput-object v2, Lg4;->A:Lxu1;

    const/16 v0, 0x25a

    sget-object v3, Lg4;->s:Lce;

    nop

    if-eqz v3, :cond_20

    const/16 v0, 0x7aa

    sput-object v2, Lg4;->s:Lce;

    const/16 v0, 0xc7e

    invoke-static {p0}, Lg4;->b(Landroid/content/SharedPreferences;)V

    :cond_20
    const/16 v0, 0x1c4

    sget-object v3, Lg4;->w:Let0;

    nop

    if-eqz v3, :cond_30

    const/16 v0, 0x6fe

    sput-object v2, Lg4;->w:Let0;

    const/16 v0, 0x10af

    invoke-static {p0}, Lg4;->c(Landroid/content/SharedPreferences;)V

    :cond_30
    return-void
.end method

.method public static b(Landroid/content/SharedPreferences;)V
    .registers 13

    .prologue
    const/4 v2, 0x0

    const/16 v0, 0x98

    invoke-static {v2}, Lmi2;->c(Z)Ljava/lang/String;

    move-result-object v3

    const-string/jumbo v4, "ks6dlFx"

    const-string/jumbo v5, ""

    const/16 v0, 0x2e

    invoke-interface {p0, v4, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x1

    const/16 v0, 0x98

    invoke-static {v7}, Lmi2;->c(Z)Ljava/lang/String;

    move-result-object v8

    const-string/jumbo v9, "hAPdtA1"

    const/16 v0, 0x2e

    invoke-interface {p0, v9, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/16 v0, 0x7a

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v10

    const/16 v0, 0x128

    invoke-virtual {v3, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v6

    const-string/jumbo v11, "sR3sd4"

    if-nez v6, :cond_3f

    const/16 v0, 0x3c

    invoke-interface {v10, v4, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x56

    invoke-interface {v10, v11, v7}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    goto :goto_4b

    :cond_3f
    const/16 v0, 0xb0

    invoke-interface {p0, v11, v2}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v3

    add-int/2addr v3, v7

    const/16 v0, 0x56

    invoke-interface {v10, v11, v3}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    :goto_4b
    const/16 v0, 0x128

    invoke-virtual {v8, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v3

    const-string/jumbo v4, "fTHfz4g"

    if-nez v3, :cond_61

    const/16 v0, 0x3c

    invoke-interface {v10, v9, v8}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x56

    invoke-interface {v10, v4, v7}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    goto :goto_6d

    :cond_61
    const/16 v0, 0xb0

    invoke-interface {p0, v4, v2}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result p0

    add-int/2addr p0, v7

    const/16 v0, 0x56

    invoke-interface {v10, v4, p0}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    :goto_6d
    const/16 v0, 0x6f

    invoke-interface {v10}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method public static c(Landroid/content/SharedPreferences;)V
    .registers 13

    .prologue
    const/4 v2, 0x0

    const/16 v0, 0x98

    invoke-static {v2}, Lmi2;->c(Z)Ljava/lang/String;

    move-result-object v3

    const-string/jumbo v4, "Bs6dlTz"

    const-string/jumbo v5, ""

    const/16 v0, 0x2e

    invoke-interface {p0, v4, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const/4 v7, 0x1

    const/16 v0, 0x98

    invoke-static {v7}, Lmi2;->c(Z)Ljava/lang/String;

    move-result-object v8

    const-string/jumbo v9, "lA4dtxV"

    const/16 v0, 0x2e

    invoke-interface {p0, v9, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/16 v0, 0x7a

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v10

    const/16 v0, 0x128

    invoke-virtual {v3, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v6

    const-string/jumbo v11, "VkB8aR"

    if-nez v6, :cond_3f

    const/16 v0, 0x3c

    invoke-interface {v10, v4, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x56

    invoke-interface {v10, v11, v7}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    goto :goto_4b

    :cond_3f
    const/16 v0, 0xb0

    invoke-interface {p0, v11, v2}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v3

    add-int/2addr v3, v7

    const/16 v0, 0x56

    invoke-interface {v10, v11, v3}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    :goto_4b
    const/16 v0, 0x128

    invoke-virtual {v8, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v3

    const-string/jumbo v4, "PkHfz5S"

    if-nez v3, :cond_61

    const/16 v0, 0x3c

    invoke-interface {v10, v9, v8}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x56

    invoke-interface {v10, v4, v7}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    goto :goto_6d

    :cond_61
    const/16 v0, 0xb0

    invoke-interface {p0, v4, v2}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result p0

    add-int/2addr p0, v7

    const/16 v0, 0x56

    invoke-interface {v10, v4, p0}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    :goto_6d
    const/16 v0, 0x6f

    invoke-interface {v10}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method public static d(Landroid/app/Activity;)V
    .registers 14

    .prologue
    const/16 v6, 0x101

    sget-boolean v8, Lmi2;->n:Z

    nop

    if-nez v8, :cond_b4

    const/16 v6, 0x140

    sget-boolean v8, Lg4;->a:Z

    nop

    if-nez v8, :cond_b4

    const/16 v6, 0x8f7

    sget-boolean v8, Lg4;->b:Z

    nop

    if-eqz v8, :cond_17

    goto/16 :goto_b4

    :cond_17
    const/16 v6, 0x547

    new-instance v8, Lec;

    nop

    const/16 v6, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v9

    const/16 v6, 0x9f7

    invoke-direct {v8, v9}, Lec;-><init>(Landroid/content/Context;)V

    const/16 v6, 0xbfa

    sget-object v9, Lg4;->c:Ljava/util/List;

    nop

    const/16 v6, 0x170

    invoke-interface {v9}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_32
    const/16 v6, 0x13e

    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-eqz v10, :cond_4f

    const/16 v6, 0x16e

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/String;

    const/16 v6, 0x11ec

    iget-object v11, v8, Lec;->b:Ljava/lang/Object;

    nop

    check-cast v11, Ljava/util/ArrayList;

    const/16 v6, 0x174

    invoke-virtual {v11, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_32

    :cond_4f
    const/16 v6, 0x74d

    new-instance v9, Lam0;

    nop

    const/16 v10, 0x13

    const/4 v11, 0x0

    const/16 v6, 0x94e

    invoke-direct {v9, v10, v11}, Lam0;-><init>(IZ)V

    const/16 v6, 0xa1b

    invoke-virtual {v8}, Lec;->i()Llv;

    move-result-object v8

    const/16 v6, 0x6ca

    iput-object v8, v9, Lam0;->b:Ljava/lang/Object;

    const/16 v6, 0xaa3

    new-instance v8, Lrv;

    nop

    const/16 v6, 0xbde

    invoke-direct {v8, v9}, Lrv;-><init>(Lam0;)V

    const/16 v6, 0xa80

    invoke-static {p0}, Lcom/google/android/gms/internal/consent_sdk/zza;->zza(Landroid/content/Context;)Lcom/google/android/gms/internal/consent_sdk/zza;

    move-result-object v9

    const/16 v6, 0x8dd

    invoke-virtual {v9}, Lcom/google/android/gms/internal/consent_sdk/zza;->zzb()Lcom/google/android/gms/internal/consent_sdk/zzj;

    move-result-object v9

    const/16 v6, 0x108b

    new-instance v10, Lx3;

    nop

    const/16 v6, 0xf34

    invoke-direct {v10, v11, p0, v9}, Lx3;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    const/16 v6, 0x11f8

    new-instance v11, Lo1;

    nop

    const/16 v12, 0xd

    const/16 v6, 0xfca

    invoke-direct {v11, v12}, Lo1;-><init>(I)V

    const/16 v6, 0x74b

    move v0, v6

    move-object v1, v9

    move-object v2, p0

    move-object v3, v8

    move-object v4, v10

    move-object v5, v11

    invoke-virtual/range {v1 .. v5}, Lcom/google/android/gms/internal/consent_sdk/zzj;->requestConsentInfoUpdate(Landroid/app/Activity;Lrv;Lpv;Lov;)V

    const/16 v6, 0xfd0

    invoke-virtual {v9}, Lcom/google/android/gms/internal/consent_sdk/zzj;->canRequestAds()Z

    move-result v8

    if-eqz v8, :cond_b4

    const/16 v6, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v6, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x1136

    invoke-static {p0}, Lg4;->e(Landroid/content/Context;)V

    :cond_b4
    :goto_b4
    return-void
.end method

.method public static e(Landroid/content/Context;)V
    .registers 13

    .prologue
    const/16 v6, 0x101

    sget-boolean v8, Lmi2;->n:Z

    nop

    if-nez v8, :cond_43

    const/16 v6, 0x140

    sget-boolean v8, Lg4;->a:Z

    nop

    if-nez v8, :cond_43

    const/16 v6, 0x8f7

    sget-boolean v8, Lg4;->b:Z

    nop

    if-eqz v8, :cond_16

    goto :goto_43

    :cond_16
    const/4 v8, 0x1

    const/16 v6, 0x549

    sput-boolean v8, Lg4;->a:Z

    const/16 v6, 0x132

    sget-object v8, Lh50;->a:Li20;

    nop

    const/16 v6, 0x126

    sget-object v8, Lx10;->c:Lx10;

    nop

    const/16 v6, 0xf43

    invoke-static {v8}, Lw53;->a(Lly;)Lsx;

    move-result-object v8

    const/16 v6, 0x23

    new-instance v9, Lc4;

    nop

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/16 v6, 0x22

    invoke-direct {v9, p0, v11, v10}, Lc4;-><init>(Ljava/lang/Object;Lvx;I)V

    const/4 p0, 0x3

    const/16 v6, 0xb3

    move v0, v6

    move-object v1, v8

    move-object v2, v11

    move-object v3, v11

    move-object v4, v9

    move v5, p0

    invoke-static/range {v1 .. v5}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    :cond_43
    :goto_43
    return-void
.end method

.method public static f(Landroid/content/SharedPreferences;)Z
    .registers 11

    .prologue
    const/4 v2, 0x0

    const/16 v0, 0x98

    invoke-static {v2}, Lmi2;->c(Z)Ljava/lang/String;

    move-result-object v3

    const-string/jumbo v4, "ks6dlFx"

    const-string/jumbo v5, ""

    const/16 v0, 0x2e

    invoke-interface {p0, v4, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const/16 v0, 0x128

    invoke-virtual {v3, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v6

    const-string/jumbo v7, "sR3sd4"

    if-nez v6, :cond_34

    const/16 v0, 0x7a

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/16 v0, 0x3c

    invoke-interface {p0, v4, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x56

    invoke-interface {p0, v7, v2}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x6f

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return v2

    :cond_34
    const/16 v0, 0xb0

    invoke-interface {p0, v7, v2}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v3

    const/4 v0, -0x3

    new-instance v4, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v6, "Limite de Exibição (AppOpen) \""

    const/16 v0, 0x97

    invoke-direct {v4, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x6

    const/4 v8, 0x1

    if-lt v3, v7, :cond_4c

    move v9, v8

    goto :goto_4d

    :cond_4c
    move v9, v2

    :goto_4d
    const/16 v0, 0x6a

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string/jumbo v9, "\" MAX_DAILY_APPOPEN("

    const/4 v0, 0x0

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x33

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v9, "/6)"

    const/4 v0, 0x0

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const-string/jumbo v9, "Ads-Limits"

    nop

    if-lt v3, v7, :cond_71

    goto :goto_d6

    :cond_71
    const/16 v0, 0x98

    invoke-static {v8}, Lmi2;->c(Z)Ljava/lang/String;

    move-result-object v3

    const-string/jumbo v4, "hAPdtA1"

    const/16 v0, 0x2e

    invoke-interface {p0, v4, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/16 v0, 0x128

    invoke-virtual {v3, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v5

    const-string/jumbo v7, "fTHfz4g"

    if-nez v5, :cond_a1

    const/16 v0, 0x7a

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/16 v0, 0x3c

    invoke-interface {p0, v4, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x56

    invoke-interface {p0, v7, v2}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x6f

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return v2

    :cond_a1
    const/16 v0, 0xb0

    invoke-interface {p0, v7, v2}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result p0

    const/4 v0, -0x3

    new-instance v3, Ljava/lang/StringBuilder;

    nop

    const/16 v0, 0x97

    invoke-direct {v3, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    if-lt p0, v4, :cond_b5

    move v5, v8

    goto :goto_b6

    :cond_b5
    move v5, v2

    :goto_b6
    const/16 v0, 0x6a

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string/jumbo v5, "\" MAX_HOURLY_APPOPEN("

    const/4 v0, 0x0

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x33

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v5, "/2)"

    const/4 v0, 0x0

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    nop

    if-lt p0, v4, :cond_d7

    :goto_d6
    return v8

    :cond_d7
    return v2
.end method

.method public static g(Landroid/content/SharedPreferences;)Z
    .registers 7

    .prologue
    const/16 v0, 0x622

    invoke-static {p0}, Lg4;->i(Landroid/content/SharedPreferences;)Z

    move-result p0

    if-nez p0, :cond_27

    const/16 v0, 0x1ff

    sget p0, Lmi2;->o:I

    nop

    const/4 v2, 0x3

    if-ne p0, v2, :cond_27

    const/16 v0, 0x26f

    sget-wide v2, Lmi2;->i:J

    nop

    const/16 v0, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    sub-long/2addr v2, v4

    const/16 v0, 0x29a

    sget-wide v4, Lmi2;->j:J

    nop

    cmp-long p0, v2, v4

    if-gez p0, :cond_27

    const/4 p0, 0x1

    return p0

    :cond_27
    const/4 p0, 0x0

    return p0
.end method

.method public static h(Landroid/content/SharedPreferences;)Z
    .registers 11

    .prologue
    const/4 v2, 0x0

    const/16 v0, 0x98

    invoke-static {v2}, Lmi2;->c(Z)Ljava/lang/String;

    move-result-object v3

    const-string/jumbo v4, "Bs6dlTz"

    const-string/jumbo v5, ""

    const/16 v0, 0x2e

    invoke-interface {p0, v4, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const/16 v0, 0x128

    invoke-virtual {v3, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v6

    const-string/jumbo v7, "VkB8aR"

    if-nez v6, :cond_34

    const/16 v0, 0x7a

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/16 v0, 0x3c

    invoke-interface {p0, v4, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x56

    invoke-interface {p0, v7, v2}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x6f

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return v2

    :cond_34
    const/16 v0, 0xb0

    invoke-interface {p0, v7, v2}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v3

    const/4 v0, -0x3

    new-instance v4, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v6, "Limite de Exibição (Intersticial) \""

    const/16 v0, 0x97

    invoke-direct {v4, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x6

    const/4 v8, 0x1

    if-lt v3, v7, :cond_4c

    move v9, v8

    goto :goto_4d

    :cond_4c
    move v9, v2

    :goto_4d
    const/16 v0, 0x6a

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string/jumbo v9, "\" MAX_DAILY_INTERSTICIAL("

    const/4 v0, 0x0

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x33

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v9, "/6)"

    const/4 v0, 0x0

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const-string/jumbo v9, "Ads-Limits"

    nop

    if-lt v3, v7, :cond_71

    goto :goto_d5

    :cond_71
    const/16 v0, 0x98

    invoke-static {v8}, Lmi2;->c(Z)Ljava/lang/String;

    move-result-object v3

    const-string/jumbo v4, "lA4dtxV"

    const/16 v0, 0x2e

    invoke-interface {p0, v4, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/16 v0, 0x128

    invoke-virtual {v3, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v5

    const-string/jumbo v7, "PkHfz5S"

    if-nez v5, :cond_a1

    const/16 v0, 0x7a

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/16 v0, 0x3c

    invoke-interface {p0, v4, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x56

    invoke-interface {p0, v7, v2}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x6f

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return v2

    :cond_a1
    const/16 v0, 0xb0

    invoke-interface {p0, v7, v2}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result p0

    const/4 v0, -0x3

    new-instance v3, Ljava/lang/StringBuilder;

    nop

    const/16 v0, 0x97

    invoke-direct {v3, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    if-lt p0, v8, :cond_b4

    move v4, v8

    goto :goto_b5

    :cond_b4
    move v4, v2

    :goto_b5
    const/16 v0, 0x6a

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string/jumbo v4, "\" MAX_HOURLY_INTERSTICIAL("

    const/4 v0, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x33

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v4, "/1)"

    const/4 v0, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    nop

    if-lt p0, v8, :cond_d6

    :goto_d5
    return v8

    :cond_d6
    return v2
.end method

.method public static i(Landroid/content/SharedPreferences;)Z
    .registers 11

    .prologue
    const/4 v2, 0x0

    const/16 v0, 0x98

    invoke-static {v2}, Lmi2;->c(Z)Ljava/lang/String;

    move-result-object v3

    const-string/jumbo v4, "gd4Lrfa"

    const-string/jumbo v5, ""

    const/16 v0, 0x2e

    invoke-interface {p0, v4, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const/16 v0, 0x128

    invoke-virtual {v3, v6}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v6

    const-string/jumbo v7, "adXs5SFd"

    if-nez v6, :cond_34

    const/16 v0, 0x7a

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/16 v0, 0x3c

    invoke-interface {p0, v4, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x56

    invoke-interface {p0, v7, v2}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x6f

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return v2

    :cond_34
    const/16 v0, 0xb0

    invoke-interface {p0, v7, v2}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v3

    const/4 v0, -0x3

    new-instance v4, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v6, "Limites de Exibição (Rewarded) \""

    const/16 v0, 0x97

    invoke-direct {v4, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v7, 0x18

    const/4 v8, 0x1

    if-lt v3, v7, :cond_4d

    move v9, v8

    goto :goto_4e

    :cond_4d
    move v9, v2

    :goto_4e
    const/16 v0, 0x6a

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string/jumbo v9, "\" REWARD_DAILY_COUNT("

    const/4 v0, 0x0

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x33

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v9, "/24)"

    const/4 v0, 0x0

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const-string/jumbo v9, "Ads-Limits"

    nop

    if-lt v3, v7, :cond_72

    goto :goto_d8

    :cond_72
    const/16 v0, 0x98

    invoke-static {v8}, Lmi2;->c(Z)Ljava/lang/String;

    move-result-object v3

    const-string/jumbo v4, "Ss5fGn2"

    const/16 v0, 0x2e

    invoke-interface {p0, v4, v5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/16 v0, 0x128

    invoke-virtual {v3, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v5

    const-string/jumbo v7, "drVw5ad"

    if-nez v5, :cond_a2

    const/16 v0, 0x7a

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/16 v0, 0x3c

    invoke-interface {p0, v4, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x56

    invoke-interface {p0, v7, v2}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x6f

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return v2

    :cond_a2
    const/16 v0, 0xb0

    invoke-interface {p0, v7, v2}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result p0

    const/4 v0, -0x3

    new-instance v3, Ljava/lang/StringBuilder;

    nop

    const/16 v0, 0x97

    invoke-direct {v3, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v4, 0x8

    if-lt p0, v4, :cond_b7

    move v5, v8

    goto :goto_b8

    :cond_b7
    move v5, v2

    :goto_b8
    const/16 v0, 0x6a

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string/jumbo v5, "\" REWARD_HOURLY_COUNT("

    const/4 v0, 0x0

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x33

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v5, "/8)"

    const/4 v0, 0x0

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    nop

    if-lt p0, v4, :cond_d9

    :goto_d8
    return v8

    :cond_d9
    return v2
.end method

.method public static j(JLandroid/content/Context;)V
    .registers 7

    .prologue
    const/16 v0, 0x101

    sget-boolean v2, Lmi2;->n:Z

    nop

    if-eqz v2, :cond_8

    goto :goto_47

    :cond_8
    const/16 v0, 0x8f7

    sget-boolean v2, Lg4;->b:Z

    nop

    if-nez v2, :cond_10

    goto :goto_47

    :cond_10
    const/16 v0, 0xa53

    sget-boolean v2, Lg4;->t:Z

    nop

    if-eqz v2, :cond_18

    goto :goto_47

    :cond_18
    const/16 v0, 0x25a

    sget-object v2, Lg4;->s:Lce;

    nop

    if-eqz v2, :cond_20

    goto :goto_47

    :cond_20
    const/16 v0, 0x195

    sget-boolean v2, Lmi2;->d:Z

    nop

    if-nez v2, :cond_2f

    const/16 v0, 0xf11

    sget-boolean v2, Lmi2;->e:Z

    nop

    if-nez v2, :cond_2f

    goto :goto_47

    :cond_2f
    const/16 v0, 0x53

    invoke-virtual {p2}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p2

    const/16 v0, 0x2a

    invoke-static {p2}, Lxl1;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xda5

    invoke-static {p2}, Lg4;->f(Landroid/content/SharedPreferences;)Z

    move-result p2

    if-eqz p2, :cond_48

    :goto_47
    return-void

    :cond_48
    const/4 p2, 0x1

    const/16 v0, 0xfa5

    sput-boolean p2, Lg4;->t:Z

    const/4 v0, -0x3

    new-instance p2, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v2, "O AppOpen será carregado daqui a "

    const/16 v0, 0x97

    invoke-direct {p2, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-wide/16 v2, 0x3e8

    div-long v2, p0, v2

    const/16 v0, 0x83

    invoke-virtual {p2, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/16 v2, 0x73

    const/16 v0, 0x1b

    invoke-virtual {p2, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const-string/jumbo v2, "Ads-Delays"

    nop

    const/16 v0, 0x5d3

    new-instance p2, Landroid/os/Handler;

    nop

    const/16 v0, 0x1210

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v2

    const/16 v0, 0xad4

    invoke-direct {p2, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/16 v0, 0xf67

    new-instance v2, Lw3;

    nop

    const/4 v3, 0x0

    const/16 v0, 0x11c0

    invoke-direct {v2, v3}, Lw3;-><init>(I)V

    const/16 v0, 0xc45

    invoke-virtual {p2, v2, p0, p1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public static k(JLandroid/content/Context;)V
    .registers 9

    .prologue
    const/16 v1, 0x8f7

    sget-boolean v3, Lg4;->b:Z

    nop

    if-nez v3, :cond_8

    goto :goto_40

    :cond_8
    const/16 v1, 0x1161

    sget-boolean v3, Lg4;->x:Z

    nop

    if-eqz v3, :cond_10

    goto :goto_40

    :cond_10
    const/16 v1, 0x1c4

    sget-object v3, Lg4;->w:Let0;

    nop

    if-eqz v3, :cond_18

    goto :goto_40

    :cond_18
    const/16 v1, 0x195

    sget-boolean v3, Lmi2;->d:Z

    nop

    if-nez v3, :cond_20

    goto :goto_40

    :cond_20
    const/16 v1, 0x101

    sget-boolean v3, Lmi2;->n:Z

    nop

    if-eqz v3, :cond_28

    goto :goto_40

    :cond_28
    const/16 v1, 0x53

    invoke-virtual {p2}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p2

    const/16 v1, 0x2a

    invoke-static {p2}, Lxl1;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p2

    const/4 v1, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v1, 0x69c

    invoke-static {p2}, Lg4;->h(Landroid/content/SharedPreferences;)Z

    move-result p2

    if-eqz p2, :cond_41

    :goto_40
    return-void

    :cond_41
    const/4 p2, 0x1

    const/16 v1, 0x992

    sput-boolean p2, Lg4;->x:Z

    const/4 v1, -0x3

    new-instance v3, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v4, "O Intersticial será carregado daqui a "

    const/16 v1, 0x97

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-wide/16 v4, 0x3e8

    div-long v4, p0, v4

    const/16 v1, 0x83

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/16 v4, 0x73

    const/16 v1, 0x1b

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v1, -0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const-string/jumbo v4, "Ads-Delays"

    nop

    const/16 v1, 0x5d3

    new-instance v3, Landroid/os/Handler;

    nop

    const/16 v1, 0x1210

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v4

    const/16 v1, 0xad4

    invoke-direct {v3, v4}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/16 v1, 0xf67

    new-instance v4, Lw3;

    nop

    const/16 v1, 0x11c0

    invoke-direct {v4, p2}, Lw3;-><init>(I)V

    const/16 v1, 0xc45

    invoke-virtual {v3, v4, p0, p1}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public static l(Landroid/content/Context;JZ)V
    .registers 11

    .prologue
    const/16 v0, 0x8f7

    sget-boolean v2, Lg4;->b:Z

    nop

    if-nez v2, :cond_8

    goto :goto_47

    :cond_8
    const/16 v0, 0x584

    sget-boolean v2, Lg4;->B:Z

    nop

    if-eqz v2, :cond_10

    goto :goto_47

    :cond_10
    const/16 v0, 0x22b

    sget-object v2, Lg4;->A:Lxu1;

    nop

    if-eqz v2, :cond_18

    goto :goto_47

    :cond_18
    const/16 v0, 0x101

    sget-boolean v2, Lmi2;->n:Z

    nop

    if-eqz v2, :cond_20

    goto :goto_47

    :cond_20
    const/16 v0, 0x195

    sget-boolean v2, Lmi2;->d:Z

    nop

    if-nez v2, :cond_2f

    const/16 v0, 0xf11

    sget-boolean v2, Lmi2;->e:Z

    nop

    if-nez v2, :cond_2f

    goto :goto_47

    :cond_2f
    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/16 v0, 0x2a

    invoke-static {p0}, Lxl1;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x622

    invoke-static {p0}, Lg4;->i(Landroid/content/SharedPreferences;)Z

    move-result v2

    if-eqz v2, :cond_48

    :goto_47
    return-void

    :cond_48
    const/4 v2, 0x1

    const/16 v0, 0x1178

    sput-boolean v2, Lg4;->B:Z

    const/16 v0, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    const/16 v0, 0x5f5

    sget-wide v4, Lg4;->k:J

    nop

    sub-long/2addr v4, v2

    cmp-long v2, v4, p1

    if-lez v2, :cond_5e

    move-wide p1, v4

    :cond_5e
    const/4 v0, -0x3

    new-instance v2, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v3, "O Rewarded será carregado daqui a "

    const/16 v0, 0x97

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-wide/16 v3, 0x3e8

    div-long v3, p1, v3

    const/16 v0, 0x83

    invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/16 v3, 0x73

    const/16 v0, 0x1b

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string/jumbo v3, "Ads-Delays"

    nop

    const/16 v0, 0x5d3

    new-instance v2, Landroid/os/Handler;

    nop

    const/16 v0, 0x1210

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v3

    const/16 v0, 0xad4

    invoke-direct {v2, v3}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/16 v0, 0xe4a

    new-instance v3, Lv3;

    nop

    const/16 v0, 0xb16

    invoke-direct {v3, p3, p0}, Lv3;-><init>(ZLandroid/content/SharedPreferences;)V

    const/16 v0, 0xc45

    invoke-virtual {v2, v3, p1, p2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    return-void
.end method

.method public static synthetic m(Landroid/content/Context;IJ)V
    .registers 6

    .prologue
    and-int/lit8 p1, p1, 0x2

    if-eqz p1, :cond_6

    const-wide/16 p2, 0x0

    :cond_6
    const/4 p1, 0x0

    const/16 v0, 0x9a8

    invoke-static {p0, p2, p3, p1}, Lg4;->l(Landroid/content/Context;JZ)V

    return-void
.end method

.method public static n(Landroid/content/SharedPreferences;Landroidx/fragment/app/l;)V
    .registers 12

    .prologue
    const/16 v0, 0x1084

    sget-object v2, Lpn1;->i:Lpn1;

    nop

    const/16 v0, 0xb6e

    iget-object v2, v2, Lpn1;->f:Lk11;

    nop

    const/16 v0, 0x8bd

    iget-object v2, v2, Lk11;->h:Lz01;

    nop

    const/16 v0, 0xe66

    sget-object v3, Lz01;->e:Lz01;

    nop

    const/16 v0, 0xb56

    invoke-virtual {v2, v3}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    move-result v2

    if-ltz v2, :cond_10a

    const/16 v0, 0x101

    sget-boolean v2, Lmi2;->n:Z

    nop

    if-nez v2, :cond_10a

    const/16 v0, 0x8f7

    sget-boolean v2, Lg4;->b:Z

    nop

    if-eqz v2, :cond_10a

    const/16 v0, 0xde

    sget-boolean v2, Lg4;->j:Z

    nop

    if-eqz v2, :cond_33

    goto/16 :goto_10a

    :cond_33
    const/16 v0, 0x49d

    sget-wide v2, Lg4;->i:J

    nop

    const-wide/32 v4, 0xea60

    add-long/2addr v2, v4

    const/16 v0, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v6

    cmp-long v2, v2, v6

    const/4 v3, 0x0

    const/4 v6, 0x1

    if-gez v2, :cond_4a

    move v2, v6

    goto :goto_4b

    :cond_4a
    move v2, v3

    :goto_4b
    const/16 v0, 0x69c

    invoke-static {p0}, Lg4;->h(Landroid/content/SharedPreferences;)Z

    move-result v7

    if-eqz v7, :cond_5d

    const/16 v0, 0x1c4

    sget-object v7, Lg4;->w:Let0;

    nop

    if-eqz v7, :cond_5b

    goto :goto_5d

    :cond_5b
    move v7, v3

    goto :goto_5e

    :cond_5d
    :goto_5d
    move v7, v6

    :goto_5e
    if-eqz v2, :cond_63

    if-eqz v7, :cond_63

    goto :goto_64

    :cond_63
    move v6, v3

    :goto_64
    const/4 v0, -0x3

    new-instance v7, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v8, "Exibir Intersticial? "

    const/16 v0, 0x97

    invoke-direct {v7, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x6a

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/16 v8, 0x20

    const/16 v0, 0x1b

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    if-nez v6, :cond_ae

    if-nez v2, :cond_ae

    const/4 v0, -0x3

    new-instance v2, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v8, "(Só daqui a ~"

    const/16 v0, 0x97

    invoke-direct {v2, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x49d

    sget-wide v8, Lg4;->i:J

    nop

    add-long/2addr v8, v4

    const/16 v0, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    sub-long/2addr v8, v4

    const-wide/16 v4, 0x3e8

    div-long/2addr v8, v4

    const/16 v0, 0x83

    invoke-virtual {v2, v8, v9}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string/jumbo v4, "s)"

    const/4 v0, 0x0

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    goto :goto_b1

    :cond_ae
    const-string/jumbo v2, ""

    :goto_b1
    const/4 v0, 0x0

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string/jumbo v4, "Ads-Limits"

    nop

    if-nez v6, :cond_c1

    goto :goto_10a

    :cond_c1
    const/16 v0, 0x1c4

    sget-object v2, Lg4;->w:Let0;

    nop

    if-nez v2, :cond_da

    const/16 v0, 0x53

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-wide/16 v2, 0x0

    const/16 v0, 0x2ce

    invoke-static {v2, v3, p0}, Lg4;->k(JLandroid/content/Context;)V

    return-void

    :cond_da
    const/16 v0, 0xffa

    new-instance v4, Le4;

    nop

    const/16 v0, 0xf79

    invoke-direct {v4, p0, p1}, Le4;-><init>(Landroid/content/SharedPreferences;Landroidx/fragment/app/l;)V

    check-cast v2, Lads_mobile_sdk/ai1;

    const/16 v0, 0xeab

    iget-object p0, v2, Lads_mobile_sdk/ai1;->c:Lads_mobile_sdk/ji;

    nop

    const/16 v0, 0xa12

    sget-object v5, Lads_mobile_sdk/ai1;->e:[Liy0;

    nop

    aget-object v3, v5, v3

    const/16 v0, 0x1037

    invoke-virtual {p0, v2, v3, v4}, Lads_mobile_sdk/ji;->setValue(Ljava/lang/Object;Liy0;Ljava/lang/Object;)V

    const/16 v0, 0x1c4

    sget-object p0, Lg4;->w:Let0;

    nop

    if-eqz p0, :cond_10a

    check-cast p0, Lads_mobile_sdk/ai1;

    const/16 v0, 0xb92

    iget-object p0, p0, Lads_mobile_sdk/ai1;->b:Lxx2;

    nop

    const/16 v0, 0x914

    invoke-virtual {p0, p1}, Lads_mobile_sdk/xo;->a(Landroid/content/Context;)V

    :cond_10a
    :goto_10a
    return-void
.end method
