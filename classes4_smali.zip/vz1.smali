.class public final Lvz1;
.super Lvb;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final q:Lw82;

.field public r:Landroidx/constraintlayout/widget/ConstraintLayout;

.field public s:Landroid/view/View;

.field public t:Landroidx/constraintlayout/widget/ConstraintLayout;

.field public u:Landroid/view/View;

.field public v:Landroidx/constraintlayout/widget/ConstraintLayout;


# direct methods
.method public constructor <init>()V
    .registers 5

    invoke-direct {p0}, Lvb;-><init>()V

    const/16 v0, 0x9ca

    new-instance v2, Lsz1;

    nop

    const/4 v3, 0x0

    const/16 v0, 0xf0b

    invoke-direct {v2, v3, p0}, Lsz1;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x27a

    new-instance v3, Lw82;

    nop

    const/16 v0, 0x215

    invoke-direct {v3, v2}, Lw82;-><init>(Lzj0;)V

    const/16 v0, 0x95b

    iput-object v3, p0, Lvz1;->q:Lw82;

    return-void
.end method


# virtual methods
.method public final c()V
    .registers 7

    const/16 v0, 0x4e5

    new-instance v2, Lg12;

    nop

    const/16 v0, 0x2b3

    invoke-direct {v2}, Lg12;-><init>()V

    const/16 v0, 0x108

    new-instance v3, Landroid/os/Bundle;

    nop

    const/16 v0, 0x198

    invoke-direct {v3}, Landroid/os/Bundle;-><init>()V

    const-string/jumbo v4, "is_premium"

    const/4 v5, 0x0

    const/16 v0, 0x27b

    invoke-virtual {v3, v4, v5}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/16 v0, 0x19a

    invoke-virtual {v2, v3}, Landroidx/fragment/app/Fragment;->setArguments(Landroid/os/Bundle;)V

    const/16 v0, 0x8b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getParentFragmentManager()Landroidx/fragment/app/p;

    move-result-object v3

    const v4, 0x7f1301e0

    const/16 v0, 0x4c

    invoke-virtual {p0, v4}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v4

    const/16 v0, 0x8c

    invoke-virtual {v2, v3, v4}, Landroidx/fragment/app/g;->show(Landroidx/fragment/app/p;Ljava/lang/String;)V

    const/16 v0, 0x181

    invoke-virtual {p0}, Landroidx/fragment/app/g;->dismiss()V

    return-void
.end method

.method public final d()V
    .registers 7

    const/16 v0, 0x4e5

    new-instance v2, Lg12;

    nop

    const/16 v0, 0x2b3

    invoke-direct {v2}, Lg12;-><init>()V

    const/16 v0, 0x108

    new-instance v3, Landroid/os/Bundle;

    nop

    const/16 v0, 0x198

    invoke-direct {v3}, Landroid/os/Bundle;-><init>()V

    const-string/jumbo v4, "is_premium"

    const/4 v5, 0x1

    const/16 v0, 0x27b

    invoke-virtual {v3, v4, v5}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/16 v0, 0x19a

    invoke-virtual {v2, v3}, Landroidx/fragment/app/Fragment;->setArguments(Landroid/os/Bundle;)V

    const/16 v0, 0x8b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getParentFragmentManager()Landroidx/fragment/app/p;

    move-result-object v3

    const v4, 0x7f1301ff

    const/16 v0, 0x4c

    invoke-virtual {p0, v4}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v4

    const/16 v0, 0x8c

    invoke-virtual {v2, v3, v4}, Landroidx/fragment/app/g;->show(Landroidx/fragment/app/p;Ljava/lang/String;)V

    const/16 v0, 0x181

    invoke-virtual {p0}, Landroidx/fragment/app/g;->dismiss()V

    return-void
.end method

.method public final e()V
    .registers 7

    const/16 v0, 0x310

    new-instance v2, Ldn1;

    nop

    const/16 v0, 0x3f8

    invoke-direct {v2}, Ldn1;-><init>()V

    const/16 v0, 0x108

    new-instance v3, Landroid/os/Bundle;

    nop

    const/16 v0, 0x198

    invoke-direct {v3}, Landroid/os/Bundle;-><init>()V

    const-string/jumbo v4, "eptalert"

    const/4 v5, 0x0

    const/16 v0, 0x27b

    invoke-virtual {v3, v4, v5}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const/16 v0, 0x19a

    invoke-virtual {v2, v3}, Landroidx/fragment/app/Fragment;->setArguments(Landroid/os/Bundle;)V

    const/16 v0, 0x8b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getParentFragmentManager()Landroidx/fragment/app/p;

    move-result-object v3

    const v4, 0x7f130203

    const/16 v0, 0x4c

    invoke-virtual {p0, v4}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v4

    const/16 v0, 0x8c

    invoke-virtual {v2, v3, v4}, Landroidx/fragment/app/g;->show(Landroidx/fragment/app/p;Ljava/lang/String;)V

    const/16 v0, 0x181

    invoke-virtual {p0}, Landroidx/fragment/app/g;->dismiss()V

    return-void
.end method

.method public final onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .registers 13

    .prologue
    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const p3, 0x7f0c00ce

    const/4 v2, 0x0

    const/16 v0, 0x107b

    invoke-virtual {p1, p3, p2, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    const p2, 0x7f090291

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroidx/constraintlayout/widget/ConstraintLayout;

    const/16 v0, 0xe0e

    iput-object p2, p0, Lvz1;->r:Landroidx/constraintlayout/widget/ConstraintLayout;

    const p2, 0x7f090292

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x932

    iput-object p2, p0, Lvz1;->s:Landroid/view/View;

    const p2, 0x7f0902cb

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroidx/constraintlayout/widget/ConstraintLayout;

    const/16 v0, 0x626

    iput-object p2, p0, Lvz1;->t:Landroidx/constraintlayout/widget/ConstraintLayout;

    const p2, 0x7f0902cc

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x789

    iput-object p2, p0, Lvz1;->u:Landroid/view/View;

    const p2, 0x7f0902ce

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroidx/constraintlayout/widget/ConstraintLayout;

    const/16 v0, 0xbac

    iput-object p2, p0, Lvz1;->v:Landroidx/constraintlayout/widget/ConstraintLayout;

    const/16 v0, 0x4e6

    iget-object p2, p0, Lvz1;->r:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    const/4 p3, 0x0

    const-string/jumbo v3, "officialservers"

    if-eqz p2, :cond_1da

    const/16 v0, 0x200

    new-instance v4, Ltz1;

    nop

    const/16 v0, 0x1d3

    invoke-direct {v4, p0, v2}, Ltz1;-><init>(Lvz1;I)V

    const/16 v0, 0x5f

    invoke-virtual {p2, v4}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0x4e6

    iget-object p2, p0, Lvz1;->r:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz p2, :cond_1d5

    const/16 v0, 0x1b0

    new-instance v3, Luz1;

    nop

    const/16 v0, 0x239

    invoke-direct {v3, p0, v2}, Luz1;-><init>(Lvz1;I)V

    const/16 v0, 0x8f

    invoke-virtual {p2, v3}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    const/16 v0, 0x281

    iget-object p2, p0, Lvz1;->t:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    const-string/jumbo v3, "premiumservers"

    if-eqz p2, :cond_1d0

    const/16 v0, 0x200

    new-instance v4, Ltz1;

    nop

    const/4 v5, 0x1

    const/16 v0, 0x1d3

    invoke-direct {v4, p0, v5}, Ltz1;-><init>(Lvz1;I)V

    const/16 v0, 0x5f

    invoke-virtual {p2, v4}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0x281

    iget-object p2, p0, Lvz1;->t:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz p2, :cond_1cb

    const/16 v0, 0x1b0

    new-instance v4, Luz1;

    nop

    const/16 v0, 0x239

    invoke-direct {v4, p0, v5}, Luz1;-><init>(Lvz1;I)V

    const/16 v0, 0x8f

    invoke-virtual {p2, v4}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    const/16 v0, 0x270

    iget-object p2, p0, Lvz1;->v:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    const-string/jumbo v4, "privateServer"

    if-eqz p2, :cond_1c6

    const/16 v0, 0x200

    new-instance v6, Ltz1;

    nop

    const/4 v7, 0x2

    const/16 v0, 0x1d3

    invoke-direct {v6, p0, v7}, Ltz1;-><init>(Lvz1;I)V

    const/16 v0, 0x5f

    invoke-virtual {p2, v6}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0x270

    iget-object p2, p0, Lvz1;->v:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz p2, :cond_1c1

    const/16 v0, 0x1b0

    new-instance v6, Luz1;

    nop

    const/16 v0, 0x239

    invoke-direct {v6, p0, v7}, Luz1;-><init>(Lvz1;I)V

    const/16 v0, 0x8f

    invoke-virtual {p2, v6}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    const/16 v0, 0xde4

    iget-object p2, p0, Lvz1;->q:Lw82;

    nop

    const/16 v0, 0x177

    invoke-virtual {p2}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/content/SharedPreferences;

    const/4 v0, -0x6

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x1c6

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getResources()Landroid/content/res/Resources;

    move-result-object v7

    const/4 v0, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v8, 0x3

    const/16 v0, 0x4fe

    invoke-static {v6, v7, v8}, Lqk;->p(Landroid/content/SharedPreferences;Landroid/content/res/Resources;I)[Ljava/lang/String;

    move-result-object v6

    const/16 v0, 0x281

    iget-object v7, p0, Lvz1;->t:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz v7, :cond_1bc

    array-length v3, v6

    const/16 v6, 0x8

    if-le v3, v5, :cond_129

    move v3, v2

    goto :goto_12a

    :cond_129
    move v3, v6

    :goto_12a
    const/4 v0, -0x5

    invoke-virtual {v7, v3}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0xc48

    iget-object v3, p0, Lvz1;->s:Landroid/view/View;

    nop

    if-eqz v3, :cond_1b4

    const/16 v0, 0x177

    invoke-virtual {p2}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/content/SharedPreferences;

    const-string/jumbo v7, "nfslavailable"

    const/16 v0, 0x77

    invoke-interface {v5, v7, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v5

    if-eqz v5, :cond_14a

    move v5, v2

    goto :goto_14b

    :cond_14a
    move v5, v6

    :goto_14b
    const/4 v0, -0x5

    invoke-virtual {v3, v5}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0x5b5

    iget-object v3, p0, Lvz1;->u:Landroid/view/View;

    nop

    if-eqz v3, :cond_1ac

    const/16 v0, 0x177

    invoke-virtual {p2}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Landroid/content/SharedPreferences;

    const-string/jumbo v7, "nfplavailable"

    const/16 v0, 0x77

    invoke-interface {v5, v7, v2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v5

    if-eqz v5, :cond_16a

    goto :goto_16b

    :cond_16a
    move v2, v6

    :goto_16b
    const/4 v0, -0x5

    invoke-virtual {v3, v2}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0x1fc

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 v3, 0x1d

    if-ge v2, v3, :cond_189

    const/16 v0, 0x270

    iget-object v2, p0, Lvz1;->v:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz v2, :cond_184

    const/4 v0, -0x5

    invoke-virtual {v2, v6}, Landroid/view/View;->setVisibility(I)V

    goto :goto_189

    :cond_184
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_189
    :goto_189
    const/16 v0, 0x140

    sget-boolean p3, Lg4;->a:Z

    nop

    const/16 v0, 0xfb

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object p0

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x177

    invoke-virtual {p2}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Landroid/content/SharedPreferences;

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x394

    invoke-static {p2, p0}, Lg4;->n(Landroid/content/SharedPreferences;Landroidx/fragment/app/l;)V

    check-cast p1, Landroid/view/View;

    return-object p1

    :cond_1ac
    const-string/jumbo p0, "premiumserversRedDot"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_1b4
    const-string/jumbo p0, "officialserversRedDot"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_1bc
    const/4 v0, 0x5

    invoke-static {v3}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_1c1
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_1c6
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_1cb
    const/4 v0, 0x5

    invoke-static {v3}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_1d0
    const/4 v0, 0x5

    invoke-static {v3}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_1d5
    const/4 v0, 0x5

    invoke-static {v3}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_1da
    const/4 v0, 0x5

    invoke-static {v3}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3
.end method

.method public final onStart()V
    .registers 5

    .prologue
    const/16 v0, 0x55f

    invoke-super {p0}, Landroidx/fragment/app/g;->onStart()V

    const/16 v0, 0xaeb

    invoke-virtual {p0}, Landroidx/fragment/app/g;->getDialog()Landroid/app/Dialog;

    move-result-object p0

    if-eqz p0, :cond_34

    const/16 v0, 0xc8b

    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object p0

    if-eqz p0, :cond_34

    const/4 v2, -0x1

    const/4 v3, -0x2

    const/16 v0, 0x1132

    invoke-virtual {p0, v2, v3}, Landroid/view/Window;->setLayout(II)V

    const/16 v0, 0x10ad

    new-instance v2, Landroid/graphics/drawable/ColorDrawable;

    nop

    const/4 v3, 0x0

    const/16 v0, 0xc14

    invoke-direct {v2, v3}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    const/16 v0, 0xba3

    invoke-virtual {p0, v2}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    const v2, 0x7f140137

    const/16 v0, 0xa0d

    invoke-virtual {p0, v2}, Landroid/view/Window;->setWindowAnimations(I)V

    :cond_34
    return-void
.end method
