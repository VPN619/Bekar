.class public final Ll41;
.super Lpr1;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final u:Landroid/widget/TextView;


# direct methods
.method public constructor <init>(Landroid/view/View;)V
    .registers 5

    invoke-direct {p0, p1}, Lpr1;-><init>(Landroid/view/View;)V

    const v2, 0x7f090375

    const/16 v0, 0x11

    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p1, Landroid/widget/TextView;

    const/16 v0, 0xbcc

    iput-object p1, p0, Ll41;->u:Landroid/widget/TextView;

    return-void
.end method
