.class public final synthetic Lf51;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lzj0;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/tlsvpn/tlstunnel/MainActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/tlsvpn/tlstunnel/MainActivity;I)V
    .registers 5

    iput p2, p0, Lf51;->a:I

    iput-object p1, p0, Lf51;->b:Lcom/tlsvpn/tlstunnel/MainActivity;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 6

    .prologue
    const/16 v0, 0xff2

    iget v2, p0, Lf51;->a:I

    nop

    const/16 v0, 0x8d4

    iget-object p0, p0, Lf51;->b:Lcom/tlsvpn/tlstunnel/MainActivity;

    nop

    packed-switch v2, :pswitch_data_62

    const/16 v0, 0x44d

    sget v2, Lcom/tlsvpn/tlstunnel/MainActivity;->m:I

    nop

    const-class v2, Lmd3;

    monitor-enter v2

    :try_start_15
    const/16 v0, 0x7cb

    sget-object v3, Lmd3;->e:Lik3;

    nop

    if-nez v3, :cond_42

    const/16 v0, 0xea6

    new-instance v3, Lly2;

    nop

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v4

    if-eqz v4, :cond_2a

    move-object p0, v4

    :cond_2a
    const/4 v4, 0x0

    const/16 v0, 0xf96

    invoke-direct {v3, p0, v4}, Lly2;-><init>(Landroid/content/Context;Z)V

    const/16 v0, 0x11f9

    new-instance p0, Lik3;

    nop

    const/16 v0, 0x84b

    invoke-direct {p0, v3}, Lik3;-><init>(Lly2;)V

    const/16 v0, 0x1240

    sput-object p0, Lmd3;->e:Lik3;
    :try_end_3e
    .catchall {:try_start_15 .. :try_end_3e} :catchall_40

    move-object v3, p0

    goto :goto_42

    :catchall_40
    move-exception p0

    goto :goto_51

    :cond_42
    :goto_42
    monitor-exit v2

    const/16 v0, 0x82b

    iget-object p0, v3, Lik3;->a:Ltb3;

    nop

    const/16 v0, 0xf6d

    invoke-interface {p0}, Ltb3;->zza()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Lli3;

    return-object p0

    :goto_51
    :try_start_51
    monitor-exit v2
    :try_end_52
    .catchall {:try_start_51 .. :try_end_52} :catchall_40

    throw p0

    :pswitch_53  #0x0
    const/16 v0, 0x44d

    sget v2, Lcom/tlsvpn/tlstunnel/MainActivity;->m:I

    nop

    const/16 v0, 0x2a

    invoke-static {p0}, Lxl1;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    check-cast p0, Ljava/lang/Object;

    return-object p0

    nop

    :pswitch_data_62
    .packed-switch 0x0
        :pswitch_53  #00000000
    .end packed-switch
.end method
