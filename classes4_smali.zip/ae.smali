.class public final Lae;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Ljava/util/ArrayList;

.field public final b:Ljava/util/ArrayList;


# direct methods
.method public constructor <init>(Ljava/util/ArrayList;Ljava/util/ArrayList;)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0xbea

    iput-object p1, p0, Lae;->a:Ljava/util/ArrayList;

    const/16 v0, 0x57e

    iput-object p2, p0, Lae;->b:Ljava/util/ArrayList;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .prologue
    if-ne p0, p1, :cond_3

    goto :goto_31

    :cond_3
    instance-of v2, p1, Lae;

    if-nez v2, :cond_8

    goto :goto_2f

    :cond_8
    check-cast p1, Lae;

    const/16 v0, 0x2b9

    iget-object v2, p0, Lae;->a:Ljava/util/ArrayList;

    nop

    const/16 v0, 0x2b9

    iget-object v3, p1, Lae;->a:Ljava/util/ArrayList;

    nop

    const/16 v0, 0x128

    invoke-virtual {v2, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_1d

    goto :goto_2f

    :cond_1d
    const/16 v0, 0x44a

    iget-object p0, p0, Lae;->b:Ljava/util/ArrayList;

    nop

    const/16 v0, 0x44a

    iget-object p1, p1, Lae;->b:Ljava/util/ArrayList;

    nop

    const/16 v0, 0x128

    invoke-virtual {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_31

    :goto_2f
    const/4 p0, 0x0

    return p0

    :cond_31
    :goto_31
    const/4 p0, 0x1

    return p0
.end method

.method public final hashCode()I
    .registers 4

    const/16 v0, 0x2b9

    iget-object v2, p0, Lae;->a:Ljava/util/ArrayList;

    nop

    const/16 v0, 0x45c

    invoke-virtual {v2}, Ljava/util/ArrayList;->hashCode()I

    move-result v2

    mul-int/lit8 v2, v2, 0x1f

    const/16 v0, 0x44a

    iget-object p0, p0, Lae;->b:Ljava/util/ArrayList;

    nop

    const/16 v0, 0x45c

    invoke-virtual {p0}, Ljava/util/ArrayList;->hashCode()I

    move-result p0

    add-int/2addr p0, v2

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 5

    const/4 v0, -0x3

    new-instance v2, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v3, "AppList(checked="

    const/16 v0, 0x97

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x2b9

    iget-object v3, p0, Lae;->a:Ljava/util/ArrayList;

    nop

    const/16 v0, 0x190

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string/jumbo v3, ", unchecked="

    const/4 v0, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x44a

    iget-object p0, p0, Lae;->b:Ljava/util/ArrayList;

    nop

    const/16 v0, 0x190

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 p0, 0x29

    const/16 v0, 0x1b

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    return-object p0
.end method
