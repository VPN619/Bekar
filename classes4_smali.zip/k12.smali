.class public final Lk12;
.super Lpr1;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final A:Landroidx/constraintlayout/widget/ConstraintLayout;

.field public final B:Landroid/widget/ImageView;

.field public final C:Landroid/widget/TextView;

.field public final D:Lcom/google/android/material/card/MaterialCardView;

.field public final E:Landroid/widget/ImageView;

.field public final u:Landroid/widget/ImageView;

.field public final v:Landroidx/constraintlayout/widget/ConstraintLayout;

.field public final w:Landroid/widget/ImageView;

.field public final x:Landroid/widget/TextView;

.field public final y:Landroid/widget/TextView;

.field public final z:Landroid/widget/ProgressBar;


# direct methods
.method public constructor <init>(Landroid/view/View;)V
    .registers 5

    invoke-direct {p0, p1}, Lpr1;-><init>(Landroid/view/View;)V

    const v2, 0x7f09030d

    const/16 v0, 0x11

    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/ImageView;

    const/16 v0, 0xd71

    iput-object v2, p0, Lk12;->u:Landroid/widget/ImageView;

    const v2, 0x7f0903ad

    const/16 v0, 0x11

    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroidx/constraintlayout/widget/ConstraintLayout;

    const/16 v0, 0xb2a

    iput-object v2, p0, Lk12;->v:Landroidx/constraintlayout/widget/ConstraintLayout;

    const v2, 0x7f09031a

    const/16 v0, 0x11

    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/ImageView;

    const/16 v0, 0x10fe

    iput-object v2, p0, Lk12;->w:Landroid/widget/ImageView;

    const v2, 0x7f090323

    const/16 v0, 0x11

    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    const/16 v0, 0x566

    iput-object v2, p0, Lk12;->x:Landroid/widget/TextView;

    const v2, 0x7f0900ae

    const/16 v0, 0x11

    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    const/16 v0, 0xf12

    iput-object v2, p0, Lk12;->y:Landroid/widget/TextView;

    const v2, 0x7f090169

    const/16 v0, 0x11

    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/ProgressBar;

    const/16 v0, 0x91c

    iput-object v2, p0, Lk12;->z:Landroid/widget/ProgressBar;

    const v2, 0x7f090389

    const/16 v0, 0x11

    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroidx/constraintlayout/widget/ConstraintLayout;

    const/16 v0, 0xac8

    iput-object v2, p0, Lk12;->A:Landroidx/constraintlayout/widget/ConstraintLayout;

    const v2, 0x7f090149

    const/16 v0, 0x11

    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/ImageView;

    const/16 v0, 0xc50

    iput-object v2, p0, Lk12;->B:Landroid/widget/ImageView;

    const v2, 0x7f0903a5

    const/16 v0, 0x11

    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    const/16 v0, 0x103f

    iput-object v2, p0, Lk12;->C:Landroid/widget/TextView;

    const v2, 0x7f0903a6

    const/16 v0, 0x11

    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Lcom/google/android/material/card/MaterialCardView;

    const/16 v0, 0x81d

    iput-object v2, p0, Lk12;->D:Lcom/google/android/material/card/MaterialCardView;

    const v2, 0x7f09014a

    const/16 v0, 0x11

    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/ImageView;

    const/16 v0, 0x111c

    iput-object p1, p0, Lk12;->E:Landroid/widget/ImageView;

    return-void
.end method
