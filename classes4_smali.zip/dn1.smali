.class public final Ldn1;
.super Lvb;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public A:Landroid/widget/EditText;

.field public B:Landroid/widget/EditText;

.field public C:Lcom/google/android/material/textfield/TextInputLayout;

.field public D:Landroid/widget/EditText;

.field public E:Lcom/google/android/material/textfield/TextInputLayout;

.field public F:Landroidx/constraintlayout/widget/ConstraintLayout;

.field public G:Landroid/widget/TextView;

.field public final q:Lw82;

.field public r:Z

.field public s:Landroid/widget/ImageView;

.field public t:Landroid/widget/LinearLayout;

.field public u:Landroid/widget/TextView;

.field public v:Landroid/widget/TableLayout;

.field public w:Landroid/widget/EditText;

.field public x:Lcom/google/android/material/textfield/TextInputLayout;

.field public y:Landroid/widget/EditText;

.field public z:Lcom/google/android/material/textfield/TextInputLayout;


# direct methods
.method public constructor <init>()V
    .registers 5

    invoke-direct {p0}, Lvb;-><init>()V

    const/16 v0, 0xa84

    new-instance v2, Ld;

    nop

    const/16 v3, 0x17

    const/16 v0, 0x6cb

    invoke-direct {v2, v3, p0}, Ld;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x27a

    new-instance v3, Lw82;

    nop

    const/16 v0, 0x215

    invoke-direct {v3, v2}, Lw82;-><init>(Lzj0;)V

    const/16 v0, 0x80e

    iput-object v3, p0, Ldn1;->q:Lw82;

    const/4 v2, 0x1

    const/16 v0, 0x742

    iput-boolean v2, p0, Ldn1;->r:Z

    return-void
.end method


# virtual methods
.method public final c(ZZ)V
    .registers 9

    .prologue
    const-string/jumbo v2, "pserver"

    if-eqz p1, :cond_25

    const/16 v0, 0x5e

    invoke-virtual {p0}, Ldn1;->e()Landroid/content/SharedPreferences;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x7a

    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    const/16 v0, 0x48

    invoke-interface {p1, v2, p2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x6f

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/16 v0, 0x4a1

    invoke-virtual {p0}, Ldn1;->g()V

    return-void

    :cond_25
    const/16 v0, 0xf8

    iget-object p1, p0, Ldn1;->w:Landroid/widget/EditText;

    nop

    const/4 v3, 0x0

    const-string/jumbo v4, "sshhost"

    if-eqz p1, :cond_178

    const/16 v0, 0x2d

    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x7c

    invoke-static {p1}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result p1

    const v5, 0x7f1300c8

    if-eqz p1, :cond_71

    const/16 v0, 0xf8

    iget-object p1, p0, Ldn1;->w:Landroid/widget/EditText;

    nop

    if-eqz p1, :cond_6c

    const/16 v0, 0xc4

    invoke-virtual {p1}, Landroid/view/View;->requestFocus()Z

    const/16 v0, 0x500

    iget-object p1, p0, Ldn1;->x:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz p1, :cond_64

    const/16 v0, 0x4c

    invoke-virtual {p0, v5}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x6e

    invoke-virtual {p1, p0}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    return-void

    :cond_64
    const-string/jumbo p0, "sshhost_l"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_6c
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_71
    const/16 v0, 0x129

    iget-object p1, p0, Ldn1;->y:Landroid/widget/EditText;

    nop

    const-string/jumbo v4, "sshport"

    if-eqz p1, :cond_173

    const/16 v0, 0x2d

    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x7c

    invoke-static {p1}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result p1

    if-eqz p1, :cond_b9

    const/16 v0, 0x129

    iget-object p1, p0, Ldn1;->y:Landroid/widget/EditText;

    nop

    if-eqz p1, :cond_b4

    const/16 v0, 0xc4

    invoke-virtual {p1}, Landroid/view/View;->requestFocus()Z

    const/16 v0, 0x4ed

    iget-object p1, p0, Ldn1;->z:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz p1, :cond_ac

    const/16 v0, 0x4c

    invoke-virtual {p0, v5}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x6e

    invoke-virtual {p1, p0}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    return-void

    :cond_ac
    const-string/jumbo p0, "sshport_l"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_b4
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_b9
    const/16 v0, 0x94

    iget-object p1, p0, Ldn1;->B:Landroid/widget/EditText;

    nop

    const-string/jumbo v4, "sshuser"

    if-eqz p1, :cond_16e

    const/16 v0, 0x2d

    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x7c

    invoke-static {p1}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result p1

    if-eqz p1, :cond_101

    const/16 v0, 0x94

    iget-object p1, p0, Ldn1;->B:Landroid/widget/EditText;

    nop

    if-eqz p1, :cond_fc

    const/16 v0, 0xc4

    invoke-virtual {p1}, Landroid/view/View;->requestFocus()Z

    const/16 v0, 0x4ce

    iget-object p1, p0, Ldn1;->C:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz p1, :cond_f4

    const/16 v0, 0x4c

    invoke-virtual {p0, v5}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x6e

    invoke-virtual {p1, p0}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    return-void

    :cond_f4
    const-string/jumbo p0, "sshuser_l"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_fc
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_101
    const/16 v0, 0x81

    iget-object p1, p0, Ldn1;->D:Landroid/widget/EditText;

    nop

    const-string/jumbo v4, "sshpass"

    if-eqz p1, :cond_169

    const/16 v0, 0x2d

    invoke-virtual {p1}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x7c

    invoke-static {p1}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result p1

    if-eqz p1, :cond_149

    const/16 v0, 0x81

    iget-object p1, p0, Ldn1;->D:Landroid/widget/EditText;

    nop

    if-eqz p1, :cond_144

    const/16 v0, 0xc4

    invoke-virtual {p1}, Landroid/view/View;->requestFocus()Z

    const/16 v0, 0x2f1

    iget-object p1, p0, Ldn1;->E:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz p1, :cond_13c

    const/16 v0, 0x4c

    invoke-virtual {p0, v5}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x6e

    invoke-virtual {p1, p0}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    return-void

    :cond_13c
    const-string/jumbo p0, "sshpass_l"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_144
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_149
    const/16 v0, 0x5e

    invoke-virtual {p0}, Ldn1;->e()Landroid/content/SharedPreferences;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x7a

    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    const/16 v0, 0x48

    invoke-interface {p1, v2, p2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x6f

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/16 v0, 0x4a1

    invoke-virtual {p0}, Ldn1;->g()V

    return-void

    :cond_169
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_16e
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_173
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_178
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3
.end method

.method public final d()V
    .registers 7

    .prologue
    const/16 v0, 0x94

    iget-object v2, p0, Ldn1;->B:Landroid/widget/EditText;

    nop

    const/4 v3, 0x0

    const-string/jumbo v4, "sshuser"

    if-eqz v2, :cond_bd

    const/16 v0, 0x2d

    invoke-virtual {v2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x7c

    invoke-static {v2}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v2

    const v5, 0x7f1300c8

    if-eqz v2, :cond_4c

    const/16 v0, 0x94

    iget-object v2, p0, Ldn1;->B:Landroid/widget/EditText;

    nop

    if-eqz v2, :cond_47

    const/16 v0, 0xc4

    invoke-virtual {v2}, Landroid/view/View;->requestFocus()Z

    const/16 v0, 0x4ce

    iget-object v2, p0, Ldn1;->C:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz v2, :cond_3f

    const/16 v0, 0x4c

    invoke-virtual {p0, v5}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x6e

    invoke-virtual {v2, p0}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    return-void

    :cond_3f
    const-string/jumbo p0, "sshuser_l"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_47
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_4c
    const/16 v0, 0x81

    iget-object v2, p0, Ldn1;->D:Landroid/widget/EditText;

    nop

    const-string/jumbo v4, "sshpass"

    if-eqz v2, :cond_b8

    const/16 v0, 0x2d

    invoke-virtual {v2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x7c

    invoke-static {v2}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v2

    if-eqz v2, :cond_94

    const/16 v0, 0x81

    iget-object v2, p0, Ldn1;->D:Landroid/widget/EditText;

    nop

    if-eqz v2, :cond_8f

    const/16 v0, 0xc4

    invoke-virtual {v2}, Landroid/view/View;->requestFocus()Z

    const/16 v0, 0x2f1

    iget-object v2, p0, Ldn1;->E:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz v2, :cond_87

    const/16 v0, 0x4c

    invoke-virtual {p0, v5}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x6e

    invoke-virtual {v2, p0}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    return-void

    :cond_87
    const-string/jumbo p0, "sshpass_l"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_8f
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_94
    const/16 v0, 0x5e

    invoke-virtual {p0}, Ldn1;->e()Landroid/content/SharedPreferences;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x7a

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string/jumbo v3, "pserver"

    const/4 v4, 0x1

    const/16 v0, 0x48

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x6f

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/16 v0, 0x4a1

    invoke-virtual {p0}, Ldn1;->g()V

    return-void

    :cond_b8
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_bd
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3
.end method

.method public final e()Landroid/content/SharedPreferences;
    .registers 3

    const/16 v0, 0xd6c

    iget-object p0, p0, Ldn1;->q:Lw82;

    nop

    const/16 v0, 0x177

    invoke-virtual {p0}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/content/SharedPreferences;

    return-object p0
.end method

.method public final f()V
    .registers 7

    .prologue
    const/16 v0, 0x5e

    invoke-virtual {p0}, Ldn1;->e()Landroid/content/SharedPreferences;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x7a

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const/16 v0, 0xf8

    iget-object v3, p0, Ldn1;->w:Landroid/widget/EditText;

    nop

    const/4 v4, 0x0

    const-string/jumbo v5, "sshhost"

    if-eqz v3, :cond_d4

    const/16 v0, 0x2d

    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v3

    const/16 v0, 0xcb

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    const/16 v0, 0x3c

    invoke-interface {v2, v5, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x129

    iget-object v3, p0, Ldn1;->y:Landroid/widget/EditText;

    nop

    const-string/jumbo v5, "sshport"

    if-eqz v3, :cond_cf

    const/16 v0, 0x2d

    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v3

    const/16 v0, 0xcb

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    const/16 v0, 0x3c

    invoke-interface {v2, v5, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x357

    iget-object v3, p0, Ldn1;->A:Landroid/widget/EditText;

    nop

    const-string/jumbo v5, "udpgwport"

    if-eqz v3, :cond_ca

    const/16 v0, 0x2d

    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v3

    const/4 v0, -0x6

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xff

    invoke-interface {v3}, Ljava/lang/CharSequence;->length()I

    move-result v3

    if-lez v3, :cond_7c

    const/16 v0, 0x357

    iget-object v3, p0, Ldn1;->A:Landroid/widget/EditText;

    nop

    if-eqz v3, :cond_77

    const/16 v0, 0x2d

    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v3

    const/16 v0, 0xcb

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    goto :goto_7f

    :cond_77
    const/4 v0, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_7c
    const-string/jumbo v3, "7300"

    :goto_7f
    const/16 v0, 0x3c

    invoke-interface {v2, v5, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x94

    iget-object v3, p0, Ldn1;->B:Landroid/widget/EditText;

    nop

    const-string/jumbo v5, "sshuser"

    if-eqz v3, :cond_c5

    const/16 v0, 0x2d

    invoke-virtual {v3}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v3

    const/16 v0, 0xcb

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    const/16 v0, 0x3c

    invoke-interface {v2, v5, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x81

    iget-object p0, p0, Ldn1;->D:Landroid/widget/EditText;

    nop

    const-string/jumbo v3, "sshpass"

    if-eqz p0, :cond_c0

    const/16 v0, 0x2d

    invoke-virtual {p0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p0

    const/16 v0, 0xcb

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x3c

    invoke-interface {v2, v3, p0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x6f

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void

    :cond_c0
    const/4 v0, 0x5

    invoke-static {v3}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_c5
    const/4 v0, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_ca
    const/4 v0, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_cf
    const/4 v0, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_d4
    const/4 v0, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4
.end method

.method public final g()V
    .registers 6

    const/16 v0, 0x768

    invoke-virtual {p0}, Ldn1;->f()V

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v2

    const/16 v0, 0x5b

    new-instance v3, Landroid/content/Intent;

    nop

    const-string/jumbo v4, "restoreHome"

    const/16 v0, 0x62

    invoke-direct {v3, v4}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v4

    const/16 v0, 0x53

    invoke-virtual {v4}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v4

    const/16 v0, 0x4a

    invoke-virtual {v4}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    const/16 v0, 0x64

    invoke-virtual {v3, v4}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v3

    const/16 v0, 0x63

    invoke-virtual {v2, v3}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    const/16 v0, 0x181

    invoke-virtual {p0}, Landroidx/fragment/app/g;->dismiss()V

    return-void
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .registers 6

    .prologue
    const/16 v0, 0x11c5

    invoke-super {p0, p1}, Landroidx/fragment/app/g;->onCreate(Landroid/os/Bundle;)V

    const/16 v0, 0xc2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getArguments()Landroid/os/Bundle;

    move-result-object p1

    if-eqz p1, :cond_1b

    const-string/jumbo v2, "eptalert"

    const/4 v3, 0x1

    const/16 v0, 0x428

    invoke-virtual {p1, v2, v3}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;Z)Z

    move-result p1

    const/16 v0, 0x742

    iput-boolean p1, p0, Ldn1;->r:Z

    :cond_1b
    return-void
.end method

.method public final onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .registers 29

    .prologue
    move-object/from16 v8, p0

    const/4 v6, -0x6

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const v9, 0x7f0c00c4

    const/4 v10, 0x0

    move-object/from16 v11, p1

    move-object/from16 v12, p2

    const/16 v6, 0x107b

    invoke-virtual {v11, v9, v12, v10}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object v9

    const v11, 0x7f09013b

    const/16 v6, 0x11

    invoke-virtual {v9, v11}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v11

    const/4 v6, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v11, Landroid/widget/ImageView;

    const/16 v6, 0x59c

    iput-object v11, v8, Ldn1;->s:Landroid/widget/ImageView;

    const v11, 0x7f090317

    const/16 v6, 0x11

    invoke-virtual {v9, v11}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v11

    const/4 v6, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v11, Landroid/widget/LinearLayout;

    const/16 v6, 0xa73

    iput-object v11, v8, Ldn1;->t:Landroid/widget/LinearLayout;

    const v11, 0x7f090258

    const/16 v6, 0x11

    invoke-virtual {v9, v11}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v11

    const/4 v6, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v11, Landroid/widget/TextView;

    const/16 v6, 0x9a9

    iput-object v11, v8, Ldn1;->u:Landroid/widget/TextView;

    const v11, 0x7f09034b

    const/16 v6, 0x11

    invoke-virtual {v9, v11}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v11

    const/4 v6, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v11, Landroid/widget/TableLayout;

    const/16 v6, 0x9a4

    iput-object v11, v8, Ldn1;->v:Landroid/widget/TableLayout;

    const v11, 0x7f090349

    const/16 v6, 0x11

    invoke-virtual {v9, v11}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v11

    const/4 v6, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v11, Landroid/widget/EditText;

    const/16 v6, 0x9b1

    iput-object v11, v8, Ldn1;->w:Landroid/widget/EditText;

    const v11, 0x7f09034a

    const/16 v6, 0x11

    invoke-virtual {v9, v11}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v11

    const/4 v6, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v11, Lcom/google/android/material/textfield/TextInputLayout;

    const/16 v6, 0x1114

    iput-object v11, v8, Ldn1;->x:Lcom/google/android/material/textfield/TextInputLayout;

    const v11, 0x7f09034f

    const/16 v6, 0x11

    invoke-virtual {v9, v11}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v11

    const/4 v6, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v11, Landroid/widget/EditText;

    const/16 v6, 0x1176

    iput-object v11, v8, Ldn1;->y:Landroid/widget/EditText;

    const v11, 0x7f090350

    const/16 v6, 0x11

    invoke-virtual {v9, v11}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v11

    const/4 v6, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v11, Lcom/google/android/material/textfield/TextInputLayout;

    const/16 v6, 0x1221

    iput-object v11, v8, Ldn1;->z:Lcom/google/android/material/textfield/TextInputLayout;

    const v11, 0x7f0903a7

    const/16 v6, 0x11

    invoke-virtual {v9, v11}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v11

    const/4 v6, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v11, Landroid/widget/EditText;

    const/16 v6, 0xa3e

    iput-object v11, v8, Ldn1;->A:Landroid/widget/EditText;

    const v11, 0x7f090354

    const/16 v6, 0x11

    invoke-virtual {v9, v11}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v11

    const/4 v6, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v11, Landroid/widget/LinearLayout;

    const v11, 0x7f090352

    const/16 v6, 0x11

    invoke-virtual {v9, v11}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v11

    const/4 v6, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v11, Landroid/widget/EditText;

    const/16 v6, 0xeec

    iput-object v11, v8, Ldn1;->B:Landroid/widget/EditText;

    const v11, 0x7f090353

    const/16 v6, 0x11

    invoke-virtual {v9, v11}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v11

    const/4 v6, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v11, Lcom/google/android/material/textfield/TextInputLayout;

    const/16 v6, 0xfd3

    iput-object v11, v8, Ldn1;->C:Lcom/google/android/material/textfield/TextInputLayout;

    const v11, 0x7f09034d

    const/16 v6, 0x11

    invoke-virtual {v9, v11}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v11

    const/4 v6, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v11, Landroid/widget/EditText;

    const/16 v6, 0xa16

    iput-object v11, v8, Ldn1;->D:Landroid/widget/EditText;

    const v11, 0x7f09034e

    const/16 v6, 0x11

    invoke-virtual {v9, v11}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v11

    const/4 v6, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v11, Lcom/google/android/material/textfield/TextInputLayout;

    const/16 v6, 0x674

    iput-object v11, v8, Ldn1;->E:Lcom/google/android/material/textfield/TextInputLayout;

    const v11, 0x7f090058

    const/16 v6, 0x11

    invoke-virtual {v9, v11}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v11

    const/4 v6, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v11, Landroidx/constraintlayout/widget/ConstraintLayout;

    const/16 v6, 0x8dc

    iput-object v11, v8, Ldn1;->F:Landroidx/constraintlayout/widget/ConstraintLayout;

    const v11, 0x7f090059

    const/16 v6, 0x11

    invoke-virtual {v9, v11}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v11

    const/4 v6, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v11, Landroid/widget/TextView;

    const/16 v6, 0xd4e

    iput-object v11, v8, Ldn1;->G:Landroid/widget/TextView;

    const/16 v6, 0xf8

    iget-object v11, v8, Ldn1;->w:Landroid/widget/EditText;

    nop

    const-string/jumbo v13, "sshhost"

    if-eqz v11, :cond_6b0

    const/16 v6, 0xb36

    new-instance v14, Lc;

    nop

    const/16 v15, 0x16

    const/16 v6, 0x87c

    invoke-direct {v14, v15, v8}, Lc;-><init>(ILjava/lang/Object;)V

    const/16 v6, 0x1156

    invoke-virtual {v11, v14}, Landroid/view/View;->post(Ljava/lang/Runnable;)Z

    const/16 v6, 0xf8

    iget-object v11, v8, Ldn1;->w:Landroid/widget/EditText;

    nop

    if-eqz v11, :cond_6a9

    const/16 v6, 0x18c

    new-instance v14, Lcn1;

    nop

    const/16 v6, 0x15a

    invoke-direct {v14, v8, v10}, Lcn1;-><init>(Ldn1;I)V

    const/16 v6, 0xb8

    invoke-virtual {v11, v14}, Landroid/widget/TextView;->addTextChangedListener(Landroid/text/TextWatcher;)V

    const/16 v6, 0x129

    iget-object v11, v8, Ldn1;->y:Landroid/widget/EditText;

    nop

    const-string/jumbo v14, "sshport"

    if-eqz v11, :cond_6a2

    const/16 v6, 0x18c

    new-instance v15, Lcn1;

    nop

    const/16 v16, 0x1

    const/16 v6, 0x15a

    move/from16 v0, v16

    invoke-direct {v15, v8, v0}, Lcn1;-><init>(Ldn1;I)V

    const/16 v6, 0xb8

    invoke-virtual {v11, v15}, Landroid/widget/TextView;->addTextChangedListener(Landroid/text/TextWatcher;)V

    const/16 v6, 0x94

    iget-object v11, v8, Ldn1;->B:Landroid/widget/EditText;

    nop

    const-string/jumbo v15, "sshuser"

    if-eqz v11, :cond_69b

    const/16 v6, 0x18c

    new-instance v17, Lcn1;

    nop

    const/16 v18, 0x2

    const/16 v6, 0x15a

    move-object/from16 v0, v17

    move/from16 v1, v18

    invoke-direct {v0, v8, v1}, Lcn1;-><init>(Ldn1;I)V

    const/16 v6, 0xb8

    move-object/from16 v0, v17

    invoke-virtual {v11, v0}, Landroid/widget/TextView;->addTextChangedListener(Landroid/text/TextWatcher;)V

    const/16 v6, 0x81

    iget-object v11, v8, Ldn1;->D:Landroid/widget/EditText;

    nop

    const-string/jumbo v17, "sshpass"

    if-eqz v11, :cond_692

    const/16 v6, 0x18c

    new-instance v19, Lcn1;

    nop

    const/16 v20, 0x3

    const/16 v6, 0x15a

    move-object/from16 v0, v19

    move/from16 v1, v20

    invoke-direct {v0, v8, v1}, Lcn1;-><init>(Ldn1;I)V

    const/16 v6, 0xb8

    move-object/from16 v0, v19

    invoke-virtual {v11, v0}, Landroid/widget/TextView;->addTextChangedListener(Landroid/text/TextWatcher;)V

    const/16 v6, 0x166

    iget-object v11, v8, Ldn1;->s:Landroid/widget/ImageView;

    nop

    const-string/jumbo v19, "top_bar_right_icon"

    if-eqz v11, :cond_689

    const/16 v6, 0x79

    new-instance v21, Lbn1;

    nop

    const/16 v6, 0x6c

    move-object/from16 v0, v21

    invoke-direct {v0, v8, v10}, Lbn1;-><init>(Ldn1;I)V

    const/16 v6, 0x5f

    move-object/from16 v0, v21

    invoke-virtual {v11, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v6, 0x15c

    iget-object v11, v8, Ldn1;->F:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    const-string/jumbo v21, "aplicar"

    if-eqz v11, :cond_680

    const/16 v6, 0x79

    new-instance v22, Lbn1;

    nop

    const/16 v6, 0x6c

    move-object/from16 v0, v22

    move/from16 v1, v16

    invoke-direct {v0, v8, v1}, Lbn1;-><init>(Ldn1;I)V

    const/16 v6, 0x5f

    move-object/from16 v0, v22

    invoke-virtual {v11, v0}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v6, 0x8ea

    new-instance v11, Lou;

    nop

    const/16 v6, 0x5e

    invoke-virtual {v8}, Ldn1;->e()Landroid/content/SharedPreferences;

    move-result-object v16

    const/4 v6, -0x6

    move-object/from16 v0, v16

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x1c6

    invoke-virtual {v8}, Landroidx/fragment/app/Fragment;->getResources()Landroid/content/res/Resources;

    move-result-object v22

    const/4 v6, -0x6

    move-object/from16 v0, v22

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x83d

    move v0, v6

    move-object v1, v11

    move-object/from16 v2, v16

    move-object/from16 v3, v22

    move v4, v10

    move v5, v10

    invoke-direct/range {v1 .. v5}, Lou;-><init>(Landroid/content/SharedPreferences;Landroid/content/res/Resources;ZZ)V

    const/16 v6, 0x75

    iget-boolean v10, v11, Lou;->w:Z

    nop

    const-string/jumbo v16, "sshpass_l"

    const-string/jumbo v22, "sshuser_l"

    const v23, 0x7f1300c8

    const/16 p1, 0x0

    const-string/jumbo v12, ""

    if-nez v10, :cond_402

    const/16 v6, 0xf8

    iget-object v10, v8, Ldn1;->w:Landroid/widget/EditText;

    nop

    if-eqz v10, :cond_3fd

    const/16 v6, 0x5e

    invoke-virtual {v8}, Ldn1;->e()Landroid/content/SharedPreferences;

    move-result-object v11

    const/16 v6, 0x2e

    invoke-interface {v11, v13, v12}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const/16 v6, 0x8a

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v6, 0x129

    iget-object v10, v8, Ldn1;->y:Landroid/widget/EditText;

    nop

    if-eqz v10, :cond_3f8

    const/16 v6, 0x5e

    invoke-virtual {v8}, Ldn1;->e()Landroid/content/SharedPreferences;

    move-result-object v11

    const/16 v6, 0x2e

    invoke-interface {v11, v14, v12}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const/16 v6, 0x8a

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v6, 0x94

    iget-object v10, v8, Ldn1;->B:Landroid/widget/EditText;

    nop

    if-eqz v10, :cond_3f3

    const/16 v6, 0x5e

    invoke-virtual {v8}, Ldn1;->e()Landroid/content/SharedPreferences;

    move-result-object v11

    const/16 v6, 0x2e

    invoke-interface {v11, v15, v12}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const/16 v6, 0x8a

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v6, 0x81

    iget-object v10, v8, Ldn1;->D:Landroid/widget/EditText;

    nop

    if-eqz v10, :cond_3ec

    const/16 v6, 0x5e

    invoke-virtual {v8}, Ldn1;->e()Landroid/content/SharedPreferences;

    move-result-object v11

    const/16 v6, 0x2e

    move-object/from16 v0, v17

    invoke-interface {v11, v0, v12}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const/16 v6, 0x8a

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v6, 0x296

    iget-boolean v10, v8, Ldn1;->r:Z

    nop

    if-eqz v10, :cond_61a

    const/16 v6, 0xf8

    iget-object v10, v8, Ldn1;->w:Landroid/widget/EditText;

    nop

    if-eqz v10, :cond_3e7

    const/16 v6, 0x2d

    invoke-virtual {v10}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v10

    const/4 v6, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x7c

    invoke-static {v10}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v10

    if-eqz v10, :cond_2fe

    const/16 v6, 0xf8

    iget-object v10, v8, Ldn1;->w:Landroid/widget/EditText;

    nop

    if-eqz v10, :cond_2f9

    const/16 v6, 0xc4

    invoke-virtual {v10}, Landroid/view/View;->requestFocus()Z

    const/16 v6, 0x500

    iget-object v10, v8, Ldn1;->x:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz v10, :cond_2f1

    const/16 v6, 0x4c

    move/from16 v0, v23

    invoke-virtual {v8, v0}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v11

    const/16 v6, 0x6e

    invoke-virtual {v10, v11}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    goto/16 :goto_61a

    :cond_2f1
    const-string/jumbo v8, "sshhost_l"

    const/4 v6, 0x5

    invoke-static {v8}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_2f9
    const/4 v6, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_2fe
    const/16 v6, 0x129

    iget-object v10, v8, Ldn1;->y:Landroid/widget/EditText;

    nop

    if-eqz v10, :cond_3e2

    const/16 v6, 0x2d

    invoke-virtual {v10}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v10

    const/4 v6, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x7c

    invoke-static {v10}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v10

    if-eqz v10, :cond_346

    const/16 v6, 0x129

    iget-object v10, v8, Ldn1;->y:Landroid/widget/EditText;

    nop

    if-eqz v10, :cond_341

    const/16 v6, 0xc4

    invoke-virtual {v10}, Landroid/view/View;->requestFocus()Z

    const/16 v6, 0x4ed

    iget-object v10, v8, Ldn1;->z:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz v10, :cond_339

    const/16 v6, 0x4c

    move/from16 v0, v23

    invoke-virtual {v8, v0}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v11

    const/16 v6, 0x6e

    invoke-virtual {v10, v11}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    goto/16 :goto_61a

    :cond_339
    const-string/jumbo v8, "sshport_l"

    const/4 v6, 0x5

    invoke-static {v8}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_341
    const/4 v6, 0x5

    invoke-static {v14}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_346
    const/16 v6, 0x94

    iget-object v10, v8, Ldn1;->B:Landroid/widget/EditText;

    nop

    if-eqz v10, :cond_3dd

    const/16 v6, 0x2d

    invoke-virtual {v10}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v10

    const/4 v6, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x7c

    invoke-static {v10}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v10

    if-eqz v10, :cond_38d

    const/16 v6, 0x94

    iget-object v10, v8, Ldn1;->B:Landroid/widget/EditText;

    nop

    if-eqz v10, :cond_388

    const/16 v6, 0xc4

    invoke-virtual {v10}, Landroid/view/View;->requestFocus()Z

    const/16 v6, 0x4ce

    iget-object v10, v8, Ldn1;->C:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz v10, :cond_381

    const/16 v6, 0x4c

    move/from16 v0, v23

    invoke-virtual {v8, v0}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v11

    const/16 v6, 0x6e

    invoke-virtual {v10, v11}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    goto/16 :goto_61a

    :cond_381
    const/4 v6, 0x5

    move-object/from16 v0, v22

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_388
    const/4 v6, 0x5

    invoke-static {v15}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_38d
    const/16 v6, 0x81

    iget-object v10, v8, Ldn1;->D:Landroid/widget/EditText;

    nop

    if-eqz v10, :cond_3d6

    const/16 v6, 0x2d

    invoke-virtual {v10}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v10

    const/4 v6, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x7c

    invoke-static {v10}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v10

    if-eqz v10, :cond_61a

    const/16 v6, 0x81

    iget-object v10, v8, Ldn1;->D:Landroid/widget/EditText;

    nop

    if-eqz v10, :cond_3cf

    const/16 v6, 0xc4

    invoke-virtual {v10}, Landroid/view/View;->requestFocus()Z

    const/16 v6, 0x2f1

    iget-object v10, v8, Ldn1;->E:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz v10, :cond_3c8

    const/16 v6, 0x4c

    move/from16 v0, v23

    invoke-virtual {v8, v0}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v11

    const/16 v6, 0x6e

    invoke-virtual {v10, v11}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    goto/16 :goto_61a

    :cond_3c8
    const/4 v6, 0x5

    move-object/from16 v0, v16

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_3cf
    const/4 v6, 0x5

    move-object/from16 v0, v17

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_3d6
    const/4 v6, 0x5

    move-object/from16 v0, v17

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_3dd
    const/4 v6, 0x5

    invoke-static {v15}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_3e2
    const/4 v6, 0x5

    invoke-static {v14}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_3e7
    const/4 v6, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_3ec
    const/4 v6, 0x5

    move-object/from16 v0, v17

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_3f3
    const/4 v6, 0x5

    invoke-static {v15}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_3f8
    const/4 v6, 0x5

    invoke-static {v14}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_3fd
    const/4 v6, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_402
    const/16 v6, 0x1002

    iget-boolean v10, v11, Lou;->z:Z

    nop

    const-string/jumbo v13, "fullcfg"

    const/16 v14, 0x8

    const-string/jumbo v24, "msginfo"

    if-eqz v10, :cond_5c3

    const/16 v6, 0xbe2

    iget-boolean v10, v11, Lou;->A:Z

    nop

    if-nez v10, :cond_560

    const/16 v6, 0x1fa

    iget-object v10, v8, Ldn1;->u:Landroid/widget/TextView;

    nop

    if-eqz v10, :cond_559

    const v11, 0x7f130214

    const/16 v6, 0x93

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(I)V

    const/16 v6, 0xa21

    iget-object v10, v8, Ldn1;->v:Landroid/widget/TableLayout;

    nop

    if-eqz v10, :cond_551

    const/4 v6, -0x5

    invoke-virtual {v10, v14}, Landroid/view/View;->setVisibility(I)V

    const/16 v6, 0x94

    iget-object v10, v8, Ldn1;->B:Landroid/widget/EditText;

    nop

    if-eqz v10, :cond_54c

    const/16 v6, 0x5e

    invoke-virtual {v8}, Ldn1;->e()Landroid/content/SharedPreferences;

    move-result-object v11

    const/16 v6, 0x2e

    invoke-interface {v11, v15, v12}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const/16 v6, 0x8a

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v6, 0x81

    iget-object v10, v8, Ldn1;->D:Landroid/widget/EditText;

    nop

    if-eqz v10, :cond_545

    const/16 v6, 0x5e

    invoke-virtual {v8}, Ldn1;->e()Landroid/content/SharedPreferences;

    move-result-object v11

    const/16 v6, 0x2e

    move-object/from16 v0, v17

    invoke-interface {v11, v0, v12}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const/16 v6, 0x8a

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v6, 0x166

    iget-object v10, v8, Ldn1;->s:Landroid/widget/ImageView;

    nop

    if-eqz v10, :cond_53e

    const/16 v6, 0x79

    new-instance v11, Lbn1;

    nop

    const/16 v6, 0x6c

    move/from16 v0, v18

    invoke-direct {v11, v8, v0}, Lbn1;-><init>(Ldn1;I)V

    const/16 v6, 0x5f

    invoke-virtual {v10, v11}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v6, 0x15c

    iget-object v10, v8, Ldn1;->F:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz v10, :cond_537

    const/16 v6, 0x79

    new-instance v11, Lbn1;

    nop

    const/16 v6, 0x6c

    move/from16 v0, v20

    invoke-direct {v11, v8, v0}, Lbn1;-><init>(Ldn1;I)V

    const/16 v6, 0x5f

    invoke-virtual {v10, v11}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v6, 0x296

    iget-boolean v10, v8, Ldn1;->r:Z

    nop

    if-eqz v10, :cond_61a

    const/16 v6, 0x94

    iget-object v10, v8, Ldn1;->B:Landroid/widget/EditText;

    nop

    if-eqz v10, :cond_532

    const/16 v6, 0x2d

    invoke-virtual {v10}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v10

    const/4 v6, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x7c

    invoke-static {v10}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v10

    if-eqz v10, :cond_4e2

    const/16 v6, 0x94

    iget-object v10, v8, Ldn1;->B:Landroid/widget/EditText;

    nop

    if-eqz v10, :cond_4dd

    const/16 v6, 0xc4

    invoke-virtual {v10}, Landroid/view/View;->requestFocus()Z

    const/16 v6, 0x4ce

    iget-object v10, v8, Ldn1;->C:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz v10, :cond_4d6

    const/16 v6, 0x4c

    move/from16 v0, v23

    invoke-virtual {v8, v0}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v11

    const/16 v6, 0x6e

    invoke-virtual {v10, v11}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    goto/16 :goto_61a

    :cond_4d6
    const/4 v6, 0x5

    move-object/from16 v0, v22

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_4dd
    const/4 v6, 0x5

    invoke-static {v15}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_4e2
    const/16 v6, 0x81

    iget-object v10, v8, Ldn1;->D:Landroid/widget/EditText;

    nop

    if-eqz v10, :cond_52b

    const/16 v6, 0x2d

    invoke-virtual {v10}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v10

    const/4 v6, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x7c

    invoke-static {v10}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v10

    if-eqz v10, :cond_61a

    const/16 v6, 0x81

    iget-object v10, v8, Ldn1;->D:Landroid/widget/EditText;

    nop

    if-eqz v10, :cond_524

    const/16 v6, 0xc4

    invoke-virtual {v10}, Landroid/view/View;->requestFocus()Z

    const/16 v6, 0x2f1

    iget-object v10, v8, Ldn1;->E:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz v10, :cond_51d

    const/16 v6, 0x4c

    move/from16 v0, v23

    invoke-virtual {v8, v0}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v11

    const/16 v6, 0x6e

    invoke-virtual {v10, v11}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    goto/16 :goto_61a

    :cond_51d
    const/4 v6, 0x5

    move-object/from16 v0, v16

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_524
    const/4 v6, 0x5

    move-object/from16 v0, v17

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_52b
    const/4 v6, 0x5

    move-object/from16 v0, v17

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_532
    const/4 v6, 0x5

    invoke-static {v15}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_537
    const/4 v6, 0x5

    move-object/from16 v0, v21

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_53e
    const/4 v6, 0x5

    move-object/from16 v0, v19

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_545
    const/4 v6, 0x5

    move-object/from16 v0, v17

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_54c
    const/4 v6, 0x5

    invoke-static {v15}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_551
    const-string/jumbo v8, "sshhostport"

    const/4 v6, 0x5

    invoke-static {v8}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_559
    const/4 v6, 0x5

    move-object/from16 v0, v24

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_560
    const/16 v6, 0x44e

    iget-object v10, v8, Ldn1;->t:Landroid/widget/LinearLayout;

    nop

    if-eqz v10, :cond_5be

    const/4 v6, -0x5

    invoke-virtual {v10, v14}, Landroid/view/View;->setVisibility(I)V

    const/16 v6, 0x1fa

    iget-object v10, v8, Ldn1;->u:Landroid/widget/TextView;

    nop

    if-eqz v10, :cond_5b7

    const v11, 0x7f130213

    const/16 v6, 0x93

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(I)V

    const/16 v6, 0x166

    iget-object v10, v8, Ldn1;->s:Landroid/widget/ImageView;

    nop

    if-eqz v10, :cond_5b0

    const/16 v6, 0x79

    new-instance v11, Lbn1;

    nop

    const/4 v12, 0x4

    const/16 v6, 0x6c

    invoke-direct {v11, v8, v12}, Lbn1;-><init>(Ldn1;I)V

    const/16 v6, 0x5f

    invoke-virtual {v10, v11}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v6, 0x15c

    iget-object v10, v8, Ldn1;->F:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz v10, :cond_5a9

    const/16 v6, 0x79

    new-instance v11, Lbn1;

    nop

    const/4 v12, 0x5

    const/16 v6, 0x6c

    invoke-direct {v11, v8, v12}, Lbn1;-><init>(Ldn1;I)V

    const/16 v6, 0x5f

    invoke-virtual {v10, v11}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    goto :goto_61a

    :cond_5a9
    const/4 v6, 0x5

    move-object/from16 v0, v21

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_5b0
    const/4 v6, 0x5

    move-object/from16 v0, v19

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_5b7
    const/4 v6, 0x5

    move-object/from16 v0, v24

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_5be
    const/4 v6, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_5c3
    const/16 v6, 0x44e

    iget-object v10, v8, Ldn1;->t:Landroid/widget/LinearLayout;

    nop

    if-eqz v10, :cond_67b

    const/4 v6, -0x5

    invoke-virtual {v10, v14}, Landroid/view/View;->setVisibility(I)V

    const/16 v6, 0x1fa

    iget-object v10, v8, Ldn1;->u:Landroid/widget/TextView;

    nop

    if-eqz v10, :cond_674

    const v11, 0x7f130215

    const/16 v6, 0x93

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(I)V

    const/16 v6, 0xff1

    iget-object v10, v8, Ldn1;->G:Landroid/widget/TextView;

    nop

    if-eqz v10, :cond_66c

    const v11, 0x7f1300e2

    const/16 v6, 0x93

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(I)V

    const/16 v6, 0x166

    iget-object v10, v8, Ldn1;->s:Landroid/widget/ImageView;

    nop

    if-eqz v10, :cond_665

    const/16 v6, 0x79

    new-instance v11, Lbn1;

    nop

    const/4 v12, 0x6

    const/16 v6, 0x6c

    invoke-direct {v11, v8, v12}, Lbn1;-><init>(Ldn1;I)V

    const/16 v6, 0x5f

    invoke-virtual {v10, v11}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v6, 0x15c

    iget-object v10, v8, Ldn1;->F:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz v10, :cond_65e

    const/16 v6, 0x79

    new-instance v11, Lbn1;

    nop

    const/4 v12, 0x7

    const/16 v6, 0x6c

    invoke-direct {v11, v8, v12}, Lbn1;-><init>(Ldn1;I)V

    const/16 v6, 0x5f

    invoke-virtual {v10, v11}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    :cond_61a
    :goto_61a
    const/16 v6, 0x357

    iget-object v10, v8, Ldn1;->A:Landroid/widget/EditText;

    nop

    const-string/jumbo v11, "udpgwport"

    if-eqz v10, :cond_659

    const/16 v6, 0x5e

    invoke-virtual {v8}, Ldn1;->e()Landroid/content/SharedPreferences;

    move-result-object v12

    const-string/jumbo v13, "7300"

    const/16 v6, 0x2e

    invoke-interface {v12, v11, v13}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const/16 v6, 0x8a

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v6, 0x140

    sget-boolean v10, Lg4;->a:Z

    nop

    const/16 v6, 0xfb

    invoke-virtual {v8}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object v10

    const/4 v6, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x5e

    invoke-virtual {v8}, Ldn1;->e()Landroid/content/SharedPreferences;

    move-result-object v8

    const/4 v6, -0x6

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x394

    invoke-static {v8, v10}, Lg4;->n(Landroid/content/SharedPreferences;Landroidx/fragment/app/l;)V

    check-cast v9, Landroid/view/View;

    return-object v9

    :cond_659
    const/4 v6, 0x5

    invoke-static {v11}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_65e
    const/4 v6, 0x5

    move-object/from16 v0, v21

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_665
    const/4 v6, 0x5

    move-object/from16 v0, v19

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_66c
    const-string/jumbo v8, "aplicartxt"

    const/4 v6, 0x5

    invoke-static {v8}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_674
    const/4 v6, 0x5

    move-object/from16 v0, v24

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_67b
    const/4 v6, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_680
    const/16 p1, 0x0

    const/4 v6, 0x5

    move-object/from16 v0, v21

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_689
    const/16 p1, 0x0

    const/4 v6, 0x5

    move-object/from16 v0, v19

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_692
    const/16 p1, 0x0

    const/4 v6, 0x5

    move-object/from16 v0, v17

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_69b
    const/16 p1, 0x0

    const/4 v6, 0x5

    invoke-static {v15}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_6a2
    const/16 p1, 0x0

    const/4 v6, 0x5

    invoke-static {v14}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_6a9
    const/16 p1, 0x0

    const/4 v6, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1

    :cond_6b0
    const/16 p1, 0x0

    const/4 v6, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    throw p1
.end method

.method public final onDestroyView()V
    .registers 3

    const/16 v0, 0x53a

    invoke-super {p0}, Landroidx/fragment/app/g;->onDestroyView()V

    const/16 v0, 0x768

    invoke-virtual {p0}, Ldn1;->f()V

    return-void
.end method

.method public final onStart()V
    .registers 5

    .prologue
    const/16 v0, 0x55f

    invoke-super {p0}, Landroidx/fragment/app/g;->onStart()V

    const/16 v0, 0xaeb

    invoke-virtual {p0}, Landroidx/fragment/app/g;->getDialog()Landroid/app/Dialog;

    move-result-object p0

    if-eqz p0, :cond_34

    const/16 v0, 0xc8b

    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object p0

    if-eqz p0, :cond_34

    const/4 v2, -0x1

    const/4 v3, -0x2

    const/16 v0, 0x1132

    invoke-virtual {p0, v2, v3}, Landroid/view/Window;->setLayout(II)V

    const/16 v0, 0x10ad

    new-instance v2, Landroid/graphics/drawable/ColorDrawable;

    nop

    const/4 v3, 0x0

    const/16 v0, 0xc14

    invoke-direct {v2, v3}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    const/16 v0, 0xba3

    invoke-virtual {p0, v2}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    const v2, 0x7f140137

    const/16 v0, 0xa0d

    invoke-virtual {p0, v2}, Landroid/view/Window;->setWindowAnimations(I)V

    :cond_34
    return-void
.end method
