.class public final synthetic Li12;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/view/View$OnLongClickListener;


# instance fields
.field public final synthetic a:Ll12;

.field public final synthetic b:I

.field public final synthetic c:Lk12;


# direct methods
.method public synthetic constructor <init>(Ll12;ILk12;)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x11d3

    iput-object p1, p0, Li12;->a:Ll12;

    const/16 v0, 0x970

    iput p2, p0, Li12;->b:I

    const/16 v0, 0x923

    iput-object p3, p0, Li12;->c:Lk12;

    return-void
.end method


# virtual methods
.method public final onLongClick(Landroid/view/View;)Z
    .registers 16

    const/16 v6, 0x6a6

    iget-object p1, p0, Li12;->a:Ll12;

    nop

    const/16 v6, 0x44

    iget-object v8, p1, Ll12;->f:Ljava/util/ArrayList;

    nop

    const/16 v6, 0xe6b

    iget v9, p0, Li12;->b:I

    nop

    const/16 v6, 0x43

    invoke-virtual {v8, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, La12;

    const/4 v10, 0x0

    const/16 v6, 0x2ee

    iput v10, v8, La12;->j:I

    const/16 v6, 0x710

    iget-object p0, p0, Li12;->c:Lk12;

    nop

    const/16 v6, 0xde6

    iget-object v8, p0, Lk12;->z:Landroid/widget/ProgressBar;

    nop

    const/4 v11, 0x1

    const/16 v6, 0x483

    invoke-virtual {v8, v11}, Landroid/widget/ProgressBar;->setIndeterminate(Z)V

    const/4 v6, -0x5

    invoke-virtual {v8, v10}, Landroid/view/View;->setVisibility(I)V

    const/16 v6, 0x11c7

    iget-object p0, p0, Lk12;->A:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    const/16 v8, 0x8

    const/4 v6, -0x5

    invoke-virtual {p0, v8}, Landroid/view/View;->setVisibility(I)V

    const/16 v6, 0x5b

    new-instance p0, Landroid/content/Intent;

    nop

    const/16 v6, 0xfc6

    iget-object v8, p1, Ll12;->d:Landroid/content/Context;

    nop

    const-class v10, Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;

    const-string/jumbo v12, "CONSULTSTATUS"

    const/4 v13, 0x0

    const/16 v6, 0x3fd

    move v0, v6

    move-object v1, p0

    move-object v2, v12

    move-object v3, v13

    move-object v4, v8

    move-object v5, v10

    invoke-direct/range {v1 .. v5}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;Landroid/content/Context;Ljava/lang/Class;)V

    const-string/jumbo v10, "cId"

    const/16 v6, 0xa7b

    iget v12, p1, Ll12;->h:I

    nop

    const/16 v6, 0x29

    invoke-virtual {p0, v10, v12}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object p0

    const-string/jumbo v10, "cTp"

    const/16 v6, 0x29

    invoke-virtual {p0, v10, v11}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object p0

    const/16 v6, 0x44

    iget-object v10, p1, Ll12;->f:Ljava/util/ArrayList;

    nop

    const/16 v6, 0x43

    invoke-virtual {v10, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, La12;

    const/16 v6, 0x4ba

    iget-object v9, v9, La12;->a:Ljava/lang/String;

    nop

    const-string/jumbo v10, "srv"

    const/16 v6, 0x4b

    invoke-virtual {p0, v10, v9}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    const/16 v6, 0xa85

    iget-object p1, p1, Ll12;->c:Lg12;

    nop

    const/16 v6, 0x1b1

    iget-boolean p1, p1, Lg12;->r:Z

    nop

    const-string/jumbo v9, "cspl"

    const/16 v6, 0x178

    invoke-virtual {p0, v9, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    move-result-object p0

    const/4 v6, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x4a7

    invoke-virtual {v8, p0}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    return v11
.end method
