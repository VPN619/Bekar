.class public final Lit1;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public final synthetic t:Llt1;

.field public final synthetic u:J


# direct methods
.method public constructor <init>(Llt1;JLvx;)V
    .registers 7

    iput-object p1, p0, Lit1;->t:Llt1;

    iput-wide p2, p0, Lit1;->u:J

    const/4 p1, 0x2

    invoke-direct {p0, p1, p4}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 15

    const/16 v7, 0x1098

    new-instance p2, Lit1;

    nop

    const/16 v7, 0x9ee

    iget-object v9, p0, Lit1;->t:Llt1;

    nop

    const/16 v7, 0xe6e

    iget-wide v10, p0, Lit1;->u:J

    nop

    const/16 v7, 0xc6c

    move v0, v7

    move-object v1, p2

    move-object v2, v9

    move-wide v3, v10

    move-object v5, p1

    invoke-direct/range {v1 .. v5}, Lit1;-><init>(Llt1;JLvx;)V

    check-cast p2, Lvx;

    return-object p2
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    const/16 v0, 0x775

    invoke-virtual {p0, p2, p1}, Lit1;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lit1;

    const/16 v0, 0x21

    sget-object p1, Lrg2;->a:Lrg2;

    nop

    const/16 v0, 0x104f

    invoke-virtual {p0, p1}, Lit1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast p1, Ljava/lang/Object;

    return-object p1
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 21

    .prologue
    const/4 v8, 0x6

    move-object/from16 v0, p1

    invoke-static {v0}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v8, 0x9ee

    move-object/from16 v0, p0

    iget-object v8, v0, Lit1;->t:Llt1;

    move-object/16 p1, v8

    const/16 v8, 0xe6e

    move-object/from16 v0, p0

    iget-wide v14, v0, Lit1;->u:J

    nop

    const/16 v8, 0xc8f

    sget p0, Llt1;->t:I

    nop

    :try_start_1b
    const/16 v8, 0x118a

    move-object/from16 v0, p1

    iget-object v8, v0, Llt1;->p:Ljava/net/ServerSocket;

    move-object/16 p0, v8

    const/16 v17, 0x0

    if-eqz p0, :cond_c5

    const/16 v8, 0x6de

    move-object/from16 v0, p0

    invoke-virtual {v0}, Ljava/net/ServerSocket;->accept()Ljava/net/Socket;

    move-result-object p0

    const/4 v8, -0x6

    move-object/from16 v0, p0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v8, 0x119a

    move-object/from16 v0, p1

    move-object/from16 v1, p0

    iput-object v1, v0, Llt1;->q:Ljava/net/Socket;

    const/4 v10, 0x1

    const/16 v8, 0x44c

    move-object/from16 v0, p0

    invoke-virtual {v0, v10}, Ljava/net/Socket;->setTcpNoDelay(Z)V

    const/16 v8, 0x4db

    move-object/from16 v0, p1

    iget-object v8, v0, Llt1;->q:Ljava/net/Socket;

    move-object/16 p0, v8
    :try_end_4f
    .catch Ljava/lang/Exception; {:try_start_1b .. :try_end_4f} :catch_cf

    const-string/jumbo v18, "lSocketConnection"

    if-eqz p0, :cond_be

    :try_start_54
    const/16 v8, 0x2e0

    move-object/from16 v0, p0

    invoke-static {v0}, Landroid/os/ParcelFileDescriptor;->fromSocket(Ljava/net/Socket;)Landroid/os/ParcelFileDescriptor;

    move-result-object p0

    const/16 v8, 0x5a

    sget-object v10, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->a:Lcom/tlsvpn/tlstunnel/utils/SocketOps;

    nop

    const/16 v8, 0x730

    invoke-virtual {v10}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->i()I

    move-result v11

    const/16 v8, 0xcb8

    move-object/from16 v0, p1

    iput v11, v0, Llt1;->m:I

    const/16 v8, 0x1e5

    move-object/from16 v0, p1

    iget-object v12, v0, Llt1;->n:Landroid/os/ParcelFileDescriptor;

    nop

    if-eqz v12, :cond_b4

    const/16 v8, 0xc8

    invoke-virtual {v12}, Landroid/os/ParcelFileDescriptor;->getFd()I

    move-result v12

    const/16 v8, 0xc8

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/os/ParcelFileDescriptor;->getFd()I

    move-result v13

    const/16 v16, 0x1

    const/16 v8, 0xe0c

    move v0, v8

    move-object v1, v10

    move v2, v11

    move v3, v12

    move v4, v13

    move-wide v5, v14

    move/from16 v7, v16

    invoke-virtual/range {v1 .. v7}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->e(IIIJZ)V

    const/16 v8, 0x18b

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/os/ParcelFileDescriptor;->close()V

    const/16 v8, 0x4db

    move-object/from16 v0, p1

    iget-object v8, v0, Llt1;->q:Ljava/net/Socket;

    move-object/16 p0, v8

    if-eqz p0, :cond_ad

    const/16 v8, 0x1a5

    move-object/from16 v0, p0

    invoke-virtual {v0}, Ljava/net/Socket;->close()V

    goto :goto_cf

    :cond_ad
    const/4 v8, 0x5

    move-object/from16 v0, v18

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v17

    :cond_b4
    const-string/jumbo p0, "mainConnection"

    const/4 v8, 0x5

    move-object/from16 v0, p0

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v17

    :cond_be
    const/4 v8, 0x5

    move-object/from16 v0, v18

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v17

    :cond_c5
    const-string/jumbo p0, "lSocketServer"

    const/4 v8, 0x5

    move-object/from16 v0, p0

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v17
    :try_end_cf
    .catch Ljava/lang/Exception; {:try_start_54 .. :try_end_cf} :catch_cf

    :catch_cf
    :goto_cf
    const/16 v8, 0x5a

    sget-object p0, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->a:Lcom/tlsvpn/tlstunnel/utils/SocketOps;

    nop

    const/16 v8, 0x3ea

    move-object/from16 v0, p0

    invoke-virtual {v0, v14, v15}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->x(J)V

    const/16 v8, 0x21

    sget-object p0, Lrg2;->a:Lrg2;

    nop

    check-cast p0, Ljava/lang/Object;

    return-object p0
.end method
