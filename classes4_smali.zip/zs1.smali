.class public final synthetic Lzs1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;


# direct methods
.method public synthetic constructor <init>(Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;I)V
    .registers 5

    iput p2, p0, Lzs1;->a:I

    iput-object p1, p0, Lzs1;->b:Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 30

    .prologue
    move-object/from16 v9, p0

    const/16 v7, 0xdd1

    iget v10, v9, Lzs1;->a:I

    nop

    const-string/jumbo v12, "loadCountDown"

    const-string/jumbo v13, "removeads"

    const-string/jumbo v14, "removeAdsDot"

    const v15, 0x7f13022b

    const-string/jumbo v16, "header"

    const-string/jumbo v17, "server"

    const/16 v18, 0x64

    const/16 v19, 0x3

    const-string/jumbo v20, "progresso"

    const-string/jumbo v21, "txtMensagem"

    const/16 v22, 0x8

    const-string/jumbo v23, "btnAssistirTxt"

    const/16 v24, 0x1

    const-string/jumbo v25, "btnAssistir"

    const-string/jumbo v26, "loadIndicator"

    const/16 v7, 0x87f

    iget-object v9, v9, Lzs1;->b:Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;

    nop

    const/16 v27, 0x0

    const/4 v11, 0x0

    packed-switch v10, :pswitch_data_6fa

    const/16 v7, 0x1a6

    move/from16 v0, v19

    iput v0, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->u:I

    const/16 v7, 0xd5

    new-instance v10, Landroid/util/TypedValue;

    nop

    const/16 v7, 0xe7

    invoke-direct {v10}, Landroid/util/TypedValue;-><init>()V

    const/16 v7, 0x1a9

    invoke-virtual {v9}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v12

    const v19, 0x7f040117

    const/16 v7, 0x68

    move/from16 v0, v19

    move/from16 v1, v24

    invoke-virtual {v12, v0, v10, v1}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    const/16 v7, 0x20f

    iget-object v12, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->h:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz v12, :cond_255

    const/16 v7, 0x9b

    iget v7, v10, Landroid/util/TypedValue;->data:I

    move/16 v19, v7

    const/16 v7, 0x1024

    move/from16 v0, v19

    invoke-virtual {v12, v0}, Landroid/view/View;->setBackgroundColor(I)V

    const/16 v7, 0x34

    iget-object v12, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->n:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz v12, :cond_24e

    const v19, 0x7f08007d

    const/16 v7, 0xb4b

    move/from16 v0, v19

    invoke-virtual {v12, v0}, Landroid/view/View;->setBackgroundResource(I)V

    const/16 v7, 0xb7

    iget-object v12, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->p:Landroid/widget/TextView;

    nop

    if-eqz v12, :cond_247

    const/16 v7, 0xa82

    invoke-virtual {v9}, Lra;->getResources()Landroid/content/res/Resources;

    move-result-object v19

    const/16 v7, 0x953

    move-object/from16 v0, v19

    invoke-virtual {v0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v19

    const/16 v7, 0xc20

    move-object/from16 v0, v19

    iget v7, v0, Landroid/util/DisplayMetrics;->density:F

    move/16 v19, v7

    const/high16 v28, 0x42280000  # 42.0f

    mul-float v28, v28, v19

    const/high16 v19, 0x3f000000  # 0.5f

    add-float v19, v28, v19

    move/from16 v0, v19

    float-to-int v0, v0

    move/from16 v19, v0

    const/16 v7, 0x11a4

    move v0, v7

    move-object v1, v12

    move v2, v11

    move v3, v11

    move/from16 v4, v19

    move v5, v11

    invoke-virtual/range {v1 .. v5}, Landroid/widget/TextView;->setPadding(IIII)V

    const/16 v7, 0x99

    iget-object v12, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->l:Landroid/widget/ProgressBar;

    nop

    if-eqz v12, :cond_240

    const/16 v7, 0x9b

    iget v7, v10, Landroid/util/TypedValue;->data:I

    move/16 v19, v7

    const/16 v7, 0x171

    move/from16 v0, v19

    invoke-static {v0}, Landroid/content/res/ColorStateList;->valueOf(I)Landroid/content/res/ColorStateList;

    move-result-object v19

    const/16 v7, 0xba4

    move-object/from16 v0, v19

    invoke-virtual {v12, v0}, Landroid/widget/ProgressBar;->setIndeterminateTintList(Landroid/content/res/ColorStateList;)V

    const/16 v7, 0xb15

    iget-object v12, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->i:Landroid/widget/TextView;

    nop

    if-eqz v12, :cond_238

    const v19, 0x7f1300cd

    const/16 v7, 0x93

    move/from16 v0, v19

    invoke-virtual {v12, v0}, Landroid/widget/TextView;->setText(I)V

    const/16 v7, 0x120

    iget-object v12, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->j:Landroid/widget/TextView;

    nop

    if-eqz v12, :cond_231

    const v19, 0x7f13021f

    const/16 v7, 0x93

    move/from16 v0, v19

    invoke-virtual {v12, v0}, Landroid/widget/TextView;->setText(I)V

    const/16 v7, 0x34

    iget-object v12, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->n:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz v12, :cond_22a

    const/16 v7, 0xf7

    move/from16 v0, v24

    invoke-virtual {v12, v0}, Landroid/view/View;->setEnabled(Z)V

    const/16 v7, 0xb7

    iget-object v12, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->p:Landroid/widget/TextView;

    nop

    if-eqz v12, :cond_223

    const/16 v7, 0x93

    invoke-virtual {v12, v15}, Landroid/widget/TextView;->setText(I)V

    const/16 v7, 0x34

    iget-object v12, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->n:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz v12, :cond_21c

    const/16 v7, 0x14d

    new-instance v15, Lat1;

    nop

    const/16 v19, 0x2

    const/16 v7, 0x193

    move/from16 v0, v19

    invoke-direct {v15, v9, v0}, Lat1;-><init>(Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;I)V

    const/16 v7, 0x5f

    invoke-virtual {v12, v15}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v7, 0x265

    iget-object v12, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->k:Landroid/widget/TextView;

    nop

    if-eqz v12, :cond_215

    const/4 v7, -0x5

    invoke-virtual {v12, v11}, Landroid/view/View;->setVisibility(I)V

    const/16 v7, 0x27

    iget-object v12, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->y:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    nop

    if-eqz v12, :cond_20e

    const/16 v7, 0xd3

    invoke-virtual {v12, v11}, Lki;->setIndeterminate(Z)V

    const/16 v7, 0x27

    iget-object v12, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->y:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    nop

    if-eqz v12, :cond_207

    const/16 v7, 0xe4

    move/from16 v0, v18

    invoke-virtual {v12, v0}, Lki;->setProgress(I)V

    const/16 v7, 0x27

    iget-object v12, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->y:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    nop

    if-eqz v12, :cond_200

    const/16 v7, 0x9b

    iget v10, v10, Landroid/util/TypedValue;->data:I

    nop

    filled-new-array {v10}, [I

    move-result-object v10

    const/16 v7, 0x235

    invoke-virtual {v12, v10}, Lcom/google/android/material/progressindicator/LinearProgressIndicator;->setIndicatorColor([I)V

    const/16 v7, 0x27

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->y:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    nop

    if-eqz v10, :cond_1f9

    const/4 v7, -0x5

    invoke-virtual {v10, v11}, Landroid/view/View;->setVisibility(I)V

    const/16 v7, 0x99

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->l:Landroid/widget/ProgressBar;

    nop

    if-eqz v10, :cond_1f2

    const/4 v7, -0x5

    move/from16 v0, v22

    invoke-virtual {v10, v0}, Landroid/view/View;->setVisibility(I)V

    const/16 v7, 0x4ca

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->q:Landroid/widget/ImageView;

    nop

    if-eqz v10, :cond_1ed

    const/16 v7, 0x23d

    move/from16 v0, v22

    invoke-virtual {v10, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    const/16 v7, 0x413

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->r:Landroid/view/View;

    nop

    if-eqz v10, :cond_1e8

    const/4 v7, -0x5

    move/from16 v0, v22

    invoke-virtual {v10, v0}, Landroid/view/View;->setVisibility(I)V

    const/16 v7, 0x20f

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->h:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz v10, :cond_1e1

    const/4 v7, -0x5

    invoke-virtual {v10, v11}, Landroid/view/View;->setVisibility(I)V

    const/16 v7, 0x120

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->j:Landroid/widget/TextView;

    nop

    if-eqz v10, :cond_1da

    const/4 v7, -0x5

    invoke-virtual {v10, v11}, Landroid/view/View;->setVisibility(I)V

    const/16 v7, 0x34

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->n:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz v10, :cond_1d3

    const/4 v7, -0x5

    invoke-virtual {v10, v11}, Landroid/view/View;->setVisibility(I)V

    const/16 v7, 0x978

    iget-object v9, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->o:Landroid/widget/ImageView;

    nop

    if-eqz v9, :cond_1cb

    const v10, 0x7f080115

    const/16 v7, 0x87

    invoke-virtual {v9, v10}, Landroid/widget/ImageView;->setImageResource(I)V

    return-void

    :cond_1cb
    const-string/jumbo v9, "btnAssistirImg"

    const/4 v7, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_1d3
    const/4 v7, 0x5

    move-object/from16 v0, v25

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_1da
    const/4 v7, 0x5

    move-object/from16 v0, v21

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_1e1
    const/4 v7, 0x5

    move-object/from16 v0, v16

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_1e8
    const/4 v7, 0x5

    invoke-static {v14}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_1ed
    const/4 v7, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_1f2
    const/4 v7, 0x5

    move-object/from16 v0, v20

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_1f9
    const/4 v7, 0x5

    move-object/from16 v0, v26

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_200
    const/4 v7, 0x5

    move-object/from16 v0, v26

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_207
    const/4 v7, 0x5

    move-object/from16 v0, v26

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_20e
    const/4 v7, 0x5

    move-object/from16 v0, v26

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_215
    const/4 v7, 0x5

    move-object/from16 v0, v17

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_21c
    const/4 v7, 0x5

    move-object/from16 v0, v25

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_223
    const/4 v7, 0x5

    move-object/from16 v0, v23

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_22a
    const/4 v7, 0x5

    move-object/from16 v0, v25

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_231
    const/4 v7, 0x5

    move-object/from16 v0, v21

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_238
    const-string/jumbo v9, "txtTitulo"

    const/4 v7, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_240
    const/4 v7, 0x5

    move-object/from16 v0, v20

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_247
    const/4 v7, 0x5

    move-object/from16 v0, v23

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_24e
    const/4 v7, 0x5

    move-object/from16 v0, v25

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_255
    const/4 v7, 0x5

    move-object/from16 v0, v16

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :pswitch_25c  #0x4
    const/16 v7, 0xbd

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->x:Lbt1;

    nop

    if-eqz v10, :cond_27b

    const/16 v7, 0x2f3

    invoke-virtual {v10}, Landroid/os/CountDownTimer;->cancel()V

    const/16 v7, 0xbd

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->x:Lbt1;

    nop

    if-eqz v10, :cond_276

    const/16 v7, 0x315

    move/from16 v0, v24

    iput-boolean v0, v10, Lbt1;->c:Z

    goto :goto_27b

    :cond_276
    const/4 v7, 0x5

    invoke-static {v12}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_27b
    :goto_27b
    const/16 v7, 0x1a6

    move/from16 v0, v24

    iput v0, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->u:I

    const/16 v7, 0x99

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->l:Landroid/widget/ProgressBar;

    nop

    if-eqz v10, :cond_353

    const/4 v7, -0x5

    invoke-virtual {v10, v11}, Landroid/view/View;->setVisibility(I)V

    const/16 v7, 0x99

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->l:Landroid/widget/ProgressBar;

    nop

    if-eqz v10, :cond_34c

    const/16 v7, 0x483

    move/from16 v0, v24

    invoke-virtual {v10, v0}, Landroid/widget/ProgressBar;->setIndeterminate(Z)V

    const/16 v7, 0x99

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->l:Landroid/widget/ProgressBar;

    nop

    if-eqz v10, :cond_345

    const/16 v7, 0xdf0

    invoke-virtual {v10, v11}, Landroid/widget/ProgressBar;->setProgress(I)V

    const/16 v7, 0x20f

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->h:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz v10, :cond_33e

    const/4 v7, -0x5

    move/from16 v0, v22

    invoke-virtual {v10, v0}, Landroid/view/View;->setVisibility(I)V

    const/16 v7, 0x120

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->j:Landroid/widget/TextView;

    nop

    if-eqz v10, :cond_337

    const/4 v7, -0x5

    move/from16 v0, v22

    invoke-virtual {v10, v0}, Landroid/view/View;->setVisibility(I)V

    const/16 v7, 0x265

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->k:Landroid/widget/TextView;

    nop

    if-eqz v10, :cond_330

    const/4 v7, -0x5

    move/from16 v0, v22

    invoke-virtual {v10, v0}, Landroid/view/View;->setVisibility(I)V

    const/16 v7, 0x4ca

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->q:Landroid/widget/ImageView;

    nop

    if-eqz v10, :cond_32b

    const/16 v7, 0x23d

    move/from16 v0, v22

    invoke-virtual {v10, v0}, Landroid/widget/ImageView;->setVisibility(I)V

    const/16 v7, 0x413

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->r:Landroid/view/View;

    nop

    if-eqz v10, :cond_326

    const/4 v7, -0x5

    move/from16 v0, v22

    invoke-virtual {v10, v0}, Landroid/view/View;->setVisibility(I)V

    const/16 v7, 0x27

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->y:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    nop

    if-eqz v10, :cond_31f

    const/4 v7, -0x5

    move/from16 v0, v22

    invoke-virtual {v10, v0}, Landroid/view/View;->setVisibility(I)V

    const/16 v7, 0x6f9

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->m:Landroid/widget/TextView;

    nop

    if-eqz v10, :cond_317

    const/4 v7, -0x5

    move/from16 v0, v22

    invoke-virtual {v10, v0}, Landroid/view/View;->setVisibility(I)V

    const/16 v7, 0x34

    iget-object v9, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->n:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz v9, :cond_310

    const/4 v7, -0x5

    move/from16 v0, v22

    invoke-virtual {v9, v0}, Landroid/view/View;->setVisibility(I)V

    return-void

    :cond_310
    const/4 v7, 0x5

    move-object/from16 v0, v25

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_317
    const-string/jumbo v9, "freeRenewLimit"

    const/4 v7, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_31f
    const/4 v7, 0x5

    move-object/from16 v0, v26

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_326
    const/4 v7, 0x5

    invoke-static {v14}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_32b
    const/4 v7, 0x5

    invoke-static {v13}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_330
    const/4 v7, 0x5

    move-object/from16 v0, v17

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_337
    const/4 v7, 0x5

    move-object/from16 v0, v21

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_33e
    const/4 v7, 0x5

    move-object/from16 v0, v16

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_345
    const/4 v7, 0x5

    move-object/from16 v0, v20

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_34c
    const/4 v7, 0x5

    move-object/from16 v0, v20

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_353
    const/4 v7, 0x5

    move-object/from16 v0, v20

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :pswitch_35a  #0x3
    const/16 v7, 0x143

    sget v10, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->F:I

    nop

    const/16 v7, 0x232

    invoke-virtual {v9}, Landroid/app/Activity;->isDestroyed()Z

    move-result v10

    if-nez v10, :cond_429

    const/16 v7, 0x1e7

    iget v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->u:I

    nop

    if-eqz v10, :cond_370

    goto/16 :goto_429

    :cond_370
    const/16 v7, 0x27

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->y:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    nop

    if-eqz v10, :cond_422

    const/4 v7, -0x5

    invoke-virtual {v10, v11}, Landroid/view/View;->setVisibility(I)V

    const/16 v7, 0x27

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->y:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    nop

    if-eqz v10, :cond_41b

    const/16 v7, 0xd3

    invoke-virtual {v10, v11}, Lki;->setIndeterminate(Z)V

    const/16 v7, 0x27

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->y:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    nop

    if-eqz v10, :cond_414

    const/16 v7, 0xe4

    move/from16 v0, v18

    invoke-virtual {v10, v0}, Lki;->setProgress(I)V

    const/16 v7, 0xd5

    new-instance v10, Landroid/util/TypedValue;

    nop

    const/16 v7, 0xe7

    invoke-direct {v10}, Landroid/util/TypedValue;-><init>()V

    const/16 v7, 0x1a9

    invoke-virtual {v9}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v12

    const v13, 0x7f0402b3

    const/16 v7, 0x68

    move/from16 v0, v24

    invoke-virtual {v12, v13, v10, v0}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    const/16 v7, 0x27

    iget-object v12, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->y:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    nop

    if-eqz v12, :cond_40d

    const/16 v7, 0x9b

    iget v10, v10, Landroid/util/TypedValue;->data:I

    nop

    filled-new-array {v10}, [I

    move-result-object v10

    const/16 v7, 0x235

    invoke-virtual {v12, v10}, Lcom/google/android/material/progressindicator/LinearProgressIndicator;->setIndicatorColor([I)V

    const/16 v7, 0x34

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->n:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz v10, :cond_406

    const/16 v7, 0xf7

    move/from16 v0, v24

    invoke-virtual {v10, v0}, Landroid/view/View;->setEnabled(Z)V

    const/16 v7, 0xb7

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->p:Landroid/widget/TextView;

    nop

    if-eqz v10, :cond_3ff

    const v12, 0x7f130226

    const/16 v7, 0x93

    invoke-virtual {v10, v12}, Landroid/widget/TextView;->setText(I)V

    const/16 v7, 0x34

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->n:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz v10, :cond_3f8

    const/16 v7, 0x14d

    new-instance v12, Lat1;

    nop

    const/16 v7, 0x193

    invoke-direct {v12, v9, v11}, Lat1;-><init>(Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;I)V

    const/16 v7, 0x5f

    invoke-virtual {v10, v12}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    goto :goto_429

    :cond_3f8
    const/4 v7, 0x5

    move-object/from16 v0, v25

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_3ff
    const/4 v7, 0x5

    move-object/from16 v0, v23

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_406
    const/4 v7, 0x5

    move-object/from16 v0, v25

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_40d
    const/4 v7, 0x5

    move-object/from16 v0, v26

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_414
    const/4 v7, 0x5

    move-object/from16 v0, v26

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_41b
    const/4 v7, 0x5

    move-object/from16 v0, v26

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_422
    const/4 v7, 0x5

    move-object/from16 v0, v26

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_429
    :goto_429
    return-void

    :pswitch_42a  #0x2
    const/16 v7, 0x1a6

    iput v11, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->u:I

    const/16 v7, 0x99

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->l:Landroid/widget/ProgressBar;

    nop

    if-eqz v10, :cond_52c

    const/4 v7, -0x5

    move/from16 v0, v22

    invoke-virtual {v10, v0}, Landroid/view/View;->setVisibility(I)V

    const/16 v7, 0x120

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->j:Landroid/widget/TextView;

    nop

    if-eqz v10, :cond_525

    const/4 v7, -0x5

    invoke-virtual {v10, v11}, Landroid/view/View;->setVisibility(I)V

    const/16 v7, 0x265

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->k:Landroid/widget/TextView;

    nop

    if-eqz v10, :cond_51e

    const/4 v7, -0x5

    invoke-virtual {v10, v11}, Landroid/view/View;->setVisibility(I)V

    const/16 v7, 0x27

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->y:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    nop

    if-eqz v10, :cond_517

    const/4 v7, -0x5

    invoke-virtual {v10, v11}, Landroid/view/View;->setVisibility(I)V

    const/16 v7, 0x34

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->n:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz v10, :cond_510

    const/4 v7, -0x5

    invoke-virtual {v10, v11}, Landroid/view/View;->setVisibility(I)V

    const/16 v7, 0x34

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->n:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz v10, :cond_509

    const/16 v7, 0xf7

    invoke-virtual {v10, v11}, Landroid/view/View;->setEnabled(Z)V

    const/16 v7, 0x140

    sget-boolean v10, Lg4;->a:Z

    nop

    const/16 v7, 0x5f5

    sget-wide v12, Lg4;->k:J

    nop

    const/16 v7, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v14

    cmp-long v10, v12, v14

    if-gtz v10, :cond_488

    goto :goto_48a

    :cond_488
    move/from16 v24, v11

    :goto_48a
    const/16 v7, 0x27

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->y:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    nop

    if-eqz v10, :cond_502

    const/16 v7, 0xd3

    move/from16 v0, v24

    invoke-virtual {v10, v0}, Lki;->setIndeterminate(Z)V

    const/16 v7, 0xb7

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->p:Landroid/widget/TextView;

    nop

    if-eqz v10, :cond_4fb

    if-nez v24, :cond_4a5

    const v12, 0x7f13001f

    goto :goto_4a8

    :cond_4a5
    const v12, 0x7f130114

    :goto_4a8
    const/16 v7, 0x93

    invoke-virtual {v10, v12}, Landroid/widget/TextView;->setText(I)V

    const/16 v7, 0x22b

    sget-object v10, Lg4;->A:Lxu1;

    nop

    if-eqz v10, :cond_4c4

    const/16 v7, 0x22e

    new-instance v10, Lzs1;

    nop

    const/16 v7, 0x1d4

    invoke-direct {v10, v9, v11}, Lzs1;-><init>(Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;I)V

    const/16 v7, 0x147

    invoke-virtual {v9, v10}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    goto :goto_4fa

    :cond_4c4
    const/16 v7, 0x33c

    iget-wide v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->w:J

    nop

    const-wide/16 v12, 0x0

    cmp-long v10, v10, v12

    if-lez v10, :cond_4e9

    const/16 v7, 0x53

    invoke-virtual {v9}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v9

    const/4 v7, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v7, 0x195

    sget-boolean v10, Lmi2;->d:Z

    nop

    if-eqz v10, :cond_4e2

    const-wide/16 v12, 0x1388

    :cond_4e2
    const/4 v10, 0x4

    const/16 v7, 0x3d5

    invoke-static {v9, v10, v12, v13}, Lg4;->m(Landroid/content/Context;IJ)V

    goto :goto_4fa

    :cond_4e9
    const/16 v7, 0x22e

    new-instance v10, Lzs1;

    nop

    const/16 v7, 0x1d4

    move/from16 v0, v19

    invoke-direct {v10, v9, v0}, Lzs1;-><init>(Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;I)V

    const/16 v7, 0x147

    invoke-virtual {v9, v10}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    :goto_4fa
    return-void

    :cond_4fb
    const/4 v7, 0x5

    move-object/from16 v0, v23

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_502
    const/4 v7, 0x5

    move-object/from16 v0, v26

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_509
    const/4 v7, 0x5

    move-object/from16 v0, v25

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_510
    const/4 v7, 0x5

    move-object/from16 v0, v25

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_517
    const/4 v7, 0x5

    move-object/from16 v0, v26

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_51e
    const/4 v7, 0x5

    move-object/from16 v0, v17

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_525
    const/4 v7, 0x5

    move-object/from16 v0, v21

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_52c
    const/4 v7, 0x5

    move-object/from16 v0, v20

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :pswitch_533  #0x1
    const/16 v7, 0x143

    sget v10, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->F:I

    nop

    const/16 v7, 0x232

    invoke-virtual {v9}, Landroid/app/Activity;->isDestroyed()Z

    move-result v10

    if-nez v10, :cond_5e9

    const/16 v7, 0x1e7

    iget v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->u:I

    nop

    if-eqz v10, :cond_549

    goto/16 :goto_5e9

    :cond_549
    const/16 v7, 0xbd

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->x:Lbt1;

    nop

    if-eqz v10, :cond_5d8

    const/16 v7, 0x60a

    iget-boolean v10, v10, Lbt1;->b:Z

    nop

    if-eqz v10, :cond_559

    goto/16 :goto_5d8

    :cond_559
    const/16 v7, 0x27

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->y:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    nop

    if-eqz v10, :cond_5d1

    const/4 v7, -0x5

    invoke-virtual {v10, v11}, Landroid/view/View;->setVisibility(I)V

    const/16 v7, 0x27

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->y:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    nop

    if-eqz v10, :cond_5ca

    const/16 v7, 0xd3

    invoke-virtual {v10, v11}, Lki;->setIndeterminate(Z)V

    const/16 v7, 0x27

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->y:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    nop

    if-eqz v10, :cond_5c3

    const/16 v7, 0xe4

    invoke-virtual {v10, v11}, Lki;->setProgress(I)V

    const/16 v7, 0x34

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->n:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz v10, :cond_5bc

    const/16 v7, 0xf7

    move/from16 v0, v24

    invoke-virtual {v10, v0}, Landroid/view/View;->setEnabled(Z)V

    const/16 v7, 0x34

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->n:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz v10, :cond_5b5

    const/16 v7, 0x14d

    new-instance v11, Lat1;

    nop

    const/4 v12, 0x4

    const/16 v7, 0x193

    invoke-direct {v11, v9, v12}, Lat1;-><init>(Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;I)V

    const/16 v7, 0x5f

    invoke-virtual {v10, v11}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v7, 0xb7

    iget-object v9, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->p:Landroid/widget/TextView;

    nop

    if-eqz v9, :cond_5ae

    const/16 v7, 0x93

    invoke-virtual {v9, v15}, Landroid/widget/TextView;->setText(I)V

    goto :goto_5e9

    :cond_5ae
    const/4 v7, 0x5

    move-object/from16 v0, v23

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_5b5
    const/4 v7, 0x5

    move-object/from16 v0, v25

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_5bc
    const/4 v7, 0x5

    move-object/from16 v0, v25

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_5c3
    const/4 v7, 0x5

    move-object/from16 v0, v26

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_5ca
    const/4 v7, 0x5

    move-object/from16 v0, v26

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_5d1
    const/4 v7, 0x5

    move-object/from16 v0, v26

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_5d8
    :goto_5d8
    const/16 v7, 0x22e

    new-instance v10, Lzs1;

    nop

    const/16 v7, 0x1d4

    move/from16 v0, v19

    invoke-direct {v10, v9, v0}, Lzs1;-><init>(Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;I)V

    const/16 v7, 0x147

    invoke-virtual {v9, v10}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    :cond_5e9
    :goto_5e9
    return-void

    :pswitch_5ea  #0x0
    const/16 v7, 0x143

    sget v10, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->F:I

    nop

    const/16 v7, 0x232

    invoke-virtual {v9}, Landroid/app/Activity;->isDestroyed()Z

    move-result v10

    if-nez v10, :cond_6f9

    const/16 v7, 0x1e7

    iget v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->u:I

    nop

    if-eqz v10, :cond_600

    goto/16 :goto_6f9

    :cond_600
    const/16 v7, 0xbd

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->x:Lbt1;

    nop

    if-eqz v10, :cond_63f

    :try_start_607
    const/16 v7, 0x27

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->y:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    nop

    if-eqz v10, :cond_638

    const/4 v7, -0x5

    move/from16 v0, v22

    invoke-virtual {v10, v0}, Landroid/view/View;->setVisibility(I)V

    const/16 v7, 0xbd

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->x:Lbt1;

    nop

    if-eqz v10, :cond_633

    const/16 v7, 0x2f3

    invoke-virtual {v10}, Landroid/os/CountDownTimer;->cancel()V

    const/16 v7, 0xbd

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->x:Lbt1;

    nop

    if-eqz v10, :cond_62e

    const/16 v7, 0x315

    move/from16 v0, v24

    iput-boolean v0, v10, Lbt1;->c:Z

    goto :goto_63f

    :cond_62e
    const/4 v7, 0x5

    invoke-static {v12}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_633
    const/4 v7, 0x5

    invoke-static {v12}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_638
    const/4 v7, 0x5

    move-object/from16 v0, v26

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27
    :try_end_63f
    .catch Ljava/lang/Exception; {:try_start_607 .. :try_end_63f} :catch_63f

    :catch_63f
    :cond_63f
    :goto_63f
    const/16 v7, 0xd5

    new-instance v10, Landroid/util/TypedValue;

    nop

    const/16 v7, 0xe7

    invoke-direct {v10}, Landroid/util/TypedValue;-><init>()V

    const/16 v7, 0x1a9

    invoke-virtual {v9}, Landroid/content/Context;->getTheme()Landroid/content/res/Resources$Theme;

    move-result-object v12

    const v13, 0x7f0402b1

    const/16 v7, 0x68

    move/from16 v0, v24

    invoke-virtual {v12, v13, v10, v0}, Landroid/content/res/Resources$Theme;->resolveAttribute(ILandroid/util/TypedValue;Z)Z

    const/16 v7, 0x27

    iget-object v12, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->y:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    nop

    if-eqz v12, :cond_6f2

    const/16 v7, 0x9b

    iget v10, v10, Landroid/util/TypedValue;->data:I

    nop

    filled-new-array {v10}, [I

    move-result-object v10

    const/16 v7, 0x235

    invoke-virtual {v12, v10}, Lcom/google/android/material/progressindicator/LinearProgressIndicator;->setIndicatorColor([I)V

    const/16 v7, 0x27

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->y:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    nop

    if-eqz v10, :cond_6eb

    const/4 v7, -0x5

    invoke-virtual {v10, v11}, Landroid/view/View;->setVisibility(I)V

    const/16 v7, 0x27

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->y:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    nop

    if-eqz v10, :cond_6e4

    const/16 v7, 0xd3

    invoke-virtual {v10, v11}, Lki;->setIndeterminate(Z)V

    const/16 v7, 0x27

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->y:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    nop

    if-eqz v10, :cond_6dd

    const/16 v7, 0xe4

    move/from16 v0, v18

    invoke-virtual {v10, v0}, Lki;->setProgress(I)V

    const/16 v7, 0x34

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->n:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz v10, :cond_6d6

    const/16 v7, 0xf7

    move/from16 v0, v24

    invoke-virtual {v10, v0}, Landroid/view/View;->setEnabled(Z)V

    const/16 v7, 0xb7

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->p:Landroid/widget/TextView;

    nop

    if-eqz v10, :cond_6cf

    const v11, 0x7f13002f

    const/16 v7, 0x93

    invoke-virtual {v10, v11}, Landroid/widget/TextView;->setText(I)V

    const/16 v7, 0x34

    iget-object v10, v9, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->n:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz v10, :cond_6c8

    const/16 v7, 0x14d

    new-instance v11, Lat1;

    nop

    const/4 v12, 0x5

    const/16 v7, 0x193

    invoke-direct {v11, v9, v12}, Lat1;-><init>(Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;I)V

    const/16 v7, 0x5f

    invoke-virtual {v10, v11}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    goto :goto_6f9

    :cond_6c8
    const/4 v7, 0x5

    move-object/from16 v0, v25

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_6cf
    const/4 v7, 0x5

    move-object/from16 v0, v23

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_6d6
    const/4 v7, 0x5

    move-object/from16 v0, v25

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_6dd
    const/4 v7, 0x5

    move-object/from16 v0, v26

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_6e4
    const/4 v7, 0x5

    move-object/from16 v0, v26

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_6eb
    const/4 v7, 0x5

    move-object/from16 v0, v26

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_6f2
    const/4 v7, 0x5

    move-object/from16 v0, v26

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v27

    :cond_6f9
    :goto_6f9
    return-void

    :pswitch_data_6fa
    .packed-switch 0x0
        :pswitch_5ea  #00000000
        :pswitch_533  #00000001
        :pswitch_42a  #00000002
        :pswitch_35a  #00000003
        :pswitch_25c  #00000004
    .end packed-switch
.end method
