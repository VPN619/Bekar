.class public final synthetic Lqu;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lsu;


# direct methods
.method public synthetic constructor <init>(Lsu;I)V
    .registers 5

    iput p2, p0, Lqu;->a:I

    iput-object p1, p0, Lqu;->b:Lsu;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 4

    .prologue
    const/16 v0, 0xb26

    iget p1, p0, Lqu;->a:I

    nop

    const/16 v0, 0x6bb

    iget-object p0, p0, Lqu;->b:Lsu;

    nop

    packed-switch p1, :pswitch_data_1a

    const/16 v0, 0x454

    invoke-virtual {p0}, Lsu;->c()V

    return-void

    :pswitch_13  #0x0
    const/16 v0, 0x454

    invoke-virtual {p0}, Lsu;->c()V

    return-void

    nop

    :pswitch_data_1a
    .packed-switch 0x0
        :pswitch_13  #00000000
    .end packed-switch
.end method
