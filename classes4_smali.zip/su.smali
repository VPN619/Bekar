.class public final Lsu;
.super Lvb;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final q:Lw82;

.field public r:[Ljava/lang/String;

.field public s:Landroid/widget/ImageView;

.field public t:Landroid/widget/TextView;

.field public u:Landroid/widget/Spinner;

.field public v:Landroid/widget/EditText;

.field public w:Lcom/google/android/material/textfield/TextInputLayout;

.field public x:Landroid/widget/LinearLayout;

.field public y:Z


# direct methods
.method public constructor <init>()V
    .registers 5

    invoke-direct {p0}, Lvb;-><init>()V

    const/16 v0, 0xa84

    new-instance v2, Ld;

    nop

    const/4 v3, 0x5

    const/16 v0, 0x6cb

    invoke-direct {v2, v3, p0}, Ld;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x27a

    new-instance v3, Lw82;

    nop

    const/16 v0, 0x215

    invoke-direct {v3, v2}, Lw82;-><init>(Lzj0;)V

    const/16 v0, 0xb1b

    iput-object v3, p0, Lsu;->q:Lw82;

    return-void
.end method


# virtual methods
.method public final c()V
    .registers 6

    .prologue
    const/16 v0, 0x720

    iget-boolean v2, p0, Lsu;->y:Z

    nop

    if-nez v2, :cond_70

    const/16 v0, 0x21d

    iget-object v2, p0, Lsu;->u:Landroid/widget/Spinner;

    nop

    const/4 v3, 0x0

    if-eqz v2, :cond_68

    const/16 v0, 0x1e2

    invoke-virtual {v2}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    move-result v2

    const/16 v0, 0x502

    iget-object v4, p0, Lsu;->r:[Ljava/lang/String;

    nop

    if-eqz v4, :cond_60

    array-length v4, v4

    add-int/lit8 v4, v4, -0x1

    if-ne v2, v4, :cond_70

    const/16 v0, 0x2da

    iget-object v2, p0, Lsu;->v:Landroid/widget/EditText;

    nop

    if-eqz v2, :cond_58

    const/16 v0, 0x2d

    invoke-virtual {v2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xff

    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    move-result v2

    if-nez v2, :cond_70

    const/16 v0, 0x36e

    iget-object v2, p0, Lsu;->w:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz v2, :cond_50

    const v3, 0x7f1300c8

    const/16 v0, 0x4c

    invoke-virtual {p0, v3}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x6e

    invoke-virtual {v2, p0}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    return-void

    :cond_50
    const-string/jumbo p0, "customport_l"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_58
    const-string/jumbo p0, "editcustomport"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_60
    const-string/jumbo p0, "portas"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_68
    const-string/jumbo p0, "spinnerPorta"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_70
    const/16 v0, 0xfcd

    invoke-virtual {p0}, Lsu;->d()V

    const/16 v0, 0x181

    invoke-virtual {p0}, Landroidx/fragment/app/g;->dismiss()V

    return-void
.end method

.method public final d()V
    .registers 9

    .prologue
    const/16 v0, 0x21d

    iget-object v2, p0, Lsu;->u:Landroid/widget/Spinner;

    nop

    const/4 v3, 0x0

    const-string/jumbo v4, "spinnerPorta"

    if-eqz v2, :cond_ca

    const/16 v0, 0x1e2

    invoke-virtual {v2}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    move-result v2

    const/16 v0, 0x502

    iget-object v5, p0, Lsu;->r:[Ljava/lang/String;

    nop

    const-string/jumbo v6, "portas"

    if-eqz v5, :cond_c5

    array-length v5, v5

    add-int/lit8 v5, v5, -0x1

    const-string/jumbo v7, "editcustomport"

    if-ne v2, v5, :cond_4a

    const/16 v0, 0x2da

    iget-object v2, p0, Lsu;->v:Landroid/widget/EditText;

    nop

    if-eqz v2, :cond_45

    const/16 v0, 0x2d

    invoke-virtual {v2}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xff

    invoke-interface {v2}, Ljava/lang/CharSequence;->length()I

    move-result v2

    if-lez v2, :cond_3d

    goto :goto_63

    :cond_3d
    const/16 v0, 0x720

    iget-boolean v2, p0, Lsu;->y:Z

    nop

    if-nez v2, :cond_63

    goto :goto_4a

    :cond_45
    const/4 v0, 0x5

    invoke-static {v7}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_4a
    :goto_4a
    const/16 v0, 0x21d

    iget-object v2, p0, Lsu;->u:Landroid/widget/Spinner;

    nop

    if-eqz v2, :cond_c0

    const/16 v0, 0x1e2

    invoke-virtual {v2}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    move-result v2

    const/16 v0, 0x502

    iget-object v5, p0, Lsu;->r:[Ljava/lang/String;

    nop

    if-eqz v5, :cond_bb

    array-length v5, v5

    add-int/lit8 v5, v5, -0x1

    if-ge v2, v5, :cond_ba

    :cond_63
    :goto_63
    const/16 v0, 0xac5

    iget-object v2, p0, Lsu;->q:Lw82;

    nop

    const/16 v0, 0x177

    invoke-virtual {v2}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/content/SharedPreferences;

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x7a

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const/16 v0, 0x21d

    iget-object v5, p0, Lsu;->u:Landroid/widget/Spinner;

    nop

    if-eqz v5, :cond_b5

    const/16 v0, 0x1e2

    invoke-virtual {v5}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    move-result v4

    const-string/jumbo v5, "port"

    const/16 v0, 0x56

    invoke-interface {v2, v5, v4}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x2da

    iget-object p0, p0, Lsu;->v:Landroid/widget/EditText;

    nop

    if-eqz p0, :cond_b0

    const/16 v0, 0x2d

    invoke-virtual {p0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p0

    const/16 v0, 0xcb

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const-string/jumbo v3, "cport"

    const/16 v0, 0x3c

    invoke-interface {v2, v3, p0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x6f

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void

    :cond_b0
    const/4 v0, 0x5

    invoke-static {v7}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_b5
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_ba
    return-void

    :cond_bb
    const/4 v0, 0x5

    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_c0
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_c5
    const/4 v0, 0x5

    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_ca
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3
.end method

.method public final onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .registers 20

    .prologue
    const/4 v6, -0x6

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const p3, 0x7f0c00b3

    const/4 v8, 0x0

    const/16 v6, 0x107b

    move-object/from16 v0, p1

    move/from16 v1, p3

    move-object/from16 v2, p2

    invoke-virtual {v0, v1, v2, v8}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    const/16 v6, 0x1c6

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getResources()Landroid/content/res/Resources;

    move-result-object p2

    const p3, 0x7f030005

    const/16 v6, 0x3e2

    move-object/from16 v0, p2

    move/from16 v1, p3

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object p2

    const/4 v6, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x1061

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    iput-object v1, v0, Lsu;->r:[Ljava/lang/String;

    const p2, 0x7f09013b

    const/16 v6, 0x11

    move-object/from16 v0, p1

    move/from16 v1, p2

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v6, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/ImageView;

    const/16 v6, 0x9fd

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    iput-object v1, v0, Lsu;->s:Landroid/widget/ImageView;

    const p2, 0x7f0902c5

    const/16 v6, 0x11

    move-object/from16 v0, p1

    move/from16 v1, p2

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v6, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/TextView;

    const/16 v6, 0x831

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    iput-object v1, v0, Lsu;->t:Landroid/widget/TextView;

    const p2, 0x7f09033a

    const/16 v6, 0x11

    move-object/from16 v0, p1

    move/from16 v1, p2

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v6, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/Spinner;

    const/16 v6, 0x773

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    iput-object v1, v0, Lsu;->u:Landroid/widget/Spinner;

    const p2, 0x7f0900ce

    const/16 v6, 0x11

    move-object/from16 v0, p1

    move/from16 v1, p2

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v6, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/EditText;

    const/16 v6, 0xf90

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    iput-object v1, v0, Lsu;->v:Landroid/widget/EditText;

    const p2, 0x7f0900cf

    const/16 v6, 0x11

    move-object/from16 v0, p1

    move/from16 v1, p2

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v6, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Lcom/google/android/material/textfield/TextInputLayout;

    const/16 v6, 0x9c3

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    iput-object v1, v0, Lsu;->w:Lcom/google/android/material/textfield/TextInputLayout;

    const p2, 0x7f090058

    const/16 v6, 0x11

    move-object/from16 v0, p1

    move/from16 v1, p2

    invoke-virtual {v0, v1}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v6, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/LinearLayout;

    const/16 v6, 0xceb

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    iput-object v1, v0, Lsu;->x:Landroid/widget/LinearLayout;

    const/16 v6, 0x2da

    move-object/from16 v0, p0

    iget-object v6, v0, Lsu;->v:Landroid/widget/EditText;

    move-object/16 p2, v6

    const/16 p3, 0x0

    const-string/jumbo v9, "editcustomport"

    if-eqz p2, :cond_2f0

    const/16 v6, 0x3d8

    new-instance v10, Lro1;

    nop

    const/4 v11, 0x2

    const/16 v6, 0x48d

    move-object/from16 v0, p0

    invoke-direct {v10, v0, v11}, Lro1;-><init>(Lvb;I)V

    const/16 v6, 0xb8

    move-object/from16 v0, p2

    invoke-virtual {v0, v10}, Landroid/widget/TextView;->addTextChangedListener(Landroid/text/TextWatcher;)V

    const/16 v6, 0x8ea

    new-instance p2, Lou;

    nop

    const/16 v6, 0xac5

    move-object/from16 v0, p0

    iget-object v10, v0, Lsu;->q:Lw82;

    nop

    const/16 v6, 0x177

    invoke-virtual {v10}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Landroid/content/SharedPreferences;

    const/4 v6, -0x6

    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x1c6

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getResources()Landroid/content/res/Resources;

    move-result-object v12

    const/4 v6, -0x6

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v13, 0x1

    const/16 v6, 0x83d

    move v0, v6

    move-object/from16 v1, p2

    move-object v2, v11

    move-object v3, v12

    move v4, v13

    move v5, v13

    invoke-direct/range {v1 .. v5}, Lou;-><init>(Landroid/content/SharedPreferences;Landroid/content/res/Resources;ZZ)V

    const/16 v6, 0x75

    move-object/from16 v0, p2

    iget-boolean v11, v0, Lou;->w:Z

    nop

    const/16 v6, 0xb9f

    move-object/from16 v0, p0

    iput-boolean v11, v0, Lsu;->y:Z

    const-string/jumbo v12, "spinnerPorta"

    if-eqz v11, :cond_1a9

    const/16 v6, 0xe1

    move-object/from16 v0, p2

    iget-object v6, v0, Lou;->f:Ljava/lang/String;

    move-object/16 p2, v6

    const/16 v6, 0x47

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result p2

    if-nez p2, :cond_1a9

    const/16 v6, 0xc65

    new-instance p2, Landroid/widget/ArrayAdapter;

    nop

    const/16 v6, 0x2b

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v11

    const/16 v6, 0x502

    move-object/from16 v0, p0

    iget-object v14, v0, Lsu;->r:[Ljava/lang/String;

    nop

    if-eqz v14, :cond_19f

    array-length v15, v14

    sub-int/2addr v15, v13

    const/16 v6, 0x218

    invoke-static {v14, v8, v15}, Laf;->h0([Ljava/lang/Object;II)[Ljava/lang/Object;

    move-result-object v14

    const v15, 0x7f0c00d4

    const/16 v6, 0xa19

    move-object/from16 v0, p2

    invoke-direct {v0, v11, v15, v14}, Landroid/widget/ArrayAdapter;-><init>(Landroid/content/Context;I[Ljava/lang/Object;)V

    const/16 v6, 0x21d

    move-object/from16 v0, p0

    iget-object v11, v0, Lsu;->u:Landroid/widget/Spinner;

    nop

    if-eqz v11, :cond_19a

    const/16 v6, 0x623

    move-object/from16 v0, p2

    invoke-virtual {v11, v0}, Landroid/widget/Spinner;->setAdapter(Landroid/widget/SpinnerAdapter;)V

    goto :goto_1a9

    :cond_19a
    const/4 v6, 0x5

    invoke-static {v12}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_19f
    const-string/jumbo p0, "portas"

    const/4 v6, 0x5

    move-object/from16 v0, p0

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_1a9
    :goto_1a9
    const/16 v6, 0x21d

    move-object/from16 v0, p0

    iget-object v6, v0, Lsu;->u:Landroid/widget/Spinner;

    move-object/16 p2, v6

    if-eqz p2, :cond_2eb

    const/16 v6, 0x69d

    new-instance v11, Lru;

    nop

    const/16 v6, 0x1116

    move-object/from16 v0, p0

    invoke-direct {v11, v8, v0}, Lru;-><init>(ILjava/lang/Object;)V

    const/16 v6, 0x613

    move-object/from16 v0, p2

    invoke-virtual {v0, v11}, Landroid/widget/AdapterView;->setOnItemSelectedListener(Landroid/widget/AdapterView$OnItemSelectedListener;)V

    const/16 v6, 0xc41

    move-object/from16 v0, p0

    iget-object v6, v0, Lsu;->s:Landroid/widget/ImageView;

    move-object/16 p2, v6

    if-eqz p2, :cond_2e1

    const/16 v6, 0x3ff

    new-instance v11, Lqu;

    nop

    const/16 v6, 0x43e

    move-object/from16 v0, p0

    invoke-direct {v11, v0, v8}, Lqu;-><init>(Lsu;I)V

    const/16 v6, 0x5f

    move-object/from16 v0, p2

    invoke-virtual {v0, v11}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v6, 0x1006

    move-object/from16 v0, p0

    iget-object v6, v0, Lsu;->x:Landroid/widget/LinearLayout;

    move-object/16 p2, v6

    if-eqz p2, :cond_2d7

    const/16 v6, 0x3ff

    new-instance v11, Lqu;

    nop

    const/16 v6, 0x43e

    move-object/from16 v0, p0

    invoke-direct {v11, v0, v13}, Lqu;-><init>(Lsu;I)V

    const/16 v6, 0x5f

    move-object/from16 v0, p2

    invoke-virtual {v0, v11}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v6, 0x2c3

    move-object/from16 v0, p0

    iget-object v6, v0, Lsu;->t:Landroid/widget/TextView;

    move-object/16 p2, v6

    const-string/jumbo v11, "portsavailablelink"

    if-eqz p2, :cond_2d2

    const v13, 0x7f1301fc

    const/16 v6, 0x4c

    move-object/from16 v0, p0

    invoke-virtual {v0, v13}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v13

    const/16 v14, 0x3f

    const/16 v6, 0x9b4

    invoke-static {v13, v14}, Landroid/text/Html;->fromHtml(Ljava/lang/String;I)Landroid/text/Spanned;

    move-result-object v13

    const/16 v6, 0x8a

    move-object/from16 v0, p2

    invoke-virtual {v0, v13}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v6, 0x2c3

    move-object/from16 v0, p0

    iget-object v6, v0, Lsu;->t:Landroid/widget/TextView;

    move-object/16 p2, v6

    if-eqz p2, :cond_2cd

    const/16 v6, 0xb9c

    invoke-static {}, Landroid/text/method/LinkMovementMethod;->getInstance()Landroid/text/method/MovementMethod;

    move-result-object v11

    const/16 v6, 0xfc1

    move-object/from16 v0, p2

    invoke-virtual {v0, v11}, Landroid/widget/TextView;->setMovementMethod(Landroid/text/method/MovementMethod;)V

    const/16 v6, 0x21d

    move-object/from16 v0, p0

    iget-object v6, v0, Lsu;->u:Landroid/widget/Spinner;

    move-object/16 p2, v6

    if-eqz p2, :cond_2c8

    const/16 v6, 0x177

    invoke-virtual {v10}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Landroid/content/SharedPreferences;

    const-string/jumbo v12, "port"

    const/16 v6, 0xb0

    invoke-interface {v11, v12, v8}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v8

    const/16 v6, 0x820

    move-object/from16 v0, p2

    invoke-virtual {v0, v8}, Landroid/widget/AdapterView;->setSelection(I)V

    const/16 v6, 0x2da

    move-object/from16 v0, p0

    iget-object v6, v0, Lsu;->v:Landroid/widget/EditText;

    move-object/16 p2, v6

    if-eqz p2, :cond_2c3

    const/16 v6, 0x177

    invoke-virtual {v10}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Landroid/content/SharedPreferences;

    const-string/jumbo v8, "cport"

    const-string/jumbo v9, ""

    const/16 v6, 0x2e

    move-object/from16 v0, p3

    invoke-interface {v0, v8, v9}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    const/4 v6, -0x6

    move-object/from16 v0, p3

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x8a

    move-object/from16 v0, p2

    move-object/from16 v1, p3

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v6, 0x140

    sget-boolean p2, Lg4;->a:Z

    nop

    const/16 v6, 0xfb

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object p0

    const/4 v6, -0x6

    move-object/from16 v0, p0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x177

    invoke-virtual {v10}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Landroid/content/SharedPreferences;

    const/4 v6, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x394

    move-object/from16 v0, p2

    move-object/from16 v1, p0

    invoke-static {v0, v1}, Lg4;->n(Landroid/content/SharedPreferences;Landroidx/fragment/app/l;)V

    check-cast p1, Landroid/view/View;

    return-object p1

    :cond_2c3
    const/4 v6, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_2c8
    const/4 v6, 0x5

    invoke-static {v12}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_2cd
    const/4 v6, 0x5

    invoke-static {v11}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_2d2
    const/4 v6, 0x5

    invoke-static {v11}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_2d7
    const-string/jumbo p0, "aplicar"

    const/4 v6, 0x5

    move-object/from16 v0, p0

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_2e1
    const-string/jumbo p0, "top_bar_right_icon"

    const/4 v6, 0x5

    move-object/from16 v0, p0

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_2eb
    const/4 v6, 0x5

    invoke-static {v12}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_2f0
    const/4 v6, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3
.end method

.method public final onDestroyView()V
    .registers 6

    .prologue
    const/16 v0, 0x53a

    invoke-super {p0}, Landroidx/fragment/app/g;->onDestroyView()V

    const/16 v0, 0xfcd

    invoke-virtual {p0}, Lsu;->d()V

    const/16 v0, 0x22f

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v2

    if-eqz v2, :cond_42

    const/16 v0, 0x5b

    new-instance v3, Landroid/content/Intent;

    nop

    const-string/jumbo v4, "restoreHome"

    const/16 v0, 0x62

    invoke-direct {v3, v4}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x22f

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object p0

    if-eqz p0, :cond_36

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    if-eqz p0, :cond_36

    const/16 v0, 0x4a

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    goto :goto_37

    :cond_36
    const/4 p0, 0x0

    :goto_37
    const/16 v0, 0x64

    invoke-virtual {v3, p0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    const/16 v0, 0x63

    invoke-virtual {v2, p0}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    :cond_42
    return-void
.end method

.method public final onStart()V
    .registers 5

    .prologue
    const/16 v0, 0x55f

    invoke-super {p0}, Landroidx/fragment/app/g;->onStart()V

    const/16 v0, 0xaeb

    invoke-virtual {p0}, Landroidx/fragment/app/g;->getDialog()Landroid/app/Dialog;

    move-result-object p0

    if-eqz p0, :cond_34

    const/16 v0, 0xc8b

    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object p0

    if-eqz p0, :cond_34

    const/4 v2, -0x1

    const/4 v3, -0x2

    const/16 v0, 0x1132

    invoke-virtual {p0, v2, v3}, Landroid/view/Window;->setLayout(II)V

    const/16 v0, 0x10ad

    new-instance v2, Landroid/graphics/drawable/ColorDrawable;

    nop

    const/4 v3, 0x0

    const/16 v0, 0xc14

    invoke-direct {v2, v3}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    const/16 v0, 0xba3

    invoke-virtual {p0, v2}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    const v2, 0x7f140137

    const/16 v0, 0xa0d

    invoke-virtual {p0, v2}, Landroid/view/Window;->setWindowAnimations(I)V

    :cond_34
    return-void
.end method
