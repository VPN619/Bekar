.class public final Lgx;
.super Ljava/lang/Thread;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;

.field public final b:Landroid/content/SharedPreferences;

.field public final c:Landroid/content/Intent;


# direct methods
.method public constructor <init>(Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;Landroid/content/SharedPreferences;Landroid/content/Intent;)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Thread;-><init>()V

    const/16 v0, 0xd62

    iput-object p1, p0, Lgx;->a:Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;

    const/16 v0, 0xdc6

    iput-object p2, p0, Lgx;->b:Landroid/content/SharedPreferences;

    const/16 v0, 0xc08

    iput-object p3, p0, Lgx;->c:Landroid/content/Intent;

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 39

    .prologue
    move-object/from16 v12, p0

    const/16 v10, 0xb32

    invoke-super {v12}, Ljava/lang/Thread;->run()V

    const/16 v13, 0x400

    const/16 v10, 0x123

    sget-object v14, Lpp1;->a:Lv0;

    nop

    const/16 v10, 0x16d

    invoke-virtual {v14, v13}, Lv0;->l(I)I

    move-result v13

    const/16 v10, 0x747

    iget-object v14, v12, Lgx;->c:Landroid/content/Intent;

    nop

    const-string/jumbo v15, "cId"

    const/16 v10, 0xa8

    invoke-virtual {v14, v15, v13}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v19

    const-string/jumbo v13, "cTp"

    const/4 v15, 0x0

    const/16 v10, 0xa8

    invoke-virtual {v14, v13, v15}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v20

    const-string/jumbo v13, "cspl"

    const/16 v10, 0x151

    invoke-virtual {v14, v13, v15}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v21

    const/16 v10, 0x8ea

    new-instance v13, Lou;

    nop

    const/16 v10, 0x1065

    iget-object v10, v12, Lgx;->a:Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;

    move-object/16 v17, v10

    const/16 v10, 0x142

    move-object/from16 v0, v17

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v16

    const/4 v10, -0x6

    move-object/from16 v0, v16

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v10, 0x5a3

    iget-object v10, v12, Lgx;->b:Landroid/content/SharedPreferences;

    move-object/16 v18, v10

    const/16 v25, 0x1

    const/16 v10, 0x83d

    move v0, v10

    move-object v1, v13

    move-object/from16 v2, v18

    move-object/from16 v3, v16

    move/from16 v4, v25

    move/from16 v5, v25

    invoke-direct/range {v1 .. v5}, Lou;-><init>(Landroid/content/SharedPreferences;Landroid/content/res/Resources;ZZ)V

    const/16 v10, 0x142

    move-object/from16 v0, v17

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v16

    const/4 v10, -0x6

    move-object/from16 v0, v16

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v22, 0x2

    const/16 v10, 0x4fe

    move-object/from16 v0, v18

    move-object/from16 v1, v16

    move/from16 v2, v22

    invoke-static {v0, v1, v2}, Lqk;->p(Landroid/content/SharedPreferences;Landroid/content/res/Resources;I)[Ljava/lang/String;

    move-result-object v26

    const/16 v10, 0x142

    move-object/from16 v0, v17

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v16

    const/4 v10, -0x6

    move-object/from16 v0, v16

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-eqz v21, :cond_96

    const/16 v23, 0x3

    goto :goto_98

    :cond_96
    move/from16 v23, v15

    :goto_98
    const/16 v10, 0x4fe

    move-object/from16 v0, v18

    move-object/from16 v1, v16

    move/from16 v2, v23

    invoke-static {v0, v1, v2}, Lqk;->p(Landroid/content/SharedPreferences;Landroid/content/res/Resources;I)[Ljava/lang/String;

    move-result-object v16

    const-string/jumbo v23, "srv"

    const/16 v10, 0x8d

    move-object/from16 v0, v23

    invoke-virtual {v14, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v24

    const-string/jumbo v28, ""

    if-nez v24, :cond_b6

    move-object/from16 v24, v28

    :cond_b6
    const/16 v10, 0x47

    move-object/from16 v0, v24

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v24

    move/from16 v29, v25

    const/16 v25, 0x4

    if-lez v24, :cond_e0

    const/16 v10, 0x8d

    move-object/from16 v0, v23

    invoke-virtual {v14, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v23

    if-nez v23, :cond_d0

    move-object/from16 v23, v28

    :cond_d0
    const-string/jumbo v24, "Automatic"

    check-cast v24, Ljava/lang/String;

    check-cast v23, Ljava/lang/String;

    move-object/from16 v0, v24

    move-object/from16 v1, v23

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v23

    goto :goto_eb

    :cond_e0
    move/from16 v0, v20

    move/from16 v1, v25

    if-ne v0, v1, :cond_e9

    move-object/from16 v23, v26

    goto :goto_eb

    :cond_e9
    move-object/from16 v23, v16

    :goto_eb
    const/16 v10, 0x142

    move-object/from16 v0, v17

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v24

    const v25, 0x7f030005

    const/16 v10, 0x3e2

    move-object/from16 v0, v24

    move/from16 v1, v25

    invoke-virtual {v0, v1}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v24

    const/4 v10, -0x6

    move-object/from16 v0, v24

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-object/from16 v0, v24

    array-length v0, v0

    move/from16 v25, v0

    move/from16 v0, v25

    move/from16 v1, v22

    if-ge v0, v1, :cond_113

    goto/16 :goto_632

    :cond_113
    const/16 v10, 0xe1

    iget-object v10, v13, Lou;->f:Ljava/lang/String;

    move-object/16 v25, v10

    const/16 v10, 0x47

    move-object/from16 v0, v25

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v25

    const/16 v10, 0xe1

    iget-object v10, v13, Lou;->f:Ljava/lang/String;

    move-object/16 v22, v10

    if-lez v25, :cond_142

    move-object/from16 v0, v24

    array-length v0, v0

    move/from16 v25, v0

    add-int/lit8 v25, v25, -0x1

    const-string/jumbo v27, "T "

    const/16 v10, 0xebf

    move-object/from16 v0, v27

    move-object/from16 v1, v22

    invoke-static {v0, v1}, Lrt2;->h(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v22

    aput-object v22, v24, v25

    goto :goto_15d

    :cond_142
    const/16 v10, 0x47

    move-object/from16 v0, v22

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v22

    if-nez v22, :cond_15d

    move-object/from16 v0, v24

    array-length v0, v0

    move/from16 v22, v0

    add-int/lit8 v22, v22, -0x1

    const/16 v10, 0x218

    move-object/from16 v0, v24

    move/from16 v1, v22

    invoke-static {v0, v15, v1}, Laf;->h0([Ljava/lang/Object;II)[Ljava/lang/Object;

    move-result-object v24

    :cond_15d
    :goto_15d
    move-object/from16 v25, v24

    const/16 v10, 0x1ff

    sget v22, Lmi2;->o:I

    nop

    const v24, 0x7f130039

    const/16 v27, 0x3

    move/from16 v0, v22

    move/from16 v1, v27

    if-eq v0, v1, :cond_1ba

    const/16 v22, 0x2

    move/from16 v0, v20

    move/from16 v1, v22

    if-ne v0, v1, :cond_183

    const/16 v10, 0x32

    iget v10, v13, Lou;->e:I

    move/16 v27, v10

    if-nez v27, :cond_183

    :goto_180
    move/from16 v32, v15

    goto :goto_1bd

    :cond_183
    const/16 v10, 0x32

    iget v10, v13, Lou;->e:I

    move/16 v27, v10

    move/from16 v32, v15

    if-eqz v27, :cond_1b5

    move-object/from16 v0, v25

    array-length v15, v0

    move/from16 v0, v27

    if-ge v0, v15, :cond_1b5

    move/from16 v0, v22

    new-array v15, v0, [Ljava/lang/String;

    const/16 v10, 0xb4

    move-object/from16 v0, v17

    move/from16 v1, v24

    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v22

    aput-object v22, v15, v32

    move-object/from16 v22, v25

    check-cast v22, [Ljava/lang/String;

    const/16 v10, 0x32

    iget v10, v13, Lou;->e:I

    move/16 v24, v10

    aget-object v22, v22, v24

    aput-object v22, v15, v29

    goto :goto_1d2

    :cond_1b5
    move-object/from16 v15, v25

    check-cast v15, [Ljava/lang/String;

    goto :goto_1d2

    :cond_1ba
    const/16 v22, 0x2

    goto :goto_180

    :goto_1bd
    move/from16 v0, v22

    new-array v15, v0, [Ljava/lang/String;

    const/16 v10, 0xb4

    move-object/from16 v0, v17

    move/from16 v1, v24

    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v22

    aput-object v22, v15, v32

    const-string/jumbo v22, "T 443"

    aput-object v22, v15, v29

    :goto_1d2
    const-string/jumbo v22, ".3dUcP:CHECKSUMAQUI:STRRAND::::"

    const-string/jumbo v24, "android_id"

    const-string/jumbo v27, ":498:"

    move-object/from16 v34, v18

    if-eqz v20, :cond_3b3

    move/from16 v18, v29

    move/from16 v0, v20

    move/from16 v1, v18

    if-eq v0, v1, :cond_34f

    const/16 v18, 0x2

    move/from16 v0, v20

    move/from16 v1, v18

    if-eq v0, v1, :cond_29e

    const/16 v18, 0x3

    move/from16 v0, v20

    move/from16 v1, v18

    if-eq v0, v1, :cond_258

    const/16 v18, 0x4

    move/from16 v0, v20

    move/from16 v1, v18

    if-eq v0, v1, :cond_205

    :goto_1ff
    move-object/from16 v12, v28

    move/from16 v28, v19

    goto/16 :goto_416

    :cond_205
    const/4 v10, -0x3

    new-instance v12, Ljava/lang/StringBuilder;

    nop

    if-eqz v21, :cond_20f

    const-string/jumbo v18, "SERVERLISTPRO"

    goto :goto_212

    :cond_20f
    const-string/jumbo v18, "SERVERLIST"

    :goto_212
    const/16 v10, 0x97

    move-object/from16 v0, v18

    invoke-direct {v12, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x0

    move-object/from16 v0, v27

    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v18, 0x7f130024

    const/16 v10, 0xb4

    move-object/from16 v0, v17

    move/from16 v1, v18

    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v18

    const/4 v10, 0x0

    move-object/from16 v0, v18

    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v18, 0x3a

    const/16 v10, 0x1b

    move/from16 v0, v18

    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v10, 0x4a

    move-object/from16 v0, v17

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v18

    const/4 v10, 0x0

    move-object/from16 v0, v18

    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v18, ".3dUcP:CHECKSUMAQUI:STRRAND::::::"

    const/4 v10, 0x0

    move-object/from16 v0, v18

    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, -0x2

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v28

    goto :goto_1ff

    :cond_258
    move-object/from16 v0, v23

    array-length v13, v0

    move/from16 v15, v32

    :goto_25d
    if-ge v15, v13, :cond_632

    aget-object v14, v23, v15

    const/16 v10, 0x47

    invoke-virtual {v14}, Ljava/lang/String;->length()I

    move-result v17

    if-lez v17, :cond_29b

    :try_start_269
    const/16 v10, 0x2b8

    invoke-virtual {v12}, Ljava/lang/Thread;->isInterrupted()Z

    move-result v17

    if-eqz v17, :cond_273

    goto/16 :goto_632

    :cond_273
    const/16 v10, 0x3fa

    new-instance v17, Ljava/lang/Thread;

    nop

    const/16 v10, 0x7ae

    new-instance v18, Lfx;

    nop

    const/16 v10, 0xe31

    move v0, v10

    move-object/from16 v1, v18

    move-object v2, v12

    move-object/from16 v3, v16

    move-object v4, v14

    move/from16 v5, v19

    invoke-direct/range {v1 .. v5}, Lfx;-><init>(Lgx;[Ljava/lang/String;Ljava/lang/String;I)V

    const/16 v10, 0x4cc

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-direct {v0, v1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    const/16 v10, 0x41b

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V
    :try_end_29b
    .catch Ljava/lang/Exception; {:try_start_269 .. :try_end_29b} :catch_29b

    :catch_29b
    :cond_29b
    add-int/lit8 v15, v15, 0x1

    goto :goto_25d

    :cond_29e
    const-string/jumbo v12, "rtype"

    const/16 v10, 0x8d

    invoke-virtual {v14, v12}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    const-string/jumbo v18, "frn"

    move/from16 v22, v32

    const/16 v10, 0x151

    move-object/from16 v0, v18

    move/from16 v1, v22

    invoke-virtual {v14, v0, v1}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v18

    const/4 v10, -0x3

    new-instance v22, Ljava/lang/StringBuilder;

    nop

    move/from16 v28, v19

    const-string/jumbo v19, "TLSVPNRENEW:"

    const/16 v10, 0x97

    move-object/from16 v0, v22

    move-object/from16 v1, v19

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v10, 0x1d2

    move-object/from16 v0, v17

    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v19

    const/16 v10, 0x249

    move-object/from16 v0, v19

    move-object/from16 v1, v24

    invoke-static {v0, v1}, Landroid/provider/Settings$Secure;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v19

    const/4 v10, 0x0

    move-object/from16 v0, v22

    move-object/from16 v1, v19

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v19, 0x3a

    const/16 v10, 0x1b

    move-object/from16 v0, v22

    move/from16 v1, v19

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const v24, 0x7f130024

    const/16 v10, 0xb4

    move-object/from16 v0, v17

    move/from16 v1, v24

    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v24

    const/4 v10, 0x0

    move-object/from16 v0, v22

    move-object/from16 v1, v24

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    move-object/from16 v0, v22

    move-object/from16 v1, v27

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v10, 0x4a

    move-object/from16 v0, v17

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v24

    const/4 v10, 0x0

    move-object/from16 v0, v22

    move-object/from16 v1, v24

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v24, ".3dUcP:"

    const/4 v10, 0x0

    move-object/from16 v0, v22

    move-object/from16 v1, v24

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v10, 0x6a

    move-object/from16 v0, v22

    move/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/16 v10, 0x1b

    move-object/from16 v0, v22

    move/from16 v1, v19

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    move-object/from16 v0, v22

    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v12, ":CHECKSUMAQUI:STRRAND::::::"

    const/4 v10, 0x0

    move-object/from16 v0, v22

    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, -0x2

    move-object/from16 v0, v22

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    goto/16 :goto_416

    :cond_34f
    move/from16 v28, v19

    const/4 v10, -0x3

    new-instance v12, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v18, "TLSATIME:"

    const/16 v10, 0x97

    move-object/from16 v0, v18

    invoke-direct {v12, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v10, 0x1d2

    move-object/from16 v0, v17

    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v18

    const/16 v10, 0x249

    move-object/from16 v0, v18

    move-object/from16 v1, v24

    invoke-static {v0, v1}, Landroid/provider/Settings$Secure;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v18

    const/4 v10, 0x0

    move-object/from16 v0, v18

    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    move-object/from16 v0, v27

    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v18, 0x7f130024

    const/16 v10, 0xb4

    move-object/from16 v0, v17

    move/from16 v1, v18

    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v18

    const/4 v10, 0x0

    move-object/from16 v0, v18

    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v18, 0x3a

    const/16 v10, 0x1b

    move/from16 v0, v18

    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v10, 0x4a

    move-object/from16 v0, v17

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v18

    const/4 v10, 0x0

    move-object/from16 v0, v18

    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    move-object/from16 v0, v22

    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, -0x2

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    goto :goto_416

    :cond_3b3
    move/from16 v28, v19

    const/4 v10, -0x3

    new-instance v12, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v18, "TLSUONLINE:"

    const/16 v10, 0x97

    move-object/from16 v0, v18

    invoke-direct {v12, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v10, 0x1d2

    move-object/from16 v0, v17

    invoke-virtual {v0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v18

    const/16 v10, 0x249

    move-object/from16 v0, v18

    move-object/from16 v1, v24

    invoke-static {v0, v1}, Landroid/provider/Settings$Secure;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v18

    const/4 v10, 0x0

    move-object/from16 v0, v18

    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    move-object/from16 v0, v27

    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const v18, 0x7f130024

    const/16 v10, 0xb4

    move-object/from16 v0, v17

    move/from16 v1, v18

    invoke-virtual {v0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v18

    const/4 v10, 0x0

    move-object/from16 v0, v18

    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v18, 0x3a

    const/16 v10, 0x1b

    move/from16 v0, v18

    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v10, 0x4a

    move-object/from16 v0, v17

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v18

    const/4 v10, 0x0

    move-object/from16 v0, v18

    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    move-object/from16 v0, v22

    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, -0x2

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    :goto_416
    const/16 v10, 0xd7

    new-instance v27, Ljava/util/ArrayList;

    nop

    const/16 v10, 0x16b

    move-object/from16 v0, v27

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    move-object/from16 v0, v23

    array-length v0, v0

    move/from16 v18, v0

    const/16 v19, 0x1

    const/16 v10, 0x218

    move-object/from16 v0, v23

    move/from16 v1, v19

    move/from16 v2, v18

    invoke-static {v0, v1, v2}, Laf;->h0([Ljava/lang/Object;II)[Ljava/lang/Object;

    move-result-object v18

    check-cast v18, [Ljava/lang/String;

    move-object/from16 v0, v18

    array-length v0, v0

    move/from16 v22, v0

    const/16 v23, 0x0

    :goto_43e
    move/from16 v0, v23

    move/from16 v1, v22

    if-ge v0, v1, :cond_5b8

    aget-object v24, v18, v23

    move-object/from16 p0, v12

    array-length v12, v15

    const/16 v10, 0x218

    move/from16 v0, v19

    invoke-static {v15, v0, v12}, Laf;->h0([Ljava/lang/Object;II)[Ljava/lang/Object;

    move-result-object v12

    check-cast v12, [Ljava/lang/String;

    array-length v0, v12

    move/from16 v19, v0

    move-object/from16 v30, v12

    const/4 v12, 0x0

    :goto_459
    move/from16 v0, v19

    if-ge v12, v0, :cond_590

    move/from16 v33, v12

    aget-object v12, v30, v33

    move-object/from16 v35, v15

    const/16 v10, 0x487

    new-instance v15, Lkm0;

    nop

    const/16 v10, 0x51f

    invoke-direct {v15}, Lkm0;-><init>()V

    move-object/from16 v36, v17

    const-class v17, Lou;

    const/16 v10, 0xc5d

    move-object/from16 v0, v17

    invoke-virtual {v15, v0, v13}, Lkm0;->f(Ljava/lang/Class;Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v15

    move-object/from16 v37, v13

    const/16 v10, 0x487

    new-instance v13, Lkm0;

    nop

    const/16 v10, 0x51f

    invoke-direct {v13}, Lkm0;-><init>()V

    const/16 v10, 0xd56

    move-object/from16 v0, v17

    invoke-virtual {v13, v0, v15}, Lkm0;->a(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v13

    const/4 v10, -0x6

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v13, Lou;

    const/4 v15, 0x0

    const/16 v10, 0x3c8

    iput-boolean v15, v13, Lou;->h:Z

    const/4 v10, -0x6

    move-object/from16 v0, v24

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v10, 0x244

    move-object/from16 v0, v24

    iput-object v0, v13, Lou;->i:Ljava/lang/String;

    const/16 v17, 0x4

    move/from16 v0, v20

    move/from16 v1, v17

    if-ne v0, v1, :cond_4b7

    const/16 v10, 0x1ed

    move-object/from16 v0, v24

    move-object/from16 v1, v26

    invoke-static {v0, v1}, Laf;->l0(Ljava/lang/Object;[Ljava/lang/Object;)I

    move-result v17

    goto :goto_4c1

    :cond_4b7
    const/16 v10, 0x1ed

    move-object/from16 v0, v24

    move-object/from16 v1, v16

    invoke-static {v0, v1}, Laf;->l0(Ljava/lang/Object;[Ljava/lang/Object;)I

    move-result v17

    :goto_4c1
    const/16 v10, 0x103

    move/from16 v0, v17

    iput v0, v13, Lou;->d:I

    const/4 v10, -0x6

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v10, 0xdb

    iput-object v12, v13, Lou;->g:Ljava/lang/String;

    const/16 v10, 0x1ed

    move-object/from16 v0, v25

    invoke-static {v12, v0}, Laf;->l0(Ljava/lang/Object;[Ljava/lang/Object;)I

    move-result v12

    const/16 v10, 0x91

    iput v12, v13, Lou;->e:I

    const/16 v10, 0x905

    sget-boolean v12, Lmi2;->a:Z

    nop

    const/16 v10, 0x285

    iget-object v12, v13, Lou;->o:Ljava/lang/String;

    nop

    const/16 v10, 0x20e

    invoke-static {v12, v13}, Lmi2;->b(Ljava/lang/String;Lou;)Ljava/lang/String;

    move-result-object v12

    const/16 v10, 0x3d4

    iput-object v12, v13, Lou;->o:Ljava/lang/String;

    const/16 v10, 0x2e3

    iget-object v12, v13, Lou;->s:Ljava/lang/String;

    nop

    const/16 v10, 0x20e

    invoke-static {v12, v13}, Lmi2;->b(Ljava/lang/String;Lou;)Ljava/lang/String;

    move-result-object v12

    const/16 v10, 0x360

    iput-object v12, v13, Lou;->s:Ljava/lang/String;

    const/16 v10, 0x26e

    iget-object v12, v13, Lou;->q:Ljava/lang/String;

    nop

    const/16 v10, 0x20e

    invoke-static {v12, v13}, Lmi2;->b(Ljava/lang/String;Lou;)Ljava/lang/String;

    move-result-object v12

    const/16 v10, 0x47f

    iput-object v12, v13, Lou;->q:Ljava/lang/String;

    const/16 v10, 0x1ff

    sget v12, Lmi2;->o:I

    nop

    const/16 v17, 0x3

    move/from16 v0, v17

    if-ne v12, v0, :cond_51a

    move v12, v15

    goto :goto_51f

    :cond_51a
    const/16 v10, 0x1b8

    iget v12, v13, Lou;->m:I

    nop

    :goto_51f
    const/16 v10, 0x495

    iput v12, v13, Lou;->m:I

    const/16 v10, 0x2e8

    sget v12, Lhl1;->a:I

    nop

    const-string/jumbo v12, "notifymain"

    const/4 v15, 0x1

    const/16 v10, 0x151

    invoke-virtual {v14, v12, v15}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v12

    move-object/from16 v15, v16

    const/16 v10, 0xd53

    new-instance v16, Llt1;

    nop

    move/from16 v31, v22

    move-object/from16 v22, v13

    move/from16 v13, v31

    move-object/from16 v31, v36

    move/from16 v36, v17

    move-object/from16 v17, v31

    move-object/from16 v31, v24

    move/from16 v24, v12

    move-object/from16 v12, v18

    move-object/from16 v18, v34

    move/from16 v34, v19

    move/from16 v19, v28

    move/from16 v28, v23

    move-object/from16 v23, p0

    const/16 v10, 0xabe

    move v0, v10

    move-object/from16 v1, v16

    move-object/from16 v2, v17

    move-object/from16 v3, v18

    move/from16 v4, v19

    move/from16 v5, v20

    move/from16 v6, v21

    move-object/from16 v7, v22

    move-object/from16 v8, v23

    move/from16 v9, v24

    invoke-direct/range {v1 .. v9}, Llt1;-><init>(Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;Landroid/content/SharedPreferences;IIZLou;Ljava/lang/String;Z)V

    const/16 v10, 0x174

    move-object/from16 v0, v27

    move-object/from16 v1, v16

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v16, v33, 0x1

    move/from16 v22, v13

    move/from16 v23, v28

    move-object/from16 v24, v31

    move-object/from16 v13, v37

    move/from16 v28, v19

    move/from16 v19, v34

    move-object/from16 v34, v18

    move-object/from16 v18, v12

    move/from16 v12, v16

    move-object/from16 v16, v15

    move-object/from16 v15, v35

    goto/16 :goto_459

    :cond_590
    move-object/from16 v37, v13

    move-object/from16 v35, v15

    move-object/from16 v15, v16

    move-object/from16 v12, v18

    move/from16 v13, v22

    move/from16 v19, v28

    move-object/from16 v18, v34

    const/16 v36, 0x3

    move/from16 v28, v23

    move-object/from16 v23, p0

    add-int/lit8 v16, v28, 0x1

    move/from16 v28, v19

    move-object/from16 v13, v37

    const/16 v19, 0x1

    move-object/from16 v18, v12

    move-object/from16 v12, v23

    move/from16 v23, v16

    move-object/from16 v16, v15

    move-object/from16 v15, v35

    goto/16 :goto_43e

    :cond_5b8
    const/16 v10, 0xdce

    move-object/from16 v0, v27

    invoke-static {v0}, Ljava/util/Collections;->shuffle(Ljava/util/List;)V

    if-eqz v20, :cond_5fe

    const/4 v15, 0x1

    move/from16 v0, v20

    if-eq v0, v15, :cond_5ef

    const/16 v18, 0x4

    move/from16 v0, v20

    move/from16 v1, v18

    if-eq v0, v1, :cond_5cf

    goto :goto_60c

    :cond_5cf
    if-eqz v21, :cond_5e0

    :try_start_5d1
    const/16 v10, 0xfe6

    move-object/from16 v0, v17

    iget-object v12, v0, Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;->e:Ljava/util/ArrayList;

    nop

    const/16 v10, 0x12a

    move-object/from16 v0, v27

    invoke-virtual {v12, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    goto :goto_60c

    :cond_5e0
    const/16 v10, 0xf7a

    move-object/from16 v0, v17

    iget-object v12, v0, Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;->d:Ljava/util/ArrayList;

    nop

    const/16 v10, 0x12a

    move-object/from16 v0, v27

    invoke-virtual {v12, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    goto :goto_60c

    :cond_5ef
    const/16 v10, 0x9e4

    move-object/from16 v0, v17

    iget-object v12, v0, Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;->b:Ljava/util/ArrayList;

    nop

    const/16 v10, 0x12a

    move-object/from16 v0, v27

    invoke-virtual {v12, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    goto :goto_60c

    :cond_5fe
    const/16 v10, 0x89d

    move-object/from16 v0, v17

    iget-object v12, v0, Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;->c:Ljava/util/ArrayList;

    nop

    const/16 v10, 0x12a

    move-object/from16 v0, v27

    invoke-virtual {v12, v0}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z
    :try_end_60c
    .catch Ljava/lang/Exception; {:try_start_5d1 .. :try_end_60c} :catch_60c

    :catch_60c
    :goto_60c
    const/16 v10, 0xb5b

    move-object/from16 v0, v27

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v12

    const/4 v10, -0x6

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :goto_618
    const/16 v10, 0x13e

    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_632

    const/16 v10, 0x16e

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    const/4 v10, -0x6

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v13, Llt1;

    const/16 v10, 0x41b

    invoke-virtual {v13}, Ljava/lang/Thread;->start()V

    goto :goto_618

    :cond_632
    :goto_632
    return-void
.end method
