.class public final Ljt1;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public final synthetic t:I

.field public u:I

.field public final synthetic v:Llt1;


# direct methods
.method public synthetic constructor <init>(Llt1;Lvx;I)V
    .registers 6

    iput p3, p0, Ljt1;->t:I

    iput-object p1, p0, Ljt1;->v:Llt1;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 6

    .prologue
    const/16 v0, 0xb4a

    iget p2, p0, Ljt1;->t:I

    nop

    const/16 v0, 0x119e

    iget-object p0, p0, Ljt1;->v:Llt1;

    nop

    packed-switch p2, :pswitch_data_38

    const/16 v0, 0x245

    new-instance p2, Ljt1;

    nop

    const/4 v2, 0x2

    const/16 v0, 0x1c7

    invoke-direct {p2, p0, p1, v2}, Ljt1;-><init>(Llt1;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_1b  #0x1
    const/16 v0, 0x245

    new-instance p2, Ljt1;

    nop

    const/4 v2, 0x1

    const/16 v0, 0x1c7

    invoke-direct {p2, p0, p1, v2}, Ljt1;-><init>(Llt1;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_29  #0x0
    const/16 v0, 0x245

    new-instance p2, Ljt1;

    nop

    const/4 v2, 0x0

    const/16 v0, 0x1c7

    invoke-direct {p2, p0, p1, v2}, Ljt1;-><init>(Llt1;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    nop

    :pswitch_data_38
    .packed-switch 0x0
        :pswitch_29  #00000000
        :pswitch_1b  #00000001
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7

    .prologue
    const/16 v0, 0xb4a

    iget v2, p0, Ljt1;->t:I

    nop

    const/16 v0, 0x21

    sget-object v3, Lrg2;->a:Lrg2;

    nop

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    packed-switch v2, :pswitch_data_3e

    const/16 v0, 0x259

    invoke-virtual {p0, p2, p1}, Ljt1;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Ljt1;

    const/16 v0, 0x258

    invoke-virtual {p0, v3}, Ljt1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_20  #0x1
    const/16 v0, 0x259

    invoke-virtual {p0, p2, p1}, Ljt1;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Ljt1;

    const/16 v0, 0x258

    invoke-virtual {p0, v3}, Ljt1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_2f  #0x0
    const/16 v0, 0x259

    invoke-virtual {p0, p2, p1}, Ljt1;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Ljt1;

    const/16 v0, 0x258

    invoke-virtual {p0, v3}, Ljt1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    return-object p0

    :pswitch_data_3e
    .packed-switch 0x0
        :pswitch_2f  #00000000
        :pswitch_20  #00000001
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 11

    .prologue
    const/16 v0, 0xb4a

    iget v2, p0, Ljt1;->t:I

    nop

    const/16 v0, 0x21

    sget-object v3, Lrg2;->a:Lrg2;

    nop

    const/16 v0, 0x119e

    iget-object v4, p0, Ljt1;->v:Llt1;

    nop

    const/4 v5, 0x0

    const-string/jumbo v6, "call to \'resume\' before \'invoke\' with coroutine"

    const/16 v0, 0x15

    sget-object v7, Lwy;->a:Lwy;

    nop

    const/4 v8, 0x1

    packed-switch v2, :pswitch_data_98

    const/16 v0, 0x1f6

    iget v2, p0, Ljt1;->u:I

    nop

    if-eqz v2, :cond_31

    if-ne v2, v8, :cond_2a

    const/4 v0, 0x6

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_42

    :cond_2a
    const/16 v0, 0x13

    invoke-static {v6}, Lz6;->w(Ljava/lang/String;)V

    move-object v3, v5

    goto :goto_42

    :cond_31
    const/4 v0, 0x6

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v0, 0x1ec

    iput v8, p0, Ljt1;->u:I

    const/16 v0, 0x231

    invoke-virtual {v4, p0}, Llt1;->a(Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v7, :cond_42

    move-object v3, v7

    :cond_42
    :goto_42
    check-cast v3, Ljava/lang/Object;

    return-object v3

    :pswitch_45  #0x1
    const/16 v0, 0x1f6

    iget v2, p0, Ljt1;->u:I

    nop

    if-eqz v2, :cond_5a

    if-ne v2, v8, :cond_53

    const/4 v0, 0x6

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_6b

    :cond_53
    const/16 v0, 0x13

    invoke-static {v6}, Lz6;->w(Ljava/lang/String;)V

    move-object v3, v5

    goto :goto_6b

    :cond_5a
    const/4 v0, 0x6

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v0, 0x1ec

    iput v8, p0, Ljt1;->u:I

    const/16 v0, 0x231

    invoke-virtual {v4, p0}, Llt1;->a(Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v7, :cond_6b

    move-object v3, v7

    :cond_6b
    :goto_6b
    check-cast v3, Ljava/lang/Object;

    return-object v3

    :pswitch_6e  #0x0
    const/16 v0, 0x1f6

    iget v2, p0, Ljt1;->u:I

    nop

    if-eqz v2, :cond_83

    if-ne v2, v8, :cond_7c

    const/4 v0, 0x6

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    goto :goto_94

    :cond_7c
    const/16 v0, 0x13

    invoke-static {v6}, Lz6;->w(Ljava/lang/String;)V

    move-object v3, v5

    goto :goto_94

    :cond_83
    const/4 v0, 0x6

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v0, 0x1ec

    iput v8, p0, Ljt1;->u:I

    const/16 v0, 0x231

    invoke-virtual {v4, p0}, Llt1;->a(Lwx;)Ljava/lang/Object;

    move-result-object p0

    if-ne p0, v7, :cond_94

    move-object v3, v7

    :cond_94
    :goto_94
    check-cast v3, Ljava/lang/Object;

    return-object v3

    nop

    :pswitch_data_98
    .packed-switch 0x0
        :pswitch_6e  #00000000
        :pswitch_45  #00000001
    .end packed-switch
.end method
