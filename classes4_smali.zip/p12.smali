.class public final Lp12;
.super Ljava/util/TimerTask;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Lcom/tlsvpn/tlstunnel/services/ServicoVpn;

.field public final b:Ljava/lang/String;

.field public final c:Landroid/content/SharedPreferences;

.field public d:Z


# direct methods
.method public constructor <init>(Lcom/tlsvpn/tlstunnel/services/ServicoVpn;Ljava/lang/String;Landroid/content/SharedPreferences;)V
    .registers 6

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {p0}, Ljava/util/TimerTask;-><init>()V

    const/16 v0, 0x1185

    iput-object p1, p0, Lp12;->a:Lcom/tlsvpn/tlstunnel/services/ServicoVpn;

    const/16 v0, 0x111d

    iput-object p2, p0, Lp12;->b:Ljava/lang/String;

    const/16 v0, 0x943

    iput-object p3, p0, Lp12;->c:Landroid/content/SharedPreferences;

    return-void
.end method


# virtual methods
.method public final cancel()Z
    .registers 4

    const/4 v2, 0x1

    const/16 v0, 0x5f4

    iput-boolean v2, p0, Lp12;->d:Z

    const/16 v0, 0xd8b

    invoke-super {p0}, Ljava/util/TimerTask;->cancel()Z

    move-result p0

    return p0
.end method

.method public final run()V
    .registers 32

    .prologue
    move-object/from16 v8, p0

    const-string/jumbo v9, "[NTFCC] Notificação de renovação disparada, tempo restante ("

    const/16 v6, 0x272

    sget-object v10, Lmi2;->m:Ljava/lang/String;

    nop

    const/16 v6, 0xd0e

    iget-object v11, v8, Lp12;->b:Ljava/lang/String;

    nop

    const/16 v6, 0x84

    invoke-static {v11, v10}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_3b5

    const/16 v6, 0x1ff

    sget v10, Lmi2;->o:I

    nop

    const/4 v12, 0x3

    if-eq v10, v12, :cond_21

    goto/16 :goto_3b5

    :cond_21
    const/16 v6, 0x101

    sget-boolean v10, Lmi2;->n:Z

    nop

    const-string/jumbo v12, "Renew"

    const/4 v13, 0x2

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v6, 0xef3

    iget-object v6, v8, Lp12;->a:Lcom/tlsvpn/tlstunnel/services/ServicoVpn;

    move-object/16 v16, v6

    if-eqz v10, :cond_82

    const-string/jumbo v8, "[PRO] Executando Renovação Automática!"

    nop

    const/16 v6, 0x5b

    new-instance v8, Landroid/content/Intent;

    nop

    const-string/jumbo v9, "CONSULTSTATUS"

    const-class v10, Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;

    const/16 v6, 0x3fd

    move v0, v6

    move-object v1, v8

    move-object v2, v9

    move-object v3, v14

    move-object/from16 v4, v16

    move-object v5, v10

    invoke-direct/range {v1 .. v5}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;Landroid/content/Context;Ljava/lang/Class;)V

    const-string/jumbo v9, "srv"

    const/16 v6, 0x4b

    invoke-virtual {v8, v9, v11}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string/jumbo v9, "cId"

    const/16 v6, 0x29

    invoke-virtual {v8, v9, v15}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string/jumbo v9, "frn"

    const/16 v6, 0x178

    invoke-virtual {v8, v9, v15}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    const-string/jumbo v9, "rtype"

    const-string/jumbo v10, "video"

    const/16 v6, 0x4b

    invoke-virtual {v8, v9, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string/jumbo v9, "cTp"

    const/16 v6, 0x29

    invoke-virtual {v8, v9, v13}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    :try_start_7a
    const/16 v6, 0x4a7

    move-object/from16 v0, v16

    invoke-virtual {v0, v8}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_81
    .catch Ljava/lang/Exception; {:try_start_7a .. :try_end_81} :catch_3b5

    return-void

    :cond_82
    const/16 v6, 0x12e

    iget-boolean v10, v8, Lp12;->d:Z

    nop

    if-eqz v10, :cond_8b

    goto/16 :goto_3b5

    :cond_8b
    const/16 v6, 0xf11

    sget-boolean v10, Lmi2;->e:Z

    nop

    const-string/jumbo v17, "serverh"

    if-eqz v10, :cond_bb

    const/16 v6, 0xada

    sget-object v10, Lmi2;->p:Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;

    nop

    if-eqz v10, :cond_ac

    const/16 v6, 0x28

    invoke-virtual {v10}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v10

    if-eqz v10, :cond_ac

    const/16 v6, 0x8d

    move-object/from16 v0, v17

    invoke-virtual {v10, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    :cond_ac
    const/16 v6, 0x272

    sget-object v10, Lmi2;->m:Ljava/lang/String;

    nop

    const/16 v6, 0x84

    invoke-static {v14, v10}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_bb

    goto/16 :goto_3b5

    :cond_bb
    const/16 v6, 0x26f

    sget-wide v18, Lmi2;->i:J

    nop

    const/16 v6, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v20

    sub-long v18, v18, v20

    const-wide/32 v20, 0xdbf88

    cmp-long v10, v18, v20

    if-lez v10, :cond_db

    const/16 v6, 0x380

    move-object/from16 v0, v16

    iget-boolean v10, v0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->c:Z

    nop

    if-eqz v10, :cond_d9

    goto :goto_db

    :cond_d9
    move v10, v15

    goto :goto_dc

    :cond_db
    :goto_db
    const/4 v10, 0x1

    :goto_dc
    const/16 v6, 0xd20

    move-object/from16 v0, v16

    iput-boolean v10, v0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->c:Z

    const/16 v6, 0x12e

    iget-boolean v6, v8, Lp12;->d:Z

    move/16 v20, v6

    const/16 v21, 0x5d

    const-string/jumbo v22, "s) ["

    const-string/jumbo v23, "m) ou ("

    const-wide/16 v24, 0x3c

    const-wide/16 v26, 0x3e8

    const/16 v6, 0xfee

    iget-object v14, v8, Lp12;->c:Landroid/content/SharedPreferences;

    nop

    if-nez v20, :cond_16e

    if-nez v10, :cond_16e

    const/16 v6, 0x140

    sget-boolean v10, Lg4;->a:Z

    nop

    const/16 v6, 0x622

    invoke-static {v14}, Lg4;->i(Landroid/content/SharedPreferences;)Z

    move-result v10

    if-eqz v10, :cond_16e

    :try_start_10b
    const/16 v6, 0x286

    invoke-virtual {v8}, Lp12;->cancel()Z
    :try_end_110
    .catch Ljava/lang/Exception; {:try_start_10b .. :try_end_110} :catch_110

    :catch_110
    const/16 v6, 0x351

    new-instance v8, Ljava/util/Timer;

    nop

    const/16 v6, 0x477

    invoke-direct {v8}, Ljava/util/Timer;-><init>()V

    const/16 v6, 0x2fa

    move-object/from16 v0, v16

    iput-object v8, v0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->b:Ljava/util/Timer;

    :try_start_120
    const/16 v6, 0x393

    new-instance v9, Lp12;

    nop

    const/16 v6, 0x46b

    move-object/from16 v0, v16

    invoke-direct {v9, v0, v11, v14}, Lp12;-><init>(Lcom/tlsvpn/tlstunnel/services/ServicoVpn;Ljava/lang/String;Landroid/content/SharedPreferences;)V

    const-wide/32 v13, 0x493e0

    const/16 v6, 0x4e8

    invoke-virtual {v8, v9, v13, v14}, Ljava/util/Timer;->schedule(Ljava/util/TimerTask;J)V
    :try_end_134
    .catch Ljava/lang/Exception; {:try_start_120 .. :try_end_134} :catch_134

    :catch_134
    const/4 v6, -0x3

    new-instance v8, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v9, "[NTF] Notificação de renovação reagendada (Rewarded Limitado), tempo restante ("

    const/16 v6, 0x97

    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    div-long v18, v18, v26

    div-long v9, v18, v24

    const/16 v6, 0x83

    invoke-virtual {v8, v9, v10}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    move-object/from16 v0, v23

    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v6, 0x83

    move-wide/from16 v0, v18

    invoke-virtual {v8, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    move-object/from16 v0, v22

    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    invoke-virtual {v8, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v6, 0x1b

    move/from16 v0, v21

    invoke-virtual {v8, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v6, -0x2

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    nop

    return-void

    :cond_16e
    const/16 v6, 0x1fc

    sget v10, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 v20, 0x21

    move/from16 v0, v20

    if-lt v10, v0, :cond_18e

    const/16 v6, 0x53

    move-object/from16 v0, v16

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v10

    const-string/jumbo v20, "android.permission.POST_NOTIFICATIONS"

    const/16 v6, 0x2b7

    move-object/from16 v0, v20

    invoke-static {v10, v0}, Lqx;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)I

    move-result v10

    if-nez v10, :cond_190

    :cond_18e
    const/4 v10, 0x1

    goto :goto_191

    :cond_190
    move v10, v15

    :goto_191
    const/16 v6, 0x12e

    iget-boolean v6, v8, Lp12;->d:Z

    move/16 v20, v6

    if-nez v20, :cond_37b

    if-eqz v10, :cond_37b

    const/16 v6, 0x53

    move-object/from16 v0, v16

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v10

    const/16 v6, 0x51

    invoke-virtual {v11}, Ljava/lang/String;->hashCode()I

    move-result v20

    const/16 v6, 0x5b

    new-instance v21, Landroid/content/Intent;

    nop

    const/16 v6, 0x53

    move-object/from16 v0, v16

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v15

    const-class v13, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;

    const/16 v6, 0xd0

    move-object/from16 v0, v21

    invoke-direct {v0, v15, v13}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/16 v6, 0x4b

    move-object/from16 v0, v21

    move-object/from16 v1, v17

    invoke-virtual {v0, v1, v11}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v13

    const/high16 v15, 0x14000000

    const/16 v6, 0x59

    invoke-virtual {v13, v15}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    move-result-object v13

    const/high16 v15, 0xc000000

    const/16 v6, 0x1067

    move/from16 v0, v20

    invoke-static {v10, v0, v13, v15}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v10

    const/16 v6, 0x52b

    sget-object v13, Ldz;->a:Lcz;

    nop

    const/4 v13, 0x2

    const/16 v6, 0x196

    invoke-static {v13, v11}, Lc72;->G0(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v15

    const/16 v6, 0x1f7

    sget-object v13, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    nop

    const/16 v6, 0x3b0

    invoke-virtual {v15, v13}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v15

    const/4 v6, -0x6

    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x334

    invoke-static {v15}, Ldz;->a(Ljava/lang/String;)Lcz;

    move-result-object v15

    const/4 v6, -0x3

    new-instance v17, Ljava/lang/StringBuilder;

    nop

    const/16 v6, 0x1e6

    iget-object v15, v15, Lcz;->c:Ljava/lang/String;

    nop

    const/16 v6, 0x97

    move-object/from16 v0, v17

    invoke-direct {v0, v15}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v15, 0x20

    const/16 v6, 0x1b

    move-object/from16 v0, v17

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const-string/jumbo v15, "."

    check-cast v15, Ljava/lang/String;

    filled-new-array {v15}, [Ljava/lang/String;

    move-result-object v15

    const/16 v20, 0x6

    const/16 v6, 0x89

    move/from16 v0, v20

    invoke-static {v11, v15, v0}, Lc72;->E0(Ljava/lang/CharSequence;[Ljava/lang/String;I)Ljava/util/List;

    move-result-object v15

    const/16 v20, 0x0

    const/16 v6, 0x24

    move/from16 v0, v20

    invoke-interface {v15, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v15

    check-cast v15, Ljava/lang/String;

    const/16 v6, 0x12d

    invoke-virtual {v15, v13}, Ljava/lang/String;->toUpperCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v13

    const/4 v6, -0x6

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v6, 0x0

    move-object/from16 v0, v17

    invoke-virtual {v0, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v13, ": "

    const/4 v6, 0x0

    move-object/from16 v0, v17

    invoke-virtual {v0, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v6, 0x380

    move-object/from16 v0, v16

    iget-boolean v13, v0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->c:Z

    nop

    if-eqz v13, :cond_263

    const v13, 0x7f130224

    :goto_25a
    const/16 v6, 0xb4

    move-object/from16 v0, v16

    invoke-virtual {v0, v13}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v13

    goto :goto_267

    :cond_263
    const v13, 0x7f130065

    goto :goto_25a

    :goto_267
    const/4 v6, 0x0

    move-object/from16 v0, v17

    invoke-virtual {v0, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, -0x2

    move-object/from16 v0, v17

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v13

    const/16 v6, 0xedb

    new-instance v15, Lkg1;

    nop

    const/16 v6, 0x53

    move-object/from16 v0, v16

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v17

    const-string/jumbo v20, "tls_ipt0"

    const/16 v6, 0xefa

    move-object/from16 v0, v17

    move-object/from16 v1, v20

    invoke-direct {v15, v0, v1}, Lkg1;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    const-string/jumbo v17, "renew"

    const/16 v6, 0xf4e

    move-object/from16 v0, v17

    iput-object v0, v15, Lkg1;->l:Ljava/lang/String;

    const v17, 0x7f080139

    const/16 v6, 0x1bd

    iget-object v6, v15, Lkg1;->u:Landroid/app/Notification;

    move-object/16 v20, v6

    const/16 v6, 0xdd4

    move-object/from16 v0, v20

    move/from16 v1, v17

    iput v1, v0, Landroid/app/Notification;->icon:I

    const/16 v17, 0x2

    const/16 v21, 0x0

    const/16 v6, 0x4df

    move/from16 v0, v17

    move/from16 v1, v21

    invoke-virtual {v15, v0, v1}, Lkg1;->e(IZ)V

    const/16 v17, 0x10

    move-object/from16 v28, v13

    const/4 v13, 0x1

    const/16 v6, 0x4df

    move/from16 v0, v17

    invoke-virtual {v15, v0, v13}, Lkg1;->e(IZ)V

    const/16 v6, 0x226

    move/from16 v0, v21

    invoke-virtual {v15, v0}, Lkg1;->d(Z)V

    move-wide/from16 v29, v18

    const-wide/16 v17, 0x0

    const/16 v6, 0x210

    move-object/from16 v0, v20

    move-wide/from16 v1, v17

    iput-wide v1, v0, Landroid/app/Notification;->when:J

    const/16 v6, 0x2db

    move/from16 v0, v21

    iput-boolean v0, v15, Lkg1;->j:Z

    const/16 v6, 0xf14

    move/from16 v0, v21

    iput v0, v15, Lkg1;->h:I

    const v13, 0x7f130024

    const/16 v6, 0xb4

    move-object/from16 v0, v16

    invoke-virtual {v0, v13}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v13

    const/16 v6, 0x3e6

    invoke-static {v13}, Lkg1;->c(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v13

    const/16 v6, 0xbc2

    iput-object v13, v15, Lkg1;->e:Ljava/lang/CharSequence;

    const/16 v6, 0x3e6

    move-object/from16 v0, v28

    invoke-static {v0}, Lkg1;->c(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    move-result-object v13

    const/16 v6, 0x67b

    iput-object v13, v15, Lkg1;->f:Ljava/lang/CharSequence;

    const/4 v13, 0x1

    const/16 v6, 0xe40

    iput-boolean v13, v15, Lkg1;->n:Z

    const/16 v6, 0xc3e

    iput-boolean v13, v15, Lkg1;->o:Z

    const-string/jumbo v13, "alarm"

    const/16 v6, 0xe89

    iput-object v13, v15, Lkg1;->p:Ljava/lang/String;

    const/16 v6, 0x53

    move-object/from16 v0, v16

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v13

    const v17, 0x7f06003b

    const/16 v6, 0x77c

    move/from16 v0, v17

    invoke-static {v13, v0}, Lqx;->getColor(Landroid/content/Context;I)I

    move-result v13

    const/16 v6, 0x11d7

    iput v13, v15, Lkg1;->r:I

    const/16 v6, 0x947

    iput-object v10, v15, Lkg1;->g:Landroid/app/PendingIntent;

    :try_start_32c
    const/4 v6, -0x3

    new-instance v10, Ljava/lang/StringBuilder;

    nop

    const/16 v6, 0x97

    invoke-direct {v10, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    div-long v18, v29, v26

    div-long v18, v18, v24

    const/16 v6, 0x83

    move-wide/from16 v0, v18

    invoke-virtual {v10, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    move-object/from16 v0, v23

    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    div-long v18, v29, v26

    const/16 v6, 0x83

    move-wide/from16 v0, v18

    invoke-virtual {v10, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    move-object/from16 v0, v22

    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v9, 0x5d

    const/16 v6, 0x1b

    invoke-virtual {v10, v9}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v6, -0x2

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    nop

    const/16 v6, 0xe9

    move-object/from16 v0, v16

    invoke-virtual {v0}, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->a()Landroid/app/NotificationManager;

    move-result-object v9

    const/16 v6, 0x1df

    invoke-virtual {v15}, Lkg1;->b()Landroid/app/Notification;

    move-result-object v10

    const/4 v13, 0x2

    const/16 v6, 0x1be

    invoke-virtual {v9, v13, v10}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V
    :try_end_37a
    .catch Ljava/lang/Exception; {:try_start_32c .. :try_end_37a} :catch_37d

    goto :goto_37d

    :cond_37b
    move-wide/from16 v29, v18

    :catch_37d
    :goto_37d
    const/16 v6, 0x12e

    iget-boolean v9, v8, Lp12;->d:Z

    nop

    if-nez v9, :cond_3b5

    const-wide/32 v9, 0xdbba0

    cmp-long v12, v29, v9

    if-lez v12, :cond_3b5

    :try_start_38b
    const/16 v6, 0x286

    invoke-virtual {v8}, Lp12;->cancel()Z
    :try_end_390
    .catch Ljava/lang/Exception; {:try_start_38b .. :try_end_390} :catch_390

    :catch_390
    const/16 v6, 0x351

    new-instance v8, Ljava/util/Timer;

    nop

    const/16 v6, 0x477

    invoke-direct {v8}, Ljava/util/Timer;-><init>()V

    const/16 v6, 0x2fa

    move-object/from16 v0, v16

    iput-object v8, v0, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;->b:Ljava/util/Timer;

    :try_start_3a0
    const/16 v6, 0x393

    new-instance v12, Lp12;

    nop

    const/16 v6, 0x46b

    move-object/from16 v0, v16

    invoke-direct {v12, v0, v11, v14}, Lp12;-><init>(Lcom/tlsvpn/tlstunnel/services/ServicoVpn;Ljava/lang/String;Landroid/content/SharedPreferences;)V

    sub-long v18, v29, v9

    const/16 v6, 0x4e8

    move-wide/from16 v0, v18

    invoke-virtual {v8, v12, v0, v1}, Ljava/util/Timer;->schedule(Ljava/util/TimerTask;J)V
    :try_end_3b5
    .catch Ljava/lang/Exception; {:try_start_3a0 .. :try_end_3b5} :catch_3b5

    :catch_3b5
    :cond_3b5
    :goto_3b5
    return-void
.end method
