.class public final Lf12;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public final synthetic t:I

.field public final synthetic u:Lg12;


# direct methods
.method public synthetic constructor <init>(Lg12;Lvx;I)V
    .registers 6

    iput p3, p0, Lf12;->t:I

    iput-object p1, p0, Lf12;->u:Lg12;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 6

    .prologue
    const/16 v0, 0x115a

    iget p2, p0, Lf12;->t:I

    nop

    const/16 v0, 0x1123

    iget-object p0, p0, Lf12;->u:Lg12;

    nop

    packed-switch p2, :pswitch_data_38

    const/16 v0, 0x24d

    new-instance p2, Lf12;

    nop

    const/4 v2, 0x2

    const/16 v0, 0x1ad

    invoke-direct {p2, p0, p1, v2}, Lf12;-><init>(Lg12;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_1b  #0x1
    const/16 v0, 0x24d

    new-instance p2, Lf12;

    nop

    const/4 v2, 0x1

    const/16 v0, 0x1ad

    invoke-direct {p2, p0, p1, v2}, Lf12;-><init>(Lg12;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_29  #0x0
    const/16 v0, 0x24d

    new-instance p2, Lf12;

    nop

    const/4 v2, 0x0

    const/16 v0, 0x1ad

    invoke-direct {p2, p0, p1, v2}, Lf12;-><init>(Lg12;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    nop

    :pswitch_data_38
    .packed-switch 0x0
        :pswitch_29  #00000000
        :pswitch_1b  #00000001
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7

    .prologue
    const/16 v0, 0x115a

    iget v2, p0, Lf12;->t:I

    nop

    const/16 v0, 0x21

    sget-object v3, Lrg2;->a:Lrg2;

    nop

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    packed-switch v2, :pswitch_data_42

    const/16 v0, 0x243

    invoke-virtual {p0, p2, p1}, Lf12;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lf12;

    const/16 v0, 0x22c

    invoke-virtual {p0, v3}, Lf12;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v3, Ljava/lang/Object;

    return-object v3

    :pswitch_21  #0x1
    const/16 v0, 0x243

    invoke-virtual {p0, p2, p1}, Lf12;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lf12;

    const/16 v0, 0x22c

    invoke-virtual {p0, v3}, Lf12;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v3, Ljava/lang/Object;

    return-object v3

    :pswitch_31  #0x0
    const/16 v0, 0x243

    invoke-virtual {p0, p2, p1}, Lf12;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lf12;

    const/16 v0, 0x22c

    invoke-virtual {p0, v3}, Lf12;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v3, Ljava/lang/Object;

    return-object v3

    nop

    :pswitch_data_42
    .packed-switch 0x0
        :pswitch_31  #00000000
        :pswitch_21  #00000001
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .prologue
    const/16 v0, 0x115a

    iget v2, p0, Lf12;->t:I

    nop

    const/16 v0, 0x21

    sget-object v3, Lrg2;->a:Lrg2;

    nop

    const/16 v0, 0x1123

    iget-object p0, p0, Lf12;->u:Lg12;

    nop

    packed-switch v2, :pswitch_data_36

    const/4 v0, 0x6

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v0, 0x1fb

    invoke-virtual {p0}, Lg12;->c()V

    check-cast v3, Ljava/lang/Object;

    return-object v3

    :pswitch_1e  #0x1
    const/4 v0, 0x6

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v0, 0x1fb

    invoke-virtual {p0}, Lg12;->c()V

    check-cast v3, Ljava/lang/Object;

    return-object v3

    :pswitch_2a  #0x0
    const/4 v0, 0x6

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v0, 0x1fb

    invoke-virtual {p0}, Lg12;->c()V

    check-cast v3, Ljava/lang/Object;

    return-object v3

    :pswitch_data_36
    .packed-switch 0x0
        :pswitch_2a  #00000000
        :pswitch_1e  #00000001
    .end packed-switch
.end method
