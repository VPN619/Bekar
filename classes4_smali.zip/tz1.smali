.class public final synthetic Ltz1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lvz1;


# direct methods
.method public synthetic constructor <init>(Lvz1;I)V
    .registers 5

    iput p2, p0, Ltz1;->a:I

    iput-object p1, p0, Ltz1;->b:Lvz1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 4

    .prologue
    const/16 v0, 0x797

    iget p1, p0, Ltz1;->a:I

    nop

    const/16 v0, 0xae4

    iget-object p0, p0, Ltz1;->b:Lvz1;

    nop

    packed-switch p1, :pswitch_data_20

    const/16 v0, 0x8c8

    invoke-virtual {p0}, Lvz1;->e()V

    return-void

    :pswitch_13  #0x1
    const/16 v0, 0x70a

    invoke-virtual {p0}, Lvz1;->d()V

    return-void

    :pswitch_19  #0x0
    const/16 v0, 0x533

    invoke-virtual {p0}, Lvz1;->c()V

    return-void

    nop

    :pswitch_data_20
    .packed-switch 0x0
        :pswitch_19  #00000000
        :pswitch_13  #00000001
    .end packed-switch
.end method
