.class public final Lvj1;
.super Lvb;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public A:Landroid/widget/CheckBox;

.field public B:Landroid/widget/CheckBox;

.field public C:Landroid/widget/CheckBox;

.field public D:Landroid/widget/CheckBox;

.field public E:Landroid/widget/CheckBox;

.field public F:Landroid/widget/CheckBox;

.field public G:Landroid/widget/CheckBox;

.field public H:Landroid/widget/LinearLayout;

.field public I:Landroid/widget/EditText;

.field public J:Landroid/widget/Button;

.field public K:Landroid/widget/Button;

.field public L:Landroid/widget/Button;

.field public final q:Lw82;

.field public r:Ljava/lang/String;

.field public s:Landroid/widget/ImageView;

.field public t:Landroid/widget/ImageView;

.field public u:Landroid/widget/LinearLayout;

.field public v:Landroid/widget/LinearLayout;

.field public w:Landroid/widget/EditText;

.field public x:Landroid/widget/Spinner;

.field public y:Landroid/widget/Spinner;

.field public z:Landroid/widget/CheckBox;


# direct methods
.method public constructor <init>()V
    .registers 5

    invoke-direct {p0}, Lvb;-><init>()V

    const/16 v0, 0xa84

    new-instance v2, Ld;

    nop

    const/16 v3, 0x14

    const/16 v0, 0x6cb

    invoke-direct {v2, v3, p0}, Ld;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x27a

    new-instance v3, Lw82;

    nop

    const/16 v0, 0x215

    invoke-direct {v3, v2}, Lw82;-><init>(Lzj0;)V

    const/16 v0, 0xa05

    iput-object v3, p0, Lvj1;->q:Lw82;

    const-string/jumbo v2, "pnull"

    const/16 v0, 0xba8

    iput-object v2, p0, Lvj1;->r:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final c()V
    .registers 10

    .prologue
    const/16 v0, 0x202

    iget-object v2, p0, Lvj1;->x:Landroid/widget/Spinner;

    nop

    const-string/jumbo v3, "metodo"

    const/4 v4, 0x0

    if-eqz v2, :cond_2b2

    const/16 v0, 0x1db

    invoke-virtual {v2}, Landroid/widget/AdapterView;->getSelectedItem()Ljava/lang/Object;

    move-result-object v2

    const/16 v0, 0xcb

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    const/16 v0, 0x3b7

    iget-object v5, p0, Lvj1;->w:Landroid/widget/EditText;

    nop

    const-string/jumbo v6, "urltxt"

    if-eqz v5, :cond_2ad

    const/16 v0, 0x2d

    invoke-virtual {v5}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v5

    const/4 v0, -0x6

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xff

    invoke-interface {v5}, Ljava/lang/CharSequence;->length()I

    move-result v5

    if-lez v5, :cond_4c

    const/16 v0, 0x3b7

    iget-object v5, p0, Lvj1;->w:Landroid/widget/EditText;

    nop

    if-eqz v5, :cond_47

    const/16 v0, 0x2d

    invoke-virtual {v5}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v5

    const/16 v0, 0xcb

    invoke-virtual {v5}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    goto :goto_4f

    :cond_47
    const/4 v0, 0x5

    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_4c
    const-string/jumbo v5, "[host_port]"

    :goto_4f
    const-string/jumbo v6, "ftp://"

    const/4 v7, 0x1

    const/16 v0, 0x92

    invoke-static {v5, v6, v7}, Lk72;->k0(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v6

    if-nez v6, :cond_a3

    const-string/jumbo v6, "ssh://"

    const/16 v0, 0x92

    invoke-static {v5, v6, v7}, Lk72;->k0(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v6

    if-nez v6, :cond_a3

    const-string/jumbo v6, "ftps://"

    const/16 v0, 0x92

    invoke-static {v5, v6, v7}, Lk72;->k0(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v6

    if-nez v6, :cond_a3

    const-string/jumbo v6, "sftp://"

    const/16 v0, 0x92

    invoke-static {v5, v6, v7}, Lk72;->k0(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v6

    if-nez v6, :cond_a3

    const-string/jumbo v6, "http://"

    const/16 v0, 0x92

    invoke-static {v5, v6, v7}, Lk72;->k0(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v8

    if-nez v8, :cond_a3

    const-string/jumbo v8, "https://"

    const/16 v0, 0x92

    invoke-static {v5, v8, v7}, Lk72;->k0(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v8

    if-nez v8, :cond_a3

    const-string/jumbo v8, "["

    const/16 v0, 0x92

    invoke-static {v5, v8, v7}, Lk72;->k0(Ljava/lang/String;Ljava/lang/String;Z)Z

    move-result v7

    if-nez v7, :cond_a3

    const/16 v0, 0xee

    invoke-virtual {v6, v5}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    :cond_a3
    const/16 v0, 0x202

    iget-object v6, p0, Lvj1;->x:Landroid/widget/Spinner;

    nop

    if-eqz v6, :cond_2a8

    const/16 v0, 0x1e2

    invoke-virtual {v6}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    move-result v6

    const-string/jumbo v7, "httpv"

    const-string/jumbo v8, "[crlf]"

    if-nez v6, :cond_ec

    const/4 v0, -0x3

    new-instance v2, Ljava/lang/StringBuilder;

    nop

    const/4 v0, -0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/16 v0, 0x47c

    iget-object v6, p0, Lvj1;->y:Landroid/widget/Spinner;

    nop

    if-eqz v6, :cond_e7

    const/16 v0, 0x1db

    invoke-virtual {v6}, Landroid/widget/AdapterView;->getSelectedItem()Ljava/lang/Object;

    move-result-object v6

    const/16 v0, 0x190

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string/jumbo v6, " [crlf]Host: "

    const/4 v0, 0x0

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {v2, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    goto :goto_12e

    :cond_e7
    const/4 v0, 0x5

    invoke-static {v7}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_ec
    const/4 v0, -0x3

    new-instance v6, Ljava/lang/StringBuilder;

    nop

    const/4 v0, -0x4

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v0, 0x0

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v2, 0x20

    const/16 v0, 0x1b

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x1b

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v0, 0x47c

    iget-object v2, p0, Lvj1;->y:Landroid/widget/Spinner;

    nop

    if-eqz v2, :cond_2a3

    const/16 v0, 0x1db

    invoke-virtual {v2}, Landroid/widget/AdapterView;->getSelectedItem()Ljava/lang/Object;

    move-result-object v2

    const/16 v0, 0x190

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string/jumbo v2, "[crlf]Host: "

    const/4 v0, 0x0

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    :goto_12e
    const/16 v0, 0x298

    iget-object v6, p0, Lvj1;->z:Landroid/widget/CheckBox;

    nop

    if-eqz v6, :cond_29b

    const/16 v0, 0x36

    invoke-virtual {v6}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v6

    if-eqz v6, :cond_146

    const-string/jumbo v6, "Connection: keep-alive[crlf]"

    const/16 v0, 0xee

    invoke-virtual {v2, v6}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :cond_146
    const/16 v0, 0x32b

    iget-object v6, p0, Lvj1;->A:Landroid/widget/CheckBox;

    nop

    if-eqz v6, :cond_293

    const/16 v0, 0x36

    invoke-virtual {v6}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v6

    if-eqz v6, :cond_15e

    const-string/jumbo v6, "Connection: close[crlf]"

    const/16 v0, 0xee

    invoke-virtual {v2, v6}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :cond_15e
    const/16 v0, 0x5ab

    iget-object v6, p0, Lvj1;->B:Landroid/widget/CheckBox;

    nop

    if-eqz v6, :cond_28b

    const/16 v0, 0x36

    invoke-virtual {v6}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v6

    if-eqz v6, :cond_193

    const/4 v0, -0x3

    new-instance v6, Ljava/lang/StringBuilder;

    nop

    const/16 v0, 0x97

    invoke-direct {v6, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const-string/jumbo v2, "User-Agent: "

    const/4 v0, 0x0

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v2, "http.agent"

    const/16 v0, 0x77d

    invoke-static {v2}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v0, 0x0

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {v6, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    :cond_193
    const/16 v0, 0xf76

    iget-object v6, p0, Lvj1;->C:Landroid/widget/CheckBox;

    nop

    if-eqz v6, :cond_283

    const/16 v0, 0x36

    invoke-virtual {v6}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v6

    if-eqz v6, :cond_1ab

    const-string/jumbo v6, "Referer: "

    const/16 v0, 0x141

    invoke-static {v2, v6, v5, v8}, Lmz2;->l(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :cond_1ab
    const/16 v0, 0xb4c

    iget-object v6, p0, Lvj1;->D:Landroid/widget/CheckBox;

    nop

    if-eqz v6, :cond_27b

    const/16 v0, 0x36

    invoke-virtual {v6}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v6

    if-eqz v6, :cond_1c3

    const-string/jumbo v6, "X-Online-Host: "

    const/16 v0, 0x141

    invoke-static {v2, v6, v5, v8}, Lmz2;->l(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :cond_1c3
    const/16 v0, 0x7d3

    iget-object v6, p0, Lvj1;->E:Landroid/widget/CheckBox;

    nop

    if-eqz v6, :cond_273

    const/16 v0, 0x36

    invoke-virtual {v6}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v6

    if-eqz v6, :cond_1db

    const-string/jumbo v6, "X-Forward-Host: "

    const/16 v0, 0x141

    invoke-static {v2, v6, v5, v8}, Lmz2;->l(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :cond_1db
    const/16 v0, 0x69f

    iget-object v6, p0, Lvj1;->F:Landroid/widget/CheckBox;

    nop

    if-eqz v6, :cond_26b

    const/16 v0, 0x36

    invoke-virtual {v6}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v6

    if-eqz v6, :cond_1f3

    const-string/jumbo v6, "X-Forwarded-For: "

    const/16 v0, 0x141

    invoke-static {v2, v6, v5, v8}, Lmz2;->l(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :cond_1f3
    const/16 v0, 0xab6

    iget-object v5, p0, Lvj1;->G:Landroid/widget/CheckBox;

    nop

    if-eqz v5, :cond_263

    const/16 v0, 0x36

    invoke-virtual {v5}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result v5

    if-eqz v5, :cond_208

    const/16 v0, 0xee

    invoke-virtual {v2, v8}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :cond_208
    const/16 v0, 0x202

    iget-object v5, p0, Lvj1;->x:Landroid/widget/Spinner;

    nop

    if-eqz v5, :cond_25e

    const/16 v0, 0x1e2

    invoke-virtual {v5}, Landroid/widget/AdapterView;->getSelectedItemPosition()I

    move-result v3

    if-nez v3, :cond_220

    const-string/jumbo v3, "`"

    const/16 v0, 0xee

    invoke-virtual {v2, v3}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    :cond_220
    const/16 v0, 0x4fc

    iget-object v3, p0, Lvj1;->I:Landroid/widget/EditText;

    nop

    if-eqz v3, :cond_256

    const/16 v0, 0x8a

    invoke-virtual {v3, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v0, 0x3c9

    iget-object v2, p0, Lvj1;->u:Landroid/widget/LinearLayout;

    nop

    if-eqz v2, :cond_24e

    const/16 v3, 0x8

    const/4 v0, -0x5

    invoke-virtual {v2, v3}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0x662

    iget-object p0, p0, Lvj1;->v:Landroid/widget/LinearLayout;

    nop

    if-eqz p0, :cond_246

    const/4 v2, 0x0

    const/4 v0, -0x5

    invoke-virtual {p0, v2}, Landroid/view/View;->setVisibility(I)V

    return-void

    :cond_246
    const-string/jumbo p0, "generatedpayloadlayout"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_24e
    const-string/jumbo p0, "generatepayloadlayout"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_256
    const-string/jumbo p0, "generatedpayload"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_25e
    const/4 v0, 0x5

    invoke-static {v3}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_263
    const-string/jumbo p0, "finishh"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_26b
    const-string/jumbo p0, "fwrdfor"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_273
    const-string/jumbo p0, "fwrdhost"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_27b
    const-string/jumbo p0, "onhost"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_283
    const-string/jumbo p0, "referer"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_28b
    const-string/jumbo p0, "useragent"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_293
    const-string/jumbo p0, "close"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_29b
    const-string/jumbo p0, "keepalive"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_2a3
    const/4 v0, 0x5

    invoke-static {v7}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_2a8
    const/4 v0, 0x5

    invoke-static {v3}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_2ad
    const/4 v0, 0x5

    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_2b2
    const/4 v0, 0x5

    invoke-static {v3}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4
.end method

.method public final d()V
    .registers 9

    .prologue
    const/16 v0, 0x11c2

    iget-object v2, p0, Lvj1;->q:Lw82;

    nop

    const/16 v0, 0x177

    invoke-virtual {v2}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/content/SharedPreferences;

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x7a

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string/jumbo v3, "metodo"

    const/4 v4, 0x1

    const/16 v0, 0x56

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x3fb

    iget-object v3, p0, Lvj1;->r:Ljava/lang/String;

    nop

    const-string/jumbo v5, "pn"

    const/16 v0, 0x84

    invoke-static {v3, v5}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    const/4 v5, 0x0

    const-string/jumbo v6, "generatedpayload"

    if-eqz v3, :cond_5e

    const-string/jumbo v3, "upayload"

    const/16 v0, 0x48

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const/16 v0, 0x4fc

    iget-object v4, p0, Lvj1;->I:Landroid/widget/EditText;

    nop

    if-eqz v4, :cond_59

    const/16 v0, 0x2d

    invoke-virtual {v4}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v4

    const/16 v0, 0xcb

    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    const-string/jumbo v5, "payload"

    const/16 v0, 0x3c

    invoke-interface {v3, v5, v4}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    goto :goto_98

    :cond_59
    const/4 v0, 0x5

    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw v5

    :cond_5e
    const/16 v0, 0x3fb

    iget-object v3, p0, Lvj1;->r:Ljava/lang/String;

    nop

    const-string/jumbo v7, "pasni"

    const/16 v0, 0x84

    invoke-static {v3, v7}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_98

    const-string/jumbo v3, "upayloadat"

    const/16 v0, 0x48

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    move-result-object v3

    const/16 v0, 0x4fc

    iget-object v4, p0, Lvj1;->I:Landroid/widget/EditText;

    nop

    if-eqz v4, :cond_93

    const/16 v0, 0x2d

    invoke-virtual {v4}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object v4

    const/16 v0, 0xcb

    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    const-string/jumbo v5, "payloadat"

    const/16 v0, 0x3c

    invoke-interface {v3, v5, v4}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    goto :goto_98

    :cond_93
    const/4 v0, 0x5

    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw v5

    :cond_98
    :goto_98
    const/16 v0, 0x6f

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v2

    const/16 v0, 0x5b

    new-instance v3, Landroid/content/Intent;

    nop

    const-string/jumbo v4, "restoremtdcfg"

    const/16 v0, 0x62

    invoke-direct {v3, v4}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v4

    const/16 v0, 0x53

    invoke-virtual {v4}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v4

    const/16 v0, 0x4a

    invoke-virtual {v4}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    const/16 v0, 0x64

    invoke-virtual {v3, v4}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v3

    const/16 v0, 0x63

    invoke-virtual {v2, v3}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    const/16 v0, 0x181

    invoke-virtual {p0}, Landroidx/fragment/app/g;->dismiss()V

    return-void
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .registers 6

    .prologue
    const/16 v0, 0x11c5

    invoke-super {p0, p1}, Landroidx/fragment/app/g;->onCreate(Landroid/os/Bundle;)V

    const/16 v0, 0xc2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getArguments()Landroid/os/Bundle;

    move-result-object p1

    if-eqz p1, :cond_21

    const-string/jumbo v2, "pasni"

    const-string/jumbo v3, "pnull"

    const/16 v0, 0x54e

    invoke-virtual {p1, v2, v3}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xba8

    iput-object p1, p0, Lvj1;->r:Ljava/lang/String;

    :cond_21
    return-void
.end method

.method public final onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .registers 11

    .prologue
    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const p3, 0x7f0c00b1

    const/4 v2, 0x0

    const/16 v0, 0x107b

    invoke-virtual {p1, p3, p2, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    const p2, 0x7f090392

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/ImageView;

    const/16 v0, 0x603

    iput-object p2, p0, Lvj1;->s:Landroid/widget/ImageView;

    const p2, 0x7f09013b

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/ImageView;

    const/16 v0, 0xf89

    iput-object p2, p0, Lvj1;->t:Landroid/widget/ImageView;

    const p2, 0x7f09011f

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/LinearLayout;

    const/16 v0, 0x80c

    iput-object p2, p0, Lvj1;->u:Landroid/widget/LinearLayout;

    const p2, 0x7f09011e

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/LinearLayout;

    const/16 v0, 0xd26

    iput-object p2, p0, Lvj1;->v:Landroid/widget/LinearLayout;

    const p2, 0x7f090135

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/EditText;

    const/16 v0, 0x786

    iput-object p2, p0, Lvj1;->w:Landroid/widget/EditText;

    const p2, 0x7f09024b

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/Spinner;

    const/16 v0, 0x5c4

    iput-object p2, p0, Lvj1;->x:Landroid/widget/Spinner;

    const p2, 0x7f090138

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/Spinner;

    const/16 v0, 0xc12

    iput-object p2, p0, Lvj1;->y:Landroid/widget/Spinner;

    const p2, 0x7f09015d

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/CheckBox;

    const/16 v0, 0x86b

    iput-object p2, p0, Lvj1;->z:Landroid/widget/CheckBox;

    const p2, 0x7f0900ac

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/CheckBox;

    const/16 v0, 0x5e4

    iput-object p2, p0, Lvj1;->A:Landroid/widget/CheckBox;

    const p2, 0x7f0903b2

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/CheckBox;

    const/16 v0, 0x9da

    iput-object p2, p0, Lvj1;->B:Landroid/widget/CheckBox;

    const p2, 0x7f0902e0

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/CheckBox;

    const/16 v0, 0xc9b

    iput-object p2, p0, Lvj1;->C:Landroid/widget/CheckBox;

    const p2, 0x7f090295

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/CheckBox;

    const/16 v0, 0x88a

    iput-object p2, p0, Lvj1;->D:Landroid/widget/CheckBox;

    const p2, 0x7f09011c

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/CheckBox;

    const/16 v0, 0x601

    iput-object p2, p0, Lvj1;->E:Landroid/widget/CheckBox;

    const p2, 0x7f09011b

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/CheckBox;

    const/16 v0, 0x10bb

    iput-object p2, p0, Lvj1;->F:Landroid/widget/CheckBox;

    const p2, 0x7f09010d

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/CheckBox;

    const/16 v0, 0xe5c

    iput-object p2, p0, Lvj1;->G:Landroid/widget/CheckBox;

    const p2, 0x7f090121

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/LinearLayout;

    const/16 v0, 0xeaa

    iput-object p2, p0, Lvj1;->H:Landroid/widget/LinearLayout;

    const p2, 0x7f09011d

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/EditText;

    const/16 v0, 0xda8

    iput-object p2, p0, Lvj1;->I:Landroid/widget/EditText;

    const p2, 0x7f090071

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/Button;

    const/16 v0, 0x11fb

    iput-object p2, p0, Lvj1;->J:Landroid/widget/Button;

    const p2, 0x7f0900c6

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/Button;

    const/16 v0, 0xb76

    iput-object p2, p0, Lvj1;->K:Landroid/widget/Button;

    const p2, 0x7f09005e

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/Button;

    const/16 v0, 0x10f9

    iput-object p2, p0, Lvj1;->L:Landroid/widget/Button;

    const/16 v0, 0x298

    iget-object p2, p0, Lvj1;->z:Landroid/widget/CheckBox;

    nop

    const/4 p3, 0x0

    if-eqz p2, :cond_32e

    const/16 v0, 0x70

    new-instance v3, Luj1;

    nop

    const/16 v0, 0x78

    invoke-direct {v3, p0, v2}, Luj1;-><init>(Lvj1;I)V

    const/16 v0, 0x5f

    invoke-virtual {p2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0x32b

    iget-object p2, p0, Lvj1;->A:Landroid/widget/CheckBox;

    nop

    if-eqz p2, :cond_326

    const/16 v0, 0x70

    new-instance v3, Luj1;

    nop

    const/4 v4, 0x1

    const/16 v0, 0x78

    invoke-direct {v3, p0, v4}, Luj1;-><init>(Lvj1;I)V

    const/16 v0, 0x5f

    invoke-virtual {p2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0xd16

    iget-object p2, p0, Lvj1;->s:Landroid/widget/ImageView;

    nop

    if-eqz p2, :cond_31e

    const/16 v0, 0x70

    new-instance v3, Luj1;

    nop

    const/4 v4, 0x2

    const/16 v0, 0x78

    invoke-direct {v3, p0, v4}, Luj1;-><init>(Lvj1;I)V

    const/16 v0, 0x5f

    invoke-virtual {p2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0x1141

    iget-object p2, p0, Lvj1;->t:Landroid/widget/ImageView;

    nop

    if-eqz p2, :cond_316

    const/16 v0, 0x70

    new-instance v3, Luj1;

    nop

    const/4 v4, 0x3

    const/16 v0, 0x78

    invoke-direct {v3, p0, v4}, Luj1;-><init>(Lvj1;I)V

    const/16 v0, 0x5f

    invoke-virtual {p2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0x8a3

    iget-object p2, p0, Lvj1;->H:Landroid/widget/LinearLayout;

    nop

    if-eqz p2, :cond_30e

    const/16 v0, 0x70

    new-instance v3, Luj1;

    nop

    const/4 v4, 0x4

    const/16 v0, 0x78

    invoke-direct {v3, p0, v4}, Luj1;-><init>(Lvj1;I)V

    const/16 v0, 0x5f

    invoke-virtual {p2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0xcf4

    iget-object p2, p0, Lvj1;->J:Landroid/widget/Button;

    nop

    if-eqz p2, :cond_306

    const/16 v0, 0x70

    new-instance v3, Luj1;

    nop

    const/4 v4, 0x5

    const/16 v0, 0x78

    invoke-direct {v3, p0, v4}, Luj1;-><init>(Lvj1;I)V

    const/16 v0, 0x5f

    invoke-virtual {p2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0x1019

    iget-object p2, p0, Lvj1;->K:Landroid/widget/Button;

    nop

    if-eqz p2, :cond_2fe

    const/16 v0, 0x70

    new-instance v3, Luj1;

    nop

    const/4 v4, 0x6

    const/16 v0, 0x78

    invoke-direct {v3, p0, v4}, Luj1;-><init>(Lvj1;I)V

    const/16 v0, 0x5f

    invoke-virtual {p2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0x1ac

    iget-object p2, p0, Lvj1;->L:Landroid/widget/Button;

    nop

    const-string/jumbo v3, "applypayload"

    if-eqz p2, :cond_2f9

    const/16 v0, 0x70

    new-instance v4, Luj1;

    nop

    const/4 v5, 0x7

    const/16 v0, 0x78

    invoke-direct {v4, p0, v5}, Luj1;-><init>(Lvj1;I)V

    const/16 v0, 0x5f

    invoke-virtual {p2, v4}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0x11c2

    iget-object p2, p0, Lvj1;->q:Lw82;

    nop

    const/16 v0, 0x177

    invoke-virtual {p2}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/content/SharedPreferences;

    const-string/jumbo v5, "cryptoconfig"

    const-string/jumbo v6, ""

    const/16 v0, 0x2e

    invoke-interface {v4, v5, v6}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v0, -0x6

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x47

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v4

    if-lez v4, :cond_26b

    goto :goto_27b

    :cond_26b
    const/16 v0, 0x3fb

    iget-object v4, p0, Lvj1;->r:Ljava/lang/String;

    nop

    const-string/jumbo v5, "pnull"

    const/16 v0, 0x84

    invoke-static {v4, v5}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2ad

    :goto_27b
    const/16 v0, 0x1ac

    iget-object v4, p0, Lvj1;->L:Landroid/widget/Button;

    nop

    if-eqz v4, :cond_2a8

    const/16 v0, 0xf7

    invoke-virtual {v4, v2}, Landroid/view/View;->setEnabled(Z)V

    const/16 v0, 0x1ac

    iget-object v2, p0, Lvj1;->L:Landroid/widget/Button;

    nop

    if-eqz v2, :cond_2a3

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v3

    const v4, 0x7f060084

    const/16 v0, 0xa6b

    invoke-static {v3, v4}, Lqx;->getColorStateList(Landroid/content/Context;I)Landroid/content/res/ColorStateList;

    move-result-object v3

    const/16 v0, 0xcbc

    invoke-virtual {v2, v3}, Landroid/view/View;->setBackgroundTintList(Landroid/content/res/ColorStateList;)V

    goto :goto_2ad

    :cond_2a3
    const/4 v0, 0x5

    invoke-static {v3}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_2a8
    const/4 v0, 0x5

    invoke-static {v3}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_2ad
    :goto_2ad
    const/16 v0, 0x3b7

    iget-object v2, p0, Lvj1;->w:Landroid/widget/EditText;

    nop

    if-eqz v2, :cond_2f1

    const/16 v0, 0x177

    invoke-virtual {p2}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object p3

    check-cast p3, Landroid/content/SharedPreferences;

    const-string/jumbo v3, "ud"

    const/16 v0, 0x2e

    invoke-interface {p3, v3, v6}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    const/4 v0, -0x6

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x8a

    invoke-virtual {v2, p3}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v0, 0x140

    sget-boolean p3, Lg4;->a:Z

    nop

    const/16 v0, 0xfb

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object p0

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x177

    invoke-virtual {p2}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Landroid/content/SharedPreferences;

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x394

    invoke-static {p2, p0}, Lg4;->n(Landroid/content/SharedPreferences;Landroidx/fragment/app/l;)V

    check-cast p1, Landroid/view/View;

    return-object p1

    :cond_2f1
    const-string/jumbo p0, "urltxt"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_2f9
    const/4 v0, 0x5

    invoke-static {v3}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_2fe
    const-string/jumbo p0, "copypayload"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_306
    const-string/jumbo p0, "backtogen"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_30e
    const-string/jumbo p0, "gerar"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_316
    const-string/jumbo p0, "top_bar_right_icon"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_31e
    const-string/jumbo p0, "top_bar_left_icon"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_326
    const-string/jumbo p0, "close"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_32e
    const-string/jumbo p0, "keepalive"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3
.end method

.method public final onDestroyView()V
    .registers 5

    .prologue
    const/16 v0, 0x53a

    invoke-super {p0}, Landroidx/fragment/app/g;->onDestroyView()V

    const/16 v0, 0x11c2

    iget-object v2, p0, Lvj1;->q:Lw82;

    nop

    const/16 v0, 0x177

    invoke-virtual {v2}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroid/content/SharedPreferences;

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x7a

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const/16 v0, 0x3b7

    iget-object p0, p0, Lvj1;->w:Landroid/widget/EditText;

    nop

    if-eqz p0, :cond_3d

    const/16 v0, 0x2d

    invoke-virtual {p0}, Landroid/widget/EditText;->getText()Landroid/text/Editable;

    move-result-object p0

    const/16 v0, 0xcb

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const-string/jumbo v3, "ud"

    const/16 v0, 0x3c

    invoke-interface {v2, v3, p0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x6f

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void

    :cond_3d
    const-string/jumbo p0, "urltxt"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0
.end method

.method public final onStart()V
    .registers 5

    .prologue
    const/16 v0, 0x55f

    invoke-super {p0}, Landroidx/fragment/app/g;->onStart()V

    const/16 v0, 0xaeb

    invoke-virtual {p0}, Landroidx/fragment/app/g;->getDialog()Landroid/app/Dialog;

    move-result-object p0

    if-eqz p0, :cond_34

    const/16 v0, 0xc8b

    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object p0

    if-eqz p0, :cond_34

    const/4 v2, -0x1

    const/4 v3, -0x2

    const/16 v0, 0x1132

    invoke-virtual {p0, v2, v3}, Landroid/view/Window;->setLayout(II)V

    const/16 v0, 0x10ad

    new-instance v2, Landroid/graphics/drawable/ColorDrawable;

    nop

    const/4 v3, 0x0

    const/16 v0, 0xc14

    invoke-direct {v2, v3}, Landroid/graphics/drawable/ColorDrawable;-><init>(I)V

    const/16 v0, 0xba3

    invoke-virtual {p0, v2}, Landroid/view/Window;->setBackgroundDrawable(Landroid/graphics/drawable/Drawable;)V

    const v2, 0x7f140137

    const/16 v0, 0xa0d

    invoke-virtual {p0, v2}, Landroid/view/Window;->setWindowAnimations(I)V

    :cond_34
    return-void
.end method
