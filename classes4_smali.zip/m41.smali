.class public final Lm41;
.super Lqq1;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public c:Lcom/tlsvpn/tlstunnel/ui/Logs;


# virtual methods
.method public final a()I
    .registers 3

    const/16 v0, 0x905

    sget-boolean p0, Lmi2;->a:Z

    nop

    const/16 v0, 0xb7a

    sget-object p0, Lmi2;->b:Ljava/util/concurrent/CopyOnWriteArrayList;

    nop

    const/16 v0, 0x13d

    invoke-virtual {p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->size()I

    move-result p0

    return p0
.end method

.method public final e(Lpr1;I)V
    .registers 7

    check-cast p1, Ll41;

    const/16 v0, 0x8df

    iget-object p1, p1, Ll41;->u:Landroid/widget/TextView;

    nop

    const/16 v0, 0xb7a

    sget-object v2, Lmi2;->b:Ljava/util/concurrent/CopyOnWriteArrayList;

    nop

    const/16 v0, 0xd25

    invoke-virtual {v2, p2}, Ljava/util/concurrent/CopyOnWriteArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/CharSequence;

    const/16 v0, 0x8a

    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/16 v0, 0xb9c

    invoke-static {}, Landroid/text/method/LinkMovementMethod;->getInstance()Landroid/text/method/MovementMethod;

    move-result-object v2

    const/16 v0, 0xfc1

    invoke-virtual {p1, v2}, Landroid/widget/TextView;->setMovementMethod(Landroid/text/method/MovementMethod;)V

    const/16 v0, 0x1187

    new-instance v2, Lk41;

    nop

    const/4 v3, 0x0

    const/16 v0, 0xe10

    invoke-direct {v2, p0, p2, v3}, Lk41;-><init>(Lqq1;II)V

    const/16 v0, 0x8f

    invoke-virtual {p1, v2}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    return-void
.end method

.method public final f(Landroid/view/ViewGroup;I)Lpr1;
    .registers 6

    const/16 v0, 0xee7

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p0

    const/16 v0, 0x8f9

    invoke-static {p0}, Landroid/view/LayoutInflater;->from(Landroid/content/Context;)Landroid/view/LayoutInflater;

    move-result-object p0

    const p2, 0x7f0c00c7

    const/4 v2, 0x0

    const/16 v0, 0x107b

    invoke-virtual {p0, p2, p1, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p0

    const/16 v0, 0x10b0

    new-instance p1, Ll41;

    nop

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xb5e

    invoke-direct {p1, p0}, Ll41;-><init>(Landroid/view/View;)V

    check-cast p1, Lpr1;

    return-object p1
.end method
