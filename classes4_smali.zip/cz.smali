.class public final Lcz;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:I

.field public final b:I

.field public final c:Ljava/lang/String;


# direct methods
.method public constructor <init>(IILjava/lang/String;)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x5f6

    iput p1, p0, Lcz;->a:I

    const/16 v0, 0x781

    iput p2, p0, Lcz;->b:I

    const/16 v0, 0xf70

    iput-object p3, p0, Lcz;->c:Ljava/lang/String;

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .prologue
    if-ne p0, p1, :cond_3

    goto :goto_38

    :cond_3
    instance-of v2, p1, Lcz;

    if-nez v2, :cond_8

    goto :goto_36

    :cond_8
    check-cast p1, Lcz;

    const/16 v0, 0x3c6

    iget v2, p0, Lcz;->a:I

    nop

    const/16 v0, 0x3c6

    iget v3, p1, Lcz;->a:I

    nop

    if-eq v2, v3, :cond_17

    goto :goto_36

    :cond_17
    const/16 v0, 0x36f

    iget v2, p0, Lcz;->b:I

    nop

    const/16 v0, 0x36f

    iget v3, p1, Lcz;->b:I

    nop

    if-eq v2, v3, :cond_24

    goto :goto_36

    :cond_24
    const/16 v0, 0x1e6

    iget-object p0, p0, Lcz;->c:Ljava/lang/String;

    nop

    const/16 v0, 0x1e6

    iget-object p1, p1, Lcz;->c:Ljava/lang/String;

    nop

    const/16 v0, 0x128

    invoke-virtual {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_38

    :goto_36
    const/4 p0, 0x0

    return p0

    :cond_38
    :goto_38
    const/4 p0, 0x1

    return p0
.end method

.method public final hashCode()I
    .registers 6

    const/16 v0, 0x3c6

    iget v2, p0, Lcz;->a:I

    nop

    const/16 v0, 0x1130

    invoke-static {v2}, Ljava/lang/Integer;->hashCode(I)I

    move-result v2

    const/16 v3, 0x1f

    mul-int/2addr v2, v3

    const/16 v0, 0x36f

    iget v4, p0, Lcz;->b:I

    nop

    const/16 v0, 0x19b

    invoke-static {v4, v2, v3}, Lmz2;->g(III)I

    move-result v2

    const/16 v0, 0x1e6

    iget-object p0, p0, Lcz;->c:Ljava/lang/String;

    nop

    const/16 v0, 0x51

    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result p0

    add-int/2addr p0, v2

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 5

    const/4 v0, -0x3

    new-instance v2, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v3, "CountryRes(flagId="

    const/16 v0, 0x97

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x3c6

    iget v3, p0, Lcz;->a:I

    nop

    const/16 v0, 0x33

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v3, ", fullname="

    const/4 v0, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x36f

    iget v3, p0, Lcz;->b:I

    nop

    const/16 v0, 0x33

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v3, ", emoji="

    const/4 v0, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x1e6

    iget-object p0, p0, Lcz;->c:Ljava/lang/String;

    nop

    const/16 v3, 0x29

    const/16 v0, 0x7a8

    invoke-static {v2, p0, v3}, Ly41;->r(Ljava/lang/StringBuilder;Ljava/lang/String;C)Ljava/lang/String;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    return-object p0
.end method
