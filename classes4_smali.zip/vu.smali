.class public final synthetic Lvu;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lwu;


# direct methods
.method public synthetic constructor <init>(Lwu;I)V
    .registers 5

    iput p2, p0, Lvu;->a:I

    iput-object p1, p0, Lvu;->b:Lwu;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .registers 11

    .prologue
    const/16 v0, 0x11af

    iget v2, p0, Lvu;->a:I

    nop

    const-string/jumbo v3, "payloadasL"

    const/4 v4, 0x0

    const/16 v5, 0x8

    const/4 v6, 0x0

    const/16 v0, 0x5da

    iget-object p0, p0, Lvu;->b:Lwu;

    nop

    packed-switch v2, :pswitch_data_d8

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xb8a

    iget-object p0, p0, Lwu;->E:Landroid/widget/LinearLayout;

    nop

    if-eqz p0, :cond_27

    if-eqz p2, :cond_22

    move v5, v6

    :cond_22
    const/4 v0, -0x5

    invoke-virtual {p0, v5}, Landroid/view/View;->setVisibility(I)V

    return-void

    :cond_27
    const-string/jumbo p0, "prxserverL"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :pswitch_2f  #0x2
    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x3f3

    iget-object p1, p0, Lwu;->C:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz p1, :cond_5a

    if-eqz p2, :cond_55

    const/16 v0, 0xbf1

    iget-object p0, p0, Lwu;->x:Landroid/widget/CheckBox;

    nop

    if-eqz p0, :cond_4d

    const/16 v0, 0x36

    invoke-virtual {p0}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result p0

    if-eqz p0, :cond_55

    move v5, v6

    goto :goto_55

    :cond_4d
    const-string/jumbo p0, "usesnihost"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_55
    :goto_55
    const/4 v0, -0x5

    invoke-virtual {p1, v5}, Landroid/view/View;->setVisibility(I)V

    return-void

    :cond_5a
    const/4 v0, 0x5

    invoke-static {v3}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :pswitch_5f  #0x1
    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x1032

    iget-object p1, p0, Lwu;->y:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz p1, :cond_b4

    if-eqz p2, :cond_6e

    move v2, v6

    goto :goto_6f

    :cond_6e
    move v2, v5

    :goto_6f
    const/4 v0, -0x5

    invoke-virtual {p1, v2}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0x339

    iget-object p1, p0, Lwu;->A:Landroid/widget/CheckBox;

    nop

    const-string/jumbo v2, "usepayloadas"

    if-eqz p1, :cond_af

    if-eqz p2, :cond_81

    move v7, v6

    goto :goto_82

    :cond_81
    move v7, v5

    :goto_82
    const/4 v0, -0x5

    invoke-virtual {p1, v7}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0x3f3

    iget-object p1, p0, Lwu;->C:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz p1, :cond_aa

    if-eqz p2, :cond_a5

    const/16 v0, 0x339

    iget-object p0, p0, Lwu;->A:Landroid/widget/CheckBox;

    nop

    if-eqz p0, :cond_a0

    const/16 v0, 0x36

    invoke-virtual {p0}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result p0

    if-eqz p0, :cond_a5

    move v5, v6

    goto :goto_a5

    :cond_a0
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_a5
    :goto_a5
    const/4 v0, -0x5

    invoke-virtual {p1, v5}, Landroid/view/View;->setVisibility(I)V

    return-void

    :cond_aa
    const/4 v0, 0x5

    invoke-static {v3}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_af
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :cond_b4
    const-string/jumbo p0, "snihostL"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    :pswitch_bc  #0x0
    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x558

    iget-object p0, p0, Lwu;->v:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz p0, :cond_cf

    if-eqz p2, :cond_ca

    move v5, v6

    :cond_ca
    const/4 v0, -0x5

    invoke-virtual {p0, v5}, Landroid/view/View;->setVisibility(I)V

    return-void

    :cond_cf
    const-string/jumbo p0, "payloadL"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v4

    nop

    :pswitch_data_d8
    .packed-switch 0x0
        :pswitch_bc  #00000000
        :pswitch_5f  #00000001
        :pswitch_2f  #00000002
    .end packed-switch
.end method
