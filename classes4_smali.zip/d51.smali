.class public final synthetic Ld51;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 5

    iput p1, p0, Ld51;->a:I

    iput-object p2, p0, Ld51;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 20

    .prologue
    const/16 v6, 0xa41

    move-object/from16 v0, p0

    iget v8, v0, Ld51;->a:I

    nop

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x1

    const/16 v6, 0xde2

    move-object/from16 v0, p0

    iget-object v6, v0, Ld51;->b:Ljava/lang/Object;

    move-object/16 p0, v6

    packed-switch v8, :pswitch_data_43e

    check-cast p0, Lcom/vungle/ads/internal/presenter/w;

    const/16 v6, 0x6dd

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p2

    invoke-static {v0, v1, v2}, Lcom/vungle/ads/internal/presenter/w;->a(Lcom/vungle/ads/internal/presenter/w;Landroid/content/DialogInterface;I)V

    return-void

    :pswitch_24  #0x4
    check-cast p0, Ljava/util/concurrent/atomic/AtomicInteger;

    const/16 v6, 0xa58

    move-object/from16 v0, p0

    move/from16 v1, p2

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;->set(I)V

    return-void

    :pswitch_30  #0x3
    check-cast p0, Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings;

    const/16 v6, 0x637

    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings;->a:Lw82;

    move-object/16 p2, v6

    const/16 v6, 0x177

    move-object/from16 v0, p2

    invoke-virtual {v0}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Landroid/content/SharedPreferences;

    const-string/jumbo v12, "dmode"

    const/16 v6, 0x77

    invoke-interface {v8, v12, v10}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v8

    const/16 v6, 0x177

    move-object/from16 v0, p2

    invoke-virtual {v0}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Landroid/content/SharedPreferences;

    const-string/jumbo v14, "language"

    const-string/jumbo v15, "system"

    const/16 v6, 0x2e

    invoke-interface {v13, v14, v15}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    const/16 v6, 0x84

    invoke-static {v13, v15}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v13

    if-nez v8, :cond_72

    if-nez v13, :cond_6f

    goto :goto_72

    :cond_6f
    move/from16 v16, v10

    goto :goto_74

    :cond_72
    :goto_72
    move/from16 v16, v11

    :goto_74
    const/16 v6, 0x177

    move-object/from16 v0, p2

    invoke-virtual {v0}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Landroid/content/SharedPreferences;

    const/4 v6, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x7a

    move-object/from16 v0, p2

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p2

    const/16 v6, 0x3c

    move-object/from16 v0, p2

    invoke-interface {v0, v14, v15}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/16 v6, 0x48

    move-object/from16 v0, p2

    invoke-interface {v0, v12, v10}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const-string/jumbo v12, "atcountdown"

    const/16 v6, 0x48

    move-object/from16 v0, p2

    invoke-interface {v0, v12, v11}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const-string/jumbo v12, "cname"

    const/16 v6, 0x48

    move-object/from16 v0, p2

    invoke-interface {v0, v12, v11}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const-string/jumbo v12, "appfilter"

    const/16 v6, 0x48

    move-object/from16 v0, p2

    invoke-interface {v0, v12, v10}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const-string/jumbo v12, "appfilter_mode"

    const/16 v6, 0x48

    move-object/from16 v0, p2

    invoke-interface {v0, v12, v11}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const-string/jumbo v12, "checkedapps"

    const/16 v6, 0xc01

    sget-object v14, Lea0;->a:Lea0;

    nop

    const/16 v6, 0x123d

    move-object/from16 v0, p2

    invoke-interface {v0, v12, v14}, Landroid/content/SharedPreferences$Editor;->putStringSet(Ljava/lang/String;Ljava/util/Set;)Landroid/content/SharedPreferences$Editor;

    const-string/jumbo v12, "intranet"

    const/16 v6, 0x48

    move-object/from16 v0, p2

    invoke-interface {v0, v12, v10}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const-string/jumbo v12, "compresspkt"

    const/16 v6, 0x48

    move-object/from16 v0, p2

    invoke-interface {v0, v12, v10}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const-string/jumbo v12, "encdns"

    const/16 v6, 0x48

    move-object/from16 v0, p2

    invoke-interface {v0, v12, v11}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const-string/jumbo v12, "osdns"

    const/16 v6, 0x48

    move-object/from16 v0, p2

    invoke-interface {v0, v12, v11}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const-string/jumbo v12, "dnsP"

    const-string/jumbo v14, "8.8.8.8"

    const/16 v6, 0x3c

    move-object/from16 v0, p2

    invoke-interface {v0, v12, v14}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const-string/jumbo v12, "dnsS"

    const-string/jumbo v14, "1.1.1.1"

    const/16 v6, 0x3c

    move-object/from16 v0, p2

    invoke-interface {v0, v12, v14}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const-string/jumbo v12, "nup"

    const/16 v6, 0x48

    move-object/from16 v0, p2

    invoke-interface {v0, v12, v11}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const-string/jumbo v12, "renewnotf"

    const/16 v6, 0x48

    move-object/from16 v0, p2

    invoke-interface {v0, v12, v11}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/16 v6, 0x6f

    move-object/from16 v0, p2

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    if-eqz v16, :cond_17f

    const/16 v6, 0x7dd

    sput-boolean v10, Lmi2;->h:Z

    if-eqz v8, :cond_168

    if-nez v13, :cond_168

    const/16 v6, 0x192

    move-object/from16 v0, p0

    iget-object v6, v0, Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings;->b:Landroid/view/View;

    move-object/16 p0, v6

    if-eqz p0, :cond_15b

    const/16 v6, 0xec6

    new-instance p2, Li90;

    nop

    const/4 v8, 0x2

    const/16 v6, 0xb41

    move-object/from16 v0, p2

    invoke-direct {v0, v8}, Li90;-><init>(I)V

    const-wide/16 v8, 0xfa

    const/16 v6, 0x60d

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    invoke-virtual {v0, v1, v8, v9}, Landroid/view/View;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_15b
    const/16 v6, 0x39b

    sget-object p0, Lv31;->b:Lv31;

    nop

    const/16 v6, 0x474

    move-object/from16 v0, p0

    invoke-static {v0}, Leb;->l(Lv31;)V

    goto :goto_1ba

    :cond_168
    if-eqz v8, :cond_170

    const/16 v6, 0xe6d

    invoke-static {v11}, Leb;->p(I)V

    goto :goto_1ba

    :cond_170
    if-nez v13, :cond_1ba

    const/16 v6, 0x39b

    sget-object p0, Lv31;->b:Lv31;

    nop

    const/16 v6, 0x474

    move-object/from16 v0, p0

    invoke-static {v0}, Leb;->l(Lv31;)V

    goto :goto_1ba

    :cond_17f
    const/16 v6, 0x401

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->getChildFragmentManager()Landroidx/fragment/app/p;

    move-result-object p0

    const/4 v6, -0x6

    move-object/from16 v0, p0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xca0

    new-instance p2, Landroidx/fragment/app/a;

    nop

    const/16 v6, 0xf9e

    move-object/from16 v0, p2

    move-object/from16 v1, p0

    invoke-direct {v0, v1}, Landroidx/fragment/app/a;-><init>(Landroidx/fragment/app/p;)V

    const/16 v6, 0x586

    new-instance p0, Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings$a;

    nop

    const/16 v6, 0x11f1

    move-object/from16 v0, p0

    invoke-direct {v0}, Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings$a;-><init>()V

    const v8, 0x7f0903a2

    const/16 v6, 0xbb7

    move-object/from16 v0, p2

    move-object/from16 v1, p0

    invoke-virtual {v0, v8, v1, v9}, Lvi0;->e(ILandroidx/fragment/app/Fragment;Ljava/lang/String;)V

    const/16 v6, 0xae9

    move-object/from16 v0, p2

    invoke-virtual {v0, v10}, Landroidx/fragment/app/a;->g(Z)I

    :cond_1ba
    :goto_1ba
    const/16 v6, 0x179

    move-object/from16 v0, p1

    invoke-interface {v0}, Landroid/content/DialogInterface;->dismiss()V

    return-void

    :pswitch_1c2  #0x2
    check-cast p0, Lg12;

    const/16 v6, 0xcfe

    move-object/from16 v0, p0

    invoke-virtual {v0, v11}, Lg12;->e(Z)V

    const/16 v6, 0x2ba

    move-object/from16 v0, p0

    iget-object v6, v0, Lg12;->x:Landroidx/recyclerview/widget/RecyclerView;

    move-object/16 p2, v6

    if-eqz p2, :cond_35c

    const/16 v8, 0x8

    const/4 v6, -0x5

    move-object/from16 v0, p2

    invoke-virtual {v0, v8}, Landroid/view/View;->setVisibility(I)V

    new-array v0, v10, [Ljava/lang/String;

    move-object/from16 p2, v0

    const/16 v6, 0xe56

    move-object/from16 v0, p2

    sput-object v0, Lqk;->m:[Ljava/lang/String;

    new-array v0, v10, [Ljava/lang/String;

    move-object/from16 p2, v0

    const/16 v6, 0x9d0

    move-object/from16 v0, p2

    sput-object v0, Lqk;->n:[Ljava/lang/String;

    const/16 v6, 0x131

    move-object/from16 v0, p0

    invoke-virtual {v0}, Lg12;->d()Landroid/content/SharedPreferences;

    move-result-object p2

    const/4 v6, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x7a

    move-object/from16 v0, p2

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p2

    const/16 v6, 0x1b1

    move-object/from16 v0, p0

    iget-boolean v8, v0, Lg12;->r:Z

    nop

    const-string/jumbo v11, "server"

    const-string/jumbo v12, "psrvslctd"

    const-string/jumbo v13, ""

    if-eqz v8, :cond_246

    const/16 v6, 0x131

    move-object/from16 v0, p0

    invoke-virtual {v0}, Lg12;->d()Landroid/content/SharedPreferences;

    move-result-object v8

    const/16 v6, 0x77

    invoke-interface {v8, v12, v10}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v8

    if-eqz v8, :cond_231

    const/16 v6, 0x56

    move-object/from16 v0, p2

    invoke-interface {v0, v11, v10}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    :cond_231
    const-string/jumbo v8, "psrvlistid"

    const/16 v6, 0x3c

    move-object/from16 v0, p2

    invoke-interface {v0, v8, v13}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const-string/jumbo v8, "psrvlist"

    const/16 v6, 0x3c

    move-object/from16 v0, p2

    invoke-interface {v0, v8, v13}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    goto :goto_271

    :cond_246
    const/16 v6, 0x131

    move-object/from16 v0, p0

    invoke-virtual {v0}, Lg12;->d()Landroid/content/SharedPreferences;

    move-result-object v8

    const/16 v6, 0x77

    invoke-interface {v8, v12, v10}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v8

    if-nez v8, :cond_25d

    const/16 v6, 0x56

    move-object/from16 v0, p2

    invoke-interface {v0, v11, v10}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    :cond_25d
    const-string/jumbo v8, "osrvlistid"

    const/16 v6, 0x3c

    move-object/from16 v0, p2

    invoke-interface {v0, v8, v13}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const-string/jumbo v8, "osrvlist"

    const/16 v6, 0x3c

    move-object/from16 v0, p2

    invoke-interface {v0, v8, v13}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    :goto_271
    const/16 v6, 0x6f

    move-object/from16 v0, p2

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/16 v6, 0x123

    sget-object p2, Lpp1;->a:Lv0;

    nop

    const/16 v8, 0x400

    const/16 v6, 0x16d

    move-object/from16 v0, p2

    invoke-virtual {v0, v8}, Lv0;->l(I)I

    move-result v11

    const/16 v6, 0xfad

    move-object/from16 v0, p0

    iput v11, v0, Lg12;->z:I

    const/16 v6, 0x16d

    move-object/from16 v0, p2

    invoke-virtual {v0, v8}, Lv0;->l(I)I

    move-result p2

    const/16 v6, 0x850

    move-object/from16 v0, p0

    move/from16 v1, p2

    iput v1, v0, Lg12;->A:I

    const/16 v6, 0x5b

    new-instance p2, Landroid/content/Intent;

    nop

    const/16 v6, 0x2b

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v8

    const-class v11, Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;

    const-string/jumbo v12, "SLISTUPDATE"

    const/16 v6, 0x3fd

    move v0, v6

    move-object/from16 v1, p2

    move-object v2, v12

    move-object v3, v9

    move-object v4, v8

    move-object v5, v11

    invoke-direct/range {v1 .. v5}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;Landroid/content/Context;Ljava/lang/Class;)V

    const/16 v6, 0x1b1

    move-object/from16 v0, p0

    iget-boolean v8, v0, Lg12;->r:Z

    nop

    if-nez v8, :cond_2cc

    const/16 v6, 0x81c

    move-object/from16 v0, p0

    iget v8, v0, Lg12;->z:I

    nop

    goto :goto_2cd

    :cond_2cc
    move v8, v10

    :goto_2cd
    const-string/jumbo v9, "cId"

    const/16 v6, 0x29

    move-object/from16 v0, p2

    invoke-virtual {v0, v9, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object p2

    const-string/jumbo v8, "cTp"

    const/4 v9, 0x4

    const/16 v6, 0x29

    move-object/from16 v0, p2

    invoke-virtual {v0, v8, v9}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object p2

    const-string/jumbo v8, "cspl"

    const/16 v6, 0x1b1

    move-object/from16 v0, p0

    iget-boolean v9, v0, Lg12;->r:Z

    nop

    const/16 v6, 0x178

    move-object/from16 v0, p2

    invoke-virtual {v0, v8, v9}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    move-result-object p2

    const-string/jumbo v8, "notifymain"

    const/16 v6, 0x178

    move-object/from16 v0, p2

    invoke-virtual {v0, v8, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    move-result-object p2

    const/4 v6, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x2b

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v8

    const/16 v6, 0x4a7

    move-object/from16 v0, p2

    invoke-virtual {v8, v0}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    const/16 v6, 0x2b

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p2

    const/16 v6, 0x5b

    new-instance v8, Landroid/content/Intent;

    nop

    const-string/jumbo v9, "restoreHome"

    const/16 v6, 0x62

    invoke-direct {v8, v9}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v6, 0x2b

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p0

    const/16 v6, 0x53

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/16 v6, 0x4a

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/16 v6, 0x64

    move-object/from16 v0, p0

    invoke-virtual {v8, v0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    const/16 v6, 0x63

    move-object/from16 v0, p2

    move-object/from16 v1, p0

    invoke-virtual {v0, v1}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    const/16 v6, 0x179

    move-object/from16 v0, p1

    invoke-interface {v0}, Landroid/content/DialogInterface;->dismiss()V

    return-void

    :cond_35c
    const-string/jumbo p0, "serverlist"

    const/4 v6, 0x5

    move-object/from16 v0, p0

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v9

    :pswitch_366  #0x1
    check-cast p0, Lcom/tlsvpn/tlstunnel/ui/Others;

    const/16 v6, 0x2b

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p2

    const-string/jumbo v8, "clipboard"

    const/16 v6, 0x31d

    move-object/from16 v0, p2

    invoke-virtual {v0, v8}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p2

    const/4 v6, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/content/ClipboardManager;

    const/16 v6, 0x2b

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v8

    const/16 v6, 0x1d2

    invoke-virtual {v8}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v8

    const-string/jumbo v9, "android_id"

    const/16 v6, 0x249

    invoke-static {v8, v9}, Landroid/provider/Settings$Secure;->getString(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const v9, 0x7f1300f9

    const/16 v6, 0x4c

    move-object/from16 v0, p0

    invoke-virtual {v0, v9}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v9

    const/16 v6, 0x703

    invoke-static {v9, v8}, Landroid/content/ClipData;->newPlainText(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Landroid/content/ClipData;

    move-result-object v9

    const/16 v6, 0xba6

    move-object/from16 v0, p2

    invoke-virtual {v0, v9}, Landroid/content/ClipboardManager;->setPrimaryClip(Landroid/content/ClipData;)V

    const/16 v6, 0xfb

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object p2

    const/16 v6, 0x5b

    new-instance v9, Landroid/content/Intent;

    nop

    const-string/jumbo v10, "ssb"

    const/16 v6, 0x62

    invoke-direct {v9, v10}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v6, -0x3

    new-instance v10, Ljava/lang/StringBuilder;

    nop

    const/4 v6, -0x4

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const v11, 0x7f130097

    const/16 v6, 0x4c

    move-object/from16 v0, p0

    invoke-virtual {v0, v11}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object v11

    const/4 v6, 0x0

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v11, ": "

    const/4 v6, 0x0

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    invoke-virtual {v10, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, -0x2

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    const-string/jumbo v10, "msg"

    const/16 v6, 0x4b

    invoke-virtual {v9, v10, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v8

    const/16 v6, 0x2b

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p0

    const/16 v6, 0x53

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/16 v6, 0x4a

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/16 v6, 0x64

    move-object/from16 v0, p0

    invoke-virtual {v8, v0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    const/16 v6, 0x63

    move-object/from16 v0, p2

    move-object/from16 v1, p0

    invoke-virtual {v0, v1}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    const/16 v6, 0x179

    move-object/from16 v0, p1

    invoke-interface {v0}, Landroid/content/DialogInterface;->dismiss()V

    return-void

    :pswitch_428  #0x0
    check-cast p0, Lcom/tlsvpn/tlstunnel/MainActivity;

    const/16 v6, 0x44d

    sget p2, Lcom/tlsvpn/tlstunnel/MainActivity;->m:I

    nop

    const/16 v6, 0x7e9

    move-object/from16 v0, p0

    invoke-virtual {v0}, Lcom/tlsvpn/tlstunnel/MainActivity;->m()V

    const/16 v6, 0x179

    move-object/from16 v0, p1

    invoke-interface {v0}, Landroid/content/DialogInterface;->dismiss()V

    return-void

    :pswitch_data_43e
    .packed-switch 0x0
        :pswitch_428  #00000000
        :pswitch_366  #00000001
        :pswitch_1c2  #00000002
        :pswitch_30  #00000003
        :pswitch_24  #00000004
    .end packed-switch
.end method
