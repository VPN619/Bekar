.class public final synthetic Lgc0;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lkc0;


# direct methods
.method public synthetic constructor <init>(Lkc0;I)V
    .registers 5

    iput p2, p0, Lgc0;->a:I

    iput-object p1, p0, Lgc0;->b:Lkc0;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .registers 15

    .prologue
    const/16 v0, 0xfcf

    iget v2, p0, Lgc0;->a:I

    nop

    const-string/jumbo v3, "blockTorrent"

    const-string/jumbo v4, "sshuserpass"

    const-string/jumbo v5, "mensagem_l"

    const-string/jumbo v6, "htmlspp"

    const-string/jumbo v7, "msgpreviewhint"

    const-string/jumbo v8, "txtMsgPreviewCard"

    const/4 v9, 0x0

    const/16 v10, 0x8

    const/16 v0, 0xd5f

    iget-object p0, p0, Lgc0;->b:Lkc0;

    nop

    const/4 v11, 0x0

    packed-switch v2, :pswitch_data_2d6

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x268

    iget-object p1, p0, Lkc0;->x:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz p2, :cond_6a

    if-eqz p1, :cond_65

    const/4 v0, -0x5

    invoke-virtual {p1, v9}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0xce

    iget-object p1, p0, Lkc0;->R:Landroid/widget/TextView;

    nop

    if-eqz p1, :cond_60

    const/4 v0, -0x5

    invoke-virtual {p1, v9}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0xfc

    iget-object p1, p0, Lkc0;->O:Landroid/widget/TextView;

    nop

    if-eqz p1, :cond_5b

    const/4 v0, -0x5

    invoke-virtual {p1, v9}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0xda

    iget-object p0, p0, Lkc0;->P:Lcom/google/android/material/card/MaterialCardView;

    nop

    if-eqz p0, :cond_56

    const/4 v0, -0x5

    invoke-virtual {p0, v9}, Landroid/view/View;->setVisibility(I)V

    goto :goto_91

    :cond_56
    const/4 v0, 0x5

    invoke-static {v8}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_5b
    const/4 v0, 0x5

    invoke-static {v7}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_60
    const/4 v0, 0x5

    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_65
    const/4 v0, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_6a
    if-eqz p1, :cond_a1

    const/4 v0, -0x5

    invoke-virtual {p1, v10}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0xce

    iget-object p1, p0, Lkc0;->R:Landroid/widget/TextView;

    nop

    if-eqz p1, :cond_9c

    const/4 v0, -0x5

    invoke-virtual {p1, v10}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0xfc

    iget-object p1, p0, Lkc0;->O:Landroid/widget/TextView;

    nop

    if-eqz p1, :cond_97

    const/4 v0, -0x5

    invoke-virtual {p1, v10}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0xda

    iget-object p0, p0, Lkc0;->P:Lcom/google/android/material/card/MaterialCardView;

    nop

    if-eqz p0, :cond_92

    const/4 v0, -0x5

    invoke-virtual {p0, v10}, Landroid/view/View;->setVisibility(I)V

    :goto_91
    return-void

    :cond_92
    const/4 v0, 0x5

    invoke-static {v8}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_97
    const/4 v0, 0x5

    invoke-static {v7}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_9c
    const/4 v0, 0x5

    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_a1
    const/4 v0, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :pswitch_a6  #0x2
    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x23b

    iget-object p0, p0, Lkc0;->G:Landroid/widget/LinearLayout;

    nop

    if-eqz p2, :cond_bd

    if-eqz p0, :cond_b8

    const/4 v0, -0x5

    invoke-virtual {p0, v9}, Landroid/view/View;->setVisibility(I)V

    goto :goto_c3

    :cond_b8
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_bd
    if-eqz p0, :cond_c4

    const/4 v0, -0x5

    invoke-virtual {p0, v10}, Landroid/view/View;->setVisibility(I)V

    :goto_c3
    return-void

    :cond_c4
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :pswitch_c9  #0x1
    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x23f

    iget-object p1, p0, Lkc0;->M:Landroid/widget/CheckBox;

    nop

    const-string/jumbo v2, "sshhostport"

    const-string/jumbo v5, "sshlogin"

    if-eqz p2, :cond_146

    if-eqz p1, :cond_141

    const/16 v0, 0xf4

    iget-object p2, p0, Lkc0;->y:Landroid/widget/CheckBox;

    nop

    if-eqz p2, :cond_139

    const/16 v0, 0x36

    invoke-virtual {p2}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result p2

    if-eqz p2, :cond_ed

    move p2, v9

    goto :goto_ee

    :cond_ed
    move p2, v10

    :goto_ee
    const/4 v0, -0x5

    invoke-virtual {p1, p2}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0x494

    iget-object p1, p0, Lkc0;->A:Landroid/widget/TableLayout;

    nop

    if-eqz p1, :cond_134

    const/4 v0, -0x5

    invoke-virtual {p1, v9}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0xa1

    iget-object p1, p0, Lkc0;->F:Landroid/widget/CheckBox;

    nop

    if-eqz p1, :cond_12f

    const/4 v0, -0x5

    invoke-virtual {p1, v9}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0x23b

    iget-object p1, p0, Lkc0;->G:Landroid/widget/LinearLayout;

    nop

    if-eqz p1, :cond_12a

    const/16 v0, 0xa1

    iget-object p0, p0, Lkc0;->F:Landroid/widget/CheckBox;

    nop

    if-eqz p0, :cond_125

    const/16 v0, 0x36

    invoke-virtual {p0}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result p0

    if-eqz p0, :cond_11f

    goto :goto_120

    :cond_11f
    move v9, v10

    :goto_120
    const/4 v0, -0x5

    invoke-virtual {p1, v9}, Landroid/view/View;->setVisibility(I)V

    goto :goto_16d

    :cond_125
    const/4 v0, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_12a
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_12f
    const/4 v0, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_134
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_139
    const-string/jumbo p0, "bloqmc"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_141
    const/4 v0, 0x5

    invoke-static {v3}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_146
    if-eqz p1, :cond_17d

    const/4 v0, -0x5

    invoke-virtual {p1, v10}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0x494

    iget-object p1, p0, Lkc0;->A:Landroid/widget/TableLayout;

    nop

    if-eqz p1, :cond_178

    const/4 v0, -0x5

    invoke-virtual {p1, v10}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0xa1

    iget-object p1, p0, Lkc0;->F:Landroid/widget/CheckBox;

    nop

    if-eqz p1, :cond_173

    const/4 v0, -0x5

    invoke-virtual {p1, v10}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0x23b

    iget-object p0, p0, Lkc0;->G:Landroid/widget/LinearLayout;

    nop

    if-eqz p0, :cond_16e

    const/4 v0, -0x5

    invoke-virtual {p0, v10}, Landroid/view/View;->setVisibility(I)V

    :goto_16d
    return-void

    :cond_16e
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_173
    const/4 v0, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_178
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_17d
    const/4 v0, 0x5

    invoke-static {v3}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :pswitch_182  #0x0
    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x23f

    iget-object p1, p0, Lkc0;->M:Landroid/widget/CheckBox;

    nop

    const-string/jumbo v2, "blockRootDev"

    const-string/jumbo v4, "addmsg"

    if-eqz p2, :cond_26a

    if-eqz p1, :cond_265

    const/16 v0, 0x90

    iget-object p2, p0, Lkc0;->z:Landroid/widget/CheckBox;

    nop

    if-eqz p2, :cond_25d

    const/16 v0, 0x36

    invoke-virtual {p2}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result p2

    if-eqz p2, :cond_1a6

    move p2, v9

    goto :goto_1a7

    :cond_1a6
    move p2, v10

    :goto_1a7
    const/4 v0, -0x5

    invoke-virtual {p1, p2}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0xe6

    iget-object p1, p0, Lkc0;->L:Landroid/widget/CheckBox;

    nop

    if-eqz p1, :cond_258

    const/4 v0, -0x5

    invoke-virtual {p1, v9}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0x1b5

    iget-object p1, p0, Lkc0;->N:Landroid/widget/CheckBox;

    nop

    if-eqz p1, :cond_253

    const/4 v0, -0x5

    invoke-virtual {p1, v9}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0xe6

    iget-object p1, p0, Lkc0;->L:Landroid/widget/CheckBox;

    nop

    if-eqz p1, :cond_24e

    const/16 v0, 0x36

    invoke-virtual {p1}, Landroid/widget/CompoundButton;->isChecked()Z

    move-result p1

    const/16 v0, 0x268

    iget-object p2, p0, Lkc0;->x:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz p1, :cond_212

    if-eqz p2, :cond_20d

    const/4 v0, -0x5

    invoke-virtual {p2, v9}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0xce

    iget-object p1, p0, Lkc0;->R:Landroid/widget/TextView;

    nop

    if-eqz p1, :cond_208

    const/4 v0, -0x5

    invoke-virtual {p1, v9}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0xfc

    iget-object p1, p0, Lkc0;->O:Landroid/widget/TextView;

    nop

    if-eqz p1, :cond_203

    const/4 v0, -0x5

    invoke-virtual {p1, v9}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0xda

    iget-object p0, p0, Lkc0;->P:Lcom/google/android/material/card/MaterialCardView;

    nop

    if-eqz p0, :cond_1fe

    const/4 v0, -0x5

    invoke-virtual {p0, v9}, Landroid/view/View;->setVisibility(I)V

    goto/16 :goto_2b2

    :cond_1fe
    const/4 v0, 0x5

    invoke-static {v8}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_203
    const/4 v0, 0x5

    invoke-static {v7}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_208
    const/4 v0, 0x5

    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_20d
    const/4 v0, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_212
    if-eqz p2, :cond_249

    const/4 v0, -0x5

    invoke-virtual {p2, v10}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0xce

    iget-object p1, p0, Lkc0;->R:Landroid/widget/TextView;

    nop

    if-eqz p1, :cond_244

    const/4 v0, -0x5

    invoke-virtual {p1, v10}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0xfc

    iget-object p1, p0, Lkc0;->O:Landroid/widget/TextView;

    nop

    if-eqz p1, :cond_23f

    const/4 v0, -0x5

    invoke-virtual {p1, v10}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0xda

    iget-object p0, p0, Lkc0;->P:Lcom/google/android/material/card/MaterialCardView;

    nop

    if-eqz p0, :cond_23a

    const/4 v0, -0x5

    invoke-virtual {p0, v10}, Landroid/view/View;->setVisibility(I)V

    goto :goto_2b2

    :cond_23a
    const/4 v0, 0x5

    invoke-static {v8}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_23f
    const/4 v0, 0x5

    invoke-static {v7}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_244
    const/4 v0, 0x5

    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_249
    const/4 v0, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_24e
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_253
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_258
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_25d
    const-string/jumbo p0, "sshserver"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_265
    const/4 v0, 0x5

    invoke-static {v3}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_26a
    if-eqz p1, :cond_2d1

    const/4 v0, -0x5

    invoke-virtual {p1, v10}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0x1b5

    iget-object p1, p0, Lkc0;->N:Landroid/widget/CheckBox;

    nop

    if-eqz p1, :cond_2cc

    const/4 v0, -0x5

    invoke-virtual {p1, v10}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0xe6

    iget-object p1, p0, Lkc0;->L:Landroid/widget/CheckBox;

    nop

    if-eqz p1, :cond_2c7

    const/4 v0, -0x5

    invoke-virtual {p1, v10}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0x268

    iget-object p1, p0, Lkc0;->x:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz p1, :cond_2c2

    const/4 v0, -0x5

    invoke-virtual {p1, v10}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0xce

    iget-object p1, p0, Lkc0;->R:Landroid/widget/TextView;

    nop

    if-eqz p1, :cond_2bd

    const/4 v0, -0x5

    invoke-virtual {p1, v10}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0xfc

    iget-object p1, p0, Lkc0;->O:Landroid/widget/TextView;

    nop

    if-eqz p1, :cond_2b8

    const/4 v0, -0x5

    invoke-virtual {p1, v10}, Landroid/view/View;->setVisibility(I)V

    const/16 v0, 0xda

    iget-object p0, p0, Lkc0;->P:Lcom/google/android/material/card/MaterialCardView;

    nop

    if-eqz p0, :cond_2b3

    const/4 v0, -0x5

    invoke-virtual {p0, v10}, Landroid/view/View;->setVisibility(I)V

    :goto_2b2
    return-void

    :cond_2b3
    const/4 v0, 0x5

    invoke-static {v8}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_2b8
    const/4 v0, 0x5

    invoke-static {v7}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_2bd
    const/4 v0, 0x5

    invoke-static {v6}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_2c2
    const/4 v0, 0x5

    invoke-static {v5}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_2c7
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_2cc
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :cond_2d1
    const/4 v0, 0x5

    invoke-static {v3}, Lgt0;->F0(Ljava/lang/String;)V

    throw v11

    :pswitch_data_2d6
    .packed-switch 0x0
        :pswitch_182  #00000000
        :pswitch_c9  #00000001
        :pswitch_a6  #00000002
    .end packed-switch
.end method
