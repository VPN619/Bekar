.class public final Ld12;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/view/View$OnLongClickListener;


# instance fields
.field public final a:Lg12;

.field public final b:Ljava/lang/String;

.field public final c:I


# direct methods
.method public constructor <init>(Lg12;Ljava/lang/String;I)V
    .registers 6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0xd94

    iput-object p1, p0, Ld12;->a:Lg12;

    const/16 v0, 0xabc

    iput-object p2, p0, Ld12;->b:Ljava/lang/String;

    const/16 v0, 0xe4e

    iput p3, p0, Ld12;->c:I

    return-void
.end method


# virtual methods
.method public final onLongClick(Landroid/view/View;)Z
    .registers 8

    .prologue
    const/16 v0, 0x1071

    iget-object p1, p0, Ld12;->a:Lg12;

    nop

    const/16 v0, 0x1b1

    iget-boolean v2, p1, Lg12;->r:Z

    nop

    const/4 v3, 0x1

    if-eqz v2, :cond_4d

    const/16 v0, 0x101

    sget-boolean v2, Lmi2;->n:Z

    nop

    if-nez v2, :cond_4d

    const/16 v0, 0x1200

    new-instance p0, Lnn1;

    nop

    const/16 v0, 0x6df

    invoke-direct {p0}, Lnn1;-><init>()V

    const/16 v0, 0x108

    new-instance v2, Landroid/os/Bundle;

    nop

    const/16 v0, 0x198

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    const-string/jumbo v4, "strnew"

    const-string/jumbo v5, ""

    const/16 v0, 0x76

    invoke-virtual {v2, v4, v5}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v0, 0x19a

    invoke-virtual {p0, v2}, Landroidx/fragment/app/Fragment;->setArguments(Landroid/os/Bundle;)V

    const/16 v0, 0x8b

    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->getParentFragmentManager()Landroidx/fragment/app/p;

    move-result-object v2

    const v4, 0x7f130209

    const/16 v0, 0x4c

    invoke-virtual {p1, v4}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0x8c

    invoke-virtual {p0, v2, p1}, Landroidx/fragment/app/g;->show(Landroidx/fragment/app/p;Ljava/lang/String;)V

    return v3

    :cond_4d
    const/16 v0, 0x131

    invoke-virtual {p1}, Lg12;->d()Landroid/content/SharedPreferences;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x7a

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string/jumbo v4, "pserver"

    const/4 v5, 0x0

    const/16 v0, 0x48

    invoke-interface {v2, v4, v5}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x1b1

    iget-boolean v4, p1, Lg12;->r:Z

    nop

    if-eqz v4, :cond_75

    const/16 v0, 0x101

    sget-boolean v4, Lmi2;->n:Z

    nop

    if-eqz v4, :cond_75

    move v5, v3

    :cond_75
    const-string/jumbo v4, "psrvslctd"

    const/16 v0, 0x48

    invoke-interface {v2, v4, v5}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const-string/jumbo v4, "server"

    const/16 v0, 0x68a

    iget v5, p0, Ld12;->c:I

    nop

    const/16 v0, 0x56

    invoke-interface {v2, v4, v5}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x6f

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/16 v0, 0x2b

    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v2

    const/16 v0, 0x5b

    new-instance v4, Landroid/content/Intent;

    nop

    const-string/jumbo v5, "restoreHome"

    const/16 v0, 0x62

    invoke-direct {v4, v5}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x2b

    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v5

    const/16 v0, 0x53

    invoke-virtual {v5}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v5

    const/16 v0, 0x4a

    invoke-virtual {v5}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v5

    const/16 v0, 0x64

    invoke-virtual {v4, v5}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v4

    const/16 v0, 0x63

    invoke-virtual {v2, v4}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    const/16 v0, 0x1ff

    sget v2, Lmi2;->o:I

    nop

    if-eqz v2, :cond_108

    const/16 v0, 0x272

    sget-object v2, Lmi2;->m:Ljava/lang/String;

    nop

    const/16 v0, 0xa8a

    iget-object p0, p0, Ld12;->b:Ljava/lang/String;

    nop

    const/16 v0, 0x84

    invoke-static {v2, p0}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    if-nez p0, :cond_108

    const/16 v0, 0x2b

    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p0

    const/16 v0, 0x5b

    new-instance v2, Landroid/content/Intent;

    nop

    const-string/jumbo v4, "reconnect"

    const/16 v0, 0x62

    invoke-direct {v2, v4}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x2b

    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v4

    const/16 v0, 0x53

    invoke-virtual {v4}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v4

    const/16 v0, 0x4a

    invoke-virtual {v4}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    const/16 v0, 0x64

    invoke-virtual {v2, v4}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v2

    const/16 v0, 0x63

    invoke-virtual {p0, v2}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    :cond_108
    const/16 v0, 0x195

    sget-boolean p0, Lmi2;->d:Z

    nop

    if-eqz p0, :cond_12d

    const/16 v0, 0x140

    sget-boolean p0, Lg4;->a:Z

    nop

    const/16 v0, 0xfb

    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object p0

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x131

    invoke-virtual {p1}, Lg12;->d()Landroid/content/SharedPreferences;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x394

    invoke-static {v2, p0}, Lg4;->n(Landroid/content/SharedPreferences;Landroidx/fragment/app/l;)V

    :cond_12d
    const/16 v0, 0x24a

    invoke-virtual {p1}, Lkk;->dismiss()V

    return v3
.end method
