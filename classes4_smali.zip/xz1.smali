.class public final synthetic Lxz1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/view/View$OnLongClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lvb;


# direct methods
.method public synthetic constructor <init>(Lvb;I)V
    .registers 5

    iput p2, p0, Lxz1;->a:I

    iput-object p1, p0, Lxz1;->b:Lvb;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onLongClick(Landroid/view/View;)Z
    .registers 14

    .prologue
    const/16 v6, 0x9bd

    iget p1, p0, Lxz1;->a:I

    nop

    const/4 v8, 0x0

    const/4 v9, 0x1

    const/16 v6, 0xfd5

    iget-object p0, p0, Lxz1;->b:Lvb;

    nop

    packed-switch p1, :pswitch_data_8a

    check-cast p0, Lg12;

    const/16 v6, 0xcfe

    invoke-virtual {p0, v9}, Lg12;->e(Z)V

    const/16 v6, 0x140

    sget-boolean p1, Lg4;->a:Z

    nop

    const/16 v6, 0xfb

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object p1

    const/4 v6, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x131

    invoke-virtual {p0}, Lg12;->d()Landroid/content/SharedPreferences;

    move-result-object v10

    const/4 v6, -0x6

    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x394

    invoke-static {v10, p1}, Lg4;->n(Landroid/content/SharedPreferences;Landroidx/fragment/app/l;)V

    const/16 v6, 0x325

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getViewLifecycleOwner()Lh11;

    move-result-object p1

    const/4 v6, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x341

    invoke-static {p1}, Lns2;->m(Lh11;)Lc11;

    move-result-object p1

    const/16 v6, 0x24d

    new-instance v10, Lf12;

    nop

    const/4 v11, 0x2

    const/16 v6, 0x1ad

    invoke-direct {v10, p0, v8, v11}, Lf12;-><init>(Lg12;Lvx;I)V

    const/4 p0, 0x3

    const/16 v6, 0xb3

    move v0, v6

    move-object v1, p1

    move-object v2, v8

    move-object v3, v8

    move-object v4, v10

    move v5, p0

    invoke-static/range {v1 .. v5}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    return v9

    :pswitch_5c  #0x1
    check-cast p0, Lyz1;

    const/16 v6, 0x1f1

    iget-object p1, p0, Lyz1;->C:Ljava/lang/String;

    nop

    if-eqz p1, :cond_6b

    const/16 v6, 0x374

    invoke-virtual {p0, p1}, Lyz1;->c(Ljava/lang/String;)V

    return v9

    :cond_6b
    const-string/jumbo p0, "selectedServerHost"

    const/4 v6, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v8

    :pswitch_73  #0x0
    check-cast p0, Lyz1;

    const/16 v6, 0x4cb

    iget-object p1, p0, Lyz1;->v:Ljava/lang/String;

    nop

    if-eqz p1, :cond_82

    const/16 v6, 0x374

    invoke-virtual {p0, p1}, Lyz1;->c(Ljava/lang/String;)V

    return v9

    :cond_82
    const-string/jumbo p0, "connectedServerHost"

    const/4 v6, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v8

    :pswitch_data_8a
    .packed-switch 0x0
        :pswitch_73  #00000000
        :pswitch_5c  #00000001
    .end packed-switch
.end method
