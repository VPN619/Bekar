.class public final synthetic Lic0;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic a:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 4

    iput p1, p0, Lic0;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 5

    .prologue
    const/16 v0, 0x7e0

    iget p0, p0, Lic0;->a:I

    nop

    packed-switch p0, :pswitch_data_26

    const/16 v0, 0x179

    invoke-interface {p1}, Landroid/content/DialogInterface;->dismiss()V

    return-void

    :pswitch_e  #0x2
    const/16 v0, 0x179

    invoke-interface {p1}, Landroid/content/DialogInterface;->dismiss()V

    return-void

    :pswitch_14  #0x1
    const/16 v0, 0x44d

    sget p0, Lcom/tlsvpn/tlstunnel/MainActivity;->m:I

    nop

    const/16 v0, 0x179

    invoke-interface {p1}, Landroid/content/DialogInterface;->dismiss()V

    return-void

    :pswitch_1f  #0x0
    const/16 v0, 0x179

    invoke-interface {p1}, Landroid/content/DialogInterface;->dismiss()V

    return-void

    nop

    :pswitch_data_26
    .packed-switch 0x0
        :pswitch_1f  #00000000
        :pswitch_14  #00000001
        :pswitch_e  #00000002
    .end packed-switch
.end method
