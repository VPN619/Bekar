.class public final Lcn1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/text/TextWatcher;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ldn1;


# direct methods
.method public synthetic constructor <init>(Ldn1;I)V
    .registers 5

    iput p2, p0, Lcn1;->a:I

    iput-object p1, p0, Lcn1;->b:Ldn1;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final a(IIILjava/lang/CharSequence;)V
    .registers 7

    return-void
.end method

.method private final b(IIILjava/lang/CharSequence;)V
    .registers 7

    return-void
.end method

.method private final c(IIILjava/lang/CharSequence;)V
    .registers 7

    return-void
.end method

.method private final d(IIILjava/lang/CharSequence;)V
    .registers 7

    return-void
.end method

.method private final e(IIILjava/lang/CharSequence;)V
    .registers 7

    return-void
.end method

.method private final f(IIILjava/lang/CharSequence;)V
    .registers 7

    return-void
.end method

.method private final g(IIILjava/lang/CharSequence;)V
    .registers 7

    return-void
.end method

.method private final h(IIILjava/lang/CharSequence;)V
    .registers 7

    return-void
.end method


# virtual methods
.method public final afterTextChanged(Landroid/text/Editable;)V
    .registers 7

    .prologue
    const/16 v0, 0x812

    iget p1, p0, Lcn1;->a:I

    nop

    const/4 v2, 0x0

    const/16 v0, 0x10bc

    iget-object p0, p0, Lcn1;->b:Ldn1;

    nop

    const/4 v3, 0x0

    packed-switch p1, :pswitch_data_a8

    const/16 v0, 0x2f1

    iget-object p1, p0, Ldn1;->E:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    const-string/jumbo v4, "sshpass_l"

    if-eqz p1, :cond_30

    const/16 v0, 0x6e

    invoke-virtual {p1, v3}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    const/16 v0, 0x2f1

    iget-object p0, p0, Ldn1;->E:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz p0, :cond_2b

    const/16 v0, 0xdd

    invoke-virtual {p0, v2}, Lcom/google/android/material/textfield/TextInputLayout;->setErrorEnabled(Z)V

    return-void

    :cond_2b
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_30
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :pswitch_35  #0x2
    const/16 v0, 0x4ce

    iget-object p1, p0, Ldn1;->C:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    const-string/jumbo v4, "sshuser_l"

    if-eqz p1, :cond_56

    const/16 v0, 0x6e

    invoke-virtual {p1, v3}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    const/16 v0, 0x4ce

    iget-object p0, p0, Ldn1;->C:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz p0, :cond_51

    const/16 v0, 0xdd

    invoke-virtual {p0, v2}, Lcom/google/android/material/textfield/TextInputLayout;->setErrorEnabled(Z)V

    return-void

    :cond_51
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_56
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :pswitch_5b  #0x1
    const/16 v0, 0x4ed

    iget-object p1, p0, Ldn1;->z:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    const-string/jumbo v4, "sshport_l"

    if-eqz p1, :cond_7c

    const/16 v0, 0x6e

    invoke-virtual {p1, v3}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    const/16 v0, 0x4ed

    iget-object p0, p0, Ldn1;->z:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz p0, :cond_77

    const/16 v0, 0xdd

    invoke-virtual {p0, v2}, Lcom/google/android/material/textfield/TextInputLayout;->setErrorEnabled(Z)V

    return-void

    :cond_77
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_7c
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :pswitch_81  #0x0
    const/16 v0, 0x500

    iget-object p1, p0, Ldn1;->x:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    const-string/jumbo v4, "sshhost_l"

    if-eqz p1, :cond_a2

    const/16 v0, 0x6e

    invoke-virtual {p1, v3}, Lcom/google/android/material/textfield/TextInputLayout;->setError(Ljava/lang/CharSequence;)V

    const/16 v0, 0x500

    iget-object p0, p0, Ldn1;->x:Lcom/google/android/material/textfield/TextInputLayout;

    nop

    if-eqz p0, :cond_9d

    const/16 v0, 0xdd

    invoke-virtual {p0, v2}, Lcom/google/android/material/textfield/TextInputLayout;->setErrorEnabled(Z)V

    return-void

    :cond_9d
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_a2
    const/4 v0, 0x5

    invoke-static {v4}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    nop

    :pswitch_data_a8
    .packed-switch 0x0
        :pswitch_81  #00000000
        :pswitch_5b  #00000001
        :pswitch_35  #00000002
    .end packed-switch
.end method

.method public final beforeTextChanged(Ljava/lang/CharSequence;III)V
    .registers 7

    const/4 v1, 0x0

    const/16 v0, 0x812

    iget p0, p0, Lcn1;->a:I

    nop

    return-void
.end method

.method public final onTextChanged(Ljava/lang/CharSequence;III)V
    .registers 7

    const/4 v1, 0x0

    const/16 v0, 0x812

    iget p0, p0, Lcn1;->a:I

    nop

    return-void
.end method
