.class public final synthetic Lfx;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:I

.field public final synthetic c:Ljava/lang/Object;

.field public final synthetic d:Ljava/lang/Object;

.field public final synthetic e:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Lgx;[Ljava/lang/String;Ljava/lang/String;I)V
    .registers 8

    const/4 v2, 0x0

    iput v2, p0, Lfx;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x8bf

    iput-object p1, p0, Lfx;->c:Ljava/lang/Object;

    const/16 v0, 0x92f

    iput-object p2, p0, Lfx;->d:Ljava/lang/Object;

    const/16 v0, 0xeda

    iput-object p3, p0, Lfx;->e:Ljava/lang/Object;

    const/16 v0, 0x9b6

    iput p4, p0, Lfx;->b:I

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;ILjava/lang/Object;I)V
    .registers 8

    iput p5, p0, Lfx;->a:I

    iput-object p1, p0, Lfx;->c:Ljava/lang/Object;

    iput-object p2, p0, Lfx;->d:Ljava/lang/Object;

    iput p3, p0, Lfx;->b:I

    iput-object p4, p0, Lfx;->e:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final run()V
    .registers 36

    .prologue
    move-object/from16 v17, p0

    const/16 v15, 0x688

    move-object/from16 v0, v17

    iget v15, v0, Lfx;->a:I

    move/16 v18, v15

    const/16 v19, 0x1

    const/16 v15, 0xad1

    move-object/from16 v0, v17

    iget-object v15, v0, Lfx;->e:Ljava/lang/Object;

    move-object/16 v20, v15

    const/16 v15, 0xb8b

    move-object/from16 v0, v17

    iget v15, v0, Lfx;->b:I

    move/16 v21, v15

    const/16 v15, 0xb34

    move-object/from16 v0, v17

    iget-object v15, v0, Lfx;->d:Ljava/lang/Object;

    move-object/16 v22, v15

    const/16 v15, 0x8c5

    move-object/from16 v0, v17

    iget-object v15, v0, Lfx;->c:Ljava/lang/Object;

    move-object/16 v17, v15

    packed-switch v18, :pswitch_data_30e

    check-cast v17, Lvh2;

    check-cast v22, Lyg;

    check-cast v20, Ljava/lang/Runnable;

    const/16 v15, 0x641

    move-object/from16 v0, v17

    iget-object v15, v0, Lvh2;->d:Ljava/lang/Object;

    move-object/16 v18, v15

    check-cast v18, Lix1;

    :try_start_45
    const/16 v15, 0xdc2

    move-object/from16 v0, v17

    iget-object v15, v0, Lvh2;->c:Ljava/lang/Object;

    move-object/16 v23, v15

    check-cast v23, Lix1;

    const/16 v15, 0x105f

    move-object/from16 v0, v23

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/16 v15, 0x7fc

    new-instance v24, Lsh2;

    nop

    const/16 v15, 0xd61

    move-object/from16 v0, v24

    move-object/from16 v1, v23

    move/from16 v2, v19

    invoke-direct {v0, v1, v2}, Lsh2;-><init>(Lix1;I)V

    const/16 v15, 0x2eb

    move-object/from16 v0, v18

    move-object/from16 v1, v24

    invoke-virtual {v0, v1}, Lix1;->H(Lv82;)Ljava/lang/Object;

    const/16 v15, 0x975

    move-object/from16 v0, v17

    iget-object v15, v0, Lvh2;->a:Ljava/lang/Object;

    move-object/16 v23, v15

    check-cast v23, Landroid/content/Context;

    const-string/jumbo v24, "connectivity"

    const/16 v15, 0x31d

    move-object/from16 v0, v23

    move-object/from16 v1, v24

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v23

    check-cast v23, Landroid/net/ConnectivityManager;

    const/16 v15, 0xc6d

    move-object/from16 v0, v23

    invoke-virtual {v0}, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;

    move-result-object v23

    if-eqz v23, :cond_ac

    const/16 v15, 0xb72

    move-object/from16 v0, v23

    invoke-virtual {v0}, Landroid/net/NetworkInfo;->isConnected()Z

    move-result v23

    if-eqz v23, :cond_ac

    const/16 v15, 0xb48

    move-object/from16 v0, v17

    move-object/from16 v1, v22

    move/from16 v2, v21

    invoke-virtual {v0, v1, v2}, Lvh2;->b(Lyg;I)V

    goto :goto_c7

    :catchall_aa
    move-exception v17

    goto :goto_ed

    :cond_ac
    const/16 v15, 0xa81

    new-instance v23, Lth2;

    nop

    const/16 v15, 0x11d1

    move-object/from16 v0, v23

    move-object/from16 v1, v17

    move-object/from16 v2, v22

    move/from16 v3, v21

    invoke-direct {v0, v1, v2, v3}, Lth2;-><init>(Lvh2;Lyg;I)V

    const/16 v15, 0x2eb

    move-object/from16 v0, v18

    move-object/from16 v1, v23

    invoke-virtual {v0, v1}, Lix1;->H(Lv82;)Ljava/lang/Object;
    :try_end_c7
    .catch Lu82; {:try_start_45 .. :try_end_c7} :catch_cf
    .catchall {:try_start_45 .. :try_end_c7} :catchall_aa

    :goto_c7
    const/16 v15, 0x2d0

    move-object/from16 v0, v20

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    goto :goto_ec

    :catch_cf
    :try_start_cf
    const/16 v15, 0x557

    move-object/from16 v0, v17

    iget-object v15, v0, Lvh2;->f:Ljava/lang/Object;

    move-object/16 v17, v15

    check-cast v17, Ltd;

    add-int v21, v21, v19

    const/16 v18, 0x0

    const/16 v15, 0xe8a

    move-object/from16 v0, v17

    move-object/from16 v1, v22

    move/from16 v2, v21

    move/from16 v3, v18

    invoke-virtual {v0, v1, v2, v3}, Ltd;->C(Lyg;IZ)V
    :try_end_eb
    .catchall {:try_start_cf .. :try_end_eb} :catchall_aa

    goto :goto_c7

    :goto_ec
    return-void

    :goto_ed
    const/16 v15, 0x2d0

    move-object/from16 v0, v20

    invoke-interface {v0}, Ljava/lang/Runnable;->run()V

    throw v17

    :pswitch_f5  #0x1
    check-cast v17, Lcom/tlsvpn/tlstunnel/ui/Home;

    check-cast v22, Landroid/widget/FrameLayout;

    check-cast v20, Lx4;

    const/16 v15, 0x195

    sget-boolean v18, Lmi2;->d:Z

    nop

    if-eqz v18, :cond_226

    const/16 v15, 0x101

    sget-boolean v18, Lmi2;->n:Z

    nop

    if-nez v18, :cond_226

    const/16 v15, 0x8f7

    sget-boolean v18, Lg4;->b:Z

    nop

    if-eqz v18, :cond_226

    const/16 v15, 0xd9

    move-object/from16 v0, v17

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->isAdded()Z

    move-result v17

    if-nez v17, :cond_11c

    goto/16 :goto_226

    :cond_11c
    const/16 v15, 0x1fd

    move-object/from16 v0, v22

    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v17

    const/4 v15, -0x3

    new-instance v18, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v22, "Container Alterado, largura: old("

    const/16 v15, 0x97

    move-object/from16 v0, v18

    move-object/from16 v1, v22

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v15, 0x33

    move-object/from16 v0, v18

    move/from16 v1, v21

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v22, ") new("

    const/4 v15, 0x0

    move-object/from16 v0, v18

    move-object/from16 v1, v22

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v15, 0x33

    move-object/from16 v0, v18

    move/from16 v1, v17

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 v22, 0x29

    const/16 v15, 0x1b

    move-object/from16 v0, v18

    move/from16 v1, v22

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v15, -0x2

    move-object/from16 v0, v18

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v18

    const-string/jumbo v22, "Ads-Show"

    nop

    move/from16 v0, v21

    move/from16 v1, v17

    if-le v0, v1, :cond_226

    const/16 v15, 0xd21

    sget-boolean v17, Lg4;->p:Z

    nop

    if-nez v17, :cond_226

    const-string/jumbo v17, "Ads-Load"

    const-string/jumbo v18, "Recarregando Banner com novas dimensões..."

    nop

    const/16 v15, 0x8ba

    move/from16 v0, v19

    sput-boolean v0, Lg4;->p:Z

    const/16 v15, 0x1013

    sget-object v22, Lg4;->f:Ljava/lang/String;

    nop

    const/16 v15, 0xb6b

    sget-object v31, Lg4;->o:Ls4;

    nop

    const/4 v15, -0x6

    move-object/from16 v0, v22

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v15, -0x6

    move-object/from16 v0, v31

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v15, 0x11b1

    move-object/from16 v0, v31

    invoke-static {v0}, Luz;->G(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v32

    const/16 v15, 0x48a

    new-instance v23, Ljava/util/LinkedHashSet;

    nop

    const/16 v15, 0x3f9

    move-object/from16 v0, v23

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    const/16 v15, 0x160

    new-instance v25, Ljava/util/LinkedHashMap;

    nop

    const/16 v15, 0x158

    move-object/from16 v0, v25

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    const/16 v15, 0x108

    new-instance v26, Landroid/os/Bundle;

    nop

    const/16 v15, 0x198

    move-object/from16 v0, v26

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/16 v15, 0x167

    new-instance v27, Ljava/util/HashSet;

    nop

    const/16 v15, 0x13f

    move-object/from16 v0, v27

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    const/16 v15, 0x167

    new-instance v28, Ljava/util/HashSet;

    nop

    const/16 v15, 0x13f

    move-object/from16 v0, v28

    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    const/16 v15, 0x160

    new-instance v29, Ljava/util/LinkedHashMap;

    nop

    const/16 v15, 0x158

    move-object/from16 v0, v29

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    const/16 v15, 0xaed

    new-instance v21, Lph;

    nop

    const/16 v24, 0x0

    const/16 v30, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v15, 0x93c

    move v0, v15

    move-object/from16 v1, v21

    move-object/from16 v2, v22

    move-object/from16 v3, v23

    move-object/from16 v4, v24

    move-object/from16 v5, v25

    move-object/from16 v6, v26

    move-object/from16 v7, v27

    move-object/from16 v8, v28

    move-object/from16 v9, v29

    move-object/from16 v10, v30

    move-object/from16 v11, v31

    move-object/from16 v12, v32

    move-object/from16 v13, v33

    move/from16 v14, v34

    invoke-direct/range {v1 .. v14}, Lph;-><init>(Ljava/lang/String;Ljava/util/LinkedHashSet;Ljava/lang/String;Ljava/util/LinkedHashMap;Landroid/os/Bundle;Ljava/util/HashSet;Ljava/util/HashSet;Ljava/util/LinkedHashMap;Ljava/lang/String;Ls4;Ljava/util/List;Lpj2;Z)V

    const/16 v15, 0xbe1

    sget-object v17, Lg4;->r:Lvp1;

    nop

    const/16 v15, 0xaa9

    move-object/from16 v0, v20

    move-object/from16 v1, v21

    move-object/from16 v2, v17

    invoke-virtual {v0, v1, v2}, Lx4;->d(Lph;Lk4;)V

    :cond_226
    :goto_226
    return-void

    :pswitch_227  #0x0
    check-cast v17, Lgx;

    check-cast v22, [Ljava/lang/String;

    check-cast v20, Ljava/lang/String;

    const/16 v15, 0x1065

    move-object/from16 v0, v17

    iget-object v15, v0, Lgx;->a:Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;

    move-object/16 v17, v15

    const/16 v15, 0x1ed

    move-object/from16 v0, v20

    move-object/from16 v1, v22

    invoke-static {v0, v1}, Laf;->l0(Ljava/lang/Object;[Ljava/lang/Object;)I

    move-result v18

    const/4 v15, -0x6

    move-object/from16 v0, v20

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v15, -0x3

    new-instance v19, Ljava/lang/StringBuilder;

    nop

    const/16 v15, 0x97

    move-object/from16 v0, v19

    move-object/from16 v1, v20

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v22, 0x3a

    const/16 v15, 0x1b

    move-object/from16 v0, v19

    move/from16 v1, v22

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v15, 0x33

    move-object/from16 v0, v19

    move/from16 v1, v18

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/16 v15, 0x1b

    move-object/from16 v0, v19

    move/from16 v1, v22

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v15, -0x2

    move-object/from16 v0, v19

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v18

    const/16 v15, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v22

    :try_start_27d
    const/16 v15, 0x104b

    move-object/from16 v0, v20

    invoke-static {v0}, Ljava/net/InetAddress;->getByName(Ljava/lang/String;)Ljava/net/InetAddress;

    move-result-object v19

    const/16 v20, 0x9c4

    const/16 v15, 0xb5a

    move-object/from16 v0, v19

    move/from16 v1, v20

    invoke-virtual {v0, v1}, Ljava/net/InetAddress;->isReachable(I)Z

    move-result v19

    if-eqz v19, :cond_30c

    const/16 v15, 0x5b

    new-instance v19, Landroid/content/Intent;

    nop

    const-string/jumbo v20, "SERVERRPL"

    const/16 v15, 0x62

    move-object/from16 v0, v19

    move-object/from16 v1, v20

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string/jumbo v20, "RPL"

    const/16 v15, 0x4b

    move-object/from16 v0, v19

    move-object/from16 v1, v20

    move-object/from16 v2, v18

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v18

    const-string/jumbo v20, "cId"

    const/16 v15, 0x29

    move-object/from16 v0, v18

    move-object/from16 v1, v20

    move/from16 v2, v21

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v18

    const-string/jumbo v20, "cTp"

    const/16 v21, 0x3

    const/16 v15, 0x29

    move-object/from16 v0, v18

    move-object/from16 v1, v20

    move/from16 v2, v21

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v18

    const-string/jumbo v20, "rtime"

    const/16 v15, 0x4e

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v24

    sub-long v24, v24, v22

    const/16 v15, 0xba

    move-object/from16 v0, v18

    move-object/from16 v1, v20

    move-wide/from16 v2, v24

    invoke-virtual {v0, v1, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/16 v15, 0x53

    move-object/from16 v0, v17

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v18

    const/16 v15, 0x4a

    move-object/from16 v0, v18

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v18

    const/16 v15, 0x64

    move-object/from16 v0, v19

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v18

    const/16 v15, 0x63

    move-object/from16 v0, v17

    move-object/from16 v1, v18

    invoke-virtual {v0, v1}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V
    :try_end_30c
    .catch Ljava/lang/Exception; {:try_start_27d .. :try_end_30c} :catch_30c

    :catch_30c
    :cond_30c
    return-void

    nop

    :pswitch_data_30e
    .packed-switch 0x0
        :pswitch_227  #00000000
        :pswitch_f5  #00000001
    .end packed-switch
.end method
