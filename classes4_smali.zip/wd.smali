.class public final Lwd;
.super Lpr1;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final u:Landroid/widget/ImageView;

.field public final v:Landroid/widget/TextView;

.field public final w:Landroid/widget/TextView;

.field public final x:Landroid/widget/CheckBox;


# direct methods
.method public constructor <init>(Landroid/view/View;)V
    .registers 5

    invoke-direct {p0, p1}, Lpr1;-><init>(Landroid/view/View;)V

    const v2, 0x7f09013c

    const/16 v0, 0x11

    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/ImageView;

    const/16 v0, 0xa0c

    iput-object v2, p0, Lwd;->u:Landroid/widget/ImageView;

    const v2, 0x7f090277

    const/16 v0, 0x11

    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    const/16 v0, 0xb5c

    iput-object v2, p0, Lwd;->v:Landroid/widget/TextView;

    const v2, 0x7f0902ae

    const/16 v0, 0x11

    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    check-cast v2, Landroid/widget/TextView;

    const/16 v0, 0x591

    iput-object v2, p0, Lwd;->w:Landroid/widget/TextView;

    const v2, 0x7f0900a3

    const/16 v0, 0x11

    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    check-cast p1, Landroid/widget/CheckBox;

    const/16 v0, 0xb05

    iput-object p1, p0, Lwd;->x:Landroid/widget/CheckBox;

    return-void
.end method
