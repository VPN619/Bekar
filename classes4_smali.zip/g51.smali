.class public final Lg51;
.super Lwx;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public t:Ljava/util/Iterator;

.field public u:I

.field public synthetic v:Ljava/lang/Object;

.field public final synthetic w:Lcom/tlsvpn/tlstunnel/MainActivity;

.field public x:I


# direct methods
.method public constructor <init>(Lcom/tlsvpn/tlstunnel/MainActivity;Lwx;)V
    .registers 5

    iput-object p1, p0, Lg51;->w:Lcom/tlsvpn/tlstunnel/MainActivity;

    invoke-direct {p0, p2}, Lwx;-><init>(Lvx;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    const/16 v0, 0xe35

    iput-object p1, p0, Lg51;->v:Ljava/lang/Object;

    const/16 v0, 0x30f

    iget p1, p0, Lg51;->x:I

    nop

    const/high16 v2, -0x80000000

    or-int/2addr p1, v2

    const/16 v0, 0x3fe

    iput p1, p0, Lg51;->x:I

    const/16 v0, 0x44d

    sget p1, Lcom/tlsvpn/tlstunnel/MainActivity;->m:I

    nop

    const/16 v0, 0x75c

    iget-object p1, p0, Lg51;->w:Lcom/tlsvpn/tlstunnel/MainActivity;

    nop

    const/16 v0, 0x872

    invoke-virtual {p1, p0}, Lcom/tlsvpn/tlstunnel/MainActivity;->i(Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
