.class public final Lgt1;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public final synthetic t:I

.field public final synthetic u:Llt1;


# direct methods
.method public synthetic constructor <init>(Llt1;Lvx;I)V
    .registers 6

    iput p3, p0, Lgt1;->t:I

    iput-object p1, p0, Lgt1;->u:Llt1;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 6

    .prologue
    const/16 v0, 0xaca

    iget p2, p0, Lgt1;->t:I

    nop

    packed-switch p2, :pswitch_data_54

    const/16 v0, 0x150

    new-instance p2, Lgt1;

    nop

    const/16 v0, 0x13c

    iget-object p0, p0, Lgt1;->u:Llt1;

    nop

    const/4 v2, 0x3

    const/16 v0, 0x138

    invoke-direct {p2, p0, p1, v2}, Lgt1;-><init>(Llt1;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_1b  #0x2
    const/16 v0, 0x150

    new-instance p2, Lgt1;

    nop

    const/16 v0, 0x13c

    iget-object p0, p0, Lgt1;->u:Llt1;

    nop

    const/4 v2, 0x2

    const/16 v0, 0x138

    invoke-direct {p2, p0, p1, v2}, Lgt1;-><init>(Llt1;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_2e  #0x1
    const/16 v0, 0x150

    new-instance p2, Lgt1;

    nop

    const/16 v0, 0x13c

    iget-object p0, p0, Lgt1;->u:Llt1;

    nop

    const/4 v2, 0x1

    const/16 v0, 0x138

    invoke-direct {p2, p0, p1, v2}, Lgt1;-><init>(Llt1;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_41  #0x0
    const/16 v0, 0x150

    new-instance p2, Lgt1;

    nop

    const/16 v0, 0x13c

    iget-object p0, p0, Lgt1;->u:Llt1;

    nop

    const/4 v2, 0x0

    const/16 v0, 0x138

    invoke-direct {p2, p0, p1, v2}, Lgt1;-><init>(Llt1;Lvx;I)V

    check-cast p2, Lvx;

    return-object p2

    :pswitch_data_54
    .packed-switch 0x0
        :pswitch_41  #00000000
        :pswitch_2e  #00000001
        :pswitch_1b  #00000002
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7

    .prologue
    const/16 v0, 0xaca

    iget v2, p0, Lgt1;->t:I

    nop

    const/16 v0, 0x21

    sget-object v3, Lrg2;->a:Lrg2;

    nop

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    packed-switch v2, :pswitch_data_52

    const/16 v0, 0x117

    invoke-virtual {p0, p2, p1}, Lgt1;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lgt1;

    const/16 v0, 0x19c

    invoke-virtual {p0, v3}, Lgt1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v3, Ljava/lang/Object;

    return-object v3

    :pswitch_21  #0x2
    const/16 v0, 0x117

    invoke-virtual {p0, p2, p1}, Lgt1;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lgt1;

    const/16 v0, 0x19c

    invoke-virtual {p0, v3}, Lgt1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v3, Ljava/lang/Object;

    return-object v3

    :pswitch_31  #0x1
    const/16 v0, 0x117

    invoke-virtual {p0, p2, p1}, Lgt1;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lgt1;

    const/16 v0, 0x19c

    invoke-virtual {p0, v3}, Lgt1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v3, Ljava/lang/Object;

    return-object v3

    :pswitch_41  #0x0
    const/16 v0, 0x117

    invoke-virtual {p0, p2, p1}, Lgt1;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lgt1;

    const/16 v0, 0x19c

    invoke-virtual {p0, v3}, Lgt1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v3, Ljava/lang/Object;

    return-object v3

    nop

    :pswitch_data_52
    .packed-switch 0x0
        :pswitch_41  #00000000
        :pswitch_31  #00000001
        :pswitch_21  #00000002
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7

    .prologue
    const/16 v0, 0xaca

    iget v2, p0, Lgt1;->t:I

    nop

    const/4 v3, 0x0

    const/16 v0, 0x21

    sget-object v4, Lrg2;->a:Lrg2;

    nop

    const/16 v0, 0x13c

    iget-object p0, p0, Lgt1;->u:Llt1;

    nop

    packed-switch v2, :pswitch_data_6c

    const/4 v0, 0x6

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v0, 0x4db

    iget-object p0, p0, Llt1;->q:Ljava/net/Socket;

    nop

    if-eqz p0, :cond_26

    const/16 v0, 0x1a5

    invoke-virtual {p0}, Ljava/net/Socket;->close()V

    check-cast v4, Ljava/lang/Object;

    return-object v4

    :cond_26
    const-string/jumbo p0, "lSocketConnection"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :pswitch_2e  #0x2
    const/4 v0, 0x6

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v0, 0x889

    iget-object p0, p0, Llt1;->j:Ljava/net/Socket;

    nop

    const/16 v0, 0x1a5

    invoke-virtual {p0}, Ljava/net/Socket;->close()V

    check-cast v4, Ljava/lang/Object;

    return-object v4

    :pswitch_3f  #0x1
    const/4 v0, 0x6

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v0, 0xe52

    iget-object p0, p0, Llt1;->i:Ljava/net/Socket;

    nop

    const/16 v0, 0x1a5

    invoke-virtual {p0}, Ljava/net/Socket;->close()V

    check-cast v4, Ljava/lang/Object;

    return-object v4

    :pswitch_50  #0x0
    const/4 v0, 0x6

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v0, 0x118a

    iget-object p0, p0, Llt1;->p:Ljava/net/ServerSocket;

    nop

    if-eqz p0, :cond_63

    const/16 v0, 0x110e

    invoke-virtual {p0}, Ljava/net/ServerSocket;->close()V

    check-cast v4, Ljava/lang/Object;

    return-object v4

    :cond_63
    const-string/jumbo p0, "lSocketServer"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    nop

    :pswitch_data_6c
    .packed-switch 0x0
        :pswitch_50  #00000000
        :pswitch_3f  #00000001
        :pswitch_2e  #00000002
    .end packed-switch
.end method
