.class public final Lc12;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public a:Lg12;

.field public b:I


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 7

    .prologue
    const/16 v0, 0xdbc

    iget-object p1, p0, Lc12;->a:Lg12;

    nop

    const/16 v0, 0x1b1

    iget-boolean v2, p1, Lg12;->r:Z

    nop

    if-eqz v2, :cond_4c

    const/16 v0, 0x101

    sget-boolean v2, Lmi2;->n:Z

    nop

    if-nez v2, :cond_4c

    const/16 v0, 0x1200

    new-instance p0, Lnn1;

    nop

    const/16 v0, 0x6df

    invoke-direct {p0}, Lnn1;-><init>()V

    const/16 v0, 0x108

    new-instance v2, Landroid/os/Bundle;

    nop

    const/16 v0, 0x198

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    const-string/jumbo v3, "strnew"

    const-string/jumbo v4, ""

    const/16 v0, 0x76

    invoke-virtual {v2, v3, v4}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v0, 0x19a

    invoke-virtual {p0, v2}, Landroidx/fragment/app/Fragment;->setArguments(Landroid/os/Bundle;)V

    const/16 v0, 0x8b

    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->getParentFragmentManager()Landroidx/fragment/app/p;

    move-result-object v2

    const v3, 0x7f130209

    const/16 v0, 0x4c

    invoke-virtual {p1, v3}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object p1

    const/16 v0, 0x8c

    invoke-virtual {p0, v2, p1}, Landroidx/fragment/app/g;->show(Landroidx/fragment/app/p;Ljava/lang/String;)V

    return-void

    :cond_4c
    const/16 v0, 0x131

    invoke-virtual {p1}, Lg12;->d()Landroid/content/SharedPreferences;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x7a

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const-string/jumbo v3, "pserver"

    const/4 v4, 0x0

    const/16 v0, 0x48

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x1b1

    iget-boolean v3, p1, Lg12;->r:Z

    nop

    if-eqz v3, :cond_74

    const/16 v0, 0x101

    sget-boolean v3, Lmi2;->n:Z

    nop

    if-eqz v3, :cond_74

    const/4 v4, 0x1

    :cond_74
    const-string/jumbo v3, "psrvslctd"

    const/16 v0, 0x48

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const-string/jumbo v3, "server"

    const/16 v0, 0x10b2

    iget p0, p0, Lc12;->b:I

    nop

    const/16 v0, 0x56

    invoke-interface {v2, v3, p0}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x6f

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/16 v0, 0x2b

    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p0

    const/16 v0, 0x5b

    new-instance v2, Landroid/content/Intent;

    nop

    const-string/jumbo v3, "restoreHome"

    const/16 v0, 0x62

    invoke-direct {v2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x2b

    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v3

    const/16 v0, 0x53

    invoke-virtual {v3}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    const/16 v0, 0x4a

    invoke-virtual {v3}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    const/16 v0, 0x64

    invoke-virtual {v2, v3}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v2

    const/16 v0, 0x63

    invoke-virtual {p0, v2}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    const/16 v0, 0x195

    sget-boolean p0, Lmi2;->d:Z

    nop

    if-eqz p0, :cond_e3

    const/16 v0, 0x140

    sget-boolean p0, Lg4;->a:Z

    nop

    const/16 v0, 0xfb

    invoke-virtual {p1}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object p0

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x131

    invoke-virtual {p1}, Lg12;->d()Landroid/content/SharedPreferences;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x394

    invoke-static {v2, p0}, Lg4;->n(Landroid/content/SharedPreferences;Landroidx/fragment/app/l;)V

    :cond_e3
    const/16 v0, 0x24a

    invoke-virtual {p1}, Lkk;->dismiss()V

    return-void
.end method
