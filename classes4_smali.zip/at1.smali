.class public final synthetic Lat1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;


# direct methods
.method public synthetic constructor <init>(Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;I)V
    .registers 5

    iput p2, p0, Lat1;->a:I

    iput-object p1, p0, Lat1;->b:Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 16

    .prologue
    const/16 v6, 0xabf

    iget p1, p0, Lat1;->a:I

    nop

    const/4 v8, 0x1

    const/16 v6, 0x10c5

    iget-object p0, p0, Lat1;->b:Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;

    nop

    packed-switch p1, :pswitch_data_114

    const/16 v6, 0x143

    sget p1, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->F:I

    nop

    const/16 v6, 0x22b

    sget-object p1, Lg4;->A:Lxu1;

    nop

    if-eqz p1, :cond_86

    const/16 v6, 0x242

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->h()Landroid/content/SharedPreferences;

    move-result-object p1

    const/4 v6, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0xc72

    new-instance v8, Lsr1;

    nop

    const/16 v6, 0x21a

    invoke-direct {v8}, Ljava/lang/Object;-><init>()V

    const/16 v6, 0x22b

    sget-object v9, Lg4;->A:Lxu1;

    nop

    const/4 v10, 0x0

    if-eqz v9, :cond_53

    const/16 v6, 0x6ee

    new-instance v11, Lf4;

    nop

    const/16 v6, 0x607

    invoke-direct {v11, p0, v8, p1}, Lf4;-><init>(Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;Lsr1;Landroid/content/SharedPreferences;)V

    check-cast v9, Lads_mobile_sdk/lw2;

    const/16 v6, 0x805

    iget-object v12, v9, Lads_mobile_sdk/lw2;->c:Lads_mobile_sdk/ji;

    nop

    const/16 v6, 0x7b8

    sget-object v13, Lads_mobile_sdk/lw2;->e:[Liy0;

    nop

    aget-object v13, v13, v10

    const/16 v6, 0x1037

    invoke-virtual {v12, v9, v13, v11}, Lads_mobile_sdk/ji;->setValue(Ljava/lang/Object;Liy0;Ljava/lang/Object;)V

    :cond_53
    const/16 v6, 0x22b

    sget-object v9, Lg4;->A:Lxu1;

    nop

    if-eqz v9, :cond_95

    const/16 v6, 0x592

    new-instance v11, Lz3;

    nop

    const/16 v6, 0x72a

    move v0, v6

    move-object v1, v11

    move-object v2, v8

    move-object v3, p1

    move-object v4, p0

    move v5, v10

    invoke-direct/range {v1 .. v5}, Lz3;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    check-cast v9, Lads_mobile_sdk/lw2;

    const/16 v6, 0x62a

    iget-object p1, v9, Lads_mobile_sdk/lw2;->b:Lads_mobile_sdk/jh1;

    nop

    const/16 v6, 0xec1

    invoke-virtual {p1}, Lads_mobile_sdk/cc1;->j()Lads_mobile_sdk/ph0;

    move-result-object v8

    monitor-enter v8

    :try_start_78
    const/16 v6, 0xc2e

    iput-object v11, v8, Lads_mobile_sdk/ph0;->n:Lei1;
    :try_end_7c
    .catchall {:try_start_78 .. :try_end_7c} :catchall_83

    monitor-exit v8

    const/16 v6, 0x914

    invoke-virtual {p1, p0}, Lads_mobile_sdk/xo;->a(Landroid/content/Context;)V

    goto :goto_95

    :catchall_83
    move-exception p0

    monitor-exit v8

    throw p0

    :cond_86
    const/16 v6, 0x22e

    new-instance p1, Lzs1;

    nop

    const/16 v6, 0x1d4

    invoke-direct {p1, p0, v8}, Lzs1;-><init>(Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;I)V

    const/16 v6, 0x147

    invoke-virtual {p0, p1}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    :cond_95
    :goto_95
    return-void

    :pswitch_96  #0x4
    const/16 v6, 0x143

    sget p1, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->F:I

    nop

    const/16 v6, 0x22e

    new-instance p1, Lzs1;

    nop

    const/4 v8, 0x2

    const/16 v6, 0x1d4

    invoke-direct {p1, p0, v8}, Lzs1;-><init>(Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;I)V

    const/16 v6, 0x147

    invoke-virtual {p0, p1}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V

    return-void

    :pswitch_ac  #0x3
    const/16 v6, 0x88

    iget-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->t:Ljava/lang/String;

    nop

    const/4 v6, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x1200

    new-instance v8, Lnn1;

    nop

    const/16 v6, 0x6df

    invoke-direct {v8}, Lnn1;-><init>()V

    const/16 v6, 0x108

    new-instance v9, Landroid/os/Bundle;

    nop

    const/16 v6, 0x198

    invoke-direct {v9}, Landroid/os/Bundle;-><init>()V

    const-string/jumbo v10, "strnew"

    const/16 v6, 0x76

    invoke-virtual {v9, v10, p1}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v6, 0x19a

    invoke-virtual {v8, v9}, Landroidx/fragment/app/Fragment;->setArguments(Landroid/os/Bundle;)V

    const/16 v6, 0x2ff

    invoke-virtual {p0}, Landroidx/fragment/app/l;->c()Lfi0;

    move-result-object p1

    const v9, 0x7f130209

    const/16 v6, 0xb4

    invoke-virtual {p0, v9}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/16 v6, 0x8c

    invoke-virtual {v8, p1, p0}, Landroidx/fragment/app/g;->show(Landroidx/fragment/app/p;Ljava/lang/String;)V

    return-void

    :pswitch_eb  #0x2
    const/16 v6, 0x79d

    iget-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->z:Ljava/lang/String;

    nop

    const/16 v6, 0x112b

    iget-boolean v8, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->A:Z

    nop

    const/16 v6, 0x399

    invoke-virtual {p0, p1, v8}, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->i(Ljava/lang/String;Z)V

    return-void

    :pswitch_fb  #0x1
    const/16 v6, 0x143

    sget p1, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->F:I

    nop

    const/16 v6, 0x224

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->finish()V

    return-void

    :pswitch_106  #0x0
    const/16 v6, 0x143

    sget p1, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->F:I

    nop

    const-string/jumbo p1, "nothing"

    const/16 v6, 0x399

    invoke-virtual {p0, p1, v8}, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;->i(Ljava/lang/String;Z)V

    return-void

    :pswitch_data_114
    .packed-switch 0x0
        :pswitch_106  #00000000
        :pswitch_fb  #00000001
        :pswitch_eb  #00000002
        :pswitch_ac  #00000003
        :pswitch_96  #00000004
    .end packed-switch
.end method
