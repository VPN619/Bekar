.class public final synthetic Ll92;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lkl1;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings$a;


# direct methods
.method public synthetic constructor <init>(Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings$a;I)V
    .registers 5

    iput p2, p0, Ll92;->a:I

    iput-object p1, p0, Ll92;->b:Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings$a;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public a(Landroidx/preference/Preference;)V
    .registers 6

    .prologue
    const/16 v0, 0xa22

    iget p1, p0, Ll92;->a:I

    nop

    const/16 v0, 0x976

    iget-object p0, p0, Ll92;->b:Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings$a;

    nop

    packed-switch p1, :pswitch_data_76

    const/16 v0, 0x5b

    new-instance p1, Landroid/content/Intent;

    nop

    const/4 v0, -0x3

    new-instance v2, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v3, "package:"

    const/16 v0, 0x97

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v3

    const/16 v0, 0x4a

    invoke-virtual {v3}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    const/4 v0, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/16 v0, 0x985

    invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    const-string/jumbo v3, "android.settings.APPLICATION_DETAILS_SETTINGS"

    const/16 v0, 0x8d5

    invoke-direct {p1, v3, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const-string/jumbo v2, "android.intent.category.DEFAULT"

    const/16 v0, 0xcce

    invoke-virtual {p1, v2}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    const/high16 v2, 0x10000000

    const/16 v0, 0x59

    invoke-virtual {p1, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/16 v0, 0x634

    invoke-virtual {p0, p1}, Landroidx/fragment/app/Fragment;->startActivity(Landroid/content/Intent;)V

    return-void

    :pswitch_56  #0x0
    const/16 v0, 0xeb3

    new-instance p1, Lrd;

    nop

    const/16 v0, 0xd28

    invoke-direct {p1}, Lrd;-><init>()V

    const/16 v0, 0x8b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getParentFragmentManager()Landroidx/fragment/app/p;

    move-result-object v2

    const v3, 0x7f130028

    const/16 v0, 0x4c

    invoke-virtual {p0, v3}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x8c

    invoke-virtual {p1, v2, p0}, Landroidx/fragment/app/g;->show(Landroidx/fragment/app/p;Ljava/lang/String;)V

    return-void

    nop

    :pswitch_data_76
    .packed-switch 0x0
        :pswitch_56  #00000000
    .end packed-switch
.end method

.method public b(Landroidx/preference/Preference;Ljava/lang/Object;)V
    .registers 13

    .prologue
    const/16 v0, 0x499

    iget-object v2, p1, Landroidx/preference/Preference;->l:Ljava/lang/String;

    nop

    const-string/jumbo v3, "dmode"

    const/16 v0, 0x84

    invoke-static {v2, v3}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_30

    const/16 v0, 0x905

    sget-boolean v3, Lmi2;->a:Z

    nop

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-object v3, p2

    check-cast v3, Ljava/lang/Boolean;

    const/16 v0, 0x205

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    const/16 v0, 0x7dd

    sput-boolean v3, Lmi2;->h:Z

    if-eqz v3, :cond_2a

    const/4 v3, 0x2

    goto :goto_2b

    :cond_2a
    const/4 v3, 0x1

    :goto_2b
    const/16 v0, 0xe6d

    invoke-static {v3}, Leb;->p(I)V

    :cond_30
    const-string/jumbo v3, "language"

    const/16 v0, 0x84

    invoke-static {v2, v3}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_5d

    const-string/jumbo v3, "system"

    const/16 v0, 0x84

    invoke-static {p2, v3}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_4c

    const/16 v0, 0x39b

    sget-object v3, Lv31;->b:Lv31;

    nop

    goto :goto_58

    :cond_4c
    const/16 v0, 0xcb

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    const/16 v0, 0x11a3

    invoke-static {v3}, Lv31;->a(Ljava/lang/String;)Lv31;

    move-result-object v3

    :goto_58
    const/16 v0, 0x474

    invoke-static {v3}, Leb;->l(Lv31;)V

    :cond_5d
    instance-of v3, p1, Landroidx/preference/EditTextPreference;

    if-eqz v3, :cond_c9

    const/16 v0, 0xcb

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    const/16 v0, 0x7c

    invoke-static {v3}, Lc72;->u0(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_87

    check-cast p1, Landroidx/preference/EditTextPreference;

    const/16 v0, 0xcb

    invoke-virtual {p2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    const/16 v0, 0x1d6

    invoke-virtual {p1, v3}, Landroidx/preference/EditTextPreference;->z(Ljava/lang/String;)V

    const/16 v0, 0x237

    iget-object v3, p1, Landroidx/preference/EditTextPreference;->T:Ljava/lang/String;

    nop

    const/16 v0, 0x1cc

    invoke-virtual {p1, v3}, Landroidx/preference/Preference;->w(Ljava/lang/CharSequence;)V

    goto :goto_c9

    :cond_87
    check-cast p1, Landroidx/preference/EditTextPreference;

    const/16 v0, 0x499

    iget-object v3, p1, Landroidx/preference/Preference;->l:Ljava/lang/String;

    nop

    const-string/jumbo v4, "dnsP"

    const/16 v0, 0x84

    invoke-static {v3, v4}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_ac

    const-string/jumbo v3, "8.8.8.8"

    const/16 v0, 0x1d6

    invoke-virtual {p1, v3}, Landroidx/preference/EditTextPreference;->z(Ljava/lang/String;)V

    const/16 v0, 0x237

    iget-object v3, p1, Landroidx/preference/EditTextPreference;->T:Ljava/lang/String;

    nop

    const/16 v0, 0x1cc

    invoke-virtual {p1, v3}, Landroidx/preference/Preference;->w(Ljava/lang/CharSequence;)V

    goto :goto_c9

    :cond_ac
    const-string/jumbo v4, "dnsS"

    const/16 v0, 0x84

    invoke-static {v3, v4}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_c9

    const-string/jumbo v3, "1.1.1.1"

    const/16 v0, 0x1d6

    invoke-virtual {p1, v3}, Landroidx/preference/EditTextPreference;->z(Ljava/lang/String;)V

    const/16 v0, 0x237

    iget-object v3, p1, Landroidx/preference/EditTextPreference;->T:Ljava/lang/String;

    nop

    const/16 v0, 0x1cc

    invoke-virtual {p1, v3}, Landroidx/preference/Preference;->w(Ljava/lang/CharSequence;)V

    :cond_c9
    :goto_c9
    const-string/jumbo p1, "intranet"

    const/16 v0, 0x84

    invoke-static {v2, p1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    const/16 v0, 0x976

    iget-object p0, p0, Ll92;->b:Lcom/tlsvpn/tlstunnel/ui/settings/TTSettings$a;

    nop

    const-string/jumbo v3, "reconnect"

    const-string/jumbo v4, " pelo usuário! Reconectando..."

    const-string/jumbo v5, "desativada"

    const-string/jumbo v6, "ativada"

    const-string/jumbo v7, "Prefs"

    if-eqz p1, :cond_148

    const/16 v0, 0x1ff

    sget p1, Lmi2;->o:I

    nop

    if-eqz p1, :cond_148

    const/4 v0, -0x3

    new-instance p1, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v8, "Intranet "

    const/16 v0, 0x97

    invoke-direct {p1, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-object v8, p2

    check-cast v8, Ljava/lang/Boolean;

    const/16 v0, 0x205

    invoke-virtual {v8}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v8

    if-eqz v8, :cond_10c

    move-object v8, v6

    goto :goto_10d

    :cond_10c
    move-object v8, v5

    :goto_10d
    const/4 v0, 0x0

    invoke-virtual {p1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {p1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    nop

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p1

    const/16 v0, 0x5b

    new-instance v8, Landroid/content/Intent;

    nop

    const/16 v0, 0x62

    invoke-direct {v8, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v9

    const/16 v0, 0x53

    invoke-virtual {v9}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v9

    const/16 v0, 0x4a

    invoke-virtual {v9}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v9

    const/16 v0, 0x64

    invoke-virtual {v8, v9}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object v8

    const/16 v0, 0x63

    invoke-virtual {p1, v8}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    :cond_148
    const-string/jumbo p1, "compresspkt"

    const/16 v0, 0x84

    invoke-static {v2, p1}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_1b0

    const/16 v0, 0x1ff

    sget p1, Lmi2;->o:I

    nop

    if-eqz p1, :cond_1b0

    const/4 v0, -0x3

    new-instance p1, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v2, "Compressão "

    const/16 v0, 0x97

    invoke-direct {p1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Ljava/lang/Boolean;

    const/16 v0, 0x205

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    if-eqz p2, :cond_175

    move-object v5, v6

    :cond_175
    const/4 v0, 0x0

    invoke-virtual {p1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {p1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    nop

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p1

    const/16 v0, 0x5b

    new-instance p2, Landroid/content/Intent;

    nop

    const/16 v0, 0x62

    invoke-direct {p2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p0

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/16 v0, 0x4a

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x64

    invoke-virtual {p2, p0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    const/16 v0, 0x63

    invoke-virtual {p1, p0}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    :cond_1b0
    return-void
.end method
