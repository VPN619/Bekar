.class public final synthetic Lb12;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Lg12;


# direct methods
.method public synthetic constructor <init>(Lg12;I)V
    .registers 5

    iput p2, p0, Lb12;->a:I

    iput-object p1, p0, Lb12;->b:Lg12;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 13

    .prologue
    const/16 v6, 0xbf7

    iget p1, p0, Lb12;->a:I

    nop

    const/16 v6, 0xd85

    iget-object p0, p0, Lb12;->b:Lg12;

    nop

    packed-switch p1, :pswitch_data_c2

    const/4 p1, 0x1

    const/16 v6, 0xcfe

    invoke-virtual {p0, p1}, Lg12;->e(Z)V

    const/16 v6, 0x140

    sget-boolean v8, Lg4;->a:Z

    nop

    const/16 v6, 0xfb

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object v8

    const/4 v6, -0x6

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x131

    invoke-virtual {p0}, Lg12;->d()Landroid/content/SharedPreferences;

    move-result-object v9

    const/4 v6, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x394

    invoke-static {v9, v8}, Lg4;->n(Landroid/content/SharedPreferences;Landroidx/fragment/app/l;)V

    const/16 v6, 0x325

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getViewLifecycleOwner()Lh11;

    move-result-object v8

    const/4 v6, -0x6

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x341

    invoke-static {v8}, Lns2;->m(Lh11;)Lc11;

    move-result-object v8

    const/16 v6, 0x24d

    new-instance v9, Lf12;

    nop

    const/4 v10, 0x0

    const/16 v6, 0x1ad

    invoke-direct {v9, p0, v10, p1}, Lf12;-><init>(Lg12;Lvx;I)V

    const/4 p0, 0x3

    const/16 v6, 0xb3

    move v0, v6

    move-object v1, v8

    move-object v2, v10

    move-object v3, v10

    move-object v4, v9

    move v5, p0

    invoke-static/range {v1 .. v5}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    return-void

    :pswitch_59  #0x0
    const/16 v6, 0xbb1

    new-instance p1, Lg8;

    nop

    const/16 v6, 0xfb

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object v8

    const/16 v6, 0x100b

    invoke-direct {p1, v8}, Lg8;-><init>(Landroid/content/Context;)V

    const/16 v6, 0x11e6

    iget-object v8, p1, Lg8;->c:Ljava/lang/Object;

    nop

    check-cast v8, Lc8;

    const/16 v6, 0x505

    iget-object v9, v8, Lc8;->a:Landroid/view/ContextThemeWrapper;

    nop

    const v10, 0x7f1300af

    const/16 v6, 0x492

    invoke-virtual {v9, v10}, Landroid/content/Context;->getText(I)Ljava/lang/CharSequence;

    move-result-object v9

    const/16 v6, 0x7c3

    iput-object v9, v8, Lc8;->f:Ljava/lang/CharSequence;

    const/16 v6, 0xfe3

    new-instance v9, Ld51;

    nop

    const/4 v10, 0x2

    const/16 v6, 0xb08

    invoke-direct {v9, v10, p0}, Ld51;-><init>(ILjava/lang/Object;)V

    const p0, 0x7f1300ae

    const/16 v6, 0xf53

    invoke-virtual {p1, p0, v9}, Lg8;->j(ILandroid/content/DialogInterface$OnClickListener;)V

    const/16 v6, 0x120f

    new-instance p0, Lic0;

    nop

    const/16 v6, 0x1192

    invoke-direct {p0, v10}, Lic0;-><init>(I)V

    const v9, 0x7f130064

    const/16 v6, 0x505

    iget-object v10, v8, Lc8;->a:Landroid/view/ContextThemeWrapper;

    nop

    const/16 v6, 0x492

    invoke-virtual {v10, v9}, Landroid/content/Context;->getText(I)Ljava/lang/CharSequence;

    move-result-object v9

    const/16 v6, 0xe5d

    iput-object v9, v8, Lc8;->i:Ljava/lang/CharSequence;

    const/16 v6, 0xe2e

    iput-object p0, v8, Lc8;->j:Landroid/content/DialogInterface$OnClickListener;

    const/16 v6, 0x670

    invoke-virtual {p1}, Lg8;->b()Lh8;

    move-result-object p0

    const/16 v6, 0x9a5

    invoke-virtual {p0}, Landroid/app/Dialog;->show()V

    return-void

    nop

    :pswitch_data_c2
    .packed-switch 0x0
        :pswitch_59  #00000000
    .end packed-switch
.end method
