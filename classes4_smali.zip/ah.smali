.class public final synthetic Lah;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lj3;
.implements Lsg1;
.implements Lyt;
.implements Lei1;
.implements Lzu0;
.implements Ls82;
.implements Lcom/google/android/gms/tasks/OnSuccessListener;
.implements Lcom/google/android/gms/tasks/OnCompleteListener;
.implements Lwd1;
.implements Lcom/android/billingclient/api/ProductDetailsResponseListener;
.implements Lkn;
.implements Lkp;
.implements Lih1;
.implements Lv82;
.implements Lcom/mbridge/msdk/config/activity/backdispatcher/b;
.implements Landroidx/webkit/WebViewCompat$WebViewStartUpCallback;
.implements Le82;
.implements Lcom/mbridge/msdk/config/component/info/provider/listener/a;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 5

    iput p1, p0, Lah;->a:I

    iput-object p2, p0, Lah;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public H()Ljava/lang/Object;
    .registers 10

    .prologue
    const/16 v1, 0xc68

    iget v3, p0, Lah;->a:I

    nop

    const/4 v4, 0x0

    const/16 v1, 0xeac

    iget-object p0, p0, Lah;->b:Ljava/lang/Object;

    nop

    packed-switch v3, :pswitch_data_b0

    check-cast p0, Lx5;

    const/16 v1, 0x916

    iget-object v3, p0, Lx5;->d:Ljava/lang/Object;

    nop

    check-cast v3, Lix1;

    const/16 v1, 0xaa2

    new-instance v5, Lpw1;

    nop

    const/4 v6, 0x7

    const/16 v1, 0x61e

    invoke-direct {v5, v6}, Lpw1;-><init>(I)V

    const/16 v1, 0x7e5

    invoke-virtual {v3, v5}, Lix1;->p(Lgx1;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Iterable;

    const/16 v1, 0x429

    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_30
    const/16 v1, 0x13e

    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v5

    if-eqz v5, :cond_4f

    const/16 v1, 0x16e

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Lyg;

    const/16 v1, 0x1e3

    iget-object v6, p0, Lx5;->e:Ljava/lang/Object;

    nop

    check-cast v6, Ltd;

    const/4 v7, 0x1

    const/4 v8, 0x0

    const/16 v1, 0xe8a

    invoke-virtual {v6, v5, v7, v8}, Ltd;->C(Lyg;IZ)V

    goto :goto_30

    :cond_4f
    return-object v4

    :pswitch_50  #0x17
    check-cast p0, Lvh2;

    const/16 v1, 0xc36

    iget-object p0, p0, Lvh2;->e:Ljava/lang/Object;

    nop

    check-cast p0, Lix1;

    const/16 v1, 0xcd

    invoke-virtual {p0}, Lix1;->k()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v3

    const/16 v1, 0xb23

    invoke-virtual {v3}, Landroid/database/sqlite/SQLiteDatabase;->beginTransaction()V

    :try_start_64
    const-string/jumbo v5, "DELETE FROM log_event_dropped"

    const/16 v1, 0x112

    invoke-virtual {v3, v5}, Landroid/database/sqlite/SQLiteDatabase;->compileStatement(Ljava/lang/String;)Landroid/database/sqlite/SQLiteStatement;

    move-result-object v5

    const/16 v1, 0x34c

    invoke-virtual {v5}, Landroid/database/sqlite/SQLiteStatement;->execute()V

    const/4 v1, -0x3

    new-instance v5, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v6, "UPDATE global_log_event_state SET last_metrics_upload_ms="

    const/16 v1, 0x97

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v1, 0xe15

    iget-object p0, p0, Lix1;->b:Lns1;

    nop

    const/16 v1, 0xa83

    invoke-virtual {p0}, Lns1;->c()J

    move-result-wide v6

    const/16 v1, 0x83

    invoke-virtual {v5, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v1, -0x2

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/16 v1, 0x112

    invoke-virtual {v3, p0}, Landroid/database/sqlite/SQLiteDatabase;->compileStatement(Ljava/lang/String;)Landroid/database/sqlite/SQLiteStatement;

    move-result-object p0

    const/16 v1, 0x34c

    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteStatement;->execute()V

    const/16 v1, 0x9b2

    invoke-virtual {v3}, Landroid/database/sqlite/SQLiteDatabase;->setTransactionSuccessful()V
    :try_end_a3
    .catchall {:try_start_64 .. :try_end_a3} :catchall_a9

    const/16 v1, 0x38d

    invoke-virtual {v3}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    return-object v4

    :catchall_a9
    move-exception p0

    const/16 v1, 0x38d

    invoke-virtual {v3}, Landroid/database/sqlite/SQLiteDatabase;->endTransaction()V

    throw p0

    :pswitch_data_b0
    .packed-switch 0x17
        :pswitch_50  #00000017
    .end packed-switch
.end method

.method public a()V
    .registers 3

    const/16 v0, 0xeac

    iget-object p0, p0, Lah;->b:Ljava/lang/Object;

    nop

    check-cast p0, Lcom/mbridge/msdk/config/component/vc/VCCpt;

    const/16 v0, 0xdd9

    invoke-static {p0}, Lcom/mbridge/msdk/config/component/vc/VCCpt;->g(Lcom/mbridge/msdk/config/component/vc/VCCpt;)V

    return-void
.end method

.method public a(Ljava/util/Map;)V
    .registers 4

    const/16 v0, 0xeac

    iget-object p0, p0, Lah;->b:Ljava/lang/Object;

    nop

    check-cast p0, Lcom/mbridge/msdk/config/component/info/provider/a;

    const/16 v0, 0xa47

    invoke-static {p0, p1}, Lcom/mbridge/msdk/config/component/info/provider/a;->a(Lcom/mbridge/msdk/config/component/info/provider/a;Ljava/util/Map;)V

    return-void
.end method

.method public a(Landroid/view/MenuItem;)Z
    .registers 31

    .prologue
    move-object/from16 v13, p0

    const/16 v11, 0xeac

    iget-object v13, v13, Lah;->b:Ljava/lang/Object;

    nop

    move-object v14, v13

    check-cast v14, Lzc1;

    const/4 v11, -0x6

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v11, 0x4b9

    iget-object v15, v14, Lzc1;->b:Lmc1;

    nop

    const/16 v11, 0x271

    invoke-virtual {v15}, Lmc1;->f()Luc1;

    move-result-object v13

    const/4 v11, -0x6

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v11, 0xf0c

    iget-object v13, v13, Luc1;->c:Lwc1;

    nop

    const/4 v11, -0x6

    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v11, 0x17e

    move-object/from16 v0, p1

    invoke-interface {v0}, Landroid/view/MenuItem;->getItemId()I

    move-result v16

    const/16 v11, 0xa9c

    move/from16 v0, v16

    invoke-virtual {v13, v0}, Lwc1;->h(I)Luc1;

    move-result-object v13

    instance-of v13, v13, Lc3;

    if-eqz v13, :cond_51

    const v13, 0x7f01002e

    const v16, 0x7f01002f

    const v17, 0x7f010030

    const v18, 0x7f010031

    :goto_48
    move/from16 v25, v13

    move/from16 v26, v16

    move/from16 v27, v17

    move/from16 v28, v18

    goto :goto_5e

    :cond_51
    const v13, 0x7f020028

    const v16, 0x7f020029

    const v17, 0x7f02002a

    const v18, 0x7f02002b

    goto :goto_48

    :goto_5e
    const/16 v11, 0xc2d

    move-object/from16 v0, p1

    invoke-interface {v0}, Landroid/view/MenuItem;->getOrder()I

    move-result v13

    const/high16 v16, 0x30000

    and-int v13, v13, v16

    const/16 v16, 0x1

    const/16 v23, 0x0

    if-nez v13, :cond_90

    const/16 v11, 0xc67

    sget v13, Lwc1;->h:I

    nop

    const/16 v11, 0x7c0

    invoke-virtual {v15}, Lmc1;->g()Lwc1;

    move-result-object v13

    const/16 v11, 0xfb5

    invoke-static {v13}, Llk;->l(Lwc1;)Luc1;

    move-result-object v13

    const/16 v11, 0xbcf

    iget-object v13, v13, Luc1;->b:Lz4;

    nop

    const/16 v11, 0xa10

    iget v13, v13, Lz4;->b:I

    nop

    move/from16 v24, v16

    :goto_8d
    move/from16 v22, v13

    goto :goto_94

    :cond_90
    const/4 v13, -0x1

    move/from16 v24, v23

    goto :goto_8d

    :goto_94
    const/16 v11, 0xbcd

    new-instance v19, Lcd1;

    nop

    const/16 v20, 0x1

    const/16 v21, 0x1

    const/16 v11, 0xe4b

    move v0, v11

    move-object/from16 v1, v19

    move/from16 v2, v20

    move/from16 v3, v21

    move/from16 v4, v22

    move/from16 v5, v23

    move/from16 v6, v24

    move/from16 v7, v25

    move/from16 v8, v26

    move/from16 v9, v27

    move/from16 v10, v28

    invoke-direct/range {v1 .. v10}, Lcd1;-><init>(ZZIZZIIII)V

    :try_start_b7
    const/16 v11, 0x17e

    move-object/from16 v0, p1

    invoke-interface {v0}, Landroid/view/MenuItem;->getItemId()I

    move-result v13

    const/16 v11, 0xcf7

    move-object/from16 v0, v19

    invoke-virtual {v14, v13, v0}, Lzc1;->a(ILcd1;)V

    const/16 v11, 0x271

    invoke-virtual {v15}, Lmc1;->f()Luc1;

    move-result-object v13

    if-eqz v13, :cond_e5

    const/16 v11, 0x17e

    move-object/from16 v0, p1

    invoke-interface {v0}, Landroid/view/MenuItem;->getItemId()I

    move-result v17

    const/16 v11, 0xc89

    move/from16 v0, v17

    invoke-static {v0, v13}, Li10;->x0(ILuc1;)Z

    move-result v13
    :try_end_de
    .catch Ljava/lang/IllegalArgumentException; {:try_start_b7 .. :try_end_de} :catch_e3

    move/from16 v0, v16

    if-ne v13, v0, :cond_e5

    return v16

    :catch_e3
    move-exception v13

    goto :goto_e6

    :cond_e5
    return v23

    :goto_e6
    const/16 v11, 0x758

    sget v16, Luc1;->f:I

    nop

    const/16 v11, 0x759

    iget-object v14, v14, Lzc1;->a:Landroid/content/Context;

    nop

    const/16 v11, 0x17e

    move-object/from16 v0, p1

    invoke-interface {v0}, Landroid/view/MenuItem;->getItemId()I

    move-result v16

    const v17, 0xffffff

    move/from16 v0, v16

    move/from16 v1, v17

    if-gt v0, v1, :cond_10a

    const/16 v11, 0x262

    move/from16 v0, v16

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v14

    goto :goto_125

    :cond_10a
    :try_start_10a
    const/16 v11, 0x142

    invoke-virtual {v14}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v14

    const/16 v11, 0x682

    move/from16 v0, v16

    invoke-virtual {v14, v0}, Landroid/content/res/Resources;->getResourceName(I)Ljava/lang/String;

    move-result-object v14

    const/4 v11, -0x6

    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_11c
    .catch Landroid/content/res/Resources$NotFoundException; {:try_start_10a .. :try_end_11c} :catch_11d

    goto :goto_125

    :catch_11d
    const/16 v11, 0x262

    move/from16 v0, v16

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v14

    :goto_125
    const-string/jumbo v16, "Ignoring onNavDestinationSelected for MenuItem "

    const-string/jumbo v17, " as it cannot be found from the current destination "

    const/16 v11, 0x540

    move-object/from16 v0, v16

    move-object/from16 v1, v17

    invoke-static {v0, v14, v1}, Lrt2;->o(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v14

    const/16 v11, 0x271

    invoke-virtual {v15}, Lmc1;->f()Luc1;

    move-result-object v15

    const/16 v11, 0x190

    invoke-virtual {v14, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v11, -0x2

    invoke-virtual {v14}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v14

    const-string/jumbo v15, "NavigationUI"

    nop

    return v23
.end method

.method public b(Lwu1;)V
    .registers 4

    const/16 v0, 0xeac

    iget-object p0, p0, Lah;->b:Ljava/lang/Object;

    nop

    check-cast p0, Lcom/tlsvpn/tlstunnel/utils/mediation/GamRewardedCustomEvent;

    const/16 v0, 0x70f

    invoke-static {p0, p1}, Lcom/tlsvpn/tlstunnel/utils/mediation/GamRewardedCustomEvent;->a(Lcom/tlsvpn/tlstunnel/utils/mediation/GamRewardedCustomEvent;Lwu1;)V

    return-void
.end method

.method public c(Ld82;)Lf82;
    .registers 17

    .prologue
    const/16 v7, 0xeac

    iget-object p0, p0, Lah;->b:Ljava/lang/Object;

    nop

    move-object v10, p0

    check-cast v10, Landroid/content/Context;

    const/16 v7, 0xf91

    move-object/from16 v0, p1

    iget-object v11, v0, Ld82;->b:Ljava/lang/String;

    nop

    const/16 v7, 0x107f

    move-object/from16 v0, p1

    iget-object v12, v0, Ld82;->c:Lg8;

    nop

    const/4 v7, -0x6

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    if-eqz v11, :cond_3a

    const/16 v7, 0x47

    invoke-virtual {v11}, Ljava/lang/String;->length()I

    move-result p0

    if-eqz p0, :cond_3a

    const/16 v7, 0x102d

    new-instance v9, Ltj0;

    nop

    const/4 v13, 0x1

    move v14, v13

    const/16 v7, 0xe6c

    move v0, v7

    move-object v1, v9

    move-object v2, v10

    move-object v3, v11

    move-object v4, v12

    move v5, v13

    move v6, v14

    invoke-direct/range {v1 .. v6}, Ltj0;-><init>(Landroid/content/Context;Ljava/lang/String;Lg8;ZZ)V

    check-cast v9, Lf82;

    return-object v9

    :cond_3a
    const-string/jumbo p0, "Must set a non-null database name to a configuration that uses the no backup directory."

    const/16 v7, 0x52e

    invoke-static {p0}, Lz6;->s(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public d()V
    .registers 5

    const/16 v0, 0xeac

    iget-object p0, p0, Lah;->b:Ljava/lang/Object;

    nop

    check-cast p0, La62;

    const/16 v0, 0x5d8

    iget-object v2, p0, La62;->d:Lcom/google/android/material/internal/CheckableImageButton;

    nop

    const/16 v0, 0x11c3

    iget-object p0, p0, La62;->i:Landroid/view/View$OnLongClickListener;

    nop

    const/16 v0, 0x8bc

    invoke-virtual {v2}, Landroid/view/View;->getContentDescription()Ljava/lang/CharSequence;

    move-result-object v3

    const/16 v0, 0x644

    invoke-static {v2, p0, v3}, Lja;->K(Lcom/google/android/material/internal/CheckableImageButton;Landroid/view/View$OnLongClickListener;Ljava/lang/CharSequence;)V

    return-void
.end method

.method public e(Ltd;)Lvn;
    .registers 30

    .prologue
    move-object/from16 v10, p0

    move-object/from16 v11, p1

    const/16 v8, 0xeac

    iget-object v10, v10, Lah;->b:Ljava/lang/Object;

    nop

    check-cast v10, Lwn;

    const/16 v8, 0xd89

    iget-object v12, v11, Ltd;->b:Ljava/lang/Object;

    nop

    check-cast v12, Ljava/net/URL;

    const-string/jumbo v13, "CctTransportBackend"

    const/16 v8, 0x312

    invoke-static {v13}, Lg73;->x(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    const/4 v15, 0x4

    const/16 v8, 0x481

    invoke-static {v14, v15}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v16

    if-eqz v16, :cond_36

    filled-new-array {v12}, [Ljava/lang/Object;

    move-result-object v16

    const-string/jumbo v17, "Making request to: %s"

    const/16 v8, 0x377

    move-object/from16 v0, v17

    move-object/from16 v1, v16

    invoke-static {v0, v1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v16

    nop

    :cond_36
    const/16 v8, 0x5f2

    invoke-virtual {v12}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v12

    check-cast v12, Ljava/net/HttpURLConnection;

    const/16 v14, 0x7530

    const/16 v8, 0x667

    invoke-virtual {v12, v14}, Ljava/net/URLConnection;->setConnectTimeout(I)V

    const v14, 0x1fbd0

    const/16 v8, 0xb5f

    invoke-virtual {v12, v14}, Ljava/net/URLConnection;->setReadTimeout(I)V

    const/4 v14, 0x1

    const/16 v8, 0x7f4

    invoke-virtual {v12, v14}, Ljava/net/URLConnection;->setDoOutput(Z)V

    const/4 v14, 0x0

    const/16 v8, 0x10d9

    invoke-virtual {v12, v14}, Ljava/net/HttpURLConnection;->setInstanceFollowRedirects(Z)V

    const-string/jumbo v14, "POST"

    const/16 v8, 0x1102

    invoke-virtual {v12, v14}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    const-string/jumbo v14, "User-Agent"

    const-string/jumbo v16, "datatransport/3.1.8 android/"

    const/16 v8, 0xe0

    move-object/from16 v0, v16

    invoke-virtual {v12, v14, v0}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const-string/jumbo v14, "Content-Encoding"

    const-string/jumbo v16, "gzip"

    const/16 v8, 0xe0

    move-object/from16 v0, v16

    invoke-virtual {v12, v14, v0}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const-string/jumbo v17, "application/json"

    const-string/jumbo v18, "Content-Type"

    const/16 v8, 0xe0

    move-object/from16 v0, v18

    move-object/from16 v1, v17

    invoke-virtual {v12, v0, v1}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const-string/jumbo v17, "Accept-Encoding"

    const/16 v8, 0xe0

    move-object/from16 v0, v17

    move-object/from16 v1, v16

    invoke-virtual {v12, v0, v1}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v8, 0xd63

    iget-object v8, v11, Ltd;->d:Ljava/lang/Object;

    move-object/16 v17, v8

    check-cast v17, Ljava/lang/String;

    if-eqz v17, :cond_ad

    const-string/jumbo v19, "X-Goog-Api-Key"

    const/16 v8, 0xe0

    move-object/from16 v0, v19

    move-object/from16 v1, v17

    invoke-virtual {v12, v0, v1}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    :cond_ad
    :try_start_ad
    const/16 v8, 0x5a2

    invoke-virtual {v12}, Ljava/net/URLConnection;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v20
    :try_end_b3
    .catch Ljava/net/ConnectException; {:try_start_ad .. :try_end_b3} :catch_15f
    .catch Ljava/net/UnknownHostException; {:try_start_ad .. :try_end_b3} :catch_158
    .catch Lka0; {:try_start_ad .. :try_end_b3} :catch_155
    .catch Ljava/io/IOException; {:try_start_ad .. :try_end_b3} :catch_152

    :try_start_b3
    const/16 v8, 0x853

    new-instance v21, Ljava/util/zip/GZIPOutputStream;

    nop

    const/16 v8, 0xaf9

    move-object/from16 v0, v21

    move-object/from16 v1, v20

    invoke-direct {v0, v1}, Ljava/util/zip/GZIPOutputStream;-><init>(Ljava/io/OutputStream;)V
    :try_end_c1
    .catchall {:try_start_b3 .. :try_end_c1} :catchall_280

    :try_start_c1
    const/16 v8, 0x1166

    iget-object v10, v10, Lwn;->a:Loj0;

    nop

    const/16 v8, 0x788

    iget-object v11, v11, Ltd;->c:Ljava/lang/Object;

    nop

    check-cast v11, Leg;

    const/16 v8, 0x7d8

    new-instance v23, Ljava/io/BufferedWriter;

    nop

    const/16 v8, 0x9fe

    new-instance v22, Ljava/io/OutputStreamWriter;

    nop

    const/16 v8, 0xae8

    move-object/from16 v0, v22

    move-object/from16 v1, v21

    invoke-direct {v0, v1}, Ljava/io/OutputStreamWriter;-><init>(Ljava/io/OutputStream;)V

    const/16 v8, 0x99c

    move-object/from16 v0, v23

    move-object/from16 v1, v22

    invoke-direct {v0, v1}, Ljava/io/BufferedWriter;-><init>(Ljava/io/Writer;)V

    const/16 v8, 0xe01

    new-instance v22, Ldy0;

    nop

    const/16 v8, 0x19e

    iget-object v10, v10, Loj0;->a:Ljava/lang/Object;

    nop

    check-cast v10, Lew0;

    const/16 v8, 0xa3c

    iget-object v8, v10, Lew0;->a:Ljava/util/HashMap;

    move-object/16 v24, v8

    const/16 v8, 0xaa6

    iget-object v8, v10, Lew0;->b:Ljava/util/HashMap;

    move-object/16 v17, v8

    const/16 v8, 0x115e

    iget-object v8, v10, Lew0;->c:Lbw0;

    move-object/16 v19, v8

    const/16 v8, 0xe48

    iget-boolean v10, v10, Lew0;->d:Z

    nop

    move/from16 v27, v10

    move-object/from16 v25, v17

    move-object/from16 v26, v19

    const/16 v8, 0xa56

    move v0, v8

    move-object/from16 v1, v22

    move-object/from16 v2, v23

    move-object/from16 v3, v24

    move-object/from16 v4, v25

    move-object/from16 v5, v26

    move/from16 v6, v27

    invoke-direct/range {v1 .. v6}, Ldy0;-><init>(Ljava/io/BufferedWriter;Ljava/util/HashMap;Ljava/util/HashMap;Lbw0;Z)V

    const/16 v8, 0x769

    move-object/from16 v0, v22

    invoke-virtual {v0, v11}, Ldy0;->e(Ljava/lang/Object;)Ldy0;

    const/16 v8, 0x89e

    move-object/from16 v0, v22

    invoke-virtual {v0}, Ldy0;->g()V

    const/16 v8, 0xc7f

    move-object/from16 v0, v22

    iget-object v10, v0, Ldy0;->b:Landroid/util/JsonWriter;

    nop

    const/16 v8, 0x1148

    invoke-virtual {v10}, Landroid/util/JsonWriter;->flush()V
    :try_end_141
    .catchall {:try_start_c1 .. :try_end_141} :catchall_285

    :try_start_141
    const/16 v8, 0x148

    move-object/from16 v0, v21

    invoke-virtual {v0}, Ljava/io/OutputStream;->close()V
    :try_end_148
    .catchall {:try_start_141 .. :try_end_148} :catchall_280

    if-eqz v20, :cond_161

    :try_start_14a
    const/16 v8, 0x148

    move-object/from16 v0, v20

    invoke-virtual {v0}, Ljava/io/OutputStream;->close()V
    :try_end_151
    .catch Ljava/net/ConnectException; {:try_start_14a .. :try_end_151} :catch_15f
    .catch Ljava/net/UnknownHostException; {:try_start_14a .. :try_end_151} :catch_158
    .catch Lka0; {:try_start_14a .. :try_end_151} :catch_155
    .catch Ljava/io/IOException; {:try_start_14a .. :try_end_151} :catch_152

    goto :goto_161

    :catch_152
    move-exception v10

    goto/16 :goto_2a7

    :catch_155
    move-exception v10

    goto/16 :goto_2a7

    :catch_158
    move-exception v10

    :goto_159
    const-wide/16 v14, 0x0

    const/16 v16, 0x0

    goto/16 :goto_2c6

    :catch_15f
    move-exception v10

    goto :goto_159

    :cond_161
    :goto_161
    const/16 v8, 0xa7f

    invoke-virtual {v12}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v10

    const/16 v8, 0xb1

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    const/16 v8, 0x312

    invoke-static {v13}, Lg73;->x(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v17

    const/16 v8, 0x481

    move-object/from16 v0, v17

    invoke-static {v0, v15}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v15

    if-eqz v15, :cond_18b

    filled-new-array {v11}, [Ljava/lang/Object;

    move-result-object v11

    const-string/jumbo v15, "Status Code: %d"

    const/16 v8, 0x377

    invoke-static {v15, v11}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v11

    nop

    :cond_18b
    const-string/jumbo v11, "Content-Type: %s"

    const/16 v8, 0x16c

    move-object/from16 v0, v18

    invoke-virtual {v12, v0}, Ljava/net/URLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    const/16 v8, 0x4eb

    invoke-static {v13, v11, v15}, Lg73;->q(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    const-string/jumbo v11, "Content-Encoding: %s"

    const/16 v8, 0x16c

    invoke-virtual {v12, v14}, Ljava/net/URLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    const/16 v8, 0x4eb

    invoke-static {v13, v11, v15}, Lg73;->q(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    const/16 v11, 0x12e

    if-eq v10, v11, :cond_259

    const/16 v11, 0x12d

    if-eq v10, v11, :cond_259

    const/16 v11, 0x133

    if-ne v10, v11, :cond_1b7

    goto/16 :goto_259

    :cond_1b7
    const/16 v11, 0xc8

    if-eq v10, v11, :cond_1d0

    const/16 v8, 0x104

    new-instance v11, Lvn;

    nop

    const-wide/16 v12, 0x0

    const/4 v14, 0x0

    const/16 v8, 0xdc

    move v0, v8

    move-object v1, v11

    move v2, v10

    move-object v3, v14

    move-wide v4, v12

    invoke-direct/range {v1 .. v5}, Lvn;-><init>(ILjava/net/URL;J)V

    check-cast v11, Lvn;

    return-object v11

    :cond_1d0
    const/16 v8, 0xfd4

    invoke-virtual {v12}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v11

    :try_start_1d6
    const/16 v8, 0x16c

    invoke-virtual {v12, v14}, Ljava/net/URLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    const/4 v8, -0x7

    move-object/from16 v0, v16

    invoke-virtual {v0, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_1f0

    const/16 v8, 0xa64

    new-instance v12, Ljava/util/zip/GZIPInputStream;

    nop

    const/16 v8, 0x9e3

    invoke-direct {v12, v11}, Ljava/util/zip/GZIPInputStream;-><init>(Ljava/io/InputStream;)V
    :try_end_1ef
    .catchall {:try_start_1d6 .. :try_end_1ef} :catchall_22c

    goto :goto_1f1

    :cond_1f0
    move-object v12, v11

    :goto_1f1
    :try_start_1f1
    const/16 v8, 0xe82

    new-instance v13, Ljava/io/BufferedReader;

    nop

    const/16 v8, 0x588

    new-instance v14, Ljava/io/InputStreamReader;

    nop

    const/16 v8, 0xbb6

    invoke-direct {v14, v12}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;)V

    const/16 v8, 0x11b6

    invoke-direct {v13, v14}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    const/16 v8, 0x982

    invoke-static {v13}, Lpg;->a(Ljava/io/BufferedReader;)Lpg;

    move-result-object v13

    const/16 v8, 0xa88

    iget-wide v8, v13, Lpg;->a:J

    move-wide/16 v13, v8

    const/16 v8, 0x104

    new-instance v15, Lvn;

    nop

    const/16 v16, 0x0

    const/16 v8, 0xdc

    move v0, v8

    move-object v1, v15

    move v2, v10

    move-object/from16 v3, v16

    move-wide v4, v13

    invoke-direct/range {v1 .. v5}, Lvn;-><init>(ILjava/net/URL;J)V
    :try_end_224
    .catchall {:try_start_1f1 .. :try_end_224} :catchall_239

    if-eqz v12, :cond_22f

    :try_start_226
    const/16 v8, 0x122

    invoke-virtual {v12}, Ljava/io/InputStream;->close()V
    :try_end_22b
    .catchall {:try_start_226 .. :try_end_22b} :catchall_22c

    goto :goto_22f

    :catchall_22c
    move-exception v10

    move-object v12, v10

    goto :goto_24a

    :cond_22f
    :goto_22f
    if-eqz v11, :cond_236

    const/16 v8, 0x122

    invoke-virtual {v11}, Ljava/io/InputStream;->close()V

    :cond_236
    check-cast v15, Lvn;

    return-object v15

    :catchall_239
    move-exception v10

    move-object v13, v10

    if-eqz v12, :cond_249

    :try_start_23d
    const/16 v8, 0x122

    invoke-virtual {v12}, Ljava/io/InputStream;->close()V
    :try_end_242
    .catchall {:try_start_23d .. :try_end_242} :catchall_243

    goto :goto_249

    :catchall_243
    move-exception v10

    :try_start_244
    const/16 v8, 0x135

    invoke-virtual {v13, v10}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_249
    :goto_249
    throw v13
    :try_end_24a
    .catchall {:try_start_244 .. :try_end_24a} :catchall_22c

    :goto_24a
    if-eqz v11, :cond_258

    :try_start_24c
    const/16 v8, 0x122

    invoke-virtual {v11}, Ljava/io/InputStream;->close()V
    :try_end_251
    .catchall {:try_start_24c .. :try_end_251} :catchall_252

    goto :goto_258

    :catchall_252
    move-exception v10

    const/16 v8, 0x135

    invoke-virtual {v12, v10}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_258
    :goto_258
    throw v12

    :cond_259
    :goto_259
    const-string/jumbo v11, "Location"

    const/16 v8, 0x16c

    invoke-virtual {v12, v11}, Ljava/net/URLConnection;->getHeaderField(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const/16 v8, 0x104

    new-instance v12, Lvn;

    nop

    const/16 v8, 0x7b4

    new-instance v13, Ljava/net/URL;

    nop

    const/16 v8, 0x103c

    invoke-direct {v13, v11}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    const-wide/16 v14, 0x0

    const/16 v8, 0xdc

    move v0, v8

    move-object v1, v12

    move v2, v10

    move-object v3, v13

    move-wide v4, v14

    invoke-direct/range {v1 .. v5}, Lvn;-><init>(ILjava/net/URL;J)V

    check-cast v12, Lvn;

    return-object v12

    :catchall_280
    move-exception v10

    move-object v11, v10

    goto :goto_296

    :goto_283
    move-object v11, v10

    goto :goto_287

    :catchall_285
    move-exception v10

    goto :goto_283

    :goto_287
    :try_start_287
    const/16 v8, 0x148

    move-object/from16 v0, v21

    invoke-virtual {v0}, Ljava/io/OutputStream;->close()V
    :try_end_28e
    .catchall {:try_start_287 .. :try_end_28e} :catchall_28f

    goto :goto_295

    :catchall_28f
    move-exception v10

    :try_start_290
    const/16 v8, 0x135

    invoke-virtual {v11, v10}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_295
    throw v11
    :try_end_296
    .catchall {:try_start_290 .. :try_end_296} :catchall_280

    :goto_296
    if-eqz v20, :cond_2a6

    :try_start_298
    const/16 v8, 0x148

    move-object/from16 v0, v20

    invoke-virtual {v0}, Ljava/io/OutputStream;->close()V
    :try_end_29f
    .catchall {:try_start_298 .. :try_end_29f} :catchall_2a0

    goto :goto_2a6

    :catchall_2a0
    move-exception v10

    :try_start_2a1
    const/16 v8, 0x135

    invoke-virtual {v11, v10}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_2a6
    :goto_2a6
    throw v11
    :try_end_2a7
    .catch Ljava/net/ConnectException; {:try_start_2a1 .. :try_end_2a7} :catch_15f
    .catch Ljava/net/UnknownHostException; {:try_start_2a1 .. :try_end_2a7} :catch_158
    .catch Lka0; {:try_start_2a1 .. :try_end_2a7} :catch_155
    .catch Ljava/io/IOException; {:try_start_2a1 .. :try_end_2a7} :catch_152

    :goto_2a7
    const-string/jumbo v11, "Couldn\'t encode request, returning with 400"

    const/16 v8, 0x42f

    invoke-static {v13, v11, v10}, Lg73;->s(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Exception;)V

    const/16 v8, 0x104

    new-instance v10, Lvn;

    nop

    const/16 v11, 0x190

    const-wide/16 v14, 0x0

    const/16 v16, 0x0

    const/16 v8, 0xdc

    move v0, v8

    move-object v1, v10

    move v2, v11

    move-object/from16 v3, v16

    move-wide v4, v14

    invoke-direct/range {v1 .. v5}, Lvn;-><init>(ILjava/net/URL;J)V

    goto :goto_2e0

    :goto_2c6
    const-string/jumbo v11, "Couldn\'t open connection, returning with 500"

    const/16 v8, 0x42f

    invoke-static {v13, v11, v10}, Lg73;->s(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Exception;)V

    const/16 v8, 0x104

    new-instance v10, Lvn;

    nop

    const/16 v11, 0x1f4

    const/16 v8, 0xdc

    move v0, v8

    move-object v1, v10

    move v2, v11

    move-object/from16 v3, v16

    move-wide v4, v14

    invoke-direct/range {v1 .. v5}, Lvn;-><init>(ILjava/net/URL;J)V

    :goto_2e0
    check-cast v10, Lvn;

    return-object v10
.end method

.method public f(Landroid/view/View;Lpp2;)Lpp2;
    .registers 10

    .prologue
    const/16 v0, 0xeac

    iget-object p0, p0, Lah;->b:Ljava/lang/Object;

    nop

    check-cast p0, La92;

    const/16 v0, 0x751

    iget-object p1, p0, La92;->b:Ljava/util/ArrayList;

    nop

    const/16 v0, 0xe13

    iget-object v2, p2, Lpp2;->a:Lmp2;

    nop

    const/16 v3, 0x207

    const/16 v0, 0x2f6

    invoke-virtual {v2, v3}, Lmp2;->f(I)Lxr0;

    move-result-object v4

    const/16 v5, 0x40

    const/16 v0, 0x2f6

    invoke-virtual {v2, v5}, Lmp2;->f(I)Lxr0;

    move-result-object v6

    const/16 v0, 0x365

    invoke-static {v4, v6}, Lxr0;->b(Lxr0;Lxr0;)Lxr0;

    move-result-object v4

    const/16 v0, 0x373

    invoke-virtual {v2, v3}, Lmp2;->g(I)Lxr0;

    move-result-object v3

    const/16 v0, 0x373

    invoke-virtual {v2, v5}, Lmp2;->g(I)Lxr0;

    move-result-object v2

    const/16 v0, 0x365

    invoke-static {v3, v2}, Lxr0;->b(Lxr0;Lxr0;)Lxr0;

    move-result-object v2

    const/16 v0, 0x7e1

    iget-object v3, p0, La92;->c:Lxr0;

    nop

    const/16 v0, 0x30b

    invoke-virtual {v4, v3}, Lxr0;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_53

    const/16 v0, 0x544

    iget-object v3, p0, La92;->d:Lxr0;

    nop

    const/16 v0, 0x30b

    invoke-virtual {v2, v3}, Lxr0;->equals(Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_88

    :cond_53
    const/16 v0, 0x1075

    iput-object v4, p0, La92;->c:Lxr0;

    const/16 v0, 0xa2c

    iput-object v2, p0, La92;->d:Lxr0;

    const/16 v0, 0xac

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p0

    add-int/lit8 p0, p0, -0x1

    :goto_63
    if-ltz p0, :cond_88

    const/16 v0, 0x43

    invoke-virtual {p1, p0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lco1;

    const/16 v0, 0x1033

    iget-object v2, v2, Lco1;->a:Ljava/util/ArrayList;

    nop

    const/16 v0, 0xac

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v3

    add-int/lit8 v3, v3, -0x1

    if-gez v3, :cond_7f

    add-int/lit8 p0, p0, -0x1

    goto :goto_63

    :cond_7f
    const/16 v0, 0xdb4

    invoke-static {v3, v2}, Ly41;->n(ILjava/util/ArrayList;)Ljava/lang/ClassCastException;

    move-result-object p0

    check-cast p0, Ljava/lang/Throwable;

    throw p0

    :cond_88
    return-object p2
.end method

.method public g()Ljava/lang/Object;
    .registers 8

    .prologue
    const/16 v0, 0xc68

    iget v2, p0, Lah;->a:I

    nop

    const/16 v0, 0xeac

    iget-object p0, p0, Lah;->b:Ljava/lang/Object;

    nop

    packed-switch v2, :pswitch_data_b8

    check-cast p0, Ljava/lang/Class;

    :try_start_f
    const/16 v0, 0xaaf

    sget-object v2, Lih2;->a:Lih2;

    nop

    const/16 v0, 0xdd5

    invoke-virtual {v2, p0}, Lih2;->a(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p0
    :try_end_1a
    .catch Ljava/lang/Exception; {:try_start_f .. :try_end_1a} :catch_1b

    return-object p0

    :catch_1b
    move-exception v2

    const/16 v0, 0x379

    new-instance v3, Ljava/lang/RuntimeException;

    nop

    const/4 v0, -0x3

    new-instance v4, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v5, "Unable to create instance of "

    const/16 v0, 0x97

    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x190

    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string/jumbo p0, ". Registering an InstanceCreator or a TypeAdapter for this type, or adding a no-args constructor may fix this problem."

    const/4 v0, 0x0

    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x2a1

    invoke-direct {v3, p0, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    check-cast v3, Ljava/lang/Throwable;

    throw v3

    :pswitch_46  #0x2
    check-cast p0, Ljava/lang/reflect/Constructor;

    const-string/jumbo v2, "\' with no args"

    const-string/jumbo v3, "Failed to invoke constructor \'"

    const/4 v4, 0x0

    :try_start_4f
    const/16 v0, 0xae2

    invoke-virtual {p0, v4}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4
    :try_end_55
    .catch Ljava/lang/InstantiationException; {:try_start_4f .. :try_end_55} :catch_8e
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_4f .. :try_end_55} :catch_65
    .catch Ljava/lang/IllegalAccessException; {:try_start_4f .. :try_end_55} :catch_56

    goto :goto_8d

    :catch_56
    move-exception p0

    const/16 v0, 0x1145

    sget-object v2, Lbs1;->a:Luz;

    nop

    const-string/jumbo v2, "Unexpected IllegalAccessException occurred (Gson 2.14.0). Certain ReflectionAccessFilter features require Java >= 9 to work correctly. If you are not using ReflectionAccessFilter, report this to the Gson maintainers."

    const/16 v0, 0x4d4

    invoke-static {v2, p0}, Lvx2;->k(Ljava/lang/String;Ljava/lang/Throwable;)V

    goto :goto_8d

    :catch_65
    move-exception v5

    const/4 v0, -0x3

    new-instance v6, Ljava/lang/StringBuilder;

    nop

    const/16 v0, 0x97

    invoke-direct {v6, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x2b6

    invoke-static {p0}, Lbs1;->b(Ljava/lang/reflect/Constructor;)Ljava/lang/String;

    move-result-object p0

    const/4 v0, 0x0

    invoke-virtual {v6, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x7d6

    invoke-virtual {v5}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;

    move-result-object v2

    const/16 v0, 0x4d4

    invoke-static {p0, v2}, Lvx2;->k(Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_8d
    return-object v4

    :catch_8e
    move-exception v4

    const/16 v0, 0x379

    new-instance v5, Ljava/lang/RuntimeException;

    nop

    const/16 v0, 0x2b6

    invoke-static {p0}, Lbs1;->b(Ljava/lang/reflect/Constructor;)Ljava/lang/String;

    move-result-object p0

    const/4 v0, -0x3

    new-instance v6, Ljava/lang/StringBuilder;

    nop

    const/16 v0, 0x97

    invoke-direct {v6, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v0, 0x0

    invoke-virtual {v6, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x2a1

    invoke-direct {v5, p0, v4}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    check-cast v5, Ljava/lang/Throwable;

    throw v5

    :pswitch_data_b8
    .packed-switch 0x2
        :pswitch_46  #00000002
    .end packed-switch
.end method

.method public h(Lk20;)Ljava/lang/Object;
    .registers 17

    const/16 v7, 0xeac

    iget-object p0, p0, Lah;->b:Ljava/lang/Object;

    nop

    check-cast p0, Lyo1;

    const/16 v7, 0x91f

    new-instance v9, Lw10;

    nop

    const-class v10, Landroid/content/Context;

    const/16 v7, 0x4e3

    move-object/from16 v0, p1

    invoke-virtual {v0, v10}, Lk20;->a(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Landroid/content/Context;

    const-class v11, Lee0;

    const/16 v7, 0x4e3

    move-object/from16 v0, p1

    invoke-virtual {v0, v11}, Lk20;->a(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object v11

    check-cast v11, Lee0;

    const/16 v7, 0xd6f

    invoke-virtual {v11}, Lee0;->c()Ljava/lang/String;

    move-result-object v11

    const-class v12, Lkn0;

    const/16 v7, 0xc27

    invoke-static {v12}, Lyo1;->a(Ljava/lang/Class;)Lyo1;

    move-result-object v12

    const/16 v7, 0x532

    move-object/from16 v0, p1

    invoke-virtual {v0, v12}, Lk20;->b(Lyo1;)Ljava/util/Set;

    move-result-object v12

    const-class v13, Lt20;

    const/16 v7, 0x1043

    move-object/from16 v0, p1

    invoke-virtual {v0, v13}, Lk20;->c(Ljava/lang/Class;)Lpo1;

    move-result-object v13

    const/16 v7, 0x5b8

    move-object/from16 v0, p1

    invoke-virtual {v0, p0}, Lk20;->f(Lyo1;)Ljava/lang/Object;

    move-result-object p0

    move-object v14, p0

    check-cast v14, Ljava/util/concurrent/Executor;

    const/16 v7, 0x9fa

    move v0, v7

    move-object v1, v9

    move-object v2, v10

    move-object v3, v11

    move-object v4, v12

    move-object v5, v13

    move-object v6, v14

    invoke-direct/range {v1 .. v6}, Lw10;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;Lpo1;Ljava/util/concurrent/Executor;)V

    check-cast v9, Ljava/lang/Object;

    return-object v9
.end method

.method public i(Loj0;ILandroid/os/Bundle;)Z
    .registers 12

    .prologue
    const/16 v0, 0xeac

    iget-object p0, p0, Lah;->b:Ljava/lang/Object;

    nop

    check-cast p0, Lyb;

    const/16 v0, 0x1fc

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 v3, 0x19

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-lt v2, v3, :cond_5a

    and-int/2addr p2, v5

    if-eqz p2, :cond_5a

    :try_start_15
    const/16 v0, 0x19e

    iget-object p2, p1, Loj0;->a:Ljava/lang/Object;

    nop

    check-cast p2, Lrr0;

    const/16 v0, 0x981

    invoke-interface {p2}, Lrr0;->b()V
    :try_end_21
    .catch Ljava/lang/Exception; {:try_start_15 .. :try_end_21} :catch_51

    const/16 v0, 0x19e

    iget-object p2, p1, Loj0;->a:Ljava/lang/Object;

    nop

    check-cast p2, Lrr0;

    const/16 v0, 0xf46

    invoke-interface {p2}, Lrr0;->d()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Landroid/os/Parcelable;

    if-nez p3, :cond_3d

    const/16 v0, 0x108

    new-instance p3, Landroid/os/Bundle;

    nop

    const/16 v0, 0x198

    invoke-direct {p3}, Landroid/os/Bundle;-><init>()V

    goto :goto_48

    :cond_3d
    const/16 v0, 0x108

    new-instance v3, Landroid/os/Bundle;

    nop

    const/16 v0, 0x1076

    invoke-direct {v3, p3}, Landroid/os/Bundle;-><init>(Landroid/os/Bundle;)V

    move-object p3, v3

    :goto_48
    const-string/jumbo v3, "androidx.core.view.extra.INPUT_CONTENT_INFO"

    const/16 v0, 0x9a

    invoke-virtual {p3, v3, p2}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    goto :goto_5a

    :catch_51
    move-exception p0

    const-string/jumbo p1, "InputConnectionCompat"

    const-string/jumbo p2, "Can\'t insert content from IME; requestPermission() failed"

    nop

    return v4

    :cond_5a
    :goto_5a
    const/16 v0, 0x1259

    new-instance p2, Landroid/content/ClipData;

    nop

    const/16 v0, 0x19e

    iget-object p1, p1, Loj0;->a:Ljava/lang/Object;

    nop

    check-cast p1, Lrr0;

    const/16 v0, 0xb35

    invoke-interface {p1}, Lrr0;->getDescription()Landroid/content/ClipDescription;

    move-result-object v3

    const/16 v0, 0xd76

    new-instance v6, Landroid/content/ClipData$Item;

    nop

    const/16 v0, 0xc88

    invoke-interface {p1}, Lrr0;->a()Landroid/net/Uri;

    move-result-object v7

    const/16 v0, 0x884

    invoke-direct {v6, v7}, Landroid/content/ClipData$Item;-><init>(Landroid/net/Uri;)V

    const/16 v0, 0xaff

    invoke-direct {p2, v3, v6}, Landroid/content/ClipData;-><init>(Landroid/content/ClipDescription;Landroid/content/ClipData$Item;)V

    const/16 v3, 0x1f

    const/4 v6, 0x2

    if-lt v2, v3, :cond_91

    const/16 v0, 0xfe8

    new-instance v2, Lkx;

    nop

    const/16 v0, 0xa35

    invoke-direct {v2, p2, v6}, Lkx;-><init>(Landroid/content/ClipData;I)V

    goto :goto_a3

    :cond_91
    const/16 v0, 0x6af

    new-instance v2, Lmx;

    nop

    const/16 v0, 0xd73

    invoke-direct {v2}, Lmx;-><init>()V

    const/16 v0, 0xdfe

    iput-object p2, v2, Lmx;->b:Landroid/content/ClipData;

    const/16 v0, 0x7ac

    iput v6, v2, Lmx;->c:I

    :goto_a3
    const/16 v0, 0xb44

    invoke-interface {p1}, Lrr0;->c()Landroid/net/Uri;

    move-result-object p1

    const/16 v0, 0xb10

    invoke-interface {v2, p1}, Llx;->b(Landroid/net/Uri;)V

    const/16 v0, 0xd5e

    invoke-interface {v2, p3}, Llx;->setExtras(Landroid/os/Bundle;)V

    const/16 v0, 0x7f0

    invoke-interface {v2}, Llx;->build()Lox;

    move-result-object p1

    const/16 v0, 0x8d9

    invoke-static {p0, p1}, Lek2;->k(Landroid/view/View;Lox;)Lox;

    move-result-object p0

    if-nez p0, :cond_c2

    return v5

    :cond_c2
    return v4
.end method

.method public onActivityResult(Ljava/lang/Object;)V
    .registers 8

    .prologue
    const/16 v0, 0xc68

    iget v2, p0, Lah;->a:I

    nop

    const/4 v3, 0x0

    const/4 v4, -0x1

    const/16 v0, 0xeac

    iget-object p0, p0, Lah;->b:Ljava/lang/Object;

    nop

    sparse-switch v2, :sswitch_data_196

    check-cast p0, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;

    check-cast p1, Li3;

    const/16 v0, 0xfe2

    sget v2, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;->o:I

    nop

    const/16 v0, 0x1bf

    iget v2, p1, Li3;->a:I

    nop

    const/16 v0, 0x37f

    iget-object p1, p1, Li3;->b:Landroid/content/Intent;

    nop

    if-ne v2, v4, :cond_5e

    if-eqz p1, :cond_5e

    const/16 v0, 0x187

    invoke-virtual {p1}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v2

    if-eqz v2, :cond_63

    const/16 v0, 0x5b

    new-instance v2, Landroid/content/Intent;

    nop

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    const-class v4, Lcom/tlsvpn/tlstunnel/ui/imex/Importar;

    const/16 v0, 0xd0

    invoke-direct {v2, v3, v4}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/16 v0, 0x187

    invoke-virtual {p1}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p1

    const/16 v0, 0x11c6

    invoke-virtual {v2, p1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    const-string/jumbo p1, "android.intent.action.VIEW"

    const/16 v0, 0x48f

    invoke-virtual {v2, p1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    const/16 v0, 0xc9

    invoke-virtual {p0, v2}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    const/16 v0, 0x107

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    goto :goto_63

    :cond_5e
    const/16 v0, 0x107

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    :cond_63
    :goto_63
    return-void

    :sswitch_64
    check-cast p0, Lcom/tlsvpn/tlstunnel/ui/Home;

    check-cast p1, Li3;

    const/16 v0, 0x1bf

    iget p1, p1, Li3;->a:I

    nop

    if-ne p1, v4, :cond_8c

    :try_start_6f
    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p1

    const/16 v0, 0x5b

    new-instance v2, Landroid/content/Intent;

    nop

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p0

    const-class v3, Lcom/tlsvpn/tlstunnel/services/ServicoVpn;

    const/16 v0, 0xd0

    invoke-direct {v2, p0, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/16 v0, 0x4a7

    invoke-virtual {p1, v2}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_8c
    .catch Ljava/lang/Exception; {:try_start_6f .. :try_end_8c} :catch_8c

    :catch_8c
    :cond_8c
    return-void

    :sswitch_8d
    check-cast p0, Lkc0;

    check-cast p1, Li3;

    const/16 v0, 0x1bf

    iget v2, p1, Li3;->a:I

    nop

    const/16 v0, 0x37f

    iget-object p1, p1, Li3;->b:Landroid/content/Intent;

    nop

    if-ne v2, v4, :cond_ed

    if-eqz p1, :cond_ed

    const/16 v0, 0x187

    invoke-virtual {p1}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v2

    if-eqz v2, :cond_ed

    const/16 v0, 0x187

    invoke-virtual {p1}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xd8a

    iput-object p1, p0, Lkc0;->U:Landroid/net/Uri;

    const/16 v0, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p1

    const/16 v0, 0x1d2

    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p1

    const/16 v0, 0x4f0

    iget-object v2, p0, Lkc0;->U:Landroid/net/Uri;

    nop

    if-eqz v2, :cond_e5

    const-string/jumbo v3, "wt"

    const/16 v0, 0xe1b

    invoke-virtual {p1, v2, v3}, Landroid/content/ContentResolver;->openOutputStream(Landroid/net/Uri;Ljava/lang/String;)Ljava/io/OutputStream;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x10fa

    iput-object p1, p0, Lkc0;->V:Ljava/io/OutputStream;

    const/16 v0, 0xd4c

    iget-boolean p1, p0, Lkc0;->S:Z

    nop

    const/4 v2, 0x0

    const/16 v0, 0x347

    invoke-virtual {p0, p1, v2}, Lkc0;->c(ZZ)V

    goto :goto_ed

    :cond_e5
    const-string/jumbo p0, "cfgfileUri"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_ed
    :goto_ed
    return-void

    :sswitch_ee
    check-cast p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;

    check-cast p1, Ljava/lang/Boolean;

    const/16 v0, 0x205

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    if-eqz p1, :cond_105

    const/16 v0, 0x3ad

    sget p1, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;->o:I

    nop

    const/16 v0, 0x337

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;->finish()V

    goto :goto_173

    :cond_105
    const/16 v0, 0x8da

    iget-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;->g:Landroidx/constraintlayout/widget/ConstraintLayout;

    nop

    if-eqz p1, :cond_18e

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const v4, 0x7f06041a

    const/16 v0, 0x52f

    invoke-static {v2, v4}, Lqx;->getDrawable(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v2

    const/16 v0, 0x2fd

    invoke-virtual {p1, v2}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/16 v0, 0x1c0

    iget-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;->l:Landroid/widget/LinearLayout;

    nop

    const-string/jumbo v2, "aplicar"

    if-eqz p1, :cond_189

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v4

    const v5, 0x7f08007d

    const/16 v0, 0x52f

    invoke-static {v4, v5}, Lqx;->getDrawable(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v4

    const/16 v0, 0x2fd

    invoke-virtual {p1, v4}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/16 v0, 0x2c7

    iget-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;->k:Landroid/widget/TextView;

    nop

    if-eqz p1, :cond_181

    const v4, 0x7f1301f5

    const/16 v0, 0x93

    invoke-virtual {p1, v4}, Landroid/widget/TextView;->setText(I)V

    const/16 v0, 0xee9

    iget-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;->m:Landroid/widget/TextView;

    nop

    if-eqz p1, :cond_179

    const v4, 0x7f1300e2

    const/16 v0, 0x93

    invoke-virtual {p1, v4}, Landroid/widget/TextView;->setText(I)V

    const/16 v0, 0x1c0

    iget-object p1, p0, Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;->l:Landroid/widget/LinearLayout;

    nop

    if-eqz p1, :cond_174

    const/16 v0, 0x2d5

    new-instance v2, Lzg;

    nop

    const/4 v3, 0x2

    const/16 v0, 0x2c8

    invoke-direct {v2, p0, v3}, Lzg;-><init>(Lcom/tlsvpn/tlstunnel/ui/dialogs/Aviso;I)V

    const/16 v0, 0x5f

    invoke-virtual {p1, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    :goto_173
    return-void

    :cond_174
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_179
    const-string/jumbo p0, "aplicartxt"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_181
    const-string/jumbo p0, "msginfo"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_189
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_18e
    const-string/jumbo p0, "toolbar"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :sswitch_data_196
    .sparse-switch
        0x0 -> :sswitch_ee
        0x5 -> :sswitch_8d
        0x7 -> :sswitch_64
    .end sparse-switch
.end method

.method public onCancel()V
    .registers 3

    const/16 v0, 0xeac

    iget-object p0, p0, Lah;->b:Ljava/lang/Object;

    nop

    check-cast p0, Landroidx/fragment/app/u;

    const/16 v0, 0x11e2

    invoke-virtual {p0}, Landroidx/fragment/app/u;->a()V

    return-void
.end method

.method public onComplete(Lcom/google/android/gms/tasks/Task;)V
    .registers 5

    const/16 v0, 0xeac

    iget-object p0, p0, Lah;->b:Ljava/lang/Object;

    nop

    check-cast p0, Lcom/tlsvpn/tlstunnel/MainActivity;

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x44d

    sget p1, Lcom/tlsvpn/tlstunnel/MainActivity;->m:I

    nop

    const/16 v0, 0x95

    invoke-virtual {p0}, Lcom/tlsvpn/tlstunnel/MainActivity;->j()Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x7a

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo p1, "reviewRequested"

    const/4 v2, 0x1

    const/16 v0, 0x48

    invoke-interface {p0, p1, v2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x6f

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void
.end method

.method public onProductDetailsResponse(Lcom/android/billingclient/api/BillingResult;Lcom/android/billingclient/api/QueryProductDetailsResult;)V
    .registers 22

    .prologue
    const/16 v9, 0xeac

    move-object/from16 v0, p0

    iget-object v9, v0, Lah;->b:Ljava/lang/Object;

    move-object/16 p0, v9

    move-object/from16 v12, p0

    check-cast v12, Lnn1;

    const/4 v9, -0x6

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v9, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v9, 0x450

    move-object/from16 v0, p1

    invoke-virtual {v0}, Lcom/android/billingclient/api/BillingResult;->getResponseCode()I

    move-result p0

    if-eqz p0, :cond_29

    const/16 v9, 0x3f4

    invoke-virtual {v12}, Lnn1;->d()V

    return-void

    :cond_29
    const/16 v9, 0xddb

    move-object/from16 v0, p2

    invoke-virtual {v0}, Lcom/android/billingclient/api/QueryProductDetailsResult;->getProductDetailsList()Ljava/util/List;

    move-result-object p0

    const/4 v9, -0x6

    move-object/from16 v0, p0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v9, 0x19f

    move-object/from16 v0, p0

    invoke-static {v0}, Lbs;->l0(Ljava/util/List;)Ljava/lang/Object;

    move-result-object p0

    move-object/from16 v17, p0

    check-cast v17, Lcom/android/billingclient/api/ProductDetails;

    const/16 p0, 0x0

    if-eqz v17, :cond_50

    const/16 v9, 0x110b

    move-object/from16 v0, v17

    invoke-virtual {v0}, Lcom/android/billingclient/api/ProductDetails;->getSubscriptionOfferDetails()Ljava/util/List;

    move-result-object p1

    goto :goto_52

    :cond_50
    move-object/from16 p1, p0

    :goto_52
    if-eqz v17, :cond_1af

    move-object/from16 p2, p1

    check-cast p2, Ljava/util/Collection;

    if-eqz p2, :cond_1af

    const/16 v9, 0xc4e

    move-object/from16 v0, p2

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result p2

    if-eqz p2, :cond_66

    goto/16 :goto_1af

    :cond_66
    check-cast p1, Ljava/lang/Iterable;

    const/16 v9, 0x429

    move-object/from16 v0, p1

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :cond_70
    const/16 v9, 0x13e

    move-object/from16 v0, p2

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v11

    if-eqz v11, :cond_97

    const/16 v9, 0x16e

    move-object/from16 v0, p2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v11

    move-object v13, v11

    check-cast v13, Lcom/android/billingclient/api/ProductDetails$SubscriptionOfferDetails;

    const/16 v9, 0x2ec

    invoke-virtual {v13}, Lcom/android/billingclient/api/ProductDetails$SubscriptionOfferDetails;->getBasePlanId()Ljava/lang/String;

    move-result-object v13

    const-string/jumbo v14, "p1m"

    const/16 v9, 0x84

    invoke-static {v13, v14}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_70

    goto :goto_99

    :cond_97
    move-object/from16 v11, p0

    :goto_99
    check-cast v11, Lcom/android/billingclient/api/ProductDetails$SubscriptionOfferDetails;

    const/16 v9, 0x429

    move-object/from16 v0, p1

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :cond_a3
    const/16 v9, 0x13e

    move-object/from16 v0, p1

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    if-eqz p2, :cond_cb

    const/16 v9, 0x16e

    move-object/from16 v0, p1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    move-object/from16 v13, p2

    check-cast v13, Lcom/android/billingclient/api/ProductDetails$SubscriptionOfferDetails;

    const/16 v9, 0x2ec

    invoke-virtual {v13}, Lcom/android/billingclient/api/ProductDetails$SubscriptionOfferDetails;->getBasePlanId()Ljava/lang/String;

    move-result-object v13

    const-string/jumbo v14, "p1y"

    const/16 v9, 0x84

    invoke-static {v13, v14}, Lgt0;->N(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_a3

    goto :goto_cd

    :cond_cb
    move-object/from16 p2, p0

    :goto_cd
    check-cast p2, Lcom/android/billingclient/api/ProductDetails$SubscriptionOfferDetails;

    const-string/jumbo p1, ""

    if-eqz v11, :cond_f6

    const/16 v9, 0x39d

    invoke-virtual {v11}, Lcom/android/billingclient/api/ProductDetails$SubscriptionOfferDetails;->getPricingPhases()Lcom/android/billingclient/api/ProductDetails$PricingPhases;

    move-result-object v13

    if-eqz v13, :cond_f6

    const/16 v9, 0x3d7

    invoke-virtual {v13}, Lcom/android/billingclient/api/ProductDetails$PricingPhases;->getPricingPhaseList()Ljava/util/List;

    move-result-object v13

    if-eqz v13, :cond_f6

    const/16 v9, 0x19f

    invoke-static {v13}, Lbs;->l0(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lcom/android/billingclient/api/ProductDetails$PricingPhase;

    if-eqz v13, :cond_f6

    const/16 v9, 0x47a

    invoke-virtual {v13}, Lcom/android/billingclient/api/ProductDetails$PricingPhase;->getFormattedPrice()Ljava/lang/String;

    move-result-object v13

    if-nez v13, :cond_f8

    :cond_f6
    move-object/from16 v13, p1

    :cond_f8
    if-eqz p2, :cond_11e

    const/16 v9, 0x39d

    move-object/from16 v0, p2

    invoke-virtual {v0}, Lcom/android/billingclient/api/ProductDetails$SubscriptionOfferDetails;->getPricingPhases()Lcom/android/billingclient/api/ProductDetails$PricingPhases;

    move-result-object v14

    if-eqz v14, :cond_11e

    const/16 v9, 0x3d7

    invoke-virtual {v14}, Lcom/android/billingclient/api/ProductDetails$PricingPhases;->getPricingPhaseList()Ljava/util/List;

    move-result-object v14

    if-eqz v14, :cond_11e

    const/16 v9, 0x19f

    invoke-static {v14}, Lbs;->l0(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Lcom/android/billingclient/api/ProductDetails$PricingPhase;

    if-eqz v14, :cond_11e

    const/16 v9, 0x47a

    invoke-virtual {v14}, Lcom/android/billingclient/api/ProductDetails$PricingPhase;->getFormattedPrice()Ljava/lang/String;

    move-result-object v14

    if-nez v14, :cond_120

    :cond_11e
    move-object/from16 v14, p1

    :cond_120
    if-eqz v11, :cond_12e

    const/16 v9, 0x326

    invoke-virtual {v11}, Lcom/android/billingclient/api/ProductDetails$SubscriptionOfferDetails;->getOfferToken()Ljava/lang/String;

    move-result-object v11

    if-nez v11, :cond_12b

    goto :goto_12e

    :cond_12b
    move-object/from16 v16, v11

    goto :goto_130

    :cond_12e
    :goto_12e
    move-object/from16 v16, p1

    :goto_130
    if-eqz p2, :cond_140

    const/16 v9, 0x326

    move-object/from16 v0, p2

    invoke-virtual {v0}, Lcom/android/billingclient/api/ProductDetails$SubscriptionOfferDetails;->getOfferToken()Ljava/lang/String;

    move-result-object p2

    if-nez p2, :cond_13d

    goto :goto_140

    :cond_13d
    move-object/from16 v15, p2

    goto :goto_142

    :cond_140
    :goto_140
    move-object/from16 v15, p1

    :goto_142
    const/16 v9, 0x25e

    iget-object v9, v12, Lnn1;->x:Landroid/widget/RadioGroup;

    move-object/16 p1, v9

    if-eqz p1, :cond_1a5

    const/16 v9, 0x817

    move-object/from16 v0, p1

    invoke-virtual {v0}, Landroid/widget/RadioGroup;->getCheckedRadioButtonId()I

    move-result p1

    const p2, 0x7f0902dc

    move/from16 v0, p1

    move/from16 v1, p2

    if-ne v0, v1, :cond_15f

    move-object/from16 p1, v15

    goto :goto_161

    :cond_15f
    move-object/from16 p1, v16

    :goto_161
    const/16 v9, 0x707

    move-object/from16 v0, p1

    iput-object v0, v12, Lnn1;->A:Ljava/lang/String;

    const/16 v9, 0x325

    invoke-virtual {v12}, Landroidx/fragment/app/Fragment;->getViewLifecycleOwner()Lh11;

    move-result-object p1

    const/4 v9, -0x6

    move-object/from16 v0, p1

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v9, 0x341

    move-object/from16 v0, p1

    invoke-static {v0}, Lns2;->m(Lh11;)Lc11;

    move-result-object p1

    const/16 v9, 0xb40

    new-instance v11, Lkn1;

    nop

    const/16 v18, 0x0

    const/16 v9, 0x9af

    move v0, v9

    move-object v1, v11

    move-object v2, v12

    move-object v3, v13

    move-object v4, v14

    move-object v5, v15

    move-object/from16 v6, v16

    move-object/from16 v7, v17

    move-object/from16 v8, v18

    invoke-direct/range {v1 .. v8}, Lkn1;-><init>(Lnn1;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/android/billingclient/api/ProductDetails;Lvx;)V

    const/16 p2, 0x3

    const/16 v9, 0xb3

    move v0, v9

    move-object/from16 v1, p1

    move-object/from16 v2, p0

    move-object/from16 v3, p0

    move-object v4, v11

    move/from16 v5, p2

    invoke-static/range {v1 .. v5}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    return-void

    :cond_1a5
    const-string/jumbo p1, "rgplanos"

    const/4 v9, 0x5

    move-object/from16 v0, p1

    invoke-static {v0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p0

    :cond_1af
    :goto_1af
    const/16 v9, 0x3f4

    invoke-virtual {v12}, Lnn1;->d()V

    return-void
.end method

.method public onSuccess(Landroidx/webkit/WebViewStartUpResult;)V
    .registers 7

    const/16 v0, 0xeac

    iget-object p0, p0, Lah;->b:Ljava/lang/Object;

    nop

    check-cast p0, Landroidx/webkit/WebViewCompat$WebViewStartUpCallback;

    const/16 v0, 0xac7

    sget-object v2, Landroidx/webkit/WebViewCompat;->a:Landroid/net/Uri;

    nop

    const/16 v0, 0x5d3

    new-instance v2, Landroid/os/Handler;

    nop

    const/16 v0, 0x1210

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v3

    const/16 v0, 0xad4

    invoke-direct {v2, v3}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/16 v0, 0xd45

    new-instance v3, Lu7;

    nop

    const/16 v4, 0x17

    const/16 v0, 0x1080

    invoke-direct {v3, v4, p0, p1}, Lu7;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    const/16 v0, 0x216

    invoke-virtual {v2, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    return-void
.end method

.method public onSuccess(Ljava/lang/Object;)V
    .registers 5

    .prologue
    const/16 v0, 0xc68

    iget v2, p0, Lah;->a:I

    nop

    const/16 v0, 0xeac

    iget-object p0, p0, Lah;->b:Ljava/lang/Object;

    nop

    packed-switch v2, :pswitch_data_32

    check-cast p0, Lcom/vungle/ads/internal/platform/c;

    check-cast p1, Lcom/google/android/gms/appset/AppSetIdInfo;

    const/16 v0, 0x5be

    invoke-static {p0, p1}, Lcom/vungle/ads/internal/platform/c;->a(Lcom/vungle/ads/internal/platform/c;Lcom/google/android/gms/appset/AppSetIdInfo;)V

    return-void

    :pswitch_17  #0xe
    check-cast p0, Le51;

    const/16 v0, 0x44d

    sget v2, Lcom/tlsvpn/tlstunnel/MainActivity;->m:I

    nop

    const/16 v0, 0x40e

    invoke-virtual {p0, p1}, Le51;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    :pswitch_24  #0xd
    check-cast p0, Le51;

    const/16 v0, 0x44d

    sget v2, Lcom/tlsvpn/tlstunnel/MainActivity;->m:I

    nop

    const/16 v0, 0x40e

    invoke-virtual {p0, p1}, Le51;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void

    nop

    :pswitch_data_32
    .packed-switch 0xd
        :pswitch_24  #0000000d
        :pswitch_17  #0000000e
    .end packed-switch
.end method

.method public run()V
    .registers 7

    .prologue
    const/16 v0, 0xc68

    iget v2, p0, Lah;->a:I

    nop

    const/16 v0, 0xeac

    iget-object p0, p0, Lah;->b:Ljava/lang/Object;

    nop

    packed-switch v2, :pswitch_data_3c

    check-cast p0, Lvu0;

    const/16 v0, 0x445

    iget-object v2, p0, Lvu0;->d:Lyu0;

    nop

    const/16 v0, 0x110d

    iget-object v3, v2, Lyu0;->f:Ljava/util/concurrent/atomic/AtomicInteger;

    nop

    const/4 v4, 0x1

    const/4 v5, 0x4

    const/16 v0, 0x10b4

    invoke-virtual {v3, v4, v5}, Ljava/util/concurrent/atomic/AtomicInteger;->compareAndSet(II)Z

    move-result v3

    if-eqz v3, :cond_32

    const/16 v0, 0x414

    iget-object p0, p0, Lvu0;->a:Lij2;

    nop

    const/16 v0, 0x386

    iget-object v3, v2, Lyu0;->o:Lyh2;

    nop

    const/16 v0, 0xc17

    invoke-virtual {p0, v2, v3}, Lij2;->onResponseStarted(Lorg/chromium/net/UrlRequest;Lorg/chromium/net/UrlResponseInfo;)V

    :cond_32
    return-void

    :pswitch_33  #0xa
    check-cast p0, Lqh2;

    const/16 v0, 0xc3d

    invoke-virtual {p0}, Lqh2;->close()V

    return-void

    nop

    :pswitch_data_3c
    .packed-switch 0xa
        :pswitch_33  #0000000a
    .end packed-switch
.end method
