.class public final synthetic Lj12;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic a:Ll12;

.field public final synthetic b:I


# direct methods
.method public synthetic constructor <init>(Ll12;I)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0xd9c

    iput-object p1, p0, Lj12;->a:Ll12;

    const/16 v0, 0x10e8

    iput p2, p0, Lj12;->b:I

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .registers 8

    const/16 v0, 0x821

    iget-object p1, p0, Lj12;->a:Ll12;

    nop

    const/16 v0, 0xa85

    iget-object v2, p1, Ll12;->c:Lg12;

    nop

    const/16 v0, 0x82f

    iget-object v3, v2, Lg12;->B:Ljava/util/ArrayList;

    nop

    const/16 v0, 0x44

    iget-object v4, p1, Ll12;->f:Ljava/util/ArrayList;

    nop

    const/16 v0, 0xaa7

    iget p0, p0, Lj12;->b:I

    nop

    const/16 v0, 0x43

    invoke-virtual {v4, p0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, La12;

    const/16 v0, 0x4ba

    iget-object v4, v4, La12;->a:Ljava/lang/String;

    nop

    const/16 v0, 0xef7

    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    const/16 v0, 0x5b

    new-instance v3, Landroid/content/Intent;

    nop

    const/16 v0, 0xfc6

    iget-object v4, p1, Ll12;->d:Landroid/content/Context;

    nop

    const-class v5, Lcom/tlsvpn/tlstunnel/ui/dialogs/Renew;

    const/16 v0, 0xd0

    invoke-direct {v3, v4, v5}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/16 v0, 0x44

    iget-object p1, p1, Ll12;->f:Ljava/util/ArrayList;

    nop

    const/16 v0, 0x43

    invoke-virtual {p1, p0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, La12;

    const/16 v0, 0x4ba

    iget-object p0, p0, La12;->a:Ljava/lang/String;

    nop

    const-string/jumbo p1, "serverh"

    const/16 v0, 0x4b

    invoke-virtual {v3, p1, p0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    const/16 v0, 0x634

    invoke-virtual {v2, p0}, Landroidx/fragment/app/Fragment;->startActivity(Landroid/content/Intent;)V

    return-void
.end method
