.class public final synthetic Lhc0;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# instance fields
.field public final synthetic a:Lkc0;

.field public final synthetic b:Z


# direct methods
.method public synthetic constructor <init>(Lkc0;Z)V
    .registers 5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0xd60

    iput-object p1, p0, Lhc0;->a:Lkc0;

    const/16 v0, 0x694

    iput-boolean p2, p0, Lhc0;->b:Z

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/content/DialogInterface;I)V
    .registers 6

    const/16 v0, 0xabb

    iget-boolean p2, p0, Lhc0;->b:Z

    nop

    const/4 v2, 0x1

    const/16 v0, 0xf6f

    iget-object p0, p0, Lhc0;->a:Lkc0;

    nop

    const/16 v0, 0x347

    invoke-virtual {p0, p2, v2}, Lkc0;->c(ZZ)V

    const/16 v0, 0x179

    invoke-interface {p1}, Landroid/content/DialogInterface;->dismiss()V

    return-void
.end method
