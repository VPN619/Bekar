.class public abstract Lhl1;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# static fields
.field public static final a:I


# direct methods
.method static constructor <clinit>()V
    .registers 3

    const/16 v0, 0x5a

    sget-object v2, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->a:Lcom/tlsvpn/tlstunnel/utils/SocketOps;

    nop

    const/16 v0, 0x598

    invoke-virtual {v2}, Lcom/tlsvpn/tlstunnel/utils/SocketOps;->z()I

    move-result v2

    const/16 v0, 0x109f

    sput v2, Lhl1;->a:I

    return-void
.end method
