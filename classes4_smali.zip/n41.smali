.class public final Ln41;
.super Lwx;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public t:Ljava/util/Iterator;

.field public u:I

.field public synthetic v:Ljava/lang/Object;

.field public final synthetic w:Lcom/tlsvpn/tlstunnel/ui/Logs;

.field public x:I


# direct methods
.method public constructor <init>(Lcom/tlsvpn/tlstunnel/ui/Logs;Lwx;)V
    .registers 5

    iput-object p1, p0, Ln41;->w:Lcom/tlsvpn/tlstunnel/ui/Logs;

    invoke-direct {p0, p2}, Lwx;-><init>(Lvx;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    const/16 v0, 0xf49

    iput-object p1, p0, Ln41;->v:Ljava/lang/Object;

    const/16 v0, 0x301

    iget p1, p0, Ln41;->x:I

    nop

    const/high16 v2, -0x80000000

    or-int/2addr p1, v2

    const/16 v0, 0x3ec

    iput p1, p0, Ln41;->x:I

    const/16 v0, 0xee3

    iget-object p1, p0, Ln41;->w:Lcom/tlsvpn/tlstunnel/ui/Logs;

    nop

    const/16 v0, 0x11a1

    invoke-virtual {p1, p0}, Lcom/tlsvpn/tlstunnel/ui/Logs;->d(Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
