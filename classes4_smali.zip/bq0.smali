.class public final Lbq0;
.super Lkk;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final q:Lw82;

.field public r:Landroid/widget/LinearLayout;

.field public s:Landroid/widget/LinearLayout;

.field public t:Landroid/widget/LinearLayout;


# direct methods
.method public constructor <init>()V
    .registers 5

    invoke-direct {p0}, Lkk;-><init>()V

    const/16 v0, 0xa84

    new-instance v2, Ld;

    nop

    const/16 v3, 0xb

    const/16 v0, 0x6cb

    invoke-direct {v2, v3, p0}, Ld;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x27a

    new-instance v3, Lw82;

    nop

    const/16 v0, 0x215

    invoke-direct {v3, v2}, Lw82;-><init>(Lzj0;)V

    const/16 v0, 0x1105

    iput-object v3, p0, Lbq0;->q:Lw82;

    return-void
.end method


# virtual methods
.method public final onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .registers 8

    .prologue
    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const p3, 0x7f0c003e

    const/4 v2, 0x0

    const/16 v0, 0x107b

    invoke-virtual {p1, p3, p2, v2}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    const p2, 0x7f090106

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/LinearLayout;

    const/16 v0, 0x8b9

    iput-object p2, p0, Lbq0;->r:Landroid/widget/LinearLayout;

    const p2, 0x7f09014e

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/LinearLayout;

    const/16 v0, 0xad5

    iput-object p2, p0, Lbq0;->s:Landroid/widget/LinearLayout;

    const p2, 0x7f0900a8

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/LinearLayout;

    const/16 v0, 0x5bb

    iput-object p2, p0, Lbq0;->t:Landroid/widget/LinearLayout;

    const/16 v0, 0xea3

    iget-object p2, p0, Lbq0;->r:Landroid/widget/LinearLayout;

    nop

    const/4 p3, 0x0

    if-eqz p2, :cond_c4

    const/16 v0, 0x278

    new-instance v3, Laq0;

    nop

    const/16 v0, 0x1cb

    invoke-direct {v3, p0, v2}, Laq0;-><init>(Lbq0;I)V

    const/16 v0, 0x5f

    invoke-virtual {p2, v3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0x785

    iget-object p2, p0, Lbq0;->s:Landroid/widget/LinearLayout;

    nop

    if-eqz p2, :cond_bc

    const/16 v0, 0x278

    new-instance v2, Laq0;

    nop

    const/4 v3, 0x1

    const/16 v0, 0x1cb

    invoke-direct {v2, p0, v3}, Laq0;-><init>(Lbq0;I)V

    const/16 v0, 0x5f

    invoke-virtual {p2, v2}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0xbef

    iget-object p2, p0, Lbq0;->t:Landroid/widget/LinearLayout;

    nop

    if-eqz p2, :cond_b4

    const/16 v0, 0x278

    new-instance p3, Laq0;

    nop

    const/4 v2, 0x2

    const/16 v0, 0x1cb

    invoke-direct {p3, p0, v2}, Laq0;-><init>(Lbq0;I)V

    const/16 v0, 0x5f

    invoke-virtual {p2, p3}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v0, 0x140

    sget-boolean p2, Lg4;->a:Z

    nop

    const/16 v0, 0xfb

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0xd10

    iget-object p0, p0, Lbq0;->q:Lw82;

    nop

    const/16 v0, 0x177

    invoke-virtual {p0}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/content/SharedPreferences;

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x394

    invoke-static {p0, p2}, Lg4;->n(Landroid/content/SharedPreferences;Landroidx/fragment/app/l;)V

    check-cast p1, Landroid/view/View;

    return-object p1

    :cond_b4
    const-string/jumbo p0, "clearcfg"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_bc
    const-string/jumbo p0, "importcfg"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_c4
    const-string/jumbo p0, "exportcfg"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3
.end method

.method public final onStart()V
    .registers 6

    .prologue
    const/16 v0, 0x55f

    invoke-super {p0}, Landroidx/fragment/app/g;->onStart()V

    const/16 v0, 0xaeb

    invoke-virtual {p0}, Landroidx/fragment/app/g;->getDialog()Landroid/app/Dialog;

    move-result-object v2

    instance-of v3, v2, Ljk;

    const/4 v4, 0x0

    if-eqz v3, :cond_13

    check-cast v2, Ljk;

    goto :goto_14

    :cond_13
    move-object v2, v4

    :goto_14
    if-eqz v2, :cond_1c

    const/16 v0, 0xff7

    invoke-virtual {v2}, Ljk;->f()Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    move-result-object v4

    :cond_1c
    const/16 v0, 0x1c6

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/16 v0, 0x84a

    invoke-virtual {p0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object p0

    const/16 v0, 0x8b5

    iget p0, p0, Landroid/content/res/Configuration;->orientation:I

    nop

    const/4 v2, 0x2

    if-ne p0, v2, :cond_3d

    if-eqz v4, :cond_3d

    const/4 p0, 0x3

    const/16 v0, 0x8a6

    invoke-virtual {v4, p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->L(I)V

    const/4 p0, 0x1

    const/16 v0, 0x1099

    iput-boolean p0, v4, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->K:Z

    :cond_3d
    return-void
.end method
