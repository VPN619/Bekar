.class public final Lpd;
.super Lwx;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public synthetic t:Ljava/lang/Object;

.field public final synthetic u:Lrd;

.field public v:I


# direct methods
.method public constructor <init>(Lrd;Lwx;)V
    .registers 5

    iput-object p1, p0, Lpd;->u:Lrd;

    invoke-direct {p0, p2}, Lwx;-><init>(Lvx;)V

    return-void
.end method


# virtual methods
.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    const/16 v0, 0x62f

    iput-object p1, p0, Lpd;->t:Ljava/lang/Object;

    const/16 v0, 0x2a8

    iget p1, p0, Lpd;->v:I

    nop

    const/high16 v2, -0x80000000

    or-int/2addr p1, v2

    const/16 v0, 0x364

    iput p1, p0, Lpd;->v:I

    const/16 v0, 0x1193

    iget-object p1, p0, Lpd;->u:Lrd;

    nop

    const/16 v0, 0xbd6

    invoke-virtual {p1, p0}, Lrd;->c(Lwx;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method
