.class public final Ltd;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lrr0;


# static fields
.field public static volatile e:Ltd;

.field public static final f:Ljava/lang/Object;


# instance fields
.field public final synthetic a:I

.field public b:Ljava/lang/Object;

.field public c:Ljava/lang/Object;

.field public d:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, Ltd;->f:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(I)V
    .registers 5

    .prologue
    iput p1, p0, Ltd;->a:I

    packed-switch p1, :pswitch_data_72

    :pswitch_5  #0x10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-string/jumbo p1, "AES/GCM/NoPadding"

    invoke-static {p1}, Ljavax/crypto/Cipher;->getInstance(Ljava/lang/String;)Ljavax/crypto/Cipher;

    move-result-object p1

    iput-object p1, p0, Ltd;->b:Ljava/lang/Object;

    sget-object p1, Lip;->a:Ljava/nio/charset/Charset;

    const-string/jumbo v0, "#%Gضdvσουρc3%2|\\3dừng4dA!"

    invoke-virtual {v0, p1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string/jumbo v1, "8jd2f%a~d[/¨$@|]·°²¹¬vd/°"

    invoke-virtual {v1, p1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    filled-new-array {v0, v1}, [[B

    move-result-object v0

    iput-object v0, p0, Ltd;->c:Ljava/lang/Object;

    const-string/jumbo v0, "ËG(FG2e3df|@4%aض23\\5FBạnHsF#"

    invoke-static {v0}, Lc72;->B0(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v0, p1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const-string/jumbo v1, "VxF°3DgKa$¨%·°s$5!²¹¬h00k"

    invoke-static {v1}, Lc72;->B0(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1, p1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p1

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    filled-new-array {v0, p1}, [[B

    move-result-object p1

    iput-object p1, p0, Ltd;->d:Ljava/lang/Object;

    return-void

    :pswitch_58  #0x11
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p1, Lib1;

    const/4 v0, 0x6

    invoke-direct {p1, v0}, Lib1;-><init>(I)V

    iput-object p1, p0, Ltd;->b:Ljava/lang/Object;

    return-void

    :pswitch_64  #0xf
    const/16 p1, 0xa

    new-array v0, p1, [J

    new-array v1, p1, [J

    new-array p1, p1, [J

    const/16 v2, 0xf

    invoke-direct {p0, v0, v1, p1, v2}, Ltd;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    return-void

    :pswitch_data_72
    .packed-switch 0xf
        :pswitch_64  #0000000f
        :pswitch_5  #00000010
        :pswitch_58  #00000011
    .end packed-switch
.end method

.method public synthetic constructor <init>(IZ)V
    .registers 3

    iput p1, p0, Ltd;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;I)V
    .registers 6

    .prologue
    iput p2, p0, Ltd;->a:I

    packed-switch p2, :pswitch_data_90

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    iput-object p1, p0, Ltd;->d:Ljava/lang/Object;

    new-instance p1, Ljava/util/HashSet;

    invoke-direct {p1}, Ljava/util/HashSet;-><init>()V

    iput-object p1, p0, Ltd;->c:Ljava/lang/Object;

    new-instance p1, Ljava/util/HashMap;

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    iput-object p1, p0, Ltd;->b:Ljava/lang/Object;

    return-void

    :pswitch_1d  #0x9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const-class p2, Lb71;

    invoke-virtual {p2}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object p2

    const v0, 0x7f040392

    invoke-static {p1, v0, p2}, Lnp3;->c0(Landroid/content/Context;ILjava/lang/String;)Landroid/util/TypedValue;

    move-result-object p2

    iget p2, p2, Landroid/util/TypedValue;->data:I

    sget-object v0, Lcp1;->v:[I

    invoke-virtual {p1, p2, v0}, Landroid/content/Context;->obtainStyledAttributes(I[I)Landroid/content/res/TypedArray;

    move-result-object p2

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-virtual {p2, v0, v1}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v0

    invoke-static {p1, v0}, Lam0;->l(Landroid/content/Context;I)Lam0;

    move-result-object v0

    iput-object v0, p0, Ltd;->b:Ljava/lang/Object;

    const/4 v0, 0x2

    invoke-virtual {p2, v0, v1}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v0

    invoke-static {p1, v0}, Lam0;->l(Landroid/content/Context;I)Lam0;

    const/4 v0, 0x3

    invoke-virtual {p2, v0, v1}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v0

    invoke-static {p1, v0}, Lam0;->l(Landroid/content/Context;I)Lam0;

    const/4 v0, 0x5

    invoke-virtual {p2, v0, v1}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v0

    invoke-static {p1, v0}, Lam0;->l(Landroid/content/Context;I)Lam0;

    const/4 v0, 0x7

    invoke-static {p1, p2, v0}, Llk;->n(Landroid/content/Context;Landroid/content/res/TypedArray;I)Landroid/content/res/ColorStateList;

    move-result-object v0

    const/16 v2, 0x9

    invoke-virtual {p2, v2, v1}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v2

    invoke-static {p1, v2}, Lam0;->l(Landroid/content/Context;I)Lam0;

    move-result-object v2

    iput-object v2, p0, Ltd;->c:Ljava/lang/Object;

    const/16 v2, 0x8

    invoke-virtual {p2, v2, v1}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v2

    invoke-static {p1, v2}, Lam0;->l(Landroid/content/Context;I)Lam0;

    const/16 v2, 0xa

    invoke-virtual {p2, v2, v1}, Landroid/content/res/TypedArray;->getResourceId(II)I

    move-result v1

    invoke-static {p1, v1}, Lam0;->l(Landroid/content/Context;I)Lam0;

    move-result-object p1

    iput-object p1, p0, Ltd;->d:Ljava/lang/Object;

    new-instance p0, Landroid/graphics/Paint;

    invoke-direct {p0}, Landroid/graphics/Paint;-><init>()V

    invoke-virtual {v0}, Landroid/content/res/ColorStateList;->getDefaultColor()I

    move-result p1

    invoke-virtual {p0, p1}, Landroid/graphics/Paint;->setColor(I)V

    invoke-virtual {p2}, Landroid/content/res/TypedArray;->recycle()V

    return-void

    nop

    :pswitch_data_90
    .packed-switch 0x9
        :pswitch_1d  #00000009
    .end packed-switch
.end method

.method public synthetic constructor <init>(Landroid/content/Context;Ljava/lang/Object;Ljava/lang/Object;I)V
    .registers 5

    iput p4, p0, Ltd;->a:I

    iput-object p1, p0, Ltd;->d:Ljava/lang/Object;

    iput-object p2, p0, Ltd;->b:Ljava/lang/Object;

    iput-object p3, p0, Ltd;->c:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Li61;Landroid/view/View;)V
    .registers 5

    .prologue
    const/16 v0, 0x16

    iput v0, p0, Ltd;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x22

    if-lt v0, v1, :cond_13

    new-instance v0, Ll61;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    goto :goto_1e

    :cond_13
    const/16 v1, 0x21

    if-lt v0, v1, :cond_1d

    new-instance v0, Lj61;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    goto :goto_1e

    :cond_1d
    const/4 v0, 0x0

    :goto_1e
    iput-object v0, p0, Ltd;->b:Ljava/lang/Object;

    iput-object p1, p0, Ltd;->c:Ljava/lang/Object;

    iput-object p2, p0, Ltd;->d:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Ljava/lang/Class;)V
    .registers 38

    move-object/from16 v0, p0

    const/16 v1, 0x1a

    iput v1, v0, Ltd;->a:I

    invoke-virtual/range {p1 .. p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object v1, v0, Ltd;->b:Ljava/lang/Object;

    new-instance v2, Lvq2;

    iget-object v1, v0, Ltd;->b:Ljava/lang/Object;

    check-cast v1, Ljava/util/UUID;

    invoke-virtual {v1}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual/range {p1 .. p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v5

    const/16 v34, 0x0

    const v35, 0x1fffffa

    const/4 v4, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const-wide/16 v9, 0x0

    const-wide/16 v11, 0x0

    const-wide/16 v13, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const-wide/16 v18, 0x0

    const-wide/16 v20, 0x0

    const-wide/16 v22, 0x0

    const-wide/16 v24, 0x0

    const/16 v26, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const-wide/16 v29, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    invoke-direct/range {v2 .. v35}, Lvq2;-><init>(Ljava/lang/String;Lmq2;Ljava/lang/String;Ljava/lang/String;Lw00;Lw00;JJJLyw;ILih;JJJJZLri1;IJIILjava/lang/String;Ljava/lang/Boolean;I)V

    iput-object v2, v0, Ltd;->c:Ljava/lang/Object;

    invoke-virtual/range {p1 .. p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    filled-new-array {v1}, [Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/util/LinkedHashSet;

    const/4 v3, 0x1

    invoke-static {v3}, Lb61;->Q(I)I

    move-result v3

    invoke-direct {v2, v3}, Ljava/util/LinkedHashSet;-><init>(I)V

    const/4 v3, 0x0

    aget-object v1, v1, v3

    invoke-interface {v2, v1}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    iput-object v2, v0, Ltd;->d:Ljava/lang/Object;

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .registers 5

    iput p4, p0, Ltd;->a:I

    iput-object p1, p0, Ltd;->b:Ljava/lang/Object;

    iput-object p2, p0, Ltd;->c:Ljava/lang/Object;

    iput-object p3, p0, Ltd;->d:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .registers 5

    const/16 v0, 0x17

    iput v0, p0, Ltd;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lfm0;

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lfm0;-><init>(IZ)V

    iput-object v0, p0, Ltd;->c:Ljava/lang/Object;

    iput-object v0, p0, Ltd;->d:Ljava/lang/Object;

    iput-object p1, p0, Ltd;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lkg1;)V
    .registers 26

    .prologue
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    const/16 v2, 0x19

    iput v2, v0, Ltd;->a:I

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    new-instance v2, Landroid/os/Bundle;

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    iput-object v2, v0, Ltd;->d:Ljava/lang/Object;

    iput-object v1, v0, Ltd;->c:Ljava/lang/Object;

    iget-object v2, v1, Lkg1;->a:Landroid/content/Context;

    iget-object v3, v1, Lkg1;->v:Ljava/util/ArrayList;

    iget-object v4, v1, Lkg1;->c:Ljava/util/ArrayList;

    iget-object v5, v1, Lkg1;->d:Ljava/util/ArrayList;

    sget v6, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v7, 0x1a

    if-lt v6, v7, :cond_30

    iget-object v6, v1, Lkg1;->s:Ljava/lang/String;

    invoke-static {v2, v6}, Lja;->e(Landroid/content/Context;Ljava/lang/String;)Landroid/app/Notification$Builder;

    move-result-object v2

    iput-object v2, v0, Ltd;->b:Ljava/lang/Object;

    goto :goto_38

    :cond_30
    new-instance v6, Landroid/app/Notification$Builder;

    invoke-direct {v6, v2}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;)V

    iput-object v6, v0, Ltd;->b:Ljava/lang/Object;

    move-object v2, v6

    :goto_38
    iget-object v6, v1, Lkg1;->u:Landroid/app/Notification;

    iget-wide v8, v6, Landroid/app/Notification;->when:J

    invoke-virtual {v2, v8, v9}, Landroid/app/Notification$Builder;->setWhen(J)Landroid/app/Notification$Builder;

    move-result-object v8

    iget v9, v6, Landroid/app/Notification;->icon:I

    iget v10, v6, Landroid/app/Notification;->iconLevel:I

    invoke-virtual {v8, v9, v10}, Landroid/app/Notification$Builder;->setSmallIcon(II)Landroid/app/Notification$Builder;

    move-result-object v8

    iget-object v9, v6, Landroid/app/Notification;->contentView:Landroid/widget/RemoteViews;

    invoke-virtual {v8, v9}, Landroid/app/Notification$Builder;->setContent(Landroid/widget/RemoteViews;)Landroid/app/Notification$Builder;

    move-result-object v8

    iget-object v9, v6, Landroid/app/Notification;->tickerText:Ljava/lang/CharSequence;

    const/4 v10, 0x0

    invoke-virtual {v8, v9, v10}, Landroid/app/Notification$Builder;->setTicker(Ljava/lang/CharSequence;Landroid/widget/RemoteViews;)Landroid/app/Notification$Builder;

    move-result-object v8

    iget-object v9, v6, Landroid/app/Notification;->vibrate:[J

    invoke-virtual {v8, v9}, Landroid/app/Notification$Builder;->setVibrate([J)Landroid/app/Notification$Builder;

    move-result-object v8

    iget v9, v6, Landroid/app/Notification;->ledARGB:I

    iget v11, v6, Landroid/app/Notification;->ledOnMS:I

    iget v12, v6, Landroid/app/Notification;->ledOffMS:I

    invoke-virtual {v8, v9, v11, v12}, Landroid/app/Notification$Builder;->setLights(III)Landroid/app/Notification$Builder;

    move-result-object v8

    iget v9, v6, Landroid/app/Notification;->flags:I

    and-int/lit8 v9, v9, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x1

    if-eqz v9, :cond_6f

    move v9, v12

    goto :goto_70

    :cond_6f
    move v9, v11

    :goto_70
    invoke-virtual {v8, v9}, Landroid/app/Notification$Builder;->setOngoing(Z)Landroid/app/Notification$Builder;

    move-result-object v8

    iget v9, v6, Landroid/app/Notification;->flags:I

    and-int/lit8 v9, v9, 0x8

    if-eqz v9, :cond_7c

    move v9, v12

    goto :goto_7d

    :cond_7c
    move v9, v11

    :goto_7d
    invoke-virtual {v8, v9}, Landroid/app/Notification$Builder;->setOnlyAlertOnce(Z)Landroid/app/Notification$Builder;

    move-result-object v8

    iget v9, v6, Landroid/app/Notification;->flags:I

    and-int/lit8 v9, v9, 0x10

    if-eqz v9, :cond_89

    move v9, v12

    goto :goto_8a

    :cond_89
    move v9, v11

    :goto_8a
    invoke-virtual {v8, v9}, Landroid/app/Notification$Builder;->setAutoCancel(Z)Landroid/app/Notification$Builder;

    move-result-object v8

    iget v9, v6, Landroid/app/Notification;->defaults:I

    invoke-virtual {v8, v9}, Landroid/app/Notification$Builder;->setDefaults(I)Landroid/app/Notification$Builder;

    move-result-object v8

    iget-object v9, v1, Lkg1;->e:Ljava/lang/CharSequence;

    invoke-virtual {v8, v9}, Landroid/app/Notification$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v8

    iget-object v9, v1, Lkg1;->f:Ljava/lang/CharSequence;

    invoke-virtual {v8, v9}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v8

    invoke-virtual {v8, v10}, Landroid/app/Notification$Builder;->setContentInfo(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v8

    iget-object v9, v1, Lkg1;->g:Landroid/app/PendingIntent;

    invoke-virtual {v8, v9}, Landroid/app/Notification$Builder;->setContentIntent(Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;

    move-result-object v8

    iget-object v9, v6, Landroid/app/Notification;->deleteIntent:Landroid/app/PendingIntent;

    invoke-virtual {v8, v9}, Landroid/app/Notification$Builder;->setDeleteIntent(Landroid/app/PendingIntent;)Landroid/app/Notification$Builder;

    move-result-object v8

    iget v9, v6, Landroid/app/Notification;->flags:I

    and-int/lit16 v9, v9, 0x80

    if-eqz v9, :cond_b7

    goto :goto_b8

    :cond_b7
    move v12, v11

    :goto_b8
    invoke-virtual {v8, v10, v12}, Landroid/app/Notification$Builder;->setFullScreenIntent(Landroid/app/PendingIntent;Z)Landroid/app/Notification$Builder;

    move-result-object v8

    invoke-virtual {v8, v11}, Landroid/app/Notification$Builder;->setNumber(I)Landroid/app/Notification$Builder;

    move-result-object v8

    invoke-virtual {v8, v11, v11, v11}, Landroid/app/Notification$Builder;->setProgress(IIZ)Landroid/app/Notification$Builder;

    invoke-virtual {v2, v10}, Landroid/app/Notification$Builder;->setLargeIcon(Landroid/graphics/drawable/Icon;)Landroid/app/Notification$Builder;

    invoke-virtual {v2, v10}, Landroid/app/Notification$Builder;->setSubText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    move-result-object v2

    iget-boolean v8, v1, Lkg1;->j:Z

    invoke-virtual {v2, v8}, Landroid/app/Notification$Builder;->setUsesChronometer(Z)Landroid/app/Notification$Builder;

    move-result-object v2

    iget v8, v1, Lkg1;->h:I

    invoke-virtual {v2, v8}, Landroid/app/Notification$Builder;->setPriority(I)Landroid/app/Notification$Builder;

    iget-object v2, v1, Lkg1;->b:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v8

    move v9, v11

    :goto_dc
    const-string/jumbo v12, "android.support.allowGeneratedReplies"

    const-string/jumbo v14, ""

    if-ge v9, v8, :cond_1ec

    invoke-virtual {v2, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v16

    add-int/lit8 v9, v9, 0x1

    move-object/from16 v11, v16

    check-cast v11, Leg1;

    iget-object v10, v11, Leg1;->b:Landroidx/core/graphics/drawable/IconCompat;

    if-nez v10, :cond_fc

    iget v15, v11, Leg1;->h:I

    if-eqz v15, :cond_fc

    invoke-static {v15, v14}, Landroidx/core/graphics/drawable/IconCompat;->a(ILjava/lang/String;)Landroidx/core/graphics/drawable/IconCompat;

    move-result-object v10

    iput-object v10, v11, Leg1;->b:Landroidx/core/graphics/drawable/IconCompat;

    :cond_fc
    iget v14, v11, Leg1;->f:I

    iget-boolean v15, v11, Leg1;->d:Z

    iget-object v13, v11, Leg1;->a:Landroid/os/Bundle;

    if-eqz v10, :cond_109

    invoke-static {v10}, Lt12;->X(Landroidx/core/graphics/drawable/IconCompat;)Landroid/graphics/drawable/Icon;

    move-result-object v10

    goto :goto_10a

    :cond_109
    const/4 v10, 0x0

    :goto_10a
    iget-object v7, v11, Leg1;->i:Ljava/lang/CharSequence;

    move-object/from16 v17, v2

    iget-object v2, v11, Leg1;->j:Landroid/app/PendingIntent;

    move/from16 v18, v8

    new-instance v8, Landroid/app/Notification$Action$Builder;

    invoke-direct {v8, v10, v7, v2}, Landroid/app/Notification$Action$Builder;-><init>(Landroid/graphics/drawable/Icon;Ljava/lang/CharSequence;Landroid/app/PendingIntent;)V

    iget-object v2, v11, Leg1;->c:[Lxs1;

    if-eqz v2, :cond_190

    array-length v7, v2

    new-array v10, v7, [Landroid/app/RemoteInput;

    move/from16 v19, v9

    move-object/from16 v20, v10

    const/4 v9, 0x0

    :goto_123
    array-length v10, v2

    if-ge v9, v10, :cond_183

    aget-object v10, v2, v9

    move-object/from16 v21, v2

    new-instance v2, Landroid/app/RemoteInput$Builder;

    move/from16 v22, v9

    iget-object v9, v10, Lxs1;->a:Ljava/lang/String;

    invoke-direct {v2, v9}, Landroid/app/RemoteInput$Builder;-><init>(Ljava/lang/String;)V

    iget-object v9, v10, Lxs1;->b:Ljava/lang/CharSequence;

    invoke-virtual {v2, v9}, Landroid/app/RemoteInput$Builder;->setLabel(Ljava/lang/CharSequence;)Landroid/app/RemoteInput$Builder;

    move-result-object v2

    iget-object v9, v10, Lxs1;->c:[Ljava/lang/CharSequence;

    invoke-virtual {v2, v9}, Landroid/app/RemoteInput$Builder;->setChoices([Ljava/lang/CharSequence;)Landroid/app/RemoteInput$Builder;

    move-result-object v2

    iget-boolean v9, v10, Lxs1;->d:Z

    invoke-virtual {v2, v9}, Landroid/app/RemoteInput$Builder;->setAllowFreeFormInput(Z)Landroid/app/RemoteInput$Builder;

    move-result-object v2

    iget-object v9, v10, Lxs1;->f:Landroid/os/Bundle;

    invoke-virtual {v2, v9}, Landroid/app/RemoteInput$Builder;->addExtras(Landroid/os/Bundle;)Landroid/app/RemoteInput$Builder;

    move-result-object v2

    sget v9, Landroid/os/Build$VERSION;->SDK_INT:I

    move-object/from16 v23, v5

    const/16 v5, 0x1a

    if-lt v9, v5, :cond_16b

    iget-object v5, v10, Lxs1;->g:Ljava/util/Set;

    if-eqz v5, :cond_16b

    invoke-interface {v5}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v5

    :goto_15b
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v9

    if-eqz v9, :cond_16b

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    invoke-static {v2, v9}, Lja;->v(Landroid/app/RemoteInput$Builder;Ljava/lang/String;)V

    goto :goto_15b

    :cond_16b
    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v9, 0x1d

    if-lt v5, v9, :cond_176

    iget v5, v10, Lxs1;->e:I

    invoke-static {v2, v5}, Lla;->s(Landroid/app/RemoteInput$Builder;I)V

    :cond_176
    invoke-virtual {v2}, Landroid/app/RemoteInput$Builder;->build()Landroid/app/RemoteInput;

    move-result-object v2

    aput-object v2, v20, v22

    add-int/lit8 v9, v22, 0x1

    move-object/from16 v2, v21

    move-object/from16 v5, v23

    goto :goto_123

    :cond_183
    move-object/from16 v23, v5

    const/4 v2, 0x0

    :goto_186
    if-ge v2, v7, :cond_194

    aget-object v5, v20, v2

    invoke-virtual {v8, v5}, Landroid/app/Notification$Action$Builder;->addRemoteInput(Landroid/app/RemoteInput;)Landroid/app/Notification$Action$Builder;

    add-int/lit8 v2, v2, 0x1

    goto :goto_186

    :cond_190
    move-object/from16 v23, v5

    move/from16 v19, v9

    :cond_194
    if-eqz v13, :cond_19c

    new-instance v2, Landroid/os/Bundle;

    invoke-direct {v2, v13}, Landroid/os/Bundle;-><init>(Landroid/os/Bundle;)V

    goto :goto_1a1

    :cond_19c
    new-instance v2, Landroid/os/Bundle;

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    :goto_1a1
    invoke-virtual {v2, v12, v15}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    invoke-virtual {v8, v15}, Landroid/app/Notification$Action$Builder;->setAllowGeneratedReplies(Z)Landroid/app/Notification$Action$Builder;

    const-string/jumbo v5, "android.support.action.semanticAction"

    invoke-virtual {v2, v5, v14}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    sget v5, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v7, 0x1c

    if-lt v5, v7, :cond_1b6

    invoke-static {v8, v14}, Lea;->A(Landroid/app/Notification$Action$Builder;I)V

    :cond_1b6
    const/16 v9, 0x1d

    if-lt v5, v9, :cond_1bf

    iget-boolean v7, v11, Leg1;->g:Z

    invoke-static {v8, v7}, Lla;->r(Landroid/app/Notification$Action$Builder;Z)V

    :cond_1bf
    const/16 v7, 0x1f

    if-lt v5, v7, :cond_1c8

    iget-boolean v5, v11, Leg1;->k:Z

    invoke-static {v8, v5}, Ljf1;->e(Landroid/app/Notification$Action$Builder;Z)V

    :cond_1c8
    const-string/jumbo v5, "android.support.action.showsUserInterface"

    iget-boolean v7, v11, Leg1;->e:Z

    invoke-virtual {v2, v5, v7}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    invoke-virtual {v8, v2}, Landroid/app/Notification$Action$Builder;->addExtras(Landroid/os/Bundle;)Landroid/app/Notification$Action$Builder;

    iget-object v2, v0, Ltd;->b:Ljava/lang/Object;

    check-cast v2, Landroid/app/Notification$Builder;

    invoke-virtual {v8}, Landroid/app/Notification$Action$Builder;->build()Landroid/app/Notification$Action;

    move-result-object v5

    invoke-virtual {v2, v5}, Landroid/app/Notification$Builder;->addAction(Landroid/app/Notification$Action;)Landroid/app/Notification$Builder;

    move-object/from16 v2, v17

    move/from16 v8, v18

    move/from16 v9, v19

    move-object/from16 v5, v23

    const/16 v7, 0x1a

    const/4 v10, 0x0

    const/4 v11, 0x0

    goto/16 :goto_dc

    :cond_1ec
    move-object/from16 v23, v5

    iget-object v2, v1, Lkg1;->q:Landroid/os/Bundle;

    if-eqz v2, :cond_1f9

    iget-object v5, v0, Ltd;->d:Ljava/lang/Object;

    check-cast v5, Landroid/os/Bundle;

    invoke-virtual {v5, v2}, Landroid/os/Bundle;->putAll(Landroid/os/Bundle;)V

    :cond_1f9
    iget-object v2, v0, Ltd;->b:Ljava/lang/Object;

    check-cast v2, Landroid/app/Notification$Builder;

    iget-boolean v5, v1, Lkg1;->i:Z

    invoke-virtual {v2, v5}, Landroid/app/Notification$Builder;->setShowWhen(Z)Landroid/app/Notification$Builder;

    iget-object v2, v0, Ltd;->b:Ljava/lang/Object;

    check-cast v2, Landroid/app/Notification$Builder;

    iget-boolean v5, v1, Lkg1;->m:Z

    invoke-virtual {v2, v5}, Landroid/app/Notification$Builder;->setLocalOnly(Z)Landroid/app/Notification$Builder;

    iget-object v2, v0, Ltd;->b:Ljava/lang/Object;

    check-cast v2, Landroid/app/Notification$Builder;

    iget-object v5, v1, Lkg1;->l:Ljava/lang/String;

    invoke-virtual {v2, v5}, Landroid/app/Notification$Builder;->setGroup(Ljava/lang/String;)Landroid/app/Notification$Builder;

    iget-object v2, v0, Ltd;->b:Ljava/lang/Object;

    check-cast v2, Landroid/app/Notification$Builder;

    const/4 v5, 0x0

    invoke-virtual {v2, v5}, Landroid/app/Notification$Builder;->setSortKey(Ljava/lang/String;)Landroid/app/Notification$Builder;

    iget-object v2, v0, Ltd;->b:Ljava/lang/Object;

    check-cast v2, Landroid/app/Notification$Builder;

    const/4 v5, 0x0

    invoke-virtual {v2, v5}, Landroid/app/Notification$Builder;->setGroupSummary(Z)Landroid/app/Notification$Builder;

    iget-object v2, v0, Ltd;->b:Ljava/lang/Object;

    check-cast v2, Landroid/app/Notification$Builder;

    iget-object v7, v1, Lkg1;->p:Ljava/lang/String;

    invoke-virtual {v2, v7}, Landroid/app/Notification$Builder;->setCategory(Ljava/lang/String;)Landroid/app/Notification$Builder;

    iget-object v2, v0, Ltd;->b:Ljava/lang/Object;

    check-cast v2, Landroid/app/Notification$Builder;

    iget v7, v1, Lkg1;->r:I

    invoke-virtual {v2, v7}, Landroid/app/Notification$Builder;->setColor(I)Landroid/app/Notification$Builder;

    iget-object v2, v0, Ltd;->b:Ljava/lang/Object;

    check-cast v2, Landroid/app/Notification$Builder;

    invoke-virtual {v2, v5}, Landroid/app/Notification$Builder;->setVisibility(I)Landroid/app/Notification$Builder;

    iget-object v2, v0, Ltd;->b:Ljava/lang/Object;

    check-cast v2, Landroid/app/Notification$Builder;

    const/4 v5, 0x0

    invoke-virtual {v2, v5}, Landroid/app/Notification$Builder;->setPublicVersion(Landroid/app/Notification;)Landroid/app/Notification$Builder;

    iget-object v2, v0, Ltd;->b:Ljava/lang/Object;

    check-cast v2, Landroid/app/Notification$Builder;

    iget-object v5, v6, Landroid/app/Notification;->sound:Landroid/net/Uri;

    iget-object v6, v6, Landroid/app/Notification;->audioAttributes:Landroid/media/AudioAttributes;

    invoke-virtual {v2, v5, v6}, Landroid/app/Notification$Builder;->setSound(Landroid/net/Uri;Landroid/media/AudioAttributes;)Landroid/app/Notification$Builder;

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v7, 0x1c

    if-ge v2, v7, :cond_2b0

    if-nez v4, :cond_25a

    const/4 v2, 0x0

    goto :goto_290

    :cond_25a
    new-instance v2, Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v5

    invoke-direct {v2, v5}, Ljava/util/ArrayList;-><init>(I)V

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v5

    const/4 v6, 0x0

    :goto_268
    if-ge v6, v5, :cond_290

    invoke-virtual {v4, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v7

    add-int/lit8 v6, v6, 0x1

    check-cast v7, Lxj1;

    iget-object v8, v7, Lxj1;->a:Ljava/lang/CharSequence;

    iget-object v7, v7, Lxj1;->c:Ljava/lang/String;

    if-eqz v7, :cond_279

    goto :goto_28c

    :cond_279
    if-eqz v8, :cond_28b

    new-instance v7, Ljava/lang/StringBuilder;

    const-string/jumbo v9, "name:"

    invoke-direct {v7, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    goto :goto_28c

    :cond_28b
    move-object v7, v14

    :goto_28c
    invoke-virtual {v2, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_268

    :cond_290
    :goto_290
    if-nez v2, :cond_293

    goto :goto_2b0

    :cond_293
    if-nez v3, :cond_297

    move-object v3, v2

    goto :goto_2b0

    :cond_297
    new-instance v5, Lxe;

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v6

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v7

    add-int/2addr v7, v6

    invoke-direct {v5, v7}, Lxe;-><init>(I)V

    invoke-virtual {v5, v2}, Lxe;->addAll(Ljava/util/Collection;)Z

    invoke-virtual {v5, v3}, Lxe;->addAll(Ljava/util/Collection;)Z

    new-instance v3, Ljava/util/ArrayList;

    invoke-direct {v3, v5}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    :cond_2b0
    :goto_2b0
    if-eqz v3, :cond_2cf

    invoke-interface {v3}, Ljava/util/List;->isEmpty()Z

    move-result v2

    if-nez v2, :cond_2cf

    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v5, 0x0

    :goto_2bd
    if-ge v5, v2, :cond_2cf

    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    add-int/lit8 v5, v5, 0x1

    check-cast v6, Ljava/lang/String;

    iget-object v7, v0, Ltd;->b:Ljava/lang/Object;

    check-cast v7, Landroid/app/Notification$Builder;

    invoke-virtual {v7, v6}, Landroid/app/Notification$Builder;->addPerson(Ljava/lang/String;)Landroid/app/Notification$Builder;

    goto :goto_2bd

    :cond_2cf
    invoke-virtual/range {v23 .. v23}, Ljava/util/ArrayList;->size()I

    move-result v2

    if-lez v2, :cond_418

    iget-object v2, v1, Lkg1;->q:Landroid/os/Bundle;

    if-nez v2, :cond_2e0

    new-instance v2, Landroid/os/Bundle;

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    iput-object v2, v1, Lkg1;->q:Landroid/os/Bundle;

    :cond_2e0
    const-string/jumbo v3, "android.car.EXTENSIONS"

    invoke-virtual {v2, v3}, Landroid/os/Bundle;->getBundle(Ljava/lang/String;)Landroid/os/Bundle;

    move-result-object v2

    if-nez v2, :cond_2ee

    new-instance v2, Landroid/os/Bundle;

    invoke-direct {v2}, Landroid/os/Bundle;-><init>()V

    :cond_2ee
    new-instance v5, Landroid/os/Bundle;

    invoke-direct {v5, v2}, Landroid/os/Bundle;-><init>(Landroid/os/Bundle;)V

    new-instance v6, Landroid/os/Bundle;

    invoke-direct {v6}, Landroid/os/Bundle;-><init>()V

    const/4 v7, 0x0

    :goto_2f9
    invoke-virtual/range {v23 .. v23}, Ljava/util/ArrayList;->size()I

    move-result v8

    if-ge v7, v8, :cond_3fa

    invoke-static {v7}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v8

    move-object/from16 v9, v23

    invoke-virtual {v9, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Leg1;

    new-instance v11, Landroid/os/Bundle;

    invoke-direct {v11}, Landroid/os/Bundle;-><init>()V

    iget-object v13, v10, Leg1;->b:Landroidx/core/graphics/drawable/IconCompat;

    if-nez v13, :cond_31e

    iget v15, v10, Leg1;->h:I

    if-eqz v15, :cond_31e

    invoke-static {v15, v14}, Landroidx/core/graphics/drawable/IconCompat;->a(ILjava/lang/String;)Landroidx/core/graphics/drawable/IconCompat;

    move-result-object v13

    iput-object v13, v10, Leg1;->b:Landroidx/core/graphics/drawable/IconCompat;

    :cond_31e
    iget-object v15, v10, Leg1;->a:Landroid/os/Bundle;

    if-eqz v13, :cond_329

    invoke-virtual {v13}, Landroidx/core/graphics/drawable/IconCompat;->b()I

    move-result v13

    :goto_326
    move/from16 v17, v7

    goto :goto_32b

    :cond_329
    const/4 v13, 0x0

    goto :goto_326

    :goto_32b
    const-string/jumbo v7, "icon"

    invoke-virtual {v11, v7, v13}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const-string/jumbo v7, "title"

    iget-object v13, v10, Leg1;->i:Ljava/lang/CharSequence;

    invoke-virtual {v11, v7, v13}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    const-string/jumbo v7, "actionIntent"

    iget-object v13, v10, Leg1;->j:Landroid/app/PendingIntent;

    invoke-virtual {v11, v7, v13}, Landroid/os/Bundle;->putParcelable(Ljava/lang/String;Landroid/os/Parcelable;)V

    if-eqz v15, :cond_349

    new-instance v7, Landroid/os/Bundle;

    invoke-direct {v7, v15}, Landroid/os/Bundle;-><init>(Landroid/os/Bundle;)V

    goto :goto_34e

    :cond_349
    new-instance v7, Landroid/os/Bundle;

    invoke-direct {v7}, Landroid/os/Bundle;-><init>()V

    :goto_34e
    iget-boolean v13, v10, Leg1;->d:Z

    invoke-virtual {v7, v12, v13}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const-string/jumbo v13, "extras"

    invoke-virtual {v11, v13, v7}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    iget-object v7, v10, Leg1;->c:[Lxs1;

    if-nez v7, :cond_366

    move-object/from16 v23, v9

    move-object/from16 v18, v12

    const/4 v15, 0x0

    :cond_362
    move-object/from16 v21, v14

    goto/16 :goto_3d9

    :cond_366
    array-length v15, v7

    new-array v15, v15, [Landroid/os/Bundle;

    move-object/from16 v23, v9

    move-object/from16 v18, v12

    const/4 v9, 0x0

    :goto_36e
    array-length v12, v7

    if-ge v9, v12, :cond_362

    aget-object v12, v7, v9

    move-object/from16 v19, v7

    new-instance v7, Landroid/os/Bundle;

    invoke-direct {v7}, Landroid/os/Bundle;-><init>()V

    move/from16 v20, v9

    const-string/jumbo v9, "resultKey"

    move-object/from16 v21, v14

    iget-object v14, v12, Lxs1;->a:Ljava/lang/String;

    invoke-virtual {v7, v9, v14}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const-string/jumbo v9, "label"

    iget-object v14, v12, Lxs1;->b:Ljava/lang/CharSequence;

    invoke-virtual {v7, v9, v14}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    const-string/jumbo v9, "choices"

    iget-object v14, v12, Lxs1;->c:[Ljava/lang/CharSequence;

    invoke-virtual {v7, v9, v14}, Landroid/os/Bundle;->putCharSequenceArray(Ljava/lang/String;[Ljava/lang/CharSequence;)V

    const-string/jumbo v9, "allowFreeFormInput"

    iget-boolean v14, v12, Lxs1;->d:Z

    invoke-virtual {v7, v9, v14}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    iget-object v9, v12, Lxs1;->f:Landroid/os/Bundle;

    invoke-virtual {v7, v13, v9}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    iget-object v9, v12, Lxs1;->g:Ljava/util/Set;

    if-eqz v9, :cond_3d0

    invoke-interface {v9}, Ljava/util/Set;->isEmpty()Z

    move-result v12

    if-nez v12, :cond_3d0

    new-instance v12, Ljava/util/ArrayList;

    invoke-interface {v9}, Ljava/util/Set;->size()I

    move-result v14

    invoke-direct {v12, v14}, Ljava/util/ArrayList;-><init>(I)V

    invoke-interface {v9}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v9

    :goto_3ba
    invoke-interface {v9}, Ljava/util/Iterator;->hasNext()Z

    move-result v14

    if-eqz v14, :cond_3ca

    invoke-interface {v9}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v14

    check-cast v14, Ljava/lang/String;

    invoke-virtual {v12, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    goto :goto_3ba

    :cond_3ca
    const-string/jumbo v9, "allowedDataTypes"

    invoke-virtual {v7, v9, v12}, Landroid/os/Bundle;->putStringArrayList(Ljava/lang/String;Ljava/util/ArrayList;)V

    :cond_3d0
    aput-object v7, v15, v20

    add-int/lit8 v9, v20, 0x1

    move-object/from16 v7, v19

    move-object/from16 v14, v21

    goto :goto_36e

    :goto_3d9
    const-string/jumbo v7, "remoteInputs"

    invoke-virtual {v11, v7, v15}, Landroid/os/Bundle;->putParcelableArray(Ljava/lang/String;[Landroid/os/Parcelable;)V

    const-string/jumbo v7, "showsUserInterface"

    iget-boolean v9, v10, Leg1;->e:Z

    invoke-virtual {v11, v7, v9}, Landroid/os/BaseBundle;->putBoolean(Ljava/lang/String;Z)V

    const-string/jumbo v7, "semanticAction"

    iget v9, v10, Leg1;->f:I

    invoke-virtual {v11, v7, v9}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    invoke-virtual {v6, v8, v11}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    add-int/lit8 v7, v17, 0x1

    move-object/from16 v12, v18

    move-object/from16 v14, v21

    goto/16 :goto_2f9

    :cond_3fa
    const-string/jumbo v7, "invisible_actions"

    invoke-virtual {v2, v7, v6}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    invoke-virtual {v5, v7, v6}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    iget-object v6, v1, Lkg1;->q:Landroid/os/Bundle;

    if-nez v6, :cond_40e

    new-instance v6, Landroid/os/Bundle;

    invoke-direct {v6}, Landroid/os/Bundle;-><init>()V

    iput-object v6, v1, Lkg1;->q:Landroid/os/Bundle;

    :cond_40e
    invoke-virtual {v6, v3, v2}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    iget-object v2, v0, Ltd;->d:Ljava/lang/Object;

    check-cast v2, Landroid/os/Bundle;

    invoke-virtual {v2, v3, v5}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    :cond_418
    iget-object v2, v0, Ltd;->b:Ljava/lang/Object;

    check-cast v2, Landroid/app/Notification$Builder;

    iget-object v3, v1, Lkg1;->q:Landroid/os/Bundle;

    invoke-virtual {v2, v3}, Landroid/app/Notification$Builder;->setExtras(Landroid/os/Bundle;)Landroid/app/Notification$Builder;

    iget-object v2, v0, Ltd;->b:Ljava/lang/Object;

    check-cast v2, Landroid/app/Notification$Builder;

    const/4 v5, 0x0

    invoke-virtual {v2, v5}, Landroid/app/Notification$Builder;->setRemoteInputHistory([Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v5, 0x1a

    if-lt v2, v5, :cond_47f

    iget-object v3, v0, Ltd;->b:Ljava/lang/Object;

    check-cast v3, Landroid/app/Notification$Builder;

    invoke-static {v3}, Lja;->x(Landroid/app/Notification$Builder;)V

    iget-object v3, v0, Ltd;->b:Ljava/lang/Object;

    check-cast v3, Landroid/app/Notification$Builder;

    invoke-static {v3}, Lja;->F(Landroid/app/Notification$Builder;)V

    iget-object v3, v0, Ltd;->b:Ljava/lang/Object;

    check-cast v3, Landroid/app/Notification$Builder;

    invoke-static {v3}, Lja;->G(Landroid/app/Notification$Builder;)V

    iget-object v3, v0, Ltd;->b:Ljava/lang/Object;

    check-cast v3, Landroid/app/Notification$Builder;

    invoke-static {v3}, Lja;->H(Landroid/app/Notification$Builder;)V

    iget-object v3, v0, Ltd;->b:Ljava/lang/Object;

    check-cast v3, Landroid/app/Notification$Builder;

    invoke-static {v3}, Lja;->A(Landroid/app/Notification$Builder;)V

    iget-boolean v3, v1, Lkg1;->o:Z

    if-eqz v3, :cond_45f

    iget-object v3, v0, Ltd;->b:Ljava/lang/Object;

    check-cast v3, Landroid/app/Notification$Builder;

    iget-boolean v5, v1, Lkg1;->n:Z

    invoke-static {v3, v5}, Lja;->y(Landroid/app/Notification$Builder;Z)V

    :cond_45f
    iget-object v3, v1, Lkg1;->s:Ljava/lang/String;

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_47f

    iget-object v3, v0, Ltd;->b:Ljava/lang/Object;

    check-cast v3, Landroid/app/Notification$Builder;

    const/4 v5, 0x0

    invoke-virtual {v3, v5}, Landroid/app/Notification$Builder;->setSound(Landroid/net/Uri;)Landroid/app/Notification$Builder;

    move-result-object v3

    const/4 v6, 0x0

    invoke-virtual {v3, v6}, Landroid/app/Notification$Builder;->setDefaults(I)Landroid/app/Notification$Builder;

    move-result-object v3

    invoke-virtual {v3, v6, v6, v6}, Landroid/app/Notification$Builder;->setLights(III)Landroid/app/Notification$Builder;

    move-result-object v3

    invoke-virtual {v3, v5}, Landroid/app/Notification$Builder;->setVibrate([J)Landroid/app/Notification$Builder;

    :goto_47c
    const/16 v7, 0x1c

    goto :goto_481

    :cond_47f
    const/4 v6, 0x0

    goto :goto_47c

    :goto_481
    if-lt v2, v7, :cond_4a1

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v2

    move v11, v6

    :goto_488
    if-ge v11, v2, :cond_4a1

    invoke-virtual {v4, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    add-int/lit8 v11, v11, 0x1

    check-cast v3, Lxj1;

    iget-object v5, v0, Ltd;->b:Ljava/lang/Object;

    check-cast v5, Landroid/app/Notification$Builder;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v3}, Lea;->C(Lxj1;)Landroid/app/Person;

    move-result-object v3

    invoke-static {v5, v3}, Lea;->a(Landroid/app/Notification$Builder;Landroid/app/Person;)V

    goto :goto_488

    :cond_4a1
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v9, 0x1d

    if-lt v2, v9, :cond_4b7

    iget-object v2, v0, Ltd;->b:Ljava/lang/Object;

    check-cast v2, Landroid/app/Notification$Builder;

    iget-boolean v1, v1, Lkg1;->t:Z

    invoke-static {v2, v1}, Lla;->p(Landroid/app/Notification$Builder;Z)V

    iget-object v0, v0, Ltd;->b:Ljava/lang/Object;

    check-cast v0, Landroid/app/Notification$Builder;

    invoke-static {v0}, Lla;->q(Landroid/app/Notification$Builder;)V

    :cond_4b7
    return-void
.end method

.method public constructor <init>(Ltd;)V
    .registers 4

    const/16 v0, 0xf

    iput v0, p0, Ltd;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iget-object v0, p1, Ltd;->b:Ljava/lang/Object;

    check-cast v0, [J

    const/16 v1, 0xa

    invoke-static {v0, v1}, Ljava/util/Arrays;->copyOf([JI)[J

    move-result-object v0

    iput-object v0, p0, Ltd;->b:Ljava/lang/Object;

    iget-object v0, p1, Ltd;->c:Ljava/lang/Object;

    check-cast v0, [J

    invoke-static {v0, v1}, Ljava/util/Arrays;->copyOf([JI)[J

    move-result-object v0

    iput-object v0, p0, Ltd;->c:Ljava/lang/Object;

    iget-object p1, p1, Ltd;->d:Ljava/lang/Object;

    check-cast p1, [J

    invoke-static {p1, v1}, Ljava/util/Arrays;->copyOf([JI)[J

    move-result-object p1

    iput-object p1, p0, Ltd;->d:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Ltp0;Lc00;Landroid/content/ComponentName;)V
    .registers 4

    const/16 p1, 0xd

    iput p1, p0, Ltd;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p1, Ljava/lang/Object;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Ltd;->b:Ljava/lang/Object;

    iput-object p2, p0, Ltd;->c:Ljava/lang/Object;

    iput-object p3, p0, Ltd;->d:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lv70;)V
    .registers 3

    const/16 v0, 0xf

    iput v0, p0, Ltd;->a:I

    invoke-direct {p0, v0}, Ltd;-><init>(I)V

    invoke-static {p0, p1}, Ltd;->w(Ltd;Lv70;)V

    return-void
.end method

.method public constructor <init>(Lww;)V
    .registers 3

    const/4 v0, 0x7

    iput v0, p0, Ltd;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Ltd;->b:Ljava/lang/Object;

    new-instance v0, Lzi;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    iput-object v0, p0, Ltd;->c:Ljava/lang/Object;

    iput-object p1, p0, Ltd;->d:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lx5;Lvp1;Lu10;Ljava/util/Set;)V
    .registers 12

    .prologue
    const/16 v0, 0x10

    iput v0, p0, Ltd;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p2, p0, Ltd;->b:Ljava/lang/Object;

    iput-object p1, p0, Ltd;->c:Ljava/lang/Object;

    iput-object p3, p0, Ltd;->d:Ljava/lang/Object;

    invoke-interface {p4}, Ljava/util/Set;->isEmpty()Z

    move-result p1

    if-eqz p1, :cond_14

    goto :goto_3e

    :cond_14
    invoke-interface {p4}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_18
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result p2

    if-eqz p2, :cond_3e

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p2

    check-cast p2, [I

    new-instance v1, Ljava/lang/String;

    array-length p3, p2

    const/4 p4, 0x0

    invoke-direct {v1, p2, p4, p3}, Ljava/lang/String;-><init>([III)V

    new-instance v6, Lq5;

    const/16 p2, 0x17

    invoke-direct {v6, v1, p2, p4}, Lq5;-><init>(Ljava/lang/String;IZ)V

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v4, 0x1

    const/4 v5, 0x1

    const/4 v2, 0x0

    move-object v0, p0

    invoke-virtual/range {v0 .. v6}, Ltd;->B(Ljava/lang/CharSequence;IIIZLp90;)Ljava/lang/Object;

    goto :goto_18

    :cond_3e
    :goto_3e
    return-void
.end method

.method public static p(Ljava/lang/String;Lq5;Lyl;)Ltd;
    .registers 7

    .prologue
    sget v0, Lji2;->a:I

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    new-array v0, v0, [B

    const/4 v1, 0x0

    :goto_9
    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v2

    if-ge v1, v2, :cond_36

    invoke-virtual {p0, v1}, Ljava/lang/String;->charAt(I)C

    move-result v2

    const/16 v3, 0x21

    if-lt v2, v3, :cond_21

    const/16 v3, 0x7e

    if-gt v2, v3, :cond_21

    int-to-byte v2, v2

    aput-byte v2, v0, v1

    add-int/lit8 v1, v1, 0x1

    goto :goto_9

    :cond_21
    new-instance p0, Ljava/security/GeneralSecurityException;

    new-instance p1, Ljava/lang/StringBuilder;

    const-string/jumbo p2, "Not a printable ASCII character: "

    invoke-direct {p1, p2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_36
    invoke-static {v0}, Lzl;->a([B)Lzl;

    new-instance v0, Ltd;

    const/16 v1, 0x1b

    invoke-direct {v0, p2, p0, p1, v1}, Ltd;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    return-object v0
.end method

.method public static s(Landroid/text/Editable;Landroid/view/KeyEvent;Z)Z
    .registers 9

    .prologue
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getMetaState()I

    move-result p1

    invoke-static {p1}, Landroid/view/KeyEvent;->metaStateHasNoModifiers(I)Z

    move-result p1

    const/4 v0, 0x0

    if-nez p1, :cond_c

    goto :goto_4b

    :cond_c
    invoke-static {p0}, Landroid/text/Selection;->getSelectionStart(Ljava/lang/CharSequence;)I

    move-result p1

    invoke-static {p0}, Landroid/text/Selection;->getSelectionEnd(Ljava/lang/CharSequence;)I

    move-result v1

    const/4 v2, -0x1

    if-eq p1, v2, :cond_4b

    if-eq v1, v2, :cond_4b

    if-eq p1, v1, :cond_1c

    goto :goto_4b

    :cond_1c
    const-class v2, Llf2;

    invoke-interface {p0, p1, v1, v2}, Landroid/text/Spanned;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;

    move-result-object v1

    check-cast v1, [Llf2;

    if-eqz v1, :cond_4b

    array-length v2, v1

    if-lez v2, :cond_4b

    array-length v2, v1

    move v3, v0

    :goto_2b
    if-ge v3, v2, :cond_4b

    aget-object v4, v1, v3

    invoke-interface {p0, v4}, Landroid/text/Spanned;->getSpanStart(Ljava/lang/Object;)I

    move-result v5

    invoke-interface {p0, v4}, Landroid/text/Spanned;->getSpanEnd(Ljava/lang/Object;)I

    move-result v4

    if-eqz p2, :cond_3b

    if-eq v5, p1, :cond_43

    :cond_3b
    if-nez p2, :cond_3f

    if-eq v4, p1, :cond_43

    :cond_3f
    if-le p1, v5, :cond_48

    if-ge p1, v4, :cond_48

    :cond_43
    invoke-interface {p0, v5, v4}, Landroid/text/Editable;->delete(II)Landroid/text/Editable;

    const/4 p0, 0x1

    return p0

    :cond_48
    add-int/lit8 v3, v3, 0x1

    goto :goto_2b

    :cond_4b
    :goto_4b
    return v0
.end method

.method public static w(Ltd;Lv70;)V
    .registers 5

    iget-object v0, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v0, [J

    iget-object v1, p1, Lv70;->a:Ltd;

    iget-object v2, v1, Ltd;->b:Ljava/lang/Object;

    check-cast v2, [J

    iget-object p1, p1, Lv70;->b:[J

    invoke-static {v0, v2, p1}, Lns2;->u([J[J[J)V

    iget-object v0, p0, Ltd;->c:Ljava/lang/Object;

    check-cast v0, [J

    iget-object v2, v1, Ltd;->c:Ljava/lang/Object;

    check-cast v2, [J

    iget-object v1, v1, Ltd;->d:Ljava/lang/Object;

    check-cast v1, [J

    invoke-static {v0, v2, v1}, Lns2;->u([J[J[J)V

    iget-object p0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast p0, [J

    invoke-static {p0, v1, p1}, Lns2;->u([J[J[J)V

    return-void
.end method

.method public static x(Landroid/content/Context;)Ltd;
    .registers 4

    .prologue
    sget-object v0, Ltd;->e:Ltd;

    if-nez v0, :cond_1a

    sget-object v0, Ltd;->f:Ljava/lang/Object;

    monitor-enter v0

    :try_start_7
    sget-object v1, Ltd;->e:Ltd;

    if-nez v1, :cond_16

    new-instance v1, Ltd;

    const/4 v2, 0x0

    invoke-direct {v1, p0, v2}, Ltd;-><init>(Landroid/content/Context;I)V

    sput-object v1, Ltd;->e:Ltd;

    goto :goto_16

    :catchall_14
    move-exception p0

    goto :goto_18

    :cond_16
    :goto_16
    monitor-exit v0

    goto :goto_1a

    :goto_18
    monitor-exit v0
    :try_end_19
    .catchall {:try_start_7 .. :try_end_19} :catchall_14

    throw p0

    :cond_1a
    :goto_1a
    sget-object p0, Ltd;->e:Ltd;

    return-object p0
.end method

.method public static y(Ll90;Landroid/text/Editable;IIZ)Z
    .registers 12

    .prologue
    const/4 v0, 0x0

    if-eqz p1, :cond_ef

    if-ltz p2, :cond_ef

    if-gez p3, :cond_9

    goto/16 :goto_ef

    :cond_9
    invoke-static {p1}, Landroid/text/Selection;->getSelectionStart(Ljava/lang/CharSequence;)I

    move-result v1

    invoke-static {p1}, Landroid/text/Selection;->getSelectionEnd(Ljava/lang/CharSequence;)I

    move-result v2

    const/4 v3, -0x1

    if-eq v1, v3, :cond_ef

    if-eq v2, v3, :cond_ef

    if-eq v1, v2, :cond_1a

    goto/16 :goto_ef

    :cond_1a
    const/4 v4, 0x1

    if-eqz p4, :cond_a5

    invoke-static {p2, v0}, Ljava/lang/Math;->max(II)I

    move-result p2

    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result p4

    if-ltz v1, :cond_2c

    if-ge p4, v1, :cond_2a

    goto :goto_2c

    :cond_2a
    if-gez p2, :cond_2e

    :cond_2c
    :goto_2c
    move v1, v3

    goto :goto_5d

    :cond_2e
    :goto_2e
    move p4, v0

    :goto_2f
    if-nez p2, :cond_32

    goto :goto_5d

    :cond_32
    add-int/lit8 v1, v1, -0x1

    if-gez v1, :cond_3b

    if-eqz p4, :cond_39

    goto :goto_2c

    :cond_39
    move v1, v0

    goto :goto_5d

    :cond_3b
    invoke-interface {p1, v1}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v5

    if-eqz p4, :cond_4b

    invoke-static {v5}, Ljava/lang/Character;->isHighSurrogate(C)Z

    move-result p4

    if-nez p4, :cond_48

    goto :goto_2c

    :cond_48
    add-int/lit8 p2, p2, -0x1

    goto :goto_2e

    :cond_4b
    invoke-static {v5}, Ljava/lang/Character;->isSurrogate(C)Z

    move-result v6

    if-nez v6, :cond_54

    add-int/lit8 p2, p2, -0x1

    goto :goto_2f

    :cond_54
    invoke-static {v5}, Ljava/lang/Character;->isHighSurrogate(C)Z

    move-result p4

    if-eqz p4, :cond_5b

    goto :goto_2c

    :cond_5b
    move p4, v4

    goto :goto_2f

    :goto_5d
    invoke-static {p3, v0}, Ljava/lang/Math;->max(II)I

    move-result p2

    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result p3

    if-ltz v2, :cond_6c

    if-ge p3, v2, :cond_6a

    goto :goto_6c

    :cond_6a
    if-gez p2, :cond_6e

    :cond_6c
    :goto_6c
    move p3, v3

    goto :goto_a0

    :cond_6e
    :goto_6e
    move p4, v0

    :goto_6f
    if-nez p2, :cond_73

    move p3, v2

    goto :goto_a0

    :cond_73
    if-lt v2, p3, :cond_78

    if-eqz p4, :cond_a0

    goto :goto_6c

    :cond_78
    invoke-interface {p1, v2}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v5

    if-eqz p4, :cond_8a

    invoke-static {v5}, Ljava/lang/Character;->isLowSurrogate(C)Z

    move-result p4

    if-nez p4, :cond_85

    goto :goto_6c

    :cond_85
    add-int/lit8 p2, p2, -0x1

    add-int/lit8 v2, v2, 0x1

    goto :goto_6e

    :cond_8a
    invoke-static {v5}, Ljava/lang/Character;->isSurrogate(C)Z

    move-result v6

    if-nez v6, :cond_95

    add-int/lit8 p2, p2, -0x1

    add-int/lit8 v2, v2, 0x1

    goto :goto_6f

    :cond_95
    invoke-static {v5}, Ljava/lang/Character;->isLowSurrogate(C)Z

    move-result p4

    if-eqz p4, :cond_9c

    goto :goto_6c

    :cond_9c
    add-int/lit8 v2, v2, 0x1

    move p4, v4

    goto :goto_6f

    :cond_a0
    :goto_a0
    if-eq v1, v3, :cond_ef

    if-ne p3, v3, :cond_b3

    goto :goto_ef

    :cond_a5
    sub-int/2addr v1, p2

    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result v1

    add-int/2addr v2, p3

    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result p2

    invoke-static {v2, p2}, Ljava/lang/Math;->min(II)I

    move-result p3

    :cond_b3
    const-class p2, Llf2;

    invoke-interface {p1, v1, p3, p2}, Landroid/text/Spanned;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;

    move-result-object p2

    check-cast p2, [Llf2;

    if-eqz p2, :cond_ef

    array-length p4, p2

    if-lez p4, :cond_ef

    array-length p4, p2

    move v2, v0

    :goto_c2
    if-ge v2, p4, :cond_d9

    aget-object v3, p2, v2

    invoke-interface {p1, v3}, Landroid/text/Spanned;->getSpanStart(Ljava/lang/Object;)I

    move-result v5

    invoke-interface {p1, v3}, Landroid/text/Spanned;->getSpanEnd(Ljava/lang/Object;)I

    move-result v3

    invoke-static {v5, v1}, Ljava/lang/Math;->min(II)I

    move-result v1

    invoke-static {v3, p3}, Ljava/lang/Math;->max(II)I

    move-result p3

    add-int/lit8 v2, v2, 0x1

    goto :goto_c2

    :cond_d9
    invoke-static {v1, v0}, Ljava/lang/Math;->max(II)I

    move-result p2

    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result p4

    invoke-static {p3, p4}, Ljava/lang/Math;->min(II)I

    move-result p3

    invoke-virtual {p0}, Landroid/view/inputmethod/InputConnectionWrapper;->beginBatchEdit()Z

    invoke-interface {p1, p2, p3}, Landroid/text/Editable;->delete(II)Landroid/text/Editable;

    invoke-virtual {p0}, Landroid/view/inputmethod/InputConnectionWrapper;->endBatchEdit()Z

    return v4

    :cond_ef
    :goto_ef
    return v0
.end method


# virtual methods
.method public A(ILzv;Lvw;)Z
    .registers 9

    .prologue
    iget-object p0, p0, Ltd;->c:Ljava/lang/Object;

    check-cast p0, Lzi;

    iget-object v0, p3, Lvw;->p0:[I

    iget-object v1, p3, Lvw;->t:[I

    const/4 v2, 0x0

    aget v3, v0, v2

    iput v3, p0, Lzi;->a:I

    const/4 v3, 0x1

    aget v0, v0, v3

    iput v0, p0, Lzi;->b:I

    invoke-virtual {p3}, Lvw;->q()I

    move-result v0

    iput v0, p0, Lzi;->c:I

    invoke-virtual {p3}, Lvw;->k()I

    move-result v0

    iput v0, p0, Lzi;->d:I

    iput-boolean v2, p0, Lzi;->i:Z

    iput p1, p0, Lzi;->j:I

    iget p1, p0, Lzi;->a:I

    const/4 v0, 0x3

    if-ne p1, v0, :cond_29

    move p1, v3

    goto :goto_2a

    :cond_29
    move p1, v2

    :goto_2a
    iget v4, p0, Lzi;->b:I

    if-ne v4, v0, :cond_30

    move v0, v3

    goto :goto_31

    :cond_30
    move v0, v2

    :goto_31
    const/4 v4, 0x0

    if-eqz p1, :cond_3c

    iget p1, p3, Lvw;->W:F

    cmpl-float p1, p1, v4

    if-lez p1, :cond_3c

    move p1, v3

    goto :goto_3d

    :cond_3c
    move p1, v2

    :goto_3d
    if-eqz v0, :cond_47

    iget v0, p3, Lvw;->W:F

    cmpl-float v0, v0, v4

    if-lez v0, :cond_47

    move v0, v3

    goto :goto_48

    :cond_47
    move v0, v2

    :goto_48
    const/4 v4, 0x4

    if-eqz p1, :cond_51

    aget p1, v1, v2

    if-ne p1, v4, :cond_51

    iput v3, p0, Lzi;->a:I

    :cond_51
    if-eqz v0, :cond_59

    aget p1, v1, v3

    if-ne p1, v4, :cond_59

    iput v3, p0, Lzi;->b:I

    :cond_59
    invoke-virtual {p2, p3, p0}, Lzv;->b(Lvw;Lzi;)V

    iget p1, p0, Lzi;->e:I

    invoke-virtual {p3, p1}, Lvw;->O(I)V

    iget p1, p0, Lzi;->f:I

    invoke-virtual {p3, p1}, Lvw;->L(I)V

    iget-boolean p1, p0, Lzi;->h:Z

    iput-boolean p1, p3, Lvw;->E:Z

    iget p1, p0, Lzi;->g:I

    invoke-virtual {p3, p1}, Lvw;->I(I)V

    iput v2, p0, Lzi;->j:I

    iget-boolean p0, p0, Lzi;->i:Z

    return p0
.end method

.method public B(Ljava/lang/CharSequence;IIIZLp90;)Ljava/lang/Object;
    .registers 23

    .prologue
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p3

    move/from16 v3, p4

    move-object/from16 v4, p6

    new-instance v5, Lq90;

    iget-object v6, v0, Ltd;->c:Ljava/lang/Object;

    check-cast v6, Lx5;

    iget-object v6, v6, Lx5;->e:Ljava/lang/Object;

    check-cast v6, Lv91;

    invoke-direct {v5, v6}, Lq90;-><init>(Lv91;)V

    invoke-static/range {p1 .. p2}, Ljava/lang/Character;->codePointAt(Ljava/lang/CharSequence;I)I

    move-result v6

    const/4 v7, 0x0

    const/4 v8, 0x1

    move v9, v6

    move v10, v7

    move v11, v8

    move/from16 v6, p2

    :cond_22
    :goto_22
    move v7, v6

    :goto_23
    const/4 v12, 0x2

    if-ge v6, v2, :cond_ca

    if-ge v10, v3, :cond_ca

    if-eqz v11, :cond_ca

    iget-object v13, v5, Lq90;->c:Lv91;

    iget-object v13, v13, Lv91;->a:Landroid/util/SparseArray;

    invoke-virtual {v13, v9}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Lv91;

    iget v14, v5, Lq90;->a:I

    const/4 v15, 0x3

    if-eq v14, v12, :cond_48

    if-nez v13, :cond_40

    invoke-virtual {v5}, Lq90;->a()V

    :goto_3e
    move v13, v8

    goto :goto_88

    :cond_40
    iput v12, v5, Lq90;->a:I

    iput-object v13, v5, Lq90;->c:Lv91;

    iput v8, v5, Lq90;->f:I

    :goto_46
    move v13, v12

    goto :goto_88

    :cond_48
    if-eqz v13, :cond_52

    iput-object v13, v5, Lq90;->c:Lv91;

    iget v13, v5, Lq90;->f:I

    add-int/2addr v13, v8

    iput v13, v5, Lq90;->f:I

    goto :goto_46

    :cond_52
    const v13, 0xfe0e

    if-ne v9, v13, :cond_5b

    invoke-virtual {v5}, Lq90;->a()V

    goto :goto_3e

    :cond_5b
    const v13, 0xfe0f

    if-ne v9, v13, :cond_61

    goto :goto_46

    :cond_61
    iget-object v13, v5, Lq90;->c:Lv91;

    iget-object v14, v13, Lv91;->b:Lkf2;

    if-eqz v14, :cond_84

    iget v14, v5, Lq90;->f:I

    if-ne v14, v8, :cond_7e

    invoke-virtual {v5}, Lq90;->b()Z

    move-result v13

    if-eqz v13, :cond_7a

    iget-object v13, v5, Lq90;->c:Lv91;

    iput-object v13, v5, Lq90;->d:Lv91;

    invoke-virtual {v5}, Lq90;->a()V

    :goto_78
    move v13, v15

    goto :goto_88

    :cond_7a
    invoke-virtual {v5}, Lq90;->a()V

    goto :goto_3e

    :cond_7e
    iput-object v13, v5, Lq90;->d:Lv91;

    invoke-virtual {v5}, Lq90;->a()V

    goto :goto_78

    :cond_84
    invoke-virtual {v5}, Lq90;->a()V

    goto :goto_3e

    :goto_88
    iput v9, v5, Lq90;->e:I

    if-eq v13, v8, :cond_b8

    if-eq v13, v12, :cond_a9

    if-eq v13, v15, :cond_91

    goto :goto_23

    :cond_91
    if-nez p5, :cond_9d

    iget-object v12, v5, Lq90;->d:Lv91;

    iget-object v12, v12, Lv91;->b:Lkf2;

    invoke-virtual {v0, v1, v7, v6, v12}, Ltd;->z(Ljava/lang/CharSequence;IILkf2;)Z

    move-result v12

    if-nez v12, :cond_22

    :cond_9d
    iget-object v11, v5, Lq90;->d:Lv91;

    iget-object v11, v11, Lv91;->b:Lkf2;

    invoke-interface {v4, v1, v7, v6, v11}, Lp90;->c(Ljava/lang/CharSequence;IILkf2;)Z

    move-result v11

    add-int/lit8 v10, v10, 0x1

    goto/16 :goto_22

    :cond_a9
    invoke-static {v9}, Ljava/lang/Character;->charCount(I)I

    move-result v12

    add-int/2addr v12, v6

    if-ge v12, v2, :cond_b5

    invoke-static {v1, v12}, Ljava/lang/Character;->codePointAt(Ljava/lang/CharSequence;I)I

    move-result v6

    move v9, v6

    :cond_b5
    move v6, v12

    goto/16 :goto_23

    :cond_b8
    invoke-static {v1, v7}, Ljava/lang/Character;->codePointAt(Ljava/lang/CharSequence;I)I

    move-result v6

    invoke-static {v6}, Ljava/lang/Character;->charCount(I)I

    move-result v6

    add-int/2addr v6, v7

    if-ge v6, v2, :cond_22

    invoke-static {v1, v6}, Ljava/lang/Character;->codePointAt(Ljava/lang/CharSequence;I)I

    move-result v7

    move v9, v7

    goto/16 :goto_22

    :cond_ca
    iget v2, v5, Lq90;->a:I

    if-ne v2, v12, :cond_f5

    iget-object v2, v5, Lq90;->c:Lv91;

    iget-object v2, v2, Lv91;->b:Lkf2;

    if-eqz v2, :cond_f5

    iget v2, v5, Lq90;->f:I

    if-gt v2, v8, :cond_de

    invoke-virtual {v5}, Lq90;->b()Z

    move-result v2

    if-eqz v2, :cond_f5

    :cond_de
    if-ge v10, v3, :cond_f5

    if-eqz v11, :cond_f5

    if-nez p5, :cond_ee

    iget-object v2, v5, Lq90;->c:Lv91;

    iget-object v2, v2, Lv91;->b:Lkf2;

    invoke-virtual {v0, v1, v7, v6, v2}, Ltd;->z(Ljava/lang/CharSequence;IILkf2;)Z

    move-result v0

    if-nez v0, :cond_f5

    :cond_ee
    iget-object v0, v5, Lq90;->c:Lv91;

    iget-object v0, v0, Lv91;->b:Lkf2;

    invoke-interface {v4, v1, v7, v6, v0}, Lp90;->c(Ljava/lang/CharSequence;IILkf2;)Z

    :cond_f5
    invoke-interface {v4}, Lp90;->b()Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public C(Lyg;IZ)V
    .registers 21

    .prologue
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p2

    iget-object v3, v0, Ltd;->c:Ljava/lang/Object;

    check-cast v3, Lug;

    new-instance v4, Landroid/content/ComponentName;

    iget-object v5, v0, Ltd;->d:Ljava/lang/Object;

    check-cast v5, Landroid/content/Context;

    const-class v6, Lcom/google/android/datatransport/runtime/scheduling/jobscheduling/JobInfoSchedulerService;

    invoke-direct {v4, v5, v6}, Landroid/content/ComponentName;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const-string/jumbo v6, "jobscheduler"

    invoke-virtual {v5, v6}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/app/job/JobScheduler;

    new-instance v7, Ljava/util/zip/Adler32;

    invoke-direct {v7}, Ljava/util/zip/Adler32;-><init>()V

    invoke-virtual {v5}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v5

    const-string/jumbo v8, "UTF-8"

    invoke-static {v8}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v9

    invoke-virtual {v5, v9}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v5

    invoke-virtual {v7, v5}, Ljava/util/zip/Adler32;->update([B)V

    iget-object v5, v1, Lyg;->a:Ljava/lang/String;

    invoke-static {v8}, Ljava/nio/charset/Charset;->forName(Ljava/lang/String;)Ljava/nio/charset/Charset;

    move-result-object v8

    invoke-virtual {v5, v8}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/util/zip/Adler32;->update([B)V

    const/4 v8, 0x4

    invoke-static {v8}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v8

    iget-object v9, v1, Lyg;->c:Lym1;

    invoke-static {v9}, Lan1;->a(Lym1;)I

    move-result v10

    invoke-virtual {v8, v10}, Ljava/nio/ByteBuffer;->putInt(I)Ljava/nio/ByteBuffer;

    move-result-object v8

    invoke-virtual {v8}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/util/zip/Adler32;->update([B)V

    iget-object v8, v1, Lyg;->b:[B

    if-eqz v8, :cond_5f

    invoke-virtual {v7, v8}, Ljava/util/zip/Adler32;->update([B)V

    :cond_5f
    invoke-virtual {v7}, Ljava/util/zip/Adler32;->getValue()J

    move-result-wide v10

    long-to-int v7, v10

    const-string/jumbo v10, "JobInfoScheduler"

    const-string/jumbo v11, "attemptNumber"

    if-nez p3, :cond_97

    invoke-virtual {v6}, Landroid/app/job/JobScheduler;->getAllPendingJobs()Ljava/util/List;

    move-result-object v12

    invoke-interface {v12}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v12

    :cond_74
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    move-result v13

    if-eqz v13, :cond_97

    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Landroid/app/job/JobInfo;

    invoke-virtual {v13}, Landroid/app/job/JobInfo;->getExtras()Landroid/os/PersistableBundle;

    move-result-object v14

    invoke-virtual {v14, v11}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;)I

    move-result v14

    invoke-virtual {v13}, Landroid/app/job/JobInfo;->getId()I

    move-result v13

    if-ne v13, v7, :cond_74

    if-lt v14, v2, :cond_97

    const-string/jumbo v0, "Upload for context %s is already scheduled. Returning..."

    invoke-static {v10, v0, v1}, Lg73;->q(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    return-void

    :cond_97
    iget-object v0, v0, Ltd;->b:Ljava/lang/Object;

    check-cast v0, Lix1;

    invoke-virtual {v0}, Lix1;->k()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v0

    invoke-static {v9}, Lan1;->a(Lym1;)I

    move-result v12

    invoke-static {v12}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v12

    filled-new-array {v5, v12}, [Ljava/lang/String;

    move-result-object v12

    const-string/jumbo v13, "SELECT next_request_ms FROM transport_contexts WHERE backend_name = ? and priority = ?"

    invoke-virtual {v0, v13, v12}, Landroid/database/sqlite/SQLiteDatabase;->rawQuery(Ljava/lang/String;[Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v12

    :try_start_b2
    move-object v0, v12

    check-cast v0, Landroid/database/Cursor;

    invoke-interface {v0}, Landroid/database/Cursor;->moveToNext()Z

    move-result v13

    const/4 v14, 0x0

    if-eqz v13, :cond_c5

    invoke-interface {v0, v14}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide v15

    invoke-static/range {v15 .. v16}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    goto :goto_cb

    :cond_c5
    const-wide/16 v15, 0x0

    invoke-static/range {v15 .. v16}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0
    :try_end_cb
    .catchall {:try_start_b2 .. :try_end_cb} :catchall_169

    :goto_cb
    invoke-interface {v12}, Landroid/database/Cursor;->close()V

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v12

    new-instance v15, Landroid/app/job/JobInfo$Builder;

    invoke-direct {v15, v7, v4}, Landroid/app/job/JobInfo$Builder;-><init>(ILandroid/content/ComponentName;)V

    move-object v4, v6

    move/from16 v16, v7

    invoke-virtual {v3, v9, v12, v13, v2}, Lug;->a(Lym1;JI)J

    move-result-wide v6

    invoke-virtual {v15, v6, v7}, Landroid/app/job/JobInfo$Builder;->setMinimumLatency(J)Landroid/app/job/JobInfo$Builder;

    iget-object v6, v3, Lug;->b:Ljava/util/HashMap;

    invoke-virtual {v6, v9}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Lvg;

    iget-object v6, v6, Lvg;->c:Ljava/util/Set;

    sget-object v7, Lmy1;->a:Lmy1;

    invoke-interface {v6, v7}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v7

    const/4 v14, 0x1

    if-eqz v7, :cond_f9

    const/4 v7, 0x2

    invoke-virtual {v15, v7}, Landroid/app/job/JobInfo$Builder;->setRequiredNetworkType(I)Landroid/app/job/JobInfo$Builder;

    goto :goto_fc

    :cond_f9
    invoke-virtual {v15, v14}, Landroid/app/job/JobInfo$Builder;->setRequiredNetworkType(I)Landroid/app/job/JobInfo$Builder;

    :goto_fc
    sget-object v7, Lmy1;->c:Lmy1;

    invoke-interface {v6, v7}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_107

    invoke-virtual {v15, v14}, Landroid/app/job/JobInfo$Builder;->setRequiresCharging(Z)Landroid/app/job/JobInfo$Builder;

    :cond_107
    sget-object v7, Lmy1;->b:Lmy1;

    invoke-interface {v6, v7}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_112

    invoke-virtual {v15, v14}, Landroid/app/job/JobInfo$Builder;->setRequiresDeviceIdle(Z)Landroid/app/job/JobInfo$Builder;

    :cond_112
    new-instance v6, Landroid/os/PersistableBundle;

    invoke-direct {v6}, Landroid/os/PersistableBundle;-><init>()V

    invoke-virtual {v6, v11, v2}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const-string/jumbo v7, "backendName"

    invoke-virtual {v6, v7, v5}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const-string/jumbo v5, "priority"

    invoke-static {v9}, Lan1;->a(Lym1;)I

    move-result v7

    invoke-virtual {v6, v5, v7}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    if-eqz v8, :cond_137

    const-string/jumbo v5, "extras"

    const/4 v7, 0x0

    invoke-static {v8, v7}, Landroid/util/Base64;->encodeToString([BI)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v5, v7}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    :cond_137
    invoke-virtual {v15, v6}, Landroid/app/job/JobInfo$Builder;->setExtras(Landroid/os/PersistableBundle;)Landroid/app/job/JobInfo$Builder;

    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v3, v9, v12, v13, v2}, Lug;->a(Lym1;JI)J

    move-result-wide v6

    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    filled-new-array {v1, v5, v3, v0, v2}, [Ljava/lang/Object;

    move-result-object v0

    invoke-static {v10}, Lg73;->x(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x3

    invoke-static {v1, v2}, Landroid/util/Log;->isLoggable(Ljava/lang/String;I)Z

    move-result v2

    if-eqz v2, :cond_161

    const-string/jumbo v2, "Scheduling upload for context %s with jobId=%d in %dms(Backend next call timestamp %d). Attempt %d"

    invoke-static {v2, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    nop

    :cond_161
    invoke-virtual {v15}, Landroid/app/job/JobInfo$Builder;->build()Landroid/app/job/JobInfo;

    move-result-object v0

    invoke-virtual {v4, v0}, Landroid/app/job/JobScheduler;->schedule(Landroid/app/job/JobInfo;)I

    return-void

    :catchall_169
    move-exception v0

    invoke-interface {v12}, Landroid/database/Cursor;->close()V

    throw v0
.end method

.method public D(Ljava/lang/String;)V
    .registers 2

    .prologue
    if-eqz p1, :cond_5

    iput-object p1, p0, Ltd;->b:Ljava/lang/Object;

    return-void

    :cond_5
    const-string/jumbo p0, "Null backendName"

    invoke-static {p0}, Ldm2;->n(Ljava/lang/String;)V

    return-void
.end method

.method public E(I)V
    .registers 3

    .prologue
    const/16 v0, 0x10

    if-eq p1, v0, :cond_20

    const/16 v0, 0x20

    if-ne p1, v0, :cond_9

    goto :goto_20

    :cond_9
    new-instance p0, Ljava/security/InvalidAlgorithmParameterException;

    mul-int/lit8 p1, p1, 0x8

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    filled-new-array {p1}, [Ljava/lang/Object;

    move-result-object p1

    const-string/jumbo v0, "Invalid key size %d; only 128-bit and 256-bit AES keys are supported"

    invoke-static {v0, p1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/security/InvalidAlgorithmParameterException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_20
    :goto_20
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    iput-object p1, p0, Ltd;->b:Ljava/lang/Object;

    return-void
.end method

.method public F(I)V
    .registers 3

    .prologue
    const/16 v0, 0xa

    if-lt p1, v0, :cond_f

    const/16 v0, 0x10

    if-lt v0, p1, :cond_f

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    iput-object p1, p0, Ltd;->c:Ljava/lang/Object;

    return-void

    :cond_f
    new-instance p0, Ljava/security/GeneralSecurityException;

    const-string/jumbo v0, "Invalid tag size for AesCmacParameters: "

    invoke-static {p1, v0}, Lrt2;->f(ILjava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-direct {p0, p1}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public G(Lww;III)V
    .registers 8

    .prologue
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget v0, p1, Lvw;->b0:I

    iget v1, p1, Lvw;->c0:I

    const/4 v2, 0x0

    iput v2, p1, Lvw;->b0:I

    iput v2, p1, Lvw;->c0:I

    invoke-virtual {p1, p3}, Lvw;->O(I)V

    invoke-virtual {p1, p4}, Lvw;->L(I)V

    if-gez v0, :cond_17

    iput v2, p1, Lvw;->b0:I

    goto :goto_19

    :cond_17
    iput v0, p1, Lvw;->b0:I

    :goto_19
    if-gez v1, :cond_1e

    iput v2, p1, Lvw;->c0:I

    goto :goto_20

    :cond_1e
    iput v1, p1, Lvw;->c0:I

    :goto_20
    iget-object p0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast p0, Lww;

    iput p2, p0, Lww;->t0:I

    invoke-virtual {p0}, Lww;->U()V

    return-void
.end method

.method public H()[B
    .registers 5

    const/16 v0, 0xa

    new-array v1, v0, [J

    new-array v2, v0, [J

    new-array v0, v0, [J

    iget-object v3, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v3, [J

    invoke-static {v1, v3}, Lns2;->o([J[J)V

    iget-object v3, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v3, [J

    invoke-static {v2, v3, v1}, Lns2;->u([J[J[J)V

    iget-object p0, p0, Ltd;->c:Ljava/lang/Object;

    check-cast p0, [J

    invoke-static {v0, p0, v1}, Lns2;->u([J[J[J)V

    invoke-static {v0}, Lns2;->g([J)[B

    move-result-object p0

    const/16 v0, 0x1f

    aget-byte v1, p0, v0

    invoke-static {v2}, Lns2;->g([J)[B

    move-result-object v2

    const/4 v3, 0x0

    aget-byte v2, v2, v3

    and-int/lit8 v2, v2, 0x1

    shl-int/lit8 v2, v2, 0x7

    xor-int/2addr v1, v2

    int-to-byte v1, v1

    aput-byte v1, p0, v0

    return-object p0
.end method

.method public I(Lww;)V
    .registers 10

    .prologue
    iget-object p0, p0, Ltd;->b:Ljava/lang/Object;

    check-cast p0, Ljava/util/ArrayList;

    invoke-virtual {p0}, Ljava/util/ArrayList;->clear()V

    iget-object v0, p1, Lww;->q0:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    move v2, v1

    :goto_f
    const/4 v3, 0x1

    if-ge v2, v0, :cond_2b

    iget-object v4, p1, Lww;->q0:Ljava/util/ArrayList;

    invoke-virtual {v4, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lvw;

    iget-object v5, v4, Lvw;->p0:[I

    aget v6, v5, v1

    const/4 v7, 0x3

    if-eq v6, v7, :cond_25

    aget v3, v5, v3

    if-ne v3, v7, :cond_28

    :cond_25
    invoke-virtual {p0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_28
    add-int/lit8 v2, v2, 0x1

    goto :goto_f

    :cond_2b
    iget-object p0, p1, Lww;->s0:Lx30;

    iput-boolean v3, p0, Lx30;->b:Z

    return-void
.end method

.method public a()Landroid/net/Uri;
    .registers 1

    iget-object p0, p0, Ltd;->b:Ljava/lang/Object;

    check-cast p0, Landroid/net/Uri;

    return-object p0
.end method

.method public b()V
    .registers 1

    return-void
.end method

.method public c()Landroid/net/Uri;
    .registers 1

    iget-object p0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast p0, Landroid/net/Uri;

    return-object p0
.end method

.method public d()Ljava/lang/Object;
    .registers 1

    const/4 p0, 0x0

    return-object p0
.end method

.method public e()Lm5;
    .registers 5

    .prologue
    iget-object v0, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v0, Lr5;

    const/4 v1, 0x0

    if-eqz v0, :cond_9f

    iget-object v2, p0, Ltd;->c:Ljava/lang/Object;

    check-cast v2, Loj0;

    if-eqz v2, :cond_9f

    iget v3, v0, Lr5;->a:I

    iget-object v2, v2, Loj0;->a:Ljava/lang/Object;

    check-cast v2, Lzl;

    iget-object v2, v2, Lzl;->a:[B

    array-length v2, v2

    if-ne v3, v2, :cond_98

    invoke-virtual {v0}, Lr5;->a()Z

    move-result v0

    if-eqz v0, :cond_2c

    iget-object v0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    if-eqz v0, :cond_25

    goto :goto_2c

    :cond_25
    const-string/jumbo p0, "Cannot create key without ID requirement with parameters with ID requirement"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    return-object v1

    :cond_2c
    :goto_2c
    iget-object v0, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v0, Lr5;

    invoke-virtual {v0}, Lr5;->a()Z

    move-result v0

    if-nez v0, :cond_44

    iget-object v0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    if-nez v0, :cond_3d

    goto :goto_44

    :cond_3d
    const-string/jumbo p0, "Cannot create key with ID requirement with parameters without ID requirement"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    return-object v1

    :cond_44
    :goto_44
    iget-object v0, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v0, Lr5;

    iget-object v0, v0, Lr5;->c:Lq5;

    sget-object v2, Lq5;->f:Lq5;

    if-ne v0, v2, :cond_51

    sget-object v0, Lui1;->a:Lzl;

    goto :goto_86

    :cond_51
    sget-object v2, Lq5;->e:Lq5;

    if-eq v0, v2, :cond_7a

    sget-object v2, Lq5;->d:Lq5;

    if-ne v0, v2, :cond_5a

    goto :goto_7a

    :cond_5a
    sget-object v2, Lq5;->c:Lq5;

    if-ne v0, v2, :cond_6b

    iget-object v0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-static {v0}, Lui1;->b(I)Lzl;

    move-result-object v0

    goto :goto_86

    :cond_6b
    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const-string/jumbo v0, "Unknown AesCmacParametersParameters.Variant: "

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v1

    :cond_7a
    :goto_7a
    iget-object v0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-static {v0}, Lui1;->a(I)Lzl;

    move-result-object v0

    :goto_86
    new-instance v1, Lm5;

    iget-object v2, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v2, Lr5;

    iget-object v3, p0, Ltd;->c:Ljava/lang/Object;

    check-cast v3, Loj0;

    iget-object p0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast p0, Ljava/lang/Integer;

    invoke-direct {v1, v2, v3, v0, p0}, Lm5;-><init>(Lr5;Loj0;Lzl;Ljava/lang/Integer;)V

    return-object v1

    :cond_98
    const-string/jumbo p0, "Key size mismatch"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    return-object v1

    :cond_9f
    const-string/jumbo p0, "Cannot build without parameters and/or key material"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    return-object v1
.end method

.method public f()Lr5;
    .registers 4

    .prologue
    iget-object v0, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    const/4 v1, 0x0

    if-eqz v0, :cond_37

    iget-object v2, p0, Ltd;->c:Ljava/lang/Object;

    check-cast v2, Ljava/lang/Integer;

    if-eqz v2, :cond_30

    iget-object v2, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v2, Lq5;

    if-eqz v2, :cond_29

    new-instance v1, Lr5;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    iget-object v2, p0, Ltd;->c:Ljava/lang/Object;

    check-cast v2, Ljava/lang/Integer;

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    iget-object p0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast p0, Lq5;

    invoke-direct {v1, v0, v2, p0}, Lr5;-><init>(IILq5;)V

    return-object v1

    :cond_29
    const-string/jumbo p0, "variant not set"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    return-object v1

    :cond_30
    const-string/jumbo p0, "tag size not set"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    return-object v1

    :cond_37
    const-string/jumbo p0, "key size not set"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    return-object v1
.end method

.method public g()Ls6;
    .registers 5

    .prologue
    iget-object v0, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v0, Lw6;

    const/4 v1, 0x0

    if-eqz v0, :cond_9a

    iget-object v2, p0, Ltd;->c:Ljava/lang/Object;

    check-cast v2, Loj0;

    if-eqz v2, :cond_9a

    iget v3, v0, Lw6;->a:I

    iget-object v2, v2, Loj0;->a:Ljava/lang/Object;

    check-cast v2, Lzl;

    iget-object v2, v2, Lzl;->a:[B

    array-length v2, v2

    if-ne v3, v2, :cond_93

    invoke-virtual {v0}, Lw6;->a()Z

    move-result v0

    if-eqz v0, :cond_2c

    iget-object v0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    if-eqz v0, :cond_25

    goto :goto_2c

    :cond_25
    const-string/jumbo p0, "Cannot create key without ID requirement with parameters with ID requirement"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    return-object v1

    :cond_2c
    :goto_2c
    iget-object v0, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v0, Lw6;

    invoke-virtual {v0}, Lw6;->a()Z

    move-result v0

    if-nez v0, :cond_44

    iget-object v0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    if-nez v0, :cond_3d

    goto :goto_44

    :cond_3d
    const-string/jumbo p0, "Cannot create key with ID requirement with parameters without ID requirement"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    return-object v1

    :cond_44
    :goto_44
    iget-object v0, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v0, Lw6;

    iget-object v0, v0, Lw6;->d:Lq5;

    sget-object v2, Lq5;->q:Lq5;

    if-ne v0, v2, :cond_51

    sget-object v0, Lui1;->a:Lzl;

    goto :goto_72

    :cond_51
    sget-object v2, Lq5;->p:Lq5;

    if-ne v0, v2, :cond_62

    iget-object v0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-static {v0}, Lui1;->a(I)Lzl;

    move-result-object v0

    goto :goto_72

    :cond_62
    sget-object v2, Lq5;->o:Lq5;

    if-ne v0, v2, :cond_84

    iget-object v0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-static {v0}, Lui1;->b(I)Lzl;

    move-result-object v0

    :goto_72
    new-instance v1, Ls6;

    iget-object v2, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v2, Lw6;

    iget-object v3, p0, Ltd;->c:Ljava/lang/Object;

    check-cast v3, Loj0;

    iget-object p0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast p0, Ljava/lang/Integer;

    invoke-direct {v1, v2, v3, v0, p0}, Ls6;-><init>(Lw6;Loj0;Lzl;Ljava/lang/Integer;)V

    return-object v1

    :cond_84
    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const-string/jumbo v0, "Unknown AesEaxParameters.Variant: "

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v1

    :cond_93
    const-string/jumbo p0, "Key size mismatch"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    return-object v1

    :cond_9a
    const-string/jumbo p0, "Cannot build without parameters and/or key material"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    return-object v1
.end method

.method public getDescription()Landroid/content/ClipDescription;
    .registers 1

    iget-object p0, p0, Ltd;->c:Ljava/lang/Object;

    check-cast p0, Landroid/content/ClipDescription;

    return-object p0
.end method

.method public h()Le7;
    .registers 5

    .prologue
    iget-object v0, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v0, Li7;

    const/4 v1, 0x0

    if-eqz v0, :cond_9a

    iget-object v2, p0, Ltd;->c:Ljava/lang/Object;

    check-cast v2, Loj0;

    if-eqz v2, :cond_9a

    iget v3, v0, Li7;->a:I

    iget-object v2, v2, Loj0;->a:Ljava/lang/Object;

    check-cast v2, Lzl;

    iget-object v2, v2, Lzl;->a:[B

    array-length v2, v2

    if-ne v3, v2, :cond_93

    invoke-virtual {v0}, Li7;->a()Z

    move-result v0

    if-eqz v0, :cond_2c

    iget-object v0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    if-eqz v0, :cond_25

    goto :goto_2c

    :cond_25
    const-string/jumbo p0, "Cannot create key without ID requirement with parameters with ID requirement"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    return-object v1

    :cond_2c
    :goto_2c
    iget-object v0, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v0, Li7;

    invoke-virtual {v0}, Li7;->a()Z

    move-result v0

    if-nez v0, :cond_44

    iget-object v0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    if-nez v0, :cond_3d

    goto :goto_44

    :cond_3d
    const-string/jumbo p0, "Cannot create key with ID requirement with parameters without ID requirement"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    return-object v1

    :cond_44
    :goto_44
    iget-object v0, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v0, Li7;

    iget-object v0, v0, Li7;->d:Lq5;

    sget-object v2, Lq5;->t:Lq5;

    if-ne v0, v2, :cond_51

    sget-object v0, Lui1;->a:Lzl;

    goto :goto_72

    :cond_51
    sget-object v2, Lq5;->s:Lq5;

    if-ne v0, v2, :cond_62

    iget-object v0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-static {v0}, Lui1;->a(I)Lzl;

    move-result-object v0

    goto :goto_72

    :cond_62
    sget-object v2, Lq5;->r:Lq5;

    if-ne v0, v2, :cond_84

    iget-object v0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-static {v0}, Lui1;->b(I)Lzl;

    move-result-object v0

    :goto_72
    new-instance v1, Le7;

    iget-object v2, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v2, Li7;

    iget-object v3, p0, Ltd;->c:Ljava/lang/Object;

    check-cast v3, Loj0;

    iget-object p0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast p0, Ljava/lang/Integer;

    invoke-direct {v1, v2, v3, v0, p0}, Le7;-><init>(Li7;Loj0;Lzl;Ljava/lang/Integer;)V

    return-object v1

    :cond_84
    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const-string/jumbo v0, "Unknown AesGcmParameters.Variant: "

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v1

    :cond_93
    const-string/jumbo p0, "Key size mismatch"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    return-object v1

    :cond_9a
    const-string/jumbo p0, "Cannot build without parameters and/or key material"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    return-object v1
.end method

.method public i()Ln7;
    .registers 5

    .prologue
    iget-object v0, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v0, Lr7;

    const/4 v1, 0x0

    if-eqz v0, :cond_9a

    iget-object v2, p0, Ltd;->c:Ljava/lang/Object;

    check-cast v2, Loj0;

    if-eqz v2, :cond_9a

    iget v3, v0, Lr7;->a:I

    iget-object v2, v2, Loj0;->a:Ljava/lang/Object;

    check-cast v2, Lzl;

    iget-object v2, v2, Lzl;->a:[B

    array-length v2, v2

    if-ne v3, v2, :cond_93

    invoke-virtual {v0}, Lr7;->a()Z

    move-result v0

    if-eqz v0, :cond_2c

    iget-object v0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    if-eqz v0, :cond_25

    goto :goto_2c

    :cond_25
    const-string/jumbo p0, "Cannot create key without ID requirement with parameters with ID requirement"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    return-object v1

    :cond_2c
    :goto_2c
    iget-object v0, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v0, Lr7;

    invoke-virtual {v0}, Lr7;->a()Z

    move-result v0

    if-nez v0, :cond_44

    iget-object v0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    if-nez v0, :cond_3d

    goto :goto_44

    :cond_3d
    const-string/jumbo p0, "Cannot create key with ID requirement with parameters without ID requirement"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    return-object v1

    :cond_44
    :goto_44
    iget-object v0, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v0, Lr7;

    iget-object v0, v0, Lr7;->b:Lq5;

    sget-object v2, Lq5;->w:Lq5;

    if-ne v0, v2, :cond_51

    sget-object v0, Lui1;->a:Lzl;

    goto :goto_72

    :cond_51
    sget-object v2, Lq5;->v:Lq5;

    if-ne v0, v2, :cond_62

    iget-object v0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-static {v0}, Lui1;->a(I)Lzl;

    move-result-object v0

    goto :goto_72

    :cond_62
    sget-object v2, Lq5;->u:Lq5;

    if-ne v0, v2, :cond_84

    iget-object v0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-static {v0}, Lui1;->b(I)Lzl;

    move-result-object v0

    :goto_72
    new-instance v1, Ln7;

    iget-object v2, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v2, Lr7;

    iget-object v3, p0, Ltd;->c:Ljava/lang/Object;

    check-cast v3, Loj0;

    iget-object p0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast p0, Ljava/lang/Integer;

    invoke-direct {v1, v2, v3, v0, p0}, Ln7;-><init>(Lr7;Loj0;Lzl;Ljava/lang/Integer;)V

    return-object v1

    :cond_84
    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const-string/jumbo v0, "Unknown AesGcmSivParameters.Variant: "

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v1

    :cond_93
    const-string/jumbo p0, "Key size mismatch"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    return-object v1

    :cond_9a
    const-string/jumbo p0, "Cannot build without parameters and/or key material"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    return-object v1
.end method

.method public j()Lyg;
    .registers 4

    .prologue
    iget-object v0, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    if-nez v0, :cond_a

    const-string/jumbo v0, " backendName"

    goto :goto_d

    :cond_a
    const-string/jumbo v0, ""

    :goto_d
    iget-object v1, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v1, Lym1;

    if-nez v1, :cond_1a

    const-string/jumbo v1, " priority"

    invoke-virtual {v0, v1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    :cond_1a
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_32

    new-instance v0, Lyg;

    iget-object v1, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    iget-object v2, p0, Ltd;->c:Ljava/lang/Object;

    check-cast v2, [B

    iget-object p0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast p0, Lym1;

    invoke-direct {v0, v1, v2, p0}, Lyg;-><init>(Ljava/lang/String;[BLym1;)V

    return-object v0

    :cond_32
    const-string/jumbo p0, "Missing required properties:"

    invoke-virtual {p0, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    const/4 p0, 0x0

    return-object p0
.end method

.method public k()Ln70;
    .registers 5

    .prologue
    iget-object v0, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v0, Lf70;

    const/4 v1, 0x0

    if-eqz v0, :cond_a3

    iget-object v2, p0, Ltd;->c:Ljava/lang/Object;

    check-cast v2, Ljava/security/spec/ECPoint;

    if-eqz v2, :cond_9c

    iget-object v0, v0, Lf70;->b:Le70;

    iget-object v0, v0, Le70;->b:Ljava/security/spec/ECParameterSpec;

    invoke-virtual {v0}, Ljava/security/spec/ECParameterSpec;->getCurve()Ljava/security/spec/EllipticCurve;

    move-result-object v0

    invoke-static {v2, v0}, Lz80;->b(Ljava/security/spec/ECPoint;Ljava/security/spec/EllipticCurve;)V

    iget-object v0, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v0, Lf70;

    invoke-virtual {v0}, Lf70;->a()Z

    move-result v0

    if-eqz v0, :cond_30

    iget-object v0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    if-eqz v0, :cond_29

    goto :goto_30

    :cond_29
    const-string/jumbo p0, "Cannot create key without ID requirement with parameters with ID requirement"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    return-object v1

    :cond_30
    :goto_30
    iget-object v0, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v0, Lf70;

    invoke-virtual {v0}, Lf70;->a()Z

    move-result v0

    if-nez v0, :cond_48

    iget-object v0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    if-nez v0, :cond_41

    goto :goto_48

    :cond_41
    const-string/jumbo p0, "Cannot create key with ID requirement with parameters without ID requirement"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    return-object v1

    :cond_48
    :goto_48
    iget-object v0, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v0, Lf70;

    iget-object v0, v0, Lf70;->d:Lq5;

    sget-object v2, Lq5;->I:Lq5;

    if-ne v0, v2, :cond_55

    sget-object v0, Lui1;->a:Lzl;

    goto :goto_8a

    :cond_55
    sget-object v2, Lq5;->H:Lq5;

    if-eq v0, v2, :cond_7e

    sget-object v2, Lq5;->G:Lq5;

    if-ne v0, v2, :cond_5e

    goto :goto_7e

    :cond_5e
    sget-object v2, Lq5;->F:Lq5;

    if-ne v0, v2, :cond_6f

    iget-object v0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-static {v0}, Lui1;->b(I)Lzl;

    move-result-object v0

    goto :goto_8a

    :cond_6f
    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const-string/jumbo v0, "Unknown EcdsaParameters.Variant: "

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v1

    :cond_7e
    :goto_7e
    iget-object v0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-static {v0}, Lui1;->a(I)Lzl;

    move-result-object v0

    :goto_8a
    new-instance v1, Ln70;

    iget-object v2, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v2, Lf70;

    iget-object v3, p0, Ltd;->c:Ljava/lang/Object;

    check-cast v3, Ljava/security/spec/ECPoint;

    iget-object p0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast p0, Ljava/lang/Integer;

    invoke-direct {v1, v2, v3, v0, p0}, Ln70;-><init>(Lf70;Ljava/security/spec/ECPoint;Lzl;Ljava/lang/Integer;)V

    return-object v1

    :cond_9c
    const-string/jumbo p0, "Cannot build without public point"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    return-object v1

    :cond_a3
    const-string/jumbo p0, "Cannot build without parameters"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    return-object v1
.end method

.method public l()Lwn0;
    .registers 5

    .prologue
    iget-object v0, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v0, Lbo0;

    const/4 v1, 0x0

    if-eqz v0, :cond_9f

    iget-object v2, p0, Ltd;->c:Ljava/lang/Object;

    check-cast v2, Loj0;

    if-eqz v2, :cond_9f

    iget v3, v0, Lbo0;->a:I

    iget-object v2, v2, Loj0;->a:Ljava/lang/Object;

    check-cast v2, Lzl;

    iget-object v2, v2, Lzl;->a:[B

    array-length v2, v2

    if-ne v3, v2, :cond_98

    invoke-virtual {v0}, Lbo0;->a()Z

    move-result v0

    if-eqz v0, :cond_2c

    iget-object v0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    if-eqz v0, :cond_25

    goto :goto_2c

    :cond_25
    const-string/jumbo p0, "Cannot create key without ID requirement with parameters with ID requirement"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    return-object v1

    :cond_2c
    :goto_2c
    iget-object v0, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v0, Lbo0;

    invoke-virtual {v0}, Lbo0;->a()Z

    move-result v0

    if-nez v0, :cond_44

    iget-object v0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    if-nez v0, :cond_3d

    goto :goto_44

    :cond_3d
    const-string/jumbo p0, "Cannot create key with ID requirement with parameters without ID requirement"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    return-object v1

    :cond_44
    :goto_44
    iget-object v0, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v0, Lbo0;

    iget-object v0, v0, Lbo0;->c:Lq5;

    sget-object v2, Lq5;->Q:Lq5;

    if-ne v0, v2, :cond_51

    sget-object v0, Lui1;->a:Lzl;

    goto :goto_86

    :cond_51
    sget-object v2, Lq5;->P:Lq5;

    if-eq v0, v2, :cond_7a

    sget-object v2, Lq5;->O:Lq5;

    if-ne v0, v2, :cond_5a

    goto :goto_7a

    :cond_5a
    sget-object v2, Lq5;->N:Lq5;

    if-ne v0, v2, :cond_6b

    iget-object v0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-static {v0}, Lui1;->b(I)Lzl;

    move-result-object v0

    goto :goto_86

    :cond_6b
    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const-string/jumbo v0, "Unknown HmacParameters.Variant: "

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v1

    :cond_7a
    :goto_7a
    iget-object v0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-static {v0}, Lui1;->a(I)Lzl;

    move-result-object v0

    :goto_86
    new-instance v1, Lwn0;

    iget-object v2, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v2, Lbo0;

    iget-object v3, p0, Ltd;->c:Ljava/lang/Object;

    check-cast v3, Loj0;

    iget-object p0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast p0, Ljava/lang/Integer;

    invoke-direct {v1, v2, v3, v0, p0}, Lwn0;-><init>(Lbo0;Loj0;Lzl;Ljava/lang/Integer;)V

    return-object v1

    :cond_98
    const-string/jumbo p0, "Key size mismatch"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    return-object v1

    :cond_9f
    const-string/jumbo p0, "Cannot build without parameters and/or key material"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    return-object v1
.end method

.method public m()Lgi1;
    .registers 42

    .prologue
    move-object/from16 v1, p0

    new-instance v2, Lgi1;

    iget-object v3, v1, Ltd;->b:Ljava/lang/Object;

    check-cast v3, Ljava/util/UUID;

    iget-object v4, v1, Ltd;->c:Ljava/lang/Object;

    check-cast v4, Lvq2;

    iget-object v5, v1, Ltd;->d:Ljava/lang/Object;

    check-cast v5, Ljava/util/LinkedHashSet;

    invoke-direct {v2, v3, v4, v5}, Lgi1;-><init>(Ljava/util/UUID;Lvq2;Ljava/util/LinkedHashSet;)V

    iget-object v3, v4, Lvq2;->j:Lyw;

    iget-object v4, v3, Lyw;->i:Ljava/util/Set;

    check-cast v4, Ljava/util/Collection;

    invoke-interface {v4}, Ljava/util/Collection;->isEmpty()Z

    move-result v4

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eqz v4, :cond_30

    iget-boolean v4, v3, Lyw;->e:Z

    if-nez v4, :cond_30

    iget-boolean v4, v3, Lyw;->c:Z

    if-nez v4, :cond_30

    iget-boolean v3, v3, Lyw;->d:Z

    if-eqz v3, :cond_2e

    goto :goto_30

    :cond_2e
    move v3, v6

    goto :goto_31

    :cond_30
    :goto_30
    move v3, v5

    :goto_31
    iget-object v4, v1, Ltd;->c:Ljava/lang/Object;

    check-cast v4, Lvq2;

    iget-boolean v7, v4, Lvq2;->q:Z

    if-eqz v7, :cond_53

    const/4 v7, 0x0

    if-nez v3, :cond_4c

    iget-wide v8, v4, Lvq2;->g:J

    const-wide/16 v10, 0x0

    cmp-long v3, v8, v10

    if-gtz v3, :cond_45

    goto :goto_53

    :cond_45
    const-string/jumbo v1, "Expedited jobs cannot be delayed"

    invoke-static {v1}, Lz6;->s(Ljava/lang/String;)V

    return-object v7

    :cond_4c
    const-string/jumbo v1, "Expedited jobs only support network and storage constraints"

    invoke-static {v1}, Lz6;->s(Ljava/lang/String;)V

    return-object v7

    :cond_53
    :goto_53
    iget-object v3, v4, Lvq2;->x:Ljava/lang/String;

    const/16 v7, 0x7f

    if-nez v3, :cond_88

    iget-object v3, v4, Lvq2;->c:Ljava/lang/String;

    const-string/jumbo v8, "."

    filled-new-array {v8}, [Ljava/lang/String;

    move-result-object v8

    const/4 v9, 0x6

    invoke-static {v3, v8, v9}, Lc72;->E0(Ljava/lang/CharSequence;[Ljava/lang/String;I)Ljava/util/List;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v8

    if-ne v8, v5, :cond_74

    invoke-interface {v3, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    goto :goto_7a

    :cond_74
    invoke-static {v3}, Lbs;->q0(Ljava/util/List;)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    :goto_7a
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v5

    if-gt v5, v7, :cond_81

    goto :goto_85

    :cond_81
    invoke-static {v7, v3}, Lc72;->G0(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v3

    :goto_85
    iput-object v3, v4, Lvq2;->x:Ljava/lang/String;

    goto :goto_98

    :cond_88
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v4

    if-le v4, v7, :cond_98

    iget-object v4, v1, Ltd;->c:Ljava/lang/Object;

    check-cast v4, Lvq2;

    invoke-static {v7, v3}, Lc72;->G0(ILjava/lang/String;)Ljava/lang/String;

    move-result-object v3

    iput-object v3, v4, Lvq2;->x:Ljava/lang/String;

    :cond_98
    :goto_98
    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iput-object v3, v1, Ltd;->b:Ljava/lang/Object;

    new-instance v4, Lvq2;

    invoke-virtual {v3}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v3, v1, Ltd;->c:Ljava/lang/Object;

    check-cast v3, Lvq2;

    iget-object v7, v3, Lvq2;->c:Ljava/lang/String;

    iget-object v6, v3, Lvq2;->b:Lmq2;

    iget-object v8, v3, Lvq2;->d:Ljava/lang/String;

    new-instance v9, Lw00;

    iget-object v10, v3, Lvq2;->e:Lw00;

    invoke-direct {v9, v10}, Lw00;-><init>(Lw00;)V

    new-instance v10, Lw00;

    iget-object v11, v3, Lvq2;->f:Lw00;

    invoke-direct {v10, v11}, Lw00;-><init>(Lw00;)V

    iget-wide v11, v3, Lvq2;->g:J

    iget-wide v13, v3, Lvq2;->h:J

    iget-wide v15, v3, Lvq2;->i:J

    move-object/from16 v38, v2

    new-instance v2, Lyw;

    move-object/from16 v17, v4

    iget-object v4, v3, Lvq2;->j:Lyw;

    invoke-direct {v2, v4}, Lyw;-><init>(Lyw;)V

    iget v4, v3, Lvq2;->k:I

    move-object/from16 v18, v2

    iget-object v2, v3, Lvq2;->l:Lih;

    move/from16 v20, v4

    move-object/from16 v19, v5

    iget-wide v4, v3, Lvq2;->m:J

    move-wide/from16 v21, v4

    iget-wide v4, v3, Lvq2;->n:J

    move-wide/from16 v23, v4

    iget-wide v4, v3, Lvq2;->o:J

    move-wide/from16 v25, v4

    iget-wide v4, v3, Lvq2;->p:J

    move-object/from16 v27, v2

    iget-boolean v2, v3, Lvq2;->q:Z

    move/from16 v28, v2

    iget-object v2, v3, Lvq2;->r:Lri1;

    move-object/from16 v29, v2

    iget v2, v3, Lvq2;->s:I

    move-wide/from16 v30, v4

    iget-wide v4, v3, Lvq2;->u:J

    move/from16 v32, v2

    iget v2, v3, Lvq2;->v:I

    move/from16 v33, v2

    iget v2, v3, Lvq2;->w:I

    move/from16 v34, v2

    iget-object v2, v3, Lvq2;->x:Ljava/lang/String;

    iget-object v3, v3, Lvq2;->y:Ljava/lang/Boolean;

    const/high16 v37, 0x80000

    move-object/from16 v35, v2

    move-object/from16 v36, v3

    move-wide/from16 v39, v4

    move-object/from16 v4, v17

    move-object/from16 v17, v18

    move-object/from16 v5, v19

    move/from16 v18, v20

    move-wide/from16 v20, v21

    move-wide/from16 v22, v23

    move-wide/from16 v24, v25

    move-object/from16 v19, v27

    move-wide/from16 v26, v30

    move/from16 v30, v32

    move-wide/from16 v31, v39

    invoke-direct/range {v4 .. v37}, Lvq2;-><init>(Ljava/lang/String;Lmq2;Ljava/lang/String;Ljava/lang/String;Lw00;Lw00;JJJLyw;ILih;JJJJZLri1;IJIILjava/lang/String;Ljava/lang/Boolean;I)V

    iput-object v4, v1, Ltd;->c:Ljava/lang/Object;

    return-object v38
.end method

.method public n()Lzv1;
    .registers 5

    .prologue
    iget-object v0, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v0, Lrv1;

    const/4 v1, 0x0

    if-eqz v0, :cond_b0

    iget-object v0, p0, Ltd;->c:Ljava/lang/Object;

    check-cast v0, Ljava/math/BigInteger;

    if-eqz v0, :cond_a9

    invoke-virtual {v0}, Ljava/math/BigInteger;->bitLength()I

    move-result v0

    iget-object v2, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v2, Lrv1;

    iget v3, v2, Lrv1;->a:I

    if-ne v0, v3, :cond_99

    invoke-virtual {v2}, Lrv1;->a()Z

    move-result v0

    if-eqz v0, :cond_2d

    iget-object v0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    if-eqz v0, :cond_26

    goto :goto_2d

    :cond_26
    const-string/jumbo p0, "Cannot create key without ID requirement with parameters with ID requirement"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    return-object v1

    :cond_2d
    :goto_2d
    iget-object v0, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v0, Lrv1;

    invoke-virtual {v0}, Lrv1;->a()Z

    move-result v0

    if-nez v0, :cond_45

    iget-object v0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    if-nez v0, :cond_3e

    goto :goto_45

    :cond_3e
    const-string/jumbo p0, "Cannot create key with ID requirement with parameters without ID requirement"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    return-object v1

    :cond_45
    :goto_45
    iget-object v0, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v0, Lrv1;

    iget-object v0, v0, Lrv1;->c:Lq5;

    sget-object v2, Lq5;->s0:Lq5;

    if-ne v0, v2, :cond_52

    sget-object v0, Lui1;->a:Lzl;

    goto :goto_87

    :cond_52
    sget-object v2, Lq5;->r0:Lq5;

    if-eq v0, v2, :cond_7b

    sget-object v2, Lq5;->q0:Lq5;

    if-ne v0, v2, :cond_5b

    goto :goto_7b

    :cond_5b
    sget-object v2, Lq5;->p0:Lq5;

    if-ne v0, v2, :cond_6c

    iget-object v0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-static {v0}, Lui1;->b(I)Lzl;

    move-result-object v0

    goto :goto_87

    :cond_6c
    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const-string/jumbo v0, "Unknown RsaSsaPkcs1Parameters.Variant: "

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v1

    :cond_7b
    :goto_7b
    iget-object v0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-static {v0}, Lui1;->a(I)Lzl;

    move-result-object v0

    :goto_87
    new-instance v1, Lzv1;

    iget-object v2, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v2, Lrv1;

    iget-object v3, p0, Ltd;->c:Ljava/lang/Object;

    check-cast v3, Ljava/math/BigInteger;

    iget-object p0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast p0, Ljava/lang/Integer;

    invoke-direct {v1, v2, v3, v0, p0}, Lzv1;-><init>(Lrv1;Ljava/math/BigInteger;Lzl;Ljava/lang/Integer;)V

    return-object v1

    :cond_99
    new-instance p0, Ljava/security/GeneralSecurityException;

    const-string/jumbo v1, "Got modulus size "

    const-string/jumbo v2, ", but parameters requires modulus size "

    invoke-static {v0, v3, v1, v2}, Ly41;->o(IILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_a9
    const-string/jumbo p0, "Cannot build without modulus"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    return-object v1

    :cond_b0
    const-string/jumbo p0, "Cannot build without parameters"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    return-object v1
.end method

.method public o()Lsw1;
    .registers 5

    .prologue
    iget-object v0, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v0, Ljw1;

    const/4 v1, 0x0

    if-eqz v0, :cond_b0

    iget-object v0, p0, Ltd;->c:Ljava/lang/Object;

    check-cast v0, Ljava/math/BigInteger;

    if-eqz v0, :cond_a9

    invoke-virtual {v0}, Ljava/math/BigInteger;->bitLength()I

    move-result v0

    iget-object v2, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v2, Ljw1;

    iget v3, v2, Ljw1;->a:I

    if-ne v0, v3, :cond_99

    invoke-virtual {v2}, Ljw1;->a()Z

    move-result v0

    if-eqz v0, :cond_2d

    iget-object v0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    if-eqz v0, :cond_26

    goto :goto_2d

    :cond_26
    const-string/jumbo p0, "Cannot create key without ID requirement with parameters with ID requirement"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    return-object v1

    :cond_2d
    :goto_2d
    iget-object v0, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v0, Ljw1;

    invoke-virtual {v0}, Ljw1;->a()Z

    move-result v0

    if-nez v0, :cond_45

    iget-object v0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    if-nez v0, :cond_3e

    goto :goto_45

    :cond_3e
    const-string/jumbo p0, "Cannot create key with ID requirement with parameters without ID requirement"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    return-object v1

    :cond_45
    :goto_45
    iget-object v0, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v0, Ljw1;

    iget-object v0, v0, Ljw1;->c:Lq5;

    sget-object v2, Lq5;->w0:Lq5;

    if-ne v0, v2, :cond_52

    sget-object v0, Lui1;->a:Lzl;

    goto :goto_87

    :cond_52
    sget-object v2, Lq5;->v0:Lq5;

    if-eq v0, v2, :cond_7b

    sget-object v2, Lq5;->u0:Lq5;

    if-ne v0, v2, :cond_5b

    goto :goto_7b

    :cond_5b
    sget-object v2, Lq5;->t0:Lq5;

    if-ne v0, v2, :cond_6c

    iget-object v0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-static {v0}, Lui1;->b(I)Lzl;

    move-result-object v0

    goto :goto_87

    :cond_6c
    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const-string/jumbo v0, "Unknown RsaSsaPssParameters.Variant: "

    invoke-virtual {v0, p0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Lz6;->w(Ljava/lang/String;)V

    return-object v1

    :cond_7b
    :goto_7b
    iget-object v0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/Integer;

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    invoke-static {v0}, Lui1;->a(I)Lzl;

    move-result-object v0

    :goto_87
    new-instance v1, Lsw1;

    iget-object v2, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v2, Ljw1;

    iget-object v3, p0, Ltd;->c:Ljava/lang/Object;

    check-cast v3, Ljava/math/BigInteger;

    iget-object p0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast p0, Ljava/lang/Integer;

    invoke-direct {v1, v2, v3, v0, p0}, Lsw1;-><init>(Ljw1;Ljava/math/BigInteger;Lzl;Ljava/lang/Integer;)V

    return-object v1

    :cond_99
    new-instance p0, Ljava/security/GeneralSecurityException;

    const-string/jumbo v1, "Got modulus size "

    const-string/jumbo v2, ", but parameters requires modulus size "

    invoke-static {v0, v3, v1, v2}, Ly41;->o(IILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-direct {p0, v0}, Ljava/security/GeneralSecurityException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_a9
    const-string/jumbo p0, "Cannot build without modulus"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    return-object v1

    :cond_b0
    const-string/jumbo p0, "Cannot build without parameters"

    invoke-static {p0}, Lvx2;->t(Ljava/lang/String;)V

    return-object v1
.end method

.method public q([B)[B
    .registers 16

    .prologue
    const/16 v0, 0xd89

    iget-object v2, p0, Ltd;->b:Ljava/lang/Object;

    nop

    check-cast v2, Ljavax/crypto/Cipher;

    const/4 v3, 0x0

    new-array v4, v3, [B

    const/16 v0, 0xd63

    iget-object p0, p0, Ltd;->d:Ljava/lang/Object;

    nop

    check-cast p0, [[B

    array-length v5, p0

    :goto_12
    if-ge v3, v5, :cond_f4

    aget-object v6, p0, v3

    :try_start_16
    const/16 v0, 0x905

    sget-boolean v7, Lmi2;->a:Z

    nop

    const/16 v0, 0x105

    invoke-static {p1}, Laf;->p0([B)[B

    move-result-object v7

    const/4 v8, 0x2

    const/16 v0, 0x40

    invoke-static {v7, v8}, Landroid/util/Base64;->decode([BI)[B

    move-result-object v7

    const/4 v0, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x58f

    new-instance v9, Ljavax/crypto/spec/SecretKeySpec;

    nop

    const-string/jumbo v10, "AES"

    const/16 v0, 0x722

    invoke-direct {v9, v6, v10}, Ljavax/crypto/spec/SecretKeySpec;-><init>([BLjava/lang/String;)V

    array-length v10, v7

    add-int/lit16 v10, v10, -0x84

    div-int/2addr v10, v8

    const/16 v11, 0xc

    add-int/2addr v10, v11

    array-length v12, v7

    add-int/lit16 v12, v12, -0x84

    div-int/2addr v12, v8

    add-int/lit8 v12, v12, 0x1e

    const/16 v0, 0x145

    invoke-static {v7, v10, v12}, Laf;->g0([BII)[B

    move-result-object v10

    const/16 v0, 0x105

    invoke-static {v10}, Laf;->p0([B)[B

    move-result-object v10

    array-length v12, v7

    add-int/lit8 v12, v12, -0x66

    array-length v13, v7

    add-int/lit8 v13, v13, -0x54

    const/16 v0, 0x145

    invoke-static {v7, v12, v13}, Laf;->g0([BII)[B

    move-result-object v12

    const/16 v0, 0x105

    invoke-static {v12}, Laf;->p0([B)[B

    move-result-object v12

    const/16 v0, 0xe5

    invoke-static {v10, v12}, Laf;->o0([B[B)[B

    move-result-object v10

    array-length v12, v7

    add-int/lit16 v12, v12, -0x84

    div-int/2addr v12, v8

    add-int/2addr v12, v11

    const/16 v0, 0x145

    invoke-static {v7, v11, v12}, Laf;->g0([BII)[B

    move-result-object v11

    const/16 v0, 0x105

    invoke-static {v11}, Laf;->p0([B)[B

    move-result-object v11

    array-length v12, v7

    add-int/lit16 v12, v12, -0x84

    div-int/2addr v12, v8

    add-int/lit8 v12, v12, 0x1e

    array-length v13, v7

    add-int/lit8 v13, v13, -0x66

    const/16 v0, 0x145

    invoke-static {v7, v12, v13}, Laf;->g0([BII)[B

    move-result-object v7

    const/16 v0, 0x105

    invoke-static {v7}, Laf;->p0([B)[B

    move-result-object v7

    const/16 v0, 0xe5

    invoke-static {v11, v7}, Laf;->o0([B[B)[B

    move-result-object v7

    const/16 v0, 0xa2d

    new-instance v11, Ljavax/crypto/spec/IvParameterSpec;

    nop

    const/16 v0, 0x10d1

    invoke-direct {v11, v10}, Ljavax/crypto/spec/IvParameterSpec;-><init>([B)V

    const/16 v0, 0xa08

    invoke-virtual {v2, v8, v9, v11}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;Ljava/security/spec/AlgorithmParameterSpec;)V

    const/16 v0, 0x950

    invoke-virtual {v2, v7}, Ljavax/crypto/Cipher;->doFinal([B)[B

    move-result-object v7

    const/4 v0, -0x6

    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_af
    .catch Ljava/lang/Exception; {:try_start_16 .. :try_end_af} :catch_b1

    move-object v4, v7

    goto :goto_f0

    :catch_b1
    move-exception v7

    const/4 v0, -0x3

    new-instance v8, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v9, "decryptCfg: ["

    const/16 v0, 0x97

    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    array-length v6, v6

    const/16 v0, 0x33

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v6, "] "

    const/4 v0, 0x0

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0xda1

    invoke-virtual {v7}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v6

    const/16 v0, 0x190

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v6, 0x20

    const/16 v0, 0x1b

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v0, 0x1da

    invoke-virtual {v7}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v6

    const/4 v0, 0x0

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const-string/jumbo v7, "Cryptor"

    nop

    :goto_f0
    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_12

    :cond_f4
    return-object v4
.end method

.method public r([B)Ljava/lang/String;
    .registers 16

    .prologue
    const/16 v0, 0xd89

    iget-object v2, p0, Ltd;->b:Ljava/lang/Object;

    nop

    check-cast v2, Ljavax/crypto/Cipher;

    const/16 v0, 0x788

    iget-object p0, p0, Ltd;->c:Ljava/lang/Object;

    nop

    check-cast p0, [[B

    array-length v3, p0

    const-string/jumbo v4, ""

    const/4 v5, 0x0

    move v6, v5

    :goto_14
    if-ge v6, v3, :cond_bd

    aget-object v7, p0, v6

    :try_start_18
    const/16 v0, 0x905

    sget-boolean v8, Lmi2;->a:Z

    nop

    const/4 v8, 0x2

    const/16 v0, 0x40

    invoke-static {p1, v8}, Landroid/util/Base64;->decode([BI)[B

    move-result-object v9

    const/4 v0, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x58f

    new-instance v10, Ljavax/crypto/spec/SecretKeySpec;

    nop

    const-string/jumbo v11, "AES"

    const/16 v0, 0x722

    invoke-direct {v10, v7, v11}, Ljavax/crypto/spec/SecretKeySpec;-><init>([BLjava/lang/String;)V

    const/16 v11, 0x24

    const/16 v0, 0x145

    invoke-static {v9, v5, v11}, Laf;->g0([BII)[B

    move-result-object v12

    array-length v13, v9

    const/16 v0, 0x145

    invoke-static {v9, v11, v13}, Laf;->g0([BII)[B

    move-result-object v9

    const/16 v0, 0xa2d

    new-instance v11, Ljavax/crypto/spec/IvParameterSpec;

    nop

    const/16 v0, 0x10d1

    invoke-direct {v11, v12}, Ljavax/crypto/spec/IvParameterSpec;-><init>([B)V

    const/16 v0, 0xa08

    invoke-virtual {v2, v8, v10, v11}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;Ljava/security/spec/AlgorithmParameterSpec;)V

    const/16 v0, 0x950

    invoke-virtual {v2, v9}, Ljavax/crypto/Cipher;->doFinal([B)[B

    move-result-object v8

    const/4 v0, -0x6

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v9, Ljava/lang/String;

    const/16 v0, 0x2e4

    sget-object v10, Lip;->a:Ljava/nio/charset/Charset;

    nop

    check-cast v10, Ljava/nio/charset/Charset;

    invoke-direct {v9, v8, v10}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V
    :try_end_69
    .catch Ljava/lang/Exception; {:try_start_18 .. :try_end_69} :catch_77

    :try_start_69
    const/16 v0, 0x47

    invoke-virtual {v9}, Ljava/lang/String;->length()I

    move-result v4
    :try_end_6f
    .catch Ljava/lang/Exception; {:try_start_69 .. :try_end_6f} :catch_75

    if-lez v4, :cond_73

    move-object v4, v9

    goto :goto_bd

    :cond_73
    :goto_73
    move-object v4, v9

    goto :goto_b9

    :catch_75
    move-exception v4

    goto :goto_7a

    :catch_77
    move-exception v8

    move-object v9, v4

    move-object v4, v8

    :goto_7a
    const/4 v0, -0x3

    new-instance v8, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v10, "decryptServerList: ["

    const/16 v0, 0x97

    invoke-direct {v8, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    array-length v7, v7

    const/16 v0, 0x33

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v7, "] "

    const/4 v0, 0x0

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0xda1

    invoke-virtual {v4}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v7

    const/16 v0, 0x190

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v7, 0x20

    const/16 v0, 0x1b

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v0, 0x1da

    invoke-virtual {v4}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v4

    const/4 v0, 0x0

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const-string/jumbo v7, "Cryptor"

    nop

    goto :goto_73

    :goto_b9
    add-int/lit8 v6, v6, 0x1

    goto/16 :goto_14

    :cond_bd
    :goto_bd
    check-cast v4, Ljava/lang/String;

    return-object v4
.end method

.method public t(Landroid/os/Bundle;)V
    .registers 8

    .prologue
    iget-object v0, p0, Ltd;->c:Ljava/lang/Object;

    check-cast v0, Ljava/util/HashSet;

    iget-object v1, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v1, Landroid/content/Context;

    const v2, 0x7f130021

    invoke-virtual {v1, v2}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    if-eqz p1, :cond_60

    :try_start_11
    new-instance v2, Ljava/util/HashSet;

    invoke-direct {v2}, Ljava/util/HashSet;-><init>()V

    invoke-virtual {p1}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :cond_1e
    :goto_1e
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_45

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    const/4 v5, 0x0

    invoke-virtual {p1, v4, v5}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_1e

    invoke-static {v4}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v4

    const-class v5, Lkr0;

    invoke-virtual {v5, v4}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v5

    if-eqz v5, :cond_1e

    invoke-virtual {v0, v4}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    goto :goto_1e

    :cond_45
    invoke-virtual {v0}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_49
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_60

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/Class;

    invoke-virtual {p0, v0, v2}, Ltd;->u(Ljava/lang/Class;Ljava/util/HashSet;)Ljava/lang/Object;
    :try_end_58
    .catch Ljava/lang/ClassNotFoundException; {:try_start_11 .. :try_end_58} :catch_59

    goto :goto_49

    :catch_59
    move-exception p0

    new-instance p1, Lft;

    invoke-direct {p1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    throw p1

    :cond_60
    return-void
.end method

.method public toString()Ljava/lang/String;
    .registers 5

    .prologue
    iget v0, p0, Ltd;->a:I

    packed-switch v0, :pswitch_data_a6

    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :pswitch_a  #0x18
    iget-object v0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast v0, Ljava/lang/String;

    iget-object v1, p0, Ltd;->c:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string/jumbo v3, "NavDeepLinkRequest{"

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object p0, p0, Ltd;->b:Ljava/lang/Object;

    check-cast p0, Landroid/net/Uri;

    if-eqz p0, :cond_2d

    const-string/jumbo v3, " uri="

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_2d
    if-eqz v1, :cond_38

    const-string/jumbo p0, " action="

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_38
    if-eqz v0, :cond_43

    const-string/jumbo p0, " mimetype="

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_43
    const-string/jumbo p0, " }"

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :pswitch_4e  #0x17
    new-instance v0, Ljava/lang/StringBuilder;

    const/16 v1, 0x20

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    iget-object v1, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v1, Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v1, 0x7b

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    iget-object p0, p0, Ltd;->c:Ljava/lang/Object;

    check-cast p0, Lfm0;

    iget-object p0, p0, Lfm0;->c:Ljava/lang/Object;

    check-cast p0, Lfm0;

    const-string/jumbo v1, ""

    :goto_6c
    if-eqz p0, :cond_9c

    iget-object v2, p0, Lfm0;->b:Ljava/lang/Object;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    if-eqz v2, :cond_91

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Class;->isArray()Z

    move-result v1

    if-eqz v1, :cond_91

    filled-new-array {v2}, [Ljava/lang/Object;

    move-result-object v1

    invoke-static {v1}, Ljava/util/Arrays;->deepToString([Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v3, 0x1

    sub-int/2addr v2, v3

    invoke-virtual {v0, v1, v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/CharSequence;II)Ljava/lang/StringBuilder;

    goto :goto_94

    :cond_91
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    :goto_94
    iget-object p0, p0, Lfm0;->c:Ljava/lang/Object;

    check-cast p0, Lfm0;

    const-string/jumbo v1, ", "

    goto :goto_6c

    :cond_9c
    const/16 p0, 0x7d

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0

    :pswitch_data_a6
    .packed-switch 0x17
        :pswitch_4e  #00000017
        :pswitch_a  #00000018
    .end packed-switch
.end method

.method public u(Ljava/lang/Class;Ljava/util/HashSet;)Ljava/lang/Object;
    .registers 8

    .prologue
    iget-object v0, p0, Ltd;->b:Ljava/lang/Object;

    check-cast v0, Ljava/util/HashMap;

    const-string/jumbo v1, "Cannot initialize "

    invoke-static {}, Lq23;->C()Z

    move-result v2

    if-eqz v2, :cond_18

    :try_start_d
    invoke-virtual {p1}, Ljava/lang/Class;->getSimpleName()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lq23;->b0(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    :cond_18
    invoke-virtual {p2, p1}, Ljava/util/HashSet;->contains(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_74

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_6c

    invoke-virtual {p2, p1}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z
    :try_end_27
    .catchall {:try_start_d .. :try_end_27} :catchall_90

    const/4 v1, 0x0

    :try_start_28
    invoke-virtual {p1, v1}, Ljava/lang/Class;->getDeclaredConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lkr0;

    invoke-interface {v1}, Lkr0;->a()Ljava/util/List;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    move-result v3

    if-nez v3, :cond_56

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_40
    :goto_40
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_56

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/Class;

    invoke-virtual {v0, v3}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_40

    invoke-virtual {p0, v3, p2}, Ltd;->u(Ljava/lang/Class;Ljava/util/HashSet;)Ljava/lang/Object;

    goto :goto_40

    :cond_56
    iget-object p0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast p0, Landroid/content/Context;

    invoke-interface {v1, p0}, Lkr0;->b(Landroid/content/Context;)Ljava/lang/Object;

    move-result-object p0

    invoke-virtual {p2, p1}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    invoke-virtual {v0, p1, p0}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_64
    .catchall {:try_start_28 .. :try_end_64} :catchall_65

    goto :goto_70

    :catchall_65
    move-exception p0

    :try_start_66
    new-instance p1, Lft;

    invoke-direct {p1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    throw p1

    :cond_6c
    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0
    :try_end_70
    .catchall {:try_start_66 .. :try_end_70} :catchall_90

    :goto_70
    invoke-static {}, Landroid/os/Trace;->endSection()V

    return-object p0

    :cond_74
    :try_start_74
    invoke-virtual {p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo p0, ". Cycle detected."

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    new-instance p1, Ljava/lang/IllegalStateException;

    invoke-direct {p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
    :try_end_90
    .catchall {:try_start_74 .. :try_end_90} :catchall_90

    :catchall_90
    move-exception p0

    invoke-static {}, Landroid/os/Trace;->endSection()V

    throw p0
.end method

.method public v([B)[B
    .registers 13

    .prologue
    const/16 v0, 0xd89

    iget-object v2, p0, Ltd;->b:Ljava/lang/Object;

    nop

    check-cast v2, Ljavax/crypto/Cipher;

    const/4 v3, 0x0

    :try_start_8
    const/16 v0, 0x58f

    new-instance v4, Ljavax/crypto/spec/SecretKeySpec;

    nop

    const/16 v0, 0xd63

    iget-object p0, p0, Ltd;->d:Ljava/lang/Object;

    nop

    check-cast p0, [[B

    const/16 v0, 0x86d

    invoke-static {p0}, Laf;->j0([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    check-cast p0, [B

    const-string/jumbo v5, "AES"

    const/16 v0, 0x722

    invoke-direct {v4, p0, v5}, Ljavax/crypto/spec/SecretKeySpec;-><init>([BLjava/lang/String;)V

    const/16 p0, 0x24

    new-array v5, p0, [B

    const/16 v6, 0xc

    new-array v6, v6, [B

    const/16 v7, 0x54

    new-array v7, v7, [B

    const/16 v0, 0x26c

    new-instance v8, Ljava/security/SecureRandom;

    nop

    const/16 v0, 0x221

    invoke-direct {v8}, Ljava/security/SecureRandom;-><init>()V

    const/16 v0, 0x20d

    invoke-virtual {v8, v5}, Ljava/security/SecureRandom;->nextBytes([B)V

    const/16 v0, 0x26c

    new-instance v8, Ljava/security/SecureRandom;

    nop

    const/16 v0, 0x221

    invoke-direct {v8}, Ljava/security/SecureRandom;-><init>()V

    const/16 v0, 0x20d

    invoke-virtual {v8, v6}, Ljava/security/SecureRandom;->nextBytes([B)V

    const/16 v0, 0x26c

    new-instance v8, Ljava/security/SecureRandom;

    nop

    const/16 v0, 0x221

    invoke-direct {v8}, Ljava/security/SecureRandom;-><init>()V

    const/16 v0, 0x20d

    invoke-virtual {v8, v7}, Ljava/security/SecureRandom;->nextBytes([B)V

    const/16 v0, 0xa2d

    new-instance v8, Ljavax/crypto/spec/IvParameterSpec;

    nop

    const/16 v0, 0x10d1

    invoke-direct {v8, v5}, Ljavax/crypto/spec/IvParameterSpec;-><init>([B)V

    const/4 v9, 0x1

    const/16 v0, 0xa08

    invoke-virtual {v2, v9, v4, v8}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;Ljava/security/spec/AlgorithmParameterSpec;)V

    const/16 v0, 0x950

    invoke-virtual {v2, p1}, Ljavax/crypto/Cipher;->doFinal([B)[B

    move-result-object p1

    new-instance v2, Ljava/lang/String;

    const/16 v0, 0x905

    sget-boolean v4, Lmi2;->a:Z

    nop

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    array-length v4, p1

    const/4 v8, 0x2

    div-int/2addr v4, v8

    const/16 v0, 0x145

    invoke-static {p1, v3, v4}, Laf;->g0([BII)[B

    move-result-object v4

    const/16 v0, 0x105

    invoke-static {v4}, Laf;->p0([B)[B

    move-result-object v4

    const/16 v0, 0xe5

    invoke-static {v6, v4}, Laf;->o0([B[B)[B

    move-result-object v4

    const/16 v6, 0x12

    const/16 v0, 0x145

    invoke-static {v5, v3, v6}, Laf;->g0([BII)[B

    move-result-object v9

    const/16 v0, 0x105

    invoke-static {v9}, Laf;->p0([B)[B

    move-result-object v9

    const/16 v0, 0xe5

    invoke-static {v4, v9}, Laf;->o0([B[B)[B

    move-result-object v4

    array-length v9, p1

    div-int/2addr v9, v8

    array-length v10, p1

    const/16 v0, 0x145

    invoke-static {p1, v9, v10}, Laf;->g0([BII)[B

    move-result-object p1

    const/16 v0, 0x105

    invoke-static {p1}, Laf;->p0([B)[B

    move-result-object p1

    const/16 v0, 0xe5

    invoke-static {v4, p1}, Laf;->o0([B[B)[B

    move-result-object p1

    const/16 v0, 0x145

    invoke-static {v5, v6, p0}, Laf;->g0([BII)[B

    move-result-object p0

    const/16 v0, 0x105

    invoke-static {p0}, Laf;->p0([B)[B

    move-result-object p0

    const/16 v0, 0xe5

    invoke-static {p1, p0}, Laf;->o0([B[B)[B

    move-result-object p0

    const/16 v0, 0xe5

    invoke-static {p0, v7}, Laf;->o0([B[B)[B

    move-result-object p0

    const/16 v0, 0x3e

    invoke-static {p0, v8}, Landroid/util/Base64;->encode([BI)[B

    move-result-object p0

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x2e4

    sget-object p1, Lip;->a:Ljava/nio/charset/Charset;

    nop

    check-cast p1, Ljava/nio/charset/Charset;

    invoke-direct {v2, p0, p1}, Ljava/lang/String;-><init>([BLjava/nio/charset/Charset;)V

    const-string/jumbo p0, "="

    const-string/jumbo v4, ""

    const/16 v0, 0x1a

    invoke-static {v2, p0, v4, v3}, Lk72;->h0(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Z)Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x511

    invoke-static {p0}, Lc72;->B0(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    const/16 v0, 0xcb

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const/16 v0, 0x2c

    invoke-virtual {p0, p1}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object p0

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_10a
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_10a} :catch_10b

    return-object p0

    :catch_10b
    move-exception p0

    const/4 v0, -0x3

    new-instance p1, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v2, "encryptCfg: "

    const/16 v0, 0x97

    invoke-direct {p1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0xda1

    invoke-virtual {p0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v2

    const/16 v0, 0x190

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/16 v2, 0x20

    const/16 v0, 0x1b

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/16 v0, 0x1da

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v0, 0x0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string/jumbo p1, "Cryptor"

    nop

    new-array p0, v3, [B

    return-object p0
.end method

.method public z(Ljava/lang/CharSequence;IILkf2;)Z
    .registers 11

    .prologue
    iget v0, p4, Lkf2;->c:I

    and-int/lit8 v0, v0, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-nez v0, :cond_64

    iget-object p0, p0, Ltd;->d:Ljava/lang/Object;

    check-cast p0, Lu10;

    invoke-virtual {p4}, Lkf2;->b()Lt91;

    move-result-object v0

    const/16 v4, 0x8

    invoke-virtual {v0, v4}, Ln51;->a(I)I

    move-result v4

    if-eqz v4, :cond_23

    iget-object v5, v0, Ln51;->d:Ljava/lang/Object;

    check-cast v5, Ljava/nio/ByteBuffer;

    iget v0, v0, Ln51;->a:I

    add-int/2addr v4, v0

    invoke-virtual {v5, v4}, Ljava/nio/ByteBuffer;->getShort(I)S

    :cond_23
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v0, Lu10;->b:Ljava/lang/ThreadLocal;

    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v4

    if-nez v4, :cond_36

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v4}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    :cond_36
    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/lang/StringBuilder;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->setLength(I)V

    :goto_3f
    if-ge p2, p3, :cond_4b

    invoke-interface {p1, p2}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    add-int/lit8 p2, p2, 0x1

    goto :goto_3f

    :cond_4b
    iget-object p0, p0, Lu10;->a:Landroid/text/TextPaint;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    sget p2, Lcj1;->a:I

    invoke-virtual {p0, p1}, Landroid/graphics/Paint;->hasGlyph(Ljava/lang/String;)Z

    move-result p0

    iget p1, p4, Lkf2;->c:I

    and-int/lit8 p1, p1, 0x4

    if-eqz p0, :cond_60

    or-int/lit8 p0, p1, 0x2

    goto :goto_62

    :cond_60
    or-int/lit8 p0, p1, 0x1

    :goto_62
    iput p0, p4, Lkf2;->c:I

    :cond_64
    iget p0, p4, Lkf2;->c:I

    and-int/lit8 p0, p0, 0x3

    if-ne p0, v1, :cond_6b

    return v3

    :cond_6b
    return v2
.end method
