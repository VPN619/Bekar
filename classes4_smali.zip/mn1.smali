.class public final Lmn1;
.super Lm82;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Lpk0;


# instance fields
.field public final synthetic t:I

.field public final synthetic u:Lnn1;

.field public final synthetic v:Lcom/android/billingclient/api/BillingResult;

.field public final synthetic w:Ljava/util/List;


# direct methods
.method public synthetic constructor <init>(Lnn1;Lcom/android/billingclient/api/BillingResult;Ljava/util/List;Lvx;I)V
    .registers 8

    iput p5, p0, Lmn1;->t:I

    iput-object p1, p0, Lmn1;->u:Lnn1;

    iput-object p2, p0, Lmn1;->v:Lcom/android/billingclient/api/BillingResult;

    iput-object p3, p0, Lmn1;->w:Ljava/util/List;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p4}, Lm82;-><init>(ILvx;)V

    return-void
.end method


# virtual methods
.method public final create(Lvx;Ljava/lang/Object;)Lvx;
    .registers 19

    .prologue
    const/16 v7, 0xafb

    move-object/from16 v0, p0

    iget v7, v0, Lmn1;->t:I

    move/16 p2, v7

    packed-switch p2, :pswitch_data_66

    const/16 v7, 0x4b0

    new-instance v9, Lmn1;

    nop

    const/16 v7, 0x4b6

    move-object/from16 v0, p0

    iget-object v12, v0, Lmn1;->w:Ljava/util/List;

    nop

    const/4 v14, 0x1

    const/16 v7, 0x4a2

    move-object/from16 v0, p0

    iget-object v10, v0, Lmn1;->u:Lnn1;

    nop

    const/16 v7, 0x3c7

    move-object/from16 v0, p0

    iget-object v11, v0, Lmn1;->v:Lcom/android/billingclient/api/BillingResult;

    nop

    move-object/from16 v13, p1

    const/16 v7, 0x2b1

    move v0, v7

    move-object v1, v9

    move-object v2, v10

    move-object v3, v11

    move-object v4, v12

    move-object v5, v13

    move v6, v14

    invoke-direct/range {v1 .. v6}, Lmn1;-><init>(Lnn1;Lcom/android/billingclient/api/BillingResult;Ljava/util/List;Lvx;I)V

    check-cast v9, Lvx;

    return-object v9

    :pswitch_38  #0x0
    move-object/from16 v13, p1

    const/16 v7, 0x4b0

    new-instance v10, Lmn1;

    nop

    move-object v14, v13

    const/16 v7, 0x4b6

    move-object/from16 v0, p0

    iget-object v13, v0, Lmn1;->w:Ljava/util/List;

    nop

    const/4 v15, 0x0

    const/16 v7, 0x4a2

    move-object/from16 v0, p0

    iget-object v11, v0, Lmn1;->u:Lnn1;

    nop

    const/16 v7, 0x3c7

    move-object/from16 v0, p0

    iget-object v12, v0, Lmn1;->v:Lcom/android/billingclient/api/BillingResult;

    nop

    const/16 v7, 0x2b1

    move v0, v7

    move-object v1, v10

    move-object v2, v11

    move-object v3, v12

    move-object v4, v13

    move-object v5, v14

    move v6, v15

    invoke-direct/range {v1 .. v6}, Lmn1;-><init>(Lnn1;Lcom/android/billingclient/api/BillingResult;Ljava/util/List;Lvx;I)V

    check-cast v10, Lvx;

    return-object v10

    nop

    :pswitch_data_66
    .packed-switch 0x0
        :pswitch_38  #00000000
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7

    .prologue
    const/16 v0, 0xafb

    iget v2, p0, Lmn1;->t:I

    nop

    const/16 v0, 0x21

    sget-object v3, Lrg2;->a:Lrg2;

    nop

    check-cast p1, Lvy;

    check-cast p2, Lvx;

    packed-switch v2, :pswitch_data_32

    const/16 v0, 0x346

    invoke-virtual {p0, p2, p1}, Lmn1;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lmn1;

    const/16 v0, 0x408

    invoke-virtual {p0, v3}, Lmn1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v3, Ljava/lang/Object;

    return-object v3

    :pswitch_21  #0x0
    const/16 v0, 0x346

    invoke-virtual {p0, p2, p1}, Lmn1;->create(Lvx;Ljava/lang/Object;)Lvx;

    move-result-object p0

    check-cast p0, Lmn1;

    const/16 v0, 0x408

    invoke-virtual {p0, v3}, Lmn1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    check-cast v3, Ljava/lang/Object;

    return-object v3

    nop

    :pswitch_data_32
    .packed-switch 0x0
        :pswitch_21  #00000000
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 8

    .prologue
    const/16 v0, 0xafb

    iget v2, p0, Lmn1;->t:I

    nop

    const/16 v0, 0x21

    sget-object v3, Lrg2;->a:Lrg2;

    nop

    const/16 v0, 0x4b6

    iget-object v4, p0, Lmn1;->w:Ljava/util/List;

    nop

    const/16 v0, 0x3c7

    iget-object v5, p0, Lmn1;->v:Lcom/android/billingclient/api/BillingResult;

    nop

    const/16 v0, 0x4a2

    iget-object p0, p0, Lmn1;->u:Lnn1;

    nop

    packed-switch v2, :pswitch_data_40

    const/4 v0, 0x6

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    const/16 v0, 0x3a3

    invoke-virtual {p0, v5, v4}, Lnn1;->e(Lcom/android/billingclient/api/BillingResult;Ljava/util/List;)V

    check-cast v3, Ljava/lang/Object;

    return-object v3

    :pswitch_28  #0x0
    const/4 v0, 0x6

    invoke-static {p1}, Lt12;->W(Ljava/lang/Object;)V

    if-nez v4, :cond_38

    const/16 v0, 0xd7

    new-instance v4, Ljava/util/ArrayList;

    nop

    const/16 v0, 0x16b

    invoke-direct {v4}, Ljava/util/ArrayList;-><init>()V

    :cond_38
    const/16 v0, 0x3a3

    invoke-virtual {p0, v5, v4}, Lnn1;->e(Lcom/android/billingclient/api/BillingResult;Ljava/util/List;)V

    check-cast v3, Ljava/lang/Object;

    return-object v3

    :pswitch_data_40
    .packed-switch 0x0
        :pswitch_28  #00000000
    .end packed-switch
.end method
