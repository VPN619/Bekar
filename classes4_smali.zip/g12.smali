.class public final Lg12;
.super Lkk;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public A:I

.field public final B:Ljava/util/ArrayList;

.field public C:I

.field public final D:Lob;

.field public final q:Lw82;

.field public r:Z

.field public s:Landroid/widget/ImageView;

.field public t:Landroid/widget/ImageView;

.field public u:Landroidx/constraintlayout/widget/ConstraintLayout;

.field public v:Landroid/widget/ImageView;

.field public w:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

.field public x:Landroidx/recyclerview/widget/RecyclerView;

.field public y:Ll12;

.field public z:I


# direct methods
.method public constructor <init>()V
    .registers 6

    invoke-direct {p0}, Lkk;-><init>()V

    const/16 v0, 0x9ca

    new-instance v2, Lsz1;

    nop

    const/4 v3, 0x6

    const/16 v0, 0xf0b

    invoke-direct {v2, v3, p0}, Lsz1;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x27a

    new-instance v3, Lw82;

    nop

    const/16 v0, 0x215

    invoke-direct {v3, v2}, Lw82;-><init>(Lzj0;)V

    const/16 v0, 0x114f

    iput-object v3, p0, Lg12;->q:Lw82;

    const/16 v0, 0x123

    sget-object v2, Lpp1;->a:Lv0;

    nop

    const/16 v3, 0x400

    const/16 v0, 0x16d

    invoke-virtual {v2, v3}, Lv0;->l(I)I

    move-result v4

    const/16 v0, 0xfad

    iput v4, p0, Lg12;->z:I

    const/16 v0, 0x16d

    invoke-virtual {v2, v3}, Lv0;->l(I)I

    move-result v2

    const/16 v0, 0x850

    iput v2, p0, Lg12;->A:I

    const/16 v0, 0xd7

    new-instance v2, Ljava/util/ArrayList;

    nop

    const/16 v0, 0x16b

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    const/16 v0, 0x863

    iput-object v2, p0, Lg12;->B:Ljava/util/ArrayList;

    const/16 v0, 0xf6e

    new-instance v2, Lob;

    nop

    const/4 v3, 0x7

    const/16 v0, 0x11c1

    invoke-direct {v2, v3, p0}, Lob;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x115b

    iput-object v2, p0, Lg12;->D:Lob;

    return-void
.end method


# virtual methods
.method public final c()V
    .registers 17

    .prologue
    const/16 v6, 0x5d3

    new-instance v8, Landroid/os/Handler;

    nop

    const/16 v6, 0x1210

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v9

    const/16 v6, 0xad4

    invoke-direct {v8, v9}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/16 v6, 0xb36

    new-instance v9, Lc;

    nop

    const/16 v10, 0x1a

    const/16 v6, 0x87c

    move-object/from16 v0, p0

    invoke-direct {v9, v10, v0}, Lc;-><init>(ILjava/lang/Object;)V

    const-wide/16 v10, 0xbb8

    const/16 v6, 0xc45

    invoke-virtual {v8, v9, v10, v11}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    const/16 v6, 0x82f

    move-object/from16 v0, p0

    iget-object v8, v0, Lg12;->B:Ljava/util/ArrayList;

    nop

    const/16 v6, 0x15b

    invoke-virtual {v8}, Ljava/util/ArrayList;->clear()V

    const/16 v6, 0x42

    move-object/from16 v0, p0

    iget-object v8, v0, Lg12;->y:Ll12;

    nop

    const-string/jumbo v9, "serverListAdapter"

    const/4 v10, 0x0

    if-eqz v8, :cond_fe

    const/16 v6, 0x44

    iget-object v8, v8, Ll12;->f:Ljava/util/ArrayList;

    nop

    const/16 v6, 0xc4e

    invoke-interface {v8}, Ljava/util/Collection;->isEmpty()Z

    move-result v11

    const/4 v12, 0x1

    const/4 v13, 0x0

    if-nez v11, :cond_6d

    const/16 v6, 0xac

    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    move-result v11

    move v14, v13

    :goto_54
    if-ge v14, v11, :cond_6d

    const/16 v6, 0x43

    invoke-virtual {v8, v14}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v15

    add-int/lit8 v14, v14, 0x1

    check-cast v15, La12;

    const/16 v6, 0x2ee

    iput v13, v15, La12;->j:I

    const/16 v6, 0x2e7

    iput-boolean v12, v15, La12;->h:Z

    const/16 v6, 0x4ad

    iput-boolean v13, v15, La12;->i:Z

    goto :goto_54

    :cond_6d
    :try_start_6d
    const/16 v6, 0x42

    move-object/from16 v0, p0

    iget-object v8, v0, Lg12;->y:Ll12;

    nop

    if-eqz v8, :cond_f8

    const/16 v6, 0x44

    iget-object v9, v8, Ll12;->f:Ljava/util/ArrayList;

    nop

    const/16 v6, 0xac

    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    move-result v9

    const/16 v6, 0x504

    iget-object v8, v8, Lqq1;->a:Lrq1;

    nop

    const/16 v6, 0x635

    invoke-virtual {v8, v13, v9, v10}, Lrq1;->c(IILandroidx/preference/Preference;)V

    const/16 v6, 0x123

    sget-object v8, Lpp1;->a:Lv0;

    nop

    const/16 v9, 0x400

    const/16 v6, 0x16d

    invoke-virtual {v8, v9}, Lv0;->l(I)I

    move-result v8

    const/16 v6, 0xfad

    move-object/from16 v0, p0

    iput v8, v0, Lg12;->z:I

    const/16 v6, 0x5b

    new-instance v8, Landroid/content/Intent;

    nop

    const-string/jumbo v9, "CONSULTSTATUS"

    const/16 v6, 0x2b

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object v11

    const-class v13, Lcom/tlsvpn/tlstunnel/services/serveraction/ServerAction;

    const/16 v6, 0x3fd

    move v0, v6

    move-object v1, v8

    move-object v2, v9

    move-object v3, v10

    move-object v4, v11

    move-object v5, v13

    invoke-direct/range {v1 .. v5}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;Landroid/content/Context;Ljava/lang/Class;)V

    const-string/jumbo v9, "cId"

    const/16 v6, 0x81c

    move-object/from16 v0, p0

    iget v10, v0, Lg12;->z:I

    nop

    const/16 v6, 0x29

    invoke-virtual {v8, v9, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v8

    const-string/jumbo v9, "cTp"

    const/16 v6, 0x29

    invoke-virtual {v8, v9, v12}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v8

    const-string/jumbo v9, "cspl"

    const/16 v6, 0x1b1

    move-object/from16 v0, p0

    iget-boolean v10, v0, Lg12;->r:Z

    nop

    const/16 v6, 0x178

    invoke-virtual {v8, v9, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    move-result-object v8

    const/4 v6, -0x6

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x2b

    move-object/from16 v0, p0

    invoke-virtual {v0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p0

    const/16 v6, 0x4a7

    move-object/from16 v0, p0

    invoke-virtual {v0, v8}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    return-void

    :cond_f8
    const/4 v6, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10
    :try_end_fd
    .catch Ljava/lang/IllegalStateException; {:try_start_6d .. :try_end_fd} :catch_fd

    :catch_fd
    return-void

    :cond_fe
    const/4 v6, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw v10
.end method

.method public final d()Landroid/content/SharedPreferences;
    .registers 3

    const/16 v0, 0x88d

    iget-object p0, p0, Lg12;->q:Lw82;

    nop

    const/16 v0, 0x177

    invoke-virtual {p0}, Lw82;->getValue()Ljava/lang/Object;

    move-result-object p0

    check-cast p0, Landroid/content/SharedPreferences;

    return-object p0
.end method

.method public final e(Z)V
    .registers 7

    .prologue
    const/16 v0, 0x438

    iget-object v2, p0, Lg12;->t:Landroid/widget/ImageView;

    nop

    const/4 v3, 0x0

    if-eqz v2, :cond_38

    xor-int/lit8 v4, p1, 0x1

    const/16 v0, 0xf7

    invoke-virtual {v2, v4}, Landroid/view/View;->setEnabled(Z)V

    const/16 v0, 0x9c8

    iget-object v2, p0, Lg12;->s:Landroid/widget/ImageView;

    nop

    if-eqz v2, :cond_30

    const/16 v0, 0xf7

    invoke-virtual {v2, v4}, Landroid/view/View;->setEnabled(Z)V

    const/16 v0, 0x875

    iget-object p0, p0, Lg12;->w:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    nop

    if-eqz p0, :cond_28

    const/16 v0, 0xd3

    invoke-virtual {p0, p1}, Lki;->setIndeterminate(Z)V

    return-void

    :cond_28
    const-string/jumbo p0, "progressBar"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_30
    const-string/jumbo p0, "downloadslist"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3

    :cond_38
    const-string/jumbo p0, "reload"

    const/4 v0, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw v3
.end method

.method public final onCreate(Landroid/os/Bundle;)V
    .registers 6

    .prologue
    const/16 v0, 0x11c5

    invoke-super {p0, p1}, Landroidx/fragment/app/g;->onCreate(Landroid/os/Bundle;)V

    const/16 v0, 0xc2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getArguments()Landroid/os/Bundle;

    move-result-object p1

    if-eqz p1, :cond_1b

    const-string/jumbo v2, "is_premium"

    const/4 v3, 0x0

    const/16 v0, 0x428

    invoke-virtual {p1, v2, v3}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;Z)Z

    move-result p1

    const/16 v0, 0x7b9

    iput-boolean p1, p0, Lg12;->r:Z

    :cond_1b
    return-void
.end method

.method public final onCreateView(Landroid/view/LayoutInflater;Landroid/view/ViewGroup;Landroid/os/Bundle;)Landroid/view/View;
    .registers 18

    .prologue
    const/4 v6, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const p3, 0x7f0c00d1

    const/4 v8, 0x0

    const/16 v6, 0x107b

    move/from16 v0, p3

    move-object/from16 v1, p2

    invoke-virtual {p1, v0, v1, v8}, Landroid/view/LayoutInflater;->inflate(ILandroid/view/ViewGroup;Z)Landroid/view/View;

    move-result-object p1

    const p2, 0x7f090395

    const/16 v6, 0x11

    move/from16 v0, p2

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v6, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/LinearLayout;

    const p2, 0x7f0902cf

    const/16 v6, 0x11

    move/from16 v0, p2

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v6, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    const/16 v6, 0x1036

    move-object/from16 v0, p2

    iput-object v0, p0, Lg12;->w:Lcom/google/android/material/progressindicator/LinearProgressIndicator;

    const p2, 0x7f0900e8

    const/16 v6, 0x11

    move/from16 v0, p2

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v6, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/ImageView;

    const/16 v6, 0xa13

    move-object/from16 v0, p2

    iput-object v0, p0, Lg12;->s:Landroid/widget/ImageView;

    const p2, 0x7f0902e2

    const/16 v6, 0x11

    move/from16 v0, p2

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v6, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/ImageView;

    const/16 v6, 0x55d

    move-object/from16 v0, p2

    iput-object v0, p0, Lg12;->t:Landroid/widget/ImageView;

    const p2, 0x7f0903b3

    const/16 v6, 0x11

    move/from16 v0, p2

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v6, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroidx/constraintlayout/widget/ConstraintLayout;

    const/16 v6, 0x1231

    move-object/from16 v0, p2

    iput-object v0, p0, Lg12;->u:Landroidx/constraintlayout/widget/ConstraintLayout;

    const p2, 0x7f090314

    const/16 v6, 0x11

    move/from16 v0, p2

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v6, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroidx/recyclerview/widget/RecyclerView;

    const/16 v6, 0xb6c

    move-object/from16 v0, p2

    iput-object v0, p0, Lg12;->x:Landroidx/recyclerview/widget/RecyclerView;

    const p2, 0x7f09006e

    const/16 v6, 0x11

    move/from16 v0, p2

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v6, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/ImageView;

    const/16 v6, 0xd06

    move-object/from16 v0, p2

    iput-object v0, p0, Lg12;->v:Landroid/widget/ImageView;

    const p2, 0x7f090148

    const/16 v6, 0x11

    move/from16 v0, p2

    invoke-virtual {p1, v0}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v6, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/ImageView;

    const/16 v6, 0x1b1

    iget-boolean v6, p0, Lg12;->r:Z

    move/16 p3, v6

    if-eqz p3, :cond_f1

    const/16 v6, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p3

    const v9, 0x7f08010d

    const/16 v6, 0x52f

    move-object/from16 v0, p3

    invoke-static {v0, v9}, Lqx;->getDrawable(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object p3

    const/16 v6, 0xcae

    move-object/from16 v0, p2

    move-object/from16 v1, p3

    invoke-virtual {v0, v1}, Landroid/widget/ImageView;->setImageDrawable(Landroid/graphics/drawable/Drawable;)V

    :cond_f1
    const/16 v6, 0x9c8

    iget-object v6, p0, Lg12;->s:Landroid/widget/ImageView;

    move-object/16 p2, v6

    const/16 p3, 0x0

    if-eqz p2, :cond_3d6

    const/16 v6, 0x426

    new-instance v9, Lb12;

    nop

    const/16 v6, 0x41e

    invoke-direct {v9, p0, v8}, Lb12;-><init>(Lg12;I)V

    const/16 v6, 0x5f

    move-object/from16 v0, p2

    invoke-virtual {v0, v9}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v6, 0x438

    iget-object v6, p0, Lg12;->t:Landroid/widget/ImageView;

    move-object/16 p2, v6

    const-string/jumbo v9, "reload"

    if-eqz p2, :cond_3d1

    const/16 v6, 0x426

    new-instance v10, Lb12;

    nop

    const/4 v11, 0x1

    const/16 v6, 0x41e

    invoke-direct {v10, p0, v11}, Lb12;-><init>(Lg12;I)V

    const/16 v6, 0x5f

    move-object/from16 v0, p2

    invoke-virtual {v0, v10}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v6, 0x438

    iget-object v6, p0, Lg12;->t:Landroid/widget/ImageView;

    move-object/16 p2, v6

    if-eqz p2, :cond_3cc

    const/16 v6, 0x490

    new-instance v9, Lxz1;

    nop

    const/4 v10, 0x2

    const/16 v6, 0x382

    invoke-direct {v9, p0, v10}, Lxz1;-><init>(Lvb;I)V

    const/16 v6, 0x8f

    move-object/from16 v0, p2

    invoke-virtual {v0, v9}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    const/16 v6, 0xcfe

    invoke-virtual {p0, v11}, Lg12;->e(Z)V

    const/16 v6, 0x8ea

    new-instance p2, Lou;

    nop

    const/16 v6, 0x131

    invoke-virtual {p0}, Lg12;->d()Landroid/content/SharedPreferences;

    move-result-object v9

    const/4 v6, -0x6

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x1c6

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getResources()Landroid/content/res/Resources;

    move-result-object v12

    const/4 v6, -0x6

    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x83d

    move v0, v6

    move-object/from16 v1, p2

    move-object v2, v9

    move-object v3, v12

    move v4, v8

    move v5, v8

    invoke-direct/range {v1 .. v5}, Lou;-><init>(Landroid/content/SharedPreferences;Landroid/content/res/Resources;ZZ)V

    const/16 v6, 0x1ff

    sget v9, Lmi2;->o:I

    nop

    const/4 v12, 0x3

    if-ne v9, v12, :cond_17a

    move v9, v11

    goto :goto_1ad

    :cond_17a
    const/16 v6, 0x32

    move-object/from16 v0, p2

    iget v9, v0, Lou;->e:I

    nop

    if-eqz v9, :cond_185

    move v9, v10

    goto :goto_1ad

    :cond_185
    const/16 v6, 0x1b8

    move-object/from16 v0, p2

    iget v9, v0, Lou;->m:I

    nop

    const v13, 0x7f030005

    if-eqz v9, :cond_19f

    const/16 v6, 0x1c6

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getResources()Landroid/content/res/Resources;

    move-result-object v9

    const/16 v6, 0x3e2

    invoke-virtual {v9, v13}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v9

    array-length v9, v9

    goto :goto_1ad

    :cond_19f
    const/16 v6, 0x1c6

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getResources()Landroid/content/res/Resources;

    move-result-object v9

    const/16 v6, 0x3e2

    invoke-virtual {v9, v13}, Landroid/content/res/Resources;->getStringArray(I)[Ljava/lang/String;

    move-result-object v9

    array-length v9, v9

    sub-int/2addr v9, v11

    :goto_1ad
    const/16 v6, 0xbc7

    iput v9, p0, Lg12;->C:I

    const/16 v6, 0x11f

    move-object/from16 v0, p2

    iget v9, v0, Lou;->d:I

    nop

    const-string/jumbo v13, "psrvslctd"

    if-nez v9, :cond_1d2

    const/16 v6, 0x1b1

    iget-boolean v9, p0, Lg12;->r:Z

    nop

    if-eqz v9, :cond_1d2

    const/16 v6, 0x131

    invoke-virtual {p0}, Lg12;->d()Landroid/content/SharedPreferences;

    move-result-object v9

    const/16 v6, 0x77

    invoke-interface {v9, v13, v8}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v9

    if-nez v9, :cond_1f8

    :cond_1d2
    const/16 v6, 0x11f

    move-object/from16 v0, p2

    iget v6, v0, Lou;->d:I

    move/16 p2, v6

    if-nez p2, :cond_1f7

    const/16 v6, 0x1b1

    iget-boolean v6, p0, Lg12;->r:Z

    move/16 p2, v6

    if-nez p2, :cond_1f7

    const/16 v6, 0x131

    invoke-virtual {p0}, Lg12;->d()Landroid/content/SharedPreferences;

    move-result-object p2

    const/16 v6, 0x77

    move-object/from16 v0, p2

    invoke-interface {v0, v13, v8}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p2

    if-nez p2, :cond_1f7

    goto :goto_1f8

    :cond_1f7
    move v11, v8

    :cond_1f8
    :goto_1f8
    const/16 v6, 0x1029

    iget-object v6, p0, Lg12;->v:Landroid/widget/ImageView;

    move-object/16 p2, v6

    if-eqz p2, :cond_3c4

    if-eqz v11, :cond_205

    move v9, v8

    goto :goto_207

    :cond_205
    const/16 v9, 0x8

    :goto_207
    const/16 v6, 0x23d

    move-object/from16 v0, p2

    invoke-virtual {v0, v9}, Landroid/widget/ImageView;->setVisibility(I)V

    const/16 v6, 0x31a

    iget-object v6, p0, Lg12;->u:Landroidx/constraintlayout/widget/ConstraintLayout;

    move-object/16 p2, v6

    const-string/jumbo v9, "autoServer"

    if-eqz p2, :cond_3bf

    const/16 v6, 0xc04

    new-instance v11, Lc12;

    nop

    const/16 v6, 0x21a

    invoke-direct {v11}, Ljava/lang/Object;-><init>()V

    const/16 v6, 0x959

    iput-object p0, v11, Lc12;->a:Lg12;

    const/16 v6, 0x91b

    iput v8, v11, Lc12;->b:I

    const/16 v6, 0x5f

    move-object/from16 v0, p2

    invoke-virtual {v0, v11}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/16 v6, 0x31a

    iget-object v6, p0, Lg12;->u:Landroidx/constraintlayout/widget/ConstraintLayout;

    move-object/16 p2, v6

    if-eqz p2, :cond_3ba

    const/16 v6, 0xa93

    new-instance v9, Ld12;

    nop

    const-string/jumbo v11, ""

    const/16 v6, 0x7ef

    invoke-direct {v9, p0, v11, v8}, Ld12;-><init>(Lg12;Ljava/lang/String;I)V

    const/16 v6, 0x8f

    move-object/from16 v0, p2

    invoke-virtual {v0, v9}, Landroid/view/View;->setOnLongClickListener(Landroid/view/View$OnLongClickListener;)V

    const/16 v6, 0xf80

    new-instance p2, Lp50;

    nop

    const/16 v6, 0xfb

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object v8

    const/16 v6, 0x1133

    move-object/from16 v0, p2

    invoke-direct {v0, v8}, Lp50;-><init>(Landroid/content/Context;)V

    const/16 v6, 0xfb

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object v8

    const v9, 0x7f0800a6

    const/16 v6, 0x52f

    invoke-static {v8, v9}, Lqx;->getDrawable(Landroid/content/Context;I)Landroid/graphics/drawable/Drawable;

    move-result-object v8

    const/4 v6, -0x6

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x8fa

    move-object/from16 v0, p2

    iput-object v8, v0, Lp50;->b:Ljava/lang/Object;

    const/16 v6, 0x2ba

    iget-object v8, p0, Lg12;->x:Landroidx/recyclerview/widget/RecyclerView;

    nop

    const-string/jumbo v9, "serverlist"

    if-eqz v8, :cond_3b5

    const/16 v6, 0x892

    move-object/from16 v0, p2

    invoke-virtual {v8, v0}, Landroidx/recyclerview/widget/RecyclerView;->i(Lwq1;)V

    const/16 v6, 0x2ba

    iget-object v6, p0, Lg12;->x:Landroidx/recyclerview/widget/RecyclerView;

    move-object/16 p2, v6

    if-eqz p2, :cond_3b0

    const/16 v6, 0x7ba

    move-object/from16 v0, p2

    move-object/from16 v1, p3

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->setItemAnimator(Lvq1;)V

    const/16 v6, 0x325

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getViewLifecycleOwner()Lh11;

    move-result-object p2

    const/4 v6, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x341

    move-object/from16 v0, p2

    invoke-static {v0}, Lns2;->m(Lh11;)Lc11;

    move-result-object p2

    const/16 v6, 0x1f0

    new-instance v8, Le12;

    nop

    const/16 v6, 0x21b

    move-object/from16 v0, p3

    invoke-direct {v8, p0, v0, v10}, Le12;-><init>(Lg12;Lvx;I)V

    const/16 v6, 0xb3

    move v0, v6

    move-object/from16 v1, p2

    move-object/from16 v2, p3

    move-object/from16 v3, p3

    move-object v4, v8

    move v5, v12

    invoke-static/range {v1 .. v5}, Lg73;->C(Lvy;Lly;Lyy;Lpk0;I)Lx52;

    const/16 v6, 0x1fc

    sget p2, Landroid/os/Build$VERSION;->SDK_INT:I

    nop

    const/16 p3, 0x21

    const-string/jumbo v8, "pVacTd"

    const-string/jumbo v9, "SERVERLURPL"

    const-string/jumbo v10, "SERVERRPL"

    const/16 v6, 0x10fd

    iget-object v11, p0, Lg12;->D:Lob;

    nop

    move/from16 v0, p2

    move/from16 v1, p3

    if-ge v0, v1, :cond_339

    const/16 v6, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p2

    const/16 v6, 0x1f

    new-instance p3, Landroid/content/IntentFilter;

    nop

    const/16 v6, 0x1d

    move-object/from16 v0, p3

    invoke-direct {v0, v10}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v6, 0x3a

    move-object/from16 v0, p2

    move-object/from16 v1, p3

    invoke-virtual {v0, v11, v1}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/16 v6, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p2

    const/16 v6, 0x1f

    new-instance p3, Landroid/content/IntentFilter;

    nop

    const/16 v6, 0x1d

    move-object/from16 v0, p3

    invoke-direct {v0, v9}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v6, 0x3a

    move-object/from16 v0, p2

    move-object/from16 v1, p3

    invoke-virtual {v0, v11, v1}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/16 v6, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p2

    const/16 v6, 0x1f

    new-instance p3, Landroid/content/IntentFilter;

    nop

    const/16 v6, 0x1d

    move-object/from16 v0, p3

    invoke-direct {v0, v8}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v6, 0x3a

    move-object/from16 v0, p2

    move-object/from16 v1, p3

    invoke-virtual {v0, v11, v1}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    goto :goto_38b

    :cond_339
    const/16 v6, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p2

    const/16 v6, 0x1f

    new-instance p3, Landroid/content/IntentFilter;

    nop

    const/16 v6, 0x1d

    move-object/from16 v0, p3

    invoke-direct {v0, v10}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x4

    const/16 v6, 0x5d

    move-object/from16 v0, p2

    move-object/from16 v1, p3

    invoke-virtual {v0, v11, v1, v10}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    const/16 v6, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p2

    const/16 v6, 0x1f

    new-instance p3, Landroid/content/IntentFilter;

    nop

    const/16 v6, 0x1d

    move-object/from16 v0, p3

    invoke-direct {v0, v9}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v6, 0x5d

    move-object/from16 v0, p2

    move-object/from16 v1, p3

    invoke-virtual {v0, v11, v1, v10}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    const/16 v6, 0x2b

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireContext()Landroid/content/Context;

    move-result-object p2

    const/16 v6, 0x1f

    new-instance p3, Landroid/content/IntentFilter;

    nop

    const/16 v6, 0x1d

    move-object/from16 v0, p3

    invoke-direct {v0, v8}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/16 v6, 0x5d

    move-object/from16 v0, p2

    move-object/from16 v1, p3

    invoke-virtual {v0, v11, v1, v10}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    :goto_38b
    const/16 v6, 0x140

    sget-boolean p2, Lg4;->a:Z

    nop

    const/16 v6, 0xfb

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->requireActivity()Landroidx/fragment/app/l;

    move-result-object p2

    const/4 v6, -0x6

    move-object/from16 v0, p2

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x131

    invoke-virtual {p0}, Lg12;->d()Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v6, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v6, 0x394

    move-object/from16 v0, p2

    invoke-static {p0, v0}, Lg4;->n(Landroid/content/SharedPreferences;Landroidx/fragment/app/l;)V

    check-cast p1, Landroid/view/View;

    return-object p1

    :cond_3b0
    const/4 v6, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_3b5
    const/4 v6, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_3ba
    const/4 v6, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_3bf
    const/4 v6, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_3c4
    const-string/jumbo p0, "autoserversi"

    const/4 v6, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_3cc
    const/4 v6, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_3d1
    const/4 v6, 0x5

    invoke-static {v9}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3

    :cond_3d6
    const-string/jumbo p0, "downloadslist"

    const/4 v6, 0x5

    invoke-static {p0}, Lgt0;->F0(Ljava/lang/String;)V

    throw p3
.end method

.method public final onDestroyView()V
    .registers 7

    .prologue
    const/16 v0, 0x53a

    invoke-super {p0}, Landroidx/fragment/app/g;->onDestroyView()V

    :try_start_5
    const/16 v0, 0x22f

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v2

    if-eqz v2, :cond_17

    const/16 v0, 0x10fd

    iget-object v3, p0, Lg12;->D:Lob;

    nop

    const/16 v0, 0x345

    invoke-virtual {v2, v3}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_17
    .catch Ljava/lang/Exception; {:try_start_5 .. :try_end_17} :catch_17

    :catch_17
    :cond_17
    const/16 v0, 0x905

    sget-boolean v2, Lmi2;->a:Z

    nop

    const/16 v0, 0x131

    invoke-virtual {p0}, Lg12;->d()Landroid/content/SharedPreferences;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x1112

    invoke-static {v2}, Lmi2;->d(Landroid/content/SharedPreferences;)Z

    move-result v2

    if-eqz v2, :cond_8f

    const/16 v0, 0x131

    invoke-virtual {p0}, Lg12;->d()Landroid/content/SharedPreferences;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x7a

    invoke-interface {v2}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v2

    const/16 v0, 0x1b1

    iget-boolean v3, p0, Lg12;->r:Z

    nop

    if-eqz v3, :cond_49

    const-string/jumbo v3, "nfplavailable"

    goto :goto_4c

    :cond_49
    const-string/jumbo v3, "nfslavailable"

    :goto_4c
    const/4 v4, 0x0

    const/16 v0, 0x48

    invoke-interface {v2, v3, v4}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x22f

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object v3

    if-eqz v3, :cond_8a

    const/16 v0, 0x5b

    new-instance v4, Landroid/content/Intent;

    nop

    const-string/jumbo v5, "restoreHome"

    const/16 v0, 0x62

    invoke-direct {v4, v5}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x22f

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getContext()Landroid/content/Context;

    move-result-object p0

    if-eqz p0, :cond_7e

    const/16 v0, 0x53

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    if-eqz p0, :cond_7e

    const/16 v0, 0x4a

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    goto :goto_7f

    :cond_7e
    const/4 p0, 0x0

    :goto_7f
    const/16 v0, 0x64

    invoke-virtual {v4, p0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p0

    const/16 v0, 0x63

    invoke-virtual {v3, p0}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    :cond_8a
    const/16 v0, 0x6f

    invoke-interface {v2}, Landroid/content/SharedPreferences$Editor;->apply()V

    :cond_8f
    return-void
.end method

.method public final onStart()V
    .registers 6

    .prologue
    const/16 v0, 0x55f

    invoke-super {p0}, Landroidx/fragment/app/g;->onStart()V

    const/16 v0, 0xaeb

    invoke-virtual {p0}, Landroidx/fragment/app/g;->getDialog()Landroid/app/Dialog;

    move-result-object v2

    instance-of v3, v2, Ljk;

    const/4 v4, 0x0

    if-eqz v3, :cond_13

    check-cast v2, Ljk;

    goto :goto_14

    :cond_13
    move-object v2, v4

    :goto_14
    if-eqz v2, :cond_1c

    const/16 v0, 0xff7

    invoke-virtual {v2}, Ljk;->f()Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    move-result-object v4

    :cond_1c
    const/16 v0, 0x1c6

    invoke-virtual {p0}, Landroidx/fragment/app/Fragment;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/16 v0, 0x84a

    invoke-virtual {p0}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    move-result-object p0

    const/16 v0, 0x8b5

    iget p0, p0, Landroid/content/res/Configuration;->orientation:I

    nop

    const/4 v2, 0x2

    if-ne p0, v2, :cond_3d

    if-eqz v4, :cond_3d

    const/4 p0, 0x3

    const/16 v0, 0x8a6

    invoke-virtual {v4, p0}, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->L(I)V

    const/4 p0, 0x1

    const/16 v0, 0x1099

    iput-boolean p0, v4, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->K:Z

    :cond_3d
    return-void
.end method
