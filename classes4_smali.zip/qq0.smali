.class public final Lqq0;
.super Lpr1;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final u:Lcom/tlsvpn/tlstunnel/ui/imex/Importar;

.field public final v:Landroid/widget/ImageView;

.field public final w:Landroid/widget/TextView;

.field public final x:Landroid/widget/TextView;


# direct methods
.method public constructor <init>(Landroid/view/View;Lcom/tlsvpn/tlstunnel/ui/imex/Importar;)V
    .registers 6

    invoke-direct {p0, p1}, Lpr1;-><init>(Landroid/view/View;)V

    const/16 v0, 0xde3

    iput-object p2, p0, Lqq0;->u:Lcom/tlsvpn/tlstunnel/ui/imex/Importar;

    const p2, 0x7f09015a

    const/16 v0, 0x11

    invoke-virtual {p1, p2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p2

    const/4 v0, -0x6

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p2, Landroid/widget/LinearLayout;

    const v2, 0x7f090146

    const/16 v0, 0x11

    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v2, Landroid/widget/ImageView;

    const/16 v0, 0x579

    iput-object v2, p0, Lqq0;->v:Landroid/widget/ImageView;

    const v2, 0x7f090385

    const/16 v0, 0x11

    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object v2

    const/4 v0, -0x6

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast v2, Landroid/widget/TextView;

    const/16 v0, 0x8f8

    iput-object v2, p0, Lqq0;->w:Landroid/widget/TextView;

    const v2, 0x7f090386

    const/16 v0, 0x11

    invoke-virtual {p1, v2}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    check-cast p1, Landroid/widget/TextView;

    const/16 v0, 0xcfc

    iput-object p1, p0, Lqq0;->x:Landroid/widget/TextView;

    const/16 v0, 0xa20

    new-instance p1, Lvd;

    nop

    const/16 v2, 0xf

    const/16 v0, 0xd0d

    invoke-direct {p1, v2, p0}, Lvd;-><init>(ILjava/lang/Object;)V

    const/16 v0, 0x5f

    invoke-virtual {p2, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    return-void
.end method
