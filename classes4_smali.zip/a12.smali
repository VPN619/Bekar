.class public final La12;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"


# instance fields
.field public final a:Ljava/lang/String;

.field public final b:I

.field public final c:Ljava/lang/String;

.field public final d:Ljava/lang/String;

.field public e:Ljava/lang/String;

.field public f:I

.field public g:I

.field public h:Z

.field public i:Z

.field public j:I

.field public final k:Z

.field public final l:Z


# direct methods
.method public constructor <init>(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZ)V
    .registers 9

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/16 v0, 0x11d5

    iput-object p2, p0, La12;->a:Ljava/lang/String;

    const/16 v0, 0x873

    iput p1, p0, La12;->b:I

    const/16 v0, 0xd08

    iput-object p3, p0, La12;->c:Ljava/lang/String;

    const/16 v0, 0x666

    iput-object p4, p0, La12;->d:Ljava/lang/String;

    const-string/jumbo p1, ""

    const/16 v0, 0xdcf

    iput-object p1, p0, La12;->e:Ljava/lang/String;

    const/4 p1, 0x0

    const/16 v0, 0xe9c

    iput p1, p0, La12;->f:I

    const/16 v0, 0xcb1

    iput p1, p0, La12;->g:I

    const/4 p2, 0x1

    const/16 v0, 0x2e7

    iput-boolean p2, p0, La12;->h:Z

    const/16 v0, 0x4ad

    iput-boolean p1, p0, La12;->i:Z

    const/16 v0, 0x2ee

    iput p1, p0, La12;->j:I

    const/16 v0, 0x11bd

    iput-boolean p5, p0, La12;->k:Z

    const/16 v0, 0xcd9

    iput-boolean p6, p0, La12;->l:Z

    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .prologue
    if-ne p0, p1, :cond_4

    goto/16 :goto_c4

    :cond_4
    instance-of v2, p1, La12;

    if-nez v2, :cond_a

    goto/16 :goto_c2

    :cond_a
    check-cast p1, La12;

    const/16 v0, 0x4ba

    iget-object v2, p0, La12;->a:Ljava/lang/String;

    nop

    const/16 v0, 0x4ba

    iget-object v3, p1, La12;->a:Ljava/lang/String;

    nop

    const/16 v0, 0x128

    invoke-virtual {v2, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_20

    goto/16 :goto_c2

    :cond_20
    const/16 v0, 0x3fc

    iget v2, p0, La12;->b:I

    nop

    const/16 v0, 0x3fc

    iget v3, p1, La12;->b:I

    nop

    if-eq v2, v3, :cond_2e

    goto/16 :goto_c2

    :cond_2e
    const/16 v0, 0x479

    iget-object v2, p0, La12;->c:Ljava/lang/String;

    nop

    const/16 v0, 0x479

    iget-object v3, p1, La12;->c:Ljava/lang/String;

    nop

    const/16 v0, 0x128

    invoke-virtual {v2, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_42

    goto/16 :goto_c2

    :cond_42
    const/16 v0, 0x350

    iget-object v2, p0, La12;->d:Ljava/lang/String;

    nop

    const/16 v0, 0x350

    iget-object v3, p1, La12;->d:Ljava/lang/String;

    nop

    const/16 v0, 0x128

    invoke-virtual {v2, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_55

    goto :goto_c2

    :cond_55
    const/16 v0, 0x36b

    iget-object v2, p0, La12;->e:Ljava/lang/String;

    nop

    const/16 v0, 0x36b

    iget-object v3, p1, La12;->e:Ljava/lang/String;

    nop

    const/16 v0, 0x128

    invoke-virtual {v2, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_68

    goto :goto_c2

    :cond_68
    const/16 v0, 0x4fd

    iget v2, p0, La12;->f:I

    nop

    const/16 v0, 0x4fd

    iget v3, p1, La12;->f:I

    nop

    if-eq v2, v3, :cond_75

    goto :goto_c2

    :cond_75
    const/16 v0, 0x29b

    iget v2, p0, La12;->g:I

    nop

    const/16 v0, 0x29b

    iget v3, p1, La12;->g:I

    nop

    if-eq v2, v3, :cond_82

    goto :goto_c2

    :cond_82
    const/16 v0, 0x530

    iget-boolean v2, p0, La12;->h:Z

    nop

    const/16 v0, 0x530

    iget-boolean v3, p1, La12;->h:Z

    nop

    if-eq v2, v3, :cond_8f

    goto :goto_c2

    :cond_8f
    const/16 v0, 0x2af

    iget-boolean v2, p0, La12;->i:Z

    nop

    const/16 v0, 0x2af

    iget-boolean v3, p1, La12;->i:Z

    nop

    if-eq v2, v3, :cond_9c

    goto :goto_c2

    :cond_9c
    const/16 v0, 0x37b

    iget v2, p0, La12;->j:I

    nop

    const/16 v0, 0x37b

    iget v3, p1, La12;->j:I

    nop

    if-eq v2, v3, :cond_a9

    goto :goto_c2

    :cond_a9
    const/16 v0, 0x355

    iget-boolean v2, p0, La12;->k:Z

    nop

    const/16 v0, 0x355

    iget-boolean v3, p1, La12;->k:Z

    nop

    if-eq v2, v3, :cond_b6

    goto :goto_c2

    :cond_b6
    const/16 v0, 0x3b6

    iget-boolean p0, p0, La12;->l:Z

    nop

    const/16 v0, 0x3b6

    iget-boolean p1, p1, La12;->l:Z

    nop

    if-eq p0, p1, :cond_c4

    :goto_c2
    const/4 p0, 0x0

    return p0

    :cond_c4
    :goto_c4
    const/4 p0, 0x1

    return p0
.end method

.method public final hashCode()I
    .registers 6

    const/16 v0, 0x4ba

    iget-object v2, p0, La12;->a:Ljava/lang/String;

    nop

    const/16 v0, 0x51

    invoke-virtual {v2}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/16 v3, 0x1f

    mul-int/2addr v2, v3

    const/16 v0, 0x3fc

    iget v4, p0, La12;->b:I

    nop

    const/16 v0, 0x19b

    invoke-static {v4, v2, v3}, Lmz2;->g(III)I

    move-result v2

    const/16 v0, 0x479

    iget-object v4, p0, La12;->c:Ljava/lang/String;

    nop

    const/16 v0, 0x26b

    invoke-static {v2, v3, v4}, Ly41;->j(IILjava/lang/String;)I

    move-result v2

    const/16 v0, 0x350

    iget-object v4, p0, La12;->d:Ljava/lang/String;

    nop

    const/16 v0, 0x26b

    invoke-static {v2, v3, v4}, Ly41;->j(IILjava/lang/String;)I

    move-result v2

    const/16 v0, 0x36b

    iget-object v4, p0, La12;->e:Ljava/lang/String;

    nop

    const/16 v0, 0x26b

    invoke-static {v2, v3, v4}, Ly41;->j(IILjava/lang/String;)I

    move-result v2

    const/16 v0, 0x4fd

    iget v4, p0, La12;->f:I

    nop

    const/16 v0, 0x19b

    invoke-static {v4, v2, v3}, Lmz2;->g(III)I

    move-result v2

    const/16 v0, 0x29b

    iget v4, p0, La12;->g:I

    nop

    const/16 v0, 0x19b

    invoke-static {v4, v2, v3}, Lmz2;->g(III)I

    move-result v2

    const/16 v0, 0x530

    iget-boolean v4, p0, La12;->h:Z

    nop

    const/16 v0, 0x10a

    invoke-static {v4}, Ljava/lang/Boolean;->hashCode(Z)I

    move-result v4

    add-int/2addr v4, v2

    mul-int/2addr v4, v3

    const/16 v0, 0x2af

    iget-boolean v2, p0, La12;->i:Z

    nop

    const/16 v0, 0x10a

    invoke-static {v2}, Ljava/lang/Boolean;->hashCode(Z)I

    move-result v2

    add-int/2addr v2, v4

    mul-int/2addr v2, v3

    const/16 v0, 0x37b

    iget v4, p0, La12;->j:I

    nop

    const/16 v0, 0x19b

    invoke-static {v4, v2, v3}, Lmz2;->g(III)I

    move-result v2

    const/16 v0, 0x355

    iget-boolean v4, p0, La12;->k:Z

    nop

    const/16 v0, 0x10a

    invoke-static {v4}, Ljava/lang/Boolean;->hashCode(Z)I

    move-result v4

    add-int/2addr v4, v2

    mul-int/2addr v4, v3

    const/16 v0, 0x3b6

    iget-boolean p0, p0, La12;->l:Z

    nop

    const/16 v0, 0x10a

    invoke-static {p0}, Ljava/lang/Boolean;->hashCode(Z)I

    move-result p0

    add-int/2addr p0, v4

    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 5

    const/4 v0, -0x3

    new-instance v2, Ljava/lang/StringBuilder;

    nop

    const-string/jumbo v3, "ServerInfo(serverhostaddr="

    const/16 v0, 0x97

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/16 v0, 0x4ba

    iget-object v3, p0, La12;->a:Ljava/lang/String;

    nop

    const/4 v0, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v3, ", serverFlagResourceId="

    const/4 v0, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x3fc

    iget v3, p0, La12;->b:I

    nop

    const/16 v0, 0x33

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v3, ", serverabrv="

    const/4 v0, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x479

    iget-object v3, p0, La12;->c:Ljava/lang/String;

    nop

    const/4 v0, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v3, ", countryname="

    const/4 v0, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x350

    iget-object v3, p0, La12;->d:Ljava/lang/String;

    nop

    const/4 v0, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v3, ", serverTime="

    const/4 v0, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x36b

    iget-object v3, p0, La12;->e:Ljava/lang/String;

    nop

    const/4 v0, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v3, ", srvUsageLvl="

    const/4 v0, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x4fd

    iget v3, p0, La12;->f:I

    nop

    const/16 v0, 0x33

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v3, ", serverTimeStatus="

    const/4 v0, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x29b

    iget v3, p0, La12;->g:I

    nop

    const/16 v0, 0x33

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v3, ", loading="

    const/4 v0, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x530

    iget-boolean v3, p0, La12;->h:Z

    nop

    const/16 v0, 0x6a

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string/jumbo v3, ", loaderror="

    const/4 v0, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x2af

    iget-boolean v3, p0, La12;->i:Z

    nop

    const/16 v0, 0x6a

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string/jumbo v3, ", errorCount="

    const/4 v0, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x37b

    iget v3, p0, La12;->j:I

    nop

    const/16 v0, 0x33

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string/jumbo v3, ", selected="

    const/4 v0, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x355

    iget-boolean v3, p0, La12;->k:Z

    nop

    const/16 v0, 0x6a

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const-string/jumbo v3, ", connected="

    const/4 v0, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v0, 0x3b6

    iget-boolean p0, p0, La12;->l:Z

    nop

    const/16 v0, 0x6a

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/16 p0, 0x29

    const/16 v0, 0x1b

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v0, -0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    check-cast p0, Ljava/lang/String;

    return-object p0
.end method
