.class public final synthetic Lod;
.super Ljava/lang/Object;
.source "r8-map-id-adab7f8a469d0adb41290c753ded15c97d17d08051cab7bdb8dee3c679a8c018"

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# instance fields
.field public final synthetic a:I

.field public final synthetic b:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 5

    iput p1, p0, Lod;->a:I

    iput-object p2, p0, Lod;->b:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .registers 6

    .prologue
    const/16 v0, 0xa5e

    iget v2, p0, Lod;->a:I

    nop

    const/16 v0, 0xb37

    iget-object p0, p0, Lod;->b:Ljava/lang/Object;

    nop

    packed-switch v2, :pswitch_data_8c

    check-cast p0, Lcom/google/android/material/chip/Chip;

    const/16 v0, 0xab3

    sget-object v2, Lcom/google/android/material/chip/Chip;->w:Landroid/graphics/Rect;

    nop

    const/16 v0, 0xae7

    iget-object p0, p0, Lcom/google/android/material/chip/Chip;->i:Landroid/widget/CompoundButton$OnCheckedChangeListener;

    nop

    if-eqz p0, :cond_20

    const/16 v0, 0x5aa

    invoke-interface {p0, p1, p2}, Landroid/widget/CompoundButton$OnCheckedChangeListener;->onCheckedChanged(Landroid/widget/CompoundButton;Z)V

    :cond_20
    return-void

    :pswitch_21  #0x1
    check-cast p0, Lrd;

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x208

    invoke-virtual {p0}, Lrd;->d()Landroid/content/SharedPreferences;

    move-result-object p1

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x7a

    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    const-string/jumbo v2, "appfilter_mode"

    const/16 v0, 0x48

    invoke-interface {p1, v2, p2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x6f

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/16 v0, 0x1d7

    iget-object p1, p0, Lrd;->s:Landroidx/appcompat/widget/SwitchCompat;

    nop

    if-eqz p1, :cond_61

    if-eqz p2, :cond_57

    const p2, 0x7f13002b

    :goto_50
    const/16 v0, 0x4c

    invoke-virtual {p0, p2}, Landroidx/fragment/app/Fragment;->getString(I)Ljava/lang/String;

    move-result-object p0

    goto :goto_5b

    :cond_57
    const p2, 0x7f13002c

    goto :goto_50

    :goto_5b
    const/16 v0, 0x8a

    invoke-virtual {p1, p0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void

    :cond_61
    const/4 v0, 0x5

    invoke-static {v2}, Lgt0;->F0(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0

    :pswitch_67  #0x0
    check-cast p0, Lrd;

    const/4 v0, -0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x208

    invoke-virtual {p0}, Lrd;->d()Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v0, -0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/16 v0, 0x7a

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const-string/jumbo p1, "appfilter"

    const/16 v0, 0x48

    invoke-interface {p0, p1, p2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/16 v0, 0x6f

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    return-void

    nop

    :pswitch_data_8c
    .packed-switch 0x0
        :pswitch_67  #00000000
        :pswitch_21  #00000001
    .end packed-switch
.end method
